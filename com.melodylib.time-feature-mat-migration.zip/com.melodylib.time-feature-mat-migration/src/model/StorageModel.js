import JSONModel from "sap/ui/model/json/JSONModel"

const jsonModel = new JSONModel({});
jsonModel.setSizeLimit(9999);
export default jsonModel;