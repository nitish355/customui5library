import JSONModel from "sap/ui/model/json/JSONModel";
import ResourceModel from "sap/ui/model/resource/ResourceModel";
import BaseState from "com/melodylib/core/state/BaseState";
import MasterService from "com/melodylib/core/service/MasterService";
import Settings from "com/melodylib/time/classes/Settings";
import DateService from "com/melodylib/core/service/DateService"

/**
 * @name com.melodylib.core.state.TimeModels
 */
export default class TimeModels extends BaseState {
	constructor() {
		super(MasterService.getInstance());
		this.setData({});
	}

	static getInstance() {
		if (!this._instance) {
			this._instance = new TimeModels();
		}
		return this._instance;
	}
	static getMTRResourceModel() {
		let oModel = sap.ui.getCore().getModel("i18nMTR");

		if (!oModel) {
			oModel = new ResourceModel({
				bundleName: "com.melodylib.time.i18n.i18n",
				supportedLocales: ["en", "de"],
				fallbackLocale: "en"
			});
			sap.ui.getCore().setModel(oModel, "i18nMTR");
		}
		return oModel;
	}
	static getMTRSettingsModel() {
		let oSettingsModel = sap.ui.getCore().getModel("mtrSettings");

		if (!oSettingsModel) {
			const oSettings = new Settings();
			// const oSettings = new com.melodylib.time.classes.Settings();
			oSettingsModel = new JSONModel(oSettings);
			sap.ui.getCore().setModel(oSettingsModel, "mtrSettings");
		}
		return oSettingsModel;
	}
	static getMatrixModel(){
		let oModel = sap.ui.getCore().getModel("matrixModel");
			if (!oModel) {
				const matrixModelData = {
					"matrixCategory": "activity",
					"registrationTypes": [{
						"name": "Account",
						"type": true,
						"key": "4",
						"isEnabled": true,
						"isPressed": true,
						"keyId": 0,
						"ActvtAsstdID": "501"
					}, {
						"name": "Opportunity",
						"type": false,
						"key": "1",
						"isEnabled": true,
						"isPressed": false,
						"keyId": 1,
						"ActvtAsstdID": "502"
					}, {
						"name": "No Association",
						"type": false,
						"key": "2",
						"isEnabled": true,
						"isPressed": false,
						"keyId": 2,
						"ActvtAsstdID": "503"
					}],
					"matrixLearningData": [{
						"selectedAssociation": "",
						"activityMode": "NEW",
						"activityId": ""
					}],
					"tempExistingActivities": [],
					"existingActivities": [{
						"ActTypeDesc": "",
						"StartDate": "",
						"ActStatusDesc": "",
						"IsSelected": false
					}],
					"ActTypesForFilter": "",
					"ActStatusForFilter": "",
					"StartOfStartDateRange": null,
					"EndOfStartDateRange": null,
					"StartOfEndDateRange": null,
					"EndOfEndDateRange": null,
					"totalHours": {
						Date1: 0,
						Date2: 0,
						Date3: 0,
						Date4: 0,
						Date5: 0,
						Date6: 0,
						Date7: 0,
					},
					"subTotalHours": {
						Date1: 0,
						Date2: 0,
						Date3: 0,
						Date4: 0,
						Date5: 0,
						Date6: 0,
						Date7: 0,
					},
					"activityData": {
						"activityId": "",
						"startDate": ""
					},
					"IsSaveBusy": false,
					"IsSubmitBusy": false,
					"matrixMenu": [{
						"name": "New Activity",
						"key": "1"
					}, {
						"name": "Existing Activity",
						"key": "2"
					}],
					"aMatrixDrafts": [],
					"SearchBarMenu": [{
						"name": "Account",
						"key": "4",
						"ActvtAsstdID": "501"
					}, {
						"name": "Opportunity",
						"key": "1",
						"ActvtAsstdID": "502"
					}, {
						"name": "No Association",
						"key": "2",
						"ActvtAsstdID": "503"
					}],
					"aSortColumns": [{
						key: "AccountName",
						text: "Account",
						selected: false
					}, {
						key: "OpportunityName",
						text: "Opportunity",
						selected: false
					}],
					"filterBarKey": "502",
					"sSearchMatrixList": ""
				};
				oModel = new JSONModel(matrixModelData);
				oModel.setSizeLimit(99999);
				sap.ui.getCore().setModel(oModel, "matrixModel");
			}
			return oModel;
	}
	static getTargetModel (){
		let oModel = sap.ui.getCore().getModel("target");

			if (!oModel) {
				oModel = new JSONModel({
					Holidays: [],
					Vacations: [],
					TargetHours: []
				});
				sap.ui.getCore().setModel(oModel, "target");
			}
			return oModel;
	}
	static getSolutionHierarchyModel(){
		let oSolutionsModel = sap.ui.getCore().getModel("oSolutionsModel");
			if (!oSolutionsModel) {
				oSolutionsModel = new JSONModel([]);
				oSolutionsModel.setSizeLimit(99999);
				sap.ui.getCore().setModel(oSolutionsModel, "oSolutionsModel");
			}
			return oSolutionsModel;
	}
	static getDayWeekTimesheetModel() {

			let oModel = sap.ui.getCore().getModel("dayWeekTimesheet");

			if (!oModel) {
				oModel = new JSONModel({
					SelectedDate: DateService.getInstance().format(new Date(), "EEEE, MMMM dd,y"),
					NewEntry: null,
					Entries: [],
					TempEntries: []
				});
				sap.ui.getCore().setModel(oModel, "dayWeekTimesheet");
			}
			return oModel;
		}
	static getMessagesModel() {

		let oModel = sap.ui.getCore().getModel("messages");

		if (!oModel) {
			oModel = new JSONModel([]);
			sap.ui.getCore().setModel(oModel, "messages");
		}
		return oModel;
	}
		static getMessagePopoverModel() {
			let oMessagePopoverModel = sap.ui.getCore().getModel("messagePopoverModel");
			if (!oMessagePopoverModel) {
				oMessagePopoverModel = new JSONModel({
					"aMessageData": [],
					"aSources": []
				});
				sap.ui.getCore().setModel(oMessagePopoverModel, "messagePopoverModel");
			}
			return oMessagePopoverModel;
		}
}
