import BaseState from "com/melodylib/core/state/BaseState";
import TimeMasterService from "com/melodylib/time/service/TimeMasterService";
import Task from "com/melodylib/time/classes/Task";
import Category from "com/melodylib/time/classes/Category"
import IndexedDB from "com/melodylib/core/db/IndexedDB";
import AuthState from "com/melodylib/core/state/AuthState";
import Status from "com/melodylib/time/enum/Status";


/**
 * @name com.melodylib.time.state.TimeMasterState
 */
export default class TimeMasterState extends BaseState {
    constructor() {

        super();
        this._service = TimeMasterService.getInstance();
       
        const data = {
            timesheetModes: [],
            dateFormats: [],
            tasks: [],
            categories: [],
            entryStatuses: [{       // 1- Saved, 2 - In Queue, 3 - Failed, 4 -Submitted
                id: Status.Saved,
                value: "Saved"
            }, {
                id: Status.InQueue,
                value: "In Queue"
            }, {
                id: Status.Failed,
                value: "Failed"
            }, {
                id: Status.Submitted,
                value: "Submitted"
            }]
        }
        this._data = data;

    }

    static getInstance() {
        if (!this._instance) {
            this._instance = new TimeMasterState();
        }
        return this._instance;
    }

    async init() {
        await this.getDomainHelp();
    }

    async getDomainHelp() {
		const { data } = await this._service.getDomainHelp();
        const results = data?.results || [];
		const timesheetModes = results.filter(function (domain) {
			return domain.Type === "YDO_TIMESHEETPREF";
		});
		const dateFormats = results.filter(function (domain) {
			return domain.Type === "YDO_DATEFORMARTID";
		});
        this._data.timesheetModes = timesheetModes;
		this._data.dateFormats = dateFormats;
	}

    

    getTasks() {
        return this.getData().tasks;
    }

    getCategories() {
        return this.getData().categories;
    }

    getEssInMuTasks() {
        const authState = AuthState.getInstance();
        const user = authState.getData();
        const essInMu = user.EssInMu;
        this._data.essInMuTasks = this._data.tasks.filter(function (task) {
            return (essInMu && !task.essInMu) || !essInMu;
        });
        return this._data.essInMuTasks;
    }

    async fetchMasterByProfileId(profileId) {
        let mtrTasks = [];
        const data = await this._service.fetchMasterByProfileId(profileId);
        const tasks = data.to_Activity?.results ?? [];


        const constypemap = data.to_ActivityCostTypeMap?.results ?? [];
        const costtypes = data.to_CostType?.results ?? [];
        const locationmap = data.to_ActivityLocationMap?.results ?? [];
        const locations = data.to_Location?.results ?? [];

        for (let i = 0; i < tasks.length; i++) {
            const mtrTask = new Task({
                taskId: tasks[i].activity_id,
                taskName: tasks[i].ActivityName,
                taskDescription: tasks[i].ActivityDescription,
                categoryId: tasks[i].CategoryId.toString(),
                addCategoryId: tasks[i].AddCategoryId.toString(),
                isArchive: tasks[i].IsArchive ? true : false,
                costTypes: [],
                locations: [],
                activityShortName: tasks[i].ActivityShortName,
                ispSubTaskDes: tasks[i].IspSubTaskDes,
                isCostCentre: tasks[i].IsCostCentre,
                isOpportunity: tasks[i].IsOpportunity,
                isManualIO: tasks[i].IsManualIo,
                isAccount: tasks[i].IsAccount,
                isPlaceholder: tasks[i].IsPlaceholder,
                isRemote: tasks[i].IsRemote,
                ispTask: tasks[i].IspTask,
                ispTaskDescription: tasks[i].IspTaskdes,
                ispSubTask: tasks[i].IspSubTask,
                essInMu: (tasks[i].EssInMu && (tasks[i].EssInMu === "X")) ? true : false,
                taskLevel: tasks[i].TaskLevel,
                taskCompHours: tasks[i].TaskCompHours,
                taskCompDays: tasks[i].TaskCompDays,
                isLearning: (tasks[i].AddCategoryId && tasks[i].AddCategoryId === 4) ? true : false
            });

            const filteredcosttype = constypemap.filter(item => item.ActivityID === mtrTask.taskId);
            for (let j = 0; j < filteredcosttype.length; j++) {
                const costtype = costtypes.find(item => item.CostTypeID === filteredcosttype[j].CostTypeID);
                mtrTask.costTypes.push({
                    id: costtype.CostTypeID,
                    name: costtype.CostTypeName
                });
            }

            const filteredlocations = locationmap.filter(item => item.ActivityID === mtrTask.taskId);
            for (let j = 0; j < filteredlocations.length; j++) {
                const location = locations.find(item => item.LocationId === filteredlocations[j].LocationID && item.LocationId.toString() !==
                    "2" && item.LocationId.toString() !== "3");
                if (location) {
                    mtrTask.locations.push({
                        id: location.LocationId,
                        name: location.LocationName
                    });
                }
            }

            mtrTasks.push(mtrTask);
        }

        mtrTasks = mtrTasks.sort(function (a, b) {
            return a.taskId - b.taskId;
        });

        let categories = Array.from(
            data.to_Category.results,
            (category) =>
                new Category(category)
        );
        IndexedDB.fnInsertDataToDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "mtrTasksData",
            aObjectsToInsert: mtrTasks,
        });

        IndexedDB.fnInsertDataToDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "mtrCategoriesData",
            aObjectsToInsert: categories,
        });

        this._data.tasks = mtrTasks;
        this._data.categories = categories;
        this.updateModel();
    }

}
