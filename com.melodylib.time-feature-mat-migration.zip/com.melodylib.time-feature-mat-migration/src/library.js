/*!
 * ${copyright}
 */

/**
 * Initialization Code and shared classes of library com.melodylib.time.
 */
sap.ui.define([
	"sap/ui/core/library"
], function () {
	"use strict";

	// delegate further initialization of this library to the Core
	// Hint: sap.ui.getCore() must still be used to support preload with sync bootstrap!
	sap.ui.getCore().initLibrary({
		name: "com.melodylib.time",
		version: "${version}",
		dependencies: [ // keep in sync with the ui5.yaml and .library files
			"sap.ui.core",
			"sap.viz"
		],
		types: [
			"com.melodylib.time.ExampleColor"
		],
		interfaces: [],
		controls: [
			"com.melodylib.time.Example",
			"com.melodylib.time.controls.TimeEntryButton",
			"com.melodylib.time.controls.calendar.Calendar",
			"com.melodylib.time.controls.calendar.DayWeekCalendar",
			"com.melodylib.time.controls.calendar.MatrixCalendar"
			

		],
		elements: [
			"com.melodylib.state.TimeState"
		],
		noLibraryCSS: false, // if no CSS is provided, you can disable the library.css load here
		noLibraryPreload : false

	});

	/**
	 * Some description about <code>com.melodylib.time</code>
	 *
	 * @namespace
	 * @name com.melodylib.time
	 * @author DARSHAN PULIKESHI
	 * @version ${version}
	 * @public
	 */
	var thisLib = com.melodylib.time;

	/**
	 * Semantic Colors of the <code>com.melodylib.time.Example</code>.
	 *
	 * @enum {string}
	 * @public
	 */
	thisLib.ExampleColor = {

		/**
		 * Default color (brand color)
		 * @public
		 */
		Default : "Default",

		/**
		 * Highlight color
		 * @public
		 */
		Highlight : "Highlight"

	};

	return thisLib;

});
