/*!
 * ${copyright}
 */
sap.ui.define([
	"sap/m/Button",
	"sap/ui/Device",
	"sap/ui/core/Control",
	"sap/ui/core/Fragment",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/resource/ResourceModel",

	"com/melodylib/time/enum/Actions",
	"com/melodylib/time/classes/Account",
	"com/melodylib/time/model/StorageModel",
	"com/melodylib/time/model/TimeModels",
	
	"com/melodylib/time/model/formatter"
], function (
	Button,
	Device,
	Control,
	Fragment,
	Filter,
	FilterOperator,
	JSONModel,
	MessageToast,
	Controller,
	ResourceModel,
	Actions,
	Account,
	oStorageModel,
	MTRModels,
	formatter
) {
	"use strict";

	let oController;

	/* ===================================================== */
	/* ================= MessageHelper ===================== */
	/* ===================================================== */

	const MessageHelper = {

		fnStaticInit: function (oParentRef) {
			this.self = oParentRef;
		},

		onInitializeMessageDialog: async function (oSource) {
			let self = this;
			let oMessagePopoverModel = MTRModels.getMessagePopoverModel();

			if (!self._oMessageDialog) {
				self._oMessageDialog = Fragment.load({
					id: "_MessageInfoPopupDialog",
					name: "com.melodylib.time.controls.calendar.matrix.fragments.MessagePopover",
					controller: self.MessageDialogControl
				}).then(function (oDialog) {
					oDialog.setModel(oMessagePopoverModel, "messagePopoverModel");
					self.addDependent(oDialog);
					self.MessageDialogControl.fnLoadLangModel(oDialog);
					return oDialog;
				}.bind(self));
			}

			self._oMessageDialog.then(function (oDialog) {
				oMessagePopoverModel.setProperty("/sMsgPopoverId", oDialog.getId());
				oMessagePopoverModel.refresh();
				oDialog.openBy(oSource);
			});
		},

		fnGetDialogUsingId: function (dialogId, contentId) {
			return sap.ui.core.Fragment.byId(dialogId, contentId);
		},

		fnLoadResourceBundle: function (dialog) {
			let i18nModel = new ResourceModel({
				bundleName: "com.melody.lib.i18n.i18n"
			});
			if (dialog) {
				dialog.setModel(i18nModel, "i18n");
			}
		},

		fnRemoveEmptyRecords: function (aRecords) {
			return aRecords.filter(function (oMessage) {
				return oMessage.title && oMessage.title.trim();
			});
		},

		fnFilterRecordByActivityId: function (aRecords, activityId) {
			if (!activityId) {
				return aRecords;
			}
			return aRecords.filter(function (oMessage) {
				if (oMessage.hasOwnProperty("activityId")) {
					oMessage.activityId = oMessage.activityId
						? oMessage.activityId.replace(/^0+/, "")
						: "";
					return oMessage.activityId === activityId;
				}
			});
		}
	};

	/* ===================================================== */
	/* ============ MessageDialogController ================= */
	/* ===================================================== */

	const MessageDialogController = Controller.extend(
		"com.melody.lib.util.message.MessageDialogController",
		{
			formatter: formatter,

			constructor: function (oParentref) {
				this.self = oParentref;
			},

			onClearMessages: function () {
				let oMessageModel = MTRModels.getMessagesModel();
				let oMessagePopoverModel = MTRModels.getMessagePopoverModel();
				oMessageModel.setData([]);
				oMessagePopoverModel.setProperty("/aMessageData", []);
				oMessagePopoverModel.refresh();
			},

			onActiveTitlePressMessage: function (oEvent) {
				let oSelectedItem = oEvent.getParameter("item");
				let oItemObject =
					oSelectedItem.getBindingContext("messagePopoverModel").getObject() || {};
				let statusId = oItemObject.statusId ? oItemObject.statusId.toString() : "";
				MessageUtil.fnRouteToMyEntries(statusId);
			},

			fnGetHashValue: function () {
				let oHashChanger = new sap.ui.core.routing.HashChanger();
				return oHashChanger.getHash();
			},

			fnGetLinkAccess: function (value) {
				let hashValue = this.fnGetHashValue();
				if (
					hashValue &&
					(hashValue.includes("pcactivityform-app&/MyEntries") ||
						hashValue.includes("/MyEntries"))
				) {
					return false;
				}
				return value;
			}
		}
	);

	/* ===================================================== */
	/* ================= MessageUtil ======================== */
	/* ===================================================== */

	const MessageUtil = {

		fnStaticInit: function (oParentRef) {
			this.self = oParentRef;
			MessageHelper.fnStaticInit(oParentRef);
			this.fnLoadMessageController(oParentRef);
		},

		fnLoadMessageController: function (oParentRef) {
			if (!oParentRef.MessageDialogControl) {
				oParentRef.MessageDialogControl =
					new MessageDialogController(oParentRef);
				oParentRef.MessageDialogControl.fnLoadLangModel =
					MessageHelper.fnLoadResourceBundle;
			}
		},

		fnOpenMessagePopover: function (oButtonSrc) {
			if (!oButtonSrc) {
				MessageToast.show("MessagePopover Button Source is Invalid");
				return;
			}

			if (!this.self._oMessageDialog) {
				MessageHelper.onInitializeMessageDialog.call(this.self, oButtonSrc);
			} else {
				this.self._oMessageDialog.then(function (oDialog) {
					oDialog.openBy(oButtonSrc);
				});
			}
		},

		fnSetFormatMessageDataBasedOnId: function (activityId) {
			let oMessageModel = MTRModels.getMessagesModel();
			let oMessagePopoverModel = MTRModels.getMessagePopoverModel();

			if (oMessageModel) {
				let aMessageData = $.extend(true, [], oMessageModel.getData());
				if (activityId) {
					aMessageData =
						MessageHelper.fnFilterRecordByActivityId(aMessageData, activityId);
				}
				oMessageModel.setData(aMessageData);
				oMessagePopoverModel.setProperty("/aMessageData", aMessageData);
			}
		},

		fnRouteToMyEntries: function (statusId, projectType) {
			let statusValue = "";
			statusId = statusId ? statusId.toString() : "0";

			switch (statusId) {
				case "1":
					statusValue = "savedEntries";
					break;
				case "3":
					statusValue = "failedEntries";
					break;
				case "4":
					statusValue = "submittedEntries";
					break;
				default:
					statusValue = "savedEntries";
			}

			let oHashChanger = new sap.ui.core.routing.HashChanger();
			let hashValue = oHashChanger.getHash();

			if (
				hashValue &&
				(hashValue.includes("pcactivityform-app&/MyEntries") ||
					hashValue.includes("/MyEntries"))
			) {
				return;
			}

			let routeUrl = `#pcactivityform-app&/MyEntries?StatusId=${statusValue}`;
			oHashChanger.replaceHash(routeUrl);
		}
	};

	/* ===================================================== */
	/* ================= Custom Control ===================== */
	/* ===================================================== */

	const MessagepopoverButton = Button.extend(
		"com.melody.lib.controls.MessagepopoverButton",
		{
			metadata: {
				properties: {
					activityId: { type: "string", defaultValue: null }
				}
			},

			init: function () {
				oController = this;
				this.addStyleClass("sapMessagePopoverCustomBtn");
				this.setType("Emphasized");
				this.setIcon("sap-icon://alert");

				this.setModel(MTRModels.getMessagesModel(), "messages");
				MessageUtil.fnStaticInit(this);

				this.bindProperty("text", {
					path: "messages>/",
					formatter: this.fnFormatterFunctionForText.bind(this)
				});

				this.bindProperty("enabled", {
					path: "messages>/",
					formatter: this.fnFormatterFunctionForBoolean.bind(this)
				});

				this.attachPress(this.onPressMessagePopoverBtn.bind(this));
			},

			fnFormatterFunctionForText: async function (value) {
				this.setBusy(true);
				await new Promise(resolve => setTimeout(resolve, 1000));
				value = value || [];
				if (this.getActivityId()) {
					value = MessageHelper.fnFilterRecordByActivityId(
						value,
						this.getActivityId()
					);
				}
				this.setBusy(false);
				return value.length;
			},

			fnFormatterFunctionForBoolean: async function (value) {
				this.setBusy(true);
				await new Promise(resolve => setTimeout(resolve, 1000));
				value = value || [];
				if (this.getActivityId()) {
					value = MessageHelper.fnFilterRecordByActivityId(
						value,
						this.getActivityId()
					);
				}
				this.setBusy(false);
				return !!value.length;
			},

			onPressMessagePopoverBtn: function (oEvent) {
				let activityId = oEvent.getSource().getActivityId();
				let oMessageModel = MTRModels.getMessagesModel();
				let oMessagePopoverModel = MTRModels.getMessagePopoverModel();

				let sOpenedDialog =
					oMessagePopoverModel.getProperty("/sMsgPopoverId");
				let oOpenedPreviousDialog =
					sap.ui.getCore().byId(sOpenedDialog);

				if (
					oOpenedPreviousDialog &&
					oOpenedPreviousDialog.isOpen &&
					oOpenedPreviousDialog.isOpen()
				) {
					oOpenedPreviousDialog.close();
				}

				if (oMessageModel) {
					let aMessageData = $.extend(true, [], oMessageModel.getData());
					if (activityId) {
						aMessageData =
							MessageHelper.fnFilterRecordByActivityId(
								aMessageData,
								activityId
							);
					}
					oMessagePopoverModel.setProperty("/aMessageData", aMessageData);
				}

				MessageUtil.fnOpenMessagePopover(oEvent.getSource());
			},

			renderer: {
				render: function (oRm, oControl) {
					sap.m.ButtonRenderer.render(oRm, oControl);
				}
			}
		}
	);

	return MessagepopoverButton;
});
