/*!
 * ${copyright}
 */
import Button from "sap/m/Button";
import Control from "sap/ui/core/Control";
import Controller from "sap/ui/core/mvc/Controller";
import ResourceBundle from "sap/base/i18n/ResourceBundle";
import ResourceModel from "sap/ui/model/resource/ResourceModel";
import JSONModel from "sap/ui/model/json/JSONModel";
import TimeEntryButtonRenderer from "com/melodylib/time/controls/TimeEntryButtonRenderer";
import TimeState from "com/melodylib/time/state/TimeState";
import Helper from "com/melodylib/core/util/Helper";
import OreService from "com/melodylib/core/service/OREService";
import AuthState from "com/melodylib/core/state/AuthState";
import TimeModels from "com/melodylib/time/model/TimeModels";
import Actions from "com/melodylib/time/enum/Actions";
import MatrixTimeController,{oMatrix} from "com/melodylib/time/controls/calendar/matrix/Matrix"
import Entry from "com/melodylib/time/classes/Entry"
import TimeMasterState from "com/melodylib/time/state/TimeMasterState";
import DateService from "com/melodylib/core/service/DateService";
import OpportunityState from "com/melodylib/integration/state/OpportunityState";
import AccountState from "com/melodylib/integration/state/AccountState";
import StaffingState from "com/melodylib/time/state/StaffingState";
import dayController  from "com/melodylib/time/controls/calendar/day/Day";
import { oMTRHelper } from "./calendar/day/Day";
import  Fragment  from "sap/ui/core/Fragment"


/**
 * Constructor for a new <code>com.melodylib.integration.controls.AccountSelect</code> control.
 *
 * Some class description goes here.
 * @extends Control
 *
 * @author Siddharth Sagvekar
 * @version ${version}
 *
 * @constructor
 * @public
 * @name com.melodylib.time.controls.TimeEntryButton
 */


export default class TimeEntryButton extends Button {
	static metadata = {
		library: "com.melodylib.time",
		properties: {
			selectedActivity: {
				type: "object",
				defaultValue: null
			},

			entries: {
				type: "object",
				defaultValue: []
			},

			mtrUid: {
				type: "string",
				defaultValue: ""
			},

			statusId: {
				type: "string",
				defaultValue: ""
			},
		},
		events: {
			updateEntries: {
				parameters: {
					"updateEntries": {
						type: "boolean"
					}
				}
			}
		},

		aggregations: {
			_button: {
				type: "sap.m.Button",
				multiple: false,
				visibility: "hidden",
			}
		}

		
		
	};
	static renderer = TimeEntryButtonRenderer;

	init() {

		
		  
		this.controller = new TimeEntryButtonController(this);
		//this.controller.TimeState.init();
		const oData = this.controller.TimeState.getData();
		this.oTimeMasterIntance = TimeMasterState.getInstance()
		
		
		
		// this.getAggregation("_button").setVisible(true);

		this.setAggregation(
			"_button",
			new sap.m.Button(this.getId() + "-button", {
				text: "Create Time Entry",
				type: "Transparent",
				icon: "sap-icon://create-entry-time",
				press: this.openTimeDialog.bind(this)
			})
		);
		this.setBusyIndicatorDelay(0);
		this.setBusy(true);

		// set i18n model on view
		var i18nModel = new ResourceModel({
			bundleName: "com.melodylib.time.i18n.i18n"
		});
		sap.ui.getCore().setModel(i18nModel, "i18n");

		const oModel = new JSONModel({
			User: null,
			UserSetting: null,
			MtrTasks: [],
			SelectedDates: [],
			SelectedActivity: null,
			SelectedMtrTask: null,
			SelectedLocationId: "",
			ShowCalendar: false,
			Entries: [{
				RecordDate: "04/11/2021",
				Task: "Business Development - CF",
				Location: "Virtual",
				Activity: "Demand Generation - PreBA",
				Type: "Cost Center: 0176000711",
				WorkDuration: "8.0"
			}, {
				RecordDate: "11/11/2021",
				Task: "Business Development - CF",
				Location: "Virtual",
				Activity: "Demand Generation - PreBA",
				Type: "Cost Center: 0176000711",
				WorkDuration: "8.0"
			}, {
				RecordDate: "12/11/2021",
				Task: "Business Development - CF",
				Location: "Virtual",
				Activity: "Demand Generation - PreBA",
				Type: "Cost Center: 0176000711",
				WorkDuration: "8.0"
			}]
		});
		this.DurationSuggestion = {
			Hour: [{
				key: "0.5",
				value: "0.5",
				allowedOnDay: true
			}, {
				key: "1.0",
				value: "1.0",
				allowedOnDay: true
			}, {
				key: "1.5",
				value: "1.5",
				allowedOnDay: false
			}, {
				key: "2.0",
				value: "2.0",
				allowedOnDay: false
			}, {
				key: "2.5",
				value: "2.5",
				allowedOnDay: false
			}, {
				key: "3.0",
				value: "3.0",
				allowedOnDay: false
			}, {
				key: "3.5",
				value: "3.5",
				allowedOnDay: false
			}, {
				key: "4.0",
				value: "4.0",
				allowedOnDay: false
			}, {
				key: "4.5",
				value: "4.5",
				allowedOnDay: false
			}, {
				key: "5.0",
				value: "5.0",
				allowedOnDay: false
			}, {
				key: "5.5",
				value: "5.5",
				allowedOnDay: false
			}, {
				key: "6.0",
				value: "6.0",
				allowedOnDay: false
			}, {
				key: "6.5",
				value: "6.5",
				allowedOnDay: false
			}, {
				key: "7.0",
				value: "7.0",
				allowedOnDay: false
			}, {
				key: "7.5",
				value: "7.5",
				allowedOnDay: false
			}, {
				key: "8.0",
				value: "8.0",
				allowedOnDay: false
			}],
			Day: [{
				key: "0.5",
				value: "0.5",
				allowedOnDay: true
			}, {
				key: "1.0",
				value: "1.0",
				allowedOnDay: true
			}]
		}

		this.setModel(oModel);
		this.setModel(i18nModel, "i18n");
		oMatrix.init(this);
		this.setTooltip("Create Time Entry");
		this.setBusy(false);
	}

	async openTimeDialog(event) {
		let that = this;
		const control = event.getSource().getParent();
		const oThisController = new MatrixTimeController(oMatrix);
		const dayWeekController = new dayController();
		const matrixModel = TimeModels.getMatrixModel();
		const timeStateModel = this.controller.TimeState.getModel();
		const authStateModel = AuthState.getInstance().getModel();
		const timeMasterState = TimeMasterState.getInstance().getModel();
		const models = [
			{model : matrixModel, name : "matrixModel"},
			{model : timeStateModel, name : "timeState"},
			{model : authStateModel, name : "authState"},

		]
		
		const authState = AuthState.getInstance();
		const user = authState.getData();
		const bEssInMu = user.time.essInMu;
		var oppor = OpportunityState.getInstance().getData();
		var acnts = AccountState.getInstance().getData();
		var aStaffingRecord = StaffingState.getInstance().getData();
		
		let fragment = {};


		try {
			let oMatrixEntry = {
				"isMatrixEditList": false,
				"activeTab": Actions.matrixCategory.activity,
				"taskId": "",
				"activityId": "",
				"startDate": new Date(),
				"costTypeId": "",
				"costTypeValue": ""
			};
			
			const MatrixViewAccess = user.time.MatrixViewAccess;
			let oTimeRecordingOption = await OreService.getTimeSheetPreference(user.id) || {};
			let isMatrixView = ("Value" in oTimeRecordingOption && oTimeRecordingOption.Value === "1" && MatrixViewAccess === "X") ? true :
				false;

		
				if (!isMatrixView) {
					TimeState.getInstance().filterEntries();
				}
				const oSelectedActivity = this.getSelectedActivity();
				let dDate = new Date();
				if (oSelectedActivity && oSelectedActivity.StartDate) {
					let actStartDate = new Date(oSelectedActivity.StartDate);
					if (actStartDate >= dDate) {
						dDate = (oSelectedActivity.StartDate) ? oSelectedActivity.StartDate : new Date();
					}
				}
				let sDate = DateService.getInstance().format(dDate, "yMMdd");
				let oEntry = new Entry({
					recordDate: sDate
				});
				if(oSelectedActivity){

				}
				else {
					
					let oModel = this._setModel(oEntry);
					if (isMatrixView) {
						if (matrixModel) {
							const aValidActivityTaskId = oMatrix.getEntriesTaskIds().activityTaskId || [];
							const aValidLearningTaskId = oMatrix.getEntriesTaskIds().learningTaskIds || [];
							if (this.getMtrUid()) {
								oMatrixEntry = oThisController.fnGetActivityDataForMatrix(oThisController.getMtrUid(), "MYTIME");
								let taskId = (oMatrixEntry.taskId) ? parseInt(oMatrixEntry.taskId) : 0;
								if (aValidLearningTaskId.length && aValidLearningTaskId.indexOf(taskId) === -1 && !oMatrixEntry.activityId) {
									MessageToast.show("Please select Edit from MTR.");
									return;
								}
							}

						}
						matrixModel.setProperty("/defaultEntry",oMatrixEntry)
						let aMTRTasks = this.oTimeMasterIntance.getData().tasks;
						let aEntries = this.controller.TimeState.getData().entries;
						let oDefaultEntry = matrixModel.getProperty("/defaultEntry") || {};
						let oMTRSettingsModel = TimeModels.getMTRSettingsModel();
						oMTRSettingsModel.setProperty("/MTRTasks",aMTRTasks);
						oMTRSettingsModel.setProperty("/UserNotifEssInMu",bEssInMu)

						var activityStartDate = ("startDate" in oDefaultEntry && oDefaultEntry.startDate) ? oDefaultEntry.startDate : new Date();
						const oTaskIds = oMatrix.getEntriesTaskIds();
						matrixModel.setProperty("/aValidActivityTaskId", oTaskIds.activityTaskId);
						matrixModel.setProperty("/aValidLearningTaskId", oTaskIds.learningTaskIds);
						let libraryPath = jQuery.sap.getModulePath("resources.com.melodylib.time").replace("/resources", "");
						jQuery.sap.includeStyleSheet(libraryPath + "/css/matrixStyle.css");
						fragment = {
							i18n: 'com.melodylib.time.i18n.i18n',
							controller: oThisController,
							path: "com.melodylib.time.controls.calendar.matrix.fragments.MatrixCreateTimeEntry",
							name: "_TimeDialog",
							id: "_MatrixTimeRecordingDialog",
							model: control.getModel(),
							models: models,
						};
						const openFrag = Helper.openFragment.bind(control);
						openFrag(fragment, false, control).then(() => {
						let oDefaultEntry = matrixModel.getProperty("/defaultEntry") || {};
						matrixModel.setProperty("/MatrixListDialogBusy", false);
						matrixModel.setProperty("/IsSaveBusy", false);
						matrixModel.setProperty("/IsSubmitBusy", false);
						matrixModel.setProperty("/matrixCategory", oDefaultEntry.activeTab);
						matrixModel.setProperty("/sSearchMatrixList", "");
						oMatrix.seperateEntriesBasedOnDate(activityStartDate,true).then((aMatrixData) => {
							if (oDefaultEntry.activeTab === Actions.matrixCategory.learning) {
						 		matrixModel.setProperty("/matrixLearningData", aMatrixData);
							} else {
								matrixModel.setProperty("/matrixActivityData", aMatrixData);
							}
							 	matrixModel.setProperty("/MatrixListDialogBusy", false);
						 	matrixModel.refresh();
						});
							
						
					});

					}
					else{
						fragment = {
							i18n: "com.melodylib.time.i18n.i18n",
							controller: dayWeekController,
							path: "com.melodylib.time.controls.calendar.day.fragments.MTRDialog",
							name: "_TimeDialog",
							id: `${control.getId()}_TimeDialog`,
							model: oModel,
							models: models,
						};
						const openFrag = Helper.openFragment.bind(control);
						openFrag(fragment, false, control).then((oDialog) => {
					
							dayWeekController.DialogId = `${control.getId()}_TimeDialog`,
							dayWeekController.Model = oModel;
							dayWeekController._oTimeRecordingDialog = oDialog;
							oMTRHelper.setController(dayWeekController);
							//check for MyEntries Page in URL
							let oHashChanger = new sap.ui.core.routing.HashChanger();
							let hashValue = oHashChanger.getHash();
							if (hashValue && (hashValue.includes("pcactivityform-app&/MyEntries") || hashValue.includes("/MyEntries"))) {
								oModel.setProperty("/bVisibleTimeEntry", false);
							} else {
								oModel.setProperty("/bVisibleTimeEntry", true);
							}
							const sTimeMatrics = AuthState.getInstance().getData().time.unit;
							oModel.setProperty("/Durations", sTimeMatrics === "D" ? this.DurationSuggestion.Day : this.DurationSuggestion.Hour);
							const aEntries = TimeState.getInstance().getModel().getProperty("/entries")
							let oNewEntry = oModel.getProperty("/Entry");

							oModel.setProperty("/IsOtherTab", false);
							oModel.setProperty("/isOthersTabManualIO", false);
							oModel.setProperty("/isSpecialTask", false);
							oModel.setProperty("/MaxCapacityAlert", false);
							//handling edit case
							let oEntry;
							if(event.getSource().getBindingContext("timeState")){
								 oEntry = aEntries.find(item => item.guid === event.getSource().getBindingContext("timeState").getObject().guid);
							}
							else {
								oEntry = undefined;
							}
							
							if (oEntry) {
								dayWeekController.Model.setProperty("/IsEdit", true);
								oEntry.task.taskId = (oEntry.task.taskId) ? oEntry.task.taskId.toString() : "";
								const oClonedEntry = $.extend(true, {}, oEntry);
								dayWeekController.Model.setProperty("/Entry", oClonedEntry);
								if (oEntry.AddCategoryId === "5") {
									dayWeekController.Model.setProperty("/IsOtherTab", true);
									if (oEntry.task.taskId === "11") {
										dayWeekController.Model.setProperty("/isSpecialTask", true);
										if (oEntry.costType.id === "3") {
											dayWeekController.Model.setProperty("/isOthersTabManualIO", true);
										}
									}
								}
								if (oEntry.task.taskId === "10") {
									dayWeekController.Model.setProperty("/IsLearning", true);
								}
								if (oEntry.costType.id === "3") {
									dayWeekController.Model.setProperty("/isManualIO", true);
								}
							}
							const oCalendar = dayWeekController.getCalendar();
							oNewEntry = dayWeekController.Model.getProperty("/Entry");
							let entryDate = (oEntry) ? oEntry.date : oNewEntry.date;
							oCalendar.removeAllSelectedDates();
							oCalendar.addSelectedDate(new sap.ui.unified.DateRange({
								startDate: entryDate,
								endDate: entryDate
							}));
							oCalendar.setInitialFocusedDate(entryDate);
							oCalendar.fireSelect();
							dayWeekController.Model.setProperty("/IsCustomerFacingVisible", true);
							//hide customer facing when there is no mapping
							const aMtrTasks = dayWeekController.Model.getProperty("/MtrTasks");
							if (aMtrTasks && aMtrTasks.length === 1) {
								dayWeekController.Model.setProperty("/IsCustomerFacingVisible", false);
							}
							if(oEntry){
								dayWeekController._filterEntries();
								const oActivity = {
									"ActivityId": oEntry.ActvtId,
									"ActAsstId": (oEntry.ActDetails && oEntry.ActDetails.ActAsstId) ? oEntry.ActDetails.ActAsstId : oEntry.costType.id === "1" ?
										"502" : (oEntry.costType.id === "4") ?
											"501" : "503"
								};
								if (oEntry.AddCategoryId === "5") {
									oActivity.ActAsstId = "";
								}
								dayWeekController.Model.setProperty("/Entry/ActAsstId", oActivity.ActAsstId);
								oMTRHelper.filterMtrTasks(oActivity, true).then(function (filteredTasktypes) {
									dayWeekController.Model.setProperty("/MtrTasks", filteredTasktypes);
									if (filteredTasktypes.length === 1) {
										dayWeekController.Model.setProperty("/IsCustomerFacingVisible", false);
									}
									dayWeekController._selectMTRTask();
								});
							}
							const sActId = oNewEntry.ActvtId;
							const sActTypeDesc = oNewEntry.ActTypeDesc;
							const sCostTypeId = oNewEntry.costType.id;
							const sCostTypeValue = oNewEntry.costType.value;
							const bIsEdit = dayWeekController.Model.getProperty("/IsEdit");
							if (sActId) {
								const sTitle = sActTypeDesc + "(" + sActId + ") Entry";
								dayWeekController.Model.setProperty("/DailogTitle", sTitle);
							}
							dayWeekController._setCostObjectItems(sCostTypeId, sCostTypeValue);
							if (!bIsEdit && sCostTypeId) {
								dayWeekController._selectMTRTask();
							}
							dayWeekController._setEntriesInfoData(aEntries, oNewEntry.recordDate);
							Fragment.load({
						id:  dayWeekController.DialogId + "_UserActivitiesDialog",
						name: "com.melodylib.time.controls.calendar.day.fragments.UserActivities",
						controller: dayWeekController
					}).then(function (oDialog) {
						oDialog.setModel(oModel);
						
						
							that.addDependent(oDialog);
						
						dayWeekController._oUserActivitiesDialog = oDialog;
						return oDialog;
					}.bind(dayWeekController));
						});

					}
				
				}

			
			
			
			
		} catch (error) {
			console.log("ERROR IN openTimeRecordBox : ", error)
		}
		
		

		// const accountState = control.controller.accountState;
		// const accountStateModel = accountState.getModel();
		// const accountStateVariant = accountStateModel.getProperty("/variant");

		const model = control.getModel();
		// const variant = model.getProperty("/variant");

		// variant.copy(accountStateVariant);
		model.refresh();
		// const query = variant.searchQuery;
		// control.controller._search(query);
	}

	_validate(){
		let bValid = false;
		if (!this.getVisible() && !this.getStatusId()) {
			return false;
		}
	}
	_setModel(entry,filteredActivityTaskTypes){
		const oThisController = this;
				const oModel = this.getModel();
				const timeStateModel = this.controller.TimeState.getModel();
				const aEntries = timeStateModel.getProperty("/entries")
				const expected = timeStateModel.getProperty("/Expected");
				const submitted = timeStateModel.getProperty("/Submitted");
				const saved = timeStateModel.getProperty("/Saved");

				
				const aMTRTasks = this.oTimeMasterIntance.getData().tasks;

				const oSelectedActivity = this.getSelectedActivity();

				oModel.setData({
					// UserSetting: oUserMtrSettings,
					MtrTasks: filteredActivityTaskTypes,
					SelectedDates: [],
					SelectedActivity: oSelectedActivity,
					SelectedMtrTask: null,
					SelectedLocationId: "",
					ShowCalendar: false,
					Entries: aEntries,
					i18n: this.getModel("i18n"),
					Entry: entry,
					Expected: expected,
					Submitted: submitted,
					Saved: saved,
					MTRTasks: aMTRTasks,
					MtrUid: this.getMtrUid()
				});

				return oModel;

	}


}
class TimeEntryButtonController extends Controller {
	constructor(control) {
		super();
		this.control = control;
		this.TimeState = TimeState.getInstance();
		// this.masterDataState = MasterDataState.getInstance();
	}
	onInit() {
		this.setBusy(false);
	}
	

}
