/*!
 * ${copyright}
 */

import Lib from "sap/ui/core/Lib";
// import Actions from "com/melodylib/time/enum/Actions";

/**
 * Example renderer.
 * @namespace
 */
export default {
    apiVersion: 2, // usage of DOM Patcher

    /**
     * Renders the HTML for the given control, using the provided {@link RenderManager}.
     *
     * @param rm The reference to the <code>sap.ui.core.RenderManager</code>
     * @param control The control instance to be rendered
     */


    render: function (oRm, oControl) {
        oRm.openStart("div", oControl);
        oRm.class("matrixCalendarContainer");
        oRm.style("width", oControl.getWidth());
        oRm.style("position", "relative");
        oRm.openEnd();

        oRm.openStart("div");
        oRm.class("calendarContainer");
        oRm.openEnd();

        oRm.openStart("div");
        oRm.class("calendarInnerContainer");
        oRm.openEnd();

        oRm.renderControl(oControl.getAggregation("_navCalendar"));
        oControl.getAggregation("_shortCalendar")
            .setStartDate(oControl._getStartDateOfWeek())
            .setNonWorkingDays(oControl.getWeekends());
        oRm.renderControl(oControl.getAggregation("_shortCalendar"));
        oRm.renderControl(oControl.getAggregation("_datePicker"));

        oRm.close("div"); // calendarInnerContainer
        oRm.renderControl(oControl.getAggregation("_legends"));
        oRm.close("div"); // calendarContainer
        oRm.close("div"); // matrixCalendarContainer
    }
};
