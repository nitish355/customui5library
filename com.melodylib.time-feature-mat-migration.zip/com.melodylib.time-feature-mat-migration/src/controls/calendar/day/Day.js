import Controller from "sap/ui/core/mvc/Controller";
import ActivityService from "com/melodylib/activity/service/ActivityService";
import TimeService from "com/melodylib/time/service/TimeService";
import Filter from "sap/ui/model/Filter";
import formatter from "com/melodylib/time/model/formatter";
import Fragment from "sap/ui/core/Fragment";
import JSONModel from "sap/ui/model/json/JSONModel";
import DateFormat from "sap/ui/core/format/DateFormat";
import coreLibrary from "sap/ui/core/library";
import TimeState from "../../../state/TimeState";
import DateService from "com/melodylib/core/service/DateService";
import MTRModels from "com/melodylib/time/model/TimeModels";
import OpportunityService from "com/melodylib/integration/service/OpportunityService";
import OpportunityState from "com/melodylib/integration/state/OpportunityState";
import FilterOperator from "sap/ui/model/FilterOperator";
import MessageToast from "sap/m/MessageToast";
import ActivityState from "com/melodylib/activity/state/ActivityState"
import Message from "com/melodylib/time/classes/Message";
import MessageBox from "sap/m/MessageBox";
import Entry from "com/melodylib/time/classes/Entry";
import StaffingState from "com/melodylib/time/state/StaffingState"
const CalendarType = coreLibrary.CalendarType;


export const oMTRHelper = {

	setController(controllerInstance) {
		this.Controller = controllerInstance;
	},
	async filterMtrTasks(oSelectedActivity, isEditTimeEntry) {



		const oUserActivityRole = await ActivityService.getInstance().getUserActivityRole();
		if (!oSelectedActivity || !oUserActivityRole) {
			return [];
		}

		const oData = await ActivityService.getInstance().getActivityList();
		const aUserActivities = oData.data.results;

		const oUserActivity = aUserActivities.find(item => {
			return item.ActivityId === oSelectedActivity.ActivityId && item.ActAsstId === oSelectedActivity.ActAsstId;
		});

		if (!oUserActivity) {
			return [];
		}

		if (isEditTimeEntry) {
			oSelectedActivity = oUserActivity;
		}

		//To Handle SL Lead
		let sParentRoleId = oSelectedActivity["ParentRoleId"];
		if (oSelectedActivity["ParentRoleId"] === "0066" && oSelectedActivity["IsSlLead"] === "X") {
			sParentRoleId = oUserActivityRole["ParentRoleID"];
		}



		const oAct = {
			"ActivityTypeId": oSelectedActivity.ActivityTypeId,
			"ActAsstId": oSelectedActivity.ActAsstId,
			// "ParentRoleId": sParentRoleId,
			"RoleMpngID": oSelectedActivity.RoleMpngID
		};
		const aFilters = [
			new Filter("ActvtTypeID", "EQ", oAct.ActivityTypeId),
			new Filter("ActvtAsstdID", "EQ", oAct.ActAsstId),

			new Filter("RoleMpngID", "EQ", oAct.RoleMpngID),
		];
		var mParameters = {};
		mParameters.filters = (aFilters) ? aFilters : "";
		const aActivityMappedTaskTypes = await TimeService.getInstance().getTasksByActivity(mParameters);

		return aActivityMappedTaskTypes;
	},

	_closeTimeRecordingDialog() {

		this.Controller._oTimeRecordingDialog.close();
		//this.Controller._oTimeRecordingDialog.destroy();
		//this.Controller._oUserActivitiesDialog.destroy();
		//this.Controller.DialogId = null;


	}

}
export default class TimeRecordingController extends Controller {
	constructor(controlRef) {
		super();
		this.formatter = formatter;
		this.DurationLimit = {};
		this.parentControl = controlRef;
		this.oFormatYyyymmdd = DateFormat.getInstance({
			pattern: "MMM-dd",
			calendarType: CalendarType.Gregorian
		});

	}
	onChangeCategory(oEvent) {
		const oSource = oEvent.getSource();
		const sKey = oSource.getSelectedKey();


		this.Model.setProperty("/IsOtherTab", false);

		if (sKey === "02") {
			this._selectMTRTask(true);
			this.Model.setProperty("/Entry/costType/id", "2");
			this.Model.setProperty("/IsLearning", true);
		} else if (sKey === "01") {
			const oActDetails = this.Model.getProperty("/Entry/ActDetails");
			if (oActDetails) {
				let sCostTypeId = this._setCostTypeId(oActDetails.ActAsstId);
				this.Model.setProperty("/Entry/costType/id", sCostTypeId);
				this.Model.setProperty("/Entry/task/taskId", oActDetails.MtrTaskID);
				this.Model.setProperty("/Entry/task/name", oActDetails.MtrTaskName);
			}
			this.Model.setProperty("/IsLearning", false);
		} else {
			this.Model.setProperty("/IsLearning", false);
			this.Model.setProperty("/IsOtherTab", true);
			this.Model.setProperty("/Entry/TaskId", "");
			this.Model.setProperty("/Entry/TaskName", "");
			this.Model.setProperty("/isSpecialTask", false);
			this.Model.setProperty("/isOthersTabManualIO", false);
		}
	}
	_selectMTRTask(isLearning) {
		if (isLearning) {
			const aMtrTasks = this.Model.getProperty("/MTRTasks");
			const oMtrTask = aMtrTasks.find(item => item.isLearning === true);
			if (oMtrTask) {
				this.Model.setProperty("/Entry/task/taskId", oMtrTask.taskId);
				this.Model.setProperty("/Entry/task/name", oMtrTask.taskName);
			}
		} else {
			const isEdit = this.Model.getProperty("/IsEdit");
			const bState = this.Model.getProperty("/Entry/CustomerFacing");
			const sMpngAttrVal = bState ? "1" : "2";
			const aMtrTasks = this.Model.getProperty("/MtrTasks");
			if (aMtrTasks.length === 2) { //to check customer facing condition
				const oMtrTask = aMtrTasks.find(item => item.MpngAttrVal === sMpngAttrVal);
				if (oMtrTask) {
					this.Model.setProperty("/Entry/task/taskId", oMtrTask.taskId);
					this.Model.setProperty("/Entry/task/name", oMtrTask.taskName);
				}
			} else if (aMtrTasks.length === 1) {
				const oMtrTask = aMtrTasks[0];
				this.Model.setProperty("/Entry/task/taskId", oMtrTask.taskId);
				this.Model.setProperty("/Entry/task/name", oMtrTask.taskName);
			}

		}
	}
	handleTaskPopoverPress(oEvent) {

		if (!this._oTaskPopover) {
			this._oTaskPopover = sap.ui.xmlfragment(
				"com.melodylib.time.controls.calendar.day.fragments.TaskPopover",
				this);
		}
		this._oTaskPopover.setModel(this.Model);
		this._oTaskPopover.openBy(oEvent.getSource());

	}

	getCalendar() {
		const oMtrCalendar = sap.ui.core.Fragment.byId(this.DialogId, "calender");
		const oCalendar = oMtrCalendar.getAggregation("_calendar");
		return oCalendar;
	}
	_setCostObjectItems(sCostTypeId, sCostTypValue) {
		if (sCostTypeId) {
			const sActAsstId = this.Model.getProperty("/Entry/ActAsstId");
			const isEdit = this.Model.getProperty("/IsEdit");
			const aCostObject = [];
			if (sCostTypeId !== "2" && sActAsstId !== "503") {
				sCostTypeId = isEdit ? sActAsstId === "501" ? "4" : "1" : sCostTypeId;
				const oCostObject = {
					key: sCostTypeId,
					text: sCostTypeId === "1" ? "Opportunity" : "Account"
				};
				aCostObject.push(oCostObject);
			} else {
				const oCostCenter = {
					key: "2",
					text: "SAP Cost Center"
				};
				aCostObject.push(oCostCenter);
			}
			const oManualIO = {
				key: "3",
				text: "Manual IO"
			};
			aCostObject.push(oManualIO);
			this.Model.setProperty("/CostObjectItems", aCostObject);
		}
	}

	onStartDateChange(oEvent) {
		let that = this;
		const isEdit = this.Model.getProperty("/IsEdit");
		const oCalendar = this.getCalendar();
		if (isEdit) {
			const oEntry = this.Model.getProperty("/Entry");
			MessageToast.show("Cannot change date in edit mode");
			oCalendar.removeAllSelectedDates();
			oCalendar.addSelectedDate(new sap.ui.unified.DateRange({
				startDate: oEntry.Date,
				endDate: oEntry.Date
			}));
			return;
		}

		const bRestrictPriorYear = TimeState.getInstance().getUser().time.restrictPriorYear;
		const oSettingsModel = MTRModels.getMTRSettingsModel();

		const dStartDate = oEvent.getParameter("selectionStartDate");
		let bRestrictEntry = false;
		if (oCalendar) {
			oCalendar.addSelectedDate(new sap.ui.unified.DateRange({
				startDate: dStartDate,
				endDate: dStartDate
			}));
			oCalendar.setInitialFocusedDate(dStartDate);
		}
		if (bRestrictPriorYear && dStartDate.getFullYear() < 2023) {
			bRestrictEntry = true;
		}
		oSettingsModel.setProperty("/RestrictEntry", bRestrictEntry);
		const sSelectedDate = DateService.getInstance().format(dStartDate, "yMMdd"); // YYYYMMDD
		TimeState.getInstance().filterEntries(sSelectedDate);

		const oDayWeekTimesheetModel = TimeState.getInstance().getModel();
		const oNewEntry = this.Model.getProperty("/Entry");
		// oNewEntry.WorkDuration = 0;
		oNewEntry.date = dStartDate;
		oNewEntry.recordDate = sSelectedDate;
		oNewEntry.formattedLongDate = DateService.getInstance().format(dStartDate, "EEEE, MMMM dd, y");
		oNewEntry.formattedRecordDate = DateService.getInstance().format(dStartDate, "dd/MM/YYYY");
		oNewEntry.Expected = oDayWeekTimesheetModel.getProperty("/Expected");
		oNewEntry.IsSubmitEnabled = oNewEntry.validateISPFutureDate();
		oNewEntry.IsInOREDateRange = oNewEntry.validateOREDateRange();   //For ORE date integration  
		this.Model.setProperty("/Entry", oNewEntry);
		that.Model.setProperty("/Submitted", oDayWeekTimesheetModel.getProperty("/Submitted"));
		that.Model.setProperty("/Saved", oDayWeekTimesheetModel.getProperty("/Saved"));
		that.Model.setProperty("/Expected", oDayWeekTimesheetModel.getProperty("/Expected"));
		const oSelectedActivity = this.Model.getProperty("/SelectedActivity");
		if (oSelectedActivity) {
			oNewEntry.setMelodyActivity(oSelectedActivity.ActivityId);
			that.Model.refresh(true);
			that._selectMTRTask();
		}
		const isLearning = that.Model.getProperty("/IsLearning");
		if (isLearning) {
			that.Model.setProperty("/Entry/costType/id", "2");
			that._selectMTRTask(true);
		}

		const aEntries = oDayWeekTimesheetModel.getProperty("/entries");
		that._setEntriesInfoData(aEntries, oNewEntry.recordDate);
		that.Model.setProperty("/MaxCapacityAlert", false);


	}

	_setEntriesInfoData(aEntries, sRecordDate) {
		const that = this;
		let aSavedEntries = [],
			aFailedEntries = [],
			aSubmittedEntries = [];
		aEntries.filter(function (Entry) {
			if (Entry.recordDate === sRecordDate) {
				var workDuration = parseFloat(Entry.duration.current);
				switch (Entry.status.id) {
					case "1":
						// aSavedEntries.push(Entry);
						aSavedEntries.push(Entry);
						break;
					case "3":
						aFailedEntries.push(Entry);
						break;
					case "4":
						aSubmittedEntries.push(Entry);
						break;
					default:
						break;
				}
			}
		});
		this.Model.setProperty("/CfNcfSavedEntries", "");
		this.Model.setProperty("/CfNcfSubmittedEntries", "");
		this.Model.setProperty("/CfNcfFailedEntries", "");
		this.Model.setProperty("/CfNcfSavedEntriesActInfo", "");
		this.Model.setProperty("/CfNcfSubmittedEntriesActInfo", "");
		this.Model.setProperty("/CfNcfFailedEntriesActInfo", "");
		let cfSavedWorkDuration = 0;
		let ncfSavedWorkDuration = 0;
		if (aSavedEntries.length) {
			aSavedEntries.filter(function (oEntry) {
				const workDuration = parseFloat(oEntry.duration.current, 10);
				const bCustomerFacing = oEntry.customerFacing;
				if (bCustomerFacing) {
					cfSavedWorkDuration += workDuration;
				} else {
					ncfSavedWorkDuration += workDuration;
				}
				that._formatEntryInfoDate(oEntry, "CfNcfSavedEntries", "CfNcfSavedEntriesActInfo", cfSavedWorkDuration, ncfSavedWorkDuration);
			});
		} else {
			this._formatEntryInfoDate(undefined, "CfNcfSavedEntries", "CfNcfSavedEntriesActInfo", cfSavedWorkDuration, ncfSavedWorkDuration);
		}

		let cfSubmittedWorkDuration = 0;
		let ncfSubmittedWorkDuration = 0;
		if (aSubmittedEntries.length) {
			aSubmittedEntries.filter(function (oEntry) {
				const workDuration = parseFloat(oEntry.duration.current, 10);
				const bCustomerFacing = oEntry.customerFacing;
				if (bCustomerFacing) {
					cfSubmittedWorkDuration += workDuration;
				} else {
					ncfSubmittedWorkDuration += workDuration;
				}

				that._formatEntryInfoDate(oEntry, "CfNcfSubmittedEntries", "CfNcfSubmittedEntriesActInfo", cfSubmittedWorkDuration,
					ncfSubmittedWorkDuration);
			});
		} else {
			this._formatEntryInfoDate(undefined, "CfNcfSubmittedEntries", "CfNcfSubmittedEntriesActInfo", cfSubmittedWorkDuration,
				ncfSubmittedWorkDuration);
		}

		let cfFailedWorkDuration = 0;
		let ncfFailedWorkDuration = 0;
		if (aFailedEntries.length) {
			aFailedEntries.filter(function (oEntry) {
				const workDuration = parseFloat(oEntry.duration.current, 10);
				const bCustomerFacing = oEntry.customerFacing;
				if (bCustomerFacing) {
					cfFailedWorkDuration += workDuration;
				} else {
					ncfFailedWorkDuration += workDuration;
				}

						that._formatEntryInfoDate(oEntry, "CfNcfFailedEntries", "CfNcfFailedEntriesActInfo", cfFailedWorkDuration,
							ncfFailedWorkDuration);
					});
				} else {
					this._formatEntryInfoDate(undefined, "CfNcfFailedEntries", "CfNcfFailedEntriesActInfo", cfFailedWorkDuration,
						ncfFailedWorkDuration);
				}
				this.Model.refresh(true);
			}
			_formatEntryInfoDate(oEntry, cfNcfProperty, cfNcfActInfoProperty, cfWorkDuration, ncfWorkDuration) {
				let sDescription = "";
				let sDescriptionActInfo = "";
				
				const sTimeMatrics = TimeState.getInstance().getUser().time.unit;
				const sTimeMatricsTxt = sTimeMatrics === "H" ? "hours" : "day";
				if (oEntry) {
					const dDate = oEntry.date;
					const sDate = DateService.getInstance().format(dDate, "MMMM dd");
					sDescription = sDate + " : " + cfWorkDuration + " " + sTimeMatricsTxt + " CF / " + ncfWorkDuration + " " + sTimeMatricsTxt +
						" NCF";
					sDescriptionActInfo = cfWorkDuration + " " + sTimeMatricsTxt + " CF / " + ncfWorkDuration + " " + sTimeMatricsTxt +
						" NCF";
				} else {
					sDescription = cfWorkDuration + " " + sTimeMatricsTxt + " CF / " + ncfWorkDuration + " " + sTimeMatricsTxt +
						" NCF";
					sDescriptionActInfo = cfWorkDuration + " " + sTimeMatricsTxt + " CF / " + ncfWorkDuration + " " + sTimeMatricsTxt +
						" NCF";
				}
				this.Model.setProperty("/" + cfNcfProperty, sDescription);
				this.Model.setProperty("/" + cfNcfActInfoProperty, sDescriptionActInfo);
			}
			openEntriesInfoPopover(oEvent) {
				const oSource = oEvent.getSource();
				this._oEntriesInfoPopover = Fragment.load({
						id:  "_EntriesPopOver",
						name: "com.melodylib.time.controls.calendar.day.fragments.EntriesInfoPopover",
						controller: this
					}).then(function (oPopover) {
						oPopover.setModel(this.Model);
						let oResourcei18nModel = MTRModels.getMTRResourceModel();
						const oMtrSettings = sap.ui.getCore().getModel("mtrSettings");
						oPopover.setModel(oMtrSettings, "mtrSettings");
						oPopover.setModel(oResourcei18nModel, "i18n");
						
						this._oEntriesInfoPopover = oPopover;
						oPopover.openBy(oSource);
					}.bind(this));
			}
			openUserActivityPopup(){
				this.setUserActivities();
				this._oUserActivitiesDialog.open();
			}
				async setUserActivities(activity) {
				const that = this;
				this.Model.setSizeLimit(1000);
				let aActivities = this.Model.getProperty("/UserActivities");
				let aFilters = [];
				let archivedFilter = new Filter({
					path: "IsArchived",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: false
				});
				aFilters.push(archivedFilter);
				if (!aActivities) {
					this.Model.setProperty("/IsUserActDlgBusy", true);
					aActivities = await TimeService.getInstance().getMatrixTimeEntryActivitites(aFilters);
					aActivities.filter(function (actvt) {
						var that = this;
						actvt.ActivityId = parseInt(actvt.ActivityId).toString();
						if (actvt.ActAsstId === "501") {
							actvt.OpportunityName = "Not Applicable";
							if (actvt.AccountId) {
								// AccountService.getZSBupaInfoSet(this.AccountId)
								OpportunityService.getBusinessPartnerAttribSet(actvt.AccountId).then(function (oResponse) {
									if (oResponse && oResponse.data) {
										// that.AccountName = oResponse[0].AccountName;
										actvt.AccountName = oResponse.data.PARTNER_NAME;
									} else {
										actvt.AccountName = "Not Applicable";
									}
								});
							} else {
								actvt.AccountName = "Not Applicable";
							}
						} else if (actvt.ActAsstId === "502") {
							const oMtrSettingsModel = sap.ui.getCore().getModel("mtrSettings");
							const aOpportunities = OpportunityState.getInstance().getData().opportunities;
							if (aOpportunities) {
								const oOpportunity = aOpportunities.find(item => item.id === actvt.OpportunityId);
								if (oOpportunity) {
									actvt.OpportunityName = oOpportunity.description ? oOpportunity.description : "Not Authorized";
									actvt.AccountName = oOpportunity.accountName ? oOpportunity.accountName : "Not Authorized";
								} else {
									actvt.AccountName = "Not Authorized";
									actvt.OpportunityName = "Not Authorized";
								}
							}
						} else {
							actvt.AccountName = actvt.ActSetDesc ? actvt.ActSetDesc : "Not Applicable";
							actvt.OpportunityName = "Not Applicable";
						}
					});
				}
				const aActStatus = await TimeService.getInstance().getActStatusMasterData();
				// const aActTypes = ActivityUtil.getActivityTypes().then(function (results) {
				// 	that.Model.setProperty("/ActTypes", results);
				// });
				this.Model.setProperty("/ActStatus", aActStatus);
				this.Model.setProperty("/UserActivities", aActivities);
				this.filterUserActivities();
			}

	onActivitySelect(oEvent) {
		const that = this;
		const mtrSettings = sap.ui.getCore().getModel("mtrSettings");
		const oActivity = oEvent.getSource().getBindingContext().getObject();
		if (oActivity) {
			let startDate = (oActivity.StartDate) ? oActivity.StartDate : new Date();
			this.Model.setProperty("/Entry/ActDetails", oActivity);
			this.Model.setProperty("/Entry/ActvtId", oActivity.ActivityId);
			this.Model.setProperty("/Entry/ActTypeDesc", oActivity.ActTypeDesc);
			const sActAsstId = oActivity.ActAsstId;
			let sCostTypeId = "";
			let sCostTypeName = "";
			let sCostTypeValue = "";
			if (sActAsstId === "501") {
				sCostTypeId = "4";
				sCostTypeName = oActivity.AccountName;
				sCostTypeValue = oActivity.AccountId;
			} else if (sActAsstId === "502") {
				sCostTypeId = "1";
				sCostTypeName = oActivity.OpportunityName;
				sCostTypeValue = oActivity.OpportunityId;
			} else if (sActAsstId === "503") {
				sCostTypeId = "2"
				sCostTypeValue = AuthState.getInstance().getData().costCenter;
			}
			this.Model.setProperty("/Entry/costType/id", sCostTypeId);
			this.Model.setProperty("/Entry/costType/value", sCostTypeValue);
			this.Model.setProperty("/Entry/costType/name", sCostTypeName);
			this.Model.setProperty("/Entry/task/taskId", oActivity.MtrTaskID);
			this.Model.setProperty("/Entry/task/name", oActivity.MtrTaskName);
			this.Model.setProperty("/Entry/OpportunityID", oActivity.OpportunityId);
			this.Model.setProperty("/Entry/OpportunityName", oActivity.OpportunityName);
			this.Model.setProperty("/Entry/AccountID", oActivity.AccountId);
			this.Model.setProperty("/Entry/AccountName", oActivity.AccountName);

			this._setCostObjectItems(sCostTypeId, sCostTypeValue);

			if (sCostTypeId === "1") {
				this.fnSetOppoInfoDetails(sCostTypeValue, "DISPLAYMODE");
			} else if (sCostTypeId === "4") {
				this.fnSetAccountInfoDetails(sCostTypeValue, "DISPLAYMODE");
			}
			//hide customer facing when there is no mapping
			if (oActivity.MpngAttrVal) {
				this.Model.setProperty("/IsCustomerFacingVisible", true);
			} else {
				this.Model.setProperty("/IsCustomerFacingVisible", false);
			}

			this.Model.setProperty("/isManualIO", false);
			if (new Date() >= startDate) {
				startDate = new Date();
			}
			this.Model.setProperty("/Entry/date", startDate);
			this.Model.setProperty("/Entry/recordDate", DateService.getInstance().format(startDate, "yMMdd"));
			this.Model.setProperty("/Entry/FormattedRecordDate", DateService.getInstance().format(startDate, "dd/MM/YYYY"));
			this.Model.setProperty("/Entry/formattedLongDate", DateService.getInstance().format(startDate, "EEEE, MMMM dd, y"));
			this.Model.refresh(true);

			this.fnSetCalendar(startDate);
			this.onActivitySelectionPopupClose();
			const oNewEntry = this.Model.getProperty("/Entry");
			const sSelectedOppId = (oNewEntry && oNewEntry.OpportunityID) ? oNewEntry.OpportunityID : "";
			let bIsDiscontinuedOpp = false;
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			oSettingsModel.setProperty("/IsDisontinuedOppSubmit", false);
			if (sSelectedOppId && oNewEntry.duration.current) {
				bIsDiscontinuedOpp = TimeState.getInstance().fnIsDiscontinuedOpportunity(false, oNewEntry, sSelectedOppId, this, "dayWeekActivityData");
			}
			// that._oUserActivitiesDialog.close();
		}
	}

	fnSetOppoInfoDetails(OppId, viewMode) {
		let opportunityControl = sap.ui.core.Fragment.byId(this.DialogId, "dayWeekOpportunityCtrl");
		let opportunityControl1 = sap.ui.core.Fragment.byId(this.DialogId, "dayWeekOpportunityCtrl1");
		if (opportunityControl) {
			opportunityControl.setOpportunityId(OppId);
		}
		if (opportunityControl1) {
			opportunityControl1.setOpportunityId(OppId);
		}
	}

	//Function to update Account details to Info popover from Application to library
	fnSetAccountInfoDetails(accountId, viewMode) {
		let accountControl = sap.ui.core.Fragment.byId(this.DialogId, "dayWeekAccountCtrl");
		let accountControl1 = sap.ui.core.Fragment.byId(this.DialogId, "dayWeekAccountCtrl1");

		if (accountControl) {
			accountControl.setAccountId(accountId);
		}
		if (accountControl1) {
			accountControl1.setAccountId(accountId);
		}
	}

	handleDialogEscape() {
		MessageToast.show("Click on close button to close the dialog");
		return;
	}

	fnSetCalendar(date) {
		const oCalendar = this.getCalendar();
		if (oCalendar) {
			oCalendar.removeAllSelectedDates();
			oCalendar.addSelectedDate(new sap.ui.unified.DateRange({
				startDate: date,
				endDate: date
			}));
			oCalendar.setInitialFocusedDate(date);
			//To Display Entries Info Popup & Hours in Calendar
			oCalendar.fireSelect();
		}
	}



	onActivitySelectionPopupClose() {
		this._oUserActivitiesDialog.close();
		this.onResetActFilters();
	}
	_setCostTypeId(sActAsstId) {
		let sCostTypeId = "";
		if (sActAsstId === "501") {
			sCostTypeId = "4";
		} else if (sActAsstId === "502") {
			sCostTypeId = "1";
		} else if (sActAsstId === "503") {
			sCostTypeId = "2"
		}
		return sCostTypeId;
	}
	_getControlById(id) {
		if (id) {
			return sap.ui.core.Fragment.byId(this.DialogId + "_UserActivitiesDialog", id);
		}
	}

	filterUserActivities(searchFilter) {
		let aFilters = [];
		let aDateFilter = [];
		let aCustomerFacingFilter = [];
		const oDateRangeFilter = this._getControlById("dateRangeFilter");
		const dateFrom = oDateRangeFilter.getFrom();
		const dateTo = oDateRangeFilter.getTo();
		if (dateFrom && dateTo) {
			aDateFilter.push(new Filter("StartDate", "GE", dateFrom));
			aDateFilter.push(new Filter("EndDate", "LE", dateTo));
			aFilters.push(new Filter({
				filters: aDateFilter,
				and: true
			}));
		}
		const oStatusFilter = this._getControlById("statusFilter");
		const sStatusId = oStatusFilter.getSelectedKey();
		if (sStatusId) {
			aFilters.push(new Filter("ActStatus", "EQ", sStatusId));
		}
		const oActTypeFilter = this._getControlById("actTypeFilter");
		const sActTypeId = oActTypeFilter.getSelectedKey();
		if (sActTypeId) {
			aFilters.push(new Filter("ActivityTypeId", "EQ", sActTypeId));
		}
		if (searchFilter) {
			aFilters.push(searchFilter);
		}
		const bState = this.Model.getProperty("/Entry/CustomerFacing");
		const sMpngAttrVal = bState ? "1" : "2";
		if (sMpngAttrVal) {
			aCustomerFacingFilter.push(new Filter("MpngAttrVal", "EQ", sMpngAttrVal));
			aCustomerFacingFilter.push(new Filter("MpngAttrVal", "EQ", ""));
		}
		aFilters.push(new Filter({
			filters: aCustomerFacingFilter,
			and: false
		}));
		const aActFilters = new Filter({
			filters: aFilters,
			and: true
		});
		const oList = this._getControlById("userActList");
		oList.getBinding("items").filter([aActFilters]);
		this.Model.setProperty("/IsUserActDlgBusy", false);
	}

	onResetActFilters() {
		const oDateRangeFilter = this._getControlById("dateRangeFilter");
		oDateRangeFilter.setValue("");
		const oStatusFilter = this._getControlById("statusFilter");
		oStatusFilter.setSelectedKey("");
		const oActTypeFilter = this._getControlById("actTypeFilter");
		oActTypeFilter.setSelectedKey("");
		const oActSearchFilter = this._getControlById("actSearchFilter");
		oActSearchFilter.setValue("");
		this.filterUserActivities([]);
	}

	onActivitySearch(oEvent) {
		const sQuery = oEvent.getSource().getValue();
		const aSearchFilters = new Filter({
			filters: [
				new Filter("ActivityId", FilterOperator.Contains, sQuery),
				new Filter("AccountId", FilterOperator.Contains, sQuery),
				new Filter("OpportunityId", FilterOperator.Contains, sQuery),
				new Filter("OpportunityName", FilterOperator.Contains, sQuery),
				new Filter("AccountName", FilterOperator.Contains, sQuery),
				new Filter("ActSetDesc", FilterOperator.Contains, sQuery)
			],
			and: false
		});
		this.filterUserActivities(aSearchFilters);
	}
	onDurationChange(oEvent) {

		const iValue = oEvent.getSource().getValue();
		const oNewEntry = this.Model.getProperty("/Entry");
		const sTimeMatrics = oNewEntry.unit;
		const isValid = iValue % 0.5 === 0;
		if (sTimeMatrics === "D" && (iValue > 1 || !isValid)) {
			oEvent.getSource().setValue("");
			return;
		}

		const sSelectedOppId = (oNewEntry && oNewEntry.OpportunityID) ? oNewEntry.OpportunityID : "";
		let bIsDiscontinuedOpp = false;
		if (sSelectedOppId) {
			bIsDiscontinuedOpp = TimeState.getInstance().fnIsDiscontinuedOpportunity(oEvent, oNewEntry, sSelectedOppId, this, "dayWeekActivityData");
		}

		if (!bIsDiscontinuedOpp) {
			this.fnChangeDuration(oEvent, "dayWeekActivityData");
		}

	}

	fnChangeDuration(oEvent, refDataFrm) {
		const oNewEntry = this.Model.getProperty("/Entry");
		const iWorkDuration = (oNewEntry && oNewEntry.duration.current) ? oNewEntry.duration.current : "";
		let iValue = (oEvent) ? oEvent.getSource().getValue() : iWorkDuration;

		const sTimeMatrics = oNewEntry.unit;
		const isValid = iValue % 0.5 === 0;
		if (sTimeMatrics === "D" && (iValue > 1 || !isValid)) {
			if (oEvent) {
				oEvent.getSource().setValue("");
			} else {
				this.Model.setProperty("/Entry/duration/current", "");
			}
			return;
		}

		const iExpectedHrs = (sTimeMatrics === "D" && parseInt(oNewEntry.Expected, 10) === 0) ? 1 : parseInt(oNewEntry.Expected, 10);
		const bMaxCapacityAlert = this.Model.getProperty("/MaxCapacityAlert");
		const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
		const aEntries = TimeState.getInstance().getModel().getProperty("/entries");
		const isEdit = oNewEntry.IsEdit;
		const oResourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
		const sUnit = sTimeMatrics === "H" ? "hours" : "days";
		let totalWorkDuration = 0;
		aEntries.filter(function (item) {
			if (item.recordDate === oNewEntry.recordDate) {
				totalWorkDuration = totalWorkDuration + parseFloat(item.duration.current, 10);
			}
		});
		if ((totalWorkDuration + iValue) > iExpectedHrs) {
			if (sTimeMatrics === "H") {
				if (!bMaxCapacityAlert) {
					MessageToast.show("You have already logged time entries up to your capacity hours (" + iExpectedHrs + " " + sUnit +
						") for the day.");
					this.Model.setProperty("/MaxCapacityAlert", true);
				}
			} else {
				if (!isEdit) {
					MessageToast.show("Cannot book >1day in a day.");
					if (oEvent) {
						oEvent.getSource().setValue("");
					} else {
						this.Model.setProperty("/Entry/WorkDuration", "")
					}
					return;
				}
			}
		}
	}
	fnSaveNewEntry(oEvent) {
		const that = this;
		const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
		const aEntries = TimeState.getInstance().getData().entries;
		const oNewEntry = this.Model.getProperty("/Entry");
		const oSelectedActivity = this.Model.getProperty("/SelectedActivity");
		const isLearning = this.Model.getProperty("/IsLearning");
		const isOthersTab = this.Model.getProperty("/IsOtherTab");
		const isCFvisible = this.Model.getProperty("/IsCustomerFacingVisible");
		const sTimeMatrics = oNewEntry.unit;

		const currentWorkDuration = oNewEntry.duration.current;
		if (!parseFloat(currentWorkDuration, 10) || parseFloat(currentWorkDuration, 10) <= 0) {
			MessageToast.show("Please Enter Time");
			return;
		}

		let totalWorkDuration = 0;
		aEntries.filter(function (item) {
			if (item.RecordDate === oNewEntry.recordDate) {
				totalWorkDuration = totalWorkDuration + parseFloat(item.duration.current, 10);
			}
		});
		let ExpectedWorkDuration = 0;
		ExpectedWorkDuration = currentWorkDuration + totalWorkDuration;
		if (sTimeMatrics === "H" && ExpectedWorkDuration > 24) {
			MessageToast.show("Cannot book >24hours in a day");
			return;
		}

		if (isOthersTab && !oNewEntry.task.taskId) {
			MessageToast.show("Please Select Task");
			return;
		}

		if (!isLearning) {
			if (!isOthersTab) {
				const sActivityId = oNewEntry.ActvtId;
				if (!sActivityId) {
					MessageToast.show("Please select activity");
					return;
				}
			}

			const sCostTypeId = oNewEntry.costType.id;
			if (!sCostTypeId) {
				MessageToast.show("Please select cost type");
				return;
			}

			const sManualIo = oNewEntry.costType.value;
			const property = isOthersTab ? "isOthersTabManualIO" : "isManualIO";
			if (this.Model.getProperty("/" + property) && !sManualIo) {
				MessageToast.show("Please select Manual IO");
				return;
			}
		}

		if (isLearning || isOthersTab || !isCFvisible) {
			oNewEntry.customerFacing = false;
		}

		const isEdit = this.Model.getProperty("/IsEdit");
		if (isEdit) {
			oNewEntry.Indicator = "U";
		} else {
			oNewEntry.Indicator = "I";
		}
		// aEntries.push(oNewEntry);
		this.Model.setProperty("/IsSaveBusy", true);
		TimeState.getInstance()._saveEntries([oNewEntry]).then(() => {
			let index = aEntries.findIndex(function (item) {
				return item.guid === oNewEntry.guid;
			});
			if (index !== -1) {
				oNewEntry.Busy = false;
				oNewEntry.StatusId = aEntries[index].StatusId;
				if (this.Model.getProperty("/IsOtherTab")) {
					oNewEntry.AddCategoryId = "5";
				}
				aEntries[index] = oNewEntry;
			}
			const oResourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
			const sWorkDuration = this.Model.getProperty("/Entry/duration/current");
			const dDate = this.Model.getProperty("/Entry/date");
			const sDate = DateService.getInstance().format(dDate, "MMMM dd");
			const oMtrSettings = sap.ui.getCore().getModel("mtrSettings");
			const sTimeMatrics = TimeState.getInstance().getUser().time.unit;
			const sTimeMatricsTxt = sTimeMatrics === "H" ? "hours" : "days";
			const sDescription = sDate + " : " + parseFloat(sWorkDuration, 10) + " " + sTimeMatricsTxt;
			let sActvtId = this.Model.getProperty("/Entry/ActvtId");
			let statusId = this.Model.getProperty("/Entry/status/id");
			const oMessage = new Message({
				Type: sap.ui.core.MessageType.Success,
				Title: oResourceBundle.getText("savedSuccessfullyMsg"),
				Description: sDescription,
				Subtitle: ""
			});
			oMessage.addToMessages(oNewEntry.guid, sActvtId, statusId);
			this.onMessagePopoverPress();
			this._filterEntries();
			this._setEntriesInfoData(aEntries, oNewEntry.recordDate);
			if (!isEdit) {
				this._ResetEntryData();
			}

			this.Model.setProperty("/IsSaveBusy", false);
		});
	}

			onCostObjectChange(oEvent) {
				let that = this;
				const sSelectedKey = oEvent.getSource().getSelectedKey();
				if (sSelectedKey === "3") {
					this.Model.setProperty("/isManualIO", true);
					this.Model.setProperty("/Entry/costType/value", "");
				} else {
					this.Model.setProperty("/isManualIO", false);
				}
				const bIsManualIo = this.Model.getProperty("/isManualIO");
				if (!bIsManualIo) {
					const oEntry = this.Model.getProperty("/Entry");
					let sPrevCostTypeVal = oEntry.ActAsstId === "501" ? oEntry.AccountID : oEntry.OpportunityID;
					if (!sPrevCostTypeVal) {
						const aActivities = ActivityState.getInstance().getData().activities;
						const oActivity = aActivities.find(item => parseInt(item.ActivityId, 10) === parseInt(oEntry.ActvtId, 10));
						sPrevCostTypeVal = oActivity.ActAsstId === "501" ? oActivity.AccountId : oActivity.OpportunityId;
					}
					this.Model.setProperty("/Entry/costType/value", sPrevCostTypeVal)
					oEntry.setCostTypeName().then(() => {
						that.Model.refresh(true);
					});
					const sCostTypeId = this.Model.getProperty("/Entry/costType/id");
					if (sCostTypeId === "1") {
						this.fnSetOppoInfoDetails(sPrevCostTypeVal, "DISPLAYMODE");
					} else if (sCostTypeId === "4") {
						this.fnSetAccountInfoDetails(sPrevCostTypeVal, "DISPLAYMODE");
					}
				}
			}
	handleISPMessagePopoverPress(oEvent) {




		let aStaffingRecord = StaffingState.getInstance().getData();
		let oEntry = this.Model.getProperty("/Entry");
		const oResourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
		var remainingDays;
		var aStaffingData = [];
		var that = this;
		var sOwnerName = "";
		var sOpportunityName = "";
		const oSettingsModel = MTRModels.getMTRSettingsModel();
		var aOpportunities = OpportunityState.getInstance().getData().opportunities;
		var aManualIOs = TimeState.getInstance().getData().manualIOs;
		var oOpportunity = null;
		var oManualIO = null;
		this.IOStaffing = null;
		var sInternalOrder = "";
		var isOpportunity = true;
		var isValid = false;




		if (oEntry.costType.id.toString() === "1") {

			oOpportunity = aOpportunities.find(function (item) {
				return item.id === oEntry.costType.value;
			});
			if (oOpportunity && oOpportunity.ioSetting === "Yes" && oOpportunity.associatedIO.id && oOpportunity.associatedIO.id !== "") {
				sInternalOrder = oOpportunity.associatedIO.id;
			}

		} else if ((oEntry.costType.id === "3" || oEntry.costType.id === 3) && oEntry.costType.value && oEntry.costType.value !== "") {
			oManualIO = aManualIOs.find(function (item) {
				return item.internalOrder.id === oEntry.costType.value;
			});
			if (oManualIO) {
				sInternalOrder = oEntry.costType.value;
			}
			isOpportunity = false;
		}

		//const sDateFormat = oSettingsModel.getProperty("/DateFormat");

		// const oDateFormat = oSettingsModel.getProperty("/DateFormats").find(function (d) {
		// 	return d.ID === sDateFormat;
		// });
		const oDateFormat = TimeState.getInstance().getUser().time.dateFormat;

		const aAssociatedIOData = aStaffingRecord.filter(function (item) {
			return sInternalOrder && item.internalOrder === sInternalOrder;
		});

		if (!sInternalOrder || aAssociatedIOData.length === 0) {
			let sOpportunityOrManulDesc = (isOpportunity) ? oOpportunity.description : "";
			if (!isOpportunity && oManualIO) {
				sOpportunityOrManulDesc = oManualIO.internalOrder.description;
			}

			const sOpportunutyDetails = (oOpportunity && oOpportunity.id) ? oOpportunity.id : sInternalOrder;

			aStaffingData.push({
				Name: sOpportunityOrManulDesc,
				Error: true,
				ErrorMessage: (!sInternalOrder) ? "IO not associated with Opportunity" : "IO details associated with Opportunity but you are not staffed",
				MessageDescription: (!sInternalOrder) ?
					"INFO SECTION\n\nSelected Opportunity " + sOpportunutyDetails +
					" is not associated with any IO as of today. Hence, you will not be able to Submit time for the same. \n\n" +
					"This could be due to any of the below reasons: \n\n1. IO has not been created for Opportunity so far. \n\n" +
					"2. You have not been staffed with the associated IO. \n\nRESOLUTION\n\nPlease submit a ticket for resolution, you can save the entry for now." : "INFO SECTION\n\nSelected Opportunity " +
					sOpportunutyDetails +
					" is associated with an IO " + sInternalOrder +
					", but you are not staffed on the IO. Hence, you will not be able to Submit time for the same. \n\nThis could be due below reasons:\n1. You are not staffed on the associated IO. \n\nRESOLUTION \n\nPlease submit a ticket for resolution, you can save the entry for now.",
				TicketText: "Submit a ticket",
				TicketLinkHref: "https://itsm.services.sap/sp?id=sc_cat_item&sys_id=703f22d51b3b441020c8fddacd4bcbe2&sysparm_category=e15706fc0a0a0aa7007fc21e1ab70c2&service_offering=2aa782291b244110d9c921fbbb4bcbdb&short_description=PreSales%20Tools:%20Melody%20Time%20Recordingp",
				Staffing: (!sInternalOrder) ? "IO Details" : sInternalOrder,
			});
		} else {
			for (let i = 0; i < aAssociatedIOData.length; i++) {
				const sOpportunityId = (isOpportunity) ? oOpportunity.id : "";
				if (!aAssociatedIOData[i].staffedDays) {
					let sMessageDescription = "";
					if (aAssociatedIOData[i].isOpportunityIO) {
						sMessageDescription = "INFO SECTION\n\nSelected Opportunity " + sOpportunityId +
							" is associated with an IO " + sInternalOrder +
							". which has been assigned to the Task Type or Task Level not matching with the Task Type or Task Level assigned to the Task you have Selected." +
							"\n\n1. IO – " + sInternalOrder +
							" assigned to Task Level and Task Type. \n\n2.Support and Enablement assigned to Task Level K1 and Task Type. \n\nRESOLUTION\n\nPlease submit a ticket for resolution, you can save the entry for now."
					} else {
						sMessageDescription = "INFO SECTION\n\nSelected Manual IO " + aAssociatedIOData[i].internalOrder +
							". which has been assigned to the Task Type or Task Level not matching with the Task Type or Task Level assigned to the Task you have Selected." +
							"\n\n1. Manual IO – " + aAssociatedIOData[i].internalOrder +
							" assigned to Task Level and Task Type. \n\n2.Support and Enablement assigned to Task Level K1 and Task Type. \n\nRESOLUTION\n\nPlease submit a ticket for resolution, you can save the entry for now."
					}

					aStaffingData.push({
						Name: (isOpportunity) ? oOpportunity.description : aAssociatedIOData[i].description,
						Error: true,
						ErrorMessage: "IO Task Type or Task Level not matching with Task Selected",
						MessageDescription: sMessageDescription,
						TicketText: "Submit a ticket",
						TicketLinkHref: "https://itsm.services.sap/sp?id=sc_cat_item&sys_id=703f22d51b3b441020c8fddacd4bcbe2&sysparm_category=e15706fc0a0a0aa7007fc21e1ab70c2&service_offering=2aa782291b244110d9c921fbbb4bcbdb&short_description=PreSales%20Tools:%20Melody%20Time%20Recordingp",
						Staffing: sInternalOrder
					});
				} else {
					remainingDays = (parseFloat(aAssociatedIOData[i].staffedDays) - parseFloat(aAssociatedIOData[i].recordedDays)) + " Days Left";

					aStaffingData.push({
						Error: false,
						Staffing: "Staffing " + (i + 1),
						ID: (isOpportunity) ? oOpportunity.id : aAssociatedIOData[i].internalOrder,
						Name: (isOpportunity) ? oOpportunity.description : aAssociatedIOData[i].description,
						Owner: (isOpportunity) ? oOpportunity.ownerName : "",
						AccountID: (isOpportunity) ? oOpportunity.account.id : "",
						AccountName: (isOpportunity) ? oOpportunity.account.name : "",
						InternalOrder: sInternalOrder,
						StaffedDays: aAssociatedIOData[i].staffedDays,
						StartDate: DateService.getInstance().formatStringDate(aAssociatedIOData[i].startDate, oDateFormat.Value),
						EndDate: DateService.getInstance().formatStringDate(aAssociatedIOData[i].endDate, oDateFormat.Value),
						TaskType: aAssociatedIOData[i].taskType,
						TaskLevel: aAssociatedIOData[i].taskLevel,
						IsOpportunity: isOpportunity,
						RemainingDays: remainingDays,
						Analytics: [{
							"Staffing": oResourceBundle.getText("recordedDays"),
							"Days": parseFloat(aAssociatedIOData[i].recordedDays)
						}, {
							"Staffing": oResourceBundle.getText("remainingDays"),
							"Days": parseFloat(aAssociatedIOData[i].staffedDays) - parseFloat(aAssociatedIOData[i].recordedDays)
						}]
					});
				}
			}
		}

		if (!this._oISPInfoPopover) {
			this._oISPInfoPopover = sap.ui.xmlfragment("com.melodylib.time.controls.calendar.matrix.fragments.ISPMessagePopover", this);
			var oResourcei18nModel = MTRModels.getMTRResourceModel();
			this._oISPInfoPopover.setModel(oResourcei18nModel, "i18n");
			this._oISPInfoPopover.setModel(new JSONModel(aStaffingData));
		}
		this._oISPInfoPopover.openBy(oEvent.getSource());

	}

	handleISPMessagePopoverClose() {
		if (this._oISPInfoPopover) {
			this._oISPInfoPopover.close();
			this._oISPInfoPopover.destroy();
			this._oISPInfoPopover = null;
		}
	}
			onCloseTimeRecordingDialog(){
				oMTRHelper._closeTimeRecordingDialog();
			}
			onNavigateCalendar(oEvent) {
				const that = this;
				const dStartDate = oEvent.getParameter("selectionStartDate");
				/*
				-Below setInitialFocusedDate is added bcz months navigation is not working
				*/
				const oCalendar = this.getCalendar();
				if (oCalendar) {
					oCalendar.setInitialFocusedDate(dStartDate);
					//oCalendar.setBusy(true);
				}
				// MTRUtil.updateTimesheets(dStartDate).then(() => {
				// 	const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				// 	const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
				// 	that.Model.setProperty("/Entries", aEntries);
				// 	oDayWeekTimesheetModel.refresh(true);
				// 	that.Model.refresh(true);
				// 	const oCalendar = MTRHelper.Controller.getCalendar();
				// 	if (oCalendar) {
				// 		oCalendar.setBusy(false);
				// 	}
				// });
			}

	checkDiscontinuedOpp(oEvent, oNewEntry, type) {
		const that = this;

		const aOpportunities = OpportunityState.getInstance().getData().opportunities || [];
		const oSettings = TimeState.getInstance().getUser().time;
		const oOpportunity = aOpportunities.find(item => item.id === oNewEntry.OpportunityID);
		const oResourceModel = MTRModels.getMTRResourceModel().getResourceBundle();


		if (oOpportunity && oOpportunity?.status?.key === "E0002" && !oSettings.IsDisontinuedOppSubmit) {

			const bCompact = true;
			oOpportunity.discontinuedDate = "";
			if (oOpportunity.statusSince) {
				oOpportunity.discontinuedDate = DateService.getInstance().format(oOpportunity.statusSince, 'dd-MMM-yy');
			}

			MessageBox.show(
				oResourceModel.getText("discontinuedSinceMsg1") + " (" + oOpportunity.discontinuedDate + ").\n" + oResourceModel.getText("discontinuedSinceMsg2") + "?", {
				styleClass: bCompact ? "sapUiSizeCompact" : "",
				icon: MessageBox.Icon.CONFIRM,
				title: oResourceModel.getText("discontinuedOpportunitiesTxt"),
				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				dependentOn: that.getView(),
				onClose: (sAction) => {
					if (sAction === sap.m.MessageBox.Action.YES) {
						if (type === "save") {
							that.fnSaveNewEntry(oEvent);
						} else {
							that.fnSubmitNewEntry(oEvent);
						}
					} else {
						that.Model.setProperty("/Entry/WorkDuration", "0.0");
						MessageToast.show(oResourceModel.getText("noTimeEntriesSaveMsg"));
					}
				}
			});
		} else {
			if (type === "save") {
				that.fnSaveNewEntry(oEvent);
			} else {
				that.fnSubmitNewEntry(oEvent);
			}
		}
	}

	onSaveNewEntry(oEvent) {
		const oNewEntry = this.Model.getProperty("/Entry");
		const currentWorkDuration = oNewEntry.duration.current;
		if (!parseFloat(currentWorkDuration, 10) || parseFloat(currentWorkDuration, 10) <= 0) {
			MessageToast.show("Please Enter Time");
			return;
		}
		this.checkDiscontinuedOpp(oEvent, oNewEntry, "save");

	}

	onMessagePopoverPress(oEvent) {
		const oButton = sap.ui.core.Fragment.byId(this.DialogId, "messagePopoverBtn");
		const oSource = oEvent ? oEvent.getSource() : oButton;
		if (oButton) {
			oButton.firePress();
		}

	}

	_filterEntries() {
		const that = this;
		const sSelectedDate = this.Model.getProperty("/Entry/recordDate");
		TimeState.getInstance().filterEntries(sSelectedDate);
		const oTimeState = TimeState.getInstance().getData();
		if (oTimeState) {

			that.Model.setProperty("/Submitted", oTimeState.Submitted);
			that.Model.setProperty("/Saved", oTimeState.Saved);
			that.Model.setProperty("/Expected", oTimeState.Expected);
		}
	}

	_ResetEntryData() {
		let oEntry = this.Model.getProperty("/Entry");
		const oSelectedActivity = this.Model.getProperty("/SelectedActivity");
		const dDate = oEntry.date;
		const sTaskId = oEntry.task.taskId;
		const sTaskName = oEntry.task.name;
		const sDate = DateService.getInstance().format(dDate, "yMMdd");
		const longDate = oEntry.formattedLongDate;
		const sCostTypeName = oEntry.costType.name;
		if (oSelectedActivity) {
			oEntry = new Entry({
				ActvtId: oEntry.ActvtId,
				ActTypeDesc: oEntry.ActTypeDesc,
				RecordDate: sDate,
				CostTypeId: oEntry.CostTypeId,
				CostTypeValue: oEntry.CostTypeValue,
				TaskId: sTaskId,
				TaskName: sTaskName
			});
			oEntry.CostTypeName = sCostTypeName;
		} else {
			oEntry = new Entry({
				RecordDate: sDate
			});
		}
		oEntry.formattedLongDate = longDate;
		oEntry.recordDate = sDate;
		const isLearning = this.Model.getProperty("/IsLearning");
		if (isLearning) {
			oEntry.costType.id = "2";
			oEntry.task.taskId = sTaskId;
			oEntry.task.name = sTaskName;
		}
		this.Model.setProperty("/Entry", oEntry);
		this.Model.setProperty("/isManualIO", false);
		this.Model.setProperty("/isSpecialTask", false);
		this.Model.setProperty("/isOthersTabManualIO", false);
		this.Model.refresh(true);
	}

	onOthrsTabTaskChange(oEvent) {
		const oSelectedItem = oEvent.getParameter("selectedItem");
		if (oSelectedItem) {
			const oTask = oSelectedItem.getBindingContext().getObject();
			if (oTask.taskId === 11) {
				this.Model.setProperty("/isSpecialTask", true);
			} else {
				this.Model.setProperty("/isSpecialTask", false);
				this.Model.setProperty("/isOthersTabManualIO", false);
			}
			const mtrSettings = sap.ui.getCore().getModel("mtrSettings");
			const sCostTypeValue = TimeState.getInstance().getUser().costCenter;
			this.Model.setProperty("/Entry/task/taskId", oTask.taskId);
			this.Model.setProperty("/Entry/task/name", oTask.taskName);
			this.Model.setProperty("/Entry/costType/id", "2");
			this.Model.setProperty("/Entry/costType/value", sCostTypeValue);
		}
	}

	onSubmitNewEntry() {
		const oNewEntry = this.Model.getProperty("/Entry");
		const currentWorkDuration = oNewEntry.duration.current;
		if (!parseFloat(currentWorkDuration, 10) || parseFloat(currentWorkDuration, 10) <= 0) {
			MessageToast.show("Please Enter Time");
			return;
		}
		this.checkDiscontinuedOpp(oEvent, oNewEntry);
	}
	fnSubmitNewEntry() {
		const that = this;
		const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
		const aEntries = TimeState.getInstance().getData().entries;
		const oNewEntry = this.Model.getProperty("/Entry");
		const oSelectedActivity = this.Model.getProperty("/SelectedActivity");
		const isLearning = this.Model.getProperty("/IsLearning");
		const isOthersTab = this.Model.getProperty("/IsOtherTab");
		const isCFvisible = this.Model.getProperty("/IsCustomerFacingVisible");
		const sTimeMatrics = oNewEntry.unit;

		const currentWorkDuration = oNewEntry.duration.current;
		if (!parseFloat(currentWorkDuration, 10) || parseFloat(currentWorkDuration, 10) <= 0) {
			MessageToast.show("Please Enter Time");
			return;
		}

		let totalWorkDuration = 0;

		aEntries.filter(function (item) {
			if (item.RecordDate === oNewEntry.recordDate) {
				totalWorkDuration = totalWorkDuration + parseFloat(item.duration.current, 10);
			}
		});
		let ExpectedWorkDuration = 0;
		ExpectedWorkDuration = currentWorkDuration + totalWorkDuration;
		if (sTimeMatrics === "H" && ExpectedWorkDuration > 24) {
			MessageToast.show("Cannot book >24hours in a day");
			return;
		}

		if (isOthersTab && !oNewEntry.task.taskId) {
			MessageToast.show("Please Select Task");
			return;
		}

		if (!isLearning) {
			if (!isOthersTab) {
				const sActivityId = oNewEntry.ActvtId;
				if (!sActivityId) {
					MessageToast.show("Please select activity");
					return;
				}
			}

			const sCostTypeId = oNewEntry.costType.id;
			if (!sCostTypeId) {
				MessageToast.show("Please select cost type");
				return;
			}

			const sManualIo = oNewEntry.costType.value;
			const property = isOthersTab ? "isOthersTabManualIO" : "isManualIO";
			if (this.Model.getProperty("/" + property) && !sManualIo) {
				MessageToast.show("Please select Manual IO");
				return;
			}
		}

		if (isLearning || isOthersTab || !isCFvisible) {
			oNewEntry.customerFacing = false;
		}

		const isEdit = this.Model.getProperty("/IsEdit");
		if (isEdit) {
			oNewEntry.Indicator = "U";
		} else {
			oNewEntry.Indicator = "I";
		}

		this.Model.setProperty("/IsSubmitBusy", true);

		TimeState.getInstance().submitEntries([oNewEntry]).then(() => {
			let index = aEntries.findIndex(function (item) {
				return item.MtrUid === oNewEntry.MtrUid;
			});
			if (index !== -1) {
				oNewEntry.status.id = aEntries[index].status.id;
				aEntries[index] = oNewEntry;
			}
			this.onMessagePopoverPress();
			this._filterEntries();
			this._setEntriesInfoData(aEntries, oNewEntry.RecordDate);
			if (!isEdit) {
				this._ResetEntryData();
			}
			this.Model.setProperty("/IsSubmitBusy", false);


		})

	}

	onCustomerFacingChange(oEvent) {
		let bState = oEvent.getSource().getState();
		const isEdit = this.Model.getProperty("/IsEdit");
		const oSelectedActivity = this.Model.getProperty("/SelectedActivity");
		const sActId = this.Model.getProperty("/Entry/ActvtId");
		this.Model.setProperty("/Entry/customerFacing", bState);
		if (!isEdit && !oSelectedActivity) {
			this.filterUserActivities();
			const aActivities = this.Model.getProperty("/UserActivities");
			const sMpngAttrVal = bState ? "1" : "2";
			if (aActivities && aActivities.length) {
				const oActivity = aActivities.find(item => item.ActivityId === sActId && item.MpngAttrVal === sMpngAttrVal);
				if (oActivity) {
					this.Model.setProperty("/Entry/task/taskId", oActivity.MtrTaskID);
					this.Model.setProperty("/Entry/task/name", oActivity.MtrTaskName);
				}
			}
		} else {
			this._selectMTRTask();
		}
	}
}
