/*!
 * ${copyright}
 */
import jQuery from "jquery.sap.global";
import ResourceBundle from "sap/base/i18n/ResourceBundle";
import ResourceModel from "sap/ui/model/resource/ResourceModel";
import JSONModel from "sap/ui/model/json/JSONModel";
import Calendar from "sap/ui/unified/Calendar";
import CalendarDateInterval from "sap/ui/unified/CalendarDateInterval";
import CalendarMode from "com/melodylib/time/controls/calendar/CalendarMode";
import DateService from "com/melodylib/time/service/DateService";
import DateRange from "sap/ui/unified/DateRange";
import Control from "sap/ui/core/Control";
import Controller from "sap/ui/core/mvc/Controller";
import CalendarRenderer from "./CalendarRenderer";
import TimeState from "com/melodylib/time/state/TimeState";
import TimeMasterState from "com/melodylib/time/state/TimeMasterState"
import Device from "sap/ui/Device";
import TimeModels from "com/melodylib/time/model/TimeModels";
import CalendarType from "sap/ui/core/CalendarType";
import DateFormat from "sap/ui/core/format/DateFormat";
const genericDateFormat = DateFormat.getInstance({
    pattern: "yMMdd",
    calendarType: CalendarType.Gregorian
});
/**
 * Constructor for a new <code>com.melodylib.integration.controls.AccountSelect</code> control.
 *
 * Some class description goes here.
 * @extends Control
 *
 * @author Siddharth Sagvekar
 * @version ${version}
 *
 * @constructor
 * @public
 * @name com.melodylib.time.controls.DayWeekCalendar
 */


export default class CalendarControl extends Control {

    static metadata = {
        library: "com.melodylib.time",
        properties: {
            /**
             * width
             */
            width: {
                type: "sap.ui.core.CSSSize",
                defaultValue: "100%"
            },
            /**
             * isWeekly
             */
            isWeekly: {
                type: "boolean",
                defaultValue: false
            },
            /**
             * isWeekly
             */
            mode: {
                type: "com.melodylib.time.controls.calendar.CalendarMode",
                defaultValue: CalendarMode.Daily
            },

            /**
             * singleSelection
             */
            singleSelection: {
                type: "boolean",
                defaultValue: true
            },

            /**
             * dayWeekIndicatorVisibility
             */
            dayWeekIndicatorVisibility: {
                type: "boolean",
                defaultValue: true
            },

            startDate: {
                type: "string",
                defaultValue: ""
            },

            /**
             * selectedDate
             */
            selectedDate: {
                type: "object",
                defaultValue: false
            },

            /**
             * selectedDates
             */
            selectedDates: {
                type: "object",
                defaultValue: false
            },

            copyPeriod: {
                type: "string",
                defaultValue: ""
            },

            /**
             * entries
             */
            entries: {
                type: "object",
                defaultValue: []
            },
            /**
             * startDayOfWeek
             */
            startDayOfWeek: {
                defaultValue: 1
            },
            /**
                 * datePicker
                 */
            isDatePicker: {
                type: "boolean",
                defaultValue: false
            },
            /**
             * unit
             */
            unit: {
                type: "string",
                defaultValue: "H"
            },
            /**
             * holidays
             */
            holidays: {
                type: "object",
                defaultValue: []
            },
            /**
             * vacations
             */
            vacations: {
                type: "object",
                defaultValue: []
            },
            /**
             * essInMu
             */
            essInMu: {
                type: "boolean",
                defaultValue: false
            },
            /**
             * tasks
             */
            tasks: {
                type: "object",
                defaultValue: []
            },

            showLegends: {
                type: "boolean",
                defaultValue: true
            }
        },
        events: {
            /**
             * Event is fired when the user clicks on the control.
             */
            press: {},
            select: {
                parameters: {
                    selectionStartDate: {
                        type: "object"
                    },
                    selectionEndDate: {
                        type: "object"
                    }
                }
            },
            navigate: {
                parameters: {
                    selectionStartDate: {
                        type: "object"
                    },
                    selectionEndDate: {
                        type: "object"
                    }
                }
            },
            changeMode: {
                parameters: {
                    mode: {
                        type: "com/melodylib/time/controls/calendar/CalendarMode"
                    }
                }
            }
        },
        aggregations: {
            /**
             * Calendar control for desktop view
             */
            _calendar: {
                type: "sap.ui.unified.Calendar",
                multiple: false,
                visibility: "hidden"
            },

            /**
             * Day/Week Indicator buttons
             */
            _dayWeekIndicator: {
                type: "sap.m.SegmentedButton",
                multiple: false,
                visibility: "hidden"
            },

            /**
             * Event is fired when the user clicks on the control.
             */
            _legendBox: {
                type: "sap.m.FlexBox",
                multiple: false,
                visibility: "hidden"
            },

            /**
             * Event is fired when the user clicks on the control.
             */
            _copyFrom: {
                type: "sap.m.FormattedText",
                multiple: false,
                visibility: "hidden"
            },

            /**
             * Tokens for Copy functionality
             */
            _selections: {
                type: "sap.m.Tokenizer",
                multiple: false,
                visibility: "hidden"
            }
        }
    };
    static renderer = CalendarRenderer;

    init() {
        var that = this;
        that.setBusyIndicatorDelay(0);
        this.controller = new CalendarController(this);

        //initialisation code, in this case, ensure css is imported
        let styleSheetPath = sap.ui.require.toUrl("com/melodylib/time/css/");
        jQuery.sap.includeStyleSheet(`${styleSheetPath}melodyTimeCalendar.css`);
        jQuery.sap.includeStyleSheet(`${styleSheetPath}activityProgressBar.css`);
        jQuery.sap.includeStyleSheet(`${styleSheetPath}mTRCalendar.css`);

        //Set i18n Model
        var i18nModel = new ResourceModel({
            bundleName: "com.melodylib.time.i18n.i18n"
        });
        this.setModel(i18nModel, "i18n");
        const oResourceBundle = TimeModels.getMTRResourceModel().getResourceBundle();
        const sText = oResourceBundle.getText('dayWeekCalSelectedDayLegend');
        // initialize Calendar
        that._initCalendar();

        //initializion day week indicator
        that._initDayWeekIndicator();

        //initializion legendItem
        that._initLegends();

        this.setAggregation("_copyFrom", new sap.m.FormattedText({
            htmlText: "",
            visible: !that.getSingleSelection()
        }).addStyleClass("copyFrom"));

        //initializion selections
        this.setAggregation("_selections", new sap.m.Tokenizer({
            // tokens: that.getSelectedDates(),
            tokens: [],
            visible: !that.getSingleSelection()
        }));
    }
    setIsDatePicker(bValue) {
        this.setProperty("isDatePicker", (bValue || bValue === "true"));
    }
    _startDateChange() {
        var oTimeStateModel = this.controller.TimeState.getModel();
        var oTimeStateMasterModel = TimeMasterState.getInstance().getModel()
        var that = this;
        var oCalendar = that.getAggregation("_calendar");
        var startDate = oCalendar.getStartDate();
        if (that.getSingleSelection()) {
            var aEntries = that.getEntries();
            setTimeout(function () {
                that.setEntries(aEntries);
            }, 100);

            var dateSelector = "sapUiCalMonthView";
            if (!Device.system.desktop) {
                dateSelector = "sapUiCalRow";
            }
            var selectedWeekHighlighter = $("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent ." + dateSelector + " .selectedWeek");
            var selector = selectedWeekHighlighter.attr("data-selector-id");
            var weekStartDate = new Date($("#" + that.getId() + "-dayWeekCalendar " + selector).attr("aria-label"));
            if (weekStartDate.getMonth() === startDate.getMonth()) {
                selectedWeekHighlighter.show();
                $("#" + that.getId() + "-dayWeekCalendar " + selector).addClass("weekSelected");
                $("#" + that.getId() + "-dayWeekCalendar " + selector).nextUntil(".sapUiCalFirstWDay").addClass("weekSelected");
            } else {
                selectedWeekHighlighter.hide();
                $("#" + that.getId() + "-dayWeekCalendar " + selector).removeClass("weekSelected");
                $("#" + that.getId() + "-dayWeekCalendar " + selector).nextUntil(".sapUiCalFirstWDay").removeClass("weekSelected");
            }

            if (!Device.system.desktop && that.getSingleSelection()) {
                var entries = that.getEntries();
                that.setEntries(entries);
            }

            var sStartDate = DateService.getInstance().format(startDate, "yMMdd");

            var endDate = new Date(startDate.getTime() + (6 * 24 * 60 * 60 * 1000));
            var endDateString = genericDateFormat.format(endDate);
            if (that.getMode() === CalendarMode.Weekly && that.getSingleSelection()) {
                dateSelector = "sapUiCalRow";
                var elementId = $("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent ." + dateSelector +
                    "  .sapUiCalItem[data-sap-day='" + sStartDate + "']").attr("id");
                that._setSelectedWeekHighlighter(elementId, that, sStartDate, endDateString);
            }
            if (!Device.system.desktop && that.getMode() === CalendarMode.Weekly) {
                that.fireEvent("select", {
                    selectionStartDate: startDate,
                    selectionEndDate: endDate
                });
            } else {
                that.fireEvent("navigate", {
                    selectionStartDate: startDate,
                    selectionEndDate: endDate
                });
            }
            if (that.getMode() === CalendarMode.Weekly && that.getSingleSelection()) {
                that._setMode();
            }
        }

    }
    _initCalendar() {
        var that = this;
        var cal = Calendar;
        if (!Device.system.desktop) {
            cal = CalendarDateInterval;
        }

        //initializion calendar
        this.setAggregation("_calendar", new cal(that.getId() + "-dayWeekCalendar", {
            specialDates: [],
            showWeekNumbers: false,
            busyIndicatorDelay: 0,
            select: function (oEvent) {
                that._select();
            },
            startDateChange: function () {
                that._startDateChange();
            },
            singleSelection: that.getSingleSelection()
        }).setIntervalSelection(false));

        if (Device.system.desktop) {
            this.getAggregation("_calendar").setShowWeekNumbers(false)
                .addStyleClass("dayWeekCalendar");
        } else {
            this.getAggregation("_calendar")
                .setIntervalSelection(false).addStyleClass("shortCalendar");
        }
        this.getAggregation("_calendar").addStyleClass("melodyMtrCalendar");
    }

    _initDayWeekIndicator() {
        const oResourceBundle = sap.ui.getCore().getModel("i18n");
        var that = this;
        this.setAggregation("_dayWeekIndicator", new sap.m.SegmentedButton({
            width: "100px",
            items: [
                new sap.m.SegmentedButtonItem({
                    text: "Day",

                    key: CalendarMode.Daily
                }),
                new sap.m.SegmentedButtonItem({
                    // text: "{i18n>calWeekModeTxt}",
                    text: "Week",
                    key: CalendarMode.Weekly
                })
            ],
            visible: that.getDayWeekIndicatorVisibility() && that.getSingleSelection(),
            // visible: true,
            selectedKey: that.getMode(),
            // selectedKey: '',
            selectionChange: (function (oEvent) {
                // var value = oEvent.getParameter("item").getProperty("key");
                // that.setBusy(true);
                // that.getAggregation("_calendar").removeAllSelectedDates();
                // that.setMode(value);
                // that.modeChangeTriggered = true;
                // if (value === CalendarMode.Daily) {
                //     that.getAggregation("_legendBox").getAggregation("items")[1].setVisible(false);
                //     that.getAggregation("_legendBox").getAggregation("items")[2].setVisible(true);
                // } else {
                //     that.getAggregation("_legendBox").getAggregation("items")[1].setVisible(true);
                //     that.getAggregation("_legendBox").getAggregation("items")[2].setVisible(false);
                // }

                // that._setMode();
                // that.fireEvent("changeMode", {
                //     mode: that.getMode()
                // });
            }).bind(this)
        }).addStyleClass("dateModeSelector"));
    }

    _initLegends() {
        var that = this;
        // const oResourceBundle = sap.ui.getCore().getModel("i18n");
        this.setAggregation("_legendBox", new sap.m.FlexBox({
            renderType: "List",
            justifyContent: "Center",
            alignItems: "Center",
            visible: (that.getSingleSelection() && that.getShowLegends()),
            items: [
                new sap.m.Link({
                    text: "{i18n>dayWeekCalTodayLegend}",
                    press: function (evt) {

                    }
                }).addStyleClass("legendItem legendLink"),
                new sap.m.Text({
                    // text: "{i18n>dayWeekCalSelectedWeekLegend}",
                    text: "Selected Week",
                    visible: that.getMode() !== CalendarMode.Daily
                }).addStyleClass("legendItem legendSelected"),
                new sap.m.Text({
                    text: "{i18n>dayWeekCalSelectedDayLegend}",
                    // text: "Selected Day",
                    visible: that.getMode() === CalendarMode.Daily
                }).addStyleClass("legendItem legendSelectedDay"),
                new sap.m.Text({
                    // text: "{i18n>dayWeekCalWeekendLegend}"
                    text: "Weekend"
                }).addStyleClass("legendItem legendWeekend"),
                new sap.m.Text({
                    // text: "{i18n>dayWeekCalHolidayLegend}"
                    text: "Holiday"
                }).addStyleClass("legendItem legendHoliday")
            ]
        }).addStyleClass("legendBar"));
    }
    setShowLegends(bValue) {
        const value = (bValue === false) ? false : true;
        const legendBox = this.getAggregation("_legendBox");
        legendBox.setVisible(value);
    }
    onAfterRendering() {
        var that = this;
        that.setBusy(true);
        //if I need to do any post render actions, it will happen here
        if (sap.ui.core.Control.prototype.onAfterRendering) {
            sap.ui.core.Control.prototype.onAfterRendering.apply(this, arguments); //run the super class's method first
        }
        if (!Device.system.desktop) {
            this.getAggregation("_calendar").setShowWeekNumbers(false)
                .setStartDate(that._getStartDateOfWeek());
        } else {
            this.getAggregation("_calendar").setProperty("firstDayOfWeek", parseInt(this.getStartDayOfWeek(), 10));
        }
        this.getAggregation("_calendar").setNonWorkingDays(this.getWeekends());

        that._setMode();
    }
    _getStartDateOfWeek() {
        var d = new Date();
        var day = d.getDay(),
            diff = d.getDate() - day + (day === 0 ? -6 : parseInt(this.getStartDayOfWeek(), 10));
        return new Date(d.setDate(diff));
    }
    _setMode() {
        var that = this;
        that.setBusy(true);

        /*var oComponent = Application.getInstance().Component;
        var oDayWeekTimesheetModel = oComponent.getModel("DayWeekTimesheet");
        var sSelectedDate = oDayWeekTimesheetModel.getProperty("/SelectedDate");*/

        var sSelectedDate = that.getStartDate();

        var dSelectedDate = new Date();

        var _handleClickWeekHighlighter = function (event) {
            that._selectWeek(this);
        };
        if (sSelectedDate) {
            dSelectedDate = new Date(sSelectedDate);
        } else {
            dSelectedDate = new Date();
        }
        setTimeout(function () {
            var oResourceBundle = that.getModel("i18n").getResourceBundle();
            if (that.getMode() === CalendarMode.Weekly) {
                if (Device.system.desktop) {
                    that.getAggregation("_calendar").addStyleClass("week");
                    that.getAggregation("_calendar").setShowWeekNumbers(true);
                    var calendar = jQuery.sap.byId(that.getId() + "-dayWeekCalendar")[0];
                    var firstHeaderElement = calendar.querySelectorAll('.sapUiCalContent .sapUiCalMonthView div[role="row"] .sapUiCalFirstWDay');
                    var sFirstHeaderElementText = (firstHeaderElement[0].innerText) ? jQuery.sap.encodeHTML(firstHeaderElement[0].innerText) : "";
                    if (jQuery(firstHeaderElement).has("span.weekLabel").length === 0) {
                        firstHeaderElement[0].innerHTML = "<span id='" + that.getId() + "-weekLabel" +
                            "' class='weekLabel'>" + oResourceBundle.getText("calWeekModeFirstHeader") + "</span><span class='val'>" +
                            sFirstHeaderElementText +
                            "</span>";
                    }
                    if ($("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent .sapUiCalMonthView").has(".weekHighlighter").length === 0) {
                        var nodes = "<div class='weekHighlighter'></div><div class='selectedWeek'></div>";
                        /*eslint-disable sap-no-dom-insertion*/
                        $("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent .sapUiCalMonthView").append(nodes);
                        /*eslint-enable sap-no-dom-insertion*/
                    }
                    $("#" + that.getId() + "-dayWeekCalendar .sapUiCalFirstWDay:last").addClass("lastCalItem");
                    $("#" + that.getId() + "-dayWeekCalendar .sapUiCalFirstWDay:last").nextAll(".sapUiCalItem").addClass("lastCalItem");
                    $("#" + that.getId() + "-dayWeekCalendar").off("mouseenter", ".sapUiCalMonthView div.sapUiCalItem", this._handleMouseEnterWeeklyItem);
                    $(document).off("mouseleave", "#" + that.getId() + "-dayWeekCalendar", this._handleMouseLeaveWeeklyItem);
                    $("#" + that.getId() + "-dayWeekCalendar").off("click", ".weekHighlighter");
                    $("#" + that.getId() + "-dayWeekCalendar").on("mouseenter", ".sapUiCalMonthView div.sapUiCalItem", {
                        calObj: that
                    }, that._handleMouseEnterWeeklyItem);
                    $(document).on("mouseleave", "#" + that.getId() + "-dayWeekCalendar", {
                        calObj: that
                    }, that._handleMouseLeaveWeeklyItem);
                    $("#" + that.getId() + "-dayWeekCalendar").on("click", ".weekHighlighter", _handleClickWeekHighlighter);
                }
            }
            if (that.getSingleSelection()) {
                var aEntries = that.getEntries();
                that.setEntries(aEntries);
            }
            if (that.getMode() === CalendarMode.Weekly && that.getSingleSelection()) {
                var startDateString = that.genericDateFormat.format(dSelectedDate);
                var endDate = new Date(dSelectedDate.getTime() + (6 * 24 * 60 * 60 * 1000));
                var endDateString = that.genericDateFormat.format(endDate);
                var dStartDate = DateService.getInstance().getStartDateOfWeek(dSelectedDate, 1);
                var sStartDate = DateService.getInstance().format(dStartDate, "yMMdd");
                var dateSelector = "sapUiCalMonthView";
                if (!Device.system.desktop) {
                    dateSelector = "sapUiCalRow";
                }
                var elementId = $("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent ." + dateSelector +
                    "  .sapUiCalItem[data-sap-day='" + sStartDate + "']").attr("id");
                that._setSelectedWeekHighlighter(elementId, that, startDateString, endDateString);
            }
            that.setBusy(false);
        }, 500);
        $("#" + that.getId() + "-dayWeekCalendar .weekHighlighter").hide();
        $("#" + that.getId() + "-dayWeekCalendar .selectedWeek").hide();
        $("#" + that.getId() + "-dayWeekCalendar .sapUiCalMonthView .sapUiCalItem").removeClass("lastCalItem");
        if (that.getMode() === CalendarMode.Weekly) {
            if (!Device.system.desktop && that.getSingleSelection()) {
                $(".selectedWeek").show();
            }
        } else {
            that.getAggregation("_calendar").removeStyleClass("week");
            that.getAggregation("_calendar").setShowWeekNumbers(false);
            $("#" + that.getId() + "-dayWeekCalendar").off("mouseenter", ".sapUiCalMonthView div.sapUiCalItem", this._handleMouseEnterWeeklyItem);
            $(document).off("mouseleave", "#" + that.getId() + "-dayWeekCalendar", this._handleMouseLeaveWeeklyItem);
            $("#" + that.getId() + "-dayWeekCalendar").off("click", ".weekHighlighter");
        }
        if (this.getSingleSelection() && this.getMode() === CalendarMode.Daily) {
            var selectedDateRange = new sap.ui.unified.DateRange({
                startDate: dSelectedDate,
                endDate: dSelectedDate
            });
            that.getAggregation("_calendar").insertSelectedDate(selectedDateRange);
        }
    }
    setDayWeekIndicatorVisibility(bValue) {
        this.getAggregation("_dayWeekIndicator").setVisible(bValue);
        this.setProperty("dayWeekIndicatorVisibility", bValue);

        if (bValue) {
            jQuery(".melodyTimeCalendar").find(".sapUiCalHead").css("width", "315px");
        } else {
            jQuery(".melodyTimeCalendar").find(".sapUiCalHead").css("width", "100%");
        }
    }
    _handleMouseEnterWeeklyItem(event) {
        var that = event.data.calObj;
        var p = $(this).position();
        $("#" + that.getId() + "-dayWeekCalendar .weekHighlighter").show();
        var firstElement, firstElementId;
        if ($(this).hasClass("sapUiCalFirstWDay")) {
            firstElement = $(this);
            firstElementId = firstElement[0].getAttribute("id");
        } else {
            firstElement = $(this).prevAll(".sapUiCalFirstWDay:first");
            firstElementId = firstElement[0].getAttribute("id");
        }
        $("#" + that.getId() + "-dayWeekCalendar .weekHighlighter").attr("data-selector-id", firstElementId);
        $("#" + that.getId() + "-dayWeekCalendar .weekHighlighter").css({
            top: p.top
        });
    }
    setEntries(aEntries) {
        var that = this;


        var bEssInMu = this.getEssInMu();

        var aTasks = this.getTasks();
        if (that.getSingleSelection()) {
            var dateSelector = "sapUiCalMonthView";
            if (!Device.system.desktop) {
                dateSelector = "sapUiCalRow";
            }
            var oResourceBundle = this.getModel("i18n").getResourceBundle();
            var unit = (this.getUnit() === "H") ? " " + oResourceBundle.getText("dayWeekCalHoursUnit") : oResourceBundle.getText(
                "dayWeekCalDayUnit");
            var unitHr = (this.getUnit() === "H") ? " " + oResourceBundle.getText("dayWeekCalHourUnit") : oResourceBundle.getText(
                "dayWeekCalDayUnit");
            $("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent ." + dateSelector + "  .sapUiCalItem .calDuartion").text(
                '');

            this.setProperty("entries", aEntries);
            if (aEntries && aEntries.length > 0) {
                var groupedEntriesByDate = this.groupBy(aEntries, function (item) {
                    return [item.recordDate];
                });
                for (var item in groupedEntriesByDate) {
                    var totalWorkDuration = 0;
                    var statusId = "";
                    for (var i = 0; i < groupedEntriesByDate[item].length; i++) {
                        var workDuration = 0;
                        if (groupedEntriesByDate[item][i].dataFrom && groupedEntriesByDate[item][i].dataFrom !== "") {
                            workDuration = parseFloat(groupedEntriesByDate[item][i].duration.current);
                            if (!isNaN(workDuration)) {
                                var oTask = aTasks.find(function (entry) {
                                    return entry.taskId && groupedEntriesByDate[item][i].task.taskId && entry.taskId.toString() === groupedEntriesByDate[item][i].task.taskId
                                        .toString();
                                });
                                if (oTask && ((bEssInMu && !oTask.EssInMu) || !bEssInMu) && oTask.IsArchive !== "X") {
                                    totalWorkDuration += parseFloat(groupedEntriesByDate[item][i].duration.current);
                                    if (groupedEntriesByDate[item][i].status.key && groupedEntriesByDate[item][i].status.key !== "") {
                                        if (groupedEntriesByDate[item][i].status.key === "3") {
                                            statusId = "3"; // Failed
                                        } else if (groupedEntriesByDate[item][i].status.key === "1" && statusId !== "3") {
                                            statusId = "1"; // Save
                                        } else if (groupedEntriesByDate[item][i].status.key === "2" && statusId !== "1" && statusId !== "3") {
                                            statusId = "2"; // In queue
                                        } else if (groupedEntriesByDate[item][i].status.key === "4" && statusId !== "1" && statusId !== "2" && statusId !== "3") {
                                            statusId = "4"; // Submitted
                                        }
                                    }
                                }
                            }
                        }
                    }

                    var counts = this.countDecimal(totalWorkDuration);
                    if (counts > 0) {
                        totalWorkDuration = totalWorkDuration.toFixed(1);
                    }
                    var totalDurationString = "";
                    if (totalWorkDuration !== 0) {
                        if (totalWorkDuration > 1) {
                            totalDurationString += totalWorkDuration + unit;
                        } else {
                            totalDurationString += totalWorkDuration + unitHr;
                        }
                    }

                    // setTimeout(function() {
                    var calDuration = $("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent ." + dateSelector +
                        "  .sapUiCalItem[data-sap-day='" + groupedEntriesByDate[item][0].RecordDate + "'] .calDuartion");
                    if (calDuration.length === 0) {
                        /*eslint-disable sap-no-dom-insertion*/
                        $("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent ." + dateSelector + "  .sapUiCalItem[data-sap-day='" +
                            groupedEntriesByDate[item][0].recordDate + "']").append("<span class='calDuartion' data-statusid='" + statusId + "'>" +
                                totalDurationString + "</span>");
                        /*eslint-enable sap-no-dom-insertion*/
                    } else {
                        calDuration.text(totalDurationString);
                        calDuration.attr("data-statusid", statusId);
                    }
                    // }, 500);

                }
            } else {
                $("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent ." + dateSelector + " .sapUiCalItem .calDuartion").text(
                    '');
            }
        }
    }
    countDecimal(value) {
        if (Math.floor(value) === value) return 0;
        return value.toString().split(".")[1].length || 0;
    }
    getWeekends() {
        var iStartDayfOfWeek = parseInt(this.getStartDayOfWeek(), 10);
        var firstWeekend = 5 + iStartDayfOfWeek;
        if (firstWeekend > 6) {
            firstWeekend = firstWeekend - 7;
        }

        var secondWeekend = 6 + iStartDayfOfWeek;
        if (secondWeekend > 6) {
            secondWeekend = secondWeekend - 7;
        }

        return [firstWeekend, secondWeekend];
    }

    groupBy(entries, f) {
        var groups = {};
        entries.forEach(function (o) {
            var group = JSON.stringify(f(o));
            groups[group] = groups[group] || [];
            groups[group].push(o);
        });
        var keys = [];
        for (var k in groups) keys.push(k);
        return keys.map(function (group) {
            return groups[group];
        });
    }
    _select() {
        var that = this;
        that.setBusy(true);
        var oCalendar = that.getAggregation("_calendar");
        var aSelectedDates = oCalendar.getSelectedDates();
        if (!this.getSingleSelection()) {
            var calendarDateFormat = sap.ui.core.format.DateFormat.getInstance({
                pattern: "EEE, MMM d, y",
                calendarType: sap.ui.core.CalendarType.Gregorian
            });

            var oDate;
            var aDates = [];
            that.getAggregation("_selections").removeAllTokens();
            if (aSelectedDates.length > 0) {
                for (var i = 0; i < aSelectedDates.length; i++) {
                    oDate = aSelectedDates[i].getStartDate();
                    var token = new sap.m.Token({
                        text: calendarDateFormat.format(oDate),
                        delete: function (event) {
                            that._deleteSelection(that, event);
                        }
                    });
                    token.data("date", oDate);
                    that.getAggregation("_selections").addToken(token);
                }
                that.setSelectedDates(aDates);
            }
        }
        if (that.getMode() === CalendarMode.Daily || (!Device.system.desktop && !this.getSingleSelection())) {
            if (aSelectedDates.length > 0) {
                let index = 0;
                if (that.getIsDatePicker()) {
                    index = aSelectedDates.length - 1;
                }

                that.fireEvent("select", {
                    selectionStartDate: aSelectedDates[index].getProperty("startDate"),
                    selectionEndDate: aSelectedDates[index].getProperty("endDate")
                });
            } else {
                that.fireEvent("select", {
                    selectionStartDate: null,
                    selectionEndDate: null
                });
            }
        }
        var aEntries = that.getEntries();
        setTimeout(function () {
            that.setEntries(aEntries);
        }, 100);
        that.setBusy(false);

    }
}
class CalendarController extends Controller {
    constructor(control) {
        super();
        this.control = control;
        this.TimeState = TimeState.getInstance();
        // this.masterDataState = MasterDataState.getInstance();
    }
    onInit() {
        this.setBusy(false);
    }
}
