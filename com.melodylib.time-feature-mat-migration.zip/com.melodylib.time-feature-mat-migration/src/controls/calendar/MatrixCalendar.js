/*!
 * ${copyright}
 */
import jQuery from "jquery.sap.global";
import Calendar from "sap/ui/unified/Calendar";
import CalendarDateInterval from "sap/ui/unified/CalendarDateInterval";
import TimeMasterState from "com/melodylib/time/state/TimeMasterState";
import DateService from "com/melodylib/core/service/DateService";
import DateRange from "sap/ui/unified/DateRange";
import Control from "sap/ui/core/Control";
import Controller from "sap/ui/core/mvc/Controller";
import ResourceBundle from "sap/base/i18n/ResourceBundle";
import ResourceModel from "sap/ui/model/resource/ResourceModel";
import JSONModel from "sap/ui/model/json/JSONModel";
import MatrixCalendarRenderer from "./MatrixCalendarRenderer";
import TimeState from "com/melodylib/time/state/TimeState";
import Fragment from "sap/ui/core/Fragment";



/**
 * Constructor for a new <code>com.melodylib.time.controls.MatrixCalendar</code> control.
 *
 * Some class description goes here.
 * @extends Control
 *
 * @author Siddharth Sagvekar
 * @version ${version}
 *
 * @constructor
 * @public
 * @name com.melodylib.time.controls.MatrixCalendar
 */



export default class MatrixCalendar extends Control {

	static metadata = {
		library: "com.melodylib.time",
		properties: {

			/**
			 * width
			 */
			width: {
				type: "sap.ui.core.CSSSize",
				defaultValue: "100%"
			},

			/**
			 * isValidTimesheet
			 */
			valid: {
				type: "boolean",
				defaultValue: true
			},

			/**
			 * startDayOfWeek
			 */
			startDayOfWeek: {
				defaultValue: 1
			},

			/**
			 * holidays
			 */
			holidays: {
				type: "object",
				defaultValue: []
			},

			/**
			 * vacations
			 */
			vacations: {
				type: "object",
				defaultValue: []
			}
		},
		events: {
			/**
			 * Event is fired when the user clicks on the control.
			 */
			press: {},

			/**
			 * Event is fired when the user clicks on the previous button.
			 */
			calendarNav: {},

			/**
			 * Event is fired when the user clicks on the previous button.
			 */
			beforeCalendarNav: {}
		},

		aggregations: {
			/**
			 * Calendar control
			 */
			_shortCalendar: {
				type: "sap.ui.unified.CalendarDateInterval",
				multiple: false,
				visibility: "hidden"
			},

			/**
			 * controls to navigate to previous and next calendar weeks
			 */
			_navCalendar: {
				type: "sap.m.FlexBox",
				multiple: false,
				visibility: "hidden"
			},

			/**
			 * Custom Legend Box
			 */
			_legends: {
				type: "sap.m.FlexBox",
				multiple: false,
				visibility: "hidden"
			},

		}
	};
	static renderer = MatrixCalendarRenderer;
	dateServicesInstance = DateService.getInstance();


	init() {
		let that = this;
		this.setBusyIndicatorDelay(0);
		this.controller = new MatrixCalendarController(this);
		this._setModel();

		var libraryPath = jQuery.sap.getModulePath("com.melodylib.time"); //get the server location of the ui library
		let styleSheetPath = sap.ui.require.toUrl("com/melodylib/time/css/");
		jQuery.sap.includeStyleSheet(`${styleSheetPath}activityProgressBar.css`); //specify the css path relative from the ui folder
		jQuery.sap.includeStyleSheet(`${styleSheetPath}matrixCreateEntry.css`); //specify the css path relative from the ui folder
		//initializion short calendar for mobile
		this.setAggregation("_shortCalendar", new CalendarDateInterval(this.getId() + "-shortCalendar", {
			showWeekNumbers: false,
			showDayNamesLine: false,
			specialDates: [],
			startDate: this._getStartDateOfWeek()
		}).addStyleClass("matrixDialogCalendar"));

		this.getAggregation("_shortCalendar").detachSelect(function () {
			return;
		});

		this.setAggregation("_navCalendar", new sap.m.FlexBox(this.getId() + "-navCalendar", {
			alignItems: "Center",
			justifyContent: "Center",
			items: [
				new sap.m.Button({
					text: "{i18n>matrixCalPreviousBtnTxt}",
					type: "Emphasized",
					press: this.onWeekChange.bind(this)
				}).data("isNext", false).addStyleClass("matrixPrevBt sapUiTinyMarginBeginEnd"),
				new sap.m.VBox({
					items: [
						new sap.m.Text({
							text: "{i18n>matrixCalHeaderLbl}"
						}).addStyleClass("currentWeek"),
						new sap.m.HBox({
							items: [
								new sap.m.Text(this.getId() + "-navCalendar-startDate", {
									text: this._getDate(this.getAggregation("_shortCalendar").getStartDate(), 0, true, true),
									wrapping: false
								}),
								new sap.m.Text({
									text: "-"
								}),
								new sap.m.Text(this.getId() + "-navCalendar-endDate", {
									text: this._getDate(this.getAggregation("_shortCalendar").getStartDate(), 6, true, true),
									wrapping: false
								}),
								new sap.ui.core.Icon({
									src: "sap-icon://appointment",
									press: function (event) {
										const core = sap.ui.getCore();


										if (core._pMelodyDatePickerPopover) {
											core._pMelodyDatePickerPopover.destroy();
											core._pMelodyDatePickerPopover = null;
										}


										Fragment.load({
											id: "MelodyDatePickerPopover",
											name: "com.melodylib.time.controls.calendar.matrix.fragments.MelodyDatePickerPopover",
											controller: this.controller
										}).then(function (popover) {
											core._pMelodyDatePickerPopover = popover;
											core._pMelodyDatePickerPopover.setModel(this.Model);
											core._pMelodyDatePickerPopover.openBy(event.getSource());

											const oCalendar = sap.ui.core.Fragment.byId("MelodyDatePickerPopover", "melodyDatePicker").getAggregation("_calendar");
											oCalendar.setSingleSelection(false);
											const startDate = this._getStartDateOfWeek();
											this.controller._selectWeek(startDate, oCalendar);
										}.bind(this));


									}.bind(this)
								}).addStyleClass("sapUiTinyMarginBegin")
							]
						})
					]
				}).addStyleClass("matrixPeriod"),
				new sap.m.Button({
					text: "{i18n>matrixCalNextBtnTxt}",
					type: "Emphasized",
					press: this.onWeekChange.bind(this)
				}).data("isNext", true).addStyleClass("matrixNextBt sapUiTinyMarginBeginEnd")
			]
		}).addStyleClass("matrixDialogCalendarHeader"));


		this.setAggregation("_legends", new sap.m.FlexBox(this.getId() + "-legends", {
			direction: "Column",
			alignItems: "Start",
			justifyContent: "Center",
			items: [
				new sap.m.Link({
					text: "{i18n>matrixCalTodayLegendTxt}",
					press: function () {
						var dDate = new Date();
						var dMatrixSelectedStartDate = this._getStartDateOfWeek();
						var dFirstDate = null;
						if (dDate) {
							dFirstDate = this._getFirstDayOfWeek(dDate);
						}
						if (dFirstDate && dMatrixSelectedStartDate !== dFirstDate) {
							this._onWeekChange(dFirstDate);
						}
					}.bind(this)
				}).addStyleClass("matrixLegend matrixTodayLegend matrixLegendLink"),
				new sap.m.Text({
					text: "{i18n>matrixCalHolidayLegendTxt}"
				}).addStyleClass("matrixLegend matrixHolidayLegend"),
				new sap.m.Text({
					text: "{i18n>matrixCalWeekendLegendTxt}"
				}).addStyleClass("matrixLegend matrixWeekendLegend")
			]
		}).addStyleClass("matrixDialogCalendarLegends"));







		const core = sap.ui.getCore();
		if (core._pMelodyDatePickerPopover) {
			const oCalendar = sap.ui.core.Fragment.byId("MelodyDatePickerPopover", "melodyDatePicker").getAggregation("_calendar");
			oCalendar.setInitialFocusedDate(new Date());
		}


	}

	_setModel() {
		const aEntries = TimeState.getInstance().getData().entries
		const aMTRTasks = TimeMasterState.getInstance().getTasks();
		const oModel = new JSONModel({
			Entries: aEntries,
			MTRTasks: aMTRTasks
		});

		this.Model = oModel;
	}

	_getDate(date, days, isNext, returnFormatted) {
		var calendarDateFormat = sap.ui.core.format.DateFormat.getInstance({
			pattern: "MMMM dd, yyyy",
			calendarType: sap.ui.core.CalendarType.Gregorian
		});
		var dt;
		if (isNext) {
			dt = new Date(date.getTime() + (days * 24 * 60 * 60 * 1000));

		} else {
			dt = new Date(date.getTime() - (days * 24 * 60 * 60 * 1000));
		}

		dt = this.adjustDateForDST(dt);

		if (returnFormatted) {
			return calendarDateFormat.format(dt);
		} else {
			return dt;
		}


	}

	setValid(bValue) {
		this.setProperty("valid", bValue);
	}

	setHolidays(aHolidays) {
		var calendar = this.getAggregation("_shortCalendar");
		for (var i = 0; i < aHolidays.length; i++) {
			var dHoliday = this.dateServicesInstance.formatStringDate(aHolidays[i]);
			var holiday = new sap.ui.unified.DateTypeRange({
				startDate: dHoliday,
				type: "Type01",
				color: "#537581",
				tooltip: "{i18n>matrixCalHolidayTooltip}"
			});
			calendar.addSpecialDate(holiday);
		}
		this._setCalendarSettings();
	}

	setVacations(aVacations) {
		var calendar = this.getAggregation("_shortCalendar");
		for (var i = 0; i < aVacations.length; i++) {
			var dHoliday = this.dateServicesInstance.formatStringDate(aVacations[i]);
			var holiday = new sap.ui.unified.DateTypeRange({
				startDate: dHoliday,
				type: "Type02",
				color: "#537581",
				tooltip: "{i18n>matrixCalVacationTooltip}"
			});
			calendar.addSpecialDate(holiday);
		}
		this._setCalendarSettings();
	}
	onWeekChange(oEvent) {

		var isNext = oEvent.getSource().data("isNext");
		var currentStartDate = this.getAggregation("_shortCalendar").getStartDate();
		var nextStartDate = this._getDate(currentStartDate, 7, isNext, false);
		this._onWeekChange(nextStartDate);
	}

	_onWeekChange(nextStartDate, isNext) {

		this.fireBeforeCalendarNav();

		if (this.getValid()) {
			this.getAggregation("_shortCalendar").setStartDate(nextStartDate);
			jQuery.sap.byId(this.getId() + "-navCalendar-startDate")[0].innerText = this._getDate(this.getAggregation("_shortCalendar").getStartDate(),
				0, true, true);
			jQuery.sap.byId(this.getId() + "-navCalendar-endDate")[0].innerText = this._getDate(this.getAggregation("_shortCalendar").getStartDate(),
				6, true, true);
			var currentStartDateOfWeek = DateService.getInstance().getStartDateOfWeek(new Date());
			if (currentStartDateOfWeek.getFullYear() === nextStartDate.getFullYear() &&
				currentStartDateOfWeek.getMonth() === nextStartDate.getMonth() &&
				currentStartDateOfWeek.getDate() === nextStartDate.getDate()) {
				this.getAggregation("_navCalendar").getAggregation("items")[1].getAggregation("items")[0].setText("CURRENT WEEK");
			} else {
				var weekNumber = this.dateServicesInstance.getWeek(nextStartDate);
				this.getAggregation("_navCalendar").getAggregation("items")[1].getAggregation("items")[0].setText("WEEK" + " " + weekNumber);
			}
			this._setCalendarSettings();
			this.fireCalendarNav();
		}
	}

	getWeekends() {
		var iStartDayfOfWeek = parseInt(this.getStartDayOfWeek(), 10);
		var firstWeekend = 5 + iStartDayfOfWeek;
		if (firstWeekend > 6) {
			firstWeekend = firstWeekend - 7;
		}
		var secondWeekend = 6 + iStartDayfOfWeek;
		if (secondWeekend > 6) {
			secondWeekend = secondWeekend - 7;
		}
		return [firstWeekend, secondWeekend];
	}

	setStartDayOfWeek(fValue) {
		this.setProperty("startDayOfWeek", fValue);
		this.getAggregation("_shortCalendar").setStartDate(this._getStartDateOfWeek());
		this.getAggregation("_navCalendar").getAggregation("items")[1].getAggregation("items")[1].getAggregation("items")[0].setText(this._getDate(
			this.getAggregation("_shortCalendar").getStartDate(), 0, true, true));
		this.getAggregation("_navCalendar").getAggregation("items")[1].getAggregation("items")[1].getAggregation("items")[2].setText(this._getDate(
			this.getAggregation("_shortCalendar").getStartDate(), 6, true, true));
		this._setCalendarSettings();
	}

	setStartDate(dDate) {
		this.getAggregation("_shortCalendar").setStartDate(dDate);
		this.getAggregation("_navCalendar").getAggregation("items")[1].getAggregation("items")[1].getAggregation("items")[0].setText(this._getDate(
			this.getAggregation("_shortCalendar").getStartDate(), 0, true, true));
		this.getAggregation("_navCalendar").getAggregation("items")[1].getAggregation("items")[1].getAggregation("items")[2].setText(this._getDate(
			this.getAggregation("_shortCalendar").getStartDate(), 6, true, true));
		this._setCalendarSettings(dDate);
		this._setCalendarWeekText(dDate);
	}

	_getStartDateOfWeek() {
		var cal = this.getAggregation("_shortCalendar");
		var d;
		if (cal) {
			d = cal.getStartDate();
		} else {
			d = new Date();
		}
		return this._getFirstDayOfWeek(d);
	}
	_getFirstDayOfWeek(d) {
		return DateService.getInstance().getStartDateOfWeek(d);
		/*var day = d.getDay(),
		  diff = d.getDate() - day + (day === 0 ? -6 : parseInt(this.dateServicesInstance.getStartDateOfWeek(), 10));
		return new Date(d.setDate(diff));*/
	}

	onAfterRendering() {
		this._setCalendarSettings();
	}

	_setCalendarSettings() {
		setTimeout(() => {
			const oResourceBundle = this.getModel("i18n").getResourceBundle();
			const todayElement = $("#" + this.getId() + "-shortCalendar--Month0").find(".sapUiCalItem.sapUiCalItemNow");

			if (todayElement.has("span.dateLabel").length === 0) {
				todayElement.append("<span class='dateLabel todayLabel'>" + oResourceBundle.getText("matrixCalTodayLbl") + "</span>");
			}
			if (todayElement.hasClass("sapUiCalItemType01") || todayElement.hasClass("sapUiCalItemType02")) {
				todayElement.find(".dateLabel").text(todayElement.attr("title"));
			}

			const holidayElement = $("#" + this.getId() + "-shortCalendar--Month0").find(".sapUiCalItem.sapUiCalItemType01");
			const vacationElement = $("#" + this.getId() + "-shortCalendar--Month0").find(".sapUiCalItem.sapUiCalItemType02");

			if (holidayElement.has("span.dateLabel").length === 0) {
				holidayElement.append("<span class='dateLabel'>" + holidayElement.attr("title") + "</span>");
			}
			if (vacationElement.has("span.dateLabel").length === 0) {
				vacationElement.append("<span class='dateLabel'>" + vacationElement.attr("title") + "</span>");
			}
		}, 1000);

	}

	_setCalendarWeekText(startDate) {
		var currentStartDateOfWeek = DateService.getInstance().getStartDateOfWeek(new Date());
		if (currentStartDateOfWeek.getFullYear() === startDate.getFullYear() &&
			currentStartDateOfWeek.getMonth() === startDate.getMonth() &&
			currentStartDateOfWeek.getDate() === startDate.getDate()) {
			that.getAggregation("_navCalendar").getAggregation("items")[1].getAggregation("items")[0].setText("CURRENT WEEK");
		} else {
			var weekNumber = DateService.getInstance().getWeek(startDate);
			that.getAggregation("_navCalendar").getAggregation("items")[1].getAggregation("items")[0].setText("WEEK" + " " + weekNumber);
		}
	}
	adjustDateForDST(date = new Date()) {

		const year = date.getFullYear();
		// Get the offsets for January (non-DST in most regions) and July (DST in most regions)
		const janOffset = new Date(year, 0, 1).getTimezoneOffset(); // January 1st
		const julOffset = new Date(year, 6, 1).getTimezoneOffset(); // July 1st

		// Determine the larger offset (standard time) and the smaller offset (DST time)
		const standardOffset = Math.max(janOffset, julOffset);
		const dstOffset = Math.min(janOffset, julOffset);

		// Current offset
		//const currentOffset = date.getTimezoneOffset();
		// Adjust the date if DST is active
		//if (currentOffset === dstOffset) {
		// DST is active, adjust time to standard offset
		const adjustment = (standardOffset - dstOffset) * 60000; // in milliseconds
		return new Date(date.getTime() + adjustment); // Adjusted to standard time
		//}

		// If not in DST, return the original date
		//	return date;
	}



}
class MatrixCalendarController extends Controller {
	constructor(control) {
		super();
		this.control = control;
		this.TimeState = TimeState.getInstance();
		// this.masterDataState = MasterDataState.getInstance();
	}
	onInit() {
		this.setBusy(false);
	}

	_selectWeek(startDate, calendar) {
		var endDate = new Date(startDate.getTime() + (6 * 24 * 60 * 60 * 1000));
		calendar.removeAllSelectedDates();

		calendar.addSelectedDate(new DateRange({
			startDate: startDate,
			endDate: endDate
		}));
		calendar.focusDate(startDate);
	}

	onSelect(oEvent) {
		debugger;
		const core = sap.ui.getCore();
		const oSource = oEvent.getSource();
		var oCalendar = oSource.getAggregation("_calendar");
		const dDate = oEvent.getParameter("selectionStartDate");
		const dMatrixSelectedStartDate = this.control._getStartDateOfWeek();
		let dFirstDate = null;
		if (dDate) {
			dFirstDate = this.control._getFirstDayOfWeek(dDate);
		}
		if (dFirstDate && dMatrixSelectedStartDate !== dFirstDate) {
			oSource.setStartDate(DateService.getInstance().format(dFirstDate, "EEEE, MMMM dd,y"));
			this.control._onWeekChange(dFirstDate);
			this._selectWeek(dFirstDate, oCalendar);
		}
		setTimeout(function () {
			core._pMelodyDatePickerPopover.close();
		}, 100);
	}


}
