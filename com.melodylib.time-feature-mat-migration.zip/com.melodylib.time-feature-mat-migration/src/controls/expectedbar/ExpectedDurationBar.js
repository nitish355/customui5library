/*!
 * ${copyright}
 */
import jQuery from "jquery.sap.global";
import Calendar from "sap/ui/unified/Calendar";
import CalendarDateInterval from "sap/ui/unified/CalendarDateInterval";
import DateService from "com/melodylib/time/service/DateService";
import DateRange from "sap/ui/unified/DateRange";
import Control from "sap/ui/core/Control";
import Controller from "sap/ui/core/mvc/Controller";
import ResourceBundle from "sap/base/i18n/ResourceBundle";
import ResourceModel from "sap/ui/model/resource/ResourceModel";
import JSONModel from "sap/ui/model/json/JSONModel";
import ExpectedDurationBarRenderer from "./ExpectedDurationBarRenderer";
import TimeState from "com/melodylib/time/state/TimeState";
import TimeModels from "com/melodylib/time/model/TimeModels";


/**
 * Constructor for a new <code>com.melodylib.time.controls.ExpectedDurationBar</code> control.
 *
 * Some class description goes here.
 * @extends Control
 *
 * @author Siddharth Sagvekar
 * @version ${version}
 *
 * @constructor
 * @public
 * @name com.melodylib.time.controls.ExpectedDurationBar
 */
export default class ExpectedDurationBar extends Control {
    static metadata = {
        library: "com.melodylib.time",
        properties: {
            /**
             * width
             */
            width: {
                type: "sap.ui.core.CSSSize",
                defaultValue: "100%"
            },

            /**
             * height
             */
            height: {
                type: "sap.ui.core.CSSSize",
                defaultValue: "auto"
            },

            /**
             * height
             */
            expected: {
                defaultValue: 0
            },

            /**
             * height
             */
            submitted: {
                defaultValue: 0
            },

            /**
             * height
             */
            saved: {
                defaultValue: 0
            },

            /**
             * unit
             */
            unit: {
                type: "string",
                defaultValue: "H"
            }
        },
        events: {
            /**
             * Event is fired when the user clicks on the control.
             */
            press: {}

        },

        aggregations: {
            _statusIndicator: {
                type: "sap.m.HBox",
                multiple: false,
                visibility: "hidden"
            }
        }
    };
    static renderer = ExpectedDurationBarRenderer;

    init() {
        //initialisation code, in this case, ensure css is imported
        let styleSheet = sap.ui.require.toUrl("com/melodylib/time/css/activityProgressBar.css");
        jQuery.sap.includeStyleSheet(styleSheet);
        const oSettingsModel = TimeModels.getMTRSettingsModel();
        const sTimeMatrics = oSettingsModel.getProperty("/TimeMatrics");
        const sExpectedLbl = (sTimeMatrics && sTimeMatrics === "D") ? "Capacity Days" : "Capacity Hrs";
        this.setAggregation("_statusIndicator", new sap.m.HBox({
            fitContainer: true,
            alignItems: "Stretch",

            items: [
                new sap.m.VBox({
                    alignItems: "Center",
                    fitContainer: true,
                    items: [
                        new sap.m.Text({
                            text: sExpectedLbl
                        }).addStyleClass("expectedHrsLbl"),
                        new sap.m.Text({
                            text: this.getExpected()
                        }).addStyleClass("extectedHrsVal")
                    ]
                }).addStyleClass("expectedHrsContainer")
                    .setLayoutData(new sap.m.FlexItemData({
                        growFactor: 3
                    })),
                new sap.m.VBox({
                    fitContainer: true,
                    items: [
                        new sap.m.HBox({
                            alignItems: "Center",
                            justifyContent: "Start",
                            items: [
                                new sap.m.Text({
                                    text: "{i18n>expectedBarSubmittedLbl}"
                                }).addStyleClass("statusIndicatorLegend legendSubmitted"),
                                new sap.m.Text({
                                    text: "{i18n>expectedBarSavedLbl}"
                                }).addStyleClass("statusIndicatorLegend legendSaved"),
                                new sap.m.Text({
                                    text: "Available"
                                }).addStyleClass("statusIndicatorLegend legendMissing")
                            ]
                        }).addStyleClass("statusIndicatorLegendBox"),
                        new sap.m.HBox({
                            alignItems: "Center",
                            justifyContent: "Center",
                            items: [
                                new sap.m.Text(this.getId() + "-submitted", {
                                    text: this.getSubmitted()
                                }).addStyleClass("submittedStatusIndicator")
                                    .setLayoutData(new sap.m.FlexItemData({
                                        growFactor: 2
                                    })),
                                new sap.m.Text(this.getId() + "-saved", {
                                    text: this.getSaved()
                                }).addStyleClass("savedStatusIndicator")
                                    .setLayoutData(new sap.m.FlexItemData({
                                        growFactor: 2
                                    })),
                                new sap.m.Text(this.getId() + "-missing", {
                                    text: "0"
                                }).addStyleClass("missingStatusIndicator")
                                    .setLayoutData(new sap.m.FlexItemData({
                                        growFactor: 8
                                    }))
                            ]
                        }).addStyleClass("statusIndicatorValue")
                    ]
                }).addStyleClass("statusIndicatorContainer")
                    .setLayoutData(new sap.m.FlexItemData({
                        growFactor: 9
                    }))
            ]
        }).addStyleClass("statusBar"));
    }
    onAfterRendering() {
        this._setMissing();
    }
    _setMissing() {
        var expected = parseFloat(this.getExpected());
        var saved = parseFloat(this.getSaved());
        var submitted = parseFloat(this.getSubmitted());
        var total = submitted + saved;
        var missing = expected - submitted - saved;

        if (total < expected) {
            total = expected;
        } else {
            missing = 0;
        }
        var submittedPercent = (submitted !== 0) ? (submitted / total) * 100 : 0;
        var savedPercent = (saved !== 0) ? (saved / total) * 100 : 0;
        var missingPercent = (missing !== 0) ? (100 - submittedPercent - savedPercent) : 0;

        jQuery.sap.byId(this.getId() + "-submitted").parent().css({ "width": submittedPercent + "%", "min-width": ((submittedPercent <= 0) ? "0px" : "45px"), "display": ((submittedPercent <= 0) ? "none" : "block") });
        jQuery.sap.byId(this.getId() + "-saved").parent().css({ "width": savedPercent + "%", "min-width": ((savedPercent <= 0) ? "0px" : "45px"), "display": ((savedPercent <= 0) ? "none" : "block") });
        jQuery.sap.byId(this.getId() + "-missing").parent().css({ "width": missingPercent + "%", "min-width": ((missingPercent <= 0) ? "0px" : "45px"), "display": ((missingPercent <= 0) ? "none" : "block") });

        if (typeof (missing) === "number") {
            var counts = this.countDecimal(missing);
            if (counts > 0) {
                missing = missing.toFixed(1);
            }
        } else {
            missing = 0;
        }
        this.getAggregation("_statusIndicator").getAggregation("items")[1].getAggregation("items")[1].getAggregation("items")[2].setText(missing);

    }
    countDecimal(value) {
        if (isNaN(value) || Math.floor(value) === value) return 0;
        return value.toString().split(".")[1].length || 0;
    }

    setUnit(sValue) {
        var oResourceBundle = this.getModel("i18n").getResourceBundle();
        this.setProperty("unit", sValue);
        var sUnit = (sValue === "H") ? oResourceBundle.getText("expectedBarHoursUnit") : oResourceBundle.getText("expectedBarDaysUnit");
        this.getAggregation("_statusIndicator").getAggregation("items")[0].getAggregation("items")[0].setText(oResourceBundle.getText("capacityexpectedBarLbl") + " " + sUnit);
    }

    _getUnitName() {
        return (this.getUnit() === "H") ? "hrs" : "days";
    }

    setExpected(fValue) {
        this.setProperty("expected", fValue);
        var expected = parseFloat(fValue);
        let timeMatrix = this.getUnit();
        if (timeMatrix === "H") {
            expected = isNaN(expected) ? 8 : expected;
        } else if (timeMatrix === "D") {
            expected = isNaN(expected) ? 1 : expected;
        } else {
            expected = 0;
        }
        if (typeof (expected) === "number") {
            var counts = this.countDecimal(expected);
            if (counts > 0) {
                expected = expected.toFixed(1);
            }
        } else {
            expected = 0;
        }
        this.getAggregation("_statusIndicator").getAggregation("items")[0].getAggregation("items")[1].setText(expected);
    }
    setSubmitted(fValue) {
        this.setProperty("submitted", fValue);
        var submitted = parseFloat(fValue);
        if (typeof (submitted) === "number") {
            var counts = this.countDecimal(submitted);
            if (counts > 0) {
                submitted = submitted.toFixed(1);
            }
        } else {
            submitted = 0;
        }
        this._setMissing();
        this.getAggregation("_statusIndicator").getAggregation("items")[1].getAggregation("items")[1].getAggregation("items")[0].setText(submitted + " (G)");
    }

    setSaved(fValue) {
        this.setProperty("saved", fValue);
        var saved = parseFloat(fValue);
        if (typeof (saved) === "number") {
            var counts = this.countDecimal(saved);
            if (counts > 0) {
                saved = saved.toFixed(1);
            }
        } else {
            saved = 0;
        }
        this._setMissing();
        this.getAggregation("_statusIndicator").getAggregation("items")[1].getAggregation("items")[1].getAggregation("items")[1].setText(saved);
    }
}
class ExpectedDurationBarController extends Controller {
    constructor(control) {
        super();
        this.control = control;
        this.TimeState = TimeState.getInstance();
        // this.masterDataState = MasterDataState.getInstance();
    }
    onInit() {
        this.setBusy(false);
    }


}
