import CoreService from "com/melodylib/core/service/CoreService";
import Filter from "sap/ui/model/Filter";

/**
 * @name com.melodylib.time.service.TimeService
 */
export default class TimeService extends CoreService {
    constructor() {
        super();
    }
    static getInstance() {
        if (!this.instance) {
            this.instance = new TimeService();
        }
        return this.instance;
    }

    async getTimeMasterData(profile) {
        const projectType = "ACTVT";
        const parameters = {
            urlParameters: "$expand=to_Activity,to_Category,to_Location,to_CostType,to_Status,to_ActivityCostTypeMap,to_ActivityLocationMap"
        };
        const result = await this.odata("/YC_TRM_Lookup(project_type='" + projectType +
            "',product_id=1,profile_id=" + parseInt(profile, 10) + ")").get("mtr", parameters);
        return result.data;
    }

    async getUserSettings(userGuid) {
        const parameters = {
            urlParameters: "$expand=to_OPPORTUNITYIO,to_MANUAL,to_ACCOUNT"
        };
        const result = await this.odata("/YC_TRMSETTINGS('" + userGuid + "')").get("mtr", parameters);
        return result.data;
    }

    async getSettingsLookups() {
        const result = await this.odata("/YC_TRM_DOMAIN_HELP").get("mtr");
        return result.data.results;
    }

    async getUserMtrConfig(postData) {
        return this.odata("/YC_Get_UserGuidSet").post("mtr", postData);
    }


    async getEntriesFromISP(personalNumber, fromDate, toDate) {
        const url = "/Param(Pernr='" + personalNumber + "',Datefrom='" + fromDate + "',Dateto='" + toDate + "')/Activity";
        return await this.odata(url).get("isp");
    }


    async getEntries(guid) {
        const filters = [
            new Filter("UserGuid", "EQ", guid)
        ];
        const params = {};
        params.filters = (filters) ? filters : "";
        return await this.odata("/YC_TimeSheetEntrySet").get("mtr", params);
    }

    async saveEntries(postData) {
        return this.odata("/YC_TimesheetSet").post("mtr", postData);
    }

    async getTasksByActivity(params) {
        const options = this.getUrlParameters(params);
        return this.odata("/YC_MTR_M_INTG_MAP").get("mtr", options);
    }
    async getActStatusMasterData() {
        const oResult = await this.odata("/YC_TRM_M_ACT_STATUS").get("mtr");
        return oResult.data.results;
    }
    async saveDefaultFilter(oData) {
        return this.odata("/YC_UT_EXSTNG_ACT_VARIANT").post("utility", oData);
    }
    async getDefaultFilter() {
        return this.odata("/YC_UT_EXSTNG_ACT_VARIANT").get("utility");
    }
    async getMatrixTimeEntryActivitites(aFilters = [], search, skip, top, ServiceCallCount) {
        const urlParameters = {};
        const mParameters = {
            filters: aFilters
        };
        if (ServiceCallCount && ServiceCallCount !== 1) { // service call is first service call when opening dialog box, click on go in filter and restor
            urlParameters.$skip = skip;
            if (top) {
                urlParameters.$top = top.toString();
            } else {
                urlParameters.$top = "50";
            }
        }
        /*if (search) {
            urlParameters.search = search;
        }*/
        mParameters.urlParameters = urlParameters;
        const oResult = await this.odata("/yc_mtr_t_actvt").get("mtr", mParameters);
        return oResult.data.results;
    }


}