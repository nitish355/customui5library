import CoreService from "com/melodylib/core/service/CoreService";
import Object from "sap/ui/base/Object";

/**
 * @name com.melodylib.integration.service.DateService
 */
export default class DateService extends CoreService {
    constructor() {
        super();

    }
    static getInstance() {
        if (!this.instance) {
            this.instance = new DateService();
        }
        return this.instance;
    }
    //function to format date
    format(dDate, sFormat) {
        if (!sFormat || sFormat === "") {
            sFormat = "MMM dd, y";
        }
        sFormat = sFormat.replace(/D/g, "d");
        sFormat = sFormat.replace(/Y/g, "y");
        var oFormat = sap.ui.core.format.DateFormat.getInstance({
            pattern: sFormat,
            calendarType: sap.ui.core.CalendarType.Gregorian
        });
        return oFormat.format(dDate);
    }

    formatStringDate(sDate, sFormat) {
			if (!sDate) {
				return "";
			}
			var dDate = new Date(sDate.substring(0, 4) + "/" + sDate.substring(4, 6) + "/" + sDate.substring(6, 8));
			if (sFormat && sFormat !== "") {
				return this.format(dDate, sFormat);
			} else {
				return dDate;
			}

		}
}