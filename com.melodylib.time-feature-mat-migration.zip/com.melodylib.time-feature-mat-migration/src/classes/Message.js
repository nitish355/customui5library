import Object from "sap/ui/base/Object";
import MTRModels from "com/melodylib/time/model/TimeModels";

/**
 * @namespace com.melodylib.time.classes.Message
 */
export default class Message extends Object {
    constructor(data) {
        super()
        this.messages = this.messages ? this.messages :[];
        this.setData(data);

    }
    setData(data) {
        if(!data) {
            data = {};
        }
        this.type = data.Type || "";
        this.title = data.Title || "";
        this.description = data.Description || "";
        this.subtitle = data.Subtitle || "";
    }
    addToMessages(guid, activityId, statusId) {
        var oMessageModel = MTRModels.getMessagesModel();
        if (statusId) {
            statusId = statusId;
        } else if (!statusId && this.type === sap.ui.core.MessageType.Error) {
            statusId = "3";
        }

        const message = {
            type: this.type,
            title: this.title,
            subtitle: this.subtitle,
            description: this.description,
            guid: guid,
            activityId: activityId,
            statusId: statusId,
            bLink: (statusId) ? true : false
        };
        if (message.title || (message.activityId && message.title)) {
            //this.messages.unshift(message);
            oMessageModel.getData().unshift(message);
				oMessageModel.refresh(true);
        }
    }
}

