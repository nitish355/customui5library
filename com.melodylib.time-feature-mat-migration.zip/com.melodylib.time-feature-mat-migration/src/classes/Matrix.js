import Filter from "sap/ui/model/Filter";
import MessageToast from "sap/m/MessageToast";
import Actions from "com/melodylib/time/enum/Actions";
import ActivityUtil from "com/melodylib/activity/util/ActivityUtil";
import StorageModel from "com/melodylib/time/model/StorageModel";
import MTRModels from "com/melodylib/time/model/TimeModels";
import MTRHelper from "com/melodylib/time/controls/calendar/day/Day";
import Message from "com/melodylib/time/classes/Message";
import DateService from "com/melodylib/core/service/DateService";
import BaseEntry from "com/melodylib/time/classes/BaseEntry";
import ActivityService from "com/melodylib/activity/service/ActivityService";
import OpportunityService from "com/melodylib/integration/service/OpportunityService";
import OpportunityUtil from "com/melodylib/integration/util/opportunity/OpportunityUtil";
import OpportunityState from "com/melodylib/integration/state/OpportunityState";
import TimeState from "com/melodylib/time/state/TimeState";
import AccountState from "com/melodylib/integration/state/AccountState";

/**
 * @namespace com.melodylib.time.classes.Matrix
 */

export default class Matrix extends BaseEntry {
	constructor(data = {}){
		super(this);
		this.ActvtId = ("ActvtId" in data) ? data.ActvtId : "";
			this.isMatrixEditable = true;
			this.isValidForCheck = true;
			this.selectedAssociationId = ("associationId" in data) ? data.associationId : "";
			this.selectedAssociationValue = ("CostTypeValue" in data) ? data.CostTypeValue : "";
			this.ActAsstId = ("associationId" in data) ? data.associationId : "";
			this.CostTypeId = ("CostTypeId" in data) ? data.CostTypeId : ("costType" in data) ? data.costType.id :"";
			this.CostTypeValue = ("CostTypeValue" in data) ? data.CostTypeValue :("costType" in data) ? data.costType.value :"";
			this.selectedRegion = ("selectedRegion" in data) ? data.selectedRegion : "";
			this.selectedMarketUnit = ("selectedMarketUnit" in data) ? data.selectedMarketUnit : "";
			this.selectedActivityType = ("ActivityTypeId" in data) ? data.ActivityTypeId : "";
			this.ActTypes = ("ActTypes" in data) ? data.ActTypes : "";
			this.ActTypeDesc = ("ActTypeDesc" in data) ? data.ActTypeDesc : "";
			this.activityMode = ("ActvtId" in data && data.ActvtId) ? Actions.ActivityMode.existingActivity : Actions.ActivityMode.newActivity;
			this.StatusId = ("StatusId" in data) ? data.StatusId : "";
			this.LocationId = ("LocationId" in data) ? data.LocationId : "";
			this.IsLegacy = ("IsLegacy" in data) ? data.IsLegacy : "";
			this.AddCategoryId = ("AddCategoryId" in data) ? data.AddCategoryId : "";
			this.TaskName = ("TaskName" in data) ? data.TaskName : "";
			this.IsOthers = ("IsOthers" in data) ? data.IsOthers : false;
			this.IsRecntSelect = ("IsRecntSelect" in data && data.IsRecntSelect.toUpperCase() === "X") ? data.IsRecntSelect : "";
			this.activityRegistration = {};
			this.activityDescription = "";
			this.defaultMenuKey = "1";
			this.CostTypeName = ("CostTypeName" in data) ? data.CostTypeName : "";
			this.selectedCostType = "";
			this.OpportunityID = ("OpportunityID" in data) ? data.OpportunityID : "";
			this.OpportunityName = ("OpportunityName" in data) ? data.OpportunityName : "";
			this.AccountID = ("AccountID" in data) ? data.AccountID : "";
			this.AccountName = ("AccountName" in data) ? data.AccountName : "";
			this.Unit = ("Unit" in data) ? data.Unit : "H";
			this.isVisibleInMatrix = ("isVisibleInMatrix" in data) ? data.isVisibleInMatrix : true;
			this.isNonMatEntry = ("isNonMatEntry" in data) ? data.isNonMatEntry : false;
			this.MatrixDateRange = {
				fromDate: "",
				toDate: ""
			};
			
			this.TaskId = ("TaskId" in data) ? data.TaskId : ("task" in data) ? data.task.taskId : "10";
			this.ActTypesData = [];
			this.customFacing = {};
			this.nonCustomFacing = {};
			this.visible = {
				deleteicon: false,
				addTimeIcon: false,
				msgStrip: false,
				addRow: true,
				registerBtn: true,
			};
			this.selectedCategory = ("selectedCategory" in data && data.selectedCategory) ? data.selectedCategory : "activity"
			this.busy = {
				listItem: true,
				registrationBtn: true,
				marketUnit: true,
				activityInfo: false
			};
			this.isCustomerFacingEnabled = true;
			if (this.ActvtId) {
				this.updateActivityRegistration();
			} else {
				this.busy.registrationBtn = false;
				this.busy.listItem = false;
				this.busy.marketUnit = false;
				//Activity Data is available, Avoid Resetting
				if (!("ActivityId" in this.activityRegistration) || !this.activityRegistration.ActivityId) {
					this.setActivityRegistration();
				}
			}

			//Learning and Others: Special Project
			if (this.TaskId === "11") {
				this.setCostObjectItems();
			}
	}
	//Edit OR Update Activity
	async updateActivityRegistration(){
		if ("ActivityId" in this.activityRegistration && this.activityRegistration.ActivityId) {
				return;
			}
			if (this.ActvtId) {
				let aActIdFilter = [];
				 aActIdFilter = [new Filter("ActivityId", "EQ", this.ActvtId)];
				  let mParameters = {
								 filters: (aActIdFilter.length) ? aActIdFilter : [],
								 urlParameters: {
									 $select: Actions.ActivitySet.select
								 }
							 };
				ActivityService.getInstance().getActivityList(mParameters,null).then((oActvt) => {
					let ActivityData = oActvt.data.results;
					if (!ActivityData.length) {
						this.busy.listItem = false;
						return;
					}
					const oActivity = ActivityData[0];
					this.activityRegistration = Object.assign(this.activityRegistration, oActivity);
					this.setActivityMatrixValues(oActivity);
					this.busy.registrationBtn = false;
					this.setCostObjectItems();
					this.refreshData();
				});
			}
	}
	//Create Activity
		setActivityRegistration(userData = {}, noAssociationData = {}, activityType = {}) {
			let existingData = $.extend(true, {}, this.activityRegistration);
			this.activityRegistration = {
				"ActivityId": "",
				"ActivityGUID": "",
				"ActivityLead": ("UserId" in userData) ? userData.UserId : "",
				"ActivityLeadName": ("UserName" in userData) ? userData.UserName : "",
				"ActivityLeadEmailId": ("UserEmail" in userData) ? userData.UserEmail : "",
				"ActivitySetId": ("ActivitySetId" in noAssociationData) ? noAssociationData.ActivitySetId : ("ActivitySetId" in
					existingData) ? existingData.ActivitySetId : "",
				"ActivitySetStatus": "",
				"ActivitySetdescription": ("Description" in noAssociationData) ? noAssociationData.Description : ("ActivitySetdescription" in
					existingData) ? existingData.ActivitySetdescription : "",
				"ActivityTypeDescription": ("ActvtTypeDesc" in activityType) ? activityType.ActvtTypeDesc : "",
				"ActivityTypeId": ("ActvtTypeID" in activityType) ? activityType.ActvtTypeID : "",
				"Authorized": "",
				"ActvtAsstdID": ("ActvtAsstdID" in activityType) ? activityType.ActvtAsstdID : "",
				"ChildFrmLayoutId": ("ChildFrmLayoutId" in activityType) ? activityType.ChildFrmLayoutId : "",
				"CreateDate": new Date(),
				"FormLayoutId": ("FormLayoutID" in activityType) ? activityType.FormLayoutID : "",
				"OpportunityNumber": "", //Opportunity & Account Based
				"OpportunityId": "", //Opportunity & Account Based
				"GlobalUltimateID": "", //Opportunity & Account Based
				"MuId": "",
				"MuDesc": "",
				"Region": ("Region" in noAssociationData) ? noAssociationData.Region : "",
				"SubRegion": ("SubRegion" in noAssociationData) ? noAssociationData.SubRegion : "",
				"IndustryDesc": ("IndustryDesc" in noAssociationData) ? noAssociationData.IndustryDesc : "",
				"Requestor": ("UserId" in userData) ? userData.UserId : "",
				"RequestorName": ("UserName" in userData) ? userData.UserName : "",
				"RoleMpngID": ("RoleMpngID" in activityType) ? activityType.RoleMpngID : "",
				"StartDate": new Date(),
				"EndDate": new Date(),
				"to_AAccnt": ("to_AAccnt" in existingData && existingData.to_AAccnt.length) ? existingData
					.to_AAccnt : [],
				"to_AOpportunity": ("to_AOpportunity" in existingData && existingData.to_AOpportunity.length) ? existingData
					.to_AOpportunity : [],
			};
		}
	//function to set values to the activity fields in the martix list(Association, Activity Mode Menu, ActivityType)
		setActivityMatrixValues(data = {}) {
			this.defaultMenuKey = ("ActivityId" in data && data.ActivityId) ? "2" : "1";
			this.ActvtId = ("ActivityId" in data && data.ActivityId) ? parseInt(data.ActivityId).toString() : "";
			this.activityDescription = ("ActTypeDesc" in data && "ActivityId" in data) ?
				`${data.ActTypeDesc}-${this.ActvtId}` : "";
			this.activityMode = ("ActivityId" in data && data.ActivityId) ? Actions.ActivityMode.existingActivity : Actions.ActivityMode.newActivity;
			this.selectedActivityType = ("ActivityTypeId" in data && data.ActivityTypeId) ? data.ActivityTypeId : "";
			this.setAssociationType(data);
			this.setCostTypeData(this.CostTypeId, data);

			//Update Delete icons
			if (this.ActvtId) {
				this.visible.deleteicon = true;
			}

			//Check for MTR taskType
			this.checkForMTRTasks();
		}	
//Function to set Association Type (Only)
		setAssociationType(activityData) {
			this.ActAsstId = activityData.ActAsstId;
			switch (this.ActAsstId) {
			case "501": //Account
				this.selectedAssociationId = "4";
				if (!this.CostTypeId) {
					this.CostTypeId = "4";
				}
				break;
			case "502": //Opportunity
				this.selectedAssociationId = "1";
				if (!this.CostTypeId) {
					this.CostTypeId = "1";
				}
				break;
			case "503": //No Association
				this.selectedAssociationId = "2";
				if (!this.CostTypeId) {
					this.CostTypeId = "2";
				}
				break;
			default:
				this.selectedAssociationId = "";
				// this.ActAsstId = "";
				// this.CostTypeId = "";
			}
			this.selectedCostType = this.CostTypeId;
		}
		//Update costTypeValue Based on costTypeID and also registred activity's ActvtAsstdID 
		setCostTypeData(costTypeId, activityData) {
			const settingsModel = MTRModels.getMTRSettingsModel();
			let costCenter = settingsModel.getProperty("/CostCenter");
			this.selectedActivityType = activityData.ActivityTypeId;
			let opportunityId = ("OpportunityId" in activityData && activityData.OpportunityId) ? activityData.OpportunityId :
				"";
			let accountId = ("GlobalUltimateID" in activityData && activityData.GlobalUltimateID) ? activityData.GlobalUltimateID :
				"";
			switch (costTypeId) {
			case "1": //Opportunity
				this.CostTypeValue = opportunityId;
				this.selectedAstOpportunityValue = opportunityId;
				this.setCostTypeName(activityData);
				break;
			case "4": //Account
				this.CostTypeValue = accountId;
				this.selectedAstAccountValue = accountId;
				this.setCostTypeName(activityData);
				break;
			case "2": //No Association
				break;
			case "3": //Manual IO
				if (this.ActAsstId === "501") { //Account
					this.selectedAstAccountValue = accountId;
				}
				if (this.ActAsstId === "502") { // Opportunity
					this.selectedAstOpportunityValue = opportunityId;
				}
				this.setCostTypeName(activityData);
				break;
			default:
			}
		}
		async setCostTypeName () {
			const oMtrSettingsModel = MTRModels.getMTRSettingsModel();
			if (this.CostTypeId === "1" || this.ActAsstId === "502") {
				//const aOpportunities = oMtrSettingsModel.getProperty("/Opportunities");
				const aOpportunities = OpportunityState.getInstance().getData().opportunities;
				const aNONVatOppData = oMtrSettingsModel.getProperty("/aNONVatOppData") || [];
				let oSelectedOppDataForNonVat = StorageModel.getProperty("/oSelectedOppDataForNonVat") || {};
				let oOpportunity = aOpportunities.find(item => item.id === this.selectedAstOpportunityValue);
				if (oOpportunity) {
					this.OpportunityID = this.selectedAstOpportunityValue;
					this.OpportunityName = oOpportunity.OpportunityName ?? oOpportunity.description ?? '';
					this.AccountID = oOpportunity.AccountID
						?? oOpportunity.account?.id
						?? '';

					this.AccountName = oOpportunity.AccountName
						?? oOpportunity.account?.name
						?? '';
					
					this.CostTypeName = oOpportunity.OpportunityName ?? oOpportunity.description ?? '';;
				} else {
					let sOpportunityName = "";
					//If CostType Value is of NON-VAT
					oOpportunity = aNONVatOppData.find(item => item.OpportunityId === this.selectedAstOpportunityValue) || false;

					//if opp data is not found
					if (!oOpportunity && oSelectedOppDataForNonVat && Object.values(oSelectedOppDataForNonVat).length) {
						oOpportunity = (this.selectedAstOpportunityValue === oSelectedOppDataForNonVat.OpportunityId) ? oSelectedOppDataForNonVat :
							false;
					}

					if (oOpportunity && "OpportunityName" in oOpportunity) {
						sOpportunityName = oOpportunity.OpportunityName;
					}

					if (oOpportunity) {
						this.OpportunityID = this.selectedAstOpportunityValue;
						this.OpportunityName = sOpportunityName;
						this.AccountID = oOpportunity.AccountId;
						this.AccountName = oOpportunity.AccountName;
						this.CostTypeName = oOpportunity.OpportunityName;
					} else {
						//Worst-case if still opp data is not found;
						if (this.selectedAstOpportunityValue) {
							let aFilters = [];
							aFilters.push(new Filter({
								path: "OPPT_ID",
								operator: sap.ui.model.FilterOperator.Contains,
								value1: this.selectedAstOpportunityValue
							}));
							let aSearchFilter = new Filter({
								filters: aFilters,
								and: true
							});
							let mParameters = {
								filters: aSearchFilter,
							};
							let aResponse = await OpportunityUtil.getInstance().fnSetFormatParamsForNonVATOppData(mParameters);
							if (aResponse && aResponse instanceof Array && aResponse.length) {
								oOpportunity = aResponse[0];
							}

							this.OpportunityID = this.selectedAstOpportunityValue;
							this.OpportunityName = (oOpportunity && oOpportunity.hasOwnProperty("OpportunityName")) ? oOpportunity.OpportunityName :
								"Not Applicable";
							this.AccountID = (oOpportunity && oOpportunity.hasOwnProperty("AccountId")) ? oOpportunity.AccountId : "Not Applicable";
							this.AccountName = (oOpportunity && oOpportunity.hasOwnProperty("AccountName")) ? oOpportunity.AccountName : "Not Applicable";
							this.CostTypeName = (oOpportunity && oOpportunity.hasOwnProperty("OpportunityName")) ? oOpportunity.OpportunityName :
								"Not Applicable";

						} else {
							this.OpportunityID = this.selectedAstOpportunityValue;
							this.OpportunityName = "Not Applicable";
							this.AccountID = "Not Applicable";
							this.AccountName = "Not Applicable";
							this.CostTypeName = "Not Applicable";
						}
					}
				}
			} else if (this.CostTypeId === "4" || this.ActAsstId === "501") {
				//const aAccounts = oMtrSettingsModel.getProperty("/to_ACCOUNT")
				const aAccounts = AccountState.getInstance().getData().accounts;
				const oAccount = aAccounts.find(item => item.id === this.selectedAstAccountValue);
				if (oAccount) {
					this.CostTypeName = oAccount.AccountDesc ?? oAccount.name ?? "";
					this.OpportunityID = "";
					this.OpportunityName = "";
					this.AccountID = this.selectedAstAccountValue;
					this.AccountName = oAccount.AccountDesc ?? oAccount.name ?? "";
				} else {
					if (this.selectedAstAccountValue) {
						const oResponse = await OpportunityService.getBusinessPartnerAttribSet(this.selectedAstAccountValue);
						this.CostTypeName = (oResponse && oResponse.data) ? oResponse.data.PARTNER_NAME : "Not Applicable";
						this.OpportunityID = "";
						this.OpportunityName = "";
						this.AccountID = this.selectedAstAccountValue;
						this.AccountName = (oResponse && oResponse.data) ? oResponse.data.PARTNER_NAME : "Not Applicable";
					//	this.AccountID = activityData.GlobalUltimateID;
					
					
						// let matrixModel = MTRModels.getMatrixModel();
						// if (matrixModel) {
						// 	matrixModel.refresh(true);
						// }
					}
				}
			}
			let matrixModel = MTRModels.getMatrixModel();
						if (matrixModel) {
							matrixModel.refresh(true);
						}
		}

		//Function to set Learning Details
		fnSetLearningConfig() {
			this.fnSetTaskIds();
			//Set Delete icon visible
			if (this.TaskId && this.CostTypeId && this.CostTypeValue) {
				this.visible.deleteicon = true;
			}
		}
		//Function to set TaskIds
		fnSetTaskIds() {
			let matrixModel = MTRModels.getMatrixModel();
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			let bEssInMu = oSettingsModel.getProperty("/UserNotifEssInMu");
			const aMTRTasks = oSettingsModel.getProperty("/MTRTasks") || [];
			let aTasks = aMTRTasks.filter(function (task) {
				return (bEssInMu && !task.essInMu) || !bEssInMu;
			});
			let aFilteredTask = aTasks.filter((task) => {
				return task.addCategoryId === "5"
			});
			this.MTRTasksByEssInMu = aFilteredTask;
		}
		//function to check and update the payload for "CREATE" but from both (New and Exisiting Activity data)
		checkAndUpdateActvtPayload (activityRegistration) {
			for (let property in activityRegistration) {
				if (property in this.activityRegistration) {
					this.activityRegistration[property] = activityRegistration[property];
					//based on the keys, change data when required to save an activity from an existing activity data
					if (property === "ActvtAsstdID" && this.selectedAssociationId) {
						switch (this.selectedAssociationId) {
						case "4": //Account
							this.activityRegistration[property] = "501";
							break;
						case "1": //Opportunity
							this.activityRegistration[property] = "502";
							break;
						case "2": //No Association
							this.activityRegistration[property] = "503";
							break;
						default:
							this.activityRegistration[property] = "";
						}
					}
				}
			}
		}
		//Function to handle only to use from the registration table to update the matrix list
		updateMatrixDataFromRegTable(activityRegistration) {
			let ActvtAsstdID;
			this.defaultMenuKey = "2";
			this.ActvtId = parseInt(activityRegistration.ActivityId).toString();
			this.activityDescription = `${activityRegistration.ActTypeDesc}-${parseInt(activityRegistration.ActivityId)}`;
			this.ActTypeDesc = JSON.parse(JSON.stringify(activityRegistration.ActTypeDesc));
			this.selectedActivityType = activityRegistration.ActivityTypeId;
			this.activityMode = (this.ActvtId) ? Actions.ActivityMode.existingActivity : Actions.ActivityMode.newActivity;

			// activityRegistration Level
			this.activityRegistration.ActivityTypeId = activityRegistration.ActivityTypeId;
			this.activityRegistration.ActivityId = parseInt(activityRegistration.ActivityId).toString();
			this.activityRegistration.ActivityTypeDescription = activityRegistration.ActTypeDesc;
			this.activityRegistration.OpportunityNumber = activityRegistration.OpportunityId;
			this.activityRegistration.OpportunityId = activityRegistration.OpportunityId;
			this.activityRegistration.StartDate = activityRegistration.StartDate;
			this.activityRegistration.EndDate = activityRegistration.EndDate;
			this.activityRegistration.ActivityLead = activityRegistration.ActivityLead;
			this.activityRegistration.ActivityLeadName = activityRegistration.ActLeadName;
			this.activityRegistration.ActivitySetId = activityRegistration.ActivitySetId;
			this.activityRegistration.ActivitySetdescription = activityRegistration.ActSetDesc;
			this.activityRegistration.ActvtAsstdID = activityRegistration.ActAsstId;
			ActvtAsstdID = activityRegistration.ActAsstId;
			this.activityRegistration.RoleMpngID = activityRegistration.RoleMpngId;
			this.activityRegistration.ActivityGUID = activityRegistration.activity_guid;
			this.activityRegistration.ActivityGuid = activityRegistration.activity_guid;
			this.activityRegistration.Region = activityRegistration.Region;
			this.activityRegistration.SubRegion = activityRegistration.SubRegion;

			switch (activityRegistration.ActAsstId) {
			case "502": //Opportunity
				this.activityRegistration.GlobalUltimateID = activityRegistration.AccountId
				break;
			case "501": // Account
				this.activityRegistration.OpportunityId = "";
				this.activityRegistration.OpportunityNumber = "";
				this.activityRegistration.GlobalUltimateID = activityRegistration.AccountId
				break;
			case "503": // No Association
				break;
			default:
			}
			this.activityRegistration = this.activityRegistration;
			this.setCostObjectItems(ActvtAsstdID);
			//Check for MTR taskType
			this.checkForMTRTasks(true, activityRegistration);
			this.validateRegisterBtn = Math.random();
			this.refreshData();
		}
		//Function to set CostType Object
		setCostObjectItems(ActAsstId = "") {
			if (this.CostTypeId) {
				const sActAsstId = (ActAsstId) ? ActAsstId : this.ActAsstId;
				const isEdit = this.isMatrixEditable;
				const aCostObject = [];

				switch (sActAsstId) {
				case "501": //Account
					if (this.CostTypeId === "4" || this.CostTypeId === "3") {
						aCostObject.push({
							key: "4",
							text: "Account"
						});
					}
					break;
				case "502": //Opportunity
					if (this.CostTypeId === "1" || this.CostTypeId === "3") {
						aCostObject.push({
							key: "1",
							text: "Opportunity"
						});
					}
					break;
				case "503": //No Association
					if (this.CostTypeId === "2" && sActAsstId === "503") {
						aCostObject.push({
							key: "2",
							text: "SAP Cost Center"
						});
					}
					break;
				default: //Learning & Others case
					aCostObject.push({
						key: "2",
						text: "SAP Cost Center"
					});
				}

				const oManualIO = {
					key: "3",
					text: "Manual IO"
				};
				aCostObject.push(oManualIO);
				this.CostObjectItems = aCostObject;
			}
		}
		//function to check entries
		checkIsEntriesAvailable() {
			let IsAvailable = false;
			const validCount = 7;
			let validCf = Object.values(this.customFacing) || [];
			validCf = validCf.filter((entry) => entry.duration.current);

			let validNCf = Object.values(this.nonCustomFacing) || [];
			validNCf = validNCf.filter((entry) => entry.duration.current);
			this.checkSubmittedEntries();
			if (validCf.length || validNCf.length) {
				IsAvailable = true;
			}
			return IsAvailable;
		}

		//Function to check for Submitted Entries
		checkSubmittedEntries() {
			this.visible.addRow = true;
			this.visible.addTimeIcon = false;
			this.IsSubmittedEntriesNotPresent = true;
			let validCf = Object.values(this.customFacing) || [];
			validCf = validCf.filter((entry) => {
				return entry.StatusId === "4";
			});

			let validNCf = Object.values(this.nonCustomFacing) || [];
			validNCf = validNCf.filter((entry) => {
				return entry.StatusId === "4";
			});
			if (validCf.length || validNCf.length) {
				this.IsSubmittedEntriesNotPresent = false;
				this.visible.addTimeIcon = true;
				this.visible.addRow = false;
			}
			this.refreshData();
		}

		//Function to validate matrix entry
		validate() {
			let valid = false;
			switch (this.selectedCategory) {
			case Actions.matrixCategory.learning:

				break;
			case Actions.matrixCategory.activity:
				if (this.selectedAssociationId && !this.CostTypeValue) {
					return false;
				}
				break;
			default:

			}
		}

		//Function to update the Entries data in CF/NCF
		updateFacingEntries(options = {
			addNotes: false,
			dateKey: "",
			customerFacing: ""
		}, isSingleEntry = false) {
			//Single
			if (isSingleEntry && options.dateKey) {
				if (options.customerFacing) {
					let oCfEntry = (this.customFacing[options.dateKey]) ? this.customFacing[options.dateKey] : false;
					if (oCfEntry) {
						this._fnHelpUpdateFacingData(oCfEntry, options, "CF");
						this.customFacing[options.dateKey] = oCfEntry
					}
				} else {
					let oNCfEntry = (this.nonCustomFacing[options.dateKey]) ? this.nonCustomFacing[options.dateKey] : false;
					if (oNCfEntry) {
						this._fnHelpUpdateFacingData(oNCfEntry, options, "NCF");
						this.nonCustomFacing[options.dateKey] = oNCfEntry
					}
				}
			} else {
				//Multiple
				let counter = 1;
				while (counter <= 7) {
					let dateKey = `Date${counter}`;
					let oCfEntry = (this.customFacing[dateKey]) ? this.customFacing[dateKey] : false;
					let oNCfEntry = (this.nonCustomFacing[dateKey]) ? this.nonCustomFacing[dateKey] : false;

					//Customer Facing
					if (oCfEntry) {
						oCfEntry = this._fnHelpUpdateFacingData(oCfEntry, options, "CF");
						this.customFacing[dateKey] = oCfEntry
					}

					//Non-Customer Facing
					if (oNCfEntry) {
						oNCfEntry = this._fnHelpUpdateFacingData(oNCfEntry, options, "NCF");
						this.nonCustomFacing[dateKey] = oNCfEntry
					}

					counter += 1;
				}
			}
			this.refreshData();
		}

		//Helper Function to update the Entries data in CF/NCF
		_fnHelpUpdateFacingData(oEntry, options = {}, type) {
			const settingsModel = MTRModels.getMTRSettingsModel();
			let costCenter = TimeState.getInstance().getUser().costCenter;

			switch (this.selectedCategory) {
			case Actions.matrixCategory.learning:
				oEntry.task.taskId = (this.TaskId) ? this.TaskId : "10";
				break;
			case "others":
				oEntry.TaskId = this.TaskId;
				break;
			case Actions.matrixCategory.activity:
				oEntry.ActvtId = this.ActvtId;
				oEntry.ActTypeDesc = this.ActTypeDesc;
				// oEntry.TaskId = (oEntry.ActvtId && oEntry.CustomerFacing) ? "3" : "4";
				break;
			default:

			}

			oEntry.costType.id = this.CostTypeId;
			oEntry.costType.value = (oEntry.CostTypeId === "2" && !this.CostTypeValue) ? costCenter : this.CostTypeValue;
			oEntry.costType.name = this.CostTypeName || "";
			if ("clearActivity" in options && options.clearActivity) {
				oEntry.ActvtId = "";
			} else {
				oEntry.ActvtId = this.ActvtId || "";
			}

			// oEntry.StatusId = ""; //It means pending, which is required for save/submit

			if ("addNotes" in options && options.addNotes) {
				oEntry.Note = options.notes;
				oEntry.Indicator = "U";
			}

			return oEntry;
		}

		//Function to check for MTRTasks
		async checkForMTRTasks(existingActivity, activityData = {}) {
			if (!this.ActvtId) {
				return;
			}
			if (existingActivity) {
				if ("MpngAttrVal" in activityData && activityData.MpngAttrVal) {
					this.isCustomerFacingEnabled = true;
				} else {
					this.isCustomerFacingEnabled = false;
					this.clearFacingEntries();
				}
			} else {
				let oActivity = {
					"ActivityId": this.ActvtId,
					"ActAsstId": (this.ActAsstId) ? this.ActAsstId : this.CostTypeId === "1" ?
						"502" : (this.CostTypeId === "4") ?
						"501" : "503"
				};
				let aFilteredTasktypes = await MTRHelper.filterMtrTasks(oActivity, true) || [];
				
				if (aFilteredTasktypes.length === 1) { //TODO CHECK THIS
					this.isCustomerFacingEnabled = false;
					this.clearFacingEntries();
				} else {
					this.isCustomerFacingEnabled = true;
				}
				
			}
			this.refreshData();
		}

		//Function to refresh the data
		refreshData(hardReload) {
			const oMatrixModel = MTRModels.getMatrixModel();
			oMatrixModel.refresh(hardReload);
		}

		//Function to update Day week Time Sheet entries
		checkAndUpdateDayWeekEntries() {
			let i = 0;
			let j = 0;
			let dayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			let aEntries = dayWeekTimesheetModel.getProperty("/Entries") || [];

			let aCFData = (this.customFacing && Object.keys(this.customFacing).length) ? Object.values(this.customFacing) : [];
			let aNCFData = (this.nonCustomFacing && Object.keys(this.nonCustomFacing).length) ? Object.values(this.nonCustomFacing) : [];

			if (aCFData.length) {
				aCFData = aCFData.filter(entry => entry.WorkDuration);
			}
			if (aNCFData.length) {
				aNCFData = aNCFData.filter(entry => entry.WorkDuration);
			}

			while (i < aCFData.length || j < aNCFData.length) {
				let cfItem = i < aCFData.length ? aCFData[i] : null;
				let ncfItem = j < aNCFData.length ? aNCFData[j] : null;

				if (cfItem) {
					aEntries = this._updateEntries(cfItem, aEntries)
				}
				if (ncfItem) {
					aEntries = this._updateEntries(ncfItem, aEntries)
				}

				if (i < aCFData.length) {
					i++;
				}
				if (j < aNCFData.length) {
					j++;
				}
			}
			dayWeekTimesheetModel.setProperty("/Entries", aEntries);
			dayWeekTimesheetModel.refresh(true);
		}

		// Function to update mainArray based on dataid
		_updateEntries(entry, aEntries) {
			if (entry) {
				let iIndex = aEntries.findIndex(item => item.MtrUid === entry.MtrUid);
				if (iIndex !== -1) {
					let oEntry = aEntries[iIndex];
					oEntry = this._fnHelpUpdateFacingData(oEntry);
					if (oEntry.Indicator !== "C") {
						oEntry.Indicator = "U";
					}
					switch (this.CostTypeId) { //NEED TO IMPROVE
					case "1": //Opportunity
						oEntry.CostTypeValue = this.selectedAstOpportunityValue;
						break;
					case "2": //No Assoication
						break;
					case "4": //Account
						oEntry.CostTypeValue = this.selectedAstAccountValue;
						break;
					case "3": //ManualIO
						break;
					default:
					}
					aEntries[iIndex] = oEntry;
				}
			}
			return aEntries;
		}

		//Function to clear facing entries
		clearFacingEntries () {
			if (this.customFacing && !Object.keys(this.customFacing).length) {
				return;
			}
			for (let date in this.customFacing) {
				this.customFacing[date].WorkDuration = "";
			}
		}

		//Function to get ActivityTypes based on AssociationId
		async getActivityTypes(associationId) {
			if (!associationId) {
				return;
			}
			let matrixModel = MTRModels.getMatrixModel();
			const aAssociations = matrixModel.getProperty("/registrationTypes");
			const oAssociation = aAssociations.find(item => item.key === associationId);
			let aFilter = [new Filter("ActivtyTypeCatznID", "EQ", "0001"), new Filter("ActvtAsstdID", "EQ",
				oAssociation.ActvtAsstdID), new Filter("operation_status", "EQ",
				true)];
			const aResponse = await ActivityService.getInstance().getActivityTypesForMatrix(aFilter) || [];

			//Check if type Id is present
			let oTypeId = (aResponse.length && this.selectedActivityType) ? aResponse.find((item) => item.ActvtTypeID === this.selectedActivityType) ||
				false : false;
			if (oTypeId) {
				this.selectedActivityTypeData = oTypeId;
			} else {
				this.selectedActivityType = "";
				this.selectedActivityTypeData = {};
			}
			this.ActTypesData = aResponse;
			matrixModel.setProperty("/ActTypes", aResponse);
			matrixModel.refresh();
			this.refreshData();
		}

		//Function to create new matrix entry based on activities based on week dates
		fnSetActivityToMatrixValues(oActivity) {
			this.activityRegistration = Object.assign(this.activityRegistration, oActivity);
			this.activityRegistration.Region = oActivity.ActSetRegion;
			this.activityRegistration.SubRegion = oActivity.ActSetSubRegion;
			this.activityRegistration.ActivitySetdescription = oActivity.ActivitySetName;
			this.setActivityMatrixValues(oActivity);
			this.busy.registrationBtn = false;
			this.busy.listItem = false;
			this.setCostObjectItems();
			this.refreshData();
		}


}