import Object from "sap/ui/base/Object";
// import DateUtil from "com/melodylib/core/util/DateUtil";
import TargetHourState from "com/melodylib/time/state/TargetHourState";

import DateService from "com/melodylib/core/service/DateService";
import AuthState from "com/melodylib/core/state/AuthState";
import ActivityState from "com/melodylib/activity/state/ActivityState"
import TimeMasterState from "com/melodylib/time/state/TimeMasterState";
import OppService from "com/melodylib/integration/service/OppService";
import Message from "com/melodylib/time/classes/Message";
import DateUtility from "com/melodylib/core/util/DateUtility";
import TargetHour from "com/melodylib/time/classes/TargetHour";
//import EntryStatus from "com/melodylib/time/enum/EntryStatus";
import OpportunityState from "com/melodylib/integration/state/OpportunityState";

/**
 * @namespace com.melodylib.core.classes.BaseEntry
 */
export default class BaseEntry extends Object {
    constructor() {
        super();
    }

    getUser() {
        const authState = AuthState.getInstance();
        return authState.getData();
    }

    

    
}

