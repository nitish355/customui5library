sap.ui.define([
    "sap/m/MessageToast",
    "sap/ui/model/Filter",
    "sap/ui/core/Control",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "com/melodylib/activity/service/ServiceHelper",
    "com/melodylib/integration/util/opportunity/OpportunityUtil"
], (MessageToast, Filter, Control, Fragment, JSONModel, ServiceHelper, OpportunityUtil) => {
    "use strict";

    return Control.extend("com.melodylib.activity.controls.avatar.Avatar", {
        metadata: {
            properties: {
                type: { type: "string", defaultValue: 'individual' },
                mode: { type: "string", defaultValue: "READ" },
                opportunityId: { type: "string", defaultValue: null },
                roleMappingId: { type: "string", defaultValue: null },
                leadInfo: { type: "object", defaultValue: null },
                teamMembers: { type: "array", defaultValue: [] },
                controlId: { type: "string", defaultValue: "Lead" }
            },
            aggregations: {
                _avatar: { type: "sap.m.Avatar", multiple: false, visibility: "hidden" },
                _avatarGroup: { type: "sap.ui.layout.VerticalLayout", multiple: false, visibility: "hidden" },
                // _button: { type: "sap.m.Button", multiple: false, visibility: "hidden" },
                // _editButton: { type: "sap.m.Button", multiple: false, visibility: "hidden" },
                _input: { type: "sap.m.Input", multiple: false, visibility: "hidden" },
                _multiInput: { type: "sap.m.MultiInput", multiple: false, visibility: "hidden" },
                _notAvailableText: { type: 'sap.m.Text', multiple: false, visibility: "hidden" }



            }
        },

        init() {
            this.oModel = new JSONModel();
            // this.oModel.loadData(sap.ui.require.toUrl("com/melody/activity/controls/Users.json"), null, false);
            this.setModel(this.oModel, "oUserModel");
            if (!this.OpportunityUtil) {
                this.OpportunityUtil = OpportunityUtil.getInstance(this);
            }
            let oThisController = this;
            //INIT CSS FILE
            //initialisation code, in this case, ensure css is imported
            var libraryPath = jQuery.sap.getModulePath(
                "com.melodylib.activity"
            );
            jQuery.sap.includeStyleSheet(
                libraryPath + "/css/Style.css"
            );

            let bDefaultLead = false;
            if (oThisController.getLeadInfo()) bDefaultLead = true;
            this.setAggregation("_avatar", new sap.m.Avatar({
                displaySize: "XS",
                visible: bDefaultLead,
                // initials: "{oUserModel>/userData/initials}",
                initials: oThisController.getLeadInfo()?.initials,
                tooltip: oThisController.getLeadInfo()?.Name,
                press: this.fnShowUserDetails.bind(this)
            }).addStyleClass(""))
            this.setAggregation("_avatarGroup", new sap.ui.layout.VerticalLayout({
                content: [
                    new sap.f.AvatarGroup({
                        avatarDisplaySize: "XS",
                        groupType: "Group",
                        press: this.fnShowTeamMembers.bind(this),
                        id: this.getId() + "_avatarGroup"
                    })
                ]
            }).addStyleClass('avatarGroupWidth '))
            this.setAggregation("_input", new sap.m.Input({
                showValueHelp: true,
                valueHelpOnly: true,
                valueHelpRequest: this.fnOpenUserSelection.bind(this),
                value: oThisController.getLeadInfo()?.Name
            }).addStyleClass("sapUiTinyMarginEnd"))
            this.setAggregation("_multiInput", new sap.m.MultiInput({
                showValueHelp: true,
                valueHelpOnly: true,
                placeholder: "Select Activity Team",
                valueHelpRequest: this.fnOpenUserSelection.bind(this),
                tokenUpdate: this.fnDeleteTeamMember.bind(this)
            }).addStyleClass("sapUiTinyMarginEnd"))
            this.setAggregation("_notAvailableText", new sap.m.Text({
                text: "Not Available"
            }))
            // this.setAggregation("_button", new sap.m.Button({
            //     icon: "sap-icon://add",
            //     type: "Transparent",
            //     press: this.fnOpenUserSelection.bind(this)
            // }).addStyleClass("sapUiTinyMarginBegin"))
            // this.setAggregation("_editButton", new sap.m.Button({
            //     icon: bDefaultLead ? "sap-icon://edit" : "sap-icon://add",
            //     type: "Transparent",
            //     press: this.fnOpenUserSelection.bind(this)
            // }).addStyleClass("sapUiTinyMarginBegin"))
        },
        onAfterRendering: function () {
            this._oAvatarGroup = sap.ui.getCore().byId(this.getId() + "_avatarGroup");
            let sMode = this.getMode();
            let oUserModel = this.getModel("oUserModel")
            if (sMode === "CREATE") oUserModel.setProperty('/bDeleteTeamMem', true);
            else oUserModel.setProperty('/bDeleteTeamMem', false)

        },

        /**
         * @author Srikari
         * @async
         * @function setTeamMembers
         * @description function to set selected team members data to activity team control 
         * @public
         * @param {array} aUsers 
         * @param {array} aAllTeam
         */
        setTeamMembers: function (team) {
            this.setProperty("teamMembers", team);
            this.getModel("oUserModel").setProperty('/aUsers', team)
            let oAvatarGroup = this.getAggregation("_avatarGroup");
            let oMultiInput = this.getAggregation("_multiInput");
            oMultiInput?.removeAllTokens();
            if (oAvatarGroup) {
                this.getAggregation("_avatarGroup").getContent()[0].removeAllItems(); // needed to clear avatar group on change of activity 
                team?.forEach(user => {
                    let oAvatar = new sap.f.AvatarGroupItem({
                        initials: user.initials
                    })
                    user.avatarColor = oAvatar.getAvatarColor();
                    oAvatarGroup.getContent()[0].addItem(oAvatar)
                    if (oMultiInput) {
                        oMultiInput.addToken(new sap.m.Token({ text: user.name, key: user.id }))
                    }
                })
            }
        },
        setTeamMembers1: function (aUsers, aAllTeam) {
            this.setProperty("teamMembers", aAllTeam || aUsers);
            let oAvatarGroup = this.getAggregation("_avatarGroup");
            let oMultiInput = this.getAggregation("_multiInput");
            if (oAvatarGroup) {
                if (!aAllTeam && !aUsers) this.getAggregation("_avatarGroup").getContent()[0].removeAllItems(); // needed to clear avatar group on change of activity 
                aUsers?.forEach(user => {
                    let oAvatar = new sap.f.AvatarGroupItem({
                        initials: user.initials
                    })
                    user.avatarColor = oAvatar.getAvatarColor();
                    oAvatarGroup.getContent()[0].addItem(oAvatar)
                    if (oMultiInput) {
                        oMultiInput.addToken(new sap.m.Token({ text: user.name, key: user.ID }))
                    }
                })
            }
        },

        /**
        * @author Srikari
        * @async
        * @function setLeadInfo
        * @description function to set selected lead data to activity lead control 
        * @public
        * @param {object} oLead
        */
        setLeadInfo: function (oLead) {
            this.setProperty("leadInfo", oLead);
            let oAvatar = this.getAggregation("_avatar");
            // let oEditButton = this.getAggregation("_editButton")
            let oInput = this.getAggregation("_input")
            if (oInput)
                oInput.setPlaceholder(this.getControlId() === "Lead" ? "Select Activity Lead" : "Select Activity Executive")

            if (oAvatar && oLead) {
                oAvatar.setInitials(oLead?.initials);
                oAvatar.setTooltip(oLead?.Name || oLead?.name)
                oAvatar.setVisible(true)
                if (oInput) {
                    oInput.setValue(oLead?.Name || oLead?.name);
                }
            }
            // if (oEditButton && oLead) oEditButton.setIcon("sap-icon://edit")
        },

        /**
        * @author Srikari
        * @async
        * @function fnOpenUserSelection
        * @description function to open ActLeadSelection / ActTeamSelection fragment based on type on click of add  button and to fetch opportunity data 
        * @public
        */
        fnOpenUserSelection: function () {
            var oThisController = this;
            if (this.getType() === "individual") {
                if (!this._ActLeadDialog) {
                    this._ActLeadDialog = Fragment.load({
                        name: "com.melodylib.activity.fragments.avatar.ActLeadSelection",
                        controller: oThisController
                    }).then(function (oActLeadDialog) {
                        oThisController.addDependent(oActLeadDialog)
                        return oActLeadDialog;
                    });
                }
                this._ActLeadDialog.then(async function (oActLeadDialog) {
                    let sOpportunityId = this.getOpportunityId();
                    let oUserModel = this.getModel("oUserModel");
                    let bOppoSingleTabVisible = false;
                    if (sOpportunityId) {
                        oUserModel.setProperty('/bOppoTabVisible', true);
                        let { data } = await this.OpportunityUtil.getOpportunitiesTeam(sOpportunityId);
                        let aUsers = data?.PartiesInvolved?.results || [];
                        let aOppoTeam = aUsers.map(function (user) {
                            return {

                                id: user.USER_ID,
                                name: user.NAME,
                                email: user.EMAIL,
                                roleDescription: user.ROLE_DESCR

                            };

                        });
                        oUserModel.setProperty('/aOpportunityTeam', aOppoTeam);
                        bOppoSingleTabVisible = true;
                    }
                    oUserModel.setProperty('/bOppoSingleTabVisible', bOppoSingleTabVisible)
                    oUserModel.setProperty('/sControlId', this.getControlId())
                    oActLeadDialog.open();
                }.bind(this))
            }
            else {
                if (!this._ActTeamDialog) {
                    this._ActTeamDialog = Fragment.load({
                        name: "com.melodylib.activity.fragments.avatar.ActTeamSelection",
                        controller: oThisController
                    }).then(function (oActTeamDialog) {
                        oThisController.addDependent(oActTeamDialog)
                        return oActTeamDialog;
                    });
                }
                this._ActTeamDialog.then(async function (oActTeamDialog) {
                    let sOpportunityId = this.getOpportunityId();
                    let oUserModel = this.getModel("oUserModel");
                    let bOppoMultiListTabVisible = false
                    if (sOpportunityId) {
                        let { data } = await this.OpportunityUtil.getOpportunitiesTeam(sOpportunityId);
                        let aUsers = data?.PartiesInvolved?.results || [];
                        let aOppoTeam = aUsers.map(function (user) {
                            return {

                                id: user.USER_ID,
                                name: user.NAME,
                                email: user.EMAIL,
                                roleDescription: user.ROLE_DESCR

                            };

                        });
                        oUserModel.setProperty('/aOpportunityTeam', aOppoTeam);
                        bOppoMultiListTabVisible = true;
                    }

                    oUserModel.setProperty('/bOppoMultiListTabVisible', bOppoMultiListTabVisible);
                    this.oSelectedTeam = {}
                    oActTeamDialog.open();
                }.bind(this))
            }
        },

        /**
        * @author Srikari
        * @async
        * @function fnShowUserDetails
        * @description function to show the activity lead information on click of activity lead avatar
        * @public
        */
        fnShowUserDetails: function (oEvent) {
            let oThisController = this;
            if (!this._oUserPopover) {
                this._oUserPopover = Fragment.load({
                    name: "com.melodylib.activity.fragments.avatar.UserDetailsPopover",
                    controller: oThisController
                }).then(function (oUserPopover) {
                    oThisController.addDependent(oUserPopover)
                    return oUserPopover;
                });
            }
            this._oUserPopover.then(function (oUserPopover) {
                let oUserModel = this.getModel('oUserModel');
                let oEventSource = oEvent.getSource();
                let oLeadInfo = this.getLeadInfo();
                var oUserData = { ...oLeadInfo, backgroundColor: oEventSource.getBackgroundColor() };
                oUserModel.setProperty('/oUserInfo', oUserData);
                oUserPopover.openBy(oEventSource).addStyleClass("sapFAvatarGroupPopover");
            }.bind(this));

        },

        /**
        * @author Srikari
        * @async
        * @function _getAvatarModel
        * @description function to format the user details and also fetch the avatar color on click of avatar
        * @public
        */
        _getAvatarModel: function (oBindingInfo, oAvatarGroupItem) {
            return {
                src: oBindingInfo.src,
                initials: oBindingInfo.initials,
                fallbackIcon: oBindingInfo.fallbackIcon,
                backgroundColor: oAvatarGroupItem.getAvatarColor(),
                name: oBindingInfo.name,
                roleDescription: oBindingInfo.roleDescription,
                mobile: oBindingInfo.mobile,
                phone: oBindingInfo.phone,
                email: oBindingInfo.email,
                id: oBindingInfo.id
            };
        },
        _getContent: function (sGroupType, iAvatarsDisplayed) {
            var aAllAvatars = this._oAvatarGroup.getItems(),
                aAvatarsToShowInPopover,
                oBindingInfo;

            if (sGroupType === "Individual") {
                aAvatarsToShowInPopover = aAllAvatars.slice(iAvatarsDisplayed);
            } else {
                aAvatarsToShowInPopover = aAllAvatars;
            }

            return aAvatarsToShowInPopover.map(function (oAvatarGroupItem) {
                oBindingInfo = oAvatarGroupItem.getBindingContext("oUserModel").getObject();
                return this._getAvatarModel(oBindingInfo, oAvatarGroupItem);
            }, this);
        },

        /**
        * @author Srikari
        * @async
        * @function fnShowTeamMembers
        * @description function to open TeamMembersPopover that shows all the selected team members details
        * @public
        */
        fnShowTeamMembers: function (oEvent) {
            let oUserModel = this.getModel("oUserModel");
            let aTeamMembers = this.getTeamMembers();
            let iItemsCount = aTeamMembers.length,
                sGroupType = oEvent.getParameter("groupType"),
                iAvatarsDisplayed = oEvent.getParameter("avatarsDisplayed"),
                oEventSource = oEvent.getSource(),
                sTitle;

            sTitle = "Team Members (" + iItemsCount + ")";
            let oThisController = this;
            oUserModel.setProperty("/popoverTitle", sTitle);
            if (!this._TeamMembersPopover) {
                this._TeamMembersPopover = Fragment.load({
                    name: "com.melodylib.activity.fragments.avatar.TeamMembersPopover",
                    controller: oThisController
                }).then(function (oGroupPopover) {
                    oThisController.addDependent(oGroupPopover)
                    return oGroupPopover;
                });
            }

            this._TeamMembersPopover.then(function (oGroupPopover) {
                var oNavCon = sap.ui.getCore().byId("navCon"),
                    oMainPage = sap.ui.getCore().byId("main"),
                    aContent = aTeamMembers,
                    // aContent = oThisController._getContent(sGroupType, iAvatarsDisplayed),
                    iNumberOfAvatarsInPopover = aContent.length;
                oThisController._sGroupPopoverHeight = (Math.floor(iNumberOfAvatarsInPopover / 2) + iNumberOfAvatarsInPopover % 2) * 68 + 48 + "px";
                oUserModel.setProperty("/aUsers", aTeamMembers);
                oGroupPopover.setContentHeight(oThisController._sGroupPopoverHeight);
                oNavCon.to(oMainPage);
                oGroupPopover.openBy(oEventSource).addStyleClass("sapFAvatarGroupPopover");
            }.bind(this));
        },

        /**
        * @author Srikari
        * @async
        * @function onAvatarPress
        * @description function to navigate to show the selected team member details on click of any team member in TeamMembersPopover
        * @public
        */
        onAvatarPress: function (oEvent) {
            let oGroupPopover = sap.ui.getCore().byId('groupPopover');
            oGroupPopover.setContentHeight('600px')
            let oUserModel = this.getModel('oUserModel');
            var oBindingInfo = oEvent.getSource().getBindingContext("oUserModel").getObject(),
                oNavCon = sap.ui.getCore().byId("navCon"),
                oDetailPage = sap.ui.getCore().byId("detail");
            oUserModel.setProperty('/oUserInfo', oBindingInfo);
            oNavCon.to(oDetailPage);
        },

        /**
        * @author Srikari
        * @async
        * @function onNavBack
        * @description function to navigate back to TeamMemberPopover on click back icon
        * @public
        */
        onNavBack: function () {
            let oGroupPopover = sap.ui.getCore().byId('groupPopover');
            oGroupPopover.setContentHeight(this._sGroupPopoverHeight)
            var oNavCon = sap.ui.getCore().byId("navCon");
            oNavCon.back();
        },

        /**
        * @author Srikari
        * @async
        * @function fnDeleteTeamMember
        * @description function to delete team member
        * @public
        */
        fnDeleteTeamMember: function (oEvent) {

            let oUserModel = this.getModel("oUserModel");
            let sSelectedID = oEvent.getParameter("removedTokens")[0].getKey()
            let aUsers = oUserModel.getProperty('/aUsers');

            let sIndexToDelete = aUsers.findIndex(each => each.id === sSelectedID)
            aUsers.splice(sIndexToDelete, 1);
            oUserModel.setProperty('/aUsers', aUsers)
            let oAvatarGroup = this.getAggregation("_avatarGroup");
            if (oAvatarGroup) {
                oAvatarGroup.getContent()[0].removeItem(parseInt(sIndexToDelete))
            }
            let oMultiInput = this.getAggregation("_multiInput");
            if (oMultiInput)
                oMultiInput.removeToken(sIndexToDelete);
            // this.setTeamMembers(null, aUsers);
            this.setProperty("teamMembers", aUsers);
        },

        /**
        * @author Srikari
        * @async
        * @function handleTeamSelect
        * @description function that get fired on selection change of team members and shows message if selected user already exists
        * @public
        */
        handleTeamSelect: function (oEvent) {
            let oSelectedUser = oEvent.getParameter("listItem")?.getBindingContext("oUserModel").getObject();
            let bSelected = oEvent.getParameter("listItem").isSelected();
            if (bSelected) {
                let aTeamMembers = this.getTeamMembers();
                let oUserExists = aTeamMembers?.find(each => each.id === oSelectedUser.id);
                oUserExists ? MessageToast.show(oSelectedUser.name + ' already exists') : this.oSelectedTeam[oSelectedUser.id] = oSelectedUser;
            }
            else delete this.oSelectedTeam[oSelectedUser['id']]
        },

        /**
        * @author Srikari
        * @async
        * @function handleTeamSelection
        * @description function gets triggered on click of OK in TeamMembersPopover and adds all selected team members to activity team.
        * @public
        */
        handleTeamSelection: function (oEvent) {
            let oUserModel = this.getModel('oUserModel');
            let sSelectedTab = sap.ui.getCore().byId("team-tabs").getSelectedKey();
            let sListId = sSelectedTab === "SAP" ? "UserListMulti_SAP" : "UserListMulti_Oppo"
            let aSelectedTeam = Object.keys(this.oSelectedTeam)
            let aSelectedData = aSelectedTeam.map(id => { return { ...this.oSelectedTeam[id], name: this.oSelectedTeam[id].name, email: this.oSelectedTeam[id].email, initials: this.oSelectedTeam[id].name.split(" ")[0][0] + this.oSelectedTeam[id].name.split(" ").pop()[0], roleDescription: this.oSelectedTeam[id].roleDescription, id: this.oSelectedTeam[id].id } });
            let aUsers = this.getTeamMembers();
            let aValidUsers = [], oUserExists;
            aSelectedData.forEach(each => {
                oUserExists = aUsers.find(user => each.id === user.id);
                !oUserExists && aValidUsers.push(each)
            })
            aUsers = aUsers.concat(aValidUsers);
            // this.setTeamMembers(aValidUsers, aUsers);
            oUserModel.setProperty('/aUsers', aUsers);
            this.setProperty("teamMembers", aUsers);
            let oAvatarGroup = this.getAggregation("_avatarGroup");
            let oMultiInput = this.getAggregation("_multiInput");
            aValidUsers?.forEach(user => {
                let oAvatar = new sap.f.AvatarGroupItem({
                    initials: user.initials
                })
                user.avatarColor = oAvatar.getAvatarColor();
                oAvatarGroup.getContent()[0].addItem(oAvatar)
                if (oMultiInput) {
                    oMultiInput.addToken(new sap.m.Token({ text: user.name, key: user.id }))
                }
            })
            this.onCloseTeamSelection();
        },

        /**
         * @author Srikari
         * @async
         * @function onCloseTeamSelection
         * @description function to close Activity Team selection dialog 
         * @public
         */
        onCloseTeamSelection: function () {
            let oThisController = this;
            let oUserModel = this.getModel('oUserModel');
            oThisController._ActTeamDialog.then(function (oActTeamDialog) {
                oActTeamDialog.close();
                oActTeamDialog.destroy();
                oThisController._ActTeamDialog = null;
            })
            oUserModel.setProperty('/aOpportunityTeam', []);
            oUserModel.setProperty('/aSAPusers', []);
            this.oSelectedTeam = {}
        },

        /**
         * @author Srikari
         * @async
         * @function onCloseUserDetailsPopover
         * @description function to close user details popover on click of cancel button
         * @public
         */
        onCloseUserDetailsPopover: function () {
            let oThisController = this
            oThisController._oUserPopover.then(function (oUserPopover) {
                oUserPopover.close();
                oUserPopover.destroy();
                oThisController._oUserPopover = null
            })
        },

        /**
         * @author Srikari
         * @async
         * @function onCloseUserDetailsPopover
         * @description function to close Team Members Popover on click of cancel button
         * @public
         */
        onCloseTeamMembersPopover: function () {
            let oThisController = this
            oThisController._TeamMembersPopover.then(function (oTeamMembersPopover) {
                oTeamMembersPopover.close();
                oTeamMembersPopover.destroy();
                oThisController._TeamMembersPopover = null
            })
        },

        /**
         * @author Srikari
         * @async
         * @function handleTeamTabSelection
         * @description function gets triggered on change of tabs in Team Selection Dialog
         * @public
         */
        handleTeamTabSelection: function (oEvent) {
            let sSelectedTab = sap.ui.getCore().byId("team-tabs").getSelectedKey();
            let bSAPListVisible = sSelectedTab === "SAP" ? true : false;
            let oUserModel = this.getModel("oUserModel")
            oUserModel.setProperty('/bSAPListVisible', bSAPListVisible);

        },

        /**
         * @author Srikari
         * @async
         * @function onSearchOppoUser
         * @description filters opportunity team based on the search in Team Selection
         * @public
         */
        onSearchOppoUser: function (oEvent) {
            var sQuery = "";
            var aFilter = [];
            if (oEvent) {
                sQuery = oEvent.getParameter("query");
            }
            if (sQuery) {
                aFilter = new Filter({
                    filters: [
                        new Filter("name", "Contains", sQuery),
                        new Filter("id", "Contains", sQuery)
                    ],
                    and: false
                });
            }
            var oList = sap.ui.getCore().byId("UserListMulti_Oppo");
            var oBinding = oList.getBinding("items");
            oBinding.filter(aFilter);

        },

        /**
         * @author Srikari
         * @async
         * @function onSearchSAPUser
         * @description fetches SAP users data based the search
         * @public
         */
        onSearchSAPUser: async function (oEvent) {
            let oUserModel = this.getModel("oUserModel");
            let sQuery = oEvent.getParameter("query");
            if (sQuery !== "" && sQuery.length > 2) {
                let urlParameters = {
                    "search": sQuery
                }
                let { data } = await ServiceHelper.getSAPUsers(null, urlParameters);
                let sapUsers = data?.results?.map(each => {
                    return {
                        email: each.EMAIL,
                        id: each.ID,
                        name: each.NAME,
                    }
                })
                oUserModel.setProperty("/aSAPusers", sapUsers || []);
                sap.ui.getCore().byId('UserListMulti_SAP').removeSelections();
            }
            else {
                MessageToast.show("Please enter minimum of 3 characters");
            }

        },

        /**
         * @author Srikari
         * @async
         * @function onSearchOppoLeadUser
         * @description filters opportunity team based on the search in Lead Selection
         * @public
         */
        onSearchOppoLeadUser: function (oEvent) {
            var sQuery = "";
            var aFilter = [];
            if (oEvent) {
                sQuery = oEvent.getParameter("query");
            }
            if (sQuery !== "" && sQuery.length > 2) {
                aFilter = new Filter({
                    filters: [
                        new Filter("name", "Contains", sQuery),
                        new Filter("id", "Contains", sQuery),
                        new Filter("email", "Contains", sQuery)
                    ],
                    and: false
                });
            } else {
                MessageToast.show("Please enter minimum of 2 characters")
            }
            var oList = sap.ui.getCore().byId("Lead_UserListSingle_Oppo");
            var oBinding = oList.getBinding("items");
            oBinding.filter(aFilter);
        },

        /**
         * @author Srikari
         * @async
         * @function onSearchORELeadUser
         * @description fetches ORE users data based on the search  for Lead
         * @public
         */
        onSearchORELeadUser: async function (oEvent) {
            let oUserModel = this.getModel("oUserModel");
            let sQuery = oEvent.getParameter("query");
            if (sQuery !== "" && sQuery.length > 2) {
                let aFilters = [], sRolempngId = this.getRoleMappingId();
                aFilters.push(new Filter("RolempngId", "EQ", sRolempngId));
                let { data } = await ServiceHelper.getActLeadUsers(sRolempngId ? aFilters : null, sQuery);
                let aORELeadusers = data?.results?.map(each => { return { id: each.UserId, name: each.Name, email: each.EmailId, roleDescription: each.RoleDesc } })
                oUserModel.setProperty("/aORELeadusers", aORELeadusers || [])
            } else {
                oUserModel.setProperty("/aORELeadusers", []);
                MessageToast.show("Please enter minimum of 3 characters");
            }
        },

        /**
       * @author Srikari
       * @async
       * @function onSearchExecutive
       * @description fetches  users data based on the search for Executive
       * @public
       */
        onSearchExecutive: async function (oEvent) {
            let oUserModel = this.getModel("oUserModel");
            let sQuery = oEvent.getParameter("query");
            if (sQuery !== "" && sQuery.length > 2) {
                let urlParameters = {
                    "search": sQuery
                }
                let { data } = await ServiceHelper.getSAPUsers(null, urlParameters);
                let aORELeadusers = data?.results?.map(each => { return { ...each, name: each.NAME, email: each.EMAIL, id: each.ID } })
                oUserModel.setProperty("/aORELeadusers", aORELeadusers || [])
            } else {
                oUserModel.setProperty("/aORELeadusers", []);
                MessageToast.show("Please enter minimum of 3 characters");
            }
        },

        /**
         * @author Srikari
         * @async
         * @function handleLeadSelection
         * @description function gets triggered on click of OK in lead selection dialog and sets the user to activity lead 
         * @public
         */
        handleLeadSelection: function (oEvent) {
            let oSelectedUser = oEvent.getSource().getBindingContext('oUserModel').getObject();
            if (oSelectedUser?.id === this.getLeadInfo()?.id) {
                MessageToast.show(oSelectedUser.name + ' already exists')
            }
            else {
                let oLead = { ...oSelectedUser, name: oSelectedUser.name, email: oSelectedUser.email, initials: oSelectedUser.name?.split(" ")[0][0] + oSelectedUser.name.split(" ").pop()[0], roleDescription: oSelectedUser.roleDescription, id: oSelectedUser.id };
                let oUserModel = this.getModel("oUserModel");
                oUserModel.setProperty('/userData', oLead);
                this.setLeadInfo(oLead)
                this.onCloseLeadSelectionPoupup();
            }
        },

        /**
         * @author Srikari
         * @async
         * @function onCloseLeadSelectionPoupup
         * @description closes lead selection dialog on click of cancel button 
         * @public
         */
        onCloseLeadSelectionPoupup: function () {
            let oThisController = this;
            let oUserModel = this.getModel('oUserModel')
            oThisController._ActLeadDialog.then(function (oActLeadDialog) {
                oActLeadDialog.close();
                oActLeadDialog.destroy();
                oThisController._ActLeadDialog = null;
            })
            oUserModel.setProperty('/aORELeadusers', []);
            oUserModel.setProperty('/aOpportunityTeam', []);
        },

        /**
         * @author Srikari
         * @async
         * @function onDeleteTeamMem
         * @description deletes all activity team members on click of clear all button 
         * @public
         */
        onDeleteTeamMem: function () {
            let oUserModel = this.getModel("oUserModel");
            oUserModel.setProperty('/aUsers', []);
            this.setProperty("teamMembers", []);
            this.getAggregation("_avatarGroup").getContent()[0].removeAllItems();
            this.getAggregation("_multiInput")?.removeAllTokens();
            // this.setTeamMembers([])
        }
    });
});