import CoreService from "com/melodylib/core/service/CoreService";

/**
 * @name com.melodylib.activity.service.ActivityMasterService
 */
export default class ActivityMasterService extends CoreService {
	constructor() {
		super();
	}
	static getInstance() {
		if (!this.instance) {
			this.instance = new ActivityMasterService();
		}
		return this.instance;
	}

	getActivityRisks() {
		return this.odata("/Yc_Mac_M_Risk_Asses").get("activityList");
	}

	getActivityStatusList() {
		return this.odata("/YC_MAC_M_STATUS_LIST").get("activityList");
	}

	getDBRStatusList() {
		return this.odata("/Yc_Mac_M_Requeststatus").get("activityList");
	}

	getDBRStatusReasonList() {
		return this.odata("/YC_MAC_M_STATUS_RSN").get("activityList");
	}

	getActivityDeliveryTeam() {
		return this.odata("/YC_MAC_M_DELV_TEAM").get("activityList");
	}

	getActivityHostTypes() {
		return this.odata("/YC_MAC_M_HOST_TYPE").get("activityList");
	}

	getActivityLandScapes() {
		return this.odata("/Yc_Mac_M_Landscape").get("activity");
	}

	getActivityProjectTypes() {
		return this.odata("/YC_MAC_M_PROJ_TYPE").get("activityList");
	}

	getActivityRegions() {
		return this.odata("/YC_MAC_REGION_MASTER_ACTLIST").get("activityList");
	}

	getActivityShowrooms() {
		return this.odata("/Yc_Mac_M_Showroom_As").get("activityList");
	}

	getActivityUseCases() {
		return this.odata("/YC_MAC_M_USE_CASE").get("activityList");
	}

	getActivityInnovations() {
		return this.odata("/Yc_Mac_M_Strategic_Area").get("activityList");
	}

	// getActivityRoles(parameters) {
	//   return this.odata("/YC_MAC_M_ACTVTYPE_ROLE").get(
	//     "activityList",
	//     parameters
	//   );
	// }

	getActivityTypes(params) {
		const options = this.getUrlParameters(params);
		return this.odata("/YC_ROLE_ACTVT_FORMACCESS_USER").get("activity", options);
	}

	getAllActivityTypes() {
		return this.odata("/Yc_Mac_M_Activity_Type").get("activityList");
	}

	getActivityRoles(params) {
		const options = this.getUrlParameters(params);
		return this.odata("/YC_ROLE_ACTVT_FRMACSS").get(
			"activity",
			options
		);
	}

	getUsersBySearch(params) {
		const options = this.getUrlParameters(params);
		return this.odata("/Yc_MD_Usersearch").get("activityList", options);
	}

	getActivityCVJPhase(params) {
		const options = this.getUrlParameters(params);
		return this.odata("/YC_MAC_M_CVJ_PHASE").get("activity", options)
	}

	getMethodsByType(params) {
		const options = this.getUrlParameters(params);
		return this.odata("/Yc_Mac_M_Method").get("activity", options)
	}

	getActivityDataCenters() {
		return this.odata("/Yc_Mac_M_Datacenter").get("activity");
	}

	getActivityDetailTypes(params) {
		const options = this.getUrlParameters(params);
		return this.odata("/Yc_Mac_M_Activity_Det_Type").get("activity", options)
	}

	getDemoEducations() {
		return this.odata("/Yc_Mac_M_LS_DemoEC").get("activity")
	}

	getSolutionsLevel2Data(params) {
		const options = this.getUrlParameters(params);
		return this.odata("/YC_MAC_M_SOL_HIER").get("activity", options)
	}
	getSolHierarchyById(params, guid) {
		const options = this.getUrlParameters(params);
		return this.odata("/YC_MAC_M_SOL_HIERARCHY(soln_guid=guid'" + guid + "',project_type='ACTVT')").get("activity", options);
	}
	getActivityRegions() {
		return this.odata("/YC_MOP_REGION_MASTER").get("activity")
	}
	getBsnsAreaEngaged(params) {
		const options = this.getUrlParameters(params);
		return this.odata("/YC_MAC_M_BSNSAREAENGD").get("activity", options)
	}
	

}
