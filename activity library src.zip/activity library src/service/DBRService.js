import CoreService from "com/melodylib/core/service/CoreService";

/**
 * @name com.melodylib.activity.service.DBRService
 */
export default class DBRService extends CoreService {
	constructor() {
		super();
	}
	static getInstance() {
		if (!this.instance) {
			this.instance = new DBRService();
		}
		return this.instance;
	}

	getDBRList(params, isManager) {
		const url = isManager
			? "/YC_MAC_T_REQUESTS(P_IncludeTeam='X')/Set"
			: "/YC_MAC_T_REQUESTS(P_IncludeTeam='')/Set";
		const options = this.getUrlParameters(params);
		return this.odata(url).get("activityList", options);
	}
}
