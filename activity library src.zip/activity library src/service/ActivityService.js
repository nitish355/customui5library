import CoreService from "com/melodylib/core/service/CoreService";
import Filter from "sap/ui/model/Filter"

/**
 * @name com.melodylib.activity.service.ActivityService
 */
export default class ActivityService extends CoreService {
	constructor() {
		super();
	}
	static getInstance() {
		if (!this.instance) {
			this.instance = new ActivityService();
		}
		return this.instance;
	}

	getActivityList(params, isManager) {
		const options = this.getUrlParameters(params);
		let url = isManager
			? "/YC_MAC_T_ACTVT_SET(P_IncludeTeam='X')/Set"
			: "/YC_MAC_T_ACTVT_SET(P_IncludeTeam='')/Set";
		return this.odata(url).get("activityList", options);
	}

	getActivityDetail(params) {
		const options = this.getUrlParameters(params);
		return this.odata("/Yc_Mac_T_Act_Main").get("activity", options);
	}

	async getUserActivityRole() {
		const oResult = await this.odata("/YC_ROLE_ACTVT_FRMACSS").get("activity");
		return oResult.data.results[0];
	}

	async getActivitySets(){
		 const oResult = await this.odata("/Yc_Mac_M_Actity_Set").get("activity");
        return oResult.data.results
	}

	  async getActivityTypesForMatrix(aFilters) {
            var mParameters = {
                filters: aFilters
            };
            const oResult = await this.odata("/YC_ROLE_ACTVT_FORMACCESS_USER").get("activity", mParameters);
            return oResult.data.results;
        }

	 async getActMenuData(aFilters) {
            var mParameters = {
                filters: aFilters,
                urlParameters: {
                    "$expand": 'to_caction'
                }
            };
            const oResult = await this.odata("/YC_SL_M_ACT_PRNT_ACTION").get("activity", mParameters);
            return oResult.data.results;
        }

	
	getActivityListCounts(includeTeamFlag = "") {
		return this.odata(
			"/YC_MAC_T_ACTVT_SET_COUNT(P_IncludeTeam='" + includeTeamFlag + "')/Set"
		).get("activityList");
	}

	getCountData(params, type) {
		const options = this.getUrlParameters(params);
		let url = "";
		switch (type) {
			case "team":
				url = "/Yc_Mac_T_Actteam";
				break;
			case "files":
				url = "/YC_MAC_T_FILE_CONTENT";
				break;
			case "additionalOpportunities":
				url = "/YC_MAC_T_ADD_OPP";
				break;
			case "innovations":
				url = "/YC_MAC_T_ACTSTR_SOL";
				break;
			case "landscapes":
				url = "/Yc_Mac_T_Landscapes";
				break;
			case "showrooms":
				url = "/YC_MAC_T_ACTSHOWROOM";
				break;
			case "successFactors":
				url = "/Yc_Mac_T_Success_F";
				break;
			case "solutions":
				url = "/Yc_Mac_T_Solution";
				break;
			case "detailTypes":
				url = "/Yc_Mac_T_Activity_Details_Type";
				break;
			case "cvjPhases":
				url = "/YC_MAC_T_PHASE";
				break;
			case "cloudEnvironments":
				url = "/Yc_Mac_T_Cloud_Env";
				break;
			default:
				break;
		}
		return this.odata(url).get("activity", options);
	}

	getActivityListStatusMasterData() {
		return this.odata("/YC_MAC_M_STATUS_LIST").get("activityList");
	}

	getActivityListDelTeamMasterData() {
		return this.odata("/YC_MAC_M_DELV_TEAM").get("activityList");
	}

	getActivityListHostTypeMasterData() {
		return this.odata("/YC_MAC_M_HOST_TYPE").get("activityList");
	}

	getActivityListLandScapeMasterData() {
		return this.odata("/Yc_Mac_M_Landscape_As").get("activityList");
	}

	getActivityListProjectTypeMasterData() {
		return this.odata("/YC_MAC_M_PROJ_TYPE").get("activityList");
	}

	getActivityListRegionMasterData() {
		return this.odata("/YC_MAC_REGION_MASTER_ACTLIST").get("activityList");
	}

	getActivityListShowroomMasterData() {
		return this.odata("/Yc_Mac_M_Showroom_As").get("activityList");
	}

	getActivityListUseCaseMasterData() {
		return this.odata("/YC_MAC_M_USE_CASE").get("activityList");
	}

	getEntitiyString(params) {
		const options = this.getUrlParameters(params);
		return this.odata("/YC_MAC_M_TYP_EXPAND").get("activity", options);
	}

	getFormLayoutString(params) {
		const options = this.getUrlParameters(params);
		return this.odata("/YC_MAC_M_FORM_LAYOUT").get("activity", options);
	}

	getMaterialsById(params) {
		const options = this.getUrlParameters(params);
		return this.odata("/YC_MAC_T_SOL_MATERIAL").get("activity", options);
	}
	getAddOpportunities(params) {
		const options = this.getUrlParameters(params);
		return this.odata("/YC_MAC_T_ADD_OPP").get("activity", options);
	}

	getSolutions(guid) {
		const url = "/Yc_Mac_T_Act_Main(guid'" + guid + "')/to_ASolution";
		return this.odata(url).get("activity");
	}

	getMaterials(guid) {
		const url = "/Yc_Mac_T_Act_Main(guid'" + guid + "')/to_AMaterials";
		return this.odata(url).get("activity");
	}

	getSolHierarchyById(params) {
		const options = this.getUrlParameters(params);
		return this.odata("/YC_MAC_T_SOL_HIERARCHY").get("activity", options);
	}

	registerActivity(data) {
		return this.odata("/Yc_Mac_T_Act_Main").post("activity", data);
	}
	createActivitySet(data) {
		return this.odata("/Yc_Mac_T_ActSetUsr").post("activity", data);
	}
	getDuplicateRegistrations(params) {
		const options = this.getUrlParameters(params);
		return this.odata("/YC_MAC_T_OPP_ACC").get("activity", options);
	}
	getCommentId(data) {
		return this.odata("/YC_MD_COMMENTS").post("utility", data);
	}
	saveComment(data) {
		return this.odata("/YC_MAC_T_ACTCOMMENT").post("activity", data)
	}
	saveTeam(data) {
		return this.odata("/Yc_Mac_T_Actteam").post("activity", data)
	}
	getTimeEntryDefaults(params) {
		const options = this.getUrlParameters(params);
		return this.odata("/YC_ActTypeDefMpngSet").get("mtr", options)
	}
	 async getLevel2MasterData  () {
            const oResult = await this.odata("/YC_MD_SOL_M_LEVEL2").get("activity");
            return oResult.data.results;
        }

        async getLandscapes  () {
            const oResult = await this.odata("/YC_MAC_M_LANDSCAPES").get("activity");
            return oResult.data.results;
        }
		   async getActStatusMaster() {
            const oResult = await this.odata("/YC_MAC_M_ACT_STATUS").get("activity");
            return oResult.data.results;
        }
		  async getCVJPhaseMasterData(aFilter) {
            var mParameters = {
                filters: aFilter
            };
            const oResult = await this.odata("/YC_MAC_M_CVJ_PHASE").get("activity", mParameters);
            return oResult.data.results;
        }
		 async getRiskButtons () {
            const oResult = await this.odata("/Yc_Mac_M_Risk_Asses").get("activity");
            return oResult.data.results;
        }
		 	async  getUserActivityDays() {
            const oResult = await this.odata("/YC_MAC_M_USR_ACTDAYS_CHK").get("activity");
            return oResult.data.results;
        }
		 async getConstants() {
            const oResult = await this.odata("/Yc_Mac_M_Constants").get("activity");
            return oResult.data.results;
        }
		  async getRecentSelSolutionsData (aFilters) {
            	let mParameters = {
				filters: aFilters,
			};
            const oResult = await this.odata("/YC_MD_T_SOL_NODERECENT").get("melody",mParameters);
            return oResult?.data?.results??[];
        }
		  async getOreUsers(sQuery) {
            var mParameters = {
                urlParameters: {
                    search: sQuery
                }
            };
            const oResult = await this.odata("/Yc_MD_Usersearch").get("activity", mParameters);
            return oResult.data.results;
        }
		 async fnGetLayoutData(aFilters) {
            var mParameters = {
                filters: aFilters
            };
            const oResult = await this.odata("/YC_MAC_M_FORM_LAYOUT").get("activity", mParameters);
            return oResult.data.results;
        }
		 async fnGetActivityDetails (sActivityId, urlParams) {
            var aActIdFilter = [new Filter("ActivityId", "EQ", sActivityId)];
            var mParameters = {
                filters: aActIdFilter,
                urlParameters: urlParams
            };
            const oResult = await this.odata("/Yc_Mac_T_Act_Main").get("activity", mParameters);
            return oResult.data.results[0];
        }
		 async fnFetchActAssociations(sUrl, aFilters) {
            var mParameters = {
                filters: aFilters
            };
            const oResult = await this.odata(sUrl).get("activity", mParameters);
            return oResult.data.results;
        }
		async  getSolutionHierarchy(mParameters) {
            const oResult = await this.odata("/YC_MD_SOL_HIER").get("activity", mParameters);
            return oResult.data.results;
        }
		  async getSolHierarchyCount () {
            const oResponse = await this.odata("/YC_MD_SOL_HIER/$count").get("activity");
            return oResponse.data;
        }
		async getActivityTypes() {
            let mParameters = {
                filters: [new Filter("OperationStatus", "EQ", true)]
            };
            const oResult = await this.odata("/Yc_Mac_M_Activity_Type").get("activity", mParameters);
            return oResult.data.results;
        }

}
