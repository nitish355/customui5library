sap.ui.define([
	"com/melodylib/core/service/CoreService",
    "com/melodylib/activity/enum/Services"
], function (CoreService,Services) {
	"use strict";
    var ServiceHelper = CoreService.extend("com.melodylib.activity.service.ServiceHelper", {
        getSAPUsers:function(aFilters,urlParameters){
             var mParameters = {
				filters: aFilters ?? [],
                urlParameters:urlParameters
			};
            return this.odata(Services.GET_SAP_USERS).get("activityModel",mParameters);
        },
        getActLeadUsers: function (aFilters, sQuery) {
			var oParameters = {
				urlParameters: {
					search: sQuery
				},
				filters: aFilters
			};
			return this.odata(Services.GET_ORE_USERS).get("activityModel",oParameters);
		}
    });
    return new ServiceHelper();
});