sap.ui.define({
    GET_SAP_USERS:"/Yc_MD_Usersearch",
    GET_ORE_USERS:"/YC_MAC_M_USER_LIST"
},true)