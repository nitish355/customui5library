import * as UI5Object from "sap/ui/base/Object";
import ActivityService from "com/melodylib/activity/service/ActivityService";
import Activity from "com/melodylib/activity/classes/Activity";
import ActivityType from "com/melodylib/activity/classes/ActivityType"

/**
 * @name com.melodylib.activity.util.ActivityUtil
 */
export default class ActivityUtil extends UI5Object {
    constructor () {
        super();
        this._service = ActivityService.getInstance();
    }
    static getInstance() {
        if (!this.instance) {
            this.instance = new ActivityUtil();
        }
        return this.instance;
    }

    async getActivityList (params) {
        let activities = [];

        const { data } = await this._service.getActivityList(params);
        const results = data?.results;
        if(results.length > 0) {
            activities = Array.from(results, (activity) => new Activity(activity));
        }

        return activities;
    }
    async getActivityTypes () {
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let aActivityTypes = oStorage.get("activityTypes");
			if (!aActivityTypes) {
				aActivityTypes = [];
				const aResult = await ActivityService.getInstance().getActivityTypes();
				for (let i = 0; i < aResult.length; i++) {
					if (aResult[i].ActivityTypeId && aResult[i].ActivityTypeId !== "") {
						const oActivityType = new ActivityType({
							ActivityTypeId: aResult[i].ActivityTypeId,
							ActivityTypeName: aResult[i].Description
						});
						if (oActivityType.ActivityTypeName) {
							aActivityTypes.push(oActivityType);
						}
					}
				}
				oStorage.put("activityTypes", aActivityTypes);
			}
			return aActivityTypes;
		}

}