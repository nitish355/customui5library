import * as UI5Object from "sap/ui/base/Object";

/**
 * @name com.melodylib.activity.util.ActivityUtil
 */
export default class TimeEntries extends UI5Object {
    constructor () {
        super();
    }
    // static getInstance() {
    //     if (!this.instance) {
    //         this.instance = new ActivityUtil();
    //     }
    //     return this.instance;
    // }

   
}