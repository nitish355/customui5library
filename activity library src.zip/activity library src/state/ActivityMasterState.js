import BaseState from "com/melodylib/core/state/BaseState";
import ActivityMasterService from "com/melodylib/activity/service/ActivityMasterService";
import IndexedDB from "com/melodylib/core/db/IndexedDB";
import Filter from "sap/ui/model/Filter";
import FilterOperator from "sap/ui/model/FilterOperator";
import ActivityType from "com/melodylib/activity/classes/ActivityType";

/**
 * @name com.melodylib.activity.state.ActivityMasterState
 */
export default class ActivityMasterState extends BaseState {
	constructor() {
		super(ActivityMasterService.getInstance());
		this._data = {
			risks: [],
			statuses: [],
			dbrStatuses: [],
			dbrStatusReasons: [],
			landscapes: [],
			showrooms: [],
			innovations: [],
			types: [],
			dataCenters: [],
			associations: { 501: [], 502: [], 503: [] },
			busy: { // busy of type dependent data shd  be false initially for Drafts Scenario.
				landscapes: true,
				cvjPhases: false,
				methods: false,
				detailTypes: false,
				dataCenters: true,
				demoEducations: true,
				businessAreaEngaged: true
			},
			level2Data: [],
			solHierarchy: {},
			selectedAssociationTypes: []


		};
		this.setData(this._data);
	}

	static getInstance() {
		if (!this._instance) {
			this._instance = new ActivityMasterState();
		}
		return this._instance;
	}

	init() {
		let promises = [
			this.getActivityRisks(),
			this.getActivityStatuses(),
			this.getDBRStatuses(),
			this.getDBRStausReasons(),
			// this.getActivityRoles(),
			this.getActivityLandScapes(),
			this.getActivityShowrooms(),
			this.getActivityInnovations(),
			this.getActivityTypes(),
			this.getActivityDataCenters(),
			this.getDemoEducations(),
			this.getSolutionsLevel2Data(),
			this.getActivityRegions(),
			this.getBsnsAreaEngaged()
		];
		return Promise.allSettled(promises);
		// Promise.allSettled(promises)
		// 	.then((responses) => {
		// 		this._data.risks = responses[0].value;
		// 		this._data.statuses = responses[1].value;
		// 		this._data.roles = responses[2].value;
		// 		this._data.landscapes = responses[3].value;
		// 		this._data.showrooms = responses[4].value;
		// 		this._data.innovations = responses[5].value;
		// 		this.updateModel();
		// 	})
		// 	.catch(function (error) {
		// 		console.log("Error in MasterData: ", error);
		// 	});
	}

	async getActivityRisks() {
		let risks =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "actriskbuttons",
			})) || [];
		if (!risks.length) {
			let { data } = await this._service.getActivityRisks();
			const results = data?.results ?? [];
			risks = Array.from(results, (risk) => ({
				id: risk.ra_id,
				color: risk.colorcode,
				description: risk.description,
				status: risk.operation_status,
			}));

			IndexedDB.fnInsertDataToDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "actriskbuttons",
				aObjectsToInsert: risks,
			});
		}
		this._data.risks = risks;
		this.updateModel();
		return risks;
	}

	async getActivityStatuses() {
		let statuses =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "activityliststatus",
			})) || [];
		if (!statuses.length) {
			let { data } = await this._service.getActivityStatusList();
			const results = data?.results ?? [];
			statuses = Array.from(results, (status) => ({
				id: status.StatusId,
				description: status.StatusDesc,
				projectType: status.ProjectType,
				region: status.RegionHc,
			}));

			IndexedDB.fnInsertDataToDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "activityliststatus",
				aObjectsToInsert: statuses,
			});
		}
		this._data.statuses = statuses;
		this.updateModel();
		return statuses;
	}

	async getDBRStatuses() {
		let dbrStatuses =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "dbrliststatus",
			})) || [];
		if (!dbrStatuses.length) {
			let { data } = await this._service.getDBRStatusList();
			const results = data?.results ?? [];
			dbrStatuses = Array.from(results, (status) => ({
				id: status.StatusId,
				description: status.StatusDesc,
				projectType: status.ProjectType,
				status: status.opp_status,
			}));

			IndexedDB.fnInsertDataToDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "dbrliststatus",
				aObjectsToInsert: dbrStatuses,
			});
		}
		this._data.dbrStatuses = dbrStatuses;
		this.updateModel();
		return dbrStatuses;
	}

	async getDBRStausReasons() {
		let dbrStatusReasons =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "dbrliststatusreasons",
			})) || [];
		if (!dbrStatusReasons.length) {
			let { data } = await this._service.getDBRStatusReasonList();
			const results = data?.results ?? [];
			dbrStatusReasons = Array.from(results, (statusReason) => ({
				id: statusReason.StatusReasonId,
				description: statusReason.StatusReasonDesc,
				projectType: statusReason.ProjectType,
				status: statusReason.opp_status,
			}));

			IndexedDB.fnInsertDataToDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "dbrliststatusreasons",
				aObjectsToInsert: dbrStatusReasons,
			});
		}
		this._data.dbrStatusReasons = dbrStatusReasons;
		this.updateModel();
		return dbrStatusReasons;
	}

	// async getActivityDeliveryTeam() {
	// 	let deliveryTeam =
	// 		(await IndexedDB.fnGetAllDatafromDB({
	// 			dbName: "master-data",
	// 			storeName: "master-data-table",
	// 			keyName: "activitydelteam",
	// 		})) || [];
	// 	if (!deliveryTeam.length) {
	// 		let { data } = await this._service.getActivityDeliveryTeam();
	// 		const results = data?.results ?? [];
	// 		deliveryTeam = Array.from(results, (del) => ({
	// 			id: del.DelTeamId,
	// 			typeId: del.ActivityTypeId,
	// 			description: del.DelTeam,
	// 			status: del.OperationStatus,
	// 		}));

	// 		IndexedDB.fnInsertDataToDB({
	// 			dbName: "master-data",
	// 			storeName: "master-data-table",
	// 			keyName: "activitydelteam",
	// 			aObjectsToInsert: deliveryTeam,
	// 		});
	// 	}
	// 	this._data.deliveryTeam = deliveryTeam;
	// 	this.updateModel();
	// 	return deliveryTeam;
	// }

	// async getActivityHostTypes() {
	// 	let hostTypes =
	// 		(await IndexedDB.fnGetAllDatafromDB({
	// 			dbName: "master-data",
	// 			storeName: "master-data-table",
	// 			keyName: "activityhosttype",
	// 		})) || [];
	// 	if (!hostTypes.length) {
	// 		let { data } = await this._service.getActivityHostTypes();
	// 		const results = data?.results ?? [];
	// 		hostTypes = Array.from(results, (hostType) => ({
	// 			id: hostType.HostTypeId,
	// 			typeId: hostType.ActivityTypeId,
	// 			description: hostType.HostTypeDesc,
	// 			status: hostType.OperationStatus,
	// 		}));

	// 		IndexedDB.fnInsertDataToDB({
	// 			dbName: "master-data",
	// 			storeName: "master-data-table",
	// 			keyName: "activityhosttype",
	// 			aObjectsToInsert: hostTypes,
	// 		});
	// 	}
	// 	this._data.hostTypes = hostTypes;
	// 	this.updateModel();
	// 	return hostTypes;
	// }

	async getActivityLandScapes() {
		let landscapes =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "landscapes",
			})) || [];
		if (!landscapes.length) {
			let { data } = await this._service.getActivityLandScapes();
			const results = data?.results ?? [];
			landscapes = results.map((item) => {
				return {
					id: item.LandsId,
					description: item.LandDescription,
					type: item.Ltype,
					typeDescription: item.LTypeDescription,
					landscapeId: item.LandscapeId,
					product: item.Product,
					location: item.Location,
					category: item.SelectionCat,
				};
			});

			IndexedDB.fnInsertDataToDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "landscapes",
				aObjectsToInsert: landscapes,
			});
		}
		let tree = this.convertArrayToTree(landscapes, "category");
		this._data.landscapes = { list: landscapes, tree };
		this.updateModel();
		return landscapes;
	}

	convertArrayToTree(data, groupByProperty) {
		let tree = [];
		let groupedData = {};
		data.forEach((item) => {
			let groupBy = item[groupByProperty];
			if (!groupedData[groupBy]) {
				groupedData[groupBy] = {
					isParent: true,
					isExpanded: true,
					groupBy: groupBy,
					data: [],
				};
			}
			groupedData[groupBy].data.push(item);
		});
		for (let each in groupedData) {
			tree.push(groupedData[each]);
		}
		return tree;
	}
	async getDemoEducations() {
		let demoEducations =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "demoEducations",
			})) || [];
		if (!demoEducations.length) {
			let { data } = await this._service.getDemoEducations();
			const results = data?.results ?? [];
			demoEducations = results.map((item) => {
				return {
					id: item.LandsId,
					description: item.LandDescription,
					type: item.Ltype,
					typeDescription: item.LTypeDescription,
					landscapeId: item.LandscapeId,
					product: item.Product,
					location: item.Location,
					category: item.SelectionCat,
				};
			});

			IndexedDB.fnInsertDataToDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "demoEducations",
				aObjectsToInsert: demoEducations,
			});
		}
		let tree = this.convertArrayToTree(demoEducations, "category");
		this._data.demoEducations = { list: demoEducations, tree };
		this.setBusy("demoEducations", false);
		this.updateModel();
		return demoEducations;
	}

	// async getActivityProjectTypes() {
	// 	let projectTypes =
	// 		(await IndexedDB.fnGetAllDatafromDB({
	// 			dbName: "master-data",
	// 			storeName: "master-data-table",
	// 			keyName: "activityprojtype",
	// 		})) || [];
	// 	if (!projectTypes.length) {
	// 		let { data } = await this._service.getActivityProjectTypes();
	// 		const results = data?.results ?? [];
	// 		projectTypes = Array.from(results, (projectType) => ({
	// 			id: projectType.ProjectId,
	// 			typeId: projectType.ActivityTypeId,
	// 			description: projectType.ProjectDesc,
	// 			status: projectType.OperationStatus,
	// 		}));

	// 		IndexedDB.fnInsertDataToDB({
	// 			dbName: "master-data",
	// 			storeName: "master-data-table",
	// 			keyName: "activityprojtype",
	// 			aObjectsToInsert: projectTypes,
	// 		});
	// 	}
	// 	this._data.projectTypes = projectTypes;
	// 	this.updateModel();
	// 	return projectTypes;
	// }

	// async getActivityRegions() {
	// 	let regions =
	// 		(await IndexedDB.fnGetAllDatafromDB({
	// 			dbName: "master-data",
	// 			storeName: "master-data-table",
	// 			keyName: "activityregion",
	// 		})) || [];
	// 	if (!regions.length) {
	// 		let { data } = await this._service.getActivityRegions();
	// 		const results = data?.results ?? [];
	// 		regions = Array.from(results, (region) => ({
	// 			id: region.id,
	// 			description: region.region,
	// 		}));

	// 		IndexedDB.fnInsertDataToDB({
	// 			dbName: "master-data",
	// 			storeName: "master-data-table",
	// 			keyName: "activityregion",
	// 			aObjectsToInsert: regions,
	// 		});
	// 	}
	// 	this._data.regions = regions;
	// 	this.updateModel();
	// 	return regions;
	// }

	async getActivityShowrooms() {
		let showrooms =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "activityShowroom",
			})) || [];
		if (!showrooms.length) {
			let { data } = await this._service.getActivityShowrooms();
			const results = data?.results ?? [];
			showrooms = Array.from(results, (showroom) => ({
				id: showroom.Description,
				description: showroom.Description,
			}));

			IndexedDB.fnInsertDataToDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "activityShowroom",
				aObjectsToInsert: showrooms,
			});
		}
		this._data.showrooms = showrooms;
		this.updateModel();
		return showrooms;
	}

	// async getActivityUseCases() {
	// 	let usecases =
	// 		(await IndexedDB.fnGetAllDatafromDB({
	// 			dbName: "master-data",
	// 			storeName: "master-data-table",
	// 			keyName: "activityUseCase",
	// 		})) || [];
	// 	if (!usecases.length) {
	// 		let { data } = await this._service.getActivityUseCases();
	// 		const results = data?.results ?? [];
	// 		usecases = Array.from(results, (usecase) => ({
	// 			id: usecase.UseCaseId,
	// 			typeId: usecase.ActivityTypeId,
	// 			description: usecase.UseCase,
	// 			status: usecase.OperationStatus,
	// 		}));

	// 		IndexedDB.fnInsertDataToDB({
	// 			dbName: "master-data",
	// 			storeName: "master-data-table",
	// 			keyName: "activityUseCase",
	// 			aObjectsToInsert: usecases,
	// 		});
	// 	}
	// 	this._data.usecases = usecases;
	// 	this.updateModel();
	// 	return usecases;
	// }

	async getActivityInnovations() {
		let innovations =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "activityInnovations",
			})) || [];
		if (!innovations.length) {
			let { data } = await this._service.getActivityInnovations();
			const results = data?.results ?? [];
			innovations = Array.from(results, (innovation) => ({
				id: innovation.StrSolId,
				description: innovation.Description,
				status: innovation.OperationStatus,
			}));

			IndexedDB.fnInsertDataToDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "activityInnovations",
				aObjectsToInsert: innovations,
			});
		}
		this._data.innovations = innovations;
		this.updateModel();
		return innovations;
	}

	// async getActivityRoles() {
	// 	let { data } = await this._service.getActivityRoles();
	// 	const results = data?.results ?? [];
	// 	let roles = Array.from(results, (role) => ({
	// 		id: role.RoleID,
	// 		description: role.RoleDesc,
	// 		default: role.DefaultRole,
	// 		mappingId: role.RoleMpngID,
	// 	}));

	// 	this._data.roles = roles;
	// 	this.updateModel();
	// 	return roles;
	// }
	setBusy(property, busy) {
		this._data.busy[property] = busy;
	}
	async getActivityTypes() {
		// await fetch types master
		let allTypes = await this._service.getAllActivityTypes();
		this._data.types = allTypes?.data?.results?.map(
			(type) =>
				new ActivityType({
					ActvtTypeID: type.ActivityTypeId,
					ActvtTypeDesc: type.Description,
				})
		);
		const params = {
			filters: [
				new Filter("ActivtyTypeCatznID", FilterOperator.EQ, "0001"),
				new Filter("operation_status", FilterOperator.EQ, true),
			],
		};
		let { data } = await this._service.getActivityTypes(params);
		let types = data?.results ?? [];
		types.forEach((obj) => {
			let type = this._data.types.find((each) => each.id === obj.ActvtTypeID);
			if (!type) {
				type = new ActivityType(obj);
				this._data.types.push(type);
			} else {
				type.setLayout(obj.FormLayoutID, obj.ChildFrmLayoutId); // since this data is not coming in getAllActivityTypes
				type.setInfo(obj.ActivityTypeInfo);
			}
			let key = obj.ActvtAsstdID;
			let index = this._data.associations[key].findIndex(
				(each) => each.id === type.id
			);
			if (index === -1) this._data.associations[key].push(type);
			type.setActive(true);
		});
		this._data.selectedAssociationTypes = this._data.associations['501']
		this.updateModel();
		return this._data.associations;
	}

	async getUsersBySearch(params) {
		let { data } = await this._service.getUsersBySearch(params);
		const results = data?.results || [];
		let users = Array.from(results, (user) => ({
			id: user.ID,
			name: user.NAME_FIRST + user.NAME_LAST,
		}));
		return users;
	}


	async getSolutionsLevel2Data() {
		let filters = [new Filter("ProjectType", "EQ",'ACTVT')];
		const params = { filters }
		let { data } = await this._service.getSolutionsLevel2Data(params);
		const results = data?.results || [];
		let solutions = Array.from(results, (each) => ({
			id: each.SolnId,
			guid: each.SolGuid,
			name: each.SolName
		}));
		this._data.level2Data = solutions;
		this.updateModel()
		this.getSolHierarchyById(solutions[0].guid);
		return solutions;
	}

	async getSolHierarchyById(guid) {
		if (!this._data.solHierarchy[guid]) {
			var params = {
				expand: "to_Child"
			};
			const { data } = await this._service.getSolHierarchyById(params, guid);
			let solHierarchy = data?.to_Child?.results?.length ? data.to_Child.results : [];
			solHierarchy = solHierarchy.map(function (item) {
				return {
					guid: item.soln_guid,
					id: item.soln_id,
					name: item.soln_name,
					parentGuid: item.soln_prnt_guid,
					levels: item.is_final ? [] : [{
						name: "Loading..."
					}]
				}
			});
			this._data.solHierarchy[guid] = solHierarchy;
			this.updateModel()
		}
		return this._data.solHierarchy[guid];
	}
	async getActivityCVJPhase(type, roleMappingId) {
		this.setBusy("cvjPhases", true);

		if (!type?.cvjPhases) {
			let filters = [];
			if (type.id) {
				filters.push(new Filter("Acttypeid", "EQ", type.id));
			}
			if (roleMappingId) {
				filters.push(new Filter("RoleMpngID", "EQ", roleMappingId));
			}
			const params = { filters };
			let { data } = await this._service.getActivityCVJPhase(params);
			type.cvjPhases = data?.results?.map((each) => {
				return {
					id: each.CvjPhaseId,
					description: each.CvjPhaseDesc,
					sortOrder: each.SortOrder,
				};
			});
		}
		this.setBusy("cvjPhases", false);
		this.updateModel();
		return type?.cvjPhases || [];
	}

	async getMethodsByType(type) {
		this.setBusy("methods", true);
		let params = { filters: [new Filter("acttypeid", "EQ", type.id)] };
		if (!type.methods) {
			let { data } = await this._service.getMethodsByType(params);
			type.methods = data?.results?.map((each) => {
				return {
					id: each.methodid,
					status: each.operation_status,
					description: each.description,
				};
			});
		}
		this.setBusy("methods", false);
		this.updateModel();
		return type?.methods || [];
	}

	async getActivityDetailTypes(type) {
		this.setBusy("detailTypes", true);
		let params = { filters: [new Filter("ActTypeId", "EQ", type.id)] };
		if (!type.detailTypes) {
			let { data } = await this._service.getActivityDetailTypes(params);
			type.detailTypes = data?.results?.map((each) => {
				return {
					id: each.TypeId,
					description: each.Description,
				};
			});
		}
		this.setBusy("detailTypes", false);
		this.updateModel();
		return type?.detailTypes || [];
	}

	async getActivityDataCenters() {
		let { data } = await this._service.getActivityDataCenters();
		let dataCenters = data?.results?.map((each) => {
			return {
				id: each.dc_id,
				description: each.description,
				status: each.operation_status,
			};
		});
		this._data.dataCenters = dataCenters;
		this.setBusy("dataCenters", false);
		this.updateModel();
		return dataCenters;
	}



	// async getDataByTypeId(activity) {
	// 	debugger;
	// 	if (activity?.type) {
	// 		this.getMethodsByTypeId(activity.type.id);
	// 		this.getActivityCVJPhase(activity.type.id, activity?.role?.mappingId)
	// 	}
	// 	// Promise.allSettled(promises).then(([methods, cvjPhases]) => {
	// 	// 	activity.setDetail({ type: { ...activity.type, methods: methods?.value, cvjPhases: cvjPhases?.value } })

	// 	// 	this.updateModel()
	// 	// })
	// }

	async getActivityRegions() {
		let { data } = await this._service.getActivityRegions();
		let regions = data?.results?.map((each) => {
			return {
				region: each.Region,
				subRegion: each.SubRegion,
				isDefault: each.IsDefault,
				profitCenter: each.ProfitCenter
			};
		});
		let regionMap = {};
		regions.forEach(each => {
			if (!regionMap[each.region]) {
				each.marketUnits = [{ marketUnit: each.subRegion }]
				regionMap[each.region] = each
			}
			else {
				regionMap[each.region].marketUnits.push({ marketUnit: each.subRegion });
			}
		})
		let filteredRegions = Object.values(regionMap)
		this._data.regions = filteredRegions;
		this.updateModel();
		return filteredRegions;
	}

	async getBsnsAreaEngaged(type) {
		let params = { filters: [new Filter("ActvtTypeID", "EQ", type.id)] };
		if (!type.businessAreaEngaged) {
			let { data } = await this._service.getBsnsAreaEngaged(params);
			type.businessAreaEngaged = data?.results?.map((each) => {
				return {
					type: each.ActvtTypeID,
					description: each.BsnsAreaEngdDesc,
					id: each.BsnsAreaEngdID

				};
			});
		}
		this.setBusy("businessAreaEngaged", false);
		this.updateModel();
		return type?.businessAreaEngaged || [];

	}
}
