import Filter from "sap/ui/model/Filter";
import Helper from "com/melodylib/core/util/Helper";
import FilterOperator from "sap/ui/model/FilterOperator";
import AuthState from "com/melodylib/core/state/AuthState";
import BaseState from "com/melodylib/core/state/BaseState";
import Activity from "com/melodylib/activity/classes/Activity";
import * as CoreActions from "com/melodylib/core/enum/Actions";
import VariantState from "com/melodylib/core/state/VariantState";
import ActivityService from "com/melodylib/activity/service/ActivityService";
import OpportunityState from "com/melodylib/integration/state/OpportunityState";
import ActivityMasterState from "com/melodylib/activity/state/ActivityMasterState";
import VATTeamUtil from "com/melodylib/integration/util/opportunity/VATTeamUtil";
import Fragment from "sap/ui/core/Fragment";
import MessageBox from "sap/m/MessageBox";
import StatusBox from "com/melodylib/core/StatusBox";
import IndexedDB from "com/melodylib/core/db/IndexedDB";
// import Entry from "com/melodylib/time/classes/Entry";
// import TimeState from "com/melodylib/time/state/TimeState";
/**
 * @name com.melodylib.activity.state.ActivityState
 */
export default class ActivityState extends BaseState {
	constructor() {
		super(ActivityService.getInstance());
		const data = {
			activities: [],
			loading: true,
			totalActivities: 0,
			openedActivities: [],
			draftActivities: [],
			saveProcess: []
		};
		this.setData(data);
		this.opportunityState = OpportunityState.getInstance();
		this.activityMasterState = ActivityMasterState.getInstance();
		this.variantState = VariantState.getInstance();
		this.VATTeam = VATTeamUtil.getInstance();
		this.timeState = com.melodylib.time.state.TimeState.getInstance();
		this.targetHourState = com.melodylib.time.state.TargetHourState.getInstance();
		this.dateService = com.melodylib.core.service.DateService.getInstance();
		let { Entry } = com.melodylib.time.classes.Entry;
		this.Entry = Entry;
		let { Settings } = com.melodylib.time.classes.Settings;
		this.Settings = Settings;
	}

	static getInstance() {
		if (!this._instance) {
			this._instance = new ActivityState();
		}
		return this._instance;
	}

	async init(variantOption) {
		/* await this.activityMasterState.init();
		this.getActivities(); */

		let defaultVariant = await this.variantState.getDefaultVariant(
			variantOption
		);

		const params = defaultVariant ? defaultVariant.configurations : {};
		params.inlineCount = true;

		let isManager = defaultVariant.checkForManagerVariant();

		const promises = [
			this.getActivities(params, isManager),
			this.activityMasterState.init(),
		];

		Promise.allSettled(promises).then((results) => {
			let isSucceeded = true;
			results.forEach((result) => {
				if (result.status !== "fulfilled") {
					isSucceeded = false;
				}
			});
			if (isSucceeded) {
				this.updateAssociation();
			}
		});
	}

	updateAssociation() {
		const activities = this.getData().activities;
		for (let i = 0; i < activities.length; i++) {
			activities[i].updateAssociation();
		}
		this.updateModel();
	}

	async getActivities(params, isManager) {
		this.setLoading(true);
		const options = Helper.getFilters(params);
		const { data } = await this._service.getActivityList(options, isManager);
		const results = data?.results || [];

		let activities = Array.from(results, (activity) => new Activity(activity));

		if (params && "inlineCount" in params && params.inlineCount) {
			this._data.activities = [];
			this._data.totalActivities = "__count" in data ? data.__count : "0";
		}
		if (this._data && this._data.activities.length && activities.length) {
			const concatArr = [...this._data.activities, ...activities];
			activities = [
				...new Map(
					concatArr.map((obj) => [`${obj.id}:${obj.guid}`, obj])
				).values(),
			];
		}
		this._data.activities = activities;
		this.getActivityListCounts(isManager);
		this.setOpportunity();
		this.setLoading(false);
		return this.getData();
	}

	async getActivityListCounts(isManager) {
		let includeTeamFlag = isManager ? "X" : "";
		const { data } = await this._service.getActivityListCounts(includeTeamFlag);
		const activities = this.getData().activities;
		const results = data.results;
		for (let i = 0; i < results.length; i++) {
			const activity = activities.find(
				(a) => a.guid === results[i].ActivityGUID
			);
			if (activity) {
				activity.setCounts(results[i]);
				activity.setBusy("count", false);
			}
		}

		this.updateModel();
		return data;
	}

	setLoading(isLoading) {
		this.getData().loading = isLoading ? true : false;
		this.updateModel();
	}

	setOpportunity() {
		const opportunities = this.opportunityState.getOpportunities();
		const activities = this.getData().activities;
		for (let i = 0; i < activities.length; i++) {
			const opportunity = opportunities.find(
				(item) => item.id === activities[i].opportunity.id
			);
			activities[i].setOpportunity(opportunity);
			if (opportunity) {
				activities[i].setAccount(opportunity.account);
			}
			activities[i].busy.account = false;
		}
		this.updateModel();
	}
	async setOpportunityTeam(activity) {
		let { data } = await this.opportunityState.getOpportunitiesTeam(activity.opportunity.id);
		let team = data.PartiesInvolved?.results?.map(user => {
			return {
				id: user.USER_ID,
				name: user.NAME,
				email: user.EMAIL,
				roleDescription: user.ROLE_DESCR
			}
		})
		activity.opportunity.team = team;
		this.updateModel()
	}
	async getActivityById(activityId) {
		const activity = this._data.activities?.find((a) => a.id === activityId);
		this._data.openedActivities = [activity];
		this.updateModel();
		this.getActivityDetail(activityId);
	}
	async getActivityDetail(activityId) {
		if (!activityId) {
			return null;
		} else {
			activityId = parseInt(activityId, 10).toString();
		}
		// let activity = this._data.activities?.find(a => parseInt(a.id, 10) === parseInt(activityId, 10));

		const params = {
			filters: [new Filter("ActivityId", FilterOperator.EQ, activityId)],
		};
		const { data } = await this._service.getActivityDetail(params);

		let activity = new Activity();
		if (data?.results?.length) {
			activity.setData({
				...data.results[0],
				ActivityId: data.results[0].ActivityId,
				OpportunityId: data.results[0].OpportunityNumber,
				ActivityGUID: data.results[0].ActivityGuid,
				ActAsstId: data.results[0].ActvtAsstdID,
				RiskId: data.results[0].RiskAssessId,
				ActStatus: data.results[0].Status,
				ActivityLeadEmail: data.results[0].ActivityLeadEmailId
			});
		}
		this.setOpportunityTeam(activity)
		// let promises = [this.getEntities(guid, typeId), this.getTypeInfo(typeId, roleMappingId), this.getFieldsLayout(childFormLayoutId)]
		//  Promise.allSettled(promises).then(([entities, typeInfo, fieldsLayout]) => {
		//     //create setDetail  to set entities , type info , fieldslayput
		//     activity.setData({
		//         ...data.results[0],
		//         ActivityId: data.results[0].ActivityId,
		//         OpportunityId: data.results[0].OpportunityNumber,
		//         ActivityGUID: data.results[0].ActivityGuid,
		//         ActTypeDesc: data.results[0].ActivityTypeDescription,
		//         ActAsstId: data.results[0].ActvtAsstdID,
		//         fieldsLayout: fieldsLayout.value,
		//         ActivityTypeInfo: typeInfo.value,
		//         entities: entities.value,

		//     })

		// })

		// fetch activitytypeinfo from activitytypes
		// setdetail here instead of set data
		// activity.setData({ ...data.results[0], ActivityId: data.results[0].ActivityId, OpportunityId: data.results[0].OpportunityNumber, ActivityGUID: data.results[0].ActivityGuid, ActTypeDesc: data.results[0].ActivityTypeDescription, ActAsstId: data.results[0].ActvtAsstdID, fieldsLayout, ActivityTypeInfo: typeInfo, RiskId: data.results[0].RiskAssessId })
		this._data.openedActivities = [activity];
		this.updateModel();
		this.getTypeDataByActivityId(activity.id);
		this.getUserTimeMatrics(activity.id);
		return activity;
	}

	async getEntities(guid, type) {
		if (!type.entities.length) {
			const params = {
				filters: [new Filter("ActivityTypeId", "EQ", type.id)],
			};
			const { data } = await this._service.getEntitiyString(params);
			const entityString = data?.results?.length
				? data?.results[0].EntityString
				: "";
			const entities = entityString?.split(",") || [];
			type.setEntities(entities);
		}
		type.entities?.forEach((entity) => {
			switch (entity) {
				case "YC_MAC_T_FILE_CONTENT":
					this.getFiles(guid);
					break;
				case "Yc_Mac_T_Actteam":
					this.getTeamMembers(guid);
					break;
				case "Yc_Mac_T_Activity_Details_Type":
					this.getDetailTypes(guid);
					break;
				// case "YC_MAC_T_PHASE":
				// 	this.getCVJPhases(guid);
				// 	break;
				case "Yc_Mac_T_Landscapes":
					this.getLandscapes(guid);
					break;
				case "Yc_Mac_T_Success_F":
					this.getSuccessFactors(guid);
					break;
				case "Yc_Mac_T_Cloud_Env":
					this.getCloudEnvironments(guid);
					break;
				case "Yc_Mac_T_Solution":
					this.getSolutions(guid);
					break;

				case "YC_MAC_T_SOL_MTRL":
					this.getMaterials(guid);
					break;
				case "YC_MAC_T_ADD_OPP":
					this.getAddOpportunities(guid);
					break;


			}
		});
		// return entities;
		// const activity = this._data.activities.find(a => a.guid === guid);
		// activity.setDetail({ type: { ...activity.type, entities } })

		// model.refresh(true)
		this.updateModel();
	}

	async getFiles(guid) {
		const params = { filters: [new Filter("ActivityGuid", "EQ", guid)] };
		const { data } = await this._service.getCountData(params, "files");
		let files = data?.results?.map((file) => {
			return {
				url: file.Url,
				id: file.FileId,
				name: file.FileName,
			};
		});
		const activity = this._data.openedActivities.find((a) => a.guid === guid);
		activity.setCountData("files", files);
		activity.setBusy("files", false);
		this.updateModel();
	}

	async getTeamMembers(guid, list) {
		const params = { filters: [new Filter("ActivityGuid", "EQ", guid)] };
		const { data } = await this._service.getCountData(params, "team");
		const activities = list
			? this._data.activities
			: this._data.openedActivities;
		const activity = activities.find((a) => a.guid === guid);
		let team = data?.results?.map((user) => {
			return {
				id: user.ID,
				name: user.NAME,
				initials: activity?.generateInitials(user.NAME),
				email: user.EMAIL,
			};
		});
		activity.setCountData("team", team);
		activity.setBusy("count", false);
		activity.setBusy("team", false);
		this.updateModel();
		return team;
	}

	async getDetailTypes(guid) {
		const params = { filters: [new Filter("ActivityGuid", "EQ", guid)] };
		const { data } = await this._service.getCountData(params, "detailTypes");
		let detailTypes = data?.results?.map((each) => {
			return {
				id: each.TypeId,
				description: each.Description,
			};
		});
		const activity = this._data.openedActivities.find((a) => a.guid === guid);
		activity.setDetail({ detailTypes: detailTypes });
		activity.setBusy("detailTypes", false);
		this.updateModel();
	}

	async getCVJPhases(guid) {
		const params = { filters: [new Filter("ActivityGuid", "EQ", guid)] };
		const { data } = await this._service.getCountData(params, "cvjPhases");
		let phases = data?.results?.map((phase) => {
			return {
				url: phase.Url,
				id: phase.FileId,
				name: phase.FileName,
			};
		});
		const activity = this._data.openedActivities.find((a) => a.guid === guid);
		activity.setDetail({ cvjPhases: phases });
		activity.setBusy("cvjPhases", false);
		this.updateModel();
	}

	async getLandscapes(guid) {
		const params = { filters: [new Filter("ActivityGuid", "EQ", guid)] };
		const { data } = await this._service.getCountData(params, "landscapes");
		let landscapes = data?.results?.map((each) => {
			return {
				id: each.LandsId,
				description: each.LandDescription,
				type: each.Ltype,
				typeDescription: each.LTypeDescription,
				landscapeId: each.LandscapeId,
				location: each.Location,
				product: each.Product,
				operationStatus: each.OperationStatus
			};
		});
		const activity = this._data.openedActivities.find((a) => a.guid === guid);
		activity.setCountData("landscapes", landscapes);
		activity.setBusy("landscapes", false);
		this.updateModel();
	}

	async getSuccessFactors(guid) {
		const params = { filters: [new Filter("ActivityGuid", "EQ", guid)] };
		const { data } = await this._service.getCountData(params, "successFactors");
		let successFactors = data?.results?.map((each) => {
			return {
				dataCenter: {
					id: each.DCId,
					description: each.DCDesc,
				},
				company: each.CompName,
				username: each.Username,
				password: each.AccessKey,
			};
		});
		const activity = this._data.openedActivities.find((a) => a.guid === guid);
		activity.setCountData("successFactors", successFactors);
		activity.setBusy("successFactors", false);
		this.updateModel();
	}

	async getCloudEnvironments(guid) {
		const params = { filters: [new Filter("ActivityGuid", "EQ", guid)] };
		const { data } = await this._service.getCountData(
			params,
			"cloudEnvironments"
		);
		let cloudEnvironments = data?.results?.map((each) => {
			return {
				instance: each.Instance,
				description: each.Description,
			};
		});
		const activity = this._data.openedActivities.find((a) => a.guid === guid);
		activity.setCountData("cloudEnvironments", cloudEnvironments);
		activity.setBusy("cloudEnvironments", false);
		this.updateModel();
	}

	async getSolutions1(guid) {
		const { data } = await this._service.getSolutions(guid);
		let guids = []
		data.results?.map(each => {
			let sol = {
				guid: each.soln_guid,
				description: each.SolutionDesc,
				isMaterial: false
			};
			guids.push(sol.guid)
		})
		const activity = this._data.openedActivities.find((a) => a.guid === guid);
		if (activity.association.id === "502") {
			let { data } = await this.opportunityState.getOpportunitiesTeam(activity.opportunity.id);
			let oppoMaterialsMap = {};
			data.Items.results?.forEach(each => {
				each = { id: each.PRODUCT_ID, name: each.PRODUCT_DESCR }
				oppoMaterialsMap[each.id] = each
			})
			activity.oppoMaterials = oppoMaterialsMap;
		}
		let hierarchyList = await this.getHierarchyByGuid(guids);
		let selectedSolsMap = activity.solHierarchyMap;
		let displayTokens = [];
		displayTokens = displayTokens.concat(activity.solutions.results);
		let materialPromises = [];
		for (let i = 0; i < hierarchyList.length; i++) {
			hierarchyList[i].selected = true;
			selectedSolsMap.set(hierarchyList[i].guid, hierarchyList[i]);
			if (hierarchyList[i].isFinal) {
				displayTokens.push(hierarchyList[i]);
				materialPromises.push(this.getMaterialsById(hierarchyList[i].guid))
			};
		}
		let materialsMap = {};
		activity.solutions.results.forEach(each => { if (each.isMaterial) materialsMap[each.id] = each })
		let materials = [];
		if (activity.oppoMaterials) {
			Object.values(activity.oppoMaterials).forEach(each => {
				if (!materialsMap[each.id]) materials.push({ ...each, isOpportunity: true });
			})
		}
		Promise.allSettled(materialPromises).then((responses) => {
			responses.forEach(each => materials = materials.concat(each.value));
			materials.forEach(each => {
				each.isMaterial = true;
				if (materialsMap[each.id]) {
					each.selected = true;
				}
				if (activity.oppoMaterials && activity.oppoMaterials[each.id]) each.isOpportunity = true;
			})
			activity.materials = materials;
		})
		activity.setCountData("solutions", displayTokens);
		this.updateModel();
		// fetch all children and updating selected propety 
		// Also create opportunity sol hierachy tree
		let promises = []
		for (let i = 0; i < hierarchyList.length; i++) {
			let node = selectedSolsMap.get(hierarchyList[i].guid);
			if (!node.isFinal) {
				promises.push(this.activityMasterState.getSolHierarchyById(node.guid))
			}
			const parent = selectedSolsMap.get(node.parentGuid);
			if (parent) {
				parent.levels.push(node);
			} else {
				activity.solLevel = node;
				// oppoSolHierarchy.push(node);
			}
		}
		let that = this;
		Promise.allSettled(promises)
			.then((responses) => {
				responses.forEach(each => {
					let levels = each.value

					levels = levels.map(each => {
						if (selectedSolsMap.get(each.guid)) {
							// levels[j].selected = true;
							each = selectedSolsMap.get(each.guid)
						}
						selectedSolsMap.set(each.guid, each)
						return selectedSolsMap.get(each.guid)
					})
					selectedSolsMap.get(levels[0].parentGuid).levels = levels;
				})

				// setting partial selections
				displayTokens.forEach(each => {
					// that.updatePartialSelections(selectedSolsMap, each)
					that.updateParentSelections(selectedSolsMap, each)

				})
				activity.solHierarchyMap = selectedSolsMap;
				this.updateModel()

			})
			.catch(function (error) {

			});
		let oppoHierarchyList = await this.getHierarchyByMaterials(Object.values(activity.oppoMaterials));
		let oppoSolHierarchy = [], oppoHierarchyMap = new Map();
		oppoHierarchyList.forEach(each => oppoHierarchyMap.set(each.guid, each))
		oppoHierarchyList.forEach(node => {
			const parent = oppoHierarchyMap.get(node.parentGuid);
			if (selectedSolsMap.get(node.guid)) node.selected = selectedSolsMap.get(node.guid).selected;
			else selectedSolsMap.set(node.guid, node);
			if (parent) {
				parent.levels.push(node);
			} else {
				oppoSolHierarchy.push(node);
			}
		});
		activity.oppSolHierarchy = structuredClone(oppoSolHierarchy);
		this.updateModel();
	}

	async getSolutions(guid) {
		const { data } = await this._service.getSolutions(guid);
		let guids = []
		data.results?.map(each => {
			let sol = {
				guid: each.soln_guid,
				description: each.SolutionDesc,
				isMaterial: false
			};
			guids.push(sol.guid)
		});
		this.setSolutionHierarchy("EDIT", guid, guids)
	}

	async setSolutionHierarchy(mode, guid, solGuids) {
		const activity = this._data.openedActivities.find(each => each.guid === guid);
		if (activity.association.id === '502' || mode === "CREATE") {
			let { data } = await this.opportunityState.getOpportunitiesTeam(activity.opportunity.id);
			let oppoMaterialsMap = {};
			data.Items.results?.map(each => {
				each = { id: each.PRODUCT_ID, name: each.PRODUCT_DESCR }
				oppoMaterialsMap[each.id] = each
			})
			activity.oppoMaterials = oppoMaterialsMap;
		}
		let hierarchyList = [], displayTokens = [], materialPromises = [],
			selectedSolsMap = activity.solHierarchyMap, materialsMap = {}, materials = [], oppoSolHierarchy = [];
		if (mode === "EDIT") {
			hierarchyList = await this.getHierarchyByGuid(solGuids);
			displayTokens = displayTokens.concat(activity.solutions.results);
			activity.solutions.results.forEach(each => { if (each.isMaterial) materialsMap[each.id] = each })
			if (activity.oppoMaterials) {
				Object.values(activity.oppoMaterials).forEach(each => {
					if (!materialsMap[each.id]) materials.push({ ...each, isOpportunity: true });
				})
			}
		}
		else if (mode === "CREATE") {
			hierarchyList = await this.getHierarchyByMaterials(Object.values(activity.oppoMaterials));
		}
		for (let i = 0; i < hierarchyList.length; i++) {
			hierarchyList[i].selected = true;
			selectedSolsMap.set(hierarchyList[i].guid, hierarchyList[i]);
			// if (hierarchyList[i].isFinal && mode === "CREATE") {
			// 	displayTokens.push(hierarchyList[i]);
			// 	materialPromises.push(this.getMaterialsById(hierarchyList[i].guid))
			// }
			if (mode === "CREATE" && hierarchyList[i].matId == "X") {
				displayTokens.push(hierarchyList[i]);
				materialPromises.push(this.getMaterialsById(hierarchyList[i].guid))
			}
		}
		if (solGuids && mode === "EDIT") {
			solGuids.forEach(each => {
				displayTokens.push(selectedSolsMap.get(each))
				materialPromises.push(this.getMaterialsById(each))
			})
		}
		// Promise.allSettled(materialPromises).then((responses) => {
		// 	responses.forEach(each => materials = materials.concat(each.value));
		// 	materials.forEach(each => {
		// 		each.isMaterial = true;
		// 		if (materialsMap[each.id]) {
		// 			each.selected = true;
		// 		}
		// 		if (activity.oppoMaterials && activity.oppoMaterials[each.id]) each.isOpportunity = true;
		// 	})
		// 	activity.materials = materials;
		// 	this.updateModel();
		// })
		activity.setCountData("solutions", displayTokens);
		activity.setBusy("solutions", false);
		this.updateModel();

		let promises = []
		for (let i = 0; i < hierarchyList.length; i++) {
			let node = selectedSolsMap.get(hierarchyList[i].guid);
			if (!node.isFinal) {
				promises.push(this.activityMasterState.getSolHierarchyById(node.guid))
			}
			const parent = selectedSolsMap.get(node.parentGuid);
			if (parent) {
				parent.levels.push(node);
			} else {

				if (mode === "CREATE") oppoSolHierarchy.push(node);
				else activity.solLevel = node;

			}
		}
		let that = this;
		Promise.allSettled(promises)
			.then((responses) => {
				responses.forEach(each => {
					let levels = each.value

					levels = levels.map(each => {
						if (selectedSolsMap.get(each.guid)) {
							// levels[j].selected = true;
							each = selectedSolsMap.get(each.guid)
						}
						selectedSolsMap.set(each.guid, each)
						return selectedSolsMap.get(each.guid)
					})
					selectedSolsMap.get(levels[0].parentGuid).levels = levels;
				})

				// setting partial selections
				displayTokens.forEach(each => {
					// that.updatePartialSelections(selectedSolsMap, each)
					that.updateParentSelections(selectedSolsMap, each)

				})
				activity.solHierarchyMap = selectedSolsMap;
				this.updateModel()

			})
			.catch(function (error) {

			});
		if (mode === 'EDIT' && activity.association.id === "502") {
			let oppoHierarchyList = await this.getHierarchyByMaterials(Object.values(activity.oppoMaterials));
			let oppoHierarchyMap = new Map();
			oppoHierarchyList.forEach(each => oppoHierarchyMap.set(each.guid, each))
			oppoHierarchyList.forEach(node => {
				const parent = oppoHierarchyMap.get(node.parentGuid);
				if (selectedSolsMap.get(node.guid)) node.selected = selectedSolsMap.get(node.guid).selected;
				else selectedSolsMap.set(node.guid, node);
				if (parent) {
					parent.levels.push(node);
				} else {
					oppoSolHierarchy.push(node);
				}
			});

		}
		activity.oppSolHierarchy = structuredClone(oppoSolHierarchy);
		this.updateModel();

	}

	// updates hierachy selections from currentNode to parentNode
	updateParentSelections(solHierarchyMap, selectedNode, displayTokens, materials) {
		if (materials && !selectedNode.selected) materials = materials.filter(each => each.triggeredBy !== selectedNode.guid)
		if (selectedNode.isParent) {
			return { displayTokens, materials };
		}
		let parentNode = solHierarchyMap.get(selectedNode.parentGuid);
		if (!parentNode) return { displayTokens, materials };
		let partiallySelected = false;
		if (selectedNode.partiallySelected) {
			parentNode.partiallySelected = true;
			parentNode.selected = true
		}
		else {
			partiallySelected = parentNode.levels.find(each => {
				if (selectedNode.selected) return !each.selected
				else return each.selected
			});
			parentNode.partiallySelected = partiallySelected ? true : false;
			parentNode.selected = parentNode.partiallySelected ? true : selectedNode.selected
		}
		if (displayTokens) displayTokens = displayTokens.filter(each => parentNode.guid !== each.guid)
		return this.updateParentSelections(solHierarchyMap, parentNode, displayTokens, materials)
	}

	async getMaterials(guid) {
		const { data } = await this._service.getMaterials(guid);
		let materials = data.results?.map(each => {
			return {
				id: each.MatId,
				description: each.MatDesc,
				name: each.MatDesc,
				isMaterial: true
			}
		})
		const activity = this._data.openedActivities.find((a) => a.guid === guid);
		materials = materials.concat(activity.solutions.results)
		activity.setCountData("solutions", materials);
		this.updateModel();
	}
	async getAddOpportunities(guid) {
		const params = {
			filters: [new Filter("ActivityGuid", FilterOperator.EQ, guid)],
		};
		const { data } = await this._service.getAddOpportunities(params);
		let opportunities = data.results?.map(each => {
			return {
				id: each.OpportunityNo,

			}
		})
		const activity = this._data.openedActivities.find((a) => a.guid === guid);
		activity.setCountData("additionalOpportunities", opportunities);
		activity.setBusy("additionalOpportunities", false);
		this.updateModel();
	}
	// get from activity types master data
	async getTypeInfo(typeId, roleMappingId) {
		const params = {
			filters: [
				new Filter("ActvtTypeID", FilterOperator.EQ, typeId),
				new Filter("RoleMpngID", "EQ", roleMappingId),
			],
		};
		const { data } = await this._service.getTypeInfo(params);
		const typeInfo = data.results[0]?.ActivityTypeInfo || {};
		return typeInfo;
	}

	async getTeam(guid) {
		return await this._getCountData(guid, "team", "userid", "name", true);
	}

	// async getFiles(guid) {
	//     return await this._getCountData(guid, "files", "Url", "Url", false);
	// }

	async getAddOpps(guid) {
		return await this._getCountData(
			guid,
			"additionalOpportunities",
			"OpportunityNo",
			"OpportunityNo",
			false
		);
	}

	async getInnovations(guid) {
		return await this._getCountData(
			guid,
			"innovations",
			"Description",
			"Description",
			false
		);
	}

	// async getLandscapes(guid) {
	//     return await this._getCountData(guid, "landscapes", "LandDescription", "LandDescription", false);
	// }

	async getShowrooms(guid) {
		return await this._getCountData(
			guid,
			"showrooms",
			"Description",
			"Description",
			false
		);
	}

	// async getSuccessFactors(guid) {
	//     return await this._getCountData(guid, "successFactors", "comp_name", "comp_name", false);
	// }

	// async getSolutions(guid) {
	// 	return await this._getCountData(
	// 		guid,
	// 		"solutions",
	// 		"SolId",
	// 		"SolutionDesc",
	// 		false
	// 	);
	// }

	async _getCountData(guid, type, idProperty, descProperty, isTeam) {
		if (!guid) {
			return [];
		}
		let countData = [];
		const activities = this.getData().activities;
		const activity = activities.find((a) => a.guid === guid);
		const filters = [new Filter("ActivityGuid", FilterOperator.EQ, guid)];
		if (isTeam) {
			filters.push(new Filter("Role", FilterOperator.NE, "RSCMGR"));
		}
		if (type === "solutions") {
			filters.push(new Filter("IsServiceRequest", FilterOperator.EQ, false));
		}
		const params = {
			filters: filters,
		};
		const { data } = await this._service.getCountData(params, type);

		if (data?.results.length) {
			const results = data.results ?? [];

			countData = Array.from(results, (each) => ({
				id: each[idProperty],
				description: each[descProperty],
			}));

			if (activity) {
				activity.setCountData(type, countData);
			}
		}
		countData = data?.results || [];
		return countData;
	}
	async getTypeDataByActivityId(id) {
		const activity = this._data.openedActivities?.find(
			(activity) => activity.id === id
		);
		if (activity?.type?.id) {
			if (activity.guid) this.getEntities(activity.guid, activity.type); // only in edit scenario
			this.getTypeData(activity.type, activity.guid);
		}
	}
	async getFieldsLayout(type) {
		if (!type.layout.fields) {
			const params = {
				filters: [new Filter("FormLayoutID", "EQ", type.layout.childId)],
			};
			const { data } = await this._service.getFormLayoutString(params);
			let fieldsLayout =
				JSON.parse(data?.results?.length && data.results[0].FormLayoutString)
					?.Fields || {};
			type.setLayoutFields(fieldsLayout);
			this.updateModel();
		}
		return type.layout.fields;
	}
	async getTypeData(type, guid) {
		const user = AuthState.getInstance().getData();
		const defaultRole = user.role;
		this.getFieldsLayout(type);
		this.setTimeEntryVisibility(guid);
		let promises = [
			this.activityMasterState.getMethodsByType(type),
			this.activityMasterState.getActivityDetailTypes(type),
			// this.activityMasterState.getBsnsAreaEngaged(type),
		];
		if (defaultRole.mappingId)
			promises.push(
				this.activityMasterState.getActivityCVJPhase(
					type,
					defaultRole.mappingId
				)
			);
		let that = this;
		Promise.allSettled(promises).then(() => {
			that.updateModel();
		});
	}

	async getMaterialsById(id) {
		const params = {
			filters: [new Filter("soln_guid", "EQ", id)],
		};
		const { data } = await this._service.getMaterialsById(params);
		let materials = data?.results.map(each => {
			return {
				id: each.mat_id,
				name: each.mat_desc,
				guid: each.soln_guid,
				triggeredBy: id
			}
		})
		return materials || []
	}

	async getHierarchyByGuid(guids) {
		const filters = guids.map(guid => new Filter("soln_guid", FilterOperator.EQ, guid))
		const params = {
			filters: [new Filter({
				filters: filters,
				and: false,
			})]
		};
		let { data } = await this._service.getSolHierarchyById(params);
		let hierarchy = data?.results?.map(each => {
			return {
				guid: each.soln_guid,
				id: each.soln_id,
				name: each.soln_name,
				isFinal: each.is_final,
				parentGuid: each.soln_prnt_guid,
				levels: []

			}
		})
		return hierarchy;
	}

	async getHierarchyByMaterials1(materials) {
		const filters = materials.map(material => new Filter("mat_id", FilterOperator.EQ, material.id))
		const params = {
			filters: [new Filter({
				filters: filters,
				and: false,
			})]
		};
		let { data } = await this._service.getSolHierarchyById(params);

		const solutionsMap = new Map();
		let hierarchyList = data?.results?.map((each, index) => {
			let node = {
				guid: each.soln_guid,
				id: each.soln_id,
				name: each.soln_name,
				parentGuid: each.soln_prnt_guid,
				isFinal: each.is_final,
				levels: []
			}
			solutionsMap.set(node.guid, node);
			return node
		})


		// Build the tree structure
		let hierarchy = [], displayTokens = [];
		hierarchyList.forEach(node => {
			const parent = solutionsMap.get(node.parentGuid);
			node.selected = true
			if (parent) {
				parent.levels.push(node);
			} else {
				hierarchy.push(node);
			}
			if (node.isFinal) displayTokens.push(node)
		});
		return { hierarchy, displayTokens };
	}

	async getHierarchyByMaterials(materials) {
		const filters = materials.map(material => new Filter("mat_id", FilterOperator.EQ, material.id))
		const params = {
			filters: [new Filter({
				filters: filters,
				and: false,
			})]
		};
		let { data } = await this._service.getSolHierarchyById(params);


		let hierarchyList = data?.results?.map((each, index) => {
			return {
				guid: each.soln_guid,
				id: each.soln_id,
				name: each.soln_name,
				parentGuid: each.soln_prnt_guid,
				isFinal: each.is_final,
				matId: each.mat_id,
				levels: []
			}


		})


		return hierarchyList;
	}

	async initializeActivity(activity) {
		let { data } = await this._service.registerActivity({});
		activity.guid = data.ActivityGuid;
		this.updateModel()

	}

	async registerActivities() {
		//push opened activities to list
		let drafts = [], savedActivities = []
		this._data.openedActivities.forEach((activity, index) => {
			let act = this.validateData(activity, index);
			if (act.isValid) savedActivities.push(act.data)
			else drafts.push(act.data)
		})
		this.updateDrafts(drafts, savedActivities)
		this.updateModel()
	}



	validateData(activity, index) {
		// sap.m.MessageToast.show('Data Validation Started')
		let errors = [], fields = activity.type.layout.fields;
		// registration dialog data validation
		if (!activity.type.id || !activity.type.layout.id) {
			activity.valueStates['type'].state = 'Error'
			errors.push({
				message: activity.valueStates['type'].message,
				tabId: index
			})
		}
		if (activity.association.id === '501') {
			if (!activity.account.id) {
				activity.valueStates['account'].state = 'Error'
				errors.push({
					message: activity.valueStates['account'].message,
					tabId: index
				})
			}
		}
		else if (activity.association.id === '502') {
			if (!activity.opportunity.id) {
				activity.valueStates['opportunity'].state = 'Error'
				errors.push({
					message: activity.valueStates['opportunity'].message,
					tabId: index
				})

			}
		}
		else if (activity.association.id === '503') {

		}

		// mandatory data validation based on configuration 
		Object.keys(activity).forEach(each => {
			if (fields[each]?.property) {
				let data = this.getModel().getProperty('/openedActivities/' + index + fields[each].property)
				if (fields[each].isArray) data = data?.length;
				if (fields[each].required && fields[each].visible) {
					activity.valueStates[each].state = 'None'
					if (!data) {
						activity.valueStates[each].state = 'Error'
						errors.push({
							message: activity.valueStates[each].message,
							tabId: index
						})
					}
				}
			}
		})

		// risk comment 
		if ((activity.risk.id === "01" || activity.risk.id === "02") && !activity.risk.comments?.trim()) {
			errors.push({
				message: activity.valueStates['riskComment'].message,
				tabId: index
			})
			activity.valueStates['riskComment'].state = 'Error'
		}

		// atleast one demo env section should have data if demo environment is shown
		if (activity.type.layout.fields.demoEnvSection?.visible &&
			(!activity.landscapes.results.length && !activity.cloudEnvironments.results.length && !activity.successFactors.results.length)) {
			errors.push({
				message: activity.valueStates['demoEnvSection'].message,
				tabId: index
			})
		}

		activity.validationErrors = errors
		this.updateModel();
		// update the activities with openedActvities 
		if (!errors.length) {
			if (!activity.id) {
				this._data.activities.unshift(activity);
			}
			else {
				let listIndex = this._data.activities.findIndex(each =>
					each.id === activity.id
				);
				if (listIndex !== -1) {
					this._data.activities[listIndex].status.description = null
				}

			}
			if (activity.association.id === '502' && (!activity.id || (activity.id && (activity.modified.team || activity.modified.lead || activity.modified.accountExecutive)))) {
				this.validateVATteam(activity)
			}
			else {
				this.saveActivity(activity);
			}
			return {
				data: activity,
				isValid: true
			}
		}
		else {
			return {
				data: activity,
				isValid: false
			};
		}
	}
	async updateDrafts(draftActivities, savedActivities) {
		let drafts =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "myActivities",
				storeName: "drafts-table",
				keyName: "activitydrafts",
			})) || [];

		// drafts = drafts.concat(draftActivities);
		let draftsMap = {};
		drafts.forEach(each => draftsMap[each['guid']] = each);
		draftActivities.forEach(each => {
			let index = drafts.findIndex(act => act.guid === each.guid);
			if (index === -1) {
				drafts.push(each)
			}
			else {
				drafts[index] = each
			}
		})

		// push draft activities to draft only if its not there already
		// const draftsMap = new Map(drafts.map(item => [item.guid, item]));
		// draftActivities.forEach(item => {
		// 	if (draftsMap.has(item.guid)) {
		// 		Object.assign(draftsMap.get(item.guid), item);
		// 	} else {
		// 		drafts.push(item);
		// 	}
		// });
		// drafts = draftsMap.values();
		if (savedActivities?.length) {
			savedActivities = new Set(savedActivities.map(each => each.guid));
			drafts = drafts.filter(item => !savedActivities.has(item.guid));
		}
		IndexedDB.fnInsertDataToDB({
			dbName: "myActivities",
			storeName: "drafts-table",
			keyName: "activitydrafts",
			aObjectsToInsert: drafts,
		});
		this._data.draftActivities = drafts;
		this.updateModel();
	}






	async validateVATteam(activity) {

		let team = [], that = this;
		if (activity.lead.id) team.push(activity.lead);
		if (activity.team.results.length) team = team.concat(activity.team.results);
		if (activity.accountExecutive.id) team.push(activity.accountExecutive);
		this.requestedForOppoAccess = false;
		if (team.length) {
			const process = StatusBox.addProcess(activity.type.description + " VAT Team in progress");
			let opportunityTeam = activity.opportunity.team;
			let noAccessUsers = team.filter(({
				id: id1,
				email: email1
			}) => !opportunityTeam.some(({
				id: id2,
				email: email2
			}) =>
				id2.toLowerCase() === id1.toLowerCase() && email1.toLowerCase() === email2.toLowerCase()));

			// remove duplicate users
			noAccessUsers = this.removeDuplicates(noAccessUsers);

			// provide oppo access to noAccessUsers
			// 	if success then proceed with save and notifyOppoOwner abt users access
			// else show a confirmation msg regarding the error and if the user still wants to save activity.
			// if yes proceed with save

			if (noAccessUsers.length) {
				noAccessUsers = noAccessUsers.map(each => {
					return {

						"ROLE": each.role,
						"NAME": each.name,
						"ID": each.id,
						"EMAIL": each.email

					}
				})
				const success = async function (errorCode, response) {
					if (errorCode === "HARMONY_SERVER_DOWN" || errorCode === "SERVICE_LIMIT_REACHED" || response) {

						// let message =
						// 	"Harmony server is unavailable, users cannot be added to Opportunity team. Do you still want to save the Activity?";

						// if (errorCode === "SERVICE_LIMIT_REACHED") {
						// 	message = "Unable to reach the service to update VAT team members. Do you still want to create Activity?";
						// }
						// if (response) {
						// 	if (response && response.responseText.includes("{")) {
						// 		var code = JSON.parse(response.responseText).error.code;
						// 		if (code === "Z_CROSS_REPORTING/009") {
						// 			message = "You do not have access to this Opportunity. Do you still want to save the Activity?";

						// 		}
						// 	} else {
						// 		if (response && response.responseText) {
						// 			message = response.responseText

						// 			message = message + " Do you still want to save the Activity?";

						// 		}
						// 	}
						// }
						StatusBox.setFailed(process.id);

					} else {

						StatusBox.setCompleted(process.id);

					}
					that.saveActivity(activity)
				};
				this.requestedForOppoAccess = true;
				this.VATTeam.fnProvideOppoAccess(noAccessUsers, activity.opportunity.id, success, true)
			}

		}

	}
	removeDuplicates(users) {
		return users.filter((item, index, self) =>
			index === self.findIndex(t => t.id === item.id && t.email === item.email)
		);
	}



	async saveActivity(activity) {
		let processName = activity.type.description;
		const process = StatusBox.addProcess(processName + " Registration in progress...");
		let payload = {
			"ActivityGuid": activity.guid,
			"ActivityId": activity.id,
			"ActvtAsstdID": activity.association.id,
			"RoleMpngID": activity.role.mappingId,
			"Requestor": "",
			"RequestorName": "",
			"ActivityLead": activity.lead.id,
			"ActivityLeadName": activity.lead.name,
			"ActivityLeadEmailId": activity.lead.email,
			"AccountExecutive": activity.accountExecutive.id,
			"AccountExecutiveName": activity.accountExecutive.name,
			"AccountExecutiveEmailId": activity.accountExecutive.email,
			"ActivitySupportName": "",
			"MethodId": activity.method.id,
			"MethodDescription": activity.method.description,
			"ActivitySetId": activity.set.id,
			"ActivityTypeId": activity.type.id,
			"ActivityTypeDescription": activity.type.description,
			"FormLayoutId": activity.type.layout.id,
			"ChildFrmLayoutId": activity.type.layout.childId,
			"MainSolutionId": "",
			"MainSolutionDescription": "",
			"external_flag": false,
			"ActivitySetdescription": activity.set.description,
			"OpportunityNumber": activity.opportunity.id,
			"StartDate": activity.startDate,
			"EndDate": activity.endDate,
			"Status": activity.status?.id,
			"DealType": "0",
			"CreateDate": null,
			"Description": activity.description,
			"VirtualStudioId": "",
			"BoardRoomNumber": "",
			"RoomName": "",
			"RiskAssessId": activity.risk.id,
			"RiskColorCode": "",
			"RiskComment": activity.risk.comments,
			"DcId": "",
			"ActivitySetStatus": "",
			"GlobalUltimateID": activity.account.id,
			"ActvtRegion": "",
			"TargetValue": "",
			"SCPAccount": "",
			"PotentialCloseDate": null,
			"RequestorManagerID": "",
			"RequestorManagerName": "",
			"Region": "",
			"SubRegion": "",
			"Industry": "",
			"CancledOn": null,
			"CanceledBy": "",
			"CanceledByName": "",
			"expiredActivity": "",
			"Authorized": "X",
			"SurveyRecpt": "",
			"SurveyRecptName": "",
			"RequestedDelivery": null,
			"ActvtStatus": "",
			"NotifyMe": "",
			"DryRunDate": activity.dryRun,
			"DiscoveryCompleted": "",
			"TopDealFlag": "",
			"MeetingInvitees": "",
			"ExistingClient": "",
			"CntryID": "",
			"CntryName": "",
			"ImpactID": "",
			"ImpactDesc": "",
			"NmbrOfAttnds": "",
			"ActvtName": "",
			"Archived": false,
			"LastChangedAt": null,
			"SLActGUID": "00000000-0000-0000-0000-000000000000",
			"SlName": "",
			"SlSnro": "",
			"SlStatusId": "",
			"IsSlLead": "",
			"RequestorRegHC": "",
			"StatusChangedAt": null,
			"SlRisk": "",
			"cvaguid": "00000000-0000-0000-0000-000000000000",
			"ConsPS": "",
			"EngLevel": "",
			"EngLevelDesc": "",
			"SuppChainOfSuccId": "",
			"SuppChainOfSuccDesc": "",
			"SalesLobId": "",
			"SalesLOBDesc": "",
			"ScopeId": "",
			"ScopeDesc": "",
			"IncrPipeline": "",
			"BPSMEAlign": false,
			"ActLeadHC": "",
			"Scripted": "",
			"CustomerDays": "0",
			"CustomerHours": "0",
			"Security": "",
			"IndustryId": "",
			"IndustryDesc": "",
			"MuId": "",
			"MuDesc": "",
			"ScheduledDemoDt": null,
			"CustomerUrl": "",
			"CvjPhaseId": activity.cvjPhase.id,
			"CvjPhaseDesc": activity.cvjPhase.description,
			"guid": "00000000-0000-0000-0000-000000000000",
			"ProjectId": "",
			"ProjectDesc": "",
			"HostTypeId": "",
			"HostTypeDesc": "",
			"UseCaseId": "",
			"UseCase": "",
			"DeliveryTeamId": "",
			"DeliveryTeam": "",
			"VendorId": "",
			"VendorDesc": "",
			"TAId": "",
			"TADesc": "",
			"HSCDesc": "",
			"EngTypeId": "",
			"EngTypeDesc": "",
			"CurrentSize": "00000",
			"RecommendedSize": "00000",
			"CompressionFactor": "0.00",
			"PrefDCId": "",
			"PrefDC": "",
			"UserNumber": "",
			"NumberTeam": "",
			"to_AAccnt": [
				{
					"iss": "Transform",
					"iac": "Transform-Other",
					"accountname": activity.account.name,
					"accountid": activity.account.id
				}
			],
			"to_AAddOpp": [],
			"to_AAudience": [],
			"to_ABsnsArEngd": [],
			"to_ACloudEnv": [],
			"to_AComments": [],
			"to_ACrossTopic": [],
			"to_ADemoCntnt": [],
			"to_ADetType": [],
			"to_AFiles": [],
			"to_AIndustry": [],
			"to_AInitiative": [],
			"to_ALand": [],
			"to_AMaterial": [],
			"to_AOpportunity": [
				{
					"accountid": activity.account.id,
					"ACCOUNT_NAME": activity.account.name,
					"OPPT_ID": activity.opportunity.id
				}
			],
			"to_APhase": [],
			"to_ARegionMu": [],
			"to_ARouteMkt": [],
			"to_AShowroom": [],
			"to_ASol": [],
			"to_ASrvReq": [],
			"to_AStrategicSol": [],
			"to_ASuccessFactor": [],
			"to_ATaxonomy": [], // for solutions
			"to_ATeam": [],
			"to_AMaterials": [],
			"to_ASolution": []
		}
		payload.to_ACloudEnv = activity.cloudEnvironments.results.map(each => {
			return {
				"ActivityGuid": activity.guid,
				"Description": each.description,
				"Instance": each.instance
			}
		})
		payload.to_ADetType = activity.detailTypes.map(each => {
			return {
				"ActivityGuid": activity.guid,
				"Description": each.description,
				"TypeId": each.id
			}
		})
		payload.to_AFiles = activity.files.results.map(each => {
			return {
				"Url": each.url,
				"FileId": each.id,
				"FileName": each.name,
				"DocumentType": "0001",
				"Status": "X",
				"ProjectType": "ACTVT"
			}
		})
		payload.to_ALand = activity.landscapes.results.map(each => {
			return {
				"ActivityGuid": activity.guid,
				"LandsId": each.id,
				"LandDescription": each.description,
				"Location": each.location,
				"Ltype": each.type,
				"Product": each.product,
				"LTypeDescription": each.typeDescription,
				"OperationStatus": each.operationStatus,
				"LandscapeId": each.landscapeId
			}
		})
		payload.to_ASuccessFactor = activity.successFactors.results.map(each => {
			return {
				"ActivityGuid": activity.guid,
				"CompName": each.company,
				"Username": each.username,
				"AccessKey": each.password,
				"DCId": each.dataCenter.id,
				"DCDesc": each.dataCenter.description
			}
		})
		payload.to_ATeam = activity.team.results.map(each => {
			return {
				"EMAIL": each.email,
				"ROLE": each.role,
				"NAME": each.name,
				"ID": each.id,
				"ActivityGuid": activity.guid
			}
		})
		payload.to_AAddOpp = activity.additionalOpportunities.results.map(each => {
			return {
				"OpportunityNo": each.id,
				"ActivityGuid": activity.guid
			}
		})
		activity.solutions.results.forEach(each => {
			if (each.isMaterial) {
				payload.to_AMaterials.push({
					"MatId": each.id,
					"MatDesc": each.name,
					"SolYear": each.solYear,
					"ActivityGuid": activity.guid
				})
			}
			else payload.to_ASolution.push({
				"activity_guid": activity.guid,
				"soln_guid": each.guid,
			})
		})

		let result = await this._service.registerActivity(payload);
		let data = result.data, that = this;
		if (activity.association.id === "502" && this.requestedForOppoAccess) {
			var success = function (response, isError) {
				if (isError) {
					sap.m.MessageToast.show("Unable to update Opportunity team members to Melody");
				}
				that.saveTimeEntries(activity.guid);
			};
			this.VATTeam.fnGetOpportunityOwner(data.ActivityId, "", result, success);
		}

		let index = this._data.activities.findIndex(each => each.id === data.ActivityId);
		if (index !== -1) this._data.activities[index].status.description = "Registered"; // edit scenario
		activity.id = data.ActivityId;
		activity.status = {
			id: "01", description: "Registered"
		}
		this.saveTimeEntries(activity.guid);
		this.updateModel();
		StatusBox.setCompleted(process.id)
		if (activity.justificationComment) {
			this.saveComment({
				"ActivityGuid": activity.guid,
				"CommentGuid": activity.justificationComment.guid
			})
		}
		return activity
	}

	async saveTimeEntries(guid) {
		const activity = this._data.openedActivities.find(act => act.guid === guid)
		const failedEntries = await this.fetchFailedTimeEntries(activity);
		if (failedEntries || activity.estimatedTime.ncf || activity.estimatedTime.cf) {
			this.fnDoTimeEntry(activity)
		}

	}

	fnGetUserEntries(activity) {
		var userEntries = this.timeState.getData().entries;
		userEntries = this.sortTimeEntries(userEntries);
		this.setLastEntryDate(userEntries, activity);
		return userEntries;
	}

	//Function to sort Array based on date object
	sortTimeEntries(entries) {
		return entries.sort((entry1, entry2) => entry1.date.getTime() - entry2.date.getTime());
	}

	//Function to capture the date of the last entry user made
	setLastEntryDate(userEntries, activity) {
		var lastEntryDate = null;
		var firstEntryDate = null;
		var length = userEntries.length - 1;
		if (userEntries.length) {
			firstEntryDate = userEntries[0]["date"];
			lastEntryDate = userEntries[length]["date"];
		}
		activity.estimatedTime.firstEntryDate = firstEntryDate;
		activity.estimatedTime.lastEntryDate = lastEntryDate;


	}

	async fetchFailedTimeEntries(activity) {
		var filterEnteries = [];
		let userEntries = this.fnGetUserEntries(activity);
		var activityId = activity.id;
		if (activityId === "") {
			return filterEnteries;
		}
		userEntries.filter(function (Entry) {
			if (Entry.activity.id === activityId && (Entry.status.id === "3" || Entry.status.id === "1")) {
				var object = $.extend(true, {}, Entry);
				object["indicator"] = "I";
				filterEnteries.push(object);
			}
		});
		return filterEnteries;
	}

	async createActivitySet(payload, activity) {
		let { data } = await this._service.createActivitySet(payload)
		// return {
		// 	id: data.ActSetId,
		// 	description: payload.Description
		// }
		activity.set = {
			id: data.ActSetId,
			description: payload.Description
		}
		this.updateModel()
	}

	//Function to validate for user time entry
	async fnDoTimeEntry(activity) {
		const process = StatusBox.addProcess(activity.type.description + " Time Entries Creation in progress");
		var entries;
		// var oViewSettingsModel = this.oViewSettingsModel;
		// oViewSettingsModel.setProperty("/ResponseObject", oResponseObject);
		// oViewSettingsModel.setProperty("/SavedActivityID", ActivityId);
		var IsActSaveEntries = true  // is true for save and false for submit
		if (IsActSaveEntries) {
			// this.fnUpdateActSaveProcessObj("SAVE_ENTRIES", "IN_PROGRESS");
			entries = await this.fnFormatGetUserTimeEntries(activity, false, true);
		} else {
			var aToSaveEntries = oViewSettingsModel.getProperty("/aToSaveEntries");
			var isShowEntriesBeforeSubmit = oViewSettingsModel.getProperty("/isShowEntriesBeforeSubmit");
			if (aToSaveEntries && aToSaveEntries.length && isShowEntriesBeforeSubmit) {
				await this.fnDoBothSaveSubmitEntries();
				return;
			} else {
				this.fnUpdateActSaveProcessObj("SUBMIT_ENTRIES", "IN_PROGRESS");
				entries = await this.fnFormatGetUserTimeEntries(false, true);
			}
		}

		if (entries["isMTRTasks"]) {
			await this.fnSaveSubmitEntries(activity, entries["aEntries"]);
			StatusBox.setCompleted(process.id)
		} else {
			if (IsActSaveEntries) {
				this.fnUpdateActSaveProcessObj("SAVE_ENTRIES", "COMPLETED");
			} else {
				this.fnUpdateActSaveProcessObj("SUBMIT_ENTRIES", "COMPLETED");
			}
			this.fnSuccessErrorActSave(oResponseObject);
		}

	}

	async fnFormatGetUserTimeEntries(activity) {
		let mtrTasks = await this.getMTRTasks(activity.guid);
		// create new entries and then save 
		let userEntries = this.timeState.getData().entries;
		let estimatedTime = activity.estimatedTime.cf;
		estimatedTime = parseFloat(estimatedTime);
		let NCFEstimatedTime = activity.estimatedTime.ncf;
		NCFEstimatedTime = parseFloat(NCFEstimatedTime);
		let newEntries = [],
			filteredMTRTask,
			customerFacingTask, nonCustomerFacingTask,
			isMTRTasks = false;
		var alterCustomerFacing = activity.estimatedTime.alterCustomerFacing;
		var isCustomerFacing = activity.estimatedTime.isCustomerFacing;
		if (mtrTasks.length) {
			isMTRTasks = true;
			if (mtrTasks.length === 2) {
				if (isCustomerFacing) {
					customerFacingTask = this.fnGetCustomerFacingMTRTasks(mtrTasks, isCustomerFacing);
					nonCustomerFacingTask = this.fnGetCustomerFacingMTRTasks(mtrTasks, !isCustomerFacing);
					newEntries = await this.fnCreateTimeEntries(activity, userEntries, customerFacingTask, estimatedTime, true);
					userEntries = this.fnGetUserEntries(activity);
					var NCFEntries = await this.fnCreateTimeEntries(activity, userEntries, nonCustomerFacingTask, NCFEstimatedTime, false, newEntries);
					newEntries = newEntries.concat(NCFEntries);
				} else if (alterCustomerFacing) {
					customerFacingTask = this.fnGetCustomerFacingMTRTasks(mtrTasks, alterCustomerFacing);
					nonCustomerFacingTask = this.fnGetCustomerFacingMTRTasks(mtrTasks, !alterCustomerFacing);
					var NCFEntries = await this.fnCreateTimeEntries(activity, userEntries, nonCustomerFacingTask, NCFEstimatedTime, false);
					userEntries = this.fnGetUserEntries(activity);
					newEntries = await this.fnCreateTimeEntries(activity, userEntries, customerFacingTask, estimatedTime, true, NCFEntries);
					NCFEntries = NCFEntries.concat(newEntries);
					newEntries = NCFEntries;
				}
			} else if (mtrTasks.length === 1) {
				filteredMTRTask = mtrTasks[0];
				newEntries = await this.fnCreateTimeEntries(activity, userEntries, filteredMTRTask, NCFEstimatedTime, isCustomerFacing);
			}
		}
		var oSplitEntries = this.validateISPFutureDate(activity, newEntries);
		var isSaveEntry = true;  // true for save ; false for submit
		if (oSplitEntries["aToSaveEntries"].length && !isSaveEntry) {
			// let aToSaveEntries = this.fnPerformConcatEntries(oSplitEntries["aToSaveEntries"]);
			// let aToSubmitEntries = this.fnPerformConcatEntries(oSplitEntries["aToSubmitEntries"]);
			// oViewSettingsModel.setProperty("/isShowEntriesBeforeSubmit", true);
			// oViewSettingsModel.setProperty("/aToDisplaySaveEntries", aToSaveEntries);
			// oViewSettingsModel.setProperty("/aToDisplaySubmitEntries", aToSubmitEntries);
			// oViewSettingsModel.setProperty("/aToSaveEntries", oSplitEntries["aToSaveEntries"]);
			// oViewSettingsModel.setProperty("/aToSubmitEntries", oSplitEntries["aToSubmitEntries"]);
		} else {
			// oViewSettingsModel.setProperty("/isShowEntriesBeforeSubmit", false);
		}
		return {
			aEntries: newEntries,
			isMTRTasks: isMTRTasks
		};
	}

	//Function to get MTR task based in Customer facing:True/False
	fnGetCustomerFacingMTRTasks(mtrTasks, isCustomerFacing) {
		isCustomerFacing = isCustomerFacing ? "1" : "2";
		var filteredMTRTask = mtrTasks.find(function (task) {
			var sMpngAttr = task["MpngAttr"];
			//MpngAttr === "1" => The selected field is Customer Facing
			//MpngAttrVal === "1" => Customer Facing is true;
			//MpngAttrVal === "2" => Customer Facing is false;
			if (sMpngAttr === "1") {
				return task["MpngAttrVal"] === isCustomerFacing;
			}
		});
		return filteredMTRTask;
	}

	//Function to create new time entries
	async fnCreateTimeEntries(activity, userEntries, mtrTask, estimatedTime, customerFacing, prevEntries) {
		var aEntries = [];
		var estimatedTime = structuredClone(estimatedTime);
		var bPrevEntries = $.extend(true, [], prevEntries);
		var StdWorkDuration = this.fnGetWorkDuration();
		var oActStartDate = activity.startDate;
		var oNextDate = new Date(oActStartDate);
		if (prevEntries && prevEntries.length) {
			var length = prevEntries.length - 1;
			oNextDate = new Date(prevEntries[length]["date"]);
			userEntries = userEntries.concat(prevEntries);
		}
		var nEntries = await this.fnValidateIsEntriesAvailable(oNextDate, activity);
		if (nEntries.length) {
			userEntries = nEntries.concat(bPrevEntries);
		}
		userEntries = this.sortTimeEntries(userEntries);
		while (estimatedTime != 0) {
			var strDate = this.fnConvertDateObjToString(oNextDate);
			var selDateEntriesArray = this.getActStartDateEntries(strDate, userEntries);
			var selDateWorkDuration = this.fnCalculateWorkDuration(selDateEntriesArray);
			if (selDateWorkDuration >= StdWorkDuration) {
				oNextDate = this.fnGetNewEntryDate(oNextDate);
			} else if (selDateWorkDuration < StdWorkDuration) {
				var oRecordDateEntry = await this.fnValidateRecordDateEntry(strDate);
				if (oRecordDateEntry["isValidDate"] && oRecordDateEntry["targetHrs"] > 0) {
					StdWorkDuration = oRecordDateEntry["targetHrs"];
					var oTempObj = this.fnCalculateEstimateTime(activity, StdWorkDuration, selDateWorkDuration, estimatedTime, mtrTask, oNextDate, aEntries,
						customerFacing);
					oNextDate = oTempObj["oNextDate"];
					aEntries = oTempObj["aEntries"];
					estimatedTime = oTempObj["EstimatedTime"];
				} else if (oRecordDateEntry["isValidDate"] && oRecordDateEntry["targetHrs"] === 0) {
					oNextDate = this.fnGetNewEntryDate(oNextDate);
				} else if (!oRecordDateEntry["isValidDate"] && oRecordDateEntry["targetHrs"] === 0) {
					var WeekDayIndices = this.fnGetWeekDayIndex(oNextDate);
					if ((WeekDayIndices["DayIndex"] === WeekDayIndices["Sunday"]) || (WeekDayIndices["DayIndex"] === WeekDayIndices["Saturday"])) {
						oNextDate = this.fnGetNewEntryDate(oNextDate);
					} else {
						var oTempObj = this.fnCalculateEstimateTime(activity, StdWorkDuration, selDateWorkDuration, estimatedTime, mtrTask, oNextDate, aEntries,
							customerFacing);
						oNextDate = oTempObj["oNextDate"];
						aEntries = oTempObj["aEntries"];
						estimatedTime = oTempObj["EstimatedTime"];
					}
				}
			}
		}
		return aEntries;
	}
	//Function to get selected Date's weekdays indices
	fnGetWeekDayIndex(oDate) {
		var dayIndex = oDate.getDay();

		// var SundayIndex = this.Settings.getData().SecondWeekendDay;
		// var WeekStartDay = this.Settings.getData().WeekStartDay;
		// var SaturdayIndex =this.Settings.getData().FirstWeekendDay;
		var SundayIndex = 0;
		var WeekStartDay = 1;
		var SaturdayIndex = 6;
		return {
			DayIndex: dayIndex,
			Sunday: SundayIndex,
			Saturday: SaturdayIndex,
			WeekStartDay: WeekStartDay
		}
	}
	//Function to check whether a new entry can be created if the entry creation date is < sLastEntryDate
	//If the entry creation date is > sLastEntryDate, fetch the user entries for the next month
	async fnValidateIsEntriesAvailable(sEntryDate, activity) {
		var bVal = true;
		// var oSettings = MTRModels.getMTRSettingsModel().getData();
		var sActivityStartDate = activity.startDate;
		var sFirstEntryDate = activity.estimatedTime.firstEntryDate;
		if (!sFirstEntryDate) {
			this.fnGetUserEntries(activity);
			sFirstEntryDate = activity.estimatedTime.firstEntryDate;
		}
		var sLastEntryDate = activity.estimatedTime.lastEntryDate
		// var isGetPostEndDtEntries = oViewSettingsModel.getProperty("/isGetPostEndDtEntries");

		if (!sFirstEntryDate && !sLastEntryDate) {
			var diffMonths = this.fnGetDiffNoOfMonths(sEntryDate, new Date());
			var sEndDate = this.fnGetFutureMonths(sEntryDate, diffMonths);
			var aEntries = await this.getMTRUserEntries(sEntryDate, sEndDate, activity);
			// oViewSettingsModel.setProperty("/isGetPostEndDtEntries", true);
			await this.fnFetchTargetHours(sEntryDate, sEndDate);
			return aEntries;
		} else if ((sFirstEntryDate <= sActivityStartDate) && (sEntryDate <= sLastEntryDate)) {
			var diffMonths = this.fnGetDiffNoOfMonths(sEntryDate, sLastEntryDate);
			var sEndDate = this.fnGetFutureMonths(sEntryDate, diffMonths);
			var aEntries = await this.getMTRUserEntries(sEntryDate, sEndDate, activity);
			// oViewSettingsModel.setProperty("/isGetPostEndDtEntries", true);
			await this.fnFetchTargetHours(sEntryDate, sEndDate);
			return aEntries;
		} else if ((sActivityStartDate >= sFirstEntryDate) && (sEntryDate >= sLastEntryDate)) {
			var diffMonths = this.fnGetDiffNoOfMonths(sLastEntryDate, sEntryDate);
			var sEndDate = this.fnGetFutureMonths(sLastEntryDate, diffMonths);
			var aEntries = await this.getMTRUserEntries(sLastEntryDate, sEndDate, activity);
			// oViewSettingsModel.setProperty("/isGetPostEndDtEntries", true);
			await this.fnFetchTargetHours(sLastEntryDate, sEndDate);
			return aEntries;
		} else if ((sActivityStartDate <= sFirstEntryDate) && (sEntryDate <= sLastEntryDate)) {
			var diffMonths = this.fnGetDiffNoOfMonths(sEntryDate, sLastEntryDate);
			var sEndDate = this.fnGetFutureMonths(sEntryDate, diffMonths);
			var aEntries = await this.getMTRUserEntries(sEntryDate, sEndDate, activity);
			// oViewSettingsModel.setProperty("/isGetPostEndDtEntries", true);
			await this.fnFetchTargetHours(sEntryDate, sEndDate);
			return aEntries;
		} else {
			return [];
		}
	}
	//Function to get difference in no of days between 2 dates
	fnGetDiffNoOfMonths(date1, date2) {
		var diffMonths = Math.abs(date2.getMonth() - date1.getMonth() +
			(12 * (date2.getFullYear() - date1.getFullYear())));
		diffMonths = diffMonths + 1;
		return diffMonths;
	}

	//Function to get future months based on start date
	fnGetFutureMonths(StartDate, noOfMonths) {
		var date = new Date(StartDate.getTime());
		date.setMonth(date.getMonth() + noOfMonths);
		return date;
	}

	//Function to fetch target hours
	async fnFetchTargetHours(oStartDate, oEndDate) {
		oEndDate = this.dateService.format(oEndDate, "yMMdd");
		oStartDate = this.dateService.format(oStartDate, "yMMdd");
		await this.targetHourState.getTargetHours(oStartDate, oEndDate);
	}
	//Function to fetch user entries based on Activity start date
	async getMTRUserEntries(oStartDate, oEndDate, activity) {

		oEndDate = this.dateService.format(oEndDate, "yMMdd");
		oStartDate = this.dateService.format(oStartDate, "yMMdd");
		await this.timeState.getEntries(oStartDate, oEndDate);
		return this.fnGetUserEntries(activity);
	}

	//Function to get Standard Work Duration
	fnGetWorkDuration() {
		const user = AuthState.getInstance().getData();
		var StdWorkDuration = user.time.stdWorkDuration;
		StdWorkDuration = parseFloat(StdWorkDuration);
		return StdWorkDuration;
	}

	//Function to convert Javascript Date objec to string format for comparison
	fnConvertDateObjToString(ActStartDate) {
		var date = new Date(ActStartDate),
			month = '' + (date.getMonth() + 1),
			day = '' + date.getDate(),
			year = date.getFullYear();

		if (month.length < 2)
			month = '0' + month;
		if (day.length < 2)
			day = '0' + day;

		return [year, month, day].join('');
	}


	//Function to get Entries that are present on Activity Start Date
	getActStartDateEntries(startDate, sUserEntries) {
		var aStrtEntries = [];
		sUserEntries.find(function (oEntry) {
			if (oEntry["recordDate"] === startDate) {
				aStrtEntries.push(oEntry);
			}
		});
		return aStrtEntries;
	}

	//Function to calculate the total work duration for a selected date
	fnCalculateWorkDuration(aEntries) {
		var totalWorkDuration = 0;
		aEntries.filter(function (oEntry) {
			totalWorkDuration = totalWorkDuration + parseFloat(oEntry.duration.original);
		});
		return totalWorkDuration;
	}


	//Function to get next date for new Entry
	fnGetNewEntryDate(EntryDate) {
		var oDate = new Date(EntryDate);
		oDate.setDate(EntryDate.getDate() + 1);
		return oDate;
	}

	//Function to check if the record date is available for Time Entry, based on User's calendar profile
	async fnValidateRecordDateEntry(sRecordDate) {
		var isRecordAvailObj = {
			isValidDate: false,
			targetHrs: 0
		};
		// var TargetModel = sap.ui.getCore().getModel("target");
		// var aCalendarDays = TargetModel.getProperty("/TargetHours");
		var aCalendarDays = await this.targetHourState.getTargetHours();
		var oCalendarDay = aCalendarDays.find(function (CalendarDay) {
			return CalendarDay["Date"] === sRecordDate;
		});

		if (oCalendarDay) {
			var sTargetHrs = oCalendarDay["Datetype"] === "WORK" ? oCalendarDay["Targethours"] : 0;

			const loggedInUser = AuthState.getInstance().getData();
			var sTimeMatrics = loggedInUser.time.unit;
			// var sTimeMatrics = sap.ui.getCore().getModel("mtrSettings").getProperty("/TimeMatrics");
			sTargetHrs = parseFloat(sTargetHrs);
			if (sTimeMatrics === "D") {
				if (sTargetHrs !== 0 && sTargetHrs < 4) {
					sTargetHrs = 0.5;
				} else if (sTargetHrs !== 0 && sTargetHrs >= 4) {
					sTargetHrs = 1;
				}
			}
			isRecordAvailObj = {
				isValidDate: true,
				targetHrs: sTargetHrs
			};
		}
		return isRecordAvailObj;
	}

	//Function to calculate estimated time and then creat new entries
	fnCalculateEstimateTime(activity, StdWorkDuration, selDateWorkDuration, EstimatedTime, MTRTask, oNextDate, aEntries, bCustomerFacing) {
		var selDateRemainingHrs = StdWorkDuration - selDateWorkDuration;
		if (EstimatedTime > selDateRemainingHrs) {
			EstimatedTime = EstimatedTime - selDateRemainingHrs;
		} else {
			selDateRemainingHrs = EstimatedTime;
			EstimatedTime = 0;
		}
		var newEntry = this.fnGetNewEntryObj(activity, MTRTask, oNextDate, selDateRemainingHrs, bCustomerFacing);
		aEntries.push(newEntry);
		if (EstimatedTime) {
			oNextDate = this.fnGetNewEntryDate(oNextDate);
		}
		return {
			oNextDate: oNextDate,
			aEntries: aEntries,
			EstimatedTime: EstimatedTime
		};
	}
	//Function to create a new Entry Object
	fnGetNewEntryObj(activity, MTRTask, RecordDate, WorkDuration, bCustomerFacing) {
		// var oViewSettingsModel = this.oViewSettingsModel;
		// var oResponseObj = oViewSettingsModel.getProperty("/ResponseObject/data");
		var CostTypeId = activity.association.id;
		if (CostTypeId === "501") {
			CostTypeId = "4";
		} else if (CostTypeId === "502") {
			CostTypeId = "1";
		} else if (CostTypeId === "503") {
			CostTypeId = "2";
		}
		var CostTypeValue = CostTypeId === "1" ? activity.opportunity.id : activity.account.id;

		// var object = {
		// 	ActvtId: activity.id,
		// 	ActTypeDesc: activity.type.description,
		// 	Indicator: "I",
		// 	TaskId: MTRTask["MtrTaskID"],
		// 	TaskName: MTRTask["MtrTaskName"],
		// 	WorkDuration: WorkDuration.toString(),
		// 	RecordDate: this.fnConvertDateObjToString(RecordDate),
		// 	CostTypeId: CostTypeId,
		// 	CostTypeValue: CostTypeValue,
		// 	CustomerFacing: bCustomerFacing //this.oViewSettingsModel.getProperty("/IsCustomerFacing")
		// };
		const entryData = {
			recordDate: this.fnConvertDateObjToString(RecordDate),
			customerFacing: bCustomerFacing,
			activity: {
				id: activity.id,
				type: {
					description: activity.type.description,
				},
			},
			task: {
				taskId: MTRTask["MtrTaskID"],
				taskName: MTRTask["MtrTaskName"]
			},
			costType: {
				id: CostTypeId
			},
			costTypeValue: CostTypeValue,
			duration: WorkDuration.toString(),
			dataFrom: "I",
			indicator: "I"
		};
		var oEntry = new this.Entry(entryData);
		oEntry.setActivity(activity);
		return oEntry;
	}

	//Function to validate and separate Submitted and Saved entries if more than 7 days
	//7 is hardcoded as per said validation for the number of days
	validateISPFutureDate(activity, aEntries) {
		var iNoOfDays = 7;
		var aEntriesToBeSaved = [];
		var aEntriesToBeSubmitted = [];
		// var defaultModel = this.defaultModel;
		var actStrtDate = activity.startDate;
		var startDate = new Date(actStrtDate);
		startDate.setHours(0, 0, 0, 0);
		// var oViewSettingsModel = this.oViewSettingsModel;
		var endDate = this.fnGetTargetEndDate(iNoOfDays, startDate);
		aEntries.filter(function (entry) {
			var entryDate = entry["date"];
			if (entryDate >= startDate && entryDate < endDate) {
				aEntriesToBeSubmitted.push(entry);
			} else {
				aEntriesToBeSaved.push(entry);
			}
		});

		// oViewSettingsModel.setProperty("/showSaveEntryValidationMsg", false);
		// oViewSettingsModel.setProperty("/showSubmitEntryValidationMsg", false);
		// if (aEntriesToBeSaved.length > 0) {
		// 	oViewSettingsModel.setProperty("/showSaveEntryValidationMsg", true);
		// }
		// if (aEntriesToBeSubmitted.length > 0) {
		// 	oViewSettingsModel.setProperty("/showSubmitEntryValidationMsg", true);
		// }
		return {
			aToSubmitEntries: aEntriesToBeSubmitted,
			aToSaveEntries: aEntriesToBeSaved
		};
	}
	//Function to returns a end date based on number of days from start date
	fnGetTargetEndDate(iNoOfDays, dStartDate) {
		return new Date(new Date(dStartDate).getTime() + (iNoOfDays * 24 * 60 * 60 * 1000));
	}

	//Function to Save/Submit entries:
	async fnSaveSubmitEntries(activity, aEntries) {
		var oResult = [];

		var EstimatedTime = activity.estimatedTime.cf;
		EstimatedTime = parseFloat(EstimatedTime);
		var NCFEstimatedTime = activity.estimatedTime.ncf;
		NCFEstimatedTime = parseFloat(NCFEstimatedTime);
		// var oResponseObject = oViewSettingsModel.getProperty("/ResponseObject");
		let isActSaveEntries = true; //true for save ; false for submit
		let IsActSaveSubmitEntries = false; //true for submit ; false for save
		if (isActSaveEntries) {
			if (EstimatedTime || NCFEstimatedTime) {
				oResult = await this.timeState._sendToLS(aEntries);
				return oResult;
				//this.fnShowActMTREntriesStatusDialog(oResult);
				// this.fnUpdateActSaveProcessObj("SAVE_ENTRIES", "COMPLETED");
				// this.fnOponActSuccessErorrPopup(oResult, true);
			} else {
				// this.fnSuccessErrorActSave(oResponseObject);
			}
		} else if (IsActSaveSubmitEntries) {
			var saveFailedEntries = this.fetchFailedTimeEntries(activity);
			aEntries = aEntries.concat(saveFailedEntries);
			if (aEntries.length) {
				oResult = await this.timeState._sendToLS(aEntries);
				//this.fnShowActMTREntriesStatusDialog(oResult);
				// this.fnUpdateActSaveProcessObj("SUBMIT_ENTRIES", "COMPLETED");
				// this.fnOponActSuccessErorrPopup(oResult, true);
			} else {
				// this.fnSuccessErrorActSave(oResponseObject);
			}
		}
	}
	async getDuplicateRegistrations(activity) {
		var dateOffset = (24 * 60 * 60 * 1000) * 5;
		var myDate = new Date(activity.endDate);
		var myDate1 = new Date(activity.endDate);
		var subtTime = myDate.setTime(myDate.getTime() - dateOffset);
		var fromDate = new Date(subtTime);
		var Addtime = myDate1.setTime(myDate1.getTime() + dateOffset);
		var toDate = new Date(Addtime);
		const filters = [
			new Filter({
				path: "OpportunityNumber",
				operator: "EQ",
				value1: activity.opportunity.id
			}),
			new Filter({
				path: "EndDate",
				operator: "BT",
				value1: fromDate,
				value2: toDate
			}),
			new Filter({
				path: "ActivityTypeId",
				operator: "EQ",
				value1: activity.type.id
			})
		]


		const params = {
			filters: [new Filter({
				filters: filters,
				and: true,
			})]
		};
		const { data } = await this._service.getDuplicateRegistrations(params);
		let duplicateRegistrations = data?.results?.map(each => {
			return {
				account: {
					id: each.AccountID,
					description: activity.opportunity.account.name
				},
				guid: each.ActivityGuid,
				id: each.ActivityId,
				lead: {
					id: each.ActivityLead,
					name: each.ActivityLeadName
				},
				type: {
					id: each.ActivityTypeId
				},
				endDate: each.EndDate,
				solutions: each.Solutions,
				mainSolution: {
					id: each.MainSolutionId,
					description: each.MainSolutionDescription
				},
				opportunity: { id: each.OpportunityNumber, description: activity.opportunity.description }
			}
		})
		return duplicateRegistrations || []
	}
	async getCommentId(payload, guid) {
		const { data } = await this._service.getCommentId(payload);
		if (data) {
			let comment = {
				description: data.CommentDesc,
				guid: data.CommentGuid,
				createdBy: data.CreatedBy,
				createdOn: data.CreationDate
			}
			const activity = this._data.openedActivities.find((a) => a.guid === guid);
			activity.setJustificationComments(comment);
			this.updateModel()
		}
	}
	async saveComment(payload) {
		this._service.saveComment(payload);
	}

	async saveTeam(guid) {
		const user = AuthState.getInstance().getData()
		let payload = {
			ActivityGuid: guid,
			EMAIL: user.email,
			ID: user.id,
			ROLE: "ZOPRST01",
		}
		return await this._service.saveTeam(payload);
	}
	async setTimeEntryVisibility(guid) {
		const activity = this._data.openedActivities.find(a => a.guid === guid);
		const loggedInUser = AuthState.getInstance().getData();
		let lead = activity.lead
		let team = activity.team.results;
		let isRequestor = false;
		let actTeam = [];
		actTeam.push(lead);
		actTeam = actTeam.concat(team);
		if (actTeam.some(member => member.id === loggedInUser.id)) {
			isRequestor = true;
		}
		if (isRequestor) {
			let mtrTasks = [];
			activity.estimatedTime.isCustomerFacing = false, activity.estimatedTime.alterCustomerFacing = !activity.estimatedTime.isCustomerFacing;
			mtrTasks = await this.getMTRTasks(activity.guid);
			if (mtrTasks.length === 1) {
				activity.estimatedTime.alterCustomerFacing = false;
				activity.type.layout.fields.customerFacingTime = {
					enable: false,
					required: false,
					visible: false
				}
				activity.type.layout.fields.nonCustomerFacingTime = {
					enable: true,
					required: true,
					visible: true
				}
			}
			else if (mtrTasks.length === 2) {
				activity.type.layout.fields.customerFacingTime = {
					enable: true,
					required: true,
					visible: true
				}
				activity.type.layout.fields.nonCustomerFacingTime = {
					enable: true,
					required: true,
					visible: true
				}

			}


		}
		else {
			activity.type.layout.fields.customerFacingTime = {
				enable: false,
				required: false,
				visible: false
			}
			activity.type.layout.fields.nonCustomerFacingTime = {
				enable: false,
				required: false,
				visible: false
			}
		}
		this.updateModel();
	}
	async getTimeEntryDefaultValues(guid) {
		const activity = this._data.openedActivities.find(a => a.guid === guid);
		const user = AuthState.getInstance().getData();
		var aFilter = [];
		aFilter.push(new Filter("UserGuid", "EQ", user.time.guid));
		aFilter.push(new Filter("ActvtType", "EQ", activity.type.id));
		if (activity.id) {
			aFilter.push(new Filter("ActivityId", "EQ", activity.id));
		}
		if (activity.role.mappingId) {
			aFilter.push(new Filter("RoleMpngID", "EQ", activity.role.mappingId));
		}
		var associateType = activity.association.id;
		if (activity.account.id) {
			if (associateType === '501' || associateType === '502') {
				aFilter.push(new Filter("SaleSegType", "EQ", activity.account["SEGMENT"]));
			}
		}
		if (associateType === '502') {
			aFilter.push(new Filter("SaleSegType", "EQ", "NA"));
		}
		const params = {
			filters: aFilter
		};
		let { data } = await this._service.getTimeEntryDefaults(params);
		let defaultValues = data.results, cfTime = "0.0", ncfTime = "0.0";
		defaultValues.forEach(each => {
			if (each.CustomerFacing === "X") {
				cfTime = each.EstimatedHrs;
			}
			else {
				ncfTime = each.EstimatedHrs;
			}
		})

		cfTime = this.convertHrsToDays(cfTime);
		ncfTime = this.convertHrsToDays(ncfTime);

		activity.estimatedTime.cf = cfTime, activity.estimatedTime.ncf = ncfTime;

		this.updateModel();

	}
	convertHrsToDays(sHours) {
		var days = 0;
		const loggedInUser = AuthState.getInstance().getData();
		const timeMatrix = loggedInUser.time.unit;
		if (timeMatrix === "D") {
			sHours = parseFloat(sHours, 1);
			days = sHours / 8;
			var oDecimals = days - Math.floor(days);
			if (oDecimals === 0 || oDecimals > 0.5) {
				days = Math.round(days);
			} else if (oDecimals > 0 && oDecimals < 0.5) {
				days = Math.round(days) + 0.5;
			}
			return days.toString();
		} else {
			return sHours;
		}
	}
	async getMTRTasks(guid) {
		const activity = this._data.openedActivities.find(a => a.guid === guid);
		const user = AuthState.getInstance().getData();
		let mtrTasks = [];
		if (user.activityRecording) {

			mtrTasks = await this.timeState.getTasksByActivity(activity.type.id, activity.association.id)

		}
		return mtrTasks
	}
	getUserTimeMatrics(activityId) {
		var that = this;
		var timeStateModel = this.timeState.getModel()
		if (timeStateModel) {
			var binding = new sap.ui.model.Binding(timeStateModel, "/entries", timeStateModel.getContext(
				"/entries"));
			binding.attachChange(function () {
				var timeStateModel = that.timeState.getModel()
				var entries = timeStateModel.getProperty("/entries");
				if (entries.length && !that.triggered) {
					that.triggered = true;
					that.displaySaveSubmitEntries(activityId);
				}
			});
			binding.refresh(true);
		}

	}
	async getActivityUserEntries(activityId) {
		var that = this;
		const activity = this._data.openedActivities.find(a => a.id === activityId);
		const entries = this.timeState.getData().entries;
		//Customer Facing
		let oCustomerFacing = {
			iSavedHrs: 0,
			iFailedHrs: 0,
			iSubmittedHrs: 0,
			aEntriesArray: [],
			aSavedEntries: [],
			aFailedEntries: [],
			aSubmittedEntries: [],
			aSameSavedEntries: [],
			aSameFailedEntries: [],
			aSameSubmittedEntries: [],
		};

		//Non Customer Facing
		let oNonCustomerFacing = {
			iSavedHrs: 0,
			iFailedHrs: 0,
			iSubmittedHrs: 0,
			aEntriesArray: [],
			aSavedEntries: [],
			aFailedEntries: [],
			aSubmittedEntries: [],
			aSameSavedEntries: [],
			aSameFailedEntries: [],
			aSameSubmittedEntries: [],
		};
		let activityEntries = entries.filter(each => parseInt(each.activity.id, 10) === parseInt(activityId));
		activityEntries = this.sortTimeEntries(activityEntries);
		activityEntries.filter(function (Entry) {
			Entry = $.extend(true, {}, Entry);
			var isCustomerFacing = Entry.customerFacing;
			var workDuration = parseFloat(Entry.duration.original);
			switch (Entry.status.id) {
				case "1":
					if (isCustomerFacing) {
						oCustomerFacing = that.fnSetFormatCFNCFData("1", workDuration, Entry, oCustomerFacing);
					} else {
						oNonCustomerFacing = that.fnSetFormatCFNCFData("1", workDuration, Entry, oNonCustomerFacing);
					}
					break;
				case "3":
					if (isCustomerFacing) {
						oCustomerFacing = that.fnSetFormatCFNCFData("3", workDuration, Entry, oCustomerFacing);
					} else {
						oNonCustomerFacing = that.fnSetFormatCFNCFData("3", workDuration, Entry, oNonCustomerFacing);
					}
					break;
				case "4":
					if (isCustomerFacing) {
						oCustomerFacing = that.fnSetFormatCFNCFData("4", workDuration, Entry, oCustomerFacing);
					} else {
						oNonCustomerFacing = that.fnSetFormatCFNCFData("4", workDuration, Entry, oNonCustomerFacing);
					}
					break;
				default:
					break;
			}
		});
		activity.estimatedTime.customerFacing = oCustomerFacing;
		activity.estimatedTime.nonCustomerFacing = oNonCustomerFacing;
		this.updateModel();
		// oViewSettingsModel.setProperty("/oCustomerFacing", oCustomerFacing);
		// oViewSettingsModel.setProperty("/oNonCustomerFacing", oNonCustomerFacing);

	}
	//Function to create CF / NCF data
	fnSetFormatCFNCFData(statusId, workDuration, oEntry, oCustomerInvestment) {
		var sHrs, sEntries, sSameEntries;
		switch (statusId) {
			case "1":
				sHrs = "iSavedHrs";
				sEntries = "aSavedEntries";
				sSameEntries = "aSameSavedEntries";
				break;
			case "3":
				sHrs = "iFailedHrs";
				sEntries = "aFailedEntries";
				sSameEntries = "aSameFailedEntries";
				break;
			case "4":
				sHrs = "iSubmittedHrs";
				sEntries = "aSubmittedEntries";
				sSameEntries = "aSameSubmittedEntries";
				break;
			default:
		}

		oCustomerInvestment[sHrs] = oCustomerInvestment[sHrs] + workDuration;
		oCustomerInvestment[sEntries].push(oEntry);
		var updateSameDateEntries = this.fnFindSameDateEntries(oEntry, oCustomerInvestment[sSameEntries]);
		oCustomerInvestment[sSameEntries] = updateSameDateEntries;
		return oCustomerInvestment;
	}

	//Function to find if same date entries are available, for grouping Saved/Failed/Submitted hrs
	fnFindSameDateEntries(oEntry, aEntries) {
		var sameDateEntryobj = aEntries.find(function (obj) {
			if (obj.recordDate === oEntry.recordDate) {
				var workDuration = parseFloat(oEntry["duration"]["original"]) + parseFloat(obj["duration"]["original"]);
				obj["duration"]["original"] = workDuration.toString();
				return obj;
			}
		});
		if (!sameDateEntryobj) {
			aEntries.push(oEntry);
		}
		return aEntries;
	}
	async displaySaveSubmitEntries(activityId) {
		await this.getActivityUserEntries(activityId);
	}

}
