import BaseState from "com/melodylib/core/state/BaseState";
import ActivityService from "com/melodylib/activity/service/ActivityService";

/**
 * @name com.melodylib.activity.state.ActivityColumnState
 */
export default class ActivityColumnState extends BaseState {
	constructor() {
		super(ActivityService.getInstance());
		this._data = {
			columns: [],
			map: {},
		};
		this.getColumns();
	}

	static getInstance() {
		if (!this._instance) {
			this._instance = new ActivityColumnState();
		}
		return this._instance;
	}

	getColumns() {
		this._data.map = this._getColumns();
		this._data.columns = this.getColumnsArray();
		this.updateModel();
	}

	updateProperty(name, isSelected) {
		this._data.map[name].selected = isSelected ? true : false;
		this._data.columns = this.getColumnsArray();
		this.updateModel();
	}

	getColumnsArray() {
		const columns = Object.values(this._data.map);
		return columns;
	}

	_getColumns() {
		return {
			activity: {
				key: "activity",
				label: "Activity",
				visible: false,
				selected: true,
			},
			// description: {
			//     key: "description",
			//     label: "Description",
			//     visible: true,
			//     selected: false
			// },
			account: {
				key: "account",
				label: "Account",
				visible: true,
				selected: true,
			},
			opportunity: {
				key: "opportunity",
				label: "Opportunity",
				visible: true,
				selected: true,
			},
			association: {
				key: "association",
				label: "Association",
				visible: true,
				selected: false,
			},
			status: {
				key: "status",
				label: "Status",
				visible: true,
				selected: true,
			},
			lead: {
				key: "lead",
				label: "Lead",
				visible: true,
				selected: true,
			},
			// team: {
			//     key: "team",
			//     label: "Team",
			//     visible: true,
			//     selected: false
			// },
			// additionalOpportunities: {
			//     key: "additionalOpportunities",
			//     label: "Additional Opportunities",
			//     visible: true,
			//     selected: false
			// },
			// contentInKm: {
			//     key: "contentInKm",
			//     label: "Content In KM",
			//     visible: true,
			//     selected: false
			// },
			creationDate: {
				key: "creationDate",
				label: "Creation Date",
				visible: true,
				selected: false,
			},
			startDate: {
				key: "startDate",
				label: "Start Date",
				visible: true,
				selected: false,
			},
			endDate: {
				key: "endDate",
				label: "End Date",
				visible: true,
				selected: false,
			},
			// innovations: {
			//     key: "innovations",
			//     label: "Innovations",
			//     visible: true,
			//     selected: false
			// },
			// landscapes: {
			//     key: "landscapes",
			//     label: "Other Landscapes",
			//     visible: true,
			//     selected: false
			// },
			requestor: {
				key: "requestor",
				label: "Requestor",
				visible: true,
				selected: false,
			},
			risk: {
				key: "risk",
				label: "Risk",
				visible: true,
				selected: true,
			},
			// successFactors: {
			//     key: "successFactors",
			//     label: "Success Factors",
			//     visible: true,
			//     selected: false
			// },
			// solutions: {
			//     key: "solutions",
			//     label: "Solutions",
			//     visible: true,
			//     selected: false
			// },
			// subTitle: {
			//     key: "subTitle",
			//     label: "Sub Title",
			//     visible: true,
			//     selected: false
			// },
			slName: {
				key: "slName",
				label: "Success Line",
				visible: true,
				selected: false,
			},
		};
	}
}
