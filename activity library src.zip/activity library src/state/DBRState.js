import Helper from "com/melodylib/core/util/Helper";
import BaseState from "com/melodylib/core/state/BaseState";
import DBR from "com/melodylib/activity/classes/DBR";
import DBRService from "com/melodylib/activity/service/DBRService";
import VariantState from "com/melodylib/core/state/VariantState";

/**
 * @name com.melodylib.activity.state.DBRState
 */
export default class DBRState extends BaseState {
	constructor() {
		super(DBRService.getInstance());
		const data = {
			dbrList: [],
			totalDBR: 0,
			loading: true,
		};
		this.variantState = VariantState.getInstance();
		this.setData(data);
	}

	static getInstance() {
		if (!this._instance) {
			this._instance = new DBRState();
		}
		return this._instance;
	}

	async init(variantOption) {
		let defaultVariant = await this.variantState.getDefaultVariant(
			variantOption
		);
		const params = defaultVariant ? defaultVariant.configurations : {};
		params.inlineCount = true;
		let isManager = defaultVariant.checkForManagerVariant();
		this.getDBRs(params, isManager);
	}

	async getDBRs(params, isManager) {
		this.setLoading(true);
		const options = Helper.getFilters(params);
		const { data } = await this._service.getDBRList(options, isManager);
		const results = data?.results || [];
		let dbrList = Array.from(results, (dbr) => new DBR(dbr));

		if (params && "inlineCount" in params && params.inlineCount) {
			this._data.dbrList = [];
			this._data.totalDBR = "__count" in data ? data.__count : "0";
		}
		if (this._data && this._data.dbrList.length && dbrList.length) {
			dbrList = [...this._data.dbrList, ...dbrList];
		}
		this._data.dbrList = dbrList;
		this.setLoading(false);
	}

	setLoading(isLoading) {
		this.getData().loading = isLoading ? true : false;
		this.updateModel();
	}
}
