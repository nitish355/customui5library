/*!
 * ${copyright}
 */

/**
 * Initialization Code and shared classes of library com.melodylib.activity.
 */
sap.ui.define([
	"sap/ui/core/library"
], function () {
	"use strict";

	// delegate further initialization of this library to the Core
	// Hint: sap.ui.getCore() must still be used to support preload with sync bootstrap!
	sap.ui.getCore().initLibrary({
		name: "com.melodylib.activity",
		version: "${version}",
		dependencies: [ // keep in sync with the ui5.yaml and .library files
			"sap.ui.core"
		],
		types: [
			"com.melodylib.activity.ExampleColor"
		],
		interfaces: [],
		controls: [
			"com.melodylib.activity.Example",
			"com.melodylib.activity.controls.avatar.Avatar"
		],
		elements: [],
		noLibraryCSS: false // if no CSS is provided, you can disable the library.css load here
	});

	/**
	 * Some description about <code>com.melodylib.activity</code>
	 *
	 * @namespace
	 * @name com.melodylib.activity
	 * @author DARSHAN PULIKESHI
	 * @version ${version}
	 * @public
	 */
	var thisLib = com.melodylib.activity;

	/**
	 * Semantic Colors of the <code>com.melodylib.activity.Example</code>.
	 *
	 * @enum {string}
	 * @public
	 */
	thisLib.ExampleColor = {

		/**
		 * Default color (brand color)
		 * @public
		 */
		Default : "Default",

		/**
		 * Highlight color
		 * @public
		 */
		Highlight : "Highlight"

	};

	return thisLib;

});
