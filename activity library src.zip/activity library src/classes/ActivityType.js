import * as UI5Object from "sap/ui/base/Object";
/**
 * @namespace com.melodylib.activity.classes.ActivityType
 */
export default class ActivityType extends UI5Object {
    constructor(data) {
        super();
        this.setData(data)
    }

    setData(data) {
        this.id = data?.ActvtTypeID || null
        this.description = data?.ActvtTypeDesc || null
        this.info = data?.ActivityTypeInfo || null
        this.active = data?.active || false
        this.layout = {
            id: data?.FormLayoutID || null,
            childId: data?.ChildFrmLayoutId || null
        }
        this.entities = []
    }
    setInfo(info) {
        this.info = info
    }
    setLayout(id, childId) {
        this.layout = {
            id, childId
        }
    }

    setLayoutFields(data) {
        let fields = {
            type: {
                visible: data.ActivityTypeId.Visible,
                required: data.ActivityTypeId.Required,
                property: "",
                isArray: false,
            },
            dryRun: {
                visible: data.DryRunDate.Visible,
                required: data.DryRunDate.Required,
                property: "/dryRun",
                isArray: false,
                errorMessage: "Please select Dry Run",
                label: "Dry Run"
            },
            description: {
                visible: data.Description.Visible,
                required: data.Description.Required,
                property: "/description",
                isArray: false,
                errorMessage: "Please enter Description",
                label: "Description"

            },
            startDate: {
                visible: data.StartDate.Visible,
                required: data.StartDate.Required,
                property: "/startDate",
                isArray: false,
                errorMessage: "Please select start date",
                label: "Start Date"
            },
            endDate: {
                visible: data.EndDate.Visible,
                required: data.EndDate.Required,
                property: "/endDate",
                isArray: false,
                errorMessage: "Please select end date",
                label: "End Date"
            },
            startTime: {
                visible: data.StartTime?.Visible,
                required: data.StartTime?.Required,
                property: "/startDate",
                isArray: false,
                errorMessage: "Please select start date",
                label: "Start Date"
            },
            endTime: {
                visible: data.EndTime?.Visible,
                required: data.EndTime?.Required,
                property: "/endDate",
                isArray: false,
                errorMessage: "Please select end date",
                label: "End Date"
            },
            checkDuplicates: {
                visible: data.CheckDuplicates?.Visible,
                required: data.CheckDuplicates?.Required,
            },
            additionalOpportunities: {
                visible: data.AdditionalOpp.Visible,
                required: data.AdditionalOpp.Required,
                property: "/additionalOpportunities/results",
                isArray: true,
                errorMessage: "Please select additional opportunities",
                label: "Additional Opportunities"
            },
            comments: {
                visible: data.Comments.Visible,
                required: data.Comments.Required,
                property: "/comments",
                isArray: false,
                errorMessage: "Please enter comments",
                label: "Comments"
            },
            detailTypes: {
                visible: data.ActDetailType.Visible,
                required: data.ActDetailType.Required,
                property: "/detailTypes",
                isArray: true,
                errorMessage: "Please select type",
                label: "Type"
            },

            method: {
                visible: data.Method.Visible,
                required: data.Method.Required,
                property: "/method/id",
                isArray: false,
                errorMessage: "Please select method",
                label: "Method"
            },
            solutions: {
                visible: data.Solutions?.Visible,
                required: data.Solutions?.Required,
                isArray: true,
                property: "/solutions/results",
                errorMessage: "Please select Solution(s)",
                label: "Solutions"
            },
            cvjPhase: {
                visible: data.CVJPhase.Visible,
                required: data.CVJPhase.Required,
                isArray: false,
                property: "/cvjPhase/id",
                errorMessage: "Please select CVJ Phase",
                label: "Solution"
            },
            risk: {
                visible: data.ActivityRisk.Visible,
                required: data.ActivityRisk.Required,
                isArray: false,
                property: "/risk/id",
                errorMessage: "Please select risk",
                label: "Risk"
            },
            riskComments: {
                visible: data.ActivityRisk.Visible,
                required: data.ActivityRisk.Required,
                isArray: false,
                property: "",
                label: "Risk Comments"
            },
            lead: {
                visible: data.ActLead.Visible,
                required: data.ActLead.Required,
                property: "/lead/id",
                isArray: false,
                errorMessage: "Please select Lead",
                label: "Lead"
            },
            team: {
                visible: data.ActTeam?.Visible,
                required: data.ActTeam?.Required,
                property: "/team/results",
                isArray: true,
                errorMessage: "Please select team members",
                label: "Team"
            },
            accountExecutive: {
                visible: data.AccountExecutive?.Visible,
                required: data.AccountExecutive?.Required,
                property: "/accountExecutive/id",
                isArray: false,
                errorMessage: "Please select Account Executive",
                label: "Account Executive"
            },

            assetsDocsSection: {
                visible: data.AssetsDocsSection?.Visible,
                required: data.AssetsDocsSection?.Required,
                property: "/files/results",
                errorMessage: "Please add Assets and Documents",
                isArray: true
            },
            cusInvestmentSection: {
                visible: data.CusInvestmentSection?.Visible,
                required: data.CusInvestmentSection?.Required,
                property: ""
            },
            demoEnvSection: {
                visible: data.DemoEnvSection?.Visible,
                required: data.DemoEnvSection?.Required,
                property: "",
            },
            demoEducation: {
                visible: data.DemoEducation?.Visible,
                required: false,
                property: "/landscapes/results",
                isArray: true,
                label: "Demo Education"

            },
            landscapes: {
                visible: data.Landscapes?.Visible,
                required: false,
                property: "/landscapes/results",
                isArray: true,
                label: "Landscapes"
            },
            successFactors: {
                visible: data.SuccessFactors?.Visible,
                required: false,
                property: "/successFactors/results",
                isArray: true,
                label: "Success Factors"
            },
            cloudEnvironments: {
                visible: data.CloudEnvironments?.Visible,
                required: false,
                property: "/cloudEnvironments/results",
                isArray: true,
                label:"Cloud Environments"
            },
            cusExperience: {
                visible: data.CusExperience?.Visible,
                required: data.CusExperience?.Required,
                property: ""
            },
            informationSection: {
                visible: data.InformationSection?.Visible,
                required: data.InformationSection?.Required,
                property: ""
            },
            detailSection: {
                visible: data.DetailSection?.Visible,
                required: data.DetailSection?.Required,
                property: ""
            },
            teamSection: {
                visible: data.TeamSection?.Visible,
                required: data.TeamSection?.Required,
                property: ""
            },
            customerFacingTime: {
                visible: data.CustomerFacingTime?.Visible,
                required: data.CustomerFacingTime?.Required,
                property: ""
            },
            nonCustomerFacingTime: {
                visible: data.NonCustomerFacingTime?.Visible,
                required: data.NonCustomerFacingTime?.Required,
                property: ""
            }
        }
        this.layout.fields = fields;
        // this.layout.fieldsConfig = fieldsConfig
    }
    setEntities(entities) {
        this.entities = entities
    }
    setActive(active) {
        this.active = active
    }
}