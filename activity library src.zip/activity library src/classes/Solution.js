import * as UI5Object from "sap/ui/base/Object";
/**
 * @namespace com.melodylib.activity.classes.Solution
 */
export default class Solution extends UI5Object {
    constructor(data) {
        super();
        this.setData(data)
    }

    setData(data) {
        this.id = data?.id || null
        this.guid = data?.guid || null
        this.name = data?.name || ''
        this.parentGuid = data?.parentGuid || false
        this.isFinal = data.isFinal || false
        this.partiallySelected = data.partiallySelected || false
        this.selected = data.selected || false
    }
    setPartialSelection(selected) {
        this.partiallySelected = selected
    }
    setSelection(selected) {
        this.selected = selected
    }
}