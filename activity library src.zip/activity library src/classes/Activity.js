import * as UI5Object from "sap/ui/base/Object";
import ActivityMasterState from "com/melodylib/activity/state/ActivityMasterState";
import ActivityType from 'com/melodylib/activity/classes/ActivityType';
/**
 * @namespace com.melodylib.activity.classes.Activity
 */

export default class Activity extends UI5Object {
    constructor(data) {
        super();
        this.setData(data);

    }

    setData(data) {
        if (data) {
            this.setCostTypeValue(data);
            this.id = data.ActivityId ? data.ActivityId : "";
            this.guid = data.ActivityGUID ? data.ActivityGUID : "";
            this.name = data.name ? data.name : 'New Activity';
            this.description = data?.Description || "";
            this.setType(data);
            this.association = {
                id: data?.ActAsstId || '501',
                name: ""
            }
            if (data?.ActAsstId) {
                this.setAssociation();
            }
            this.set = {
                id: data?.ActivitySetId || null,
                description: data?.ActivitySetdescription || null
            }
            this.status = {
                id: data.ActStatus ? data.ActStatus : "",
                description: data.ActStatusDesc ? data.ActStatusDesc : ""
            }

            this.opportunity = {
                id: data.OpportunityId ? data.OpportunityId : "",
                description: ""
            }

            this.account = {
                id: data?.GlobalUltimateID || "",
                name: ""
            }

            this.risk = {
                id: data?.RiskId || "",
                description: data?.RiskDesc || "",
                comments: data?.RiskComment || ""
            }

            this.setRiskType();

            this.method = {
                id: data?.MethodId || "",
                description: data?.MethodDescription || ""
            }

            this.cvjPhase = {
                id: data?.CvjPhaseId || "",
                description: data?.CvjPhaseDesc || ""
            }
            this.detailTypes = data?.detailTypes || []



            this.lead = {
                id: data?.ActivityLead || "",
                name: data?.ActivityLeadName || "",
                initials: data?.ActivityLeadName ? this.generateInitials(data.ActivityLeadName) : "",
                email: data.ActivityLeadEmail
            }

            this.role = {
                id: data?.RoleID || null,
                mappingId: data?.RoleMpngID || null
            }

            this.estimatedTime = {
                ncf: data?.NCFEstimatedTime || "",
                cf: data?.estimatedTime || ""
            }

            this.requestor = {
                id: data?.Requestor || "",
                name: data?.RequestorName || ""
            }

            this.sl = {
                id: data?.SlSnro || "",
                name: data?.SlName || "",
                statusId: data?.SlStatusId || "",
                activityGuid: data?.SLActGUID || "",
            }

            this.team = {
                count: 0,
                results: []
            };
            this.files = {
                count: 0,
                results: data?.files || []
            };
            this.additionalOpportunities = {
                count: 0,
                results: []
            };
            this.innovations = {
                count: 0,
                results: []
            };
            this.landscapes = {
                count: 0,
                results: []
            };
            this.showrooms = {
                count: 0,
                results: []
            };
            this.successFactors = {
                count: 0,
                results: []
            };
            this.solutions = {
                count: 0,
                results: []
            };
            this.cloudEnvironments = {
                count: 0,
                results: []
            };

            this.accountExecutive = {
                id: data?.AccountExecutive || null,
                name: data?.AccountExecutiveName || null,
                email: data?.AccountExecutiveEmailId || null,
                initials: data?.AccountExecutiveName ? this.generateInitials(data.AccountExecutiveName) : "",
            }

            this.startDate = data.StartDate ? data.StartDate : this.setDate("startDate");
            this.endDate = data.EndDate ? data.EndDate : this.setDate("endDate");
            this.createdOn = data.CreateDate ? data.CreateDate : new Date();
            this.dryRun = data?.DryRunDate || null;
            this.region = data?.Region || "";
            this.marketUnit = data?.marketUnit || "";
            this.title = data?.title || "";
            this.deliveryTeamId = data.DeliveryTeamId ? data.DeliveryTeamId : "";
            this.hostTypeId = data.HostTypeId ? data.HostTypeId : "";
            this.projectId = data.ProjectId ? data.ProjectId : "";
            this.subTitle = data.SubTitle ? data.SubTitle : "";
            this.topDealFlag = data.TopDealFlag ? data.TopDealFlag : "";
            this.useCaseId = data.UseCaseId ? data.UseCaseId : "";
            this.setBusyData(data.ActivityId ? true : false);
            this.valueStates = {
                type: {
                    state: 'None',
                    message: 'Activity Type'
                },
                account: {
                    state: 'None',
                    message: 'Account'
                },
                opportunity: {
                    state: 'None',
                    message: 'Opportunity'
                },
                startDate: {
                    state: 'None',
                    message: "Start date"
                },
                endDate: {
                    state: 'None',
                    message: "End date"
                },
                additionalOpportunities: {
                    state: 'None',
                    message: "Additional opportunities"
                },
                comments: {
                    state: 'None',
                    message: "Comments"
                },
                detailTypes: {
                    state: 'None',
                    message: "Type"
                },
                method: {
                    state: 'None',
                    message: "Method"
                },
                solutions: {
                    state: 'None',
                    message: "Solutions"
                },
                cvjPhase: {
                    state: 'None',
                    message: "CVJ Phase"
                },
                risk: {
                    state: "None",
                    message: "Risk"
                },
                riskComment: {
                    state: 'None',
                    message: 'Risk assessment comment'
                },
                dryRun: {
                    state: 'None',
                    message: "Dry run date"
                },
                description: {
                    state: 'None',
                    message: "Description"
                },
                lead: {
                    state: 'None',
                    message: 'Lead'
                },
                team: {
                    state: 'None',
                    message: "Team members"
                },
                accountExecutive: {
                    state: 'None',
                    message: "Account executive"
                },
                files: {
                    state: 'None',
                    message: 'Assets and documents'
                },
                demoEnvSection: {
                    state: 'None',
                    message: 'Atleast one of the demo environments section should be added'
                },

            }
            this.validationErrors = [],
                this.setSolutionsMap()
            this.solLevel = {}
            this.materials = []
            this.modified = {
                lead: false,
                executive: false,
                team: false
            }


        }
    }



    setBusyData(busy) {
        this.busy = {
            count: busy,
            detail: busy,
            files: busy,
            team: busy,
            landscapes: busy,
            successFactors: busy,
            cloudEnvironments: busy,
            detailTypes: busy,
            cvjPhases: busy,
            types: busy,
            opportunity: busy,
            account: busy,
            solutions: busy,
            additionalOpportunities:busy
        };
    }

    setBusy(property, busy) {
        this.busy[property] = busy
    }

    setRiskType() {
        switch (this.risk.description.toUpperCase()) {
            case 'RED':
                this.risk.state = "Error";
                break;
            case 'YELLOW':
                this.risk.state = "Warning";
                break;
            case 'GREEN':
                this.risk.state = "Success";
                break;
            default:
                this.risk.state = "None";
                break;
        }
    }

    setAssociation() {
        if (this.association) {
            switch (this.association.id) {
                case '501':
                    this.association.name = "Account";
                    this.association.index = 0;
                    break;
                case '502':
                    this.association.name = "Opportunity";
                    this.association.index = 1;
                    break;
                case '503':
                    this.association.name = "No Association";
                    this.association.index = 2;
                    break;
                default:
                    this.association.name = "";
                    this.association.index = -1;
                    break;

            }
        }

    }

    setCounts(data) {
        if (data) {
            this.team.count = data.TeamCount;
            this.files.count = data.FileCount;
            this.additionalOpportunities.count = data.AddOppCount;
            this.innovations.count = data.StrSolCount;
            this.landscapes.count = data.LandscapeCount;
            this.showrooms.count = data.ShowroomCount;
            this.successFactors.count = data.SuccessFCount;
            this.solutions.count = data.SolutionCount;
            this.cloudEnvironments.count = data.CloudEnvCount;
        }
    }

    setCountData(property, countData) {
        this[property].results = countData ?? [];
    }

    setLead() {
        return {
            name: this.leadName,
            id: this.leadId,
            roleDescription: this.roleDescription,
            initials: this.leadName ? this.generateInitials(this.leadName) : null,
            email: this.leadEmail
        }
    }

    generateInitials(name) {
        let initials = '';
        if (name) {
            const words = name.split(" ");
            for (let i = 0; i < words.length; i++) {
                initials += words[i][0].toUpperCase();
            }
        }
        return initials;
    }

    setAccount(account) {
        if (account) {
            this.account = account;
            this.busy.account = false;
        }
        // this.account.id = account?.id;
        // this.account.name = account?.name;
    }

    setOpportunity(opportunity) {
        if (opportunity) {
            this.opportunity = opportunity;
        }
        this.busy.opportunity = false;
        // this.opportunity.id = opportunity?.id;
        // this.opportunity.description = opportunity?.description;
    }

    setAssociateType() {
        let associateType = 0;
        switch (this.association.id) {
            case '501':
                associateType = 0;
                break;
            case '502':
                associateType = 1;
                break;
            case '503':
                associateType = 2;
                break;
            default:
                associateType = 0;
                break;

        }
        this.association.type = associateType
    }

    setDetail(data) {
        Object.keys(data).forEach(property => this[property] = data[property])
    }


    setType(data) {
        const activityMasterState = ActivityMasterState.getInstance();
        const types = activityMasterState.getData().types;
        const type = types?.find(each => each.id === data.ActivityTypeId);
        if (type) this.type = type;
        else { this.type = new ActivityType({ ActvtTypeID: data.ActivityTypeId, ActvtTypeDesc: data.ActivityTypeDescription || data.ActTypeDesc }) };
        let id = data.FormLayoutId, childId = data.ChildFrmLayoutId
        this.type.setLayout(id, childId); // don't remove this
    }

    updateAssociation() {
        // if (this.type?.id) {
        //     this.setType(this.type.id);
        // }
    }

    setSolutionsMap() {
        // setting level2data to map
        const activityMasterState = ActivityMasterState.getInstance();
        const level2Data = activityMasterState.getData().level2Data;
        this.solHierarchyMap = new Map();
        level2Data.forEach(each => this.solHierarchyMap.set(each.guid, { ...each }));
    }

    setModified(property, modified) {
        this.modified[property] = modified
    }

    setJustificationComments(comment) {
        this.justificationComment = comment
    }

    setDate(property) {
        let date = new Date();
        if (property === 'startDate') date.setHours(9, 0, 0)
        else if (property === 'endDate') date.setHours(17, 0, 0)
        return date;
    }

    setCostTypeValue(oData){
        if(oData){
            if (oData.CostTypeValue && oData.CostTypeValue !== "") {
					this.CostTypeName = oData.CostTypeName;
					this.CostTypeValue = oData.CostTypeValue;
				} else if (oData.ActAsstId.toString() === "501") {
					this.CostTypeName = "Account";
					this.CostTypeValue = oData.GlobalUltimateID;
				} else if (oData.ActAsstId.toString() === "502") {
					this.CostTypeName = "Opportunity";
					this.CostTypeValue = oData.OpportunityId;
				} else if (oData.ActAsstId.toString() === "503") {
					this.CostTypeName = "Cost Center";
					this.CostTypeValue = "";
				} else {
					this.CostTypeName = "";
					this.CostTypeValue = "";
				}
        }
        else {
            this.CostTypeValue = "";
        }
    }



}