import * as UI5Object from "sap/ui/base/Object";
// import ActivityMasterState from "com/melodylib/activity/state/ActivityMasterState";
// import ActivityType from 'com/melodylib/activity/classes/ActivityType';
/**
 * @namespace com.melodylib.activity.classes.DBR
 */

export default class DBR extends UI5Object {
	constructor(data) {
		super();
		this.setData(data);
	}

	setData(data) {
		if (data) {
			this.id = data.RequestId ? data.RequestId : "";
			this.guid = data.RequestGuid ? data.RequestGuid : "";
			this.activityId = data.ActivityId ? data.ActivityId : "";
			this.activityGuid = data.ActivityGUID ? data.ActivityGUID : "";
			this.account = data.AccountName ? data.AccountName : "";
			this.status = {
				id: data.StatusId ? data.StatusId : "",
				description: data.Status ? data.Status : "",
			};
			this.owner = {
				id: data?.RequestOwnerId || "",
				name: data?.RequestOwner || "",
				initials: data?.RequestOwner
					? this.generateInitials(data.RequestOwner)
					: "",
			};
			this.dealAdvisor = {
				id: data?.DealAdvisorId || "",
				name: data?.DealAdvisor || "",
				initials: data?.DealAdvisor
					? this.generateInitials(data.DealAdvisor)
					: "",
			};
			this.requestor = {
				id: data?.UserId || "",
				name: data?.Requestor || "",
				initials: data?.Requestor ? this.generateInitials(data.Requestor) : "",
			};
			this.resourceManager = {
				id: data?.ResourceManagerId || "",
				name: data?.ResourceManager || "",
				initials: data?.ResourceManager
					? this.generateInitials(data.ResourceManager)
					: "",
			};
			this.statusReason = {
				id: data.StatusReasonId ? data.StatusReasonId : "",
				description: data.StatusReason ? data.StatusReason : "",
			};
			this.endDate = data.EndDate ? data.EndDate : "";
		}
	}

	generateInitials(name) {
		const words = name.split(" ");
		let initials = "";
		for (let i = 0; i < words.length; i++) {
			initials += words[i][0].toUpperCase();
		}
		return initials;
	}
}
