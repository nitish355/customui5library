/*!
 * ${copyright}
 */

sap.ui.define(
	["jquery.sap.global"],

	function (jQuery) {
		"use strict";

		/**
		 * Avatar renderer.
		 * @namespace
		 */
		var AvatarRenderer = {};

		/**
		 * Renders the HTML for the given control, using the provided
		 * {@link sap.ui.core.RenderManager}.
		 *
		 * @param {sap.ui.core.RenderManager} oRm
		 *            the RenderManager that can be used for writing to
		 *            the Render-Output-Buffer
		 * @param Control oControl
		 *            the control to be rendered
		 */
		AvatarRenderer.render = function (oRm, oControl) {

			oRm.write("<div");

			//add this controls style class (plus any additional ones the developer has specified)
			oRm.addClass("activityleadalign");
			oRm.writeClasses(oControl);

			//next, render the control information, this handles your sId (you must do this for your control to be properly tracked by ui5).
			oRm.writeControlData(oControl);
			oRm.write(">");
			if (oControl.getIconOnly()) oRm.renderControl(oControl.getAggregation("_teamCount"))
			else {
				oControl.getType() !== "individual" && oControl.getMode() === "CREATE" && oRm.renderControl(oControl.getAggregation("_multiInput"));
				oControl.getType() === "individual" && oControl.getMode() === "CREATE" && oRm.renderControl(oControl.getAggregation("_input"));
				oControl.getType() === "individual" ? oRm.renderControl(oControl.getAggregation("_avatar")) : oRm.renderControl(oControl.getAggregation("_avatarGroup"));
				// oControl.getType() !== "individual" && oControl.getMode() === "CREATE" && oRm.renderControl(oControl.getAggregation("_button"));
				// oControl.getType() === "individual" && oControl.getMode() === "CREATE" && oRm.renderControl(oControl.getAggregation("_editButton"));
				oControl.getMode() === "READ" && ((oControl.getType() === "individual" && !oControl.getLeadInfo()) || (oControl.getType() === "group" && !oControl.getTeamMembers().length)) && oRm.renderControl(oControl.getAggregation("_notAvailableText"))
			}
			oRm.write("</div>");
		};

		return AvatarRenderer;
	},
	/* bExport= */ true
);
