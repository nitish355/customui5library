sap.ui.define(function () {
	"use strict";

	return {
		name: "QUnit TestSuite for com.melodylib.core",
		defaults: {
			bootCore: true,
			ui5: {
				libs: "sap.ui.core,com.melodylib.core",
				theme: "sap_horizon",
				noConflict: true,
				preload: "auto"
			},
			qunit: {
				version: 2,
				reorder: false
			},
			sinon: {
				version: 4,
				qunitBridge: true,
				useFakeTimers: false
			},
			module: "./{name}.qunit",
			coverage: {
				only: ["com/melodylib/core/"],
				never: ["test-resources/"]
			}
		},
		tests: {
			// test file for the Example control
			Example: {
				title: "QUnit Test for Example",
				_alternativeTitle: "QUnit tests: com.melodylib.core.Example"
			}
		}
	};
});
