sap.ui.define(
	{
		DataSources: [
			{
				name: "activityModel",
				url: "/int_ls/sap/opu/odata/sap/YACTIVITY_SRV",
			},
			{
				name: "utility",
				url: "/int_ls/sap/opu/odata/sap/YUTILITY_SRV",
			},
			{
				name: "roster",
				url: "/int_ls/sap/opu/odata/SAP/YROSTER_SRV;v=0002",
			},
			{
				useBatch: true,
				name: "harmony",
				url: "/int_ic/sap/opu/odata/sap/zharmony_callidus_srv",
			},
			{
				useBatch: true,
				name: "opportunity",
				url: "/int_ls/sap/opu/odata/sap/YOPPORTUNITY_SRV",
			},
			{
				name: "oreModel",
				url: "/int_ls/sap/opu/odata/sap/YUTILITY_SRV",
			},
			{
				name: "utility",
				url: "/int_ls/sap/opu/odata/sap/YUTILITY_SRV",
			},
			{
				name: "mtr",
				url: "/int_ls/sap/opu/odata/sap/YMTR_SRV",
			},
			{
				name: "activity",
				url: "/int_ls/sap/opu/odata/sap/YACTIVITY_SRV",
			},
			{
				name: "activityList",
				url: "/int_ls/sap/opu/odata/sap/YACTIVITYLIST_SRV",
			},
			{
				name: "isp",
				url: "/int_is/sap/opu/odata/sap/ZCATSXTMO",
			},
			{
				name: "successLine",
				url: "/int_ls/sap/opu/odata/sap/YSUCCESSLINE_SRV",
			},
			{
				name: "melodyDashboard",
				url: "/int_ls/sap/opu/odata/sap/YMELODY_SRV",
			},
			{
				name: "cpi",
				url: "/int_pc/sap/opu/odata/sap/YMELODY_EXTERNAL_INTEGRATION_SRV"
			},
			{
			name: "melody",
			url: "/int_pc/sap/opu/odata/sap/YMELODY_SRV"
			}
		],
	},
	true
);
