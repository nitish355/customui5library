sap.ui.define({
    Array: "array",
    Date: "date",
    DateRange: "dateRange",
    Number: "number",
    NumberRange: "numberRange",
    String: "string"
},true)