import MessageToast from "sap/m/MessageToast";
import * as UI5Object from "sap/ui/base/Object";
import Actions from "com/melodylib/core/enum/Actions";
import PropertyType from "com/melodylib/core/enum/PropertyType";
import FilterProperty from "com/melodylib/core/classes/FilterProperty";

export default class Variant extends UI5Object {
	constructor(data, viewName) {
		super();
		this.id = data?.variantid || "";
		this.name = data?.variant_name || "";
		this.role = data?.role || "";
		this.viewName = data?.view_name || "";
		this.includeTeam = data?.includeteam === "X" ? true : false;
		this.editable = data?.Editable === "X" ? true : false;
		this.applicationId = data?.applicationid || "LIREP";
		this.createdBy = data?.author || "";
		this.default = data?.defaultVariant === "X" ? true : false;
		this.executeOnSelect = data?.executeonselect === "X" ? true : false;
		this.firstName = data?.name_first || "";
		this.lastName = data?.name_last || "";
		this.psUser = data?.psuser || "";
		this.seUser = data?.seuser || "";
		this.type = data?.type || "";
		this.sharing =
			data?.type === "P" ? sap.m.SharingMode.Private : sap.m.SharingMode.Public;
		this.favourite = data?.Favourite === "X" ? true : false;
		this.configurations = data?.filterstring || "";
	}

	/**
	 * @author DARSHAN
	 * @function parseFilterString
	 * @description function to convert filter string into FilterProperty Object
	 */
	parseFilterString() {
		let configurations = {
			properties: {},
			sort: {},
			group: {},
			search: "",
		};

		if (this.viewName === Actions.variantGroupTypes.activity) {
			configurations.tab = "00";
		}

		try {
			const obj = JSON.parse(this.configurations);
			if (obj) {
				if (obj?.properties) {
					const properties = { ...obj.properties };
					for (let key in properties) {
						let property = properties[key];
						property = new FilterProperty(property);
						//FORMAT DATES
						if (property.type === "dateRange") {
							let dateProperty = property.values;
							dateProperty.value1 = dateProperty.value1
								? new Date(dateProperty.value1)
								: null;
							dateProperty.value2 = dateProperty.value2
								? new Date(dateProperty.value2)
								: null;
						}
						if (property.type === "date") {
							let dateProperty = property.values;
							dateProperty.value1 = dateProperty.value1
								? new Date(dateProperty.value1)
								: null;
						}
						configurations.properties[property.key] = property;
					}
					this.validVariant = true;
				}

				if (obj?.tab) {
					configurations.tab = obj.tab;
				}
				if (obj?.search) {
					configurations.search = obj.search;
				}
				if (obj?.sort) {
					configurations.sort = obj.sort;
				}
				if (obj?.group) {
					configurations.group = obj.group;
				}
			}
			this.configurations = configurations;
		} catch (error) {
			this.validVariant = false;
			this.configurations = configurations;
		}
	}

	/**
	 * @author DARSHAN
	 * @function setFilterString
	 * @description function to set filterString Object
	 * @param {String} key
	 * @param {Object} data
	 */
	setFilterString(key, value) {
		let filterStrings = { ...this.filterString };
		filterStrings[key] = new FilterProperty(value);
		this.filterString = filterStrings;
	}

	/**
	 * @author DARSHAN
	 * @function getDefaultVariant
	 * @description function to get the default variant
	 * @param {Object} variants
	 */
	static getDefaultVariant(variants) {
		return (
			variants.find((variant) => {
				return variant.default;
			}) || false
		);
	}

	/**
	 * @author DARSHAN
	 * @function getCreatePayload
	 * @description function to set create variant payload
	 * @param {Object} data
	 */
	static getCreatePayload(data) {
		return {
			Favourite: data?.favourite ? "X" : "",
			applicationid: data?.applicationId || "",
			defaultVariant: data?.default ? "X" : "",
			executeonselect: data?.executeOnSelect ? "X" : "",
			filterstring: data?.configurations || "",
			includeteam: data?.includeTeam || "",
			type: data?.type || "",
			variant_name: data?.name || "",
			variantid: data?.id || "",
			view_name: data?.viewName || "",
		};
	}

	/**
	 * @author DARSHAN
	 * @function getUpdatePayload
	 * @description function to set update variant payload
	 * @param {Object} data
	 */
	static getUpdatePayload(data) {
		return {
			...this.getCreatePayload(data),
			Editable: data?.editable ? "X" : "",
			author: data?.createdBy || "",
			name_first: data?.firstName || "",
			name_last: data?.lastName || "",
			psuser: data?.psUser || "",
			seuser: data?.seUser || "",
		};
	}

	/**
	 * @author DARSHAN
	 * @function getVariantForPost
	 * @description function to find the variant based on id and return for post
	 * @param {Object} data
	 */
	static getVariantForPost(variants, id) {
		const tempVariants = JSON.parse(JSON.stringify(variants));
		let variant =
			tempVariants.find((item) => {
				return item.id === id;
			}) || false;
		if (variant) {
			if (
				variant?.configurations &&
				typeof variant.configurations !== "string"
			) {
				variant.configurations = JSON.stringify(variant.configurations);
			}
			return variant;
		}
		return false;
	}

	/**
	 * @author BALWANT, DARSHAN
	 * @function hasConfigurationChanged
	 * @description function to check and compare the data which is changed in the variant
	 * @param {Object} configurations
	 * @param {Object} data
	 */
	hasConfigurationChanged(configurations, modifiedkeys) {
		try {
			if (!configurations || !modifiedkeys) {
				return false;
			}
			let modified = false;
			for (let i = 0; i < modifiedkeys.length; i++) {
				let modifiedKey = modifiedkeys[i];
				let key = modifiedKey.key.toUpperCase();
				const property = modifiedKey.property;
				switch (key) {
					case "TAB":
						if (configurations?.tab !== this.configurations?.tab) {
							return true;
						}
						break;
					case "SORT":
						if (
							this.hasSortChanged(configurations.sort, this.configurations.sort)
						) {
							return true;
						}
						break;
					case "GROUP":
						if (
							this.hasGroupChanged(
								configurations.group,
								this.configurations.group
							)
						) {
							return true;
						}
						break;
					case "SEARCH":
						if (configurations?.search !== this.configurations?.search) {
							return true;
						}
						break;
					default: //PROPERTIES
						if (configurations.properties[property]) {
							if (
								this.hasPropertyChanged(configurations.properties[property])
							) {
								return true;
							}
						}
						break;
				}
			}

			return modified;
		} catch (error) {
			console.log("ERROR IN  hasConfigurationChanged: ", error);
		}
	}

	/**
	 * @author DARSHAN
	 * @function hasPropertyChanged
	 * @description function to check and compare the data which is changed in the variant
	 * @param {Object} data
	 */
	hasPropertyChanged(property) {
		let modified = false;
		if (this.configurations.properties[property.key]) {
			const activeProperty = this.configurations.properties[property.key]; //Active Properties
			// property; //Backup
			switch (property.type) {
				case PropertyType.Array:
					{
						let containString = typeof activeProperty.values[0] === "string";
						if (!containString) {
							if (activeProperty.values.length !== property.values.length) {
								return true;
							}
							modified = !activeProperty.values.every((item1) =>
								property.values.some((item2) => item1.value1 === item2.value1)
							);
						} else {
							if (activeProperty.values.length !== property.values.length) {
								return true;
							}
							modified = !activeProperty.values.every((item1) =>
								property.values.some((item2) => item1 === item2)
							);
						}
					}
					break;
				case PropertyType.Date:
					{
						const date1 = property.values.value1
							? new Date(property.values.value1).getTime()
							: null;
						const date2 = activeProperty.values.value1
							? new Date(activeProperty.values.value1).getTime()
							: null;
						modified = date1 !== date2;
					}
					break;
				case PropertyType.DateRange:
					{
						const startdate1 = property.values.value1
							? new Date(property.values.value1).getTime()
							: null;
						const enddate1 = property.values.value2
							? new Date(property.values.value2).getTime()
							: null;
						const startdate2 = activeProperty.values.value1
							? new Date(activeProperty.values.value1).getTime()
							: null;
						const enddate2 = activeProperty.values.value2
							? new Date(activeProperty.values.value2).getTime()
							: null;

						const startEqual = startdate1 !== startdate2;
						const endEqual = enddate1 !== enddate2;
						modified = startEqual || endEqual;
					}
					break;
				default: //string
					if (property.values && activeProperty.values) {
						modified = property.values !== activeProperty.values;
					}
			}
		}
		return modified;
	}

	/**
	 * @author DARSHAN
	 * @function hasSortChanged
	 * @description function to check and compare the sort data which is changed in the variant
	 * @param {Object} data
	 */
	hasSortChanged(backUpSort, activeSort) {
		if (!activeSort || (activeSort && !"sortBy" in activeSort)) {
			return false;
		}
		const value = activeSort?.sortBy !== backUpSort?.sortBy;
		const desc = activeSort?.sortOrderDesc !== backUpSort?.sortOrderDesc;
		return value || desc;
	}

	/**
	 * @author DARSHAN
	 * @function hasGroupChanged
	 * @description function to check and compare the group data which is changed in the variant
	 * @param {Object} data
	 */
	hasGroupChanged(backUpGroup, activeGroup) {
		if (!activeGroup || (activeGroup && !"groupBy" in activeGroup)) {
			return false;
		}
		const value = activeGroup?.groupBy !== backUpGroup?.groupBy;
		const desc = activeGroup?.groupOrderDesc !== backUpGroup?.groupOrderDesc;
		return value || desc;
	}

	/**
	 * @author DARSHAN
	 * @function showErrorMsg
	 * @description function to show error messages
	 * @param {String} msg
	 */
	static showErrorMsg(msg) {
		if (!msg) {
			msg = "Please save the standard variant to proceed.";
		}
		MessageToast.show(msg, {
			duration: 4000,
		});
	}

	/**
	 * @author DARSHAN
	 * @function checkForManagerVariant
	 * @description function to check whether a variant is belongs to any of the mentioned manager variant
	 * @param {Object} variant
	 * TODO: Check team default
	 */
	checkForManagerVariant() {
		// const teamViewNames = ["DEFAULT", "TEAMDEFAULT", "MYDBR"];
		const teamViewNames = ["TEAMDEFAULT"];
		if (this.includeTeam && teamViewNames.indexOf(this.viewName) !== -1) {
			return true;
		} else {
			return false;
		}
	}
}
