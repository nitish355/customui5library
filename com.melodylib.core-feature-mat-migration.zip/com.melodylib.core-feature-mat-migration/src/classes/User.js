import Device from "sap/ui/Device";
import * as UI5Object from "sap/ui/base/Object";
import Account from "com/melodylib/time/classes/Account";
import ManualIO from "com/melodylib/time/classes/ManualIO";
import DateService from "com/melodylib/core/service/DateService";
import Staffing from "com/melodylib/integration/classes/time/Staffing";
/**
 * @namespace com.melodylib.core.classes.User
 */
export default class User extends UI5Object {
	constructor(data) {
		super();
		this.dateService = DateService.getInstance();
		this.setVariants();
		this.setData(data);
	}

	setData(data) {
		if(data) {
			this.oreData = data;
		}
		this.id = data?.UserId || "";
		this.name = data?.UserName || "";
		this.email = data?.UserEmail || "";
		this.firstName = data?.NameFirst || "";
		this.lastName = data?.NameLast || "";
		this.costCenter = data?.CostCenter || "";
		this.personalNumber = data?.PersonalNumber || "";
		this.muName = data?.MuName || "";
		this.requestorManagerId = data?.RequestorManagerId || "";
		this.requestorManagerName = data?.RequestorManagerName || "";
		this.oreFlag = data?.OreFlag || "";
		this.activityRecording = data?.ActivityRecording === "1" ? true : false;
		this.updateIOArtes = data?.UpdateIOArte || "";
		this.updateIoArtesValue = data?.UpdateIoArtesValu || "";
		this.companyCode = data?.CompanyCode || "";
		this.belongEss = data?.BelongEss || "";
		this.regionId = data?.RegionId || "";
		this.authFlg = data?.AuthFlg === "X" ? true : false;
		this.editAuth = data?.EditAuth === "X" ? true : false;
		this.projectType = data?.ProjectType || "";
		this.isISPUser = false;

		// this.essInMu = true;
		this.time = {
			guid:"",
			registered: false,
			holidays: [],
			vacations: [],
			startDayOfWeek: 1,
			stdWorkDuration: 8,
			essInMu: (this.belongEss === "1") ? false : true,
			unit: "H",
			status: "",
			restrictPriorYear: "",
			cutOffDate: "",
			graceDate: "",
			profileId: "1"
		}
		
		/* this.targetHours = [];
		this.holidays = [];
		this.vacations = [];
		this.staffing = [];
		this.EssInMu = true;
		this.IsFirstTimeUser = true;
		this.isOREDataCaptured = false;
		this.IsISPDown = false;
		this.RouteName = "";
		this.PilotFlag = "";
		this.appId = "";
		if (data) {
			this.setTimeSettings(data);
		} */
	}

	setTimeConfig(config) {
		this.time.guid = config.guid || "";
		this.time.status = config.status || "";
		this.time.opportunityURL = config.opportunityURL || "";
		this.time.isUnitEdit = config.isUnitEdit || "";
		this.time.restrictPriorYear = config.restrictPriorYear || "";
		this.time.cutOffDate = config.cutOffDate || "";
		this.time.graceDate = config.graceDate || "";
		this.time.profileId = config.profileId || "1";
		this.time.unit = config.unit || "H";
		this.time.OreTimeData = config.OreTimeData;
	}

	setTimeConfigByGuid(data) {
		this.time.isArchive = data.isArchive ? true : false;
		this.time.essInMu = data.essInMu ? true : false;
		this.time.timesheet = (data.timesheet && !Device.system.desktop) ? data.timesheet.toString() : "1";
		this.time.custId = data.custId || "";
		this.time.createdOn =data.createdOn || "";
		this.time.createdTime = data.createdTime || "";
		this.time.updatedOn = data.updatedOn || "";
		this.time.updatedTime = data.updatedTime || "";
		this.time.registered = data.registered;
		this.time.dateFormat = data.dateFormat;
		this.time.prdProfMapId = data.prdProfMapId || "";
		this.time.MatrixViewAccess = data.MatrixViewAccess;
	}

	setVariants(variants, variant) {
		this.variants = variants ?? [];
		this.variant = variant ?? {
			busy: true,
			defaultKey: "",
			selectedKey: "",
		};
	}

	setNonOreUserData(data) {
		this.authFlg = data.AuthFlg === "X" ? true : false;
		this.editAuth = data.EditAuth === "X" ? true : false;
		this.projectType = data.ProjectType ? data.ProjectType : "";
	}

	setISPUserData(data) {
		if (data) {
			if (data.Kostl && data.Kostl !== "") {
				// overrites ORE Costcenter with ISP Cost Center
				this.costCenter = data.Kostl;
			}
			this.costCenterName = data.costCenterName ? data.costCenterName : "";
			this.objnr = data.objnr ? data.objnr : "";
			this.isISPUser = true;
		} else {
			this.isISPUser = false;
		}
	}

	setTeam(data = []) {
		this.team = data;
	}

	/* setTimeSettings(data) {
		this.startDayWeek = data?.StartDayWeek ? data.StartDayWeek : "";
		this.setTimeMatrics(data?.TimeMatrics);
		this.opportunities = data?.Opportunities ? data.Opportunities : [];
		this.tempOpportunities = data?.TempOpportunities
			? data?.TempOpportunities
			: [];
		this.lSOpportunities = data?.LSOpportunities ? data.LSOpportunities : "";
		this.availableManualIOs = data?.AvailableManualIOs
			? data?.AvailableManualIOs
			: [];
		this.isFirstTimeUser = data?.IsFirstTimeUse ? data?.IsFirstTimeUser : "";
		this.essInMu = data?.EssInMu ? data?.EssInMu : "";
		this.isOREDataCaptured = data?.isOREDataCaptured
			? data?.isOREDataCaptured
			: "";
		this.userGuid = data?.UserGuid
			? data?.UserGuid
			: "005056A230B01EDA81C01FF9CA28810D";
		this.orgFlag = data?.OrgFlag ? data?.OrgFlag : "";
		this.oRERole = data?.ORERole ? data?.ORERole : "";
		this.headcount = data?.Headcount ? data?.Headcount : "";
		this.headcountId = data?.HeadcountId ? data?.HeadcountId : "";
		this.muId = data?.MuId ? data?.MuId : "";
		this.specialization = data?.Specialization ? data?.Specialization : "";
		this.updatedTime = data?.UpdatedTime ? data?.UpdatedTime : "";
		this.isArchive = data?.IsArchive ? data?.IsArchive : "";
		this.partnerId = data?.PartnerId ? data?.PartnerId : "";
		this.dateFormat = data?.DateFormat ? data?.DateFormat : "";
		if (!Device.system.desktop) {
			this.timesheet = "1";
		} else {
			this.timesheet = data?.Timesheet ? data?.Timesheet : "";
		}
		this.custId = data?.CustId ? data?.CustId : "";
		this.createdOn = data?.CreatedOn ? data?.CreatedOn : "";
		this.createdTime = data?.CreatedTime ? data?.CreatedTime : "";
		this.updatedOn = data?.UpdatedOn ? data?.UpdatedOn : "";
		this.to_MANUAL = this.setManualIOs(data.to_MANUAL);
		this.to_ACCOUNT = this.setAccounts(data.to_ACCOUNT);
		this.loading = true;
		this.sizeLimit = 500;
		// ISP Data
		this.weekStartDay = 1;
		this.firstWeekendDay = 6;
		this.secondWeekendDay = 0;
		// LS Data
		this.application = "MTR";
		let profileId = "1"; // by default Profile ID is 1
        if (data.ProfileId && data.ProfileId !== "") {
            profileId = data.ProfileId;
        }
        this.profileId = profileId;
        this.dateFormats =[];
		this.displayDateFormat = this.displayDateFormat
			? this.displayDateFormat
			: "";
		this.setFirstTimeUserSettings(false);
	}
	setTimeMatrics(sValue) {
		this.timeMatrics = sValue;
		if (sValue === "H") {
			const oTargetHour = this.targetHours.find(function (item) {
				return item.Datetype === "WORK";
			});
			if (oTargetHour) {
				this.StdWorkDuration = oTargetHour.Targethours.toString();
			} else {
				this.StdWorkDuration = "8";
			}
		} else {
			this.StdWorkDuration = "1";
		}
	}

	setManualIOs(data, sDataFrom) {
		var manualIOs = [];
		if (data) {
			for (var i = 0; i < data.length; i++) {
				var io = new ManualIO(data[i]);
				io.DataFrom = io.DataFrom ? io.DataFrom : sDataFrom;
				manualIOs.unshift(io);
			}
			return manualIOs;
		} else return [];
	}

	setAccounts(data, sDataFrom) {
		var accounts = [];
		if (data) {
			for (var i = 0; i < data.length; i++) {
				var account = new Account(data[i]);
				account.DataFrom = account.DataFrom ? account.DataFrom : sDataFrom;
				accounts.push(account);
			}
			return accounts;
		} else return [];
	}

	setFirstTimeUserSettings(value) {
		this.firstTimeUser = value;
		if (this.belongEss === "1") {
			this.essInMu = false;
		} else {
			this.essInMu = true;
		}
	}

	setTimeLookups(timesheetModes, dateFormats) {
		this.timesheetModes = timesheetModes ? timesheetModes : [];
		this.dateFormats = dateFormats ? dateFormats : [];
	}

	setMtrSettings(data) {
		this.userGuid = data?.UserGuid
			? data?.UserGuid
			: "005056A230B01EDA81C01FF9CA28810D";
		this.status = data?.Status ? data?.Status : "";
		this.OpportunityURL = data?.OpportunityURL ? data?.OpportunityURL : "";
		this.isUnitEdit = data?.IsUnitEdit ? data?.IsUnitEdit : "";
		this.RestrictPriorYear = data?.RestrictPriorYear
			? data?.RestrictPriorYear
			: "";
		this.CutOffDate = data?.CutOffDate ? data?.CutOffDate : "";
		this.GraceDate = data?.GraceDate ? data?.GraceDate : "";

		let profileId = "1"; // by default Profile ID is 1
		if (data?.ProfileId && data?.ProfileId !== "") {
			profileId = data?.ProfileId;
		}
		this.profileId = profileId;
		let timeMatrics = "H"; // by default TimeMatrics is H(Hours)
		if (data?.TimeSheetUnit && data?.TimeSheetUnit !== "") {
			timeMatrics = data?.TimeSheetUnit;
		}
		this.setTimeMatrics(timeMatrics);
	} */

	getLSRequest() {
		return {
			PrdProfMapId: this.profileId.toString(),
			UserGuid: this.userGuid,
			PartnerId: this.partnerId,
			DateFormat: this.dateFormat,
			EssInMu: this.essInMu ? "X" : "",
			TimeSheetUnit: this.timeMatrics,
			TimeSheet: this.timesheet.toString(),
			CustId: this.custId,
			N_UserSettingToManualIO: this.getManualIOLSRequest(),
			N_UserSettingToAccount: this.getAccountLSRequest(),
			N_UserSettingToOpportunityIO: this.getOpportunityLSRequest(),
		};
	}

	getManualIOLSRequest() {
		var manualIos = [];
		for (var i = 0; i < this.to_MANUAL.length; i++) {
			if (this.to_MANUAL[i].Indicator !== "") {
				manualIos.unshift(
					this.to_MANUAL[i].getLSRequest({
						UserGuid: this.UserGuid,
						PrdProfMapId: this.ProfileId.toString(),
					})
				);
			}
		}
		return manualIos;
	}

	getAccountLSRequest() {
		var accounts = [];
		for (var i = 0; i < this.to_ACCOUNT.length; i++) {
			if (this.to_ACCOUNT[i].Indicator === "O") {
				continue;
			} else if (this.to_ACCOUNT[i].Indicator !== "") {
				accounts.push(
					this.to_ACCOUNT[i].getLSRequest({
						UserGuid: this.UserGuid,
					})
				);
			}
		}
		return accounts;
	}

	getOpportunityLSRequest() {
		var opportunities = [];
		for (var i = 0; i < this.opportunities.length; i++) {
			if (!this.opportunities[i].IsError) {
				opportunities.push(
					this.opportunities[i].getLSRequest({
						UserGuid: this.UserGuid,
					})
				);
			}
		}
		return opportunities;
	}
}
