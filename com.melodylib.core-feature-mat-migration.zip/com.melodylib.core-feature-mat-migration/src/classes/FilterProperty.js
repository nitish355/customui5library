import Filter from "sap/ui/model/Filter";
import * as UI5Object from "sap/ui/base/Object";
import FilterOperator from "sap/ui/model/FilterOperator";
import PropertyType from "com/melodylib/core/enum/PropertyType";

export default class FilterProperty extends UI5Object {
	constructor(data) {
		super();
		this.values = data?.values || "";
		this.operator = data?.operator || FilterOperator.EQ;
		this.key = data?.key ?? "";
		this.dataProperty = data?.dataProperty || "";
		this.type = data?.type ?? PropertyType.String;
		this.label = data?.label ?? "";
		this.selected = data?.selected ?? false;
	}

	getFilter() {
		let filter = null;
		switch (this.type) {
			case PropertyType.Array:
				filter = this._getArrayFilter();
				break;
			case PropertyType.DateRange || PropertyType.NumberRange:
				filter = this._getRangeFilter();
				break;
			default:
				filter = this._getFilter();
		}
		return filter;
	}

	_getFilter() {
		if (!this.values) {
			return null;
		}

		const filter = new Filter({
			path: this.dataProperty,
			operator: this.operator,
			value1: this.values,
		});

		return filter;
	}

	_getRangeFilter() {
		if (!this.values || !this.values.value1 || !this.values.value2) {
			return null;
		}

		const filter = new Filter({
			path: this.dataProperty,
			operator: this.operator,
			value1: this.values.value1,
			value2: this.values.value2,
		});

		return filter;
	}

	_getArrayFilter() {
		if (!this.values || !Array.isArray(this.values) || !this.values.length) {
			return null;
		}

		const filters = [];
		for (let i = 0; i < this.values.length; i++) {
			const values = this.values[i];
			if (typeof values === "string" && values) {
				const filter = new Filter({
					path: this.dataProperty,
					operator: this.operator,
					value1: values,
				});
				filters.push(filter);
			} else {
				if ("value1" in values) {
					const filter = new Filter({
						path: this.dataProperty,
						operator: this.operator,
						value1: values.value1,
					});
					filters.push(filter);
				}
			}
		}

		const arrFilter = new Filter({
			filters: filters,
			and: false,
		});
		return arrFilter;
	}
}
