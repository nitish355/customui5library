import CoreService from "com/melodylib/core/service/CoreService";

/**
 * @name com.melodylib.core.service.user.UserService
 */
export default class UserService extends CoreService {
	constructor() {
		// super();
		CoreService.call(this);
	}
	static getInstance() {
		if (!this.instance) {
			this.instance = new UserService();
		}
		return this.instance;
	}

	getUserDetail() {
		return this.odata("/YC_USER_MASTER").get("utility");
	}

	getRoles() {
		return this.odata("/YC_UT_M_ORE_ROLE").get("utility");
	}

	getRegions() {
		return this.odata("/YC_UT_M_ORE_HCREGION").get("utility");
	}

	getMarketUnits() {
		return this.odata("/YC_UT_M_ORE_HCMU").get("utility");
	}

	submitUserOrgChart(data) {
		return this.odata("/YC_USER_MASTER").post("utility", data);
	}

	getExceptionUserIds() {
		return [
			"I827455",
			"I055583",
			"I832848",
			"I822054",
			"I867982",
			"I307839",
			"I327255",
		];
	}

	getAuthCheckForNonOreUser(projectType) {
		return this.odata(
			"/YC_UT_AUTH_CHECK(ProjectType='" + projectType + "')"
		).get("utility");
	}

	getMyTeam() {
		return this.odata("/YC_UT_MGR_TEAM_LIST").get("utility");
	}

	getMyVariants(options) {
		let parameters = {
			filters: options?.filters || [],
			urlParameters: options?.urlParams,
		};
		return this.odata("/YC_MANAGE_VARIANTS").get("activityList", parameters);
	}

	setMyVariants(payload) {
		let url = "/YC_MANAGE_VARIANTS";
		if (payload?.variantid) {
			url = `/YC_MANAGE_VARIANTS('${payload.variantid}')`;
			return this.odata(url).put("activityList", payload);
		}
		return this.odata(url).post("activityList", payload);
	}

	removeMyVariants(variantId) {
		return this.odata(`/YC_MANAGE_VARIANTS('${variantId}')`).delete(
			"activityList"
		);
	}
	getUserRoles(params) {
		const options = this.getUrlParameters(params);
		return this.odata("/YC_ROLE_ACTVT_FRMACSS").get("activity", options);
	}

	getEmployeeInfo(employeeId, params) {
		const options = this.getUrlParameters(params);
		return this.odata("/YC_OR_T_PRSONSPRO(EmpGuid=guid'00505619-15d5-1edc-a5a9-6b75241c2122',Id='" + employeeId + "')").get(
			"roster",
			options
		);
	}
}
