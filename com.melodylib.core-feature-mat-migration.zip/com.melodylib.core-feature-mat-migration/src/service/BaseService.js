import * as UI5Object from "sap/ui/base/Object";
import JSONModel from "sap/ui/model/json/JSONModel";
import CoreLibraryModel from "com/melodylib/core/model/CoreLibraryModel"
import ODataUrl from "com/melodylib/core/enum/ODataUrl";

/**
 * @name com.melodylib.core.service.BaseService
 */
export default class BaseService extends UI5Object {
	constructor() {
		let appId = CoreLibraryModel.getProperty("/ApplicationId") ||
			"com.melody.activity";
			// "com.melodylib.core";
			
		if (!appId) {
			console.log("MODULE ID IS NOT PRESENT");
			return;
		}
		let appPath = appId.replaceAll(".", "/");
		// this.bUseBatch = oCoreLibraryModel.getProperty("/bUseBatch") ?? true;
		this.useBatch = false;
		if (!this.appModulePath) {
			this.appModulePath = jQuery.sap.getModulePath(appPath);
		}
		this.apiRequestCache = {};
		this._setModels();
	}

	_setModels () {
		this.models = [];

		const services = {};

		for (let i = 0; i < ODataUrl.DataSources.length; i++) {
			let model;
			let modelName = ODataUrl.DataSources[i].name;
			let tempModel = sap.ui.getCore().getModel(modelName) || false;
			let tempUrl = `${this.appModulePath}${ODataUrl.DataSources[i].url}`;
			if (!tempModel) {
				model = new sap.ui.model.odata.v2.ODataModel({
					serviceUrl: tempUrl,
					useBatch: this.useBatch ?? true, //Nullish operator
				});
				//set the model for ODataURls
				sap.ui.getCore().setModel(model, modelName);
				this.models[modelName] = model;
			} else {
				this.models[modelName] = tempModel;
			}

			services[
				ODataUrl.DataSources[i].name.toUpperCase() + "_SERVICE_DOWN"
			] = false;
		}

		const serviceModel = new JSONModel(services);
		sap.ui.getCore().setModel(serviceModel, "services");
	}

	odata (url) {
		const me = this;
		const core = {
			ajax: async function (type, url, data, modelName, parameters) {
				let urlKey = url;
				if(parameters) {
					urlKey = `${urlKey}${JSON.stringify(parameters)}`;
				}
				//Check if api ref exists in apicache and return
				if (me.apiRequestCache && Object.keys(me.apiRequestCache).length) {
					/* if (parameters) {
						urlKey = `${urlKey}${JSON.stringify(parameters)}`;
					} */
					if (me.apiRequestCache[urlKey]) {
						return me.apiRequestCache[urlKey];
					}
				}
				const promise = new Promise(function (resolve, reject) {
					const args = [];
					let params = {};
					args.push(url);
					if (data) {
						args.push(data);
					}
					if (parameters) {
						params = parameters;
						// urlKey = `${urlKey}${JSON.stringify(parameters)}`;
					}

					params.success = function (result, response) {
						resolve({
							data: result,
							response: response,
						});
						//Delete the urlKey from apiCache
						if (me.apiRequestCache && me.apiRequestCache[urlKey]) {
							console.log("KEY DELETED :", urlKey);
							delete me.apiRequestCache[urlKey];
						}
					};
					params.error = function (error) {
						reject(error);
					};
					args.push(params);
					me.models[modelName][type].apply(me.models[modelName], args);
				});

				const serviceModel = sap.ui.getCore().getModel("services");
				try {
					await me.models[modelName].metadataLoaded(true);
					serviceModel.getProperty(
						"/" + modelName.toUpperCase() + "_SERVICE_DOWN",
						false
					);
				} catch (e) {
					serviceModel.getProperty(
						"/" + modelName.toUpperCase() + "_SERVICE_DOWN",
						true
					);
					throw new Error(modelName + " - METADATA_NOT_LOADED");
				}
				//TO Store URL Refs in apicache
				me.apiRequestCache[urlKey] = promise;
				return promise;
			}
		};

		return {
			get: function (modelName, params) {
				return core.ajax("read", url, false, modelName, params);
			},
			post: function (modelName, data, params) {
				return core.ajax("create", url, data, modelName, params);
			},
			put: function (modelName, data, params) {
				return core.ajax("update", url, data, modelName, params);
			},
			delete: function (modelName, params) {
				return core.ajax("remove", url, false, modelName, params);
			}
		};
	}
}