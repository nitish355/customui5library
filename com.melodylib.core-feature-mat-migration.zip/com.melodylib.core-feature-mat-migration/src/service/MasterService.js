import CoreService from "com/melodylib/core/service/CoreService";

/**
 * @name com.melodylib.core.service.MasterService
 */
export default class MasterService extends CoreService {
    constructor () {
		super();
	}
    static getInstance() {
        if (!this.instance) {
            this.instance = new MasterService();
        }
        return this.instance;
    }

    getConstants() {
        return this.odata("/Yc_Mac_M_Constants").get("activity");
	}

	getCountries () {
        return this.odata("/YC_UT_M_COUNTRY").get("utility");
    }
}