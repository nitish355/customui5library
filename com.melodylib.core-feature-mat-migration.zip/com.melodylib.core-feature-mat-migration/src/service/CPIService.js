sap.ui.define([
    "sap/ui/model/Filter", "com/melodylib/core/enum/Actions", "sap/ui/model/FilterOperator", "com/melodylib/core/service/CoreService",
], function (Filter, Actions, FilterOperator, CoreService) {
    "use strict";

    var CPIService = CoreService.extend("com.melodylib.core.service.CPIService", {

        getAppValueHelps: function () {
            const aFilters = [
                new Filter("ENTITY_NAME", FilterOperator.EQ, "OPPORTUNITY"),
                new Filter({
                    filters: [
                        new Filter("FIELD_NAME", FilterOperator.EQ, "STATUS"),
                        new Filter("FIELD_NAME", FilterOperator.EQ, "QUARTER_ID"),
                        new Filter("FIELD_NAME", FilterOperator.EQ, "PHASE")
                    ],
                    and: false
                })
            ];
            var mParameters = {};
            mParameters.filters = (aFilters) ? aFilters : "";
            return this.odata("/AppValueHelps").get("cpi", mParameters);
        },

        getOpportunityCount: function (batches) {
            let mParameters = {};
            for (let i = 0; i < batches.length; i++) {
                mParameters.filters = (batches[i].filters) ? batches[i].filters : "";
                const urlParam = JSON.parse(JSON.stringify(batches[i].parameters));
                ["$skip", "$top", "$select"].forEach(param => delete urlParam[param]);
                if (Object.keys(urlParam).length) {
                    mParameters.urlParameters = urlParam;
                }
            }
            return this.odata("/Opportunities/$count").get("cpi", mParameters);
        },

        getOpportunities: function (batches) {
            const aBatches = [];
            for (let i = 0; i < batches.length; i++) {
                const mParameters = {};
                mParameters.filters = (batches[i].filters) ? batches[i].filters : "";
                mParameters.urlParameters = batches[i].parameters;
                aBatches.push({
                    type: "read",
                    url: "/Opportunities",
                    parameters: mParameters
                });
            }
            return this.odata("/Opportunities").batch("cpi", aBatches, "opportunity");
        },

        getNonVATOpportunityList: function (mParameters) {
            let sURL = (mParameters.hasOwnProperty("count")) ? `/Opportunities${mParameters.count}` : '/Opportunities';
            return this.odata(sURL).get("cpi", mParameters);
        },

         getOppTeamWithOREAccess: function(aFilters){
            let mParameters = {};
            mParameters.filters = (aFilters) ? aFilters : "";
            return this.odata("/OpportunityPartners").get("cpi", mParameters);
        }
        
    });
    return new CPIService();
});
