import CoreService from "com/melodylib/core/service/CoreService";

/**
 * @name com.melodylib.core.service.MasterDataService
 */
export default class MasterDataService extends CoreService {
	constructor () {
		super();
	}
    
	static getInstance() {
        if (!this.instance) {
            this.instance = new MasterDataService();
        }
        return this.instance;
    }

	getConstants () {
		return this.odata("/Yc_Mac_M_Constants").get("activity");
	}

	getUserData () {
		return this.odata("/YC_USER_MASTER").get("oreModel");
	}

	getActDetRiskButtons () {
		return this.odata("/Yc_Mac_M_Risk_Asses").get("activityList");
	}

	getActDetAudience () {
		return this.odata("/YC_MAC_M_AUDIENCE").get("activityModel");
	}

	getGTMAreMasterData (oModel) {
		return this.odata("/YC_MAC_M_GTM_AREA").get("activityModel");
	}

	getActivityStatusMasterData (oModel) {
		return this.odata("/YC_MAC_M_ACTVT_STATUS").get("activityModel");
	}
}