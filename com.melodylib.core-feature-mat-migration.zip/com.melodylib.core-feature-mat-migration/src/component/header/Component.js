"use strict";

sap.ui.define(["sap/ui/core/UIComponent"], function (BaseComponent) {
	"use strict";

	/**
	 * @namespace com.melodylib.core
	 */
	const Component = BaseComponent.extend("com.melodylib.core.Component", {
		metadata: {
			manifest: "json",
			rootView: {
				viewName: "com.melodylib.core.component.header.Header",
				type: "XML",
				id: "melodyHeader",
			},
			interfaces: ["sap.ui.core.IAsyncContentCreation"],
		},
	});
	return Component;
});
//# sourceMappingURL=Component-dbg.js.map
