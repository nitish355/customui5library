sap.ui.define(
	[
		"sap/ui/core/Fragment",
		"sap/ui/core/mvc/Controller",
		"sap/ui/model/json/JSONModel",
		"com/melodylib/core/enum/Actions",
		"com/melodylib/core/db/IndexedDB",
		"com/melodylib/core/service/OREService",
		"com/melodylib/core/model/CoreLibraryModel",
		"com/melodylib/core/util/usersettings/Usermaster",
	],
	function (
		Fragment,
		Controller,
		JSONModel,
		Actions,
		oIndexedDB,
		OREService,
		oCoreLibraryModel
	) {
		"use strict";

		return Controller.extend("com.melodylib.core.component.header.Header", {
			onInit: async function () {
				let oHeaderModel = new JSONModel({});
				let oUserData = $.extend(
					true,
					{},
					oCoreLibraryModel.getProperty("/oUserData")
				);
				this.getView().setModel(oHeaderModel);
				this.getView().setModel(oCoreLibraryModel, "corelibModel");
			},

			

			//function to fetch user melody quick nav
			fnGetMelodyQuickLinks: async function () {
				let oThisController = this;

				let aQuickNavData =
					(await oIndexedDB.fnGetAllDatafromDB({
						dbName: "master-data",
						storeName: "master-data-table",
						keyName: "melodyquicknav",
					})) || [];

				if (!aQuickNavData.length) {
					let { data } = await await OREService.fnGetMelodyQuickLinks(
						OREService.models.oreModel
					);
					aQuickNavData = data?.results ?? [];

					oIndexedDB.fnInsertDataToDB({
						dbName: "master-data",
						storeName: "master-data-table",
						keyName: "melodyquicknav",
						aObjectsToInsert: aQuickNavData,
					});
				}

				return aQuickNavData;
			},

			//function to open user popover
			onUserInitialPress: function (oEvent) {
				let oAvatar = oEvent.getSource(),
					oView = this.getView();

				// create popover
				if (!this._pPopover) {
					this._pPopover = Fragment.load({
						id: oView.getId(),
						name: "com.melodylib.core.component.header.fragment.UserPopover",
						controller: this,
					}).then(function (oPopover) {
						oView.addDependent(oPopover);
						return oPopover;
					});
				}

				this._pPopover.then(function (oPopover) {
					oPopover.openBy(oAvatar);
				});
			},
		});
	}
);
