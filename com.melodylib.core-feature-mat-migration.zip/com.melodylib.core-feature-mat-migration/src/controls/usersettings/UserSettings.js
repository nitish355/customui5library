/*!
 * ${copyright}
 */

// Provides control com.melody.lib.
sap.ui.define(
	[
		"jquery.sap.global",
		"sap/ui/core/Control",
		"sap/ui/Device",
		"sap/m/MessageToast",
		"sap/ui/core/Fragment",
		"sap/ui/model/json/JSONModel",
		"sap/ui/model/resource/ResourceModel",
		"com/melodylib/core/service/OREService",
	],
	function (
		jQuery,
		Control,
		Device,
		MessageToast,
		Fragment,
		JSONModel,
		ResourceModel,
		OREService
	) {
		"use strict";

		/**
		 * Constructor for a new UserSettings Control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends  Control
		 *
		 * @author SAP SE
		 * @version ${version}
		 *
		 * @constructor
		 * @public
		 * @alias com.melody.lib.controls.UserSettings
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */
		var oDialogController = {
			//Function to get loggedIn User's notification list
			fnGetUserNotificationList: function () {
				let that = this;
				OREService.fnGetUserNotificationList(this.OreModel).then(
					(response) => {
						let data = response.data.results;
						that.oUserSettingsModel.setProperty("/UpdatedNotifList", []);
						that.oUserSettingsModel.setProperty("/NotificationList", data);
						that.oUserSettingsModel.setProperty("/isSettingBtnBusy", false);
					},
					(error) => {
						that.oUserSettingsModel.setProperty("/UpdatedNotifList", []);
						that.oUserSettingsModel.setProperty("/NotificationList", []);
						that.oUserSettingsModel.setProperty("/isSettingBtnBusy", false);
					}
				);
			},

			//Function to toggle SideNavigation
			onCollapseExpandPress: function () {
				let oSideNavigation =
					this._fnGetDialogContentById(
						"SETTINGS_SIDE_NAV"
					); /* @type sap.tnt.SideNavigation */
				let bExpanded = oSideNavigation.getExpanded(); /* @type bool */
				oSideNavigation.setExpanded(!bExpanded); // toggle expanded property of sideNavigation
				if (!bExpanded) {
					this._fnGetDialogContentById("SETTINGS_REG_NOTE").addStyleClass(
						"sapUiLargeMarginBegin"
					);
					this._fnGetDialogContentById("SETTINGS_REG_NOTE").removeStyleClass(
						"sapMActRegNoteDescMargin"
					);
				} else {
					this._fnGetDialogContentById("SETTINGS_REG_NOTE").addStyleClass(
						"sapMActRegNoteDescMargin"
					);
					this._fnGetDialogContentById("SETTINGS_REG_NOTE").removeStyleClass(
						"sapUiLargeMarginBegin"
					);
				}
			},

			//Function to navigate between detail pages
			handleNav: function (oEvent, target) {
				this.fnSetSideNavConfigs();
				let navCon = this._fnGetDialogContentById("SETTINGS_NAV_CON");
				if (oEvent) {
					target = oEvent.getSource().getCustomData()[0].getValue();
				}
				if (target) {
					// handle navigation in the settings dialog box with fade animation
					navCon.to(this._fnGetDialogContentById(target), "fade");
					this.oUserSettingsModel.setProperty("/SelectedSideNav", target);
				} else {
					// stays on same page within navContainer
					navCon.back();
				}
			},

			fnSetSideNavConfigs: function () {
				if (sap.ui.Device.system.desktop) {
					this.UserSettingsDialog.addStyleClass("sapUiSizeCompact");
				} else if (Device.system.tablet) {
					this.UserSettingsDialog.addStyleClass("sapUiSizeCompact");
				} else {
					this._fnGetDialogContentById("SETTINGS_SIDE_NAV").setExpanded(false);
				}
			},

			//Function to update the switch state change
			fnUpdateSwitchState: function (oEvent) {
				let oUserSettingsModel = this.oUserSettingsModel;
				let switchState = oEvent.getSource().getState();
				let oPath = oEvent
					.getSource()
					.getBindingContext("oUserSettingsModel")
					.getPath();
				let selectedObj = oUserSettingsModel.getProperty(oPath);
				if (switchState) {
					selectedObj.OperationStatus = "X";
				} else {
					selectedObj.OperationStatus = "";
				}
				let index;
				let updatedNotifList =
					oUserSettingsModel.getProperty("/UpdatedNotifList");
				updatedNotifList.filter(function (object, i) {
					if (object.NotifID === selectedObj.NotifID) {
						index = i;
					}
				});
				if (index || index === 0) {
					updatedNotifList[index] = selectedObj;
				} else {
					updatedNotifList.push(selectedObj);
				}
				oUserSettingsModel.setProperty("/UpdatedNotifList", updatedNotifList);
			},

			//Function to save user settings
			onSaveUserSettings: function () {
				let oCurrentPageId = this._fnGetDialogContentById("SETTINGS_NAV_CON")
					.getCurrentPage()
					.getId();
				if (
					oCurrentPageId.includes("APP_NOTIF_CONFIG") ||
					oCurrentPageId.includes("APP_REGISTRATION")
				) {
					this.fnSaveNotificationSettings();
				}
			},

			//Function to save user's notification settings
			fnSaveNotificationSettings: function () {
				let that = this;
				let updatedNotifList =
					this.oUserSettingsModel.getProperty("/UpdatedNotifList");
				if (updatedNotifList.length) {
					this._fnGetDialogContentById("APP_NOTIF_CONFIG").setBusy(true);
					OREService.fnSaveNotificationSettings(
						this.OreModel,
						updatedNotifList,
						jQuery.sap.uid()
					).then(
						(response) => {
							let responseData =
								response.data.__batchResponses[0].__changeResponses;
							for (let i = 0; i < responseData.length; i++) {
								let statusCode = responseData[i].statusCode;
								let oUserSettingsModel = this.oUserSettingsModel;
								if (statusCode === "201") {
									let notifId = responseData[i].data.NotifID;
									let notificationList =
										oUserSettingsModel.getProperty("/NotificationList");
									notificationList.find((object, index) => {
										if (object.NotifID === notifId) {
											oUserSettingsModel.setProperty(
												"/NotificationList/" + index,
												responseData[i].data
											);
										}
									});
								}
								oUserSettingsModel.refresh(true);
							}
							that._fnGetDialogContentById("APP_NOTIF_CONFIG").setBusy(false);
							that.fnCloseUserSettingsDialog();
						},
						(error) => {
							MessageToast.show(that.i18nModel.getText("NOTIF_SAVE_ERROR"));
							that._fnGetDialogContentById("APP_NOTIF_CONFIG").setBusy(false);
						}
					);
				} else {
					MessageToast.show(that.i18nModel.getText("NOTIF_NO_CHANGES"));
				}
			},

			fnCloseUserSettingsDialog: function (oEvent) {
				let updatedNotifList =
					this.oUserSettingsModel.getProperty("/UpdatedNotifList");
				if (updatedNotifList.length) {
					this.fnGetUserNotificationList();
				}
				this.UserSettingsDialog.close();
			},

			_fnGetDialogContentById: function (contentId) {
				debugger;
				return sap.ui.core.Fragment.byId(
					this.UserSettingControl.getId() + "_UserSettingsDialog",
					contentId
				);
			},

			fnLoadResourceBundle: function () {
				let i18nModel = new ResourceModel({
					bundleName: "com.melodylib.core.messagebundle",
				});
				this.UserSettingsDialog.setModel(i18nModel, "i18n");
				this.i18nModel = i18nModel.getResourceBundle();
			},
		};

		var oUserSettings = Control.extend(
			"com.melodylib.core.controls.usersettings.UserSettings",
			{
				metadata: {
					properties: {
						text: {
							type: "string",
							defaultValue: "",
						},
						icon: {
							type: "sap.ui.core.URI",
							group: "Appearance",
							defaultValue: "",
						},
					},
					aggregations: {
						_button: {
							type: "sap.m.Button",
							multiple: false,
							visibility: "hidden",
						},
					},
				},

				setText: function (text) {
					var sText = text ? text : "";
					this.setProperty("text", sText);
					this.getAggregation("_button").setText(sText);
				},

				setIcon: function (icon) {
					var sIcon = icon ? icon : "";
					this.setProperty("icon", sIcon);
					this.getAggregation("_button").setIcon(sIcon);
				},

				init: function () {
					const that = this;

					//INIT CSS FILE
					//initialisation code, in this case, ensure css is imported
					var libraryPath = jQuery.sap.getModulePath("com.melodylib.core");
					jQuery.sap.includeStyleSheet(libraryPath + "/css/UserSettings.css");

					const oModel = new JSONModel();
					this.setModel(oModel, "oUserSettingsModel");
					oDialogController.oUserSettingsModel = oModel;
					oModel.setProperty("/isSettingBtnBusy", true);
					this.setAggregation(
						"_button",
						new sap.m.Button(this.getId() + "-button", {
							text: that.getText(),
							type: "Transparent",
							press: that.fnOpenUserSettingsDialog,
							// Commented below code : QA Busy Indicator issue
							// busy: "{oUserSettingsModel>/isSettingBtnBusy}"
						})
					);
					this.addStyleClass("userSettingsBtn");
					this.fnLoadUserProfileOptions();
					this.fnGetLoggedInUserMasterList();
					this.fnLoadUserSettingsDialog(that);
					oDialogController.fnGetUserNotificationList();
				},

				openUserSettingsFromMail: function () {
					const that = this;
					const sHash = window.location.hash;
					if (sHash.includes("IsChangeUserSettings")) {
						that.fnOpenUserSettingsDialog();
					}
				},

				fnLoadUserSettingsDialog: function (that) {
					if (!that.UserSettingsDialog) {
						Fragment.load({
							id: that.getId() + "_UserSettingsDialog",
							name: "com.melodylib.core.fragments.usersettings.Settings",
							controller: oDialogController,
						}).then(
							function (oDialog) {
								oDialog.setModel(
									that.getModel("oUserSettingsModel"),
									"oUserSettingsModel"
								);
								that.addDependent(oDialog);
								that.UserSettingsDialog = oDialog;
								oDialogController.UserSettingControl = that;
								oDialogController.UserSettingsDialog = oDialog;
								oDialogController.fnLoadResourceBundle();
								that.openUserSettingsFromMail();
								return oDialog;
							}.bind(that)
						);
					}
				},

				fnLoadUserProfileOptions: function () {
					let oData = [
						{
							key: "SETTINGS",
							text: "Settings",
							icon: "sap-icon://settings",
						},
					];
					this.getModel("oUserSettingsModel").setProperty(
						"/UserProfileItems",
						oData
					);
				},

				fnGetLoggedInUserMasterList: function () {
					let oMasterList = [
						{
							key: "01",
							text: "User Settings",
							icon: "sap-icon://user-settings",
							subList: [
								{
									key: "APP_NOTIF_CONFIG",
									text: "Notifications",
								},
								{
									key: "APP_REGISTRATION",
									text: "Activity Registration",
								},
							],
						},
					];
					this.getModel("oUserSettingsModel").setProperty(
						"/MasterList",
						oMasterList
					);
					this.getModel("oUserSettingsModel").setProperty(
						"/UpdatedNotifList",
						[]
					);
				},

				fnOpenUserSettingsDialog: function (oEvent) {
					oDialogController.UserSettingsDialog.open();
				},
			}
		);

		return oUserSettings;
	},
	/* bExport= */ true
);
