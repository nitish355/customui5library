/*!
 * ${copyright}
 */
import Lib from "sap/ui/core/Lib";
/**
 * StatusBoxControl renderer.
 * @namespace
 */
export default {
	apiVersion: 2, // usage of DOM Patcher

	/**
	 * Renders the HTML for the given control, using the provided {@link RenderManager}.
	 *
	 * @param rm The reference to the <code>sap.ui.core.RenderManager</code>
	 * @param control The control instance to be rendered
	 */
	render: function (rm, control) {
		var i18n = Lib.getResourceBundleFor("com.melodylib.core");

		rm.openStart("div", control);
		rm.class("statusBox");
		rm.openEnd();
			rm.openStart("div", control);
			rm.class("statusBoxHeader");
			rm.openEnd();
				rm.text(i18n.getText("STATUS_BOX_HEADER", ["No"]));
				rm.openStart("div", control);
				rm.class("statusBoxHeaderActions");
				rm.openEnd();
					rm.renderControl(control.getAggregation("_collapseButton"));
					rm.renderControl(control.getAggregation("_closeButton"));
				rm.close("div");	
			rm.close("div");
			
			rm.openStart("ul", control);
			rm.class("statusBoxContent");
			rm.openEnd();
			rm.close("ul");
		rm.close("div");
	}
};