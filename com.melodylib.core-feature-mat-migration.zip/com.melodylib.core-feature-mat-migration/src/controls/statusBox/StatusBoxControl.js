/*!
 * ${copyright}
 */
import Control from "sap/ui/core/Control";
import StatusBoxControlRenderer from "./StatusBoxControlRenderer";

/**
 * Constructor for a new <code>com.melodylib.core.controls.statusBox.StatusBoxControl</code> control.
 *
 * Some class description goes here.
 * @extends Control
 *
 * @author Balwant Singh
 * @version ${version}
 *
 * @constructor
 * @public
 * @name com.melodylib.core.controls.statusBox.StatusBoxControl
 */
export default class StatusBoxControl extends Control {
	static metadata = {
		library: "com.melodylib.core",

		properties: {
			collapse: {
				type: "boolean",
				group: "Data",
				defaultValue: false
			}
		},
		events: {},
		aggregations: {
			_collapseButton: {
				type: "sap.ui.core.Icon",
				multiple: false,
				visibility: "hidden"
			},
			_closeButton: {
				type: "sap.ui.core.Icon",
				multiple: false,
				visibility: "hidden"
			},
		}
	};

	static renderer = StatusBoxControlRenderer;


	
	init() {
		this.processes = [];
		//initialisation code, in this case, ensure css is imported
		var libraryPath = jQuery.sap.getModulePath("com.melodylib.core"); //get the server location of the ui library
		jQuery.sap.includeStyleSheet(libraryPath + "/controls/statusBox/statusBox.css"); //specify the css path relative from the ui folder

		this.setAggregation("_collapseButton", new sap.ui.core.Icon({
			src: "sap-icon://navigation-down-arrow",
			press: (function (event) {
				this.setCollapse(!this.getCollapse());
			}).bind(this)
		}).addStyleClass("statusBoxCollapseButton"));

		this.setAggregation("_closeButton", new sap.ui.core.Icon({
			src: "sap-icon://decline",
			press: (function (event) {
				this.setOpen(false);
			}).bind(this)
		}).addStyleClass("statusBoxCloseButton sapUiTinyMarginBegin"));
	}

	setOpen(value) {
		const isOpen = (value ? true : false);
		if(this._parent) {
			if(!isOpen) {
				this._parent.close(0);
			}
		}
	}

	open() {
		if(this._parent) {
			this._parent.open(0, sap.ui.core.Popup.Dock.RightBottom, sap.ui.core.Popup.Dock.RightBottom);
			this.updateProcesses();
		}
	}

	close() {
		if(this._parent) {
			this._parent.close(0);
		}
	}

	setCollapse() {
		const element = jQuery("#" + this.getId());
		const isCollapse = (element.hasClass("collapse") ? true : false);
		element.toggleClass("collapse");
		const src = isCollapse ? "sap-icon://navigation-down-arrow" : "sap-icon://navigation-up-arrow";
		this.getAggregation("_collapseButton").setSrc(src);
	}

	addProcess(value) {
		let isExist = true;
		const hexaString  = Date.now().toString(16);
		
		let process = this.processes.find(p => p.id === hexaString);
		if(!process) {
			isExist = false;
			process = {
				id: hexaString,
				description: value.description,
				status: "IN_PROCESS"
			};

			this.processes.push(process);
		}
		
		this._addProcess(process);

		return (!isExist) ? process : null;
	}

	_addProcess(process) {
		if(!jQuery("#" + this.getId()).find("#" + process.id).length) {
			const html = '<li style="opacity:0;" id="' + process.id + '"><span>' + process.description + '</span><div class="statusContainer"></div></li>';
		
			jQuery("#" + this.getId()).find("ul.statusBoxContent").append(html);
			
			setTimeout((function() {
				jQuery("#" + this.getId()).find("ul.statusBoxContent #" + process.id).css("opacity", 1);
				this.setStatus(process.id, "IN_PROCESS");
			}).bind(this), 100);
		}
	}

	updateProcesses() {
		for(let i = 0; i < this.processes.length; i++) {
			this._addProcess(this.processes[i]);
		}
	}

	getRunningProcesses() {
		return this.processes;
	}

	setStatus(id, status) {
		if(!id) {
			return;
		}
		const index = this.processes.findIndex(p => p.id === id);
		if(index !== -1) {
			this.processes[index].status = status ? status : "INVALID";
		}
		const li = jQuery("#" + this.getId()).find("ul.statusBoxContent #" + id);
		const element = li.children(".statusContainer");
		switch (status) {
			case "SUCCESS":
				element.html(this._getSuccessHtml());
				this.processes.splice(index, 1);
				setTimeout((function() {
					li.remove();
				}).bind(this), 2000);
				break;
			case "ERROR":
				element.html(this._getErrorHtml());
				this.processes.splice(index, 1);
				setTimeout((function() {
					li.remove();
				}).bind(this), 300);
				break;
			case "IN_PROCESS":
				element.html('<span class="loader"></span>');
				break;
			default:
				break;
		}
	}

	_getSuccessHtml() {
		let html = '<span class="status"><i class="icon success"></i></span>';
		return html;
	}

	_getErrorHtml() {
		let html = '<span class="status"><i class="icon error"></i></span>';
		return html;
	}

	setPopup(parent) {
		this._parent = parent;
	}
}