/*!
 * ${copyright}
 */

// Provides control com.melody.libcore
sap.ui.define(
	[
		"sap/ui/core/Control",
		"sap/ui/model/json/JSONModel",
		"com/melodylib/core/enum/Actions",
		"com/melodylib/core/db/IndexedDB",
		"com/melodylib/core/service/OREService",
	],
	function (Control, JSONModel, Actions, oIndexedDB, OREService) {
		"use strict";

		/**
		 * Constructor for a new QuickNavMenu Control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends  Control
		 *
		 * @author SAP SE
		 * @version ${version}
		 *
		 * @constructor
		 * @public
		 * @alias com.melody.lib.controls.quickNav.QuickNavMenu
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */
		var oController = {
			fnQuickLinkNavigation: function (oEvent) {
				let oSource = oEvent.getSource();
				var oParamObj = {};
				var oSelectedObj = oEvent.getSource().getBindingContext().getObject();
				var externalURL = oSelectedObj.url;
				var semanticObj = oSelectedObj.semantic_obj;
				var sSemanticName = semanticObj.split("-")[0];
				var sSemanticAction = semanticObj.split(/-(.+)/)[1];
				var aParamObj = oSelectedObj.to_params.results;
				$.each(aParamObj, function (index, param) {
					oParamObj[param.description] = param.value;
				});
				if (sSemanticName) {
					var oCrossAppNavigator = sap.ushell.Container.getService(
						"CrossApplicationNavigation"
					);
					var hash =
						(oCrossAppNavigator &&
							oCrossAppNavigator.hrefForExternal({
								target: {
									semanticObject: sSemanticName,
									action: sSemanticAction,
								},
								params: oParamObj,
							})) ||
						"";
					oCrossAppNavigator.toExternal({
						target: {
							shellHash: hash,
						},
					});
				} else if (externalURL) {
					window.open(externalURL, "_blank");
				}
			},
		};

		var oQuickNavMenu = Control.extend(
			"com.melodylib.core.controls.quicknav.QuickNavMenu",
			{
				metadata: {
					properties: {
						text: {
							type: "string",
							defaultValue: "",
						},
					},
					aggregations: {
						_menuButton: {
							type: "sap.m.MenuButton",
							multiple: false,
							visibility: "hidden",
						},
					},
				},

				setText: function (text) {
					const sText = text ? text : "";
					this.setProperty("text", sText);
					if (this.getAggregation("_menuButton")) {
						this.getAggregation("_menuButton").setText(sText);
					}
				},

				init: function () {
					//INIT CSS FILE
					//initialisation code, in this case, ensure css is imported
					var libraryPath = jQuery.sap.getModulePath("com.melodylib.core");
					jQuery.sap.includeStyleSheet(libraryPath + "/css/QuickNav.css");

					const that = this;
					const oModel = new JSONModel({
						QuickLinksNav: [],
					});
					this.setModel(oModel);
					that.fnSetControlAggregation();
				},

				fnGetMelodyQuickLinks: async function () {
					let that = this;

					let aQuickNavData =
						(await oIndexedDB.fnGetAllDatafromDB({
							dbName: "master-data",
							storeName: "master-data-table",
							keyName: "melodyquicknav",
						})) || [];

					if (!aQuickNavData.length) {
						let { data } = await await OREService.fnGetMelodyQuickLinks(
							OREService.models.oreModel
						);
						aQuickNavData = data?.results ?? [];

						oIndexedDB.fnInsertDataToDB({
							dbName: "master-data",
							storeName: "master-data-table",
							keyName: "melodyquicknav",
							aObjectsToInsert: aQuickNavData,
						});
					}

					return aQuickNavData;
				},

				fnSetControlAggregation: async function () {
					var that = this;
					sap.ui.core.Fragment.load({
						id: that.getId() + "_menu",
						name: "com.melodylib.core.fragments.quicknav.QuickNavMenuItems",
						controller: oController,
					}).then(
						async function (oMenu) {
							that.setAggregation(
								"_menuButton",
								new sap.m.MenuButton(this.getId() + "-menuButton", {
									text: that.getText(),
									menu: oMenu,
								})
							);
							let aMenuData =
								that.getModel().getProperty("/QuickLinksNav") || [];
							//Get the Menu options from the service and load the Add Menu Items
							if (!aMenuData.length) {
								let aResponse = await that.fnGetMelodyQuickLinks();
								that.getModel().setProperty("/QuickLinksNav", aResponse);
							}
							that.getModel().refresh(true);
							that.fnMenuBusyIndicator(false);
							this.setText(that.getText());
							// setTimeout(() => {
							// 	that.fnAddMenuItemToQuickNav(oMenu);
							// }, 1200);
						}.bind(that)
					);
				},

				//function to handle busy indicator
				fnMenuBusyIndicator: function (bBusy) {
					if (this.getAggregation("_menuButton")) {
						this.getAggregation("_menuButton").setBusyIndicatorDelay(0);
						this.getAggregation("_menuButton").setBusy(bBusy);
					}
				},

				onAfterRendering: function (oEvent) {},

				//function to add create entry menu item to Quick Nav Options
				fnAddMenuItemToQuickNav: async function (oMenuControl) {
					oMenuControl.setBusy(true);
					let aQuickLinksNav = $.extend(
						true,
						[],
						this.getModel().getProperty("/QuickLinksNav")
					);
					await new Promise((resolve) => setTimeout(resolve, 1000));
					let aListItems = oMenuControl ? oMenuControl.getItems() : [];
					if (aListItems.length) {
						let oTimeEnterMenuItem = new TimeEntryMenuItem({
							text: "Melody Time",
							press: [oController.fnQuickLinkNavigation, this],
						});
						let oMTRModel = sap.ui.getCore().getModel("oMTRModel");
						oTimeEnterMenuItem.setSelectedActivity();
						oTimeEnterMenuItem.setEntries();
						this.fnInsertCstControl(aListItems, oTimeEnterMenuItem);
						if (this.getAggregation("_menuButton")) {
							this.getAggregation("_menuButton").setBusy(false);
						}
						oMenuControl.setBusy(false);
					} else {
						await new Promise((resolve) => setTimeout(resolve, 700));
						console.error("MENU_ITEMS_NOT_LOADED :", aQuickLinksNav);
						this.fnAddMenuItemToQuickNav(oMenuControl);
					}
				},

				//function to search in quicknav data
				fnSearchInQuickNavDataForMelodyTime: function (aResponse) {
					let iIndex = aResponse.findIndex((oRow) => {
						if (
							oRow.hasOwnProperty("IsPopUp") &&
							oRow.hasOwnProperty("semantic_obj")
						) {
							if (
								(oRow.IsPopUp === "X" || oRow.IsPopUp) &&
								oRow.semantic_obj === "melody-time"
							) {
								return true;
							}
						}
					});
					return iIndex;
				},

				//function to insert custom control at a given index and remove the item based on data(Melody-Time) entry
				fnInsertCstControl: function (aListItems, oTimeEnterMenuItem) {
					let oThisController = this;
					for (let i = 0; i < aListItems.length; i++) {
						let oList = aListItems[i];
						let oListData = oList.getBindingContext().getObject() || {};
						let isPopValue = oListData.hasOwnProperty("IsPopUp")
							? oListData.IsPopUp
							: "";
						if (isPopValue || isPopValue === "X") {
							isPopValue = true;
						} else {
							isPopValue = false;
						}
						let sSemanticObj = oListData.hasOwnProperty("semantic_obj")
							? oListData.semantic_obj
							: "";
						let aChildItems = aListItems[i].getItems() || [];
						if (aChildItems.length && Array.isArray(aChildItems)) {
							oThisController.fnInsertCstControl(
								aChildItems,
								oTimeEnterMenuItem
							);
						} else {
							if (isPopValue && sSemanticObj === "melody-time") {
								oTimeEnterMenuItem.setText(oListData.item_name);
								let oParentList = oList.getParent();
								if (oParentList) {
									oParentList.removeItem(oList);
									oParentList.insertItem(oTimeEnterMenuItem, i);
								}
							}
						}
					}
				},
			}
		);

		return oQuickNavMenu;
	},
	/* bExport= */ true
);
