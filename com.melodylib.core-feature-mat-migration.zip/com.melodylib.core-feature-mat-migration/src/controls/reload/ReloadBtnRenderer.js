/*!
 * ${copyright}
 */

sap.ui.define(
	["jquery.sap.global"],

	function (/*jQuery*/) {
		"use strict";

		/**
		 * ReloadBtn renderer.
		 * @namespace
		 */
		var ReloadBtnRenderer = {};

		/**
		 * Renders the HTML for the given control, using the provided
		 * {@link sap.ui.core.RenderManager}.
		 *
		 * @param {sap.ui.core.RenderManager} oRm
		 *            the RenderManager that can be used for writing to
		 *            the Render-Output-Buffer
		 * @param {sap.ui.core.Control} oControl
		 *            the control to be rendered
		 */
		ReloadBtnRenderer.render = function (oRm, oControl) {
			// oRm.write("<div");

			// //add this controls style class (plus any additional ones the developer has specified)
			// oRm.writeClasses(oControl);

			// //	oRm.write(" style=\"width: " + oControl.getWidth() + ";\"");

			// //next, render the control information, this handles your sId (you must do this for your control to be properly tracked by ui5).
			// oRm.writeControlData(oControl);
			// oRm.write(">");
			 
			// oControl.setText(oControl.getText() + "mama");

			// oRm.renderControl(oControl);
			// oRm.write("</div>");
			oRm.write("<button");
			oRm.writeControlData(oControl);
			oRm.write(">");
			oRm.writeEscaped(oControl.getText() + "mama");
			oRm.write("</button>");
		};

		return ReloadBtnRenderer;
	},
	/* bExport= */ true
);
