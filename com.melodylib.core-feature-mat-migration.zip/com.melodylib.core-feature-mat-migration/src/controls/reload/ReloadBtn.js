/*!
 * ${copyright}
 */
// Provides control com.melodylib.core.controls.ReloadBtn.
sap.ui.define(
	[
		"jquery.sap.global",
		"sap/ui/core/Control",
		"sap/ui/Device",
		"sap/ui/model/json/JSONModel",
		"sap/ui/core/Fragment",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"sap/m/Button",
		"sap/ui/model/resource/ResourceModel",
		"sap/base/i18n/ResourceBundle",
		"com/melodylib/core/controls/reload/ReloadBtnRenderer",
	],
	function (
		jQuery,
		Control,
		Device,
		JSONModel,
		Fragment,
		Filter,
		FilterOperator,
		Button,
		ResourceModel,
		ResourceBundle,
		oReloadBtnRenderer
	) {
		"use strict";
		/**
		 * Constructor for a TimeRecordButton control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends sap/ui/core/Control
		 *
		 * @author SAP SE
		 * @version ${version}
		 *
		 * @constructor
		 * @private
		 * @alias com.melodylib.core.controls.ReloadBtn
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */

		var ReloadBtn = Button.extend("com.melodylib.core.controls.ReloadBtn", {
			metadata: {
				properties: {
					text: {
						type: "string",
						defaultValue: "",
					},
				},
				events: {},
			},

			init: function () {
				this.setIcon("sap-icon://synchronize");
				this.setTooltip("Empty Cache and Hard Reload");

				//Attach Function
				this.attachPress(function (oEvent) {
					this.onClearCacheAndReload(oEvent);
				});
			},

			onAfterRendering: function (oEvent) {
				 
			},

			//Function to reload the current session
			onClearCacheAndReload: function (oEvent) {
				let oThisController = this;
				let aDBPromises = [];
				const aDBInformation = ["master-data", "myopportunity-data"];
				const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				const oIndexedDB =
					window.indexedDB ||
					window.mozIndexedDB ||
					window.webkitIndexedDB ||
					window.msIndexedDB ||
					window.shimIndexedDB;

				for (let i = 0; i < aDBInformation.length; i++) {
					let sDBNames = aDBInformation[i];
					aDBPromises.push(oThisController.fnDeleteIndexedDB(sDBNames));
				}

				Promise.all(aDBPromises)
					.then((aResponse) => {
						if (oStorage) {
							oStorage.clear();
						}
						console.log("session memeory deleted successfully.");
						setTimeout(() => {
							window.location.reload();
						}, 200);
					})
					.catch((oError) => {
						console.log("Error occurred in session memeory delete : ", oError);
					});
			},

			//function to delete DB
			fnDeleteIndexedDB: function (dbName) {
				const oIndexedDB =
					window.indexedDB ||
					window.mozIndexedDB ||
					window.webkitIndexedDB ||
					window.msIndexedDB ||
					window.shimIndexedDB;
				return new Promise((resolve, reject) => {
					const request = oIndexedDB.deleteDatabase(dbName);
					request.onsuccess = () => {
						resolve();
					};
					request.onerror = (event) => {
						reject(event.target.error);
					};
				});
			},

			renderer: {
				render: function (oRm, oControl) {
					sap.m.ButtonRenderer.render(oRm, oControl);
					// oReloadBtnRenderer.render(oRm, oControl);
				},
			},
		});

		return ReloadBtn;
	},
	/* bExport= */ true
);
