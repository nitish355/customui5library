import * as UI5Object from "sap/ui/base/Object";
import Actions from "com/melodylib/core/enum/Actions";
import AuthState from "com/melodylib/core/state/AuthState";
import MasterDataState from "com/melodylib/core/state/MasterDataState";
import CoreLibraryModel from "com/melodylib/core/model/CoreLibraryModel";
import OpportunityState from "com/melodylib/integration/state/OpportunityState";
import ActivityState from "com/melodylib/activity/state/ActivityState";
import ActivityMasterState from "com/melodylib/activity/state/ActivityMasterState";
import DBRState from "com/melodylib/activity/state/DBRState";
import TimeState from "com/melodylib/time/state/TimeState";

/**
 * @name com.melodylib.core.Lib
 */
export default class Lib extends UI5Object {
	constructor() {
		super();
		this.authState = AuthState.getInstance();
		this.masterDataState = MasterDataState.getInstance();
		this.opportunityState = OpportunityState.getInstance();
		this.activityState = ActivityState.getInstance();
		this.activityMasterState = ActivityMasterState.getInstance();
		this.dbrState = DBRState.getInstance();
		this.timeState = TimeState.getInstance();
	}
	static getInstance() {
		if (!this.instance) {
			this.instance = new Lib();
		}
		return this.instance;
	}

	async init(options) {
		let appId = CoreLibraryModel.getProperty("/ApplicationId");
		if (!appId) {
			CoreLibraryModel.setProperty("/ApplicationId", options.appId);
			CoreLibraryModel.setProperty("/bUseBatch", options.useBatch);
		}
		let appPath = options.appId.replaceAll(".", "/");
		let appModulePath = jQuery.sap.getModulePath(appPath);
		console.log("APPLICATION MODULE PATH LIBRARY : ", appModulePath);
		CoreLibraryModel.refresh();

		//User Master Details and Inital App Data
		try {
			let user = await this.authState.authenticate(true);
			this._initializeAppData(options?.type, options.variantOptions);
			return user;
		} catch {
			return false;
		}
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function initializeAppData
	 * @description function to initalize calls and set the required application Data
	 */
	async _initializeAppData(projectType, variantOptions) {
		switch (projectType) {
			case Actions.projectTypes.activity:
				if (variantOptions.groupName === "MYDBR") {
					this.dbrState.init(variantOptions);
				} else {
					this.activityState.init(variantOptions);
				}
				await this.opportunityState.init();
				this.activityState.setOpportunity();
				this.timeState.init();
				break;
			case Actions.projectTypes.successLine:
				break;
			case Actions.projectTypes.mtr:
				break;
			case Actions.projectTypes.dashboard:
				break;
			default:
		}
		/* if (promises.length) {
			return Promise.allSettled(promises);
		} */
	}
}
