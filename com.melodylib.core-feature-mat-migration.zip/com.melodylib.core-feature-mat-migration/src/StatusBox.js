import StatusBoxControl from "com/melodylib/core/controls/statusBox/StatusBoxControl";

/**
 * @name com.melodylib.core.StatusBox
 */
const StatusBox = {
	
	open() {
		const statusBox = this._getStatusBox();
		statusBox.open();
	},

	close () {
		const statusBox = this._getStatusBox();
		statusBox.close();
	},

	addProcess (value) {
		let process;
		if(value) {
			const statusBox = this._getStatusBox();
			process = statusBox.addProcess({description: value});
			statusBox.open();
		}
		return process;
	},

	setCompleted(processId) {
		const statusBox = this._getStatusBox();
		statusBox.setStatus(processId, "SUCCESS");
		/* if(statusBox.getRunningProcesses().length === 0) {
			statusBox.close();
		} */
	},

	setFailed(processId) {
		const statusBox = this._getStatusBox();
		statusBox.setStatus(processId, "ERROR");
		/* if(statusBox.getRunningProcesses().length === 0) {
			statusBox.close();
		} */
	},

	getRunningProcesses() {
		const statusBox = this._getStatusBox();
		return statusBox.getRunningProcesses();
	},

	_getStatusBox() {
		let statusBox = sap.ui.getCore().statusBox;

		if (!statusBox) {
			statusBox = new StatusBoxControl();
            const popup = new sap.ui.core.Popup(statusBox, false, true, false);
            statusBox.setPopup(popup);
			sap.ui.getCore().statusBox = statusBox;
		}
		return statusBox;
	}
};

export default StatusBox;
