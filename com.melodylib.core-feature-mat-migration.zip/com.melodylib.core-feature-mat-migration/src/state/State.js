import Object from "sap/ui/base/Object";

/**
 * @namespace com.melodylib.core.state.State
 */
export default class State extends Object {
	constructor() {
		super();
	}

	static getInstance() {
		if (!this._instance) {
			this._instance = new State();
		}
		return this._instance;
	}

	getAuthState () {
		if(!this.authState) {
			this.authState = com.melodylib.core.state.AuthState.getInstance();
		}
		return this.authState;
	}

	getCoreMasterState () {
		if(!this.coreMasterState) {
			this.coreMasterState = com.melodylib.core.state.MasterDataState.getInstance();
		}
		return this.coreMasterState;
	}

	getAccountState () {
		if(!this.accountState) {
			this.accountState = com.melodylib.integration.state.AccountState.getInstance();
		}
		return this.accountState;
	}

	getActivityMasterState () {
		if(!this.activityMasterState) {
			this.activityMasterState = com.melodylib.activity.state.ActivityMasterState.getInstance();
		}
		return this.activityMasterState;
	}

	getActivityState () {
		if(!this.activityState) {
			this.activityState = com.melodylib.activity.state.ActivityState.getInstance();
		}
		return this.activityState;
	}

	getOpportunityState () {
		if(!this.opportunityState) {
			this.opportunityState = com.melodylib.integration.state.OpportunityState.getInstance();
		}
		return this.opportunityState;
	}
}
