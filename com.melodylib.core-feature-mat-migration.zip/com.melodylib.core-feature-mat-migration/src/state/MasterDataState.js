import IndexedDB from "com/melodylib/core/db/IndexedDB";
import BaseState from "com/melodylib/core/state/BaseState";
import MasterService from "com/melodylib/core/service/MasterService";

/**
 * @name com.melodylib.core.state.MasterDataState
 */
export default class MasterDataState extends BaseState {
	constructor() {
		super(MasterService.getInstance());
		this.setData({});
	}

	static getInstance() {
		if (!this._instance) {
			this._instance = new MasterDataState();
		}
		return this._instance;
	}

	async getConstants() {
		let constants =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "harmonyconstanturls",
			})) || [];

		constants =
			constants && constants instanceof Array && !constants.length
				? []
				: constants;
		if (!constants.length) {
			let { data } = await this._service.getConstants();
			const results = data?.results ?? [];
			constants = Array.from(results, (constant) => ({
				id: constant.const_id,
				key: constant.field_name,
				value: constant.field_value,
				description: constant.const_desc,
			}));
			this._data.constants = constants;
			IndexedDB.fnInsertDataToDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "harmonyconstanturls",
				aObjectsToInsert: constants,
			});
		} else {
			this._data.constants = constants;
		}
		this.updateModel();
	}

	async getCountries() {
		let { data } = await this._service.getCountries();
		const results = data?.results ?? [];
		const countries = Array.from(results, (country) => ({
			key: country.CountryKey,
			name: country.CountryName,
		}));
		this._data.countries = countries;
		this.updateModel();
	}
}
