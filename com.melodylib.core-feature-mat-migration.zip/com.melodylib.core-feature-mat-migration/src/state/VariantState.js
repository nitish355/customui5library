import Filter from "sap/ui/model/Filter";
import MessageToast from "sap/m/MessageToast";
import Variant from "com/melodylib/core/classes/Variant";
import BaseState from "com/melodylib/core/state/BaseState";
import Actions from "com/melodylib/integration/enum/Actions";
import * as CoreActions from "com/melodylib/core/enum/Actions";
import UserService from "com/melodylib/core/service/user/UserService";
import OpportunityState from "com/melodylib/integration/state/OpportunityState";

export default class VariantState extends BaseState {
	constructor() {
		super(UserService.getInstance());
		this.opportunityState = OpportunityState.getInstance();
		this._data = {
			variants: {
				entries: [],
				activities: [],
				dbr: [],
				opportunities: [],
			},
			busy: false,
			defaultKey: "standard",
			selectedKey: "standard",
			defaultVariant: "",
		};
	}

	/**
	 * @static
	 * @author DARSHAN
	 * @function getInstance
	 * @description function to return the instance of the variant state
	 */
	static getInstance() {
		if (!this._instance) {
			this._instance = new VariantState();
		}
		return this._instance;
	}

	/**
	 * @author DARSHAN
	 * @function init
	 * @description function to intialize the variant management data based on viewName
	 * @param {Object} options
	 * @param {String} viewName
	 */
	async init(options) {
		await this.getVariants(options);
	}

	/**
	 * @author DARSHAN
	 * @function init
	 * @description function to intialize the variant management data based on viewName
	 * @param {Object} options
	 */
	async getDefaultVariant(options = {}) {
		if ("variantId" in options && options.variantId) {
			// In Future any operation or logic required.
		} else {
			options.defaultVariant = "X";
		}
		let config = this.getURlParams(options);
		if (config.params.filters.length) {
			let { data } = await this._service.getMyVariants(config.params);
			let results = data?.results || [];
			let { variants, defaultVariant } = this.formatVariants(
				results,
				config.viewName
			);
			this._data.defaultVariant = defaultVariant;

			//Check for Team Members
			this.handleIncludeTeam(defaultVariant);

			return defaultVariant;
		}
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function getURlParams
	 * @description function to get the url parameterts based on options
	 */
	getURlParams(options) {
		let params = {
			filters: [],
		};
		let viewName = CoreActions.variantGroupTypes.activity;
		if (options && "variantId" in options && options.variantId) {
			params.filters.push(
				new Filter({
					path: "variantid",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: options.variantId,
				})
			);
		}
		if (options && "groupName" in options && options.groupName) {
			viewName = options.groupName;
			params.filters.push(
				new Filter({
					path: "view_name",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: options.groupName,
				})
			);
		}

		if (options && "defaultVariant" in options && options.defaultVariant) {
			params.filters.push(
				new Filter({
					path: "defaultVariant",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: options.defaultVariant,
				})
			);
		}
		return {
			params,
			viewName,
		};
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function setVariants
	 * @description function to set logged-in users default Variant if no variant found
	 */
	_setDefaultVariant(viewName) {
		let defaultVariant = new Variant(
			{
				variantid: "standard",
				variant_name: "Standard",
				defaultVariant: "X",
				Favourite: "X",
				executeonselect: "X",
				type: "P",
				Editable: "X",
			},
			viewName
		);
		defaultVariant.parseFilterString();
		return defaultVariant;
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function formatVariants
	 * @description function to format variants backend data properties to UI data properties
	 */
	formatVariants(results, viewName) {
		let variants = [];
		let defaultVariant;
		if (results.length) {
			variants = results.map((data) => {
				let variant = new Variant(data, viewName);
				variant.parseFilterString();
				return variant;
			});
			variants = variants.filter((variant) => {
				return variant.validVariant;
			});
			if (variants.length) {
				defaultVariant = Variant.getDefaultVariant(variants);
				if (!defaultVariant) {
					defaultVariant = this._setDefaultVariant(viewName);
					variants.push(defaultVariant);
				}
			} else {
				//DEFAULT VARIANT
				defaultVariant = this._setDefaultVariant(viewName);
				variants.push(defaultVariant);
			}
		} else {
			//DEFAULT VARIANT
			defaultVariant = this._setDefaultVariant(viewName);
			variants.push(defaultVariant);
		}
		return {
			defaultVariant,
			variants,
		};
	}

	/**
	 * @author DARSHAN
	 * @function manageVariant
	 * @description function to handle manage variants (DELETE, UPDATE NAME, DEFAULT, EXECUTE ON SELECT)
	 *
	 */
	async manageVariant(event, viewName) {
		let fetchVariant = false;
		const defaultValue = event.getParameter("def"); //DEFUALT
		const deleted = event.getParameter("deleted") || [];
		const renamed = event.getParameter("renamed") || [];
		const execute = event.getParameter("exe") || [];
		const favourites = event.getParameter("fav") || [];
		if (deleted.length) {
			fetchVariant = true;
			await this.deleteVariant(deleted);
		}

		if (renamed.length || execute.length || defaultValue || favourites.length) {
			fetchVariant = true;
			await this.updateVariant(
				renamed,
				defaultValue,
				execute,
				favourites,
				viewName
			);
		}
		return fetchVariant;
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function _setVariantBusy
	 * @description function to set busy indicator to variant management control
	 */
	_setVariantBusy(busy) {
		let model = this.getModel();
		this._data.busy = false;
		model.setProperty("/busy", busy);
		this.updateModel();
	}

	/**
	 * @author DARSHAN
	 * @function getVariants
	 * @description function to get logged-in users variants list data
	 */
	async getVariants(options, viewName) {
		try {
			let model = this.getModel();
			this._setVariantBusy(true);
			let config = this.getURlParams(options);
			let { data } = await this._service.getMyVariants(config.params);
			let results = data?.results || [];
			let { variants, defaultVariant } = this.formatVariants(
				results,
				config.viewName
			);

			//Based on View Name set the variant data
			this.updateOrRetrieveVariants(config.viewName, true, variants);

			this._data = {
				...this._data,
				defaultKey: defaultVariant ? defaultVariant.id : "",
				selectedKey: defaultVariant ? defaultVariant.id : "",
				defaultVariant: defaultVariant,
			};

			this._setVariantBusy(false);
			model.setData(this._data);
			this.updateModel();
			return this._data;
		} catch (error) {
			console.log("ERROR  IN getVariants : ", error);
		}
	}

	/**
	 * @author DARSHAN
	 * @function setVariants
	 * @description function to set logged-in users variants to filter the data
	 */
	async setVariant(options) {
		this._setVariantBusy(true);
		const variants =
			this.updateOrRetrieveVariants(options.viewName, false) || [];
		//CHECK IF MANUALLY CREATED VARIANT
		if (options.params.key === "standard") {
			options.params.key = "";
		}
		//CREATE SCENARIO
		if (!options.params.key) {
			let variant = options?.variant || {};
			variant.id = "";
			variant.name = options?.params?.name;
			variant.viewName = options?.viewName;
			variant.favourite = false;
			variant.applicationid = "LIREP";
			variant.default = !variants.length ? true : options?.params?.def;
			variant.executeOnSelect = !variants.length
				? true
				: options?.params?.execute;
			variant.type = !options?.params?.public ? "P" : "S";
			variant.configurations = JSON.stringify(options?.filters);
			const payload = Variant.getCreatePayload(variant);
			await this._service.setMyVariants(payload);
		}

		//SAVE AS SCENARIO
		if (options.params.key) {
			const payload = [];
			const variant = Variant.getVariantForPost(variants, options.params.key);
			if (variant) {
				payload.push(variant);
				let promises = payload.map((data) => {
					let payload = Variant.getUpdatePayload(data);
					return this._service.setMyVariants(payload);
				});
				await Promise.all(promises);
			}
		}

		this._setVariantBusy(false);
	}

	/**
	 * @author DARSHAN
	 * @function deleteVariant
	 * @description function to remove logged-in users variants to filter the data
	 * Since the API doesnt support batch, It is written in for loop
	 */
	async deleteVariant(data) {
		this._setVariantBusy(true);
		for (let i = 0; i < data.length; i++) {
			const id = data[i];
			if (id === "standard") {
				Variant.showErrorMsg();
				return;
			}
			await new Promise((resolve) => setTimeout(resolve, 800));
			await this._service.removeMyVariants(id);
		}
		this._setVariantBusy(false);
	}

	/**
	 * @author DARSHAN
	 * @function updateOrRetrieveVariants
	 * @description function to set and get the variants data based on view name
	 */
	updateOrRetrieveVariants(viewName, setVariant, data) {
		switch (viewName) {
			case CoreActions.variantGroupTypes.opportunity:
				if (setVariant) {
					this._data.variants.opportunities = data;
				} else {
					return this._data.variants.opportunities;
				}
				break;
			case CoreActions.variantGroupTypes.dbr:
				if (setVariant) {
					this._data.variants.dbr = data;
				} else {
					return this._data.variants.dbr;
				}
				break;
			case CoreActions.variantGroupTypes.entries:
				if (setVariant) {
					this._data.variants.entries = data;
				} else {
					return this._data.variants.entries;
				}
				break;
			default:
				if (setVariant) {
					this._data.variants.activities = data;
				} else {
					return this._data.variants.activities;
				}
		}
	}

	/**
	 * @author DARSHAN
	 * @function updateVariant
	 * @description function to update logged-in users variants to filter the data
	 * Delete and Fav functionalities is not supporting batch calls using promise
	 */
	async updateVariant(renamed, defaultValue, execute, favourites, viewName) {
		try {
			const payload = [];
			const variants = this.updateOrRetrieveVariants(viewName, false);
			this._setVariantBusy(true);

			for (let i = 0; i < renamed.length; i++) {
				let data = renamed[i];
				if (data.key === "standard") {
					Variant.showErrorMsg();
					return;
				}
				let variant = Variant.getVariantForPost(variants, data.key);
				if (variant) {
					if (defaultValue && variant.id === defaultValue) {
						variant.default = true;
					}
					variant.name = data.name;
					payload.push(variant);
				}
			}

			//The Delete is not working with batch!!
			for (let i = 0; i < execute.length; i++) {
				let data = execute[i];
				if (data.key === "standard") {
					Variant.showErrorMsg();
					return;
				}
				let variant = Variant.getVariantForPost(variants, data.key);
				if (variant) {
					if (defaultValue && variant.id === defaultValue) {
						variant.default = true;
					}
					variant.executeOnSelect = data.exe;
					let payload = Variant.getUpdatePayload(variant);
					delete payload.includeteam;
					delete payload.view_name;
					await new Promise((resolve) => setTimeout(resolve, 800));
					await this._service.setMyVariants(payload);
				}
			}

			//The Favourites is not working with batch!!
			for (let i = 0; i < favourites.length; i++) {
				let data = favourites[i];
				if (data.key === "standard") {
					Variant.showErrorMsg();
					return;
				}
				let variant = Variant.getVariantForPost(variants, data.key);
				if (variant) {
					if (defaultValue && variant.id === defaultValue) {
						variant.default = true;
					}
					variant.favourite = data.visible;
					let payload = Variant.getUpdatePayload(variant);
					delete payload.includeteam;
					delete payload.view_name;
					await new Promise((resolve) => setTimeout(resolve, 800));
					await this._service.setMyVariants(payload);
				}
			}

			if (defaultValue) {
				if (defaultValue === "standard") {
					Variant.showErrorMsg();
					return;
				}
				const index = payload.findIndex((data) => {
					return data.id === defaultValue;
				});
				let variant = Variant.getVariantForPost(variants, defaultValue);
				if (index === -1 && variant) {
					variant.default = true;
					payload.push(variant);
				}
			}

			if (payload.length) {
				let promises = payload.map((variant) => {
					let payload = Variant.getUpdatePayload(variant);
					delete payload.includeteam;
					delete payload.view_name;
					return this._service.setMyVariants(payload);
				});
				await Promise.all(promises);
				this._setVariantBusy(false);
			}
			this._setVariantBusy(false);
		} catch (error) {
			Variant.showErrorMsg("Error Occured During Variant Update.");
			console.log("ERROR IN updateVariant : ", error);
		}
	}

	/**
	 * @author DARSHAN
	 * @function handleIncludeTeam
	 * @description function to handle include team members functionalities
	 * @param {Object} variant
	 */
	async handleIncludeTeam(variant) {
		try {
			if (!variant || !variant.includeTeam) {
				return;
			}
			let promises = [];
			let filterProperties;
			if (!this.opportunityState) {
				this.opportunityState = OpportunityState.getInstance();
			}

			if ("properties" in variant.configurations) {
				filterProperties = variant.configurations.properties;
			} else {
				filterProperties = {};
			}

			let activityLeads =
				"lead" in filterProperties ? filterProperties.lead.values : [];

			//Activities
			if (variant.checkForManagerVariant() && activityLeads.length) {
				activityLeads = activityLeads.map((user) => {
					return {
						id: user.value1,
					};
				});
				this.opportunityState.getTeamOpportunity(activityLeads).then();
				return;
			}

			//Opportunities
			if (
				variant.includeTeam &&
				variant.viewName === CoreActions.variantGroupTypes.opportunity
			) {
				this.opportunityState.getTeamOpportunity().then();
				return;
			}
		} catch (error) {
			console.log("ERROR IN handleIncludeTeam : ", error);
		}
	}
}
