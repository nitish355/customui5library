import Object from "sap/ui/base/Object";
import JSONModel from "sap/ui/model/json/JSONModel";

/**
 * @namespace com.melodylib.core.state.BaseState
 */
export default class BaseState extends Object {
	constructor(service) {
		super();
		this._service = service;
	}

	setData(data, hardRefresh) {
		this._data = data;
		this.updateModel(hardRefresh);
	}

	getModel() {
		if (!this._model) {
			this._model = new JSONModel(this._data);
		}
		return this._model;
	}
	updateModel(hardRefresh) {
		if (this.getModel()) {
			this._model.refresh(hardRefresh ? true : false);
		}
	}
	getService() {
		return this._service;
	}
	getData() {
		return this._data;
	}
}
