import User from "com/melodylib/core/classes/User";
import Variant from "com/melodylib/core/classes/Variant";
import BaseState from "com/melodylib/core/state/BaseState";
import DateService from "com/melodylib/core/service/DateService";
import UserService from "com/melodylib/core/service/user/UserService";
import ISPService from "com/melodylib/integration/service/ISPService";
import OppService from "com/melodylib/integration/service/OppService";
import Fragment from "sap/ui/core/Fragment";
import Filter from "sap/ui/model/Filter";

/**
 * @name com.melodylib.core.state.AuthState
 */
export default class AuthState extends BaseState {
	constructor() {
		super(UserService.getInstance());
		this.ispService = ISPService.getInstance();
		this.opportunityService = OppService.getInstance();
		this.dateService = DateService.getInstance();
		// this.timeService = TimeService.getInstance();
		// this.timeMaster = TimeMasterState.getInstance();
		this._data = new User();
		this._data.busy = false;
	}

	static getInstance() {
		if (!this._instance) {
			this._instance = new AuthState();
		}
		return this._instance;
	}

	setLoading(isLoading) {
		this._data.busy = isLoading ? true : false;
		this.updateModel();
	}

	async getUser(hardRefresh) {
		let user = this.getData();
		if (!hardRefresh && user && user?.id) {
			return user;
		}

		return await this.authenticate();
	}

	async authenticate() {
		await this._getUserDetail();
		// this.data.oreFlag = "";
		if (this._data.oreFlag === "X") {
			let projectType = "ACTVT";
			this._getNonOreUserAppBasedCheck(projectType).then((nonOreUserData) => {
				if (nonOreUserData) {
					this._data.setNonOreUserData(nonOreUserData);
				}
			});
			/* const nonOreUserData = await this._getNonOreUserAppBasedCheck(projectType);
		if (nonOreUserData) {
			this._data.setNonOreUserData(nonOreUserData);
		} */
			this.updateModel();
			this.getUserRoles();
			return this._data;
		} else {
			throw "UnAuthorized";
		}
	}

	async getISPUserInfo() {
		const user = this.getData();
		let ispUserData = null;
		try {
			const { data } = await this.ispService.getUserInfo();
			if (data.results.length > 0) {
				ispUserData = data.results[0];
			}
		} catch (error) {
			console.log(error);
		}
		user.setISPUserData(ispUserData);
		this.updateModel();
		return user.isISPUser;
	}

	async getMyTeam() {
		let { data } = await this._service.getMyTeam();
		let results = data?.results || [];
		results = results.filter((user) => {
			return user.userid !== this._data.id;
		});
		const team = Array.from(
			results,
			(user) =>
				new User({
					UserId: user.userid,
					UserName: user.name,
				})
		);
		this._data.setTeam(team);
		this.updateModel();
		return team;
	}

	async _getUserDetail() {
		const data = await this._service.getUserDetail();
		const results = data?.data.results;
		if (results && results.length > 0 && results[0].UserId !== "") {
			this._data.setData(results[0]);
			const id = this._getExceptionUserIds().find((id) => id === this._data.Id);
			if (!id) {
				this._injectWarp(this._data);
			}
		}
	}

	async _getNonOreUserAppBasedCheck(projectType) {
		const data = await this._service.getAuthCheckForNonOreUser(projectType);
		return data?.data;
	}

	async getBusinessPartner() {
		try {
			const userId = this._data?.id;
			if (!userId) {
				return null;
			}
			const { data } = await this.opportunityService.getBusinessPartner(userId);
			const partnerId = data?.results[0]?.PARTNER;

			this._data.partnerId = partnerId;

			return partnerId;
		} catch (error) {
			return null;
		}
	}

	_getExceptionUserIds() {
		return this._service.getExceptionUserIds();
	}

	_injectWarp(user) {
		//delete JSON_PIWIK;
		let pubToken, subSiteId, appName;
		pubToken = subSiteId = appName = "";
		let hash = window.location.hash.toLowerCase();

		// var that = this;
		window.swaCustomFields = {
			custom1: "",
			custom2: "",
			custom3: "",
			custom4: "",
			custom5: "",
		};

		//check whether navigation is from SMT apps to assign subsiteId of SMT
		if (
			hash.indexOf("#smtmassedit-app") !== -1 ||
			hash.indexOf("#smtform-app") !== -1 ||
			hash.indexOf("#smt-app") !== -1 ||
			hash.indexOf("#smtadmin-app") !== -1
		) {
			appName = "SMT";
		}
		if (hash.indexOf("#sl-app") !== -1) {
			appName = "SuccessLine";
		}

		if (window.location.host.indexOf("br339jmc4c") !== -1) {
			pubToken = "89cccf7b-6cfe-9243-8d9f-75e604e8c575";
			if (appName === "SMT") {
				subSiteId = "SMTDev";
			} else if (appName === "SuccessLine") {
				subSiteId = "SuccessLineDev";
			} else {
				subSiteId = "MelodyDev";
			}
		} else if (
			window.location.host.indexOf("sapitcloudt") !== -1 ||
			window.location.host.indexOf("fiorilaunchpad-qa.sap.com") !== -1
		) {
			pubToken = "4cd44f02-28e4-d347-a013-2fd77b7b5426";
			if (appName === "SMT") {
				subSiteId = "SMTTest";
			} else if (appName === "SuccessLine") {
				subSiteId = "SuccessLineTest";
			} else {
				subSiteId = "MelodyTest";
			}
		} else if (window.location.host.indexOf("fiorilaunchpad.sap.com") !== -1) {
			pubToken = "6051b26a-7f22-384a-86e0-f7bf43fea890";
			if (appName === "SMT") {
				subSiteId = "SMT";
			} else if (appName === "SuccessLine") {
				subSiteId = "SuccessLineProd";
			} else {
				subSiteId = "Melody";
			}
		}
		window.swa = {
			pubToken: pubToken,
			baseUrl: "https://webanalytics.cfapps.eu10.hana.ondemand.com/tracker/",
			/*Please provide function name which will return owner info or string value of owner info*/
			owner: "",
			subSiteId: subSiteId,
			custom1: {
				ref: function () {
					return window.swaCustomFields.custom1;
				},
			},
			custom2: {
				ref: function () {
					return window.swaCustomFields.custom2;
				},
			},
			custom3: {
				ref: function () {
					return window.swaCustomFields.custom3;
				},
			},
			custom4: {
				ref: function () {
					return window.swaCustomFields.custom4;
				},
			},
			custom5: {
				ref: function () {
					return window.swaCustomFields.custom5;
				},
			},
		};
		window.swaCustomFields.custom1 = user.RegionName;
		window.swaCustomFields.custom2 = user.SubRegionName;
		window.swaCustomFields.custom3 = user.MuName;
		window.swaCustomFields.custom4 = user.Headcount;
		window.swaCustomFields.custom5 = user.OreFlag;

		(function () {
			var d = document,
				g = d.createElement("script"),
				s = d.getElementsByTagName("script")[0];
			g.type = "text/javascript";
			g.defer = true;
			g.async = true;
			g.src = window.swa.baseUrl + "js/privacy.js";
			s.parentNode.insertBefore(g, s);
			g.onload = function (script) {
				setTimeout(function () {
					window.swa.enable();
				}, 2000);
			};
		})();
	}

	async getUserRoles() {
		let { data } = await this._service.getUserRoles();
		const results = data?.results ?? [];
		let roles = Array.from(results, (role) => ({
			id: role.RoleID,
			description: role.RoleDesc,
			default: role.DefaultRole,
			mappingId: role.RoleMpngID,
		}));
		this._data.roles = roles;
		let defaultRole = roles.find((each) => each.default === "X");
		let roleMappingId = "";
		if (!defaultRole) {
			defaultRole = "0001";
			roleMappingId = "001";
		} else {
			roleMappingId = defaultRole.mappingId;
			defaultRole = defaultRole.id;
		}
		this._data.role = {
			id: defaultRole,
			mappingId: roleMappingId,
		};
		this.updateModel();
		return roles;
	}

	async getEmployeeInfo(employeeId, source) {
		// const data = {
		// 	id: "C5378100",
		// 	firstName: "SRIKARI",
		// 	lastName: "BODUGAM",
		// 	email: "srikari.bodugam@sap.com",
		// 	country: "IN",
		// 	employeeType: "external - Service",
		// 	contactInfo: {},
		// 	costCenter: {
		// 		id: "0176000711",
		// 		name: "CA Field Readiness - Perf T&D - IND",
		// 	},
		// 	manager: {},
		// 	assistant: {},
		// 	company: {
		// 		id: "0076",
		// 		name: "SAP Labs India PVT. Ltd.",
		// 		address: {
		// 			name: "NTT DATA BUSINESS SOLUTIONS",
		// 			postalCode: "500081",
		// 			city: "Hyderabad",
		// 			street: "3rd Floor B wing, Plot no 4, Softso",
		// 			country: "IN",
		// 			region: "APJ",
		// 		},
		// 	},
		// 	department: {
		// 		id: "00000000",
		// 	},
		// 	officeLocation: {},
		// 	jobInfo: {},
		// 	profilePictureEnabled: false,
		// };
		// this._data.employeeData = data;
		// this.updateModel();
		const model = this.getModel();
		this.setLoading(true);
		let oThisController = this;
		if (!this._userInfoPopover) {
			this._userInfoPopover = Fragment.load({
				name: "com.melodylib.core.fragments.userInfo.UserInfoQuickView",
				controller: oThisController,
			}).then(function (_userInfoPopover) {
				// oThisController.addDependent(_userInfoPopover);
				return _userInfoPopover;
			});
		}
		let parameters = {
			expand: "to_dataowner",
			filters: [new Filter("Action", "EQ", "GET")],
		};
		this._userInfoPopover.then(
			async function (_userInfoPopover) {
				_userInfoPopover.setModel(model, "authState");
				_userInfoPopover.openBy(source);
			}.bind(this)
		);
		try {
			let { data } = await this._service.getEmployeeInfo(
				employeeId,
				parameters
			);
			this._data.employeeData = data;
			this.setLoading(false);
			this.updateModel();
		} catch (e) {
			console.log(e);
			this.setLoading(false);
		}

		// if (!this._userInfoPopover) {
		// 	this._userInfoPopover = await this.loadFragment({
		// 		name: "com.melodylib.core.fragments.userInfo.UserInfoQuickView",
		// 	});
		// }
		// this._userInfoPopover.openBy(source);
	}
}
