sap.ui.define(
	[
		"com/melodylib/core/model/CoreLibraryModel",
		"com/melodylib/core/util/usersettings/Usermaster",
		"com/melodylib/integration/util/opportunity/DiscontinuedOpportunity",
		"com/melodylib/integration/util/opportunity/DiscontinuedOpportunityController"
	],
	function (oCoreLibraryModel, Usermaster, DiscontinuedOpportunity, DiscontinuedOpportunityController) {
		"use strict";
		return {
			//Function to set parent application
			setApplication: async function (options) {
				const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				let ApplicationId = oCoreLibraryModel.getProperty("/ApplicationId");
				let bPcDiscontinuedOppUpdated = oStorage.get(
					"pcDiscontinuedOppUpdated"
				);
				let bPcDiscontinuedOppInitCall = oStorage.get(
					"pcDiscontinuedOppInitCall"
				);
				
				if (!ApplicationId) {
					oCoreLibraryModel.setProperty("/ApplicationId", options.appId);
					oCoreLibraryModel.setProperty("/bUseBatch", options.bUseBatch);
				}
				let appPath = options.appId.replaceAll(".", "/");
				let appModulePath = jQuery.sap.getModulePath(appPath);
				console.log("APPLICATION MODULE PATH LIBRARY : ", appModulePath);
				oCoreLibraryModel.refresh();

				//User Master Details
				let oUserData = await Usermaster.authenticate();
				oCoreLibraryModel.setProperty("/oUserData", oUserData);

				return new Promise((resolve, reject) => {
					resolve();
				});
			},

			testFunction: function (appId) {
				console.log("WORKING CROSS LIB FUNCTION CALL");
			},
		};
	}
);
