sap.ui.define(
	[],
	function () {
		"use strict";

		return {
			//function to insert data
			fnInsertDataToDB: function (options, arrayToInsert) {
				let oThisController = this;
				const indexedDB =
					window.indexedDB ||
					window.mozIndexedDB ||
					window.webkitIndexedDB ||
					window.msIndexedDB ||
					window.shimIndexedDB;

				//Creating/Opening DB (name,version);
				let request = indexedDB.open(options.dbName);

				//Error Handler in indexedDB
				request.onerror = function (event) {
					console.error("IndexedDB error:", event.target.errorCode);
				};

				//Function that executes on version change or in DB change
				request.onupgradeneeded = function (event) {
					let db = event.target.result;

					// Define object store if it doesn't exist
					if (!db.objectStoreNames.contains(options.storeName)) {
						let objectStore = db.createObjectStore(options.storeName, {
							keyPath: "key",
							autoIncrement: true,
						});
					}
				};

				request.onsuccess = function (event) {
					let db = event.target.result;
					let storeName = options.storeName;
					// Ensure the object store exists
					if (db.objectStoreNames.contains(storeName)) {
						// Access the object store
						let transaction = db.transaction([storeName], "readwrite");
						//Get Object Store
						let objectStore = transaction.objectStore(storeName);

						//Get Index
						// const oppIdIndex = objectStore.index("OpportunityId");

						if ("aObjectsToInsert" in options && options.aObjectsToInsert) {
							let aObjectsToInsert = options.aObjectsToInsert ?? [];

							objectStore.put({
								key: options.keyName,
								date: options?.updatedDate
									? options.updatedDate
									: new Date().toLocaleString(),
								value: aObjectsToInsert,
							});
						}

						transaction.oncomplete = function (event) {
							console.log("Array inserted into IndexedDB.");
							db.close();
						};

						transaction.onerror = function (event) {
							console.error("Error inserting array:", event.target.error);
							db.close();
						};
					}
					// oThisController.fnCreateStoreInsertData(options, db);
				};
			},

			//Creation of Objectstore

			//Get All The data
			fnGetAllDatafromDB: function (options) {
				const indexedDB =
					window.indexedDB ||
					window.mozIndexedDB ||
					window.webkitIndexedDB ||
					window.msIndexedDB ||
					window.shimIndexedDB;

				return new Promise((resolve, reject) => {
					let request = indexedDB.open(options.dbName);

					request.onupgradeneeded = function (event) {
						const db = event.target.result;
						// Define object store if it doesn't exist
						if (!db.objectStoreNames.contains(options.storeName)) {
							let objectStore = db.createObjectStore(options.storeName, {
								keyPath: "key",
								autoIncrement: true,
							});
						}
					};

					request.onsuccess = function (event) {
						let db = event.target.result;
						if (db && db?.objectStoreNames.contains(options.storeName)) {
							// Access an object store within the database
							let transaction = db.transaction([options.storeName], "readonly");
							let objectStore = transaction.objectStore(options.storeName);

							// Retrieve all data from the object store
							try {
								let getAllRequest;

								if (options && "keyName" in options && options.keyName) {
									getAllRequest = objectStore.get(options.keyName);
								} else {
									getAllRequest = objectStore.getAll();
								}

								getAllRequest.onsuccess = function (event) {
									let aValue = [];
									let oAllData = event.target.result || false;
									if (oAllData && "value" in oAllData) {
										aValue = oAllData.value ?? [];
										// console.log(
										// 	`DATA LOADED FROM LOCAL INDEXED-DB FOR : ${options.storeName}`,
										// 	aValue
										// );
									} else if (
										oAllData &&
										oAllData instanceof Array &&
										oAllData.length
									) {
										aValue = oAllData;
									}
									db.close();
									resolve(aValue);
								};

								getAllRequest.onerror = function (event) {
									console.error("Error getting all data:", event.target.error);
									db.close();
									reject(event.target.error);
								};
							} catch (error) {
								console.log("NO KEY IS PRESENT IN OBJECT STORE");
								resolve([]);
							}
						} else {
							console.log("NO OBJECT STORE");
							resolve([]);
						}
					};

					// Event handler for failed database opening
					request.onerror = function (event) {
						let db = event.target.result;
						if (db) {
							db.close();
						}
						console.error("Error opening database:", event.target.error);
						reject("NO DB PRESENT");
					};
				});
			},
		};
	},
	true
);
