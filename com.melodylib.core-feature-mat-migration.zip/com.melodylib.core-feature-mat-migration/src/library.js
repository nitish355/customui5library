/*!
 * ${copyright}
 */

/**
 * Initialization Code and shared classes of library com.melodylib.core.
 */
sap.ui.define(["sap/ui/core/library"], function () {
	"use strict";

	// delegate further initialization of this library to the Core
	// Hint: sap.ui.getCore() must still be used to support preload with sync bootstrap!
	sap.ui.getCore().initLibrary({
		name: "com.melodylib.core",
		version: "${version}",
		dependencies: [
			// keep in sync with the ui5.yaml and .library files
			"sap.ui.core",
		],
		types: ["com.melodylib.core.ExampleColor"],
		interfaces: [],
		controls: [
			"com.melodylib.core.Example",
			"com.melodylib.core.controls.quicknav.QuickNavMenu",
			"com.melodylib.core.controls.reload.ReloadBtn",
		],
		elements: ["com.melodylib.core.App"],
		noLibraryCSS: false, // if no CSS is provided, you can disable the library.css load here
	});

	/**
	 * Some description about <code>com.melodylib.core</code>
	 *
	 * @namespace
	 * @name com.melodylib.core
	 * @author DARSHAN PULIKESHI
	 * @version ${version}
	 * @public
	 */
	var thisLib = com.melodylib.core;

	/**
	 * Semantic Colors of the <code>com.melodylib.core.Example</code>.
	 *
	 * @enum {string}
	 * @public
	 */
	thisLib.ExampleColor = {
		/**
		 * Default color (brand color)
		 * @public
		 */
		Default: "Default",

		/**
		 * Highlight color
		 * @public
		 */
		Highlight: "Highlight",
	};

	return thisLib;
});
