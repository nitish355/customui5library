import * as UI5Object from "sap/ui/base/Object";
import CoreLibraryModel from "com/melodylib/core/model/CoreLibraryModel";
import UserService from "com/melodylib/core/service/user/UserService";
import User from "com/melodylib/core/classes/User"

/**
 * @name com.melodylib.core.util.user.UserUtil
 */
export default class UserUtil extends UI5Object {
    constructor() {
        super();
        this._service = UserService.getInstance();
    }
    static getInstance() {
        if (!this.instance) {
            this.instance = new UserUtil();
        }
        return this.instance;
    }

    async authenticate() {
        let user = CoreLibraryModel.getProperty("/oUserData") || false;
        if (user) {
            return user;
        }
        user = await this._getUserDetail();

        let projectType = "ACTVT";

        const nonOreUserData = await this._getNonOreUserAppBasedCheck(projectType);

        if (nonOreUserData) {
            user.setNonOreUserData(nonOreUserData);
        }

        CoreLibraryModel.setProperty("/oUserData", user);

        return user;
    }

    async _getUserDetail() {
        let user = null;
        const data = await this._service.getUserDetail();
        const results = data?.data.results;
        if (
            results && results.length > 0 && results[0].UserId !== ""
        ) {
            user = new User(results[0]);
            const id = this._getExceptionUserIds().find(
                (id) => id === user.Id
            );
            if (!id) {
                this._injectWarp(user);
            }
        }
        return user;
    }

    async _getNonOreUserAppBasedCheck(projectType) {
        const data = await this._service.getAuthCheckForNonOreUser(
            projectType
        );
        return data?.data;
    }

    _getExceptionUserIds() {
        return this._service.getExceptionUserIds();
    }

    _injectWarp(user) {
        //delete JSON_PIWIK;
        let pubToken, subSiteId, appName;
        pubToken = subSiteId = appName = "";
        let hash = window.location.hash.toLowerCase();

        // var that = this;
        window.swaCustomFields = {
            custom1: "",
            custom2: "",
            custom3: "",
            custom4: "",
            custom5: "",
        };

        //check whether navigation is from SMT apps to assign subsiteId of SMT
        if (
            hash.indexOf("#smtmassedit-app") !== -1 ||
            hash.indexOf("#smtform-app") !== -1 ||
            hash.indexOf("#smt-app") !== -1 ||
            hash.indexOf("#smtadmin-app") !== -1
        ) {
            appName = "SMT";
        }
        if (hash.indexOf("#sl-app") !== -1) {
            appName = "SuccessLine";
        }

        if (window.location.host.indexOf("br339jmc4c") !== -1) {
            pubToken = "89cccf7b-6cfe-9243-8d9f-75e604e8c575";
            if (appName === "SMT") {
                subSiteId = "SMTDev";
            } else if (appName === "SuccessLine") {
                subSiteId = "SuccessLineDev";
            } else {
                subSiteId = "MelodyDev";
            }
        } else if (
            window.location.host.indexOf("sapitcloudt") !== -1 ||
            window.location.host.indexOf("fiorilaunchpad-qa.sap.com") !== -1
        ) {
            pubToken = "4cd44f02-28e4-d347-a013-2fd77b7b5426";
            if (appName === "SMT") {
                subSiteId = "SMTTest";
            } else if (appName === "SuccessLine") {
                subSiteId = "SuccessLineTest";
            } else {
                subSiteId = "MelodyTest";
            }
        } else if (
            window.location.host.indexOf("fiorilaunchpad.sap.com") !== -1
        ) {
            pubToken = "6051b26a-7f22-384a-86e0-f7bf43fea890";
            if (appName === "SMT") {
                subSiteId = "SMT";
            } else if (appName === "SuccessLine") {
                subSiteId = "SuccessLineProd";
            } else {
                subSiteId = "Melody";
            }
        }
        window.swa = {
            pubToken: pubToken,
            baseUrl:
                "https://webanalytics.cfapps.eu10.hana.ondemand.com/tracker/",
            /*Please provide function name which will return owner info or string value of owner info*/
            owner: "",
            subSiteId: subSiteId,
            custom1: {
                ref: function () {
                    return window.swaCustomFields.custom1;
                },
            },
            custom2: {
                ref: function () {
                    return window.swaCustomFields.custom2;
                },
            },
            custom3: {
                ref: function () {
                    return window.swaCustomFields.custom3;
                },
            },
            custom4: {
                ref: function () {
                    return window.swaCustomFields.custom4;
                },
            },
            custom5: {
                ref: function () {
                    return window.swaCustomFields.custom5;
                },
            },
        };
        window.swaCustomFields.custom1 = user.RegionName;
        window.swaCustomFields.custom2 = user.SubRegionName;
        window.swaCustomFields.custom3 = user.MuName;
        window.swaCustomFields.custom4 = user.Headcount;
        window.swaCustomFields.custom5 = user.OreFlag;

        (function () {
            var d = document,
                g = d.createElement("script"),
                s = d.getElementsByTagName("script")[0];
            g.type = "text/javascript";
            g.defer = true;
            g.async = true;
            g.src = window.swa.baseUrl + "js/privacy.js";
            s.parentNode.insertBefore(g, s);
            g.onload = function (script) {
                setTimeout(function () {
                    window.swa.enable();
                }, 2000);
            };
        })();
    }
}