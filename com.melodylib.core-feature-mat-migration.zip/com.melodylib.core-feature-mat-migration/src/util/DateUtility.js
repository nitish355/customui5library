/**
 * @name com.melodylib.core.service.DateUtility
 */
const DateUtility = {
    format(dDate, sFormat) {
        if (!sFormat || sFormat === "") {
            sFormat = "MMM dd, y";
        }
        sFormat = sFormat.replace(/D/g, "d");
        sFormat = sFormat.replace(/Y/g, "y");
        var oFormat = sap.ui.core.format.DateFormat.getInstance({
            pattern: sFormat,
            calendarType: sap.ui.core.CalendarType.Gregorian
        });
        return oFormat.format(dDate);
    }, 

    formatStringDate(sDate, sFormat) {
        if (!sDate) {
            return "";
        }
        var dDate = new Date(sDate.substring(0, 4) + "/" + sDate.substring(4, 6) + "/" + sDate.substring(6, 8));
        if (sFormat && sFormat !== "") {
            return this.format(dDate, sFormat);
        } else {
            return dDate;
        }

    },
    
    getTimeStamp(dDate) {
        var oDateFormat = sap.ui.core.format.DateFormat.getInstance({
            pattern: "yyyyMMddHHmmss",
            calendarType: sap.ui.core.CalendarType.Gregorian
        });
        return oDateFormat.format(dDate);
    },
    
    dateDiff(dStartDate, dEndDate) {
        return Math.abs(Math.round((dEndDate - dStartDate) / (1000 * 60 * 60 * 24)));
    },

    getStartDateOfWeek(dt, iDateIndex) {
        var dDate = dt;
        if (!dDate) {
            dDate = new Date();
        }
        var iWeekStartDay = 1;
        var day = dDate.getDay();
        if (iWeekStartDay !== day) {
            var diff = dDate.getDate() - day + (day === 0 ? -6 : iWeekStartDay); // adjust when day is sunday
            return new Date(dDate.getFullYear(), dDate.getMonth(), diff);
        }
        return dDate;
    },

    getWeek(dDate) {
        var onejan = new Date(dDate.getFullYear(), 0, 1);
        return Math.ceil((((dDate - onejan) / 86400000) + onejan.getDay() + 1) / 7);
    },

    weekCount(year, month_number, startDayOfWeek) {
        // month_number is in the range 1..12

        // Get the first day of week week day (0: Sunday, 1: Monday, ...)
        var firstDayOfWeek = startDayOfWeek || 0;

        var firstOfMonth = new Date(year, month_number - 1, 1);
        var lastOfMonth = new Date(year, month_number, 0);
        var numberOfDaysInMonth = lastOfMonth.getDate();
        var firstWeekDay = (firstOfMonth.getDay() - firstDayOfWeek + 7) % 7;

        var used = firstWeekDay + numberOfDaysInMonth;

        return Math.ceil(used / 7);
    },

    weeksBetween(d1, d2) {
        return Math.round((d2 - d1) / (7 * 24 * 60 * 60 * 1000));
    },

    validateBetweenStringDate(fromStringDate, toStringDate, checkStringDate) {
        var checkDate = instance.formatStringDate(checkStringDate);
        var fromDate = instance.formatStringDate(fromStringDate);
        var toDate = instance.formatStringDate(toStringDate);

        if (checkDate < fromDate || checkDate > toDate) {
            return false;
        } else {
            return true;
        }
    },

    isWeekend(recordDate, startDayOfWeek) {
        if(!recordDate || isNaN(parseInt(startDayOfWeek))) {
            return false;
        }
        let firstWeekend = 5 + startDayOfWeek;
        if (firstWeekend > 6) {
            firstWeekend = firstWeekend - 7;
        }
        let secondWeekend = 6 + startDayOfWeek;
        if (secondWeekend > 6) {
            secondWeekend = secondWeekend - 7;
        }
        const date = this.formatStringDate(recordDate);
        const day = date.getDay();
        if (day === firstWeekend || day === secondWeekend) {
            return true;
        } else {
            return false;
        }
    }
}
export default DateUtility;