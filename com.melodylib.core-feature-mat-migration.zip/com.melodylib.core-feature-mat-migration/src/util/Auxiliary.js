sap.ui.define(
	[
		"sap/base/Log",
		"sap/m/MessageBox",
		"sap/ui/model/Filter",
		"sap/ui/core/Fragment",
		"sap/ui/model/FilterOperator",
		"sap/ui/model/json/JSONModel",
		"sap/ui/model/resource/ResourceModel",
	],
	function (
		BaseLog,
		MessageBox,
		Filter,
		Fragment,
		FilterOperator,
		JSONModel,
		ResourceModel
	) {
		"use strict";
		return {
			/**
			 * @author DARSHAN
			 * @purpose Function to initiliaze dialog fragments dynamically
			 * @param oControlSource - Object-Control Source
			 * @param bPopover - Boolean
			 * @param oFragmentData - Object-contains below params
			 * @param pFragmentPath -- String-Fragment Path
			 * @param pFragmentName -- String-Fragment Name
			 * @param pFragmentId -- String-Fragment Id
			 * @param pFragmentControl -- Object-Fragment Controller Object
			 * @param pFragmentI18n -- String-Fragment i18n Path
			 */
			fnInitializeDialogFragments: function (
				oFragmentData,
				bPopover,
				oControlSource
			) {
				let oThisController = this;
				if (!oThisController[oFragmentData.pFragmentName]) {
					oThisController[oFragmentData.pFragmentName] = Fragment.load({
						id: `${oThisController.getId()}${oFragmentData.pFragmentId}`,
						name: oFragmentData.pFragmentPath,
						controller: oFragmentData.pFragmentControl,
					}).then(
						function (oDialog) {
							let i18nModel = new ResourceModel({
								bundleName: `${oFragmentData.pFragmentI18n}`,
							});
							oDialog.setModel(i18nModel, "i18n");
							oDialog.setModel(oThisController.getModel());
							oThisController.addDependent(oDialog);
							return oDialog;
						}.bind(oThisController)
					);
				}
				oThisController[oFragmentData.pFragmentName].then(function (oDialog) {
					if (bPopover) {
						oDialog.openBy(oControlSource);
					} else {
						oDialog.open();
					}
				});
			},

			/**
			 * @author DARSHAN
			 * @purpose Message
			 * @param1 pMessage -- String-Message to be displayed
			 * @param2 pMsgTyp -- String-Message type
			 * @param2 pHandler -- function-callback function
			 */
			showMessage: function (pMessage, pMsgTyp, pHandler) {
				if (pMessage.trim().length === 0) {
					return;
				}

				if (["A", "E", "I", "W"].indexOf(pMsgTyp) === -1) {
					sap.m.MessageToast.show(pMessage);
				} else {
					var sIcon = "";

					switch (pMsgTyp) {
						case "W":
							sIcon = "WARNING";
							break;
						case "E":
							sIcon = "ERROR";
							break;
						case "I":
							sIcon = "INFORMATION";
							break;
						case "A":
							sIcon = "NONE";
							break;
						default:
					}
					MessageBox.show(pMessage, {
						icon: sIcon,
						title: sIcon,
						onClose: pHandler,
					});
				}
			},

			/**
			 * @author DARSHAN
			 * @purpose Message
			 * @param1 pMessage -- String-Message to be displayed
			 * @param2 pMsgTyp -- String-Message type
			 * @param2 pHandler -- function-callback function
			 */
			confirmUserAction: function (pMessage, pMsgTyp, pHandler) {
				var sIcon = "";
				switch (pMsgTyp) {
					case "W":
						sIcon = "WARNING";
						break;
					case "E":
						sIcon = "ERROR";
						break;
					case "I":
						sIcon = "INFORMATION";
						break;
					case "A":
						sIcon = "NONE";
						break;
					default:
				}
				MessageBox.confirm(pMessage, {
					icon: sIcon,
					title: "Confirm",
					actions: [MessageBox.Action.YES, MessageBox.Action.NO],
					onClose: pHandler,
				});
			},
		};
	}
);
