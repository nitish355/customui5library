import Filter from "sap/ui/model/Filter";
import MessageBox from "sap/m/MessageBox";
import Fragment from "sap/ui/core/Fragment";
import ResourceModel from "sap/ui/model/resource/ResourceModel";
import FilterProperty from "com/melodylib/core/classes/FilterProperty";

/**
 * @name com.melodylib.core.util.MasterUtility
 */
const Helper = {
	/**
	 * @author DARSHAN
	 * @purpose Function to initiliaze dialog fragments dynamically
	 * @param oControlSource - Object-Control Source
	 * @param bPopover - Boolean
	 * @param oFragmentData - Object-contains below params
	 * @param pFragmentPath -- String-Fragment Path
	 * @param pFragmentName -- String-Fragment Name
	 * @param pFragmentId -- String-Fragment Id
	 * @param pFragmentControl -- Object-Fragment Controller Object
	 * @param pFragmentI18n -- String-Fragment i18n Path
	 */
	async openFragment(fragment, isPopover, source) {
		if (!this[fragment.name]) {
			const dialog = await Fragment.load({
				id: fragment.id,
				name: fragment.path,
				controller: fragment.controller,
			});

			let i18nModel = new ResourceModel({
				bundleName: `${fragment.i18n}`,
			});
			dialog.setModel(i18nModel, "i18n");
			dialog.setModel(fragment.model);

			if (fragment.models.length) {
				for (let i = 0; i < fragment.models.length; i++) {
					dialog.setModel(fragment.models[i].model, fragment.models[i].name);
				}
			}

			source.addDependent(dialog);

			this[fragment.name] = dialog;
			
		}

		if (isPopover) {
			this[fragment.name].openBy(source);

		} else {
			this[fragment.name].open();
			return this[fragment.name];
		}
	},

	closeFragment(name) {
		if (this[name]) {
			this[name].close();
		}
	},

	/**
	 * @author DARSHAN
	 * @purpose Message
	 * @param1 pMessage -- String-Message to be displayed
	 * @param2 pMsgTyp -- String-Message type
	 * @param2 pHandler -- function-callback function
	 */
	showMessage(message, type = "", handler) {
		if (message.trim().length === 0) {
			return;
		}

		if (type === "") {
			sap.m.MessageToast.show(message);
		} else {
			MessageBox.show(message, {
				icon: type,
				title: type,
				onClose: handler,
			});
		}
	},

	/**
	 * @author DARSHAN
	 * @purpose Message
	 * @param1 pMessage -- String-Message to be displayed
	 * @param2 pMsgTyp -- String-Message type
	 * @param2 pHandler -- function-callback function
	 */
	confirm(message, type = "", handler) {
		MessageBox.confirm(message, {
			icon: type,
			title: "Confirm",
			actions: [MessageBox.Action.YES, MessageBox.Action.NO],
			onClose: handler,
		});
	},

	getFilters(params) {
		let filters = [];
		if (!params) {
			return null;
		}

		let options = {};

		if (params.search) {
			options.search = params.search;
		}

		if (params.tab) {
			//TODO: NEED TO CHECK THIS
			options.filters = filters.push(
				new Filter({
					path: "ActivitySetStatus",
					operator: "EQ",
					value1: params.tab === "X" ? "X" : "",
				})
			);
		}

		options.skip = params.skip || "0";

		options.top = params.top || "50";

		if (params.inlineCount) {
			options.inlinecount = "allpages";
		}

		if (params.properties) {
			const properties = params.properties;
			for (let p in properties) {
				let property = properties[p];
				if (property.selected) {
					const filter = property.getFilter();
					if (filter) {
						filters.push(filter);
					}
				}
			}

			if (filters.length) {
				const filter = new Filter({
					filters: filters,
					and: true,
				});
				options.filters = [filter];
			}
		}

		return options;
	},

	/**
	 * @author DARSHAN
	 * @function getFilterProperty
	 * @description function to create a filter properties based on the filter property data
	 * @param {Array} filterPropData
	 */
	getFilterProperties(filterPropData) {
		let filterProperties = {};
		for (let i = 0; i < filterPropData.length; i++) {
			let property = filterPropData[i];
			filterProperties[property.key] = new FilterProperty(property);
		}
		return filterProperties;
	},

	getResourceModel() {
		let model = sap.ui.getCore().getModel("i18nMelody");

		if (!model) {
			model = new ResourceModel({
				bundleName: "com.melody.lib.core.i18n.i18n",
				supportedLocales: ["en", "de"],
				fallbackLocale: "en",
			});
			sap.ui.getCore().setModel(model, "i18nMelody");
		}
		return model;
	},
};

export default Helper;
