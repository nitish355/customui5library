sap.ui.define(
	[
		"sap/ui/model/Filter",
		"sap/ui/core/Fragment",
		"sap/ui/core/mvc/Controller",
		"sap/ui/model/json/JSONModel",
		"sap/ui/model/FilterOperator",
		"com/melodylib/core/service/UserService",
		"com/melodylib/core/model/CoreLibraryModel",
	],
	function (
		Filter,
		Fragment,
		Controller,
		JSONModel,
		FilterOperator,
		UserService,
		oCoreLibraryModel
	) {
		"use strict";
		const UserMaster = {
			//Fetch the user data
			authenticate: async function (projectType) {
				let oUserData = oCoreLibraryModel.getProperty("/oUserData") || false;
				if (oUserData) {
					return oUserData;
				}
				if (!this.UserService) {
					this.UserService = new UserService();
				}
				let nonOreUserData = "";
				this.User = await this._getUserDetail();
				if (!projectType) {
					projectType = "ACTVT";
				}
				nonOreUserData = await this._getNonOreUserAppBasedCheck(projectType);
				if (this.User) {
					this.User.oNonOreData = nonOreUserData;
				}

				if (this?.User && this?.User?.UserName) {
					this.User.initials = this.User.UserName.match(/\b\w/g).join("");
				}
				return this.User;
			},

			_getUserDetail: async function () {
				let oUser = null;
				const oData = await this.UserService.getUserDetail();
				if (
					oData.data &&
					oData.data.results &&
					oData.data.results.length > 0 &&
					oData.data.results[0].UserId !== ""
				) {
					oUser = oData.data.results[0];
					const sUserId = this._getExceptionUserIds().find(
						(id) => id === oUser.UserId
					);
					if (!sUserId) {
						this._injectWarp(oUser);
					}
				}
				//}

				return oUser;
			},

			_getNonOreUserAppBasedCheck: async function (projectType) {
				let oAuthData = null;

				const oData = await this.UserService.getAuthCheckForNonOreUser(
					projectType
				);
				if (oData) {
					oAuthData = oData;
				}

				return oAuthData;
			},

			_getExceptionUserIds: function () {
				return this.UserService.getExceptionUserIds();
			},

			_injectWarp: function (user) {
				//delete JSON_PIWIK;
				var sPubToken = "";
				var sSubSiteId = "";

				var sAppName = "";
				var sHash = window.location.hash.toLowerCase();
				var that = this;
				window.swaCustomFields = {
					custom1: "",
					custom2: "",
					custom3: "",
					custom4: "",
					custom5: "",
				};

				//check whether navigation is from SMT apps to assign subsiteId of SMT
				if (
					sHash.indexOf("#smtmassedit-app") !== -1 ||
					sHash.indexOf("#smtform-app") !== -1 ||
					sHash.indexOf("#smt-app") !== -1 ||
					sHash.indexOf("#smtadmin-app") !== -1
				) {
					sAppName = "SMT";
				}
				if (sHash.indexOf("#sl-app") !== -1) {
					sAppName = "SuccessLine";
				}

				if (window.location.host.indexOf("br339jmc4c") !== -1) {
					sPubToken = "89cccf7b-6cfe-9243-8d9f-75e604e8c575";
					//sSubSiteId = "MelodyDev";
					// sSubSiteId = bFromSMT ? "SMTDev" : "MelodyDev";
					if (sAppName === "SMT") {
						sSubSiteId = "SMTDev";
					} else if (sAppName === "SuccessLine") {
						sSubSiteId = "SuccessLineDev";
					} else {
						sSubSiteId = "MelodyDev";
					}
				} else if (
					window.location.host.indexOf("sapitcloudt") !== -1 ||
					window.location.host.indexOf("fiorilaunchpad-qa.sap.com") !== -1
				) {
					sPubToken = "4cd44f02-28e4-d347-a013-2fd77b7b5426";
					//sSubSiteId = "MelodyTest";
					// sSubSiteId = bFromSMT ? "SMTTest" : "MelodyTest";
					if (sAppName === "SMT") {
						sSubSiteId = "SMTTest";
					} else if (sAppName === "SuccessLine") {
						sSubSiteId = "SuccessLineTest";
					} else {
						sSubSiteId = "MelodyTest";
					}
				} else if (
					window.location.host.indexOf("fiorilaunchpad.sap.com") !== -1
				) {
					sPubToken = "6051b26a-7f22-384a-86e0-f7bf43fea890";
					//sSubSiteId = "Melody";
					// sSubSiteId = bFromSMT ? "SMT" : "Melody";
					if (sAppName === "SMT") {
						sSubSiteId = "SMT";
					} else if (sAppName === "SuccessLine") {
						sSubSiteId = "SuccessLineProd";
					} else {
						sSubSiteId = "Melody";
					}
				}
				window.swa = {
					pubToken: sPubToken,
					baseUrl:
						"https://webanalytics.cfapps.eu10.hana.ondemand.com/tracker/",
					/*Please provide function name which will return owner info or string value of owner info*/
					owner: "",
					subSiteId: sSubSiteId,
					custom1: {
						ref: function () {
							return window.swaCustomFields.custom1;
						},
					},
					custom2: {
						ref: function () {
							return window.swaCustomFields.custom2;
						},
					},
					custom3: {
						ref: function () {
							return window.swaCustomFields.custom3;
						},
					},
					custom4: {
						ref: function () {
							return window.swaCustomFields.custom4;
						},
					},
					custom5: {
						ref: function () {
							return window.swaCustomFields.custom5;
						},
					},
				};
				window.swaCustomFields.custom1 = user.RegionName;
				window.swaCustomFields.custom2 = user.SubRegionName;
				window.swaCustomFields.custom3 = user.MuName;
				window.swaCustomFields.custom4 = user.Headcount;
				window.swaCustomFields.custom5 = user.OreFlag;

				(function () {
					var d = document,
						g = d.createElement("script"),
						s = d.getElementsByTagName("script")[0];
					g.type = "text/javascript";
					g.defer = true;
					g.async = true;
					g.src = window.swa.baseUrl + "js/privacy.js";
					s.parentNode.insertBefore(g, s);
					g.onload = function (script) {
						// window.swa.enable();
						setTimeout(function () {
							window.swa.enable();
						}, 2000);
					};
				})();
			},
		};

		return UserMaster;
	}
);
