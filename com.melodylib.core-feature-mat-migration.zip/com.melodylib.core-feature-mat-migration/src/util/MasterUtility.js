import * as UI5Object from "sap/ui/base/Object";
import CoreLibraryModel from "com/melodylib/core/model/CoreLibraryModel";
import MasterService from "com/melodylib/core/service/MasterService";
import User from "com/melodylib/core/classes/User"

/**
 * @name com.melodylib.core.util.MasterUtility
 */
export default class MasterUtility extends UI5Object {
    constructor () {
        this.MasterService = new MasterService.getInstance();
    }
    static getInstance() {
        if (!this.instance) {
            this.instance = new MasterUtility();
        }
        return this.instance;
    }

    //function to fetch risk button
    async getActDetRiskButtons () {
        let aRiskData =
            (await oIndexedDB.fnGetAllDatafromDB({
                dbName: "master-data",
                storeName: "master-data-table",
                keyName: "actriskbuttons",
            })) || [];

        if (!aRiskData.length) {
            let { data } = await oMasterDataService.getActDetRiskButtons();
            aRiskData = data?.results ?? [];

            oIndexedDB.fnInsertDataToDB({
                dbName: "master-data",
                storeName: "master-data-table",
                keyName: "actriskbuttons",
                aObjectsToInsert: aRiskData,
            });
        }

        return aRiskData;
    }

    //function to fetch Activity Status
    async getActivityStatus () {
        let aActStatusResults =
            (await oIndexedDB.fnGetAllDatafromDB({
                dbName: "master-data",
                storeName: "master-data-table",
                keyName: "activitystatus",
            })) || [];

        if (!aActStatusResults.length) {
            let { data } = await oMasterDataService.getActivityStatusMasterData();
            aActStatusResults = data?.results ?? [];

            oIndexedDB.fnInsertDataToDB({
                dbName: "master-data",
                storeName: "master-data-table",
                keyName: "activitystatus",
                aObjectsToInsert: aActStatusResults,
            });
        }

        return aActStatusResults;
    }

    //function to fetch ActDetAudience
    async getActDetAudience () {
        let aResults =
            (await oIndexedDB.fnGetAllDatafromDB({
                dbName: "master-data",
                storeName: "master-data-table",
                keyName: "actdetaudience",
            })) || [];

        if (!aResults.length) {
            let { data } = await oMasterDataService.getActDetAudience();
            aResults = data?.results ?? [];

            oIndexedDB.fnInsertDataToDB({
                dbName: "master-data",
                storeName: "master-data-table",
                keyName: "actdetaudience",
                aObjectsToInsert: aResults,
            });
        }

        return aResults;
    }

    //function to fetch Activity Status
    async getGTMAreMasterData () {
        let aResults =
            (await oIndexedDB.fnGetAllDatafromDB({
                dbName: "master-data",
                storeName: "master-data-table",
                keyName: "gtmaremasterdata",
            })) || [];

        if (!aResults.length) {
            let { data } = await oMasterDataService.getGTMAreMasterData();
            aResults = data?.results ?? [];

            oIndexedDB.fnInsertDataToDB({
                dbName: "master-data",
                storeName: "master-data-table",
                keyName: "gtmaremasterdata",
                aObjectsToInsert: aResults,
            });
        }

        return aResults;
    }
}