sap.ui.define(
	[
		"sap/base/Log",
		"sap/m/MessageBox",
		"sap/ui/model/Filter",
		"sap/ui/core/Fragment",
		"sap/ui/model/FilterOperator",
		"sap/ui/model/json/JSONModel",
		"com/melodylib/core/db/IndexedDB",
		"sap/ui/model/resource/ResourceModel",
		"com/melodylib/core/service/MasterDataService",
	],
	function (
		BaseLog,
		MessageBox,
		Filter,
		Fragment,
		FilterOperator,
		JSONModel,
		oIndexedDB,
		ResourceModel,
		oMasterDataService
	) {
		"use strict";
		return {
			//function to fetch risk button
			getActDetRiskButtons: async function () {
				let aRiskData =
					(await oIndexedDB.fnGetAllDatafromDB({
						dbName: "master-data",
						storeName: "master-data-table",
						keyName: "actriskbuttons",
					})) || [];

				if (!aRiskData.length) {
					let { data } = await oMasterDataService.getInstance().getActDetRiskButtons();
					aRiskData = data?.results ?? [];

					oIndexedDB.fnInsertDataToDB({
						dbName: "master-data",
						storeName: "master-data-table",
						keyName: "actriskbuttons",
						aObjectsToInsert: aRiskData,
					});
				}

				return aRiskData;
			},

			//function to fetch Activity Status
			getActivityStatus: async function () {
				let aActStatusResults =
					(await oIndexedDB.fnGetAllDatafromDB({
						dbName: "master-data",
						storeName: "master-data-table",
						keyName: "activitystatus",
					})) || [];

				if (!aActStatusResults.length) {
					let { data } = await oMasterDataService.getInstance().getActivityStatusMasterData();
					aActStatusResults = data?.results ?? [];

					oIndexedDB.fnInsertDataToDB({
						dbName: "master-data",
						storeName: "master-data-table",
						keyName: "activitystatus",
						aObjectsToInsert: aActStatusResults,
					});
				}

				return aActStatusResults;
			},

			//function to fetch ActDetAudience
			getActDetAudience: async function () {
				let aResults =
					(await oIndexedDB.fnGetAllDatafromDB({
						dbName: "master-data",
						storeName: "master-data-table",
						keyName: "actdetaudience",
					})) || [];

				if (!aResults.length) {
					let { data } = await oMasterDataService.getInstance().getActDetAudience();
					aResults = data?.results ?? [];

					oIndexedDB.fnInsertDataToDB({
						dbName: "master-data",
						storeName: "master-data-table",
						keyName: "actdetaudience",
						aObjectsToInsert: aResults,
					});
				}

				return aResults;
			},

			//function to fetch Activity Status
			getGTMAreMasterData: async function () {
				let aResults =
					(await oIndexedDB.fnGetAllDatafromDB({
						dbName: "master-data",
						storeName: "master-data-table",
						keyName: "gtmaremasterdata",
					})) || [];

				if (!aResults.length) {
					let { data } = await oMasterDataService.getInstance().getGTMAreMasterData();
					aResults = data?.results ?? [];

					oIndexedDB.fnInsertDataToDB({
						dbName: "master-data",
						storeName: "master-data-table",
						keyName: "gtmaremasterdata",
						aObjectsToInsert: aResults,
					});
				}

				return aResults;
			},
		};
	}
);
