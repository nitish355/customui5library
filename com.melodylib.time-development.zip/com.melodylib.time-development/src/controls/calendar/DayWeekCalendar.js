/*!
 * ${copyright}
 */
import jQuery from "jquery.sap.global";
import Calendar from "sap/ui/unified/Calendar";
import CalendarDateInterval from "sap/ui/unified/CalendarDateInterval";
import DateService from "com/melody/lib/service/DateService";
import DateRange from "sap/ui/unified/DateRange";
import Control from "sap/ui/core/Control";
import Controller from "sap/ui/core/mvc/Controller";
import ResourceBundle from "sap/base/i18n/ResourceBundle";
import ResourceModel from "sap/ui/model/resource/ResourceModel";
import JSONModel from "sap/ui/model/json/JSONModel";
import DayWeekCalendarRenderer from "./DayWeekCalendarRenderer";
import TimeState from "com/melodylib/time/state/TimeState";

/**
 * Constructor for a new <code>com.melodylib.integration.controls.AccountSelect</code> control.
 *
 * Some class description goes here.
 * @extends Control
 *
 * @author Siddharth Sagvekar
 * @version ${version}
 *
 * @constructor
 * @public
 * @name com.melodylib.time.controls.DayWeekCalendar
 */
export default class DayWeekCalendar extends Control {
    static metadata = {
        library: "com.melodylib.time",
        properties: {
            /**
             * width
             */
            width: {
                type: "sap.ui.core.CSSSize",
                defaultValue: "100%"
            },

            /**
             * isWeekly
             */
            isWeekly: {
                type: "boolean",
                defaultValue: false
            },

            /**
             * isWeekly
             */
            mode: {
                type: "com.melody.lib.controls.calendar.types.CalendarMode",
                defaultValue: CalendarMode.Daily
            },

            /**
             * singleSelection
             */
            singleSelection: {
                type: "boolean",
                defaultValue: true
            },

            /**
             * selectedDate
             */
            selectedDate: {
                type: "object",
                defaultValue: false
            },

            /**
             * selectedDates
             */
            selectedDates: {
                type: "object",
                defaultValue: false
            },

            copyPeriod: {
                type: "string",
                defaultValue: ""
            },

            /**
             * entries
             */
            entries: {
                type: "object",
                defaultValue: []
            },

            /**
             * startDayOfWeek
             */
            startDayOfWeek: {
                defaultValue: 1
            },

            /**
             * unit
             */
            unit: {
                type: "string",
                defaultValue: "H"
            },

            /**
             * holidays
             */
            holidays: {
                type: "object",
                defaultValue: []
            },

            /**
             * vacations
             */
            vacations: {
                type: "object",
                defaultValue: []
            }

        },
        events: {
            /**
             * Event is fired when the user clicks on the control.
             */
            press: {},

            select: {
                parameters: {
                    selectionStartDate: {
                        type: "object"
                    },
                    selectionEndDate: {
                        type: "object"
                    }
                }
            },
            navigate: {
                parameters: {
                    selectionStartDate: {
                        type: "object"
                    },
                    selectionEndDate: {
                        type: "object"
                    }
                }
            },
            changeMode: {
                parameters: {
                    mode: {
                        type: "com.melody.lib.controls.calendar.types.CalendarMode"
                    }
                }
            }


        },

        aggregations: {

            /**
             * Calendar control for desktop view
             */
            _calendar: {
                type: "sap.ui.unified.Calendar",
                multiple: false,
                visibility: "hidden"
            },

            /**
             * Event is fired when the user clicks on the control.
             */
            _legendBox: {
                type: "sap.m.FlexBox",
                multiple: false,
                visibility: "hidden"
            },

            /**
             * Event is fired when the user clicks on the control.
             */
            _copyFrom: {
                type: "sap.m.FormattedText",
                multiple: false,
                visibility: "hidden"
            },

            /**
             * Tokens for Copy functionality
             */
            _selections: {
                type: "sap.m.Tokenizer",
                multiple: false,
                visibility: "hidden"
            }

        }
    };
    static renderer = DayWeekCalendarRenderer;

    init() {

        var that = this;
        that.setBusyIndicatorDelay(0);

        //initialisation code, in this case, ensure css is imported
        var libraryPath = jQuery.sap.getModulePath("com.melody.time"); //get the server location of the ui library
        // jQuery.sap.includeStyleSheet(libraryPath + "/css/MTRCalendar.css"); //specify the css path relative from the ui folder
        jQuery.sap.includeStyleSheet("../resources/com/melodylib/time/css/MTRCalendar.css");
        var cal = Calendar;
        if (!Device.system.desktop) {
            cal = CalendarDateInterval;
        }

        //initializion calendar
        this.setAggregation("_calendar", new cal(that.getId() + "-dayWeekCalendar", {
            specialDates: [],
            showWeekNumbers: false,
            select: function (oEvent) {
                that._select();
            },
            startDateChange: function () {
               
                var oCalendar = that.getAggregation("_calendar");
                var startDate = oCalendar.getStartDate();

                if (that.getSingleSelection()) {
                    var aEntries = that.getEntries();
                    that.setEntries(aEntries);
                    var dateSelector = "sapUiCalMonthView";
                    if (!Device.system.desktop) {
                        dateSelector = "sapUiCalRow";
                    }
                    var selectedWeekHighlighter = $("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent ." + dateSelector + " .selectedWeek");
                    var selector = selectedWeekHighlighter.attr("data-selector-id");
                    var weekStartDate = new Date($("#" + that.getId() + "-dayWeekCalendar " + selector).attr("aria-label"));
                    if (weekStartDate.getMonth() === startDate.getMonth()) {
                        selectedWeekHighlighter.show();
                        $("#" + that.getId() + "-dayWeekCalendar " + selector).addClass("weekSelected");
                        $("#" + that.getId() + "-dayWeekCalendar " + selector).nextUntil(".sapUiCalFirstWDay").addClass("weekSelected");
                    } else {
                        selectedWeekHighlighter.hide();
                        $("#" + that.getId() + "-dayWeekCalendar " + selector).removeClass("weekSelected");
                        $("#" + that.getId() + "-dayWeekCalendar " + selector).nextUntil(".sapUiCalFirstWDay").removeClass("weekSelected");
                    }

                    if (!Device.system.desktop && that.getSingleSelection()) {
                        var entries = that.getEntries();
                        that.setEntries(entries);
                    }

                    //if (that.getMode() === CalendarMode.Weekly && that.getSingleSelection() && !Device.system.desktop) {
                    var sStartDate = that.dateServicesInstance.format(startDate, "yMMdd");

                    var endDate = new Date(startDate.getTime() + (6 * 24 * 60 * 60 * 1000));
                    var endDateString = that.genericDateFormat.format(endDate);
                    if (that.getMode() === CalendarMode.Weekly && that.getSingleSelection()) {
                        dateSelector = "sapUiCalRow";
                        var elementId = $("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent ." + dateSelector +
                            "  .sapUiCalItem[data-sap-day='" + sStartDate + "']").attr("id");
                        that._setSelectedWeekHighlighter(elementId, that, sStartDate, endDateString);
                    }
                    //var weekStartDate = new Date($("#" + selector).attr("aria-label"));
                    //if (that.getMode() === CalendarMode.Daily) {
                    if (!Device.system.desktop && that.getMode() === CalendarMode.Weekly) {
                        that.fireEvent("select", {
                            selectionStartDate: startDate,
                            selectionEndDate: endDate
                        });
                    } else {
                        that.fireEvent("navigate", {
                            selectionStartDate: startDate,
                            selectionEndDate: endDate
                        });
                    }
                    if (that.getMode() === CalendarMode.Weekly && that.getSingleSelection()) {
                        that._setMode();
                    }
                }
            },
            singleSelection: that.getSingleSelection()
        }).setIntervalSelection(false));

        if (!Device.system.desktop) {
            this.getAggregation("_calendar").setShowWeekNumbers(false)
                .addStyleClass("dayWeekCalendar");
        } else {
            this.getAggregation("_calendar")
                .setIntervalSelection(false).addStyleClass("shortCalendar");
        }

        //initializion legend
        this.setAggregation("_legendBox", new sap.m.FlexBox({
            renderType: "List",
            justifyContent: "Center",
            alignItems: "Center",
            visible: that.getSingleSelection(),
            items: [
                new sap.m.Link({
                    text: "{i18n>dayWeekCalTodayLegend}",
                    press: function (evt) {
                        var oCalendar = that.getAggregation("_calendar");

                        oCalendar.removeAllSelectedDates();
                        oCalendar.focusDate(new Date());
                        oCalendar.addSelectedDate(new DateRange({
                            startDate: new Date()
                        }));
                        if (that.getMode() === CalendarMode.Weekly) {
                            //var oComponent = Application.getInstance().Component;
                            //var oDayWeekTimesheetModel = oComponent.getModel("DayWeekTimesheet");
                            //oDayWeekTimesheetModel.setProperty("/SelectedDate", that.dateServicesInstance.format(new Date(), "EEEE, MMMM dd,y"));
                            that.getAggregation("_calendar").removeAllSelectedDates();
                            that._setMode();
                            that.fireEvent("changeMode", {
                                mode: that.getMode()
                            });
                        } else {
                            setTimeout(function () {
                                that._select();
                            }, 500);
                        }
                    }
                }).addStyleClass("legend legendLink"),
                new sap.m.Text({
                    text: "{i18n>dayWeekCalSelectedWeekLegend}",
                    visible: that.getMode() !== CalendarMode.Daily
                }).addStyleClass("legend legendSelected"),
                new sap.m.Text({
                    text: "{i18n>dayWeekCalSelectedDayLegend}",
                    visible: that.getMode() === CalendarMode.Daily
                }).addStyleClass("legend legendSelectedDay"),
                new sap.m.Text({
                    text: "{i18n>dayWeekCalWeekendLegend}"
                }).addStyleClass("legend legendWeekend"),
                /*new sap.m.Text({
                    text: "{i18n>dayWeekCalHolidayLegend}"
                }).addStyleClass("legend legendHoliday")*/
            ]
        }).addStyleClass("legendBox"));

        this.setAggregation("_copyFrom", new sap.m.FormattedText({
            htmlText: "",
            visible: !that.getSingleSelection()
        }).addStyleClass("copyFrom"));

        //initializion selections
        this.setAggregation("_selections", new sap.m.Tokenizer({
            tokens: that.getSelectedDates(),
            visible: !that.getSingleSelection()
        }));

    }

}
class DayWeekCalendarController extends Controller {
    constructor(control) {
        super();
        this.control = control;
        this.TimeState = TimeState.getInstance();
        // this.masterDataState = MasterDataState.getInstance();
    }
    onInit() {
        this.setBusy(false);
    }


}
