/*!
 * ${copyright}
 */
import jQuery from "jquery.sap.global";
import Calendar from "sap/ui/unified/Calendar";
import CalendarDateInterval from "sap/ui/unified/CalendarDateInterval";
import DateService from "com/melody/lib/service/DateService";
import DateRange from "sap/ui/unified/DateRange";
import Control from "sap/ui/core/Control";
import Controller from "sap/ui/core/mvc/Controller";
import ResourceBundle from "sap/base/i18n/ResourceBundle";
import ResourceModel from "sap/ui/model/resource/ResourceModel";
import JSONModel from "sap/ui/model/json/JSONModel";
import MatrixCalendarRenderer from "./MatrixCalendarRenderer";
import TimeState from "com/melodylib/time/state/TimeState";


/**
 * Constructor for a new <code>com.melodylib.time.controls.MatrixCalendar</code> control.
 *
 * Some class description goes here.
 * @extends Control
 *
 * @author Siddharth Sagvekar
 * @version ${version}
 *
 * @constructor
 * @public
 * @name com.melodylib.time.controls.MatrixCalendar
 */
export default class MatrixCalendar extends Control {
    static metadata = {
        library: "com.melodylib.time",
        properties:{

            /**
             * width
             */
            width: {
                type: "sap.ui.core.CSSSize",
                defaultValue: "100%"
            },
            
            /**
             * isValidTimesheet
             */
            valid: {
                type: "boolean",
                defaultValue: true
            },
            
            /**
             * startDayOfWeek
             */
            startDayOfWeek: {
                defaultValue: 1
            },
            
            /**
             * holidays
             */
            holidays: {
                type: "object",
                defaultValue: []
            },
            
            /**
             * vacations
             */
            vacations: {
                type: "object",
                defaultValue: []
            }
        },
        events: {
            /**
             * Event is fired when the user clicks on the control.
             */
            press: {},
            
            /**
             * Event is fired when the user clicks on the previous button.
             */
            calendarNav: {},
            
            /**
             * Event is fired when the user clicks on the previous button.
             */
            beforeCalendarNav: {}
        },

        aggregations: {
            /**
             * Calendar control
             */
            _shortCalendar: {
                type: "sap.ui.unified.CalendarDateInterval",
                multiple: false,
                visibility: "hidden"
            },
            
            /**
             * controls to navigate to previous and next calendar weeks
             */
            _navCalendar: {
                type: "sap.m.HBox",
                multiple: false,
                visibility: "hidden"
            },
            
            /**
             * Custom Legend Box
             */
            _legends: {
                type: "sap.m.VBox",
                multiple: false,
                visibility: "hidden"
            }
        }
    };
    static renderer = MatrixCalendarRenderer;

    init() {}

}
class MatrixCalendarController extends Controller {
    constructor(control) {
        super();
        this.control = control;
        this.TimeState = TimeState.getInstance();
        // this.masterDataState = MasterDataState.getInstance();
    }
    onInit() {
        this.setBusy(false);
    }


}
