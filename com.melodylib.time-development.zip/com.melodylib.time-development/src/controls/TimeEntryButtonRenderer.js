/*!
 * ${copyright}
 */

import Lib from "sap/ui/core/Lib";
// import Actions from "com/melodylib/time/enum/Actions";

/**
 * Example renderer.
 * @namespace
 */
export default {
    apiVersion: 2, // usage of DOM Patcher

    /**
     * Renders the HTML for the given control, using the provided {@link RenderManager}.
     *
     * @param rm The reference to the <code>sap.ui.core.RenderManager</code>
     * @param control The control instance to be rendered
     */


    render: function (rm, control) {
        // let controlType = control.getType();
        // controlType = controlType.toUpperCase();
        rm.openStart("div", control);       // <div
        rm.class("timeEntryButtonContainer");   // <div class="timeEntryButtonContainer"
        rm.openEnd();  // <div class="timeEntryButtonContainer">
        rm.renderControl(control.getAggregation("_button"));
        rm.close("div"); //</div>
    },

};
