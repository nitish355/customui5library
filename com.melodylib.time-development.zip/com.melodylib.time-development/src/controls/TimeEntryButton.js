/*!
 * ${copyright}
 */
import Button from "sap/m/Button";
import Control from "sap/ui/core/Control";
import Controller from "sap/ui/core/mvc/Controller";
import ResourceBundle from "sap/base/i18n/ResourceBundle";
import ResourceModel from "sap/ui/model/resource/ResourceModel";
import JSONModel from "sap/ui/model/json/JSONModel";
import TimeEntryButtonRenderer from "./TimeEntryButtonRenderer";
import TimeState from "com/melodylib/time/state/TimeState";
import Helper from "com/melodylib/core/util/Helper";

/**
 * Constructor for a new <code>com.melodylib.integration.controls.AccountSelect</code> control.
 *
 * Some class description goes here.
 * @extends Control
 *
 * @author Siddharth Sagvekar
 * @version ${version}
 *
 * @constructor
 * @public
 * @name com.melodylib.time.controls.TimeEntryButton
 */
export default class TimeEntryButton extends Button {
	static metadata = {
		library: "com.melodylib.time",
		properties: {
			selectedActivity: {
				type: "object",
				defaultValue: null
			},

			entries: {
				type: "object",
				defaultValue: []
			},

			mtrUid: {
				type: "string",
				defaultValue: ""
			},

			statusId: {
				type: "string",
				defaultValue: ""
			},
		},
		events: {
			updateEntries: {
				parameters: {
					"updateEntries": {
						type: "boolean"
					}
				}
			}
		},

		aggregations: {
			_button: {
				type: "sap.m.Button",
				multiple: false,
				visibility: "hidden",
			}
		}
	};
	static renderer = TimeEntryButtonRenderer;

	init() {
	
//INIT CSS FILE
		//initialisation code, in this case, ensure css is imported
		let libraryPath = jQuery.sap.getModulePath("com.melodylib.time");
		jQuery.sap.includeStyleSheet(libraryPath + "/css/melodyTimeCalendar.css");


		this.controller = new TimeEntryButtonController(this);
		this.setAggregation(
			"_button",
			new sap.m.Button(this.getId() + "-button", {
				text: "Create Time Entry",
				type: "Transparent",
				icon: "sap-icon://create-entry-time",
				press: this.openTimeDialog
			})
		);
		// this.getAggregation("_button").setVisible(true);
		this.setBusyIndicatorDelay(0);
		this.setBusy(true);

		// set i18n model on view
		var i18nModel = new ResourceModel({
			bundleName: "com.melodylib.time.i18n.i18n"
		});
		sap.ui.getCore().setModel(i18nModel, "i18n");

		const oModel = new JSONModel({
			User: null,
			UserSetting: null,
			MtrTasks: [],
			SelectedDates: [],
			SelectedActivity: null,
			SelectedMtrTask: null,
			SelectedLocationId: "",
			ShowCalendar: false,
			Entries: [{
				RecordDate: "04/11/2021",
				Task: "Business Development - CF",
				Location: "Virtual",
				Activity: "Demand Generation - PreBA",
				Type: "Cost Center: 0176000711",
				WorkDuration: "8.0"
			}, {
				RecordDate: "11/11/2021",
				Task: "Business Development - CF",
				Location: "Virtual",
				Activity: "Demand Generation - PreBA",
				Type: "Cost Center: 0176000711",
				WorkDuration: "8.0"
			}, {
				RecordDate: "12/11/2021",
				Task: "Business Development - CF",
				Location: "Virtual",
				Activity: "Demand Generation - PreBA",
				Type: "Cost Center: 0176000711",
				WorkDuration: "8.0"
			}]
		});

		this.setModel(oModel);
		this.setModel(i18nModel, "i18n");

		this.setTooltip("Create Time Entry");
		this.setBusy(false);
	}

	async openTimeDialog(event){
		const control = event.getSource().getParent();
		const models = [
			
		];

		let fragment = {
			i18n: "com.melodylib.time.i18n.i18n",
			controller: control.controller,
			path: "com.melodylib.time.fragments.MTRDialog",
			name: "_TimeDialog",
			id: `${control.getId()}_TimeDialog`,
			model: control.getModel(),
			models: models,
		};

		const openFrag = Helper.openFragment.bind(control);
		openFrag(fragment, false, control);

		// const accountState = control.controller.accountState;
		// const accountStateModel = accountState.getModel();
		// const accountStateVariant = accountStateModel.getProperty("/variant");

		 const model = control.getModel();
		// const variant = model.getProperty("/variant");

		// variant.copy(accountStateVariant);
		model.refresh();
		// const query = variant.searchQuery;
		// control.controller._search(query);
	}

}
class TimeEntryButtonController extends Controller {
	constructor(control) {
		super();
		this.control = control;
		this.TimeState = TimeState.getInstance();
		// this.masterDataState = MasterDataState.getInstance();
	}
	onInit() {
		this.setBusy(false);
	}
	
	
}
