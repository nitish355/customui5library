/*!
 * ${copyright}
 */

import Lib from "sap/ui/core/Lib";
// import Actions from "com/melodylib/time/enum/Actions";

/**
 * Example renderer.
 * @namespace
 */
export default {
    apiVersion: 2, // usage of DOM Patcher

    /**
     * Renders the HTML for the given control, using the provided {@link RenderManager}.
     *
     * @param rm The reference to the <code>sap.ui.core.RenderManager</code>
     * @param control The control instance to be rendered
     */


    render: function (rm, control) {

        //first up, render a div for the DayWeekCalendar
        rm.openStart("div");

        //add this controls style class (plus any additional ones the developer has specified)
        rm.class("expectedTimeBar");

        rm.style("width: " + control.getWidth() + ";" + "height: " + control.getWidth());
        //next, render the control information, this handles your sId (you must do this for your control to be properly tracked by ui5).

        rm.openEnd();

        rm.renderControl(control.getAggregation("_statusIndicator"));


        //and obviously, close off our div
        rm.close("div");
        
    },

};
