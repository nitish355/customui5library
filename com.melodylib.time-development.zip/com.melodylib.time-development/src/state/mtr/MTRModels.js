import JSONModel from "sap/ui/model/json/JSONModel";
import ResourceModel from "sap/ui/model/resource/ResourceModel";
import BaseState from "com/melodylib/core/state/BaseState";
import MasterService from "com/melodylib/core/service/MasterService";
import Settings from "com/melodylib/time/classes/Settings";

/**
 * @name com.melodylib.core.state.MTRModels
 */
export default class MTRModels extends BaseState {
	constructor() {
		super(MasterService.getInstance());
		this.setData({});
	}

	static getInstance() {
		if (!this._instance) {
			this._instance = new MTRModels();
		}
		return this._instance;
	}
	static getMTRResourceModel() {
		let oModel = sap.ui.getCore().getModel("i18nMTR");

		if (!oModel) {
			oModel = new ResourceModel({
				bundleName: "com.melodylib.time.i18n.i18n",
				supportedLocales: ["en", "de"],
				fallbackLocale: "en"
			});
			sap.ui.getCore().setModel(oModel, "i18nMTR");
		}
		return oModel;
	}
	static getMTRSettingsModel() {
		let oSettingsModel = sap.ui.getCore().getModel("mtrSettings");

		if (!oSettingsModel) {
			const oSettings = new Settings();
			// const oSettings = new com.melodylib.time.classes.Settings();
			oSettingsModel = new JSONModel(oSettings);
			sap.ui.getCore().setModel(oSettingsModel, "mtrSettings");
		}
		return oSettingsModel;
	}

}
