import BaseState from "com/melodylib/core/state/BaseState";
import ISPService from "com/melodylib/integration/service/ISPService";
import AuthState from "com/melodylib/core/state/AuthState";
import Staffing from "com/melodylib/time/classes/Staffing";
import DateUtility from "com/melodylib/core/util/DateUtility";


/**
 * @name com.melodylib.time.state.StaffingState
 */
export default class StaffingState extends BaseState {
    constructor() {
        super(ISPService.getInstance());
    }

    static getInstance() {
        if (!this._instance) {
            this._instance = new StaffingState();
        }
        return this._instance;
    }

    async getStaffing(fromDate, toDate) {
        const authState = AuthState.getInstance();
		const user = authState.getData();
        let staffings = [];
        if (user.isISPUser) {
            const currentDate = new Date(); // current date
            if (!fromDate) {
                fromDate = new Date(currentDate.getFullYear() - 1, 0, 1);
            }

            if (!toDate) {
                toDate = new Date(currentDate.getFullYear() + 2, 0, 0);
            }

            const formattedFromDate = DateUtility.format(fromDate, "yMMdd");
            const formattedToDate = DateUtility.format(toDate, "yMMdd");
            const { data } = await this._service.getISPData(
                user.personalNumber,
                formattedFromDate,
                formattedToDate,
                "Staffing"
            );
            const results = data?.results;
            staffings = Array.from(
                results,
                (result) =>
                    new Staffing(result)
            );
        }	
        this.setData(staffings);
		return this.getData();
	}
}
