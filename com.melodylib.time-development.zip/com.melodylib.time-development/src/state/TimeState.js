import BaseState from "com/melodylib/core/state/BaseState";
import TimeService from "com/melodylib/time/service/TimeService";
import Settings from "com/melodylib/time/classes/Settings";
import AuthState from "com/melodylib/core/state/AuthState";
import TimeMasterState from "com/melodylib/time/state/TimeMasterState";
import DateService from "com/melodylib/core/service/DateService";
import Entry from "com/melodylib/time/classes/Entry";
import ResourceModel from "sap/ui/model/resource/ResourceModel";
import OppService from "com/melodylib/integration/service/OppService";
import Staffing from "com/melodylib/time/classes/Staffing";
import OpportunityIOSettings from "com/melodylib/time/classes/OpportunityIOSettings";
import Message from "com/melodylib/time/classes/Message";
import MessageToast from "sap/m/MessageToast";
import ISPService from "com/melodylib/integration/service/ISPService";
import Timesheet from "com/melodylib/time/classes/Timesheet";
import StaffingState from "com/melodylib/time/state/StaffingState";
import TargetHourState from "com/melodylib/time/state/TargetHourState";
import Account from "com/melodylib/integration/classes/Account";
import ManualIO from "com/melodylib/time/classes/ManualIO";
import OpportunityState from "com/melodylib/integration/state/OpportunityState";
import OpportunityIOSetting from "com/melodylib/time/classes/OpportunityIOSetting";
import Opportunity from "com/melodylib/integration/classes/Opportunity";
import DateUtility from "com/melodylib/core/util/DateUtility";
import InternalOrder from "com/melodylib/time/classes/InternalOrder";
import Status from "com/melodylib/time/enum/Status";
import Indicator from "com/melodylib/time/enum/Indicator";
import Source from "com/melodylib/time/enum/Source";
import Fragment from "sap/ui/core/Fragment";
import Filter from "sap/ui/model/Filter";
/**
 * @name com.melodylib.time.state.TimeState
 */
export default class TimeState extends BaseState {
	pendingOpportunities = [];
	constructor() {
		super(TimeService.getInstance());
		this.ispService = ISPService.getInstance();
		this.dateService = DateService.getInstance();
		this._oppService = OppService.getInstance();
		this._data = {
			fromDate: "",
			toDate: "",
			opportunityIOSettings: [],
			manualIOs: [],
			accounts: [],
			entry: new Entry(),
			entries: [],
			selectedDate: "",
		};
	}

	static getInstance() {
		if (!this._instance) {
			this._instance = new TimeState();
		}
		return this._instance;
	}

	getUser() {
		const authState = AuthState.getInstance();
		return authState.getData();
	}

	async init(appId) {
		const authState = AuthState.getInstance();
		const user = authState.getData();

		if (user.activityRecording) {
			const timeMasterState = TimeMasterState.getInstance();
			const staffingState = StaffingState.getInstance();
			const targetHourState = TargetHourState.getInstance();
			const promises = [
				authState.getISPUserInfo(),
				timeMasterState.init(),
				this.getTimeConfig(appId),
			];

			Promise.all(promises).then((data) => {
				if (user.isISPUser) {
					staffingState.getStaffing();
					targetHourState.getTargetHours();
				}
			});
		}
	}

	async getTimeConfig() {
		const user = this.getUser();
		const config = {
			profileId: "1",
			unit: "H",
		};
		const oreData = user.oreData;
		const arrData = [];
		for (var i in oreData) {
			if (
				i &&
				i !== "__metadata" &&
				i !== "" &&
				oreData[i] &&
				oreData[i] !== "" &&
				typeof oreData[i] === "string"
			) {
				var obj = {
					UserId: oreData.UserId,
					ConstantType: i,
					ConstantValue: oreData[i],
				};
				arrData.push(obj);
			}
		}
		const postData = {
			UserId: oreData.UserId,
			ApplicationId: "MTR",
			N_UserIDToConstant: arrData,
		};
		try {
			const { data } = await this._service.getUserMtrConfig(postData);
			if (data) {
				config.guid = data.UserGuid;
				config.status = data.Status;
				config.opportunityURL = data.OpportunityURL;
				config.isUnitEdit = data.IsUnitEdit;
				config.restrictPriorYear = data.RestrictPriorYear;
				config.cutOffDate = data.CutOffDate;
				config.graceDate = data.GraceDate;
			
				if (data.ProfileId) {
					config.profileId = data.ProfileId;
				}
				if (data.TimeSheetUnit) {
					config.unit = data.TimeSheetUnit;
				}
			}
		} catch (error) {
			console.log(error);
		}

		user.setTimeConfig(config);

		const promises = [];
		if (config.profileId) {
			const timeMasterState = TimeMasterState.getInstance();
			promises.push(
				timeMasterState.fetchMasterByProfileId(user.time.profileId)
			);
		}

		if (config.guid) {
			promises.push(this.getTimeConfigByGuid());
		}

		Promise.all(promises).then(() => {
			this.initTimeEntryParameters();
		});
	}

	async getTimeConfigByGuid() {
		const user = this.getUser();

		const config = {
			registered: false,
		};
		let accounts = [],
			manualIOs = [];
		let dateFormatId;
		let opportunities = [];
		if (user.time.guid) {
			const data = await this._service.getUserSettings(user.time.guid);
			if (data) {
				config.updatedTime = data.UpdatedTime || "";
				config.isArchive = data.IsArchive ? true : false;
				config.essInMu = data.EssInMu === "" ? false : true;
				config.timesheet = data.Timesheet ? data.Timesheet : "1";
				config.custId = data.CustId || "";
				config.createdOn = data.CreatedOn || "";
				config.createdTime = data.CreatedTime || "";
				config.updatedOn = data.UpdatedOn || "";
				config.registered = true;
				config.prdProfMapId = data.PrdProfMapId;
				dateFormatId = data.DateFormat || "";

				if (data.to_ACCOUNT.results) {
					accounts = Array.from(
						data.to_ACCOUNT.results,
						(account) =>
							new Account({
								id: account.AccountId,
								name: account.AccountDesc,
							})
					);
				}

				if (data.to_MANUAL.results) {
					manualIOs = Array.from(
						data.to_MANUAL.results,
						(manualIO) =>
							new ManualIO({
								internalOrder: new InternalOrder({
									id: manualIO.ManualIOID,
									description: manualIO.ManualIODesc,
								}),
								dataFrom: manualIO.DataFrom,
								indicator: manualIO.Indicator,
								createdOn: manualIO.CreatedOn,
								updatedOn: manualIO.UpdatedOn,
								isArchive: manualIO.IsArchive,
								isVisible: manualIO.IsVisible,
							})
					);
				}

				opportunities = data.to_OPPORTUNITYIO.results;
			}
		}

		this._data.accounts = accounts;
		this._data.manualIOs = manualIOs;

		const timeMasterState = TimeMasterState.getInstance();
		const dateFormats = timeMasterState.getData().dateFormats;

		if (dateFormatId) {
			const dateFormat = dateFormats.find(function (d) {
				return d.ID === dateFormatId;
			});
			config.dateFormat = dateFormat || dateFormats[0];
		} else {
			config.dateFormat = dateFormats[0];
		}
		user.setTimeConfigByGuid(config);

		if (opportunities.length) {
			this.setOpportunityIOSettings(opportunities);
		}
	}

	async setOpportunityIOSettings(config) {
		try {
			this.pendingOpportunities = [];
			const oppIds = [];
			const opportunityIOSettings = [];
			const opportunityState = OpportunityState.getInstance();
			const opportunities = opportunityState.getData().opportunities;

			for (let i = 0; i < config.length; i++) {
				let opportunity = opportunities.find(function (item) {
					return item.id === config[i].OpportunityID;
				});

				const opportunityIOSetting = new OpportunityIOSetting({
					isVisible: config[i].IsVisible === "X" ? true : false,
					isDefault: config[i].IsDefault === "X" ? true : false,
					createdOn: config[i].CreatedOn,
					createdTime: config[i].CreatedTime,
					updatedOn: config[i].UpdatedOn,
					updatedTime: config[i].UpdatedTime,
					isArchive: config[i].IsArchive === "X" ? true : false,
					indicator: "",
				});
				if (opportunity) {
					if (
						opportunity.isDetailAvailable &&
						config[i].AssociatedIO &&
						opportunity.internalOrders.length
					) {
						const internalOrder = opportunity.internalOrders.find(
							(item) => item.id === config[i].AssociatedIO
						);
						if (internalOrder) {
							opportunity.associatedIO = internalOrder;
						} else {
							opportunity.associatedIO = opportunity.internalOrders[0];
						}
					} else if (!opportunity.isDetailAvailable) {
						opportunity.associatedIO = config[i].AssociatedIO
							? new InternalOrder({
								id: config[i].AssociatedIO,
							})
							: "";
						oppIds.push(opportunity.id);
					}
					opportunityIOSetting.setOpportunity(opportunity);
				} else {
					opportunity = new Opportunity({
						OPPT_ID: config[i].OpportunityID,
					});
					opportunity.associatedIO = config[i].AssociatedIO
						? new InternalOrder({
							id: config[i].AssociatedIO,
						})
						: "";
					opportunityIOSetting.opportunity = opportunity;
					opportunities.push(opportunity);
					oppIds.push(config[i].OpportunityID);
				}
				opportunityIOSettings.push(opportunityIOSetting);
			}

			for (let i = 0; i < opportunities.length; i++) {
				const opportunityIOSetting = opportunityIOSettings.find(
					(setting) => setting.opportunity.id === opportunities[i].id
				);
				if (!opportunityIOSetting) {
					const opportunityIOSetting = new OpportunityIOSetting({
						isVisible: true,
						isDefault: false,
						isArchive: false,
						indicator: "C",
					});
					opportunityIOSetting.setOpportunity(opportunities[i]);
					if (!opportunities[i].isDetailAvailable) {
						oppIds.push(opportunities[i].id);
					}
				}
			}

			if (oppIds.length) {
				opportunityState
					.getOpportunityDetail(oppIds)
					.then(() => this.setStaffingToManualIO());
			}

			this._data.opportunityIOSettings = opportunityIOSettings;

			this.updateModel();
		} catch (error) {
			console.log("ERROR in setOpportunityIOSettings : ", error);
		}
	}

	/* async updateOpportunityIOSettings (oppIds) {
		if(oppIds.length) {
			const opportunityState = OpportunityState.getInstance();
			await opportunityState.getOpportunityDetail(oppIds);
			const opportunities = opportunityState.getData().opportunities;

			for(let i = 0; i < oppIds.length; i++) {
				const opportunity = opportunities.find(o => o.id === oppIds[i]);
				const opportunityIOSetting = this._data.opportunityIOSettings.find(o => o.opportunity.id === oppIds[i]);

				if(opportunity && opportunityIOSetting) {
					opportunityIOSetting.opportunity = opportunity;
				}
			}
			this.setStaffingToManualIO();
			this.updateModel();
		}
	} */

	/* _afterGetAssociations () {
		const oSettingsModel = MTRModels.getMTRSettingsModel();

		if (!oSettingsModel.getProperty("/IsFirstTimeUser")) {
			if (!oSettingsModel.getProperty("/IsISPDown")) {
				await this.setStaffingToManualIO();
			}
			const oLSSettingsRequest = oSettingsModel.getData().getLSRequest();
			await this.onSaveSettings(oLSSettingsRequest);
		}
	} */

	setStaffingToManualIO() {
		try {
			const staffingState = StaffingState.getInstance();
			const staffings = staffingState.getData() || [];
			const staffingManualIOs = staffings.filter(function (item) {
				return !item.isOpportunityIO;
			});

			for (let i = 0; i < staffingManualIOs.length; i++) {
				let manualIO = this._data.manualIOs.find(function (item) {
					return item.internalOrder === staffingManualIOs[i].internalOrder;
				});
				if (!manualIO) {
					manualIO = new ManualIO({
						internalOrder: new InternalOrder({
							id: staffingManualIOs[i].internalOrder,
							description: staffingManualIOs[i].description,
						}),
						isArchive: "",
						isVisible: true,
						indicator: "U",
					});
				}
				manualIO.objnr = staffingManualIOs[i].objnr;
				manualIO.obart = staffingManualIOs[i].obart;
				manualIO.raufnr = staffingManualIOs[i].raufnr;
				manualIO.addStaffing(staffingManualIOs[i]);
			}
		} catch (error) {
			console.log("ERROR IN setStaffingToManualIO : ", error);
		}
	}

	async initTimeEntryParameters() {
		const currentData = new Date();
		const fromDate = new Date(
			currentData.getFullYear(),
			currentData.getMonth() - 1,
			1
		); // first date of last year
		this._data.fromDate = fromDate;
		const toDate = new Date(
			currentData.getFullYear(),
			currentData.getMonth() + 2,
			0
		); // last date of next to next year
		this._data.toDate = toDate;
		this.getEntries(fromDate, toDate, null, false);
	}

	async getEntries(fromDate, toDate, startDate) {
		try {
			const promises1 = [
				this.getEntriesFromLS(),
				this.getEntriesFromISP(fromDate, toDate, startDate),
			];

			Promise.all(promises1).then(() => {
				const formattedSelectedDate = DateUtility.format(
					new Date(this._data.selectedDate),
					"yMMdd"
				);
				this.filterEntries(formattedSelectedDate);
				const inQueueEntries = this._data.entries.filter(function (item) {
					return item.status.id === Status.InQueue;
				});

				if (inQueueEntries.length > 0) {
					this.submitEntries(inQueueEntries);
				}
				this.updateModel();
			});
		} catch (e) {
			console.log(e);
		}
		this.updateModel();
		try {
			/*await this.getEntriesFromISP({
				FromDate: fromDate,
				ToDate: toDate,
				StartDate: startDate
			});*/
		} catch (e) {
			oSettingsModel.setProperty("/Loading", false);
			throw e;
		}
	}

	async getEntriesFromLS() {
		const user = this.getUser();
		const oppIds = [];
		const opportunityState = OpportunityState.getInstance();
		const { data } = await this._service.getEntries(user.time.guid);
		const savedEntries = data?.results || [];
		for (let i = 0; i < savedEntries.length; i++) {
			let ref;
			let entry = this._data.entries.find(function (item) {
				return item.guid.toUpperCase() === savedEntries[i].MtrUid.toUpperCase();
			});
			if (!entry) {
				const timeMasterState = TimeMasterState.getInstance();
				const tasks = timeMasterState.getTasks();
				const task = tasks.find(function (task) {
					return (
						task.taskId.toString() === savedEntries[i].ActivityId.toString()
					);
				});
				if (task) {
					const location = task.locations.find(
						(item) => item.id === savedEntries[i].LocationId
					);
					const costType = task.costTypes.find(
						(item) => item.id === savedEntries[i].CostTypeId
					);

					switch (savedEntries[i].CostTypeId) {
						case "1":
							const opportunityIOSettings =
								this.getData().opportunityIOSettings;
							ref = opportunityIOSettings.find(
								(item) => item.opportunity.id === savedEntries[i].CostTypeValue
							);
							if (!ref) {
								ref = new OpportunityIOSetting({
									isVisible: true,
									isDefault: false,
									isArchive: false,
									indicator: "C",
								});
								opportunityIOSettings.push(ref);
							}

							if (!ref.opportunity) {
								const opportunity = new Opportunity({
									id: savedEntries[i].CostTypeValue,
								});
								ref.setOpportunity(opportunity);
							}

							if (!ref.opportunity.isDetailAvailable) {
								oppIds.push(ref.opportunity.id);
							}

							break;
						case "1":
							const manualIOs = this.getData().manualIOs;
							ref = manualIOs.find(
								(item) =>
									item.internalOrder.id === savedEntries[i].CostTypeValue
							);
							break;
						default:
							break;
					}

					const entryStatuses = timeMasterState.getData().entryStatuses;
					const status = entryStatuses.find(
						(item) => item.key === savedEntries[i].StatusId
					);

					entry = new Entry({
						counter: savedEntries[i].Counter,
						taskCounter: savedEntries[i].TaskCounter,
						guid: savedEntries[i].MtrUid,
						recordDate: savedEntries[i].RecordDate,
						customerFacing: savedEntries[i].CustomerFacing,
						unit: savedEntries[i].Unit,
						note: savedEntries[i].Note,
						activity: {
							id: savedEntries[i].ActvtId,
							type: {
								description: savedEntries[i].ActTypeDesc,
							},
						},
						task: task,
						location: location,
						costType: costType,
						ref: ref,
						costTypeValue: savedEntries[i].CostTypeValue,
						status: status,
						duration: savedEntries[i].WorkDuration,
						dataFrom: "L",
					});
					this._data.entries.push(entry);
				}
			}
		}

		if (oppIds.length) {
			opportunityState
				.getOpportunityDetail(oppIds)
				.then(() => this.setStaffingToManualIO());
		}
	}

	async getEntriesFromISP(fromDate, toDate, startDate) {
		try {
			const oppIds = [];
			const user = this.getUser();
			const entriesToDelete = [];
			const reportEntries = [];

			if (!fromDate) {
				throw new Error("From date is missing");
			}

			if (!toDate) {
				throw new Error("To date is missing");
			}

			if (!startDate) {
				startDate = new Date();
			}

			const from = DateUtility.format(fromDate, "yMMdd");
			const to = DateUtility.format(toDate, "yMMdd");
			const timeMasterState = TimeMasterState.getInstance();
			const tasks = timeMasterState.getData().tasks;
			const { data } = await this._service.getEntriesFromISP(
				user.personalNumber,
				from,
				to
			);
			const results = data?.results || [];
			for (let i = 0; i < results.length; i++) {
				let ref;
				const duration = parseFloat(results[i].Catsquantity);
				if (duration && !isNaN(duration)) {
					const task = tasks.find(function (item) {
						return (
							item.ispTask.toUpperCase() ===
							results[i].Tasktype.toUpperCase() &&
							item.ispSubTask.toUpperCase() ===
							results[i].Zzsubtype.toUpperCase()
						);
					});
					if (task) {
						const networkText = results[i].Zz_npktxt;
						if (networkText) {
							// logic to get guid
							const guid = networkText.substring(1, networkText.indexOf("~"));

							// logic to get cost type
							let costTypeId = "2",
								costTypeValue = "";
							const aZzcontpers = results[i].Zzcontpers.split("/");
							const accountId = aZzcontpers[0] || "";
							const opportunityId = aZzcontpers[1] || "";
							if (opportunityId) {
								costTypeId = "1";
								costTypeValue = opportunityId;
								const opportunityIOSettings =
									this.getData().opportunityIOSettings;
								ref = opportunityIOSettings.find(
									(item) => item.opportunity.id === costTypeValue
								);
								if (!ref) {
									ref = new OpportunityIOSetting({
										isVisible: true,
										isDefault: false,
										isArchive: false,
										indicator: "C",
									});
									opportunityIOSettings.push(ref);
								}

								if (!ref.opportunity) {
									const opportunity = new Opportunity({
										id: costTypeValue,
									});
									ref.setOpportunity(opportunity);
								}

								if (!ref.opportunity.isDetailAvailable) {
									oppIds.push(ref.opportunity.id);
								}
							} else if (accountId) {
								costTypeId = "4";
								costTypeValue = accountId;
							} else if (
								results[i].Raccobj &&
								results[i].Raccobj.toUpperCase() === "ORDER"
							) {
								costTypeId = "3";
								costTypeValue = results[i].Raccobj_genrec || "";
								const manualIOs = this.getData().manualIOs;
								ref = manualIOs.find(
									(item) => item.internalOrder.id === costTypeValue
								);
							} else {
								costTypeId = "2";
								costTypeValue = user.costCenter;
							}

							const costType = task.costTypes.find(
								(item) => item.id === costTypeId
							);

							// logic to get location
							const locationId = aZzcontpers[2] || "";
							const location = task.locations.find(
								(item) => item.id === locationId
							);

							const activityId = aZzcontpers[3] || "";
							const customerFacing =
								aZzcontpers[4] && aZzcontpers[4] === "false" ? false : true;

							const timeMasterState = TimeMasterState.getInstance();
							const entryStatuses = timeMasterState.getData().entryStatuses;
							const statusId = results[i].Status === "30" ? "4" : "3";
							const status = entryStatuses.find(
								(item) => item.key === statusId
							);

							let index = this._data.entries.findIndex(function (item) {
								return item.guid.toUpperCase() === guid.toUpperCase();
							});

							const entryData = {
								counter: results[i].Counter,
								taskCounter: results[i].Taskcounter,
								recordDate: results[i].Workdate,
								customerFacing: customerFacing,
								unit: results[i].Unit === "H" ? "H" : "D",
								note: results[i].Ltxa1,
								activity: {
									id: activityId,
									type: {
										description: "",
									},
								},
								task: task,
								location: location,
								costType: costType,
								ref: ref,
								costTypeValue: costTypeValue,
								status: status,
								duration: results[i].Catsquantity,
								dataFrom: "I",
							};

							let entry;
							if (index !== -1) {
								if (
									this._data.entries[index].status.id !== "4" &&
									this._data.entries[index].dataFrom !== "I"
								) {
									entriesToDelete.push(this._data.entries[index]);
									this._data.entries.splice(index, 1);
									entry = new Entry(entryData);
									this._data.entries.push(entry);
								} else {
									entry.setData(entryData);
								}
							} else {
								entry = new Entry(entryData);
								this._data.entries.push(entry);
							}
						}
					}
				}
			}
			if (entriesToDelete.length > 0) {
				await this.deleteSubmittedEntriesFromLS(entriesToDelete);
			}
		} catch (error) {
			console.log("ERROR IN getEntriesFromISP : ", error);
		}
	}

	async deleteSubmittedEntriesFromLS(entries) {
		const lsEntriesToDelete = [];
		for (let i = 0; i < entries.length; i++) {
			const lsEntry = entries[i].getLSRequest(1, "D");
			lsEntriesToDelete.push(oLSEntry);
		}
		if (ldEntriesToDelete.length > 0) {
			await this._sendToLS(ldEntriesToDelete);
		}
	}

	filterEntries(recordDate) {
		// YYYYMMDD
		const user = this.getUser();
		this.selectedEntries = [];

		const filteredEntries = this.getData().entries.filter(
			(item) => item.recordDate === recordDate
		);
		let expected = 0,
			saved = 0,
			submitted = 0;
		for (let i = 0; i < filteredEntries.length; i++) {
			const entry = filteredEntries[i];
			if (
				entry.task &&
				((user.time.essInMu && !entry.task.essInMu) || !user.time.essInMu) &&
				!entry.task.isArchive
			) {
				const cloneEntry = entry.clone();
				this.selectedEntries.push(cloneEntry);
			}

			let duration = parseFloat(entry.duration.current);
			if (isNaN(duration)) {
				duration = 0;
			}
			if (entry.dataFrom === "L") {
				saved += duration;
			}
			if (entry.DataFrom === "I") {
				submitted += duration;
			}
		}

		if (this.selectedEntries.length) {
			expected = this.selectedEntries[0].targetHour.expected;
		} else {
			this._data.entry = new Entry({
				RecordDate: recordDate,
			});
			expected = this._data.entry.targetHour.expected;
		}

		this._data.Expected = expected;
		this._data.Saved = saved;
		this._data.Submitted = submitted;

		this.updateExpectedDailyBar(recordDate);
	}

	async updateExpectedDailyBar(recordDate) {
		if (!recordDate) {
			return;
		}

		const filterByRecordDate = this._data.entries.filter(function (t) {
			return t.recordDate === recordDate;
		});

		let saved = 0;
		let submitted = 0;
		for (let j = 0; j < filterByRecordDate.length; j++) {
			let duration = parseFloat(filterByRecordDate[j].duration.current);
			if (isNaN(duration)) {
				duration = 0;
			}
			if (filterByRecordDate[j].dataFrom === "L") {
				saved += duration;
			}
			if (filterByRecordDate[j].dataFrom === "I") {
				submitted += duration;
			}
		}

		const targetHourState = TargetHourState.getInstance();
		this._data.expected = targetHourState.getExpectedDuration(recordDate);
		this._data.saved = saved;
		this._data.submitted = submitted;
	}

	/* updateTimesheetByEntries (onlyFilledEntries) {
		const aEntries = this._data.entries;
		const iWeekStartDay = this.user.weekStartDay; //0 is for Sunday, 1 is for Monday etc.
		const aTimesheets = this._data.TimeEntries;
		let startDate;
		if (aTimesheets.length > 0) {
			startDate = aTimesheets[0].StartDate;
		} else {
			let dStartDate = this.dateService.getStartDateOfWeek(new Date(), iWeekStartDay);
			startDate = this.dateService.format(dStartDate, "yMMdd");
		}

		for (let i = 0; i < aEntries.length; i++) {
			const dDate = this.dateService.formatStringDate(aEntries[i].RecordDate);
			const dStartDateOfWeek = this.dateService.getStartDateOfWeek(dDate, iWeekStartDay);
			const sStartDateOfWeek = this.dateService.format(dStartDateOfWeek, "yMMdd");
			const workDuration = parseFloat(aEntries[i].WorkDuration);
			this.setDataExportFields(aEntries[i]);
			if (!isNaN(workDuration)) {
				aEntries[i].WorkDuration = workDuration.toFixed(1);
			}
			if (aTimesheets.length > 0 && aTimesheets[0].StartDate === sStartDateOfWeek) {
				const dateNumber = this.dateService.dateDiff(dStartDateOfWeek, dDate) + 1;
				let lastSimilarTimesheet = null;
				let oAvailableTimesheet = null;

				for (let j = 0; j < aTimesheets.length; j++) {
					if (aTimesheets[j].TaskId === aEntries[i].TaskId) {
						if (aTimesheets[j].checkFilledEntries().length === 0) {
							oAvailableTimesheet = aTimesheets[j];
							break;
						} else if (
							aTimesheets[j].LocationId === aEntries[i].LocationId &&
							aTimesheets[j].CostTypeId === aEntries[i].CostTypeId &&
							aTimesheets[j].CostTypeValue === aEntries[i].CostTypeValue &&
							aTimesheets[j].ActvtId === aEntries[i].ActvtId &&
							aTimesheets[j].Entries["Date" + dateNumber].WorkDuration === "" &&
							aTimesheets[j].IsLegacy === aEntries[i].IsLegacy && aTimesheets[j].IsLegacy === false) {
							oAvailableTimesheet = aTimesheets[j];
							break;
						} else if (
							aTimesheets[j].LocationId === aEntries[i].LocationId &&
							aTimesheets[j].CostTypeId === aEntries[i].CostTypeId &&
							aTimesheets[j].ActvtId === aEntries[i].ActvtId &&
							aTimesheets[j].CostTypeValue === aEntries[i].CostTypeValue &&
							aTimesheets[j].Entries["Date" + dateNumber].WorkDuration === "" &&
							aTimesheets[j].IsLegacy === aEntries[i].IsLegacy && aTimesheets[j].IsLegacy === true) {
							oAvailableTimesheet = aTimesheets[j];
							break;
						} else {
							lastSimilarTimesheet = aTimesheets[j];
						}
					}
				}

				if (oAvailableTimesheet) {
					oAvailableTimesheet.TaskId = aEntries[i].TaskId;
					oAvailableTimesheet.LocationId = aEntries[i].LocationId;
					oAvailableTimesheet.LocationName = aEntries[i].LocationName;
					oAvailableTimesheet.CostTypeId = aEntries[i].CostTypeId;
					oAvailableTimesheet.CostTypeValue = aEntries[i].CostTypeValue;
					oAvailableTimesheet.ActvtId = aEntries[i].ActvtId;
					oAvailableTimesheet.CostTypeDisplay = aEntries[i].CostTypeDisplay;
					oAvailableTimesheet.CostTypeValueTemp = aEntries[i].CostTypeValue;
					oAvailableTimesheet.PreviousLocationId = aEntries[i].LocationId;
					oAvailableTimesheet.PreviousCostTypeId = aEntries[i].CostTypeId;
					oAvailableTimesheet.PreviousCostTypeValue = aEntries[i].CostTypeValue;
					oAvailableTimesheet.Entries["Date" + dateNumber] = aEntries[i];
					if (aEntries[i].IsLegacy) {
						oAvailableTimesheet.IsLegacy = true;
					}
				} else if (lastSimilarTimesheet) {
					var index = aTimesheets.findIndex(function (item) {
						return item.GUID === lastSimilarTimesheet.GUID;
					});
					oAvailableTimesheet = new Timesheet({
						TaskId: lastSimilarTimesheet.TaskId,
						TaskName: lastSimilarTimesheet.TaskName,
						ActvtId: aEntries[i].ActvtId,
						LocationId: aEntries[i].LocationId,
						LocationName: aEntries[i].LocationName,
						CostTypeId: aEntries[i].CostTypeId,
						CostTypeValue: aEntries[i].CostTypeValue,
						CostTypeValueTemp: aEntries[i].CostTypeValue,
						StartDate: lastSimilarTimesheet.StartDate,
						WeekNumber: lastSimilarTimesheet.WeekNumber,
						ExpectedDuration: lastSimilarTimesheet.ExpectedDuration,
						IsCostCentre: lastSimilarTimesheet.IsCostCentre,
						IsOpportunity: lastSimilarTimesheet.IsOpportunity,
						IsManualIo: lastSimilarTimesheet.IsManualIo,
						IsAccount: lastSimilarTimesheet.IsAccount,
						IsPlaceholder: lastSimilarTimesheet.IsPlaceholder,
						IsRemote: lastSimilarTimesheet.IsRemote,
						CategoryId: lastSimilarTimesheet.CategoryId,
						PreviousLocationId: aEntries[i].LocationId,
						PreviousCostTypeId: aEntries[i].CostTypeId,
						PreviousCostTypeValue: aEntries[i].CostTypeValue,
						Locations: lastSimilarTimesheet.Locations,
						CostTypes: lastSimilarTimesheet.CostTypes
					});
					if (aEntries[i].IsLegacy) {
						oAvailableTimesheet.IsLegacy = true;
					}
					oAvailableTimesheet.CostTypeDisplay = aEntries[i].CostTypeDisplay;
					oAvailableTimesheet.Entries["Date" + dateNumber] = aEntries[i];
					if (index !== -1) {
						aTimesheets.splice(index + 1, 0, oAvailableTimesheet);
					}
				}
			}
			if (aEntries[i].IOStaffing === null) {
				aEntries[i].getIOStaffing();
			}
		}

		for (var k = 0; k < aTimesheets.length; k++) {
			aTimesheets[k].getIOStaffing();
		}
		var filledTimesheets = [];
		var sSettingsTimesheet = this.user.timesheet;
		if (sSettingsTimesheet && sSettingsTimesheet.toString() === "1") {

			for (let j = 0; j < aTimesheets.length; j++) {
				if (aTimesheets[j].checkFilledEntries().length !== 0) {
					var oTimesheet = new Timesheet(aTimesheets[j], false, true);
					filledTimesheets.push(oTimesheet);
				}
			}
			if (filledTimesheets.length === 0) {
				this._data.NewEntry = this.getBlankTimesheet(startDate);
			} else {
				this._data.NewEntry = null;
			}
			this._data.TempTimesheets =  filledTimesheets;
		} else {
			this._data.TempTimesheets = [];
		}
		this.updateExpectedBar();
	}

	getBlankTimesheet (startDate) {
		var date = this.dateService.formatStringDate(startDate);
		var iWeekNumber = this.dateService.getWeek(date);
		return new Timesheet({
			TaskId: "",
			TaskName: "",
			LocationId: "",
			CostTypeId: "",
			CostTypeValue: "",
			CostTypeValueTemp: "",
			StartDate: startDate,
			WeekNumber: iWeekNumber,
			ExpectedDuration: "",
			CategoryId: "1",
			Locations: [],
			CostTypes: []
		});
	}

	setDataExportFields (oEntry) {
		const dateFormat = this.user.dateFormat;
		var oTask = this.tasks.find(function (task) {
			return task.taskId === parseInt(oEntry.TaskId, 10);
		});
		var location;
		var costType;
		if (oTask) {
			if (oTask.locations.length > 0) {
				location = oTask.locations.find(function (item) {
					return item.LocationId === oEntry.LocationId;
				});
			}

			if (oTask.costTypes.length > 0) {
				costType = oTask.costTypes.find(function (item) {
					return item.CostTypeId === parseInt(oEntry.CostTypeId, 10);
				});
			}
			oEntry.TaskName = oTask.taskName;
		}
		var oDateFormat = this.user.dateFormats.find(function (d) {
			return d.ID === dateFormat;
		});
		oEntry.LocationName = (location) ? location.LocationName : "NA";
		oEntry.CostTypeName = (costType) ? costType.CostTypeName : "NA";
		oEntry.FormattedRecordDate = (oEntry && oDateFormat) ? this.dateService.formatStringDate(oEntry.RecordDate,
			oDateFormat.Value) : oEntry.RecordDate;
	}


	async updateTimesheets(dDate, bNotGenerateTimesheet) {
		let iWeekStartDay = this.user.weekStartDay; //0 is for Sunday, 1 is for Monday etc.
		let dStartDate = this.dateService.getStartDateOfWeek(dDate, iWeekStartDay);

		let sFromDate = this._data.FromDate;
		let sToDate = this._data.ToDate;

		let dFromDate = this.dateService.formatStringDate(sFromDate);
		let dToDate = this.dateService.formatStringDate(sToDate);
		let dNextMonthStartDate = new Date(dStartDate.getFullYear(), dStartDate.getMonth() + 2, 0);
		let sNewFromDate, dNewFromDate, sNewToDate, dNewToDate;
		if (dStartDate < dFromDate) {
			dNewFromDate = new Date(dStartDate.getFullYear(), dStartDate.getMonth() - 2, 1);
			sNewFromDate = this.dateService.format(dNewFromDate, "yMMdd");
			dNewToDate = new Date(dFromDate.getFullYear(), dFromDate.getMonth(), dFromDate.getDate() - 1);
			sNewToDate = this.dateService.format(dNewToDate, "yMMdd");
			this._data.FromDate = sNewFromDate;
		} else if (dNextMonthStartDate > dToDate) {
			dNewFromDate = new Date(dToDate.getFullYear(), dToDate.getMonth(), dToDate.getDate() + 1);
			sNewFromDate = this.dateService.format(dNewFromDate, "yMMdd");
			dNewToDate = new Date(dStartDate.getFullYear(), dStartDate.getMonth() + 3, 0);
			sNewToDate = this.dateService.format(dNewToDate, "yMMdd");
			this._data.ToDate = sNewToDate;
		}
		if (sNewFromDate && sNewToDate) {
			await this.getEntries(sNewFromDate, sNewToDate, dStartDate);

		}
		return bNotGenerateTimesheet;
	} 

	async submitEntries(aEntries, successMsg) {
		return await this._sendToIS(aEntries, successMsg, true);
	}*/

	/* validateUserAuth() {
		const sActRecording = this.user.activityRecording;
		const oResourceBundle = sap.ui.getCore().getModel("i18n");
		if (sActRecording !== "1") {
			MessageBox.error(oResourceBundle.getText("userNotActive"));
			throw new Error(oResourceBundle.getText("userNotActive"));
			// return;
		}
	} */

	async _sendToIS(entries, successMsg, isSubmit) {
		const user = this.getUser();
		if (user.activityRecording && user.isISPUser) {
			throw new Error(oResourceBundle.getText("userNotActive"));
		}

		const entriesSendToLS = [];
		const entriesToSubmit = [];

		const timeEntries = this.getData().entries;
		for (let j = 0; j < entries.length; j++) {
			let entry = timeEntries.find(
				(item) => item.guid.toString() === entries[j].guid
			);

			if (!entry && entries[j].indicator === "I") {
				timeEntries.push(entries[j]);
			}

			if (entries[j].busy && entries[j].indicator !== "D") {
				continue;
			}
			if (
				(entries[j].dataFrom !== "I" && entries[j].isRestricted !== true) ||
				(entries[j].dataFrom === "I" && entries[j].indicator !== "")
			) {
				let indicator = "";
				if (entries[j].dataFrom !== "I") {
					indicator = "I";
				} else {
					switch (entries[j].indicator) {
						case "C" || "U":
							indicator = "I";
							break;
						case "D":
							indicator = "D";
							break;
					}
				}
				let opportunity;
				if (entries[j].costType.id === "1") {
					const opportunityIOSettings = this.getData().opportunityIOSettings;
					opportunity = opportunityIOSettings.find(function (item) {
						return item.opportunity.id === entries[j].costType.value;
					});
				}
				let entry;
				if (entries[j].task) {
					entries[j].busy = true;
					if (entries[j].costType.id !== "5") {
						entry = entries[j].getISRequest(indicator, false);
						if (entry) {
							entriesToSubmit.push(entry);
						}
					}

					if (isSubmit) {
						var lsEntry = entries[j].getLSRequest(entry ? 2 : 1, "C");
						entriesSendToLS.push(lsEntry);
					}
				}
			}
		}
		let result = [];
		if (entriesSendToLS.length) {
			this._sendToLS(entriesSendToLS);
		}

		if (entriesToSubmit.length) {
			result = await this._sendToISBatch(entriesToSubmit, isSubmit, successMsg);
		}
		return result;
	}	

	async _sendToLS(postEntries, isBusy) {
		const user = this.getUser();
		postEntries = postEntries.map(entry => {
			return {
				UserGuid: user.time.guid,
				MtrUid: entry.guid, // need to check
				RecordDate: entry.recordDate,
				StatusId: parseInt(entry.status.id),// need to check
				ActivityId:  parseInt(entry.task.taskId, 10),// need to check
				ActvtId: entry.activity.id,
				ProjectType: "MTR",
				LocationId: parseInt(entry.location.id), // need to check
				CostTypeId: parseInt(entry.costType.id),
				CostTypeValue: entry.costType.value,
				WorkDuration: entry.duration.original,
				Unit: entry.unit,
				Note: entry.note,
				PrdProfMapId: user.time.prdProfMapId.toString(),// need to check
				Timestamp: '',// need to check
				Errmsg: entry.errMsg,// need to check
				IsArchive: user.time.isArchive || "",// need to check
				Indicator: entry.indicator,
				CustomerFacing: entry.customerFacing ? "X" : ""

			}

		});
		const postData = {
			UserGuid: user.time.guid,
			N_TimesheetDetail: postEntries,
		};

		const { data } = await this._service.saveEntries(postData);
		const results = data?.N_TimesheetDetail?.results || [];
		const entries = this.getData().entries;

		const deletedEntries = [];

		const response = [];

		for (let i = 0; i < results.length; i++) {
			const index = entries.findIndex(
				(item) => item.guid.toUpperCase() === results[i].MtrUid.toUpperCase()
			);
			let obj;
			if (index !== -1) {
				obj = {
					// Date: entries[index].Date,
					recordDate: entries[index].recordDate,
					duration: entries[index].duration.current,
					indicator: entries[index].indicator,
					customerFacing: entries[index].customerFacing,
				};

				if (parseFloat(results[i].WorkDuration, 10) === 0) {
					deletedEntries.push(entries[index]);
				} else {
					const timeMasterState = TimeMasterState.getInstance();
					const tasks = timeMasterState.getTasks();
					const task = tasks.find(function (task) {
						return task.taskId.toString() === results[i].ActivityId.toString();
					});
					if (task) {
						const location = task.locations.find(
							(item) => item.id === results[i].LocationId
						);
						const costType = task.costTypes.find(
							(item) => item.id === results[i].CostTypeId
						);

						switch (results[i].CostTypeId) {
							case "1":
								const opportunityIOSettings =
									this.getData().opportunityIOSettings;
								ref = opportunityIOSettings.find(
									(item) => item.opportunity.id === results[i].CostTypeValue
								);
								break;
							case "1":
								const manualIOs = this.getData().manualIOs;
								ref = manualIOs.find(
									(item) => item.internalOrder.id === results[i].CostTypeValue
								);
								break;
							default:
								break;
						}

						let statusId, dataFrom;

						if (entries[index].dataFrom === "I") {
							statusId = "4";
							dataFrom = "I";
						} else if (results[i].StatusId) {
							statusId = results[i].StatusId.toString();
							dataFrom = "L";
						} else {
							statusId = "1";
							dataFrom = "L";
						}

						if (obj) {
							obj.statusId = statusId;
							obj.dataFrom = dataFrom;
							response.push(obj);
						}
						const entryStatuses = timeMasterState.getData().entryStatuses;
						const status = entryStatuses.find((item) => item.key === statusId);

						entries[index].setData({
							counter: results[i].Counter,
							taskCounter: results[i].TaskCounter,
							guid: results[i].MtrUid,
							recordDate: results[i].RecordDate,
							customerFacing: results[i].CustomerFacing,
							unit: results[i].Unit,
							note: results[i].Note,
							activity: {
								id: results[i].ActvtId,
								type: {
									description: results[i].ActTypeDesc,
								},
							},
							task: task,
							location: location,
							costType: costType,
							ref: ref,
							costTypeValue: results[i].CostTypeValue,
							status: status,
							duration: results[i].WorkDuration,
							dataFrom: dataFrom,
						});
					}

					if (!isBusy || statusId === Status.Saved) {
						entries[index].busy = false;
					}
				}
			}
		}

		for (let e in deletedEntries) {
			const index = entries.findIndex(function (item) {
				return item.guid.toUpperCase() === deletedEntries[e].guid.toUpperCase();
			});
			if (index !== -1) {
				entries.splice(index, 1);
			}
		}

		const selectedDate = this.getData().selectedDate;
		this.filterEntries(selectedDate);
		return response;
	}

	async _sendToISBatch(entriesToSubmit, isSubmit, successMsg) {
		const { results } = await this.ispService.submitEntries(entriesToSubmit);
		if (results) {
			let index = 0;
			for (let i = 0; i < results.length; i++) {
				const data = results[i];
				if (
					data.Activity &&
					data.Activity.results.length > 0 &&
					parseInt(data.Msgno, 10) === 9
				) {
					entriesToSubmit[i].StatusId = 4;
					entriesToSubmit[i].Activity[0].Taskcounter =
						data.Activity.results[0].Taskcounter;
					entriesToSubmit[i].Activity[0].Counter =
						data.Activity.results[0].Counter;
				} else {
					entriesToSubmit[i].StatusId = 3;
					entriesToSubmit[i].Msgtxt = data.Msgtxt;
				}
			}
		}
		const result = await this._updateISStatus(
			entriesToSubmit,
			isSubmit,
			successMsg
		);
		return result;
	}

	async _updateISStatus(submittedEntries, isSubmit, successMsg) {
		const response = [];
		let isValid = true;
		const aEntries = this._data.entries;
		const selectedEntries = this._data.selectedEntries;
		const resourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
		// const oResourceBundle = sap.ui.getCore().getModel("i18n");
		const lsEntriesToDelete = [];
		for (let i = 0; i < submittedEntries.length; i++) {
			let errMsg = "";
			const networkText = submittedEntries[i].Activity[0].Zz_npktxt;
			const guid = networkText.substring(1, networkText.indexOf("~"));
			if (guid !== "") {
				const entry = aEntries.find(function (item) {
					return item.guid.toUpperCase() === guid.toUpperCase();
				});
				let message;
				if (entry) {
					const entryStatuses = timeMasterState.getData().entryStatuses;
					let statusId, dataFrom, indicator;
					// const status = entryStatuses.find(item => item.key === statusId);
					if (isSubmit) {
						entry.taskCounter = submittedEntries[i].Activity[0].Taskcounter;
						entry.counter = submittedEntries[i].Activity[0].Counter;
						// let statusId, indicator;
						if (submittedEntries[i].StatusId === 4) {
							statusId = Status.Submitted;
							dataFrom = Source.ISP;
							indicator = Indicator.Delete;
						} else {
							statusId = Status.Failed;
							dataFrom = Source.LS;
							indicator = Indicator.Update;
							errMsg = entry.getValidationError(submittedEntries[i].Msgtxt);
						}
						if (errMsg && errMsg !== "") {
							isValid = false;
						}
						const lsEntry = entry.getLSRequest(statusId, indicator);
						lsEntriesToDelete.push(lsEntry);
					} else if (submittedEntries[i].Msgtxt) {
						message = new Message({
							type: sap.ui.core.MessageType.Error,
							title: submittedEntries[i].Msgtxt,
							description: "",
							subtitle: "",
						});
						message.addToMessages(
							entry.guid,
							entry.activity.id,
							entry.status.id
						);
						isValid = false;
					} else {
						const index = aEntries.findIndex(function (item) {
							return item.guid.toUpperCase() === guid.toUpperCase();
						});
						if (index !== -1) {
							aEntries.splice(index, 1);
						}

						const tempIndex = selectedEntries.findIndex(function (item) {
							return item.guid.toUpperCase() === guid.toUpperCase();
						});
						if (tempIndex !== -1) {
							selectedEntries.splice(tempIndex, 1);
						}
					}

					const obj = {
						recordDate: entry.recordDate,
						duration: entry.duration.current,
						indicator: entry.indicator,
						statusId: entry.status.id,
						dataFrom: entry.dataFrom,
						errorMsg: errMsg,
						customerFacing: entry.customerFacing,
					};
					response.push(obj);
				}
			}
		}

		if (lsEntriesToDelete.length) {
			this._sendToLS(lsEntriesToDelete);
		}
		return response;
	}

	/* setISPUnit(sUnit) {
		var lsUnit = "";
		switch (sUnit) {
			case "H":
				lsUnit = "H";
				break;
			default:
				lsUnit = "D";
				break;
		}

		return lsUnit;
	} */

	/* setISPStatus(sStatus) {
		var statusId = "";
		switch (sStatus) {
			case "30":
				statusId = "4";
				break;
			case "40":
				statusId = "3";
				break;
		}

		return statusId;
	} */

	/* async getDataByCostCenter(data) {
		var obj = {};
		var sContactPerson = data.Zzcontpers;
		var Raccobj = data.Raccobj;
		var aFields = sContactPerson.split("/");
		if (aFields.length >= 3) {
			var iAccountId = parseInt(aFields[0], 10);
			var iOpportunityId = parseInt(aFields[1], 10);
			var iLocationId = parseInt(aFields[2], 10);
			var iActvtId = (aFields[3]) ? parseInt(aFields[3], 10) : "";
			if (iOpportunityId > 0) {
				obj.CostTypeId = "1";
				obj.CostTypeValue = iOpportunityId.toString();
			} else if (iAccountId > 0) {
				obj.CostTypeId = "4";
				obj.CostTypeValue = iAccountId.toString();
			} else if (Raccobj.toUpperCase() === "ORDER") {
				obj.CostTypeId = "3";
				obj.CostTypeValue = data.Raccobj_genrec;
			} else {
				obj.CostTypeId = "2";
				obj.CostTypeValue = this.user.costCenter;
			}
			obj.LocationId = iLocationId;
			obj.ActvtId = iActvtId;
		} else {
			obj.CostTypeId = "2";
			obj.CostTypeValue = this.user.costCenter;
			obj.LocationId = 0;
		}
		return obj;
	} */

	/* async getDataByCostCenter (oData) {
		var obj = {};
		var sContactPerson = oData.Zzcontpers;
		var Raccobj = oData.Raccobj;

		const oSettingsModel = MTRModels.getMTRSettingsModel();

		var aFields = sContactPerson.split("/");
		if (aFields.length >= 3) {
			var iAccountId = parseInt(aFields[0], 10);
			var iOpportunityId = parseInt(aFields[1], 10);
			var iLocationId = parseInt(aFields[2], 10);
			var iActvtId = (aFields[3]) ? parseInt(aFields[3], 10) : "";
			var bCustomerFacing = (aFields[4]) ? JSON.parse(aFields[4].toLowerCase()) : true;
			if (iOpportunityId > 0) {
				obj.CostTypeId = "1";
				obj.CostTypeValue = iOpportunityId.toString();
			} else if (iAccountId > 0) {
				obj.CostTypeId = "4";
				obj.CostTypeValue = iAccountId.toString();
			} else if (Raccobj.toUpperCase() === "ORDER") {
				obj.CostTypeId = "3";
				obj.CostTypeValue = oData.Raccobj_genrec;
			} else {
				obj.CostTypeId = "2";
				obj.CostTypeValue = oSettingsModel.getProperty("/CostCenter");
			}
			obj.LocationId = iLocationId;
			obj.ActvtId = iActvtId;
			obj.CustomerFacing = bCustomerFacing;

		} else {
			obj.CostTypeId = "2";
			obj.CostTypeValue = oSettingsModel.getProperty("/CostCenter");
			obj.LocationId = 0;
		}
		return obj;
	} */

	/* async updateEntries() {
		var aEntries = this._data.entries;
		for (var i = 0; i < aEntries.length; i++) {
			aEntries[i].setRecordDate(aEntries[i].RecordDate);
			aEntries[i].setDuration(aEntries[i].WorkDuration);
		}
	} */

	/* getIsWeekends(iStartDayfOfWeek, sRecordDate) {
		var firstWeekend = 5 + iStartDayfOfWeek;
		if (firstWeekend > 6) {
			firstWeekend = firstWeekend - 7;
		}
		var secondWeekend = 6 + iStartDayfOfWeek;
		if (secondWeekend > 6) {
			secondWeekend = secondWeekend - 7;
		}
		var dRecordDate = this.dateService.formatStringDate(sRecordDate);
		var iRecordDay = dRecordDate.getDay();
		if (iRecordDay === firstWeekend || iRecordDay === secondWeekend) {
			return true;
		} else {
			return false;
		}
	} */

	async getAssociatedIOs(selectedOpportunities) {
		if (this.user.HarmonyDown) {
			await this._afterGetAssociations();
		} else {
			const staffingRecord = this.user.staffing;
			const opportunities = this.user.opportunities;
			let aSelectedOpportunities = selectedOpportunities;
			let bSearchedOpportunities = true;
			if (!selectedOpportunities) {
				bSearchedOpportunities = false;
				aSelectedOpportunities = opportunities;
			}

			var aTempOpportunities = this.user.tempOpportunities;

			if (this.user.IsISPDown) {
				await this._afterGetAssociations();
				return;
			}

			const aOpportunityIds = aSelectedOpportunities.map(
				({ OpportunityID }) => OpportunityID
			);

			if (aOpportunityIds && aOpportunityIds.length === 0) {
				await this._afterGetAssociations();
				return;
			}

			// Ticket-INC6607183 - service call timeout issue when opportunites are in thousands
			let batchCount = 100;
			let aResponse = $.extend(true, [], aOpportunityIds);
			let totalRecords = aResponse.length;
			let totalBatches = Math.ceil(totalRecords / batchCount);
			let aPromise = [];
			for (let i = 0; i < totalBatches; i++) {
				let startIndex = i * batchCount;
				let endIndex = startIndex + batchCount;
				let batchCallRecords = aResponse.slice(startIndex, endIndex);
				const mParameters = {
					Url: "/Opportunities",
					OpportunityIds: batchCallRecords,
					Select:
						"SALES_ORG_TEXT,SALES_ORG_SHORT,OPPT_ID,ACCOUNT_NAME,ACCOUNT,DESCRIPTION,OWNER,OWNER_NAME," +
						"STATUS,CURR_PHASE,EXPECTED_VALUE,INTERNAL_ORDER1,INTERNAL_ORDER2,LICENSE_REVENUE,CLOUD_REVENUE,EXPECT_END,REPLACED_BY,STATUS_SINCE",
					Expand: "PartiesInvolved",
				};
				aPromise.push(this._oppService.getOpportunitySlDetails(mParameters));
			}
			if (aPromise.length) {
				Promise.allSettled(aPromise)
					.then((aResponse) => {
						aResponse = aResponse || [];
						let aTempResult = aResponse.map((odata) => {
							return odata["value"] || [];
						});
						let aOppResponseData = [].concat(...aTempResult);
						for (let i = 0; i < aOppResponseData.length; i++) {
							const oData = aOppResponseData[i];
							if (oData) {
								const oTempOpportunityIndex = aTempOpportunities.findIndex(
									function (item) {
										return item.OpportunityID === oData.OPPT_ID;
									}
								);
								const opportunityIndex = opportunities.findIndex(function (
									item
								) {
									return item.OpportunityID === oData.OPPT_ID;
								});

								if (oTempOpportunityIndex !== -1 && bSearchedOpportunities) {
									aTempOpportunities.splice(oTempOpportunityIndex, 1);
									if (opportunityIndex === -1) {
										opportunities.push(
											new OpportunityIOSettings({
												OpportunityID: oData.OPPT_ID,
											})
										);
									}
								}

								const internalOrders = [];

								const opportunity = opportunities[opportunityIndex];

								if (opportunityIndex !== -1) {
									opportunities[opportunityIndex].LicenseRevenue =
										oData.LICENSE_REVENUE;
									opportunities[opportunityIndex].CloudRevenue =
										oData.CLOUD_REVENUE;
									opportunities[opportunityIndex].RevenueType =
										oData.REVENUE_TYPE;

									if (
										oData.ACCOUNT &&
										oData.ACCOUNT !== "" &&
										(!opportunities[opportunityIndex].AccountID ||
											opportunities[opportunityIndex].AccountID === "")
									) {
										opportunities[opportunityIndex].AccountID = oData.ACCOUNT;
									}
									if (
										oData.ACCOUNT_NAME &&
										oData.ACCOUNT_NAME !== "" &&
										(!opportunities[opportunityIndex].AccountName ||
											opportunities[opportunityIndex].AccountName === "")
									) {
										opportunities[opportunityIndex].AccountName =
											oData.ACCOUNT_NAME;
									}
									if (
										oData.DESCRIPTION &&
										oData.DESCRIPTION !== "" &&
										(!opportunities[opportunityIndex].OpportunityName ||
											opportunities[opportunityIndex].OpportunityName === "")
									) {
										opportunities[opportunityIndex].OpportunityName =
											oData.DESCRIPTION;
									}
									if (
										oData.OWNER_NAME &&
										oData.OWNER_NAME !== "" &&
										(!opportunities[opportunityIndex].OwnerName ||
											opportunities[opportunityIndex].OwnerName === "")
									) {
										opportunities[opportunityIndex].OwnerName =
											oData.OWNER_NAME;
									}
									if (oData.STATUS && oData.STATUS !== "") {
										opportunities[opportunityIndex].StatusKey = oData.STATUS;
									}
									opportunities[opportunityIndex].GracePeriod =
										this.calculateGracePeriod(oData.EXPECT_END);
									opportunities[opportunityIndex].isAllowed = this.setAllowed(
										opportunities[opportunityIndex].GracePeriod,
										opportunities[opportunityIndex].StatusKey
									);
									opportunities[opportunityIndex].GracePeriodStat = "";
									opportunities[opportunityIndex].isAllowedStat = "";
									if (!opportunities[opportunityIndex].isAllowed) {
										opportunities[opportunityIndex].GracePeriodStat =
											this.calculateGracePeriod(oData.STATUS_SINCE);
										opportunities[opportunityIndex].isAllowedStat =
											this.setAllowedStat(
												opportunity.GracePeriodStat,
												opportunity.StatusKey
											);
									}
									opportunities[opportunityIndex].REPLACED_BY =
										oData.REPLACED_BY;
									var aSalesOrg = oData.SALES_ORG_SHORT.split("-");
									opportunities[opportunityIndex].SalesOrg =
										aSalesOrg && aSalesOrg.length > 1 ? aSalesOrg[1] : "";
									opportunities[opportunityIndex].IOSetting =
										this.setIOSettings(oData.OPPT_ID, opportunity.SalesOrg);
									if (oData.INTERNAL_ORDER1 && oData.INTERNAL_ORDER1 !== "") {
										var internalOrder1 = oData.INTERNAL_ORDER1.replace(
											/^0+/,
											""
										);
										var oStaffingRecord1 = staffingRecord.filter(function (
											item
										) {
											return (
												item.InternalOrder !== "" &&
												item.InternalOrder === internalOrder1
											);
										});
										var totalStaffedDays1 = 0;
										var totalRecordedDays1 = 0;
										var staffings1 = [];
										for (var j = 0; j < oStaffingRecord1.length > 0; j++) {
											oStaffingRecord1[j].IsOpportunityIO = true;
											var record1 = new Staffing();
											record1.setStaffing(oStaffingRecord1[j]);
											var staffedDays1 = parseFloat(
												oStaffingRecord1[j].StaffedDays
											);
											if (!isNaN(staffedDays1)) {
												totalStaffedDays1 += staffedDays1;
											}
											var recordedDays1 = parseFloat(
												oStaffingRecord1[j].RecordedDays
											);
											if (!isNaN(recordedDays1)) {
												totalRecordedDays1 += recordedDays1;
											}
											staffings1.push(record1);
										}
										internalOrders.push({
											InternalOrder: internalOrder1,
											StaffedDays:
												totalStaffedDays1 !== 0
													? totalStaffedDays1.toString()
													: "",
											RecordedDays:
												totalRecordedDays1 !== 0
													? totalRecordedDays1.toString()
													: "",
											Staffings: staffings1,
										});
									}
									if (oData.INTERNAL_ORDER2 && oData.INTERNAL_ORDER2 !== "") {
										var internalOrder2 = oData.INTERNAL_ORDER2.replace(
											/^0+/,
											""
										);
										var oStaffingRecord2 = staffingRecord.filter(function (
											item
										) {
											return (
												item.InternalOrder !== "" &&
												item.InternalOrder === internalOrder2
											);
										});
										var totalStaffedDays2 = 0;
										var totalRecordedDays2 = 0;
										var staffings2 = [];
										for (var k = 0; k < oStaffingRecord2.length > 0; k++) {
											oStaffingRecord2[k].IsOpportunityIO = true;
											var record2 = new Staffing();
											record2.setStaffing(oStaffingRecord2[k]);
											var staffedDays2 = parseFloat(
												oStaffingRecord2[k].StaffedDays
											);
											if (!isNaN(staffedDays2)) {
												totalStaffedDays2 += staffedDays2;
											}
											var recordedDays2 = parseFloat(
												oStaffingRecord2[k].RecordedDays
											);
											if (!isNaN(recordedDays2)) {
												totalRecordedDays2 += recordedDays2;
											}
											staffings2.push(record2);
										}
										internalOrders.push({
											InternalOrder: internalOrder2,
											StaffedDays:
												totalStaffedDays2 !== 0
													? totalStaffedDays2.toString()
													: "",
											RecordedDays:
												totalRecordedDays2 !== 0
													? totalRecordedDays2.toString()
													: "",
											Staffings: staffings2,
										});
									}
									if (internalOrders.length > 0) {
										opportunities[opportunityIndex].AssociatedIO =
											internalOrders[0].InternalOrder;
										opportunities[opportunityIndex].StaffedDays =
											internalOrders[0].StaffedDays;
										opportunities[opportunityIndex].RecordedDays =
											internalOrders[0].RecordedDays;
									}
									opportunities[opportunityIndex].AvailableIOs = internalOrders;
									if (oTempOpportunityIndex !== -1) {
										aTempOpportunities[
											oTempOpportunityIndex
										].setOpportunityIOData(opportunities[opportunityIndex]);
									}
								}
							}
						}
					})
					.catch(function (error) {
						Log.error("This should never have happened:" + error);
					});
			}

			await this._afterGetAssociations();
		}
	}

	setIOSettings(sOpportunityID, sSalesOrg) {
		var sUpdateIOArtes = this.user.updateIOArtes; // fetching ORE parameter UpdateIOArtes
		/** @type {string} */
		var sCompanyCode = this.user.companyCode;
		/** @type {string} */
		var sIOSetting = "No"; // set default IO Setting = No
		if (sUpdateIOArtes === "1") {
			// condition for 'Default Yes'
			sIOSetting = "Yes";
		} else if (sUpdateIOArtes === "2") {
			// condition for 'Default No'
			sIOSetting = "No";
		} else if (sUpdateIOArtes === "3") {
			// condition for 'Autoset'
			if (this.isCloud(sOpportunityID) === "Error") {
				sIOSetting = "Error";
			} else {
				if (sCompanyCode === sSalesOrg) {
					sIOSetting = "No";
				} else {
					sIOSetting = "Yes";
				}
			}
		} else if (sUpdateIOArtes === "4") {
			// condition for 'Yes ex Cloud'
			if (this.isCloud(sOpportunityID) === "Yes") {
				sIOSetting = "No";
			} else if (this.isCloud(sOpportunityID) === "Error") {
				sIOSetting = "Error";
			} else {
				// else IO Setting is Yes
				sIOSetting = "Yes";
			}
		} else if (sUpdateIOArtes === "5") {
			if (
				sCompanyCode === sSalesOrg ||
				this.isCloud(sOpportunityID) === "Yes"
			) {
				sIOSetting = "No";
			} else if (this.isCloud(sOpportunityID) === "Error") {
				sIOSetting = "Error";
			} else {
				// else IO Setting is Yes
				sIOSetting = "Yes";
			}
		}
		return sIOSetting;
	}

	calculateGracePeriod(expectedEndDate) {
		if (expectedEndDate) {
			var isDate = Date.parse(expectedEndDate);
			var dExpEndDate = isNaN(parseFloat(isDate))
				? new Date(expectedEndDate.match(/\d+/)[0] * 1)
				: expectedEndDate;
			var currentData = new Date();
			var tTimeDiff = currentData.getTime() - dExpEndDate.getTime();
			var sDaysLeft = Math.ceil(tTimeDiff / (1000 * 60 * 60 * 24));
			return sDaysLeft;
		} else {
			return "";
		}
	}

	setAllowed(grace, statusKey) {
		if (grace || statusKey) {
			if (
				grace > 90 &&
				(statusKey === "E0002" ||
					statusKey === "E0003" ||
					statusKey === "E0004" ||
					statusKey === "E0005")
			) {
				return false;
			} else {
				return true;
			}
		} else {
			return "";
		}
	}

	async _afterGetAssociations() {
		const opportunities = this.user.opportunities;
		opportunities.sort(function (a, b) {
			if (a.OpportunityName === "" || a.OpportunityName === null) {
				return 1;
			}
			if (b.OpportunityName === "" || b.OpportunityName === null) {
				return -1;
			}
			if (a.OpportunityID === b.OpportunityID) {
				return 0;
			}
			return a.OpportunityName < b.OpportunityName ? -1 : 1;
		});
		if (!this.user.IsFirstTimeUser) {
			if (!this.user.IsISPDown) {
				await this.setStaffingToManualIO();
			}
			const oLSSettingsRequest = this.user.getLSRequest();
			await this.onSaveSettings(oLSSettingsRequest);
		}
	}

	async submitEntries(aEntries, successMsg) {
		return await this._sendToIS(aEntries, successMsg, true);
	}

	async deleteSubmittedEntries(aEntries, successMsg) {
		return await this._sendToIS(aEntries, successMsg, false);
	}
	openTimeRecordBox(oEvent, that) {
		if (!that.oTimeRecordingDialog) {
			Fragment.load({
				name: "com.melodylib.time.fragments.MTRDialog",
				controller: that,
			}).then(
				function (oDialog) {
					that.oTimeRecordingDialog = oDialog;
					that.getView().addDependent(that.oTimeRecordingDialog);
					that.oTimeRecordingDialog.open();
				}.bind(that)
			);
		} else {
			this.getView().addDependent(that.oTimeRecordingDialog);
			that.oTimeRecordingDialog.open();
		}
	}
	closeTimeRecordBox(oEvent, that) {
		that.oTimeRecordingDialog.close();
	}


	/* async _sendToIS(aEntries, successMsg, isSubmit) {
		const aEntriesSendToLS = [];
		const aEntriesToSubmit = [];
		const timeEntries = this._data.entries;
		this._data.Messages = [];
		for (let j = 0; j < aEntries.length; j++) {
			let entry = timeEntries.find(item => item.MtrUid.toString() === aEntries[j].MtrUid);

			if (!entry && aEntries[j].Indicator === "I") {
				timeEntries.push(aEntries[j]);
			}

			if (aEntries[j].Busy && aEntries[j].Indicator !== "D") {
				continue;
			}
			if ((aEntries[j].DataFrom !== "I" && aEntries[j].isRestricted !== true) || (aEntries[j].DataFrom === "I" && aEntries[j].Indicator !==
				"")) {
				const oTask = this.tasks.find(function (item) {
					return item.taskId.toString() === aEntries[j].TaskId.toString();
				});
				let indicator = "";
				if (aEntries[j].DataFrom !== "I") {
					indicator = "I";
				} else {
					switch (aEntries[j].Indicator) {
						case ("C" || "U"):
							indicator = "I";
							break;
						case "D":
							indicator = "D";
							break;
					}
				}
				const aOpportunities = this.user.opportunities;
				let oOpportunity;
				if (aEntries[j].CostTypeId === "1" || aEntries[j].CostTypeId === 1) {
					oOpportunity = aOpportunities.find(function (item) {
						return item.OpportunityID === aEntries[j].CostTypeValue;
					});
				}
				var oEntry = null;
				if (oTask) {
					aEntries[j].Busy = true;
					if (aEntries[j].CostTypeId !== "5") {
						oEntry = aEntries[j].getISRequest({
							UserId: this.user.userId,
							PersonalNumber: this.user.personalNumber,
							Indicator: indicator,
							CostCenter: this.user.costCenter,
							StdWorkDuration: this.user.stdWorkDuration,
							IspTask: oTask.IspTask,
							IspTaskdes: oTask.IspTaskdes,
							IspSubTask: oTask.IspSubTask,
							TaskLevel: oTask.TaskLevel,
							IsSubmit: false,
							InternalOrder: (oOpportunity && (aEntries[j].CostTypeId === "1" || aEntries[j].CostTypeId === 1)) ? oOpportunity.AssociatedIO : "",
							TaskComponent: (this.user.timeMatrics === "H") ? oTask.TaskCompHours : oTask.TaskCompDays
						});
					}
					if (oEntry) {
						aEntriesToSubmit.push(oEntry);
					}
					if (isSubmit) {
						var oLSEntry = aEntries[j].getLSRequest({
							UserGuid: this.user.userGuid,
							TaskId: aEntries[j].TaskId,
							LocationId: aEntries[j].LocationId,
							CostTypeId: aEntries[j].CostTypeId,
							StatusId: (oEntry) ? 2 : 1,
							Indicator: "C",
							CostTypeValue: aEntries[j].CostTypeValue,
							ProfileId: this.user.profileId
						});
						aEntriesSendToLS.push(oLSEntry);
					}

				}
			}
		}
		let aResult = [];
		if (aEntriesSendToLS.length > 0) {
			this._sendToLS(aEntriesSendToLS);
		}

		if (aEntriesToSubmit.length > 0) {
			aResult = await this._sendToISBatch(aEntriesToSubmit, isSubmit, successMsg);
		}
		return aResult;
	} */

	/* async _fetchStaffing(personalNumber) {
		var currentData = new Date(); // current date
		var dFromDate = new Date(currentData.getFullYear() - 1, 0, 1);
		var sFromDate = this.dateService.format(dFromDate, "yMMdd");
		var dToDate = new Date(currentData.getFullYear() + 2, 0, 0);
		var sToDate = this.dateService.format(dToDate, "yMMdd");
		const data = await this._ispService.getISPData(personalNumber, sFromDate, sToDate, "staffing");
		const aStaffings = [];
		if (data) {
			for (var i = 0; i < data.data.results.length; i++) {
				var oStaffing = new Staffing(data.data.results[i]);
				aStaffings.push(oStaffing);
			}
		}
		this.user.staffing = aStaffings;
		this.updateModel();
	} */

	/* _calculateTimeInMatrixDay(sDate, sCategory) {
		const aEntries = this._data.entries;
		const aFilteredEntries = aEntries.filter(function (item) {
			return item.RecordDate === sDate;
		});
		let fDuration = 0;
		let statusId = "default";
		for (let i = 0; i < aFilteredEntries.length; i++) {
			let fWorkDuration = parseFloat(aFilteredEntries[i].WorkDuration);
			if (sCategory === "0") {
				if (!isNaN(fWorkDuration)) { //condition to check valid float Work Duration
					// calculating total duration in a day
					fDuration += fWorkDuration;
					statusId = this._findStatus(aFilteredEntries[i], statusId);
				}
			} else if (aFilteredEntries[i].SelectedCategory === "1" && sCategory === "1") {
				fWorkDuration = parseFloat(aFilteredEntries[i].WorkDuration);
				if (!isNaN(fWorkDuration)) { //condition to check valid float Work Duration
					// calculating total duration for utilized in a day
					fDuration += fWorkDuration;
					statusId = this._findStatus(aFilteredEntries[i], statusId);
				}
			} else if (aFilteredEntries[i].SelectedCategory === "2" && sCategory === "2") {
				fWorkDuration = parseFloat(aFilteredEntries[i].WorkDuration);
				if (!isNaN(fWorkDuration)) { //condition to check valid float Work Duration
					// calculating total duration for non utilized in a day
					fDuration += fWorkDuration;
					statusId = this._findStatus(aFilteredEntries[i], statusId);
				}
			}
		}
		return [fDuration.toFixed(1), statusId.toString()];
	}

	_findStatus(entry, statusId) {

		if (entry.StatusId === "3") {
			statusId = "failed"; // Failed
		} else if (entry.StatusId === "1" && statusId !== "failed") {
			statusId = "save"; // Save
		} else if (entry.StatusId === "2" && statusId !== "save" && statusId !== "failed") {
			statusId = "inqueue"; // In queue
		} else if (entry.StatusId === "4" && statusId !== "save" && statusId !== "inqueue" && statusId !== "failed") {
			statusId = "submitted"; // Submitted
		}
		return statusId;
	}

	async deleteSavedEntries(entries) {
		const oResourceBundle = sap.ui.getCore().getModel("i18n");
		const result = await this._saveEntries(entries);
		const oMessage = new Message({
			Type: sap.ui.core.MessageType.Success,
			Title: oResourceBundle.getText("deleteEntriesSuccessMsg"),
			Description: "",
			Subtitle: ""
		});
		oMessage.addToMessages();
		MessageToast.show(oResourceBundle.getText("deleteEntriesSuccessMsg"));
		return result;
	}

	async _saveEntries(entries) {
		if (!entries || entries.length === 0) {
			return
		}
		const modifiedEntries = [];
		const timeEntries = this._data.entries;

		for (let i = 0; i < entries.length; i++) {
			let entry = timeEntries.find(item => item.MtrUid.toString() === entries[i].MtrUid);

			if (!entry && entries[i].Indicator === "I") {
				timeEntries.push(entries[i]);
			}
			entry = entries[i];

			if (entries[i].Indicator === "D") {
				entries[i].WorkDuration = "";
			}

			if (entry && entry.Indicator !== "" && entry.isRestricted !== true) {
				entry.Busy = true;
				var oEntry = entry.getLSRequest({
					UserGuid: this.user.userGuid,
					TaskId: entry.TaskId,
					LocationId: entry.LocationId,
					CostTypeId: entry.CostTypeId,
					ActvtId: entry.ActvtId,
					StatusId: 1,
					CostTypeValue: entry.CostTypeValue,
					ProfileId: this.user.profileId
				});
				modifiedEntries.push(oEntry);
			}
		}

		const result = await this._sendToLS(modifiedEntries);
		return result;
	} */

	async getTasksByActivity(activityType, association) {
		const user = this.getUser()
		const filters = [
			new Filter("ActvtTypeID", "EQ", activityType),
			new Filter("ActvtAsstdID", "EQ", association),
			new Filter("RoleMpngID", "EQ", user.role.mappingId),
		]
		const params = {
			filters
		};
		try {
			const { data } = await this._service.getTasksByActivity(params);
			if (data) {
				return data.results || [];
			}
		} catch (error) {
			console.log(error);
		}

	}
}
