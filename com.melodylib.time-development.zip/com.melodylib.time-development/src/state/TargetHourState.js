import BaseState from "com/melodylib/core/state/BaseState";
import ISPService from "com/melodylib/integration/service/ISPService";
import AuthState from "com/melodylib/core/state/AuthState";
import DateUtility from "com/melodylib/core/util/DateUtility";
import TargetHour from "com/melodylib/time/classes/TargetHour";

/**
 * @name com.melodylib.time.state.TargetHourState
 */
export default class TargetHourState extends BaseState {
    constructor() {
        super(ISPService.getInstance());
        this._data = [];
    }

    static getInstance() {
        if (!this._instance) {
            this._instance = new TargetHourState();
        }
        return this._instance;
    }

	getUser() {
        const authState = AuthState.getInstance();
        return authState.getData();
    }

    async getTargetHours(fromDate, toDate) {
        const user = this.getUser();
        let targetHours = [];
		if (user.isISPUser) {
			const currentDate = new Date();
			if (!fromDate) {
				fromDate = new Date(
					currentDate.getFullYear(),
					currentDate.getMonth() - 1,
					1
				); // first date of last year
			}

			if (!toDate) {
				toDate = new Date(
					currentDate.getFullYear(),
					currentDate.getMonth() + 2,
					0
				); // last date of next to next year
			}
			const formattedFromDate = DateUtility.format(fromDate, "yMMdd");
			const formattedToDate = DateUtility.format(toDate, "yMMdd");
			const { data } = await this._service.getISPData(
				user.personalNumber,
				formattedFromDate,
				formattedToDate,
				"Targethours"
			);

			if(data?.results.length > 1) {
				targetHours = Array.from(
					data.results,
					(targetHour) =>
						new TargetHour ({
							date: targetHour.Date,
							dateType: targetHour.Datetype,
							expected: targetHour.Targethours
						})
				);
			}
		}
		this.setTargetHours(targetHours);
		this.setUnit();
		return this.getData();
	}

    setTargetHours(results) {
        const user = this.getUser();
        const targetHours = this.getData();
        const holidays = [],
            vacations = [];
		for (let j = 0; j < results.length; j++) {
			const targethour = targetHours.find(function (item) {
				return item.date === results[j].date;
			});
			if (!targethour) {

				const targetHour = new TargetHour ({
					date: results[j].Date,
					dateType: results[j].Datetype,
					expected: results[j].Targethours
				});

				targetHours.push(targetHour);

				if (targetHour.dateType === "PUBL") {
					holidays.push(targetHour.date);
				} else if (targetHour.dateType === "ABSE") {
					vacations.push(targetHour.date);
				}
			}
		}

        user.time.holidays = holidays;
        user.time.vacations = vacations;
        user.time.startDayOfWeek = this.getStartDayOfWeek();
	}

	getStartDayOfWeek() {
		const targetHours = this.getData();
		let firstWeekend, secondWeekend;
		let startDayOfWeek;
		let flag = true;
		const sortedResults = targetHours.sort(function (a, b) {
			let dateA = DateUtility.formatStringDate(a.date);
			let dateB = DateUtility.formatStringDate(b.date);
			return dateA - dateB;
		});
		let tempSecondWeekend;
		let count = 0;
		for (let j = 0; j < sortedResults.length; j++) {
			if (sortedResults[j].Datetype !== "OFF") {
				if (secondWeekend && count === 2) {
					break;
				} else {
					firstWeekend = null;
					secondWeekend = null;
					flag = true;
				}
			}
			if (sortedResults[j].dateType === "OFF" && flag) {
				let weekend = DateUtility.formatStringDate(sortedResults[j].date);
				if (secondWeekend) {
					if (DateUtility.dateDiff(weekend, secondWeekend) === 1) {
						firstWeekend = null;
						secondWeekend = null;
						flag = false;
					} else {
						break;
					}
				}
				if (firstWeekend) {
					if (DateUtility.dateDiff(firstWeekend, weekend) === 1) {
						secondWeekend = weekend;
						if (Date.parse(secondWeekend) < Date.parse(firstWeekend)) {
							secondWeekend = firstWeekend;
						}
					}
					if (Date.parse(secondWeekend) < Date.parse(firstWeekend)) {
						firstWeekend = secondWeekend;
					}
				} else {
					firstWeekend = weekend;
				}
			}
			if (secondWeekend) {
				count++;
				if (count === 1) {
					tempSecondWeekend = secondWeekend;
				} else if (
					count === 2 &&
					tempSecondWeekend.getDay() === secondWeekend.getDay()
				) {
					continue;
				} else {
					count = 0;
				}
			}
		}
		if (secondWeekend) {
			let startDateOfWeek = new Date(
				secondWeekend.getFullYear(),
				secondWeekend.getMonth(),
				secondWeekend.getDate() + 1
			);
			startDayOfWeek = startDateOfWeek.getDay();
		} else {
			startDayOfWeek = 1;
		}
		return startDayOfWeek;
	}

    setUnit() {
        const user = this.getUser();
		if (user.time.unit === "H") {
			const targetHour = this.getData().find(item => item.dateType === "WORK");
			if (targetHour) {
				this.stdWorkDuration = targetHour.expected.toString();
			} else {
				this.stdWorkDuration = "8";
			}
		} else {
			this.stdWorkDuration = "1";
		}
	}

	getExpectedDuration(recordDate) {
		const user = this.getUser();
		const unit = user.time.unit;
		let expected;
        const isWeekend = DateUtility.isWeekend(this.user.time.startDayOfWeek, recordDate);
        const targetHour = this.getData().find(item => item.date === recordDate);
        if (targetHour) {
			const targetHourNumeric = parseFloat(targetHour.expected);
            if (!isNaN(targetHourNumeric) && targetHourNumeric !== 0) {
                if (unit === "H") {
                    expected = targetHourNumeric.toString();
                } else {
                    expected = "1";
                }
            } else {
                expected = "0";
            }
        } else {
            if (unit === "H" && !isWeekend) {
                expected = "8";
            } else if (unit !== "H" && !isWeekend) {
                expected = "1";
            } else {
                expected = "0";
            }
        }
	}
}
