import Object from "sap/ui/base/Object";

/**
 * @namespace com.melodylib.core.classes.Staffing
 */
export default class Staffing extends Object {
    constructor(data) {
        super();
        if (data) {
           this.setData(data)
        }
    }

    setData (data) {
        this.internalOrder = data.Objnr_f.replace(/^0+/, "");
        this.description = data.Objnr_info;
        this.staffedDays = data.Zexpdays;
        this.recordedDays = data.Pdays;
        this.taskLevel = data.Tasklevel;
        this.taskType = data.Tasktype;
        this.startDate = data.Begda;
        this.endDate = data.Endda;
        this.objnr = data.Objnr;
        this.obart = data.Obart;
        this.raufnr = data.Raufnr;
        this.isOpportunityIO = false;
    }
    setStaffing (data) {
        this.internalOrder = data.internalOrder;
        this.description = data.description;
        this.staffedDays = data.staffedDays;
        this.recordedDays = data.recordedDays;
        this.taskLevel = data.taskLevel;
        this.taskType = data.taskType;
        this.startDate = data.startDate;
        this.endDate = data.endDate;
        this.isOpportunityIO = data.isOpportunityIO;
    }
}

