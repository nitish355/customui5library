import Object from "sap/ui/base/Object";

/**
 * @namespace com.melodylib.core.classes.Account
 */
export default class Account extends Object {
    constructor(data) {
        if (data) {
            this.AccountId = (data.AccountId) ? data.AccountId : "";
            this.AccountDesc = (data.AccountDesc) ? data.AccountDesc : "";
            this.DataFrom = (data.DataFrom) ? data.DataFrom : "";
            this.Indicator = (data.Indicator) ? data.Indicator : "";
            this.CreatedOn = (data.CreatedOn) ? data.CreatedOn : "";
            this.UpdatedOn = (data.UpdatedOn) ? data.UpdatedOn : "";
        }
    }
    getLSRequest (parameters) {
        return {
            UserGuid: parameters.UserGuid,
            AccountId: this.AccountId,
            AccountDesc: this.AccountDesc,
            Indicator: this.Indicator
        };
    }
}

