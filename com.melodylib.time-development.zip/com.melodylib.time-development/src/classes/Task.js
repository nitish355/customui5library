import Object from "sap/ui/base/Object";

/**
 * @namespace com.melodylib.core.classes.Task
 */
export default class Task extends Object {
    constructor(data) {
        super();
        if (data) {
            this.taskId = data.taskId ? data.taskId : "";
            this.taskName = data.taskName ? data.taskName : "";
            this.taskDescription = data.taskDescription ? data.taskDescription : "";
            this.categoryId = data.categoryId.toString()  ? data.categoryId.toString() : "";
            this.addCategoryId = data.addCategoryId.toString() ? data.addCategoryId.toString() : "";
            this.isArchive = data.isArchive ? data.isArchive : "";
            this.costTypes = [];
            this.locations = [];
            this.shortName = data.shortName ? data.shortName : "";
            this.ispSubTaskDes = data.ispSubTaskDes ? data.ispSubTaskDes : "";
            this.isCostCentre = data.isCostCentre ? data.isCostCentre : "";
            this.isOpportunity = data.isOpportunity ? data.isOpportunity : "";
            this.isManualIo = data.isManualIo ? data.isManualIo : "";
            this.isAccount = data.isAccount ? data.isAccount : "";
            this.isPlaceholder = data.isPlaceholder ? data.isPlaceholder : "";
            this.isRemote = data.isRemote ? data.isRemote : "";
            this.ispTask = data.ispTask ? data.ispTask : "";
            this.ispTaskdes = data.ispTaskdes ? data.ispTaskdes : "";
            this.ispSubTask = data.ispSubTask ? data.ispSubTask : "";
            this.essInMu = (data.essInMu && data.essInMu === "X") ? true : false;
            this.level = data.level ? data.level : "";
            this.compHours = data.compHours ? data.compHours : "";
            this.compDays = data.compDays ? data.compDays : "";
            this.isLearning = (data.addCategoryId && data.addCategoryId === 4) ? true : false;
        }
    }
}

