import Object from "sap/ui/base/Object";
// import AuthState from "com/melodylib/core/state/AuthState";

/**
 * @namespace com.melodylib.time.classes.OpportunityIOSetting
 */
export default class OpportunityIOSetting extends Object {
	constructor(data) {
		super();
		this.setData(data);
	}

	setData(data) {
		if (!data) {
			data = {};
		}
		this.opportunity = data.opportunity || null;
		this.associatedIO = data.associatedIO || "";
		this.isDefault = data.IsDefault ? true : false;
		this.isVisible = data.IsVisible ? true : false;
		this.createdOn = data.createdOn || "";
		this.createdTime = data.createdTime || "";
		this.updatedOn = data.updatedOn || "";
		this.updatedTime = data.updatedTime || "";
		this.isArchive = data.isArchive ? true : false;
		this.indicator = data.indicator || "";
	}

	/**
	 * Darshan added this method since it was breaking in TimeState.js
	 */
	setOpportunity(data) {
		this.opportunity = data;
	}

	/* getStaffing(sTaskType, sTaskLevel) {
        var that = this;
        var IOStaffing = null;
        var aAssociatedIOData = this.AvailableIOs.find(function(item) {
            return item.InternalOrder === that.AssociatedIO;
        });
        for(var i = 0; i < aAssociatedIOData.Staffings.length; i++) {
            if(aAssociatedIOData.Staffings[i].TaskLevel === sTaskLevel && 
                aAssociatedIOData.Staffings[i].TaskType === sTaskType) {
                    IOStaffing = aAssociatedIOData.Staffings[i];
                }
        }
        return IOStaffing;
    }
    
    validate () {
        const oSettingsModel = MTRModels.getMTRSettingsModel();
        var sUpdateIOArtes = oSettingsModel.getProperty("/UpdateIOArtes");
        if(sUpdateIOArtes === "1" && this.AssociatedIO !== "") {
            return {
                isValid: false,
                msg: "No IO associated with the opportunity"
            };
        } else {
            return {
                isValid: true
            };
        }
    }
    
    getLSRequest (mParameters) {
        return {
            UserGuid: mParameters.UserGuid,
            AccountId: this.AccountID,
            AssociatedIo: this.AssociatedIO,
            IsDefault: (this.IsDefault) ? "X" : "",
            IsVisible: (this.IsVisible) ? "X" : "",
            OpportunityId: this.OpportunityID,
            IsArchive: (this.IsArchive) ? "X" : ""
        };
    } */
}
