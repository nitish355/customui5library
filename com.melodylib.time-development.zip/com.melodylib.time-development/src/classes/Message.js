import Object from "sap/ui/base/Object";

/**
 * @namespace com.melodylib.time.classes.Message
 */
export default class Message extends Object {
    constructor(data) {
        super()
        this.messages = this.messages ? this.messages :[];
        this.setData(data);

    }
    setData(data) {
        if(!data) {
            data = {};
        }
        this.type = data.type || "";
        this.title = data.title || "";
        this.description = data.description || "";
        this.subtitle = data.subtitle || "";
    }
    addToMessages(guid, activityId, statusId) {
        if (statusId) {
            statusId = statusId;
        } else if (!statusId && this.type === sap.ui.core.MessageType.Error) {
            statusId = "3";
        }

        const message = {
            type: this.type,
            title: this.title,
            subtitle: this.subtitle,
            description: this.description,
            guid: guid,
            activityId: activityId,
            statusId: statusId,
            bLink: (statusId) ? true : false
        };
        if (message.title || (message.activityId && message.title)) {
            this.messages.unshift(message);
        }
    }
}

