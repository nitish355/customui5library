import Object from "sap/ui/base/Object";
import Device from "sap/ui/Device";
import ManualIO from "com/melodylib/time/classes/ManualIO"
import Account from "com/melodylib/time/classes/Account"

/**
 * @namespace com.melodylib.time.classes.Settings
 */
export default class Settings extends Object {
    constructor() {
        super();
        this.Loading = true;
        this.SizeLimit = 500;
        // BaseObject.call(this);
        // ORE Data
        this.UserId = "";
        this.PersonalNumber = "";
        this.UserName = "";
        this.CompanyCode = "";
        this.CostCenter = "";
        this.BelongEss = "";
        this.Headcount = "";
        this.HeadcountId = "";
        this.MuId = "";
        this.MuName = "";
        this.ORERole = "";
        this.OreFlag = "";
        this.OrgFlag = "";
        this.RegionId = "";
        this.RegionName = "";
        this.Specialization = "";
        this.SubRegionName = "";
        this.UpdateIOArtes = "";
        this.UpdateIoArtesValue = "";
        this.ActivityRecording = "0";
        // ISP Data
        this.WeekStartDay = 1;
        this.FirstWeekendDay = 6;
        this.SecondWeekendDay = 0;
        // this.setTimeMatrics("H");

        // LS Data
        this.UserGuid = "";
        this.FirstName = "";
        this.LastName = "";
        this.Email = "";
        this.Status = "";
        this.Application = "MTR";
        this.PartnerId = "";
        this.DateFormat = "";
        this.DisplayDateFormat = "";
        this.EssInMu = true;
        if (!Device.system.desktop) {
            this.Timesheet = "1";
        } else {
            this.Timesheet = "";
        }
        this.CustId = "";
        this.CreatedOn = "";
        this.CreatedTime = "";
        this.UpdatedOn = "";
        this.UpdatedTime = "";
        this.IsArchive = "";
        this.Opportunities = [];
        this.TempOpportunities = [];
        this.AvailableManualIOs = [];
        this.to_MANUAL = [];
        this.to_ACCOUNT = [];
        this.LSOpportunities = []; // Temp Array

        // Local Flags
        this.IsFirstTimeUser = true;
        this.isOREDataCaptured = false;

        this.ProfileId = "";

        this.IsISPDown = false;
        this.RouteName = "";

        this.PilotFlag = "";

        this.IsUnitEdit = false;
    }


    setLSUserData(data) {
        this.updatedTime = data.updatedTime;
        this.isArchive = data.isArchive;
        this.partnerId = data.partnerId;
        this.dateFormat = data.dateFormat;
        const dFormat = this.DateFormats.find(function (d) {
            return d.ID === data.dateFormat;
        });
        this.displayDateFormat = (dFormat) ? dFormat.Value.replace(/D/g, "d") : "MMM dd, y";
        this.essInMu = data.EssInMu;
        if (!Device.system.desktop) {
            this.timesheet = "1";
        } else {
            this.timesheet = data.timesheet.toString();
        }
        this.custId = data.CustId;
        this.createdOn = data.CreatedOn;
        this.createdTime = data.CreatedTime;
        this.updatedOn = data.UpdatedOn;
        this.to_MANUAL = this.setManualIOs(data.to_MANUAL);
        this.to_ACCOUNT = this.setAccounts(data.to_ACCOUNT);
        this.setFirstTimeUserSettings(false);

    }


    setManualIOs(oData, sDataFrom) {
        var manualIOs = [];
        if (oData) {
            for (var i = 0; i < oData.length; i++) {
                var io = new  ManualIO(oData[i]);
                io.DataFrom = (io.DataFrom) ? io.DataFrom : sDataFrom;
                manualIOs.unshift(io);
            }
            return manualIOs;
        } else return [];
    }

    setAccounts(oData, sDataFrom) {
        var accounts = [];
        if (oData) {
            for (var i = 0; i < oData.length; i++) {
                var account = new Account(oData[i]);
                account.DataFrom = (account.DataFrom) ? account.DataFrom : sDataFrom;
                accounts.push(account);
            }
            return accounts;
        } else return [];
    }

    setFirstTimeUserSettings(value) {
        this.firstTimeUser = value;
        if (this.belongEss === "1") {
            this.essInMu = false;
        } else {
            this.essInMu = true;
        }
    }

    setTimeMatrics(value) {
        this.TimeMatrics = value;
        if (value === "H") {
            const oTargetModel = sap.ui.getCore().getModel("target");
            const aTargetHours = oTargetModel.getProperty("/TargetHours");
            const oTargetHour = aTargetHours.find(function (item) {
                return item.Datetype === "WORK";
            });
            if (oTargetHour) {
                this.StdWorkDuration = oTargetHour.Targethours.toString();
            } else {
                this.StdWorkDuration = "8";
            }
        } else {
            this.StdWorkDuration = "1";
        }
    }
}

