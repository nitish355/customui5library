import Object from "sap/ui/base/Object";
import DateService from "com/melodylib/core/service/DateService";
import Entry from "com/melodylib/time/classes/Entry";
import MessageToast from "sap/m/MessageToast";
import User from "com/melodylib/core/state/AuthState";



/**
 * @namespace com.melodylib.core.classes.Timesheet
 */
export default class Timesheet extends Object {
    constructor(data, isDuplicate, isExactCopy) {
        super();
        this._dateServices = DateService.getInstance();
        this._user = User.getInstance().getData();
        this.genericDateFormat = sap.ui.core.format.DateFormat.getInstance({pattern: "yMMdd", calendarType: sap.ui.core.CalendarType.Gregorian});
        this.GUID = this.generateGUID();
        this.setData(data, isDuplicate, isExactCopy);
        this.IsModified = false;
        this.IsISPError = false;
        this.ErrorMsg = "";
        this.setLocationIdValueState(sap.ui.core.ValueState.None);
        this.setCostTypeIdValueState(sap.ui.core.ValueState.None);
        this.setCostTypeValueState(sap.ui.core.ValueState.None);
        this.CostTypeValueStateText = "";
        this.IsLegacy = false;
        this.LocationName = "";
        this.CostTypeDisplay = "";
    }


    setData (data, isDuplicate, isExactCopy) {
        if (data) {
            this.TaskId = (data.TaskId) ? data.TaskId.toString() : "";
            this.ActvtId = (data && data.ActvtId) ? data.ActvtId.toString() : "";
            this.ActvtDesc = (data && data.ActvtDesc) ? data.ActvtDesc.toString() : "";
            this.TaskIdTemp = (data.TaskId) ? data.TaskId.toString() : "";
            this.TaskName = (data.TaskId) ? data.TaskName : "";
            this.LocationId = (data.LocationId && !isDuplicate) ? data.LocationId.toString() : "";
            this.LocationIndex = (data.LocationId && data.LocationId !== "" && !isDuplicate) ? parseInt(data.LocationId, 10) - 1 : -1;
            this.CostTypeId = (data.CostTypeId && !isDuplicate) ? data.CostTypeId.toString() : "";
            if(data && !isDuplicate && data.CostTypeValue && data.CostTypeValue !== "") {
                this.CostTypeValue = data.CostTypeValue;
            } else if(this.CostTypeId === "2" || this.CostTypeId === 2) {
                this.CostTypeValue = this._user.costCenter;
            } else if(isDuplicate) {
                var aOpportunities = this._user.opportunities;
                var oDefaultOpportunities = aOpportunities.find(function(item) {
                    return item.IsDefault;
                });
                if(oDefaultOpportunities) {
                    this.CostTypeId = "1";
                    this.CostTypeValue = oDefaultOpportunities.OpportunityID;	
                } else {
                    this.CostTypeValue = "";
                }
            } else {
                this.CostTypeValue = "";
            }
            this.CostTypeValueTemp = this.CostTypeValue;
            this.StartDate = data.StartDate;
            this.WeekNumber = data.WeekNumber;
            this.IsCostCentre = data.IsCostCentre;
            this.IsOpportunity = data.IsOpportunity;
            this.IsManualIo = data.IsManualIo;
            this.IsAccount = data.IsAccount;
            this.IsPlaceholder = data.IsPlaceholder;
            this.IsRemote = data.IsRemote;
            this.ExpectedDuration = data.ExpectedDuration;
            this.CategoryId = data.CategoryId.toString();
            this.Locations = data.Locations;
            this.CostTypes = data.CostTypes;
            this.IsLegacy = (!isDuplicate) ? data.IsLegacy : false;
            this.Entries = this.setEntries(data, isExactCopy);
            this.IsExpanded = false;
            if(isExactCopy) {
                this.GUID = data.GUID;
            }  
            this.validateISX();
            this.PreviousTaskId = (data && !isDuplicate && (data.PreviousTaskId  || data.PreviousTaskId === "")) ? data.PreviousTaskId.toString() : this.TaskId;
            this.PreviousLocationId = (data && !isDuplicate && (data.PreviousLocationId  || data.PreviousLocationId === "")) ? data.PreviousLocationId.toString() : this.LocationId;
            this.PreviousCostTypeId = (data && !isDuplicate && (data.PreviousCostTypeId  || data.PreviousCostTypeId === "")) ? data.PreviousCostTypeId.toString() : this.CostTypeId;
            this.PreviousCostTypeValue = (data && !isDuplicate && (data.PreviousCostTypeValue  || data.PreviousCostTypeValue === "")) ? data.PreviousCostTypeValue : this.CostTypeValue;
        }
    }
    
    setEntries(data, isExactCopy) {
        var startDate = new Date(this.StartDate.substring(0, 4) + "/" + this.StartDate.substring(4, 6) + "/" + this.StartDate.substring(
            6, 8));
        this.EndDate = this.genericDateFormat.format(new Date(startDate.getTime() + (6 * 24 * 60 * 60 * 1000)));
        return {
            Date1: (isExactCopy) ? new Entry(data.Entries.Date1) : new Entry({ RecordDate: this.genericDateFormat.format(startDate), CostTypeId: this.CostTypeId, CostTypeValue: this.CostTypeValue, Locations: this.Locations, CostTypes: this.CostTypes, IsLegacy: this.IsLegacy }),
            Date2: (isExactCopy) ? new Entry(data.Entries.Date2) : new Entry({ RecordDate: this.genericDateFormat.format(new Date(startDate.getTime() + (1 * 24 * 60 * 60 * 1000))), CostTypeId: this.CostTypeId, CostTypeValue: this.CostTypeValue, Locations: this.Locations, CostTypes: this.CostTypes, IsLegacy: this.IsLegacy }),
            Date3: (isExactCopy) ? new Entry(data.Entries.Date3) : new Entry({ RecordDate: this.genericDateFormat.format(new Date(startDate.getTime() + (2 * 24 * 60 * 60 * 1000))), CostTypeId: this.CostTypeId, CostTypeValue: this.CostTypeValue, Locations: this.Locations, CostTypes: this.CostTypes, IsLegacy: this.IsLegacy }),
            Date4: (isExactCopy) ? new Entry(data.Entries.Date4) : new Entry({ RecordDate: this.genericDateFormat.format(new Date(startDate.getTime() + (3 * 24 * 60 * 60 * 1000))), CostTypeId: this.CostTypeId, CostTypeValue: this.CostTypeValue, Locations: this.Locations, CostTypes: this.CostTypes, IsLegacy: this.IsLegacy }),
            Date5: (isExactCopy) ? new Entry(data.Entries.Date5) : new Entry({ RecordDate: this.genericDateFormat.format(new Date(startDate.getTime() + (4 * 24 * 60 * 60 * 1000))), CostTypeId: this.CostTypeId, CostTypeValue: this.CostTypeValue, Locations: this.Locations, CostTypes: this.CostTypes, IsLegacy: this.IsLegacy }),
            Date6: (isExactCopy) ? new Entry(data.Entries.Date6) : new Entry({ 
                RecordDate: this.genericDateFormat.format(new Date(startDate.getTime() + (5 * 24 * 60 * 60 * 1000))),
                DateType: "OFF", CostTypeId: this.CostTypeId, CostTypeValue: this.CostTypeValue,
                Locations: this.Locations, CostTypes: this.CostTypes, IsLegacy: this.IsLegacy
            }),
            Date7: (isExactCopy) ? new Entry(data.Entries.Date7) : new Entry({ 
                RecordDate: this.genericDateFormat.format(new Date(startDate.getTime() + (6 * 24 * 60 * 60 * 1000))),
                DateType: "OFF", CostTypeId: this.CostTypeId, CostTypeValue: this.CostTypeValue, 
                Locations: this.Locations, CostTypes: this.CostTypes, IsLegacy: this.IsLegacy
            })
        };
    }
    
    checkFilledEntries () {
        var filledEntries = [];
        for(var entry in this.Entries) {
            if(this.Entries[entry].WorkDuration !== "" ) {
                filledEntries.push(this.Entries[entry]);
            }
        }
        return filledEntries;
    }
    
    _validate (allowBlank, highlightError, showMsg, isSubmit) {
        var isValid = true;
        var isDurationValid = true;
        if(this.checkFilledEntries().length === 0 && allowBlank) {
            return true;
        } else if(this.checkFilledEntries().length === 0 && !allowBlank) {
            isDurationValid = false;
        }
        
        if(!this.TaskId || this.TaskId === "") {
            if(highlightError) {
                this.setTaskIdValueState(sap.ui.core.ValueState.Error);
            }
            isValid = false;
        } else {
            this.setTaskIdValueState(sap.ui.core.ValueState.None);
        }
        
        if(this.Locations && this.Locations.length > 0 && (!this.LocationId || this.LocationId === "")) {
            if(highlightError) {
                this.setLocationIdValueState(sap.ui.core.ValueState.Error);
            }
            isValid = false;
        } else {
            this.setLocationIdValueState(sap.ui.core.ValueState.None);
        }
        
        if(this.CostTypes && this.CostTypes.length > 0 && (!this.CostTypeId || this.CostTypeId === "")) {
            if(highlightError) {
                this.setCostTypeIdValueState(sap.ui.core.ValueState.Error);
            }
            isValid = false;
        } else {
            this.setCostTypeIdValueState(sap.ui.core.ValueState.None);
        }
        
        if(!this.CostTypeValue || this.CostTypeValue === "") {
            if(this.CostTypeId === "2" || this.CostTypeId === 2) {
                const oSettingsModel = MTRModels.getMTRSettingsModel();
                this.CostTypeValue = oSettingsModel.getProperty("/CostCenter");
            } else {
                if(highlightError) {
                    this.setCostTypeValueState(sap.ui.core.ValueState.Error);
                }
                isValid = false;
            }
        } else {
            this.setCostTypeValueState(sap.ui.core.ValueState.None);
        }
        
        if(isSubmit && !this.validateISX(isSubmit)) {
            isValid = false;
        }
        
        if(!isValid && showMsg) {
            MessageToast.show("Please select mandatory fields");
        } else if(!isDurationValid && showMsg) {
            MessageToast.show("Please enter the duration and then proceed");
        }
        
        if(!isDurationValid) {
            return false;
        }
        
        return isValid;
    }
    
    validate (allowBlank, highlightError, showMsg, isSubmit) {
        return this._validate(allowBlank, highlightError, showMsg, isSubmit);
    }
    
    validateISX (isSubmit, openPopover) {
        var isValid = true;
        this.IOStaffing = null;
        if(this.CostTypeId === "1" || this.CostTypeId === 1 || this.CostTypeId === "3" || this.CostTypeId === 3) {
            isValid = this._validateISX(openPopover);
        }
        return isValid;
    }
    
    setTaskIdValueState (oValue) {
        this.TaskIdValueState = oValue;
    }
    
    setLocationIdValueState (oValue) {
        this.LocationIdValueState = oValue;
    }
    
    setCostTypeIdValueState (oValue) {
        this.CostTypeIdValueState = oValue;
    }
    
    setCostTypeValueState (oValue) {
        this.CostTypeValueState = oValue;
    }
    
    getModified () {
        return (this.LocationId !== this.PreviousLocationId && this.PreviousLocationId !== "") ||
            (this.CostTypeId !== this.PreviousLocationId && this.PreviousLocationId !== "") ||
            (this.CostTypeValue !== this.PreviousCostTypeValue && this.PreviousCostTypeValue !== "");
    }
    
    generateGUID() {
        var s4 = (((1+Math.random())*0x10000)|0).toString(16).substring(1); 
        return (s4 + s4 + "-" + s4 + "-4" + s4.substring(0,3) + "-" + s4 + "-" + s4 + s4 + s4).toLowerCase();
    }


    getIOStaffing() {
        const that = this;
        const oResourceBundle = sap.ui.getCore().getModel("i18n");
        const staffingRecord = this._user.staffing;
        const opportunities = this._user.opportunities;
        const manualIos = this._user.to_MANUAL;
        let opportunity = null;
        let manualIo = null;
        this.IOStaffing = null;
        let internalOrder = "";
        let isOpportunity = true;
        let isValid = false;
        if (this.CostTypeId === "1" || this.CostTypeId === 1 || this.CostTypeId === "3" || this.CostTypeId === 3) {
            if (this.CostTypeId === "1" || this.CostTypeId === 1) {
                opportunity = opportunities.find(function (item) {
                    return item.OpportunityID === that.CostTypeValue;
                });
                if (opportunity && opportunity.IOSetting === "Yes" && opportunity.AssociatedIO && opportunity.AssociatedIO !== "") {
                    internalOrder = opportunity.AssociatedIO;
                } else {
                    return true;
                }
            } else if ((this.CostTypeId === "3" || this.CostTypeId === 3) && this.CostTypeValue && this.CostTypeValue !== "") {
                manualIo = manualIos.find(function (item) {
                    return item.ManualIOID === that.CostTypeValue;
                });
                if (manualIo) {
                    internalOrder = this.CostTypeValue;
                }
                isOpportunity = false;
            }
            const associatedIoData = staffingRecord.filter(function (item) {
                return internalOrder !== "" && item.InternalOrder === internalOrder;
            });
            if (associatedIoData) {
                const task = this.tasks.find(function (item) {
                    return item.taskId.toString() === that.TaskId.toString();
                });

                const taskTypes = [];
                const taskLevels = [];
                let oCurrentStaffing, sRecordDate, dRecordDate, dEndDate, dStartDate;
                const staffingData = [];
                let remainingDays;
                const dateFormat = this.user.dateFormats.find(function (d) {
                    return d.ID === that.user.dateFormat;
                });
                if (associatedIoData && task) {
                    associatedIoData.sort(function (a, b) {
                        const dT1 = that.this.user.DateFormat.formatStringDate(a.EndDate);
                        const dT2 = that.dateServicesInstance.formatStringDate(b.EndDate);
                        return dT2 > dT1 ? -1 : 1;
                    });
                    for (let i = 0; i < associatedIoData.length; i++) {

                        remainingDays = (parseFloat(associatedIoData[i].StaffedDays) - parseFloat(associatedIoData[i].RecordedDays)) + " " +
                            "Days Left";

                        staffingData.push({
                            Staffing: "Staffing " + (i + 1),
                            ID: (isOpportunity) ? opportunity.OpportunityID : manualIo.ManualIOID,
                            Name: (isOpportunity) ? opportunity.OpportunityName : manualIo.ManualIODesc,
                            Owner: (isOpportunity) ? opportunity.OwnerName : "",
                            AccountID: (isOpportunity) ? opportunity.AccountID : "",
                            AccountName: (isOpportunity) ? opportunity.AccountName : "",
                            InternalOrder: internalOrder,
                            StaffedDays: associatedIoData[i].StaffedDays,
                            StartDate: this.dateServicesInstance.formatStringDate(associatedIoData[i].StartDate, dateFormat.Value),
                            EndDate: this.dateServicesInstance.formatStringDate(associatedIoData[i].EndDate, dateFormat.Value),
                            TaskType: associatedIoData[i].TaskType,
                            TaskLevel: associatedIoData[i].TaskLevel,
                            IsOpportunity: isOpportunity,
                            RemainingDays: remainingDays,
                            Analytics: [{
                                "Staffing": oResourceBundle.getText("recordedDays"),
                                "Days": parseFloat(associatedIoData[i].RecordedDays)
                            }, {
                                "Staffing": oResourceBundle.getText("remainingDays"),
                                "Days": parseFloat(associatedIoData[i].StaffedDays) - parseFloat(associatedIoData[i].RecordedDays)
                            }]
                        });
                    }
                    this.IOStaffingList = staffingData;

                    for (let i = 0; i < associatedIoData.length; i++) {

                        remainingDays = (parseFloat(associatedIoData[i].StaffedDays) - parseFloat(associatedIoData[i].RecordedDays)) + " " +
                            oResourceBundle.getText("dayRemaining");

                        var taskType = taskTypes.find(function (item) {
                            return item === associatedIoData[i].TaskType;
                        });
                        if (!taskType) {
                            taskTypes.push(associatedIoData[i].TaskType);
                        }
                        var taskLevel = taskLevels.find(function (item) {
                            return item === associatedIoData[i].TaskLevel;
                        });
                        if (!taskLevel) {
                            taskLevels.push(associatedIoData[i].TaskLevel);
                        }
                        dStartDate = this.dateServicesInstance.formatStringDate(associatedIoData[i].StartDate);
                        dEndDate = this.dateServicesInstance.formatStringDate(associatedIoData[i].EndDate);
                        sRecordDate = this.RecordDate;
                        if (!sRecordDate) {
                            sRecordDate = this.StartDate;
                        }

                        dRecordDate = this.dateServicesInstance.formatStringDate(sRecordDate);
                        if (dStartDate && dEndDate && dStartDate <= dRecordDate && dEndDate >= dRecordDate) {
                            if (associatedIoData[i].TaskLevel === task.TaskLevel &&
                                associatedIoData[i].TaskType === task.IspTask) {
                                oCurrentStaffing = associatedIoData[i];
                                break;
                            } else if (associatedIoData[i].TaskType === "") {
                                oCurrentStaffing = associatedIoData[i];
                                break;
                            }

                        } else {
                            if (associatedIoData[i].TaskLevel === task.TaskLevel &&
                                associatedIoData[i].TaskType === task.IspTask) {
                                oCurrentStaffing = associatedIoData[i];

                            }
                            if (!oCurrentStaffing && associatedIoData[i].TaskType === "") {
                                oCurrentStaffing = associatedIoData[i];

                            }
                        }

                    }
                }
                if (oCurrentStaffing) {
                    sRecordDate = this.RecordDate;
                    if (!sRecordDate) {
                        sRecordDate = this.StartDate;
                    }
                    dRecordDate = this.dateServicesInstance.formatStringDate(sRecordDate);
                    dStartDate = this.dateServicesInstance.formatStringDate(oCurrentStaffing.StartDate);

                    dEndDate = this.dateServicesInstance.formatStringDate(oCurrentStaffing.EndDate);
                    remainingDays = (parseFloat(oCurrentStaffing.StaffedDays) - parseFloat(oCurrentStaffing.RecordedDays)) + " " +
                        "Days Left";
                    if (dEndDate && dEndDate < dRecordDate || dStartDate > dRecordDate) {
                        remainingDays = "Staffing Expired";
                    }
                    if ((dStartDate && dEndDate && dStartDate <= dRecordDate && dEndDate >= dRecordDate) || remainingDays === "Staffing Expired") {

                        var iOStaffing = {
                            Staffing: "Staffing",
                            ID: (isOpportunity) ? opportunity.OpportunityID : manualIo.ManualIOID,
                            Name: (isOpportunity) ? opportunity.OpportunityName : manualIo.ManualIODesc,
                            Owner: (isOpportunity) ? opportunity.OwnerName : "",
                            AccountID: (isOpportunity) ? opportunity.AccountID : "",
                            AccountName: (isOpportunity) ? opportunity.AccountName : "",
                            InternalOrder: internalOrder,
                            StaffedDays: oCurrentStaffing.StaffedDays,
                            StartDate: this.dateServicesInstance.formatStringDate(oCurrentStaffing.StartDate, dateFormat.Value),
                            EndDate: this.dateServicesInstance.formatStringDate(oCurrentStaffing.EndDate, dateFormat.Value),
                            TaskType: oCurrentStaffing.TaskType,
                            TaskLevel: oCurrentStaffing.TaskLevel,
                            IsOpportunity: isOpportunity,
                            RemainingDays: remainingDays,
                            Analytics: [{
                                "Staffing": "Recorded Days",
                                "Days": parseFloat(oCurrentStaffing.RecordedDays)
                            }, {
                                "Staffing": "Remaining Days",
                                "Days": parseFloat(oCurrentStaffing.StaffedDays) - parseFloat(oCurrentStaffing.RecordedDays)
                            }]
                        };

                        this.IOStaffing = iOStaffing;

                    }
                    isValid = true;
                }
            }
        }


        return isValid;
    }
}

