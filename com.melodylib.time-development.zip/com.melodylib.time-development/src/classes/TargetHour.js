import Object from "sap/ui/base/Object";

/**
 * @namespace com.melodylib.time.classes.TargetHour
 */
export default class TargetHour extends Object {
    constructor(data) {
        super();
        if (data) {
           this.setData(data)
        }
    }

    setData (data) {
        this.date = data.date;
        this.dateType = data.dateType;
        this.expected = data.expected;
    }
}

