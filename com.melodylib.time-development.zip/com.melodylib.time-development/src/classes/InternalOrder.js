import Object from "sap/ui/base/Object";

/**
 * @namespace com.melodylib.time.classes.InternalOrder
 */
export default class InternalOrder extends Object {
    constructor(data) {
        super();
        this.staffings = [];
        if (data) {
           this.setData(data)
        }
    }

    setData (data) {
        this.id = data.id;
        this.description = data.description;
        this.objnr = data.objnr;
        this.obart = data.obart;
        this.raufnr = data.raufnr;
        this.staffings = data.staffings || [];
    }

    getTotalStaffedDays() {
        let totalStaffedDays = 0;
        for (let i = 0; i < this.staffings.length > 0; i++) {
            const staffedDays = parseFloat(this.staffings[i].staffedDays);
            if (!isNaN(staffedDays)) {
                totalStaffedDays += staffedDays;
            }
        }
        return totalStaffedDays;
    }

    getTotalRecordedDays() {
        let totalRecordedDays = 0;
        for (let i = 0; i < this.staffings.length > 0; i++) {
            const recordedDays = parseFloat(this.staffings[i].recordedDays);
            if (!isNaN(recordedDays)) {
                totalRecordedDays += recordedDays;
            }
        }
        return totalRecordedDays;
    }
}

