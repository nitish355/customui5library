import Object from "sap/ui/base/Object";

/**
 * @namespace com.melodylib.core.classes.Category
 */
export default class Category extends Object {
    constructor(data) {
        if (data) {
            /* this.CategoryId = data.CategoryId.toString()? data.CategoryId.toString() : "";
            this.CategoryName = data.CategoryName? data.CategoryName.toString() : ""; */
            this.id = data.CategoryId?.toString() || "";
            this.name = data.CategoryName?.toString() || "";
        }
    }
}

