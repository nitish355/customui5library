import Object from "sap/ui/base/Object";
// import DateUtil from "com/melodylib/core/util/DateUtil";
import TargetHourState from "com/melodylib/time/state/TargetHourState";

import DateService from "com/melodylib/core/service/DateService";
import AuthState from "com/melodylib/core/state/AuthState";
import ActivityState from "com/melodylib/activity/state/ActivityState"
import TimeMasterState from "com/melodylib/time/state/TimeMasterState";
import OppService from "com/melodylib/integration/service/OppService";
import Message from "com/melodylib/time/classes/Message";
import DateUtility from "com/melodylib/core/util/DateUtility";
import TargetHour from "com/melodylib/time/classes/TargetHour";
import Status from "com/melodylib/time/enum/Status";
import OpportunityState from "com/melodylib/integration/state/OpportunityState";
import Helper from "com/melodylib/core/util/Helper";
import CostType from "com/melodylib/time/enum/CostType";

/**
 * @namespace com.melodylib.time.classes.Entry
 */
export default class Entry extends Object {
    constructor(oData) {
        super(this);
        this.genericDateFormat = sap.ui.core.format.DateFormat.getInstance({
            pattern: "yMMdd",
            calendarType: sap.ui.core.CalendarType.Gregorian
        });
        this.uniqueIdTimeStamp = sap.ui.core.format.DateFormat.getInstance({
            pattern: "mmss",
            calendarType: sap.ui.core.CalendarType.Gregorian
        });
        this.busy = false;
        this.setData(oData);
    }

    getUser() {
        const authState = AuthState.getInstance();
        return authState.getData();
    }

    generateGUID() {
        const user = this.getUser();
        return user.personalNumber + this.uniqueIdTimeStamp.format(new Date()) + Math.floor(100 + Math.random() *
            900) + "MTR";
    }

    setData(data) {
        const user = this.getUser();
        if (!data) {
            data = {};
        }
        this.counter = data.counter || "0";
        this.taskCounter = data.taskCounter || "0";
        this.guid = data.guid?.toUpperCase() || this.generateGUID().toUpperCase();
        const recordDate = data.recordDate || this.genericDateFormat.format(new Date());
        this.setRecordDate(recordDate);
        this.customerFacing = data.customerFacing ? true : false;
        this.unit = (data.unit) ? ((data.unit === "TA") ? "D" : data.Unit) : user.time.unit;
        this.note = data.note || "";
        this.setActivity(data.activity);
        this.setTask(data.task);
        this.setLocation(data.location);
        this.setCostType(data.costType, data.costTypeValue, data.ref);
        this.setStatus(data.status);
        this.setDuration(data.duration);
        this.dataFrom = data.dataFrom || "";
        this.indicator = data.indicator || "";
        this.isLegacy = data.isLegacy ? true : false;
        this.isModified = data.isModified ? true : false;
        this.timeStamp = (data && data.CrtAtTimestamp) ? data.CrtAtTimestamp.trim() : "";
        this.setRestricted();
    }

    setActivity(activity) {
        this.activity = activity || {};
    }

    setTask(task) {
        this.task = task || {};
    }

    setLocation(location) {
        this.location = location || { id: "4" };
    }

    setCostType(costType, costTypeValue, ref) {
        const user = this.getUser();
        let value = "";
        if (costTypeValue) {
            value = costTypeValue;
        } else if (costType?.id === "2") {
            value = user.costCenter;
        }
        this.costType = {
            id: costType?.id || "",
            name: costType?.name || "",
            value: value,
            ref: ref
        };
    }

    setStatus(status) {
        this.status = status || { id: "1" };
    }

    setDuration(duration) {
        const user = this.getUser();
        let currentDuration = "",
            previousDuration = "",
            originalDuration = "";
        var duration = parseFloat(duration).toFixed(1);
        if (this.unit !== user.unit && duration) {
            if (this.unit === "H") {
                if (parseFloat(duration) <= 4) {
                    currentDuration = "0.5";
                    previousDuration = "0.5";
                } else {
                    currentDuration = "1";
                    previousDuration = "1";
                }
            } else {
                if (parseFloat(duration) < 1) {
                    currentDuration = "4";
                    previousDuration = "4";
                } else {
                    currentDuration = "8";
                    previousDuration = "8";
                }
            }
            this.unit = user.time.unit;
            originalDuration = duration;
        } else {
            currentDuration = duration;
            previousDuration = duration;
            originalDuration = duration;
        }

        this.duration = {
            current: currentDuration,
            previous: previousDuration,
            original: originalDuration
        }
    }

    setRestricted() {
        const user = this.getUser();
        const currentDate = new Date();
        const recordDate = this.recordDate;
        const startDate = new Date(recordDate.substring(0, 4) + "/" + recordDate.substring(4, 6) + "/" + recordDate.substring(
            6, 8));
        const restrictPriorYear = user.time.restrictPriorYear;
        const cutOffDate = user.time.cutOffDate;
        const graceDate = user.time.graceDate;
        const cuttOffYear = (cutOffDate) ? Number(cutOffDate.substring(6, 10)) : currentDate.getFullYear();
        if (restrictPriorYear && graceDate) {
            const graceDay = Number(graceDate.substring(0, 2));
            const graceMonth = Number(graceDate.substring(3, 5));
            const graceYear = Number(graceDate.substring(6, 10));
            if ((currentDate.getFullYear() === graceYear &&
                currentDate.getMonth() + 1 === graceMonth && currentDate.getDate() <= graceDay) || (startDate.getFullYear() !== cuttOffYear)) {
                this.isRestricted = false;
            } else {
                this.isRestricted = true;
            }
        } else {
            this.isRestricted = false;
        }
    }

    setRecordDate(recordDate) {
        const user = this.getUser();
        this.recordDate = recordDate || this.genericDateFormat.format(new Date());
        this.date = recordDate ? DateUtility.formatStringDate(recordDate) : new Date();
        const startDayOfWeek = user.time.startDayOfWeek;
        var isWeekend = this.getIsWeekend(startDayOfWeek);
        let expected = "8";
        let dateType = (isWeekend) ? "OFF" : "WORK";
        const targetHourState = TargetHourState.getInstance();
        const targetHours = targetHourState.getData();
        const targetHour = targetHours.find((item) => item.Date === this.recordDate);
        if (targetHour) {
            dateType = targetHour.Datetype;
            expected = parseFloat(targetHour.Targethours);
            if (expected && !isNaN(expected)) {
                if (user.unit === "H") {
                    expected = expected.toString();
                } else {
                    expected = "1";
                }
            } else {
                expected = "0";
            }
        } else {
            if (user.time.unit === "H" && !isWeekend) {
                expected = "8";
            } else if (user.time.unit !== "H" && !isWeekend) {
                expected = "1";
            } else {
                expected = "0";
            }
        }

        this.targetHour = new TargetHour({
            date: recordDate,
            dateType: dateType,
            expected: expected
        });

        this.isSubmitEnabled = this.validateISPFutureDate();

    }

    getIsWeekend() {
        const user = this.getUser();
        const startDayOfWeek = user.time.startDayOfWeek;
        var firstWeekend = 5 + startDayOfWeek;
        if (firstWeekend > 6) {
            firstWeekend = firstWeekend - 7;
        }

        var secondWeekend = 6 + startDayOfWeek;
        if (secondWeekend > 6) {
            secondWeekend = secondWeekend - 7;
        }

        const date = DateUtility.formatStringDate(this.recordDate);
        var recordDay = date.getDay();
        if (recordDay === firstWeekend || recordDay === secondWeekend) {
            return true;
        } else {
            return false;
        }
    }

    validateISPFutureDate() {
        const currentDate = new Date();
        const futureDate = new Date(currentDate.setDate(currentDate.getDate() + 7));
        futureDate.setHours(0, 0, 0, 0);
        var date = new Date(this.recordDate.substring(0, 4) + "/" + this.recordDate.substring(4, 6) + "/" + this.recordDate.substring(
            6, 8));
        if (date >= futureDate) {
            return false;
        } else {
            return true;
        }
    }

    clone() {
        const entry = this.copy(this.recordDate);
        entry.dataFrom = this.dataFrom;
        entry.indicator = this.indicator;
        entry.isLegacy = this.isLegacy;
        entry.isModified = this.isModified;

        return entry;
    }

    copy(recordDate) {
        if (!recordDate) {
            throw new Error("Invalid date to copy");
        }
        return new Entry({
            counter: this.counter,
            taskCounter: this.taskCounter,
            guid: this.guid,
            recordDate: recordDate,
            customerFacing: this.customerFacing,
            unit: this.unit,
            note: this.note,
            activity: this.activity,
            task: this.task,
            location: this.location,
            costType: this.costType,
            costTypeValue: this.costType.value,
            status: this.status,
            duration: this.duration.current
        });
    }

    getReplacedByOpportunity(replacedBy) {
        const opportunityState = OpportunityState.getInstance();
        const opportunities = opportunityState.getData().opportunities;
        return opportunities.find(function (item) {
            return item.id === replacedBy;
        });
    }

    getISRequest(indicator, isSubmit) {
        const user = this.getUser();
        // const oSettingsModel = MTRModels.getMTRSettingsModel();
        // const oStaffingModel = MTRModels.getStaffingModel();
        // const aStaffingRecord = oStaffingModel.getData();
        const resourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
        let unit = user.time.unit;
        if (unit === "D") {
            unit = "TA";
        }

        let isKS = true;
        let raccobjText = user.costCenterName;
        let objnr = user.objnr;
        let internalOrder;
        let raufnr = "";
        let obart = "KS";
        let isValid = true;
        let errorDescription = "";
        let errorTitle = "";
        if (this.costType.id === "1") {
            const opportunity = this.costType.ref.opportunity;
            if (this.costType.ref) {
                internalOrder = opportunity.associatedIO;
            }
            if (opportunity) {
                isKS = false;
                if (opportunity.ioSetting === "Yes") {
                    if ((!internalOrder) && indicator !== "D") {
                        errorDescription = resourceBundle.getText("blankIOMsgDesc", [this.costType.value]);
                        errorTitle = resourceBundle.getText("blankIOMsg");
                        isValid = false;
                    }
                } else if (opportunity.ioSetting === "Error") {
                    errorDescription = resourceBundle.getText("noCloudAndPreIOMsgDesc", [this.costType.value]);
                    errorTitle = resourceBundle.getText("noCloudAndPreIOMsg");
                    isValid = false;
                } else if (opportunity.ioSetting === "") {
                    errorDescription = resourceBundle.getText("noAccessOppDesc", [this.costType.value]);
                    errorTitle = resourceBundle.getText("noAccessOppMsg");
                    isValid = false;
                } else if (!opportunity.isAllowed || !opportunity.isAllowedStatus) {
                    if (opportunity.replacedBy && opportunity.status.key === "E0002") {
                        const replacedByOpportunity = this.getReplacedByOpportunity(opportunity.replacedBy);
                        errorDescription = (replacedByOpportunity) ?
                            resourceBundle.getText((!opportunity.isAllowed) ? "gracePerWithRepBy" : "gracePerStatWithRepBy", [this.costType.value, opportunity.replacedBy]) :
                            resourceBundle.getText((!opportunity.isAllowed) ? "gracePerWithRep" : "gracePerStatWithRep", [this.costType.value, opportunity.replacedBy]);
                    } else {
                        errorDescription = resourceBundle.getText((!opportunity.isAllowed) ? "noGracePerDesc" : "noGracePerStatDesc", [this.costType.value]);
                    }
                    errorTitle = resourceBundle.getText((!opportunity.isAllowed) ? "noGracePerMsg" : "noGracePerStatDesc");
                    isValid = false;
                }

                if (!isValid) {
                    const message = new Message({
                        type: sap.ui.core.MessageType.Error,
                        title: errorTitle,
                        description: errorDescription,
                        subtitle: ""
                    });
                    message.addToMessages(this.guid, this.activity.id);
                    this.setValueState("durationValueState", sap.ui.core.ValueState.Error);
                    this.durationValueStateText = resourceBundle.getText("noCloudAndPreIOMsg");
                    MessageToast.show(this.durationValueStateText);
                    return null;
                }
            }
            /* if (opportunity && opportunity.ioSetting === "Yes") {
                isKS = false;
                if ((!internalOrder) && indicator !== "D") {
                    errorDescription = resourceBundle.getText("blankIOMsgDesc", [this.costType.value]);
                    errorTitle = resourceBundle.getText("blankIOMsg");
                    isValid = false;
                    const message = new Message({
                        type: sap.ui.core.MessageType.Error,
                        title: resourceBundle.getText("blankIOMsg"),
                        description: description,
                        subtitle: ""
                    });
                    // message.addToMessages(this.guid, this.activity.id);
                    // this.setValueState("durationValueState", sap.ui.core.ValueState.Error);
                    // this.durationValueStateText = "IO not associated with Opportunity";
                    // MessageToast.show(this.durationValueStateText);
                    // return null;
                }
            } else if (opportunity && opportunity.ioSetting === "Error") {
                isKS = false;
                errorDescription = resourceBundle.getText("noCloudAndPreIOMsgDesc", [this.costType.value]);
                errorTitle = resourceBundle.getText("noCloudAndPreIOMsg");
                isValid = false;
                const message = new Message({
                    type: sap.ui.core.MessageType.Error,
                    title: resourceBundle.getText("noCloudAndPreIOMsg"),
                    description: description,
                    subtitle: ""
                });
                message.addToMessages(this.guid, this.activity.id);
                this.setValueState("durationValueState", sap.ui.core.ValueState.Error);
                this.durationValueStateText = resourceBundle.getText("noCloudAndPreIOMsg");
                MessageToast.show(this.durationValueStateText);
                return null;
            } else if (!opportunity || (opportunity && opportunity.ioSetting === "")) {     // when opportunity not available
                isKS = false;
                errorDescription = resourceBundle.getText("noAccessOppDesc", [this.costType.value]);
                errorTitle = resourceBundle.getText("noAccessOppMsg");
                isValid = false;
                const message = new Message({
                    type: sap.ui.core.MessageType.Error,
                    title: resourceBundle.getText("noAccessOppMsg"),
                    description: description,
                    subtitle: ""
                });
                message.addToMessages(this.guid, this.activity.id);
                this.setValueState("durationValueState", sap.ui.core.ValueState.Error);
                this.durationValueStateText = oResourceBundle.getText("noAccessOppMsg");
                MessageToast.show(this.WorkDurationValueStateText);
                return null;

            } else if (opportunity && opportunity.isAllowed === false) {
                isKS = false;
                if (opportunity && opportunity.replacedBy) {
                    const opportunityState = OpportunityState.getInstance();
                    const opportunities = opportunityState.getData().opportunities;
                    const replacedByOpportunity = opportunities.find(function (item) {
                        return item.id === opportunity.replacedBy;
                    });
                }
                errorDescription = (opportunity.replacedBy && opportunity.status.key === "E0002" && replacedByOpportunity) ? resourceBundle.getText(
                    "gracePerWithRepBy", [this.costType.value, opportunity.replacedBy]) : 
                    (opportunity.replacedBy && opportunity.status.key === "E0002" && !replacedByOpportunity) ? resourceBundle.getText(
                    "gracePerWithRep", [this.costType.value, opportunity.replacedBy]) : 
                    resourceBundle.getText("noGracePerDesc", [this.costType.value]);
                errorTitle = resourceBundle.getText("noGracePerMsg");
                var oMessageReplace = new Message({
                    Type: sap.ui.core.MessageType.Error,
                    Title: oResourceBundle.getText("noGracePerMsg"),
                    Description: sDescriptionReplace,
                    Subtitle: ""
                });
                let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
                oMessageReplace.addToMessages(this.MtrUid, activityId);
                this.setValueState("WorkDurationValueState", sap.ui.core.ValueState.Error);
                this.WorkDurationValueStateText = oResourceBundle.getText("noGracePerMsg");
                MessageToast.show(this.WorkDurationValueStateText);
                return null;
            } else if (opportunity && !opportunity.isAllowedStatus) {
                isKS = false;
                if (opportunity.replacedBy) {
                    var isRepOpp = this.user.opportunities.find(function (item) {
                        return item.OpportunityID === oOpportunity.REPLACED_BY;
                    });
                }
                var sDescriptionStat = (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && isRepOpp) ? oResourceBundle.getText(
                    "gracePerStatWithRepBy", [
                    this.CostTypeValue, oOpportunity.REPLACED_BY
                ]) : (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && !isRepOpp) ? oResourceBundle.getText(
                    "gracePerStatWithRep", [
                    this.CostTypeValue, oOpportunity.REPLACED_BY
                ]) : oResourceBundle.getText("noGracePerStatDesc", [this.CostTypeValue]);
                var oMessageStat = new Message({
                    Type: sap.ui.core.MessageType.Error,
                    Title: oResourceBundle.getText("noGracePerStatDesc"),
                    Description: sDescriptionStat,
                    Subtitle: ""
                });
                let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
                oMessageStat.addToMessages(this.MtrUid, activityId);
                this.setValueState("WorkDurationValueState", sap.ui.core.ValueState.Error);
                this.WorkDurationValueStateText = oResourceBundle.getText("noGracePerStatDesc");
                MessageToast.show(this.WorkDurationValueStateText);
                return null;

            } */
        } else if (this.costType.id === "3") {
            isKS = false;
            const manualIO = this.costType.ref;
            internalOrder = manualIO.internalOrder;
        }

        if (!isKS && internalOrder) {
            obart = internalOrder.obart;
            objnr = internalOrder.objnr;
            raccobjText = internalOrder.description;
            raufnr = internalOrder.raufnr;
            /* var oStaffingRecord = aStaffingRecord.find(function (item) {
                return item.InternalOrder !== "" && item.InternalOrder === sInternalOrder;
            });
            if (oStaffingRecord) {
                sObart = oStaffingRecord.Obart;
                sObjnr = oStaffingRecord.Objnr;
                sRaccobjText = oStaffingRecord.Description;
                sRaufnr = oStaffingRecord.Raufnr;
            } */
        }

        this.note = this.note || this.task.taskType;
        const taskComponent = (this.user.time.unit === "H") ? task.taskCompHours : task.taskCompDays;

        const data = {
            "Taskcounter": this.taskCounter,
            "Testrun": "",
            "Version": "",
            "Msgno": "P",
            "Msgtxt": "",
            "Activity": [{
                "Taskcounter": this.taskCounter,
                "Counter": this.counter,
                "Taskcomponent": taskComponent,
                "Pflag": indicator,
                "Pernr": user.personalNumber,
                "Workdate": this.recordDate,
                "Skostl": (indicator === "D" && taskComponent !== "WORKSTAT" && taskComponent !== "WDAYSST") ? user.costCenter : "",
                "Unit": user.time.unit,
                "Catsquantity": this.duration.current.toString(),
                "Waers": "",
                "Catsamount": "0.00",
                "Status": "",
                "Ltxa1": this.note ? this.note.length > 40 ? this.note.substring(0, 40) : this.Note : "",
                "Rkostl": (isKS) ? user.time.costCenter : "",
                "Rproj": "",
                "Raufnr": (isKS) ? "" : raufnr,
                "Rnplnr": "",
                "Raufpl": "",
                "Raplzl": "",
                "Vornr": "",
                "Rkdauf": "",
                "Rkdpos": "",
                "Lstnr": "",
                "Tasktype": this.task.taskType || this.task.ispTask,
                "Tasktypetext": this.task.ispTaskDescription,
                "Tasklevel": this.task.taskLevel,
                "Raccobj": (isKS) ? "Cost center" : "Order",
                "Raccobj_text": raccobjText,
                "Raccobj_genrec": (isKS) ? this.getRaccobjGenrec(objnr, obart, user.costCenter) : internalOrder.id,
                "Zzsubtype": this.task.subTaskType || this.task.ispSubTask,
                "Zz_npktxt": this.getLocationChar() + this.guid + "~" + this.costType.id + this.costType.value,
                "Zz_location": this.getISXLocationChar(),
                "Zzpsptxt": "",
                "Zzcontpers": this.getContactPerson(),
                "Zz_projn": "",
                "Zzbyd": "",
                "Zcpr_guid": "",
                "Zcpr_extid": "",
                "Zcpr_objguid": "",
                "Zcpr_objgextid": "",
                "Zcpr_objtype": "",
                "Obart": obart,
                "Objnr": objnr,
                "Essposting": "",
                "Tmp_key": "",
                "Trv_rkdauf": "",
                "Trv_rkdpos": "",
                "Zz_rel_obj": "",
                "Newo2c": "",
                "Msgno": "P",
                "Msgtxt": "",
                "Zzmoberrflag": ""
            }]
        };

        if (!isSubmit) {
            return data;
        }
        const isISPDataValid = this.validateISXEntry(true);
        return {
            isValid: isISPDataValid,
            data: data,
            msg: (!isISPDataValid) ? this.errorMsg : ""
        };
    }

    getRaccobjGenrec(objnr, obart) {
        const user = this.getUser();
        var raccobjGenrec = "";
        if (objnr) {
            raccobjGenrec = objnr.replace(obart, "");
            raccobjGenrec = raccobjGenrec.replace(user.costCenter, "");
            raccobjGenrec = raccobjGenrec + user.costCenter.replace("0", "/");
        }
        return raccobjGenrec;
    }

    getLocationChar() {
        let locationChar;
        switch (this.location.id) {
            case "1":
                locationChar = "O";
                break;
            case "2" || "4":
                locationChar = "V";
                break;
            case "3":
                locationChar = "R";
                break;
            default:
                locationChar = "N";
                break;
        }
        return locationChar;
    }

    getISXLocationChar() {
        let locationChar;
        switch (this.location.id) {
            case "1":
                locationChar = "O";
                break;
            case "2" || "3" || "4":
                locationChar = "R";
                break;
            default:
                locationChar = "";
                break;
        }
        return locationChar;
    }

    getContactPerson() {
        let accountId = 0,
            opportunityId = 0,
            locationId = 0,
            activityId = "",
            customerFacing = this.customerFacing.toString();

        if (this.costType.id === "1") {
            const opportunity = this.costType.ref?.opportunity;
            if (opportunity) {
                opportunityId = opportunity.id;
                accountId = opportunity.account.id;
            }
        } else if (this.costType.id === "4") {
            accountId = this.costType.value;
        }

        if (this.location.id) {
            locationId = this.location.id;
        }

        if (this.activity.id) {
            activityId = this.activity.id;
        }

        accountId = accountId ? this.padWithZeroes(accountId, 10) : this.padWithZeroes(0, 10);
        opportunityId = opportunityId ? this.padWithZeroes(opportunityId, 9) : this.padWithZeroes(0, 9);
        return accountId + "/" + opportunityId + "/" + locationId + "/" + activityId + "/" + customerFacing;
    }

    padWithZeroes(number, length) {
        var myString = "" + number;
        while (myString.length < length) {
            myString = "0" + myString;
        }
        return myString;
    }

    validateISXEntry(openPopover) {
        var isValid = true;
        if (this.costType.id === "1" || this.costType.id === "3") {
            isValid = this._validateISX(openPopover);
        }
        return isValid;
    }


    _validateISX(openPopover) {
        let isValid = true;
        const resourceBundle = Helper.getResourceModel().getResourceBundle();
        let description = "",
            title = "";
        if (this.costType.id === "1") {
            let replacedByOpportunity;
            const opportunity = this.costType.ref.opportunity;
            if (opportunity && opportunity.replacedBy) {
                replacedByOpportunity = this.getReplacedByOpportunity(opportunity.replacedBy);
            }
            if (!opportunity.isAllowed || !opportunity.isAllowedStat) {
                if (opportunity.status.key === "E0002") {
                    description = (replacedByOpportunity) ?
                        resourceBundle.getText(!opportunity.isAllowed ? "gracePerWithRepBy" : "gracePerStatWithRepBy", [this.costType.value, opportunity.replacedBy]) :
                        resourceBundle.getText(!opportunity.isAllowed ? "gracePerWithRep" : "gracePerStatWithRep", [this.costType.value, opportunity.replacedBy]);
                } else {
                    description = resourceBundle.getText(!opportunity.isAllowed ? "noGracePerDesc" : "noGracePerStatDesc", [this.costType.value]);
                }
                title = resourceBundle.getText(!opportunity.isAllowed ? "noGracePerMsg" : "noGracePerStatDesc");
                isValid = false;
            }

            switch (opportunity.ioSetting) {
                case "Yes":
                    if (!opportunity.associatedIO) {
                        description = resourceBundle.getText("blankIOMsgDesc", [this.costType.value]);
                        title = resourceBundle.getText("blankIOMsg")
                        isValid = false;
                    } else if (opportunity.associatedIO && (!opportunity.associatedIO.getTotalStaffedDays())) {
                        description = resourceBundle.getText("userNotStaffedMsgDesc", [this.costType.value]);
                        title = resourceBundle.getText("userNotStaffedMsg");
                        isValid = false;
                    } else {
                        isValid = true;
                    }
                    break;
                case "Error":
                    description = resourceBundle.getText("noCloudAndPreIOMsgDesc", [this.costType.value]);
                    title = resourceBundle.getText("noCloudAndPreIOMsg");
                    isValid = false;
                    break;
                case "":
                    description = resourceBundle.getText("noAccessOppDesc", [this.costType.value]);
                    title = resourceBundle.getText("noAccessOppMsg");
                    isValid = false;
                    break;
                default:
                    break;
            }

            if (!isValid) {
                const message = new Message({
                    type: sap.ui.core.MessageType.Error,
                    title: title,
                    description: description,
                    subtitle: ""
                });

                this.setValueState("costTypeValueState", sap.ui.core.ValueState.Error);
                this.costTypeValueStateText = title;
                message.addToMessages(this.guid, openPopover);
            }
            /* if (((this.CostTypeId === "1" || this.CostTypeId === 1) && oOpportunity && oOpportunity.IOSetting === "Yes") ||
                this.CostTypeId === "3" || this.CostTypeId === 3) {
                isValid = isValid && this.getIOStaffing();
            } */
        }
        return isValid;
    }

    getLSRequest(statusId, indicator) {
        const user = this.getUser();
        return {
            UserGuid: user.time.guid,
            MtrUid: this.guid,
            RecordDate: this.recordDate,
            IspGuid: this.ispGuid,
            StatusId: parseInt(statusId, 10),
            ActivityId: parseInt(this.task.id, 10),
            ActvtId: this.activity.id,
            ProjectType: this.projectType || "MTR",
            LocationId: (this.location.id) ? parseInt(this.location.id, 10) : 0,
            CostTypeId: parseInt(this.costType.id, 10),
            CostTypeValue: this.costType.value,
            WorkDuration: (this.duration.current) ? parseFloat(this.duration.current).toFixed(1) : "0",
            Unit: this.unit,
            Note: this.note,
            PrdProfMapId: user.time.profileId.toString(),
            Timestamp: "",
            Errmsg: this.errorMsg || "",
            IsArchive: "",
            Indicator: indicator || this.indicator,
            CustomerFacing: (this.customerFacing) ? "X" : ""
        };
    }

    getValidationError(errMsg) {
        const resourceBundle = Helper.getResourceModel().getResourceBundle();
        this.setValueState("durationValueState", sap.ui.core.ValueState.None);
        this.durationValueStateText = "";
        let ioSettingFlag = true;
        let isValidationHandled = false;
        let validationErrorMsg = "";
        if (this.costType.id === CostType.Opportunity || this.costType.id === CostType.ManualIO) {
            let internalOrder = "";



            /* const oTask = oSettingsModel.getProperty("/MTRTasks").find(function (item) {
                return item.TaskId.toString() === that.TaskId.toString();
            }); */
            let isValidIO = false;
            const taskTypes = [];
            const taskLevels = [];
            let currentStaffing;
            let opportunity = null;
            let manualIO = null;
            let isOpportunity = false;
            if (this.costType.id === CostType.Opportunity) {
                isOpportunity = true;
                const opportunity = this.costType.ref.opportunity;
                if (opportunity) {
                    if (opportunity.associatedIO) {
                        internalOrder = opportunity.associatedIO.internalOrder;
                    }

                    if (opportunity.ioSetting !== "Yes") {
                        ioSettingFlag = false;
                    }
                }
            } else if ((this.costType.id === CostType.ManualIO) && this.costType.value) {
                internalOrder = this.costType.ref.internalOrder;
            }

            if (internalOrder) {
                const staffings = internalOrder.staffings;
                for (let i = 0; staffings.length; i++) {
                    const taskType = taskTypes.find(item => item === staffings[i].taskType);
                    if (!taskType) {
                        taskTypes.push(staffings[i].taskType);
                    }
                    const taskLevel = taskLevels.find(item => item === staffings[i].taskLevel);
                    if (!taskLevel) {
                        taskLevels.push(staffings[i].taskLevel);
                    }
                    if (DateUtility.validateBetweenStringDate(staffings[i].startDate, staffings[i].endDate, this.recordDate) &&
                        this.duration.current) {
                        if (staffings[i].taskLevel === this.task.taskLevel &&
                            staffings[i].taskType === this.task.ispTask) {
                            currentStaffing = staffings[i];
                            isValidIO = true;
                        }
                        if (!currentStaffing && staffings[i].taskType === "") {
                            currentStaffing = staffings[i];
                            isValidIO = true;
                        }
                    }
                }

                if (!isValidIO) {
                    isValidationHandled = true;

                    const description = resourceBundle.getText("ioTaskNotMatchMsgDesc", [this.costType.value, internalOrder.id, taskLevels.toString(),
                    taskTypes.toString(), this.task.taskName, this.task.taskLevel, this.task.ispTask
                    ]);
                    const message = new Message({
                        type: sap.ui.core.MessageType.Error,
                        title: "IO Task Type or Task Level not matching with Task Selected",
                        description: description,
                        subtitle: ""
                    });
                    message.addToMessages(this.guid, this.activity.id);
                    this.setValueState("durationValueState", sap.ui.core.ValueState.Error);
                    this.durationValueStateText = "IO Task Type or Task Level not matching with Task Selected";
                    validationErrorMsg = "IO Task Type or Task Level not matching with Task Selected";
                }

                if (currentStaffing) {
                    let duration = parseFloat(this.duration.current);
                    if (this.unit === "H") {
                        duration = parseFloat(this.duration.current) / 8;
                    }
                    if (this.duration.current && parseFloat(currentStaffing.staffedDays) <= (parseFloat(currentStaffing.recordedDays) +
                        duration)) {
                        isValidationHandled = true;
                        const description = resourceBundle.getText("staffedDaysLimitMsgDesc", [this.costType.value, currentStaffing.internalOrder,
                        parseFloat(currentStaffing.staffedDays).toFixed(1), parseFloat(currentStaffing.recordedDays).toFixed(1), (parseFloat(
                            currentStaffing.staffedDays) - parseFloat(currentStaffing.recordedDays)).toFixed(1)
                        ]);
                        const message = new Message({
                            type: sap.ui.core.MessageType.Error,
                            title: "You have reached the max " + parseFloat(currentStaffing.staffedDays).toFixed(1) + " days staffed on the IO.",
                            description: description,
                            subtitle: ""
                        });
                        message.addToMessages(this.guid, this.activity.id);
                        this.setValueState("durationValueState", sap.ui.core.ValueState.Error);
                        this.durationValueStateText = "You have reached the max " + parseFloat(currentStaffing.staffedDays).toFixed(1) +
                            " days staffed on the IO.";
                        validationErrorMsg = "You have reached the max " + parseFloat(currentStaffing.staffedDays).toFixed(1) +
                            " days staffed on the IO.";
                    }
                    const calcStaffing = this.validateStaffingPeriod(currentStaffing);
                    if (calcStaffing.isValidationHandled) {
                        isValidationHandled = true;
                        validationErrorMsg = calcStaffing.msg;
                    }
                }
            }
        }
        if (!isValidationHandled) {
            const message = new Message({
                type: sap.ui.core.MessageType.Error,
                title: errMsg,
                description: errMsg,
                subtitle: ""
            });
            message.addToMessages(this.guid, this.activity.id);
            this.setValueState("durationValueState", sap.ui.core.ValueState.Error);
            this.durationValueStateText = errMsg;
            return errMsg;
        }
        return validationErrorMsg;
    }

    setValueState(property, valueState) {
        this[property] = valueState;
    }

    validateStaffingPeriod(staffing, isAddMessageNotRequired) {
        const user = this.getUser();
        const dateFormat = user.time.dateFormat;
        let isValidationHandled = false;
        let validationErrorMsg = "";
        if (!DateUtility.validateBetweenStringDate(staffing.startDate, staffing.endDate, this.recordDate) &&
            this.duration.current) {
            if (!isAddMessageNotRequired) {
                isValidationHandled = true;

                const description = "INFO SECTION \n\nSelected Opportunity " + this.costType.value +
                    " is associated with an IO which has Staffing period between " + DateUtility.formatStringDate(
                        staffing.startDate, dateFormat.value) + " and " + DateUtility.formatStringDate(staffing.endDate,
                            dateFormat.value) +
                    ". \n\nRESOLUTION \n\nPlease submit your entry within staffing period, or submit a ticket for resolution, you can save the entry for now.";

                const message = new Message({
                    type: sap.ui.core.MessageType.Error,
                    title: "Time entry for this IO is outside the staffing period",
                    description: description,
                    subtitle: ""
                });
                message.addToMessages(this.guid, this.activity.id);
                this.setValueState("durationValueState", sap.ui.core.ValueState.Error);
                this.durationValueStateText = "Time entry for this IO is outside the staffing period";
                this.setValueState("costTypeValueState", sap.ui.core.ValueState.Error);
                validationErrorMsg = "Time entry for this IO is outside the staffing period";
            }
        }
        return {
            isValidationHandled: isValidationHandled,
            msg: validationErrorMsg
        };
    }



    /* getIOStaffing() {
        const staffingRecord = this.user.staffing;
        const opportunities = this.user.opportunities;
        const manualIos = this.user.to_MANUAL;
        let opportunity = null;
        let manualIo = null;
        
        let internalOrder = "";
        let isOpportunity = true;
        let isValid = false;

        this.iOStaffing = null;
        let iOStaffing;
        
        switch (this.costType.id) {
            case "1":       // Opportunity
                
                break;
            case "3":       // Manual IO
                
                break;
            default:
                return;
        }

        
        if (this.CostTypeId === "1" || this.CostTypeId === 1 || this.CostTypeId === "3" || this.CostTypeId === 3) {
            if (this.CostTypeId === "1" || this.CostTypeId === 1) {
                opportunity = opportunities.find(function (item) {
                    return item.OpportunityID === that.CostTypeValue;
                });
                if (opportunity && opportunity.IOSetting === "Yes" && opportunity.AssociatedIO && opportunity.AssociatedIO !== "") {
                    internalOrder = opportunity.AssociatedIO;
                } else {
                    return true;
                }
            } else if ((this.CostTypeId === "3" || this.CostTypeId === 3) && this.CostTypeValue && this.CostTypeValue !== "") {
                manualIo = manualIos.find(function (item) {
                    return item.ManualIOID === that.CostTypeValue;
                });
                if (manualIo) {
                    internalOrder = this.CostTypeValue;
                }
                isOpportunity = false;
            }
            const associatedIoData = staffingRecord.filter(function (item) {
                return internalOrder !== "" && item.InternalOrder === internalOrder;
            });
            if (associatedIoData) {
                const task = this.tasks.find(function (item) {
                    return item.taskId.toString() === that.TaskId.toString();
                });

                const taskTypes = [];
                const taskLevels = [];
                let oCurrentStaffing, sRecordDate, dRecordDate, dEndDate, dStartDate;
                const staffingData = [];
                let remainingDays;
                const dateFormat = this.user.dateFormats.find(function (d) {
                    return d.ID === that.user.dateFormat;
                });
                if (associatedIoData && task) {
                    associatedIoData.sort(function (a, b) {
                        const dT1 = that.this.user.DateFormat.formatStringDate(a.EndDate);
                        const dT2 = that.dateServicesInstance.formatStringDate(b.EndDate);
                        return dT2 > dT1 ? -1 : 1;
                    });
                    for (let i = 0; i < associatedIoData.length; i++) {

                        remainingDays = (parseFloat(associatedIoData[i].StaffedDays) - parseFloat(associatedIoData[i].RecordedDays)) + " " +
                            "Days Left";

                        staffingData.push({
                            Staffing: "Staffing " + (i + 1),
                            ID: (isOpportunity) ? opportunity.OpportunityID : manualIo.ManualIOID,
                            Name: (isOpportunity) ? opportunity.OpportunityName : manualIo.ManualIODesc,
                            Owner: (isOpportunity) ? opportunity.OwnerName : "",
                            AccountID: (isOpportunity) ? opportunity.AccountID : "",
                            AccountName: (isOpportunity) ? opportunity.AccountName : "",
                            InternalOrder: internalOrder,
                            StaffedDays: associatedIoData[i].StaffedDays,
                            StartDate: this.dateServicesInstance.formatStringDate(associatedIoData[i].StartDate, dateFormat.Value),
                            EndDate: this.dateServicesInstance.formatStringDate(associatedIoData[i].EndDate, dateFormat.Value),
                            TaskType: associatedIoData[i].TaskType,
                            TaskLevel: associatedIoData[i].TaskLevel,
                            IsOpportunity: isOpportunity,
                            RemainingDays: remainingDays,
                            Analytics: [{
                                "Staffing": oResourceBundle.getText("recordedDays"),
                                "Days": parseFloat(associatedIoData[i].RecordedDays)
                            }, {
                                "Staffing": oResourceBundle.getText("remainingDays"),
                                "Days": parseFloat(associatedIoData[i].StaffedDays) - parseFloat(associatedIoData[i].RecordedDays)
                            }]
                        });
                    }
                    this.IOStaffingList = staffingData;

                    for (let i = 0; i < associatedIoData.length; i++) {

                        remainingDays = (parseFloat(associatedIoData[i].StaffedDays) - parseFloat(associatedIoData[i].RecordedDays)) + " " +
                            oResourceBundle.getText("dayRemaining");

                        var taskType = taskTypes.find(function (item) {
                            return item === associatedIoData[i].TaskType;
                        });
                        if (!taskType) {
                            taskTypes.push(associatedIoData[i].TaskType);
                        }
                        var taskLevel = taskLevels.find(function (item) {
                            return item === associatedIoData[i].TaskLevel;
                        });
                        if (!taskLevel) {
                            taskLevels.push(associatedIoData[i].TaskLevel);
                        }
                        dStartDate = this.dateServicesInstance.formatStringDate(associatedIoData[i].StartDate);
                        dEndDate = this.dateServicesInstance.formatStringDate(associatedIoData[i].EndDate);
                        sRecordDate = this.RecordDate;
                        if (!sRecordDate) {
                            sRecordDate = this.StartDate;
                        }

                        dRecordDate = this.dateServicesInstance.formatStringDate(sRecordDate);
                        if (dStartDate && dEndDate && dStartDate <= dRecordDate && dEndDate >= dRecordDate) {
                            if (associatedIoData[i].TaskLevel === task.TaskLevel &&
                                associatedIoData[i].TaskType === task.IspTask) {
                                oCurrentStaffing = associatedIoData[i];
                                break;
                            } else if (associatedIoData[i].TaskType === "") {
                                oCurrentStaffing = associatedIoData[i];
                                break;
                            }

                        } else {
                            if (associatedIoData[i].TaskLevel === task.TaskLevel &&
                                associatedIoData[i].TaskType === task.IspTask) {
                                oCurrentStaffing = associatedIoData[i];

                            }
                            if (!oCurrentStaffing && associatedIoData[i].TaskType === "") {
                                oCurrentStaffing = associatedIoData[i];

                            }
                        }

                    }
                }
                if (oCurrentStaffing) {
                    sRecordDate = this.RecordDate;
                    if (!sRecordDate) {
                        sRecordDate = this.StartDate;
                    }
                    dRecordDate = this.dateServicesInstance.formatStringDate(sRecordDate);
                    dStartDate = this.dateServicesInstance.formatStringDate(oCurrentStaffing.StartDate);

                    dEndDate = this.dateServicesInstance.formatStringDate(oCurrentStaffing.EndDate);
                    remainingDays = (parseFloat(oCurrentStaffing.StaffedDays) - parseFloat(oCurrentStaffing.RecordedDays)) + " " +
                        "Days Left";
                    if (dEndDate && dEndDate < dRecordDate || dStartDate > dRecordDate) {
                        remainingDays = "Staffing Expired";
                    }
                    if ((dStartDate && dEndDate && dStartDate <= dRecordDate && dEndDate >= dRecordDate) || remainingDays === "Staffing Expired") {

                        var iOStaffing = {
                            Staffing: "Staffing",
                            ID: (isOpportunity) ? opportunity.OpportunityID : manualIo.ManualIOID,
                            Name: (isOpportunity) ? opportunity.OpportunityName : manualIo.ManualIODesc,
                            Owner: (isOpportunity) ? opportunity.OwnerName : "",
                            AccountID: (isOpportunity) ? opportunity.AccountID : "",
                            AccountName: (isOpportunity) ? opportunity.AccountName : "",
                            InternalOrder: internalOrder,
                            StaffedDays: oCurrentStaffing.StaffedDays,
                            StartDate: this.dateServicesInstance.formatStringDate(oCurrentStaffing.StartDate, dateFormat.Value),
                            EndDate: this.dateServicesInstance.formatStringDate(oCurrentStaffing.EndDate, dateFormat.Value),
                            TaskType: oCurrentStaffing.TaskType,
                            TaskLevel: oCurrentStaffing.TaskLevel,
                            IsOpportunity: isOpportunity,
                            RemainingDays: remainingDays,
                            Analytics: [{
                                "Staffing": "Recorded Days",
                                "Days": parseFloat(oCurrentStaffing.RecordedDays)
                            }, {
                                "Staffing": "Remaining Days",
                                "Days": parseFloat(oCurrentStaffing.StaffedDays) - parseFloat(oCurrentStaffing.RecordedDays)
                            }]
                        };

                        this.IOStaffing = iOStaffing;

                    }
                    isValid = true;
                }
            }
        }


        return isValid;
    } */

    /* async setMelodyActivity(sActvtId) {
        const activities = await this._Activity.getData();
        let oActivity = activities.find(item => sActvtId && parseInt(item.ActivityId, 10) === parseInt(sActvtId, 10));
        if (oActivity) {
            this.ActDetails = oActivity;
            this.ActvtId = oActivity.ActivityId;
            this.ActTypeDesc = oActivity.ActTypeDesc;
            this.ActAsstId = oActivity.ActAsstId;
            if (this.CostTypeId === "2") {
                this.CostTypeId = "2";
                this.CostTypeValue = this.user.CostCenter;
            } else {
                if (this.CostTypeId !== "3") {
                    this.CostTypeValue = oActivity.CostTypeValue;
                    if (oActivity.CostTypeName.toUpperCase() === "OPPORTUNITY") {
                        this.CostTypeId = "1";
                    } else if (oActivity.CostTypeName.toUpperCase() === "ACCOUNT") {
                        this.CostTypeId = "4";
                    } else {
                        this.CostTypeId = "2";
                    }
                }
            }

        }
        // await this.setCostTypeName();
    }

    async setCostTypeName() {
        const that = this;
        const oMtrSettingsModel = sap.ui.getCore().getModel("mtrSettings");
        if (that.CostTypeId === "1") {
            const aOpportunities = this.user.opportunities;
            const aNONVatOppData = this.user.aNONVatOppData || [];
            // let oSelectedOppDataForNonVat = oStorageModel.getProperty("/oSelectedOppDataForNonVat") || {};

            let selectedNonVATOppData = {};

            let oSelectedOppDataForNonVat = Object.keys(selectedNonVATOppData);
            let oOpportunity = aOpportunities.find(item => item.OpportunityID === that.CostTypeValue);
            if (oOpportunity) {
                that.OpportunityID = that.CostTypeValue;
                that.OpportunityName = oOpportunity.OpportunityName;
                that.AccountID = oOpportunity.AccountID;
                that.AccountName = oOpportunity.AccountName;
                // return oOpportunity.OpportunityName;
                that.CostTypeName = oOpportunity.OpportunityName;
            } else {
                let sOpportunityName = "";
                //If CostType Value is of NON-VAT
                oOpportunity = aNONVatOppData.find(item => item.OpportunityId === that.CostTypeValue) || false;

                //if opp data is not found
                if (!oOpportunity && oSelectedOppDataForNonVat && Object.values(oSelectedOppDataForNonVat).length) {
                    oOpportunity = (that.CostTypeValue === oSelectedOppDataForNonVat.OpportunityId) ? oSelectedOppDataForNonVat : false;
                }

                if (oOpportunity && "OpportunityName" in oOpportunity) {
                    sOpportunityName = oOpportunity.OpportunityName;
                }

                if (oOpportunity) {
                    that.OpportunityID = that.CostTypeValue;
                    that.OpportunityName = sOpportunityName;
                    that.AccountID = oOpportunity.AccountID;
                    that.AccountName = oOpportunity.AccountName;
                    that.CostTypeName = oOpportunity.OpportunityName;
                } else {
                    //Worst-case if still opp data is not found;
                    if (that.CostTypeValue) {
                        let aFilters = [];
                        aFilters.push(new Filter({
                            path: "OPPT_ID",
                            operator: sap.ui.model.FilterOperator.Contains,
                            value1: that.CostTypeValue
                        }));
                        let aSearchFilter = new Filter({
                            filters: aFilters,
                            and: true
                        });
                        let mParameters = {
                            filters: aSearchFilter,
                        };
                        let aResponse = await OpportunityUtil.fnSetFormatParamsForNonVATOppData(mParameters);
                        if (aResponse && aResponse instanceof Array && aResponse.length) {
                            oOpportunity = aResponse[0];
                        }

                        that.OpportunityID = that.CostTypeValue;
                        that.OpportunityName = (oOpportunity && oOpportunity.hasOwnProperty("OpportunityName")) ? oOpportunity.OpportunityName :
                            "Not Applicable";
                        that.AccountID = (oOpportunity && oOpportunity.hasOwnProperty("AccountId")) ? oOpportunity.AccountId : "Not Applicable";
                        that.AccountName = (oOpportunity && oOpportunity.hasOwnProperty("AccountName")) ? oOpportunity.AccountName : "Not Applicable";
                        that.CostTypeName = (oOpportunity && oOpportunity.hasOwnProperty("OpportunityName")) ? oOpportunity.OpportunityName :
                            "Not Applicable";

                    } else {
                        that.OpportunityID = that.CostTypeValue;
                        that.OpportunityName = "Not Applicable";
                        that.AccountID = "Not Applicable";
                        that.AccountName = "Not Applicable";
                        that.CostTypeName = "Not Applicable";
                    }
                }
            }
        } else if (that.CostTypeId === "4") {
            const aAccounts = this.user.to_ACCOUNT;
            const oAccount = aAccounts.find(item => item.AccountId === that.CostTypeValue);
            if (oAccount) {
                // return oAccount.AccountDesc;
                that.CostTypeName = oAccount.AccountDesc;
                that.OpportunityID = "";
                that.OpportunityName = "";
                that.AccountID = that.CostTypeValue;
                that.AccountName = oAccount.AccountDesc;
            } else {
                if (that.CostTypeValue) {
                    const oResponse = await this.OpportunityService.getBusinessPartnerAttribSet(that.CostTypeValue);
                    that.CostTypeName = (oResponse && oResponse.data) ? oResponse.data.PARTNER_NAME : "Not Applicable";
                    that.OpportunityID = "";
                    that.OpportunityName = "";
                    that.AccountID = that.CostTypeValue;
                    that.AccountName = (oResponse && oResponse.data) ? oResponse.data.PARTNER_NAME : "Not Applicable";
                }
            }
        }
    }

    

    setLocationName() {
        var oLocation = null;
        var that = this;
        const oSettingsModel = MTRModels.getMTRSettingsModel();

        var aMTRTasks = oSettingsModel.getProperty("/MTRTasks");
        var oTask = aMTRTasks.find(function (task) {
            return task.TaskId === that.TaskId;
        });
        if (oTask) {
            if (oTask.Locations.length > 0) {
                oLocation = oTask.Locations.find(function (item) {
                    return item.LocationId === that.LocationId;
                });
            }
        }
        that.LocationName = (oLocation) ? oLocation.LocationName : "NA";
    }

    setTypeExportName() {
        const that = this;
        const oSettingsModel = MTRModels.getMTRSettingsModel();

        if (!this.CostTypeId || this.CostTypeId === "") {
            this.TypeExportName = "";
        }
        if (this.CostTypeId.toString() === "1") {
            var oOpportunity = oSettingsModel.getProperty("/Opportunities").find(function (o) {
                return that.CostTypeValue !== "" && parseInt(o.OpportunityID, 10) === parseInt(that.CostTypeValue, 10);
            });
            if (oOpportunity) {
                this.TypeExportName = "Opportunity: " + oOpportunity.AccountName + ": " + oOpportunity.OpportunityID + ": " + oOpportunity.OpportunityName;
            } else {
                this.TypeExportName = "Opportunity: " + that.CostTypeValue;
            }
        } else if (this.CostTypeId.toString() === "2") {
            this.TypeExportName = "Cost Center: " + oSettingsModel.getProperty("/CostCenter");
        } else if (this.CostTypeId.toString() === "3") {
            var aManualIO = oSettingsModel.getProperty("/to_MANUAL");
            var oManualIO = aManualIO.find(function (manualIO) {
                return manualIO.ManualIOID === that.CostTypeValue;
            });
            if (oManualIO) {
                this.TypeExportName = "Manual IO: " + oManualIO.ManualIOID + ": " + oManualIO.ManualIODesc;
            } else {
                this.TypeExportName = "Manual IO: " + that.CostTypeValue;
            }

        } else if (this.CostTypeId.toString() === "4") {
            var aAccount = oSettingsModel.getProperty("/to_ACCOUNT");
            var oAccount = aAccount.find(function (account) {
                return account.AccountId === that.CostTypeValue;
            });
            if (oAccount) {
                this.TypeExportName = "Account Id: " + oAccount.AccountId + ": " + oAccount.AccountDesc;
            } else {
                this.TypeExportName = "Account Id: " + that.CostTypeValue;
            }

        } else if (this.CostTypeId.toString() === "5") {
            this.TypeExportName = "Placeholder: " + this.CostTypeValue;
        }
    }
    

    setRecordDate(recordDate) {
        const that = this;
        // const oSettingsModel = MTRModels.getMTRSettingsModel();
        //  var sTimeMatrics = oSettingsModel.getProperty("/TimeMatrics");
        this.recordDate = recordDate || this.genericDateFormat.format(new Date());
        this.date = (recordDate) ? DateUtil.formatStringDate(recordDate) : new Date();

        const authState = AuthState.getInstance();
        const user = authState.getData();
        const startDayOfWeek = user.time.startDayOfWeek;
        var isWeekend = this.getIsWeekends(startDayOfWeek);


        const targetHourState = TargetHourState.getInstance();
        const targetHours = targetHourState.getData();
        const dateFormat = user.time.dateFormat;





        var sDateFormat = this.user.DateFormat;
        var oDateFormat = this.user.dateFormats || [];
        oDateFormat = oDateFormat.find(function (d) {
            return d.ID === sDateFormat;
        });
        this.FormattedRecordDate = (oDateFormat) ? this.dateServicesInstance.formatStringDate(this.RecordDate,
            oDateFormat.Value) : this.RecordDate;
        this.FormattedLongDate = this.dateServicesInstance.formatStringDate(this.RecordDate, "EEEE, MMMM dd, y");
        if (targetHours.length > 0) {
            var oTargetHour = targetHours.find(function (item) {
                return item.Date === that.RecordDate;
            });

            if (oTargetHour) {
                this.DateType = oTargetHour.Datetype;
                var fTargetHours = parseFloat(oTargetHour.Targethours);
                if (!isNaN(fTargetHours) && fTargetHours !== 0) {
                    if (this.user.timeMatrics === "H") {
                        this.Expected = fTargetHours.toString();
                    } else {
                        this.Expected = "1";
                    }
                } else {
                    this.Expected = "0";
                }
            } else {
                this.DateType = (isWeekend) ? "OFF" : "WORK";
                if (this.user.timeMatrics === "H" && !isWeekend) {
                    this.Expected = "8";
                } else if (this.user.timeMatrics !== "H" && !isWeekend) {
                    this.Expected = "1";
                } else {
                    this.Expected = "0";
                }
            }
        } else {
            this.DateType = (isWeekend) ? "OFF" : "WORK";
            if (this.user.timeMatrics === "H" && !isWeekend) {
                this.Expected = "8";
            } else if (this.user.timeMatrics !== "H" && !isWeekend) {
                this.Expected = "1";
            } else {
                this.Expected = "0";
            }
        }

        var dDate = new Date(this.RecordDate.substring(0, 4) + "/" + this.RecordDate.substring(4, 6) + "/" + this.RecordDate.substring(
            6, 8));
        this.StartDateOfWeek = this.dateServicesInstance.format(this.dateServicesInstance.getStartDateOfWeek(dDate), "yMMdd");

        this.IsSubmitEnabled = this.validateISPFutureDate();

    }

    getIsWeekends(iStartDayfOfWeek) {
        //var	iStartDayfOfWeek = parseInt(this.getStartDayOfWeek(), 10);
        var firstWeekend = 5 + iStartDayfOfWeek;
        if (firstWeekend > 6) {
            firstWeekend = firstWeekend - 7;
        }

        var secondWeekend = 6 + iStartDayfOfWeek;
        if (secondWeekend > 6) {
            secondWeekend = secondWeekend - 7;
        }

        var dRecordDate = this.dateServicesInstance.formatStringDate(this.RecordDate);
        var iRecordDay = dRecordDate.getDay();
        if (iRecordDay === firstWeekend || iRecordDay === secondWeekend) {
            return true;
        } else {
            return false;
        }
    } */



    /* duplicate(sDate) {
        var dDate = this.dateServicesInstance.formatStringDate(sDate);
        var startDateOfWeek = this.dateServicesInstance.format(this.dateServicesInstance.getStartDateOfWeek(dDate, 1), "yMMdd");
        return new Entry({
            TaskId: this.TaskId,
            TaskIdTemp: this.TaskIdTemp,
            TaskIdValueState: sap.ui.core.ValueState.None,
            PreviousTaskId: this.PreviousTaskId,
            ActvtId: this.ActvtId,
            ActvtDesc: this.ActvtDesc,
            LocationId: this.LocationId,
            LocationIdValueState: sap.ui.core.ValueState.None,
            PreviousLocationId: this.PreviousLocationId,
            CostTypeId: this.CostTypeId,
            CostTypeIdValueState: sap.ui.core.ValueState.None,
            PreviousCostTypeId: this.PreviousCostTypeId,
            CostTypeValue: this.CostTypeValue,
            CostTypeValueState: sap.ui.core.ValueState.None,
            PreviousCostTypeValue: this.PreviousCostTypeValue,
            RecordDate: sDate,
            WorkDuration: this.WorkDuration,
            WorkDurationValueState: sap.ui.core.ValueState.None,
            PreviousDuration: this.PreviousDuration,
            Note: this.Note,
            PreviousNote: this.PreviousNote,
            DateType: this.DateType,
            Timestamp: "",
            Unit: this.Unit,
            StatusId: "",
            DataFrom: "",
            Indicator: "C",
            IsModified: this.IsModified,
            StartDateOfWeek: startDateOfWeek,
            SelectedCategory: this.SelectedCategory,
            SelectedCategoryTemp: this.SelectedCategoryTemp,
            IsLocation: this.IsLocation,
            IsLocationTemp: this.IsLocationTemp,
            // CostTypeIndex: this.CostTypeIndex,
            // CostTypeIndexTemp: this.CostTypeIndexTemp,
            // LocationIndex: this.LocationIndex,
            // LocationIndexTemp: this.LocationIndexTemp,
            // IsAddNoteVisible: this.IsAddNoteVisible,
            // IsDoneVisible: this.IsDoneVisible,
            // IsExpanded: this.IsExpanded,
            // ValueStateText: this.ValueStateText,
            // Locations: this.Locations,
            // CostTypes: this.copyCostTypes(),
            TaskName: this.TaskName,
            LocationName: this.LocationName,
            CostTypeName: this.CostTypeName,
            FormattedRecordDate: this.FormattedRecordDate
        });
    } */

    /* copyCostTypes() {
        var costTypes = [];
        for (var i = 0; i < this.CostTypes.length; i++) {
            costTypes.push(new MTRCostType({
                CostTypeID: this.CostTypes[i].CostTypeId,
                CostTypeName: this.CostTypes[i].CostTypeName
            }));
        }
        return costTypes;
    }

    copyLocations() {
        var locations = [];
        for (var i = 0; i < this.Locations.length; i++) {
            locations.push(new MTRLocation({
                LocationId: this.Locations[i].LocationId,
                LocationName: this.Locations[i].LocationName
            }));
        }
        return locations;
    }

    setBlank() {
        this.MtrUid = this.generateGUID().toUpperCase();
        this.IspGuid = "";
        this.WorkDuration = "";
        this.PreviousDuration = "";
        this.Note = "";
        this.PreviousNote = "";
        this.StatusId = "";
        this.DataFrom = "";
        this.Indicator = "";
        this.IsModified = false;
        this.Busy = false;
    }

    blankPrevious() {
        this.PreviousTaskId = "";
        this.PreviousLocationId = "";
        this.PreviousCostTypeId = "";
        this.PreviousCostTypeValue = "";
        this.PreviousDuration = "";
        this.PreviousNote = "";
    }

    getCostTypeChar() {
        var costTypeChar;
        switch (this.CostTypeId) {
            case "1":
                costTypeChar = "O";
                break;
            case "2":
                costTypeChar = "C";
                break;
            case "3":
                costTypeChar = "M";
                break;
            case "4":
                costTypeChar = "A";
                break;
            default:
                costTypeChar = "P";
                break;
        }
        return costTypeChar;
    }

    

    

    

    

    

    getTask() {
        var that = this;
        var oTask = {
            TaskType: "",
            SubTaskType: ""
        };
        const oSettingsModel = MTRModels.getMTRSettingsModel();

        var oTask = oSettingsModel.getProperty("/MTRTasks").find(function (item) {
            return item.TaskId.toString() === that.TaskId.toString();
        });
        if (oTask) {
            if (oTask.EssInMu && oSettingsModel.getProperty("/BelongEss") === "1") {
                oTask.TaskType = "ADMI";
                oTask.SubTaskType = "ALLOTHR";
            } else {
                oTask.TaskType = oTask.IspTask;
                oTask.SubTaskType = oTask.IspSubTask;
            }
        }
        return oTask;
    }

    getISRequest(mParameters) {
        const that = this;
        const oSettingsModel = MTRModels.getMTRSettingsModel();
        const oStaffingModel = MTRModels.getStaffingModel();
        const aStaffingRecord = oStaffingModel.getData();
        const oResourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
        let timeMatrics = "H";
        if (oSettingsModel.getProperty("/TimeMatrics") === "D") {
            timeMatrics = "TA";
        }
        let isKS = true;
        let sRaccobjText = oSettingsModel.getProperty("/CostCenterName");
        let sObjnr = oSettingsModel.getProperty("/Objnr");
        let sInternalOrder = "";
        let sRaufnr = "";
        let sObart = "KS";
        if (this.CostTypeId === "1") {
            const oOpportunity = this.user.opportunities.find(function (item) {
                return item.OpportunityID === that.CostTypeValue;
            });
            if (oOpportunity) {
                sInternalOrder = oOpportunity.AssociatedIO;
            }

            if (oOpportunity && oOpportunity.IOSetting === "Yes") {
                isKS = false;
                if ((!sInternalOrder || sInternalOrder === "") && mParameters.Indicator !== "D") {
                    var sDescription = oResourceBundle.getText("blankIOMsgDesc", [this.CostTypeValue]);
                    var oMessage = new Message({
                        Type: sap.ui.core.MessageType.Error,
                        Title: oResourceBundle.getText("blankIOMsg"),
                        Description: sDescription,
                        Subtitle: ""
                    });
                    let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
                    oMessage.addToMessages(this.MtrUid, activityId);
                    this.setValueState("WorkDurationValueState", sap.ui.core.ValueState.Error);
                    this.WorkDurationValueStateText = "IO not associated with Opportunity";
                    MessageToast.show(this.WorkDurationValueStateText);
                    return null;
                }
            } else if (oOpportunity && oOpportunity.IOSetting === "Error") {
                isKS = false;
                var sDescriptionProduct = oResourceBundle.getText("noCloudAndPreIOMsgDesc", [this.CostTypeValue]);
                var oMessageProduct = new Message({
                    Type: sap.ui.core.MessageType.Error,
                    Title: oResourceBundle.getText("noCloudAndPreIOMsg"),
                    Description: sDescriptionProduct,
                    Subtitle: ""
                });
                let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
                oMessageProduct.addToMessages(this.MtrUid, activityId);
                this.setValueState("WorkDurationValueState", sap.ui.core.ValueState.Error);
                this.WorkDurationValueStateText = oResourceBundle.getText("noCloudAndPreIOMsg");
                MessageToast.show(this.WorkDurationValueStateText);
                return null;

            } else if (!oOpportunity || (oOpportunity && oOpportunity.IOSetting === "")) {
                isKS = false;
                var sDescriptionNoAcc = oResourceBundle.getText("noAccessOppDesc", [this.CostTypeValue]);
                var oMessageNoAcc = new Message({
                    Type: sap.ui.core.MessageType.Error,
                    Title: oResourceBundle.getText("noAccessOppMsg"),
                    Description: sDescriptionNoAcc,
                    Subtitle: ""
                });
                let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
                oMessageNoAcc.addToMessages(this.MtrUid, activityId);
                this.setValueState("WorkDurationValueState", sap.ui.core.ValueState.Error);
                this.WorkDurationValueStateText = oResourceBundle.getText("noAccessOppMsg");
                MessageToast.show(this.WorkDurationValueStateText);
                return null;

            } else if (oOpportunity && oOpportunity.isAllowed === false) {
                isKS = false;
                if (oOpportunity && oOpportunity.REPLACED_BY) {
                    var isRepOpp = this.user.opportunities.find(function (item) {
                        return item.OpportunityID === oOpportunity.REPLACED_BY;
                    });
                }
                var sDescriptionReplace = (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && isRepOpp) ? oResourceBundle.getText(
                    "gracePerWithRepBy", [
                    this.CostTypeValue, oOpportunity.REPLACED_BY
                ]) : (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && !isRepOpp) ? oResourceBundle.getText(
                    "gracePerWithRep", [
                    this.CostTypeValue, oOpportunity.REPLACED_BY
                ]) : oResourceBundle.getText("noGracePerDesc", [this.CostTypeValue]);
                var oMessageReplace = new Message({
                    Type: sap.ui.core.MessageType.Error,
                    Title: oResourceBundle.getText("noGracePerMsg"),
                    Description: sDescriptionReplace,
                    Subtitle: ""
                });
                let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
                oMessageReplace.addToMessages(this.MtrUid, activityId);
                this.setValueState("WorkDurationValueState", sap.ui.core.ValueState.Error);
                this.WorkDurationValueStateText = oResourceBundle.getText("noGracePerMsg");
                MessageToast.show(this.WorkDurationValueStateText);
                return null;

            } else if (oOpportunity && oOpportunity.isAllowedStat === false) {
                isKS = false;
                if (oOpportunity && oOpportunity.REPLACED_BY) {
                    var isRepOpp = this.user.opportunities.find(function (item) {
                        return item.OpportunityID === oOpportunity.REPLACED_BY;
                    });
                }
                var sDescriptionStat = (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && isRepOpp) ? oResourceBundle.getText(
                    "gracePerStatWithRepBy", [
                    this.CostTypeValue, oOpportunity.REPLACED_BY
                ]) : (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && !isRepOpp) ? oResourceBundle.getText(
                    "gracePerStatWithRep", [
                    this.CostTypeValue, oOpportunity.REPLACED_BY
                ]) : oResourceBundle.getText("noGracePerStatDesc", [this.CostTypeValue]);
                var oMessageStat = new Message({
                    Type: sap.ui.core.MessageType.Error,
                    Title: oResourceBundle.getText("noGracePerStatDesc"),
                    Description: sDescriptionStat,
                    Subtitle: ""
                });
                let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
                oMessageStat.addToMessages(this.MtrUid, activityId);
                this.setValueState("WorkDurationValueState", sap.ui.core.ValueState.Error);
                this.WorkDurationValueStateText = oResourceBundle.getText("noGracePerStatDesc");
                MessageToast.show(this.WorkDurationValueStateText);
                return null;

            }
        } else if (this.CostTypeId === "3") {
            isKS = false;
            sInternalOrder = this.CostTypeValue;
        }

        if (!isKS && sInternalOrder && sInternalOrder !== "") {
            var oStaffingRecord = aStaffingRecord.find(function (item) {
                return item.InternalOrder !== "" && item.InternalOrder === sInternalOrder;
            });
            if (oStaffingRecord) {
                sObart = oStaffingRecord.Obart;
                sObjnr = oStaffingRecord.Objnr;
                sRaccobjText = oStaffingRecord.Description;
                sRaufnr = oStaffingRecord.Raufnr;
            }
        }

        this.Note = (this.Note && this.Note !== "") ? this.Note : this.getTask().TaskType;

        var oData = {
            "Taskcounter": this.TaskCounter,
            "Testrun": "",
            "Version": "",
            "Msgno": "P",
            "Msgtxt": "",
            "Activity": [{
                "Taskcounter": this.TaskCounter,
                "Counter": this.Counter,
                "Taskcomponent": mParameters.TaskComponent,
                "Pflag": mParameters.Indicator,
                "Pernr": mParameters.PersonalNumber,
                "Workdate": this.RecordDate,
                "Skostl": (mParameters.Indicator === "D" && mParameters.TaskComponent !== "WORKSTAT" && mParameters.TaskComponent !==
                    "WDAYSST") ? mParameters.CostCenter : "",
                "Unit": timeMatrics,
                "Catsquantity": this.WorkDuration.toString(),
                "Waers": "",
                "Catsamount": "0.00",
                "Status": "",
                "Ltxa1": (this.Note && this.Note !== "" && this.Note.length > 40) ? this.Note.substring(0, 40) : this.Note,
                "Rkostl": (isKS) ? mParameters.CostCenter : "",
                "Rproj": "",
                "Raufnr": (isKS) ? "" : sRaufnr,
                "Rnplnr": "",
                "Raufpl": "",
                "Raplzl": "",
                "Vornr": "",
                "Rkdauf": "",
                "Rkdpos": "",
                "Lstnr": "",
                "Tasktype": (this.getTask().TaskType && this.getTask().TaskType !== "") ? this.getTask().TaskType : mParameters.IspTask,
                "Tasktypetext": mParameters.IspTaskdes,
                "Tasklevel": mParameters.TaskLevel,
                "Raccobj": (isKS) ? "Cost center" : "Order",
                "Raccobj_text": sRaccobjText,
                "Raccobj_genrec": (isKS) ? this.getRaccobjGenrec(sObjnr, sObart, mParameters.CostCenter) : sInternalOrder,
                "Zzsubtype": (this.getTask().SubTaskType && this.getTask().SubTaskType !== "") ? this.getTask().SubTaskType : mParameters.IspSubTask,
                "Zz_npktxt": this.getLocationChar() + this.MtrUid + "~" + this.CostTypeId + this.CostTypeValue,
                "Zz_location": this.getISXLocationChar(),
                "Zzpsptxt": "",
                "Zzcontpers": this.getContactPerson(),
                "Zz_projn": "",
                "Zzbyd": "",
                "Zcpr_guid": "",
                "Zcpr_extid": "",
                "Zcpr_objguid": "",
                "Zcpr_objgextid": "",
                "Zcpr_objtype": "",
                "Obart": sObart,
                "Objnr": sObjnr,
                "Essposting": "",
                "Tmp_key": "",
                "Trv_rkdauf": "",
                "Trv_rkdpos": "",
                "Zz_rel_obj": "",
                "Newo2c": "",
                "Msgno": "P",
                "Msgtxt": "",
                "Zzmoberrflag": ""
            }]
        };

        if (!mParameters.IsSubmit) {
            return oData;
        }
        var isISPDataValid = this.validateISXEntry(true);
        if (isISPDataValid && mParameters.IsSubmit) {
            return {
                isValid: isISPDataValid,
                data: oData
            };
        } else if (!isISPDataValid && mParameters.IsSubmit) {
            return {
                isValid: isISPDataValid,
                data: oData,
                msg: this.ErrorMsg
            };
        }
    }

    

    compare(oData) {
        return (this.MtrUid === oData.MtrUid &&
            this.IspGuid === oData.IspGuid &&
            this.TaskId === oData.TaskId &&
            this.LocationId === oData.LocationId &&
            this.CostTypeId === oData.CostTypeId &&
            this.CostTypeValue === oData.CostTypeValue &&
            this.RecordDate === oData.RecordDate &&
            this.WorkDuration === oData.WorkDuration &&
            this.Note === oData.Note);
    }

    validate(highlightError, showMsg, isSubmit) {
        var isValid = true;

        if (isNaN(parseFloat(this.WorkDuration))) {
            if (highlightError) {
                this.setValueState("WorkDurationValueState", sap.ui.core.ValueState.Error);
            }
            isValid = false;
        } else {
            this.setValueState("WorkDurationValueState", sap.ui.core.ValueState.None);
        }

        if (!this.TaskId || this.TaskId === "") {
            if (highlightError) {
                this.setValueState("TaskIdValueState", sap.ui.core.ValueState.Error);
            }
            isValid = false;
        } else {
            this.setValueState("TaskIdValueState", sap.ui.core.ValueState.None);
        }

        if (this.Locations && this.Locations.length > 0 && (!this.LocationId || this.LocationId === "")) {
            if (highlightError) {
                this.setValueState("LocationIdValueState", sap.ui.core.ValueState.Error);
            }
            isValid = false;
        } else {
            this.setValueState("LocationIdValueState", sap.ui.core.ValueState.None);
        }

        if (this.CostTypes && this.CostTypes.length > 0 && (!this.CostTypeId || this.CostTypeId === "")) {
            if (highlightError) {
                this.setValueState("CostTypeIdValueState", sap.ui.core.ValueState.Error);
            }
            isValid = false;
        } else {
            this.setValueState("CostTypeIdValueState", sap.ui.core.ValueState.None);
        }

        if (!this.CostTypeValue || this.CostTypeValue === "") {
            if (this.CostTypeId === "2" || this.CostTypeId === 2) {
                const oSettingsModel = MTRModels.getMTRSettingsModel();
                this.CostTypeValue = oSettingsModel.getProperty("/CostCenter");
            } else {
                if (highlightError) {
                    this.setValueState("CostTypeValueState", sap.ui.core.ValueState.Error);
                }
                isValid = false;
            }
        } else {
            this.setValueState("CostTypeValueState", sap.ui.core.ValueState.None);
        }

        if (isSubmit && !this.validateISXEntry()) {
            isValid = false;
        }

        if (!isValid && showMsg) {
            MessageToast.show("Please select mandatory fields");
        }

        return isValid;
    }

    getISModified() {
        return (this.DataFrom !== "I" || (this.DataFrom === "I" && this.Indicator !== ""));
    }

    getModified() {
        var isModified = false;
        if (this.Locations.length > 0) {
            if (
                this.WorkDuration !== "" &&
                (this.LocationId && this.LocationId !== "") &&
                this.CostTypes.length > 0 && this.CostTypeId && this.CostTypeId !== "" &&

                ((this.WorkDuration !== this.PreviousDuration) ||
                    (this.TaskId !== this.PreviousTaskId) ||
                    (this.LocationId !== this.PreviousLocationId) ||
                    (this.CostTypeId !== this.PreviousCostTypeId) ||
                    (this.CostTypeValue !== this.PreviousCostTypeValue) ||
                    (this.Note !== this.PreviousNote))) {
                isModified = true;
            }
        } else {
            if (
                this.WorkDuration !== "" &&
                this.LocationId === "" &&
                this.CostTypes.length > 0 && this.CostTypeId && this.CostTypeId !== "" &&
                ((this.WorkDuration !== this.PreviousDuration) ||
                    (this.TaskId !== this.PreviousTaskId) ||
                    (this.LocationId !== this.PreviousLocationId) ||
                    (this.CostTypeId !== this.PreviousCostTypeId) ||
                    (this.CostTypeValue !== this.PreviousCostTypeValue) ||
                    (this.Note !== this.PreviousNote))) {
                isModified = true;
            }
        }
        return isModified;
    }

    generateGUID() {
        var sPersonalNumber = this.user.personalNumber;
        return sPersonalNumber + this.uniqueIdTimeStamp.format(new Date()) + Math.floor(100 + Math.random() *
            900) + "MTR";
    }

    validateISPFutureDate() {
        const currentDate = new Date();
        const dFutureDate = new Date(currentDate.setDate(currentDate.getDate() + 7));
        dFutureDate.setHours(0, 0, 0, 0);
        // const dRecordDate = new Date(this.FormattedRecordDate);
        var dRecordDate = new Date(this.RecordDate.substring(0, 4) + "/" + this.RecordDate.substring(4, 6) + "/" + this.RecordDate.substring(
            6, 8));
        if (dRecordDate >= dFutureDate) {
            return false;
        } else {
            return true;
        }
    }

    setCreationDate(sTimestamp) {
        let dCreatedOn = new Date();
        if (sTimestamp) {
            dCreatedOn = new Date(sTimestamp.substring(0, 4) + "/" + sTimestamp.substring(4, 6) + "/" + sTimestamp.substring(6, 8) + " " +
                sTimestamp.substring(8, 10) + ":" + sTimestamp.substring(10, 12) + ":" + sTimestamp.substring(12, 14));
            this.CreatedOn = dCreatedOn;
        }
    }

    getIOStaffing() {
        const that = this;
        const oResourceBundle = sap.ui.getCore().getModel("i18n");
        const staffingRecord = this.user.staffing;
        const opportunities = this.user.opportunities;
        const manualIos = this.user.to_MANUAL;
        let opportunity = null;
        let manualIo = null;
        this.IOStaffing = null;
        let internalOrder = "";
        let isOpportunity = true;
        let isValid = false;
        if (this.CostTypeId === "1" || this.CostTypeId === 1 || this.CostTypeId === "3" || this.CostTypeId === 3) {
            if (this.CostTypeId === "1" || this.CostTypeId === 1) {
                opportunity = opportunities.find(function (item) {
                    return item.OpportunityID === that.CostTypeValue;
                });
                if (opportunity && opportunity.IOSetting === "Yes" && opportunity.AssociatedIO && opportunity.AssociatedIO !== "") {
                    internalOrder = opportunity.AssociatedIO;
                } else {
                    return true;
                }
            } else if ((this.CostTypeId === "3" || this.CostTypeId === 3) && this.CostTypeValue && this.CostTypeValue !== "") {
                manualIo = manualIos.find(function (item) {
                    return item.ManualIOID === that.CostTypeValue;
                });
                if (manualIo) {
                    internalOrder = this.CostTypeValue;
                }
                isOpportunity = false;
            }
            const associatedIoData = staffingRecord.filter(function (item) {
                return internalOrder !== "" && item.InternalOrder === internalOrder;
            });
            if (associatedIoData) {
                const task = this.tasks.find(function (item) {
                    return item.taskId.toString() === that.TaskId.toString();
                });

                const taskTypes = [];
                const taskLevels = [];
                let oCurrentStaffing, sRecordDate, dRecordDate, dEndDate, dStartDate;
                const staffingData = [];
                let remainingDays;
                const dateFormat = this.user.dateFormats.find(function (d) {
                    return d.ID === that.user.dateFormat;
                });
                if (associatedIoData && task) {
                    associatedIoData.sort(function (a, b) {
                        const dT1 = that.this.user.DateFormat.formatStringDate(a.EndDate);
                        const dT2 = that.dateServicesInstance.formatStringDate(b.EndDate);
                        return dT2 > dT1 ? -1 : 1;
                    });
                    for (let i = 0; i < associatedIoData.length; i++) {

                        remainingDays = (parseFloat(associatedIoData[i].StaffedDays) - parseFloat(associatedIoData[i].RecordedDays)) + " " +
                            "Days Left";

                        staffingData.push({
                            Staffing: "Staffing " + (i + 1),
                            ID: (isOpportunity) ? opportunity.OpportunityID : manualIo.ManualIOID,
                            Name: (isOpportunity) ? opportunity.OpportunityName : manualIo.ManualIODesc,
                            Owner: (isOpportunity) ? opportunity.OwnerName : "",
                            AccountID: (isOpportunity) ? opportunity.AccountID : "",
                            AccountName: (isOpportunity) ? opportunity.AccountName : "",
                            InternalOrder: internalOrder,
                            StaffedDays: associatedIoData[i].StaffedDays,
                            StartDate: this.dateServicesInstance.formatStringDate(associatedIoData[i].StartDate, dateFormat.Value),
                            EndDate: this.dateServicesInstance.formatStringDate(associatedIoData[i].EndDate, dateFormat.Value),
                            TaskType: associatedIoData[i].TaskType,
                            TaskLevel: associatedIoData[i].TaskLevel,
                            IsOpportunity: isOpportunity,
                            RemainingDays: remainingDays,
                            Analytics: [{
                                "Staffing": oResourceBundle.getText("recordedDays"),
                                "Days": parseFloat(associatedIoData[i].RecordedDays)
                            }, {
                                "Staffing": oResourceBundle.getText("remainingDays"),
                                "Days": parseFloat(associatedIoData[i].StaffedDays) - parseFloat(associatedIoData[i].RecordedDays)
                            }]
                        });
                    }
                    this.IOStaffingList = staffingData;

                    for (let i = 0; i < associatedIoData.length; i++) {

                        remainingDays = (parseFloat(associatedIoData[i].StaffedDays) - parseFloat(associatedIoData[i].RecordedDays)) + " " +
                            oResourceBundle.getText("dayRemaining");

                        var taskType = taskTypes.find(function (item) {
                            return item === associatedIoData[i].TaskType;
                        });
                        if (!taskType) {
                            taskTypes.push(associatedIoData[i].TaskType);
                        }
                        var taskLevel = taskLevels.find(function (item) {
                            return item === associatedIoData[i].TaskLevel;
                        });
                        if (!taskLevel) {
                            taskLevels.push(associatedIoData[i].TaskLevel);
                        }
                        dStartDate = this.dateServicesInstance.formatStringDate(associatedIoData[i].StartDate);
                        dEndDate = this.dateServicesInstance.formatStringDate(associatedIoData[i].EndDate);
                        sRecordDate = this.RecordDate;
                        if (!sRecordDate) {
                            sRecordDate = this.StartDate;
                        }

                        dRecordDate = this.dateServicesInstance.formatStringDate(sRecordDate);
                        if (dStartDate && dEndDate && dStartDate <= dRecordDate && dEndDate >= dRecordDate) {
                            if (associatedIoData[i].TaskLevel === task.TaskLevel &&
                                associatedIoData[i].TaskType === task.IspTask) {
                                oCurrentStaffing = associatedIoData[i];
                                break;
                            } else if (associatedIoData[i].TaskType === "") {
                                oCurrentStaffing = associatedIoData[i];
                                break;
                            }

                        } else {
                            if (associatedIoData[i].TaskLevel === task.TaskLevel &&
                                associatedIoData[i].TaskType === task.IspTask) {
                                oCurrentStaffing = associatedIoData[i];

                            }
                            if (!oCurrentStaffing && associatedIoData[i].TaskType === "") {
                                oCurrentStaffing = associatedIoData[i];

                            }
                        }

                    }
                }
                if (oCurrentStaffing) {
                    sRecordDate = this.RecordDate;
                    if (!sRecordDate) {
                        sRecordDate = this.StartDate;
                    }
                    dRecordDate = this.dateServicesInstance.formatStringDate(sRecordDate);
                    dStartDate = this.dateServicesInstance.formatStringDate(oCurrentStaffing.StartDate);

                    dEndDate = this.dateServicesInstance.formatStringDate(oCurrentStaffing.EndDate);
                    remainingDays = (parseFloat(oCurrentStaffing.StaffedDays) - parseFloat(oCurrentStaffing.RecordedDays)) + " " +
                        "Days Left";
                    if (dEndDate && dEndDate < dRecordDate || dStartDate > dRecordDate) {
                        remainingDays = "Staffing Expired";
                    }
                    if ((dStartDate && dEndDate && dStartDate <= dRecordDate && dEndDate >= dRecordDate) || remainingDays === "Staffing Expired") {

                        var iOStaffing = {
                            Staffing: "Staffing",
                            ID: (isOpportunity) ? opportunity.OpportunityID : manualIo.ManualIOID,
                            Name: (isOpportunity) ? opportunity.OpportunityName : manualIo.ManualIODesc,
                            Owner: (isOpportunity) ? opportunity.OwnerName : "",
                            AccountID: (isOpportunity) ? opportunity.AccountID : "",
                            AccountName: (isOpportunity) ? opportunity.AccountName : "",
                            InternalOrder: internalOrder,
                            StaffedDays: oCurrentStaffing.StaffedDays,
                            StartDate: this.dateServicesInstance.formatStringDate(oCurrentStaffing.StartDate, dateFormat.Value),
                            EndDate: this.dateServicesInstance.formatStringDate(oCurrentStaffing.EndDate, dateFormat.Value),
                            TaskType: oCurrentStaffing.TaskType,
                            TaskLevel: oCurrentStaffing.TaskLevel,
                            IsOpportunity: isOpportunity,
                            RemainingDays: remainingDays,
                            Analytics: [{
                                "Staffing": "Recorded Days",
                                "Days": parseFloat(oCurrentStaffing.RecordedDays)
                            }, {
                                "Staffing": "Remaining Days",
                                "Days": parseFloat(oCurrentStaffing.StaffedDays) - parseFloat(oCurrentStaffing.RecordedDays)
                            }]
                        };

                        this.IOStaffing = iOStaffing;

                    }
                    isValid = true;
                }
            }
        }


        return isValid;
    } */
}

