import Object from "sap/ui/base/Object";
import InternalOrder from "com/melodylib/time/classes/InternalOrder";

/**
 * @namespace com.melodylib.core.classes.ManualIO
 */
export default class ManualIO extends Object {
    constructor(data) {
        if (data) {
            // this.internalOrder = data.internalOrder || "";
            this.internalOrder = data.internalOrder || new InternalOrder();
            this.description = data.description || "";
            this.dataFrom = data.dataFrom || "";
            this.indicator = data.indicator || "";
            this.createdOn = data.createdOn || "";
            this.updatedOn = data.updatedOn || "";
            this.isArchive = (data.isArchive === "X" || data.isArchive === true) ? true : false;
            this.isVisible = (data.isVisible === "X" || data.IsVisible === true || !this.isArchive) ? true : false;
        }
    }

    addStaffing(staffing) {
        this.internalOrder.staffings.push(staffing);
    }    

    getLSRequest(user) {
        const manualIO = {
            PrdProfMapId: user.time.profileId,
            UserGuid: user.time.guid,
            ManualIoId: this.internalOrder.id,
            ManualDesc: this.internalOrder.description,
            Indicator: this.indicator
        };
        if (this.isVisible === true || this.indicator === "C") {
            manualIO.IsArchive = "";
        } else if (this.isVisible === false) {
            manualIO.IsArchive = "X";
        }
        if (this.indicator === "D") {
            manualIO.IsArchive = "D";
        }
        return manualIO;
    }
}