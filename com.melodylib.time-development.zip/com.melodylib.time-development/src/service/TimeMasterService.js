import CoreService from "com/melodylib/core/service/CoreService";
import Filter from 	"sap/ui/model/Filter";

/**
 * @name com.melodylib.time.service.TimeMasterService
 */
export default class TimeMasterService extends CoreService {
    constructor() {
        super();
    }
    static getInstance() {
        if (!this.instance) {
            this.instance = new TimeMasterService();
        }
        return this.instance;
    }

    async getDomainHelp () {
        return this.odata("/YC_TRM_DOMAIN_HELP").get("mtr");	
    }

    async fetchMasterByProfileId(profileId) {
        const params = {
            expand: "to_Activity,to_Category,to_Location,to_CostType,to_Status,to_ActivityCostTypeMap,to_ActivityLocationMap"
        }
        const options = this.getUrlParameters(params);
        const projectType = "ACTVT";
        const result = await this.odata("/YC_TRM_Lookup(project_type='" + projectType +
            "',product_id=1,profile_id=" + parseInt(profileId, 10) + ")").get("mtr", options);
        return result.data;
    }
}