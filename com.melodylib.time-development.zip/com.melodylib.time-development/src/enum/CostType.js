sap.ui.define(
	{
		Opportunity: "1",
        CostCenter: "2",
        ManualIO: "3",
        Account: "4",
		Placeholder: "5"
	},
	true
);
