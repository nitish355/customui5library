sap.ui.define(
	{
		Saved: "1",
        InQueue: "2",
        Failed: "3",
        Submitted: "4"
	},
	true
);
