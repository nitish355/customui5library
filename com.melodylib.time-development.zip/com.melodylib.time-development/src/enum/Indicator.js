sap.ui.define(
	{
		Create: "C",
        Update: "U",
        Delete: "D",
        None: ""
	},
	true
);
