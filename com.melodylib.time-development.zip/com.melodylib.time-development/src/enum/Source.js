sap.ui.define(
	{
		LS: "L",
        ISP: "I",
        None: ""
	},
	true
);
