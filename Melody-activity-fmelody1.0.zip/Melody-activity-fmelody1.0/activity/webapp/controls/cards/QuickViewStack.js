sap.ui.define([
    "sap/ui/core/Control",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel"
], function (Control, Fragment, JSONModel) {
    "use strict";
    return Control.extend("com.melodysuite.activity.controls.cards.QuickViewStack", {
        metadata: {
            application: "com.melodysuite.activity",
            properties: {
                title: {
                    type: "string",
                    defaultValue: ""
                },
                subTitle: {
                    type: "string",
                    defaultValue: ""
                },
                value: {
                    type: "string",
                    defaultValue: "0"
                },
                total: {
                    type: "string",
                    defaultValue: "0"
                },
                linkText: { type: "string", defaultValue: "View All" }
            },
            aggregations: {
                _content: { type: "sap.ui.core.Control", multiple: false, visibility: "hidden" }
            },
            events: {
                press: {}
            }
        },
        renderer: {
            render(oRm, oControl) {
                oRm.openStart("div", oControl).openEnd();
                oRm.renderControl(oControl.getAggregation("_content"));
                oRm.close("div");
            }
        },

        init() {
            try {
                //initialisation code, in this case, ensure css is imported
                const applicationPath = jQuery.sap.getModulePath("com.melodysuite.activity");
                const cssPath = sap.ui.require.toUrl("com/melodysuite/activity/controls/cards/Style.css");
                jQuery.sap.includeStyleSheet(cssPath);

                this._internalModel = new JSONModel({});

                Fragment.load({
                    id: this.getId(),
                    name: "com.melodysuite.activity.controls.cards.QuickViewStack",
                    controller: this
                }).then((content) => {
                    const sideVBox = content?.getContent()[1] || false;
                    if (sideVBox) {
                        sideVBox.addEventDelegate({
                            onclick: (event) => {
                                this.firePress(event);
                            }
                        });
                    }
                    const cardData = {
                        title: this.getTitle(),
                        subtitle: this.getSubTitle(),
                        value: this.getValue(),
                        total: this.getTotal()
                    };
                    this._internalModel.setData(cardData);
                    this.setAggregation("_content", content);
                    this.setModel(this._internalModel, "quickStackModel");
                    this._internalModel.refresh();
                });
            } catch (error) {
                console.log("ERROR IN QUICKVIEWSTACKCARD : ", error)
            }
        }
    });
});