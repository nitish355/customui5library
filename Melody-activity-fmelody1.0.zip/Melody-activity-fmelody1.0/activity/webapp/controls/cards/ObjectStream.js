sap.ui.define([
    "sap/ui/core/Control",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel"
], function (Control, Fragment, JSONModel) {
    "use strict";
    return Control.extend("com.melodysuite.activity.controls.cards.ObjectStream", {
        metadata: {
            application: "com.melodysuite.activity",
            properties: {
                cardTitle: {
                    type: "string",
                    defaultValue: ""
                },
                icon: {
                    type: "string",
                    defaultValue: "sap-icon://request"
                },
                title: {
                    type: "string",
                    defaultValue: ""
                },
                subTitle: {
                    type: "string",
                    defaultValue: ""
                },
                displayTimeSection: {
                    type: "boolean",
                    defaultValue: false
                },
                formDetails: {
                    type: "object",
                    defaultValue: [{
                        title: "",
                        elements: []
                    }]
                },
                footer: {
                    type: "object",
                    defaultValue: []
                }
            },
            aggregations: {
                _objectstream: { type: "sap.ui.core.Control", multiple: false, visibility: "hidden" }
            },
            events: {
                press: {}
            }
        },


        renderer: {
            render(oRm, oControl) {
                oRm.openStart("div", oControl).openEnd();
                oRm.renderControl(oControl.getAggregation("_objectstream"));
                oRm.close("div");
            }
        },


        init() {
            try {
                //initialisation code, in this case, ensure css is imported
                const applicationPath = jQuery.sap.getModulePath("com.melodysuite.activity");
                const cssPath = sap.ui.require.toUrl("com/melodysuite/activity/controls/cards/Style.css");
                jQuery.sap.includeStyleSheet(cssPath);

                this._internalModel = new JSONModel({});

                Fragment.load({
                    id: this.getId(),
                    name: "com.melodysuite.activity.controls.cards.ObjectStream",
                    controller: this
                }).then((content) => {
                    const objectStreamData = {
                        icon: this.getIcon(),
                        title: this.getTitle(),
                        subTitle: this.getSubTitle(),
                        cardTitle: this.getCardTitle(),
                        displayTimeSection: this.getDisplayTimeSection()
                    };

                    const footerData = this.getFooter();
                    const formDetails = this.getFormDetails();
                    this._internalModel.setData(objectStreamData);
                    content.setModel(this._internalModel, "ctrlModel");
                    this.setModel(this._internalModel, "ctrlModel");
                    content.addStyleClass("sapUiSizeCompact");
                    this.createAndInsertFormElements(content, formDetails, footerData);
                    this.setAggregation("_objectstream", content);
                });
            } catch (error) {
                console.log("ERROR IN OBJECTSTREAMCARD : ", error)
            }
        },

        /**
         * @function _getGridContainers
         * @description function to get the grid container from the content
         * @param {object} content
         */
        _getGridContainers: function (content) {
            const grid = content.getContent()[0] || {};
            const gridContents = grid?.getContent() || [];
            return gridContents;
        },

        /**
         * @function _getFormContainer
         * @description function to get the form container from the content
         * @param {object} content
         */
        _getFormContainer: function (content) {
            try {
                const gridContents = this._getGridContainers(content);
                const formContainer = gridContents[2] || {}; //VBox which contains form
                return formContainer;
            } catch (error) {
                console.log("ERROR IN _getFormContainer : ", error);
                return false;
            }
        },

        /**
         * @function _getFooterPanel
         * @description function to get Panel container from content
         * @param {object} content
         */
        _getFooterPanel: function (content) {
            const gridContents = this._getGridContainers(content);
            const footerPanel = gridContents[gridContents.length - 1];
            return footerPanel;
        },

        /**
         * @function createAndInsertFormElements
         * @description function to create the form elements and its controls based on the formData
         * any change the ObjectStream layout change, the changes in this function must be handled accordingly in _getFormContainer
         * @param {object} content -> card contents
         * @param {array} formData -> form layout details
         * @param {array} footerData -> card footer layout details
         */
        createAndInsertFormElements: function (content, formData = [], footerData = []) {
            try {
                if (!formData[0].elements.length) {
                    return;
                }
                const formContainer = this._getFormContainer(content);
                if (!formContainer) {
                    return;
                }

                const footerPanel = this._getFooterPanel(content);
                for (let i = 0; i < formData.length; i++) {
                    const form = formData[i];
                    const formTitle = form.title;
                    let formCtrl = new sap.ui.layout.form.Form({
                        editable: false,
                        title: new sap.ui.core.Title({
                            text: formTitle
                        }),
                        layout: new sap.ui.layout.form.ColumnLayout(),
                        formContainers: [
                            new sap.ui.layout.form.FormContainer({
                                formElements: form.elements.map((item) => {
                                    return this.generateFormElement(item);
                                })
                            })
                        ]
                    }).addStyleClass("customObjectStreamForm");
                    formCtrl.addStyleClass("sapUiSizeCompact");
                    formCtrl.setTitle(formTitle);
                    formContainer.addItem(formCtrl);
                }
                this.addItemsToFooter(footerPanel, footerData);
            } catch (error) {
                console.log("ERROR IN createAndInsertFormElements : ", error);
            }
        },

        /**
         * @function generateFormElement
         * @description function to generate the form element
         * @param {object} ctrlData contains label, ctrlType and value Info
         */
        generateFormElement: function (ctrlData) {
            let field;
            let formElement = new sap.ui.layout.form.FormElement({
                label: ctrlData.label
            });
            switch (ctrlData.type) {
                case "LINK":
                    field = new sap.m.Link({
                        text: ctrlData.value
                    })
                    break;
                default:
                    field = new sap.m.Text({
                        text: ctrlData.value
                    });
            }
            formElement.addField(field);
            return formElement;
        },

        /**
         * @function addItemsToFooter
         * @description function to add items to footer
         * @param {object} footerPanel footer panel ctrl
         * @param {array} data contains footer data for buttons
         */
        addItemsToFooter: function (footerPanel, footerItems = []) {
            const toolbar = footerPanel.getContent()[0];
            for (let i = 0; i < footerItems.length; i++) {
                const item = footerItems[i];
                let content = "";
                switch (item.type) {
                    case "TOOLBARSPACER":
                        content = new sap.m.ToolbarSpacer();
                        break;
                    default:
                        content = new sap.m.Button({
                            text: item.text,
                            type: item.type,
                            icon: ("icon" in item) ? item.icon : "",
                            tooltip: item.tooltip,
                            press: function (event) {

                            }
                        });
                }
                toolbar.addContent(content);
            }
        },
    });
});