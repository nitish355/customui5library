sap.ui.define([
    "sap/ui/core/Control",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel"
], function (Control, Fragment, JSONModel) {
    "use strict";
    return Control.extend("com.melodysuite.activity.controls.cards.Comparision", {
        metadata: {
            application: "com.melodysuite.activity",
            properties: {
                text: {
                    type: "string",
                    defaultValue: ""
                },
                color: {
                    type: "string",
                    defaultValue: "#4a90e2"
                },
                percentage: {
                    type: "string",
                    defaultValue: "0"
                },
                value: {
                    type: "string",
                    defaultValue: "0"
                }
            },
            aggregations: {
                _content: { type: "sap.ui.core.Control", multiple: false, visibility: "hidden" }
            },
            events: {
                press: {}
            }
        },
        renderer: {
            render(oRm, oControl) {
                oRm.openStart("div", oControl).openEnd();
                oRm.renderControl(oControl.getAggregation("_content"));
                oRm.close("div");
            }
        },

        init() {
            try {
                //initialisation code, in this case, ensure css is imported
                const applicationPath = jQuery.sap.getModulePath("com.melodysuite.activity");
                const cssPath = sap.ui.require.toUrl("com/melodysuite/activity/controls/cards/Style.css");
                jQuery.sap.includeStyleSheet(cssPath);

                this._internalModel = new JSONModel({});

                Fragment.load({
                    id: this.getId(),
                    name: "com.melodysuite.activity.controls.cards.Comparision",
                    controller: this
                }).then((content) => {
                    const container = content;
                    const barVBox = content?.getItems()[1] || false;
                    const color = this.getColor() || this._generateRandomColor();

                    container.addEventDelegate({
                        onclick: (event) => {
                            this.firePress(event);
                        }
                    });

                    //Add Background to HBox
                    const fillBar = barVBox.getItems()[0];
                    fillBar.addEventDelegate({
                        onAfterRendering: function () {
                            fillBar.getDomRef().style.backgroundColor = color;
                        }
                    });



                    const cardData = {
                        text: this.getText(),
                        value: this.getValue(),
                        color: color,
                        percentage: this.getPercentage(),
                    };
                    this._internalModel.setData(cardData);
                    this.setAggregation("_content", content);
                    this.setModel(this._internalModel, "comparision");
                    this._internalModel.refresh();
                });
            } catch (error) {
                console.log("ERROR IN COMPARISION : ", error)
            }
        },

        /**
         * @function _generateRandomColor
         * @description function to generate a random hex color
         */
        _generateRandomColor: function () {
            return "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0");
        }


    });
});