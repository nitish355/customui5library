sap.ui.define(
  [
    "com/melodysuite/activity/service/CardService",
    "com/melodysuite/activity/controller/BaseController",
  ],
  function (CardService, BaseController) {
    "use strict";
    return BaseController.extend(
      "com.melodysuite.activity.cardcomponent.table.table",
      {
        onInit: function (oEvent) {
          this.oComponent = this.getOwnerComponent();
          const cardManifest = this.oComponent.getMetadata().getManifest();
          let cardBindings = cardManifest["sap.card"]["cardUIBindings"];
          this.fnInitializeTableCardView(cardBindings);
        },

        fnInitializeTableCardView: function (cardBindings) {
          let oCardUIModel = this.createJSONModel(cardBindings);
          this.getView().setModel(oCardUIModel, "CardUIModel");
          this.oCardUIModel = oCardUIModel;

          this.cardId = this.oCardUIModel.getProperty("/cardId");
          this.dashboardDataModel = this.oComponent.getModel("dashboardDataModel");
          this.fnFetchDropdownList(oCardUIModel);
          this.generateTableColumns();
        },

        fnFetchDropdownList: function (oCardUIModel) {
          const isViewSettingsVisible = oCardUIModel.getProperty("/viewSettings/isVisible");
          if (isViewSettingsVisible) {
            const sUrl = oCardUIModel.getProperty("/viewSettings/api");
            const oData = oCardUIModel.getProperty("/viewSettings/data")
            oCardUIModel.setProperty("/filterList", oData);
          }
        },

        generateTableColumns: function () {
          let table = this.getView().byId("CustomCardTable");
          table.bindAggregation("columns", {
            path: "CardUIModel>/columnsAggregation",
            factory: function (sId) {
              return new sap.m.Column(sId, {
                visible: "{CardUIModel>visible}",
                header: new sap.m.Label({
                  text: "{CardUIModel>text}",
                  wrapping: true
                }),
              });
            },
          });
          this.getTableData();
          this.generateTableItems();
        },

        getTableData: function () {
          const oData = [
            {
              column1: "Data 1",
              datq3: "Data 2",
              sdsd: "Data 3",
              vcgfg: "Data 4",
              rtrt: "Data 5",
              sdsosiroid: "Data 3",
              jhhjhjj: "Data 4",
            },
            {
              column1: "Data 1",
              datq3: "Data 2",
              sdsd: "Data 3",
              vcgfg: "Data 4",
              rtrt: "Data 5Data 4 Data 4",
              sdsosiroid: "Data 3",
              jhhjhjj: "Data 4",
            },
          ];
          this.oCardUIModel.setProperty("/TableData", oData);

          if (this.cardId === "0021") {
            this.fetchActivityList();
          }
        },

        generateTableItems: function () {
          let oCardUIModel = this.oCardUIModel;
          let table = this.getView().byId("CustomCardTable");
          const aTableItems = oCardUIModel.getProperty("/tableItems");

          table.bindAggregation("items", {
            path: "CardUIModel>/TableData",
            factory: function (sId, oRowContext) {
              let cellIndex = 0;
              var oRow = new sap.m.ColumnListItem({
                vAlign: "Middle",
              });

              oRow.bindAggregation("cells", {
                path: "CardUIModel>/cellsAggregation",
                factory: function (sCellId, oMetaContext) {
                  let oControl;
                  let sPath = oRowContext.getPath();
                  let sDataPath = "CardUIModel>/TableData";
                  let rowIndex = sPath.split("/")[sPath.split("/").length - 1];
                  let properties = Object.keys(oCardUIModel.getProperty(sPath));
                  let sProperty = properties[cellIndex];
                  let sType = oMetaContext.getProperty("controlType");
                  let bindingProperty = "{" + sDataPath + "/" + rowIndex + "/";

                  switch (sType) {
                    case "link":
                      oControl = new sap.m.Link({
                        text: bindingProperty + sProperty + "}",
                        wrapping: true
                      });
                      break;

                    case "text":
                      oControl = new sap.m.Text({
                        text: bindingProperty + sProperty + "}",
                        wrapping: true
                      });
                      break;

                    case "actions":
                      oControl = new sap.m.Button({
                        icon: "sap-icon://overflow",
                        type: "Transparent",
                      });
                      break;

                    case "outcomes":
                      oControl = new sap.m.Button({
                        icon: "sap-icon://program-triangles",
                        type: "Transparent",
                      });
                      break;

                    case "progressIndicator":
                      oControl = new sap.m.ProgressIndicator({
                        percentValue: "30", displayValue: "30%", showValue: true, state: "None"
                      });
                      break;

                    case "aiPredictions":
                      oControl = new sap.ui.core.Icon({
                        src: "sap-icon://ai",
                        color: "#1C4C98"
                      });
                      break;

                    case "notes":
                      oControl = new sap.m.Button({
                        icon: "sap-icon://request",
                        type: "Transparent",
                        text: "2"
                      });
                      break;

                    default:
                      oControl = new sap.m.Text({ text: "" });
                  }
                  cellIndex++;
                  return oControl;
                },
                templateShareable: false,
              });
              return oRow;
            },
            templateShareable: false,
          });
        },

        fetchActivityList: function () {
          this.dashboardDataModel.read("/YC_MD_T_ACT_CARD", {
            success: function (oData) {
              debugger
            },
            error: function (oError) {
              debugger
            }
          });
        }
      },
    );
  },
);
