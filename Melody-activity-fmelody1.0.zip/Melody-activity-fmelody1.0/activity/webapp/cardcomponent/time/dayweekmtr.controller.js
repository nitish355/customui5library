sap.ui.define(
    [
        "sap/ui/core/Fragment",
        "com/melodylib/core/service/DateService",
        "com/melodysuite/activity/service/CardService",
        "com/melodysuite/activity/controller/BaseController",
    ],
    function (Fragment, DateService, CardService, BaseController) {
        "use strict";
        return BaseController.extend(
            "com.melodysuite.activity.cardcomponent.analytical.Chart",
            {
                onInit: function (oEvent) {
                    const component = this.getOwnerComponent();
                    const cardManifest = component.getMetadata().getManifest();
                    let cardBindings = cardManifest["sap.card"]["cardUIBindings"] || undefined;
                    this.initializeApplicationModel(cardBindings);
                    this.setMTRCardData();
                },

                /**
                 * @function initializeApplicationModel
                 * @description Function to initialize application's model to the component
                 * @param {object} event
                 */
                initializeApplicationModel: function (cardBindings = {}) {
                    let dayweekCardModel = new sap.ui.model.json.JSONModel({});
                    const headerData = ("header" in cardBindings) ? cardBindings.header : {};
                    const serviceData = ("service" in cardBindings) ? cardBindings.service : {};
                    dayweekCardModel.setProperty("/serviceData", serviceData);
                    this.getView().setModel(dayweekCardModel, "dayweekCardModel");
                    dayweekCardModel.refresh();
                },

                /**
                 * @function setMTRCardData
                 * @description  This function formats and sets the MTR DATA to card
                 */
                setMTRCardData: function () {
                    try {
                        const dayweekCardModel = this.getView().getModel("dayweekCardModel");
                        dayweekCardModel.setProperty("/timeBusy", true);
                        dayweekCardModel.setProperty("/mtrCard", {
                            header: {},
                            visible: {},
                            validation: {
                                minDate: null,
                                maxDate: null
                            },
                            data: {
                                selectedActiveCalendarMonthDate: new Date()
                            },
                            busy: {},
                            message: {
                                type: "sapIllus-NoActivities"
                            }
                        });
                        dayweekCardModel.setProperty("/mtrCard/visible/showToggle", false);
                        dayweekCardModel.setProperty("/mtrCard/visible/displayView2", false);
                        dayweekCardModel.setProperty("/mtrCard/visible/displayView1", false);
                        dayweekCardModel.setProperty("/mtrCard/visible/displayMsgCtrl", true);
                        dayweekCardModel.setProperty("/mtrCard/header/title", "Capacity Hours");
                        dayweekCardModel.setProperty("/listToggleicon", "sap-icon://list");
                        dayweekCardModel.setProperty("/listToggletooltip", "view activities");
                        dayweekCardModel.setProperty("/Holidays", ["20260520", "20260505"]);
                        dayweekCardModel.setProperty("/currentDate", this._formatCurrentDate());
                        dayweekCardModel.setProperty("/mtrCard/header/calendarMonth", this.getFullMonth());
                        dayweekCardModel.setProperty("/mtrCard/header/calendarMonthPrev", this.getFullMonth());
                        dayweekCardModel.setProperty("/opportunityPieChartData", []);

                        dayweekCardModel.setProperty("/timeBusy", false);
                        dayweekCardModel.refresh();
                    } catch (error) {
                        console.log("ERROR IN setMTRCardData : ", error);
                    }
                },


                /**
                * @function handleCalendarChange
                * @author DARSHAN
                * @description function to handle change of month or year in MTR Calendar
                */
                handleCalendarChange: function (event) {
                    //debugger;
                    try {
                        const dayweekCardModel = this.getView().getModel("dayweekCardModel");
                        const selectedStartDate = event.getParameter("selectionStartDate");

                        const selectedDate = DateService.getInstance().format(selectedStartDate, "yMMdd"); // YYYYMMDD
                        dayweekCardModel.setProperty("/mtrCard/visible/displayView2", false);
                        dayweekCardModel.setProperty("/mtrCard/visible/displayView1", true);
                        dayweekCardModel.setProperty("/mtrCard/visible/showToggle", false);
                        dayweekCardModel.setProperty("/listToggleicon", "sap-icon://list");
                        dayweekCardModel.setProperty("/listToggletooltip", "view activities");
                        dayweekCardModel.setProperty("/mtrCard/header/title", "Capacity Hours");
                        dayweekCardModel.setProperty("/mtrCard/data/selectedTimeInfo", []);
                        dayweekCardModel.setProperty("/mtrCard/data/selectedYearFrmCalendar", selectedStartDate.getFullYear());
                        dayweekCardModel.setProperty("/mtrCard/data/selectedActiveCalendarMonthDate", selectedStartDate);
                        dayweekCardModel.setProperty("/mtrCard/message/type", "sapIllus-NoActivities");
                        dayweekCardModel.setProperty("/mtrCard/header/calendarMonth", this.getFullMonth(selectedStartDate));
                        dayweekCardModel.setProperty("/mtrCard/header/calendarMonthPrev", this.getFullMonth(selectedStartDate));
                        dayweekCardModel.refresh();
                    } catch (error) {
                        console.log("ERROR IN handleCalendarChange : ", error);
                    }
                },


            },
        );
    },
);
