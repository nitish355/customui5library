sap.ui.define(["sap/ui/core/UIComponent"], function (UIComponent) {
    "use strict";

    var Component = UIComponent.extend(
        "com.melodysuite.activity.cardcomponent.Component",
        {
            metadata: {
                manifest: "json",
            },
        },
    );

    return Component;
});
