sap.ui.define(
    [
        "sap/ui/core/Fragment",
        "com/melodysuite/activity/service/CardService",
        "com/melodysuite/activity/controller/BaseController",
    ],
    function (Fragment, CardService, BaseController) {
        "use strict";
        return BaseController.extend(
            "com.melodysuite.activity.cardcomponent.analytical.Chart",
            {
                onInit: function (oEvent) {
                    const component = this.getOwnerComponent();
                    const cardManifest = component.getMetadata().getManifest();
                    let cardBindings = cardManifest["sap.card"]["cardUIBindings"] || undefined;
                    this.initializeApplicationModel(cardBindings);
                },

                /**
                 * @function initializeApplicationModel
                 * @description Function to initialize application's model to the component
                 * @param {object} event
                 */
                initializeApplicationModel: function (cardBindings = {}) {
                    const comparisionData = [
                        {
                            "text": "Total",
                            "value": "34",
                            "percentage": "100",
                            "color": "#4a90e2"
                        },
                        {
                            "text": "Discover",
                            "value": "4",
                            "percentage": "11.76",
                            "color": ""
                        },
                        {
                            "text": "Select",
                            "value": "23",
                            "percentage": "67.65",
                            "color": ""
                        },
                        {
                            "text": "Adopt",
                            "value": "14",
                            "percentage": "41.18",
                            "color": ""
                        },
                        {
                            "text": "Dervie",
                            "value": "3",
                            "percentage": "8.82",
                            "color": ""
                        },
                        {
                            "text": "Extend",
                            "value": "5",
                            "percentage": "14.71",
                            "color": ""
                        }
                    ];
                    let chartModel = new sap.ui.model.json.JSONModel({});
                    const headerData = ("header" in cardBindings) ? cardBindings.header : {};
                    const serviceData = ("service" in cardBindings) ? cardBindings.service : {};
                    chartModel.setProperty("/serviceData", serviceData);
                    chartModel.setProperty("/comparisionHeader", headerData);
                    chartModel.setProperty("/comparisionData", comparisionData);
                    this.getView().setModel(chartModel, "chartModel");
                    chartModel.refresh();
                }

            },
        );
    },
);
