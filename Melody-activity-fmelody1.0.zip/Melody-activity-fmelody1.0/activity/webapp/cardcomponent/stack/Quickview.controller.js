sap.ui.define(
    [
        "sap/ui/core/Fragment",
        "com/melodysuite/activity/enum/Constants",
        "com/melodysuite/activity/service/CardService",
        "com/melodysuite/activity/controller/BaseController",
    ],
    function (Fragment, Constants, CardService, BaseController) {
        "use strict";
        return BaseController.extend(
            "com.melodysuite.activity.cardcomponent.stack.Quickview",
            {
                onInit: function (oEvent) {
                    const component = this.getOwnerComponent();
                    const cardManifest = component.getMetadata().getManifest();
                    let cardBindings = cardManifest["sap.card"]["cardUIBindings"] || undefined;
                    this.initializeApplicationModel(cardBindings);
                },

                /**
                 * @function initializeApplicationModel
                 * @description Function to initialize application's model to the component
                 * @param {object} event
                 */
                initializeApplicationModel: function (cardBindings = {}) {
                    const serviceData = ("service" in cardBindings) ? cardBindings.service : {};
                    const objectStreamTemplate = ("objectStream" in cardBindings) ? cardBindings.objectStream : {};
                    const quickViewStackData = ("quickViewStack" in cardBindings) ? cardBindings.quickViewStack : {};
                    let stackModel = new sap.ui.model.json.JSONModel({});
                    stackModel.setProperty("/serviceData", serviceData);
                    stackModel.setProperty("/dialogTitle", quickViewStackData.title);
                    stackModel.setProperty("/quickViewStackData", quickViewStackData);
                    stackModel.setProperty("/objectStreamTemplate", objectStreamTemplate);
                    this.getView().setModel(stackModel, "stackModel");
                    stackModel.refresh();
                },

                /**
                 * @function handleCstStackCardSideContentPress
                 * @description Function to handle custom stack card's side content press
                 * @param {object} event
                 */
                handleCstStackCardSideContentPress: async function (event) {
                    try {

                        let apiResponseData;
                        let opportunityId = "300090826";
                        let stackModel = this.getView().getModel("stackModel");
                        const serviceData = stackModel.getProperty("/serviceData");
                        const serviceType = ("type" in serviceData) ? serviceData.type : "";

                        //Open Dialog
                        if (!this._scrollableStackCardDialog) {
                            this._scrollableStackCardDialog = await Fragment.load({
                                name: "com.melodysuite.activity.cardcomponent.fragments.ScrollableStackCardDialog",
                                controller: this
                            });

                        }
                        this.getView().addDependent(this._scrollableStackCardDialog);
                        setTimeout(() => {
                            this._scrollableStackCardDialog.open();
                        }, 450);

                        switch (serviceType) {
                            case Constants.QUICKSTACKSRVTYPE.REQUERIED_ACTION:
                                break;
                            case Constants.QUICKSTACKSRVTYPE.ACTIVITY_WITHOUT_TIME:
                                const urlParameters = {
                                    filters: [new sap.ui.model.Filter({ path: 'OpportunityId', operator: 'EQ', value1: opportunityId })],
                                    urlParams: {
                                        $expand: 'to_Actvt'
                                    }
                                };
                                let opprotunityActData = await CardService.getAnalyticalCardActivityData(urlParameters);
                                apiResponseData = opprotunityActData?.data.results || [];
                                break;
                            case Constants.QUICKSTACKSRVTYPE.ACTIVITY_DISCONTINUED_OPPORTUNITY:
                                break;
                            case Constants.QUICKSTACKSRVTYPE.ACTIVITY_PAST_ENDDATE:
                                break;
                            case Constants.QUICKSTACKSRVTYPE.MR_REQUEST_PROCESS:
                                break;
                            default:
                                apiResponseData = [];
                        }


                        const objectStreamFormData = this.generateFormDataForObjectStream(serviceType, apiResponseData);
                        stackModel.setProperty("/objectStreamData", objectStreamFormData);
                        stackModel.refresh();
                    } catch (error) {
                        console.log("ERROR IN handleCstStackCardSideContentPress : ", error);
                    }
                },

                /**
                 * @function generateFormDataForObjectStream
                 * @description function to generate the form data for object stream data
                 * which includes label,type,value
                 * @param {array} responseData
                 */
                generateFormDataForObjectStream: function (serviceType, responseData = []) {

                    try {
                        const objectStreamData = [];
                        const stackModel = this.getView().getModel("stackModel");
                        const objectStreamTemplate = stackModel.getProperty("/objectStreamTemplate");
                        const templateType = ("templateType" in objectStreamTemplate) ? objectStreamTemplate.templateType : "";
                        const templateData = ("data" in objectStreamTemplate) ? objectStreamTemplate.data : [];

                        switch (templateType) {
                            case "DYNAMIC":
                                return this.generateDynamicTemplateFormObjectStream(templateData);
                            case "AGGREGATION":
                                return this.generateAggregationTemplateFormObjectStream(serviceType, templateData, responseData);
                            default:
                                return objectStreamData;
                        }


                    } catch (error) {
                        console.log("ERROR IN generateFormDataForObjectStream : ", error);
                    }
                },


                /**
                 * @function generateAggregationTemplateFormObjectStream
                 * @description function to generate aggregation template the form based on template types 
                 * @param {string} serviceType
                 * @param {object} templateData
                 * @param {array} responseData
                 */
                generateAggregationTemplateFormObjectStream: function (serviceType, templateData, responseData) {
                    try {

                        let cardTemplateData = [];
                        switch (serviceType) {
                            case Constants.QUICKSTACKSRVTYPE.REQUERIED_ACTION:
                                break;
                            case Constants.QUICKSTACKSRVTYPE.ACTIVITY_WITHOUT_TIME:
                                if (responseData.length) {
                                    const responseObject = responseData[0];
                                    if ("to_Actvt" in responseObject && "results" in responseObject.to_Actvt && responseObject.to_Actvt.results.length) {
                                        cardTemplateData = responseObject.to_Actvt.results;
                                    }
                                }
                                break;
                            case Constants.QUICKSTACKSRVTYPE.ACTIVITY_DISCONTINUED_OPPORTUNITY:
                                break;
                            case Constants.QUICKSTACKSRVTYPE.ACTIVITY_PAST_ENDDATE:
                                break;
                            case Constants.QUICKSTACKSRVTYPE.MR_REQUEST_PROCESS:
                                break;
                            default:

                        }

                        const objectStreamData = [];
                        const templateObject = templateData[0];
                        for (let i = 0; i < cardTemplateData.length; i++) {
                            let formElements;
                            const apiData = cardTemplateData[i];
                            const templateHeader = templateObject?.header ?? {};
                            const titlePath = ("path" in templateHeader.title) ? templateHeader.title.path : "";
                            const subTitlePath = ("path" in templateHeader.subTitle) ? templateHeader.subTitle.path : "";
                            const objectStream = {
                                cardTitle: templateObject?.cardTitle ?? "",
                                title: (titlePath) ? apiData[titlePath] : "TITLE",
                                subTitle: (subTitlePath) ? apiData[subTitlePath] : "SUB_TITLE",
                                icon: templateHeader?.icon ?? "sap-icon://request",
                                displayTimeSection: templateObject?.displayTimeSection ?? false,
                                formData: [],
                                footer: templateObject?.footer ?? []
                            };

                            const primaryForm = ("primary" in templateObject && Object.keys(templateObject.primary).length) ? templateObject.primary : false;
                            const secondaryForm = ("secondary" in templateObject && Object.keys(templateObject.secondary).length) ? templateObject.secondary : false;
                            if (primaryForm) {
                                formElements = this.generateElementsForObjectStream(primaryForm, apiData);
                                objectStream.formData.push(formElements);
                            }
                            if (secondaryForm) {
                                formElements = this.generateElementsForObjectStream(secondaryForm, apiData);
                                objectStream.formData.push(secondaryForm);
                            }

                            objectStreamData.push(objectStream);
                        }

                        return objectStreamData;
                    } catch (error) {
                        console.log("ERROR IN generateAggregationTemplateFormObjectStream : ", error);
                    }
                },


                /**
                 * @function generateDynamicTemplateFormObjectStream
                 * @description function to generate dynamic template the form based on template types 
                 * @param {object} templateData
                 */
                generateDynamicTemplateFormObjectStream: function (templateData, responseData) {
                    const objectStreamData = [];
                    for (let i = 0; i < templateData.length; i++) {
                        let generateForm = "";
                        const template = templateData[i];
                        const header = template?.header ?? {};
                        const objectStream = {
                            cardTitle: template?.cardTitle ?? "",
                            title: header?.title ?? "",
                            subTitle: header?.subTitle ?? "",
                            icon: header?.icon ?? "",
                            displayTimeSection: template?.displayTimeSection ?? false,
                            formData: [],
                            footer: template?.footer ?? []
                        };
                        const primaryForm = ("primary" in template && Object.keys(template.primary).length) ? template.primary : false;
                        const secondaryForm = ("secondary" in template && Object.keys(template.secondary).length) ? template.secondary : false;
                        if (primaryForm) {
                            objectStream.formData.push(primaryForm);
                        }
                        if (secondaryForm) {
                            objectStream.formData.push(secondaryForm);
                        }
                        objectStreamData.push(objectStream);
                    }
                    return objectStreamData;
                },


                /**
                 * @function generateElementsForObjectStream
                 * @description function to generate the form element data array for object steam custom card
                 * @param {array} formData
                 * @param {object} apiData
                 * @return {object} formelements
                 */
                generateElementsForObjectStream: function (formData = {}, apiData) {
                    const titles = formData.title.split("\n") || [];
                    const title = titles.map((item) => {
                        return apiData[item] ?? "Account Name";
                    }).join("-");
                    const formElements = {
                        title: title,
                        elements: formData.elements.map((item) => {
                            return {
                                ...item,
                                value: this.formatDataValue(apiData[item.value])
                            };
                        })
                    };
                    return formElements;

                },

                /**
                 * @function formatDataValue
                 * @description funtion to handle or format the data 
                 * @param {any} value
                 * Need to improve this function
                 */
                formatDataValue: function (value) {
                    return value instanceof Date ? new Date(value).toLocaleDateString("en-US", {
                        month: "long",
                        day: "2-digit",
                        year: "numeric"
                    }) : value;
                },

                /**
                 * @function closeScrollableStackCardDialog
                 * @description function to close the scrollable stack card dialog
                 * @param {object} event
                 */
                closeScrollableStackCardDialog: function (event) {
                    this._scrollableStackCardDialog.close();
                    this._scrollableStackCardDialog.destroy();
                    this._scrollableStackCardDialog = null;
                },

            },
        );
    },
);
