sap.ui.define([], () => {
	"use strict";

	return {
		formatRevenue: function (sRevenueArgs, sCurrency) {
			const sRevenue = sRevenueArgs ? sRevenueArgs : "0";
			const oCurrFormatter = new sap.ui.model.type.Currency({
				showMeasure: false,
				decimals: 2,
				preserveDecimals: false
			});
			oCurrFormatter.setConstraints({
				maximum: "9999999999999.99",
				minimum: "0"
			});
			const sFormattedRev = oCurrFormatter.formatValue([sRevenue, sCurrency], "string");
			// remove the decimal places if currency it is for Korea or Indonesia
			if (sCurrency === "WON" || sCurrency === "RP" || sCurrency === "JPY") {
				const sRevenueTrunc = sFormattedRev.split(".")[0];
				return sRevenueTrunc;
			}
			return sFormattedRev;
		}
	};
});