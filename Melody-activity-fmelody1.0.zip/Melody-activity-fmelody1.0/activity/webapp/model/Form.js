sap.ui.define([
  "sap/ui/base/Object"
], function (Object) {
  "use strict";
  return Object.extend("com.melodysuite.activity.model.Form", {
    constructor1: function (data) {
      this.title = data?.title ? data.title : '';
      this.account = data?.account ? data.account : null;
      this.opportunity = data?.opportunity ? data.opportunity : null;
      this.formId = data?.formId ? data.formId : null;
      this.activityType = data?.activityType ? data.activityType : ''
      this.startdate = data?.startdate ? data.startdate : null
      this.enddate = data?.enddate ? data.enddate : null
      this.dryRun = data?.dryRun ? data.dryRun : null
      this.description = data?.description ? data.description : null
      this.types = data?.types ? data.types : null
      this.method = data?.method ? data.method : null
      this.SolTokens = data?.SolTokens ? data.SolTokens : null
      this.activityLead = data?.activityLead ? data.activityLead : null
      this.accountExecutive = data?.accountExecutive ? data.accountExecutive : null
      this.team = data?.team ? data.team : []
      this.riskComments = data?.riskComments ? data.riskComments : null
      this.to_AFiles = data?.to_AFiles ? data.to_AFiles : []
      this.to_ASuccessFactor = data?.to_ASuccessFactor ? data.to_ASuccessFactor : []
      this.to_ACloudEnv = data?.to_ACloudEnv ? data.to_ACloudEnv : []
      this.NCFEstimatedTime = data?.NCFEstimatedTime || null
      this.estimatedTime = data?.estimatedTime || null
    },
    constructor: function (data) {
      this.title = data?.title || null;
      this.formId = data?.formId || null;
      this.actvtAsstdID = data?.ActvtAsstdID || '501'
      this.activityGUID = data?.ActivityGUID || null;
      this.activityId = data?.ActivityId || null;
      this.activityTypeId = data?.ActivityTypeId || null;
      this.actTypeRole = data?.ActvtTypeRole || null;
      this.actTypeDesc = data?.ActivityTypeDescription || null;
      this.startDate = data?.StartDate || null;
      this.endDate = data?.EndDate || null;
      this.dryRun = data?.dryRun || null;
      this.description = data?.Description || null;
      this.region = data?.Region || null;
      this.riskId = data?.RiskId || null;
      this.riskDesc = data?.RiskDesc || null;
      this.opportunityNumber = data?.OpportunityNumber || null;
      this.activityLead = data?.ActivityLead || null;
      this.activityLeadName = data?.ActivityLeadName || null;
      this.lead = data?.ActivityLead ? this.setLead() : null;
      this.to_AFiles = []
      this.to_ASuccessFactor = []
      this.to_ACloudEnv = []
      this.to_ALand = []
      this.NCFEstimatedTime = data?.NCFEstimatedTime || null
      this.estimatedTime = data?.estimatedTime || null
      this.formLayoutId = data?.FormLayoutId || null
      this.childFrmLayoutId = data?.ChildFrmLayoutId || null
      this.roleMpngID = data?.RoleMpngID || null
      this.acivityTypeInfo = data?.ActivityTypeInfo || null
      this.globalUltimateID = data?.GlobalUltimateID || null
      this.registrationTypes = [{
        name: "Account",
        key: "ACCOUNT",
        isEnabled: true,
        keyId: 0
      }, {
        name: "Opportunity",
        key: "OPPORTUNITY",
        isEnabled: true,
        keyId: 1
      }, {
        name: "No Association",
        key: "ACTIVITYSET",
        isEnabled: true,
        keyId: 2
      }]
    },
    accountLabel: function () {
      return "Account - " + this.account;
    },
    setLead: function () {
      return {
        name: this.activityLeadName,
        id: this.activityLead,
        roleDescription: this.roleDescription,
        initials: this.activityLeadName ? this.generateInitials(this.activityLeadName) : null,
        emailId: this.UserEmail
      }
    },
    generateInitials: function (name) {
      const words = name.split(" ");
      let initials = "";
      for (let i = 0; i < words.length; i++) {
        initials += words[i][0].toUpperCase();
      }
      return initials;
    },
    setAssociateType: function () {
      let associateType = 0;
      switch (this.actvtAsstdID) {
        case '501':
          associateType = 0;
          break;
        case '502':
          associateType = 1;
          break;
        case '503':
          associateType = 2;
          break;
        default:
          associateType = 0;
          break;

      }
      this.associateType = associateType
    }


  });
});