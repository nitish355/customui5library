sap.ui.define([
    "sap/ui/integration/Extension",
    "com/melodylib/time/controls/TimeEntryButton",
], function (Extension, TimeEntryButton) {
    "use strict";

    return Extension.extend("com.melodysuite.activity.model.lazyExtension", {
        init: function () {
            Extension.prototype.init.apply(this, arguments);
        },

        getFilterData: function () {
            var aData = [];
            for (var i = 1; i <= 10000; i++) {
                aData.push({
                    shipper: "Activity " + i
                });
            }

            return new Promise(resolve =>
                setTimeout(() => resolve(aData), 600000)
            );
        },

        getOrdersData: function (sShipperName) {
            var aData = [];
            for (var i = 1; i <= 5; i++) {
                aData.push({
                    order: "Successline " + i,
                    shipper: sShipperName
                });
            }

            return new Promise(resolve =>
                setTimeout(() => resolve(aData), 600000)
            );
        }
    });
});