// @ts-nocheck
sap.ui.define(
  [
    "sap/base/Log",
    "sap/m/MessageBox",
    "sap/ui/model/Filter",
    "sap/ui/core/Fragment",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/resource/ResourceModel",
    "com/melodylib/core/db/IndexedDB",
    "com/melodysuite/activity/service/MasterService",
  ],
  function (
    BaseLog,
    MessageBox,
    Filter,
    Fragment,
    FilterOperator,
    JSONModel,
    ResourceModel,
    oIndexedDB,
    MasterService
  ) {
    "use strict";
    return {
      //function to fetch risk button
      getActDetRiskButtons: async function () {
        let aRiskData =
          (await oIndexedDB.fnGetAllDatafromDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "actriskbuttons",
          })) || [];

        if (!aRiskData.length) {
          let { data } = await MasterService.getActDetRiskButtons();
          aRiskData = data?.results ?? [];

          oIndexedDB.fnInsertDataToDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "actriskbuttons",
            aObjectsToInsert: aRiskData,
          });
        }

        return aRiskData;
      },

      //function to fetch Activity Status
      getActivityStatus: async function () {
        let aActStatusResults =
          (await oIndexedDB.fnGetAllDatafromDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "activitystatus",
          })) || [];

        if (!aActStatusResults.length) {
          let { data } = await MasterService.getActivityStatusMasterData();
          aActStatusResults = data?.results ?? [];

          oIndexedDB.fnInsertDataToDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "activitystatus",
            aObjectsToInsert: aActStatusResults,
          });
        }

        return aActStatusResults;
      },

      //function to fetch status list
      getActivityListStatus: async function () {
        let aActListStatusResults =
          (await oIndexedDB.fnGetAllDatafromDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "activityliststatus",
          })) || [];

        if (!aActListStatusResults.length) {
          let { data } = await MasterService.getActivityListStatusMasterData();
          aActListStatusResults = data?.results ?? [];

          oIndexedDB.fnInsertDataToDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "activityliststatus",
            aObjectsToInsert: aActListStatusResults,
          });
        }

        return aActListStatusResults;
      },

      getActivityListDelTeam: async function () {
        let aActListDelTeam =
          (await oIndexedDB.fnGetAllDatafromDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "activitydelteam",
          })) || [];

        if (!aActListDelTeam.length) {
          let { data } = await MasterService.getActivityListDelTeamMasterData();
          aActListDelTeam = data?.results ?? [];

          oIndexedDB.fnInsertDataToDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "activitydelteam",
            aObjectsToInsert: aActListDelTeam,
          });
        }
        return aActListDelTeam;
      },

      getActivityListHostType: async function () {
        let aActListHostType =
          (await oIndexedDB.fnGetAllDatafromDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "activityhosttype",
          })) || [];

        if (!aActListHostType.length) {
          let { data } =
            await MasterService.getActivityListHostTypeMasterData();
          aActListHostType = data?.results ?? [];

          oIndexedDB.fnInsertDataToDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "activityhosttype",
            aObjectsToInsert: aActListHostType,
          });
        }
        return aActListHostType;
      },

      getActivityListLandScape: async function () {
        let aActListLandScape =
          (await oIndexedDB.fnGetAllDatafromDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "activitylandscape",
          })) || [];

        if (!aActListLandScape.length) {
          let { data } =
            await MasterService.getActivityListLandScapeMasterData();
          aActListLandScape = data?.results ?? [];

          oIndexedDB.fnInsertDataToDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "activitylandscape",
            aObjectsToInsert: aActListLandScape,
          });
        }
        return aActListLandScape;
      },

      getActivityListProjectType: async function () {
        let aActListProjType =
          (await oIndexedDB.fnGetAllDatafromDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "activityprojtype",
          })) || [];

        if (!aActListProjType.length) {
          let { data } =
            await MasterService.getActivityListProjectTypeMasterData();
          aActListProjType = data?.results ?? [];

          oIndexedDB.fnInsertDataToDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "activityprojtype",
            aObjectsToInsert: aActListProjType,
          });
        }
        return aActListProjType;
      },

      getActivityListRegion: async function () {
        let aActListRegion =
          (await oIndexedDB.fnGetAllDatafromDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "activityregion",
          })) || [];

        if (!aActListRegion.length) {
          let { data } = await MasterService.getActivityListRegionMasterData();
          aActListRegion = data?.results ?? [];

          oIndexedDB.fnInsertDataToDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "activityregion",
            aObjectsToInsert: aActListRegion,
          });
        }
        return aActListRegion;
      },

      getActivityListShowroomMasterData: async function () {
        let aActListShowroom =
          (await oIndexedDB.fnGetAllDatafromDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "activityShowroom",
          })) || [];

        if (!aActListShowroom.length) {
          let { data } =
            await MasterService.getActivityListShowroomMasterData();
          aActListShowroom = data?.results ?? [];

          oIndexedDB.fnInsertDataToDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "activityShowroom",
            aObjectsToInsert: aActListShowroom,
          });
        }
        return aActListShowroom;
      },

      getActivityListUseCaseMasterData: async function () {
        let aActListUseCase =
          (await oIndexedDB.fnGetAllDatafromDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "activityUseCase",
          })) || [];

        if (!aActListUseCase.length) {
          let { data } = await MasterService.getActivityListUseCaseMasterData();
          aActListUseCase = data?.results ?? [];

          oIndexedDB.fnInsertDataToDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "activityUseCase",
            aObjectsToInsert: aActListUseCase,
          });
        }
        return aActListUseCase;
      },

      getActivityListStrategicAreaMasterData: async function () {
        let aActListInnovations =
          (await oIndexedDB.fnGetAllDatafromDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "activityInnovations",
          })) || [];

        if (!aActListInnovations.length) {
          let { data } =
            await MasterService.getActivityListStrategicAreaMasterData();
          aActListInnovations = data?.results ?? [];

          oIndexedDB.fnInsertDataToDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "activityInnovations",
            aObjectsToInsert: aActListInnovations,
          });
        }
        return aActListInnovations;
      },

      getActivityListRoleMasterData: async function () {
        const { data } = await MasterService.getActivityListRoleMasterData();
        return data?.results;
      },

      getActivityTypesBasedOnRole: async function (roleId) {
        let parameters = {
          filters: [new Filter("role_id", FilterOperator.EQ, roleId)],
          urlParameters: {
            $expand: "to_Atype",
          },
        };
        let { data } = await MasterService.getActivityListRoleMasterData(
          parameters
        );
        let activityTypes = data?.results[0].to_Atype?.results;
        return activityTypes;
      },

      getRoleMasterData: async function (associateType) {
        const { data } = await MasterService.getRoleMasterData();
        return data;
      },
      getActivityTypes: async function (associationId, activityTypesMap) {
        let activityTypes = activityTypesMap[associationId] || [];

        if (!activityTypes.length) {
          var filters = [
            new Filter("ActivtyTypeCatznID", "EQ", "0001"),
            new Filter("ActvtAsstdID", "EQ", associationId),
            new Filter("operation_status", "EQ", true),
          ];
          let { data } = await MasterService.getActivityTypes(filters);
          activityTypes = data?.results ?? [];
          activityTypesMap[associationId] = activityTypes;
        }
        return activityTypes;
      },

      getActions: async function (guid) {
        const params = {
          expand: "to_caction",
          filters: [new Filter("ActGuid", "EQ", guid)],
        };
        let { data } = await MasterService.getActions(params);
        const results = data?.results || [];
        return results;
      },

      setActivityStatus: async function (payload) {
        await MasterService.setActivityStatus(payload);
      },

      //NOT USED
      getAttachments: async function (controller, guid) {
        const filters = [new Filter("ActivityGuid", "EQ", guid)];
        const { data } = await MasterService.getAttachments(filters);
        let files = data?.results?.map((file) => {
          return {
            url: file.Url,
            fileId: file.FileId,
            fileName: file.FileName,
            isAddBtnVisible: false,
            isDelBtnVisible: true,
          };
        });
        // change the property names here fileId -> id , fileName -> name
        const activityFormModel = controller
          .getOwnerComponent()
          .getModel("activityFormModel");
        const path = activityFormModel.getProperty("/formPath");
        activityFormModel.setProperty(path + "/files/results", files);
      },
    };
  }
);
