sap.ui.define(
    {
        "CUSTOMTABLE1": {
            "_version": "1.84.0",
            "sap.app": {
                "id": "com.melodysuite.activity",
                "type": "card",
                "applicationVersion": {
                    "version": "1.0.0"
                }
            },
            "sap.ui": {
                "technology": "UI5",
                "icons": {
                    "icon": "sap-icon://technical-object"
                }
            },
            "sap.ui5": {
                "rootView": {
                    "viewName": "com.melodysuite.activity.cardcomponent.table.table",
                    "type": "XML",
                    "async": true,
                    "id": "app"
                },
                "dependencies": {
                    "minUI5Version": "1.38",
                    "libs": {
                        "sap.m": {},
                        "sap.ui.core": {}
                    }
                }
            },
            "sap.card": {
                "cardUIBindings": {
                    "cardId": "",
                    "columnSize": 2,
                    "title": "My Time Entries",
                    "viewSettings": {
                        "isVisible": true,
                        "api": "/",
                        "data": [
                            {
                                "text": "Saved/To Be Submitted",
                                "key": "01"
                            },
                            {
                                "text": "Failed Submissions",
                                "key": "02"
                            },
                            {
                                "text": "Successful Submissions",
                                "key": "03"
                            },
                            {
                                "text": "Activities with Discontinued Opps",
                                "key": "04"
                            }
                        ]
                    },
                    "headerActionBtn": {
                        "isVisible": true,
                        "type": "Transparent",
                        "isTextVisible": true,
                        "text": "Create Time Entry",
                        "icon": "sap-icon://create-entry-time"
                    },
                    "rowsAPI": "",
                    "columnsAggregation": [
                        {
                            "visible": true,
                            "text": "Actions",
                            "key": "01"
                        },
                        {
                            "visible": true,
                            "text": "Time Entry",
                            "key": "02"
                        },
                        {
                            "visible": true,
                            "text": "Activity",
                            "key": "03"
                        },
                        {
                            "visible": true,
                            "text": "Account",
                            "key": "04"
                        },
                        {
                            "visible": true,
                            "text": "Opp Num",
                            "key": "05"
                        },
                        {
                            "visible": true,
                            "text": "Notes",
                            "key": "06"
                        }
                    ],
                    "cellsAggregation": [
                        {
                            "controlType": "actions"
                        },
                        {
                            "controlType": "link"
                        },
                        {
                            "controlType": "text"
                        },
                        {
                            "controlType": "text"
                        },
                        {
                            "controlType": "text"
                        },
                        {
                            "controlType": "notes"
                        }
                    ]
                },
                "type": "Component"
            }
        },
        "CUSTOMTABLE2": {
            "_version": "1.84.0",
            "sap.app": {
                "id": "com.melodysuite.activity.cardcomponent.table2",
                "type": "card",
                "applicationVersion": {
                    "version": "1.0.0"
                }
            },
            "sap.ui": {
                "technology": "UI5",
                "icons": {
                    "icon": "sap-icon://technical-object"
                }
            },
            "sap.ui5": {
                "rootView": {
                    "viewName": "com.melodysuite.activity.cardcomponent.table",
                    "type": "XML",
                    "async": true,
                    "id": "app"
                },
                "dependencies": {
                    "minUI5Version": "1.38",
                    "libs": {
                        "sap.m": {},
                        "sap.ui.core": {}
                    }
                }
            },
            "sap.card": {
                "cardUIBindings": {
                    "cardId": "0014",
                    "columnSize": 2,
                    "viewSettings": {
                        "isVisible": true,
                        "api": "/"
                    },
                    "headerActionBtn": {
                        "isVisible": true,
                        "type": "Transparent",
                        "isTextVisible": true,
                        "text": "Register Activity",
                        "icon": "sap-icon://create-form"
                    },
                    "rowsAPI": "",
                    "columnsAggregation": [
                        {
                            "visible": true,
                            "text": "Actions",
                            "key": "01"
                        },
                        {
                            "visible": true,
                            "text": "Activity Type ",
                            "key": "02"
                        },
                        {
                            "visible": true,
                            "text": "Opportunity ID",
                            "key": "03"
                        },
                        {
                            "visible": true,
                            "text": "Account Name",
                            "key": "04"
                        },
                        {
                            "visible": true,
                            "text": "Start Date",
                            "key": "05"
                        },
                        {
                            "visible": true,
                            "text": "End Date",
                            "key": "06"
                        }
                    ],
                    "cellsAggregation": [
                        {
                            "controlType": "actions"
                        },
                        {
                            "controlType": "link"
                        },
                        {
                            "controlType": "text"
                        },
                        {
                            "controlType": "text"
                        },
                        {
                            "controlType": "text"
                        },
                        {
                            "controlType": "text"
                        }
                    ]
                },
                "type": "Component",
                "header": {
                    "title": "My Opportunities"
                }
            }
        },
        "TABLECRDMANIFEST": {
            "_version": "1.84.0",
            "type": "tablewithsearch",
            "sap.app": {
                "id": "card.explorer.table.card",
                "type": "card",
                "applicationVersion": {
                    "version": "1.0.0"
                }
            },
            "sap.ui": {
                "technology": "UI5",
                "icons": {
                    "icon": "sap-icon://table-view"
                }
            },
            "sap.card": {
                "configuration": {
                    "filters": {
                        "searchQuery": {
                            "type": "Search",
                            "label": "Company",
                            "placeholder": "Enter a company"
                        }
                    },
                    "destinations": {
                        "northwind": {
                            "name": "Northwind_V4",
                            "defaultUrl": "https://services.odata.org/V4/Northwind/Northwind.svc"
                        }
                    },
                    "childCards": {
                        "childCardManifest": {
                            "manifest": "./supplierManifest.json"
                        }
                    }
                },
                "type": "Table",
                "data": {
                    "request": {
                        "url": "{{destinations.northwind}}/Suppliers",
                        "parameters": {
                            "$select": "SupplierID, CompanyName, ContactName, ContactTitle, Fax, HomePage"
                        }
                    },
                    "path": "/value"
                },
                "header": {
                    "title": "Supplier contact overview",
                    "subtitle": "Select a row to view more details"
                },
                "content": {
                    "maxItems": 8,
                    "row": {
                        "columns": [
                            {
                                "title": "Contact Name",
                                "value": "{ContactName}"
                            },
                            {
                                "title": "Company Name",
                                "value": "{CompanyName}"
                            },
                            {
                                "title": "Contact Title",
                                "value": "{ContactTitle}"
                            }
                        ],
                        "actions": [
                            {
                                "type": "ShowCard",
                                "parameters": {
                                    "childCardKey": "childCardManifest",
                                    "parameters": {
                                        "supplierId": "{SupplierID}"
                                    }
                                }
                            }
                        ]
                    }
                }
            }
        },
        "TABLECRDWITHFILTER": {
            "_version": "1.84.0",
            "type": "tablewithdropdown",
            "sap.app": {
                "id": "card.explorer.table.grouping.card",
                "type": "card",
                "applicationVersion": {
                    "version": "1.0.0"
                }
            },
            "sap.ui": {
                "technology": "UI5",
                "icons": {
                    "icon": "sap-icon://table-view"
                }
            },
            "sap.card": {
                "type": "Table",
                "configuration": {
                    "filters": {
                        "shipper": {
                            "value": "{parameters>/selectedShipperID/value}",
                            "type": "Select",
                            "label": "Shipper",
                            "item": {
                                "path": "/value",
                                "template": {
                                    "key": "{ShipperID}",
                                    "title": "{CompanyName}"
                                }
                            },
                            "data": {
                                "request": {
                                    "url": "{{destinations.Northwind_V4}}/Shippers"
                                }
                            }
                        }
                    },
                    "destinations": {
                        "Northwind_V4": {
                            "name": "Northwind_V4",
                            "label": "Northwind V4 Service URL",
                            "defaultUrl": "https://services.odata.org/V4/Northwind/Northwind.svc"
                        }
                    },
                    "parameters": {
                        "maxOrdersShown": {
                            "value": 6,
                            "type": "integer",
                            "label": "Number of orders",
                            "description": "How many orders to show in the list."
                        },
                        "selectedShipperID": {
                            "value": 3,
                            "type": "integer",
                            "label": "The default selected shipper"
                        }
                    }
                },
                "data": {
                    "json": [
                        {
                            "salesOrder": "5000010050",
                            "netAmount": "2K USD",
                            "status": "Delivered",
                            "statusState": "Success",
                            "deliveryProgress": 100
                        },
                        {
                            "salesOrder": "5000010051",
                            "netAmount": "127k USD",
                            "status": "Canceled",
                            "statusState": "Error",
                            "deliveryProgress": 0
                        },
                        {
                            "salesOrder": "5000010052",
                            "netAmount": "8K USD",
                            "status": "In Progress",
                            "statusState": "Warning",
                            "deliveryProgress": 33
                        },
                        {
                            "salesOrder": "5000010053",
                            "netAmount": "25K USD",
                            "status": "Delivered",
                            "statusState": "Success",
                            "deliveryProgress": 100
                        },
                        {
                            "salesOrder": "5000010054",
                            "netAmount": "7K USD",
                            "status": "Delivered",
                            "statusState": "Success",
                            "deliveryProgress": 100
                        },
                        {
                            "salesOrder": "5000010050",
                            "netAmount": "2K USD",
                            "status": "Delivered",
                            "statusState": "Success",
                            "deliveryProgress": 100
                        },
                        {
                            "salesOrder": "5000010051",
                            "netAmount": "127k USD",
                            "status": "Canceled",
                            "statusState": "Error",
                            "deliveryProgress": 0
                        },
                        {
                            "salesOrder": "5000010052",
                            "netAmount": "8K USD",
                            "status": "In Progress",
                            "statusState": "Warning",
                            "deliveryProgress": 27
                        },
                        {
                            "salesOrder": "5000010052",
                            "netAmount": "8K USD",
                            "status": "In Progress",
                            "statusState": "Warning",
                            "deliveryProgress": 51
                        }
                    ]
                },
                "header": {
                    "title": "Sales Orders for Key Accounts",
                    "subtitle": "Today"
                },
                "content": {
                    "row": {
                        "columns": [
                            {
                                "title": "Sales Order",
                                "value": "{salesOrder}",
                                "identifier": true
                            },
                            {
                                "title": "Net Amount",
                                "value": "{netAmount}",
                                "hAlign": "End"
                            },
                            {
                                "title": "Status",
                                "value": "{status}",
                                "state": "{statusState}"
                            },
                            {
                                "title": "Delivery Progress",
                                "progressIndicator": {
                                    "percent": "{deliveryProgress}",
                                    "text": "{= format.percent(${deliveryProgress} / 100)}",
                                    "state": "{statusState}"
                                }
                            }
                        ]
                    },
                    "group": {
                        "title": "{= ${deliveryProgress} > 10 ? 'In Delivery' : 'Not in Delivery'}",
                        "order": {
                            "path": "statusState",
                            "dir": "ASC"
                        }
                    }
                }
            }
        },
        "QUICKVIEWSTACK": {
            "_version": "1.84.0",
            "sap.app": {
                "id": "com.melodysuite.activity",
                "type": "customstackcard",
                "title": "Quick View Stack Card",
                "applicationVersion": {
                    "version": "1.0.0"
                },
                "tags": {
                    "keywords": [
                        "Component",
                        "Card"
                    ]
                }
            },
            "sap.ui": {
                "technology": "UI5",
                "icons": {
                    "icon": "sap-icon://request"
                }
            },
            "sap.ui5": {
                "rootView": {
                    "viewName": "com.melodysuite.activity.cardcomponent.stack.Quickview",
                    "type": "XML",
                    "async": true,
                    "id": "app"
                },
                "dependencies": {
                    "minUI5Version": "1.38",
                    "libs": {
                        "sap.m": {},
                        "sap.ui.core": {}
                    }
                }
            },
            "sap.card": {
                "cardUIBindings": {
                    "cardId": "crypto.randomUUID()",
                    "columnSize": 1,
                    "quickViewStack": {
                        "title": "Required Actions",
                        "subTitle": "Items that needs your action",
                        "value": "7",
                        "total": "7"
                    },
                    "service": {
                        "url": "",
                        "type": "REQUERIED_ACTION"
                    },
                    "objectStream": {
                        "templateType": "DYNAMIC",
                        "data": [
                            {
                                "cardTitle": "Request",
                                "header": {
                                    "title": "GCO Account",
                                    "subTitle": "Man Lee",
                                    "icon": "sap-icon://request"
                                },
                                "displayTimeSection": false,
                                "primary": {
                                    "title": "CS Hong Kong - Solution Advisor",
                                    "elements": [
                                        {
                                            "label": "Req ID Main/Sub",
                                            "type": "LINK",
                                            "value": "70000006476 / 70000004635"
                                        },
                                        {
                                            "label": "Opp Description",
                                            "type": "LINK",
                                            "value": "Melody Test Opp 02"
                                        },
                                        {
                                            "label": "IAC",
                                            "type": "TEXT",
                                            "value": "Non-IAC Focused"
                                        }
                                    ]
                                },
                                "secondary": {
                                    "title": "In Review - Processor",
                                    "elements": [
                                        {
                                            "label": "Comments",
                                            "type": "TEXT",
                                            "value": "This is a great Opportunity!"
                                        }
                                    ]
                                },
                                "footer": [
                                    {
                                        "text": "Assign Resources",
                                        "tooltip": "Assign Resources",
                                        "type": "Accept",
                                        "icon": ""
                                    },
                                    {
                                        "text": "Reject Request",
                                        "tooltip": "Reject Request",
                                        "type": "Reject",
                                        "icon": ""
                                    },
                                    {
                                        "text": "Send Back To Requestor",
                                        "tooltip": "Send Back To Requestor",
                                        "type": "Default",
                                        "icon": ""
                                    }
                                ]
                            },
                            {
                                "cardTitle": "Activity Past The End Date",
                                "header": {
                                    "title": "Solution Discovery",
                                    "subTitle": "Jane Jayjock",
                                    "icon": "sap-icon://request"
                                },
                                "displayTimeSection": false,
                                "primary": {
                                    "title": "Nike Inc. (167545)",
                                    "elements": [
                                        {
                                            "label": "Opportunity",
                                            "type": "LINK",
                                            "value": "Nike Transformation"
                                        },
                                        {
                                            "label": "End Date",
                                            "type": "LINK",
                                            "value": "March 12, 2026"
                                        },
                                        {
                                            "label": "Status",
                                            "type": "TEXT",
                                            "value": "Registered"
                                        }
                                    ]
                                },
                                "secondary": {},
                                "footer": [
                                    {
                                        "type": "TOOLBARSPACER"
                                    },
                                    {
                                        "text": "Edit Activity",
                                        "tooltip": "Edit Activity",
                                        "type": "Default",
                                        "icon": ""
                                    }
                                ]
                            },
                            {
                                "cardTitle": "Discontinued Opportunity",
                                "header": {
                                    "title": "Demo (312833)",
                                    "subTitle": "Geff Gilligan",
                                    "icon": "sap-icon://stop"
                                },
                                "displayTimeSection": false,
                                "primary": {
                                    "title": "Nike Inc. (167545)",
                                    "elements": [
                                        {
                                            "label": "Current Opp",
                                            "type": "LINK",
                                            "value": "Nike Transformation"
                                        },
                                        {
                                            "label": "Opp Status",
                                            "type": "TEXT",
                                            "value": "Discontinued"
                                        },
                                        {
                                            "label": "Parallel Opp",
                                            "type": "TEXT",
                                            "value": "Not Defined"
                                        }
                                    ]
                                },
                                "secondary": {},
                                "footer": [
                                    {
                                        "type": "TOOLBARSPACER",
                                        "visible": true
                                    },
                                    {
                                        "text": "Update Opportunity",
                                        "tooltip": "Update Opportunity",
                                        "type": "Default",
                                        "icon": ""
                                    }
                                ]
                            }
                        ]
                    }
                },
                "type": "Component"
            }
        },
        "QUICKVIEWACTSTACK": {
            "_version": "1.84.0",
            "sap.app": {
                "id": "com.melodysuite.activity",
                "type": "customstackcard",
                "title": "Quick View Stack Card",
                "applicationVersion": {
                    "version": "1.0.0"
                },
                "tags": {
                    "keywords": [
                        "Component",
                        "Card"
                    ]
                }
            },
            "sap.ui": {
                "technology": "UI5",
                "icons": {
                    "icon": "sap-icon://request"
                }
            },
            "sap.ui5": {
                "rootView": {
                    "viewName": "com.melodysuite.activity.cardcomponent.stack.Quickview",
                    "type": "XML",
                    "async": true,
                    "id": "app"
                },
                "dependencies": {
                    "minUI5Version": "1.38",
                    "libs": {
                        "sap.m": {},
                        "sap.ui.core": {}
                    }
                }
            },
            "sap.card": {
                "cardUIBindings": {
                    "cardId": "crypto.randomUUID()",
                    "columnSize": 1,
                    "quickViewStack": {
                        "title": "Activities without Time",
                        "subTitle": "Enter your time invested",
                        "value": "7",
                        "total": "34"
                    },
                    "service": {
                        "url": "",
                        "type": "ACTIVITY_WITHOUT_TIME"
                    },
                    "objectStream": {
                        "templateType": "AGGREGATION",
                        "data": [
                            {
                                "cardTitle": "Activity Without Time",
                                "header": {
                                    "title": "{ActivityType}",
                                    "subTitle": "{ActLeadName}",
                                    "icon": "sap-icon://request"
                                },
                                "displayTimeSection": true,
                                "primary": {
                                    "title": "account_name\nglobal_ultimate_id",
                                    "elements": [
                                        {
                                            "label": "Opportunity",
                                            "type": "LINK",
                                            "value": "opportunityno",
                                            "highlight": false
                                        },
                                        {
                                            "label": "End Date",
                                            "type": "TEXT",
                                            "value": "EndActDate"
                                        },
                                        {
                                            "label": "Status",
                                            "type": "TEXT",
                                            "value": "Status"
                                        }
                                    ]
                                },
                                "secondary": {},
                                "footer": [
                                    {
                                        "type": "TOOLBARSPACER"
                                    },
                                    {
                                        "text": "Create Time Entry",
                                        "tooltip": "Create Time Entry",
                                        "type": "Default",
                                        "icon": ""
                                    },
                                    {
                                        "text": "",
                                        "tooltip": "More Actions",
                                        "type": "Default",
                                        "icon": "sap-icon://overflow"
                                    }
                                ]
                            }
                        ]
                    }
                },
                "type": "Component"
            }
        },
        "QUICKVIEWDISOPPSTACK": {
            "_version": "1.84.0",
            "sap.app": {
                "id": "com.melodysuite.activity",
                "type": "customstackcard",
                "title": "Quick View Stack Card",
                "applicationVersion": {
                    "version": "1.0.0"
                },
                "tags": {
                    "keywords": [
                        "Component",
                        "Card"
                    ]
                }
            },
            "sap.ui": {
                "technology": "UI5",
                "icons": {
                    "icon": "sap-icon://request"
                }
            },
            "sap.ui5": {
                "rootView": {
                    "viewName": "com.melodysuite.activity.cardcomponent.stack.Quickview",
                    "type": "XML",
                    "async": true,
                    "id": "app"
                },
                "dependencies": {
                    "minUI5Version": "1.38",
                    "libs": {
                        "sap.m": {},
                        "sap.ui.core": {}
                    }
                }
            },
            "sap.card": {
                "cardUIBindings": {
                    "cardId": "crypto.randomUUID()",
                    "columnSize": 1,
                    "quickViewStack": {
                        "title": "Activities with Discontinued Opps",
                        "subTitle": "Update the associated opportunities",
                        "value": "3",
                        "total": "34"
                    },
                    "service": {
                        "url": "",
                        "type": "ACTIVITY_DISCONTINUED_OPPORTUNITY"
                    },
                    "objectStream": {
                        "templateType": "AGGREGATION",
                        "data": [
                            {
                                "cardTitle": "Activities with Discontinued Opps",
                                "header": {
                                    "title": "{ActivityType}",
                                    "subTitle": "{ActLeadName}",
                                    "icon": "sap-icon://request"
                                },
                                "displayTimeSection": true,
                                "primary": {
                                    "title": "account_name\nglobal_ultimate_id",
                                    "elements": [
                                        {
                                            "label": "Discontinued Opportunity",
                                            "type": "LINK",
                                            "value": "opportunitydescription\nopportunityno",
                                            "highlight": true
                                        },
                                        {
                                            "label": "End Date",
                                            "type": "TEXT",
                                            "value": "EndActDate",
                                            "highlight": false
                                        },
                                        {
                                            "label": "Status",
                                            "type": "TEXT",
                                            "value": "Status",
                                            "highlight": false
                                        }
                                    ]
                                },
                                "secondary": {},
                                "footer": [
                                    {
                                        "type": "TOOLBARSPACER"
                                    },
                                    {
                                        "text": "Edit Registration",
                                        "tooltip": "Edit Registration",
                                        "type": "Default",
                                        "icon": ""
                                    },
                                    {
                                        "text": "",
                                        "tooltip": "More Actions",
                                        "type": "Default",
                                        "icon": "sap-icon://overflow"
                                    }
                                ]
                            }
                        ]
                    }
                },
                "type": "Component"
            }
        },
        "QUICKVIEWACTPASTENDDATESTACK": {
            "_version": "1.84.0",
            "sap.app": {
                "id": "com.melodysuite.activity",
                "type": "customstackcard",
                "title": "Quick View Stack Card",
                "applicationVersion": {
                    "version": "1.0.0"
                },
                "tags": {
                    "keywords": [
                        "Component",
                        "Card"
                    ]
                }
            },
            "sap.ui": {
                "technology": "UI5",
                "icons": {
                    "icon": "sap-icon://request"
                }
            },
            "sap.ui5": {
                "rootView": {
                    "viewName": "com.melodysuite.activity.cardcomponent.stack.Quickview",
                    "type": "XML",
                    "async": true,
                    "id": "app"
                },
                "dependencies": {
                    "minUI5Version": "1.38",
                    "libs": {
                        "sap.m": {},
                        "sap.ui.core": {}
                    }
                }
            },
            "sap.card": {
                "cardUIBindings": {
                    "cardId": "crypto.randomUUID()",
                    "columnSize": 1,
                    "quickViewStack": {
                        "title": "Activities Past the End Date",
                        "subTitle": "Update the activities with end dates in the past",
                        "value": "4",
                        "total": "34"
                    },
                    "service": {
                        "url": "",
                        "type": "ACTIVITY_PAST_ENDDATE"
                    },
                    "objectStream": {
                        "templateType": "AGGREGATION",
                        "data": [
                            {
                                "cardTitle": "Activities Past the End Date",
                                "header": {
                                    "title": "{ActivityType}",
                                    "subTitle": "{ActLeadName}",
                                    "icon": "sap-icon://request"
                                },
                                "displayTimeSection": true,
                                "primary": {
                                    "title": "account_name\nglobal_ultimate_id",
                                    "elements": [
                                        {
                                            "label": "Opportunity",
                                            "type": "LINK",
                                            "value": "opportunityno",
                                            "highlight": false
                                        },
                                        {
                                            "label": "End Date",
                                            "type": "TEXT",
                                            "value": "EndActDate",
                                            "highlight": true
                                        },
                                        {
                                            "label": "Status",
                                            "type": "TEXT",
                                            "value": "Status",
                                            "highlight": false
                                        }
                                    ]
                                },
                                "secondary": {},
                                "footer": [
                                    {
                                        "type": "TOOLBARSPACER"
                                    },
                                    {
                                        "text": "Edit Registration",
                                        "tooltip": "Edit Registration",
                                        "type": "Default",
                                        "icon": ""
                                    },
                                    {
                                        "text": "",
                                        "tooltip": "More Actions",
                                        "type": "Default",
                                        "icon": "sap-icon://overflow"
                                    }
                                ]
                            }
                        ]
                    }
                },
                "type": "Component"
            }
        },
        "QUICKVIEWREQUESTPROCESSSTACK": {
            "_version": "1.84.0",
            "sap.app": {
                "id": "com.melodysuite.activity",
                "type": "customstackcard",
                "title": "Quick View Stack Card",
                "applicationVersion": {
                    "version": "1.0.0"
                },
                "tags": {
                    "keywords": [
                        "Component",
                        "Card"
                    ]
                }
            },
            "sap.ui": {
                "technology": "UI5",
                "icons": {
                    "icon": "sap-icon://request"
                }
            },
            "sap.ui5": {
                "rootView": {
                    "viewName": "com.melodysuite.activity.cardcomponent.stack.Quickview",
                    "type": "XML",
                    "async": true,
                    "id": "app"
                },
                "dependencies": {
                    "minUI5Version": "1.38",
                    "libs": {
                        "sap.m": {},
                        "sap.ui.core": {}
                    }
                }
            },
            "sap.card": {
                "cardUIBindings": {
                    "cardId": "crypto.randomUUID()",
                    "columnSize": 1,
                    "quickViewStack": {
                        "title": "Requests to Process",
                        "subTitle": "Requests that need your action",
                        "value": "7",
                        "total": "7"
                    },
                    "service": {
                        "url": "",
                        "type": "MR_REQUEST_PROCESS"
                    },
                    "objectStream": {
                        "templateType": "AGGREGATION",
                        "data": [
                            {
                                "cardTitle": "Requests to Process",
                                "header": {
                                    "title": "Req Sub :{requestId}",
                                    "subTitle": "ActLeadName",
                                    "icon": "sap-icon://request"
                                },
                                "displayTimeSection": true,
                                "primary": {
                                    "title": "region\nrole",
                                    "elements": [
                                        {
                                            "label": "Opp Number",
                                            "type": "LINK",
                                            "value": "opportunityno",
                                            "highlight": false
                                        },
                                        {
                                            "label": "Creation Date",
                                            "type": "TEXT",
                                            "value": "EndActDate",
                                            "highlight": false
                                        },
                                        {
                                            "label": "IAC",
                                            "type": "TEXT",
                                            "value": "Iac",
                                            "highlight": false
                                        }
                                    ]
                                },
                                "secondary": {
                                    "title": "status\nrole",
                                    "elements": [
                                        {
                                            "label": "Comments",
                                            "type": "LINK",
                                            "value": "comments",
                                            "highlight": false
                                        }
                                    ]
                                },
                                "footer": [
                                    {
                                        "type": "TOOLBARSPACER"
                                    },
                                    {
                                        "text": "Process Request",
                                        "tooltip": "Process Request",
                                        "type": "Default",
                                        "icon": ""
                                    }
                                ]
                            }
                        ]
                    }
                },
                "type": "Component"
            }
        },
        "APIDATACARDS": [
            {
                "_version": "1.85.0",
                "sap.app": {
                    "id": "card.explorer.data.list.card",
                    "type": "card",
                    "title": "Sample for Data usage in Cards",
                    "subTitle": "Sample for Data usage in Cards",
                    "applicationVersion": {
                        "version": "1.0.0"
                    },
                    "shortTitle": "A short title for this Card",
                    "info": "Additional information about this Card",
                    "description": "A long description for this Card",
                    "tags": {
                        "keywords": [
                            "Data",
                            "Card",
                            "Sample"
                        ]
                    }
                },
                "sap.card": {
                    "type": "List",
                    "header": {
                        "title": "My Succesline",
                        "subtitle": "Subtitle",
                        "icon": {
                            "src": "sap-icon://product"
                        }
                    },
                    "content": {
                        "data": {
                            "request": {
                                "url": "./int_ls/sap/opu/odata/SAP/YMELODY_SRV/YC_SL_T_MYSL_CARD",
                                "method": "GET",
                                "parameters": {
                                    "$format": "json"
                                }
                            },
                            "path": "/value"
                        },
                        "item": {
                            "Account ID": "{AccountId}",
                            "SL Name": "{SlName}",
                            "Complete %": "{SlCompletionPer}"
                        },
                        "maxItems": 5
                    }
                }
            },
            {
                "_version": "1.85.0",
                "sap.app": {
                    "id": "card.explorer.data.list.card",
                    "type": "card",
                    "title": "Sample for Client-Side Pagination in Cards",
                    "subTitle": "Sample for Client-Side Pagination in Cards",
                    "applicationVersion": {
                        "version": "1.0.0"
                    },
                    "shortTitle": "A short title for this Card",
                    "info": "Additional information about this Card",
                    "description": "A long description for this Card",
                    "tags": {
                        "keywords": [
                            "Data",
                            "Pagination",
                            "Card",
                            "Sample"
                        ]
                    }
                },
                "sap.card": {
                    "type": "List",
                    "data": {
                        "request": {
                            "url": "https://services.odata.org/V4/Northwind/Northwind.svc/Products",
                            "parameters": {
                                "$format": "json",
                                "$top": 20
                            }
                        },
                        "path": "/value"
                    },
                    "header": {
                        "title": "Products",
                        "subtitle": "In Stock Information",
                        "icon": {
                            "src": "sap-icon://product"
                        },
                        "status": {
                            "text": "{= format.text(${i18n>CARD.COUNT_X_OF_Y}, [${parameters>/visibleItems}, ${/value}.length]) }"
                        }
                    },
                    "content": {
                        "item": {
                            "title": "{ProductName}",
                            "description": "{UnitsInStock} units in stock",
                            "highlight": "{= ${Discontinued} ? 'Error' : 'Success'}"
                        }
                    },
                    "footer": {
                        "paginator": {
                            "pageSize": 5
                        },
                        "actionsStrip": [
                            {
                                "text": "Approve",
                                "overflowPriority": "High",
                                "actions": [
                                    {
                                        "type": "Custom",
                                        "parameters": {
                                            "method": "approve"
                                        }
                                    }
                                ]
                            },
                            {
                                "buttonType": "Reject",
                                "text": "Reject",
                                "overflowPriority": "High",
                                "actions": [
                                    {
                                        "type": "Custom",
                                        "parameters": {
                                            "method": "reject"
                                        }
                                    }
                                ]
                            },
                            {
                                "buttonType": "Transparent",
                                "text": "Details",
                                "ariaHasPopup": "Dialog",
                                "actions": [
                                    {
                                        "type": "Custom",
                                        "parameters": {
                                            "method": "openSnack"
                                        }
                                    }
                                ]
                            },
                            {
                                "buttonType": "Transparent",
                                "icon": "sap-icon://email",
                                "text": "Contact",
                                "actions": [
                                    {
                                        "type": "Navigation",
                                        "parameters": {
                                            "url": "mailto:{email}"
                                        }
                                    }
                                ]
                            },
                            {
                                "buttonType": "Transparent",
                                "text": "Book a Meeting",
                                "overflowPriority": "AlwaysOverflow",
                                "actions": [
                                    {
                                        "type": "Navigation",
                                        "enabled": false,
                                        "parameters": {
                                            "url": "{agendaUrl}"
                                        }
                                    }
                                ]
                            },
                            {
                                "buttonType": "Transparent",
                                "text": "Contact Company",
                                "overflowPriority": "AlwaysOverflow",
                                "actions": [
                                    {
                                        "type": "Navigation",
                                        "parameters": {
                                            "url": "mailto:{company/email}?subject={company/emailSubject}"
                                        }
                                    }
                                ]
                            }
                        ]
                    }
                }
            },
            {
                "_version": "1.85.0",
                "sap.app": {
                    "id": "card.explorer.pagination.table",
                    "type": "card",
                    "title": "Table Card with Server-Side Pagination",
                    "subTitle": "",
                    "applicationVersion": {
                        "version": "1.0.0"
                    },
                    "shortTitle": "A short title for this Card",
                    "info": "Additional information about this Card",
                    "description": "A long description for this Card",
                    "tags": {
                        "keywords": [
                            "Data",
                            "Pagination",
                            "Card",
                            "Sample"
                        ]
                    }
                },
                "sap.card": {
                    "type": "Table",
                    "header": {
                        "title": "Table Pagination",
                        "status": {
                            "text": {
                                "format": {
                                    "translationKey": "i18n>CARD.COUNT_X_OF_Y",
                                    "parts": [
                                        "parameters>/visibleItems",
                                        "/@odata.count"
                                    ]
                                }
                            }
                        }
                    },
                    "content": {
                        "row": {
                            "columns": [
                                {
                                    "title": "Product",
                                    "value": "{ProductName}"
                                },
                                {
                                    "title": "Quantity Per Unit",
                                    "value": "{QuantityPerUnit}"
                                }
                            ]
                        }
                    },
                    "footer": {
                        "paginator": {
                            "totalCount": "{/@odata.count}",
                            "pageSize": 7
                        }
                    },
                    "data": {
                        "request": {
                            "url": "https://services.odata.org/V4/Northwind/Northwind.svc/Products",
                            "parameters": {
                                "$count": true,
                                "$skip": "{paginator>/skip}",
                                "$top": "{paginator>/size}"
                            }
                        },
                        "path": "/value"
                    }
                }
            },
            {
                "_version": "1.85.0",
                "sap.app": {
                    "id": "card.explorer.pagination.timeline",
                    "type": "card",
                    "title": "Timeline Card with Pagination",
                    "subTitle": "",
                    "applicationVersion": {
                        "version": "1.0.0"
                    },
                    "shortTitle": "A short title for this Card",
                    "info": "Additional information about this Card",
                    "description": "A long description for this Card",
                    "tags": {
                        "keywords": [
                            "Action",
                            "Host",
                            "Card",
                            "Sample"
                        ]
                    }
                },
                "sap.ui": {
                    "technology": "UI5",
                    "icons": {
                        "icon": "sap-icon://action"
                    }
                },
                "sap.card": {
                    "type": "Timeline",
                    "data": {
                        "request": {
                            "url": "https://services.odata.org/V4/Northwind/Northwind.svc/Orders",
                            "parameters": {
                                "$count": true,
                                "$skip": "{paginator>/skip}",
                                "$top": "{paginator>/size}",
                                "$orderby": "OrderDate desc"
                            }
                        },
                        "path": "/value"
                    },
                    "header": {
                        "title": "Timeline Pagination",
                        "status": {
                            "text": {
                                "format": {
                                    "translationKey": "i18n>CARD.COUNT_X_OF_Y",
                                    "parts": [
                                        "parameters>/visibleItems",
                                        "/@odata.count"
                                    ]
                                }
                            }
                        }
                    },
                    "content": {
                        "item": {
                            "dateTime": {
                                "value": "{OrderDate}"
                            },
                            "description": {
                                "value": "Order: {OrderID}, Address: {ShipAddress}"
                            },
                            "title": {
                                "value": "{ShipName}"
                            }
                        }
                    },
                    "footer": {
                        "paginator": {
                            "totalCount": "{/@odata.count}",
                            "pageSize": 5
                        }
                    }
                }
            },
            {
                "_version": "1.85.0",
                "sap.app": {
                    "id": "card.explorer.table.card",
                    "type": "card",
                    "title": "Sample of a Table Card",
                    "subTitle": "Sample of a Table Card",
                    "applicationVersion": {
                        "version": "1.0.0"
                    },
                    "shortTitle": "A short title for this Card",
                    "info": "Additional information about this Card",
                    "description": "A long description for this Card",
                    "tags": {
                        "keywords": [
                            "Table",
                            "Card",
                            "Sample"
                        ]
                    }
                },
                "sap.ui": {
                    "technology": "UI5",
                    "icons": {
                        "icon": "sap-icon://table-view"
                    }
                },
                "sap.card": {
                    "type": "Table",
                    "data": {
                        "request": {
                            "url": "https://services.odata.org/V4/Northwind/Northwind.svc/Products",
                            "method": "GET",
                            "parameters": {
                                "$format": "json"
                            }
                        },
                        "path": "/value"
                    },
                    "header": {
                        "title": "Sales Orders for Key Accounts",
                        "subtitle": "Today"
                    },
                    "content": {
                        "maxItems": 9,
                        "row": {
                            "columns": [
                                {
                                    "title": "Product",
                                    "value": "{ProductName}",
                                    "additionalText": "{salesOrder}",
                                    "identifier": true
                                },
                                {
                                    "title": "Description",
                                    "value": "{UnitsInStock} units in stock",
                                    "hAlign": "End"
                                },
                                {
                                    "title": "Status",
                                    "value": "{= ${Discontinued}?'Canceled':'Delivered'}",
                                    "state": "{= ${Discontinued} ? 'Warning' : 'Success'}",
                                    "showStateIcon": true,
                                    "inverted": true
                                }
                            ]
                        }
                    }
                }
            }
        ],
        "MANAGERANALYTICCARD": {
            "_version": "1.85.0",
            "sap.app": {
                "id": "card.explorer.stacked.column.card",
                "type": "card",
                "applicationVersion": {
                    "version": "1.0.0"
                }
            },
            "sap.ui": {
                "technology": "UI5",
                "icons": {
                    "icon": "sap-icon://full-stacked-column-chart"
                }
            },
            "sap.card": {
                "configuration": {
                    "parameters": {
                        "selectedShipperID": {
                            "value": "1",
                            "type": "string",
                            "label": "Default selected shipper"
                        }
                    },
                    "filters": {
                        "shipper": {
                            "type": "Select",
                            "label": "Team Members",
                            "value": "{parameters>/selectedShipperID}",
                            "item": {
                                "path": "/items",
                                "template": {
                                    "key": "{ID}",
                                    "title": "{Text}"
                                }
                            },
                            "data": {
                                "json": {
                                    "items": [
                                        {
                                            "ID": "1",
                                            "Text": "All Team Members"
                                        },
                                        {
                                            "ID": "2",
                                            "Text": "[direct report]"
                                        },
                                        {
                                            "ID": "3",
                                            "Text": "Jane Deo"
                                        }
                                    ]
                                }
                            }
                        }
                    }
                },
                "type": "Analytical",
                "header": {
                    "type": "Numeric",
                    "title": "Team Time Entries (Last Three Months)",
                    "data": {
                        "json": {
                            "n": "56",
                            "u": "%",
                            "trend": "Up",
                            "valueColor": "Good"
                        }
                    }
                },
                "content": {
                    "chartType": "stacked_column",
                    "chartProperties": {
                        "legendGroup": {
                            "position": "bottom",
                            "alignment": "topLeft"
                        },
                        "plotArea": {
                            "dataLabel": {
                                "visible": false,
                                "showTotal": true
                            }
                        },
                        "categoryAxis": {
                            "title": {
                                "visible": false
                            }
                        },
                        "valueAxis": {
                            "title": {
                                "visible": false
                            }
                        },
                        "title": {
                            "text": "Stacked column chart",
                            "alignment": "left",
                            "visible": false
                        }
                    },
                    "data": {
                        "json": {
                            "list": [
                                {
                                    "Week": "JAN",
                                    "NCF": 350,
                                    "CF": 199
                                },
                                {
                                    "Week": "FEB",
                                    "NCF": 380,
                                    "CF": 220
                                },
                                {
                                    "Week": "MAR",
                                    "NCF": 300,
                                    "CF": 200
                                }
                            ]
                        },
                        "path": "/list"
                    },
                    "dimensions": [
                        {
                            "name": "Weeks",
                            "value": "{Week}"
                        }
                    ],
                    "measures": [
                        {
                            "name": "NCF",
                            "value": "{NCF}"
                        },
                        {
                            "name": "CF",
                            "value": "{CF}"
                        }
                    ],
                    "feeds": [
                        {
                            "type": "Dimension",
                            "uid": "categoryAxis",
                            "values": [
                                "Weeks"
                            ]
                        },
                        {
                            "type": "Measure",
                            "uid": "valueAxis",
                            "values": [
                                "NCF",
                                "CF"
                            ]
                        }
                    ]
                }
            }
        },
        "ACTIVITYBYCVJPHASE": {
            "_version": "1.84.0",
            "sap.app": {
                "id": "com.melodysuite.activity",
                "type": "customcomparisonchart",
                "title": "Comparision Chart",
                "applicationVersion": {
                    "version": "1.0.0"
                },
                "tags": {
                    "keywords": [
                        "Component",
                        "Card"
                    ]
                }
            },
            "sap.ui": {
                "technology": "UI5",
                "icons": {
                    "icon": "sap-icon://request"
                }
            },
            "sap.ui5": {
                "rootView": {
                    "viewName": "com.melodysuite.activity.cardcomponent.analytical.ComparisionBarChart",
                    "type": "XML",
                    "async": true,
                    "id": "app"
                },
                "dependencies": {
                    "minUI5Version": "1.38",
                    "libs": {
                        "sap.m": {},
                        "sap.ui.core": {}
                    }
                }
            },
            "sap.card": {
                "cardUIBindings": {
                    "cardId": "crypto.randomUUID()",
                    "columnSize": 1,
                    "header": {
                        "title": "Activities by CVJ Phase",
                        "subTitle": "Current year"
                    },
                    "service": {
                        "url": "",
                        "type": "ACTIVITY_BY_CVJ_PHASE"
                    },
                    "content": {}
                },
                "type": "Component"
            }
        },
        "DAYWEEKMTRCARD": {
            "_version": "1.84.0",
            "sap.app": {
                "id": "com.melodysuite.activity",
                "type": "customdayweekmtrcard",
                "title": "Time Entry",
                "applicationVersion": {
                    "version": "1.0.0"
                },
                "tags": {
                    "keywords": [
                        "Component",
                        "Card"
                    ]
                }
            },
            "sap.ui": {
                "technology": "UI5",
                "icons": {
                    "icon": "sap-icon://request"
                }
            },
            "sap.ui5": {
                "rootView": {
                    "viewName": "com.melodysuite.activity.cardcomponent.time.dayweekmtr",
                    "type": "XML",
                    "async": true,
                    "id": "app"
                },
                "dependencies": {
                    "minUI5Version": "1.38",
                    "libs": {
                        "sap.m": {},
                        "sap.ui.core": {}
                    }
                }
            },
            "sap.card": {
                "cardUIBindings": {
                    "cardId": "crypto.randomUUID()",
                    "columnSize": 1,
                    "header": {
                        "title": "Time Entries",
                        "subTitle": ""
                    },
                    "service": {
                        "url": "",
                        "type": "DAY_WEEK_TIME_ENTRY"
                    },
                    "content": {}
                },
                "type": "Component"
            }
        },
        "APICARDSL": {
            "_version": "1.85.0",
            "sap.app": {
                "id": "card.explorer.data.list.card",
                "type": "card",
                "applicationVersion": {
                    "version": "1.0.0"
                }
            },
            "sap.card": {
                "type": "List",
                "header": {
                    "title": "My Succesline",
                    "subtitle": "Subtitle",
                    "icon": {
                        "src": "sap-icon://product"
                    }
                },
                "content": {
                    "data": {
                        "request": {
                            "url": "./int_ls/sap/opu/odata/sap/YMELODY_SRV/YC_SL_T_MYSL_CARD",
                            "method": "GET",
                            "parameters": {
                                "$format": "json"
                            }
                        },
                        "path": "/d/results"
                    },
                    "item": {
                        "Account ID": "{AccountId}",
                        "SL Name": "{SlName}",
                        "Complete %": "{SlCompletionPer}"
                    },
                    "maxItems": 5
                }
            }
        }
    },
    true,
);
