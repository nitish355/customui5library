// @ts-nocheck
sap.ui.define(
  [
    "sap/base/Log",
    "sap/ui/base/Object",
    "sap/ui/util/Storage",
    "sap/ui/core/UIComponent",
    "sap/ui/model/json/JSONModel",
    "com/melodysuite/activity/util/MasterData",
    "com/melodylib/core/util/usersettings/Usermaster",
  ],
  function (Log, BaseObject, Storage, UIComponent, JSONModel, oMasterData, oUsermaster) {
    "use strict";
    /* @type sap.ui.base.Object */
    let instance;
    /* @type sap.ui.base.Object */
    const Application = BaseObject.extend(
      "com.melodysuite.activity.util.Application",
      {
        constructor: function () {
          if (!this.sloStorage) {
            this.sloStorage = jQuery.sap.storage(
              jQuery.sap.storage.Type.session
            );
          }
          if (!this.constStorage) {
            this.constStorage = new Storage(Storage.Type.session);
          }
        },

        init: function (oComponent) {
          this.Component = oComponent;
          this._initModels();
          this.fnCheckUserAuth();
        },

        //intialize models
        _initModels: function () {
          // set the model to the view
          this.Component.setModel(
            new JSONModel({
              isAppBusy: false,
              isTableBusy: true,
              isActvtListBusy: false,
              isItemBusy: false,
            }),
            "appSettings"
          );

          // set the model to the view
          this.Component.setModel(new JSONModel([]), "masterData");
        },

        //function to check user auth
        fnCheckUserAuth: function () {
          let oThisController = this;
          let isNonOreUser = false;
          let oAppSettingsModel = this.Component.getModel("appSettings");
          oAppSettingsModel.setProperty("/isAppBusy", true);
          oUsermaster
            .authenticate()
            .then((oResponse) => {
              let oUserData = { ...oResponse };
              if (
                oUserData &&
                "oNonOreData" in oUserData &&
                "data" in oUserData["oNonOreData"]
              ) {
                let oOreData = oUserData?.oNonOreData?.data;
                if (oOreData.EditAuth !== "X") {
                  //Non-ore
                  //To Make Sure Not to Edit any fields in the UI
                  isNonOreUser = true;

                } else {
                  isNonOreUser = false;
                  oThisController.Component.getModel(
                    "masterDataModel"
                  ).setProperty("/oUserData", oUserData);
                  // enable routing

                  oThisController.loadMasterData();
                }
                oAppSettingsModel.setProperty("/isNonOreUser", isNonOreUser);
                this.handleNonOreNavigation(isNonOreUser)

              }
            })
            .catch((oError) => {
              console.log("ERROR IN fnCheckUserAuth : ", oError);
              oAppSettingsModel.setProperty("/isAppBusy", false);
            });
        },

        //function to load master data
        loadMasterData: async function () {
          let oThisController = this;
          let oAppSettingsModel = this.Component.getModel("appSettings");
          let MasterDataModel = this.Component.getModel("masterDataModel");
          let aMasterData = [
            oMasterData.getActivityListStatus(),
            oMasterData.getActivityListDelTeam(),
            oMasterData.getActivityListHostType(),
            oMasterData.getActivityListLandScape(),
            oMasterData.getActivityListProjectType(),
            oMasterData.getActivityListRegion(),
            oMasterData.getActDetRiskButtons(),
            oMasterData.getActivityListStrategicAreaMasterData(),
            oMasterData.getActivityListShowroomMasterData(),
            oMasterData.getActivityListUseCaseMasterData(),
            oMasterData.getActivityListRoleMasterData(),
          ];

          Promise.allSettled(aMasterData)
            .then((aResponse) => {
              MasterDataModel.setProperty(
                "/ActivityStatusList",
                aResponse[0].value
              );
              MasterDataModel.setProperty(
                "/aActListDelTeam",
                aResponse[1].value
              );
              MasterDataModel.setProperty(
                "/aActListHostType",
                aResponse[2].value
              );
              MasterDataModel.setProperty(
                "/ActivityLandScapesList",
                aResponse[3].value
              );
              MasterDataModel.setProperty(
                "/aActListProjType",
                aResponse[4].value
              );
              MasterDataModel.setProperty(
                "/aActListRegion",
                aResponse[5].value
              );
              MasterDataModel.setProperty(
                "/ActivityRiskList",
                aResponse[6].value
              );
              MasterDataModel.setProperty(
                "/ActivityInnovationsList",
                aResponse[7].value
              );
              MasterDataModel.setProperty(
                "/ActivityShowroomList",
                aResponse[8].value
              );
              MasterDataModel.setProperty(
                "/ActivityUseCaseList",
                aResponse[9].value
              );
              MasterDataModel.setProperty("/RolesList", aResponse[10].value);
              oAppSettingsModel.setProperty("/isAppBusy", false);
            })
            .catch(function (error) {
              Log.error("ERROR: " + error);
              oAppSettingsModel.setProperty("/isAppBusy", false);
            });
        },

        getRouter: function () {
          return UIComponent.getRouterFor(this);
        },
        handleNonOreNavigation: function (isNonOreUser) {
          const oAppSettingsModel = this.Component.getModel("appSettings");
          let isActivityDetailedForm = false;
          if (document.location.hasOwnProperty("hash")) {
            isActivityDetailedForm = document.location.hash
              .includes("detail") ? true : false;
          }
          if (isNonOreUser && !isActivityDetailedForm) {
            oAppSettingsModel.setProperty("/isAppBusy", false);
            this.getRouter().navTo("noAuthorization");
            return;
          }
        }
      }
    );
    return {
      /**
       * Method to create new instance of Application.
       * @private
       * @returns {sap.ui.base.Object} return new instance of Application
       */
      getInstance: function () {
        if (!instance) {
          // create new instance of Application Object
          instance = new Application();
        }
        return instance;
      },


    };
  }
);
