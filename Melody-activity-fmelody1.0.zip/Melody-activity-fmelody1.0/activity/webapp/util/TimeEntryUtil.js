sap.ui.define([
    "sap/ui/base/Object",
    "com/melody/lib/util/mtr/MTR",
    "com/melody/lib/util/UserMaster",
    "com/melody/lib/util/Opportunity",
    "com/melody/lib/util/mtr/MTRModels",
], function (BaseState, MTRUtil, UserMaster, OpportunityUtil, MTRModels) {
    "use strict";
    return class TimeEntryApp extends BaseState {
        constructor(appComponent) {
            super();
            this.applicationComponent = appComponent;
        }


        static getInstance(appComponent) {
            if (!this._instance) {
                this._instance = new TimeEntryApp(appComponent);
            }
            return this._instance;
        }

        /**
         * @function initializeTimeEntryUserData
         * @description function to initialize or set the user time entry data and settings
        */
        async initializeTimeEntryUserData(appId) {
            try {
                const user = await UserMaster.authenticate();
                if (user.OreFlag === "X") {
                    MTRModels.initModels();
                    const oSettingsModel = MTRModels.getMTRSettingsModel();
                    const oSettings = oSettingsModel.getData();

                    oSettings.setOREUserDetails(user);
                    oSettings.Application = (appId) ? appId.toUpperCase() : "ACTVT";

                    // fetch ISP User details and valid user is authorized in ISP
                    MTRUtil._fetchISPUserInfo();

                    // fetch Target Hours data to calculate Weekends and Start Day of Week, 
                    MTRUtil._fetchWeekends();

                    // this method gets IO Staffing three years record
                    MTRUtil._fetchStaffing(oSettings.PersonalNumber);

                    // this method gets setting's lookup data from LS - Timesheet Modes and Date Formats
                    MTRUtil._fetchSettingsLookups();

                    //set Partner ID
                    const sPartnerId = await OpportunityUtil.getBusinessPartner(user.UserId);
                    if (sPartnerId && sPartnerId !== "") {
                        oSettings.PartnerId = sPartnerId;
                    }

                    await MTRUtil._fetchMTRSettings(user, oSettings.Application, true);
                }
            } catch (error) {
                console.log("ERROR IN initializeTimeEntryUserData : ", error);
            }
        }

    }
});