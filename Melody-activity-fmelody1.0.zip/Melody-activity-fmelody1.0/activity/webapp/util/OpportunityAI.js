sap.ui.define([
    "sap/m/MessageToast",
    "sap/ui/model/Filter",
    "com/melodysuite/activity/service/CardService"
], function (MessageToast, Filter, CardService) {
    "use strict";
    return {
        /**
         * @function init
         * @description function to initilize the util file
         * @param {object} parentController 
         */
        init: function (parentController) {
            this.controller = parentController;
        },


        /**
         * @function showOpportunityDetailsAndLoadData
         * @description function to open Analytical card of opportunity AI Card
         * @param {string} opportunityId
         * @param {type} type
         * @returns {object}
         */
        showOpportunityDetailsAndLoadData: async function (opportunityId = "", type = "DASHBOARD") {
            debugger;
            try {
                let opportunityKPIResult = [];
                const opportunityHderInfo = {
                    opportunityId: "",
                    opportunityIdHref: "",
                };
                let opportunityData = {};
                let opportunityAIData = [];
                let opportunityTeamData = [];
                let opportunityAIDialog = this.controller.oOpportunityDial ?? "";

                if (!opportunityId) {
                    return {
                        opportunityData,
                        opportunityAIData,
                        opportunityTeamData,
                        opportunityHderInfo,
                        opportunityKPIResult,
                    };
                }

                const urlParameters1 = {
                    urlParams: {
                        $expand: "PartiesInvolved",
                    },
                };
                if (!opportunityAIDialog) {
                    opportunityAIDialog = await this.controller.fnCreateFragment("dashboard.OpportunityCardDialog", this);
                    opportunityAIDialog.open();
                } else {
                    opportunityAIDialog.open();
                }
                this.controller.oOpportunityDial = opportunityAIDialog;
                opportunityAIDialog.setModel(this.controller.getView().getModel("d3CtrlModel"), "d3CtrlModel");
                opportunityAIData = await this.loadAIOppoData(opportunityId);

                if (type === "DASHBOARD") {
                    opportunityData = await this.fetchOpportunityDetails(opportunityId);
                } else {
                    opportunityData = await CardService.getOpportunityData(urlParameters1, "/Opportunities('" + opportunityId + "')");
                }
                opportunityData = opportunityData?.data || {};
                opportunityTeamData = opportunityData?.data?.PartiesInvolved?.results || [];

                let opportunityKPIData = await CardService.getOpportunityKPIData({}, `/YC_MD_T_OPP_ACTCNT(opportunityno='${opportunityId}')`);

                const href = `https://sapit-home-test-004.launchpad.cfapps.eu10.hana.ondemand.com/site/Home?#harmonyquote-Display&/Opportunity/${oOpportunityId}`;
                opportunityHderInfo = {
                    opportunityId: opportunityId,
                    opportunityIdHref: href,
                };

                // let wfIstanceData = await this.getMelodyExternalIntegrationData(oOpportunityId);
                if ("data" in opportunityKPIData) {
                    const response = {
                        ...opportunityKPIData.data,
                    };
                    opportunityKPIData.data.results = [response];
                } else {
                    opportunityKPIData.data.results = [{
                        ActivityCount: 0,
                        slcount: 0,
                        mrcount: 0,
                    },];
                }
                opportunityKPIResult = opportunityKPIData.data.results;
                return {
                    opportunityData,
                    opportunityAIData,
                    opportunityTeamData,
                    opportunityHderInfo,
                    opportunityKPIResult,
                };
            } catch (error) {
                console.log("ERROR IN showOpportunityDetailsAndLoadData : ", error);
            }
        },

        /**
        * @function loadAIOppoData
        * @description function to load Opportunity AI data
        */
        loadAIOppoData: async function (oppoId = "") {
            let oComponent = this.controller.oComponent;
            this.apiModel = oComponent.getModel("apiModel");
            return new Promise(function (resolve, reject) {
                this.apiModel.read("/MLRecommendations", {
                    urlParameters: {
                        $expand: "To_RecommendedRole,To_RecommendedActivity",
                        $filter: "OpportunityId eq '" + oppoId + "'",
                    },
                    success: (data = {}) => {
                        if (!("results" in data) || !data.results.length) {
                            resolve([]);
                            return;
                        }
                        const result = data.results[0] || {
                            To_RecommendedActivity: { results: [] },
                            To_RecommendedRole: { results: [] },
                        };
                        const activities = result.To_RecommendedActivity.results.map(
                            (a) => ({
                                name: a.Name,
                                lift: parseFloat(a.Lift.replace("%", "")),
                                newProbability: parseFloat(a.NewProbability.replace("%", "")) || 0,
                            })) ?? [];
                        let roles = result.To_RecommendedRole.results.map((r) => ({
                            name: r.Name,
                            lift: parseFloat(r.Lift.replace("%", "")),
                            newProbability: parseFloat(r.NewProbability.replace("%", "")) || 0,
                        })) ?? [];

                        const values = activities
                            .map(a => Number(a.newProbability))
                            .filter(val => !isNaN(val));


                        const modelData = {
                            currentProbability: parseFloat(result.CurrentProbability.replace("%", "")) || 0,
                            bestProbability: values.length ? Math.max(...values) : 0,
                            activities,
                            roles,
                        };
                        resolve(modelData);
                    },
                    error: (oError) => {
                        reject(oError);
                    },
                });
            }.bind(this));
        },

        /**
         * @function onCloseOpportunityDialog
         * @description function to handle close of the opportunity AI Dialog and reset the values to default values
         */
        onCloseOpportunityDialog: function () {
            debugger;
            let dashboardModel = this.controller.oComponent.getModel("dashboardModel");
            const reset = {
                currentProbability: 0.0,
                bestProbability: 0.0,
                activities: [{
                    name: "",
                    lift: 0.0,
                    newProbability: 0.0,
                }, {
                    name: "",
                    lift: 0.0,
                    newProbability: 0.0,
                }, {
                    name: "",
                    lift: 0.0,
                    newProbability: 0.0,
                },],
                roles: [{
                    name: "",
                    lift: 0.0,
                    newProbability: 0.0,
                }, {
                    name: "",
                    lift: 0.0,
                    newProbability: 0.0,
                },],
            };
            this.controller.getView().getModel("viz").setData(reset);
            dashboardModel.setProperty("/OpportunityData", {
                OWNER_NAME: "",
                DESCRIPTION: "",
                ACCOUNT_NAME: "",
                CLOUD_REVENUE: "0",
                SERVICES_REVENUE: "0",
                LICENSE_REVENUE: "0",
            });
            dashboardModel.setProperty("/OpportunityKPIData", [{
                ActivityCount: 0,
                slcount: 0,
                mrcount: 0,
            },]);
            dashboardModel.refresh();
            this.oOpportunityDialog.close();
        },

        /**
         * @function fetchOpportunityDetails
         * @description function to fetch the selected opportunity AI data
         */
        fetchOpportunityDetails: async function (oppoId) {
            return new Promise(function (resolve, reject) {
                this.apiModel.read("/Opportunities", {
                    urlParameters: {
                        $filter: "OPPT_ID eq '" + oppoId + "'and SALES_TEAM_MEMBER eq '8237087'",
                        $select: "IS_FAVORITE,GUID,ACCOUNT_NAME,ACCOUNT,GROW_ACCOUNT,DEAL_TYPE,OPPT_ID,CHANGED_AT,URL,PROCESS_TYPE,PARTNER,PARTNER_NAME,IS_LEAN,BUSINESS_MODEL,DIS_CHANNEL,SOURCE,REVENUE_TYPE,HARMONY_TYPE,ERROR,HDM_MIG_STA,DESCRIPTION,EXPECTED_VALUE,DISP_AUTH,CURRENCY,MAINQUOTE,CPQ_QUOTE,CPQ_SYSTEM_ID,LICENSE_REVENUE,SERVICES_REVENUE,CLOUD_REVENUE,STATUS,OWNER_NAME,OWNER,USR_IN_SLS_TEAM,EXP_ALERT,FORECAST,EXPECT_END,CLOSE_DATE_EDITABLE,NEXTSTEP,RISKASK,LAST_UPDATED_ON,QUOTE_STATUS,CURR_PHASE,ORDER_ID,TOP_DEAL",
                    },
                    success: (data = {}) => {
                        if (!("results" in data) || !data.results.length) {
                            resolve([]);
                            return;
                        }
                        const result = data.results[0];
                        let dashboardModel = this.controller.oComponent.getModel("dashboardModel");
                        dashboardModel.setProperty("/OpportunityData", result);
                        resolve();
                    },
                    error: (error) => {
                        reject(error);
                    },
                });
            }.bind(this));
        },

        /**
         * @function formatRevenue
         * @description function to format the Revenue data
         * @param {string} sRevenueArgs
         * @param {string} sCurrency
         * @returns {string}
         */
        formatRevenue: function (sRevenueArgs, sCurrency) {
            const sRevenue = sRevenueArgs ? sRevenueArgs : "0";
            const oCurrFormatter = new sap.ui.model.type.Currency({
                showMeasure: false,
                decimals: 2,
                preserveDecimals: false,
            });
            oCurrFormatter.setConstraints({
                maximum: "9999999999999.99",
                minimum: "0",
            });
            let sFormattedRev = oCurrFormatter.formatValue(
                [sRevenue, sCurrency], "string",);
            // remove the decimal places if currency it is for Korea or Indonesia
            if (sCurrency === "WON" || sCurrency === "RP" || sCurrency === "JPY") {
                const sRevenueTrunc = sFormattedRev.split(".")[0];
                return sRevenueTrunc;
            }
            sFormattedRev = sFormattedRev.replaceAll(",", "");
            sFormattedRev = this.formatShortNumber(sFormattedRev);
            return sFormattedRev;
        },

        /**
         * @function formatShortNumber
         * @description function to format revenue number to short form.
         * @param {number} value
         * @returns {string}
         */
        formatShortNumber: function (value) {
            if (!value) {
                return "0.00";
            }
            var num = Number(value);
            if (isNaN(num)) {
                return "0.00";
            }
            if (num >= 1000000000) {
                return (num / 1000000000).toFixed(2) + "B";
            }
            if (num >= 1000000) {
                return (num / 1000000).toFixed(2) + "M";
            }
            if (num >= 1000) {
                return (num / 1000).toFixed(2) + "K";
            }
            return num.toFixed(2);
        },

        /**
         * @function getMelodyExternalIntegrationData
         * @description function to get the external integration data based on selected opportunityId
         * @param {string} oppoId
         */
        getMelodyExternalIntegrationData: async function (oppoId) {
            return new Promise(function (resolve, reject) {
                const melodyExtIntModel = this.controller.oComponent.getModel("melodyExtIntModel");
                melodyExtIntModel.read("/V_WfInstance_Act", {
                    urlParameters: {
                        $filter: `OpportunityID eq '${oppoId}'`,
                        $orderby: "InstanceID asc",
                    },
                    success: (data = {}) => {
                        if (!("results" in data) || !data.results.length) {
                            resolve([]);
                            return;
                        }
                        resolve(data.results);
                    },
                    error: (error) => {
                        reject(error);
                    },
                });
            }.bind(this));
        },


    };
});