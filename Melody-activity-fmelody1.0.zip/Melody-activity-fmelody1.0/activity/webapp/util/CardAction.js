sap.ui.define([
    "sap/m/MessageToast",
    "sap/ui/model/Filter",
    "sap/ui/integration/library",

], function (MessageToast, Filter, IntegrationLibrary) {
    "use strict";
    return {
        /**
         * @function init
         * @description function to initilize the util file
         * @param {object} parentController 
         */
        init: function (parentController) {
            this.controller = this;
        },


        /**
         * @function handleAction
         * @description Handles user actions triggered from the card, such as editing or deleting entries.
         * @param {object} event
         * @param {string} cardId
         */
        handleAction: async function (cardId, event) {
            debugger;
            let sType = event.getParameter("type") || "";
            const cardInstance = sap.ui.getCore().byId(cardId);
            const parameters = event.getParameter("parameters");
            try {
                switch (sType) {
                    case IntegrationLibrary.CardActionType.Custom:
                        await this.OpportunityAIUtil.openAnalyticalCardDetails(event);
                        return;
                    case "CustomOpportunity":
                        this.OpportunityAIUtil.init(this);
                        this.fnSegregateOpportunityTimeData(event);
                        await this.OpportunityAIUtil.openOpportunityDetails(event, {}, "DASHBOARD");
                        return;
                    case "OpportunityListNavigation":
                        // this.getOwnerComponent().getRouter().navTo("MyOpportunities");
                        return;
                    case "ActivityListNavigation":
                        // this.getOwnerComponent().getRouter().navTo("list");
                        return;
                    case "ActivityDetailPage":
                        // const activityId = event.getParameter("parameters").parameters.ActivityId;
                        // this.getOwnerComponent().getRouter().navTo("detail", {
                        //     id: activityId,
                        //     mode: "READ"
                        // });
                        return;
                    case IntegrationLibrary.CardActionType.Navigation: {
                        // const parameters = event.getParameter("parameters") ?? {};
                        // if ("type" in parameters) {
                        //     switch (parameters.type) {
                        //         case "ActivityListNavigation":
                        //             this.getOwnerComponent().getRouter().navTo("list");
                        //             return;
                        //         case "OpportunityListNavigation":
                        //             this.getOwnerComponent().getRouter().navTo("MyOpportunities");
                        //             return;
                        //         case "ActivityRegistrationNavigation":
                        //             this.getOwnerComponent().getRouter().navTo("registerForm");
                        //             return;
                        //         case "ActivityActionPopover":
                        //             const activityId = parameters.activityId;
                        //             this.openActivityCardPopover(event, activityId);
                        //             return;
                        //         default:
                        //             return;
                        //     }
                        // }
                        return;
                    }
                    default:
                    // const oParameters = event.getParameter("parameters") || {};

                    // if (oParameters?.ibnTarget) {
                    //     event.preventDefault();
                    //     UshellContainer.getServiceAsync("Navigation").then(function (NavigationService) {
                    //         NavigationService.navigate({ target: oParameters.ibnTarget, params: oParameters.ibnParams });
                    //     });
                    // }
                }

            } catch (error) {
                console.log("ERROR IN handleAction : ", error);
            }
        }

    };
});