/*!
 * Copyright (c) 2009-2014 SAP SE, All Rights Reserved
 */
sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "com/melodysuite/activity/service/CardService",
], function (
    BaseObject,
    Fragment,
    JSONModel,
    CardService
) {
    "use strict";

    return BaseObject.extend("com.melodysuite.activity.util.ManageCardUtil", {
        /**
         * constructor of the class
         * @memberOf com.melodysuite.activity.util
         * @param {sap.ui.core.mvc.Controller} controller
         * @param {sap.ui.model.json.JSONModel} model
         */
        constructor: function (controller) {
            if (!controller) {
                throw new Error("Main Controller is required to initialize ManageCardsUtil");
            }

            this.model = controller.getModel("dashboardModel");
            this.mainController = controller;
        },

        /**
         * @function openBusyIndicator
         * @description Opens busy dialog.
         */
        openBusyIndicator: function () {
            if (!this.BusyDialogSave) {
                this.BusyDialogSave = new sap.m.BusyDialog({});
            }
            this.BusyDialogSave.open();
        },

        /**
         * @function closeBusyIndicator
         * @description close busy dialog.
         */
        closeBusyIndicator: function () {
            if (!this.BusyDialogSave) {
                this.BusyDialogSave = new sap.m.BusyDialog({});
            }
            this.BusyDialogSave.close();
        },


        /**
         * Store current state of cards to compare with the new state for createOrDestroyCards method
         * 
         * @param {Array} aCardArray 
         * @returns {Array} Cards array with the new state
         */
        getManageCardsDialogModelState: function (aCardArray) {
            var aCardsArray = [];
            for (var i = 0; i < aCardArray.length; i++) {
                aCardsArray.push({
                    id: aCardArray[i].id,
                    visibility: aCardArray[i].visibility
                });
            }
            return aCardsArray;
        },

        /**
         * @function openManageCardsDialog
         * @description Opens the card com.melody.launchpad user to view and edit their cards.
         * @param {sap.ui.base.Event} event
         */
        openManageCardsDialog: async function (event) {
            //debugger;
            const dashboardModel = this.model;
            const manageCardsData = this.formatDataForManageCards();
            dashboardModel.setProperty("/cardInfoTable", manageCardsData.cardInfoTable);
            dashboardModel.setProperty("/groupCards", manageCardsData.groupedCards);
            if (!this.cardWorkBenchFrag) {
                this.cardWorkBenchFrag = await this.mainController.fnCreateFragment("dashboard.CardWorkbench", this);
            }
            this.cardWorkBenchFrag.open();
            dashboardModel.refresh();
        },


        /**
        * @function onCardDroppedToList
        * @description Function to handle the drop event of a card for grouping purposes inside a List.
        */
        onCardDroppedToList: function (event) {

            try {
                let createCase = false;
                let groupToBeUpdated = "";
                let cardToBeRemoved = "";
                const groupCard = {
                    "group_id": crypto.randomUUID(),
                    "group_title": "New Group",
                    "group_title_clone": "New Group",
                    "group_expanded": true,
                    "cards": [],
                    "groupTitleEdit": false,
                    "group_created": "New"
                };
                const cardToBeGrp = {
                    "card_id": "",
                    "card_title": "",
                    "group_id": "",
                    "group_created": "New"
                };
                let insertGroup = false;
                let updateGroup = false;
                const dropPosition = event.getParameter("dropPosition");
                const droppedControl = event.getParameter("droppedControl")
                const draggedControl = event.getParameter("draggedControl");
                const dashboardModel = this.model;
                const allGroups = dashboardModel.getProperty("/groupCards") || [];

                const draggedCardObject = draggedControl?.getBindingContext("dashboardModel")?.getObject() || false;
                const currentGroupedDataPath = droppedControl.getBindingContext("dashboardModel")?.getPath() || false;
                const currentGroupedCardData = droppedControl.getBindingContext("dashboardModel")?.getObject() || groupCard;

                // To handle updating process of groups
                if (allGroups.length === 1) {
                    createCase = true;
                }

                // If dragged Object is empty
                if (!draggedCardObject || !Object.keys(draggedCardObject).length) {
                    event.preventDefault();
                    return;
                }

                // If the dragged content is from table and the content is already grouped
                if (draggedControl?.getParent() instanceof sap.m.Table && "grouped" in draggedCardObject && draggedCardObject.grouped || ("visible" in draggedCardObject && !draggedCardObject.visible)) { // draggedControl.addStyleClass()
                    event.preventDefault();
                    return;
                }

                // If Card already excits in group
                if ("cards" in currentGroupedCardData && currentGroupedCardData.cards.length && dropPosition === "On") {
                    const isPresent = currentGroupedCardData.cards.find(card => card.card_id === draggedCardObject.card_id) || false;
                    if (isPresent) {
                        event.preventDefault();
                        return;
                    }
                }

                // To Update the groups with cards (Interchange cards)
                if (dropPosition === "On" && ("group_id" in currentGroupedCardData && "group_id" in draggedCardObject) && (currentGroupedCardData.group_id !== draggedCardObject.group_id)) {
                    groupToBeUpdated = draggedCardObject.group_id;
                    cardToBeRemoved = draggedCardObject.card_id;
                }

                if (["Before", "After"].some(value => value === dropPosition)) {
                    if ("group_id" in draggedCardObject && draggedCardObject.group_id) {
                        groupToBeUpdated = draggedCardObject.group_id;
                        cardToBeRemoved = draggedCardObject.card_id;
                    }
                }

                cardToBeGrp.card_id = draggedCardObject.card_id;
                cardToBeGrp.card_guid = draggedCardObject.cardGuid;
                cardToBeGrp.userid = draggedCardObject.userid;
                cardToBeGrp.card_title = draggedCardObject.title || draggedCardObject.card_title;

                switch (dropPosition) {
                    case "Before":
                        {
                            insertGroup = true;
                            cardToBeGrp.group_id = groupCard.group_id;
                            groupCard.cards.push(cardToBeGrp);
                            allGroups.unshift(groupCard);
                        }
                        break;
                    case "After":
                        {
                            insertGroup = true;
                            cardToBeGrp.group_id = groupCard.group_id;
                            groupCard.cards.push(cardToBeGrp);
                            allGroups.push(groupCard);
                        }
                        break;
                    case "On":
                        {
                            if (!allGroups.length) {
                                insertGroup = true;
                                cardToBeGrp.group_id = groupCard.group_id;
                                groupCard.cards.push(cardToBeGrp);
                                allGroups.push(groupCard);
                            } else {
                                updateGroup = true;
                                cardToBeGrp.group_id = currentGroupedCardData.group_id;
                                currentGroupedCardData.cards.push(cardToBeGrp)
                            }

                        }
                        break;
                    default:
                }

                if (insertGroup) {
                    dashboardModel.setProperty("/groupCards", allGroups);
                }

                if (updateGroup && currentGroupedDataPath) {
                    dashboardModel.setProperty(`${currentGroupedDataPath}`, currentGroupedCardData);
                }

                // Drag and Drop between the groups check VBox to LIST
                this.updateCardsInGroups(groupToBeUpdated, cardToBeRemoved);

                // Update the Card List Table Grouped Status
                this.updatedGroupInfoInCardTable(true, cardToBeGrp.card_id);
                dashboardModel.refresh()
            } catch (error) {
                console.log("ERROR IN onCardDroppedToList : ", error)
            }
        },

        /**
         * @function formatDataForManageCards
         * @description Handles to format the data from model of cards for the card management interface
         */
        formatDataForManageCards: function () {
            // debugger;
            const groupedCards = [];
            const dashboardModel = this.model;
            const availableCards = dashboardModel.getProperty("/cardListWorkbench") || [];
            const workbenchGroupCardsData = dashboardModel.getProperty("/workbenchGroupUnformattedData");
            const groupedDashboardCards = $.extend(true, [], dashboardModel.getProperty("/groupedDashboardCards"));
            let cardInfoTable = availableCards
                .map((card, index) => {
                    if ("type" in card && card.type === "mtr") {
                        return "";
                    }

                    return {
                        id: index,
                        card_id: card["CardId"],
                        cardGuid: card["CardGuid"],
                        cardIcon: card["CardIcon"] ? card["CardIcon"].toLowerCase() : "sap-icon://list",
                        cardIconTooltip: this.getCardIconTooltipForManageCards(card["CardIcon"]),
                        serial: index + 1,
                        grouped: false,
                        groupId: card["GroupGuid"],
                        groupTitle: card["GroupDesc"],
                        visible: card["Visibility"] === "X" ? true : false,
                        userid: card["Userid"],
                        sortOrder: card["SortOrder"],
                        title: card["CardDesc"] ? card["CardDesc"] : "Time Entry",
                    };
                })
                .filter((card) => card);

            for (let j = 0; j < cardInfoTable.length; j++) {
                let card = cardInfoTable[j];
                let cardCheck = workbenchGroupCardsData.find(
                    (val) => val.CardGuid === card.cardGuid,
                );
                if (cardCheck) {
                    card.grouped = true;
                }
            }

            for (let i = 0; i < groupedDashboardCards.length; i++) {
                const group = groupedDashboardCards[i];
                if (group.groupTitle === "My Cards") {
                    continue;
                }
                const groupItem = {
                    groupTitleEdit: false,
                    group_expanded: true,
                    group_id: group.groupId,
                    group_title: group.groupTitle,
                    group_title_clone: group.groupTitle,
                    group_created: "",
                    cards: [],
                };
                const grpdCards = workbenchGroupCardsData || [];
                grpdCards.forEach((card) => {
                    if (card.GroupGuid === groupItem.group_id) {
                        groupItem.cards.push({
                            card_id: card.CardId,
                            card_title: card.CardDesc,
                            group_id: group.groupId,
                            card_guid: card.CardGuid,
                            userid: card.Userid,
                            group_created: "",
                        });
                    }
                });
                groupedCards.push(groupItem);
            }
            cardInfoTable.sort((prev, next) => prev.grouped - next.grouped);
            return {
                cardInfoTable,
                groupedCards
            };
        },

        /**
         * @function onCloseWorkbenchDialog
         * @description  Handles the closing of the card workbench dialog.
         */
        closeWorkbenchDialog: function () {
            //debugger;
            const dashboardModel = this.model;
            this.cardWorkBenchFrag.close();
            dashboardModel.refresh();
        },

        /**
         * @function dragStartCardWorkbenchTable
         * @description Handles the drag start event for the card workbench table.
         * @param {sap.ui.base.Event} event
         */
        dragStartCardWorkbenchTable: function (event) {
            const dashboardModel = this.model;
            const targetDragged = event.getParameter("target");
            const targetObject = targetDragged?.getBindingContext("dashboardModel")?.getObject() || false;
            if (targetObject) {
                if (("grouped" in targetObject && targetObject.grouped) || !targetObject.visible) {
                    event.preventDefault();
                }
            }
        },

        /**
         * @function dropSelectedCardWorkBenchTable
         * * @description Handles the drop event for the selected card in the workbench table.
         * @param {sap.ui.base.Event} oEvent
         * TODO: Remove the return statement once the layout issue is fixed
         */
        dropSelectedCardWorkBenchTable: function (oEvent) {
            return;
            const dashboardModel = this.model;
            const draggedItem = oEvent.getParameter("draggedControl");
            const droppedItem = oEvent.getParameter("droppedControl");
            const dropPosition = oEvent.getParameter("dropPosition");

            if (!draggedItem || !droppedItem || !dropPosition) {
                return;
            }

            const draggedContext = draggedItem.getBindingContext("dashboardModel");
            const droppedContext = droppedItem.getBindingContext("dashboardModel");

            if (!draggedContext || !droppedContext) {
                return;
            }

            const cardsData = dashboardModel.getProperty("/cardInfoTable");
            const draggedIndex = draggedItem.getParent().indexOfItem(draggedItem);
            const droppedIndex = droppedItem.getParent().indexOfItem(droppedItem);

            let insertIndex = dropPosition === "After" ? droppedIndex + 1 : droppedIndex;
            if (draggedIndex < insertIndex) {
                insertIndex--;
            }

            // Prevent dropping onto itself
            if (draggedIndex === insertIndex || draggedIndex === droppedIndex) {
                dashboardModel.setProperty("/IscardPositionChanged", false);
                return;
            }

            // Move item in array
            const oDraggedData = cardsData.splice(draggedIndex, 1)[0];
            cardsData.splice(insertIndex, 0, oDraggedData);

            // Refresh model
            dashboardModel.setProperty("/cardInfoTable", cardsData);
            dashboardModel.setProperty("/IscardPositionChanged", true);
            dashboardModel.refresh();
        },

        /**
         * @function fnToggleSelCardVisibility
         * @description function to set visibility of card in a group
         */
        fnToggleSelCardVisibility: function () { },

        /**
         * @function handleCollapseExpandAllGroups
         * @description Handle the collapse action for all groups in the panel on the workbench dialog
         */
        handleCollapseExpandAllGroups: function (event) {
            let option;
            const source = event.getSource();
            const dashboardModel = this.model;
            const pressed = event.getParameter("pressed");
            if (pressed) {
                source.setIcon("sap-icon://collapse");
                option = "collaps";
            } else {
                source.setIcon("sap-icon://expand");
                option = "expand";
            }
            const allGroups = dashboardModel.getProperty("/groupCards") || [];
            allGroups.forEach((group) => {
                if (option === "expand") {
                    group.group_expanded = true;
                } else {
                    group.group_expanded = false;
                }
            });
            dashboardModel.setProperty("/groupCards", allGroups);
            dashboardModel.refresh();
        },

        /**
         * @function handleUpdateGrpTitleButton
         * @description Handles the event when the save title button is pressed to update the group title.
         */
        handleUpdateGrpTitleButton: function (event, operationType) {
            //debugger;
            const source = event.getSource();
            const dashboardModel = this.model;
            const bindingContext = source.getBindingContext("dashboardModel");
            const path = bindingContext.getPath() || false;
            const currentGrp = bindingContext.getObject() || false;
            if (path && currentGrp) {
                if (operationType === "DECLINE") {
                    dashboardModel.setProperty(`${path}/group_title`, currentGrp.group_title_clone);
                } else {
                    dashboardModel.setProperty(`${path}/group_title_clone`, currentGrp.group_title);
                }
                dashboardModel.setProperty(`${path}/groupTitleEdit`, !currentGrp.groupTitleEdit);
            }
            dashboardModel.refresh();
        },

        /**
         * @function handleEditGrpTitleButton
         * @description Handles the event when the edit title button is pressed to update the group title.
         */
        handleEditGrpTitleButton: function (event) {
            //debugger;
            const source = event.getSource();
            const dashboardModel = this.model;
            const bindingContext = source.getBindingContext("dashboardModel");
            const path = bindingContext.getPath() || false;
            const currentGrp = bindingContext.getObject() || false;
            if (path && currentGrp) {
                dashboardModel.setProperty(`${path}/groupTitleEdit`, !currentGrp.groupTitleEdit);
            }
            dashboardModel.refresh();
        },

        handleDeleteGrpButton: function (event) {
            //debugger;
            const dashboardModel = this.model;
            let groupCards = dashboardModel.getProperty("/groupCards") || [];
            let contextObject = event.getSource().getBindingContext("dashboardModel").getObject();
            let index = "";
            for (let i = 0; i < groupCards.length; i++) {
                let oGroup = groupCards[i];
                if (oGroup.group_id === contextObject.group_id) {
                    index = i;
                }
            }
            groupCards.splice(index, 1);
            dashboardModel.setProperty("/groupCards", groupCards);
            dashboardModel.refresh(true);
        },

        /**
         * @function onCardDroppedToVBoxContainer
         * @description Function to handle the drop event of a card for grouping purposes inside a VBox.
         */
        onCardDroppedToVBoxContainer: function (event) {
            try {
                debugger
                let createCase = false;
                let groupToBeUpdated = "";
                let cardToBeRemoved = "";

                const cardToBeGrp = {
                    card_id: "",
                    card_title: "",
                };

                const dropPosition = event.getParameter("dropPosition");
                const droppedControl = event.getParameter("droppedControl");
                const draggedControl = event.getParameter("draggedControl");
                const dashboardModel = this.model;

                const allGroups = dashboardModel.getProperty("/groupCards") || [];
                const currentVBoxContainer = droppedControl.getBindingContext("dashboardModel");
                const currentCardsDataPath = currentVBoxContainer?.getPath() || false;
                const currentGroupData = dashboardModel.getProperty(`${currentCardsDataPath}`) || {};
                const currentCardsData = dashboardModel.getProperty(`${currentCardsDataPath}/cards`) || [];
                const draggedCardObject = draggedControl?.getBindingContext("dashboardModel")?.getObject() || {};

                // To handle updating process of groups
                if (allGroups.length === 1) {
                    createCase = true;
                }

                // If the dragged content is from table and the content is already grouped
                if ((draggedControl?.getParent() instanceof sap.m.Table && "grouped" in draggedCardObject && draggedCardObject.grouped) ||
                    ("visible" in draggedCardObject && !draggedCardObject.visible)) {
                    event.preventDefault();
                    return;
                }

                // IF Card Already Present in the group
                const isPresent = currentCardsData.find((card) => {
                    return card.card_id === draggedCardObject.card_id;
                }) || false;

                if (isPresent) {
                    event.preventDefault();
                    return;
                }

                // To Update the groups
                if ("group_id" in draggedCardObject && "group_id" in currentGroupData && draggedCardObject.group_id !== currentGroupData.group_id) {
                    groupToBeUpdated = draggedCardObject.group_id;
                    cardToBeRemoved = draggedCardObject.card_id;
                }

                cardToBeGrp.group_id = currentGroupData.group_id;
                cardToBeGrp.card_id = draggedCardObject.card_id;
                cardToBeGrp.card_title = draggedCardObject.title || draggedCardObject.card_title;

                switch (dropPosition) {
                    case "Before": {
                        currentCardsData.unshift(cardToBeGrp);
                    }
                        break;
                    case "After": {
                        currentCardsData.push(cardToBeGrp);
                    }
                        break;
                    case "On": {
                        currentCardsData.push(cardToBeGrp);
                    }
                        break;
                    default:
                }

                // Update the Card List Table Grouped Status
                this.updatedGroupInfoInCardTable(true, cardToBeGrp.card_id);
                dashboardModel.setProperty(`${currentCardsDataPath}/cards`, currentCardsData);
                // Drag and Drop between the groups check VBox to VBox
                this.updateCardsInGroups(groupToBeUpdated, cardToBeRemoved);
                dashboardModel.refresh();
            } catch (error) {
                console.log("ERROR IN onCardDroppedToVBoxContainer : ", error);
            }
        },


        /**
         * @function updateCardsInGroups
         * @descrpition Updates the  cards within their respective groups.
         */
        updateCardsInGroups: function (groupId, cardId) {
            if (!groupId || !cardId) {
                return;
            }

            const dashboardModel = this.model;
            const allGroups = $.extend(true, [], dashboardModel.getProperty("/groupCards"));
            if (allGroups.length) {
                const groupIndex = allGroups.findIndex((group) => group.group_id === groupId);
                if (groupIndex !== -1) {
                    let grpCards = allGroups[groupIndex].cards;
                    grpCards = grpCards.filter((card) => card.card_id !== cardId);
                    allGroups[groupIndex].cards = grpCards;
                    if (!grpCards.length) {
                        allGroups.splice(groupIndex, 1);
                    }
                    dashboardModel.setProperty("/groupCards", allGroups);
                }
                dashboardModel.refresh();
            }
        },

        /**
         * @function deleteGroupedCardToken
         * @description Handles removing the tokens from the tokenizer in the grouping
         */
        deleteGroupedCardToken: function (event) {
            //debugger;
            const deletedTokens = event.getParameter("tokens");
            const dashboardModel = this.model;
            const cardInfoTableData = dashboardModel.getProperty("/cardInfoTable") || [];
            const tokenizerBindingContext = event.getSource().getBindingContext("dashboardModel") || {};
            const tokenizerPath = tokenizerBindingContext?.getPath() || false;
            const allGroups = dashboardModel.getProperty("/groupCards") || [];
            if (tokenizerPath) {
                const currentGroupData = dashboardModel.getProperty(`${tokenizerPath}`) || {};
                const currentGrpdCardData = currentGroupData?.cards || [];
                let updatedGrpdCardData;
                deletedTokens.forEach((token) => {
                    const tokenContext = token?.getBindingContext("dashboardModel") || {};
                    const currentTokenData = tokenContext?.getObject() || {};
                    updatedGrpdCardData = currentGrpdCardData.filter(
                        (card) => card.card_id !== currentTokenData.card_id,
                    );
                    this.updatedGroupInfoInCardTable(false, currentTokenData.card_id);
                });
                if (!updatedGrpdCardData.length) {
                    let updatedAllGroups = allGroups.filter(
                        (group) => group.group_id !== currentGroupData.group_id,
                    );
                    dashboardModel.setProperty(`/groupCards`, updatedAllGroups);
                } else {
                    dashboardModel.setProperty(`${tokenizerPath}/cards`, updatedGrpdCardData);
                }
                dashboardModel.setProperty(`/cardInfoTable`, cardInfoTableData);
                dashboardModel.refresh();
            }
        },

        /**
         * @function updatedGroupInfoInCardTable
         * @description Updates the information of grouped cards in the card table.
         */
        updatedGroupInfoInCardTable: function (grouped, card_id) {
            //debugger;
            const dashboardModel = this.model;
            const cardInfoTableData = dashboardModel.getProperty("/cardInfoTable") || [];
            const indexCardForTable = cardInfoTableData.findIndex((tableData) => tableData.card_id === card_id);
            if (indexCardForTable !== -1) {
                cardInfoTableData[indexCardForTable].grouped = grouped;
            }
            // Sort the grouped cards
            cardInfoTableData.sort((prev, next) => prev.grouped - next.grouped);
            dashboardModel.setProperty(`/cardInfoTable`, cardInfoTableData);
            dashboardModel.refresh();
        },

        /**
         * @function confirmWorkbenchDialogChange
         * @description function to handle update the card position in the model data
         */
        confirmWorkbenchDialogChange: async function () {
            //debugger;
            try {
                // this.openBusyIndicator();
                const dashboardModel = this.model;
                const cardsData = dashboardModel.getProperty("/cardInfoTable") || [];
                const groupCards = dashboardModel.getProperty("/groupCards") || [];

                //Validation
                if (!this.manageCardValidation(groupCards)) {
                    return;
                }

                // Prepare Payload for Card List Workbench
                let cardListPayload = cardsData.map((item) => {
                    let card = {
                        "CardDesc": item.title,
                        "CardGuid": item.cardGuid,
                        "CardId": item.card_id,
                        "GroupDesc": item.groupTitle,
                        "GroupGuid": item.groupId,
                        "SortOrder": item.sortOrder,
                        "Userid": item.userid,
                        "Visibility": item.visible === true ? 'X' : ''
                    };
                    return card;
                });

                // Prepare Payload for Group Card Data
                let cardGroupPayloadData = [];
                for (let i = 0; i < groupCards.length; i++) {
                    let group = groupCards[i];
                    let cardGroupData = group.cards.map((item) => {
                        return {
                            "CardDesc": item.card_title,
                            "CardGuid": item.card_guid,
                            "CardId": item.card_id,
                            "GroupDesc": group.group_title,
                            "GroupGuid": item.group_created === 'New' ? '00000000-0000-0000-0000-000000000000' : item.group_id,
                            "SortOrder": "",
                            "Userid": item.userid
                        };
                    });
                    cardGroupPayloadData.push(...cardGroupData);
                }

                // Post final Workbench data
                let payloadCardGroupData = {
                    Userid: cardListPayload[0].Userid,
                    to_GrpCard: cardGroupPayloadData,
                };
                let payloadCardListData = {
                    Userid: cardListPayload[0].Userid,
                    to_Cards: cardListPayload,
                };

                const workbenchPromise = [CardService.postWorkbenchDashboardData(payloadCardGroupData), CardService.postWorkbenchDashboardMainData(payloadCardListData)];

                const [groupResponse, listResponse] = await Promise.all(workbenchPromise);

                this.mainController.setCardsData();
                this.closeWorkbenchDialog();
                this.closeBusyIndicator();
            } catch (error) {
                this.closeBusyIndicator();
                console.log("confirmWorkbenchDialogChange : ", error);
            }
        },

        /**
         * @function manageCardValidation
         * @description function to validate the manage cards data before posting
         * @param {Array} groupCards
         * @returns {boolean}
         */
        manageCardValidation: function (groupCards) {
            //Title Edit
            if (groupCards.some((group) => group.groupTitleEdit)) {
                sap.m.MessageToast.show("Please save the group title changes", {
                    duration: 3000
                });
                this.closeBusyIndicator();
                return false;
            }

            //Title
            const groupTitles = groupCards.map(group => group.group_title);
            const uniqueName = new Set(groupTitles).size === groupTitles.length;
            if (!uniqueName) {
                sap.m.MessageToast.show("Please enter a unique group title", {
                    duration: 3000
                });
                this.closeBusyIndicator();
                return false;
            }

            //Title cannot be My Cards
            if (groupTitles.some((title) => title.replace(/\s+/g, "").toLowerCase() === "mycards")) {
                sap.m.MessageToast.show("The group name 'My Cards' cannot be used. Please choose a different name.", {
                    duration: 3000
                });
                this.closeBusyIndicator();
                return false;
            }
            return true;
        },

        /**
         * @function getCardIconTooltipForManageCards
         * @description function to return tooltip for manage cards to understand between stack, table and standard card
         * @param {string} icon
         */
        getCardIconTooltipForManageCards: function (icon) {
            icon = icon.toUpperCase()
            switch (icon) {
                case 'SAP-ICON://DIMENSION':
                    return 'Stack Cards';
                case 'SAP-ICON://TABLE-VIEW':
                    return 'Table Cards';
                case 'SAP-ICON://LIST':
                    return 'Standard Cards';
                default:
            }
        },

    });
});