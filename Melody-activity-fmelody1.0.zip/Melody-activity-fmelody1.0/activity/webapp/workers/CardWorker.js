self.onmessage = function (event) {
  const data = event.data.results || [];
  const staticCard = event.data.StaticCard;
  const groupedDashboardCards = [];
  debugger;

  for (let i = 0; i < data.length; i++) {
    let item = data[i];
    let groupObject = {
      groupTitle: item.GroupDesc.length === 0 ? "My Cards" : item.GroupDesc,
      groupId: item.GroupGuid,
      groupCards: (!item.Payload.length) ? [] : JSON.parse(item.Payload.slice(1, -1)),
      groupLayouts: [
        {
          cards: [],
        },
      ],
      groupShowMtr: item.GroupDesc.length === 0 ? true : false,
    };

    if (groupObject.groupId === "00000000-0000-0000-0000-000000000000") {
      // groupObject.groupCards.push(staticCard.QUICKVIEWSTACK);
      // groupObject.groupCards.push(staticCard.QUICKVIEWACTSTACK);
      // groupObject.groupCards.push(staticCard.QUICKVIEWDISOPPSTACK);
      // groupObject.groupCards.push(staticCard.QUICKVIEWACTPASTENDDATESTACK);
      // groupObject.groupCards.push(staticCard.QUICKVIEWREQUESTPROCESSSTACK);
      // groupObject.groupCards.push(staticCard.MANAGERANALYTICCARD);
      // groupObject.groupCards.push(staticCard.CUSTOMTABLE1);
      // groupObject.groupCards.push(staticCard.ACTIVITYBYCVJPHASE);
      // groupObject.groupCards.push(staticCard.DAYWEEKMTRCARD);
      // groupObject.groupCards.push(staticCard.APICARDSL);
    }
    groupObject.groupCards = groupObject.groupCards.map((card) => {
      card["sap.app"].id = "com.melodysuite.activity";
      return card;
    });
    groupedDashboardCards.push(groupObject);
  }
  self.postMessage(groupedDashboardCards);
};
