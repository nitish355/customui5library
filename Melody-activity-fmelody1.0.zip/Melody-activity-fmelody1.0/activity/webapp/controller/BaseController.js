// @ts-nocheck
sap.ui.define(
  [
    "sap/ui/core/Fragment",
    "sap/ui/core/UIComponent",
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
  ],
  function (Fragment, UIComponent, Controller, JSONModel) {
    "use strict";
    return Controller.extend("com.melodysuite.activity.controller.BaseController", {
      /**
       * Function to initialize Basecontroller
       */
      onInit: function () {
        this.setAppComponent();
      },

      /**
       * This method can be called to determine whether the sapUiSizeCompact or sapUiSizeCozy
       * design mode class should be set, which influences the size appearance of some controls.
       * @public
       * @return {string} css class, either 'sapUiSizeCompact' or 'sapUiSizeCozy' - or an empty string if no css class should be set
       */
      getContentDensityClass: function () {
        if (this._sContentDensityClass === undefined) {
          // check whether FLP has already set the content density class; do nothing in this case
          // eslint-disable-next-line sap-no-proprietary-browser-api
          if (
            document.body.classList.contains("sapUiSizeCozy") ||
            document.body.classList.contains("sapUiSizeCompact")
          ) {
            this._sContentDensityClass = "";
          } else if (!Device.support.touch) {
            // apply "compact" mode if touch is not supported
            this._sContentDensityClass = "sapUiSizeCompact";
          } else {
            // "cozy" in case of touch support; default for most sap.m controls, but needed for desktop-first controls like sap.ui.table.Table
            this._sContentDensityClass = "sapUiSizeCozy";
          }
        }
        return this._sContentDensityClass;
      },

      /**
       * @public
       * @function setAppComponent
       * @description function to get application component
       */
      setAppComponent: function () {
        if (!this.oComponent) {
          this.oComponent = this.getOwnerComponent();
        }
      },

      /**
       * @public
       * @function createJSONModel
       * @description function to create a json model
       */
      createJSONModel: function (properties) {
        return new JSONModel(properties);
      },

      /**
       * @public
       * @function getResourceBundle
       * @description function to get resource bundle
       */
      getResourceBundle: function () {
        return this.getOwnerComponent().getModel("i18n").getResourceBundle();
      },

      /**
       * @public
       * @function getRouter
       * @description function to get router for the component
       */
      getRouter: function () {
        return UIComponent.getRouterFor(this);
      },

      /**
       * @public
       * @function getUserData
       * @description function to get handle router matched and set the layout type based on VIEW name
       * @param {object} event the model name
       */
      getUserData: function () {
        const userData = CoreLibraryModel.getProperty("/oUserData");
        return userData;
      },

      /**
       * Convenience method for getting the view model by name in every controller of the application.
       * @public
       * @param {string} sName the model name
       * @returns {sap.ui.model.Model} the model instance
       */
      getModel: function (name) {
        return this.getView().getModel(name);
      },
      /**
       * Convenience method for setting the view model in every controller of the application.
       * @public
       * @param {sap.ui.model.Model} oModel the model instance
       * @param {string} sName the model name
       * @returns {sap.ui.mvc.View} the view instance
       */
      setModel: function (model, name) {
        this.getView().setModel(model, name);
      },

      /**
       * @public
       * @function handleBrowserNav
       * @description function to close all the open dialogs while exiting the screen.
       */
      handleBrowserNav: function () {
        if (sap.m.InstanceManager.getOpenDialogs().length)
          sap.m.InstanceManager.closeAllDialogs();
      },

      /**
       * @public
       * @function setFormPath
       * @description function to set the form path on tab change in create mode and on load of detail screen
       */
      setFormPath: function (path) {
        const activityFormModel =
          this.getOwnerComponent().getModel("activityFormModel");
        activityFormModel.setProperty("/formPath", path);
      },

      /**
       * @public
       * @function setFormPath
       * @description function to handle Non ORE user authentication and navigate to No Authroziation screen
       */
      handleAuthCheck: function (view) {
        const appSettings = this.getOwnerComponent().getModel("appSettings");
        let isNonOreUser = appSettings.getProperty("/isNonOreUser");
        if (isNonOreUser && view === "registerForm")
          this.getRouter().navTo("noAuthorization");
        else return;
      },

      /**
       * @public
       * @function fnCreateFragment
       * @description function to create fragment based on fragmentName and Path
       */
      fnCreateFragment: function (fragmentName, oController = this) {
        let fragment = Fragment.load({
          name: `com.melodysuite.activity.fragments.${fragmentName}`,
          controller: oController,
        }).then(
          function (dialog) {
            this.getView().addDependent(dialog);
            return dialog;
          }.bind(this),
        );
        return fragment;
      },

      /**
       * @function fnLoadFileOnDemand
       * @author RAVIKIRAN
       * @description function to load file on demand
       */
      fnLoadFileOnDemand: function (path) {
        return new Promise(function (resolve) {
          sap.ui.require([path],
            function (ManageCardUtil) {
              resolve(ManageCardUtil);
            },
          );
        });
      },

      /**
       * @function openBusyIndicator
       * @description Opens busy dialog.
       */
      openBusyIndicator: function () {
        if (!this.BusyDialogSave) {
          this.BusyDialogSave = new sap.m.BusyDialog({});
        }
        this.BusyDialogSave.open();
      },

      /**
       * @function closeBusyIndicator
       * @description close busy dialog.
       */
      closeBusyIndicator: function () {
        if (!this.BusyDialogSave) {
          this.BusyDialogSave = new sap.m.BusyDialog({});
        }
        this.BusyDialogSave.close();
      },


      /**
      * @function navigationQuickNavPress
      * @description function to handle quick nav header press
      */
      navigationQuickNavPress: function (event) {
        let navigateTo = "";
        const semanticDetails = event.getParameters() || {};
        const semanticName = semanticDetails?.semanticName ?? "";
        const headerModel = this.getOwnerComponent().getModel("headerModel");
        headerModel.setProperty("/visible/manageCards", false);
        switch (semanticName) {
          case "pcactivityset":
            navigateTo = "list";
            break;
          case "pcactivityform":
            navigateTo = "registerForm";
            break;
          case "pc":
            navigateTo = "Main";
            break;
          default:
        }
        headerModel.refresh();
        if (navigateTo) {
          this.getOwnerComponent().getRouter().navTo(navigateTo);
        }
      },

      /**
      * @function _formatCurrentDate
      * @description  This function formats the current date and returns it as a string.
      * @param {date} date
      */
      _formatCurrentDate: function (date = new Date()) {
        const options = {
          day: "2-digit",
          month: "long",
          year: "numeric"
        };
        return `Current Date : ${date.toLocaleDateString("en-GB", options)
          }`;
      },

      /**
       * @function getFullMonth
       * @description Function to get full month
       * @param {date} date
       */
      getFullMonth: function (date = new Date()) {
        return date.toLocaleString('default', { month: 'long' });
      },

    });
  },
);
