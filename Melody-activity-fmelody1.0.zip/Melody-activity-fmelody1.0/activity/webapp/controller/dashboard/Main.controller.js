sap.ui.define(
  [
    "sap/ui/core/mvc/Controller",
    "sap/ui/integration/Host",
    "sap/ui/integration/library",
    "sap/ui/core/util/MockServer",
    "sap/ui/model/odata/v2/ODataModel",
    "com/melodysuite/activity/util/CardAction",
    "com/melodysuite/activity/util/StaticCard",
    "com/melodysuite/activity/util/OpportunityAI",
    "com/melodysuite/activity/enum/StaticCardData",
    "com/melodysuite/activity/service/CardService",
    "com/melodysuite/activity/controller/BaseController",
  ],
  (Controller, Host, IntegrationLibrary, MockServer, ODataModel, CardAction, StaticCard, OpportunityAIUtil, StaticCardData, CardService, BaseController,) => {
    "use strict";
    return BaseController.extend("com.melodysuite.activity.controller.dashboard.Main", {
      onInit() {
        BaseController.prototype.onInit.apply(this, arguments);
        this.initializeDashboardModels();
        this.getRouter().attachRoutePatternMatched(this.onDashboardRoutePatternMatched, this,);
        this.oComponent.setDashboardController(this);
        this._fnResize = this.onScreenResize.bind(this);
        sap.ui.Device.resize.attachHandler(this._fnResize);

        //Init functions
        this._fnResize();
        this.setHeaderKPIs();
      },

      onExit: function () {
        this._oMockServerDefault.stop();
        this._oMockServerDisplayValue.stop();
      },


      /**
        * @function initializeDashboardModels
        * @description function to initialize dashboard models
        */
      initializeDashboardModels: function () {
        this.OpportunityAIUtil = OpportunityAIUtil;
        this.apiModel = this.oComponent.getModel("apiModel");
        const d3CtrlModel = new sap.ui.model.json.JSONModel({});
        const dashboardModel = this.oComponent.getModel("dashboardModel");

        this.getView().setModel(dashboardModel, "dashboardModel");
        this.getView().setModel(d3CtrlModel, "d3CtrlModel");
        dashboardModel.setProperty("/lazyCard", true);
        dashboardModel.refresh();
      },

      /**
      * @function onDashboardRoutePatternMatched
      * @description function to handle router pattern matched event
      */
      onDashboardRoutePatternMatched: function () {
        this.setCardsData();
      },

      /**
       * @function setCardsData
       * @description This function sets the data for the cards displayed in the grid.
       */
      setCardsData: async function () {
        this.BusyDialog = new sap.m.BusyDialog({});
        let dashboardModel = this.getModel("dashboardModel");
        try {
          const urlParameters = {
            urlParams: {
              $expand: 'ToGTC'
            }
          };

          const cardJSONData = await CardService.getDashboardCardJSONData(urlParameters);

          dashboardModel.setProperty("/groupedDashboardCards", []);
          dashboardModel.setProperty("/timeBusy", true);
          const timeDataLoaded = dashboardModel.getProperty("/timeDataLoaded") ?? false;

          if (cardJSONData) {
            let results = cardJSONData.data.results || [];
            const processedData = this.segregateCardsForDashboard(results, StaticCard);
            dashboardModel.setProperty("/groupedDashboardCards", processedData);
            this.initialiseWorkbenchGroupsData();
            this.BusyDialog.close();
          }
          dashboardModel.refresh();
        } catch (error) {
          this.BusyDialog.close();
          console.log("setCardsData : ", error);
          setTimeout(() => {
            this.onShowHideLazyCards(true);
          }, 2500);
        }
      },

      /**
       * @function onShowHideLazyCards
       * @description function to handle visibility of lazy loading cards
       * @param {boolean} isError
       */
      onShowHideLazyCards: function (isError = false) {
        try {
          const lazyCardBlock = this.getView().byId("lazyCardBlocks");
          const dashboardModel = this.getView().getModel("dashboardModel");

          if (!lazyCardBlock) {
            dashboardModel.setProperty("/lazyCard", false);
            return;
          }

          const currentLazyCard = dashboardModel.getProperty("/lazyCard");
          if (!currentLazyCard) {
            lazyCardBlock.addStyleClass("fadeBlockVisible");
          } else {
            lazyCardBlock.removeStyleClass("fadeBlockVisible");
          }

          setTimeout(() => {
            dashboardModel.setProperty("/lazyCard", !currentLazyCard);
            dashboardModel.refresh();

            const lazyCardBlock = this.getView().byId("lazyCardBlocks");
            if (lazyCardBlock) {
              lazyCardBlock.destroy();
            }
          }, 500);
        } catch (error) {
          console.log("ERROR IN onShowHideLazyCards : ", error)
        }
      },

      /**
        * @function initialiseWorkbenchGroupsData
        * @description function to initializes the groups for the dashboard cards.
        */
      initialiseWorkbenchGroupsData: async function () {
        try {
          const dashboardModel = this.getView().getModel("dashboardModel");
          const groupPromise = CardService.getDashboardCardGroupData({
            urlParams: {
              $expand: "to_GrpCard",
            },
          });
          const listPromise = CardService.getDashboardCardListData({
            urlParams: {
              $expand: "to_Cards",
            },
          });
          const [cardGroupData, cardListData] = await Promise.all([groupPromise, listPromise]);
          if (cardGroupData?.data?.results?.[0]?.to_GrpCard?.results) {
            dashboardModel.setProperty("/workbenchGroupUnformattedData", cardGroupData.data.results[0].to_GrpCard.results);
          }
          if (cardListData?.data?.results?.[0]?.to_Cards?.results) {
            dashboardModel.setProperty("/cardListWorkbench", cardListData.data.results[0].to_Cards.results);
          }
          dashboardModel.refresh();
        } catch (error) {
          console.log("ERROR IN initialiseWorkbenchGroupsData :", error);
        }
      },


      /**
        * @function factoryFuncToInsrtCardToGrid
        * @description function to handle factory function to insert cards into the Grid Container and updates the layout accordingly
        * @param {string} id
        * @param {string} context
        */
      factoryFuncToInsrtCardToGrid: function (id, context) {
        try {
          let columnSize = 1;
          const isDesktop = sap.ui.Device.system.desktop;
          let cardData = context.getObject() || false;
          const dashboardModel = this.getView().getModel("dashboardModel");
          const lazyCard = dashboardModel.getProperty("/lazyCard");

          if (lazyCard && !this?.lazyCardBlock) {
            this.lazyCardBlock = true;
            setTimeout(() => {
              this.onShowHideLazyCards();
            }, 2500);
          }
          if (!cardData) {
            return;
          }

          switch (cardData.type) {
            case "mtr":
              if (!this.timeCard || this.timeCard.isDestroyed()) {
                this.timeCard = this.generateTimeCard();
              }
              this.timeCard.addStyleClass("sapUiSizeCompact");
              this.timeCard.addStyleClass("gridCardItem");
              return this.timeCard;
            case "carouselcard":
              if (!this.carouselcard || this.carouselcard.isDestroyed()) {
                this.carouselcard = this.generateCarouselcard();
              }
              this.carouselcard.addStyleClass("sapUiSizeCompact");
              this.carouselcard.addStyleClass("gridCardItem");
              return this.carouselcard;
            case "mrquarterlycard":
              if (!this.mrquarterlycard || this.mrquarterlycard.isDestroyed()) {
                this.mrquarterlycard = this.generateMRquarterlyCard();
              }
              this.mrquarterlycard.addStyleClass("sapUiSizeCompact");
              this.mrquarterlycard.addStyleClass("gridCardItem");
              return this.mrquarterlycard;
            default:
          }

          //To handle column for custom table card
          let cardManifest = cardData["sap.card"]["cardUIBindings"];
          if (cardManifest) {
            columnSize = isDesktop ? cardManifest["columnSize"] : 1;
            let cardId = cardManifest["id"];
            switch (cardId) {
              case "ACTIVITY_CARD":
                break;
              case "ACTIVITY_CARD1":
                break;
            }
          }

          const card = new sap.ui.integration.widgets.Card({
            manifest: cardData,
            layoutData: new sap.f.GridContainerItemLayoutData({
              columns: columnSize
            })
          });
          const hostEvent = new Host({
            action: CardAction.handleAction.bind(this, card.getId())
          });
          card.setHost(hostEvent);
          card.addStyleClass("sapUiSizeCompact");
          card.addStyleClass("gridCardItem");
          card.setDataMode("Auto");
          return card;
        } catch (error) {
          console.log("ERROR IN factoryFuncToInsrtCardToGrid : ", error);
          setTimeout(() => {
            this.onShowHideLazyCards(true);
          }, 2500);
        }
      },

      /**
       * @function generateCarouselcard
       * @description Function to generate Melody Announcements card
       */
      generateCarouselcard: function () {
        const dashboardModel = this.getModel("dashboardModel");
        dashboardModel.setProperty("/MelodyAnnouncements", StaticCardData.CAROUSELCARDDATA);

        if (!this._carouselcardFragment || this._carouselcardFragment.isDestroyed()) {
          this._carouselcardFragment = sap.ui.xmlfragment("com.melodysuite.activity.fragments.dashboard.MelodyAnnouncements", this);
          this._carouselcardFragment.setModel(dashboardModel, "dashboardModel");
          this.getView().addDependent(this._carouselcardFragment);
        }

        dashboardModel.refresh();
        return this._carouselcardFragment;
      },


      /**
      * @function generateMRquarterlyCard
      * @description Function to generate Melody Request Quaterly Data Card
      */
      generateMRquarterlyCard: function () {
        const dashboardModel = this.getModel("dashboardModel");
        dashboardModel.setProperty("/mrQuarterlyPerformanceData", StaticCardData.MRQUATERLYCARDATA);

        if (!this._mrQuarterlyCardFragment || this._mrQuarterlyCardFragment.isDestroyed()) {
          this._mrQuarterlyCardFragment = sap.ui.xmlfragment("com.melodysuite.activity.fragments.dashboard.MRquarterlyPerformance", this);
          this._mrQuarterlyCardFragment.setModel(dashboardModel, "dashboardModel");
          this.getView().addDependent(this._mrQuarterlyCardFragment);
        }

        dashboardModel.refresh();
        return this._mrQuarterlyCardFragment;
      },

      /**
       * @function generateTimeCard
       * @description Function to generate Time Entry Card
       */
      generateTimeCard: function () {
        const dashboardModel = this.getView().getModel("dashboardModel");
        if (!this._timeEntryFragment || this._timeEntryFragment.isDestroyed()) {
          this._timeEntryFragment = sap.ui.xmlfragment("com.melodysuite.activity.fragments.dashboard.TimeEntry", this);
          this._timeEntryFragment.setModel(dashboardModel, "dashboardModel");
          this.getView().addDependent(this._timeEntryFragment);
        }
        return this._timeEntryFragment;
      },


      /*************************************** MANAGE CARDS FUNCTIONALITY STARTS HERE ***************************/
      /**
       * @function openManageCards
       * @description Opens the card com.melody.launchpad user to view and edit their cards.
       * @param {sap.ui.base.Event} event
       */
      openManageCards: async function (event) {
        const constructorObject = await this.fnLoadFileOnDemand("com/melodysuite/activity/util/ManageCardUtil");
        const manageCardUtil = new constructorObject(this);
        manageCardUtil.openManageCardsDialog();
      },

      /*************************************** MANAGE CARDS FUNCTIONALITY ENDS HERE ***************************/


      /*************************************** AI Opportunity CARD FUNCTIONALITY START HERE *******************/
      /**
        * @function fnSegregateOpportunityTimeData
        * @author DARSHAN
        * @description function to segregate time data based on opportunityId from opportunity Card
        */
      fnSegregateOpportunityTimeData: function (event, applicationData = { id: "" }) {
        try {
          let parameter;
          let opportunityId;

          if (event) {
            parameter = event.getParameter("parameters") || {};
            opportunityId = parameter?.url;
          } else {
            opportunityId = applicationData.id;
          }

          const dashboardModel = this.getView().getModel("dashboardModel");
          // const dayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
          // const entries = dayWeekTimesheetModel.getProperty("/Entries") || [];
          const entries = [];
          dashboardModel.setProperty("/opportunityPieChartData", []);

          if (!opportunityId) {
            return;
          }

          const entriesForOpportunity = entries.filter((entry) => {
            return entry.CostTypeValue === "300069994";
          });

          if (!entriesForOpportunity.length) {
            return;
          }

          let opportunityPieChartData = [
            {
              Type: "CF",
              count: Math.floor(Math.random() * 21),
              items: [],
            },
            {
              Type: "NCF",
              count: Math.floor(Math.random() * 21),
              items: [],
            },
          ];

          for (let i = 0; i < entriesForOpportunity.length; i++) {
            let insertAt;
            let entry = entriesForOpportunity[i];
            let pieData = {
              ActvtId: entry.ActvtId,
              ActTypeDesc: entry.ActTypeDesc,
              WorkDuration: entry.WorkDuration,
            };
            if (entry.CustomerFacing) {
              insertAt = 0;
            } else {
              insertAt = 1;
            }
            opportunityPieChartData[insertAt].count += 1;
            opportunityPieChartData[insertAt].items.push(pieData);
          }
          dashboardModel.setProperty("/opportunityPieChartData", opportunityPieChartData);
          dashboardModel.refresh();
        } catch (error) {
          console.log("ERROR IN fnSegregateOpportunityTimeData :", error);
        }
      },

      /**
        * @function openOpportunityDetails
        * @description function to show details of Analytical card in Popover
        */
      openOpportunityDetails: async function (event, applicationData = {
        id: "",
      }, type = "DASHBOARD",) {
        debugger;
        this.openBusyIndicator();
        let validateData = true;
        let opportunityId = "";
        let vizModel = this.getView().getModel("d3CtrlModel");
        let dashboardModel = this.getView().getModel("dashboardModel");

        try {
          this.OpportunityAIUtil.init(this);
          if (event) {
            opportunityId = event.getParameter("parameters").url || "300069694";
          } else {
            opportunityId = applicationData.id ? applicationData.id : "";
            if (!opportunityId) {
              validateData = false;
            }
          }

          dashboardModel.setProperty("/opportunityAIDialogBusy", true);

          const { opportunityData,
            opportunityAIData,
            opportunityTeamData,
            opportunityHderInfo,
            opportunityKPIResult } = this.showOpportunityDetailsAndLoadData(opportunityId, type);


          vizModel.setData((validateData) ? opportunityAIData : {
            currentProbability: 0,
            bestProbability: 0,
            activities: [],
            roles: [],
          });
          dashboardModel.setProperty("/opportunityData", (validateData) ? opportunityData : {});
          dashboardModel.setProperty("/opportunityTeamData", (validateData) ? opportunityTeamData : []);
          dashboardModel.setProperty("/opportunityKPIData", (validateData) ? opportunityKPIResult : []);
          dashboardModel.setProperty("/opportunityDialogData", (validateData) ? opportunityHderInfo : []);

        } catch (error) {
          console.log("ERROR IN openOpportunityDetails : ", error);
        }
        this.closeBusyIndicator();
        dashboardModel.setProperty("/opportunityAIDialogBusy", false);
        dashboardModel.refresh();
      },

      /*************************************** AI Opportunity CARD FUNCTIONALITY ENDS HERE ********************/

      /*************************************** HEADER FUNCTIONALITY STARTS HERE *******************************/

      /**
       * @function setHeaderKPIs
       * @description function to set header KPI data
       */
      setHeaderKPIs: function () {
        const dashboardModel = this.oComponent.getModel("dashboardModel");
        dashboardModel.setProperty("/KPIData", StaticCardData.HARVEYBALLDATA);
        dashboardModel.refresh();
      },

      /**
       * @function comparisonMicroChartPress
       * @description function to handle comparisonMicroChart press event
       * @param {object} event 
       * @param {string} type 
       */
      comparisonMicroChartPress: function (event, type) {

      },

      /**
       * @function harveyBallPress
       * @description function to handle harveyBallPress
       * @param {object} event 
       * @param {string} harveyBallText 
       */
      harveyBallPress: function (event, harveyBallText) {

      },

      /*************************************** HEADER FUNCTIONALITY ENDS HERE *********************************/

      /*************************************** SCREEN RE_SIZE FUNCTIONALITY STARTS HERE ***********************/
      //function to handle screen re-size
      onScreenResize: function (event = {}) {
        let dashboardHeaderGrid = true;
        let dashboardHeaderScroll = false;
        let dashboardHeaderTimePageCount = 4;
        const isPhone = sap.ui.Device.system.phone;
        const isTablet = sap.ui.Device.system.tablet;
        const isDesktop = sap.ui.Device.system.desktop;
        const isPortrait = sap.ui.Device.orientation.portrait;
        const isLandscape = sap.ui.Device.orientation.landscape;
        const dashboardModel = this.oComponent.getModel("dashboardModel");
        const deviceType = isDesktop ? "desktop" : isTablet ? "tablet" : isPhone ? "phone" : "unknown";
        const orientation = isPortrait ? "portrait" : isLandscape ? "landscape" : "unknown";
        const key = `${deviceType}_${orientation}`;
        switch (key) {
          case "phone_portrait":
          case "phone_landscape":
            dashboardHeaderGrid = false;
            dashboardHeaderScroll = true;
            break;
          case "tablet_landscape":
            dashboardHeaderGrid = true;
            dashboardHeaderScroll = false;
            dashboardHeaderTimePageCount = 3;
            break;
          case "tablet_portrait":
            dashboardHeaderGrid = false;
            dashboardHeaderScroll = true;
            dashboardHeaderTimePageCount = 3;
            break;
          case "desktop_unknown":
          case "desktop_landscape":
            dashboardHeaderGrid = true;
            dashboardHeaderScroll = false;
            if ("height" in event && "width" in event) {
              if (event.width < 1200) {
                dashboardHeaderTimePageCount = 3;
                break;
              }
              if (event.width > 2000) {
                dashboardHeaderTimePageCount = 5;
                break;
              }
            } else {
              const width = window.innerWidth;
              if (width > 1900 && width < 2000) {
                dashboardHeaderTimePageCount = 5;
                break;
              }
              if (width < 1200) {
                dashboardHeaderTimePageCount = 3;
                break;
              }
            }
            dashboardHeaderTimePageCount = 4;
            break;
          default:
            dashboardHeaderGrid = true;
            dashboardHeaderScroll = false;
            dashboardHeaderTimePageCount = 4;
            break;
        }
        dashboardModel.setProperty("/dashboardHeaderGrid", dashboardHeaderGrid);
        dashboardModel.setProperty("/dashboardHeaderScroll", dashboardHeaderScroll);
        dashboardModel.setProperty("/dashboardHeaderTimePageCount", dashboardHeaderTimePageCount);
        dashboardModel.refresh();
      },
      /*************************************** SCREEN RE_SIZE FUNCTIONALITY ENDS HERE ***************************/

      /*************************************** SEGRAGTE CARDS FOR DASHBOARD LAYOUT FROM API  ***************************/
      /**
       * @function segregateCardsForDashboard
       * @description function to handle harveyBallPress
       * @param {object} event 
       * @param {string} harveyBallText 
       */
      segregateCardsForDashboard: function (data = [], staticCard) {
        const groupedDashboardCards = [];
        debugger;

        for (let i = 0; i < data.length; i++) {
          let item = data[i];
          let groupObject = {
            groupTitle: item.GroupDesc.length === 0 ? "My Cards" : item.GroupDesc,
            groupId: item.GroupGuid,
            groupCards: (!item.Payload.length) ? [] : JSON.parse(item.Payload.slice(1, -1)),
            groupLayouts: [
              {
                cards: [],
              },
            ],
            groupShowMtr: item.GroupDesc.length === 0 ? true : false,
          };

          if (groupObject.groupId === "00000000-0000-0000-0000-000000000000") {
            // groupObject.groupCards.push(staticCard.QUICKVIEWSTACK);
            // groupObject.groupCards.push(staticCard.QUICKVIEWACTSTACK);
            // groupObject.groupCards.push(staticCard.QUICKVIEWDISOPPSTACK);
            // groupObject.groupCards.push(staticCard.QUICKVIEWACTPASTENDDATESTACK);
            // groupObject.groupCards.push(staticCard.QUICKVIEWREQUESTPROCESSSTACK);
            // groupObject.groupCards.push(staticCard.MANAGERANALYTICCARD);
            // groupObject.groupCards.push(staticCard.CUSTOMTABLE1);
            // groupObject.groupCards.push(staticCard.ACTIVITYBYCVJPHASE);
            // groupObject.groupCards.push(staticCard.DAYWEEKMTRCARD);
            // groupObject.groupCards.push(staticCard.APICARDSL);
          }
          groupObject.groupCards = groupObject.groupCards.map((card) => {
            card["sap.app"].id = "com.melodysuite.activity";
            return card;
          });
          groupedDashboardCards.push(groupObject);
        }
        return groupedDashboardCards;
      }
      /*************************************** SEGRAGTE CARDS FOR DASHBOARD LAYOUT FROM API ***************************/
    });
  });