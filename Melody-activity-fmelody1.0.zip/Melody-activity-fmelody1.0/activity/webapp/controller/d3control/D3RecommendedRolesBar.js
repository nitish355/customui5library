sap.ui.define([
  "sap/ui/core/Control"
], function (Control) {
  "use strict";

  return Control.extend("com.melodysuite.activity.controller.d3control.D3RecommendedRolesBar", {

    metadata: {
      properties: {
        data: { type: "object" }, // roles array
        title: { type: "string", defaultValue: "Recommended Roles" }
      }
    },

    renderer: function (oRm, oControl) {
      oRm.write("<div");
      oRm.writeControlData(oControl);
      oRm.addStyle("width", "100%");
      oRm.addStyle("height", "160px");
      oRm.writeStyles();
      oRm.write("></div>");
    },

    onAfterRendering: function () {
      this._render();
    },

    _render: function () {
      const dom = this.getDomRef();
      dom.innerHTML = "";

      const data = this.getData() || [];
      if (!data.length) {
        return;
      }

      const margin = { top: 10, right: 20, bottom: 10, left: 160 };
      const width = dom.clientWidth - margin.left - margin.right;
      const height = dom.clientHeight - margin.top - margin.bottom;

      const svg = d3.select(dom)
        .append("svg")
        .attr("width", dom.clientWidth)
        .attr("height", dom.clientHeight)
        .append("g")
        .attr("transform", `translate(${margin.left},${margin.top})`);

      // Scales
      const y = d3.scale.ordinal()
        .domain(data.map(d => d.name))
        .rangeRoundBands([0, height], 0.5);

      const x = d3.scale.linear()
        .domain([0, d3.max(data, d => d.lift)])
        .range([0, width]);

      // Bars
      svg.selectAll(".bar")
        .data(data)
        .enter()
        .append("rect")
        .attr("y", d => y(d.name))
        .attr("height", y.rangeBand())
        .attr("x", 0)
        .attr("width", 0)
        .attr("fill", "#9CA3AF")
        .transition()
        .duration(700)
        .attr("width", d => x(d.lift));

      // Labels
      svg.selectAll(".label")
        .data(data)
        .enter()
        .append("text")
        .attr("x", d => x(d.lift) + 6)
        .attr("y", d => y(d.name) + y.rangeBand() / 2)
        .attr("dy", "0.35em")
        .style("font-size", "11px")
        .style("fill", "#374151")
        .text(d => `+${d.lift.toFixed(2)}% → ${d.newProbability.toFixed(2)}%`);

      // Y-axis (role names)
      svg.append("g")
        .call(d3.svg.axis().scale(y).orient("left"))
        .selectAll("text")
        .style("font-size", "11px");

      // Title (HTML)
      d3.select(dom)
        .append("div")
        .style("text-align", "left")
        .style("margin-top", "-6px")
        .style("font-size", "13px")
        .style("font-weight", "600")
        .style("color", "#374151")
        .text(this.getTitle());
    }
  });
});
