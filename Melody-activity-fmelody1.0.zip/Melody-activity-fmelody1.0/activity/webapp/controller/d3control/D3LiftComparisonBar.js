sap.ui.define([
  "sap/ui/core/Control"
], function (Control) {
  "use strict";

  return Control.extend("com.melodysuite.activity.controller.d3control.D3LiftComparisonBar", {

    metadata: {
      properties: {
        data: { type: "object" },   // activities array
        title: { type: "string", defaultValue: "Lift Comparison" }
      }
    },

    renderer: function (oRm, oControl) {
      oRm.write("<div");
      oRm.writeControlData(oControl);
      oRm.addStyle("width", "100%");
      oRm.addStyle("height", "160px");
      oRm.writeStyles();
      oRm.write("></div>");
    },

    onAfterRendering: function () {
      this._render();
    },

    _render: function () {
      const dom = this.getDomRef();
      dom.innerHTML = "";

      const data = this.getData() || [];
      if (!data.length) {
        return;
      }

      const margin = { top: 20, right: 40, bottom: 20, left: 140 };
      const width = dom.clientWidth - margin.left - margin.right;
      const height = dom.clientHeight - margin.top - margin.bottom;

      const svg = d3.select(dom)
        .append("svg")
        .attr("width", dom.clientWidth)
        .attr("height", dom.clientHeight)
        .append("g")
        .attr("transform", `translate(${margin.left - 22},${margin.top})`);

      // Y scale (activity names)
      const y = d3.scale.ordinal()
        .domain(data.map(d => d.name))
        .rangeRoundBands([0, height], 0.4);

      // X scale (lift %)
      const x = d3.scale.linear()
        .domain([0, d3.max(data, d => d.lift)])
        .range([0, width]);

      // Bars
      svg.selectAll(".bar")
        .data(data)
        .enter()
        .append("rect")
        .attr("class", "bar")
        .attr("y", d => y(d.name))
        .attr("height", y.rangeBand())
        .attr("x", 0)
        .attr("width", 0)
        .attr("fill", "#2F80ED")
        .transition()
        .duration(800)
        .attr("width", d => x(d.lift));

      // Lift value labels
      svg.selectAll(".label")
        .data(data)
        .enter()
        .append("text")
        .attr("x", d => x(d.lift) + 6)
        .attr("y", d => y(d.name) + y.rangeBand() / 2)
        .attr("dy", "0.35em")
        .style("font-size", "12px")
        .style("fill", "#374151")
        .text(d => `+${d.lift.toFixed(2)}%`);

      // Y Axis (names)
      svg.append("g")
        .call(d3.svg.axis().scale(y).orient("left"))
        .selectAll("text")
        .style("font-size", "12px");

      // Title (HTML – avoids SVG clipping)
      d3.select(dom)
        .append("div")
        .style("text-align", "center")
        .style("margin-top", "-24px")
        .style("font-size", "14px")
        .style("font-weight", "600")
        .style("color", "#374151")
        .text(this.getTitle());
    }
  });
});
