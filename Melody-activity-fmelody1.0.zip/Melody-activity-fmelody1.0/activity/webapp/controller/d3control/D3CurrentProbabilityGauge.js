sap.ui.define([
    "sap/ui/core/Control"
], function (Control) {
    "use strict";

    return Control.extend("com.melodysuite.activity.controller.d3control.D3CurrentProbabilityGauge", {

        metadata: {
            properties: {
                value: { type: "float", defaultValue: 0 }, // 0–100
                title: { type: "string", defaultValue: "Current Probability" }
            }
        },

        renderer: function (oRm, oControl) {
            oRm.write("<div");
            oRm.writeControlData(oControl);
            oRm.addStyle("width", "200px");
            oRm.addStyle("height", "160px");
            oRm.writeStyles();
            oRm.write("></div>");
        },

        onAfterRendering: function () {
            this._render();
        },

        _render: function () {
            const dom = this.getDomRef();
            dom.innerHTML = "";

            const value = Math.max(0, Math.min(this.getValue(), 100));

            const width = 240;
            const height = 140;
            const radius = 100;

            // Color logic
            const color =
                value < 30 ? "#EB5757" :
                    value < 60 ? "#F2C94C" :
                        "#27AE60";

            const svg = d3.select(dom)
                .append("svg")
                .attr("width", width)
                .attr("height", height)
                .append("g")
                .attr("transform", `translate(${width / 2},${120})`);

            // Arc (D3 v3 compatible)
            const arc = d3.svg.arc()
                .innerRadius(radius - 12)
                .outerRadius(radius)
                .startAngle(-Math.PI / 2);

            // Background arc
            svg.append("path")
                .datum({ endAngle: Math.PI / 2 })
                .attr("d", arc)
                .attr("fill", "#E5E7EB");

            // Foreground arc
            svg.append("path")
                .datum({ endAngle: -Math.PI / 2 })
                .attr("fill", color)
                .attr("d", arc)
                .transition()
                .duration(900)
                .attrTween("d", function () {
                    const interpolate = d3.interpolate(
                        -Math.PI / 2,
                        (-Math.PI / 2) + (value / 100) * Math.PI
                    );
                    return function (t) {
                        return arc({ endAngle: interpolate(t) });
                    };
                });

            // Value text
            svg.append("text")
                .attr("text-anchor", "middle")
                .attr("dy", "-0.2em")
                .style("font-size", "32px")
                .style("font-weight", "600")
                .style("fill", color)
                .text(`${value.toFixed(0)}%`);

            // Title
            d3.select(dom)
                .append("div")
                .style("text-align", "center")
                .style("margin-top", "-6px")
                .style("font-size", "14px")
                .style("color", "#6B7280")
                .text(this.getTitle());
        }
    });
});
