sap.ui.define([
  "sap/ui/core/Control"
], function (Control) {
  "use strict";

  return Control.extend("com.melodysuite.activity.controller.d3control.D3ActivityKpiRing", {

    metadata: {
      properties: {
        title: { type: "string" },
        value: { type: "float" },   // NewProbability
        lift: { type: "float" }     // Lift
      },
      events: {
        select: {}
      }
    },

    renderer: function (oRm, oControl) {
      oRm.write("<div");
      oRm.writeControlData(oControl);
      oRm.addStyle("width", "140px");
      oRm.addStyle("height", "110px");
      oRm.writeStyles();
      oRm.write("></div>");
    },

    onAfterRendering: function () {
      this._renderChart();
    },

    _renderChart: function () {
      const dom = this.getDomRef();
      dom.innerHTML = "";

      const value = this.getValue();   // 58.43
      const lift = this.getLift();     // 32.32
      const title = this.getTitle();

      const width = 140;
      const height = 120;
      const radius = 55;

      const color = lift >= 30 ? "#27AE60" :
        lift >= 15 ? "#F2C94C" :
          "#EB5757";

      const svg = d3.select(dom)
        .append("svg")
        .attr("width", width)
        .attr("height", height + 20)
        .append("g")
        .attr("transform", `translate(${width / 2},${height / 2})`);
      const that = this;

      svg.on("click", function () {
        that.fireSelect({
          value: value,
          lift: lift,
          title: title
        });
      });

      // Background ring
      svg.append("circle")
        .attr("r", radius)
        .attr("fill", "none")
        .attr("stroke", "#E5E7EB")
        .attr("stroke-width", 10);

      // Foreground arc
      // Foreground arc
      const arc = d3.svg.arc()
        .innerRadius(radius - 10)
        .outerRadius(radius)
        .startAngle(0);


      svg.append("path")
        .datum({ endAngle: 0 })
        .attr("fill", color)
        .attr("d", arc)
        .transition()
        .duration(900)
        .attrTween("d", function () {
          const interpolate = d3.interpolate(
            0,
            (value / 100) * 2 * Math.PI
          );
          return t => arc({ endAngle: interpolate(t) });
        });

      // Value text
      svg.append("text")
        .attr("text-anchor", "middle")
        .attr("dy", "-0.2em")
        .style("font-size", "28px")
        .style("font-weight", "600")
        .text(`${value.toFixed(0)}%`);

      // Lift text
      svg.append("text")
        .attr("text-anchor", "middle")
        .attr("dy", "1.2em")
        .style("font-size", "13px")
        .style("fill", color)
        .text(`+${lift.toFixed(2)}%`);

      // Title
      d3.select(dom)
        .append("div")
        .style("text-align", "center")
        .style("font-size", "12px")
        .style("margin-top", "-27px")
        .style("color", "#374151")
        .text(title);
    }
  });
});
