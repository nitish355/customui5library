sap.ui.define([
  "sap/ui/core/Control"
], function (Control) {
  "use strict";

  return Control.extend("com.melodysuite.activity.controller.d3control.D3OverallImpactDonut", {

    metadata: {
      properties: {
        current: { type: "float", defaultValue: 0 }, // CurrentProbability
        target: { type: "float", defaultValue: 0 },  // Best NewProbability
        title: { type: "string", defaultValue: "Overall Impact" }
      }
    },

    renderer: function (oRm, oControl) {
      oRm.write("<div");
      oRm.writeControlData(oControl);
      oRm.addStyle("width", "260px");
      oRm.addStyle("height", "220px");
      oRm.writeStyles();
      oRm.write("></div>");
    },

    onAfterRendering: function () {
      this._render();
    },

    _render: function () {
      const dom = this.getDomRef();
      dom.innerHTML = "";

      const current = Math.max(0, Math.min(this.getCurrent(), 100));
      const target = Math.max(current, Math.min(this.getTarget(), 100));

      const width = 260;
      const height = 180;
      const radius = 70;

      const svg = d3.select(dom)
        .append("svg")
        .attr("width", width)
        .attr("height", height)
        .append("g")
        .attr("transform", `translate(${width / 2},${height / 2})`);

      const arc = d3.svg.arc()
        .innerRadius(radius - 18)
        .outerRadius(radius);

      const pie = d3.layout.pie()
        .sort(null)
        .value(d => d.value);

      const data = [
        { label: "Target", value: target },
        { label: "Remaining", value: 100 - target }
      ];

      const color = d3.scale.ordinal()
        .range(["#27AE60", "#E5E7EB"]);

      const g = svg.selectAll(".arc")
        .data(pie(data))
        .enter()
        .append("g");

      g.append("path")
        .attr("fill", d => color(d.data.label))
        .transition()
        .duration(900)
        .attrTween("d", function (d) {
          const i = d3.interpolate(
            { startAngle: 0, endAngle: 0 },
            d
          );
          return function (t) {
            return arc(i(t));
          };
        });

      // Center text: Current → Target
      svg.append("text")
        .attr("text-anchor", "middle")
        .attr("dy", "-0.2em")
        .style("font-size", "18px")
        .style("font-weight", "600")
        .style("fill", "#374151")
        .text(`${current.toFixed(0)}% → ${target.toFixed(0)}%`);

      svg.append("text")
        .attr("text-anchor", "middle")
        .attr("dy", "1.4em")
        .style("font-size", "12px")
        .style("fill", "#6B7280")
        .text("Best achievable");

      // Title (HTML)
      d3.select(dom)
        .append("div")
        .style("text-align", "center")
        .style("margin-top", "-6px")
        .style("font-size", "14px")
        .style("font-weight", "600")
        .style("color", "#374151")
        .text(this.getTitle());
    }
  });
});
