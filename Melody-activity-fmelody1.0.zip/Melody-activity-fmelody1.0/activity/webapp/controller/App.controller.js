sap.ui.define(
  ["com/melodysuite/activity/controller/BaseController"],
  (BaseController) => {
    "use strict";

    return BaseController.extend("com.melodysuite.activity.controller.App", {
      onInit() {
        this.oRouter = this.getOwnerComponent().getRouter();
        this.oRouter.attachRoutePatternMatched(this.onRouteMatched, this);
        this.getView().addStyleClass(this.getContentDensityClass());
      },

      onRouteMatched: function (oEvent) {},

      //Function triggered upon header component initialization from core library
      onHeaderComponentCreated: function (event) {
        const headerModel = this.createJSONModel({
          visible: {
            manageCards: true,
          },
        });

        let component = event.getParameter("component") || {};
        const header = component?.getAggregation("rootControl") || {};
        const toolbar = header?.getContent()[0] || {};
        const toolBarContents = toolbar?.getContent() || {};
        const homeButton = toolBarContents[0] || {};
        header.oApplicationContainer = this.getOwnerComponent();
        header.oApplicationController = this;
        header.setModel(headerModel, "headerModel");
        this.setModel(headerModel, "headerModel");
        homeButton?.attachPress(this.headerHomeButtonPress.bind(this));
      },

      headerHomeButtonPress: function (event) {
        const headerModel = this.getModel("headerModel");
        headerModel.setProperty("/visible/manageCards", true);
        headerModel.refresh();
        this.getRouter().navTo("Main");
      },

      /**
       * @public
       * @function onBeforeRouteMatched
       * @description function to handle flexiable column layout settings
       * @param {sap.ui.base.Event} oEvent
       */
      onBeforeRouteMatched: function (oEvent) {
        //To be revisited
        var oModel = this.getOwnerComponent().getModel();
        var sLayout = oEvent.getParameters().arguments.layout;
        // If there is no layout parameter, query for the default level 0 layout (normally OneColumn)
        if (!sLayout) {
          var oNextUIState = this.getOwnerComponent()
            .getHelper()
            .getNextUIState(0);
          sLayout = oNextUIState.layout;
        }

        // Update the layout of the FlexibleColumnLayout
        if (sLayout) {
          oModel.setProperty("/layout", sLayout);
        }
      },

      /**
       * @private
       * @function _updateUIElements
       * @description Update the close/fullscreen buttons visibility
       */
      _updateUIElements: function () {
        //To be revisited
        var oModel = this.getOwnerComponent().getModel();
        var oUIState = this.getOwnerComponent().getHelper().getCurrentUIState();
        oModel.setData(oUIState);
      },

      onExit: function () {
        this.oRouter.detachRouteMatched(this.onRouteMatched, this);
        this.oRouter.detachBeforeRouteMatched(this.onBeforeRouteMatched, this);
      },
    });
  },
);
