sap.ui.define([
    "com/melodysuite/activity/controller/BaseController"
], function (BaseController) {
    return BaseController.extent("com.melodysuite.activity.controller.activity.MyActivity",{
        /**
         * @function onInit
         * @description LifeCycle Method
         */
        onInit(){

        },

        
    });
});