sap.ui.define(
  ["com/melodylib/core/service/CoreService"],
  function (CoreService, Services) {
    "use strict";
    let oCardService = CoreService.extend("com.melodysuite.activity.service.CardService", {

      getDashboardData: function (entitySet, options) {
        const parameters = {
          filters: options?.filters,
          urlParameters: options?.urlParams
        };
        return this.odata(entitySet).get("melodyDashboard", parameters);
      },

      getDashboardCardJSONData: function (options) {
        return this.getDashboardData("/DASHJSONPAYLOADSet", options);
      },

      getDashboardCardGroupData: function (options) {
        return this.getDashboardData("/YC_MD_T_USERGROUP_DASH", options);
      },

      getDashboardCardListData: function (options) {
        return this.getDashboardData("/YC_MD_M_CARDS_DASH_MAIN", options);
      },

      postWorkbenchDashboardData: function (data) {
        return this.odata("/YC_MD_T_USERGROUP_DASH").post("melodyDashboard", data);
      },

      postWorkbenchDashboardMainData: function (data) {
        return this.odata("/YC_MD_M_CARDS_DASH_MAIN").post("melodyDashboard", data);
      },

      getAnalyticalCardActivityData: function (options) {
        let parameters = {
          filters: options?.filters,
          urlParameters: options?.urlParams,
        };
        return this.odata("/YC_MD_T_OPP_ACTLIST").get("melodyDashboard", parameters);
      },

      getOpportunityData: function (options, entitySetName) {
        let parameters = {
          filters: options?.filters,
          urlParameters: options?.urlParams,
        };
        return this.odata(entitySetName).get("harmony", parameters);
      },

      getOpportunityKPIData: function (options = {}, entitySetName) {
        let parameters = {
          filters: options?.filters ?? [],
          urlParameters: options?.urlParams ?? {},
        };
        return this.odata(entitySetName).get("melodyDashboard", parameters);
      },

      getMelodyExternalIntegration(options = {}) {
        let parameters = {
          filters: options?.filters ?? [],
          urlParameters: options?.urlParams ?? {},
        };
        return this.odata("/YMELODY_EXTERNAL_INTEGRATION_SRV/V_WfInstance_Act").get("melodyDashboard", parameters);
      }
    });
    return new oCardService();
  });