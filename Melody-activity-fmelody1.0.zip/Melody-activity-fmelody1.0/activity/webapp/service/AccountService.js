sap.ui.define(
  [
    "com/melodylib/core/service/CoreService",
    "com/melodysuite/activity/enum/Services",
    "sap/ui/model/Filter",
  ],
  function (CoreService, Services, Filter) {
    let AccountService = CoreService.extend(
      "com.melodysuite.activity.service.AccountService",
      {
        getBusinessAttributeSet: function (globalUltimateID) {
          return this.odata(
            `/BusinessPartnerAttribSet('${globalUltimateID}')`
          ).get("harmony");
        },

        getAccountsListBySearch: function (searchParam) {
          let parameters = {
            filters: [
              new Filter({
                path: "TYPE",
                operator: "EQ",
                value1: "A",
              }),
            ],
            urlParameters: {
              search: searchParam,
            },
          };
          return this.odata("/BusinessPartners").get("harmony", parameters);
        },
      }
    );
    return new AccountService();
  }
);
