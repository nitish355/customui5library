sap.ui.define(
  ["sap/ui/core/UIComponent", "com/melodysuite/activity/model/models"],
  (UIComponent, models) => {
    "use strict";
    return UIComponent.extend("com.melodysuite.activity.Component", {
      metadata: {
        manifest: "json",
        interfaces: ["sap.ui.core.IAsyncContentCreation"],
      },

      init() {
        // call the base component's init function
        UIComponent.prototype.init.apply(this, arguments);
        // set the device model
        this.setModel(models.createDeviceModel(), "device");
        // enable routing
        if (this.getRouter()) {
          //if condition added because of table card component
          this.getRouter().initialize();
        }
      },

      //Function to set Dashboard controller in component for the usage of Manage cards dialog
      setDashboardController: function (dashboard) {
        this.dashboardChild = dashboard;
      },

      //Function to get Dashboard controller from component for the usage of Manage cards dialog
      getDashboardController: function () {
        return this.dashboardChild;
      },
    });
  },
);
