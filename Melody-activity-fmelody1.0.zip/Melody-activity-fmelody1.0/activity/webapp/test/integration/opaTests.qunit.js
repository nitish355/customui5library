/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["com/melodysuite/activity/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
