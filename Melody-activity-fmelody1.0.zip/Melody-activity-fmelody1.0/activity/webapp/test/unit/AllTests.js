sap.ui.define([
	"com/melodysuite/activity/test/unit/controller/App.controller"
], function () {
	"use strict";
});
