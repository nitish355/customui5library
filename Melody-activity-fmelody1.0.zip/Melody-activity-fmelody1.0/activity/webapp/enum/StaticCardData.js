sap.ui.define(
    {
        CAROUSELCARDDATA: [
            {
                backgroundImageUrl:
                    "test-resources/sap/m/demokit/sample/SlideTile/images/NewsImage2.png",
                newsContent: "Melody Announcements",
                footerContent:
                    "SAP Unveils Powerful New Player Comparision Tool Exclusively on NFL.com",
                subheader: "Today, SAP News",
            },
            {
                backgroundImageUrl:
                    "test-resources/sap/m/demokit/sample/SlideTile/images/NewsImage1.png",
                newsContent: "Melody Announcements",
                footerContent:
                    "SAP Unveils Powerful New Player Comparision Tool Exclusively on NFL.com",
                subheader: "Today, SAP News",
            },
            {
                backgroundImageUrl:
                    "test-resources/sap/m/demokit/sample/SlideTile/images/NewsImage2.png",
                newsContent: "Melody Announcements",
                footerContent:
                    "SAP Unveils Powerful New Player Comparision Tool Exclusively on NFL.com",
                subheader: "Today, SAP News",
            },
            {
                backgroundImageUrl:
                    "test-resources/sap/m/demokit/sample/SlideTile/images/NewsImage1.png",
                newsContent: "Melody Announcements",
                footerContent:
                    "SAP Unveils Powerful New Player Comparision Tool Exclusively on NFL.com",
                subheader: "Today, SAP News",
            },
        ],
        MRQUATERLYCARDATA: [
            {
                status: "Closed",
                quarterlyValue: "74",
            },
            {
                status: "In Review",
                quarterlyValue: "26",
            },
            {
                status: "Not Specified",
                quarterlyValue: "2",
            },
        ],
        HARVEYBALLDATA: [
            {
                desc: "Weekly Hours Entered",
                fraction: 25,
                total: 40,
                totalScale: "Activities",
            },
            {
                desc: "Unsubmitted Hours",
                fraction: 15,
                total: 25,
            },
            {
                desc: "Activities w/o Time",
                fraction: 15,
                total: 35,
            }
        ],
        OBJECTSTREAMFORMDATA: [
            {
                "label": "Opportunity",
                "type": "LINK",
                "value": "Nike Transformation (300045948)"
            },
            {
                "label": "End Date",
                "type": "TEXT",
                "value": "March 12, 2026"
            },
            {
                "label": "Status",
                "type": "TEXT",
                "value": "Registered"
            }
        ]
    },
    true,
);
