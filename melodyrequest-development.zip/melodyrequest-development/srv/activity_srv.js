module.exports = srv => {
// Custome Handler to delete assigned activity
srv.on('deleteActivtyList', async (req) => {
  const tx = cds.transaction(req);
 const { YMR_DF_ACTIVITY } = cds.entities('app.activity');
 const { ActivityListsData } = req.data;

  try {
      const deletedRecords = [];
      for (const { INSTANCE_GUID, AssignmentID } of ActivityListsData) {
      const ActivitiesdeletedCount =   await tx.run(
      DELETE.from(YMR_DF_ACTIVITY).where({ INSTANCE_GUID, AssignmentID })
    );
    if (ActivitiesdeletedCount > 0) {
          deletedRecords.push({ INSTANCE_GUID, AssignmentID });
        }
      }
      return {
        success: true,
        message: `${deletedRecords.length} activit${deletedRecords.length > 1 ? 'ies' : 'y'} deleted successfully`,
      };
  } catch (err) {
      await tx.rollback();
    req.error(500, `Failed to delete activity data: ${err.message}`);
  }
});
};