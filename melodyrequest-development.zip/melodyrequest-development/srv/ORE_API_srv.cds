using app.ORE_API from '../db/ORE_API';

service ORE_API_Service @(requires: 'system-user') {
    entity SOrg_PC_Map        as projection on ORE_API.YC_SORg_PC_Map;
    entity FrontStop_BackStop as projection on ORE_API.YC_FrontStop_BackStop;
    entity ResProfile_Master as projection on ORE_API.YMRR_ResProfile_Master;
    entity ProfitCenter       as projection on ORE_API.YMRR_ProfitCenter;

    entity DF_WFIns @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])                       as projection on ORE_API.YMRR_DF_WFIns;

    entity DF_WFIns_Parent @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])                       as projection on ORE_API.YMRR_DF_WFIns_Parent;
    entity DF_ReqForm_SupportType @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])                       as projection on ORE_API.YMRR_DF_ReqForm_SupportType;

    entity DF_ReqForm_Language @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])                       as projection on ORE_API.YMRR_DF_ReqForm_Language;

    entity DF_ReqForm_PartcpType @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])                       as projection on ORE_API.YMRR_DF_ReqForm_PartcpType;

    entity DF_ReqForm_InvSAP_Party @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])                       as projection on ORE_API.YMRR_DF_ReqForm_InvSAP_Party;
       entity DF_ReqForm_URL @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])                       as projection on ORE_API.YMRR_DF_WfinsURL;

      entity YC_dFWfins_Details @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])  as projection on ORE_API.YC_dFWfins_Details;
}


