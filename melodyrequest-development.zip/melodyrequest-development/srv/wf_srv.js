// Custom Handler to update solution/Material data
module.exports = srv => {
 
  srv.on('saveSolutionMatrlData', async (req) => {
  const { InstanceID, additionalSolns = [], solMtrlList = [] } = req.data;
 
  const tx = cds.transaction(req);
 
  try {
 
     await tx.run([
      DELETE.from('APP_WF_YMRR_RESPROFILESEL_SOLAREA').where({ InstanceID }),
      DELETE.from('APP_WF_YMR_T_SOL_MTRL').where({ InstanceID })
    ]);
    // insert operations
    const operations = [
      ...additionalSolns.map(soln => INSERT.into('APP_WF_YMRR_RESPROFILESEL_SOLAREA').entries(soln)),
      ...solMtrlList.map(mtrl => INSERT.into('APP_WF_YMR_T_SOL_MTRL').entries(mtrl))
    ];
 
    // Run only if we have operations
    if (operations.length > 0) {
      await tx.run(operations);
    }
    return { success: true };
 
  } catch (err) {
    req.error(500, `Failed to save solution/Material data: ${err.message}`);
  }
});

srv.on('SaveUserVariantData', async (req) => {
  const { userId, VariantDetails = [] } = req.data;
  
 if (!userId) return req.error(400, "userId is required");

  const tx = cds.transaction(req);
 
  try {
 
     await tx.run([
      DELETE.from('APP_WF_YMR_T_USER_VARIANT').where({ userId })
    ]);
    // insert operations
      if (VariantDetails.length > 0) {
          const userdata = VariantDetails.map(v => ({
              variantGuid: v.variantGuid,
              userId: userId,
              isDefault: v.isDefault
          }));

          await tx.run(
              INSERT.into('APP_WF_YMR_T_USER_VARIANT').entries(userdata)
          );
      }
      return { success: true };
 
  } catch (err) {
    req.error(500, `Failed to save user variant data: ${err.message}`);
  }
});

 srv.on('GetUserNotificationSettings', async (req) => {
    var data = req.data || {};
    var notif_Id = data.notif_Id;
    var usersByRole = data.users;
    var notifVal_Id = data.notifVal_Id;
    if (!usersByRole || !notif_Id || !notifVal_Id) {
      
      return {};
    }
    // Collect unique userIds
    var userIdMap = {};
    var userIds = [];

    Object.keys(usersByRole).forEach(function (role) {
      var users = usersByRole[role] || [];

      users.forEach(function (u) {
        if (u && u.userId && u.email) {
          if (!userIdMap[u.userId]) {
            userIdMap[u.userId] = true;
            userIds.push(u.userId);
          }
        }
      });
    });
   
    if (userIds.length === 0) {
      return usersByRole;
    }

    //fetch excluded user
    const result = await SELECT
      .distinct
      .from('APP_WF_YMR_T_USER_NOTIF')
      .columns('userId')
      .where({
        userId: { in: userIds },
        notif_Id: notif_Id,
        notif_Val_Id: notifVal_Id
      });

if (notifVal_Id === "0001") {
  var response = {};
    if (!result || result.length === 0) {
      
      Object.keys(usersByRole).forEach(function(role) { response[role] = []});
      return response;
    }

    var enabledUsers = {};
    result.forEach(function (r) {
      enabledUsers[r.userId] = true;
    });

    Object.keys(usersByRole).forEach(function (role) {
      var filteredUsers = [];
      var originalUsers = usersByRole[role] || [];
      originalUsers.forEach(function (u) {
        var uid = u.userId;
        if (uid && u.email && enabledUsers[uid]) {
          filteredUsers.push({
            userId: uid,
            email: u.email
          });
        }
      });

      response[role] = filteredUsers;
    });

    return response;
  }

 if (notifVal_Id === "0002") {
  var response = {};
    if (!result || result.length === 0) {
      return usersByRole;
    }

    var excludedUsers = {};
    result.forEach(function (r) {
      excludedUsers[r.userId] = true;
    });
   
    var response = {};
   // Build response role wise
    Object.keys(usersByRole).forEach(function (role) {
      var filteredUsers = [];
      var originalUsers = usersByRole[role] || [];
      originalUsers.forEach(function (u) {
        var uid = u.userId;
        if (uid && u.email && !excludedUsers[uid]) {
          filteredUsers.push({
            userId: uid,
            email: u.email
          });
        }
      });

      response[role] = filteredUsers;
    });

    return response;
  }
  });  

  srv.on('UserCommentUpdate', async (req) => {
    try {
      const { MailTemplate } = require("./mailTemplate");
      const SapCfMailer = require("sap-cf-mailer").default;
      const { uuid } = cds.utils;
      var workflowContext = req.data.context;
      workflowContext = JSON.parse(workflowContext);
      var newdate = new Date().toISOString();
      if(workflowContext.userChatCommentDetails.commentType && workflowContext.userChatCommentDetails.commentType === "CHAT"){
      await INSERT.into("APP_WF_YMR_COMMENT").entries({
        ID: uuid().toString(),
        instanceID: workflowContext.userChatCommentDetails.instanceID,
        commentText: workflowContext.userChatCommentDetails.commentText,
        userID: workflowContext.userChatCommentDetails.userID,
        userEmail: workflowContext.userChatCommentDetails.userEmail,
        userName: workflowContext.userChatCommentDetails.userName,
        userRole: workflowContext.userChatCommentDetails.userRole,
        createdAt: newdate,
        modifiedAt: newdate

      });
    }
      let users = [];
      if (workflowContext.primaryApproverDetails) {
        const processors = workflowContext.primaryApproverDetails;
        processors.forEach(val => {
          let uid = val.userId;

          if (uid && val.email) {
            users.push({
              userId: uid.toUpperCase(),
              email: val.email
            });
          }
        });
      }

       if (workflowContext.substituteApproverDetails && workflowContext.substituteApproverDetails.length> 0 ) {
        const subProcessors = workflowContext.substituteApproverDetails;
        subProcessors.forEach(val => {
          let uid = val.userId;

          if (uid && val.email) {
            users.push({
              userId: uid.toUpperCase(),
              email: val.email
            });
          }
        });
      }

      if (workflowContext.requesterDetails && workflowContext.requesterDetails.id && workflowContext.requesterDetails.email) {
        users.push({
          userId: workflowContext.requesterDetails.id.toUpperCase(),
          email: workflowContext.requesterDetails.email
        });
      }

      if (workflowContext.Assignment && workflowContext.Assignment.length > 0) {
        var assign = workflowContext.Assignment;
        assign.forEach(val => {
          if (val.NominatedResources && val.NominatedResources.length > 0) {

            if (val.NominatedResources[0].userId && val.NominatedResources[0].email) {
              users.push({
                userId: val.NominatedResources[0].userId.toUpperCase(),
                email: val.NominatedResources[0].email
              });
            }
          }
        });
      }

      let userIdMap = {};
      let uniqueUsers = [];

      users.forEach(function (u) {
        if (!userIdMap[u.userId]) {
          userIdMap[u.userId] = true;
          uniqueUsers.push(u);
        }
      });
      users = uniqueUsers;
      var userIds = users.map(function (u) {
        return u.userId;
      });
      const transporter = new SapCfMailer("bpmworkflowruntime_mail");

      //Fetch enabled users
      const result = await SELECT
        .distinct
        .from("APP_WF_YMR_T_USER_NOTIF")
        .columns("userId")
        .where({
          userId: { in: userIds },
          notif_Id: "13",
          notif_Val_Id: "0001"
        });

      if (result.length > 0) {
        var enabledusers = {};
        result.forEach(function (r) {
          enabledusers[r.userId] = true;
        });

        var filteredUsers = [];
        users.forEach(function (u) {
          if (u.userId && u.email && enabledusers[u.userId]) {
            filteredUsers.push(u);
          }
        });

        if (filteredUsers.length > 0) {
          await Promise.all(
            filteredUsers.map(function (u) {

              var emailSubject = "";
                if (workflowContext.RequestType === "Account") {
                  emailSubject = workflowContext.accountName;
                }
                else {
                  emailSubject = workflowContext.Opp_Desc + ", " + workflowContext.accountName;
                }
              
              return transporter.sendMail({
                to: u.email,
                subject: "Melody Request - Comment Added "+ workflowContext.RequestID.value +" - " + emailSubject,
                html: MailTemplate(workflowContext)
              });

            })
          );
        }
      }
      return "Emails sent successfully";
    } catch (error) {

      console.error('Error sending email:', error);

      return `Error sending email: ${error.message}`;

    }

  });
};