const safe = (v) => v ?? "";
export const MailTemplate = (context) => `
<!DOCTYPE html>
<html>
   <head>
      <meta charset="UTF-8">
      <title>Melody Request</title>
      <style>
         body {
         font-family: Arial, sans-serif;
         font-size: 10pt;
         background-color: #ffffff;
         color: #000000;
         }
         .hidden-row {
         display: none;
         visibility: collapse;
         }
         .container {
         width: 800px;
         margin: 0 auto;
         }
         .section-title {
         font-weight: bold;
         margin: 20px 0 12px 0;
         }
         .divider {
         border-top: 1px solid #d9d9d9;
         margin-bottom: 10px;
         }
         table {
         border-collapse: collapse;
         width: 100%;
         }
         .label {
         background-color: #f2f2f2;
         width: 300px;
         padding: 6px;
         border-bottom: 1px solid #e0e0e0;
         vertical-align: top;
         }
         .value {
         padding: 6px;
         border-bottom: 1px solid #e0e0e0;
         }
         .value a {
         color: #0070C0;
         text-decoration: underline;
         }
         .sub-item {
         margin-left: 14px;
         }
         /* Action History */
         .history-table th {
         background-color: #f2f2f2;
         font-weight: bold;
         text-align: left;
         padding: 6px;
         border-bottom: 1px solid #d9d9d9;
         }
         .History-Data {
         padding: 6px;
         border-bottom: 1px solid #e0e0e0;
         vertical-align: top;
         text-align: left;
         }
         .hide-row {
         padding: 0;
         margin: 0;
         border: none;
         height: 0;
         line-height: 0;
         }
      </style>
   </head>
   <body>
      <div class="container">
         <div align="center">
            <table class="x_MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="580" style="width:6.25in">
               <tbody>
                  <table width="100%" cellpadding="0" cellspacing="0" border="0">
                     <tr>
                        <td align="center">
                           <table width="500" cellpadding="0" cellspacing="0" border="0" align="center">
                              <tr>
                                 <td>
                                    <table cellpadding="0" cellspacing="0" border="0"
                                       style="border-collapse: collapse;">
                                       <tr>
                                          <td valign="middle"
                                             style="padding: 0; line-height: 0; width: 65px;">
                                             <img src="http://lsftdc00.tdc.only.sap:8000/sap/bc/bsp/sap/yutlt_img_src/MELODY/Activity/MELODYlogo.png"
                                                width="60" height="60" style="display: block; border: 0;">
                                          </td>
                                          <td valign="middle"
                                             style="padding: 0; padding-left: 8px; line-height: 1.2;">
                                             <span
                                                style="font-family: Arial, sans-serif; font-size: 10pt; font-weight: bold; color: #000000;">
                                             New comments have been posted on
                                             <a href="${context.extSystemsUrls.EmailWorklistURL}${context.WfID_PresalesRequestApproval}"
                                                style="color: #0070C0; font-weight: bold; text-decoration: underline;">
                                             Melody Request ${context.RequestID.value}
                                             </a>
                                             </span>
                                          </td>
                                       </tr>
                                    </table>
                                 </td>
                              </tr>
                              <tr>
                                 <td height="15"></td>
                              </tr>
                              <tr>
                                 <td>
                                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="table-layout: fixed;">
                                       <tr>
                                          <td width="50%" valign="top" style="font-family: Arial, sans-serif; font-size: 10pt; color: #000; padding-right: 5px; padding-bottom: 20px; word-wrap: break-word;">
                                             <strong style="background-color:#EAF4FB; padding:10px; border-radius:6px font-size:10pt; color:#2F5597;">
                                             New Comment Posted
                                             </strong>
                                             <br> <br>
                                             <span style="color:#666;">
                                             From <strong style="font-size:8pt; color:#2F5597;"> ${safe(context.userChatCommentDetails.userName)}</strong>
                                             (${safe(context.userChatCommentDetails.userRole)})
                                             </span><br>
											 <span style="font-family:Arial,sans-serif; font-size:10pt; color:#333;
                                             line-height:1.5;">
											  ${safe(context.userChatCommentDetails.commentText)} 
											  </span>
                                          </td>
                                          <td rowspan="2" width="50%" valign="top" style="background-color: #EAF4FB; padding: 15px; font-family: Arial, sans-serif; font-size: 10pt; color: #333333;">
                                             <strong>Account: </strong>${context.accountName} – <a
                                                href=${context.extSystemsUrls.AccountURL}
                                                style="color:#0070C0;">${context.accountId}</a><br><br>
                                             <strong>Opp: </strong> <span class=${safe(context.EmailTemplateVars.OppHide)}>
                                             ${safe(context.Opp_Desc)} – <a href=${context.extSystemsUrls.harmony}
                                                style="color:#0070C0;">${safe(context.opportunityId)}</a></span><br><br>
                                             <strong>Profit Center: </strong>
                                             ${context.selectedProfitCenter[0].Desc}<br><br>
                                             <strong>Role: </strong>
                                             ${context.aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.SelectedRoleDesc}<br><br>
                                             <strong>Solution Area: </strong>
                                             ${safe(context.EmailTemplateVars?.Solution_Area)}<br><br>
                                             <strong>Industry: </strong>
                                             ${safe(context.EmailTemplateVars?.BA_Industry)}<br><br>
                                             <strong>Group: </strong> ${safe(context.EmailTemplateVars?.Group)}<br><br>
                                             <strong>Support Type: </strong>
                                             ${safe(context.EmailTemplateVars?.supportType)}
                                             <div style="line-height: 20px; font-size: 1px;">&nbsp;</div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td valign="bottom" style="padding-right: 5px;">
                                             <table width="100%" cellpadding="0" cellspacing="0" border="0">
                                                <tr>
                                                   <td align="center" bgcolor="#4DA3F5" height="45" style="height: 45px; vertical-align: middle;">
                                                      <a href="${context.extSystemsUrls.EmailWorklistURL}${context.WfID_PresalesRequestApproval}"
                                                         style="display: block; width: 100%; line-height: 45px; font-family: Arial, sans-serif; font-size: 12pt; color: #ffffff; text-decoration: none; font-weight: bold;">
                                                      View Request
                                                      </a>
                                                   </td>
                                                </tr>
                                             </table>
                                          </td>
                                       </tr>
                                    </table>
                                 </td>
                              </tr>
                              <tr>
                                 <td height="15"></td>
                              </tr>
                           </table>
                        </td>
                     </tr>
                  </table>
               </tbody>
            </table>
         </div>
         <div class="section-title">Team</div>
         <div class="divider"></div>
         <table>
            <tr>
               <td class="label">Account Owner</td>
               <td class="value"><a
                  href="https://people.wdf.sap.corp/profiles/${context.accOwnerDetails.id}#?profile_tab=organization">${context.accOwnerDetails.fullName}</a>
               </td>
            </tr>
            <tr>
               <td class="label">Opp Owner</td>
               <td class="value"><a
                  href="https://people.wdf.sap.corp/profiles/${context.oppOwnerDetails.id}#?profile_tab=organization">${safe(context.oppOwnerDetails?.fullName)}</a>
               </td>
            </tr>
            <tr>
               <td class="label">Requestor</td>
               <td class="value">
                  <a
                     href="https://people.wdf.sap.corp/profiles/${context.requesterDetails.id}#?profile_tab=organization">${context.requesterDetails.fullName}</a><br>
                  <ul style="list-style-type: square;">
                     <li><span style="font-family:Calibri">Requestor Need:
                        ${safe(context.EmailTemplateVars?.Requestor_need)}
                     </li>
                  </ul>
               </td>
            </tr>
            <tr>
               <td class="label">Processors</td>
               <td class="value">
                  <a class=${context.approverurl[0].class}
                     href="https://people.wdf.sap.corp/profiles/${safe(context.approverurl?.[0]?.userId)}#?profile_tab=organization"
                     target="_blank" rel="noopener noreferrer"
                     data-auth="NotApplicable" data-linkindex="1">
                  ${safe(context.approverurl?.[0]?.fullName)}
                  </a>${safe(context.approverurl?.[0]?.Separator)} 
                  <a class=${context.approverurl[1].class}
                     href="https://people.wdf.sap.corp/profiles/${safe(context.approverurl?.[1]?.userId)}#?profile_tab=organization"
                     target="_blank" rel="noopener noreferrer"
                     data-auth="NotApplicable" data-linkindex="1">
                  ${safe(context.approverurl?.[1]?.fullName)}
                  </a>${safe(context.approverurl?.[1]?.Separator)} 
                  <a class=${context.approverurl[2].class}
                     href="https://people.wdf.sap.corp/profiles/${safe(context.approverurl?.[2]?.userId)}#?profile_tab=organization"
                     target="_blank" rel="noopener noreferrer"
                     data-auth="NotApplicable" data-linkindex="1">
                  ${safe(context.approverurl?.[2]?.fullName)} 
                  </a>${safe(context.approverurl?.[2]?.Separator)}
                  <a class=${context.approverurl[3].class}
                     href="https://people.wdf.sap.corp/profiles/${safe(context.approverurl?.[3]?.userId)}#?profile_tab=organization"
                     target="_blank" rel="noopener noreferrer"
                     data-auth="NotApplicable" data-linkindex="1">
                  ${safe(context.approverurl?.[3]?.fullName)} 
                  </a>${safe(context.approverurl?.[3]?.Separator)}
                  <a class=${context.approverurl[4].class}
                     href="https://people.wdf.sap.corp/profiles/${safe(context.approverurl?.[4]?.userId)}#?profile_tab=organization"
                     target="_blank" rel="noopener noreferrer"
                     data-auth="NotApplicable" data-linkindex="1">
                  ${safe(context.approverurl?.[4]?.fullName)}
                  </a>${safe(context.approverurl?.[4]?.Separator)} 
                  <a class=${context.approverurl[5].class}
                     href="https://people.wdf.sap.corp/profiles/${safe(context.approverurl?.[5]?.userId)}#?profile_tab=organization"
                     target="_blank" rel="noopener noreferrer"
                     data-auth="NotApplicable" data-linkindex="1">
                  ${safe(context.approverurl?.[5]?.fullName)}
                  </a>${safe(context.approverurl?.[5]?.Separator)} 
                  <a class=${context.approverurl[6].class}
                     href="https://people.wdf.sap.corp/profiles/${safe(context.approverurl?.[6]?.userId)}#?profile_tab=organization"
                     target="_blank" rel="noopener noreferrer"
                     data-auth="NotApplicable" data-linkindex="1">
                  ${safe(context.approverurl?.[6]?.fullName)}
                  </a>${safe(context.approverurl?.[6]?.Separator)} 
                  <a class=${context.approverurl[7].class}
                     href="https://people.wdf.sap.corp/profiles/${safe(context.approverurl?.[7]?.userId)}#?profile_tab=organization"
                     target="_blank" rel="noopener noreferrer"
                     data-auth="NotApplicable" data-linkindex="1">
                  ${safe(context.approverurl?.[7]?.fullName)} 
                  </a>${safe(context.approverurl?.[7]?.Separator)}
                  <a class=${context.approverurl[8].class}
                     href="https://people.wdf.sap.corp/profiles/${safe(context.approverurl?.[8]?.userId)}#?profile_tab=organization"
                     target="_blank" rel="noopener noreferrer"
                     data-auth="NotApplicable" data-linkindex="1">
                  ${safe(context.approverurl?.[8]?.fullName)} 
                  </a>${safe(context.approverurl?.[8]?.Separator)}
                  <a class=${context.approverurl[9].class}
                     href="https://people.wdf.sap.corp/profiles/${safe(context.approverurl?.[9]?.userId)}#?profile_tab=organization"
                     target="_blank" rel="noopener noreferrer"
                     data-auth="NotApplicable" data-linkindex="1">
                  ${safe(context.approverurl?.[9]?.fullName)}
                  </a>${safe(context.approverurl?.[9]?.Separator)} 
                  <a class=${context.approverurl[10].class}
                     href="https://people.wdf.sap.corp/profiles/${safe(context.approverurl?.[10]?.userId)}#?profile_tab=organization"
                     target="_blank" rel="noopener noreferrer"
                     data-auth="NotApplicable" data-linkindex="1">
                  ${safe(context.approverurl?.[10]?.fullName)}
                  </a>${safe(context.approverurl?.[10]?.Separator)} 
                  <a class=${context.approverurl[11].class}
                     href="https://people.wdf.sap.corp/profiles/${safe(context.approverurl?.[11]?.userId)}#?profile_tab=organization"
                     target="_blank" rel="noopener noreferrer"
                     data-auth="NotApplicable" data-linkindex="1">
                  ${safe(context.approverurl?.[11]?.fullName)}
                  </a>${safe(context.approverurl?.[11]?.Separator)} 
                  <a class=${context.approverurl[12].class}
                     href="https://people.wdf.sap.corp/profiles/${safe(context.approverurl?.[12]?.userId)}#?profile_tab=organization"
                     target="_blank" rel="noopener noreferrer"
                     data-auth="NotApplicable" data-linkindex="1">
                  ${safe(context.approverurl?.[12]?.fullName)}
                  </a>${safe(context.approverurl?.[12]?.Separator)} 
                  <a class=${context.approverurl[13].class}
                     href="https://people.wdf.sap.corp/profiles/${safe(context.approverurl?.[13]?.userId)}#?profile_tab=organization"
                     target="_blank" rel="noopener noreferrer"
                     data-auth="NotApplicable" data-linkindex="1">
                  ${safe(context.approverurl?.[13]?.fullName)} 
                  </a>${safe(context.approverurl?.[13]?.Separator)}
                  <a class=${context.approverurl[14].class}
                     href="https://people.wdf.sap.corp/profiles/${safe(context.approverurl?.[14]?.userId)}#?profile_tab=organization"
                     target="_blank" rel="noopener noreferrer"
                     data-auth="NotApplicable" data-linkindex="1">
                  ${safe(context.approverurl?.[14]?.fullName)}
                  </a>${safe(context.approverurl?.[14]?.Separator)} 
                  <a class=${context.approverurl[15].class}
                     href="https://people.wdf.sap.corp/profiles/${safe(context.approverurl?.[15]?.userId)}#?profile_tab=organization"
                     target="_blank" rel="noopener noreferrer"
                     data-auth="NotApplicable" data-linkindex="1">
                  ${safe(context.approverurl?.[15]?.fullName)}
                  </a>${safe(context.approverurl?.[15]?.Separator)} 
               </td>
            </tr>
         </table>
         <div class="section-title">Request Details</div>
         <div class="divider"></div>
         <table>
            <tr>
               <td class="label">Account Name - ID</td>
               <td class="value">
                  ${context.accountName} – <a href=${context.extSystemsUrls.AccountURL}>${context.accountId}</a>
               </td>
            </tr>
             <tr>
                <td width="25%" class="label">IAC</td>
                <td width="75%" class="value"> ${context.aResourceProfileApprovers.IAC[0].IAC_Desc} </td>
            </tr>
            <tr>
               <td class="label">Opp Desc - ID</td>
               <td class="value">
                  <span class=${safe(context.EmailTemplateVars.OppHide)}>${safe(context.Opp_Desc)} – <a href=${context.extSystemsUrls.harmony}>${safe(context.opportunityId)}</a></span>
               </td>
            </tr>
            <tr>
               <td class="label">Opp Sales Org</td>
               <td class="value">${safe(context.Opp_SalesOrg_Name)}</td>
            </tr>
            <tr>
               <td class="label">Opp Sales Office</td>
               <td class="value">${safe(context.Opp_Sales_Office)}</td>
            </tr>
            <tr>
               <td class="label">Opp Sales Group</td>
               <td class="value">${safe(context.Opp_SalesGroupName)}</td>
            </tr>
            <tr>
               <td class="label">Opp Partner (Channel)</td>
               <td class="value">${safe(context.Opp_Partner)}</td>
            </tr>
            <tr>
               <td class="label">Opp Close Date</td>
               <td class="value">${safe(context.NewOppDetails?.CLOSE_DATE)}</td>
            </tr>
            <tr>
               <td class="label">Opp Phase</td>
               <td class="value">${safe(context.NewOppDetails?.CURR_PHASE_DESC)}</td>
            </tr>
            <tr>
               <td class="label">Opp Status</td>
               <td class="value">${safe(context.NewOppDetails?.STATUS_DESC)}</td>
            </tr>
         </table>
         <br>
         <table class="history-table">
            <tr>
               <td width="468" valign="top" style="width:351.0pt; padding:0in 0in 0in 0in">
                  <table class="x_MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="468"
                     style="width:351.0pt">
                     <tbody>
                        <tr>
                           <td width="312" valign="top" style="width:3.25in; padding:0in 0in 0in 0in">
                              <p class="x_MsoNormal" style="line-height:20.0pt"><span
                                 style="font-size:10.0pt; font-family:&quot;Arial&quot;,sans-serif; color:#666564">Best
                                 regards,<br><span
                                    style="font-size:12pt; font-family:&quot;Arial&quot;,sans-serif; color:black">Global
                                 Customer Advisory Operations </span>
                                 </span>
                              </p>
                           </td>
                        </tr>
                        <tr>
                           <td width="156" valign="top" style="width:117.0pt; padding:0in 0in 0in 0in">
                              <p class="x_MsoNormal" align="left" style="text-align:left"><span
                                 style="font-family:&quot;Arial&quot;,sans-serif"><img
                                 data-imagetype="External"
                                 src="http://lsftdc00.tdc.only.sap:8000/sap/bc/bsp/sap/yutlt_img_src/MELODY/Activity/Melody%20Request%20Footer%20Image.png"
                                 border="0" width="250" height="50" id="x__x0000_i1025"
                                 alt="Border" "></span>
                                 <span
                                    style="
                                    font-family:&quot;Arial&quot;,sans-serif"></span>
                              </p>
                              <p class="x_MsoNormal" style="line-height:20.0pt"><span
                                 style="font-size:8.0pt; font-family:&quot;Arial&quot;,sans-serif; color:#666564">This
                                 mail is automatically generated. Please do not reply to this mail.<br>
                                 </span>
                              </p>
                           </td>
                        </tr>
                     </tbody>
                  </table>
               </td>
            </tr>
            <tr>
               <td style="padding:7.5pt 0in 15.0pt 0in">
                  <div style="border:none; border-top:solid black 1.0pt; padding:0in 0in 0in 0in">
                     <div style="margin-top:7.5pt; margin-bottom:18.75pt">
                        <p class="x_MsoNormal" align="right" style="text-align:right"><span
                           style="font-size:7.5pt; font-family:&quot;Arial&quot;,sans-serif; color:#9DA2A9">
                           <a href="http://www.sap.com/company/legal/copyright/index.aspx" target="_blank"
                              rel="noopener noreferrer" data-auth="NotApplicable" data-linkindex="6"><span
                              style="color:#9DA2A9; text-decoration:none">Copyright/Trademark</span></a>
                           &nbsp;|&nbsp; <a href="http://www.sap.com/company/legal/privacy.aspx"
                              target="_blank" rel="noopener noreferrer" data-auth="NotApplicable"
                              data-linkindex="6"><span
                              style="color:#9DA2A9; text-decoration:none">Privacy</span></a>&nbsp;|&nbsp;<a
                              href="http://www.sap.com/company/legal/impressum.aspx" target="_blank"
                              rel="noopener noreferrer" data-auth="NotApplicable" data-linkindex="7"><span
                              style="color:#9DA2A9; text-decoration:none">Impressum</span></a></span>
                           <span style="font-family:&quot;Arial&quot;,sans-serif"></span>
                        </p>
                     </div>
                     <p class="x_MsoNormal"><span
                        style="font-size:7.5pt; font-family:&quot;Arial&quot;,sans-serif; color:#9DA2A9">SAP SE,
                        Dietmar-Hopp-Allee 16, 69190 Walldorf, Germany <br><br>Pflichtangaben/Mandatory
                        Disclosure Statements: <a href="solutionexperience@sap.com" target="_blank"
                           rel="noopener noreferrer" data-auth="NotApplicable" data-linkindex="8"><span
                           style="color:black; text-decoration:none">http://www.sap.com/company/legal/impressum.html</span></a>
                        <br>Diese E-Mail kann Betriebs- oder Gesch�ftsgeheimnisse oder sonstige vertrauliche
                        Informationen enthalten.
                        Sollten Sie diese E-Mail irrt�mlich erhalten haben, ist Ihnen eine Kenntnisnahme des
                        Inhalts, eine Vervielf�ltigung oder Weitergabe der E-Mail ausdr�cklich untersagt.
                        Bitte benachrichtigen Sie uns und vernichten Sie die empfangene E-Mail. Vielen Dank.
                        <br>
                     <p class="x_MsoNormal"><span
                        style="font-size:7.5pt; font-family:&quot;Arial&quot;,sans-serif; color:#9DA2A9">This
                        e-mail may contain trade secrets or privileged, undisclosed, or otherwise
                        confidential information.
                        If you have received this e-mail in error, you are hereby notified that any
                        review, copying, or distribution of it is strictly prohibited. Please inform us
                        immediately and destroy the original transmittal.
                        Thank you for your cooperation.</span>
                     </p>
                     </p>
                  </div>
               </td>
            </tr>
         </table>
      </div>
   </body>
</html>`