
module.exports = cds.service.impl(async function () {
  const cds = require("@sap/cds");
  const SequenceHelper = require("./SequenceHelper");
  const db = await cds.connect.to("db");
  var id = [];
  this.on('getId', async(req) => {
    const productId = new SequenceHelper({
        db: db,
        sequence: "REFRENCE_ID",
        table: "APP_WF_YMRR_WFINSTANCE",
        field: "REFID"
    });
 id = await productId.getNextNumber();
 return id;
  });
  
});