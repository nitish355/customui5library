using app.activity from '../db/activity';
using app.wf from '../db/wf';

service Activity_Service @(requires: 'system-user') {

type ActivityLists : {
        INSTANCE_GUID : String(64);
        AssignmentID  : String(4);
    }
    entity MR_T_Activity @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }]) as projection on activity.YMR_DF_ACTIVITY;

    entity MR_Activity_Details @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }]) as projection on activity.YC_MR_T_Act_Main;

    entity V_WfInstance_Act @(restrict: [{
    grant: ['READ'],
    to   : 'system-user'
  }]) as projection on wf.YC_WfInstanceExt;

entity V_MR_CURNTQTR_DTLS @(restrict: [{
    grant: ['READ'],
    to   : 'system-user'
  }]) as projection on wf.YC_MR_T_CURNTQTR_DTLS_PERC;

entity User_Notif @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }])                         as projection on wf.YMR_T_User_Notif;
    action deleteActivtyList(
        ActivityListsData : array of ActivityLists
    ) returns Boolean;

}


