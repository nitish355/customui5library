service RefrenceId@(path : '/Refrence_Id' )
{
    function getId() returns String;
}