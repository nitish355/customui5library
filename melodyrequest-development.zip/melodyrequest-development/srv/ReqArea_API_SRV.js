const { getDestination } = require('@sap-cloud-sdk/connectivity');
//const { and, or } = require('@sap-cloud-sdk/core');
const { executeHttpRequest } = require('@sap-cloud-sdk/http-client');
module.exports = cds.service.impl(async function () {
    this.on('CRM_Req_Dtls', async (req) => {
        const { OpportunityId, salesOrgId } = req.data;
        try {
            const destination = await getDestination({
                destinationName: 'ext_CPI_Neo'
            });
            const [wfCounts, properties] = await Promise.all([SELECT.one.from('APP_WF_YC_WFINSTANCEEXT')
                .columns([
                    `count( case when ENGAGEMENTTYPEID = '0002' then 1 end ) as FBSCount`,
                    `count( case when ENGAGEMENTTYPEID = '0001' then 1 end ) as CACount`
                ])
                .where({
                    OpportunityID: OpportunityId,
                    WorkflowDefinitionID: '2'
                }),

            SELECT.from('APP_REQAREA_API_YMR_T_CRM_REQ_DTLS').columns(
                'PROPERTYNAME as propertyName',
                'SEQUENCE as sequence'
            ).orderBy('sequence'),
            ]);

            if (!properties.length) {
                return {
                    OpportunityId,
                    SalesOrgId: salesOrgId,
                    Property: []
                };
            }

            const payload = {
                Request: {
                    "opportunityId": OpportunityId,
                    "requestIntent": "GET_DATA"
                }
            };
            const response = await executeHttpRequest(destination, {

                method: 'POST',
                url: '/http/presales/cp-workflow-req',
                headers: {
                    "Content-Type": "application/json"
                },
                data: payload.Request
            },
                {
                    fetchCsrfToken: false
                });
            const opportunityStatus = response.data?.d?.STATUS || null;
            const errorFlag = String(response.data?.d?.ERROR || '').trim();
            const sGroup = String(response.data?.d?.SALES_GROUP_SHORT || '*');
            const sOffice = String(response.data?.d?.SALES_OFFICE_SHORT || '*');
            let MROppStatus = null;
            let configuredErrorFlags = null;
            let isErrorFlagCheckActive = false;
            if (opportunityStatus !== null) {
               const [oppStatusConfig, errorFlagConfig] = await Promise.all([
                    SELECT.one.from('APP_REQAREA_API_V_PARAMETER').where({
                        Type_desc: 'OpportunityStatus',
                        Value: opportunityStatus
                    }),
                    SELECT.one.from('APP_REQAREA_API_V_PARAMETER').where({
                        Type_desc: 'Opp_Error_Flag'
                    })
                ]);

                MROppStatus = oppStatusConfig;
                if ( errorFlagConfig && errorFlagConfig.OPERATIONAL_STATUS == 'X') {
                    configuredErrorFlags = String(errorFlagConfig.VALUE || '').trim();
                    isErrorFlagCheckActive = true;
                }
            }
            let salesOrgStatus = null;
            if (MROppStatus !== null && MROppStatus.OPERATIONAL_STATUS == 'X' && ( !isErrorFlagCheckActive || errorFlag !== configuredErrorFlags ) ) {
                salesOrgStatus = await SELECT.one.from('APP_REQAREA_API_V_SALESORG')
                    .columns([
                        `max(case when ENGAGEMENTTYPE = '0002' then coalesce(IS_ACTIVE, '') end) as FBSActive`,
                        `max(case when ENGAGEMENTTYPE = '0001' then coalesce(IS_ACTIVE, '') end) as CAActive`

                    ])
                    .where([
                        { ref: ['Sales_org_ID'] }, '=', { val: salesOrgId },
                        'and',
                        '(',
                        '(',
                        { ref: ['sales_group'] }, '=', { val: sGroup },
                        'and',
                        { ref: ['sales_office'] }, '=', { val: sOffice },
                        ')',
                        'or',
                        '(',
                        { ref: ['sales_group'] }, '=', { val: sGroup },
                        'and',
                        { ref: ['sales_office'] }, '=', { val: '*' },
                        ')',
                        'or',
                        '(',
                        { ref: ['sales_group'] }, '=', { val: '*' },
                        'and',
                        { ref: ['sales_office'] }, '=', { val: sOffice },
                        ')',
                        'or',
                        '(',
                        { ref: ['sales_group'] }, '=', { val: '*' },
                        'and',
                        { ref: ['sales_office'] }, '=', { val: '*' },
                        ')',
                        ')'
                    ]);

            }
            const valueMap = {
                FBSCount: wfCounts?.FBSCount || 0,
                CACount: wfCounts?.CACount || 0,
                FBSActive: salesOrgStatus?.FBSActive ?? '',
                CAActive: salesOrgStatus?.CAActive ?? ''
            };

            const result = properties.map(function (prop) {
                return {
                    PropertyName: prop.propertyName,
                    Value: String(valueMap[prop.propertyName] ?? '')
                };
            });

            return {
                OpportunityId: OpportunityId,
                SalesOrgId: salesOrgId,
                Property: result
            };

        }
        catch (error) {
            return req.error({
                code: 500,
                message: `CRM_Req_Dtls failed: ${error?.response?.data || error.message}`
            });
        }

    });
});
