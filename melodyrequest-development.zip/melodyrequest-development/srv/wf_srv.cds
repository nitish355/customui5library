using app.wf from '../db/wf';

/*
service WfService @(requires : 'system-user') {
  entity WfInstance as projection on wf.WfInstance;
  entity WIRoleAssigned as projection on wf.WIRoleAssigned;
}
*/

service WfService @(requires: 'authenticated-user') {
  // entity WfInstance @(restrict: [{
  //   grant: ['*'],
  //   to   : 'system-user'
  // }]) as projection on wf.WfInstance;

type AdditionalSolnInput : {
    InstanceID: UUID;
    solution_guid : String(64);
    is_MainSoln   : String(1);
}

type UserVariant         : {
    variantGuid : UUID;
    isDefault   : String(1);
  }
type SolMtrlInput : {
    InstanceID: UUID;
    MAT_ID   : String(40);
    SOL_YEAR : String(4);
}

type UserInfo {
  userId : String;
  email  : String;
}

type UsersByRole {
    requester    : array of UserInfo;
    processor    : array of UserInfo;
    substitute   : array of UserInfo;
    resource     : array of UserInfo;
    oldProssOrDirectMgr : array of UserInfo;
    reqTypeOwner : array of UserInfo;
    newProcessor : array of UserInfo;
    ExistingProcessor : array of UserInfo;
  }
entity WfInstance @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.YMRR_WfInstance;

entity WfInstanceExt @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.YMR_T_Wfinstance_Ext;
  entity WFInsParent @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.YMRR_WFIns_Parent;
  
   entity Account @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.YMRR_Account;

  entity SalesGroup2Emp @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.SalesGroup2Emp;


entity V_WfInstance_Inbox @(restrict: [{
    grant: ['READ'],
    to   : 'MelodyRequestEndUser'
  } 
  ]) as projection on wf.YC_WfInstanceExt;
entity V_WfInstance_Ext @(restrict: [
    {
      grant: ['READ'],
      to   : 'MelodyRequestEndUser',
      where: '(EmpRequester_ID LIKE (''%''||$user||''%'')) or (ReqApproverID LIKE (''%''||$user||''%'')) or (ReqResourcesID LIKE (''%''||$user||''%'')) or (ReqIOApproverID LIKE (''%''||$user||''%'')) or (CurrentProcessorID LIKE (''%''||$user||''%''))'
       
    },
    // Authroizations for Super Admin (Access for all Sales Org)
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdmin'
    },
    // Authorization for Sales Org Germany
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminGermany',
      where: 'orgID = `23` and orgType = `SORG`'
      
    },
    // Authorization for MU Admin Switzerland
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminSwitzerland',
      where: 'orgID = `2` and orgType = `SORG`'
      
    },
    // Authorization for MU Admin Austria
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminAustria',
      where: 'orgID = `3` and orgType = `SORG`'
    },
    // Authorization for MU Admin Spain
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminSpain',
      where: 'orgID = `6` and orgType = `SORG`'
    },
    // Authorization for MU Admin India (APJ)
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminIndia',
      where: 'orgID = `71` and orgType = `SORG`'
    },
    // Authorization for MU Admin Turkiye
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminTurkiye',
      where: 'orgID = `256` and orgType = `SORG`'
    },
    // Authorization for MU Admin CR
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminCR',
      where: 'orgID = `40` and orgType = `SORG`'
    },
    // Authorization for MU Admin Poland
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminPoland',
      where: 'orgID = `44` and orgType = `SORG`'
    },
    // Authorization for MU Admin Hungary
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminHungary',
      where: 'orgID = `48` and orgType = `SORG`'
    },
    // Authorization for MU Admin Romania
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminRomania',
      where: 'orgID = `81` and orgType = `SORG`'
    },
    // Authorization for MU Admin Bulgaria
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminBulgaria',
      where: 'orgID = `216` and orgType = `SORG`'
    },
    // Authorization for MU Admin Ukraine
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminUkraine',
      where: 'orgID = `218` and orgType = `SORG`'
    },
    // Authorization for PC Admin CsCanada
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminCsCanada',
      where: 'orgID = `00505619-15d5-1edc-a8a6-a9c517ae0122` and orgType = `PC`'
    },
    // Authorization for PC Admin CsMidwest
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminCsMidwest',
      where: 'orgID = `00505619-15d5-1edc-a8a6-a9c517ae6122` and orgType = `PC`'
    },
    // Authorization for PC Admin CsNortheast
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminCsNortheast',
      where: 'orgID = `00505619-15d5-1edc-a8a6-a9c517aea122` and orgType = `PC`'
    },
    // Authorization for PC Admin CsRegulated
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminCsRegulated',
      where: 'orgID = `00505619-15d5-1edc-a8a6-a9c517ae2122` and orgType = `PC`'
    },
    // Authorization for PC Admin CsSouth
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminCsSouth',
      where: 'orgID = `00505619-15d5-1edc-a8a6-a9c517ae8122` and orgType = `PC`'
    },
    // Authorization for PC Admin CsWest
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminCsWest',
      where: 'orgID = `00505619-15d5-1edc-a8a6-a9c517ae4122` and orgType = `PC`'
    },
    // Authorization for PC Admin CsNorthAmerica
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminCsNorthAmerica',
      where: 'orgID = `00505619-15d5-1edc-a8a6-a9c517ade122` and orgType = `PC`'
    }, 
    // Authorization for MU Admin Kasachstan
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminKasachstan',
      where: 'orgID = `245` and orgType = `SORG`'
    },
    // Authorization for MU Admin Balkans
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminWestBalkans',
      where: 'orgID = `269` and orgType = `SORG`'
    },
    // Authorization for MU Admin Slovenia
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminSlovenia',
      where: 'orgID = `280` and orgType = `SORG`'
    },
    // Authorization for MU Admin Slovensko
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminSlovensko',
      where: 'orgID = `319` and orgType = `SORG`'
    },
    // Authorization for MU Admin Azerbaijan
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminAzerbaijan',
      where: 'orgID = `392` and orgType = `SORG`'
    },
    // Authorization for MU Admin Hrvatska
    {
      grant: ['READ'],
      to   : 'MelodyRequestResourceAdminHrvatska',
      where: 'orgID = `443` and orgType = `SORG`'
    }


  ])  as projection on wf.YC_WfInstanceExt;

  entity WfInstanceAssignment @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.WfInstanceAssignment;

  entity V_WfInstanceAssignment @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.YC_WfInstanceAssignment;

  entity WfInsProcessor @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.YMRR_WfInsProcessor;

    //service for WF History
  entity WFHistory @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.YMRR_ReqHistory;

entity ResProfileSel_Header @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.YMRR_ResProfileSel_Header;
 
    entity ResProfileSel_BALOB @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.YMRR_ResProfileSel_BALOB;
 
    entity ResProfileSel_CrossCvrg @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.YMRR_ResProfileSel_CrossCvrg;
 
    entity ResProfileSel_HubLOB @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.YMRR_ResProfileSel_HubLOB;
  
  entity ResProfileSel_SolutionAreas @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.YMRR_ResProfileSel_SolArea;
 
    entity ResProfileSel_BAIndustry @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.YMRR_ResProfileSel_BAIndustry;


// Services for Submit Request Form
  entity ReqForm_SupportType @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.YMRR_ReqForm_SupportType;

  entity ReqForm_PartcpType @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.YMRR_ReqForm_PartcpType;

  entity ReqForm_Language @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.YMRR_ReqForm_Language;

  entity ReqForm_InvSAP_Party @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.YMRR_ReqForm_InvSAP_Party;
   entity ReqForm_URL @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.YMRR_WfinsURL;
entity Comments @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.YMR_Comment;
entity ActionHistory @(restrict: [{
    grant: ['READ'],
    to   : 'MelodyRequestEndUser'
  } 
  ]) as projection on wf.YC_history;
entity YC_MR_T_Comment @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }]) as projection on wf.YC_MR_T_Comment;

entity Yc_MR_Variant        as projection on wf.YC_MR_Variant;

entity Yc_MR_ManagedVariant as projection on wf.YC_MR_ManagedVariant;

  entity Variant @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }])                         as projection on wf.YMR_Variant;
  
entity YC_MR_T_WfHistory @(restrict: [{
    grant: ['*'],
    to   : 'system-user'
  }])                         as projection on wf.YC_MR_T_WfHistory;

action GetUserNotificationSettings(users: UsersByRole,
                                     notif_Id: String(4),
                                     notifVal_Id: String(4))       returns UsersByRole;

action saveSolutionMatrlData(
        InstanceID: UUID,
        additionalSolns: array of AdditionalSolnInput, 
        solMtrlList: array of SolMtrlInput
) returns Boolean;

action SaveUserVariantData(userId: String(12),
                             VariantDetails: array of UserVariant) returns Boolean;

action UserCommentUpdate(
     context : LargeString
  ) returns String;

}
