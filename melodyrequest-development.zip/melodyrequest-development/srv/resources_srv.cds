using app.resources from '../db/resources';
using app.ReqArea_API from '../db/ReqArea_API';


service ResourcesService {
    //To use in Value Help functionality
    //    entity SRV_Sales_Org  @(restrict : [{ to : 'system-user' }]) as projection on resources.Sales_Org;
    entity SRV_Sales_Org   as projection on resources.Sales_Org;
    entity UpdateResources @(restrict: [
        {
        grant: ['UPDATE'],
        to   : [
            'MelodyRequestResourceAdmin',
            'MelodyRequestResourceAdminGermany',
            'MelodyRequestResourceAdminSwitzerland',
            'MelodyRequestResourceAdminAustria',
            'MelodyRequestResourceAdminIndia',
            'MelodyRequestResourceAdminSpain',
            'MelodyRequestResourceAdminTurkiye',
            'MelodyRequestResourceAdminCR',
            'MelodyRequestResourceAdminPoland',
            'MelodyRequestResourceAdminHungary',
            'MelodyRequestResourceAdminRomania',
            'MelodyRequestResourceAdminBulgaria',
            'MelodyRequestResourceAdminUkraine',
            'MelodyRequestResourceAdminKasachstan',
            'MelodyRequestResourceAdminWestBalkans',
            'MelodyRequestResourceAdminSlovenia',
            'MelodyRequestResourceAdminSlovensko',
            'MelodyRequestResourceAdminAzerbaijan',
            'MelodyRequestResourceAdminHrvatska',
            'MelodyRequestResourceAdminCsCanada',
            'MelodyRequestResourceAdminCsMidwest',
            'MelodyRequestResourceAdminCsNortheast',
            'MelodyRequestResourceAdminCsRegulated',
            'MelodyRequestResourceAdminCsSouth',
            'MelodyRequestResourceAdminCsWest',
            'MelodyRequestResourceAdminCsNorthAmerica'
        ]
    }
            ]) as projection on resources.Resources; 
    entity AdminResources @(restrict: [
        {
            grant: ['*'],
            to   : 'MelodyRequestResourceAdmin'
        },
        //Authorization for MU Admin Germany
        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminGermany'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminGermany',
            where: '(orgID = `23` and orgType = `SORG`) or (orgID = `23` and orgType = `MUID`)'
        },
        // Authorization for MU Admin Switzerland
        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminSwitzerland'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminSwitzerland',
            where: 'orgID = `2` and orgType = `SORG`'
        },
        // Authorization for MU Admin Austria
        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminAustria'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminAustria',
            where: 'orgID = `3` and orgType = `SORG`'
        },
        // Authorization for MU Admin India (APJ)
        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminIndia'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminIndia',
            where: 'orgID = `71` and orgType = `SORG`'
        },

        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminSpain'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminSpain',
            where: 'orgID = `6` and orgType = `SORG`'
        },
        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminTurkiye'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminTurkiye', 
            where: 'orgID = `256` and orgType = `SORG`'
        },
        
        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminCR'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminCR',
            where: 'orgID = `40` and orgType = `SORG`'
        },

        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminPoland'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminPoland',
            where: 'orgID = `44` and orgType = `SORG`'
        },

        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminHungary'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminHungary',
            where: 'orgID = `48` and orgType = `SORG`'
           
        },

        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminRomania'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminRomania',
             where: 'orgID = `81` and orgType = `SORG`'
        },
        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminBulgaria'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminBulgaria',
            where: 'orgID = `216` and orgType = `SORG`'
        },
        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminUkraine'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminUkraine',
            where: 'orgID = `218` and orgType = `SORG`'
          
        },

        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminKasachstan'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminKasachstan',
            where: 'orgID = `245` and orgType = `SORG`'
            },

        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminWestBalkans'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminWestBalkans',
            where: 'orgID = `269` and orgType = `SORG`'
        },

        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminSlovenia'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminSlovenia',
            where: 'orgID = `280` and orgType = `SORG`'
           
        },

        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminSlovensko'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminSlovensko',
            where: 'orgID = `319` and orgType = `SORG`'
        },

        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminAzerbaijan'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminAzerbaijan',
            where: 'orgID = `392` and orgType = `SORG`'
        },

        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminHrvatska'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminHrvatska',
            where: 'orgID = `443` and orgType = `SORG`'
        },
        //role for profit centre
        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminCsCanada'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminCsCanada',
            where: 'orgID = `00505619-15d5-1edc-a8a6-a9c517ae0122` and orgType = `PC`'
        },
        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminCsMidwest'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminCsMidwest',
            where: 'orgID = `00505619-15d5-1edc-a8a6-a9c517ae6122` and orgType = `PC`'
        },
        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminCsNortheast'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminCsNortheast',
            where: 'orgID = `00505619-15d5-1edc-a8a6-a9c517aea122` and orgType = `PC`'
        },
        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminCsRegulated'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminCsRegulated',
            where: 'orgID = `00505619-15d5-1edc-a8a6-a9c517ae2122` and orgType = `PC`'
        },
        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminCsSouth'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminCsSouth',
            where: 'orgID = `00505619-15d5-1edc-a8a6-a9c517ae8122` and orgType = `PC`'
        },
        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminCsWest'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminCsWest',
            where: 'orgID = `00505619-15d5-1edc-a8a6-a9c517ae4122` and orgType = `PC`'
        },
        {
            grant: [
                'WRITE',
                'UPDATE',
                'DELETE'
            ],
            to   : 'MelodyRequestResourceAdminCsNorthAmerica'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceAdminCsNorthAmerica',
            where: 'orgID = `00505619-15d5-1edc-a8a6-a9c517ade122` and orgType = `PC`'
        }
    ])  
                        as projection on resources.Yc_Resources;

    entity Resources @(restrict: [
        {
            grant: ['*'],
            to   : 'system-user'
        },
        {
            grant: ['WRITE'],
            to   : 'MelodyRequestResourceApprover'
        },
        {
            grant: ['READ'],
            to   : 'MelodyRequestResourceApprover',
            where: 'Approvers LIKE (''%''||$user||''%'')'
        }
    ])                     as projection on resources.Yc_Resources;

    //Service Entity to use in the Workflow
    entity Email_Body @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])                  as projection on resources.Email_Body;

    //service for email delegates
    entity Email_Delegates @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])                  as projection on ReqArea_API.V_Email_Delegates;

    //service for Workflow Routing
    entity WF_Routing @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])                  as projection on ReqArea_API.V_WF_Routing;

    entity IOStaffException @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])                  as projection on ReqArea_API.YMRR_ioStaffExcep;

     entity EngagementType @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])                  as projection on ReqArea_API.YMR_M_Engagement;
    entity HaromonyRouting @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])                  as projection on resources.YMR_M_Harmony_Routing;
    
    
    //service for Current State Id
    entity CurrentState @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])                  as projection on ReqArea_API.YMRR_CurrentState;

    //service for Technical State
    entity TechnicalState @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])                  as projection on ReqArea_API.YMRR_TechnicalState;

    //service for Workflow Defination
    entity WF_Defination @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])                  as projection on ReqArea_API.YMRR_WF_Defination;

    //service for Request Type
    entity RequestType @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])  
                    as projection on ReqArea_API.YMRR_RequestType;
                    
    //service for Current Step Id
    entity CurrentStep @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])                  as projection on ReqArea_API.YMRR_CurrentStep;

    //service for Reminder to Approver
    entity RemindMail @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])                  as projection on ReqArea_API.V_RemindMail;
     //To display Approvers to Request Creater based on Request Area 
    entity ReadResources @(restrict: [{
        grant: ['READ'],
        to   : 'MelodyRequestEndUser'
    }])                  as projection on resources.Yc_Resources;

     // Service For User Task Label
    entity MR_UserTask @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])                  as projection on ReqArea_API.YMRR_UserTask;

    // Service for IAC_Role_RoleArea_Map
    entity IAC_RoleArea_Map @(restrict: [{
        grant: ['*'],
        to   : 'system-user'
    }])                  as projection on resources.YC_MRR_IAC_ACV_FieldMap;


    //entity YC_SolnMAC_M_SOL_HIER as projection on resources.YC_SolnMAC_M_SOL_HIER;
}




// UI Annotations to maintain Resources Tool
@odata.draft.enabled
annotate ResourcesService.Resources with @(UI: {
    CreateHidden    : true,
    DeleteHidden    : true,
    UpdateHidden    : false,
    HeaderInfo      : {
        TypeName      : 'Request Area',
        TypeNamePlural: 'Request Areas',
        Title         : {Value: RequestArea},
        Description   : {Value: 'User Role Management'}
    },
    SelectionFields : [
        orgID,
        orgType,
        RequestArea,
        Resources,
        Approvers,
        SubstituteApprovers
    ],
    LineItem        : [
        //{
        //    Value                  : SalesOrgID.Desc,
        //    ![@Common.FieldControl]: #ReadOnly,
        //    ![@HTML5.CssDefaults]  : {width: '8rem'}
        //},
        {
            Value                  : RequestArea,
            ![@Common.FieldControl]: #ReadOnly,
            ![@HTML5.CssDefaults]  : {width: '20rem'}
        },
        {
            Value                : Resources,
            ![@HTML5.CssDefaults]: {width: '15rem'}
        },
        {
            Value                  : Approvers,
            ![@Common.FieldControl]: #ReadOnly,
            ![@HTML5.CssDefaults]  : {width: '10rem'}
        },
        {
            Value                  : SubstituteApprovers,
            ![@Common.FieldControl]: #ReadOnly,
            ![@HTML5.CssDefaults]  : {width: '10rem'}
        }
    ],
    Facets          : [{
        $Type : 'UI.CollectionFacet',
        Label : 'Resources And Approvers List',
        Facets: [{
            $Type : 'UI.ReferenceFacet',
            Target: '@UI.FieldGroup#Main',
            Label : ''
        }]
    }],
    FieldGroup #Main: {Data: [
        {
            Label                  : 'GUID',
            Value                  : GUID,
            ![@Common.FieldControl]: #ReadOnly
        },
        {
            Label                  : 'Org ID',
            Value                  : orgID,
            ![@Common.FieldControl]: #ReadOnly
        },
        {
            Label                  : 'Org Type',
            Value                  : orgType,
            ![@Common.FieldControl]: #ReadOnly
        },
        //{
        //    Value                  : SalesOrgID.Desc,
        //    ![@Common.FieldControl]: #ReadOnly
        //},
        {
            Value                  : RequestArea,
            ![@Common.FieldControl]: #ReadOnly
        },
        {Value: Resources},
        {
            Value                  : Approvers,
            ![@Common.FieldControl]: #ReadOnly
        },
        {
            Value                  : SubstituteApprovers,
            ![@Common.FieldControl]: #ReadOnly
        }
    ]}
});

//*************************************************************//
// UI Annotations to maintain Resource Admin Tool
//@odata.draft.enabled
annotate ResourcesService.AdminResources with @(UI: {
    CreateHidden    : false,
    DeleteHidden    : false,
    UpdateHidden    : false,
    HeaderInfo      : {
        TypeName      : 'Request Area',
        TypeNamePlural: 'Request Areas',
        Title         : {Value: RequestArea},
        Description   : {Value: 'User Role Management'}
    },
    SelectionFields : [
        orgID,
        orgType,
        RequestArea,
        Resources,
        Approvers,
        SubstituteApprovers
    ],
    LineItem        : [
        {
            Value                : RequestArea,
            ![@HTML5.CssDefaults]: {width: '20rem'}
        },
        {
            Value                : Resources,
            ![@HTML5.CssDefaults]: {width: '15rem'}
        },
        {
            Value                : Approvers,
            ![@HTML5.CssDefaults]: {width: '10rem'}
        },
        {
            Value                : SubstituteApprovers,
            ![@HTML5.CssDefaults]: {width: '10rem'}
        }
    ],
    Facets          : [{
        $Type : 'UI.CollectionFacet',
        Label : 'Resources And Approvers List',
        Facets: [{
            $Type : 'UI.ReferenceFacet',
            Target: '@UI.FieldGroup#Main',
            Label : ''
        }]
    }],
    FieldGroup #Main: {Data: [
        {
            Label: 'GUID',
            Value: GUID
        },
        {
            Label: 'Org ID',
            Value: orgID
        },
        {
            Label: 'Org Type',
            Value: orgType
        },
        /* {
            Value                  : SalesOrgID.Desc,
            ![@Common.FieldControl]: #ReadOnly
        }, */
        {Value: RequestArea},
        {Value: Resources},
        {Value: Approvers},
        {Value: SubstituteApprovers}
    ]}
});

//*****************************************************//
annotate ResourcesService.Resources with {
    Resources @UI.MultiLineText;
/*
//Code for Value Help for Sales Org ID
    SalesOrgID@(
        title : 'Sales Organization',
        sap.value.list : 'fixed-values',
        Common         : {
            ValueListWithFixedValues,
            ValueList     : {
                CollectionPath : 'SRV_Sales_Org',
                Parameters     : [
                    { $Type             : 'Common.ValueListParameterInOut',
                      ValueListProperty : 'ID' ,
                      LocalDataProperty : SalesOrgID_ID },
                    { $Type             : 'Common.ValueListParameterDisplayOnly',
                      ValueListProperty : 'Desc' }
                ]
            }
        }
    ); */
};

/*
annotate ResourcesService.AdminResources with {
    Resources  @UI.MultiLineText;
    //Code for Value Help for Sales Org ID
    SalesOrgID @(
        title         : 'Sales Organization',
        sap.value.list: 'fixed-values',
        Common        : {
            ValueListWithFixedValues,
            ValueList: {
                CollectionPath: 'SRV_Sales_Org',
                Parameters    : [
                    {
                        $Type            : 'Common.ValueListParameterInOut',
                        ValueListProperty: 'ID',
                        LocalDataProperty: SalesOrgID_ID
                    },
                    {
                        $Type            : 'Common.ValueListParameterDisplayOnly',
                        ValueListProperty: 'Desc'
                    }
                ]
            }
        }
    );
}; */
