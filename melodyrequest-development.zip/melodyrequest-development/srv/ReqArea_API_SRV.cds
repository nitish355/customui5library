using app.ReqArea_API from '../db/ReqArea_API';

service ReqArea_API_Service  @(requires : 'system-user') 
{
    //Service for Request Area Master Data to be used at Harmony side
    entity Public_ReqArea  as projection on ReqArea_API.V_RequestArea;
    //Service for Sales Orgnization Master Data to be used at Harmony side
    entity Public_SOrg as projection on ReqArea_API.V_SalesOrg;
    //Service for Constant values
    entity Parameter as projection on ReqArea_API.V_Parameter;
    //Service for Rejection Codes
    entity Rejection_Codes as projection on ReqArea_API.V_RejectionCode ;
    //Service for Current State
    entity Current_State as projection on ReqArea_API.V_CurrentState ;
    //Services for Form Config 
    entity Form_Tab as projection on ReqArea_API.YC_MR_M_Form_Tab;
    entity Form_config as projection on ReqArea_API.YC_MR_M_Form_Config;
    entity Form_values as projection on ReqArea_API.YC_MR_M_FRM_CONFIG_VAL;
    //Service for Presales_role
    entity Presales_role as projection on ReqArea_API.V_Presales_Roles;
    //Service for Action button
    entity Action as projection on ReqArea_API.YC_MR_M_ACTION ;
    //Service for Role Profile
    //entity Role_Profile as projection on ReqArea_API.V_Role_Profile;
    // Service for Io number
    entity InternalOrder as projection on ReqArea_API.YMRR_internalOrder;
    
    // Service for Melody Request tab
    //entity MR_Tab as projection on ReqArea_API.YMRR_App_Tab;

    // Service for MR Language
    entity MR_Language as projection on ReqArea_API.YC_MRLangauage;
      
    // Service for Melody Request tab	
    entity MR_App_Label as projection on ReqArea_API.YC_AppLabel_Map;
    entity ActionService as projection on ReqArea_API.YC_MR_Rep_Action;
    entity RemindMailService as projection on ReqArea_API.YC_MR_Rep_RemindMail;
    entity RoutingService as projection on ReqArea_API.YC_MR_Rep_WF_Routing;
    entity IOExceptionService as projection on ReqArea_API.YC_MR_Rep_ioStaffExcep;

    function CRM_Req_Dtls(OpportunityId: String(50),
                          salesOrgId: String(4)) returns OpportunityReqDetails;

    type OpportunityReqDetails {
        OpportunityId : String(50);
        SalesOrgId    : String(4);
        Property      : many PropertyDetails;
    }

    type PropertyDetails {
        PropertyName : String(50);
        Value        : String(50);
    }

}
