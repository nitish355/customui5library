module.exports = cds.service.impl(async function () {
    // API reference
    const api = 'xsuaa_api';

    // Get the XSUAA host URL from service binding
    const xsuaa_bind = JSON.parse(process.env.VCAP_SERVICES).xsuaa[0];
    const api_def = cds.env.requires[api];
    api_def.credentials.url = xsuaa_bind.credentials.url;

    // connect to the XSUAA host
    const xsuaa = await cds.connect.to(api_def);

    // using req.user approach (user attribute - of class cds.User - from the request object)
    this.on('userInfo', req => {
        const user = {
            id: req.user.id,
            tenant: req.user.tenant,
            _roles: req.user._roles,
            attr: req.user.attr,
            isRoles: {
                isMelodyRequestResourceAdmin: req.user.is('MelodyRequestResourceAdmin'),
                isMelodyRequestResourceApprover: req.user.is('MelodyRequestResourceApprover'),
                isMelodyRequestResourceAdminGermany: req.user.is('MelodyRequestResourceAdminGermany'),
                isMelodyRequestResourceAdminSwitzerland: req.user.is('MelodyRequestResourceAdminSwitzerland'),
                isMelodyRequestResourceAdminAustria: req.user.is('MelodyRequestResourceAdminAustria'),
                isMelodyRequestResourceAdminIndia: req.user.is('MelodyRequestResourceAdminIndia'),
                isMelodyRequestResourceAdminSpain: req.user.is('MelodyRequestResourceAdminSpain'),
                isMelodyRequestResourceAdminTurkiye: req.user.is('MelodyRequestResourceAdminTurkiye'),
                isMelodyRequestResourceAdminCR: req.user.is('MelodyRequestResourceAdminCR'),
                isMelodyRequestResourceAdminPoland: req.user.is('MelodyRequestResourceAdminPoland'),
                isMelodyRequestResourceAdminHungary: req.user.is('MelodyRequestResourceAdminHungary'),
                isMelodyRequestResourceAdminRomania: req.user.is('MelodyRequestResourceAdminRomania'),
                isMelodyRequestResourceAdminBulgaria: req.user.is('MelodyRequestResourceAdminBulgaria'),
                isMelodyRequestResourceAdminUkraine: req.user.is('MelodyRequestResourceAdminUkraine'),
                isMelodyRequestResourceAdminKasachstan: req.user.is('MelodyRequestResourceAdminKasachstan'),
                isMelodyRequestResourceAdminWestBalkans: req.user.is('MelodyRequestResourceAdminWestBalkans'),
                isMelodyRequestResourceAdminSlovenia: req.user.is('MelodyRequestResourceAdminSlovenia'),
                isMelodyRequestResourceAdminSlovensko: req.user.is('MelodyRequestResourceAdminSlovensko'),
                isMelodyRequestResourceAdminAzerbaijan: req.user.is('MelodyRequestResourceAdminAzerbaijan'),
                isMelodyRequestResourceAdminHrvatska: req.user.is('MelodyRequestResourceAdminHrvatska'),
                isMelodyRequestResourceAdminCsCanada: req.user.is('MelodyRequestResourceAdminCsCanada'),
                isMelodyRequestResourceAdminCsMidwest: req.user.is('MelodyRequestResourceAdminCsMidwest'),
                isMelodyRequestResourceAdminCsNortheast: req.user.is('MelodyRequestResourceAdminCsNortheast'),
                isMelodyRequestResourceAdminCsRegulated: req.user.is('MelodyRequestResourceAdminCsRegulated'),
                isMelodyRequestResourceAdminCsSouth: req.user.is('MelodyRequestResourceAdminCsSouth'),
                isMelodyRequestResourceAdminCsWest: req.user.is('MelodyRequestResourceAdminCsWest'),
                isMelodyRequestResourceAdminCsNorthAmerica: req.user.is('MelodyRequestResourceAdminCsNorthAmerica'),
                isMelodyRequestResourceAreaAdmin: req.user.is('MelodyRequestResourceAreaAdmin')
            }
        }
        return user;
    });

    // using the XSUAA API
    this.on('userInfoUAA', async () => {
        return await xsuaa.get("/userinfo");
    });
});