sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "com/sap/bpm/PresalesRequestApproval/model/models",
    "sap/ui/model/json/JSONModel",
    "com/sap/bpm/PresalesRequestApproval/model/cFLPAdapter"
], function (UIComponent, Device, models, JSONModel, cFLPAdapter) {
    "use strict";

    return UIComponent.extend("com.sap.bpm.PresalesRequestApproval.Component", {

        metadata: {
            manifest: "json"
        },

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
        init: function () {
            cFLPAdapter.init();

            // add support button on detail page title header
            if (!this.getComponentData().inboxHandle.inboxDetailView.getView().byId("mainPage").getAggregation("customHeader").getContentRight().length) {
                this.getComponentData().inboxHandle.inboxDetailView.getView().byId("mainPage").getAggregation("customHeader")
                    .addContentRight(new sap.m.Button({
                        text: "Support",
                        type: "Emphasized",
                        press: function() {
                            sap.m.URLHelper.redirect("https://itsm.services.sap/sp?id=sc_cat_item&sys_id=703f22d51b3b441020c8fddacd4bcbe2&sysparm_category=e15706fc0a0a0aa7007fc21e1ab70c2&service_offering=2aa782291b244110d9c921fbbb4bcbdb&short_description=Customer%20Advisory%20Tools:%20Melody%20Request", true);
                        }
                    }));
            }
            models.getAppConstants(this.fnSuccessAppConstantsCallback, this);
            // call the base component's init function
            UIComponent.prototype.init.apply(this, arguments);
            this.oBusy = new sap.m.BusyDialog();
            this.oBusy.open()

            // enable routing
            this.getRouter().initialize();

            // set the device model
            this.setModel(models.createDeviceModel(), "device");
            //MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
                //set solution area model
                this.setModel(new JSONModel({results:[],aSelectedSolutionAreas:[]}), "SLAMasterDataL1");
                this.setModel(new JSONModel({results:[]}), "SLAMasterDataLevels");
                 //MR: [GRP02-03] GTM25 Resource Profile alignment #84 end

            // get task data
            var startupParameters = this.getComponentData().startupParameters;
            this.setModel(startupParameters.taskModel, "task");
            models.getMRRAppData(this.fnSuccessMRRAppDataCallback, this, true);

            // read process context & bind it to the view's main model
            // var contextModel = new JSONModel(this._getTaskInstancesBaseURL() + "/context");
            // this.setModel(contextModel);
            this._getContextDetails();
            this._getWfTaskDetails();
          

            // read task instance model & bind it to retrieve workflowInstanceId later
            // var taskInstanceModel = new JSONModel(this._getTaskInstancesBaseURL());
            // taskInstanceModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
            // this.setModel(taskInstanceModel, "taskInstanceModel");

        },
        fnSuccessAppConstantsCallback:function (oResponse, self) {
            let sValues = oResponse.value;
            let oResult = sValues.reduce(function (r, a) {
                r[a.Type_desc] = r[a.Type_desc] || [];
                r[a.Type_desc].push(a);
                return r;
            }, Object.create(null)); 
            const oModel = new sap.ui.model.json.JSONModel();
            oModel.setData(oResult);
            self.setModel(oModel, "appConstants");
            sap.ui.core.BusyIndicator.hide();
        },
        _getContextDetails:function(){
            var workflowBaseurl = this._getWorkflowRuntimeBaseURL();
            var that = this;
            var taskId = this.getComponentData().startupParameters.taskModel.getData().InstanceID;
            $.ajax({
                // Call workflow API to complete the task
                url: workflowBaseurl + "/task-instances/" + taskId + "/context",
                async: false,
                method: "GET",
                // refreshTask needs to be called on successful completion
                success: function (result, xhr, data) {
                    // read task instance model & bind it to retrieve workflowInstanceId later
                    // read process context & bind it to the view's main model
                    var contextModel = new JSONModel(result);
                    that.setModel(contextModel);
                },
                error: function (err) {

                }

            });
        },
        _getWfTaskDetails:function(){
            //write your odata code 
            //after getting the values you have close the dialog
            var workflowBaseurl = this._getWorkflowRuntimeBaseURL();
            var that = this;
            var taskId = this.getComponentData().startupParameters.taskModel.getData().InstanceID;
            $.ajax({
                // Call workflow API to complete the task
                url: workflowBaseurl + "/task-instances/" + taskId,
                async: false,
                method: "GET",
                // refreshTask needs to be called on successful completion
                success: function (result, xhr, data) {
                        // read task instance model & bind it to retrieve workflowInstanceId later
                        var taskInstanceModel = new JSONModel(result);
                        taskInstanceModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
                        that.setModel(taskInstanceModel, "taskInstanceModel");
                        setTimeout(function(){
                            that.oBusy.close();
                                }
                            ,1000);
                },
                error: function (err) {
                    
                }

            });
        },

        _getRuntimeBaseURL: function () {
            var componentName = this.getManifestEntry("/sap.app/id").replaceAll(".", "/");
            var componentPath = sap.ui.require.toUrl(componentName);
            return componentPath;
        },

        _getWorkflowRuntimeBaseURL: function () {
            return this._getRuntimeBaseURL() + "/workflowruntime/v1";
        },

        _getTaskInstancesBaseURL: function () {
            return this._getWorkflowRuntimeBaseURL() + "/task-instances/" + this.getTaskInstanceID();
        },

        getTaskInstanceID: function () {
            return this.getModel("task").getData().InstanceID;
        },

        getContentDensityClass: function () {
            if (!this._sContentDensityClass) {
                if (!sap.ui.Device.support.touch) {
                    this._sContentDensityClass = "sapUiSizeCompact";
                } else {
                    this._sContentDensityClass = "sapUiSizeCozy";
                }
            }
            return this._sContentDensityClass;
        },
        // set application related config
        fnSuccessMRRAppDataCallback: function (oResponse, self) {
           let sValues = oResponse.value;
           let oResult = sValues.reduce(function (r, a) {
               r[a.fieldID] = r[a.fieldID] || [];
               r[a.fieldID].push(a);
               return r;
           }, Object.create(null));
           let oModel = new sap.ui.model.json.JSONModel();
           oModel.setData(oResult);
           self.setModel(oModel, "mrrAppConfigModel");
       }
    });
});
