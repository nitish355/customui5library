sap.ui.define([
    "sap/m/ComboBox", // or "sap/m/InputBase" depending on your use case
    "sap/ui/core/IconPool",
    "sap/m/ComboBoxRenderer", // "sap/m/InputBaseRenderer" in case of InputBase
  ], function(Input, IconPool, InputRenderer) {
    "use strict";
  
    /**
     * MINIMAL EXAMPLE
     * No custom Input required if UI5 version >= 1.84!
     * For UI5 1.84 and above, simply assigning a value to `valueHelpIconSrc`.
     */
    return Input.extend("com.sap.bpm.mrr.inputCustomControl", {
      renderer: InputRenderer,
      metadata: {
        events: {
          endButtonPress: {}
        }
      },
  
      init() {
        Input.prototype.init.apply(this, arguments);
      //  const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				const sHintText = "For MidMarket support, select Digital Solution Advisor, or Digital Value Advisor"

        const icon = this.addEndIcon({
          id: this.getId() + "-info",
          src: IconPool.getIconURI("sap-icon://information"),
          noTabStop: true,
          decorative: false,
          tooltip: sHintText,
          press: [ this.onEndButtonPress, this ],
        });
         // See sap.ui.core.Icon/properties for more settings
        // icon.addStyleClass(...); if even more customization required..
      },
  
      onBeforeRendering() {
        Input.prototype.onBeforeRendering.apply(this, arguments);
        const endIcons = this.getAggregation("_endIcon");
        const isEditable = this.getEditable();
        if (Array.isArray(endIcons)) {
          endIcons.map(icon => icon.setProperty("visible", isEditable, true));
        }
      },
  
      onEndButtonPress() {
        if (this.getEnabled() && this.getEditable()) {
          this.fireEndButtonPress({});
        }
      },
  
      onsapshow(event) { // F4 pressed
        if (!this.getEnabled() || !this.getEditable()) {
          return;
        }
        this.fireEndButtonPress({});
        event.preventDefault();
        event.stopPropagation();
      },
  
    });
  });