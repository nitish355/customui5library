sap.ui.define([
    "sap/m/MessageBox"
], function (MessageBox) {
    "use strict";

    return {

        //Handling Error Messages
        setErrorMessage: function(oError, self,isDialog){
            sap.ui.core.BusyIndicator.hide();
            let i18nModel = self.getOwnerComponent().getModel("i18n").getResourceBundle();
            let sErrorMess = i18nModel.getText("Somethingwentwrong");
            let sMsgText = oError.responseText ? oError.responseText : sErrorMess;
            if (!isDialog) {
                MessageBox.error(sMsgText, {
                });
            }
            else {
                return sMsgText;
            }
        }
       
    };
});
