sap.ui.define([
	"sap/m/library",
	"sap/ui/model/json/JSONModel"
], function (mobileLibrary) {
	"use strict";
	var URLHelper = mobileLibrary.URLHelper;
	return {
		ErrorMessageBox: function (sMsg) {
			sap.m.MessageBox.error(sMsg, {
				title: "Error",
				onClose: null,
				styleClass: "",
				initialFocus: null,
				textDirection: sap.ui.core.TextDirection.Inherit
			});
		},

		_getWfServiceRuntimeBaseURL: function (self) {
			return this._getRuntimeBaseURL(self) + "/sapit-employee-data";
		},
		_getRuntimeBaseURL: function (self) {
			var componentName = self.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
			var componentPath = sap.ui.require.toUrl(componentName);
			return componentPath;
		},
		_setPFCdesc:function(element){
			if(element){
			const TrpcL1Desc = element.TGlobal 
			const TrpcL2Desc = element.Region
			const TrpcL3Desc = element.Mu 
			const TrpcL4Desc =  element.MuBelow
		   
			//var sSelectedGuid = element && element.Guid ? element.Guid : "00000000-0000-0000-0000-000000000000";
			let sSelectedDesc = "";

			if (TrpcL1Desc && TrpcL1Desc !== "") {
				sSelectedDesc += TrpcL1Desc;

				if (TrpcL2Desc && TrpcL2Desc !== "") {
					sSelectedDesc += " > " + TrpcL2Desc;

					if (TrpcL3Desc && TrpcL3Desc !== "") {
						sSelectedDesc += " > " + TrpcL3Desc;

						if (TrpcL4Desc && TrpcL4Desc !== "") {
							sSelectedDesc += " > " + TrpcL4Desc;
						}
					}
				}
			}
			return sSelectedDesc;
		}else{
			return "";
		}
		},
		
		getUserInfo: function (sUserIdArr , self,isNamedContact) {
			var workflowBaseurl = this._getWfServiceRuntimeBaseURL(self);
			const results = [];
			const that=this;
			function fetchDataForElement(element) {
				//const sUrl = isNamedContact ? element.UserID : element;
				return new Promise((resolve, reject) => {
							const value = {
								email: element.Email,
								ID: element.UserId,
								fullName: element.EmpFullName
							};
							
							const oPFCMasterData = self.getModel("territoriesMaster").getData();
							const oFilterPFCMasterData = oPFCMasterData.filter((pfc) => pfc.TrpcId === element.TrpcId)[0];
							oFilterPFCMasterData.formattedDesc = that._setPFCdesc(oFilterPFCMasterData);
							value.ProfitCenterDetails = oFilterPFCMasterData;
							results.push(value);
							resolve(value);
				});
			}
			

			function fetchDataForAllElements() {
				const promises = sUserIdArr.map(element => fetchDataForElement(element));
				return Promise.all(promises);
			}
			fetchDataForAllElements()
				.then(approversData => {
					return approversData
				})
				.catch(error => {
				});
				return results;
		}

	};

});