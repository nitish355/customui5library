sap.ui.define([
], function () {
    "use strict";
    return {
        getForecastText: function (sForecastNumVal) {
            switch (sForecastNumVal) {
                case "1":
                    return "Committed";
                case "2":
                    return "Probable";
                case "3":
                    return "Upside";
                case "4":
                    return "Excluded from Pipeline";
                default:
                    return "Not known";
            }
        },

        getDecisionText: function (sAttrValue) {
            switch (sAttrValue) {
                case "G":
                    return this.getMessage("GO");
                case "N":
                    return this.getMessage("NO_GO");
                case "Q":
                    return this.getMessage("RE_QUALIFY");
                default:
                    return "-";
            }
        },

        /**
		 * Find the State of ObjectStatus as per the attribute value
		 * @function lqColorCode
		 * @public
		 * @param {String} sAttrValue - String which holds attribute value
		 * @return {String} State of ObjectStatus
		 **/
        getQualText: function (sAttrValue, sAttrText) {
            switch (sAttrValue) {
                case "2":
                    return this.getMessage(sAttrText + "_STRONG");
                case "1":
                    return this.getMessage(sAttrText + "_MOD");
                case "0":
                    return this.getMessage(sAttrText + "_WEAK");
                default:
                    return this.getMessage("NA");
            }
        },
        /**
		 * Find the State of ObjectStatus as per the attribute value
		 * @function lqColorCode
		 * @public
		 * @param {String} sAttrValue - String which holds attribute value
		 * @return {String} State of ObjectStatus
		 **/
        getQualState: function (sAttrValue) {
            if (sAttrValue === "2") {
                return "Success";
            } else if (sAttrValue === "1") {
                return "Warning";
            } else if (sAttrValue === "0") {
                return "Error";
            }
            return "None";
        },
        /**
		 * calculate the score based on selected values
		 * @function getDealScore
		 * @public
		 * @param {array} results
		 **/
        getDealScore: function (results) {
            let iScore = 0;
            if (results) {
                const aScoreJSON = {
                    "0": 0,
                    "1": 6.25,
                    "2": 12.5
                };
                results.forEach(function (val) {
                    if (val.ATTR_VALUE === "0" || val.ATTR_VALUE === "1" || val.ATTR_VALUE === "2") {
                        iScore += aScoreJSON[val.ATTR_VALUE];
                    } else {
                        iScore += aScoreJSON["0"];
                    }
                });
            }
            return iScore;
        },
		/**
		 * get highlight for element based on given score
		 * @function getDealScoreState
		 * @public
		 * @param {array} results
		 **/
        getDealScoreState: function (results) {
            let iScore = 0;
            if (results) {
                const aScoreJSON = {
                    "0": 0,
                    "1": 6.25,
                    "2": 12.5
                };
                results.forEach(function (val) {
                    if (val.ATTR_VALUE === "0" || val.ATTR_VALUE === "1" || val.ATTR_VALUE === "2") {
                        iScore += aScoreJSON[val.ATTR_VALUE];
                    } else {
                        iScore += aScoreJSON["0"];
                    }
                });
            }
            if (iScore === 0) {
                return "None";
            } else if (iScore > 0 && iScore < 37.5) {
                return "Error";
            } else if (iScore >= 37.5 && iScore < 68.5) {
                return "Warning";
            }
            return "Success";
        },
        formatStaffingTab:function(aNominatedResources){
            if (aNominatedResources) {
                let bIsNotIOStaffing = aNominatedResources.every(val => val.isIOStaffing === false);
                let bIsNotAutoStaffing = aNominatedResources.every(val => val.isAutoStaffing !== true);
                if (!bIsNotIOStaffing) {
                    if (bIsNotAutoStaffing) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            } else {
                return false;
            }

        },
        getTreeTerritoryPrimary: function(aValue) {
            if (!aValue || aValue.length === 0) {
              return "";
            }   
        },
        /* Set Role type text */
        setRoleTypeTextToRoles: function (Desc, RoleTypeGuid) {
            if (!Desc) {
                return "";

            }
            if (Desc && !RoleTypeGuid) {
                return Desc;
            }
            const oRolesModel = this.getView().getModel("roles");
            const aRoleTypes = oRolesModel.getProperty("/RoleTypes");
            const oRoleType = aRoleTypes.find(item => RoleTypeGuid && item.Guid === RoleTypeGuid);
            if (Desc && oRoleType && oRoleType.Desc.toUpperCase() !== "STANDARD") {
                return Desc + " (" + oRoleType.Desc + ")";

            }
            return Desc;
        },
        /* Set Role primary */
        getRolePrimary: function (aValue) {
            if (!aValue || aValue.length === 0) {
                return "";
            }
            const oValue = aValue.find(item => item.IsPrimary);
            if (!oValue || oValue.IsNonFocused) {
                return "";
            }
            const oRolesModel = this.getView().getModel("roleMaster");
            const aRoleTypes = oRolesModel.getData();
            const oSelectedRole = aRoleTypes.find(item => item.Guid === oValue.Guid && item.RoleTypeGuid === oValue.RoleTypeGuid);
            if (oSelectedRole && oSelectedRole.ExceptionFlag === true) {
                return oValue.Desc + " (" + oValue.RoleTypeDesc + ")" + " (Primary)";
            }
            return oValue.Desc + " (Primary)";
        },
        /* Get primary business areas */
        getPrimary: function (aValue) {
			if (!aValue || aValue.length === 0) {
				return "";
			}
			const oValue = aValue.find(item => item.IsPrimary);
			if (!oValue || oValue.IsNonFocused) {
				return "";
			}
			return oValue.Desc + " (Primary)";
		},
        /* Set business area LoB check box selection */
        setBAIndAndLoBCheckBoxSelection: function (oValue) {
            if (!oValue) {
                return false;
            }
            oValue = oValue.filter(item => item.IsNonFocused === false);
            const aSelectedList = oValue.filter(item => item.IsSelected === true);
            if (oValue.length === aSelectedList.length) {
                return true;
            } else {
                return false;
            }
        },
        /*set role count*/
        setRoleCount: function setRoleCount(sDesc, aRole) {
            if (!aRole) {
              return sDesc + " (" + 0 + ")";
            }
      
            var aSelected = aRole.filter(function (item) {
              return item.IsVisible;
            });
            return sDesc + " (" + aSelected.length + ")";
          },
        /*Set manager-level visibility*/
        setManagerVisibility: function (sManagerLevel) {
            if (sManagerLevel === "non-managerial") {
                return true;
            }
            return false;
        },
        /*Set Hub description*/
        
        getTempHubDesc: function (sGuid) {
			if (!sGuid) {
				return "";
			}
			const oModel = this.getView().getModel("employee");
			const aSelectedHubs = oModel.getProperty("/TempEmployee/TempSelectedHubs");
			const oValue = aSelectedHubs.find(item => item.HubGuid === sGuid);
 
			if (!oValue) {
				return "";
			}

			let sDesc = "";
			if (oValue.HubDescL1 && oValue.HubDescL1 !== "") {
				sDesc += oValue.HubDescL1;
			}
 
			if (oValue.HubDescL2 && oValue.HubDescL2 !== "") {
				sDesc += " > " + oValue.HubDescL2;
			}

			if (oValue.HubDescL3 && oValue.HubDescL3 !== "") {
				sDesc += " > " + oValue.HubDescL3;
			}
			return sDesc;
		},
          /*get Hub description */
          getHubDesc: function(sGuid) {
            if (!sGuid) {
              return "";
            }
      
            var oModel = this.getView().getModel("employee");
            var aSelectedHubs = oModel.getProperty("/TempEmployee/SelectedHubs");
            var oValue = aSelectedHubs.find(function (item) {
              return item.HubGuid === sGuid;
            });
      
            if (!oValue) {
              return "";
            }
      
            var sDesc = "";
      
            if (oValue.HubDescL1 && oValue.HubDescL1 !== "") {
              sDesc += oValue.HubDescL1;
            }
      
            if (oValue.HubDescL2 && oValue.HubDescL2 !== "") {
              sDesc += " > " + oValue.HubDescL2;
            }
      
            if (oValue.HubDescL3 && oValue.HubDescL3 !== "") {
              sDesc += " > " + oValue.HubDescL3;
            }
      
            return sDesc;
          },
        setCountForOREResources:function(iCount){
            const resourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            const sTitle = iCount ? resourceBundle.getText("oreResourceCount", [iCount]) : resourceBundle.getText("oreResourceCount", [0]);
            return sTitle;
        },
        formatBALOBText: function formatBALOBText(BALobDesc, BALobClsrDesc) {
            if (BALobClsrDesc == "" || BALobClsrDesc == BALobDesc || BALobDesc == "Non-LoB Focused") {
                BALobDesc = BALobDesc;
              } else {
                BALobDesc = BALobClsrDesc + " > " + BALobDesc;
              }
        
              return BALobDesc;
          },
        setBaIndustriesText: function (clstDesc, desc, techId) {
            if(desc === "Non-Industry Focused"){
                return desc;
            }else if (techId != "") {
                return clstDesc + " > " + desc + " (" + techId + ")";
            } else {
                return clstDesc + " > " + desc;
            }
        },
        formatPCDisplay: function(sProfitCenter){
            if (sProfitCenter) {
                return sProfitCenter.replace(/,/g, "\n");
            }
            return sProfitCenter;
          },
          formatUrlNameDisplay: function(sUrlName , sUrl){
            if(sUrlName){
                return sUrlName;
            }else if(sUrl){
                return sUrl;
            }
        },
        formatProcessorComment:function(bTabVisible,sComments,sCurrentStepID){
            if(sCurrentStepID === "MANAPP"){
                return false;
            }else if(bTabVisible && sComments){
                return true;
            }else{
                return false;
            }
        },
        getCurrentPhase: function(sCurrPhase){
            const salesPhase = {
                "ZP1": "F - Recognize",
                "ZP2": "E - Consider",
                "ZP3": "D - Evaluate",
                "ZP4": "C - Select",
                "ZP5": "B - Negotiate",
                "ZP6": "A - Purchase",
                "ZM1": "D - Evaluate",
                "ZM2": "C - Select",
                "ZM3": "B - Negotiate",
                "ZM4": "A - Purchase",
                "ZM5": "E - Consider",
                "ZF1": "F - Recognize (FS)",
                "ZF2": "E - Consider (FS)",
                "ZF3": "D - Evaluate (FS)",
                "ZF4": "C - Select (FS)",
                "ZF5": "B - Negotiate (FS)",
                "ZF6": "A - Purchase (FS)"
            };
           
            function getFormattedText(sCurrPhase) {
                return salesPhase[sCurrPhase] || sCurrPhase;
            }
            return (getFormattedText(sCurrPhase));
           
        },
        getOppState: function(sCurrstate){
            const oppState = {
                "E0001": "In Process",
                "E0002": "Discontinued",
                "E0003": "Won",
                "E0004": "Booked",
                "E0005": "Lost",
                "E0007": "New",
                "E0014": "Discontinuation check"
            };
           
            function getFormattedText(sCurrstate) {
                return oppState[sCurrstate] || sCurrstate;
            }
            return (getFormattedText(sCurrstate));
           
        },
         //set resprofile description mid text based on  industry and solution area
    formatResProfileFieldVisibility:function(bIsSoln,bIsIndustry){
        if(bIsSoln || bIsIndustry){
            return true;
        }else{
            return false;
        }
    }
    };
});