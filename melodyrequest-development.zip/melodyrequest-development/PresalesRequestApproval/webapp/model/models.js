sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"sap/m/MessageBox",
	"sap/ui/model/odata/v2/ODataModel",
	"com/sap/bpm/PresalesRequestApproval/control/ErrorHandle"
], function (JSONModel, Device, MessageBox, ODataModel, ErrorHandle) {
	"use strict";

	return {

		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		systemISPDataModel: function (self) {
			//set oData model for ISP
			const componentName = self.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
			const componentPath = sap.ui.require.toUrl(componentName);
			const oDataModel = new ODataModel({
				serviceUrl: `${componentPath}/intis/sap/opu/odata/sap/ZSTAFFING_APP_2_SRV`
			});
			return oDataModel;
		},
		_getActExpData:function(oController){
			//get actExp data - Staffing purpose
			const oStaffingModel = this.systemISPDataModel(oController);
			oStaffingModel.setUseBatch(false);
			oStaffingModel.read("/DdlbValues", {
				success: function (data) {
					const  oActivityModel = new JSONModel(data);
					oController.getView().setModel(oActivityModel, "ddlbModelActexp");
				},
				error: function (oError) {
					ErrorHandle.setErrorMessage(oError, oController);
				}
			});
		},
		//get io owner details
		_getIOOwnerDetails:function(oController,sInternalOrder){
			//get task level 
			const oStaffingModel = this.systemISPDataModel(oController);
			const iInternalOrder = Number(sInternalOrder);
			const that = this;
			oStaffingModel.setUseBatch(false);
			oStaffingModel.read('/InternalOrderHeaderSet', {
				urlParameters: {
					'$filter': `(Aufnr eq '${iInternalOrder}' and Logsystem eq 'CRM_MTR')`
				}, 
				success: function (data) {
					if(data.results.length){
						const ioOwnerId = data.results[0].Zzverakuid;
						that._callEmployeeService(ioOwnerId, 100, 0, oController, false,true);
					}
				
				},
				error: function (oError) {
					ErrorHandle.setErrorMessage(oError, oController);
				}
			});

		},
		_getTaskLevelSet:function(oController,Vbeln){
			//get task level 
			const oStaffingModel = this.systemISPDataModel(oController);
			const iVblen = Number(Vbeln);
			oStaffingModel.setUseBatch(false);
			oStaffingModel.read('/TaskLevelValueSet', {
				urlParameters: {
					'$filter': `Vbeln eq '${iVblen}' and CostObjType eq 'IO' and Posnr eq '000000'`
				}, 
				success: function (data) {
					const  oTaskLevelModel = new JSONModel(data);
					oController.getView().setModel(oTaskLevelModel, "TaskLevelDdlb");
				},
				error: function (oError) {
					ErrorHandle.setErrorMessage(oError, oController);
				}
			});

		},
		_postStaffingDetails:function(aPayload,oController,fnSuccess,fnError){
			//POST staffing request
			const oStaffingModel = this.systemISPDataModel(oController)
			oStaffingModel.setUseBatch(true);
			const aDeferredGroup = oStaffingModel.getDeferredGroups().push("ReqCreate");
			oStaffingModel.setDeferredGroups(aDeferredGroup);
			const that = this;
			this.aPostedReq = [];
			aPayload.forEach(function(payload){
				oStaffingModel.create("/ReqDetails", payload,{
					groupId: "ReqCreate",
					success: function (oData, oResponse) {
						that.aPostedReq.push(oResponse);
						if (that.aPostedReq.length === aPayload.length) {
							return fnSuccess(oResponse, oController)
						}
					},
					error: function (oError) {
						that.aPostedReq.push(oError);
						that.aPostedReq = [];
						return fnError(oError, oController)
					}
				})
			});
			oStaffingModel.submitChanges();
		},
		_callUserSearchHelps:function(sUserId,oController,fnSuccess,fnError,oAssignmentContext){
			//call userSearchHelps to get perner no
			const sRooturl = this._getRuntimeBaseURL(oController) + "/intis";
			jQuery.ajax({
				async: false,
				dataType: 'json',
				url: `${sRooturl}/sap/opu/odata/sap/ZSTAFFING_APP_2_SRV/UserSearchHelps?$filter=uname eq '${sUserId}'`,
				type: "GET",
				success: function (oData) {
					return fnSuccess(oData,oController,oAssignmentContext);

				}.bind(this),
				error: function (oError) {
					return fnError(oError,oController,oAssignmentContext);
				}
			});

		},
		_getRuntimeBaseURL: function (self, isComponentScope) {
                var componentName =
                    isComponentScope ? self.getManifestEntry("/sap.app/id").replaceAll(".", "/")
                        : self.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
                var componentPath = sap.ui.require.toUrl(componentName);
                return componentPath;
            },
		_callEmployeeService: function (sUser, topValue, skipValue, oController,oList,isIoOwner) {
			//sap employee service api to get employee details
			const sBaseEmployeeServiceurl = this._getRuntimeBaseURL(oController) + "/sapit-employee-data";
			jQuery.ajax({
				contentType: "application/json",
				async: false,
				type: "GET",
				url: `${sBaseEmployeeServiceurl}/Employees?$count=true&$search="${sUser}"&$skip=${skipValue}&$top=${topValue}`,
				success: function (response) {
					const oIoOwnerData = new JSONModel(response);
					if (!isIoOwner) {
						//trigger for io owner search dialog
						oList.setBusy(false);
						oController.getView().setModel(oIoOwnerData, "ioOwnerModel");
					}else{
						oController.getView().getModel("ioOwnerDetails").setData(response.value);
					}
				}.bind(this),
				error: function (oError) {
					if (!isIoOwner) {
						oList.setBusy(false);
					}
					ErrorHandle.setErrorMessage(oError, self);
				}
			});
		},
		_CallautoStaffingAPI: function (sUser, topValue, skipValue, oController,sSalesOrg,token) {
			const sBaseEmployeeServiceurl = this._getRuntimeBaseURL(oController) + "/sapit-employee-data";
			const salesOrg = sSalesOrg;
			//employee service call to get compnay code and cost center
			jQuery.ajax({
				contentType: "application/json",
				async: false,
				type: "GET",
				url: `${sBaseEmployeeServiceurl}/Employees?$count=true&$search="${sUser}"&$skip=${skipValue}&$top=${topValue}`,
				success: function (response) {
					const sCostCenterID = response.value[0].costCenter.ID;
					const sCompanyCode = response.value[0].company.ID;
					oController.sCompanyCode = sCompanyCode;
					oController.sCostCenter = sCostCenterID;
					const sBaseISPurl = this._getRuntimeBaseURL(oController) + "/intis";
					oController.sCompanyCode = sCompanyCode;
					if(token){
						token.sCompanyCode = sCompanyCode;
						token.sCostCenter = sCostCenterID;
					}
					//auto staffing /ZsolccApiSet call to check for auto staffing
					jQuery.ajax({
						contentType: "application/json",
						dataType: 'json',
						async: false,
						type: "GET",
						url: `${sBaseISPurl}/sap/opu/odata/sap/ZSTAFFING_APP_2_SRV/ZsolccApiSet(Bukrs='${salesOrg}',Kostl='${sCostCenterID}')`,
						success: function (response) {
							let bAutoStaffingFlag = response.d.Zflag;
							const sMessage = response.d.Zmsg
							if (sMessage === "Record exists in ZSOL_CC") {
								//auto staffing => true
								bAutoStaffingFlag = true;
							}
							if(token){
								token.isAutoStaffing = bAutoStaffingFlag;
							}

						}.bind(this),
						error: function (oError) {
							try {
								if (oError.responseJSON.error.message.value === "Record does not exists in ZSOL_CC") {
									if(token){
										//auto staffing => false
										token.isAutoStaffing = false;
									}
		
								}
							} catch (err) {
								ErrorHandle.setErrorMessage(oError, oController);
							};
						}
					});

				}.bind(this),
				error: function (oError) {
					ErrorHandle.setErrorMessage(oError, oController);
					return false;

				}
			});
		},
		_callExceptionTable: function (burks, Kostl, sSalesOrg,sUserId,oController,fnSuccess,fnError,oAssignmentContext) {
			//check data(salesOrg,costCenter,userId,companyCode) maintained in exception table for staffing
			const sRooturl = this._getRuntimeBaseURL(oController) + "/resources";
			jQuery.ajax({
				async: false,
				contentType: "application/json",
				url: `${sRooturl}/resources/IOStaffException?$filter=bukrs eq '${burks}' and sorg eq '${sSalesOrg}' and zflag eq 'X'`,
				type: "GET",
				success: function (oData) {
					return fnSuccess(oData,oController,oAssignmentContext);

				}.bind(this),
				error: function (oError) {
					return fnError(oError,oController,oAssignmentContext);
				}
			});

		},
		//get IO owner from ISP table
		_getIoOwnerData:function(oController,iInternalOrder){
			const sRooturl = this._getRuntimeBaseURL(oController) + "/resources";
			const that = this;
			jQuery.ajax({
				async: false,
				contentType: "application/json",
				url: `${sRooturl}/req-area-api-/InternalOrder?$filter=internalOrder eq '${iInternalOrder}'`,
				type: "GET",
				success: function (data) {
					if(data.value.length){
						const sUserId = data.value[0].io_Owner;
						that._callEmployeeService(sUserId, 100, 0, oController, false,true);
					}
				}.bind(this),
				error: function (oError) {
					ErrorHandle.setErrorMessage(oError, oController);
				}
			});
		},
		_getLSRuntimeBaseURL: function (self) {
			return this._getRuntimeBaseURL(self) + "/int_ls";
		},
		  /**Git 181 (SalesOrg + SalesOffice mapping)
             * Retrieves the profit center master data from the specified endpoint.
             *
             * @param {Object} self - The current context or controller instance.
             */
            _getProfitCenterMasterData:function(self){
                //profit center master data call LS system
                const oResourcesSystemModel = this.systemLSDataModel(self),
				 	 sPFCUrlEndPoint = "/YC_MR_M_TRTRYPC",
                    that = this;
                this._callGETOdata(oResourcesSystemModel, sPFCUrlEndPoint).
                then(function (data) {
                    sap.ui.core.BusyIndicator.hide();
					//set selected profit center
                    let oFinalProfitCenter = { "TempProfitCenter": { "Territories": [] }, "filteredProfitCenter": [] }
                    self.getView().getModel("selectedProfitCenter").setData(oFinalProfitCenter);
					const aTerritories = data.results;
					aTerritories.map(function (element) {
						element.isCheckBox = element.isPC_Selectable ? true : false;
						element.isFiltered = true;
					});
					self.getView().getModel("territoriesMaster").setData(aTerritories);
					that.getSalesOrgProfitCenter(self);
                })
                .catch(function (oError) {
                    sap.ui.core.BusyIndicator.hide();
                    ErrorHandle.setErrorMessage(oError, that);
                });
            },
		/*Set  profit center Obj*/
		_setProfitCenterObj:function(element,bTerritory){
			const Guid =  bTerritory? element.TrpcGuid :  element.guid;
			const Desc = bTerritory ? element.TrpcDesc :  element.TrpcDesc;
			const TrpcL1Desc = bTerritory ? element.TGlobal : element.TrpcL1Desc;
			const TrpcL2Desc = bTerritory ? element.Region :  element.TrpcL2Desc;
			const TrpcL3Desc =bTerritory ? element.Mu :element.TrpcL3Desc;
			const TrpcL4Desc = bTerritory? element.MuBelow : element.TrpcL4Desc;
			const TrpcId = bTerritory ? element.TrpcId :  element.id;
			const IsPrimary = bTerritory ? element.IsPrimary : false;
		   
			//var sSelectedGuid = element && element.Guid ? element.Guid : "00000000-0000-0000-0000-000000000000";
			let sSelectedDesc = "";

			if (TrpcL1Desc && TrpcL1Desc !== "") {
				sSelectedDesc += TrpcL1Desc;

				if (TrpcL2Desc && TrpcL2Desc !== "") {
					sSelectedDesc += " > " + TrpcL2Desc;

					if (TrpcL3Desc && TrpcL3Desc !== "") {
						sSelectedDesc += " > " + TrpcL3Desc;

						if (TrpcL4Desc && TrpcL4Desc !== "") {
							sSelectedDesc += " > " + TrpcL4Desc;
						}
					}
				}
			}
			return {
				Desc: Desc,
				desc:Desc,
				SelectedDesc: sSelectedDesc,
				SelectedGuid:Guid,
				TrpcL1Desc:  TrpcL1Desc,
				TrpcL2Desc: TrpcL2Desc,
				TrpcL3Desc:  TrpcL3Desc,
				TrpcL4Desc:TrpcL4Desc,
				TrpcId: TrpcId,
				guid:Guid,
				isResourceProfile:element.isResourceProfile,
				isCheckBox:element.isCheckBox,
				isParentNodeEnable:element.isParentNodeEnable,
				isChildNodeEnable:element.isChildNodeEnable,
			};
		},
		_getWfServiceRuntimeBaseURL: function (self, isComponentScope) {
                return this._getRuntimeBaseURL(self, isComponentScope) + "/resources";
            },
		getPublicReqArea: function (self, sSalesOrg, fnSuccess, oContext) {
			var workflowBaseurl = this._getWfServiceRuntimeBaseURL(self);
			jQuery.ajax({
				url: `${workflowBaseurl}/req-area-api-/Public_ReqArea?$filter=orgID eq '${sSalesOrg}'`,
				async: false,
				dataType: 'json',
				method: "GET",
				success: function (response) {
					const aResult = response.value;
					const aModel = {};
					aModel.data = self._setReqAreasTree(aResult);
					const oUpdatedReqArea = new JSONModel();
					oUpdatedReqArea.setData(aModel);
					self.getView().setModel(oUpdatedReqArea, "myPresaleModel");
					self._configRequestDialog()
					//return fnSuccess(response, self, oContext);

				}.bind(this),
				error: function (oError) {
					ErrorHandle.setErrorMessage(oError, self);
				}
			});
		},
		 /**Git 181 (SalesOrg + SalesOffice mapping)
             * Retrieves the Sales Organization Profit Center details.
             *
             * @param {Object} self - The current context or controller instance.
             * This function only reponsible for legacy to map profit center and sales org
             */
		getSalesOrgProfitCenter: function (self) {
			 //sales org mapping for old requests or legacy
			const sBaseUrl = this._getWfServiceRuntimeBaseURL(self);
			const that = this;
			jQuery.ajax({
				async: false,
				contentType: "application/json",
				url: `${sBaseUrl}/ore-api-/SOrg_PC_Map`,
				type: "GET",
				success: function (response) {
			        const aSalesOrgTerritories = response.value;
					let opcmodel = new sap.ui.model.json.JSONModel(aSalesOrgTerritories);
					self.getView().setModel(opcmodel, "PCSalesOrgMaster")
					let sorgIDPc;
					if (self.getView().getModel().getProperty("/OrgType") === "PC") {
						self.getView().getModel("PCSalesOrgMaster").getData().find(function (item) {
							if (item.ProfitCenterGuid === self.getView().getModel().getProperty("/OrgID")) {
								sorgIDPc = item.SOrg;
							}
						});
					}
					if(sorgIDPc === "NOMP"){
						sorgIDPc = self.getView().getModel().getProperty("/OrgID")
					}
					const oReqAreaModel = new JSONModel(self._getRequestAreaBaseURL(sorgIDPc));
					self.getView().setModel(oReqAreaModel, "RequestAreaAPIData");
                       
				}.bind(this),
				error: function (oError) {
					ErrorHandle.setErrorMessage(oError, self);

				}
			});
		},
			 /**Git 181 (SalesOrg + SalesOffice mapping)
             * Retrieves and filters the Sales Organization Profit Center based on the current view context.
             *
             * @param {Object} self - The current context or controller instance.
             * @param {string} sSalesOrgNumber - Sales org Id
             * This function processes the selected profit center for the create request.
             * It updates the relevant models and refreshes the data displayed in the UI.
             */
		  getFilteredSalesOrgProfitCenter:function(self,sSalesOrgNumber){
			const that = this;
			const oModel = self.getView().getModel("selectedProfitCenter");
			//git 181
            //filter selected profit center for manager page forward
			const oSalesOrgMappingModelData =  self.getView().getModel("territoriesMaster").getData();
			let aTempTerritory =[],
			aFilteredArray=oSalesOrgMappingModelData.filter(obj=> obj.TrpcGuid == sSalesOrgNumber),
			oProfitCenter,
			oFinalData;
			if(aFilteredArray.length){
				oProfitCenter = that._setProfitCenterObj(aFilteredArray[0], true);
				aTempTerritory.push(oProfitCenter);
				oFinalData = { "TempProfitCenter": { "Territories": [aTempTerritory[0]] }, "filteredProfitCenter": aTempTerritory }
			}else{
				oFinalData = { "TempProfitCenter": { "Territories": [] }, "filteredProfitCenter": [] }
			}
	
			oModel.setData(oFinalData);
			oModel.refresh(true);
			let oPfcListModel = new sap.ui.model.json.JSONModel(oFinalData);
			self.getView().setModel(oPfcListModel, "selectedProfitCenter");
			self._setResourceProfileData(self);
			self.getView().getModel("profileViewParameters").setProperty("/isProfitCenterInputVisible",true);
			self.getView().getModel("profileViewParameters").refresh(true);
    
		  },
		/*API call for Role Role area*/
		  getRoleRoleArea: function (self) {
			const sBaseUrl = this._getLSRuntimeBaseURL(self);
			const sUrl = `YC_DS_M_ROLE_TYPESet?$expand=N_RoleTypeToRole`;
			jQuery.ajax({
				 async: false,
				url: `${sBaseUrl}/sap/opu/odata/sap/YROSTER_SRV;v=0002/${sUrl}`,
				dataType: "json",
				method: "GET",
				success: function (response) {
					self.getView().getModel("roleMasterData").setData(response.d.results)
					// self.loadRoleTypeData("ROLETYPE", response.d.results);
				}.bind(this),
				error: function (oError) {
					ErrorHandle.setErrorMessage(oError, self);
				},
			});
		},
		/*API call for Manage level*/
		getManagerLevel: function (self) {
			const sBaseUrl = this._getLSRuntimeBaseURL(self);
			const sUrl = `YC_DS_M_MANAGER_LVL`;
			jQuery.ajax({
				 async: false,
				url: `${sBaseUrl}/sap/opu/odata/sap/YROSTER_SRV;v=0002/${sUrl}`,
				dataType: "json",
				method: "GET",
				success: function (response) {
					//self.loadRoleTypeData("ROLETYPE", response.d.results);
					self.getView().getModel("managerLevelMasterData").setData(response.d.results);
					// self.getView().getModel("employee").setProperty("/TempEmployee/ManagerLevel",response.d.results);
				}.bind(this),
				error: function (oError) {
					ErrorHandle.setErrorMessage(oError, self);
				},
			});
		},
		/*API call for Resource profile master data*/
		getResourceProfileMasterData: function (oEntity,self,sText,isPromise) {
			const sBaseUrl = this._getLSRuntimeBaseURL(self);
			const that = this;
			return new Promise((resolve, reject) => {
				jQuery.ajax({
					async: false,
				   url: `${sBaseUrl}/sap/opu/odata/sap/YROSTER_SRV;v=0002/${oEntity}`,
				   dataType: "json",
				   method: "GET",
				   success: function (response) {
					switch (oEntity) {
						case "YC_OR_M_CROSSCVRG":
							self.getView().getModel("crossCvgMasterData").setData(response);
							break;
						case "YC_OR_M_BA_LOB":
							self.getView().getModel("baLoBMasterData").setData(response);
							break;
						case "YC_OR_M_BA_INDUSTRY":
							self.getView().getModel("baIndMasterData").setData(response);
							break;
						default:
							resolve(response);
							break;
						}
				   }.bind(this),
				   error: function (oError) {
					that._setErrorMsgPopOver(self,sText,oError,isPromise);
					if(oEntity !== "YC_OR_M_CROSSCVRG" && oEntity !== "YC_OR_M_BA_LOB"  && oEntity !== "YC_OR_M_BA_INDUSTRY" ){
						reject(oError)
					}
				   },
			   });
			  })
		},
		/*Get i18n text*/
		_getI18nText:function(self,sText){
			const i18nModel = self.getOwnerComponent().getModel("i18n").getResourceBundle();
			return i18nModel.getText(sText);
		},
		/*Set Error Messgage PopOver*/
		_setErrorMsgPopOver: function (appView, sTitle, oError, isPromise,sNamesContact) {
            const oErrorModel =  appView.getView().getModel("errorMsgModel");
            const sErrorMsg = ErrorHandle.setErrorMessage(oError, appView,true);
            const si18nPFC = this._getI18nText(appView,sTitle);
            const si18nError = this._getI18nText(appView,"errors");
            appView.getView().getModel("profileViewParameters").setProperty("/footerButtons/errorBtnType","Negative");
            appView.getView().getModel("profileViewParameters").setProperty("/footerButtons/errorBtnIcon","sap-icon://error");
            appView.getView().getModel("profileViewParameters").refresh();
            if (appView.getView().byId("idNotificationBadgedButton")) {
                appView.getView().byId("idNotificationBadgedButton").setVisible(true);
            }
            if (appView.getView().byId("idNotificationNamedContactBadgedButton")) {
                appView.getView().byId("idNotificationNamedContactBadgedButton").setVisible(true);
            }
            if (oErrorModel.getData().errorInformation && oError !== "Complete") {
                oErrorModel.getData().errorInformation.push({
                    "title": si18nPFC,
                    "error": sErrorMsg
                });
                oErrorModel.getData().errorInformation = oErrorModel.getData().errorInformation.filter((value, index) => {
                    const _value = JSON.stringify(value);
                    return index === oErrorModel.getData().errorInformation.findIndex(obj => {
                        return JSON.stringify(obj) === _value;
                    });
                });
                oErrorModel.setProperty("/count", oErrorModel.getData().errorInformation.length);
                oErrorModel.setProperty("/errorPriority", "High");
                oErrorModel.setProperty("/errorHeader",`${si18nError}`);
            }
            oErrorModel.refresh(true);
            if (!isPromise) {
                appView._onOpenErrorPopOver(sNamesContact);
            }
        },
		getAppConstants: function (fnSuccess, self) {
			const sFormattedUrl = self.getManifestEntry("/sap.app/id").replaceAll(".", "/");
			const componentPath = sap.ui.require.toUrl(sFormattedUrl);
			const sFinalUrl = componentPath + "/resources";
			jQuery.ajax({
				async: false,
				contentType: "application/json",
				url: `${sFinalUrl}/req-area-api-/Parameter`,
				type: "GET",
				success: function (oData) {
					return fnSuccess(oData, self);

				}.bind(this),
				error: function (oError) {
					ErrorHandle.setErrorMessage(oError, self);
				}
			});

		},
		_getOpportunitiesRuntimeBaseURL: function (self) {
			return this._getRuntimeBaseURL(self) + "/intic";
		},
		//reusable function to call oData
		_callGETOdata: function (oModel, sPath,sUrlParams) {
			const sUrlParameters = sUrlParams ? sUrlParams:[];
			return new Promise(function (resolve, reject) {
				oModel.read(sPath, {
					urlParameters:sUrlParameters,
					success: function (data) {
						resolve(data);
					},
					error: function (oError) {
						reject(oError)
					}
				});
			});
		},
		systeminticDataModel: function (self) {
			//set oData model for ISP
			const componentName = self.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
			const componentPath = sap.ui.require.toUrl(componentName);
			const oDataModel = new ODataModel({
				serviceUrl: `${componentPath}/intic/sap/opu/odata/sap/zharmony_callidus_srv`
			});
			return oDataModel;

		},
		systemResourcesDataModel: function (self) {
			//set oData model for ISP
			const componentName = self.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
			const componentPath = sap.ui.require.toUrl(componentName);
			 // call ymr_srv service for solution areas
			const oDataModel = new ODataModel({
				serviceUrl: `${componentPath}/int_ls/sap/opu/odata/sap/ymr_srv`
			});
			return oDataModel;

		},
		
		systemLSDataModel: function (self) {
			//set oData model for ISP
			const componentName = self.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
			const componentPath = sap.ui.require.toUrl(componentName);
			 // call ymr_srv service for solution areas
			const oDataModel = new ODataModel({
				serviceUrl: `${componentPath}/int_ls/sap/opu/odata/sap/ymr_srv`
			});
			return oDataModel;

		},
		//Get Solution Area initial level Master Data (Solution Area L1)
		_getSLAMasterData:function (oController) {
			const oLSSystemModel = this.systemLSDataModel(oController);
			oLSSystemModel.setUseBatch(true);
			this._callGETOdata(oLSSystemModel, "/YC_MR_M_SOL_HIERARCHY_DETAILS").then(function (oData) {
				//convert flat structure to tree structure
				let aSolutionAreas = oData.results,
					aSAList = [];
				for (let i = 0; i < aSolutionAreas.length; i++) {
					let oL1 = aSAList.find(item => item.Guid === aSolutionAreas[i].SolL1Guid);
					if (!oL1 && aSolutionAreas[i].SolL1Guid && aSolutionAreas[i].SolL1Guid !== "" && aSolutionAreas[i].SolL1Guid !==
						"00000000-0000-0000-0000-000000000000" && aSolutionAreas[i].SolL1Viewable.toUpperCase() === "X") {
						oL1 = {
							soln_guid: aSolutionAreas[i].SolL1Guid,
							soln_id: aSolutionAreas[i].SolL1Id,
							soln_name: aSolutionAreas[i].SolL1Desc,
							solnFinalName: aSolutionAreas[i].SolL1Desc,
							is_selectable: aSolutionAreas[i].SolL1Selectable,
							is_viewable: aSolutionAreas[i].SolL1Viewable,
							soln_prnt_guid:"00000000-0000-0000-0000-000000000000",
							isPartiallySelected: false,
							is_ChildLoaded: true,
							to_Child: [],
							Guid: aSolutionAreas[i].SolL1Guid,
							ID: aSolutionAreas[i].SolL1Id,
							Desc: aSolutionAreas[i].SolL1Desc,
							LevelId: 1,
							SolAreal1Guid: aSolutionAreas[i].SolL1Guid,
							SolAreal1Desc: aSolutionAreas[i].SolL1Desc,
							DisplayGuid: aSolutionAreas[i].SolL1Guid,
							DisplayDesc: aSolutionAreas[i].SolL1Desc,
							Levels: [],
						};
						aSAList.push(oL1);
						aSAList.sort((a, b) => a.soln_name.localeCompare(b.soln_name));
					}
					if (oL1) {
						let oL2 = oL1.Levels.find(item => item.Guid === aSolutionAreas[i].SolL2Guid);
						if (!oL2 && aSolutionAreas[i].SolL2Guid && aSolutionAreas[i].SolL2Guid !== "" && aSolutionAreas[i].SolL2Guid !==
							"00000000-0000-0000-0000-000000000000" && aSolutionAreas[i].SolL2Viewable.toUpperCase() === "X") {
							oL2 = {
								soln_guid: aSolutionAreas[i].SolL2Guid,
								soln_id: aSolutionAreas[i].SolL2Id,
								soln_name: aSolutionAreas[i].SolL2Desc,
								solnFinalName: aSolutionAreas[i].SolL2Desc,
								prnt_soln_id:aSolutionAreas[i].SolL1Id,
								soln_prnt_guid:aSolutionAreas[i].SolL1Guid,
								isPartiallySelected: false,
								is_selectable: aSolutionAreas[i].SolL2Selectable,
								is_viewable: aSolutionAreas[i].SolL2Viewable,
								is_ChildLoaded: false,
								to_Child: [],
								LevelId: 2,
								SolAreal1Guid: aSolutionAreas[i].SolL1Guid,
								SolAreal1Desc: aSolutionAreas[i].SolL1Desc,
								SolAreal2Guid: aSolutionAreas[i].SolL2Guid,
								SolAreal2Desc: aSolutionAreas[i].SolL2Desc
							};
							oL1.to_Child.push(oL2);
							oL1.to_Child.sort((a, b) => a.soln_name.localeCompare(b.soln_name));
						}
					}
				}

				//set default child for all masterData
				oController.getOwnerComponent().getModel("SLAMasterDataLevels").setData(
					{
						"results": aSAList
					});
				oController._OnUpdateSlaSelection(true);
			})
				.catch(function(oError) {
					ErrorHandle.setErrorMessage(oError, oController);
				});

		},
		//get Solution Area levels
		_getSLALevels:function(oController,oContext,sPath,evt){
			const oLSSystemModel = this.systemLSDataModel(oController);
			let sGuid = sPath ? oContext.soln_guid : oContext.SolGuid;
			const sUrlParams = {
				$filter: `soln_guid eq (guid'${sGuid}')`,
				$expand:"to_Child"
		   };

			oLSSystemModel.setUseBatch(true);
			this._callGETOdata(oLSSystemModel,"/YC_MR_M_SOL_HIERARCHY", sUrlParams).then(function(oData){
				const oResponse =oData.results[0].to_Child;
					//set default child for all masterData
					oResponse.results.forEach(function(data){
						data.is_final = false;
						data.isSelectable = true;
						data.is_ChildLoaded = false;
						data.is_ChildLoaded = true;
						data.isPartiallySelected = false;
						data.solnFinalName = oContext.soln_name ? `${oContext.soln_name} > ${data.soln_name} `:data.soln_name;
						let oSelectedSLA = oController.getView().getModel("employee").getProperty(`/searchItems/${oController.getView().getModel("masterDataModel").getProperty("/iIndex")}/TempEmployee/SolutionAreas/0`);
						if(oSelectedSLA && data.soln_guid === oSelectedSLA.soln_guid){
							data.isSelected = true;
						}
						if(!sPath){
							data.to_Child = [{
								"soln_name": "Loading...",
								"is_selectable":false,
								"is_viewable":"X"
						 }];
						 delete data.to_Child; //till L2
						}
					   
					});
					if(sPath){
						//more levels
						const oSelectedContext = oController.getOwnerComponent().getModel("SLAMasterDataLevels").getProperty(sPath);
						oSelectedContext.is_final = true;
						oResponse.results.forEach(function(data){
							if(data.to_Child){
								delete data.to_Child;
							}
						});
						oSelectedContext.is_ChildLoaded = true;
						oSelectedContext.to_Child = oResponse.results;
						oController.getOwnerComponent().getModel("SLAMasterDataLevels").refresh(true);

					}else{
						oController.getOwnerComponent().getModel("SLAMasterDataLevels").setData(oResponse);
					}
				   
					oController.getOwnerComponent().getModel("SLAMasterDataLevels").setProperty("/isGridLayBusy",false);
					oController.getOwnerComponent().getModel("SLAMasterDataLevels").refresh();
					oController._OnUpdateSlaSelection();
			})
			.catch(function(oError){
				ErrorHandle.setErrorMessage(oError, oController);
			});
			
		},
		  		 //get active users from ore
		 getOreActiveUsers: function(self , query , fnSuccess, sVal , data){
			var OpportunitiesBaseUrl = this._getLSRuntimeBaseURL(self);
			jQuery.ajax({
				async: false,
				url: `${OpportunitiesBaseUrl}/sap/opu/odata/sap/YROSTER_SRV;v=0002/YC_DS_T_RESOURCE_PROFILE${query}`,
				dataType: "json",
				method: "GET",
				success: function (response) {
					const aActiveUsersData = response.d.results;
					const sActiveUsersIds = aActiveUsersData.map(user => user.UserId);
					const filteredArray = data.filter(user => sActiveUsersIds.includes(user.UserID));
					return fnSuccess(filteredArray, self, sVal);
				}.bind(this),
				error: function (oError) {
					ErrorHandle.setErrorMessage(oError, self);
				},
			});
		},
		 //service call for MRR application related config (MRR Tab)
		 getMRRAppData: function (fnSuccess, self, isComponentScope) {
			const sBaseurl = this._getWfServiceRuntimeBaseURL(self, isComponentScope);
			jQuery.ajax({
				async: true,
				contentType: "application/json",
				url: `${sBaseurl}/req-area-api-/MR_App_Label`,
				type: "GET",
				success: function (oData) {
					return fnSuccess(oData, self);

				}.bind(this),
				error: function (oError) {
					ErrorHandle.setErrorMessage(oError, self);
				}
			});
		}
	 
	};
});