sap.ui.define([
   "sap/ui/core/mvc/Controller"

], function (Controller) {
   "use strict";
   return Controller.extend("com.sap.bpm.PresalesRequestApproval.NotFound", {

      onInit: function () {
      },

   });
});