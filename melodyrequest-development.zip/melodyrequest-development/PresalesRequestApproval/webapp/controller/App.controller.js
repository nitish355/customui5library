sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/ui/core/format/DateFormat",
	"sap/ui/core/Fragment",
	"sap/ui/core/syncStyleClass",
	"sap/m/Text",
	"sap/m/TextArea",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"com/sap/bpm/PresalesRequestApproval/model/formatter",
	"sap/m/Dialog",
	"sap/m/DialogType",
	"sap/m/Button",
	"sap/m/ButtonType",
	"sap/m/Label",
	"sap/m/Select",
	"sap/m/MessageBox",
	"com/sap/bpm/PresalesRequestApproval/model/models",
	"com/sap/bpm/PresalesRequestApproval/control/ErrorHandle",
	"sap/f/library",
	"sap/ui/core/mvc/XMLView",
	"com/sap/bpm/PresalesRequestApproval/model/users",
	"sap/ui/model/odata/v2/ODataModel",
    "sap/base/security/sanitizeHTML",
], function (BaseController, JSONModel, MessageToast, DateFormat, Fragment, syncStyleClass, Text, TextArea,
	Filter, FilterOperator, formatter, Dialog, DialogType, Button, ButtonType, Label, Select, MessageBox, Models, ErrorHandle, fioriLibrary,
	XMLView, users,ODataModel,sanitizeHTML) {
	var workflowInstanceId,
		token;
	"use strict";
	var URLHelper = fioriLibrary.URLHelper;
	var LayoutType = fioriLibrary.LayoutType;
	return BaseController.extend("com.sap.bpm.PresalesRequestApproval.controller.App", {

				formatter: formatter,

				onAfterRendering: function(){
					var that = this;
					setTimeout(function(that) {
						that._hideMyInboxFooterBtns(that)
					}, 1000, this);
				},
				_hideMyInboxFooterBtns:function(that){
					const oDetailView = that.getComponentData().inboxHandle.inboxDetailView;
					const aFooterBtns = oDetailView.getView().getContent()[0].getFooter().getContentRight();
					const aClaimBtn = aFooterBtns.filter((btn) => btn.getText() === "Claim");
					let oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
					let sDownTimeFlag = oAppConstantsModel.getProperty("/DownTime/0/Operational_Status");
					if (sDownTimeFlag) {
						oDetailView.getView().getContent()[0].setFooter(false);
					}
					if(aClaimBtn.length){
						aClaimBtn[0].setVisible(false);
					}
					oDetailView.getView().byId("myInbox_SHARE").setVisible(false);
					oDetailView.getView().byId("LogButtonID").setVisible(false);	
				},

				onInit: function () {
					this.getContentDensityClass();
					let oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
					let sDownTimeFlag = oAppConstantsModel.getProperty("/DownTime/0/Operational_Status");
				 if (!sDownTimeFlag) {
					//add OrgId,OrgType,RequestType for older tasks
					if (typeof (this.getModel().getData()["SalesOrgID"]) === "string") {
						this.getModel().getData()["OrgID"] = this.getModel().getData()["SalesOrgID"];
						this.getModel().getData()["OrgType"] = "SORG";
						this.getModel().getData()["RequestType"] = "Opportunity"
					}

					// document service interaction
					if(!this.getModel().getProperty("/currentStepID") && this.getModel().getProperty("/currentStepName") === "Presales Manager Approval"){
						this.getModel().setProperty("/currentStepID","MANAPP")
					}
					this.oAttachmentsModel = new JSONModel();
					this.oAttachmentsModel.downloadEnabled = false;
					this.setModel(this.oAttachmentsModel, "attachmentsModel");
					//this.loadAttachments();

					let oModel = this.getModel();
					if(oModel.getProperty("/approvalHistory")){
						oModel.getProperty("/approvalHistory").reverse();
					}
					oModel.setProperty("/namesOfPartiesVisible", false);
					const aInvolvedPartiesKeys = oModel.getProperty("/requestDetails/involvedPartiesKeys");
					if (aInvolvedPartiesKeys && aInvolvedPartiesKeys.length > 0) {
						if (aInvolvedPartiesKeys.includes("1") || aInvolvedPartiesKeys.includes("2") || aInvolvedPartiesKeys.includes("3")) { // if SAP Partner, SAP Consulting or Customer Advisory is selected
							oModel.setProperty("/namesOfPartiesVisible", true);
						}
					}
					//i18n model
					this.i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();

					this.parseGetOppDataResponse(this.getModel().getProperty("/CPICalls/getDataFromCRM/Response/d/"));
					this._fetchFormActions(this);
					this.configureView(this.getModel().getProperty("/currentStepID"));

					const oConstantsModel = new JSONModel(this._getConstantsBaseURL());
					this.getView().setModel(oConstantsModel, "ConstantsAPIData");

					const oRejectionCodeModel = new JSONModel(this._getRejectionCodeBaseURL());
					this.getView().setModel(oRejectionCodeModel, "RejectionCodeAPIData");

					const oWFRoutingModel = new JSONModel(this._getWFRoutingBaseURL());
					this.getView().setModel(oWFRoutingModel, "WFRoutingAPIData");

					const oTerritoryMasterModel = new sap.ui.model.json.JSONModel([]);
					this.getView().setModel(oTerritoryMasterModel, "territoriesMaster");
					  //Call profitcenter master data --Git 181 Start
					  Models._getProfitCenterMasterData(this);
					//--Git 181 End
			this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",[])
            this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/results",[])
            this.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
            this.oSLASearchContext = false;

					  //Change Request to IO Staffing Working for EMEA #93 start
					//get skip io workflow task flag
					const oWFRoutingModelSkipIO = new JSONModel(this._getWFRoutingSkipIOBaseURL());
					this.getView().setModel(oWFRoutingModelSkipIO, "WFRoutingSkipIOAPIData");
					//Change Request to IO Staffing Working for EMEA #93 end

					const oIoOwnerDetailsModel = new JSONModel([]);
					this.getView().setModel(oIoOwnerDetailsModel, "ioOwnerDetails");

					if (this.getModel().getData().isResourceProfile) {
						this.getResProfileDetails();
					}

					/* Start of Code for CurrentTask Instance ID Update  */
					this.updateCurrentInstance();
					/* End of Code for CurrentTask Instance ID Update  */
                    /*initialize assignments */
					this._initializeAssignments();

					 /*initialize assignments */
					 //setAttachment url visibility
					 if (this.getModel().getProperty("/requestDetails/attachmentUrls")) {
						 const bAttachmentUrl = this.getModel().getProperty("/requestDetails/attachmentUrls").length ? true : false;
						 this.getModel().setProperty("/isAttachmentUrl", bAttachmentUrl);
						 if(bAttachmentUrl){
							const aFinalAttachmentUrl = this.getView().getModel().getProperty("/requestDetails/attachmentUrls");
							let bAttachmentFinalUrl = true;
							aFinalAttachmentUrl.forEach(function(item,iIndex){
								if(!item.url && !item.urlName){
									 bAttachmentFinalUrl = false;
								}
							});
							this.getView().getModel().setProperty("/isAttachmentUrl", bAttachmentFinalUrl);
						}
					 }

					this._fetchFormConfigData(this);
					const sReqType = this.getModel().getProperty("/RequestType");
					this.getView().setModel(new JSONModel, "internalOrderModel");
					if (sReqType === "Opportunity") {
						//fetch internal order from context
						//Models._getActExpData(this);
						let sInternalOrder1 = this.getModel().getProperty("/INTERNAL_ORDER1");
						let sInternalOrder2 = this.getModel().getProperty("/INTERNAL_ORDER2");
						let aInternalOrder = [
							sInternalOrder1 ? sInternalOrder1 : "",
							sInternalOrder2 ? sInternalOrder2 : ""
						].filter(io => io)
						this.getView().getModel("internalOrderModel").setData(aInternalOrder);
						if (aInternalOrder.length) {
							const sStep = this.getModel().getProperty("/currentStepID");
							this.getModel().setProperty("/internalOrder", aInternalOrder[0]);
							if (sStep === "MANAPP") {
								//set staffing purpose model(activities)
								Models._getActExpData(this);
								//call service for IO Owner
								// Models.getIoOwnerData(this, aInternalOrder[0]);
								//call tasklevel master data
								Models._getTaskLevelSet(this, aInternalOrder[0]);
								//get IOOwner details
								Models._getIOOwnerDetails(this, aInternalOrder[0]);
							}
						}
					}
					this.getModel().getData().isResourceProfile = (this.getModel().getData().isResourceProfile) ? true : false;
					/* Set footer model for resource profile screen*/
					const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
					const sI18nError = i18nModel.getText("Error");
					const oProfileViewModel = new sap.ui.model.json.JSONModel();
					const oProfileView = {
						"footerButtons": {
							"forwardReqButtonVisible": false,
							"searchResourceButtonVisible": false,
							"forwardReqButtonEnabled": false,
							"searchResourceButtonEnabled": false,
							"errorBtnVisible": false,
							"errorBtnType": "Negative",
							"errorBtnIcon": "sap-icon://error",
							"errorBtnText": sI18nError
						}
					}
					oProfileViewModel.setData(oProfileView);
					this.getView().setModel(oProfileViewModel, "profileViewParameters");
					const oErrorModel = new sap.ui.model.json.JSONModel();
					const oErrorData = {
						"errorInformation": []
					}
					oErrorModel.setData(oErrorData);
					this.getView().setModel(oErrorModel, "errorMsgModel");

					
					//set pfc data in initial load
						const profitCenterSorgModel = new sap.ui.model.json.JSONModel();
						this.getView().setModel(profitCenterSorgModel, "selectedProfitCenter");
						const oRoleMasterModel = new sap.ui.model.json.JSONModel();
						this.getView().setModel(oRoleMasterModel, "roleMasterData");
						const oManagerLevelMasterModel = new sap.ui.model.json.JSONModel();
						this.getView().setModel(oManagerLevelMasterModel, "managerLevelMasterData");
						Models.getManagerLevel(this);
						
					
					 //set messagestrip for IO 
					 const sStaffingMsg = this.getOwnerComponent().getModel("appConstants").getProperty("/ManualStaffing/0/Value");
					 const sStaffingMsgUrl = this.getOwnerComponent().getModel("appConstants").getProperty("/ManualStaffingURL/0/Value");
					 const sStaffingMsgUrlText = this.getOwnerComponent().getModel("appConstants").getProperty("/ManualStaffingHyperlinkText/0/Value");
					 const bStaffingUrlVisible = this.getOwnerComponent().getModel("appConstants").getProperty("/ManualStaffingHyperlinkText/0/Operational_Status");
					 let sFinalStaffingMsg;
					 if (sStaffingMsg.includes(sStaffingMsgUrlText) && bStaffingUrlVisible) {
						//message with link 
						const aSplitMsg = sStaffingMsg.split(sStaffingMsgUrlText)
						sFinalStaffingMsg = aSplitMsg[1] ? sanitizeHTML(`${aSplitMsg[0]} <a target="_blank" href="${sStaffingMsgUrl}">${sStaffingMsgUrlText}</a>${aSplitMsg[1]}`): 
             sanitizeHTML(`${aSplitMsg[0]} <a target="_blank" href="${sStaffingMsgUrl}">`)
					 } else {
						//message without link
						 sFinalStaffingMsg = sStaffingMsg;
					 }
					  //set staffing message model
					 this.getView().setModel(new JSONModel({
						 "staffingMsg": sFinalStaffingMsg
					 }), "ioWorkFlowMessageModel");
				}else{
					 this.getOwnerComponent().getRouter().navTo(
						 "NotFound"
					 );
				}
				//call resource profile master data
				const oCrossCvgModel = new sap.ui.model.json.JSONModel();
					this.getView().setModel(oCrossCvgModel, "crossCvgMasterData");
					Models.getResourceProfileMasterData("YC_OR_M_CROSSCVRG", this, "crossCoverage", true);
					const oBALobModel = new sap.ui.model.json.JSONModel();
					this.getView().setModel(oBALobModel, "baLoBMasterData");
					Models.getResourceProfileMasterData("YC_OR_M_BA_LOB", this, "businessAreaLOBPrimary", true)
					const oBAIndModel = new sap.ui.model.json.JSONModel();
					this.getView().setModel(oBAIndModel, "baIndMasterData");
					Models.getResourceProfileMasterData("YC_OR_M_BA_INDUSTRY", this, "businessAreaIndustryPrimary", true)
									},
									fetchResources: function (url, self, isCA, iStartIndex, iChunkSize, sSearchValue) {
										let sUrl;
										const that = this;
										if(sSearchValue){
											 sUrl = url;
										}else{
										    sUrl = url +  "&$top=" + iStartIndex + "&$skip=" + iChunkSize; 
										}
										
										$.ajax({
											url: sUrl,
											dataType: 'json',
											async: false,
											method: "GET",
											success: function (data) {
												const filteredData = data.d.results;
												const sNo = self.i18nModel.getText("matchNo");
												const sYes = self.i18nModel.getText("matchYes");
												
												const oResourcesModel = filteredData.map(item => ({
													match: sNo,
													fullName: item.EmpName,
													email: item.EmailId,
													userId: item.Id || item.ResourceId,
													partnerId: "",
													address: "",
													country: "",
													ManagerId: item.ManagerId,
													TrpcDesc: item.TrpcDesc,
													RoleDesc: item.RoleDesc,
													RoleAreaDesc: item.RoleAreaDesc,
													BasegDesc: item.BasegDesc,
													GroupL1: item.GroupL1,
													GroupL2: item.GroupL2,
													GroupL3: item.GroupL3,
													MgrL1NameId: `${item.ManagerName} ${item.ManagerId}`,
													BaIndDesc: item.BaIndDesc,
													SolAreaDesc: item.SolDesc,
													IacDesc: item.IacDesc,
													CrossCvrgDesc: item.CrossCvrgDesc,
													ManagerLevel: item.ManagerLevel,
													selected: false,
													enabled: true,
													btnEnabled: true,
													HubDesc: item.HubDesc
												}));
									
												const oResourceSelectionData = that.getView().getModel("ResProfileModel").getData();
												
												let aMatchResources = oResourcesModel.filter(user => {
													let sQueryParams = oResourceSelectionData
														.filter(selection => selection.queryParams !== "HubDesc")
														.map(selection => {
															let queryVal = selection.queryParams === "TrpcDesc"
																? `${that.getView().getModel().getData().selectedProfitCenter[0].Desc}-${that.getView().getModel().getData().selectedProfitCenter[0].TrpcId}`
																: selection.Desc;
															
															return queryVal.split(",").map(q => `user.${selection.queryParams}.includes("${q}")`).join(" || ");
														})
														.join(" && ");
													
													return eval(`(${sQueryParams}) && (user.ManagerLevel === "non-managerial")`);
												});
												
												const aHubs = oResourceSelectionData.filter(selection => selection.queryParams === "HubDesc");
												
												if (aHubs.length) {
													const sHubList = aHubs[0].Desc.split(",");
													aMatchResources.forEach(resource => {
														const sResourceHubs = resource.HubDesc.split(";");
														resource.match = sResourceHubs.some(hub => sHubList.includes(hub)) ? sYes : sNo;
													});
												} else {
													aMatchResources.forEach(item => item.match = sYes);
												}
												
												const uniqueFinalResources = [
								...new Map([...aMatchResources, ...oResourcesModel].map(item => [item.userId, item])).values()
							];
							
							var oModel = that.getView().getModel(isCA ? "resourcesCAModel" : "resourcesOREModel");
							var aExistingData = oModel && oModel.getData().length ? oModel.getData() : [];
							
							let uniqueUpdatedData = sSearchValue ? uniqueFinalResources : aExistingData.concat(uniqueFinalResources);
							
							const aUpdatedData = [...new Map(uniqueUpdatedData.map(item => [item.userId, item])).values()];
							
							aUpdatedData.sort((a, b) => (b.match === "Yes") - (a.match === "Yes"));
							if (sSearchValue) {
								const availableResources = self.oContextAssignmentObj.selectedNominees;
								const availablePrevResources = self.oContextAssignmentObj.PreviousSelectedNominees;
							const aResourceData = oModel.getData().availableResources ?  oModel.getData().availableResources : oModel.getData();
							if(aResourceData){
								aUpdatedData.forEach(updatedItem => {
									const matchedResource = aResourceData.find(resource => resource.userId === updatedItem.userId && resource.selected === true);
									if (matchedResource) {
										updatedItem.selected = true;
										updatedItem.enabled = matchedResource.enabled;
										updatedItem.btnEnabled = matchedResource.btnEnabled;
									}
								});
									}
									if(availableResources){
									aUpdatedData.forEach(updatedItem => {
									const matchedResource = availableResources.find(resource => resource.userId === updatedItem.userId );
									if (matchedResource) {
										updatedItem.selected = true;
										updatedItem.enabled = false;
										updatedItem.btnEnabled = false;
									}
								});
									}
									if(availablePrevResources){
									  aUpdatedData.forEach(updatedItem => {
									const matchedResource = availablePrevResources.find(resource => resource.userId === updatedItem.userId && resource.selected === true);
									if (matchedResource) {
										updatedItem.selected = true;
										updatedItem.enabled = matchedResource.enabled;
										updatedItem.btnEnabled = matchedResource.btnEnabled;
									}
								});
									}
								const sSelectedKey = that.getView().byId("idTabSegmentedButton").getSelectedKey();
								const oView = that.getView();
							
								const modelMap = {
									directReports: { model: "resourceModel", property: "/resourceHeaderCount" },
									customerAdvisory: { model: "CAModel", property: "/customerHeaderCount" }
								};
							
								if (modelMap[sSelectedKey]) {
									oView.getModel(modelMap[sSelectedKey].model).setProperty(modelMap[sSelectedKey].property, uniqueFinalResources.length);
								}
								let aPrevSelectionModel = isCA ? self.getView().getModel("resourcesCAModel").getData().filter(item => item.selected === true) : self.getView().getModel("resourcesOREModel").getData().filter(item => item.selected === true);
								let aPrevSelected = aPrevSelectionModel.length ? aPrevSelectionModel.filter(element => aUpdatedData.some(item => item.userId === element.userId)) : [];
								if(aPrevSelected.length){
									  aUpdatedData.forEach(updatedItem => {
									const matchedResource = aPrevSelected.find(resource => resource.userId === updatedItem.userId && resource.selected === true);
									if (matchedResource) {
										updatedItem.selected = true;
										updatedItem.enabled = matchedResource.enabled;
										updatedItem.btnEnabled = matchedResource.btnEnabled;
									}
								});
									}
								that.getView().setModel(new JSONModel(aUpdatedData), isCA ? "searchResourcesCAModel" : "searchResourcesOREModel");
								that.getView().getModel( isCA ? "searchResourcesCAModel" : "searchResourcesOREModel").refresh();
							}else{
								if(self.oContextAssignmentObj.selectedNominees){
									aUpdatedData.forEach(updatedItem => {
								let matchedResource = self.oContextAssignmentObj.selectedNominees.find(resource => resource.userId === updatedItem.userId && resource.selected === true);
								if (matchedResource) {
									updatedItem.selected = true;
									updatedItem.enabled = true;
								} else {
									updatedItem.selected = false;
								}
							});
								}
							that.getView().setModel(new JSONModel(aUpdatedData), isCA ? "resourcesCAModel" : "resourcesOREModel");
							}
							
											},
											error: function (error) {
												ErrorHandle.setErrorMessage(error, self);
											}
										});
									},
									
								   getCAResources: function (url, self, sSearchValue) {
								var oModel = this.getView().getModel("CAModel");
								let currentPage = oModel.getProperty("/currentCAPage") || 1;
								let itemsPerPage = 20;
								let totalCount = oModel.getProperty("/customerHeaderCount");
							
								let adjustedCount = Math.ceil(totalCount / itemsPerPage) * itemsPerPage;
								let skip = (currentPage - 1) * itemsPerPage;
							
								if(skip <= adjustedCount || !adjustedCount){
									this.fetchResources(url, self, true, itemsPerPage, skip, sSearchValue);
									currentPage++;
									oModel.setProperty("/currentCAPage", currentPage);
									skip = (currentPage - 1) * itemsPerPage;
								} 
							
								oModel.refresh();
							},			
							getResources: function (url, self, sSearchValue) {
								const workflowBaseurl = this._getOREResourcesBaseURL();
								let oModel = this.getView().getModel("resourceModel");
							
								let itemsPerPage = 20;
								let totalCount = oModel.getProperty("/resourceHeaderCount"); 
								let adjustedCount = Math.ceil(totalCount / itemsPerPage) * itemsPerPage; 
							
								let currentPage = oModel.getProperty("/currentPage") || 1;
								let skip = (currentPage - 1) * itemsPerPage;
							
								if(skip <= adjustedCount || !adjustedCount){
									this.fetchResources(url, self, false, itemsPerPage, skip, sSearchValue);
									currentPage++;
									oModel.setProperty("/currentPage", currentPage);
									skip = (currentPage - 1) * itemsPerPage;
								} 
							
								oModel.refresh();
							},
							onLiveOREChange: function(oEvent){
								 var sValue = oEvent.getParameter("newValue");
								 this.getView().byId("customerAdvisoryID").setBusy(true);
								 this.getView().byId("EmpDetailsTableID").setBusy(true);
								let isLiveSearch = true;
								let that = this;
								if (!sValue) {
								
								const sSelectedKey =  this.getView().byId("idTabSegmentedButton").getSelectedKey();
							
								switch (sSelectedKey) {
									case "directReports":
										
									this._updateCount( "resourceModel", "/resourceHeaderCount", "/resourceCount");
										this.getView().getModel("resourceModel").refresh(true);
										break;
									case "customerAdvisory":
										this._updateCount("CAModel", "/customerHeaderCount", "/customerCount");
										this.getView().getModel("CAModel").refresh(true);
										break;
									default:
										break;
								}
								that.onORESearchResources(oEvent, isLiveSearch);
								that.getView().byId("customerAdvisoryID").setBusy(false);
								that.getView().byId("EmpDetailsTableID").setBusy(false);
								}else {
									//  setTimeout(function() {
										 if (sValue.length > 2){
											  that.onORESearchResources(oEvent, isLiveSearch);
										 }
								   
										  that.getView().byId("customerAdvisoryID").setBusy(false);
										  that.getView().byId("EmpDetailsTableID").setBusy(false);
									//  },1000);
								}
							},
							onHighlightOreResourcess: function (oEvent) {
								var oTable = oEvent.getSource();
								var iFirstVisibleRow = oEvent.getParameter("firstVisibleRow");
								var iVisibleRowCount = oTable.getVisibleRowCount();
								var iTotalRows = oTable.getBinding("rows").getLength();
								if (iFirstVisibleRow + iVisibleRowCount >= iTotalRows) {
									if (this.getView().byId("idTabSegmentedButton").getSelectedKey() === "directReports") {
										const emailToFind = sap.ushell.Container.getService("UserInfo").getEmail();
										let usersArray = this.getView().getModel().getData().approverDetails;
										let userId;
							
										for (let i = 0; i < usersArray.length; i++) {
											if (usersArray[i].email === emailToFind) {
												userId = usersArray[i].userId;
												break; 
											}
										}
							
										const workflowBaseurl = this._getOREResourcesBaseURL();
										let filterResources = `?$filter=ManagerId eq '${userId}' and MelodyRequest eq 'X'&$orderby=CapEmpNme asc`;
										let sUrl = workflowBaseurl + filterResources;
										this.getResources(sUrl, this);
										this._updateAvailableResources();
							
									} else {
										const oAssignmentData = this.getView().getModel("assignmentsModel").getData().assignments;
										const oSelectedCustomers = oAssignmentData.flatMap(a => a.selectedNominees);
										const ApproversOREUrl = this._getOREApproversBaseURL();
										const OREFilterUrl = "?$filter=(MelodyRequest eq 'X')&$orderby=CapEmpNme asc";
										const serviceUrlORE = ApproversOREUrl + OREFilterUrl;
										this._updateAvailableCustomers();
									}
								}
							},
									
									loadMoreData: function () {
										var oModel = this.getView().getModel("resourceModel");
										var iCurrentLength = oModel.getProperty("/availableResources").length;
										var iNextStartIndex = iCurrentLength;
									
									   this.getResources(iNextStartIndex, 20); 
									},
				//format attachment visibility
				formatAttachmentVisibility: function (bConfig,isAttachment) {
					if (bConfig === "X" && isAttachment) {
						return true;
					} else {
						return false;
					}
				},
				_setRequestAreas: function (self, oContext) {
					//code snippet to tranform flat structure to required tree structure of request areas
					self.aSelectedReqAreas = [];
					this.detailView = self;
					const aResult = oContext.value;
					const aModel = {};
					aModel.data = this._setReqAreasTree(aResult);
					self.setModel(new JSONModel(aModel), "myPresaleModel");
					//hide selection of parent nodes and keep it only for leaf nodes
					const that = self;
					const oTree = self.byId("idTree");
					oTree.bindAggregation("items", "myPresaleModel>/data", function (sId, oContext) {
						const oLeafChild = oContext.getProperty("isLeafNode");
						that.bSelCheckbox = false;
						if (oLeafChild && oLeafChild !== " " && that.aSelectedReqAreas.length) {
							const sChildSelGUID = oContext.getProperty("GUID");
							that.aSelectedReqAreas.forEach(function (obj) {
								if (obj.GUID === sChildSelGUID) {
									that.bSelCheckbox = true;
								}
							});
						}

						const oControl =
							(oLeafChild && oLeafChild !== " ") ? new sap.m.CustomTreeItem(sId, {
								content: new sap.m.RadioButton({
									text: "{myPresaleModel>text}",
									selected: that.bSelCheckbox,
									select: that.onItemSelected.bind(that)
								})
							}) :
							new sap.m.CustomTreeItem(sId, {
								content: new sap.m.Title({
									text: "{myPresaleModel>text}"
								})
							});
						return oControl;
					});
				},
				//Request area selection
				onItemSelected: function (oEvent) {
					const sPath = oEvent.getSource().getBindingContext("myPresaleModel").sPath;
					const oTemplateDetail = this.detailView.getModel("myPresaleModel").getProperty(sPath);
					if (oEvent.getParameter("selected")) {
						//this.oCreateDialog.getBeginButton().setEnabled(true);
						this.getView().getModel("profileViewParameters").setProperty("/footerButtons/createReqButtonEnabled", true);
						this.getView().getModel("profileViewParameters").refresh();
						const oSelectedReqArea = {
							"GUID": oTemplateDetail.GUID,
							"requestArea": oTemplateDetail.PresalesRequestArea,
							"requestAreaPath": oTemplateDetail.PresalesRequestAreaPath
						};
						this.detailView.aSelectedReqAreas.push(oSelectedReqArea);
					} else {
						this.detailView.aSelectedReqAreas = this.detailView.aSelectedReqAreas.filter(function (obj) {
							return obj.GUID !== oTemplateDetail.GUID;
						});
					}
					if (!this.detailView.aSelectedReqAreas.length) {
						//this.oCreateDialog.getBeginButton().setEnabled(false);
						this.getView().getModel("profileViewParameters").setProperty("/footerButtons/createReqButtonEnabled", false);
						this.getView().getModel("profileViewParameters").refresh();
					}
					const bBtnEnable = (this.detailView.aSelectedReqAreas.length > 0);
					//	this.dialog.getButtons()[0].setEnabled(bBtnEnable);
				},
				// Helper function to manage the lazy loading of views
				_loadView: function (options) {
					let mViews = this._mViews = this._mViews || Object.create(null);
					if (!mViews[options.id]) {
						mViews[options.id] = this.getOwnerComponent().runAsOwner(function () {
							return XMLView.create(options);
						});
					}
					return mViews[options.id];
				},

				onSelectInternalOrder: function (oEvent) {
					const iInternalOrder = oEvent.getSource().getBindingContext("assignmentsModel").getObject().internalOrder;
					//Call the tasklevelSet 
					Models._getTaskLevelSet(this, iInternalOrder);
					//call io owner service
					// Models._getIoOwnerData(this,iInternalOrder);
					Models._getIOOwnerDetails(this, iInternalOrder);
				},
				_fetchFormActions: function (self) {
					const sOrgID = 'ParentOrgID' in self.getModel().getData() ? self.getModel().getProperty("/ParentOrgID") : self.getModel().getProperty(
						"/OrgID");
					const sOrgType = self.getModel().getProperty("/OrgType");
					const sCurrentStepName = self.getModel().getProperty("/currentStepID");
					const sUserTask = (sCurrentStepName === "MANAPP") ? "Manager" : "Resource";
					const sFormatOrgID = self._getOrgIDnumber(sOrgID, sOrgType);
					const sUrl = self._getRuntimeBaseURL() +
						`/resources/req-area-api-/Action?$filter=(orgID eq '${sFormatOrgID}' and orgType eq '${sOrgType}') and (UserTask eq '${sUserTask}')`;
					$.ajax({
						contentType: "application/json",
						url: sUrl,
						async: false,
						type: "GET",
						success: function (oData) {
							const aFormActionsValues = oData.value;
							const oFormValue = aFormActionsValues.reduce(function (formVal, val) {
								(formVal[val.Action_ID] = formVal[val.Action_ID] || []).push(val);
								return formVal;
							}, {})
							const oFormActionsConfigModel = new JSONModel(oFormValue);
							self.getView().setModel(oFormActionsConfigModel, "formActionsConfigModel");

						},
						error: function (oError) {

						}
					});
				},
				_getOrgIDnumber: function (sOrgID, sOrgType) {
					if (sOrgType === "SORG") {
						return Number(sOrgID.replace('SORG-', '')).toString();
					} else {
						return sOrgID;
					}
				},
				//set form configurable model
				_fetchFormConfigData: function (self) {
					const sOrgID = 'ParentOrgID' in self.getModel().getData() ? self.getModel().getProperty("/ParentOrgID") : self.getModel().getProperty(
						"/OrgID");
					const sOrgType = self.getModel().getProperty("/OrgType");
					const sFormatOrgID = self._getOrgIDnumber(sOrgID, sOrgType);
					const sUrl = self._getRuntimeBaseURL() +
						`/resources/req-area-api-/Form_Tab?$expand=Fields&&$filter=orgID eq '${sFormatOrgID}' and orgType eq '${sOrgType}'`;

					$.ajax({
						contentType: "application/json",
						url: sUrl,
						async: false,
						type: "GET",
						success: function (oData) {
							let aDataNew = [];

							for (let i = 0; i < oData.value.length; i++) {
								if (!aDataNew[oData.value[i].ID]) {
									aDataNew[oData.value[i].ID] = [];
								}
								aDataNew[oData.value[i].ID] = oData.value[i];
								let aDataNewFields = [];
								for (let j = 0; j < oData.value[i].Fields.length; j++) {

									if (!aDataNew[oData.value[i].Fields[j].ID]) {
										aDataNewFields[oData.value[i].Fields[j].ID] = [];
									}
									aDataNewFields[oData.value[i].Fields[j].ID] = oData.value[i].Fields[j];
									// aDataNew[oConfigData.value[i].ID].Fields = aDataNewFields[oConfigData.value[i].Fields[j].ID
								}
								aDataNew[oData.value[i].ID].Fields = aDataNewFields;
							}
							const oFormConfigModel = new JSONModel(aDataNew);
							self.getView().setModel(oFormConfigModel, "formConfigModel");
						},
						error: function (oError) {

						}
					});
				},
				formatFormConfigVisibility: function (sVal) {
					if (sVal === "X") {
						return true;
					} else {
						return false;
					}
				},
				formatTimeInvestmentVisibility: function (sVal,bExpectedTimeInvestment) {
					if (sVal === "X" && bExpectedTimeInvestment) {
						return true;
					} else {
						return false;
					}
				},
				formatFormConfigReqAreaVisibility(sVal, isResourceProfile) {
					return sVal === "X" && !(isResourceProfile);
				},
				formatFieldForNonRise: function (isRise, formVisibility) {
					if (formVisibility === "X") {
						const isRiseVisibility = !isRise;
						return isRiseVisibility;
					} else {
						return false;
					}
				},
				formatFieldBasedOnMultipleProperties: function (bVal, formVisibility) {
					if (formVisibility === "X") {
						return bVal;
					} else {
						return false;
					}
				},
				formatFieldSelectField: function (bVal, formVisibility, isMeetingPlanned) {
					if (formVisibility && isMeetingPlanned) {
						return bVal;
					} else {
						return false;
					}
				},
				parseGetOppDataResponse: function (data) {
					if (data) {
						const oDealInfo = {
							accName: data.ACCOUNT_NAME,
							oppName: data.DESCRIPTION,
							decision: data.DECISION,
							reviewerName: data.DQReview.REVIEWER1_NAME,
							forecast: data.FORECAST,
							onPremRevenue: data.LICENSE_REVENUE,
							cloudRevenue: data.CLOUD_REVENUE,
							currency: data.CURRENCY,
							CURR_PHASE: data.CURR_PHASE,
							STATUS: data.STATUS,
							TCV: data.Items.results.length ? data.Items.results[0].TOTAL_TCV : ""
						};

						//set dates
						const jsonClosingDate = data.EXPECT_END,
							closingDateFull = jsonClosingDate ? new Date(parseInt(jsonClosingDate.substr(6))) : null;
						oDealInfo.closingDate = closingDateFull;

						const jsonReviewDate = data.DQReview.REVIEW_DATE1,
							reviewDateFull = jsonReviewDate ? new Date(parseInt(jsonReviewDate.substr(6))) : null;
						oDealInfo.reviewDate = reviewDateFull;

						//process Notes
						const aNotes = data.Notes.results;
						for (let i = 0; i < aNotes.length; i++) {
							switch (aNotes[i].TDID) {
							case "ZD01":
								oDealInfo.compelEventText = aNotes[i].CONC_LINES;
								break;
							case "ZD02":
								oDealInfo.fundingText = aNotes[i].CONC_LINES;
								break;
							case "ZD03":
								oDealInfo.custStakeText = aNotes[i].CONC_LINES;
								break;
							case "ZD04":
								oDealInfo.custChallengesText = aNotes[i].CONC_LINES;
								break;
							case "ZD05":
								oDealInfo.custBusDriversText = aNotes[i].CONC_LINES;
								break;
							case "ZD06":
								oDealInfo.solutionText = aNotes[i].CONC_LINES;
								break;
							case "ZD07":
								oDealInfo.competitorsText = aNotes[i].CONC_LINES;
								break;
							case "ZD08":
								oDealInfo.partnersText = aNotes[i].CONC_LINES;
								break;
							case "ZD10":
								oDealInfo.execSummary = aNotes[i].CONC_LINES;
								break;
							default:
							}
						}

						//process Attributes
						const aAttributes = data.Attributes.results;
						for (let i = 0; i < aAttributes.length; i++) {
							switch (aAttributes[i].ATTR_CODE) {
							case "AS0103":
								oDealInfo.compelEventQual = aAttributes[i].ATTR_VALUE;
								break;
							case "AS0104":
								oDealInfo.fundingQual = aAttributes[i].ATTR_VALUE;
								break;
							case "AS0105":
								oDealInfo.custStakeQual = aAttributes[i].ATTR_VALUE;
								break;
							case "AS0106":
								oDealInfo.custChallengesQual = aAttributes[i].ATTR_VALUE;
								break;
							case "AS0107":
								oDealInfo.custBusDriversQual = aAttributes[i].ATTR_VALUE;
								break;
							case "AS0108":
								oDealInfo.solutionQual = aAttributes[i].ATTR_VALUE;
								break;
							case "AS0109":
								oDealInfo.competitorsQual = aAttributes[i].ATTR_VALUE;
								break;
							case "AS0110":
								oDealInfo.partnersQual = aAttributes[i].ATTR_VALUE;
								break;
							case "AS0132":
								oDealInfo.decision = aAttributes[i].ATTR_VALUE;
								break;
							case "AS0133":
								oDealInfo.reviewerName = aAttributes[i].ATTR_DESCR;
								break;
							case "AS0134":
								oDealInfo.reviewDate = new Date(aAttributes[i].ATTR_VALUE.slice(0, 4) + "-" + aAttributes[i].ATTR_VALUE.slice(4, 6) + "-" +
									aAttributes[i].ATTR_VALUE.slice(-2));
								break;
							default:
							}
						}

						oDealInfo.attributes = aAttributes;

						this.getModel().setProperty("/dealInfo", oDealInfo);
						this.getModel().refresh();
					}
				},

				configureView: function (sStep) {
					const startupParameters = this.getComponentData().startupParameters;
					const approveText = this.getMessage("APPROVE");
					const rejectText = this.getMessage("REJECT");
					const sendBackText = this.getMessage("SEND_BACK_TO_REQUESTOR");
					const forwardText = this.getMessage("FORWARD");
					const taskInstanceModel = this.getModel("taskInstanceModel");
					const sSubject = taskInstanceModel.getData().subject;
					const bResReject = this.getModel().getData().ResReject;
					this.byId("presalesRequestApprovalPageHeader").setText(sSubject);
					this.byId("presalesRequestApprovalSnappedPageHeader").setText(sSubject);
					const oFormActionsModelData = this.getView().getModel("formActionsConfigModel").getData();

					const oThisController = this;

					/**

/**
* APPROVE REQUEST BUTTON
*/
					// Implementation for the approve action
					this.oApproveAction = {
						sBtnTxt: approveText,
						onBtnPressed: function () {
							const model = oThisController.getModel();
							model.refresh(true);
							if (sStep === "MANAPP") {
								if (oThisController.getView().getModel().getData().ResReject !== true) {
									const saveAndSubmitText = oThisController.getMessage("SAVEANDSUBMIT");
									const oControlAssignmentTab = oThisController.getView().byId("idAssignmentsSection");
									oThisController.onAddNewAssignment();
									oControlAssignmentTab.setVisible(true);
									const oAssignmentsection = oThisController.getView().byId("idObjPageLayout").getSections()[5];
									oThisController.getView().byId("idObjPageLayout").setSelectedSection(oAssignmentsection);

									// Implementation for the save and submit action for Assignment
									const startupParameters = oThisController.getComponentData().startupParameters;
									const oSaveAndSubmitAssignment = {
										sBtnTxt: saveAndSubmitText,
										visible: "false",
										onBtnPressed: function () {
											oThisController._onValidateAssignment();
										}
									};
									if (oThisController.getModel().getData().RequestType == "Opportunity") {
										oThisController.getView().byId("idAssignmntPanel").setVisible(true);
										oThisController.getView().byId("idAdminTable").setVisible(false);
									} else {
										oThisController.getView().byId("idAdminTable").setVisible(true);
										oThisController.getView().byId("idAssignmntPanel").setVisible(false);
									}
									// Add 'Save and Submit' action to the task
									startupParameters.inboxAPI.addAction({
											action: "saveAndSubmit",
											label: oSaveAndSubmitAssignment.sBtnTxt,
											type: "Accept"
										},
										// Set the onClick function
										oSaveAndSubmitAssignment.onBtnPressed);
									// startupParameters.inboxAPI.disableAction("saveAndSubmit");
									// Implementation for the cancel action for Assignment
									const cancelApproveText = oThisController.getMessage("CANCELAPPROVER");
									const oCancelSaveAndSubmitAssignment = {
										sBtnTxt: cancelApproveText,
										onBtnPressed: function () {
											const oFormActionsModelData = oThisController.getView().getModel("formActionsConfigModel").getData();
											const oAssignmentsReset = {
												"assignments": []
											}
											oThisController.getView().getModel("assignmentsModel").setData(oAssignmentsReset);
											oThisController.getView().getModel("assignmentsModel").refresh(true);
											oThisController.getView().byId("idAssignmentsSection").setVisible(false);
											const oReqDetSection = oThisController.getView().byId("idObjPageLayout").getSections()[0];
											oThisController.getView().byId("idObjPageLayout").setSelectedSection(oReqDetSection);

											const startupParameters = oThisController.getComponentData().startupParameters;
											// Add 'Approve' action to the task
											if (oFormActionsModelData.idapprove[0].Visibility === "X") {
												startupParameters.inboxAPI.addAction({
														action: oFormActionsModelData.idapprove[0].Label,
														label: oFormActionsModelData.idapprove[0].Label,
														type: "Accept"
													},
													// Set the onClick function
													oThisController.oApproveAction.onBtnPressed);
											};

											// Add 'Reject' action to the task
											if (oFormActionsModelData.idreject[0].Visibility === "X") {
												startupParameters.inboxAPI.addAction({
													action: oFormActionsModelData.idreject[0].Label,
													label: oFormActionsModelData.idreject[0].Label,
													type: "Reject"
												}, oThisController.oRejectAction.onBtnPressed);
											};

											// Add 'Forward' action to the task
											if (oFormActionsModelData.idforward[0].Visibility === "X") {
												startupParameters.inboxAPI.addAction({
														// confirm is a positive action
														action: oFormActionsModelData.idforward[0].Label,
														label: oFormActionsModelData.idforward[0].Label
													},
													// Set the onClick function
													oThisController.oForwardAction.onBtnPressed);
											}

											// Add 'Rework' action to the task
											if (oFormActionsModelData.idrework[0].Visibility === "X") {
												startupParameters.inboxAPI.addAction({
														// confirm is a positive action
														action: oFormActionsModelData.idrework[0].Label,
														label: oFormActionsModelData.idrework[0].Label
													},
													// Set the onClick function
													oThisController.oReworkAction.onBtnPressed);
											}
											startupParameters.inboxAPI.removeAction("Cancel");
											startupParameters.inboxAPI.removeAction("saveAndSubmit");
											oThisController._hideMyInboxFooterBtns(oThisController);
										}
									};
									startupParameters.inboxAPI.removeAction(oFormActionsModelData.idapprove[0].Label);
									startupParameters.inboxAPI.removeAction(oFormActionsModelData.idreject[0].Label);
									startupParameters.inboxAPI.removeAction(oFormActionsModelData.idforward[0].Label);
									startupParameters.inboxAPI.removeAction(oFormActionsModelData.idrework[0].Label);
									// Add Cancel action to the task
									startupParameters.inboxAPI.addAction({
											action: "Cancel",
											label: oCancelSaveAndSubmitAssignment.sBtnTxt,
											type: "Default",
											onBtnPressed: function () {}
										},
										// Set the onClick function
										oCancelSaveAndSubmitAssignment.onBtnPressed);
								} else {
									oThisController._onValidateAssignment();
								}

							} else {
								//resource approval
								const sReqType = oThisController.getModel().getProperty("/RequestType");
								const bIsIOStaffing = oThisController._getLoggedInUserAssignmentObj(oThisController).isIOStaffing;
								const isAutoStaffing = oThisController._getLoggedInUserAssignmentObj(oThisController).isAutoStaffing;
								const sUserId = oThisController._getLoggedInUserAssignmentObj(oThisController).userId;
								const sCompanyCode = oThisController._getLoggedInUserAssignmentObj(oThisController).sCompanyCode;
								const sCostCenter = oThisController._getLoggedInUserAssignmentObj(oThisController).sCostCenter;
								//Check the staffing
								if (sReqType === "Opportunity" && bIsIOStaffing) {
									//check !isAutoStaffing--> not staffed
									if (!isAutoStaffing) {
										const orgType =  oThisController.getModel().getProperty("/OrgType");
										const sOrgID =(orgType !== "PC") ? oThisController.getModel().getProperty("/OrgID"):oThisController.getModel().getProperty("/oppOrgId");
										const sFinalOrgID = oThisController.getModel().getProperty("/oppOrgId") ?  oThisController.getModel().getProperty("/oppOrgId"):oThisController.getModel().getProperty("/OrgID");
										const sSalesOrg = sFinalOrgID.replace('SORG-', '');
										if (sCompanyCode === sSalesOrg) {
											//company code of the resources matches sales org of the opportunity
											oThisController.isAutoStaffingCompanyCode = true;
											let oAssignment = oThisController._getLoggedInUserAssignmentObj(oThisController);
											oAssignment.isAutoStaffingCompanyCode = true;
											//Call userSearchHelps to fetch the perner number for staffing
											Models._callUserSearchHelps(sUserId, oThisController, oThisController.fnSuccessUserSearchHelpsCallBack, oThisController.fnErrorUserSearchHelpsCallBack,
												oAssignment);
										} else {
											oThisController.isAutoStaffingCompanyCode = false;
											//check exception table maintained
											Models._callExceptionTable(sCompanyCode, sCostCenter, sSalesOrg, sUserId, oThisController, oThisController.fnExceptionSuccessCallback,
												oThisController.fnExceptionErrorCallback, false);
										}
									} else {
										//Proceed wf trigger
										oThisController._onFinalSubmitWf(oThisController);
									}
								} else {
									//IO Staffing false --> Proceed wf trigger
									oThisController._onFinalSubmitWf(oThisController);
								}
							}
							oThisController._hideMyInboxFooterBtns(oThisController);
						}
					
					};
					// Add 'Approve' action to the task
					if (oFormActionsModelData.idapprove[0].Visibility === "X" && !bResReject) {
						startupParameters.inboxAPI.addAction({
								action: oFormActionsModelData.idapprove[0].Label,
								label: oFormActionsModelData.idapprove[0].Label,
								type: "Accept"
							},
							// Set the onClick function
							this.oApproveAction.onBtnPressed);
					};
					/**
					 * SAVE AND SUBMIT BUTTON
					 */
					if (oThisController.getModel().getProperty("/currentStepID") === "MANAPP" && bResReject) {
						let saveAndSubmitText = oThisController.getMessage("SAVEANDSUBMIT");
						let oSaveAndSubmit = {
							sBtnTxt: saveAndSubmitText,
							onBtnPressed: function () {
								oThisController._onValidateAssignment();
							}
						};
						// Add 'Save and Submit' action to the task
						startupParameters.inboxAPI.addAction({
							action: "saveAndSubmit",
							label: oSaveAndSubmit.sBtnTxt,
							type: "Accept"
						},
							// Set the onClick function
							oSaveAndSubmit.onBtnPressed);
					}
					/**
					 * 
					 * REJECT BUTTON
					 */
					// Implementation for the approve action
					this.oRejectAction = {
						sBtnTxt: rejectText,
						onBtnPressed: function () {
							const oModel = oThisController.getModel();
							oModel.refresh(true);
							const processContext = oModel.getData();
							// Call a local method to perform further action
							oThisController._openSubmitDialog(
								processContext,
								startupParameters.taskModel.getData().InstanceID,
								"Reject",
								sStep
							);
						}
					};
					// Add 'Reject' action to the task
					if (oFormActionsModelData.idreject[0].Visibility === "X") {
						const sbtnType = oThisController.getModel().getProperty("/currentStepID") === "MANAPP" ?"Reject":"Default";
						startupParameters.inboxAPI.addAction({
							action: oFormActionsModelData.idreject[0].Label,
							label: oFormActionsModelData.idreject[0].Label,
							type:sbtnType,
						}, this.oRejectAction.onBtnPressed);
					};

					/**
					 * REWORK BUTTON
					 */
					// Implementation for the rework action
					this.oReworkAction = {
						sBtnTxt: sendBackText,
						onBtnPressed: function (oEvent) {
							const oModel = oThisController.getModel();
							oModel.refresh(true);
							const processContext = oModel.getData();

							// Call a local method to perform further action
							oThisController._openSubmitDialog(
								processContext,
								startupParameters.taskModel.getData().InstanceID,
								"Send Back to Requestor",
								sStep
							);
						}
					};
					// Add 'Rework' action to the task
					if (bResReject !== true) {
						if (oFormActionsModelData.idrework[0].Visibility === "X") {
							startupParameters.inboxAPI.addAction({
									// confirm is a positive action
									action: oFormActionsModelData.idrework[0].Label,
									label: oFormActionsModelData.idrework[0].Label
								},
								// Set the onClick function
								this.oReworkAction.onBtnPressed);
						}
					};
					/**
					 * FORWARD BUTTON
					 */
					// Implementation for the forward action
					if (sStep === 'MANAPP') {
						this.oForwardAction = {
							sBtnTxt: forwardText,
							onBtnPressed: function (oEvent) {
								const oModel = oThisController.getModel();
								oModel.refresh(true);
								const processContext = oModel.getData();
								if (oModel.getData().isResourceProfile) {
									oThisController._forwardActionDialog(
										oEvent,
										processContext,
										startupParameters.taskModel.getData().InstanceID,
										"Forward",
										sStep
									);
								} else {
									oThisController.onResourceProfileSelectionPress(true)
								}

							}
						};
						// Add 'Forward' action to the task
						if (bResReject !== true) {
							if (oFormActionsModelData.idforward[0].Visibility === "X") {
								startupParameters.inboxAPI.addAction({
										// confirm is a positive action
										action: oFormActionsModelData.idforward[0].Label,
										label: oFormActionsModelData.idforward[0].Label
									},
									// Set the onClick function
									this.oForwardAction.onBtnPressed);
							}
						}
					}
				},
				_setDecision:function(sDecision){
					let sDecisionText;
					switch(sDecision) {
						case "Approve":
							sDecisionText = this.getView().getModel("formActionsConfigModel").getData().idapprove[0].Label;
						  break;
						case "Forward":
							sDecisionText = this.getView().getModel("formActionsConfigModel").getData().idforward[0].Label;
						  break;
						case "Reject":
							sDecisionText = this.getView().getModel("formActionsConfigModel").getData().idreject[0].Label;
						  break;
						case "Send Back to Requestor":
							sDecisionText= this.getView().getModel("formActionsConfigModel").getData().idrework[0].Label;
						  break;
						default:
							sDecisionText= ""
						  break;
					  }
					  return sDecisionText;
				},
				_forwardActionDialog: function (oEvent, processContext, taskId, sDecision, oPresalesData) {
					const oevt = oEvent.getSource();
					let oView = this.getView();
					if (!this._pActionSheetFragment) {
						this._pActionSheetFragment = Fragment.load({
							id: oView.getId(),
							name: "com.sap.bpm.PresalesRequestApproval.fragments.ForwardActionSheetFragment",
							controller: this
						}).then(function (oActionSheet) {
							oView.addDependent(oActionSheet);
							return oActionSheet;
						});
					}
					this._pActionSheetFragment.then(function (oActionSheet) {
						oActionSheet.openBy(oevt);
					});
				},
				onNamedContactsPress: function () {
					let oView = this.getView();
					let that = this;
				
					this.getView().getModel("profileViewParameters").setProperty("/footerButtons/errorBtnVisible", false);
					this.getView().setModel(new sap.ui.model.json.JSONModel({ ApproverDetails: [] }), "selectedOREModel");
				
					if (!this._pCreateReqDialog) {
						this._pCreateReqDialog = Fragment.load({
							id: oView.getId(),
							name: "com.sap.bpm.PresalesRequestApproval.fragments.NamedContactsListFragment",
							controller: this
						}).then(function (oNamedContactDialog) {
							that.oNamedContactDialog = oNamedContactDialog;
							oView.addDependent(oNamedContactDialog);
							return oNamedContactDialog;
						}).catch(function (error) {
						});
					}
				
					this._pCreateReqDialog.then(function (oNamedContactDialog) {
						that.getView().byId("idForwardNamedContact").setEnabled(false);
						oNamedContactDialog.addStyleClass(that.getOwnerComponent().getContentDensityClass());
						oNamedContactDialog.open();
						sap.ui.core.BusyIndicator.show(0);
						that.byId("idMultiInputORE").setVisible(false);
						// that.getView().setModel(new sap.ui.model.json.JSONModel(), "selectedOREModel");
				
						that.currentPageORE = 0;
						that.itemsPerPage = 20;
						that.isFetchingData = false;
				
						const ApproversOREUrl = that._getOREApproversBaseURL();
						const OREFilterUrl = "?$filter=(MelodyRequest eq 'X')&$orderby=CapEmpNme asc";
						const serviceUrlORE = ApproversOREUrl + OREFilterUrl;
				
						that.loadData(serviceUrlORE, that.itemsPerPage, 0);
				
						let oScrollContainer = that.getView().byId("idListORE").getParent();
						
						if (oScrollContainer) {
							oScrollContainer.attachBrowserEvent("scroll", function () {
								let domRef = oScrollContainer.getDomRef();
								if (!that.isFetchingData && domRef.scrollTop + domRef.clientHeight >= domRef.scrollHeight - 10) {
									that.isFetchingData = true;
									that.loadMoreData(serviceUrlORE);
								}
							});
						}
					});
				},
				
				loadData: function (url, top, skip) {
					var that = this;
					that.getNamedContactsData(url, top, skip)
						.then(function (data) {
							let oResourceModel = that.getView().getModel("resourceModelORE");
							let aExistingData = oResourceModel ? oResourceModel.getData().ApproverDetails || [] : [];
				
							const valueORE = data.d.results;
							const approverDetails = valueORE.map(function (obj) {
								return {
									fullName: obj.EmpName,
									ID: obj.Id,
									email: obj.EmailId,
									to_substitute:obj.to_nmdsubstitute
								};
							});
				
							const uniqueData = [...aExistingData, ...approverDetails].reduce((acc, obj) => {
								if (!acc.some(item => item.ID === obj.ID)) {
									acc.push(obj);
								}
								return acc;
							}, []);
				
							if (!oResourceModel) {
								oResourceModel = new sap.ui.model.json.JSONModel();
								that.getView().setModel(oResourceModel, "resourceModelORE");
							}
				
							oResourceModel.setData({
								ApproverDetails: uniqueData
							});
				
							that.currentPageORE++;
							that.isFetchingData = false;
						})
						.catch(function (error) {
							that.isFetchingData = false;
						});
				},
				
				loadMoreData: function (url) {
					let skip = this.currentPageORE * this.itemsPerPage;
					this.loadData(url, this.itemsPerPage, skip);
				},
				
				getNamedContactsData: function (url, top, skip) {
					return new Promise(function (resolve, reject) {
						$.ajax({
							url: `${url}&$top=${top}&$skip=${skip}&$expand=to_nmdsubstitute`,
							dataType: 'json',
							method: "GET",
							success: function (data) {
								resolve(data);
								sap.ui.core.BusyIndicator.hide();
							},
							error: function (error) {
								reject(error);
							}
						});
					});
				},
				
						loadInitialContent: function () {
							let oSegmentedButton = this.getView().byId("segmentedButton");
							oSegmentedButton.fireSelectionChange({
								selectedItem: oSegmentedButton.getItems()[0]
							});
						},
						onCloseNamedContact: function () {
							const that = this;
							this._pCreateReqDialog.then(function (oDialog) {
						that.getView().setModel(new sap.ui.model.json.JSONModel({ ApproverDetails: [] }), "selectedOREModel");
						that.getView().setModel(new sap.ui.model.json.JSONModel({ ApproverDetails: [] }), "resourceModelORE");
				
						let oListORE = that.byId("idListORE");
						if (oListORE) oListORE.removeSelections();
				
						let oSearchORE = that.byId("idSearchORE");
						if (oSearchORE) oSearchORE.setValue("");
						if (oListORE) oListORE.getBinding("items").filter([]);
				
								oDialog.close();
							});
						},
						onConfirmNamedContact: function () {
					
					let oList = this.byId("idListORE");
					let sModelName = "resourceModelORE";
				
					let aSelectedItems = this.getView().getModel("selectedOREModel").getProperty("/ApproverDetails");
							let aSubstituteFinalApprover = this._getSubstituteDetails(aSelectedItems, false, true);
							let uniqueSubs = Array.from(new Map(aSubstituteFinalApprover.map(aSubstituteFinalApprover => [aSubstituteFinalApprover.ID, aSubstituteFinalApprover])).values());
							let aFinalApprovers = aSubstituteFinalApprover.length ? aSelectedItems.concat(aSubstituteFinalApprover) : aSelectedItems;
							const uniqueApprovers = [...new Map(aFinalApprovers.map(item => [item.ID, item])).values()];
							let aUniqueListApprovers = [...new Map(aSelectedItems.map(item => [item.ID, item])).values()];

				
					this.getView().getModel().getData().aResourceProfileApprovers.ApproverDetails = uniqueApprovers;
					this.getView().getModel().setProperty("/aResourceProfileApprovers/SubstituteApproverDetails", uniqueSubs);
					this.getView().getModel().setProperty("/aResourceProfileApprovers/aApprovers", aUniqueListApprovers);
				
					this.onForwardRequest("namedContact");
					this.onCloseNamedContact();
				
						},
				onSegmentedButtonSelect: function (oEvent) {
					sap.ui.core.BusyIndicator.show(0);
					let sSelectedKey;
					var that = this;
					if (oEvent.getParameters().item && oEvent.getParameters().item.getProperty("key")) {
						sSelectedKey = oEvent.getParameters().item.getProperty("key");
					} else if (oEvent.getParameters().selectedItem && oEvent.getParameters().selectedItem.getProperty("key")) {
						sSelectedKey = oEvent.getParameters().selectedItem.getProperty("key");
					}
					this.getView().byId("idForwardNamedContact").setEnabled(false);
					this.byId("idMultiInputBs").setVisible(false);
					this.byId("idMultiInputORE").setVisible(false);
					const oListContainerResources = this.getView().byId("listContainerResources");
					const oListContainerORE = this.getView().byId("listContainerORE");
					const getBSurl = this._getApproversBaseURL(this);
					const sProfitcenter = "";
					const bSFilterurl = "?$filter=(TableTypeId%20eq%20%270002%27) and (RecordStatus eq '01')";
					const serviceUrlBS = getBSurl + bSFilterurl;
					const ApproversOREUrl = this._getOREApproversBaseURL(this);
					// const sSearchOre = "?search=Approvers";
					const OREFilterurl = "?$filter=(MelodyRequest eq 'X')";
					const serviceUrlORE = ApproversOREUrl + OREFilterurl;
					let currentPageBS = 1;
					let currentPageORE = 1;
					let itemsPerPage = 20;
		
					let listContainerBS = this.getView().byId("listContainerResources");
					let listContainerORE = this.getView().byId("listContainerORE");
		
					listContainerBS.attachBrowserEvent("scroll", function () {
						if (listContainerBS.getDomRef().scrollHeight - listContainerBS.getDomRef().clientHeight === listContainerBS.getDomRef().scrollTop) {
							loadNextPage("resources");
						}
					});
		
					listContainerORE.attachBrowserEvent("scroll", function () {
						if (listContainerORE.getDomRef().scrollHeight - listContainerORE.getDomRef().clientHeight === listContainerORE.getDomRef().scrollTop) {
							loadNextPage("ore");
						}
					});
		
					function loadNextPage(selectedKey) {
						const skip = (selectedKey === "resources") ? currentPageBS * itemsPerPage : currentPageORE * itemsPerPage;
						const serviceUrl = (selectedKey === "resources") ? serviceUrlBS : serviceUrlORE;
						loadData(serviceUrl, itemsPerPage, skip, selectedKey);
					}
		
					if (sSelectedKey === "resources") {
						oListContainerResources.setVisible(true);
						oListContainerORE.setVisible(false);
		
						loadData(serviceUrlBS, itemsPerPage, 0, "resources");
					} else if (sSelectedKey === "ore") {
						oListContainerResources.setVisible(false);
						oListContainerORE.setVisible(true);
		
						loadData(serviceUrlORE, itemsPerPage, 0, "ore");
					}
		
					function loadData(url, top, skip, selectedKey) {
						that.getNamedContactsData(url, top, skip)
							.then(function (data) {
								const approverArray = [];
								const oResourceModel = new sap.ui.model.json.JSONModel();
		
								if (selectedKey == "resources") {
									const value = data.d.results;
									const aFinalApprovers = [];
									value.forEach(function (obj) {
										if (obj.UserTypeId == "0001") {
											aFinalApprovers.push(obj);
										}
									});
		
		
									const approverInfo = users.getUserInfo(aFinalApprovers, that, true);
									//remove duplicates and update profitcenter
									const uniqueBSResources = approverInfo.reduce((approver, user) => {
										if (!approver.find(u => u.ID === user.ID)) {
											const aFilteredUserId = approverInfo.filter((resource) => resource.ID === user.ID);
											aFilteredUserId.map(resource => resource.ProfitCenterDetails.formattedDesc).join(",")
											approver.push(user);
										}
										return approver
									}, []);
									oResourceModel.setData({
										ApproverDetails: uniqueBSResources
									});
									that.getView().setModel(oResourceModel, "resourceModelBS");
									currentPageBS++;
								} else if (selectedKey == "ore") {
		
									const valueore = data.d.results;
		
									const approverDetails = valueore.map(function (obj) {
										return {
											fullName: obj.EmpName,
											ID: obj.Id,
											email: obj.EmailId
										};
									});
									const uniqueData = approverDetails.reduce((acc, obj) => {
										if (!acc.some(item => item.ID === obj.ID)) {
										  acc.push(obj);
										}
										return acc;
									  }, []);
									oResourceModel.setData({
										ApproverDetails: uniqueData
									});
									that.getView().setModel(oResourceModel, "resourceModelORE");
		
									currentPageORE++;
								}
		
							}.bind(this))
							.catch(function (error) {
								Models._setErrorMsgPopOver(that, "namedContacts", error, false, "namedContact");
							});
					}
				},
				_setSelectedNamedContactModel: function (oList) {
					const aSelectedManager = [];

					oList.forEach(function (manager) {
						aSelectedManager.push(manager.getObject())
					});
					return aSelectedManager

				},
				onSelectNamedApprovers: function (oEvent) {
					const aManagerModel = new JSONModel();
					
					let oList, oMultiInput, sModelName;
				
						oList = this.byId("idListORE");
						oMultiInput = this.byId("idMultiInputORE");
						sModelName = "resourceModelORE";
				  
				
					const aSelectedContext = oList.getSelectedContexts(sModelName);
					const aSelectedManager = this._setSelectedNamedContactModel(aSelectedContext);
				
					const oSelectedModel = this.getView().getModel("selectedOREModel");
							if(oEvent.getParameter("listItem").getProperty("selected")){
								 oSelectedModel.getProperty("/ApproverDetails").push(oEvent.getParameter("listItem").getBindingContext("resourceModelORE").getObject());
							}else{
								let sUserId = oEvent.getParameter("listItem").getProperty("number");
								let aFinalUsers = oSelectedModel.getProperty("/ApproverDetails").length ? oSelectedModel.getProperty("/ApproverDetails").filter(item => item.ID !== sUserId) : [];
								aFinalUsers.length ? oSelectedModel.setProperty("/ApproverDetails" , aFinalUsers) : oSelectedModel.setProperty("/ApproverDetails" , []);
							}
				   
							
					oSelectedModel.refresh();
				
					const bHasSelection = oSelectedModel.getProperty("/ApproverDetails").length  > 0;
					this.getView().byId("idForwardNamedContact").setEnabled(bHasSelection);
					oMultiInput.setVisible(bHasSelection);
						},
				
				onDeleteBSToken: function (oEvent) {
					const oModel = this.getView().getModel("selectedBSModel");
					const oApproversBS = oModel.getProperty("/ApproverDetails");
					const oParameters = oEvent.getParameters();
					if (oParameters.type === "removed") {
						const aTokens = oParameters.removedTokens;
						for (let i = 0; i < aTokens.length; i++) {
							const iIndex = oApproversBS.findIndex(item => item.ID === aTokens[i].getKey());
							if (iIndex !== -1) {
								oApproversBS.splice(iIndex, 1);
								oModel.refresh(true);
							}
						}
					}
					if (!oApproversBS.length) {
						this.byId("idMultiInputBs").setVisible(false);
						this.getView().byId("idForwardNamedContact").setEnabled(false);
					} else {
						this.byId("idMultiInputBs").setVisible(true);
						this.getView().byId("idForwardNamedContact").setEnabled(true);
					}
					const oList = this.byId("idListBS");
					const aItems = oList.getItems();
					for (let i = 0; i < aItems.length; i++) {
						const oContext = aItems[i].getBindingContext("resourceModelBS").getObject();
						const aFilterObj = oApproversBS.filter((approvers) => approvers.ID === oContext.ID && approvers.ProfitCenterDetails.TrpcGuid === oContext.ProfitCenterDetails.TrpcGuid);
						if (aFilterObj.length) {
							aItems[i].setSelected(true);
						} else {
							aItems[i].setSelected(false);
						}
					}
				},
				onDeleteOREToken: function (oEvent) {
					const oModel = this.getView().getModel("selectedOREModel");
					const oApproversORE = oModel.getProperty("/ApproverDetails");
					const oParameters = oEvent.getParameters();
					if (oParameters.type === "removed") {
						const aTokens = oParameters.removedTokens;
						for (let i = 0; i < aTokens.length; i++) {
							const iIndex = oApproversORE.findIndex(item => item.ID === aTokens[i].getKey());
							if (iIndex !== -1) {
								oApproversORE.splice(iIndex, 1);
								oModel.refresh(true);
							}
						}
					}
					if (!oApproversORE.length) {
						this.byId("idMultiInputORE").setVisible(false);
						this.byId("idForwardNamedContact").setEnabled(false); 
					} else {
						this.byId("idMultiInputORE").setVisible(true);
						this.byId("idForwardNamedContact").setEnabled(true); 
					}
 
					const oList = this.byId("idListORE");
					const aItems = oList.getItems();
					for (let i = 0; i < aItems.length; i++) {
						const oContext = aItems[i].getBindingContext("resourceModelORE").getObject();
						const aFilterObj = oApproversORE.filter((approvers) => approvers.ID === oContext.ID);
						if (aFilterObj.length) {
							aItems[i].setSelected(true);
						} else {
							aItems[i].setSelected(false);
						}
					}
				},
				onSearchBS: function (oEvent) {
					const sSearchValue = oEvent.getParameter("query").toLowerCase();
					const oList = this.getView().byId("idListBS");
					let aFilters = [];
					const oUserIdFilter = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.Contains, sSearchValue);
					aFilters.push(oUserIdFilter);
					const oEmailFilter = new sap.ui.model.Filter("email", sap.ui.model.FilterOperator.Contains, sSearchValue);
					aFilters.push(oEmailFilter);
					const oPFCFilter = new sap.ui.model.Filter("ProfitCenterDetails/formattedDesc", sap.ui.model.FilterOperator.Contains, sSearchValue);
					aFilters.push(oPFCFilter);

			const oCombinedFilter = new sap.ui.model.Filter(aFilters, false);

			oList.getBinding("items").filter(oCombinedFilter);
			oList.removeSelections();
					for (let i = 0; i < oList.getItems().length; i++) {
						const oContext = oList.getItems()[i].getBindingContext("resourceModelBS").getObject();
						const selectedBSModelData = this.getView().getModel("selectedBSModel").getData();
						const approverDetails = selectedBSModelData.ApproverDetails ?  selectedBSModelData.ApproverDetails: [];

						const aFilterObj = approverDetails.filter((approvers) => approvers.ID === oContext.ID);
						if (aFilterObj.length) {
							oList.getItems()[i].setSelected(true);
						}
					}
		},
		onSearchORE: function (oEvent, isLiveSearch) {
			this.currentPageORE = 0;
            let sSearchValue;
            if(!isLiveSearch){
                sSearchValue = oEvent.getParameter("query");
            }else{
                sSearchValue = oEvent.getParameter("newValue");
            }
           
    const oList = this.getView().byId("idListORE");
    const that = this;
    const ApproversOREUrl = that._getOREApproversBaseURL();
    let filterORE;
let serviceUrlORE;
    if (sSearchValue) {
        filterORE = "&$filter=(MelodyRequest eq 'X')&$orderby=CapEmpNme asc";
        serviceUrlORE = ApproversOREUrl + "?search=" + sSearchValue + filterORE;
    }else{
        filterORE = "?$filter=(MelodyRequest eq 'X')&$orderby=CapEmpNme asc";
         serviceUrlORE = ApproversOREUrl + filterORE;
    }
    sap.ui.core.BusyIndicator.show(0);
    that.getNamedContactsData(serviceUrlORE, that.itemsPerPage, 0)
        .then(function (data) {
            sap.ui.core.BusyIndicator.hide();
            const valueORE = data.d.results;
            const approverDetails = valueORE.map(function (obj) {
                return {
                    fullName: obj.EmpName,
                    ID: obj.Id,
                    email: obj.EmailId,
					to_substitute:obj.to_nmdsubstitute
                };
            });
            let oResourceModel = that.getView().getModel("resourceModelORE");
            if (!oResourceModel) {
                oResourceModel = new sap.ui.model.json.JSONModel();
                that.getView().setModel(oResourceModel, "resourceModelORE");
            }
            oResourceModel.setData({ ApproverDetails: approverDetails });
            oList.removeSelections();
            const oSelectedModel = that.getView().getModel("selectedOREModel").getData();
            const selectedApprovers = oSelectedModel && oSelectedModel.ApproverDetails ? oSelectedModel.ApproverDetails : [];

            oList.getItems().forEach((oItem) => {
                const oContext = oItem.getBindingContext("resourceModelORE").getObject();
                if (selectedApprovers.some(approver => approver.ID === oContext.ID)) {
                    oItem.setSelected(true);
                }
            });

        })
        .catch(function (error) {
            sap.ui.core.BusyIndicator.hide();
        });
        },
        onLiveORENamedChange:function(oEvent){
            var sValue = oEvent.getParameter("newValue");
    if (!sValue) {
             this.onSearchORE(oEvent);
    }else if (sValue.length > 2){
        this.onSearchORE(oEvent, true);
    }
        },
				currentAvatarDisplay: function (userId) {
					return this.getOwnerComponent().getModel("appConstants").getProperty("/userImg/0/Value") + userId;
				},
				_getOREFilterUrl: function () {
						const filterValues = {
							"Manager_Level": "non-managerial",
							"Role_GUID": this.getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RoleId,
							"RoleArea_P_GUID": this.getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.RoleArea_P_GUID.ID
						};
						const cross_CVRG_P_GUIDArray = this.getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.cross_CVRG_P_GUIDArray;

						const crossBAGuid = this.getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.BASegments;
						const baIndustriesGuid = this.getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.BAIndustries;
						const baLobs = this.getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.BALoBs;
						const hubs = this.getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.TempSelectedHubs;
						const baIndustries_GUIDs = baIndustriesGuid.map(item => item.BaIndId);
						const filterCondition1 = baIndustries_GUIDs.length ?
							`(${baIndustries_GUIDs.map(guid => `BaIndId eq '${guid}'`).join(' or ')})` : "";

const baLobs_GUIDs = baLobs.map(item => item.ID);
const filterCondition2 = baLobs_GUIDs.length ? `(${baLobs_GUIDs.map(guid => `BaLobId eq '${guid}'`).join(' or ')})` : "";
const cross_CVRG_P_GUIDs = cross_CVRG_P_GUIDArray.map(item => item.ID);
const filterCondition3 = cross_CVRG_P_GUIDs.length ? `(${cross_CVRG_P_GUIDs.map(guid => `CrossCvrgId eq '${guid}'`).join(' or ')})` : "";
const crossBAGuidGuids = crossBAGuid.map(item => item.ID);
const filterCondition4 = crossBAGuidGuids.length ? `(${crossBAGuidGuids.map(guid => `BaSegId eq '${guid}'`).join(' or ')})` : "";
// const hubGuids = hubs.map(item => item.ID);
// const filterCondition5 = hubGuids.length ? `(${hubGuids.map(guid => `HubIndId eq '${guid}'`).join(' or ')})` : "";

let finalFilterString = `$filter=(RoleId eq '${filterValues.Role_GUID}') and (RoleAreaId eq '${filterValues.RoleArea_P_GUID}')`;

const filterConditions = [filterCondition1, filterCondition2, filterCondition3, filterCondition4];
const nonEmptyFilters = filterConditions.filter(condition => condition !== '');

if (nonEmptyFilters.length > 0) {
finalFilterString += ' and ';
finalFilterString += nonEmptyFilters.join(' and ');
}
return finalFilterString;
},
bSFilterurl: function (ApproversBaseUrl, sProfitcenter, tableTypeId) {
const filterValues = {
"ProfitCenterGUID": sProfitcenter,
"TableTypeID": tableTypeId,
"Manager_Level": "non-managerial",
"Role_GUID": this.getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.Guid,
"RoleArea_P_GUID": this.getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.RoleArea_P_GUID.Guid
};
const cross_CVRG_P_GUIDArray = this.getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.cross_CVRG_P_GUIDArray;

const crossBAGuid = this.getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.BASegments;
const baIndustriesGuid = this.getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.BAIndustries;
const baLobs = this.getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.BALoBs;

const baIndustries_GUIDs = baIndustriesGuid.map(item => item.Guid);
const filterCondition1 = baIndustries_GUIDs.length ? baIndustries_GUIDs.map(guid => ` and (BA_Industry_P_GUID eq ${guid})`).join(' or ') : "";

// const filterCondition1 = baIndustries_GUIDs.map(guid => `BA_Industry_P_GUID eq ${guid}`).join(' or '); // Extract GUIDs from the first array
const baLobs_GUIDs = baLobs.map(item => item.Guid);
// const filterCondition2 = baLobs_GUIDs.map(guid => `BA_Lob_P_GUID eq ${guid}`).join(' or ');
const filterCondition2 = baLobs_GUIDs.length ? baLobs_GUIDs.map(guid => ` and (BA_Lob_P_GUID eq ${guid})`).join(' or ') : "";
const cross_CVRG_P_GUIDs = cross_CVRG_P_GUIDArray.map(item => item.Guid);
// const filterCondition3 = cross_CVRG_P_GUIDs.map(guid => `Cross_CVRG_P_GUID eq ${guid}`).join(' or ');
const filterCondition3 = cross_CVRG_P_GUIDs.length ? cross_CVRG_P_GUIDs.map(guid => ` and (Cross_CVRG_P_GUID eq ${guid})`).join(' or ') : "";
const crossBAGuidGuids = crossBAGuid.map(item => item.Guid);
// const filterCondition4 = crossBAGuidGuids.map(guid => `BA_Seg_GUID eq ${guid}`).join(' or ');
const filterCondition4 = crossBAGuidGuids.length ? crossBAGuidGuids.map(guid => ` and (BA_Seg_GUID eq ${guid})`).join(' or ') : "";
const finalFilterString = `$filter=(ProfitCenterGUID eq ${filterValues.ProfitCenterGUID}) and (TableTypeID eq '${filterValues.TableTypeID}') and (Manager_Level eq 'non-managerial') and (Role_GUID eq ${filterValues.Role_GUID}) and (RoleArea_P_GUID eq ${filterValues.RoleArea_P_GUID})${filterCondition1}${filterCondition2}${filterCondition3}${filterCondition4}`;

return finalFilterString;
},

_getLoggedInUserAssignmentObj: function (self) {
//filter loggedin user assignment details 
const sCurrentUser = sap.ushell.Container.getService("UserInfo").getUser().getEmail();
const aNominatedResources = self.getModel().getProperty("/NominatedResources");
let oResource;
oResource = aNominatedResources.filter(nom =>nom.email === sCurrentUser)[0];
return oResource;
},
		//Change Request to IO Staffing Working for EMEA #93 start
		//check the exception
		fnExceptionCallback: function (data, self, oAssignmentContext) {
			//check part of exception table
			if (data.value.length) {
				self.isPartOfException = true;
			} else {
				self.isPartOfException = false;
			}

			if (!self.isPartOfException) {
				//no exception
				oAssignmentContext.isStaffing = self.isPartOfException;
			} else {
				//exception 
				oAssignmentContext.isStaffing = true;
				self.oContextAssignmentObj.isStaffingFields = true;
				oAssignmentContext.isAutoStaffingCompanyCode = true;
				self.oContextAssignmentObj.staffingPurposeVisible = true;
				self.oContextAssignmentObj.expectedTimeInvstementVisible = false;
				self.oContextAssignmentObj.ioOwnerFieldVisible = self.oContextAssignmentObj.isOppOwnerActive;
				self.oContextAssignmentObj.ioOwnerTextFieldVisible = true;
				self.oContextAssignmentObj.staffingDateRangeVisible = true;
				self.oContextAssignmentObj.maxNoOfDaysToBookIOVisible = true;
				self.oContextAssignmentObj.taskLevelVisible = true;
				self.oContextAssignmentObj.staffingMsgVisible = true;
			}
			self._setStaffingMsg(self.oContextAssignmentObj.selectedNominees, self.oContextAssignmentObj);
		},
		//Change Request to IO Staffing Working for EMEA #93 end
fnExceptionSuccessCallback: function (data, self, oAssignmentContext) {
//check part of exception table
if (data.value.length) {
self.isPartOfException = true;
} else {
self.isPartOfException = false;
}
if (!oAssignmentContext) {
//resource approval
oAssignmentContext = self._getLoggedInUserAssignmentObj(self);
oAssignmentContext.isPartOfException = self.isPartOfException;
oAssignmentContext.isAutoStaffingCompanyCode = self.isAutoStaffingCompanyCode;
}else{
oAssignmentContext.isPartOfException = self.isPartOfException;
}
   //Change Request to IO Staffing Working for EMEA #93 start
   let bSkipIOFlag = self.getView().getModel("WFRoutingSkipIOAPIData").getProperty("/value/0/operationalStatus");
	if (self.getView().getModel().getData().currentStepID !== "RESAPP") {
		if (oAssignmentContext && !self.isPartOfException && bSkipIOFlag) {
			//no exception and skip io  not enabled
			oAssignmentContext.isStaffing = false;
			self._setStaffingMsg(self.oContextAssignmentObj.selectedNominees, self.oContextAssignmentObj);
		} else {
			oAssignmentContext.isStaffing = true;
			self.oContextAssignmentObj.isStaffingFields = true;
			if (self.isPartOfException && bSkipIOFlag) {
				oAssignmentContext.isAutoStaffingCompanyCode = true;
			} else {
				oAssignmentContext.isAutoStaffingCompanyCode = false;
			}
			self.oContextAssignmentObj.staffingPurposeVisible = true;
			self.oContextAssignmentObj.expectedTimeInvstementVisible = false;
			self.oContextAssignmentObj.ioOwnerFieldVisible = self.oContextAssignmentObj.isOppOwnerActive;
			self.oContextAssignmentObj.ioOwnerTextFieldVisible = true;
			self.oContextAssignmentObj.staffingDateRangeVisible = true;
			self.oContextAssignmentObj.maxNoOfDaysToBookIOVisible = true;
			self.oContextAssignmentObj.taskLevelVisible = true;
			self.oContextAssignmentObj.staffingMsgVisible = false;
		}
		self._setStaffingMsg(self.oContextAssignmentObj.selectedNominees, self.oContextAssignmentObj);
	}
   //Change Request to IO Staffing Working for EMEA #93 end
//Check staffing criteria 
if (oAssignmentContext.isPartOfException || oAssignmentContext.isAutoStaffingCompanyCode) {
const sUserId = oAssignmentContext.userId;
//Call userSearchHelps to fetch the perner number for staffing
Models._callUserSearchHelps(sUserId, self, self.fnSuccessUserSearchHelpsCallBack, self.fnErrorUserSearchHelpsCallBack, oAssignmentContext);
} else {
//Proceed wf trigger
self._onFinalSubmitWf(self);
}
},
//Proceed wf trigger
_onFinalSubmitWf: function (self) {
const startupParameters = self.getComponentData().startupParameters;
const sStep = self.getModel().getProperty("/currentStepID");
const processContext = self.getModel().getData();
self._openSubmitDialog(
processContext,
startupParameters.taskModel.getData().InstanceID,
"Approve",
sStep
);
},
fnSuccessUserSearchHelpsCallBack: function (data, self, oAssignmentContext) {
const sStep = self.getModel().getProperty("/currentStepID");
const sMsg =  self.i18nModel.getText("pernerServiceNoErrorMsg");
if (data) {
	if (data.d.results.length) {
if (data.d.results[0].Pernr) {
	//fetch perner number
	oAssignmentContext.Pernr = data.d.results[0].Pernr;
	if (sStep !== "MANAPP") {
		//config staffing payload
		self._formStaffingPayload(self, oAssignmentContext);
	}
}
	}
	else {
		
		if (sStep !== "MANAPP") {
			 //Proceed wf trigger
			self._onProceedForWfService(self, sMsg);
		}
		}
} else {
	
	if (sStep !== "MANAPP") {
		//Proceed wf trigger
		self._onProceedForWfService(self, sMsg);
	}
}

},
fnErrorUserSearchHelpsCallBack:function(oError,oController){
//set generic error message
ErrorHandle.setErrorMessage(oError, oController);
},
//set payload for staffing POST operation
_setStaffingPayload: function (oNominatedResources) {
const oStaffingPayload = {
"Actexp": oNominatedResources.staffingPurposeKey ? oNominatedResources.staffingPurposeKey:"",
"ActexpStr": oNominatedResources.staffingPurpose ? oNominatedResources.staffingPurpose : "",
"Action": "2",
"Begda": oNominatedResources.dateValue ? this.formatDateToMilliSeconds(oNominatedResources.dateValue) : "00000000",
"BegdaStr": oNominatedResources.dateValue ? this.getDateString(new Date(oNominatedResources.dateValue)) : "00000000",
"Bukrs": oNominatedResources.sCompanyCode ? oNominatedResources.sCompanyCode : "",
"CostObjType": "IO",
"Endda": oNominatedResources.secondDateValue ? this.formatDateToMilliSeconds(oNominatedResources.secondDateValue) : "00000000",
"EnddaStr": oNominatedResources.secondDateValue ? this.getDateString(new Date(oNominatedResources.secondDateValue)) : "00000000",
"EntryId": "O",
"LogSystem":"CRM_MTR",
"Name": oNominatedResources.fullName,
"Snote": "",
"Objnr": "",
"Pernr": "00000000",
"PernrStr": oNominatedResources.Pernr,
"Posnr": "",
"ReadOnly": false,
"TaskLevel": oNominatedResources.staffingPurposeKey!=="E" ?  oNominatedResources.taskLevelKey : "NONE",
"Tasktype": "",
"TasktypeStr":"",
"Trtkl": "",
"UserType": "",
"Vbeln": oNominatedResources.internalOrder ? oNominatedResources.internalOrder.toString() : "",
"Zexpdays": oNominatedResources.maxNoOfDaysToBookIO ? oNominatedResources.maxNoOfDaysToBookIO.toString() : "",
}
return oStaffingPayload;
},
formatDateToMilliSeconds: function (dateVal) {
//convert date in to milli seconds
const iDate = Date.parse(new Date(dateVal));
return `\/Date(${iDate})\/`;
},
getDateString: function (date) {
//convert date in to string
const year = date.getFullYear();
const month = date.getMonth() + 1;
let month_append;
let dat_append;
if (month < 10) {
month_append = "0";
} else {
month_append = "";
}
const dat = date.getDate();
if (dat < 10) {
dat_append = "0";
} else {
dat_append = "";
}
return (year + "" + month_append + "" + month + "" + dat_append + "" + dat);
},
_formStaffingPayload: function (self, oNominatedResources, bSkipResources) {
//Finalize staffing payload
let oFinalPayload = [];
if (bSkipResources) {
//skip resources ---> Presales Manager direct approve
oNominatedResources.forEach(function (nominatedResource) {
	oFinalPayload.push(self._setStaffingPayload(nominatedResource));
})
} else {
//Resource approval
oFinalPayload.push(self._setStaffingPayload(oNominatedResources));
}
sap.ui.core.BusyIndicator.show(0);
//POST staffing
Models._postStaffingDetails(oFinalPayload, self, self.fnSuccessPostStaffing, self.fnErrorPostStaffing)
},
fnSuccessPostStaffing: function (response, self) {
sap.ui.core.BusyIndicator.hide();
const bSkipResources = self.getView().getModel().getProperty("/Skip_Resource_Approver");
if (bSkipResources) {
try {
	//error handling
	if (JSON.parse(response.headers["sap-message"]).severity === "error") {
		const sMsg = `${JSON.parse(response.headers["sap-message"]).message}.${self.i18nModel.getText("staffingGenericError")}?`
		self._onProceedForWfService(self, sMsg);
	} else {
		//success message
		self._showStaffingSuccessMessage(self.i18nModel.getText("staffingSuccessMsg"));
		//proceed wf trigger
		self.onApprove();
	}
} catch (err) {
	self._showStaffingSuccessMessage(self.i18nModel.getText("staffingSuccessMsg"));
	 //proceed wf trigger
	self.onApprove();
}
} else {
try {
	if (JSON.parse(response.headers["sap-message"]).severity === "error") {
		const sMsg = `${JSON.parse(response.headers["sap-message"]).message}.${self.i18nModel.getText("staffingGenericError")}?`
		 //proceed wf trigger
		self._onProceedForWfService(self, sMsg);
	} else {
		 //proceed wf trigger
		self._onFinalSubmitWf(self);
	}
} catch (err) {
	 //proceed wf trigger
	self._onFinalSubmitWf(self);
}
}
},
_showStaffingSuccessMessage:function(sMsg){
//staffing POST success message
MessageBox.show(
sMsg, {
icon: MessageBox.Icon.SUCCESS,
title: "Success"
});
},
_onProceedForWfService: function (self, sMsg) {
 //show warning message to continue wf -> trigger when staffing service fails
 const bSkipResources = self.getView().getModel().getProperty("/Skip_Resource_Approver");
 const sBtnText = self.getView().getModel("formActionsConfigModel").getData().idproceed[0].Label;
 MessageBox.show(
	 sMsg, {
	 icon: MessageBox.Icon.WARNING,
	 title: "Warning",
	 actions: [sBtnText, MessageBox.Action.CANCEL],
	 emphasizedAction: sBtnText,
	 onClose: function (oAction) {
		 if (oAction === sBtnText) {
			 if (bSkipResources) {
				 self.onApprove();
			 } else {
				 self._onFinalSubmitWf(self);
			 }
		 }
	 }
 }
 );

 document.querySelectorAll(".sapMMessageBox").forEach(box => {
	 box.style.width = "500px";
 });
},
fnErrorPostStaffing: function (response, self) {
//staffing POST error message
sap.ui.core.BusyIndicator.hide();
const sMsg = self.i18nModel.getText("staffingErrorCallBackText");
self._onProceedForWfService(self, sMsg);
},
fnExceptionErrorCallback: function (oError, self,token) {
//exception error call back
try {
if (oError.responseJSON.error.message.value.includes("Record does not exists")) {
	if(token){
		token.isPartOfException = false;
	}
}
} catch (err) {
//set generic error message
ErrorHandle.setErrorMessage(oError, self);
};         
},
/**
* RESOURCE ASSIGNMENT
*/
_createResourceAssignmentDialog: function (processContext, taskId, sDecision) {
const oThisController = this;
if (!this._oResourceAssignmentDialog) {
Fragment.load({
name: "com.sap.bpm.PresalesRequestApproval.view.ResourceAssignmentDialog",
controller: this
}).then(function (oDialog) {
this._oResourceAssignmentDialog = oDialog;
this._oResourceAssignmentDialog.setModel(this.getModel());
this.getView().addDependent(this._oResourceAssignmentDialog);
this._configResourceAssignmentDialog();
this._oResourceAssignmentDialog.open();
this._oResourceAssignmentDialog.attachConfirm(function (oEvent) {
const aContexts = oEvent.getParameter("selectedContexts");
if (aContexts && aContexts.length) {
const oPresalesData = aContexts.map(function (oContext) { return oContext.getObject(); })
oThisController._createRoleSelectDialog(processContext, taskId, sDecision, oPresalesData);

}
	})
}.bind(this));
} else {
this._configResourceAssignmentDialog();
this._oResourceAssignmentDialog.open();
}
},
_createRequestDialog: function (oEvent, processContext, taskId, sDecision, oPresalesData) {
sap.ui.core.BusyIndicator.show(0);
oThisController._forwardActionDialog(oEvent, processContext, taskId, sDecision, oPresalesData);
sap.ui.core.BusyIndicator.hide();
},


_createRoleSelectDialog: function (processContext, taskId, sDecision, oPresalesData) {
const oThisController = this;

if (!this._oRoleSelectDialog) {
Fragment.load({
	name: "com.sap.bpm.PresalesRequestApproval.view.RoleSelectDialog",
	controller: this
}).then(function (oDialog) {
	this._oRoleSelectDialog = oDialog;
	this._oRoleSelectDialog.setModel(this.getModel());
	this.getView().addDependent(this._oRoleSelectDialog);
	this._configRoleSelectDialog();
	this._oRoleSelectDialog.open();
	this._oRoleSelectDialog.attachConfirm(function (oEvent) {
		let aContexts = oEvent.getParameter("selectedContexts");
		if (aContexts && aContexts.length) {
			const oRoleData = aContexts.map(function (oContext) { return oContext.getObject(); })
			oThisController._confirmResourceAssignment(processContext, taskId, sDecision, oPresalesData, oRoleData);
		}
	})
}.bind(this));
} else {
this._configRoleSelectDialog();
this._oRoleSelectDialog.open();
}
},
_confirmResourceAssignment: function (processContext, taskId, sDecision, oPresalesData, oRoleData) {
let oThisController = this,
oModel = this.getModel(),
sResourcesFullNames = oPresalesData[0].fullName;
for (let i = 1; i < oPresalesData.length; i++) {
sResourcesFullNames += ", " + oPresalesData[i].fullName;
}
oThisController.getModel().setProperty("/assignedPresales", oPresalesData);
const oAssignedRoleData = {
name: this.getMessage(oRoleData[0].text),
id: oRoleData[0].key
}
oThisController.getModel().setProperty("/assignedRoleData", oAssignedRoleData);
oThisController._openSubmitDialog(processContext, taskId, sDecision, oModel.getProperty("/currentStepID"), sResourcesFullNames, oRoleData);
},
_configRequestDialog: function () {
const that = this;
const oTree = this.getView().byId("idTree");
oTree.bindAggregation("items", "myPresaleModel>/data", function (sId, oContext) {
const oLeafChild = oContext.getProperty("isLeafNode");
const oControl =
	(oLeafChild === true && oLeafChild !== " ") ? new sap.m.CustomTreeItem(sId, {
		content: new sap.m.RadioButton({
			text: "{myPresaleModel>text}",
			select: that.onTreeItemSelected.bind(that)
		})
	}) :
		new sap.m.CustomTreeItem(sId, {
			content: new sap.m.Title({
				text: "{myPresaleModel>text}"
			})
		});
return oControl;
});
},
_setReqAreasTree:function(aResult){
const aReqAreaTree = [];
let oReqAreaObj = {};
for (let i = 0; i < aResult.length; i++) {
//pushing parent text into an array
oReqAreaObj.text = aResult[i].Ra1;
oReqAreaObj.enabled = !(aResult[i].Ra2 !== null);
oReqAreaObj.isLeafNode = !(aResult[i].Ra2 !== null);
if (oReqAreaObj.enabled && oReqAreaObj.isLeafNode) {
	oReqAreaObj.PresalesRequestArea = aResult[i].Ra1;
	oReqAreaObj.PresalesRequestAreaPath = aResult[i].Request_Area;
	oReqAreaObj.GUID = aResult[i].GUID;
}
oReqAreaObj.nodes = [];
aReqAreaTree.push(oReqAreaObj);
oReqAreaObj = {};
for (let j = 0; j < aReqAreaTree.length; j++) {
	for (let k = j + 1; k < aReqAreaTree.length; k++) {
		//removing duplicate element from array
		if (aReqAreaTree[j].text === aReqAreaTree[k].text) {
			aReqAreaTree.pop();
		}
	}
}
}
for (let m = 0; m < aReqAreaTree.length; m++) {
for (let n = 0; n < aResult.length; n++) {
	//pushing child1 (Ra1) data into array
	if (aReqAreaTree[m].text === aResult[n].Ra1) {
		oReqAreaObj.text = aResult[n].Ra2;
		oReqAreaObj.enabled = !(aResult[n].Ra3 !== null);
		oReqAreaObj.isLeafNode = !(aResult[n].Ra3 !== null);
		if (oReqAreaObj.enabled && oReqAreaObj.isLeafNode) {
			oReqAreaObj.PresalesRequestArea = aResult[n].Ra1 + "-" + aResult[n].Ra2;
			oReqAreaObj.PresalesRequestAreaPath = aResult[n].Request_Area;
			oReqAreaObj.GUID = aResult[n].GUID;
		}
		oReqAreaObj.nodes = [];
		aReqAreaTree[m].nodes.push(oReqAreaObj);
		oReqAreaObj = {};
		for (let j = 0; j < aReqAreaTree[m].nodes.length; j++) {
			for (let k = j + 1; k < aReqAreaTree[m].nodes.length; k++) {
				//removing duplicate element
				if (aReqAreaTree[m].nodes[j].text === aReqAreaTree[m].nodes[k].text) {
					aReqAreaTree[m].nodes.pop();
				}
			}
			for (let s = 0; s < aResult.length; s++) {
				//pushing child2 (ReqArea3) data into array
				if (aReqAreaTree[m].nodes[j].text === aResult[s].Ra2 && aReqAreaTree[m].text === aResult[s].Ra1) {
					oReqAreaObj.text = aResult[s].Ra3;
					oReqAreaObj.enabled = !(aResult[s].Ra4 !== null);
					oReqAreaObj.isLeafNode = !(aResult[s].Ra4 !== null);
					if (oReqAreaObj.enabled && oReqAreaObj.isLeafNode) {
						oReqAreaObj.PresalesRequestArea = aResult[s].Ra2 + "-" + aResult[s].Ra3;
						oReqAreaObj.PresalesRequestAreaPath = aResult[s].Request_Area;
						oReqAreaObj.GUID = aResult[s].GUID;
					}
					oReqAreaObj.nodes = [];
					aReqAreaTree[m].nodes[j].nodes.push(oReqAreaObj);
					oReqAreaObj = {};
					for (let i = 0; i < aReqAreaTree[m].nodes[j].nodes.length; i++) {
						for (let p = i + 1; p < aReqAreaTree[m].nodes[j].nodes.length; p++) {
							//removing duplicate element
							if (aReqAreaTree[m].nodes[j].nodes[i].text === aReqAreaTree[m].nodes[j].nodes[p].text) {
								aReqAreaTree[m].nodes[j].nodes.pop();
							}
						}
						//pushing child3(ReqArea4) data into array
						if (aResult[s].Ra4 !== null && aResult[s].Ra3 === aReqAreaTree[m].nodes[j].nodes[i].text && aReqAreaTree[m].nodes[j].text === aResult[s].Ra2) {
							oReqAreaObj.text = aResult[s].Ra4;
							oReqAreaObj.enabled = true;
							oReqAreaObj.isLeafNode = true;
							oReqAreaObj.PresalesRequestArea = aResult[s].Ra3 + "-" + aResult[s].Ra4;
							oReqAreaObj.PresalesRequestAreaPath = aResult[s].Request_Area;
							oReqAreaObj.GUID = aResult[s].GUID;
							oReqAreaObj.nodes = [];
							aReqAreaTree[m].nodes[j].nodes[i].nodes.push(oReqAreaObj);
							oReqAreaObj = {};
							for (let b = 0; b < aReqAreaTree[m].nodes[j].nodes[i].nodes.length; b++) {
								for (let c = b + 1; c < aReqAreaTree[m].nodes[j].nodes[i].nodes.length; c++) {
									if (aReqAreaTree[m].nodes[j].nodes[i].nodes[b].text === aReqAreaTree[m].nodes[j].nodes[i].nodes[c].text) {
										aReqAreaTree[m].nodes[j].nodes[i].nodes.pop();
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
}
return aReqAreaTree;

},
onTreeItemSelected: function (oEvent) {
const sPath = oEvent.getSource().getBindingContext("myPresaleModel").sPath;
this.selectedArea = this.getView().getModel("myPresaleModel").getProperty(sPath);
this.getView().getModel("profileViewParameters").setProperty("/footerButtons/forwardReqButtonEnabled",true);
},
_configResourceAssignmentDialog: function () {
// Set growing property
this._oResourceAssignmentDialog.setGrowing(true);
// Set style classes
const sResponsiveStyleClasses = "sapUiResponsivePadding--header sapUiResponsivePadding--subHeader sapUiResponsivePadding--content sapUiResponsivePadding--footer";
this._oResourceAssignmentDialog.toggleStyleClass(sResponsiveStyleClasses, true);
// clear the old search filter
this._oResourceAssignmentDialog.getBinding("items").filter([]);
// toggle compact style
syncStyleClass("sapUiSizeCompact", this.getView(), this._oResourceAssignmentDialog);
},
_configRoleSelectDialog: function () {
// Set growing property
this._oRoleSelectDialog.setGrowing(true);
// Set style classes
const sResponsiveStyleClasses = "sapUiResponsivePadding--header sapUiResponsivePadding--subHeader sapUiResponsivePadding--content sapUiResponsivePadding--footer";
this._oRoleSelectDialog.toggleStyleClass(sResponsiveStyleClasses, true);
// clear the old search filter
this._oRoleSelectDialog.getBinding("items").filter([]);
// toggle compact style
syncStyleClass("sapUiSizeCompact", this.getView(), this._oRoleSelectDialog);
},
onCreateRequest: function (oEvent) {
this._oRequestDialog.close();
this._oRequestDialog.complete();
},
onRequestDialogCancel: function (oEvent) {
this._oRequestDialog.close();
},
onPresalesSearch: function (oEvent) {
const sSearchQuery = oEvent.getParameter("value");
const aFilters = [];
aFilters.push(new Filter({
filters: [
	new Filter({
		path: "fullName",
		operator: FilterOperator.Contains,
		value1: sSearchQuery
	}),
	new Filter({
		path: "email",
		operator: FilterOperator.Contains,
		value1: sSearchQuery
	})
],
and: false
}));
const oFilter = new Filter({
filters: aFilters,
and: true
});
const oBinding = oEvent.getParameter("itemsBinding");
oBinding.filter(oFilter);
},
onIOOwnerSearch: function (oEvent) {
const sSearchQuery = oEvent.getParameter("value");
const oList = oEvent.getSource()._dialog.getContent()[1];
oList.setBusy(true);
Models._callEmployeeService(sSearchQuery, 100, 0, this, oList);
},
onPresalesRolesSearch: function (oEvent) {
const sSearchQuery = oEvent.getParameter("value");
const aFilters = [];

aFilters.push(new Filter({
filters: [
	new Filter({
		path: "text",
		operator: FilterOperator.Contains,
		value1: sSearchQuery
	})
],
and: false
}));
const oFilter = new Filter({
filters: aFilters,
and: true
});
const oBinding = oEvent.getParameter("itemsBinding");
oBinding.filter(oFilter);
},
onPresalesRolesDialogClose: function (oEvent) {
oEvent.getSource().getBinding("items").filter([]);
},
_openSubmitDialog: function (processContext, taskId, sDecision, sStep, sResourcesFullNames, oRoleData) {

const oModel = this.getModel();
oModel.setProperty("/comments", "");
let oRejectCodes = this.getView().getModel("RejectionCodeAPIData");
let sNewDecision = this._setDecision(sDecision);
//let sNewDecision = sDecision === "Send Back to Requestor" ? this.getMessage("SENDBACK_REQUESTOR") : sDecision;
// if (!this.oSubmitDialog) {
this.oSubmitDialog = new Dialog({
type: DialogType.Message,
title: sStep === "MANAPP" ?
	sDecision === "Approve" ? this.getMessage("CONFIRM_APPROVE_AND_ASSIGN") : this.getMessage("ENTER_COMMENT") :
	sDecision === "Approve" ? this.getMessage("CONFIRM_ASSIGNMENT") : this.getMessage("ENTER_COMMENT"),
content: [
	new Label({
		text: sStep === "MANAPP" ?
			sDecision === "Approve" ? this.getMessage("APPROVE_AND_ASSIGN_CONFIRM") + ' ' + sResourcesFullNames + ' ' + this.getMessage("IN_ROLE") + ' ' + this.getMessage(oRoleData[0].text) + '?' : this.getMessage("PROVIDE_REASON_FOR_DECISION") + ' "' + sNewDecision + '".' :
			sDecision === "Approve" ? this.getMessage("RESOURCE_ACKNOWLEDGE_TEXT") : this.getMessage("PROVIDE_REASON_FOR_DECISION") + ' "' + sNewDecision + '".',
		labelFor: "submissionNote",
		wrapping: true
	}),
	new Select("idRejectionSelect", {
		width: "100%",
		items: {
			path: "/value",
			template: new sap.ui.core.Item({
				key: "{RejID}",
				text: "{Rejection_Reason}"
			})
		},
		visible: sDecision === "Reject" ? true : false
	}),
	new TextArea("submissionNote", {
		width: "100%",
		value: '{/comments}',
		placeholder: sDecision === "Approve" && sStep === "MANAPP" ? this.getMessage("ASSIGN_RESOURCE_PLACEHOLDER") : this.getMessage("ENTER_TEXT_REQ"),
		valueState: '{/commentsState}',
		valueStateText: '{/commentsStateText}',
		visible: sDecision === "Reject" ? false : true,
		liveChange: function (oEvent) {
			const sComment = oEvent.getParameter("value");
			this.oSubmitDialog.getBeginButton().setEnabled(sComment.length > 0);
			if (sComment.length > 0) {
				oModel.setProperty("/commentsState", "None");
				oModel.setProperty("/comments", sComment);
			}
		}.bind(this)
	}),
	new TextArea("submissionNoteReject", {
		width: "100%",
		placeholder: this.getMessage("ENTER_TEXT_OPT"),
		visible: sDecision === "Reject" ? true : false
	})
],
beginButton: new Button({
	type: ButtonType.Emphasized,
	text: this.getMessage("OK"),
	enabled: sDecision == "Approve" || sDecision == "Reject" ? true : false,
	press: function () {
		this._validateInput(this.getModel().getData(), taskId, sDecision);
	}.bind(this)
}),
endButton: new Button({
	text: this.getMessage("CANCEL"),
	press: function () {
		this.oSubmitDialog.close();
		this.oSubmitDialog.destroy();
	}.bind(this)
})
});
//to get access to the controller's model
this.getView().addDependent(this.oSubmitDialog);
// }
// toggle compact style
syncStyleClass("sapUiSizeCompact", this.getView(), this.oSubmitDialog);
this.oSubmitDialog.setModel(oRejectCodes);
this.oSubmitDialog.open();
},
_validateInput: function (processContext, taskId, sDecision) {
let oModel = this.getModel(),
errorExist = false,
sComment = oModel.getProperty("/comments");

if (sDecision != "Reject") {
if (sComment && sComment.trim() && sComment !== "" && sComment !== "undefined" && sComment !==
	"null") {
	oModel.setProperty("/commentsState", "None");
} else {
	errorExist = true;
	oModel.setProperty("/commentsStateText", this.getMessage("PROVIDE_COMMENT"));
	oModel.setProperty("/commentsState", "Error");
}
} else if (sDecision == "Reject") {
processContext.rejectReason = sap.ui.getCore().byId("idRejectionSelect").getSelectedItem().getText();
processContext.comments = sap.ui.getCore().byId("submissionNoteReject").getValue();

}
if (errorExist) {
const sGenericErrorText = this.getMessage("FIELD_VALIDATION_ERROR_GENERIC");
MessageToast.show(sGenericErrorText)
this.getView().setBusy(false);
return;
} else {
this.oSubmitDialog.close();
this.oSubmitDialog.destroy();
if (processContext.ResReject !== true) {
	this._triggerComplete(processContext, taskId, sDecision);
} else {
	const oRejectReason = {
		"rejReason": processContext.rejectReason,
		"rejComments": processContext.comments
	}
	const oFinalPayload = this._fnConfigAssignmentsPayload(this);
	const oAssignments = oFinalPayload.Assignment;
	this._triggerComplete(oAssignments, taskId, sDecision, oRejectReason);
}
}
},
// This method is called when the confirm button is click by the end user
_triggerComplete: function (processContext, taskId, sDecision, managerRejectReason,isResourceProfile,sSelection) {
const oThisController = this;
const cFLPUserInfo = sap.ushell.Container.getService("UserInfo").getUser();
const workflowBaseurl = this._getWorkflowRuntimeBaseURL();
this.setBusy(true);
let aFilteredSubstitute = [];

$.ajax({
// Call workflow API to get the xsrf token
url: workflowBaseurl + "/xsrf-token",
method: "GET",
headers: {
	"X-CSRF-Token": "Fetch"
},
success: function (result, xhr, data) {
	// After retrieving the xsrf token successfully
	const token = data.getResponseHeader("X-CSRF-Token");
	let userId = null;
	if(oThisController.getModel().getProperty("/currentStepID") === "MANAPP"){
		if (!oThisController.getView().getModel().getData().isResourceProfile) {
			let usersArray = oThisController.getView().getModel().getData().approverDetails;
			let emailToFind = cFLPUserInfo.getEmail();
			for (let i = 0; i < usersArray.length; i++) {
				if (usersArray[i].email === emailToFind) {
					userId = usersArray[i].userId;
					break;
				}
			}
		} else {
			let usersArray = oThisController.getView().getModel().getData().aResourceProfileApprovers.ApproverDetails;
			let emailToFind = cFLPUserInfo.getEmail();
			for (let i = 0; i < usersArray.length; i++) {
				if (usersArray[i].email === emailToFind) {
					userId = usersArray[i].ID;
					break;
				}
			}
		}
	}
	else{
		let usersArray = oThisController.getView().getModel().getData().NominatedResources;
			let emailToFind = cFLPUserInfo.getEmail();
			for (let i = 0; i < usersArray.length; i++) {
				if (usersArray[i].email === emailToFind) {
					userId = usersArray[i].userId;
					break;
				}
			}
	}
	// form the context that will be updated
	//get substituteDetails
	let aSubstDetails = oThisController.getView().getModel().getProperty("/substituteApproverDetails");
	 aFilteredSubstitute = aSubstDetails ? aSubstDetails.filter(subs => subs.userId === userId):[];
	const oBasicData = {
		context: {
			"decision": sDecision,
			"currentProcessor": {
				"email": cFLPUserInfo.getEmail(),
				"fullName": cFLPUserInfo.getFullName(),
				"id": userId
			}
		},
		"status": "COMPLETED"
	};
	if (!oThisController.getModel().getData().parentInstanceID) {
		oBasicData.context.parentInstanceID = oThisController.getModel("WfInstanceModel").getData()[0].parentInstance_GUID;
	}
	switch(sDecision) {
		case "Approve":
		  oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idapprove[0].ID;
		  break;
		case "Forward":
		  oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idforward[0].ID;
		  if(sSelection === true){
			oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idresprofilesel[0].ID; 
		 }else if(sSelection == "namedContact"){
			 oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idnamedcontsel[0].ID; 
		 }
		  break;
		case "Reject":
		  oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idreject[0].ID;
		  break;
		case "Send Back to Requestor":
		  oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idrework[0].ID;
		  break;
		default:
		   oBasicData.context.decision_ID = ""
		  break;
	  }
	if(sDecision == "Forward" && processContext.isResourceProfile){
		oBasicData.context.oldReqArea = processContext.selectedProfitCenter[0].Desc
	}
	if (oThisController.getModel().getProperty("/currentStepID") === "MANAPP") {
		oBasicData.context.ManagerUserTaskID  = oThisController.getView().getModel("taskInstanceModel").getProperty("/id");
		if (processContext.Assignment && sDecision !== "Reject") {
			oBasicData.context.Assignment = processContext.Assignment;
		} else {
			if (sDecision !== "Send Back to Requestor" && sDecision !== "Forward" && sDecision !== "Reject") {
				oBasicData.context.Assignment = processContext;
			}
		}
	} else {
		oBasicData.context.ResourcesUserTaskID  = oThisController.getView().getModel("taskInstanceModel").getProperty("/id");
		const sReqType = processContext.RequestType;
		const sCurrentUser = sap.ushell.Container.getService("UserInfo").getUser().getEmail();
		let bIsIOStaffing;
		processContext.NominatedResources.forEach(function (nom) {
			if (sCurrentUser === nom.email) {
				bIsIOStaffing = nom.isIOStaffing
			}
		});
		if (sDecision === "Approve" && sReqType === "Opportunity" && bIsIOStaffing) {
			//submit(update) updated fields for staffing
			oBasicData.context.NominatedResources = processContext.NominatedResources;
		}
	}
	if (processContext.comments) {
		oBasicData.context.comments = processContext.comments;
	}

   
	if (sDecision === "Forward" && oThisController.selectedArea && !isResourceProfile && sSelection !== "namedContact") {
		oBasicData.context.requestAreaPath = oThisController.selectedArea.PresalesRequestAreaPath;
		oBasicData.context.requestArea = oThisController.selectedArea.PresalesRequestArea;
		oBasicData.context.forwardGUID = oThisController.selectedArea.GUID;
		oBasicData.context.isResourceProfile = false;
		oBasicData.context.OrgType = "SORG";
		let sorgID;
		let oTempEmployeeGUID = oThisController.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories/0/SelectedGuid");
		oThisController.getView().getModel("PCSalesOrgMaster").getData().find(function (item) {
			if (item.ProfitCenterGuid === oTempEmployeeGUID) {
				sorgID = item.SOrg;
			}
		});
		//update orgId when processor forward from resource profile to Req Area
		if(oTempEmployeeGUID){
			oBasicData.context.OrgID = "SORG-" + ('0000' + sorgID).slice(-4);
		}
		if (sorgID === "NOMP") {
			sorgID = oTempEmployeeGUID;
			oBasicData.context.OrgID = sorgID;
			oBasicData.context.isNoMP = true;
			oBasicData.context.OrgType = "PC";
		}
		oThisController.onCloseForwardReqDialog();
	}else if (sDecision === "Forward" && isResourceProfile && sSelection !== "namedContact"){
		oThisController["aResourceProfileApprovers"]["ResourceProfileDetails"]["SolutionAreas"] =
		oThisController["aResourceProfileApprovers"]["ResourceProfileDetails"]["SolutionAreas"] ? oThisController["aResourceProfileApprovers"]["ResourceProfileDetails"]["SolutionAreas"] : [];
		oBasicData.context.aResourceProfileApprovers = oThisController.aResourceProfileApprovers;
		oBasicData.context.OrgID  = oThisController.getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories/0/SelectedGuid");
		oBasicData.context.isResourceProfile = true;
		oBasicData.context.selectedProfitCenter = oThisController.selectedProfitCenter;
		oThisController.onCloseForwardReqDialog();
	}else if(sSelection === "namedContact"){
		oBasicData.context.aResourceProfileApprovers = oThisController.getModel().getData().aResourceProfileApprovers;
	}

	if (sDecision === "Reject") {
		if (managerRejectReason) {
			oBasicData.context.rejectReason = managerRejectReason.rejReason;
			oBasicData.context.comments = managerRejectReason.rejComments;
		} else {
			oBasicData.context.rejectReason = processContext.rejectReason;
		}
	}
	if(oThisController.getModel().getProperty("/currentStepID") !== "MANAPP" && sDecision === "Reject"){
		oBasicData.context.ResSendBackDecision = oThisController.getView().getModel("formActionsConfigModel").getData().idreject[0].Label;
	}
	//update orgid,orgtype and requesttype for older entries
	if (typeof (oThisController.getModel().getData()["SalesOrgID"]) === "string") {
		oBasicData.context["OrgID"] = oThisController.getModel().getData()["SalesOrgID"];
		oBasicData.context["OrgType"] = "SORG";
		oBasicData.context["RequestType"] = "Opportunity"

		if (sDecision === "Forward") {
			//update areapath call
			const OrgID_Num = oThisController._getOrgIDnumber(oBasicData.context.OrgID, oBasicData.context.OrgType);
			const aAreaPathCallRequests = [{
				id: "1",
				method: "GET",
				url: "/Resources(GUID=" + processContext.GUID + ",IsActiveEntity=true)",
				headers: { "content-type": "application/json;IEEE754Compatible=true" }
			},
			// To fetch Email template details
			{
				id: "2",
				method: "GET",
				url: "/Email_Body?$filter=orgID eq '" + OrgID_Num + "' and orgType eq '" + oBasicData.context.OrgType + "'",
				headers: { "content-type": "application/json;IEEE754Compatible=true" }
			},
			// End of code for Melody Resource Request Tool Sprint 1
			// to fetch Email Delegates Details
			{
				id: "3",
				method: "GET",
				url: "/Email_Delegates?$filter=orgID eq '" + oBasicData.context.OrgID + "'",
				headers: { "content-type": "application/json;IEEE754Compatible=true" }
			},
			// to check routing flags 
			{
				id: "4",
				method: "GET",
				url: "/WF_Routing?$filter=orgID eq '" + oBasicData.context.OrgID + "'",
				headers: { "content-type": "application/json;IEEE754Compatible=true" }
			}];
			oBasicData.context.areaPathCall = {
				"Request": {
					"requests": aAreaPathCallRequests
				}
			};
		}
	}
	//update refrence id for older request
	if (typeof oThisController.getModel().getData().RequestID !== "object") {
		if (oThisController.getModel().getProperty("/updatedRefId")) {
			oBasicData.context.RequestID = {
				"value": oThisController.getModel().getProperty("/updatedRefId")
			}
		}
	}
	//substitute check
	if (aFilteredSubstitute.length) {
		oBasicData.context.isSubstitute = true;
	} else {
		oBasicData.context.isSubstitute = false;
	}
	$.ajax({
		// Call workflow API to complete the task
		url: workflowBaseurl + "/task-instances/" + taskId,
		method: "PATCH",
		contentType: "application/json",
		// pass the updated context to the API
		data: JSON.stringify(oBasicData),
		headers: {
			// pass the xsrf token retrieved earlier
			"X-CSRF-Token": token
		},
		// refreshTask needs to be called on successful completion
		success: function (result, xhr, data) {
			oThisController._refreshTask();
			oThisController.setBusy(false);
		}

	});
}
});

},
onItemSearchInHierarchy: function (oEvent) {
const sQUery = oEvent.getParameter("newValue").trim();
let oPresaleTable = {};
oPresaleTable = this.getView().byId("idTree");
const oPresaleTextFilter = new Filter("text", FilterOperator.Contains, sQUery);
const oPresaleFilter = new Filter({
filters: [oPresaleTextFilter],
and: false
});
oPresaleTable.getBinding("items").filter(oPresaleFilter);
},
// Request Inbox to refresh the control once the task is completed
_refreshTask: function () {
const taskId = this.getComponentData().startupParameters.taskModel.getData().InstanceID;
this.getComponentData().startupParameters.inboxAPI.updateTask("NA", taskId);
},
/**
* DOCUMENT SERVICE INTEGRATION
*/
loadAttachments: function () {
// get workflow ID
const taskInstanceModel = this.getModel("taskInstanceModel");
workflowInstanceId = taskInstanceModel.getData().workflowInstanceId;
this.workflowFileUploadId = this.getModel().getProperty("/workflowFileUploadId") ? this.getModel().getProperty("/workflowFileUploadId") : workflowInstanceId;
this.sDocServiceUrl= this._getDocServiceRuntimeBaseURL();
const sUrl = this.sDocServiceUrl + "/WorkflowManagement/HarmonyPresalesRequests/" + this.workflowFileUploadId + "/?succinct=true";

const oSettings = {
"url": sUrl,
"method": "GET",
// "async": false
};
const oThisController = this;

$.ajax(oSettings)
.done(function (results) {
	//if(!oThisController.getModel().getProperty("/attachmentUrls")){
		//const aUploadedUrlObj = results.objects;
	//	if (aUploadedUrlObj.length) {
	// 		oThisController.getModel().setProperty("/attachmentUrls", []);
	// 		aUploadedUrlObj.forEach(function (obj) {
	// 			//form uploaded attachment url
	// 			const objectId = obj.object.succinctProperties["cmis:objectId"];
	// 			const sFileName = obj.object.succinctProperties["cmis:name"];
	// 			const sRootUrl = "https://sapit-presales-test.cockpit.workflowmanagement.cfapps.eu10.hana.ondemand.com";
	// 			const sQuery = `?objectId=${objectId}&cmisselector=content`;
	// 			const oUrl = {
	// 				"urlName": sFileName,
	// 				"url": `${sRootUrl}${oThisController.sDocServiceUrl}/WorkflowManagement/HarmonyPresalesRequests/${oThisController.workflowFileUploadId}${sQuery}`,
	// 				"urlDelete": true,
	// 				"urlNameValueState": "None",
	// 				"urlValueStateText": "",
	// 				"urlValueState": "None"
	// 			}
	// 			oThisController.getModel().getProperty("/attachmentUrls").push(oUrl);
	// 			oThisController.getModel().setProperty("/isAttachmentUrl", true);

	// 		});
	// 	}
	// }
	// oThisController.getModel().refresh()
	oThisController._mapAttachmentsModel(results);
})
.fail(function (err) {
	if (err !== undefined) {
		// const oErrorResponse = $.parseJSON(err.responseText);
		// MessageToast.show(oErrorResponse.message, {
		// 	duration: 6000
		// });
	} else {
		//MessageToast.show("Unknown error!");
	}
});
},

// assign data to attachments model
_mapAttachmentsModel: function (data) {
data.downloadEnabled = data && data.objects && data.objects.length > 0;
this.oAttachmentsModel.setData(data);
this.oAttachmentsModel.refresh();
this.getView().setBusy(false);
},

onDownloadAll: function (oEvent) {
let uploadCollection = this.byId("UploadCollection");
for (let i = 0; i < uploadCollection.getItems().length; i++) {
uploadCollection.downloadItem(uploadCollection.getItems()[i], true);
}
},
// formatting functions
formatTimestampToDate: function (timestamp) {
const oFormat = DateFormat.getDateTimeInstance();
return oFormat.format(new Date(timestamp));
},
formatFileLength: function (fileSizeInBytes) {
let i = -1;
let byteUnits = [' kB', ' MB', ' GB', ' TB', 'PB', 'EB', 'ZB', 'YB'];
do {
fileSizeInBytes = fileSizeInBytes / 1024;
i++;
} while (fileSizeInBytes > 1024);
return Math.max(fileSizeInBytes, 0.1).toFixed(1) + byteUnits[i];
},
formatDownloadUrl: function (objectId) {
const docServieBaseUrl = this._getDocServiceRuntimeBaseURL();
return docServieBaseUrl + "/WorkflowManagement/HarmonyPresalesRequests/"
+ workflowInstanceId + "?objectId=" + objectId + "&cmisselector=content";
},
_getWorkflowRuntimeBaseURL: function () {
return this._getRuntimeBaseURL() + "/workflowruntime/v1";
},
_getDocServiceRuntimeBaseURL: function () {
return this._getRuntimeBaseURL() + "/docservice";
},
_getRequestAreaBaseURL: function (sorgIDPc) {
let sOrgID = 'ParentOrgID' in this.getModel().getData() ? this.getModel().getProperty("/ParentOrgID") : this.getModel().getProperty("/OrgID");
if(this.getModel().getProperty("/OrgType") === 'SORG'){
sOrgID = Number(sOrgID.replace('SORG-', '')).toString();
}
let sFinalOrgId;
if(sorgIDPc){
	sFinalOrgId = sorgIDPc
}else{
	sFinalOrgId = sOrgID
}
return this._getRuntimeBaseURL() + "/resources/req-area-api-/Public_ReqArea?$filter=orgID eq '" + sFinalOrgId + "'";
},
_getConstantsBaseURL: function () {
return this._getRuntimeBaseURL() + "/resources/req-area-api-/Parameter";
},
_getWFRoutingBaseURL: function () {
let sOrgID = 'ParentOrgID' in this.getModel().getData() ? this.getView().getModel().getData().ParentOrgID : this.getView().getModel().getData().OrgID;
if(this.getModel().getProperty("/OrgType") === 'SORG'){
sOrgID = Number(sOrgID.replace('SORG-', '')).toString();
}
return this._getRuntimeBaseURL() + "/resources/resources/WF_Routing?$filter=orgID eq '" + sOrgID + "' and routing eq 'AUTO_STAFFING_ENABLE' and operationalStatus eq 'X'";
},
		//Change Request to IO Staffing Working for EMEA #93 start
		//base url for skipIo service
		_getWFRoutingSkipIOBaseURL: function () {
			let sOrgID = 'ParentOrgID' in this.getView().getModel().getData() ? this.getView().getModel().getData().ParentOrgID : this.getView().getModel().getData().OrgID;
			if (this.getView().getModel().getProperty("/OrgType") === 'SORG') {
				sOrgID = Number(sOrgID.replace('SORG-', '')).toString();
			}
			return this._getRuntimeBaseURL() + "/resources/resources/WF_Routing?$filter=orgID eq '" + sOrgID + "' and routing eq 'SKIP_IO_OWNER_WF' and operationalStatus eq 'X'";
		},
		//Change Request to IO Staffing Working for EMEA #93 end
_getRejectionCodeBaseURL: function () {
const sManagerORresource = this.getModel().getProperty("/currentStepID") === "MANAPP" ? "4" : "5";
let sOrgID = 'ParentOrgID' in this.getModel().getData() ? this.getModel().getProperty("/ParentOrgID") : this.getModel().getProperty("/OrgID");
if(this.getModel().getProperty("/OrgType") === 'SORG'){
sOrgID = Number(sOrgID.replace('SORG-', '')).toString();
}
return this._getRuntimeBaseURL() + "/resources/req-area-api-/Rejection_Codes?$filter=OrgID eq '" + sOrgID + "' and UserTask_ID eq '" + sManagerORresource + "'";
},
onSupportlinkpress: function () {
const aConstants = this.getView().getModel("ConstantsAPIData").getData().value;
aConstants.forEach(function (item) {
if (item.Type_desc === "supporturl" && item.Operational_Status) {
	sap.m.URLHelper.redirect(item.Value, true);
	return;
}
});
},
/*Start of code for Multiple resources */
_initializeAssignments: function () {
//initialize assignments model
let oAssignments = {
"assignments": []
};
const oModel = new JSONModel(oAssignments);
this.getView().setModel(oModel, "assignmentsModel");
const that = this;
//initialize roles model
//initialize resource model
const oResourceModel = new JSONModel(this.getModel().getData());
const oCAModel = new JSONModel(this.getView().getModel().getData());
this.getView().setModel(oCAModel, "CAModel");      
this.getView().setModel(oResourceModel, "resourceModel");
if (this.getModel("resourceModel").getData().RequestType == "Account") {
this.getView().byId("idDealInfoTabBar").setVisible(false);
this.getView().byId("idDealQualTabBar").setVisible(false);
}
if (this.getView().getModel().getData().ResReject === true) {
const oContextAssignments = this.getModel().getData().AssignmentReject;
this.getView().byId("idAssignmentsSection").setVisible(true);
oContextAssignments.forEach(function (assignment, iIndex) {
	const oFinalAssignmentContext = {

	}
	//initialize assignment properties
	oFinalAssignmentContext.AssignmentID = iIndex + 1;
	oFinalAssignmentContext.roleValueState = "None";
	oFinalAssignmentContext.roleValueStateText = "";
	oFinalAssignmentContext.resourceValueState = "None";
	oFinalAssignmentContext.resourceValueStateText = "";
	//set assignment comments to empty after send back
	oFinalAssignmentContext.comments = assignment.comments;
	oFinalAssignmentContext.resCommentValueState = "None";
	assignment.NominatedResources.forEach(item=> item.selected = true);
    assignment.NominatedResources.forEach(item=> item.enabled = true);
    assignment.NominatedResources.forEach(item=> item.btnEnabled = true);
    oFinalAssignmentContext.selectedNominees = assignment.NominatedResources;
	oFinalAssignmentContext.selectedNominees = assignment.NominatedResources;
	oFinalAssignmentContext.selectedTimeInvestment = "";
	oFinalAssignmentContext.isIOStaffing = assignment.isIOStaffing;
	// oFinalAssignmentContext.selectedIOOwner = [{ "IOOwnerDetails": assignment.NominatedResources[0].ioOwnerDetails }];
	that._setSelectedIOowner(oFinalAssignmentContext);
	oFinalAssignmentContext.maxNoOfDaysToBookIO = assignment.NominatedResources[0].maxNoOfDaysToBookIO;
	oFinalAssignmentContext.staffingDateRange = assignment.NominatedResources[0].staffingDateRange;
	oFinalAssignmentContext.staffingPurpose = assignment.NominatedResources[0].staffingPurpose;
	oFinalAssignmentContext.staffingPurposeKey = assignment.NominatedResources[0].staffingPurposeKey;
	oFinalAssignmentContext.taskLevelKey = assignment.NominatedResources[0].taskLevelKey;
	oFinalAssignmentContext.taskLevelVal = assignment.NominatedResources[0].taskLevelVal;
	oFinalAssignmentContext.taskLevelEnable = assignment.NominatedResources[0].taskLevelEnable;
	oFinalAssignmentContext.staffingPurposeVisible = assignment.NominatedResources[0].staffingPurposeVisible;
	oFinalAssignmentContext.ioOwnerFieldVisible = assignment.NominatedResources[0].ioOwnerFieldVisible;
	oFinalAssignmentContext.ioOwnerTextFieldVisible = assignment.NominatedResources[0].ioOwnerTextFieldVisible;
	oFinalAssignmentContext.internalOrderFormVisible = assignment.internalOrderFormVisible;
	oFinalAssignmentContext.ioOwnerFieldVisible = assignment.ioOwnerFieldVisible;
	oFinalAssignmentContext.ioOwnerTextFieldVisible = assignment.ioOwnerTextFieldVisible;
	oFinalAssignmentContext.staffingPurposeVisible = assignment.staffingPurposeVisible;
	oFinalAssignmentContext.expectedTimeInvstementVisible = oFinalAssignmentContext.isIOStaffing ?  false:true;
	oFinalAssignmentContext.taskLevelVisible = assignment.taskLevelVisible;
	oFinalAssignmentContext.staffingDateRangeVisible = assignment.staffingDateRangeVisible;
	oFinalAssignmentContext.maxNoOfDaysToBookIOVisible = assignment.maxNoOfDaysToBookIOVisible;
	oFinalAssignmentContext.taskLevelEnable = assignment.taskLevelEnable;
	//Change Request to IO Staffing Working for EMEA #93 start
	//set staffing warning message properties
	oFinalAssignmentContext.staffingMsgVisible = assignment.staffingMsgVisible ? assignment.staffingMsgVisible : false;
	oFinalAssignmentContext.staffingMsg = that.getOwnerComponent().getModel("appConstants").getProperty("/ManualStaffing/0/Value");
	oFinalAssignmentContext.staffingMsgUrl = that.getOwnerComponent().getModel("appConstants").getProperty("/ManualStaffingURL/0/Value");
	oFinalAssignmentContext.StaffingMsgUrlText = that.getOwnerComponent().getModel("appConstants").getProperty("/ManualStaffingHyperlinkText/0/Value");
	//set preselected nominees
	let allNominees = that.getView().getModel().getData().AssignmentReject.flatMap(obj => obj.NominatedResources);
	let uniqueNominees = Array.from(
		new Map(allNominees.map(item => [item.userId, item])).values()
	);
	oFinalAssignmentContext.PreviousSelectedNominees = uniqueNominees;
   
	//Change Request to IO Staffing Working for EMEA #93 end
	oAssignments.assignments.push(oFinalAssignmentContext);
})
}
this.getView().getModel("assignmentsModel").refresh(true);
const oAssignmentsection = this.getView().byId("idObjPageLayout").getSections()[5];
this.getView().byId("idObjPageLayout").setSelectedSection(oAssignmentsection);
},
_fetchRoleDetails: function () {
return this._getRuntimeBaseURL() + "/resources/req-area-api-/Presales_role";
},
//IO staffing switch event trigger
onIOstaffingToggle: function (oBindingContextObj) {
	//reset assignment fields
	// const isIOStaffing = evt.getParameter("state");
	// const oBindingContextObj = evt.getSource().getParent().getParent().getBindingContext("assignmentsModel").getObject();
	oBindingContextObj.staffingDateRange = "";
	oBindingContextObj.staffingPurpose = "";
	oBindingContextObj.maxNoOfDaysToBookIO = "";
	oBindingContextObj.selectedInternalOrder = "";
	this._setSelectedIOowner(oBindingContextObj);
	oBindingContextObj.staffingPurposeKey = "Sel";

	oBindingContextObj.taskLevelVal = "NONE-None";
	 
	oBindingContextObj.selectedRole = "";
	oBindingContextObj.selectedInternalOrder = "";
	oBindingContextObj.selectedNominees = [];
	 
	oBindingContextObj.staffingPurposeVisible = false;
	oBindingContextObj.ioOwnerFieldVisible = false;
	oBindingContextObj.ioOwnerTextFieldVisible = false;
	oBindingContextObj.staffingDateRangeVisible = false;
	oBindingContextObj.maxNoOfDaysToBookIOVisible = false;
	oBindingContextObj.taskLevelVisible = false;
	oBindingContextObj.taskLevelEnable = false;
	oBindingContextObj.resourceValueState = "None";
	oBindingContextObj.staffingPurposeValueState = "None";
	oBindingContextObj.dateRangeValueState = "None";
	oBindingContextObj.daysToBooksValueState = "None"
	oBindingContextObj.internalOrderSelectValueState = "None";
	oBindingContextObj.ioOwnerValueState = "None";
	oBindingContextObj.roleValueState = "None";
	oBindingContextObj.isIOStaffing = true,
	oBindingContextObj.staffingPurposeKey = "A";
	oBindingContextObj.taskLevelKey = "NONE";
	oBindingContextObj.staffingPurpose = "Activities";
	oBindingContextObj.expectedTimeInvstementVisible = false;
	 

	oBindingContextObj.internalOrderFormVisible = true;
	this.getView().getModel("assignmentsModel").refresh();
	},
//add new assignment
onAddNewAssignment: function () {
	const oModelData = this.getView().getModel("assignmentsModel").getData().assignments;
	let allNominees = oModelData.flatMap(obj => obj.selectedNominees);

let uniqueNominees = Array.from(
new Map(allNominees.map(item => [item.userId, item])).values()
);
	const oInternalOrderModel = this.getView().getModel("internalOrderModel");
	const oAssignments = {
		"minDate": new Date(),
		"isIOStaffing": false,
		"selectedRole": "",
		"selectedInternalOrder": "",
		"roleValueState": "None",
		"roleValueStateText": `${this.i18nModel.getText("roleValueStateText")}`,
		"resourceValueState": "None",
		"resourceValueStateText": this.getView().getModel().getProperty("/Skip_Resource_Approver") ? `${this.i18nModel.getText("selectResource")}` : `${this.i18nModel.getText("selectResourceNominee")}`,
		"selectedNominees": [],
		"selectedTimeInvestment": 0,
		"selectedIOOwner": [],
		"staffingPurpose": "",
		"staffingPurposeVisible": false,
		"expectedTimeInvstementVisible": true,
		"staffingPurposeValueState": "None",
		"staffingPurposeValueStateText": `${this.i18nModel.getText("staffingPurposeValueStateText")}`,
		"staffingDateRange": "",
		"staffingDateRangeVisible": false,
		"dateRangeValueStateText": `${this.i18nModel.getText("dateRangeValueStateText")}`,
		"dateRangeValueState": "None",
		"maxNoOfDaysToBookIO": "",
		"maxNoOfDaysToBookIOVisible": false,
		"daysToBooksValueStateText": `${this.i18nModel.getText("dateRangeValueStateText")}`,
		"daysToBooksValueState": "None",
		"internalOrder": oInternalOrderModel.getData().length > 1 ? oInternalOrderModel.getData()[0] : this.getView().getModel().getProperty("/internalOrder"),
		"internalOrderSelectValueState": "None",
		"internalOrderSelectValueStateText": `${this.i18nModel.getText("internalOrderSelectValueStateText")}`,
		"internalOrderFormVisible": false,
		"ioOwnerValueState": "None",
		"resCommentValueState":"None",
		"ioOwnerFieldVisible": false,
		"ioOwnerTextFieldVisible": false,
		"ioOwnerValueStateText": `${this.i18nModel.getText("ioOwnerValueStateText")}`,
		"staffingPurposeVal": "",
		"taskLevelKey": "",
		"taskLevelVal": "",
		"taskLevelVisible": false,
		"taskLevelValueStateText": `${this.i18nModel.getText("taskLevelValueStateText")}`,
		"taskLevelValueState": "None",
		"comments":"",
		"taskLevelEnable": true,
		//Change Request to IO Staffing Working for EMEA #93 start ---> staffing warning message properties
		"staffingMsg":this.getOwnerComponent().getModel("appConstants").getProperty("/ManualStaffing/0/Value"),
		"staffingMsgVisible":false,
		"staffingMsgUrl":this.getOwnerComponent().getModel("appConstants").getProperty("/ManualStaffingURL/0/Value"),
		"StaffingMsgUrlText":this.getOwnerComponent().getModel("appConstants").getProperty("/ManualStaffingHyperlinkText/0/Value"),
		"staffingUrlVisible":this.getOwnerComponent().getModel("appConstants").getProperty("/ManualStaffingHyperlinkText/0/Operational_Status"),
		"PreviousSelectedNominees": uniqueNominees,
		 //Change Request to IO Staffing Working for EMEA #93 end

	}
	oModelData.push(oAssignments);
	for (let i = 0; i < oModelData.length; i++) {
		oModelData[i].AssignmentID = i + 1;
	}
	if (oModelData.length === 1) {
		oAssignments.assignmentDelete = false;
	} else {
		oModelData.forEach(function (val) {
			val.assignmentDelete = true;
		});
	}
	//set IO owner
	this._setSelectedIOowner(oAssignments);
	this.getView().getModel("assignmentsModel").refresh();
	if (this.getView().getModel().getProperty("/RequestType") === "Opportunity" && this.getView().getModel("WFRoutingAPIData").getProperty("/value/0/operationalStatus") && this.getView().getModel("internalOrderModel").getData().length) {
		this.onIOstaffingToggle(oAssignments);
	}
},
		_setSelectedIOowner: function (oAssignments) {
			const ioOwnerModel = this.getView().getModel("ioOwnerDetails");
			//set opportunity owner as IO owner
			let iOownerDetails;
			if (ioOwnerModel.getData().length) {
				iOownerDetails = {
					"IOOwnerName": `${ioOwnerModel.getProperty("/0/firstName")} ${ioOwnerModel.getProperty("/0/lastName")}`,
					"IOOwnerEmail": ioOwnerModel.getProperty("/0/email"),
					"IOOwnerUserId": ioOwnerModel.getProperty("/0/ID")
				}
			} else {
				const oModel = this.getView().getModel();
				//set opportunity owner as IO owner
				iOownerDetails = {
					"IOOwnerName": oModel.getProperty("/oppOwnerDetails").fullName,
					"IOOwnerEmail": oModel.getProperty("/oppOwnerDetails").email,
					"IOOwnerUserId": oModel.getProperty("/oppOwnerDetails").id
				}
			}
			oAssignments.isOppOwnerActive = true;
			//Enable forward functionality
			oAssignments.isForward = true;
			//Final selected IO Owner context
			oAssignments.selectedIOOwner = [{ "IOOwnerDetails": iOownerDetails }];
		},
//Open Nominee dialog (nominee user name and mail info)
onNomineeSelectDialogOpen: function (evt) {
this.oContextAssignmentObj = evt.getSource().getBindingContext("assignmentsModel").getObject();
this.oNomineeValueHelpControl = evt.getSource();
if(!this.getView().getModel("resourceModel").getData().availableResources){
	this.getView().getModel("resourceModel").getData().availableResources = this.getView().getModel().getData().availableResources;
}else{
	 //sort user list
	 this.getView().getModel("resourceModel").getData().availableResources.sort((a, b) => {
		const empNameA = a["fullName"].toUpperCase(); // ignore upper and lowercase
		const empNameB = b["fullName"].toUpperCase(); // ignore upper and lowercase
		if (empNameA < empNameB) {
		  return -1;
		}
		if (empNameA > empNameB) {
		  return 1;
		}
	  
		// names must be equal
		return 0;
	  })
}

this.getView().getModel("resourceModel").refresh(true);
if(this.getView().getModel().getData().isResourceProfile){
this._onOpenOREResourceDialog(evt);
}else{
if (!this.pNomineeSelectDialog) {
this.pNomineeSelectDialog = this.loadFragment({
	name: "com.sap.bpm.PresalesRequestApproval.view.nomineeSelectDialog"
});
}
this.pNomineeSelectDialog.then(function (oNomineeSelectDialog) {
if (this._bNomineeSelectInitialized) {
	oNomineeSelectDialog.open();
	return;
}
oNomineeSelectDialog.open();
const oAssignmentData = this.getView().getModel("assignmentsModel").getData().assignments;
const oSelectedResources = [];

for (let i = 0; i < oAssignmentData.length; i++) {
	const aSelectedNominees = oAssignmentData[i].selectedNominees;
	aSelectedNominees.forEach(function (nom) {
		oSelectedResources.push(nom);
	})
}
const oStandaraList = oNomineeSelectDialog.getItems();
oStandaraList.forEach(function (oControl) {
	oControl.setBlocked(false);
})
oSelectedResources.forEach(function (resource) {
	for (let i = 0; i < oStandaraList.length; i++) {
		const oBindingContextObj = oStandaraList[i].getBindingContext("resourceModel").getObject();
		if (resource.fullName === oBindingContextObj.fullName &&
			resource.email === oBindingContextObj.email) {
			oStandaraList[i].setBlocked(true);
			return true;
		}
	}
});
const aSelectedNominees = this.oContextAssignmentObj.selectedNominees;
aSelectedNominees.forEach(function (resource) {
	for (let i = 0; i < oStandaraList.length; i++) {
		const oBindingContextObj = oStandaraList[i].getBindingContext("resourceModel").getObject();
		if (resource.fullName === oBindingContextObj.fullName &&
			resource.email === oBindingContextObj.email) {
			oStandaraList[i].setBlocked(false);
			return true;
		}
	}
});
}.bind(this));
}
},
//open IO Owner select dialog
onIOOwnerDialogOpen: function (evt) {
this.oContextAssignmentIOOwnerObj = evt.getSource().getBindingContext("assignmentsModel").getObject();
const oIoOwnerData = new JSONModel([]);
this.getView().setModel(oIoOwnerData, "ioOwnerModel");

if (!this.pIOOwnerSelectDialog) {
this.pIOOwnerSelectDialog = this.loadFragment({
	name: "com.sap.bpm.PresalesRequestApproval.view.IOOwneSelectDialog"
});
}
this.pIOOwnerSelectDialog.then(function (oIOOwnerSelectDialog) {
oIOOwnerSelectDialog._searchField.setPlaceholder("Search IO Owner");
if (this._bNomineeSelectInitialized) {
	oIOOwnerSelectDialog.open();
	return;
}
oIOOwnerSelectDialog.open();
}.bind(this));

},
//resource select event
onSelectResource: function (evt) {
// this.oNomineeValueHelpControl.setBusy(true);
let aToken = evt.getParameter("selectedContexts").map(function (oContext) {
return oContext.getObject();
})
this._onSelectResources(aToken);
},
onSelectIOOwner: function (evt) {
const oAssignmentsModel = this.getView().getModel("assignmentsModel");
let aToken = evt.getParameter("selectedContexts").map(function (oContext) {
oContext.getObject().IOOwnerDetails = {
	"IOOwnerName": `${oContext.getObject().firstName} ${oContext.getObject().lastName}`,
	"IOOwnerEmail": oContext.getObject().email,
	"IOOwnerUserId": oContext.getObject().ID,
}
return oContext.getObject();
})

this.oContextAssignmentIOOwnerObj.selectedIOOwner = aToken;
this.getView().getModel("assignmentsModel").refresh();

this._fnIOOwnerValidation(aToken, this.oContextAssignmentIOOwnerObj);
oAssignmentsModel.refresh(true);
// this.oNomineeValueHelpControl.setBusy(false);
},
fnSuccessISPCall: function (response, self) {
let isAutoStaffing = response.d.Zflag;
const sMessage = response.d.Zmsg
if (sMessage === "Record exists in ZSOL_CC") {
self.isAutoStaffing = true;
}
self.isAutoStaffing = isAutoStaffing;
},
//resouce select validation
_fnIOOwnerValidation: function (aToken, oContextAssignment) {
if (aToken.length) {
oContextAssignment.ioOwnerValueState = "None";
} else {
oContextAssignment.ioOwnerValueState = "Error";
}
this.getView().getModel("assignmentsModel").refresh();

},
onPresalesDialogClose: function (oEvent) {
oEvent.getSource().getBinding("items").filter([]);
const aResources = this.getView().getModel("resourceModel").getData().availableResources;
aResources.forEach(function (resource) {
resource.selected = false;
});

},

//resouce select validation
_fnResourceValidation: function (aToken, oContextAssignment) {
if (aToken.length) {
oContextAssignment.resourceValueState = "None";
} else {
oContextAssignment.resourceValueState = "Error";
}
this.getView().getModel("assignmentsModel").refresh();
if (this.getView().getModel().getData().ResReject !== true) {
// this._onValidateAssignment();
}
},
//remove resource token event
onResourceUpdate: function (evt) {
const aRemovedToken = evt.getParameter("removedTokens");
const oAssignments = evt.getSource().getBindingContext("assignmentsModel").getObject();
let oRemovedObj;
if (aRemovedToken.length) {
oRemovedObj = {
	"fullName": aRemovedToken[0].getText(),
	"email": aRemovedToken[0].getKey(),
	"selected": false
}
}
//update selection for resource selection
const aSelectedNominee = oAssignments.selectedNominees;
aSelectedNominee.forEach(function (nom, index, object) {
if (nom.fullName === oRemovedObj.fullName && nom.email === oRemovedObj.email) {
	aSelectedNominee.splice(index, 1);
	return;
}
});
if (oAssignments.isIOStaffing) {
this._checkResourceAutoStaffing(aSelectedNominee, oAssignments);
}
this._fnResourceValidation(aSelectedNominee, oAssignments);
},
_checkResourceAutoStaffing: function (aSelectedNominee, oAssignments) {
//check autostaffing based on resource updates
let bIsAutoStaffing = aSelectedNominee.every(val => val.isAutoStaffing === true);
	//Change Request to IO Staffing Working for EMEA #93 start
	//check company code eq to sales org for all the resources and auto staffing
	let bCompanySalesOrgNoMatch = aSelectedNominee.every(val => !val.isStaffing);
	let bSkipIOFlag = this.getView().getModel("WFRoutingSkipIOAPIData").getProperty("/value/0/operationalStatus");
	if ((bSkipIOFlag && !bIsAutoStaffing && !bCompanySalesOrgNoMatch) || (!bSkipIOFlag && !bIsAutoStaffing)) {
	//company code not eq to salesOrg for all the resources
//not autostaffed - show staffing fields
oAssignments.staffingPurposeVisible = true;
oAssignments.ioOwnerFieldVisible = oAssignments.isOppOwnerActive;
oAssignments.ioOwnerTextFieldVisible = true;
oAssignments.staffingDateRangeVisible = true;
oAssignments.maxNoOfDaysToBookIOVisible = true;
oAssignments.taskLevelVisible = true;
oAssignments.expectedTimeInvstementVisible = false;
oAssignments.staffingMsgVisible = false;
} else{
	 //company code eq to salesOrg for atleast one resource
//auto staffed - hide staffing fields
oAssignments.staffingPurposeVisible = false;
oAssignments.ioOwnerFieldVisible = false;
oAssignments.ioOwnerTextFieldVisible = false;
oAssignments.staffingDateRangeVisible = false;
oAssignments.maxNoOfDaysToBookIOVisible = false;
oAssignments.taskLevelVisible = false;
oAssignments.expectedTimeInvstementVisible = true;
if(!bIsAutoStaffing && aSelectedNominee.length){
	//set warning message
	this._setStaffingMsg(aSelectedNominee,oAssignments);
}
}

if(!aSelectedNominee.length){
	oAssignments.expectedTimeInvstementVisible = false;
	oAssignments.staffingMsgVisible = false;
}

this.getView().getModel("assignmentsModel").refresh(true);
},
onIOOwnerUpdate: function (evt) {
const oAssignments = evt.getSource().getBindingContext("assignmentsModel").getObject();
//update selection for resource selection
const aSelectedIOOwner = [];
this._fnIOOwnerValidation(aSelectedIOOwner, oAssignments);
},
onApprove: function () {
//final approve action
const oFinalPayload = this._fnConfigAssignmentsPayload();
const oModel = this.getModel();
oModel.refresh(true);
const oAssignments = oFinalPayload.Assignment;
const taskId = this.getComponentData().startupParameters.taskModel.getData().InstanceID;
this._triggerComplete(oAssignments, taskId,
"Approve");
},
_fnConfigAssignmentsPayload: function () {
//set payload for context
const oAssignmentsModel = this.getView().getModel("assignmentsModel");
const aAssignmentsData = oAssignmentsModel.getData().assignments;
const aAssignmentPayload = [];
aAssignmentsData.forEach(function (assignment, index) {
let oAssignmentPayloadObj = {};
let aFinalNominee = [];
let aNominee = assignment.selectedNominees;
aNominee.forEach(function (nom) {
	delete nom.selected;
	nom.isIOStaffing = assignment.isIOStaffing;
	nom.staffingPurpose = assignment.staffingPurpose;
	nom.staffingPurposeKey = assignment.staffingPurposeKey;
	nom.taskLevelKey = assignment.taskLevelKey;
	nom.taskLevelEnable = assignment.taskLevelEnable;
	nom.taskLevelVal = assignment.taskLevelVal;
	nom.staffingDateRange = assignment.staffingDateRange;
	nom.dateValue = assignment.dateValue;
	nom.secondDateValue = assignment.secondDateValue;
	nom.maxNoOfDaysToBookIO = assignment.maxNoOfDaysToBookIO;
	nom.isForward = assignment.isForward;
	nom.internalOrder = assignment.internalOrder ? assignment.internalOrder : assignment.selectedInternalOrder;
  
	if (assignment.selectedIOOwner) {
		nom.ioOwnerDetails = assignment.selectedIOOwner.length ? assignment.selectedIOOwner[0].IOOwnerDetails : "";
	}
  
	aFinalNominee.push(nom)

});
const sAssignmentId = index + 1;
const selectedTimeInvestment = (assignment.selectedTimeInvestment === 0) ? "" :
	assignment.selectedTimeInvestment;
oAssignmentPayloadObj.TimeInvestment = selectedTimeInvestment.toString();
oAssignmentPayloadObj.AssignmentID = sAssignmentId.toString();
oAssignmentPayloadObj.NominatedResources = aNominee;
oAssignmentPayloadObj.isIOStaffing = assignment.isIOStaffing;
oAssignmentPayloadObj.internalOrderFormVisible = assignment.internalOrderFormVisible;
oAssignmentPayloadObj.ioOwnerFieldVisible = assignment.ioOwnerFieldVisible;
oAssignmentPayloadObj.ioOwnerTextFieldVisible = assignment.ioOwnerTextFieldVisible;
oAssignmentPayloadObj.staffingPurposeVisible = assignment.staffingPurposeVisible;
oAssignmentPayloadObj.expectedTimeInvstementVisible = assignment.expectedTimeInvstementVisible;
oAssignmentPayloadObj.taskLevelVisible = assignment.taskLevelVisible;
oAssignmentPayloadObj.staffingDateRangeVisible = assignment.staffingDateRangeVisible;
oAssignmentPayloadObj.maxNoOfDaysToBookIOVisible = assignment.maxNoOfDaysToBookIOVisible;
oAssignmentPayloadObj.taskLevelEnable = assignment.taskLevelEnable;
 //set assignment comment
 oAssignmentPayloadObj.comments = assignment.comments;
	//Change Request to IO Staffing Working for EMEA #93 start
	//set staffing msg payload
	oAssignmentPayloadObj.staffingMsgVisible = oAssignmentPayloadObj.staffingMsgVisible ? oAssignmentPayloadObj.staffingMsgVisible : false;
	// //Change Request to IO Staffing Working for EMEA #93 end


oAssignmentPayloadObj.NominatedResources = aNominee;
aAssignmentPayload.push(oAssignmentPayloadObj);

});
const oFinalPayload = {
"Assignment": aAssignmentPayload
};
return oFinalPayload;
},
//delete assignment
onDeleteAssignment: function (evt) {
const oAssignmentObj = evt.getSource().getBindingContext("assignmentsModel").getObject();
const oAssignmentsModel = this.getView().getModel("assignmentsModel");
const filteredArray = oAssignmentsModel.getData().assignments.filter(e => e !== oAssignmentObj);
if (filteredArray.length === 1) {
filteredArray[0].assignmentDelete = false;
} else {
filteredArray.forEach(function (val) {
	val.assignmentDelete = true;
});
}
filteredArray.forEach(function (assignments, i) {
assignments.AssignmentID = i + 1;
})
oAssignmentsModel.setProperty("/assignments", filteredArray);
oAssignmentsModel.refresh(true);
},
//role selection change event
onSelectRole: function (evt) {
const sSelectedKey = evt.getParameter("value");
const oAssignmentsModel = this.getView().getModel("assignmentsModel");
const oSelectedObj = evt.getSource().getBindingContext("assignmentsModel").getObject();
if (sSelectedKey) {
oSelectedObj.roleValueState = "None";
} else {
oSelectedObj.roleValueState = "Error";
}
oAssignmentsModel.refresh(true);
if (this.getView().getModel().getData().ResReject !== true) {
//this._onValidateAssignment();
}

},
//Task level change event
onSelectTaskLevel: function (evt) {
const sSelectedKey = evt.getParameter("selectedItem").getKey();
const oAssignmentsModel = this.getView().getModel("assignmentsModel");
const sSelectedText = evt.getParameter("selectedItem").getText();
const oSelectedObj = evt.getParameter("selectedItem").getBindingContext("assignmentsModel").getObject();
if (sSelectedKey !== "Sel") {
oSelectedObj.taskLevelValueState = "None";
oSelectedObj.taskLevelVal = sSelectedText;
oSelectedObj.taskLevelKey = sSelectedKey
} else {
oSelectedObj.taskLevelValueState = "Error";

}
oAssignmentsModel.refresh(true);

},
//Staffing purpose change event
onSelectStaffingPurpose: function (evt) {
const sSelectedKey = evt.getParameter("selectedItem").getKey();
const sSelectedText = evt.getParameter("selectedItem").getText();
const oAssignmentsModel = this.getView().getModel("assignmentsModel");
const oSelectedObj = evt.getParameter("selectedItem").getBindingContext("assignmentsModel").getObject();
oSelectedObj.taskLevelEnable = true;
oSelectedObj.taskLevelKey = "NONE";
if (sSelectedKey !== "Sel") {
oSelectedObj.staffingPurposeValueState = "None";
oSelectedObj.taskLevelVisible = true;
oSelectedObj.taskLevelEnable = sSelectedKey === "E" ? false : true;
oSelectedObj.taskLevelVal = sSelectedKey === "E" ? "" : "NONE-None";
oSelectedObj.taskLevelValueState = "None";
oSelectedObj.staffingPurpose = sSelectedText;
oSelectedObj.staffingPurposeKey = sSelectedKey;
} else {
oSelectedObj.staffingPurposeValueState = "Error";
if (sSelectedKey === "Sel") {
	oSelectedObj.taskLevelEnable = false;
}
}
oAssignmentsModel.refresh(true);

},
//Date selection change event
onStaffingDateRangeChange: function (evt) {
const sDateVal = evt.getParameter("value");
const oAssignmentsModel = this.getView().getModel("assignmentsModel");
const oSelectedObj = evt.getSource().getBindingContext("assignmentsModel").getObject();
if (sDateVal) {
oSelectedObj.dateRangeValueState = "None";
} else {
oSelectedObj.dateRangeValueState = "Error";
}
oAssignmentsModel.refresh(true);

},
fetchPreSalesRoleData: function (self) {
const sUrl = self._getRuntimeBaseURL() + "/resources/req-area-api-/Presales_role";
$.ajax({
contentType: "application/json",
url: sUrl,
async: false,
type: "GET",
success: function (oData) {
	let oRolesModel = new JSONModel(oData);
	const sSalesOrg = 'ParentOrgID' in self.getModel().getData() ? self.getModel().getProperty("/ParentOrgID") : self.getModel().getProperty("/OrgID");
	const sOrgType = self.getModel().getProperty("/OrgType");
	const sFormatOrgID = self._getOrgIDnumber(sSalesOrg, sOrgType);
	const result = oData.value.reduce(function (r, a) {
		r[a.orgID] = r[a.orgID] || [];
		r[a.orgID].push(a);
		return r;
	}, Object.create(null));
	oRolesModel = result[sFormatOrgID];
	oData.value = [];
	oData.value = oRolesModel;
	const oRoleModelData = new JSONModel(oData);
	self.getView().setModel(oRoleModelData, "rolesModel");

},
error: function (oError) {

}
});
},

_onValidateAssignment: function () {
//validate assignment fields
let bAssignmentMandtValidation;
let bAssignmentValidation;
let bCommentValidation;
const oAssignmentsModel = this.getView().getModel("assignmentsModel");
const oAssignmentsData = oAssignmentsModel.getData().assignments;
const oInternalOrderModel = this.getView().getModel("internalOrderModel").getData();
const sReqType = this.getModel().getProperty("/RequestType");
let that = this;
//validation for approve
if (oAssignmentsData.length) {
oAssignmentsData.forEach(function (assignment) {
	assignment.roleValueState = assignment.selectedRole === "" ? "Error" : "None";
	if (oInternalOrderModel.length > 1) {
		assignment.internalOrderSelectValueState = assignment.selectedRole === "" ? "Error" : "None";
	}
	assignment.resourceValueState = !assignment.selectedNominees.length ? "Error" : "None";
	let bIsAutoStaffingCompanyCode = assignment.selectedNominees.every(val => val.isAutoStaffingCompanyCode === true);
	let bNoException = assignment.selectedNominees.every(val => val.isPartOfException === false);
                    let bSkipIOFlag = that.getView().getModel("WFRoutingSkipIOAPIData").getProperty("/value/0/operationalStatus");
                    if (assignment.isIOStaffing && sReqType === "Opportunity" && (bIsAutoStaffingCompanyCode || !bSkipIOFlag || !bNoException ) && assignment.staffingDateRangeVisible) {
		let bIsAutoStaffing = assignment.selectedNominees.every(val => val.isAutoStaffing === true);
		if (!bIsAutoStaffing) {
			assignment.staffingPurposeValueState = assignment.staffingPurposeKey === "Sel" ? "Error" : "None";
			assignment.dateRangeValueState = !assignment.staffingDateRange ? "Error" : "None";
			assignment.daysToBooksValueState = !assignment.maxNoOfDaysToBookIO ? "Error" : "None";
			if (assignment.staffingPurposeKey === "E") {
				assignment.taskLevelValueState = "None"
			} else {
				assignment.taskLevelValueState = assignment.taskLevelKey === "Sel" ? "Error" : "None";
			}
		}
		assignment.internalOrderSelectValueState = !assignment.internalOrderSelectValueState ? "Error" : "None";
		assignment.ioOwnerValueState = !assignment.selectedIOOwner.length ? "Error" : "None";
		if (!assignment.selectedNominees.length || (!bIsAutoStaffing && !assignment.staffingPurpose) || (!bIsAutoStaffing && !assignment.staffingDateRange)
			|| (!bIsAutoStaffing && !assignment.maxNoOfDaysToBookIO) || !assignment.selectedIOOwner.length ||
			(!bIsAutoStaffing && assignment.staffingPurposeKey === "Sel") || assignment.taskLevelValueState === "Error") {
			bAssignmentMandtValidation = true;
			bAssignmentValidation = true;
		}
	} else {
		if (!assignment.selectedNominees.length) {
			bAssignmentMandtValidation = true;
			bAssignmentValidation = true;
		}
	}


});
if(oAssignmentsData.filter(assignment=> assignment.resCommentValueState === "Error").length){
	//validation on comment => Restrict the max length to 5000
	 bCommentValidation = true;

 }
}
let sCommentValidationMsg = this.getOwnerComponent().getModel("appConstants").getProperty("/commentValidationMsg/0/Value");
if (bAssignmentMandtValidation === true) {
   const si18nAssignmentErrMsg = !bCommentValidation ? this.i18nModel.getText("assignmentValidationMsg"):
                `${this.i18nModel.getText("assignmentValidationMsg")} ${this.i18nModel.getText("and")} ${sCommentValidationMsg}`
MessageBox.error(si18nAssignmentErrMsg, {
	actions: [MessageBox.Action.OK],
	emphasizedAction: MessageBox.Action.OK
});
}else if(bCommentValidation){
	//popup comment validation message
	MessageBox.error(sCommentValidationMsg, {
		actions: [MessageBox.Action.OK],
		emphasizedAction: MessageBox.Action.OK
	});

}else if  (bAssignmentMandtValidation !== true && bAssignmentValidation !== true) {
const bSkipResources = this.getModel().getProperty("/Skip_Resource_Approver");
if (bSkipResources) {
	//Skip resource approver-->Direct Manger approve
	let aStaffingData = [];
	oAssignmentsData.forEach(function (assignment) {
		const aNominatedResource = assignment.selectedNominees[0];
		if (!aNominatedResource.isAutoStaffing) {
			if (aNominatedResource.isAutoStaffingCompanyCode || aNominatedResource.isPartOfException) {
				aNominatedResource.dateValue = assignment.dateValue;
				aNominatedResource.secondDateValue = assignment.secondDateValue;
				aNominatedResource.taskLevelKey = assignment.taskLevelKey;
				aNominatedResource.taskLevelVal = assignment.taskLevelVal;
				aNominatedResource.internalOrder = assignment.internalOrder;
				aNominatedResource.maxNoOfDaysToBookIO = assignment.maxNoOfDaysToBookIO;
				aNominatedResource.isForward = assignment.isForward;
				aNominatedResource.staffingPurpose = assignment.staffingPurpose;
				aNominatedResource.staffingPurposeKey = assignment.staffingPurposeKey;
				aStaffingData.push(aNominatedResource);
			}
		}

	});
	if (aStaffingData.length) {
		//prepare staffing payload
		this._formStaffingPayload(this, aStaffingData, bSkipResources)
	}else {
		//proceed wf trigger
		this.onApprove();
	}
} else {
	 //proceed wf trigger
	this.onApprove();
}
}
oAssignmentsModel.refresh(true);
},
//format IO staffing switch visibility
formatIOStaffingToggle: function (sRequestType, oOpportunityResponse, sOperationalStatus) {
if (sOperationalStatus && sRequestType === "Opportunity" && oOpportunityResponse.length) {
return true;
} else {
return false;
}
},
onChangeCommentsLengthValidation:function(evt){
	//live change on comment input value and check the validation
	const oBindingContext = evt.getSource().getBindingContext("assignmentsModel").getObject();
	oBindingContext.comments = evt.getParameter("value");
	if(evt.getParameter("value").length > 5000){
		oBindingContext.resCommentValueState = "Error";
	}else{
		oBindingContext.resCommentValueState = "None";
	}
},
//format Internal order text control visibility if one internal order
formatIODisplayMessage: function (oOpportunityResponse, sRequestType,bOPerationalFlag) {
if (sRequestType === "Opportunity" && bOPerationalFlag && !oOpportunityResponse.length) {
this.getView().byId("idAssignmntPanel").addStyleClass("customMessageStripPanel");
return true;
} else {
this.getView().byId("idAssignmntPanel").removeStyleClass("customMessageStripPanel");
return false;
}
},
//format Internal order select control visibility if two or more internal order
formatFormInternalOrderSelectVisibility: function (aInternalOrder, isStaffingVisible, sReqType) {
if (sReqType === "Opportunity" && isStaffingVisible && aInternalOrder.length > 1) {
return true;
} else {
return false;
}
},
formatFormInternalOrderDisplayVisibility: function (aInternalOrder, isStaffingVisible, sReqType) {
if (sReqType === "Opportunity" && isStaffingVisible && aInternalOrder.length === 1) {
return true;
} else {
return false;
}
},
/* Start of Code for CurrentTask Instance ID Update  */
updateCurrentInstance: function () {
	const WfExt_data = {};
	var URL = this._getRuntimeBaseURL() + "/resources/wf/WfInstance";
	var oModelData = this.getView().getModel().getData();
	const sStep = this.getModel().getProperty("/currentStepID");
	const oContextModelData = this.getModel();
	let that = this;
	// 	WfExt_data.instance_GUID = oContextModelData.getProperty("/workflowInstanceId");
	// if (sStep !== "MANAPP") {
	WfExt_data.instance_GUID = oContextModelData.getProperty("/WfID_PresalesRequestApproval");
	// WfExt_data.ResourcesUserTaskID = this.getParentModel("taskInstanceModel").getProperty("/id");
	// } 
	WfExt_data.parentInstance_GUID = oContextModelData.getProperty("/parentInstanceID");
	if(!WfExt_data.parentInstance_GUID){
		const sURL = `${URL}?$filter=instance_GUID eq ('${WfExt_data.instance_GUID}')`
		this.getWfInstanceModel(sURL, this);
		WfExt_data.parentInstance_GUID = this.getView().getModel("WfInstanceModel").getData()[0].parentInstance_GUID;
	}
	WfExt_data.currentTaskInstanceID = this.getParentModel("taskInstanceModel").getProperty("/id");
	WfExt_data.currentTaskURL = window.location.href;
	const instGuid = `(instance_GUID='${WfExt_data.instance_GUID}',parentInstance_GUID='${WfExt_data.parentInstance_GUID}')`;
	// WfExt_data.CurrentTaskURL = window.location.href; 
	$.ajax({
	url: URL,
	type: "GET",
	async: true,
	beforeSend: function (xhr) {
		xhr.setRequestHeader("X-CSRF-Token", "Fetch");
	},
	complete: function (xhr) {
		token = xhr.getResponseHeader("X-CSRF-Token"); const oSettings = {
			"url": URL + instGuid,
			"method": "PATCH",
			"async": false,
			"data": JSON.stringify(WfExt_data),
			"headers": {
				'X-CSRF-Token': token
			},
			"contentType": "application/json",
		};
		$.ajax(oSettings)
			.done(function (results) { 
				if(typeof that.getModel().getData().RequestID !== "object" && typeof results === "object"){
                    if(results.refID){
                        oContextModelData.setProperty("/updatedRefId" ,results.refID);
                    }
                }
			})
			.fail(function (err) {
				MessageBox.error("Current user Instance ID update failed!");
			});
	}
	});
},
		getWfInstanceModel: function (sUrl, self) {
			$.ajax({
				async: false,
				contentType: "application/json",
				url: sUrl,
				type: "GET",
				success: function (oData) {
					const aResult = oData.value;
					const oWfInstanceModel = new JSONModel();
					oWfInstanceModel.setData(aResult);
					self.getView().setModel(oWfInstanceModel, "WfInstanceModel");

				}.bind(this),
				error: function (oError) {
				}
			});
		},
/* End of Code for CurrentTask Instance ID Update  */

formatAssignmentOppDisplay: function (sRequestType) {
if (sRequestType == "Opportunity") {
return true;
} else {
return false;
}
},
formatAssignmentAccDisplay: function (sRequestType) {
if (sRequestType == "Account") {
return true;
} else {
return false;
}
},
_getServiceUrl: function (ApproversBaseUrl, sProfitcenter, tableTypeId, isSubsFlag ) {
            const filterValues = {
				"TableTypeID": tableTypeId,
				"Manager_Level": "non-managerial",
				"aRoles":this.getView().getModel("employee").getProperty(`/TempEmployee/TempRoles`).RolesData,
				"aSubsRoles":this.getView().getModel("employee").getProperty(`/TempEmployee/TempRoles`).aSubstituteRoleRoleArea
			};
			const sManagerLevel = `(ManagerLevel eq 'non-managerial')`;
			const baIndustriesGuid = this.getView().getModel("employee").getData().TempEmployee.BAIndustries;
			const baIndustries_GUIDs = baIndustriesGuid.map(item => item.BaIndId);
			//set Role payload
			const aFinaRole = isSubsFlag ? filterValues.aSubsRoles:filterValues.aRoles;
			this.getView().getModel("employee").setProperty("/aFinalRolePaylod",aFinaRole);
			const filterCondition1 = baIndustries_GUIDs.length ? `(${baIndustries_GUIDs.map(BaIndId => `(BaIndId eq '${BaIndId}')`).join(' or ')})` :
				`(BaIndId eq '')`;
				const aSolAreas = this.getView().getModel("employee").getData().TempEmployee.SolutionAreas;
				const aSolAreas_GUIDs = aSolAreas ? aSolAreas.map(item => item.soln_id) : [];
				
				const parentSolIds = aSolAreas ? aSolAreas.map(item => item.prnt_soln_id) : [];
            let filterConditionSolAreas = "";
            let filterParts = [];
            aSolAreas_GUIDs.forEach((soln_id, index) => {
                const relatedArea = aSolAreas[index];
                const parentSolId = parentSolIds[index]; 
                if (relatedArea.soln_prnt_guid === "00000000-0000-0000-0000-000000000000") {
                  filterParts.push(`(SolAreaL1Id eq '${soln_id}' and SolAreaL2Id eq '')`);
                } else {
                  filterParts.push(`(SolAreaL2Id eq '${soln_id}' and SolAreaL1Id eq '${parentSolId}')`);
                }
              });
            filterConditionSolAreas = filterParts.length
                ? `(${filterParts.join(' or ')})`
                : `(SolAreaL1Id eq '' and SolAreaL2Id eq '')`;
			//multiple profit center
			const aSelectedProfitCenter = JSON.parse(JSON.stringify(this.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories));
            for (let i = 0; i < aSelectedProfitCenter.length; i++) {
				if (!aSelectedProfitCenter[i].isCheckBox || !aSelectedProfitCenter[i].isResourceProfile) {
					aSelectedProfitCenter.splice(i, 1)
				}
			}
			const aFinalPfc = aSelectedProfitCenter.filter((obj1, i, arr) => 
				arr.findIndex(obj2 => (obj2.SelectedGuid === obj1.SelectedGuid)) === i
			  );
            const aSelectedPfcGuids = aFinalPfc.map(item => item.TrpcId);
			const filterCondition5 = aSelectedPfcGuids.length ? `(${aSelectedPfcGuids.map(SelectedGuid => `(TrpcId eq '${SelectedGuid}')`).join(' or ')})` : `(TrpcId  eq '')`;
			 //role data
			 const aRoleIds = isSubsFlag ? filterValues.aSubsRoles.map(item => item.RoleID):filterValues.aRoles.map(item => item.RoleID);
			 const aUniqueRoleIds = aRoleIds.filter((item, index) => aRoleIds.indexOf(item) === index);
			 const filterConditionForRoles = aUniqueRoleIds.length ? `(${aUniqueRoleIds.map(roleId => `RoleId eq '${roleId}'`).join(' or ')})` :
				 `(RoleId eq '')`;
			 //filter condition for Role Areas
			 const aRoleAreaIds = isSubsFlag ? filterValues.aSubsRoles.map(item => item.RoleAreaID) : filterValues.aRoles.map(item => item.RoleAreaID);
			 const aUniqueRoleAreaIds = aRoleAreaIds.filter((item, index) => aRoleAreaIds.indexOf(item) === index);
			 const filterConditionForRoleArea = aUniqueRoleAreaIds.length ? `(${aUniqueRoleAreaIds.map(roleAreaId => `RoleAreaId eq '${roleAreaId}'`).join(' or ')})` :
				 `(RoleAreaId eq '')`;
			let finalFilterString =
				`$filter=${sManagerLevel} and (TableTypeId eq '${filterValues.TableTypeID}') and 
							${filterConditionForRoles} and ${filterConditionForRoleArea} and (RecordStatus eq '01')`; 
			let aIACID = this.getView().getModel("IACRoleAreaModel").getData() ? this.getView().getModel("IACRoleAreaModel").getData()[0].IacId : "";
			let filterConditionIAC = `(IacValue eq '${aIACID}')`;
			const filterConditions = [filterCondition5];
			if (this.getView().getModel("employee").getProperty(`/BAIndustrySelectable`)) {
				//push only if industry field is selectable/visible
				filterConditions.push(filterCondition1);
			}
			if (this.getView().getModel("employee").getProperty(`/SolnAreaSelectable`)) {
				//push only if solution area is selectable/visible
				filterConditions.push(filterConditionSolAreas);
			}
			if (this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/Operational_Status") && !this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/isIACQueryRemove")) {
				filterConditions.push(filterConditionIAC)
			}
			if(this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/Operational_Status") && !this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/isIACQueryRemove")){
				filterConditions.push(filterConditionIAC)
			}
			const nonEmptyFilters = filterConditions.filter(condition => condition !== '');
			if (nonEmptyFilters.length > 0) {
				finalFilterString += ' and ';
				finalFilterString += nonEmptyFilters.join(' and ');
			}
			return `${finalFilterString}&$expand=to_substitute`;
        },
        
_getServiceBSUrl: function (ApproversBaseUrl, sProfitcenter, tableTypeId,isSubsFlag) {
	const filterValues = {
		"ProfitCenterGUID": sProfitcenter,
		"TableTypeID": tableTypeId,
		"Manager_Level": "non-managerial",
		"aRoles":this.getView().getModel("employee").getProperty(`/TempEmployee/TempRoles`).RolesData,
		"aSubsRoles":this.getView().getModel("employee").getProperty(`/TempEmployee/TempRoles`).aSubstituteRoleRoleArea
	};
	const sManagerLevel = `((ManagerLevel eq 'non-managerial') or (ManagerLevel eq '*'))`;
	const baIndustriesGuid = this.getView().getModel("employee").getData().TempEmployee.BAIndustries;
	const baIndustries_GUIDs = baIndustriesGuid.map(item => item.BaIndId);
	//set Role payload
	const aFinaRole = isSubsFlag ? filterValues.aSubsRoles:filterValues.aRoles;
	this.getView().getModel("employee").setProperty("/aFinalRolePaylod",aFinaRole);
	let filterCondition1 = baIndustries_GUIDs.length ? `(${baIndustries_GUIDs.map(BaIndId => `(BaIndId eq '${BaIndId}')`).join(' or ')} or (BaIndId eq '*'))` :
         "(BaIndId eq '')";
                let aSolAreas = this.getView().getModel("employee").getData().TempEmployee.SolutionAreas;
                let filterConditionSolAreas = "";
                if (aSolAreas.length) {
                    const filterParts = aSolAreas.map(item => {
                        if (item.soln_prnt_guid === "00000000-0000-0000-0000-000000000000") {
                             return `(SolAreaL1Id eq '${item.soln_id}' or SolAreaL1Id eq '*') and (SolAreaL2Id eq '')`;
                        } else {
							return `(SolAreaL2Id eq '${item.soln_id}' or SolAreaL2Id eq '*') and (SolAreaL1Id eq '${item.prnt_soln_id}' or SolAreaL1Id eq '*')`
                        }
                    });
                     filterConditionSolAreas = filterParts.join();
				}else{
					filterConditionSolAreas = "(SolAreaL2Id eq '' ) and (SolAreaL1Id eq '')";
				}
			//multiple profit center
			const aSelectedProfitCenter = JSON.parse(JSON.stringify(this.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories));
            for (let i = 0; i < aSelectedProfitCenter.length; i++) {
				if (!aSelectedProfitCenter[i].isCheckBox || !aSelectedProfitCenter[i].isResourceProfile) {
					aSelectedProfitCenter.splice(i, 1)
				}
			}
			const aFinalPfc = aSelectedProfitCenter.filter((obj1, i, arr) => 
				arr.findIndex(obj2 => (obj2.SelectedGuid === obj1.SelectedGuid)) === i
			  );
			const aSelectedPfcGuids = aFinalPfc.map(item => item.TrpcId);
			 //filter condition for Roles
			 const aRoleIds = isSubsFlag ? filterValues.aSubsRoles.map(item => item.RoleID):filterValues.aRoles.map(item => item.RoleID);
			 const aUniqueRoleIds = aRoleIds.filter((item, index) => aRoleIds.indexOf(item) === index);
			 const filterConditionForRoles = aUniqueRoleIds.length ? `(${aUniqueRoleIds.map(roleId => `RoleId eq '${roleId}'`).join(' or ')})` :
				 `(RoleId eq '*')`;
			 //filter condition for Role Areas
			 const aRoleAreaIds = isSubsFlag ? filterValues.aSubsRoles.map(item => item.RoleAreaID) : filterValues.aRoles.map(item => item.RoleAreaID);
			 const aUniqueRoleAreaIds = aRoleAreaIds.filter((item, index) => aRoleAreaIds.indexOf(item) === index);
			 const filterConditionForRoleArea = aUniqueRoleAreaIds.length ? `(${aUniqueRoleAreaIds.map(roleAreaId => `RoleAreaId eq '${roleAreaId}'`).join(' or ')})` :
				 `(RoleAreaId eq '*')`;
			const filterCondition5 = aSelectedPfcGuids.length ? `(${aSelectedPfcGuids.map(SelectedGuid => `(TrpcId eq '${SelectedGuid}')`).join(' or ')})` : "";
            let finalFilterString =
                `$filter=${sManagerLevel} and (TableTypeId eq '${filterValues.TableTypeID}') and
                (${filterConditionForRoles} or (RoleId eq '*')) and (${filterConditionForRoleArea} or (RoleAreaId eq '*')) and (RecordStatus eq '01')`;
                let aIACID = this.getView().getModel("IACRoleAreaModel").getData() ? this.getView().getModel("IACRoleAreaModel").getData()[0].IacId : "";
                let filterConditionIAC = `(IacValue eq '${aIACID}' or IacValue eq '*')`;
                
				const filterConditions = [filterCondition5,filterCondition1,filterConditionSolAreas];
				if(this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/Operational_Status") && !this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/isIACQueryRemove")){
					filterConditions.push(filterConditionIAC)
				}
			const nonEmptyFilters = filterConditions.filter(condition => condition !== '');
 
			if (nonEmptyFilters.length > 0) {
				finalFilterString += ' and ';
				finalFilterString += nonEmptyFilters.join(' and ');
			}
			return `${finalFilterString}&$expand=to_substitute`;
},
/*RESOURCE PROFILE SCREEN*/
/*Reset resource profile models*/
_resetResourceProfile: function () {
	const oModel = this.getView().getModel("employee");
	oModel.setProperty("/SelectedRoleKey", "");
	oModel.setProperty("/SelectedRoleAreasKey", "")
	oModel.setProperty("/TempEmployee/BAIndustries", []);
	oModel.setProperty("/TempEmployee/BALoBs", []);
	oModel.setProperty("/TempEmployee/CrossCvg", []);
	oModel.setProperty("/TempEmployee/BASegments", []);
	oModel.setProperty("/TempEmployee/SelectedHubs", []);
	oModel.setProperty("/TempEmployee/Roles", []);
	oModel.setProperty("/TempEmployee/RoleAreas", []);
	oModel.setProperty("/TempEmployee/selectedBALob", "");
	oModel.setProperty("/TempEmployee/selectedCrossCoverage", "");
	oModel.setProperty("/TempEmployee/selectedBAIndustry", "");
	oModel.setProperty("/TempEmployee/TempBALoBs",[]);
	oModel.setProperty("/TempEmployee/TempBAIndustries", []);
	oModel.setProperty("/TempEmployee/TempCrossCvg", []);
	oModel.setProperty("/TempEmployee/SolutionAreas", []);
	oModel.refresh();
	// this.getView().byId("idBusinessAreaInPrim").setRequired(true);
	// this.getView().byId("idBusinesslobPrim").setRequired(true);
	oModel.setProperty("/sSearchBoxText", "");
},
/*Event trigger for Resource Profile selection*/
onResourceProfileSelectionPress: function (isReqArea) {
	const oView = this.getView();
	var that = this;
	const oModel = this.getView().getModel();
	const sSalesOrg = oModel.getProperty("/OrgID");
	const isResourceProfile = oModel.getProperty("/isResourceProfile");
	//set Button model for forward request
	const oProfileViewModel = new sap.ui.model.json.JSONModel();
	const oProfileView = {
		"footerButtons": {
			"forwardReqButtonVisible": false,
			"searchResourceButtonVisible": false,
			"forwardReqButtonEnabled": false,
			"searchResourceButtonEnabled": false,
			"errorBtnVisible": false
		},
		"isProfitCenterTextVisible": false,
		"isProfitCenterInputVisible": false,
		"isReqAreaContainerVisible": !isResourceProfile,
		"isResProfileConatiner": isResourceProfile
	}
	oProfileViewModel.setData(oProfileView);
	this.getView().setModel(oProfileViewModel, "profileViewParameters");
	const oErrorModel = new sap.ui.model.json.JSONModel();
	const oErrorData = {
		"errorInformation": []
	}
	oErrorModel.setData(oErrorData);
	this.getView().setModel(oErrorModel, "errorMsgModel");
	/*Open fragment for Resource Profile selection*/
	that.oSLASearchContext = false
	if (!this._pForwardReqialog) {
		this._pForwardReqialog = Fragment.load({
			id: oView.getId(),
	name: "com.sap.bpm.PresalesRequestApproval.fragments.ForwardReqDialog",
			controller: this
		}).then(function (oForwardDialog) {
			if (isReqArea === true) {
				const aResult = that.getView().getModel("RequestAreaAPIData").getData().value;
				const aModel = {};
				aModel.data = that._setReqAreasTree(aResult);
				const oUpdatedReqArea = new JSONModel();
				oUpdatedReqArea.setData(aModel);
				that.getView().setModel(oUpdatedReqArea, "myPresaleModel");
				that._configRequestDialog()
			}
			that.oForwardDialog = oForwardDialog;
			oView.addDependent(oForwardDialog);
			return oForwardDialog;
		});
	}

	this._pForwardReqialog.then(function (oForwardDialog) {
		
		that._onDestroyAllResourcePopOvers();
if(!isResourceProfile){
			/*Request Area selection screen*/
			that.getView().byId("idPFCField").setVisible(false);
			that.getView().getModel("profileViewParameters").setProperty
				("/footerButtons/searchResourceButtonVisible", false);
			that.getView().getModel("profileViewParameters").setProperty
				("/footerButtons/forwardReqButtonVisible", true);
			that.getView().getModel("profileViewParameters").refresh();
			that._configRequestDialog();
}else{
	 
	  //parent selection
			/*Resource Profile selection screen*/
			const sSalesOrgNumber = Number(sSalesOrg.replace('SORG-', '')).toString();
			const sOrgType = that.getView().getModel().getProperty("/OrgType");
			const sOrgID = that.getView().getModel().getProperty("/OrgID");
		that.getView().byId("idMultiInputPFC").getAggregation("tokenizer").setEditable(false);
		that.aSelectedParentNode = false;
		if (that.getView().getModel("selectedProfitCenter")) {
			that.getView().getModel("selectedProfitCenter").setProperty("/TempProfitCenter/Territories", []);
			that.getView().getModel("selectedProfitCenter").setProperty("/TempProfitCenter/filteredProfitCenter", []);
			that.getView().getModel("selectedProfitCenter").refresh(true);
		}
		//parent selection
		Models.getFilteredSalesOrgProfitCenter(that,sOrgID,sOrgType);
	that.loadTreeTerritories("treeTerritories", that.getView().getModel("territoriesMaster").getData(), true);
	that.setTerritoryHierarchySelection(false, false, false,true,true);
	let nodeUpdate = function nodeUpdate(newValue, that) {
		for (const child of newValue.nodes) {
			if (child.isCheckBox && child.isResourceProfile) {
				child.IsSelected = true;
				let oSelectedProfitCenter = Models._setProfitCenterObj(child);
				that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories.push(
					oSelectedProfitCenter);
				that.getView().getModel("selectedProfitCenter").refresh(true);
			}
			nodeUpdate(child, that);
		}
	}
	if (that.aSelectedParentNode && that.aSelectedParentNode.isResourceProfile && that.aSelectedParentNode.isChildNodeEnable) {
		//select child nodes if LAC and isResourceProfile true
		nodeUpdate(that.aSelectedParentNode, that);
	}
	that.getView().getModel("selectedProfitCenter").refresh(true);
	that.getView().getModel("treeTerritories").refresh(true);
		
			that.getView().getModel("crossCvgMasterData").setData(that.getView().getModel("crossCvgMasterData").getData());
			that.getView().getModel("baLoBMasterData").setData(that.getView().getModel("baLoBMasterData").getData());
			that.getView().getModel("baIndMasterData").setData(that.getView().getModel("baIndMasterData").getData());
			 
			that.getView().setModel(new sap.ui.model.json.JSONModel({
				Roles: [],
				SelectedRoles: []
			}), "roles");
			that.getView().setModel(new sap.ui.model.json.JSONModel({
				TempEmployee: {
					"Roles": [],
					"TempRoleAreas": [],
					"TempBAIndustries": [],
					"TempSelectedHubs": [],
					"SelectedHubs": [],
					"TempBALoBs": [],
					"TempCrossCvg": [],
					"BASegmentsBusy": false,
					"BALoBBusy": false,
					"CrossCvgBusy": false,
					"hubLoBBusy": false,
					"BAIndBusy": false,
					"TempBASegments": [],
					"RoleAreas": [],
					"BAIndustries": [],
					"BASegments": [],
					"CrossCvg": [],
					"BALoBs": [],
					"ManagerLevel": [
					]
				},
				"RoleAreas": [],
				"BAIndustries": [],
				"sSearchBoxText": "",
				"BASegments": [],
				"CrossCvg": [],
				"BALoBs": [],
				"SelectedRoleAreas": [],
				"Hubs": [],
				"Rules": {
					"HubIndustry": [],
					"HubLoB": [],
					"HubRole": []
				},
				"BAIndustryMandatory":false,
				"BAIndustrySelectable":true,
				"SolnAreaMandatory":false,
				"SolnAreaSelectable":true,
				"minSelect":0,
                "maxSelect":2,
                "solnAreaEnable":true,
                "industryEnable":true,
                "solnIndRequired":false,
				"midSectionDesc":that.getOwnerComponent().
				getModel("mrrAppConfigModel").getProperty("/SolnInd_SelectionText/0/fieldDesc"),
				"legacyValidation":false,
				"fieldSelectionMidInfoIcon":false,
			}), "employee");
		   that._callBusinessAreaIndustryMasterData();
			oModel.setProperty("/searchItems/0/TempEmployee/selectedBAIndustry", "");
			that.loadRoleTypeData("ROLETYPE", that.getView().getModel("roleMasterData").getData());
			that.getView().getModel("employee").setProperty("/TempEmployee/ManagerLevel", that.getView().getModel("managerLevelMasterData").getData());
			that.getView().byId("idPFCField").setVisible(true);
			that.getView().getModel("profileViewParameters").setProperty
				("/footerButtons/searchResourceButtonVisible", true);
			that.getView().getModel("profileViewParameters").setProperty
				("/footerButtons/forwardReqButtonVisible", false);
			that.getView().getModel("profileViewParameters").refresh();
			//get salesOrg-profitCenter smapping
			const sFilterParams = sOrgType !== "PC" ? `SOrg eq '${sSalesOrgNumber}' and isPC_Viewable eq 'X'` :
				`ProfitCenterGuid eq  ${sOrgID} and isPC_Viewable eq 'X'`;
			var oView = that.getView();
			const oEmployeeModel = oView.getModel("employee");
			const oDataModel = oView.getModel().getData();
			const oProfileDetails = oDataModel.aResourceProfileApprovers.ResourceProfileDetails;

			const oProfileDetailsCopy = JSON.parse(JSON.stringify(oProfileDetails));

			oEmployeeModel.setProperty("/TempEmployee/BASegments", oProfileDetailsCopy.BASegments);
			oEmployeeModel.setProperty("/TempEmployee/CrossCvg", oProfileDetailsCopy.cross_CVRG_P_GUIDArray);
			oEmployeeModel.setProperty("/TempEmployee/BALoBs", oProfileDetailsCopy.BALoBs);
			oEmployeeModel.setProperty("/TempEmployee/SelectedHubs", oProfileDetailsCopy.Hubs);
			oEmployeeModel.setProperty("/TempEmployee/BAIndustries", oProfileDetailsCopy.BAIndustries);
			oEmployeeModel.setProperty("/TempEmployee/TempBALoBs", oProfileDetailsCopy.BALoBs);
			oEmployeeModel.setProperty("/TempEmployee/TempBAIndustries", oProfileDetailsCopy.BAIndustries);
			if(oProfileDetailsCopy.BAIndustries.length > 1){
				oEmployeeModel.setProperty("/TempEmployee/TempBAIndustries", []);
			}else{
				oEmployeeModel.setProperty("/TempEmployee/TempBAIndustries", oProfileDetailsCopy.BAIndustries);
			}
			oEmployeeModel.setProperty("/TempEmployee/TempCrossCvg", oProfileDetailsCopy.cross_CVRG_P_GUIDArray);
	//MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
	if(!oProfileDetailsCopy.SolutionAreas.length){
		oEmployeeModel.setProperty("/TempEmployee/SolutionAreas", []);
		that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",[]);
	}else{
		oEmployeeModel.setProperty("/TempEmployee/SolutionAreas", oProfileDetailsCopy.SolutionAreas);
		that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",oProfileDetailsCopy.SolutionAreas);
	}
                    //set selected solution area
                    //MR: [GRP02-03] GTM25 Resource Profile alignment #84 end
			const oRoleGuid = oProfileDetailsCopy.Role_GUID.RoleGuid;
			const oRoleTypeGuid = oProfileDetailsCopy.Role_GUID.RoleTypeGuid;
			const aRole = [oRoleGuid, oRoleTypeGuid];

			//MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
			//pre select role area for new requests
			that.getView().getModel().getProperty("/isRoleAreaSelection") ? oEmployeeModel.setProperty("/SelectedRoleKey", aRole) : oEmployeeModel.setProperty("/SelectedRoleKey", "");
			//MR: [GRP02-03] GTM25 Resource Profile alignment #84 end

			const oRoleAreaGuid = oProfileDetailsCopy.Role_GUID.RoleGuid;
			const oRoleAreaId = oProfileDetailsCopy.Role_GUID.RoleAreaID;
			const aRoleAreaId = [oRoleAreaId];

			//MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
			//pre select role area for new requests
			that.getView().getModel().getProperty("/isRoleAreaSelection") ? oEmployeeModel.setProperty("/SelectedRoleAreasKey", aRoleAreaId) : oEmployeeModel.setProperty("/SelectedRoleAreasKey", "");
			if (!that.getView().getModel().getProperty("/isRoleAreaSelection")) {
				that.getView().getModel("profileViewParameters").setProperty
					("/footerButtons/searchResourceButtonEnabled", false);
				that.getView().getModel("profileViewParameters").refresh();
			}
	 that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",[])
                   that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/results",[])
                   that.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
			//MR: [GRP02-03] GTM25 Resource Profile alignment #84 end

			oEmployeeModel.setProperty("/SelectedRoleAreasKey", aRoleAreaId);
			oEmployeeModel.setProperty("/aRoleAreas", [oProfileDetailsCopy.RoleArea_P_GUID]);

			const sSelectedBAInd = oProfileDetailsCopy.BAIndustries.length ? oProfileDetailsCopy.BAIndustries[0].Guid:"";
			oEmployeeModel.setProperty("/TempEmployee/selectedBAIndustry", sSelectedBAInd);

	
	that.getView().getModel("selectedProfitCenter").setProperty("/selectedPfc",that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories[0]);
	that.getView().getModel().getProperty("/isRoleAreaSelection") ? oEmployeeModel.setProperty("/TempEmployee/TempRoleAreas", oEmployeeModel.getProperty("/aRoleAreas")): [];
		}
		oForwardDialog.open();

	});

	sap.ui.core.BusyIndicator.hide();
	//that.getView().getModel("selectedProfitCenter").setProperty("/selectedPfc",that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories[0]);
	that.getView().getModel("selectedProfitCenter").refresh(true);
},
_setResValidation: function (oContextObj) {
	//set field config based on role area
	this.getView().getModel("employee").setProperty(`/BAIndustryMandatory`, oContextObj.BAIndustryMandatory);
	this.getView().getModel("employee").setProperty(`/BAIndustrySelectable`, oContextObj.BAIndustrySelectable);
	this.getView().getModel("employee").setProperty(`/SolnAreaMandatory`, oContextObj.SolnAreaMandatory);
	this.getView().getModel("employee").setProperty(`/SolnAreaSelectable`, oContextObj.SolnAreaSelectable);
	this.getView().getModel("employee").setProperty(`/minSelect`,oContextObj.minSelect);
	this.getView().getModel("employee").setProperty(`/maxSelect`,oContextObj.maxSelect);
	if (oContextObj.RoleAreaID === "0006" || oContextObj.RoleAreaID === "0003") {
		this.getView().getModel("employee").setProperty(`/fieldSelectionMidInfoIcon`, true);
	} else {
		this.getView().getModel("employee").setProperty(`/fieldSelectionMidInfoIcon`, false);
	}
	if(oContextObj.RoleAreaID === "0005"){
		//for industry advisory
		this.getView().getModel("employee").setProperty(`/midSectionDesc`,
			this.getOwnerComponent().
				getModel("mrrAppConfigModel").getProperty("/Ind_SelectionText/0/fieldDesc")
		);
	}else{
		this.getView().getModel("employee").setProperty(`/midSectionDesc`,
			this.getOwnerComponent().
				getModel("mrrAppConfigModel").getProperty("/SolnInd_SelectionText/0/fieldDesc")
		);
	}
	if(this.getView().getModel("employee").getProperty(`/minSelect`) === 0){
		this.getView().getModel("employee").setProperty(`/solnIndRequired`, false);
	}else{
		this.getView().getModel("employee").setProperty(`/solnIndRequired`, true);
	}
	this.getView().getModel("employee").refresh();
},
_onDestroyAllResourcePopOvers:function(){
	const that = this;
	if (this.pBAIndustryValueHelpDialog) {
		this.pBAIndustryValueHelpDialog.then(function (oDialog) {
			that.pBAIndustryValueHelpDialog = false;
			oDialog.destroy();

		});
	}
	if (this.pBALoBValueHelpDialog) {
		this.pBALoBValueHelpDialog.then(function (oDialog) {
			that.pBALoBValueHelpDialog = false;
			oDialog.destroy();

		});
	}
	if (this.pCrossCvgValueHelpDialog) {
		this.pCrossCvgValueHelpDialog.then(function (oDialog) {
			that.pCrossCvgValueHelpDialog = false;
			oDialog.destroy();

		});
	}
	if (this.pBASegDialog) {
		this.pBASegDialog.then(function (oDialog) {
			that.pBASegDialog = false;
			oDialog.destroy();

		});
	}
	if (this.pHubValueHelpDialog) {
		this.pHubValueHelpDialog.then(function (oDialog) {
			that.pHubValueHelpDialog = false;
			oDialog.destroy();

		});
	}
},
/*Open profit center view selection fragment*/
onOpenTerritoryValueHelpDialog: function (oEvent) {
	var that = this;
	const oModel = this.getView().getModel("selectedProfitCenter"),
		  oSource = oEvent.getSource();
	this.bSelectPfc = false;
	if (that.getView().byId("territoriesTableId")) {
		that.getView().byId("territoriesTableId").getExtension()[0].getContent()[0].setValue();
	}
	if (!this.pTerritoryValueHelpDialog) {
		this.pTerritoryValueHelpDialog = this.loadFragment({
	name:"com.sap.bpm.PresalesRequestApproval.fragments.TerritoryValueHelpDialog"
		});
	}

	this.pTerritoryValueHelpDialog.then(function (oDialog) {
		//oModel.setProperty("/TempEmployee/TempMuRegionFlg", true);
		that.filterTerritories();
		oModel.refresh(true);
		oDialog.openBy(oSource);
	});
},
/*Filter and set profit center master data*/
filterTerritories: function (initLoad, isRegionMUChange) {
	const oModel = this.getView().getModel("selectedProfitCenter");
	const oTerritoryModel = this.getView().getModel("territoriesMaster");
	const aTerritories = oTerritoryModel.getData();
	const oTempEmployee = oModel.getProperty("/TempProfitCenter");
	let aEmployeeTerritories = oTempEmployee.Territories;
	oTempEmployee.TempTreeTerritories = oTempEmployee.Territories;

	//remove parent node if checkbox selection or isResourceProfile false;

	const aSelectedPfc = oModel.getData().TempProfitCenter.Territories;
	let isResourceProfileFound = aSelectedPfc.some(function (resource) {
		return resource.isResourceProfile;
	});
	if (aSelectedPfc.length > 1) {
		for (let i = 0; i < aSelectedPfc.length; i++) {
			if (!aSelectedPfc[i].isCheckBox || !aSelectedPfc[i].isResourceProfile&& isResourceProfileFound) {
				aSelectedPfc.splice(i, 1)
			}
		}
	}
	if (isRegionMUChange) {
		aEmployeeTerritories = oTempEmployee.TempTreeTerritories;
	}

	let aTempTerritory = [];
	let bSelected = oModel.getProperty("/TempEmployee/TempMuRegionFlg");
	let aFilteredTerritories = aTerritories;

	if (bSelected) {
		aFilteredTerritories = aTerritories.filter(function (item) {
			return item.MuBelow === "";
		});
	}
	this.loadTreeTerritories("treeTerritories", aFilteredTerritories);
	oModel.refresh(true);
	this.setTerritoryHierarchySelection(false, true);
},
/*Select event for profit center view selection*/
onSelectTerritory: function (oEvent) {
	this.bSelectPfc = true;
	this.selectIfTerritoryExists(this.getView().getModel("treeTerritories").getData().territories, [], 0, true);
	const oModel = this.getView().getModel("selectedProfitCenter");
	const oSource = oEvent.getSource();
	let bSelected = oEvent.getParameter("selected");
	let sSelectedDesc = oSource.data("displaydesc");
	const oBindingContext = oSource.getBindingContext("treeTerritories");
	const oTerritoryModel = oBindingContext.getModel();
	const sPath = oBindingContext.getPath();
	const oTerritory = oTerritoryModel.getProperty(sPath);
	oTerritory.IsSelected = true;
	this.oSelectedPFCNode = oTerritory.nodes;
	oTerritory.nodes = this.selectIfTerritoryExists(oTerritory.nodes, [], 0, false);
	const oTempEmployee = oModel.getProperty("/TempProfitCenter");
	let aEmployeeTerritories = oTempEmployee.TempTreeTerritories;
	aEmployeeTerritories = aEmployeeTerritories.filter(function (item) {
		return !item.Desc.includes(sSelectedDesc);
	});
	let iIndex = aEmployeeTerritories.findIndex(function (item) {
		return item.Desc.toUpperCase().trim() === oTerritory.displaydesc.toUpperCase().trim();
	});

	if (iIndex !== -1 && !bSelected) {
		aEmployeeTerritories.splice(iIndex, 1);
		oTerritory.IsPrimary = false;
	} else if (iIndex === -1 && bSelected) {
		if (aEmployeeTerritories.length === 0) {
			oTerritory.IsPrimary = true;
		} else if (aEmployeeTerritories.length === 1 && aEmployeeTerritories[0].IsPrimary) {
			aEmployeeTerritories[0].IsPrimary = false;
		}
		aEmployeeTerritories = [];
		const oProfitCenter = Models._setProfitCenterObj(oTerritory);
		aEmployeeTerritories.push(oProfitCenter);
	} else {
		if (iIndex !== -1) {
			aEmployeeTerritories.splice(iIndex, 1);
		}
	}

	oModel.setProperty("/TempProfitCenter/TempTreeTerritories", aEmployeeTerritories);
	oModel.refresh(true);
	oTerritoryModel.refresh(true);
	this.setTerritoryHierarchySelection(false,false,oBindingContext);
},
/*Close profit center view selection fragment*/
onCloseTerritoryValueHelpDialog: function(evt) {
this.pTerritoryValueHelpDialog.then(function (oDialog) {
oDialog.close();
});
this._setResourceProfileData(this);
},
_setResourceProfileData: function (self) {
const isResourceProfile = self.getView().getModel("selectedProfitCenter").
getProperty("/TempProfitCenter/Territories/0/isResourceProfile");
if (isResourceProfile) {
/*Resource Profile selection screen*/
self.getView().getModel("profileViewParameters").setProperty
	("/footerButtons/searchResourceButtonVisible", true);
self.getView().getModel("profileViewParameters").setProperty
	("/isResProfileConatiner", true);
self.getView().getModel("profileViewParameters").setProperty
	("/footerButtons/forwardReqButtonVisible", false);
self.getView().getModel("profileViewParameters").setProperty
	("/isReqAreaContainerVisible", false);
self.getView().getModel("profileViewParameters").setProperty
	("/footerButtons/forwardReqButtonEnabled", false);
self.getView().getModel("profileViewParameters").setProperty
	("/footerButtons/searchResourceButtonEnabled", true);
} else {
/*Request Area selection screen*/
self.getView().getModel("profileViewParameters").setProperty
	("/footerButtons/searchResourceButtonVisible", false);
self.getView().getModel("profileViewParameters").setProperty
	("/isResProfileConatiner", false);
self.getView().getModel("profileViewParameters").setProperty
	("/footerButtons/forwardReqButtonVisible", true);
self.getView().getModel("profileViewParameters").setProperty
	("/isReqAreaContainerVisible", true);
self.getView().getModel("profileViewParameters").setProperty
	("/footerButtons/forwardReqButtonEnabled", false);
self.getView().getModel("profileViewParameters").setProperty
	("/footerButtons/searchResourceButtonEnabled", false);
	
	let sorgID;
	self.getView().getModel("PCSalesOrgMaster").getData().find(function (item) {
		if (item.ProfitCenterGuid === self.getView().getModel("selectedProfitCenter").
			getProperty("/TempProfitCenter/Territories/0/guid")) {
			sorgID = item.SOrg;
		}
	});
	//filter selected profit center
	self.getView().getModel("territoriesMaster").getData().find(function (item) {
		if (item.ProfitCenterGuid === self.getView().getModel("selectedProfitCenter").
			getProperty("/TempProfitCenter/Territories/0/guid")) {
			self.isResourceProfile = item.isResourceProfile;
		}
	});
	if(sorgID === "NOMP"){
		sorgID = self.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories/0/guid");
	}
	Models.getPublicReqArea(this, sorgID);

}
this.getView().getModel("profileViewParameters").refresh()

},
dialogAfterclose: function(oEvent) {//function called after Dialog is closed
this._oDialog.destroy();//destroy only the content inside the Dialog
},
/*Set Hierachy selection for profit center view*/
 setTerritoryHierarchySelection: function(initLoad,forceReset,oBindingContext,bParanetNodeSelection,initialSelection) {
	const oModel = this.getView().getModel("selectedProfitCenter");
	const oTempEmployee = oModel.getProperty("/TempProfitCenter");
	const aTempTreeTerritories = bParanetNodeSelection ?   oTempEmployee.Territories:oTempEmployee.TempTreeTerritories;
	const oTerritoryHierarchyModel = this.getView().getModel("treeTerritories");
	let that = this;
	let aTerritoryHierarchies = oTerritoryHierarchyModel.getData();
	aTerritoryHierarchies = aTerritoryHierarchies.territories;
	aTerritoryHierarchies = this.selectIfTerritoryExists(aTerritoryHierarchies, [], 0, forceReset,bParanetNodeSelection,initialSelection);
	let aTerritory = [];
	for (let i = 0; i < aTempTreeTerritories.length; i++) {
	  let aDesc = aTempTreeTerritories[i].SelectedDesc.split(">");

	  if (initLoad) {
		let territory = {};
		territory.Desc = aTempTreeTerritories[i].Desc;
		territory.Guid = aTempTreeTerritories[i].Guid;
		territory.IsPrimary = aTempTreeTerritories[i].IsPrimary;
		territory.TrpcId = aTempTreeTerritories[i].TrpcId;

		for (let j = 1; j <= 5; j++) {
		  territory["TrpcL" + j + "Desc"] = aTempTreeTerritories[i]["TrpcL" + j + "Desc"];
		}

		let oTerritory =  Models._setProfitCenterObj(oTerritory);
		aTerritory.push(oTerritory);
	  }

	  aTerritoryHierarchies = this.selectIfTerritoryExists(aTerritoryHierarchies, aDesc, 0,false,bParanetNodeSelection,initialSelection);
	}

	if (initLoad) {
	  oTempEmployee.Territories = aTerritory;
	  oModel.setProperty("/TempEmployee/TRPCPGUIDValueState", "None");
	}

	oModel.refresh(true);
	if(oBindingContext){
	let root = oBindingContext.getObject();
	let nodeUpdate = function nodeUpdate(newValue,that) {
		for (const child of newValue.nodes) {
			if(child.isCheckBox && child.isResourceProfile){
				child.IsSelected = true;
				let oSelectedProfitCenter = Models._setProfitCenterObj(child);
				that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.TempTreeTerritories.push(
					oSelectedProfitCenter);
				that.getView().getModel("selectedProfitCenter").refresh(true);
			}
			nodeUpdate(child,that);
		}
	}
	if(root.isResourceProfile && root.isChildNodeEnable){
		//select child nodes if isResourceProfile true for parent node
		nodeUpdate(root,that);
	}
}
	oTerritoryHierarchyModel.refresh(true);
  },
  /*Check if profit center exist or not*/
  selectIfTerritoryExists: function(Territory, desc, index, forceReset,bParentNodeSelection,initialSelection) {
	if (!Territory || Territory.length === 0) {
	  return [];
	}
	const that = this;
	const oModel = this.getView().getModel("selectedProfitCenter");
	const oTempEmployee = oModel.getProperty("/TempProfitCenter");
	const aTempTreeTerritories = oTempEmployee.TempTreeTerritories;
	let oPrimaryTerritory;
	if(!bParentNodeSelection){
	 oPrimaryTerritory = aTempTreeTerritories.find(function (item) {
	  return item.IsPrimary;
	});

}
	for (let j = 0; j < Territory.length; j++) {
	  let territory = Territory[j];
	  if (!forceReset) {
		if (territory.desc.toUpperCase().trim() === (desc && desc[index] && desc[index].toUpperCase().trim())) {
			if(bParentNodeSelection && !initialSelection){
				if(desc.length-2 === index){
					territory.IsSelected = true;
					let oSelectedProfitCenter = Models._setProfitCenterObj(territory);
					that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories = [oSelectedProfitCenter];
					that.aSelectedParentNode = territory;
			  }
			} else if (desc.length - 1 === index && !bParentNodeSelection) {
				that.aSelectedParentNode = territory;
				territory.IsSelected = true;
			}
	

		  if (territory.desc.toUpperCase().trim() === desc[desc.length - 1].toUpperCase().trim()) {
			if(initialSelection){
				this.aSelectedParentNode = territory;
			}
			territory.IsEnabled = true;
		  } else {
			territory.IsEnabled = false;
		  }
		if(!bParentNodeSelection){
		  if (territory.IsSelected && aTempTreeTerritories.length === 1 && aTempTreeTerritories[0].Desc.toUpperCase().trim() === territory.desc.toUpperCase().trim()) {
			territory.IsPrimary = aTempTreeTerritories[0].IsPrimary;
		  } else if (oPrimaryTerritory && oPrimaryTerritory.Desc.toUpperCase().trim() === territory.desc.toUpperCase().trim()) {
			territory.IsPrimary = true;
		  } else {
			territory.IsPrimary = false;
		  }
		}

		  if (territory.nodes && territory.nodes.length > 0) {
			territory.nodes = this.selectIfTerritoryExists(territory.nodes, desc, index + 1,false,bParentNodeSelection,initialSelection);
		  }
		}
	  } else {
		territory.IsSelected = false;
		territory.IsPrimary = false;
		territory.nodes = this.selectIfTerritoryExists(territory.nodes, desc, index + 1, true,bParentNodeSelection,initialSelection);
	  }

	  Territory[j] = territory;
	}

	return Territory;
  },
/*Confirm and add profit center into the view*/
onChangeTerritories: function onChangeTerritories(oEvent) {
	if(	this.bSelectPfc){
	this.aNonSelectableParentNode = false;
	const oModel = this.getView().getModel("selectedProfitCenter");
	const oTempEmployee = oModel.getProperty("/TempProfitCenter");
	let aTerritory = [];
	const aEmployeeTerritories = oTempEmployee.TempTreeTerritories;
	const iPrimaryIndex = aEmployeeTerritories.findIndex(function (item) {
	  return item.IsPrimary;
	});

	for (let i = 0; i < aEmployeeTerritories.length; i++) {
	  let territory = {};
	  territory.Desc = aEmployeeTerritories[i].Desc;
	  territory.guid = aEmployeeTerritories[i].guid;
	  territory.IsPrimary = aEmployeeTerritories[i].IsPrimary;
	  territory.id = aEmployeeTerritories[i].TrpcId;
	  territory.TrpcDesc = aEmployeeTerritories[i].Desc;
	   territory.isResourceProfile = aEmployeeTerritories[i].isResourceProfile;
	   territory.isCheckBox = aEmployeeTerritories[i].isCheckBox;
	   territory.isChildNodeEnable = aEmployeeTerritories[i].isChildNodeEnable
	   territory.isParentNodeEnable =aEmployeeTerritories[i].isParentNodeEnable

	  for (let j = 1; j <= 5; j++) {
		territory["TrpcL" + j + "Desc"] = aEmployeeTerritories[i]["TrpcL" + j + "Desc"];
	  }

	  const oTerritory =  Models._setProfitCenterObj(territory);
	  aTerritory.push(oTerritory);
	}

	oTempEmployee.Territories = aTerritory;
	const OrgID = oTempEmployee.Territories[0].guid;
	this.onCloseTerritoryValueHelpDialog();
	oModel.refresh(true);
	this._resetResourceProfile();
	this.getView().getModel("selectedProfitCenter").setProperty("/selectedPfc",this.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories[0]);
}else{
	this.onCloseTerritoryValueHelpDialog();
}
this.getView().getModel("employee").setProperty(`/TempEmployee/TempRoles`, "");
this.getView().getModel("employee").setProperty(`/fieldSelectionMidInfoIcon`,false);
this.getView().getModel("employee").setProperty(`/TempEmployee/TempRoles`, "");
this.getView().getModel("employee").setProperty(`/fieldSelectionMidInfoIcon`,false);
this.getView().getModel("employee").setProperty(`/BAIndustrySelectable`,true);
this.getView().getModel("employee").setProperty(`/SolnAreaMandatory`,false);
this.getView().getModel("employee").setProperty(`/BAIndustryMandatory`,false);
this.getView().getModel("employee").setProperty(`/SolnAreaSelectable`,true);
this.getView().getModel("employee").setProperty(`/minSelect`,0);
this.getView().getModel("employee").setProperty(`/maxSelect`,2);
this.getView().getModel("employee").setProperty(`/solnAreaEnable`,true);
this.getView().getModel("employee").setProperty(`/industryEnable`,true);
this.getView().getModel("employee").setProperty(`/solnIndRequired`,false);
this.getView().getModel("employee").setProperty(`/midSectionDesc`,this.getOwnerComponent().
getModel("mrrAppConfigModel").getProperty("/SolnInd_SelectionText/0/fieldDesc"));
this.getView().getModel("employee").setProperty(`/fieldSelectionMidInfoIcon`,false);
this._onEnableSearchResources();
  },
  
getInstance: function getInstance() {
if (!instance) {
// create new instance of Application Object
instance = new Application();
}

return instance;
},
/*Load and set the profit center master data*/
 loadTreeTerritories: function(type, results,bParentNodeSelection) {
	let aTerritories = []; 
	let aSlectedProfitCenter = this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories");

	let _loop = function _loop(i) {
		if(results[i].isFiltered){
		let oCluster = aTerritories.find(function (item) {
			return item.TrpcL1Desc === results[i].TGlobal;
		});

		if (!oCluster && results[i].TGlobal && results[i].TGlobal !== "") {
			let oPCCluster = results.find(function (item) {
				return item.TrpcDesc.toUpperCase().trim() === results[i].TGlobal.toUpperCase().trim();
			});
			oCluster = {
				guid: oPCCluster.TrpcGuid,
				id: oPCCluster.TrpcId,
				isResourceProfile:oPCCluster.isResourceProfile,
				desc: results[i].TGlobal,
				TrpcDesc: oPCCluster.TrpcDesc,
				Name: oPCCluster.Name,
				displaydesc: results[i].TGlobal,
				IsPrimary: false,
				IsEnabled: false,
				IsSelected: false,
				bPrimaryRole: results[i].bPrimaryRole,
				bSelectedRole: results[i].bSelectedRole,
				isRadioBtVisible: results[i].isRadioBtVisible,
				isPrimary: results[i].isPrimary,
				nodes: [],
				LevelId: "0001",
				TrpcL1Desc: results[i].TGlobal,
				isCheckBox: oPCCluster.isCheckBox,
				isParentNodeEnable: oPCCluster.isParentNodeEnable,
				isChildNodeEnable: oPCCluster.isChildNodeEnable
			};
			if(aSlectedProfitCenter.length && aSlectedProfitCenter.SelectedGuid === results[i].TrpcGuid){
				oCluster.IsSelected = true;
			}
			aTerritories.push(oCluster);
			aTerritories.sort(function (a, b) {
				return a.desc.localeCompare(b.desc);
			});
		}

		if (oCluster) {
			let aL1 = oCluster.nodes;
			let oL1 = aL1.find(function (item) {
				return item.TrpcL2Desc === results[i].Region;
			});

			if (!oL1 && results[i].Region && results[i].Region !== "") {
				// const oPCL1 = results.find(item => item.Name.includes(results[i].Region));
				let oPCL1 = results.find(function (item) {
					return item.TrpcDesc.toUpperCase().trim() === results[i].Region.toUpperCase().trim();
				});
				oL1 = {
					guid: oPCL1.TrpcGuid,
					id: oPCL1.TrpcId,
					desc: results[i].Region,
					TrpcDesc: oPCL1.TrpcDesc,
					isResourceProfile:oPCL1.isResourceProfile,
					isCheckBox: oPCL1.isCheckBox,
					isParentNodeEnable: oPCL1.isParentNodeEnable,
					isChildNodeEnable: oPCL1.isChildNodeEnable,
					Name: oPCL1.Name,
					displaydesc: results[i].TGlobal + " > " + results[i].Region,
					IsPrimary: false,
					IsEnabled: false,
					IsSelected: false,
					bPrimaryRole: results[i].bPrimaryRole,
					bSelectedRole: results[i].bSelectedRole,
					isRadioBtVisible: results[i].isRadioBtVisible,
					isPrimary: results[i].isPrimary,
					nodes: [],
					LevelId: "0002",
					TrpcL1Desc: results[i].TGlobal,
					TrpcL2Desc: results[i].Region
				};
				if(aSlectedProfitCenter.length && aSlectedProfitCenter.SelectedGuid === results[i].TrpcGuid){
					oL1.IsSelected = true;
				}
				aL1.push(oL1);
				aL1.sort(function (a, b) {
					return a.desc.localeCompare(b.desc);
				});
			}

			if (oL1) {
				let aL2 = oL1.nodes;
				let oL2 = aL2.find(function (item) {
					return item.TrpcL3Desc === results[i].Mu;
				});

				if (!oL2 && results[i].Mu && results[i].Mu !== "") {
					let oPCL2 = results.find(function (item) {
						return item.TrpcDesc.toUpperCase().trim() === results[i].Mu.toUpperCase().trim();
					});

					if (!oPCL2) {
						oPCL2 = (function () {
							throw new Error("\"oPCL2\" is read-only");
						}(), results[i]);
					}

					oL2 = {
						guid: oPCL2.TrpcGuid,
						id: oPCL2.TrpcId,
						isResourceProfile:oPCL2.isResourceProfile,
						isCheckBox: oPCL2.isCheckBox,
						isChildNodeEnable: oPCL2.isChildNodeEnable,
						isParentNodeEnable: oPCL2.isParentNodeEnable,
						desc: results[i].Mu,
						TrpcDesc: oPCL2.TrpcDesc,
						Name: oPCL2.Name,
						displaydesc: results[i].TGlobal + " > " + results[i].Region + " > " + results[i].Mu,
						IsPrimary: false,
						IsEnabled: false,
						IsSelected: false,
						bPrimaryRole: results[i].bPrimaryRole,
						bSelectedRole: results[i].bSelectedRole,
						isRadioBtVisible: results[i].isRadioBtVisible,
						isPrimary: results[i].isPrimary,
						nodes: [],
						LevelId: "0003",
						TrpcL1Desc: results[i].TGlobal,
						TrpcL2Desc: results[i].Region,
						TrpcL3Desc: results[i].Mu
					};
					if(aSlectedProfitCenter.length && aSlectedProfitCenter.SelectedGuid === results[i].TrpcGuid){
						oL2.IsSelected = true
					};
					aL2.push(oL2);
					aL2.sort(function (a, b) {
						return a.desc.localeCompare(b.desc);
					});
				}

				if (oL2) {
					let aL3 = oL2.nodes;
					let oL3 = aL3.find(function (item) {
						return item.TrpcL4Desc === results[i].MuBelow;
					});

					if (!oL3 && results[i].MuBelow && results[i].MuBelow !== "") {
						// const oPCL3 = results.find(item => item.Name.includes(results[i].MuBelow));
						let oPCL3 = results.find(function (item) {
							return item.TrpcDesc.toUpperCase().trim() === results[i].MuBelow.toUpperCase().trim();
						});

						if (!oPCL3) {
							oPCL3 = (function () {
								throw new Error("\"oPCL3\" is read-only");
							}(), results[i]);
						}

						oL3 = {
							guid: oPCL3.TrpcGuid,
							id: oPCL3.TrpcId,
							isResourceProfile:oPCL3.isResourceProfile,
							isCheckBox: oPCL3.isCheckBox,
							isChildNodeEnable: oPCL3.isChildNodeEnable,
							isParentNodeEnable: oPCL3.isParentNodeEnable,
							desc: results[i].MuBelow,
							TrpcDesc: oPCL3.TrpcDesc,
							Name: oPCL3.Name,
							displaydesc: results[i].TGlobal + " > " + results[i].Region + " > " + results[i].Mu + " > " + results[i].MuBelow,
							IsPrimary: false,
							IsEnabled: false,
							IsSelected: false,
							bPrimaryRole: results[i].bPrimaryRole,
							bSelectedRole: results[i].bSelectedRole,
							isRadioBtVisible: results[i].isRadioBtVisible,
							isPrimary: results[i].isPrimary,
							TrpcL1Desc: results[i].TGlobal,
							TrpcL2Desc: results[i].Region,
							TrpcL3Desc: results[i].Mu,
							TrpcL4Desc: results[i].MuBelow,
							nodes: [],
							LevelId: "0004"
						};
						if(aSlectedProfitCenter.length && aSlectedProfitCenter.SelectedGuid === results[i].TrpcGuid){
							oL3.IsSelected = true;
						}
						aL3.push(oL3);
						aL3.sort(function (a, b) {
							return a.desc.localeCompare(b.desc);
						});
					}
				}
			}
		}
		}
	};
	
	for (let i = 0; i < results.length; i++) {
		_loop(i);
	}
	const oTreeTerritoriesModel = new sap.ui.model.json.JSONModel({
		type: type,
		territories: aTerritories,
		leadTerritories: aTerritories
	});
	var oModel = oTreeTerritoriesModel;
    var oData = oModel.getData();

    function updateNodes(nodes) {
        nodes.forEach(function (node) {
            node.isMargin = (!node.nodes || node.nodes.length === 0);

            if (node.nodes && node.nodes.length > 0) {
                updateNodes(node.nodes); 
            }
        });
    }
    if (oData.territories && oData.territories.length > 0) {
        updateNodes(oData.territories); 
    }

    oModel.setData(oData);
	this.getView().setModel(oTreeTerritoriesModel, "treeTerritories");
},
/*Search event for profit center view selection*/
onSearchTerritory: function onSearchTerritory(oEvent) {
const query = oEvent.getSource().getValue().trim();
const TableId = oEvent.getSource().getParent().getParent();
TableId.getBinding("rows").filter(query ? new Filter({
path: "desc",
operator: "Contains",
value1: query
}) : null);
TableId.expandToLevel(query ? 99 : 0);
},
/*Open Business Area Industry Fragment*/
onOpenBAIndustryValueHelpDialog: function (oEvent) {
	const that = this;
	const oSource = oEvent.getSource();
			if (!this.pBAIndustryValueHelpDialog) {
				this.pBAIndustryValueHelpDialog = this.loadFragment({
					name: "com.sap.bpm.PresalesRequestApproval.fragments.resourceProfile.BAIndustryValueHelpDialog"
				});
				this.getView().getModel("employee").refresh();
				this._callBusinessAreaIndustryMasterData();
			}else{
				const oModel = this.getView().getModel("employee");
                if (oModel.getData().TempEmployee.BAIndustriesList) {
                    if (oModel.getData().TempEmployee.BAIndustriesList.length) {
                        oModel.setProperty(`/TempEmployee/BAIndustriesList`, oModel.getData().TempEmployee.BAIndustriesList);
                    }
                }
			}
			this.pBAIndustryValueHelpDialog.then(function (oDialog) {
				that.getView().setModel(new sap.ui.model.json.JSONModel(), "masterDataModel");
				const oMasterDataModel = that.getView().getModel("masterDataModel");
				oMasterDataModel.setData(that.getView().getModel("employee").getData());
				that.getView().getModel("masterDataModel").refresh();
				that.filterBAIndustries();
                oDialog.setPlacement("Right")
				oDialog.openBy(oSource);
				
			});
},
/*Open Business Area LoB Fragment*/
onOpenBALoBValueHelpDialog: function (oEvent) {
const that = this;
if (!this.pBALoBValueHelpDialog) {
this.pBALoBValueHelpDialog = this.loadFragment({
	name: "com.sap.bpm.PresalesRequestApproval.fragments.resourceProfile.BALoBValueHelpDialog"
});
this.getView().getModel("employee").setProperty("/TempEmployee/BALoBBusy",true);
this.getView().getModel("employee").refresh();
this._callBusinessLoBMasterData()
}
this.pBALoBValueHelpDialog.then(function (oDialog) {
that.filterBALoBs();
oDialog.openBy(that.getView().byId("RoleAreaBALobId"));
});
},
//Call Hub API and set the Hub model
_setHubMetadata: function () {
const oModel = this.getView().getModel("employee");
const that = this;
const promises = [
Models.getResourceProfileMasterData("YC_DS_M_HUB_IND_HIER", this,"Hub",true).then(data => {
	if (data && data.d && data.d.results) {
		oModel.setProperty("/Rules/HubIndustry", data.d.results);
	}
}),
Models.getResourceProfileMasterData("YC_DS_M_HUB_LOB_HIER",  this,"Hub",true).then(data => {
	if (data && data.d && data.d.results) {
		oModel.setProperty("/Rules/HubLoB", data.d.results);
	}
}),
Models.getResourceProfileMasterData("YC_DS_M_HUB_ROLE_HIER",  this,"Hub",true).then(data => {
	if (data && data.d && data.d.results) {
		oModel.setProperty("/Rules/HubRole", data.d.results);
	}
})
];
Promise.all(promises)
.then((data) => {
	// setTimeout(() => {
	// 	//that.setBusy(false);
	// }, 4000);
	that.getView().getModel("employee").setProperty("/TempEmployee/hubLoBBusy",false);
	that.getView().getModel("employee").refresh();
	that.filterBAHubs();
})
.catch(function (error) {
	//that.setBusy(false);
	that.getView().getModel("employee").setProperty("/TempEmployee/hubLoBBusy",false);
	that.getView().getModel("employee").refresh();
	Models._setErrorMsgPopOver(that,"hub",false,"complete");
});
},

/*Call BusinessAreaSegment MasterData*/
_callBASegmentMasterData:function(){
	const oModel = this.getView().getModel("employee");
	const oTempEmployee = oModel.getProperty("/TempEmployee");
	const that = this;
	const promises = [
		//Business Area Segment
		Models.getResourceProfileMasterData("YC_OR_M_BA_SEGMENT", this,"businessAreaSegment",true).then(data => {
			if (data && data.d && data.d.results) {
				const aBASegments = data.d.results;
				oTempEmployee.BASegmentsList = [];
				aBASegments.map((element, index, array) => {
					oTempEmployee.BASegmentsList.push({
						Guid: element.BaSegGuid,
						ID: element.BaSegId,
						Desc: element.BaSegDesc,
						IsDefault: (element.DefaultSel && element.DefaultSel === "X") ? true : false,
						IsNonFocused: (element.DisplayGroup && element.DisplayGroup === "2") ? true : false,
						IsPrimary: false,
						IsEnabled: (element.DisplayGroup !== "4"),
						IsSelected: false
					});
				});

			}
			let aBASegment = [];
			if(!oModel.getProperty("/TempEmployee/BASegments").length){
				
				oTempEmployee.BASegmentsList.map((element) => {
							if (!element.IsNonFocused) { 
								aBASegment.push(element);
							}
						});
				oModel.setProperty("/TempEmployee/BASegments" , aBASegment);
			}
			oModel.refresh(true);
			that.filterBASegments();

		})
	];
	Promise.allSettled(promises)
		.then((data) => {
			setTimeout(() => {
				//that.setBusy(false);
			}, 3000);
			that.getView().getModel("employee").setProperty("/TempEmployee/BASegmentsBusy",false);
			that.getView().getModel("employee").refresh();
		})
		.catch(function (error) {
			that.getView().getModel("employee").setProperty("/TempEmployee/BASegmentsBusy",false);
			that.getView().getModel("employee").refresh();
			Models._setErrorMsgPopOver(that,"BusinessAREA","complete");
		})
},
/*Call BusinessLoB MasterData*/
_callBusinessLoBMasterData: function () {
	const oModel = this.getView().getModel("employee");
	const oTempEmployee = oModel.getProperty("/TempEmployee");
	var that = this;
	const data = this.getView().getModel("baLoBMasterData").getData();

	const aBALobs = data.d.results;
	oTempEmployee.BALoBsList = [];
	aBALobs.map((element, index, array) => {
		oTempEmployee.BALoBsList.push({
			Guid: element.BaLobGuid,
			ID: element.BaLobId,
			Desc: element.BaLobDesc,
			IsDefault: (element.DefaultSel && element.DefaultSel === "X") ? true : false,
			IsNonFocused: (element.DisplayGroup && element.DisplayGroup === "2") ? true : false,
			IsPrimary: false,
			IsEnabled: (element.DisplayGroup !== "4"),
			IsSelected: false,
			ClusterGuid: element.BaLobClstrGuid,
			ClusterDesc: element.BaLobClstrDesc
		});
	});
	oTempEmployee.BALoBsList.sort((i, j) => i.ClusterDesc.localeCompare(j.ClusterDesc));
	oTempEmployee.BALoBsList.unshift(oTempEmployee.BALoBsList.splice(oTempEmployee.BALoBsList.findIndex(item => item.ID === "0009"), 1)[0]);
	oModel.refresh(true);
	that.filterBALoBs();
},
/*Call CrossCoverage MasterData*/
_callCrossCoverageMasterData: function () {
	const oModel = this.getView().getModel("employee");
	const oTempEmployee = oModel.getProperty("/TempEmployee");
	var that = this;
	const data = this.getView().getModel("crossCvgMasterData").getData();
	if (data && data.d && data.d.results) {
		const aCrossCvg = data.d.results;
		oTempEmployee.CrossCvgList = [];
		aCrossCvg.map((element, index, array) => {
			oTempEmployee.CrossCvgList.push({
				Guid: element.CrossCvrgGuid,
				ID: element.CrossCvrgId,
				Desc: element.CrossCvrgDesc,
				IsDefault: (element.DefaultSel && element.DefaultSel === "X") ? true : false,
				IsNonFocused: (element.DisplayGroup && element.DisplayGroup === "2") ? true : false,
				IsPrimary: false,
				IsEnabled: true,
				IsSelected: false,
				BaLobGuid: element.BaLobGuid
			});
		});
	}
	oTempEmployee.CrossCvgList.sort((i, j) => i.Desc.localeCompare(j.Desc));
	oTempEmployee.CrossCvgList.unshift(oTempEmployee.CrossCvgList.splice(oTempEmployee.CrossCvgList.findIndex(item => item.ID === "0005"), 1)[0]);
	oModel.refresh(true);
	that.filterCrossCoverage();
},
/*Call BusinessAreaIndustry MasterData*/
_callBusinessAreaIndustryMasterData: function () {
	const oModel = this.getView().getModel("employee");
	const oTempEmployee = oModel.getProperty("/TempEmployee");
	var that = this;
	const data = this.getView().getModel("baIndMasterData").getData();

	if (data && data.d && data.d.results) {
		const aBAIndustry = data.d.results;
		oTempEmployee.BAIndustriesList = [];
		aBAIndustry.map((element, index, array) => {
			oTempEmployee.BAIndustriesList.push({
				Guid: element.BaIndGuid,
				ID: element.BaIndId,
				Desc: element.BaIndDesc,
				ClusterGuid: element.IndClstrGuid,
				ClusterDesc: element.IndClstrDesc,
				IsDefault: (element.DefaultSel && element.DefaultSel === "X") ? true : false,
				IsNonFocused: (element.DisplayGroup && element.DisplayGroup === "2") ? true : false,
				IsPrimary: false,
				IsEnabled: (element.DisplayGroup !== "4"),
				IsSelected: false,
				BaIndTechID: element.BaIndTechId,
				BaIndId: element.BaIndId
			});
		});
	}
	oTempEmployee.BAIndustriesList.sort((i, j) => i.ClusterDesc.localeCompare(j.ClusterDesc));
	oTempEmployee.BAIndustriesList.unshift(oTempEmployee.BAIndustriesList.splice(oTempEmployee.BAIndustriesList.findIndex(item => item.ID === "0025"), 1)[0]);
	oModel.refresh(true);
	that.filterBAIndustries();
},

/*Filter business area industries*/
filterBAIndustries: function () {
const oModel = this.getView().getModel("employee");
const oTempEmployee = oModel.getProperty("/TempEmployee");

let aBAIndustries = [];
aBAIndustries = JSON.parse(JSON.stringify(oTempEmployee.BAIndustriesList));

let aEmployeeBAIndustries = JSON.parse(JSON.stringify(oModel.getProperty("/TempEmployee/BAIndustries")));
oModel.setProperty("/NonIndustryFocused", {
Guid: "",
IsSelected: false,
IsVisible: false
});
aBAIndustries.map(function (element, index, array) {
const oEmployeeBAIndustry = aEmployeeBAIndustries.find(item => item.Guid === element.Guid);
if (oEmployeeBAIndustry) {
	element.IsSelected = true;
	element.IsPrimary = false;
	oEmployeeBAIndustry.ClusterGuid = element.ClusterGuid;
	oEmployeeBAIndustry.ClusterDesc = element.ClusterDesc;
	oEmployeeBAIndustry.BaIndTechID = element.BaIndTechID;
	oEmployeeBAIndustry.BaIndId = element.BaIndId;
} else {
	element.IsSelected = false;
	element.IsPrimary = false;
}
if (element.IsNonFocused) {
	oModel.setProperty("/NonIndustryFocused", {
		Guid: element.Guid,
		IsSelected: false,
		IsVisible: true
	});
	if (oEmployeeBAIndustry && oEmployeeBAIndustry.Guid === element.Guid) {
		aEmployeeBAIndustries = [{
			Guid: element.Guid,
			Desc: element.Desc,
			IsPrimary: false,
			IsNonFocused: true,
			ID: element.ID
		}];
		oModel.setProperty("/NonIndustryFocused", {
			Guid: element.Guid,
			IsSelected: true,
			IsVisible: true,
			ID: element.ID
		});
	}
}
});
let aFilteredEmployeeBAIndustries = JSON.parse(JSON.stringify(aEmployeeBAIndustries));
for (let i = 0; i < aEmployeeBAIndustries.length; i++) {
const iIndex = aBAIndustries.findIndex(item => item.Guid === aEmployeeBAIndustries[i].Guid);
if (iIndex === -1) {
	aFilteredEmployeeBAIndustries = aFilteredEmployeeBAIndustries.filter(item => item.Guid !== aEmployeeBAIndustries[i].Guid);
}
}
oModel.setProperty("/TempEmployee/BAIndustries", aFilteredEmployeeBAIndustries);
oModel.setProperty("/TempEmployee/TempBAIndustries", JSON.parse(JSON.stringify(oTempEmployee.BAIndustries)));
oModel.setProperty("/BAIndustries", aBAIndustries);
oModel.refresh(true);
},
/*Filter business area LoBs*/
filterBALoBs: function () {
const oModel = this.getView().getModel("employee");
const oTempEmployee = oModel.getProperty("/TempEmployee");
let aBALoBs = [];
aBALoBs = JSON.parse(JSON.stringify(oTempEmployee.BALoBsList));

let aEmployeeBALoBs = JSON.parse(JSON.stringify(oModel.getProperty("/TempEmployee/BALoBs")));
oModel.setProperty("/NonLoBFocused", {
Guid: "",
IsSelected: false,
IsVisible: false
});

aBALoBs.map(function (element, index, array) {
const oEmployeeBALoB = aEmployeeBALoBs.find(item => item.Guid === element.Guid);
if (oEmployeeBALoB) {
	element.IsSelected = true;
	element.IsPrimary = (oEmployeeBALoB.IsPrimary);
	oEmployeeBALoB.ClusterGuid = element.ClusterGuid;
	oEmployeeBALoB.ClusterDesc = element.ClusterDesc;
	oEmployeeBALoB.IsNonFocused = element.IsNonFocused;
} else {
	element.IsSelected = false;
	element.IsPrimary = false;
}
if (element.IsNonFocused) {
	oModel.setProperty("/NonLoBFocused", {
		Guid: element.Guid,
		IsSelected: false,
		IsVisible: true
	});

	if (oEmployeeBALoB && oEmployeeBALoB.Guid === element.Guid) {
		aEmployeeBALoBs = [{
			Guid: element.Guid,
			Desc: element.Desc,
			IsPrimary: false,
			IsNonFocused: true,
			ID: element.ID
		}];
		oModel.setProperty("/NonLoBFocused", {
			Guid: element.Guid,
			IsSelected: true,
			IsVisible: true
		});
	}
}
});
let aFilteredEmployeeBALoBs = JSON.parse(JSON.stringify(aEmployeeBALoBs));
for (let i = 0; i < aEmployeeBALoBs.length; i++) {
const iIndex = aBALoBs.findIndex(item => item.Guid === aEmployeeBALoBs[i].Guid);
if (iIndex === -1) {
	aFilteredEmployeeBALoBs = aFilteredEmployeeBALoBs.filter(item => item.Guid !== aEmployeeBALoBs[i].Guid);
}
}
oModel.setProperty("/TempEmployee/BALoBs", aFilteredEmployeeBALoBs);
oModel.setProperty("/TempEmployee/TempBALoBs", JSON.parse(JSON.stringify(oTempEmployee.BALoBs)));
oModel.setProperty("/BALoBs", aBALoBs);
oModel.refresh(true);
},
/*Load Role type master data*/
/*Load Role type master data*/
loadRoleTypeData: function (type, results) {
            // MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
            // get IAC (Internal Account Classification) and Role, Role Area mapping #git84
            this.oSLASearchContext = false;
            this.getView().setModel(new sap.ui.model.json.JSONModel([]), "IACRoleAreaModel");
            sap.ui.core.BusyIndicator.show();
			this.getOwnerComponent().getModel("appConstants").setProperty("/IAC_ENABLE/0/isIACQueryRemove", false);
			const isIACEnabled = this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/Operational_Status");
			const sSelectedRoleAreaId = this.getView().getModel().getProperty("/aResourceProfileApprovers/ResourceProfileDetails/RoleArea_P_GUID/ID");
            const ointicSystemModel = Models.systeminticDataModel(this);
            const oResourcesSystemModel = Models.systemResourcesDataModel(this);
			const oEmployeeModel  = this.getView().getModel("employee");
            const that = this;
        
            const handleError = function (oError) {
                sap.ui.core.BusyIndicator.hide();
                ErrorHandle.setErrorMessage(oError, that);
            };
        
            const processRoleAreaData = function (data) {
                sap.ui.core.BusyIndicator.hide();
                that.getView().getModel("IACRoleAreaModel").setData(data.results);
        
                const i18nModel = that.getOwnerComponent().getModel("i18n").getResourceBundle();
                const aIACRoleArea = that.getView().getModel("IACRoleAreaModel").getData();
				if (!aIACRoleArea.length && isIACEnabled) {
					let sUrlParams = {
						$filter: `IacDesc eq 'Non-IAC Focused' and RequestType eq '${that.getView().getModel().getProperty("/RequestType")}'`,
						$expand:'to_rolemap,to_subrolemap'
					};
					that.getOwnerComponent().getModel("appConstants").setProperty("/IAC_ENABLE/0/isIACQueryRemove", true);
                Models._callGETOdata(oResourcesSystemModel, "/YC_MR_M_IAC_ACV_RAMAP", sUrlParams)
                    .then(processRoleAreaData)
                    .catch(handleError);
                    return;
                }
                const aFilteredRoleRoleArea = [];
				aIACRoleArea.forEach(function(item){
                    let sIACRoleAreaList = aIACRoleArea.filter(roleArea => item.RoleAreaId === roleArea.RoleAreaId );
                    let aRolesData = [];
					let aIACRoleAreaList = item.to_rolemap.results;
					let aIACRoleAreaSubList =  item.to_subrolemap.results;
					let aSubst = [];
					aIACRoleAreaSubList.forEach(function(sub){
						let oSubst = {
							"RoleID" : sub.RoleSubstitute_ID,
							"RoleAreaID" :  sub.RoleAreaSubstitute_ID,
							"RoleDesc":sub.RoleSubstitute_Desc
						}
						aSubst.push(oSubst);
					});
					item.aSubstituteRoleRoleArea = aSubst;
					aIACRoleAreaList.forEach(function(rolesData){
						let oRolesList ={
							"RoleID": rolesData.Role_ID,
							"RoleDesc": rolesData.Role_Desc,
							"RoleAreaID": item.RoleAreaId,
						}
						aRolesData.push(oRolesList);
					});
					item.RolesData = aRolesData;
                });
				aIACRoleArea.forEach(function (data) {
					const aRoleMasterWithoutDuplicates = {
						"RoleID": data.to_rolemap.results[0].Role_ID,
						"RoleDesc": data.to_rolemap.results[0].Role_Desc,
						"RolesData":data.RolesData,
						"RoleAreaID": data.RoleAreaId,
						"RoleAreaDesc": data.RoleAreaDesc,
						"minSelect":Number(data.MinSelect),
						"maxSelect":Number(data.MaxSelect),
						"SolnAreaMandatory": data.SolnAreaMandatory,
						"SolnAreaSelectable": data.SolnAreaSelectable,
						"BAIndustryMandatory": data.BAIndustryMandatory,
						"BAIndustrySelectable": data.BAIndustrySelectable,
						"aSubstituteRoleRoleArea":data.aSubstituteRoleRoleArea,
						"RoleAreas": [
							{
								"ID": data.RoleAreaId,
								"Desc": data.RoleAreaDesc,
								"RoleDesc": data.to_rolemap.results[0].Role_Desc
							}
						],
						"ID": data.to_rolemap.results[0].Role_ID,
						"Desc": data.to_rolemap.results[0].Role_Desc
					}
					//preselected RoleArea details
					if(data.RoleAreaId === sSelectedRoleAreaId){
						oEmployeeModel.setProperty("/TempEmployee/TempRoleAreas", aRoleMasterWithoutDuplicates.RoleAreas);
						oEmployeeModel.setProperty("/TempEmployee/TempRoles",aRoleMasterWithoutDuplicates);
						oEmployeeModel.setProperty("/TempEmployee/RoleAreas", aRoleMasterWithoutDuplicates.RoleAreas);
                        oEmployeeModel.setProperty("/TempEmployee/Roles", [aRoleMasterWithoutDuplicates]);
						that._setResValidation(aRoleMasterWithoutDuplicates);
						let oSelectParams = {
                            "minSelect":that.getView().getModel("employee").getProperty(`/minSelect`),
                            "maxSelect":that.getView().getModel("employee").getProperty(`/maxSelect`),
                        }
                        
                        if(that.getView().getModel("employee").getProperty(`/maxSelect`) === 1 && that.getView().getModel("employee").getProperty("/TempEmployee/BAIndustries").length &&  that.getView().getModel("employee").getProperty("/TempEmployee/SolutionAreas").length){
                            that.getView().getModel("employee").setProperty("/TempEmployee/SolutionAreas",[]);
                            that.getView().getModel("employee").setProperty("/TempEmployee/TempBAIndustries", []);
                            that.getView().getModel("employee").setProperty("/TempEmployee/BAIndustries", []);
                        }else if( that.getView().getModel("employee").getProperty(`/maxSelect`) === 1 &&  that.getView().getModel("employee").getProperty("/TempEmployee/BAIndustries").length && !that.getView().getModel("employee").getProperty("/TempEmployee/SolutionAreas").length){
                            oSelectParams.bIndustry = true;
                            that._onManageIndSolSelection(oSelectParams); 
                        } else if( that.getView().getModel("employee").getProperty(`/maxSelect`) === 1 && !that.getView().getModel("employee").getProperty("/TempEmployee/BAIndustries").length &&  that.getView().getModel("employee").getProperty("/TempEmployee/SolutionAreas").length){
                            oSelectParams.bIndustry = false;
                            that._onManageIndSolSelection(oSelectParams);
                        }else{
                            that.getView().getModel("employee").setProperty(`/solnAreaEnable`,true);
                            that.getView().getModel("employee").setProperty(`/industryEnable`,true);
                        }
                        that._setSearchFieldText();  
                        that._onEnableSearchResources(oSelectParams);
					}else{
						oEmployeeModel.setProperty("/SelectedRoleKey", "");
                        that.getView().getModel().setProperty("/isRoleAreaSelection",true) 
					}
                    aFilteredRoleRoleArea.push(aRoleMasterWithoutDuplicates);
                });
        
                ["roleMasterWithoutDuplicate", "roleMaster", "roleAreas"].forEach(function (key) {
                    that.fnMasterDataSuccess(key, aFilteredRoleRoleArea);
                });
        
                if (!that.getOwnerComponent().getModel("SLAMasterDataLevels").getData().results.length) {
                    Models._getSLAMasterData(that);
                }
            };
        
            const fetchRoleAreaMapping = function (IAC) {
				let sUrlParams;
				if (isIACEnabled && IAC) {
					sUrlParams = {
						$filter: `IacDesc eq '${IAC}' and RequestType eq '${that.getView().getModel().getProperty("/RequestType")}'`,
						$expand:'to_rolemap,to_subrolemap'
					};
				} else {
					sUrlParams = {
						$filter: `IacDesc eq 'Non-IAC Focused' and RequestType eq '${that.getView().getModel().getProperty("/RequestType")}'`,
						$expand:'to_rolemap,to_subrolemap'
					};
					that.getOwnerComponent().getModel("appConstants").setProperty("/IAC_ENABLE/0/isIACQueryRemove", true);
				}
                Models._callGETOdata(oResourcesSystemModel, "/YC_MR_M_IAC_ACV_RAMAP", sUrlParams)
                    .then(processRoleAreaData)
                    .catch(handleError);
            };
        
            const accountDesc = this.getView().getModel().getProperty("/aResourceProfileApprovers/IAC/0/IAC_Desc");
        
			if (isIACEnabled && (!accountDesc || accountDesc === "Non-IAC Focused")) {
                Models._callGETOdata(ointicSystemModel, `/BusinessPartnerAttribSet('${this.getView().getModel().getProperty("/accountId")}')`)
                    .then(function (data) {
                        const IAC = data.TG_ACCOUNT_DESC ? data.TG_ACCOUNT_DESC.trim():"";
                        fetchRoleAreaMapping(IAC);
                    })
                    .catch(handleError);
            } else {
				that.getOwnerComponent().getModel("appConstants").setProperty("/IAC_ENABLE/0/isIACQueryRemove", true);
                const defaultIAC = accountDesc; 
                fetchRoleAreaMapping(defaultIAC);
            }
            // MR: [GRP02-03] GTM25 Resource Profile alignment #84 end
        },
//MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
		/*Open Solution Area  Fragment*/
		onOpenSLAPopOver: function (oEvent) {
            this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/results",[]);
			const oSource = oEvent.getSource();
			const that = this,
				 aSLAMasterData =   this.getOwnerComponent().getModel("SLAMasterDataL1").getData().results;
				 that.getView().setModel(new sap.ui.model.json.JSONModel(), "masterDataModel");
				const oMasterDataModel = that.getView().getModel("masterDataModel");
				if(this.oSLASearchContext){
					this.getView().getModel("employee").setProperty(`/TempEmployee/SolutionAreas`,this.oSLASearchContext)
				}
			if (this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`)) {
				this.oSLASearchContext = JSON.parse(JSON.stringify(this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`)));
			}
				oMasterDataModel.setData(that.getView().getModel("employee"));
				oMasterDataModel.refresh();
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",[]);
			if (!this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas/0`)) {
				//set defualy solution area L1
				//this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/selectedSolAreaL1",aSLAMasterData[0].SolGuid);
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",aSLAMasterData);
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA",false)
			}else if(this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas/0`)){
				//set selected solution area L1
				this.oContextSolutionArea = this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas/0`);
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/selectedSolAreaL1",
				this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas/0/soln_prnt_guid`));
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`));
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA",true)
			}
			this.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
			this.getView().getModel("employee").setProperty(`/TempEmployee/slaBusy`,true);
			if (!this.pSLAValueHelpDialog) {
				this.pSLAValueHelpDialog = this.loadFragment({
					name: "com.sap.bpm.PresalesRequestApproval.fragments.resourceProfile.SolutionArea"
				});
			}
			this.pSLAValueHelpDialog.then(function (oDialog) {

				that.onAfterOpenSLAPopover();
				oDialog.setPlacement("Right");
				oDialog.openBy(oSource);
				that.getView().getModel("employee").setProperty(`/TempEmployee/slaBusy`, false);
				if(that.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`)){
					that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",that.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`));
				}
				
				that.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
				that._OnUpdateSlaSelection();
				that.byId("idSolutionTreeOnCreate").getHeaderToolbar().getContent()[0].setValue("")
				that.onSearchSolutionArea(false)
			});
			this.getView().getModel("employee").refresh();
		},
		//MR: [GRP02-03] GTM25 Resource Profile alignment #84 end

/*Filter business area segments*/
filterBASegments: function () {
const oModel = this.getView().getModel("employee");
const oTempEmployee = oModel.getProperty("/TempEmployee");
let aBASegments = [];
aBASegments = JSON.parse(JSON.stringify(oTempEmployee.BASegmentsList));
let aEmployeeBASegments = JSON.parse(JSON.stringify(oModel.getProperty("/TempEmployee/BASegments")));
oModel.setProperty("/NonSegmentFocused", {
Guid: "",
IsSelected: false,
IsVisible: false
});
aBASegments.map(function (element, index, array) {
const oEmployeeBASegment = aEmployeeBASegments.find(item => item.Guid === element.Guid);
if (oEmployeeBASegment) {
	element.IsSelected = true;
	element.IsPrimary = false;
} else {
	element.IsSelected = false;
	element.IsPrimary = false;
}
if (element.IsNonFocused) {
	oModel.setProperty("/NonSegmentFocused", {
		Guid: element.Guid,
		IsSelected: false,
		IsVisible: true
	});
	if (oEmployeeBASegment && oEmployeeBASegment.Guid === element.Guid) {
		oModel.setProperty("/TempEmployee/BASegments", [{
			Guid: element.Guid,
			Desc: element.Desc,
			IsPrimary: true,
			IsNonFocused: true,
			ID: element.ID
		}]);
		oModel.setProperty("/NonSegmentFocused", {
			Guid: element.Guid,
			IsSelected: true,
			IsVisible: true,
			ID: element.ID
		});
	}
}
});
aEmployeeBASegments = JSON.parse(JSON.stringify(oModel.getProperty("/TempEmployee/BASegments")));
let aFilteredEmployeeBASegments = JSON.parse(JSON.stringify(aEmployeeBASegments));
for (let i = 0; i < aEmployeeBASegments.length; i++) {
const iIndex = aBASegments.findIndex(item => item.Guid === aEmployeeBASegments[i].Guid);
if (iIndex === -1) {
	aFilteredEmployeeBASegments = aFilteredEmployeeBASegments.filter(item => item.Guid !== aEmployeeBASegments[i].Guid);
}
}
oModel.setProperty("/TempEmployee/BASegments", aFilteredEmployeeBASegments);
oModel.setProperty("/TempEmployee/TempBASegments", JSON.parse(JSON.stringify(oTempEmployee.BASegments)));
oModel.setProperty("/BASegments", aBASegments);
oModel.refresh(true);
this._onEnableSearchResources();
},
/*Set Master data model*/
fnMasterDataSuccess: function (sModelName, aResults) {
this.getView().setModel(new sap.ui.model.json.JSONModel(), sModelName);
const oModel = this.getView().getModel(sModelName);
oModel.setData(aResults);
},
/*Search event for business area industies*/
onSearchBAIndustry: function (oEvent) {
let sQuery = "";
if (oEvent) {
sQuery = oEvent.getSource().getValue();
}
let allFilter = [];
if (sQuery && sQuery.length > 0) {
const oFilter1 = new sap.ui.model.Filter("Desc", sap.ui.model.FilterOperator.Contains, sQuery);
const oFilter2 = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.Contains, sQuery);
const oFilter3 = new sap.ui.model.Filter("ClusterDesc", sap.ui.model.FilterOperator.Contains, sQuery);
allFilter = new sap.ui.model.Filter([oFilter1, oFilter2, oFilter3], false);
}
this.fnFilterNonFocusedTableData(sQuery, "baIndustrytableId", allFilter);
},
/*Select event for business area industries*/
onSelectBAIndustry: function (oEvent) {
	const oSource = oEvent.getSource();
	const oBinding = oSource.getBindingInfo("selected").binding;
	const oContext = oBinding.getContext();
	const oModel = oContext.getModel();
	const oBAIndustry = oModel.getProperty(oContext.getPath());
	const bSelected = oEvent.getParameter("selected");
	const aBAIndustries = oModel.getProperty("/BAIndustries");
	const aEmployeeBAIndustries = oModel.getProperty("/TempEmployee/TempBAIndustries");
	const iIndex = aEmployeeBAIndustries.findIndex(item => item.Guid === oBAIndustry.Guid);

	aBAIndustries.forEach(item => item.IsSelected = false);
	aEmployeeBAIndustries.length = 0; 

	oBAIndustry.IsSelected = true;
	
	aEmployeeBAIndustries.push({
		Guid: oBAIndustry.Guid,
		Desc: oBAIndustry.Desc,
		ClusterGuid: oBAIndustry.ClusterGuid,
		ClusterDesc: oBAIndustry.ClusterDesc,
		IsPrimary: true,
		BaIndTechID: oBAIndustry.BaIndTechID,
		BaIndId: oBAIndustry.BaIndId
	});

	oModel.refresh(true);
},
/*Select All Business area industy*/
onSelectAllBAIndustry: function (oEvent) {
const oModel = this.getView().getModel("employee");
const bSelected = oEvent.getParameter("selected");
let aBAIndustries = oModel.getProperty("/BAIndustries");
let aEmployeeBAIndustries = [];
aBAIndustries.map(function (item) {
item.IsSelected = bSelected;
item.IsPrimary = (bSelected === true && item.IsPrimary === true) ? true : false;
if (bSelected && item.IsNonFocused === false) {
	aEmployeeBAIndustries.push({
		Guid: item.Guid,
		Desc: item.Desc,
		ClusterGuid: item.ClusterGuid,
		ClusterDesc: item.ClusterDesc,
		IsPrimary: false,
		BaIndTechID: item.BaIndTechID,
		BaIndId: item.BaIndId
	});
}
});
oModel.setProperty("/TempEmployee/TempBAIndustries", aEmployeeBAIndustries);
oModel.refresh(true);
},
/*Update business area industries*/
onChangeBAIndustries: function (oEvent) {
const oModel = this.getView().getModel("employee");
const aEmployeeBAIndustries = oModel.getProperty("/TempEmployee/TempBAIndustries");
oModel.setProperty("/TempEmployee/BAIndustries", JSON.parse(JSON.stringify(aEmployeeBAIndustries)));
this.filterBAHubs(true);
this.onCloseBAIndustryValueHelpDialog();
let oSelectParams = {
	"bIndustry":true,
	"minSelect":oModel.getProperty(`/minSelect`),
	"maxSelect":oModel.getProperty(`/maxSelect`),
}
this._onManageIndSolSelection(oSelectParams);
this._onEnableSearchResources(oSelectParams);
this._setSearchFieldText();
},
	//manage selection for industry and solution area
		_onManageIndSolSelection: function (oSelectParams, bDelete) {
			let oModel = this.getView().getModel("employee");
			if (oSelectParams["maxSelect"] === 1 && !bDelete) {
				oSelectParams["bIndustry"] ? oModel.setProperty(`/solnAreaEnable`, false) :
					oModel.setProperty(`/industryEnable`, false);
			} else if (oSelectParams["maxSelect"] === 2 || bDelete) {
				oModel.setProperty(`/solnAreaEnable`, true);
				oModel.setProperty(`/industryEnable`, true);
			}
			if (oModel.getProperty(`/industryEnable`) && oSelectParams["maxSelect"] === 1 && !bDelete) {
				oModel.setProperty(`/TempEmployee/SolutionAreas`, [])
			} else if (oSelectParams["maxSelect"] === 1 && bDelete) {
				oModel.setProperty(`/TempEmployee/BAIndustries`, []);
				this.getView().getModel("employee").setProperty(`/TempEmployee/TempBAIndustries`, []);
			}
			oModel.refresh();
		},
/*Close business area industries fragment*/
onCloseBAIndustryValueHelpDialog: function () {
	const oModel = this.getView().getModel("masterDataModel");
	const aEmployeeBAIndustries = oModel.getProperty("/TempEmployee/BAIndustries");
	const oEmployeeModel = this.getView().getModel("employee");
	oEmployeeModel.setProperty(`/TempEmployee/TempBAIndustries`, JSON.parse(JSON.stringify(aEmployeeBAIndustries)));
	this.getView().getModel("employee").setProperty("/sSearchBoxText", "");
const that = this;
this.pBAIndustryValueHelpDialog.then(function (oDialog) {
that.onSearchBAIndustry();
oDialog.close();

});
},
/*Change selection to NonIndustyFoused*/
onChangeNonIndustryFocused: function (oEvent) {
const oModel = this.getView().getModel("employee");
const bSelected = oEvent.getParameter("state");
const aBAIndustries = oModel.getProperty("/BAIndustries");
let oNonIndustryFocused;
aBAIndustries.map(function (element, index, array) {
if (bSelected && element.IsNonFocused) {
	element.IsSelected = true;
	element.IsPrimary = true;
	oNonIndustryFocused = element;
} else {
	element.IsSelected = false;
	element.IsPrimary = false;
}
});

if (bSelected && oNonIndustryFocused) {
oModel.setProperty("/TempEmployee/TempBAIndustries", [{
	Guid: oNonIndustryFocused.Guid,
	Desc: oNonIndustryFocused.Desc,
	IsPrimary: false,
	IsNonFocused: true,
	BaIndTechID: oNonIndustryFocused.ID,
	BaIndId: oNonIndustryFocused.ID
}]);
oModel.setProperty("/NonIndustryFocused", {
	Guid: oNonIndustryFocused.Guid,
	IsSelected: true,
	IsVisible: true
});
} else {
oModel.setProperty("/TempEmployee/TempBAIndustries", []);
oModel.setProperty("/NonIndustryFocused", {
	Guid: "",
	IsSelected: false,
	IsVisible: true
});
}
},
/*Search event for BALoB*/
onSearchBALoB: function (oEvent) {
let sQuery = "";
if (oEvent) {
sQuery = oEvent.getSource().getValue();
}
let allFilter = [];
if (sQuery && sQuery.length > 0) {
const oFilter1 = new sap.ui.model.Filter("Desc", sap.ui.model.FilterOperator.Contains, sQuery);
const oFilter2 = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.Contains, sQuery);
allFilter = new sap.ui.model.Filter([oFilter1, oFilter2], false);
}
this.fnFilterNonFocusedTableData(sQuery, "baLoBsTableId", allFilter);
},
/*Select event for BALoB*/
onSelectBALoB: function (oEvent) {
const oSource = oEvent.getSource();
const oBinding = oSource.getBindingInfo("selected").binding;
const oContext = oBinding.getContext();
const oModel = oContext.getModel();
const oBALoB = oModel.getProperty(oContext.getPath());
const bSelected = oEvent.getParameter("selected");
const aBALobMasterData = this.getView().getModel("employee").getProperty("/BALoBs");
			aBALobMasterData.map(function (element) {
				if(element.Guid !== oBALoB.Guid){
					element.IsSelected = false;
				}
			});
oModel.setProperty("/TempEmployee/TempBALoBs",[]);
const aEmployeeBALoBs = oModel.getProperty("/TempEmployee/TempBALoBs");
const iIndex = aEmployeeBALoBs.findIndex(item => item.Guid === oBALoB.Guid);

if (iIndex !== -1 && !bSelected) {
aEmployeeBALoBs.splice(iIndex, 1);
oBALoB.IsPrimary = false;
} else if (iIndex === -1 && bSelected) {

const aBALoBs = oModel.getProperty("/BALoBs");
const aEnabledBALoBs = aBALoBs.filter(item => item.IsEnabled && item.IsSelected);
if (aEnabledBALoBs.length === 1 && oBALoB.IsEnabled) {
	oBALoB.IsPrimary = false;
} else if (aEnabledBALoBs.length === 2) {
	aEnabledBALoBs[0].IsPrimary = false;
	aEnabledBALoBs[1].IsPrimary = false;
	for (let i = 0; i < aEnabledBALoBs.length; i++) {
		aEnabledBALoBs[i].IsPrimary = false;
		const oEmployeeBALoB = aEmployeeBALoBs.find(item => item.Guid === aEnabledBALoBs[i].Guid);
		if (oEmployeeBALoB) {
			oEmployeeBALoB.IsPrimary = false;
		}
	}
}
aEmployeeBALoBs.push({
	Guid: oBALoB.Guid,
	Desc: oBALoB.Desc,
	IsPrimary: oBALoB.IsPrimary,
	ClusterGuid: oBALoB.ClusterGuid,
	ClusterDesc: oBALoB.ClusterDesc,
	ID: oBALoB.ID
});
}

oModel.refresh(true);

},
/*Select All BALoB*/
onSelectAllBALoB: function (oEvent) {
const oModel = this.getView().getModel("employee");
const bSelected = oEvent.getParameter("selected");
let aBALoBs = oModel.getProperty("/BALoBs");
let aEmployeeBALoBs = [];
aBALoBs.map(function (item) {
item.IsSelected = bSelected;
item.IsPrimary = (bSelected === true && item.IsPrimary === true) ? true : false;
if (bSelected && item.IsNonFocused === false) {
	aEmployeeBALoBs.push({
		Guid: item.Guid,
		Desc: item.Desc,
		IsPrimary: false,
		ClusterGuid: item.ClusterGuid,
		ClusterDesc: item.ClusterDesc,
		ID: item.ID

	});
}
});
oModel.setProperty("/TempEmployee/TempBALoBs", aEmployeeBALoBs);
oModel.refresh(true);

},
/*Reset profit center master data model*/
onResetProfitCenterSelection: function () {
	this.selectIfTerritoryExists(this.getView().getModel("treeTerritories").getData().territories, [], 0, true);
  this.getView().getModel("treeTerritories").refresh();
	this.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.TempTreeTerritories = [];
	this.getView().getModel("selectedProfitCenter").refresh();
},
/*Selection change for BALoBs*/
onChangeBALoBs: function (oEvent) {
const oModel = this.getView().getModel("employee");
const aEmployeeBALoBs = JSON.parse(JSON.stringify(oModel.getProperty("/TempEmployee/TempBALoBs")));
oModel.setProperty("/TempEmployee/BALoBs", JSON.parse(JSON.stringify(aEmployeeBALoBs)));
this.filterBAHubs();
this.onCloseBALoBValueHelpDialog();
this._onEnableSearchResources();
},
/*Close BALoB fragment*/
onCloseBALoBValueHelpDialog: function () {
this.getView().getModel("employee").setProperty("/sSearchBoxText", "");
const that = this;
this.pBALoBValueHelpDialog.then(function (oDialog) {
that.onSearchBALoB();
oDialog.close();
});
},
/*Selection changes tp NonLoBFocused*/
onChangeNonLoBFocused: function (oEvent) {
const oModel = this.getView().getModel("employee");
const bSelected = oEvent.getParameter("state");
const aBALoBs = oModel.getProperty("/BALoBs");
let oNonLoBFocused;

aBALoBs.map(function (element, index, array) {
if (bSelected && element.IsNonFocused) {
	element.IsSelected = true;
	element.IsPrimary = false;
	oNonLoBFocused = element;
} else {
	element.IsSelected = false;
	element.IsPrimary = false;
}
});

if (bSelected && oNonLoBFocused) {
oModel.setProperty("/TempEmployee/TempBALoBs", [{
	Guid: oNonLoBFocused.Guid,
	Desc: oNonLoBFocused.Desc,
	IsPrimary: false,
	IsNonFocused: true,
	ID: oNonLoBFocused.ID
}]);
oModel.setProperty("/NonIndustryFocused", {
	Guid: oNonLoBFocused.Guid,
	IsSelected: true,
	IsVisible: true,
	ID: oNonLoBFocused.ID
});
} else {
oModel.setProperty("/TempEmployee/TempBALoBs", []);
oModel.setProperty("/NonLoBFocused", {
	Guid: "",
	IsSelected: false,
	IsVisible: true
});
}
},
/*Search event for business area segment*/
onSearchBASegment: function (oEvent) {
let sQuery = "";
if (oEvent) {
sQuery = oEvent.getSource().getValue();
}
let allFilter = [];
if (sQuery && sQuery.length > 0) {
const oFilter1 = new sap.ui.model.Filter("Desc", sap.ui.model.FilterOperator.Contains, sQuery.trim());
const oFilter2 = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.Contains, sQuery.trim());
allFilter = new sap.ui.model.Filter([oFilter1, oFilter2], false);
}
this.fnFilterNonFocusedTableData(sQuery, "baSegmentssTableId", allFilter);

},
/*Selection change for business area segment*/
onSelectBASegment: function (oEvent) {
const oSource = oEvent.getSource();
const oBinding = oSource.getBindingInfo("selected").binding;
const oContext = oBinding.getContext();
const oModel = oContext.getModel();
const oBASegment = oModel.getProperty(oContext.getPath());
const bSelected = oEvent.getParameter("selected");
const aEmployeeBASegments = oModel.getProperty("/TempEmployee/TempBASegments");
const iIndex = aEmployeeBASegments.findIndex(item => item.Guid === oBASegment.Guid);

if (iIndex !== -1 && !bSelected) {
aEmployeeBASegments.splice(iIndex, 1);
oBASegment.IsPrimary = false;
} else if (iIndex === -1 && bSelected) {
const aBASegments = oModel.getProperty("/BASegments");
const aEnabledBASegments = aBASegments.filter(item => item.IsEnabled && item.IsSelected);
if (aEnabledBASegments.length === 1 && oBASegment.IsEnabled) {
	oBASegment.IsPrimary = false;
} else if (aEnabledBASegments.length === 2) {
	aEnabledBASegments[0].IsPrimary = false;
	aEnabledBASegments[1].IsPrimary = false;
	for (let i = 0; i < aEnabledBASegments.length; i++) {
		aEnabledBASegments[i].IsPrimary = false;
		const oEmployeeBASegments = aEmployeeBASegments.find(item => item.Guid === aEnabledBASegments[i].Guid);
		if (oEmployeeBASegments) {
			oEmployeeBASegments.IsPrimary = false;
		}
	}
}
aEmployeeBASegments.push({
	Guid: oBASegment.Guid,
	Desc: oBASegment.Desc,
	ID: oBASegment.ID,
	IsPrimary: oBASegment.IsPrimary
});
}
oModel.refresh(true);
},
/*Select All business area segment*/
onSelectAllBASegment: function (oEvent) {
const oModel = this.getView().getModel("employee");
const bSelected = oEvent.getParameter("selected");
let aBASegments = oModel.getProperty("/BASegments");
let aEmployeeBASegments = [];
aBASegments.map(function (item) {
item.IsSelected = bSelected;
item.IsPrimary = (bSelected === true && item.IsPrimary === true) ? true : false;
if (bSelected && item.IsNonFocused === false) {
	aEmployeeBASegments.push({
		Guid: item.Guid,
		Desc: item.Desc,
		ID: item.ID,
		IsPrimary: false
	});
}
});
oModel.setProperty("/TempEmployee/TempBASegments", aEmployeeBASegments);
oModel.refresh(true);
},
/*Selection change for business area segments*/
onChangeBASegments: function () {
const oModel = this.getView().getModel("employee");
const aEmployeeBASegments = oModel.getProperty("/TempEmployee/TempBASegments");
oModel.setProperty("/TempEmployee/BASegments", JSON.parse(JSON.stringify(aEmployeeBASegments)));
this.filterBASegments();
this.onCloseBASegmentValueHelpDialog();
},
/*Close business area segment fragment*/
onCloseBASegmentValueHelpDialog: function () {
this.getView().getModel("employee").setProperty("/sSearchBoxText", "");
const that = this;
this.pBASegDialog.then(function (oDialog) {
that.onSearchBASegment();
oDialog.close();
});
},
/*Select NonSegmentFocused*/
onChangeNonSegmentFocused: function (oEvent) {
const oModel = this.getView().getModel("employee");
const bSelected = oEvent.getParameter("state");
const aBAIndustries = oModel.getProperty("/BASegments");
let oNonBASegmentFocused;

aBAIndustries.map(function (element, index, array) {
if (bSelected && element.IsNonFocused) {
	element.IsSelected = true;
	element.IsPrimary = false;
	oNonBASegmentFocused = element;
} else {
	element.IsSelected = false;
	element.IsPrimary = false;
}
});

if (bSelected && oNonBASegmentFocused) {
oModel.setProperty("/TempEmployee/TempBASegments", [{
	Guid: oNonBASegmentFocused.Guid,
	Desc: oNonBASegmentFocused.Desc,
	IsPrimary: false,
	IsNonFocused: true,
	ID: oNonBASegmentFocused.ID
}]);
oModel.setProperty("/NonSegmentFocused", {
	Guid: oNonBASegmentFocused.Guid,
	ID: oNonBASegmentFocused.ID,
	IsSelected: true,
	IsVisible: true
});
} else {
oModel.setProperty("/TempEmployee/TempBASegments", []);
oModel.setProperty("/NonSegmentFocused", {
	Guid: "",
	IsSelected: false,
	IsVisible: true
});
}
oModel.refresh(true);
},
/*Search event for cross coverages*/
onSearchCrossCvrg: function (oEvent) {
let sQuery = "";
if (oEvent) {
sQuery = oEvent.getSource().getValue();
}
let allFilter = [];
if (sQuery && sQuery.length > 0) {
const oFilter1 = new sap.ui.model.Filter("Desc", sap.ui.model.FilterOperator.Contains, sQuery);
const oFilter2 = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.Contains, sQuery);
allFilter = new sap.ui.model.Filter([oFilter1, oFilter2], false);
}
this.fnFilterNonFocusedTableData(sQuery, "crossCvgTableId", allFilter);
},
/*Select NonCrossCoverageFocused*/
onChangeNonCrossCvrgFocused: function (oEvent) {
const oModel = this.getView().getModel("employee");
const bSelected = oEvent.getParameter("state");
const aCrossCvrg = oModel.getProperty("/CrossCvg");
let oNonCrossCvrgFocused;
aCrossCvrg.map(function (element, index, array) {
if (bSelected && element.IsNonFocused) {
	element.IsSelected = true;
	element.IsPrimary = false;
	oNonCrossCvrgFocused = element;
} else {
	element.IsSelected = false;
	element.IsPrimary = false;
}
});

if (bSelected && oNonCrossCvrgFocused) {
oModel.setProperty("/TempEmployee/TempCrossCvg", [{
	Guid: oNonCrossCvrgFocused.Guid,
	Desc: oNonCrossCvrgFocused.Desc,
	IsPrimary: false,
	IsNonFocused: true,
	ID: oNonCrossCvrgFocused.ID

}]);
oModel.setProperty("/NonCrossCoverageFocused", {
	Guid: oNonCrossCvrgFocused.Guid,
	ID: oNonCrossCvrgFocused.ID,
	IsSelected: true,
	IsVisible: true
});
} else {
oModel.setProperty("/TempEmployee/TempCrossCvg", []);
oModel.setProperty("/NonCrossCoverageFocused", {
	Guid: "",
	IsSelected: false,
	IsVisible: true
});
}
},
/*Select event for cross coverage*/
onSelectCrossCvrg: function (oEvent) {
const oSource = oEvent.getSource();
const oBinding = oSource.getBindingInfo("selected").binding;
const oContext = oBinding.getContext();
const oModel = oContext.getModel();
const oCrossCvrg = oModel.getProperty(oContext.getPath());
const bSelected = oEvent.getParameter("selected");
	const aCrossCvgMasterData = this.getView().getModel("employee").getProperty("/CrossCvg");
	aCrossCvgMasterData.map(function (element) {
		if (element.Guid !== oCrossCvrg.Guid) {
			element.IsSelected = false;
		}
	});
	oModel.setProperty("/TempEmployee/TempCrossCvg", []);
const aEmployeeCrossCvrgs = oModel.getProperty("/TempEmployee/TempCrossCvg");
const iIndex = aEmployeeCrossCvrgs.findIndex(item => item.Guid === oCrossCvrg.Guid);

if (iIndex !== -1 && !bSelected) {
aEmployeeCrossCvrgs.splice(iIndex, 1);
oCrossCvrg.IsPrimary = false;
} else if (iIndex === -1 && bSelected) {

const aCrossCvrgs = oModel.getProperty("/CrossCvg");
const aEnabledCrossCvrgs = aCrossCvrgs.filter(item => item.IsEnabled && item.IsSelected);
if (aEnabledCrossCvrgs.length === 1 && oCrossCvrg.IsEnabled) {
	oCrossCvrg.IsPrimary = false;
} else if (aEnabledCrossCvrgs.length === 2) {
	aEnabledCrossCvrgs[0].IsPrimary = false;
	aEnabledCrossCvrgs[1].IsPrimary = false;
	for (let i = 0; i < aEnabledCrossCvrgs.length; i++) {
		aEnabledCrossCvrgs[i].IsPrimary = false;
		const oEmployeeCrossCvrg = aEmployeeCrossCvrgs.find(item => item.Guid === aEnabledCrossCvrgs[i].Guid);
		if (oEmployeeCrossCvrg) {
			oEmployeeCrossCvrg.IsPrimary = false;
		}
	}
}
aEmployeeCrossCvrgs.push({
	Guid: oCrossCvrg.Guid,
	Desc: oCrossCvrg.Desc,
	IsPrimary: oCrossCvrg.IsPrimary,
	ID: oCrossCvrg.ID
});
}

oModel.refresh(true);
},
/*Select All cross coverage*/
onSelectAllCrossCvrg: function (oEvent) {
const oModel = this.getView().getModel("employee");
const bSelected = oEvent.getParameter("selected");
let aCrosCvrgs = oModel.getProperty("/CrossCvg");
let aEmployeeCrossCvrgs = [];
aCrosCvrgs.map(function (item) {
item.IsSelected = bSelected;
item.IsPrimary = (bSelected === true && item.IsPrimary === true) ? true : false;
if (bSelected && item.IsNonFocused === false) {
	aEmployeeCrossCvrgs.push({
		Guid: item.Guid,
		Desc: item.Desc,
		IsPrimary: false,
		ID: item.ID
	});
}
});
oModel.setProperty("/TempEmployee/TempCrossCvg", aEmployeeCrossCvrgs);
oModel.refresh(true);
},
/*Selection change for cross coverage*/
onChangeCrossCvgs: function (oEvent) {
const oModel = this.getView().getModel("employee");
const aEmployeeCrossCvgs = oModel.getProperty("/TempEmployee/TempCrossCvg");
oModel.setProperty("/TempEmployee/CrossCvg", JSON.parse(JSON.stringify(aEmployeeCrossCvgs)));
this.filterBAHubs();
this.onCloseCrossCvgValueHelpDialog();

},
/*Close cross coverage fragment*/
onCloseCrossCvgValueHelpDialog: function () {
this.getView().getModel("employee").setProperty("/sSearchBoxText", "");
const that = this;
this.pCrossCvgValueHelpDialog.then(function (oDialog) {
that.onSearchCrossCvrg();
oDialog.close();
});
},
fnFilterNonFocusedTableData: function (sQuery, tableId, allFilter) {
const oNonFocusedFilter = new sap.ui.model.Filter("IsNonFocused", sap.ui.model.FilterOperator.EQ, false);
const aFilters = new sap.ui.model.Filter([allFilter, oNonFocusedFilter], true);
this.getView().byId(tableId).getBinding().filter(aFilters);
},
/*Open Hub fragment*/
onOpenHubValueHelpDialog: function (oEvent) {
const oModel = this.getView().getModel("employee");
const that = this;
if (!this.pHubValueHelpDialog) {
this.pHubValueHelpDialog = this.loadFragment({
	name: "com.sap.bpm.PresalesRequestApproval.fragments.resourceProfile.HubValueHelpDialog"
});
this.getView().getModel("employee").setProperty("/TempEmployee/hubLoBBusy",true);
this.getView().getModel("employee").refresh();
this._setHubMetadata();
}
this.pHubValueHelpDialog.then(function (oDialog) {
const aSelectedHubs = oModel.getProperty("/TempEmployee/SelectedHubs");
let aTempSelectedHubs = oModel.getProperty("/TempEmployee/TempSelectedHubs");
aTempSelectedHubs = JSON.parse(JSON.stringify(aSelectedHubs));
oModel.setProperty("/TempEmployee/TempSelectedHubs", aTempSelectedHubs);
that.filterBAHubs();
oDialog.openBy(that.getView().byId("idHubsMultiInput"));
});
},
/*Search event for Hubs*/
onSearchHubs: function (oEvent) {
const query = oEvent.getSource().getValue();
let table = oEvent.getSource().getParent().getParent();
table.getBinding().filter(query ? new Filter({
path: "Desc",
operator: "Contains",
value1: query
}) : null);
table.expandToLevel(query ? 99 : 0);
},
/*Selection change for Hubs*/
onSelectHub: function (oEvent) {
const oSource = oEvent.getSource();
const oContext = oSource.getBindingContext("employee");
const oModel = oContext.getModel();
const oHub = oModel.getProperty(oContext.getPath());
const bSelected = oEvent.getParameter("selected");
let aTempSelectedHubs = oModel.getProperty("/TempEmployee/TempSelectedHubs");
const iIndex = aTempSelectedHubs.findIndex(item => item.HubGuid === oHub.Guid && item.LevelId === oHub.LevelId && item.Type ===
oHub.Type);
const aArray = oContext.getPath().split("/Levels/");
let oSelectedHubL2;
if (aArray && aArray.length > 1) {
oSelectedHubL2 = oModel.getProperty(aArray[0] + "/Levels/" + aArray[1]);
}

if (iIndex !== -1 && !bSelected) {
oHub.IsPrimary = false;
aTempSelectedHubs.splice(iIndex, 1);
if (parseInt(oHub.LevelId, 10) === 3) {
	let bL2Selected = false,
		bL2Primary = false;
	if (oSelectedHubL2) {
		const aSelectedHubL2Levels = oSelectedHubL2.Levels;
		if (aSelectedHubL2Levels && aSelectedHubL2Levels.length > 0) {
			const aSelectedLevels = aSelectedHubL2Levels.filter(item => item.IsSelected);
			oSelectedHubL2.IsSelected = true;
			if (aSelectedLevels.length === 0) {
				// oSelectedHubL2.IsSelected = true;
				bL2Selected = true;
				bL2Primary = false;
			} else if (aSelectedLevels.length === 1) {

				bL2Selected = false;
				oSelectedHubL2.IsPrimary = false;
				bL2Primary = false;
			}

		}
	}
	const iL2Index = aTempSelectedHubs.findIndex(item => item.HubGuid === oHub.HubGuidL2 && parseInt(item.LevelId, 10) === 2 &&
		item.Type ===
		oHub.Type);

	if (bL2Selected) {

		const oL2 = {
			HubGuid: oHub.HubGuidL2,
			HubDesc: oHub.HubDescL2,
			HubGuidL1: oHub.HubGuidL1,
			HubDescL1: oHub.HubDescL1,
			HubGuidL2: oHub.HubGuidL2,
			HubDescL2: oHub.HubDescL2,
			LevelId: "0002",
			Type: oHub.Type,
			IsPrimary: false,
			ID: oSelectedHubL2.ID
		};

		if (iL2Index !== -1) {
			aTempSelectedHubs[iL2Index] = oL2;
		} else {
			aTempSelectedHubs.push(oL2);
		}
	} else {
		if (iL2Index !== -1) {
			aTempSelectedHubs.splice(iL2Index, 1);
		}
	}
}
} else if (iIndex === -1 && bSelected) {
// let bIsPrimary = false;

if (parseInt(oHub.LevelId, 10) === 3) {
	const iL2Index = aTempSelectedHubs.findIndex(item => item.HubGuid === oHub.HubGuidL2 && parseInt(item.LevelId, 10) === 2 &&
		item.Type === oHub.Type);

	if (iL2Index !== -1) {
		aTempSelectedHubs.splice(iL2Index, 1);
	}
	oHub.IsPrimary = false;
	aTempSelectedHubs.push({
		HubGuid: oHub.Guid,
		HubDesc: oHub.Desc,
		HubGuidL1: oHub.HubGuidL1,
		HubDescL1: oHub.HubDescL1,
		HubGuidL2: oHub.HubGuidL2,
		HubDescL2: oHub.HubDescL2,
		HubGuidL3: oHub.HubGuidL3,
		HubDescL3: oHub.HubDescL3,
		LevelId: oHub.LevelId,
		Type: oHub.Type,
		IsPrimary: false,
		ID: oHub.ID
	});
} else if (parseInt(oHub.LevelId, 10) === 2) {
	aTempSelectedHubs.push({
		HubGuid: oHub.Guid,
		HubDesc: oHub.Desc,
		HubGuidL1: oHub.HubGuidL1,
		HubDescL1: oHub.HubDescL1,
		HubGuidL2: oHub.HubGuidL2,
		HubDescL2: oHub.HubDescL2,

		LevelId: oHub.LevelId,
		Type: oHub.Type,
		IsPrimary: false,
		ID: oHub.ID
	});
}

} else if (iIndex === -1 && !bSelected && parseInt(oHub.LevelId, 10) === 2) {
for (let i = 0; i < oHub.Levels.length; i++) {
	oHub.Levels[i].IsSelected = false;
}
aTempSelectedHubs = aTempSelectedHubs.filter(item => !(item.HubGuidL1 === oHub.HubGuidL1 && item.HubGuidL2 === oHub.HubGuidL2));

}
oModel.setProperty("/TempEmployee/TempSelectedHubs", aTempSelectedHubs);
oModel.refresh(true);
this.filterBAHubs(false, true);
oModel.refresh(true);
},
/*Change Hubs*/
onChangeHubs: function (oEvent) {
const oModel = this.getView().getModel("employee");
const aTempSelectedHubs = oModel.getProperty("/TempEmployee/TempSelectedHubs");
oModel.setProperty("/TempEmployee/SelectedHubs", JSON.parse(JSON.stringify(aTempSelectedHubs)));
this.onCloseHubValueHelpDialog();
},
/*Close Hub Fragment*/
onCloseHubValueHelpDialog: function () {
this.getView().getModel("employee").setProperty("/sSearchBoxText", "");
this.pHubValueHelpDialog.then(function (oDialog) {
let aItems = oDialog.getContent()[0].getContent()[0].getItems();
oDialog.close();
for (let i = 0; i < aItems.length; i++) {
	aItems[i].getContent()[0].getItems()[0].getBinding().filter([]);
	aItems[i].getContent()[0].getItems()[0].collapseAll();
}
});
},
/*Filter Hubs and set model*/
filterBAHubs: function (initLoad, isCheckBoxSelected) {
const oModel = this.getView().getModel("employee");
const oTempEmployee = oModel.getProperty("/TempEmployee");
const aHubs = [];
const aHubIndustryRules = oModel.getProperty("/Rules/HubIndustry");
const aHubLoBRules = oModel.getProperty("/Rules/HubLoB");
const aHubRoleRules = oModel.getProperty("/Rules/HubRole");
let aSelectedHubs = oTempEmployee.TempSelectedHubs;
const aFilteredHubIndustryRules = [],
aFilteredHubLoBRules = [];
const aFilteredHubRoleRules = aHubRoleRules;
let aFilteredSelectedHubs = JSON.parse(JSON.stringify(aSelectedHubs));
aFilteredHubIndustryRules.push(...aHubIndustryRules);
aFilteredHubLoBRules.push(...aHubLoBRules);
aSelectedHubs = aFilteredSelectedHubs;
aFilteredHubIndustryRules.map((element, index, array) => {
const oHubIndustry = aSelectedHubs.find(item => (item.HubGuidL1 === element.HubIndL1Guid && parseInt(item.LevelId, 10) === 1) ||
	(item.HubGuidL2 === element.HubIndL2Guid && parseInt(item.LevelId, 10) === 2) ||
	(item.HubGuidL3 === element.HubIndL3Guid && parseInt(item.LevelId, 10) === 3));

let oL1, oL2, oL3;
if (element.HubIndL3Guid && parseInt(element.HubIndL3Guid, 10) !== 0) {
	oL3 = {
		Guid: element.HubIndL3Guid,
		ID: element.HubIndL3Id,
		Desc: element.HubIndL3Desc,
		IsSelected: (oHubIndustry && oHubIndustry.HubGuidL1 === element.HubIndL1Guid && oHubIndustry.HubGuidL2 === element.HubIndL2Guid &&
			oHubIndustry.HubGuidL3 === element.HubIndL3Guid) ? true : false,
		// LevelId: element.HbindLevelL3,
		Type: "INDUSTRY",
		HubGuidL1: element.HubIndL1Guid,
		HubDescL1: element.HubIndL1Desc,
		HubGuidL2: element.HubIndL2Guid,
		HubDescL2: element.HubIndL2Desc,
		HubGuidL3: element.HubIndL3Guid,
		HubDescL3: element.HubIndL3Desc,
		IsPrimary: false,
		LevelId: "0003"

	};
	if (oHubIndustry && parseInt(oHubIndustry.LevelId, 10) === 3) {
		oHubIndustry.HubGuidL3 = element.HubIndL3Guid;
		oHubIndustry.HubDescL3 = element.HubIndL3Desc;
	}
}
if (element.HubIndL2Guid && parseInt(element.HubIndL2Guid, 10) !== 0) {
	oL2 = {
		Guid: element.HubIndL2Guid,
		ID: element.HubIndL2Id,
		Desc: element.HubIndL2Desc,
		IsSelected: (oHubIndustry && oHubIndustry.HubGuidL1 === element.HubIndL1Guid && oHubIndustry.HubGuidL2 === element.HubIndL2Guid) ?
			true : false,
		Type: "INDUSTRY",
		HubGuidL1: element.HubIndL1Guid,
		HubDescL1: element.HubIndL1Desc,
		HubGuidL2: element.HubIndL2Guid,
		HubDescL2: element.HubIndL2Desc,
		IsPrimary: false,
		Levels: [],
		LevelId: "0002"
	};

	if (oHubIndustry) {
		oHubIndustry.HubGuidL2 = element.HubIndL2Guid;
		oHubIndustry.HubDescL2 = element.HubIndL2Desc;
	}
}

if (element.HubIndL1Guid && parseInt(element.HubIndL1Guid, 10) !== 0) {
	oL1 = {
		Guid: element.HubIndL1Guid,
		ID: element.HubIndL1Id,
		Desc: element.HubIndL1Desc,
		IsSelected: (oHubIndustry && oHubIndustry.HubGuidL1 === element.HubIndL1Guid) ? true : false,
		LevelId: element.HbindLevelL1,
		Type: "INDUSTRY",
		HubGuidL1: element.HubIndL1Guid,
		HubDescL1: element.HubIndL1Desc,
		Levels: [],
		LevelId: "0001"
	};

	if (oHubIndustry) {
		oHubIndustry.HubGuidL1 = element.HubIndL1Guid;
		oHubIndustry.HubDescL1 = element.HubIndL1Desc;
	}
}

const iL1Index = aHubs.findIndex(item => item.Guid === element.HubIndL1Guid);
if (iL1Index !== -1) {
	const iL2Index = aHubs[iL1Index].Levels.findIndex(item => item.Guid === element.HubIndL2Guid);
	if (iL2Index !== -1) {
		const iL3Index = aHubs[iL1Index].Levels[iL2Index].Levels.findIndex(item => item.Guid === element.HubIndL2Desc);
		if (iL3Index === -1 && oL3) {
			aHubs[iL1Index].Levels[iL2Index].Levels.push(oL3);
			aHubs[iL1Index].Levels[iL2Index].Levels.sort((a, b) => a.Desc.localeCompare(b.Desc));
		}
	} else {
		if (oL3) {
			oL2.Levels = [oL3];
			oL2.Levels.sort((a, b) => a.Desc.localeCompare(b.Desc));
		}
		aHubs[iL1Index].Levels.push(oL2);
		aHubs[iL1Index].Levels.sort((a, b) => a.Desc.localeCompare(b.Desc));
	}
} else {
	if (oL3 && oL2) {
		oL2.Levels = [oL3];
	}
	if (oL2 && oL1) {
		oL1.Levels = [oL2];
	}
	if (oL1) {
		aHubs.push(oL1);
		aHubs.sort((a, b) => a.Desc.localeCompare(b.Desc));
	}
}
});

aFilteredHubLoBRules.map((element, index, array) => {
const oHubLoB = aSelectedHubs.find(item => (item.HubGuidL1 === element.HublobL1Guid && parseInt(item.LevelId, 10) === 1) ||
	(item.HubGuidL2 === element.HublobL2Guid && parseInt(item.LevelId, 10) === 2) ||
	(item.HubGuidL3 === element.HublobL3Guid && parseInt(item.LevelId, 10) === 3));

let oL1, oL2, oL3;
if (element.HublobL3Guid && parseInt(element.HublobL3Guid, 10) !== 0) {
	oL3 = {
		Guid: element.HublobL3Guid,
		ID: element.HublobL3Id,
		Desc: element.HublobL3Desc,
		// LevelId: element.HublobL3Id,
		Type: "LOB",
		HubGuidL1: element.HublobL1Guid,
		HubDescL1: element.HublobL1Desc,
		HubGuidL2: element.HublobL2Guid,
		HubDescL2: element.HublobL2Desc,
		HubGuidL3: element.HublobL3Guid,
		HubDescL3: element.HublobL3Desc,
		IsPrimary: false,
		IsSelected: (oHubLoB && oHubLoB.HubGuidL1 === element.HublobL1Guid && oHubLoB.HubGuidL2 === element.HublobL2Guid &&
			oHubLoB.HubGuidL3 === element.HublobL3Guid),
		LevelId: "0003"
	};

	if (oHubLoB && parseInt(oHubLoB.LevelId, 10) === 3) {
		oHubLoB.HubGuidL3 = element.HublobL3Guid;
		oHubLoB.HubDescL3 = element.HublobL3Desc;
	}
}

if (element.HublobL2Guid && parseInt(element.HublobL2Guid, 10) !== 0) {

	oL2 = {
		Guid: element.HublobL2Guid,
		ID: element.HublobL2Id,
		Desc: element.HublobL2Desc,

		IsRequired: (element.HUBLOBL2Meta === "M") ? true : false,
		// LevelId: element.HublobL2Id,
		Type: "LOB",
		HubGuidL1: element.HublobL1Guid,
		HubDescL1: element.HublobL1Desc,
		HubGuidL2: element.HublobL2Guid,
		HubDescL2: element.HublobL2Desc,

		Levels: [],
		isPartiallySelected: false,
		IsPrimary: false,
		IsSelected: (oHubLoB && oHubLoB.HubGuidL1 === element.HublobL1Guid && oHubLoB.HubGuidL2 === element.HublobL2Guid),
		LevelId: "0002"
	};

	if (oHubLoB) {
		oHubLoB.HubGuidL2 = element.HublobL2Guid;
		oHubLoB.HubDescL2 = element.HublobL2Desc;
	}
}

if (element.HublobL1Guid && parseInt(element.HublobL1Guid, 10) !== 0) {
	oL1 = {
		Guid: element.HublobL1Guid,
		ID: element.HublobL1Id,
		Desc: element.HublobL1Desc,
		IsSelected: (oHubLoB && oHubLoB.HubGuidL1 === element.HublobL1Guid),
		// LevelId: element.HblobLevelL1,
		Type: "LOB",
		HubGuidL1: element.HublobL1Guid,
		HubDescL1: element.HublobL1Desc,
		Levels: [],
		LevelId: "0001"

	};

	if (oHubLoB) {
		oHubLoB.HubGuidL1 = element.HublobL1Guid;
		oHubLoB.HubDescL1 = element.HublobL1Desc;
	}
}

const iL1Index = aHubs.findIndex(item => item.Guid === element.HublobL1Guid);
if (iL1Index !== -1) {
	const iL2Index = aHubs[iL1Index].Levels.findIndex(item => item.Guid === element.HublobL2Guid);

	if (iL2Index !== -1) {
		if (oL2 && oL2.HubGuidL2 === aHubs[iL1Index].Levels[iL2Index].HubGuidL2 && oL2.BAHubGuid !== aHubs[iL1Index].Levels[0].BAHubGuid &&
			oL2.IsPrimary) {
			if (aHubs[iL1Index].Levels[iL2Index].Levels && aHubs[iL1Index].Levels[iL2Index].Levels.length && (element.BaLobGuid ===
					aHubs[iL1Index].Levels[iL2Index].BAHubGuid || element.CrossCvrgGuid === aHubs[iL1Index].Levels[iL2Index].BAHubGuid)) {
				oL2.Levels = aHubs[iL1Index].Levels[iL2Index].Levels;
			}
			aHubs[iL1Index].Levels[iL2Index] = oL2;
		}
		const iL3Index = aHubs[iL1Index].Levels[iL2Index].Levels.findIndex(item => item.Guid === element.HublobL3Guid);

		if (iL3Index === -1 && oL3) {
			aHubs[iL1Index].Levels[iL2Index].Levels.push(oL3);
			aHubs[iL1Index].Levels[iL2Index].Levels.sort((a, b) => a.Desc.localeCompare(b.Desc));
		}

	} else {
		if (oL3) {
			oL2.Levels = [oL3];
			oL2.Levels.sort((a, b) => a.Desc.localeCompare(b.Desc));
		}
		aHubs[iL1Index].Levels.push(oL2);
		aHubs[iL1Index].Levels.sort((a, b) => a.Desc.localeCompare(b.Desc));
	}
} else {
	if (oL3 && oL2) {
		oL2.Levels = [oL3];
	}
	if (oL2 && oL1) {
		oL1.Levels = [oL2];
	}
	if (oL1) {
		aHubs.push(oL1);
		aHubs.sort((a, b) => a.Desc.localeCompare(b.Desc));
	}
}
});

aFilteredHubRoleRules.map((element, index, array) => {
let bIsParentPrimary = false;
const oHubRole = aSelectedHubs.find(item => (item.HubGuidL1 === element.HubroleL1Guid && parseInt(item.LevelId, 10) === 1) ||
	(item.HubGuidL2 === element.HubroleL2Guid && parseInt(item.LevelId, 10) === 2) ||
	(item.HubGuidL3 === element.HubroleL3Guid && parseInt(item.LevelId, 10) === 3));

let oL1, oL2, oL3;
if (element.HubroleL3Guid && parseInt(element.HubroleL3Guid, 10) !== 0) {
	oL3 = {
		Guid: element.HubroleL3Guid,
		ID: element.HubroleL3Id,
		Desc: element.HubroleL3Desc,
		// LevelId: element.HbrolLevelL3,
		Type: "ROLE",
		HubGuidL1: element.HubroleL1Guid,
		HubDescL1: element.HubroleL1Desc,
		HubGuidL2: element.HubroleL2Guid,
		HubDescL2: element.HubroleL2Desc,
		HubGuidL3: element.HubroleL3Guid,
		HubDescL3: element.HubroleL3Desc,
		IsPrimary: false,
		IsSelected: (oHubRole && oHubRole.HubGuidL1 === element.HubroleL1Guid && oHubRole.HubGuidL2 === element.HubroleL2Guid &&
			oHubRole.HubGuidL3 === element.HubroleL3Guid),
		LevelId: "0003"
	};

	if (oHubRole) {
		oHubRole.HubGuidL3 = element.HubroleL3Guid;
		oHubRole.HubDescL3 = element.HubroleL3Desc;
	}
}

if (element.HubroleL2Guid && parseInt(element.HubroleL2Guid, 10) !== 0) {

	oL2 = {
		Guid: element.HubroleL2Guid,
		ID: element.HubroleL2Id,
		Desc: element.HubroleL2Desc,
		// LevelId: element.HbrolLevelL2,
		Type: "ROLE",
		HubGuidL1: element.HubroleL1Guid,
		HubDescL1: element.HubroleL1Desc,
		HubGuidL2: element.HubroleL2Guid,
		HubDescL2: element.HubroleL2Desc,
		IsPrimary: false,
		IsSelected: (oHubRole && oHubRole.HubGuidL1 === element.HubroleL1Guid && oHubRole.HubGuidL2 === element.HubroleL2Guid),
		Levels: [],
		LevelId: "0002"
	};

	if (oHubRole) {
		oHubRole.HubGuidL2 = element.HubroleL2Guid;
		oHubRole.HubDescL2 = element.HubroleL2Desc;
	}
}

if (element.HubroleL1Guid && parseInt(element.HubroleL1Guid, 10) !== 0) {
	oL1 = {
		Guid: element.HubroleL1Guid,
		ID: element.HubroleL1Id,
		Desc: element.HubroleL1Desc,
		IsEnabled: false,
		IsSelected: (oHubRole && oHubRole.HubGuidL1 === element.HubroleL1Guid),
		// LevelId: element.HbrolLevelL1,
		Type: "ROLE",
		HubGuidL1: element.HubroleL1Guid,
		HubDescL1: element.HUBRoleL1Desc,
		Levels: [],
		LevelId: "0001"
	};

	if (oHubRole) {
		oHubRole.HubGuidL1 = element.HubroleL1Guid;
		oHubRole.HubDescL1 = element.HubroleL1Desc;
	}
}
const iL1Index = aHubs.findIndex(item => item.Guid === element.HubroleL1Guid);
if (iL1Index !== -1) {

	const iL2Index = aHubs[iL1Index].Levels.findIndex(item => item.Guid === element.HubroleL2Guid);

	if (iL2Index !== -1) {
		const iL3Index = aHubs[iL1Index].Levels[iL2Index].Levels.findIndex(item => item.Guid === element.HubroleL3Guid);

		if (iL3Index === -1 && oL3) {
			aHubs[iL1Index].Levels[iL2Index].Levels.push(oL3);
			aHubs[iL1Index].Levels[iL2Index].Levels.sort((a, b) => a.Desc.localeCompare(b.Desc));
		}

	} else {
		if (oL3) {
			oL2.Levels = [oL3];
		}
		aHubs[iL1Index].Levels.push(oL2);
		aHubs[iL1Index].Levels.sort((a, b) => a.Desc.localeCompare(b.Desc));
	}
} else {
	if (oL3 && oL2) {
		oL2.Levels = [oL3];
	}
	if (oL2 && oL1) {
		oL1.Levels = [oL2];
	}
	if (oL1) {
		aHubs.push(oL1);
		aHubs.sort((a, b) => a.Desc.localeCompare(b.Desc));
	}
}
});

for (let i = 0; i < aHubs.length; i++) {
const aL2 = aHubs[i].Levels;
for (let j = 0; j < aL2.length; j++) {
	const iLevel2Index = aSelectedHubs.findIndex(item => (item.HubGuidL1 === aHubs[i].Guid && item.HubGuidL2 === aL2[j].Guid &&
		parseInt(item.LevelId, 10) === 2));

	if (aL2[j].Levels && aL2[j].Levels.length > 0) {
		const aL3 = aL2[j].Levels;
		const iSelectedL3Index = aL3.findIndex(item => item.IsSelected);

		if (iSelectedL3Index !== -1) {
			if (iLevel2Index !== -1) {
				aSelectedHubs.splice(iLevel2Index, 1);
			}
			if (aL3.length > 1) {
				for (let k = 0; aL3.length > k; k++) {
					if (aL3[k].IsSelected) {
						aL2[j].IsSelected = true;
						const iLevel3Index = aSelectedHubs.findIndex(item => (item.HubGuidL1 === aHubs[i].Guid && item.HubGuidL2 === aL2[j].Guid &&
							item.HubGuidL3 === aL3[k].Guid && parseInt(item.LevelId, 10) === 3));

						const oL3 = {
							HubGuid: aL3[k].Guid,
							HubDesc: aL3[k].Desc,
							HubGuidL1: aHubs[i].Guid,
							HubDescL1: aHubs[i].Desc,
							HubGuidL2: aL2[j].Guid,
							HubDescL2: aL2[j].Desc,
							HubGuidL3: aL3[k].Guid,
							HubDescL3: aL3[k].Desc,
							LevelId: aL3[k].LevelId,
							Type: aL3[k].Type,
							IsPrimary: false,
							BAHubGuid: aL3[k].BAHubGuid
						};
						aL3[k].IsSelected = true;
						if (iLevel3Index !== -1) {
							aSelectedHubs[iLevel3Index] = oL3;
						} else {
							aSelectedHubs.push(oL3);
						}
					}
				}
			}
		} else {
			if (aL2[j].IsSelected) {

				const oL2 = {
					HubGuid: aL2[j].Guid,
					HubDesc: aL2[j].Desc,
					HubGuidL1: aHubs[i].Guid,
					HubDescL1: aHubs[i].Desc,
					HubGuidL2: aL2[j].Guid,
					HubDescL2: aL2[j].Desc,
					LevelId: aL2[j].LevelId,
					Type: aL2[j].Type,
					IsPrimary: false,
					BAHubGuid: aL2[j].BAHubGuid
				};
				if (iLevel2Index !== -1) {
					aSelectedHubs[iLevel2Index] = oL2;
				} else {
					aSelectedHubs.push(oL2);
				}
			}
		}
	}
}
// }
oModel.setProperty("/Hubs", aHubs);
oModel.refresh(true);
}
},
/*Enable Search Resources button*/
_onEnableSearchResources: function (oSelectedParams) {
	const oModel = this.getView().getModel("employee");
	const oTempEmployee = oModel.getProperty("/TempEmployee");
	const oSearchItem = oModel.getData();
	let sSelectedPfc = this.getView().getModel("selectedProfitCenter")? this.getView().getModel("selectedProfitCenter").getData().selectedPfc:"";
	if ((sSelectedPfc && oTempEmployee["TempRoles"] && oTempEmployee.TempRoles.RoleAreaID && (!oSearchItem.SolnAreaMandatory || !oSearchItem.SolnAreaSelectable) &&
		(!oSearchItem.BAIndustryMandatory || !oSearchItem.BAIndustryMandatory)) || (sSelectedPfc && oTempEmployee["TempRoles"] && oTempEmployee.TempRoles.RoleAreaID && (oSearchItem.SolnAreaMandatory && oTempEmployee.SolutionAreas.length) &&
			(oSearchItem.BAIndustryMandatory && oTempEmployee.BAIndustries.length)) ||
		(sSelectedPfc && oTempEmployee["TempRoles"] && oTempEmployee.TempRoles.RoleAreaID && oTempEmployee.TempRoles.RoleAreaID && (!oSearchItem.SolnAreaMandatory || !oSearchItem.SolnAreaSelectable) &&
			(oSearchItem.BAIndustryMandatory && oTempEmployee.BAIndustries.length)) ||
		(sSelectedPfc && oTempEmployee["TempRoles"] && oTempEmployee.TempRoles.RoleAreaID && (oSearchItem.SolnAreaMandatory && oTempEmployee.SolutionAreas.length) && (!oSearchItem.BAIndustryMandatory || !oSearchItem.BAIndustryMandatory))) {
		//if industry and solution area optional or non selectable enable create draft
		oModel.setProperty(`/isValidation`, true);
	} else {
		oModel.setProperty(`/isValidation`, false);
	}
	if(!oSelectedParams && oModel.getProperty(`/isValidation`) && this.getView().getModel("employee").getProperty(`/minSelect`) !== 0){
		oModel.setProperty(`/isValidation`, false);
	}
	if((oSelectedParams && oModel.getProperty(`/isValidation`) && oSelectedParams["minSelect"] == 1 && (!oTempEmployee.BAIndustries.length && !oTempEmployee.SolutionAreas.length)) || (oSelectedParams && oModel.getProperty(`/isValidation`) && oSelectedParams["minSelect"] == 2 && (!oTempEmployee.BAIndustries.length || !oTempEmployee.SolutionAreas.length))){
		oModel.setProperty(`/isValidation`, false);
	}
	this.getView().getModel("profileViewParameters").setProperty
	("/footerButtons/searchResourceButtonEnabled", oModel.getProperty(`/isValidation`));
},
/*Select event for Roles*/
onRoleChange: function (oEvent) {
const oSource = oEvent.getSource();
const oModel = this.getView().getModel("employee");
const oSelectectedItem = oSource.getSelectedItem();
const oTempEmployee = oModel.getProperty("/TempEmployee");
let tempRoleArea = [];
if (oSelectectedItem) {
const oContext = oSelectectedItem.getBindingContext("roleAreas");
const oRoleModel = oContext.getModel();
const oRole = oRoleModel.getProperty(oContext.getPath());
const oContextObj = oContext.getObject();
//set field config based on role area
this._setResValidation(oContextObj);
oTempEmployee.Roles.push(oRole)
tempRoleArea.push(...oRole.RoleAreas);
this.getView().getModel("employee").setProperty("/TempEmployee/TempRoles",oRole)
}else{
	this.getView().getModel("employee").setProperty(`/BAIndustryMandatory`,false);
	this.getView().getModel("employee").setProperty(`/BAIndustrySelectable`,true);
	this.getView().getModel("employee").setProperty(`/SolnAreaSelectable`,true);
	this.getView().getModel("employee").setProperty(`/fieldSelectionMidInfoIcon`,false);
	this.getView().getModel("employee").setProperty(`/minSelect`,0);
	this.getView().getModel("employee").setProperty(`/maxSelect`,2);
	this.getView().getModel("employee").setProperty(`/midSectionDesc`,this.getOwnerComponent().
	getModel("mrrAppConfigModel").getProperty("/SolnInd_SelectionText/0/fieldDesc"));
	this.getView().getModel("employee").setProperty(`/TempEmployee/TempRoles`,[]);
	this.getView().getModel("employee").setProperty(`/solnIndRequired`, false);
}
this.getView().getModel("employee").setProperty(`/TempEmployee/BAIndustries`, []);
this.getView().getModel("employee").setProperty(`/TempEmployee/SolutionAreas`, []);
this.getView().getModel("employee").setProperty(`/TempEmployee/TempBAIndustries`, []);
this.getView().getModel("employee").setProperty(`/TempEmployee/SolutionAreas`, []);
this.getView().getModel("employee").setProperty(`/solnAreaEnable`, true);
this.getView().getModel("employee").setProperty(`/industryEnable`, true);
let aNewRoleArea = [];
let map = new Map();
for (let item of tempRoleArea) { //Removing dupliated from aray..
if (!map.has(item.Guid)) {
	map.set(item.Guid, true);
	aNewRoleArea.push(item);
}
}
oModel.setProperty("/SelectedRoleAreasKey", "");
if (aNewRoleArea && aNewRoleArea.length === 1) {
oTempEmployee.RoleAreas.push(aNewRoleArea[0]);
oModel.setProperty("/SelectedRoleAreasKey", aNewRoleArea[0].ID);
}
oModel.setProperty("/aRoleAreas", aNewRoleArea);
oModel.refresh(true);
this.getView().getModel("employee").setProperty("/TempEmployee/TempRoleAreas",aNewRoleArea)
this._setSearchFieldText();
this._onEnableSearchResources();
},
/*Select event for Role area*/
onRoleAreaChange: function (oEvent) {
const oSource = oEvent.getSource();
const oModel = this.getView().getModel("employee");
const oSelectectedItem = oSource.getSelectedItem();
const oTempEmployee = oModel.getProperty("/TempEmployee");
let tempRoleArea = [];
if (oSelectectedItem) {
const oContext = oSelectectedItem.getBindingContext("employee");
const oRoleAreaModel = oContext.getModel();
const oRoleArea = oRoleAreaModel.getProperty(oContext.getPath());
oTempEmployee.RoleAreas.push(oRoleArea)
this.getView().getModel("employee").setProperty("/TempEmployee/TempRoleAreas",[oRoleArea])
}
oModel.refresh(true);
this._onEnableSearchResources();
},
/*Forward the Request to submit the updated context*/
onForwardRequest:function(sSelection){
const oProcessContext = this.getModel().getData();
const taskId = this.getComponentData().startupParameters.taskModel.getData().InstanceID;
this._triggerComplete(oProcessContext, taskId, "Forward",false,this.isResourceProfile,sSelection);	
},
/*Token updated delete Business Area Industry*/
onDeleteBAIndToken: function (oEvent) {
const oModel = this.getView().getModel("employee");
const oTempEmployee = oModel.getProperty("/TempEmployee");
const oParameters = oEvent.getParameters();
if (oParameters.type === "removed") {
const aTokens = oParameters.removedTokens;
for (let i = 0; i < aTokens.length; i++) {
	const iIndex = oTempEmployee.BAIndustries.findIndex(item => item.Guid === aTokens[i].getKey());
	if (iIndex !== -1) {
		oTempEmployee.BAIndustries.splice(iIndex, 1);
		oModel.refresh(true);
	}
}
}
let oSelectParams = {
	"bIndustry":true,
	"minSelect":oModel.getProperty(`/minSelect`),
	"maxSelect":oModel.getProperty(`/maxSelect`),
}
this._onManageIndSolSelection(oSelectParams,true)
this._onEnableSearchResources(oSelectParams);
},
/*Token updated delete Business Area LoB*/
onDeleteBALoBToken: function (oEvent) {
const oModel = this.getView().getModel("employee");
const oTempEmployee = oModel.getProperty("/TempEmployee");
const oParameters = oEvent.getParameters();
if (oParameters.type === "removed") {
const aTokens = oParameters.removedTokens;
for (let i = 0; i < aTokens.length; i++) {
	const iIndex = oTempEmployee.BALoBs.findIndex(item => item.Guid === aTokens[i].getKey());
	if (iIndex !== -1) {
		oTempEmployee.BALoBs.splice(iIndex, 1);
		oModel.refresh(true);
	}
}
}
this._onEnableSearchResources();
},
/*Token updated delete Cross Coverage*/
onDeleteCrossCvgBToken: function (oEvent) {
const oModel = this.getView().getModel("employee");
const oTempEmployee = oModel.getProperty("/TempEmployee");
const oParameters = oEvent.getParameters();
if (oParameters.type === "removed") {
const aTokens = oParameters.removedTokens;
for (let i = 0; i < aTokens.length; i++) {
	const iIndex = oTempEmployee.CrossCvg.findIndex(item => item.Guid === aTokens[i].getKey());
	if (iIndex !== -1) {
		oTempEmployee.CrossCvg.splice(iIndex, 1);
		oModel.refresh(true);
	}
}
}
},
/*Token updated delete Business Area Segment*/
onDeleteBASegToken: function (oEvent) {
const oModel = this.getView().getModel("employee");
const oTempEmployee = oModel.getProperty("/TempEmployee");
const oParameters = oEvent.getParameters();
if (oParameters.type === "removed") {
const aTokens = oParameters.removedTokens;
for (let i = 0; i < aTokens.length; i++) {
	const iIndex = oTempEmployee.BASegments.findIndex(item => item.Guid === aTokens[i].getKey());
	if (iIndex !== -1) {
		oTempEmployee.BASegments.splice(iIndex, 1);
		oModel.refresh(true);
	}
}
}
this._onEnableSearchResources();
},
/*Token updated delete Hub*/
onDeleteHubToken: function (oEvent) {
const oModel = this.getView().getModel("employee");
const oTempEmployee = oModel.getProperty("/TempEmployee");
const oParameters = oEvent.getParameters();
if (oParameters.type === "removed") {
const aTokens = oParameters.removedTokens;
for (let i = 0; i < aTokens.length; i++) {
	const iIndex = oTempEmployee.SelectedHubs.findIndex(item => item.HubGuid === aTokens[i].getKey());
	if (iIndex !== -1) {
		oTempEmployee.SelectedHubs.splice(iIndex, 1);
		oModel.refresh(true);
	}
}
}
},
/*Set ORE Service Url for search managers*/
_getOREServiceUrl: function (ApproversOREUrl, sProfitcenter, sSearchOre, isSubsFlag) {
	const sProfitCenterId = this.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories.length ? this.getView().getModel("selectedProfitCenter").getData().
		TempProfitCenter.Territories[0].TrpcId : this.getView().getModel("selectedProfitCenter").getData().
			filteredProfitCenter[0].TrpcId;

	const filterValues = {
		"ProfitCenterGUID": sProfitCenterId,
		"Manager_Level": "non-managerial",
		"aRoles":this.getView().getModel("employee").getProperty(`/TempEmployee/TempRoles`).RolesData,
		"aSubsRoles":this.getView().getModel("employee").getProperty(`/TempEmployee/TempRoles`).aSubstituteRoleRoleArea
	};
   const baIndustriesGuid = this.getView().getModel("employee").getData().TempEmployee.BAIndustries;
   const generateFilterConditions = (propertyName, values) => {
		return values.length ? `${values.map(guid => `${propertyName} eq '${guid}'`).join(' or ')}` : "";
	};
	//multiple profit center
	const aSelectedProfitCenter = JSON.parse(JSON.stringify(this.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories));
	for (let i = 0; i < aSelectedProfitCenter.length; i++) {
		if (!aSelectedProfitCenter[i].isCheckBox || !aSelectedProfitCenter[i].isResourceProfile) {
			aSelectedProfitCenter.splice(i, 1)
		}
	}
	const aFinalPfc = aSelectedProfitCenter.filter((obj1, i, arr) => 
		arr.findIndex(obj2 => (obj2.SelectedGuid === obj1.SelectedGuid)) === i
	  );
	const aRoleIds = isSubsFlag ? filterValues.aSubsRoles.map(item => item.RoleID) : filterValues.aRoles.map(item => item.RoleID);
	const aUniqueRoleIds = aRoleIds.filter((item, index) => aRoleIds.indexOf(item) === index);
	const filterConditionForRoles = aUniqueRoleIds.length ? `(${aUniqueRoleIds.map(roleId => `RoleId eq '${roleId}'`).join(' or ')})` :
		`(RoleId eq '')`;
	//filter condition for Role Areas
	const aRoleAreaIds = isSubsFlag ? filterValues.aSubsRoles.map(item => item.RoleAreaID) : filterValues.aRoles.map(item => item.RoleAreaID);
	const aUniqueRoleAreaIds = aRoleAreaIds.filter((item, index) => aRoleAreaIds.indexOf(item) === index);
	const filterConditionForRoleArea = aUniqueRoleAreaIds.length ? `(${aUniqueRoleAreaIds.map(roleAreaId => `RoleAreaId eq '${roleAreaId}'`).join(' or ')})` :
		`(RoleAreaId eq '')`;
	  let finalFilterString = `$filter=${filterConditionForRoles} and  ${filterConditionForRoleArea} and (MelodyRequest eq 'X')` + sSearchOre;
	if (aFinalPfc.length) {
		const multiple_pfc_GUIDs = aFinalPfc.map(item => item.TrpcId);
		const filterCondition10 = generateFilterConditions('Trtrypc', multiple_pfc_GUIDs);
		const filterCondition11 = generateFilterConditions('SecTrtrypc', multiple_pfc_GUIDs);
		finalFilterString += ` and (${filterCondition10} or ${filterCondition11})`;
	}
	if (baIndustriesGuid.length && this.getView().getModel("employee").getProperty(`/BAIndustrySelectable`)) {
		const baIndustries_GUIDs = baIndustriesGuid.map(item => item.BaIndId);
		const filterCondition1 = generateFilterConditions('BaIndId', baIndustries_GUIDs);
		const filterCondition6 = generateFilterConditions('SecBaIndId', baIndustries_GUIDs);
		finalFilterString += ` and (${filterCondition1} or ${filterCondition6})`;
	}
	//set Role payload
	const aFinaRole = isSubsFlag ? filterValues.aSubsRoles : filterValues.aRoles;
	this.getView().getModel("employee").setProperty("/aFinalRolePaylod", aFinaRole);
	const aSolAreas = this.getView().getModel("employee").getData().TempEmployee.SolutionAreas;
	let filterConditionSolAreas = "";
	if (aSolAreas.length && this.getView().getModel("employee").getProperty(`/SolnAreaSelectable`)) {
				const aSolAreas_GUIDs = aSolAreas ? aSolAreas.map(item => item.soln_id) : [];
				const parentSolIds = aSolAreas ? aSolAreas.map(item => item.prnt_soln_id) : [];
				let filterConditionSolAreas = "";
				let filterParts = [];
				
				aSolAreas_GUIDs.forEach((soln_id, index) => {
				  const relatedArea = aSolAreas[index];
					const parentSolId = parentSolIds[index]; 
				  if (relatedArea.soln_prnt_guid === "00000000-0000-0000-0000-000000000000") {
					filterParts.push(`(SolL1Id eq '${soln_id}') or (SecSolL1Id eq '${soln_id}')`);
				  } else {
					filterParts.push(`(SolL2Id eq '${soln_id}' or SecSolL2Id eq '${soln_id}') and (SolL1Id eq '${parentSolId}' or SecSolL1Id eq '${parentSolId}')`);
				  }
				});
				filterConditionSolAreas = filterParts.length
				? `(${filterParts.join(' or ')})` : ``;
				finalFilterString += ` and ${filterConditionSolAreas}`;
			}
			let aIACID = this.getView().getModel("IACRoleAreaModel").getData() ? this.getView().getModel("IACRoleAreaModel").getData()[0].IacId : "";
			if(this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/Operational_Status") && !this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/isIACQueryRemove")){
				finalFilterString += ` and (IacId eq '${aIACID}' or SecIacId eq '${aIACID}')`;
			}
			finalFilterString += "&$select=Id,EmpName,EmailId,ManagerLevel,ManagerId,ManagerName,ManagerEmail,to_substitute";
			return `${finalFilterString}&$expand=to_substitute`;
	
},
/*Trigger ORE or BS Service for search managers*/
onSearchResourceManagers: function () {
	let that = this;
	sap.ui.core.BusyIndicator.show();
	setTimeout(function() {
            const ApproversBaseUrl = that._getApproversBaseURL(that);
            const ApproversOREUrl = that._getOREApproversBaseURL(true);
 
            let sProfitcenter = that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories.length ? that.getView().getModel("selectedProfitCenter").getData().
                TempProfitCenter.Territories : that.getView().getModel("selectedProfitCenter").getData().
                filteredProfitCenter;
            const oResourceModel = new sap.ui.model.json.JSONModel();
            that.getView().setModel(oResourceModel, "resourceModel");
            that.getView().getModel("resourceModel").setData([]);
            const serviceUrlFS = that._getServiceUrl(ApproversBaseUrl, sProfitcenter, "0001");
            const serviceUrlBS = that._getServiceBSUrl(ApproversBaseUrl, sProfitcenter, "0002");
            const serviceUrlExactFS = that._getServiceBSUrl(ApproversBaseUrl, sProfitcenter, "0001")
            const sSearchOre = " and (ManagerLevel eq 'non-managerial')";
            
            let roleAreaSubs = that.getView().getModel("employee").getProperty(`/TempEmployee/TempRoles/subStituteRoleRoleArea`);
            const serviceUrlOREApp = that._getOREServiceUrl(ApproversOREUrl, sProfitcenter, sSearchOre);
            const serviceUrlORERes = that._getOREServiceUrl(ApproversOREUrl, sProfitcenter, "");
			const sPrimaryRoleArea = that.getView().getModel("employee").getProperty(`/TempEmployee/TempRoles/RoleAreaID`);
			const sPrimaryRoleId = that.getView().getModel("employee").getProperty(`/TempEmployee/TempRoles/ID`);
			  //multipleRoles
			  let aRolesData = that.getView().getModel("employee").getProperty("/TempEmployee/TempRoles/RolesData");
			  let aSubstRoleData = that.getView().getModel("employee").getProperty("/TempEmployee/TempRoles/aSubstituteRoleRoleArea");
			  let RoleSubstiTute;
			  //role data
			  const aRoleData = aRolesData.map(item => item.RoleID);
			  const aUniqueRoleIds = aRoleData.filter((item, index) => aRoleData.indexOf(item) === index);
			  const filterConditionForRoles = aUniqueRoleIds.length ? `(${aUniqueRoleIds.map(roleId => `RoleId eq '${roleId}'`).join(' or ')})` :
				  `(RoleId eq '')`;
			  const aRoleDataSubs = aSubstRoleData.map(item => item.RoleID);
			  const aUniqueRoleIdsSubs = aRoleDataSubs.filter((item, index) => aRoleDataSubs.indexOf(item) === index);
			  const filterConditionForRolesSubs = aUniqueRoleIdsSubs.length ? `(${aUniqueRoleIdsSubs.map(roleId => `RoleId eq '${roleId}'`).join(' or ')})` :
				  `(RoleId eq '')`;

			  if (filterConditionForRoles !== filterConditionForRolesSubs) {
				  RoleSubstiTute = true;
			  }
            let data;
            function fetchData(url) {
                return new Promise((resolve, reject) => {
                    $.ajax({
                        url: url,
                        dataType: 'json',
                        method: "GET",
                        success: function (data) {
                            resolve(data);
                        },
                        error: function (error) {
                            reject(error);
                        }
                    });
                });
            }
 
            function handleData(data, sVal) {
				 let approverArray = data.filter(obj => obj.UserTypeId === "0001");

                const appInfoUniqueArray = Array.from(
                    new Set(approverArray.map(obj => JSON.stringify({
                        email: obj.Email,
                        ID: obj.UserId,
                        fullName: obj.EmpFullName
                    })))
                ).map(JSON.parse);
				that.setResourcesModel(data, that, sVal,appInfoUniqueArray);
            }
            function handleOREData(oOREappData, sVal) {
				const uniqueManagers = oOREappData.reduce((acc, obj) => {
                    if (!acc.some(o => o.ID === obj.ManagerId)) {
                        acc.push({
                            email: obj.ManagerEmail,
                            ID: obj.ManagerId,
                            fullName: obj.ManagerName
                        });
                    }
                    return acc;
                }, []);
                that.setResourcesOREModel(oOREappData, that, sVal,uniqueManagers);
            }
            //MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
            //get IAC (Internal Account Classification) and Role,Role Area mapping #git84
            fetchData(`${ApproversBaseUrl}?${serviceUrlExactFS}`)
                .then((data) => {
                    if (data.d.results.length) {
						handleData.call(that, data.d.results, "0001");
                        return Promise.resolve();
                    }
                    throw new Error("No data found in first fetch");
                })
                .catch(() => {
                    return fetchData(`${ApproversOREUrl}?${serviceUrlOREApp}`)
                        .then((data) => {
                            if (data.d.results.length) {
								const oOREappData = data.d.results;
                                handleOREData.call(that, oOREappData, 20);
                                return Promise.resolve();
                            }
                            throw new Error("No data found in third fetch");
                        });
                })
				.catch(async () => {
					if (RoleSubstiTute) {
                            const serviceUrlSubsNotExactFS = that._getServiceBSUrl(ApproversBaseUrl, sProfitcenter, "0001",true);
                            const retryFSData = await fetchData(`${ApproversBaseUrl}?${serviceUrlSubsNotExactFS}`);
                            if (retryFSData.d.results.length) {
                                handleData.call(that, retryFSData.d.results, "0001");
                                return Promise.resolve();
                            }
                    }
                    throw new Error("No data found in retry fetch");
                })
                .catch(async () => {
					if (RoleSubstiTute) {
							const serviceUrlSubsORE = that._getOREServiceUrl(ApproversOREUrl, sProfitcenter, sSearchOre, true);
							const retryOREData = await fetchData(`${ApproversOREUrl}?${serviceUrlSubsORE}`);
							if (retryOREData.d.results.length) {
								const oRetryOREappData = retryOREData.d.results;
								handleOREData.call(that, oRetryOREappData, 20);
								return Promise.resolve();
							}

					}
                    throw new Error("No data found in retry ORE fetch");
                })
                .catch(() => {
                    return fetchData(`${ApproversBaseUrl}?${serviceUrlBS}`)
                        .then((data) => {
                            if (data) {
								handleData.call(that, data.d.results, "0002");
                                return Promise.resolve();
                            }
                            throw new Error("No data found in fallback fetch");
                        });
                })
                .catch((error) => {
                    that.errorMessageDailog(error);
                });
            //MR: [GRP02-03] GTM25 Resource Profile alignment #84 end
		},1000);
        },
		_getSubstituteDetails:function(data,isOre,isNamedContact){
			let aSubstArray = [];
			data.forEach(function (item) {
				if (item.to_substitute.results.length) {
					aSubstArray.push(...item.to_substitute.results);
				}
			});
			const now = new Date();
			const currentDate = now.toISOString().split('T')[0];
			const aSubstituteFinalApprover = [];
			aSubstArray.forEach(function(subs){
                subs.UserTypeId = "0001";
                if (!isNamedContact) {
                    if (isOre) {
                        subs.ManagerEmail = subs.SubstituteEmail;
                        subs.ManagerName = subs.SubstituteName;
                        subs.ManagerId = subs.SubstituteId;
                    } else {
                        subs.Email = subs.SubstituteEmail;
                        subs.EmpFullName = subs.SubstituteName;
                        subs.UserId = subs.SubstituteId;
                    }
                }
				let sFormattedStartDate = subs.ValidFrom.substring( subs.ValidFrom.indexOf('(')+1, subs.ValidFrom.lastIndexOf(')')),
					iFinalStartDate = Number(sFormattedStartDate.split("+")[0]),
					dateFrom = new Date(iFinalStartDate).toISOString().split('T')[0],
					sFormattedEndDate = subs.ValidTo.substring( subs.ValidFrom.indexOf('(')+1, subs.ValidFrom.lastIndexOf(')')),
					iFinalEndDate = Number(sFormattedEndDate.split("+")[0]),
					dateTo = new Date(iFinalEndDate).toISOString().split('T')[0];  
				if (currentDate >= dateFrom && currentDate <= dateTo && subs.Active) {
					//pull if today date between substitute date
					let oUserObj = {
						email: subs.SubstituteEmail,
						ID: subs.SubstituteId,
						fullName: subs.SubstituteName
					}
                    if(!isNamedContact){
                        aSubstituteFinalApprover.push(oUserObj);
                        data.push(subs);
                    }else if(!data.filter(approver => approver.ID === oUserObj.ID).length){
                        aSubstituteFinalApprover.push(oUserObj);
                    }
				}
			});		
			return aSubstituteFinalApprover;
		},	
/*Set Resource manager model*/
setResourcesModel: function (data, self, sVal,aApproversArray) {
	 let aSubstituteFinalApprover = this._getSubstituteDetails(data);
let approverArray = [];
	let value = data;
           for (let i = 0; i < value.length; i++) {
				let obj = value[i];
				switch (obj.UserTypeId) {
					case "0001":
						approverArray.push(obj);	
					default:
						break;
				}
			}
           const appinfo = approverArray.map(function (obj) {
				return {
					email: obj.Email,
					ID: obj.UserId,
					fullName: obj.EmpFullName
				};
			});

            const appInfojsonObject = appinfo.map(JSON.stringify);
            const appInfoUniqueSet = new Set(appInfojsonObject);
            const appInfoUniqueArray = Array.from(appInfoUniqueSet).map(JSON.parse);
            const sSearchType = sVal === "0002" ?   "resource": "FS";
            self.getView().getModel("resourceModel").getData().push({
				searchType:sSearchType,
				isResourceFound:false,
				sNotificationMsg:self._setNotificationMsg(sVal),
				iCount:appInfoUniqueArray.length,
				sSearchText:self.getView().getModel("employee").getProperty(`/searchFieldsText`),
				ApproverDetails:appInfoUniqueArray,
                aApprovers: aApproversArray
			});
	self.getView().getModel("resourceModel").refresh(true);
	self.isResourceProfile = true;
	const employeeData = self.getView().getModel("employee").getData().TempEmployee;
	
	//Set Payload for Resource profile details
	const ResourceProfileDetails = {
		Role_GUID: self.getView().getModel("employee").getProperty("/TempEmployee/TempRoles"),
		RoleArea_P_GUID: self.getView().getModel("employee").getProperty("/TempEmployee/TempRoleAreas")[0],
		BAIndustries: employeeData.BAIndustries,
		SolutionAreas:employeeData.SolutionAreas,
		SelectedRole:self.getView().getModel("employee").getProperty("/aFinalRolePaylod")
	};
	if(!self.getView().getModel("employee").getProperty(`/BAIndustrySelectable`)){
		//reset industry
		ResourceProfileDetails.BAIndustries = [];
	}

	if(!self.getView().getModel("employee").getProperty(`/SolnAreaSelectable`)){
		//reset solution area
		ResourceProfileDetails.SolutionAreas = [];
	}
	//MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
            //get IAC (Internal Account Classification) and Role,Role Area mapping #git84
			const oSelectRoleAreaID = self.getView().getModel("employee").getProperty("/TempEmployee/TempRoleAreas")[0].ID;
            const oSelectedIACRoleArea = self.getView().getModel("IACRoleAreaModel").getData().find(item => item.RoleAreaId === oSelectRoleAreaID);
			let uniqueSubs = Array.from(new Map(aSubstituteFinalApprover.map(aSubstituteFinalApprover => [aSubstituteFinalApprover.ID, aSubstituteFinalApprover])).values());
			uniqueSubs = uniqueSubs ? uniqueSubs.filter(item => !aApproversArray.some(aItem => aItem.ID === item.ID)) : [];
            const aResourceProfileApprovers = {
				aApprovers: aApproversArray,
                ApproverDetails: appInfoUniqueArray,
                ResourceProfileDetails: ResourceProfileDetails,
				 //update substitute array to the context
				SubstituteApproverDetails:uniqueSubs,
                IAC: [{
                    "IAC_Desc": oSelectedIACRoleArea.IacDesc,
                    "IAC_ID": oSelectedIACRoleArea.IacId,
                    "IAC_RoleMap_GUID": oSelectedIACRoleArea.IacMapGuid
                }]
            };
            //MR: [GRP02-03] GTM25 Resource Profile alignment #84 end

			self.aResourceProfileApprovers = aResourceProfileApprovers;
			self.aReqAreas = [];
			self.openResProfileDialog(self, sVal);

},
_setNotificationMsg: function (sVal) {
	const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
	let resourceMessDesc;
	if (sVal === "0001") {
		resourceMessDesc = i18nModel.getText("resMessDescFS");
	} else if (sVal === 20) {
		resourceMessDesc = i18nModel.getText("resMessDescORE");
	} else if (sVal === "0002") {
		resourceMessDesc = i18nModel.getText("resMessDescBS");
	}
	return resourceMessDesc;

},
/*Open Resource profile managers popover*/
openResProfileDialog: function (self, sVal,bShowResourceModel,isOpenCreateReqFragment) {
	const aResource = [];
	const aResourceData = this.getView().getModel("resourceModel").getData();
	const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
	const notifyDesc = i18nModel.getText("notificationMess");
	const savenNext = i18nModel.getText("saveAndNext");
	const backtext = i18nModel.getText("back");
	var that = this;
	let resourceMessDesc;
	const aResourceModelData = this.getView().getModel("resourceModel").getData();
	if (!isOpenCreateReqFragment) {
		this.selectedProfitCenter = this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories");
	  //  const applength = "(" + this.getView().getModel("resourceModel").getData().ApproverDetails.length + ")";
		if (sVal === "0001") {
			resourceMessDesc = i18nModel.getText("resMessDescFS");
		} else if (sVal === 20) {
			resourceMessDesc = i18nModel.getText("resMessDescORE");
		} else if (sVal === "0002") {
			resourceMessDesc = i18nModel.getText("resMessDescBS");
		}
		this.getView().getModel("employee").setProperty("/isResource", false);
		// appView.oFinalData.aReqAreas = [];
		let bApproverNotFound = aResourceData.some(function (resource) {
			return !resource.ApproverDetails.length
		});
		if (!bApproverNotFound) {
			aResourceData.forEach(function (resource) {
				if (resource.searchType === "resource") {
					that.getView().getModel("employee").setProperty("/isResource", "resourceAdmin");
				}
			});
		} else {
			aResourceData.forEach(function (resource) {
				if (!resource.ApproverDetails.length) {
					that.getView().getModel("employee").setProperty("/isResource", "notFound");
					aResource.push(resource);
					that.getView().getModel("employee").setProperty("/resourceContext", aResource);
				}
			});
		}
	}
	this.getView().getModel("employee").refresh();

	if(!isOpenCreateReqFragment && !this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories/0/isParentNodeEnable") && this.getView().getModel("employee").getProperty("/isResource") === "notFound"){
		this._onOpenApproverNotificationPopOver(true);
		sap.ui.core.BusyIndicator.hide();
	}else if (!isOpenCreateReqFragment && this.getView().getModel("employee").getProperty("/isResource") && !bShowResourceModel && this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories/0/isParentNodeEnable")) {
		this._onOpenApproverNotificationPopOver();
	}else{
		const fragment = new sap.ui.core.Fragment({
			fragmentName: "com.sap.bpm.PresalesRequestApproval.fragments.resourceProfileApprovers",
			type: "XML",
			controller: this
			});
			const contentVBox = new sap.m.VBox({
				items: [
					new sap.m.Text({ text: that.getView().getModel("resourceModel").getData()[0].sNotificationMsg }).addStyleClass("sapUiSmallMargin"),
					fragment
				]
			});
			const oCustomHeader = new sap.m.OverflowToolbar({
				content: [
					new sap.m.Title({
						text: notifyDesc
					}),
					new sap.m.ToolbarSpacer({

					}),
					new sap.m.Button({
						icon: "sap-icon://decline",
						press: function (evt) {
							that.popover.destroy();
						}
					})
				]
			});
			this.popover = new sap.m.ResponsivePopover({
			title: notifyDesc,
			contentWidth: "400px",
			modal:true,
			content: contentVBox,
			customHeader: oCustomHeader,
			placement: sap.m.PlacementType.Top,
			beginButton: new sap.m.Button({
				text:i18nModel.getText("CREATE_REQUEST"),
				type:"Emphasized",
				press: function () {
					that.onForwardRequest(true);
					that.popover.close();
				}
			}),
			endButton: new sap.m.Button({
				text: backtext,
				press: function () {
					that.popover.close();
				}
			}),
			afterClose: function () {
				that.popover.destroy();
			}
			});
			that.popover.addStyleClass("customPopover");
			this.getView().addDependent(that.popover);
			that.popover.openBy(this.byId("idOnSearchResourcesButton"));
	

	}

	sap.ui.core.BusyIndicator.hide();
},
_onOpenApproverNotificationPopOver: function (isHigherNodeNonSelectable){
	const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
	this.noSearchResult = false;
	this.bHigherNodeNotFound = false;
	const that = this;
	sap.ui.core.Fragment.load({
		name: "com.sap.bpm.PresalesRequestApproval.fragments.ApproverNotification",
		controller: this
	}).then(function (oFragment) {
		const contentVBox = new sap.m.VBox({
			items: [
				oFragment
			]
		});
		if (!isHigherNodeNonSelectable) {
			if (that.aNonSelectableParentNode) {
				 that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories.unshift(that.aNonSelectableParentNode)
			}
			
			//parent node => check lower node selection false and isChecBox is false or is legacy
			const oProfitCenterMasterData = that.getView().getModel("treeTerritories").getData().territories;
			this.nodeParentCheck = false;
			this.higherNodeProfitCenter = false;
			this.higherNodeItreation = false;
			this.bHigherNodeNotFound = false;
			let nodeParentCheck = function nodeUpdate(newValue, that,isItreation) {
				let oPFCMasterData = that.getView().getModel("treeTerritories").getData().territories;
				let aSelectedPFC =  isItreation ? that.higherNodeProfitCenter : that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories[0];
				let aNodeDes = aSelectedPFC.SelectedDesc.split(">");
				aNodeDes.pop();
				let sDescription = aNodeDes.join(">");
				if(!sDescription){
					that.higherNodeItreation = false;
					that.bHigherNodeNotFound = true;
				}
				else if(oPFCMasterData[0].displaydesc === sDescription.trim()){
					if (!oPFCMasterData[0].isChildNodeEnable && (!oPFCMasterData[0].isCheckBox || !oPFCMasterData[0].isResourceProfile)) {
						that.higherNodeItreation = false;
						that.bHigherNodeNotFound = true;

					}
				}else{
				for (const child of newValue.nodes) {
					if (sDescription.trim() == child.displaydesc && !child.isChildNodeEnable && (!child.isCheckBox || !child.isResourceProfile)) {
						child.IsSelected = true;
						that.nodeParentCheck = true;
						let oSelectedProfitCenter = Models._setProfitCenterObj(child);
						that.higherNodeProfitCenter = oSelectedProfitCenter;
						that.higherNodeItreation = true;

					} else if (sDescription.trim() == child.displaydesc) {
						that.higherNodeItreation = false;
					}
					if(!that.nodeParentCheck){
						nodeUpdate(child, that);
					}
					
				}
			}
				
			}
			nodeParentCheck(oProfitCenterMasterData[0], that);
			if(that.higherNodeItreation){
				nodeParentCheck(oProfitCenterMasterData[0], that,true);
			}

			if(!that.bHigherNodeNotFound){
				const aSelectedPFC = that.higherNodeProfitCenter ? that.higherNodeProfitCenter : that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories[0];
				const sDesc = aSelectedPFC.SelectedDesc;
				const aNodeDesc = sDesc.split(">");
				aNodeDesc.pop();
				const sParentNode = aNodeDesc.join(">");
				// let sNotificationMsg = `<p>${i18nModel.getText("approverNotification")} <strong>${sParentNode}</strong> ${i18nModel.getText("allSearch")}</p>`;
				let sNotificationMsg;
				if(that.getView().getModel("resourceModel").getData()[0].ApproverDetails.length){
					sNotificationMsg = `<p>${i18nModel.getText("approverNotification")} <strong>${sParentNode}</strong> ${i18nModel.getText("allSearch")}</p>`;
			   }else{
					sNotificationMsg = `<p>${i18nModel.getText("approverNotificationNoRes")} <strong>${sParentNode}</strong> ${i18nModel.getText("allSearch")}</p>`;
			   }
				let oFormattedText = new sap.m.FormattedText({
					htmlText: sNotificationMsg
				});
				oFragment.removeAllItems()
				oFragment.insertItem(oFormattedText);

			}else if(that.getView().getModel("employee").getProperty("/isResource") === "notFound"){
				that._onOpenApproverNotificationPopOver(true);
			}else{
				that.openResProfileDialog(false,false,false,true);
			}
		} else {
			let sResource = that.getView().getModel("employee").getProperty("/isResource")
			let aResourceContext = that.getView().getModel("employee").getProperty("/resourceContext");
			let aSearchMsg = [];
				aResourceContext.forEach(function (context) {
					aSearchMsg.push(
						`Search ${context.sSearchText}`
					);
				});
				//let sNotificationMsg = `${i18nModel.getText("processorNotFoundIn")} ${aSearchMsg.join(" , ")} ${i18nModel.getText("modifyOrDeleteMsg")}`;
				let sNotificationMsg = `<p>${i18nModel.getText("processorNotFoundIn")} <strong>${aSearchMsg.join(" , ")}</strong> ${i18nModel.getText("modifyOrDeleteMsForWard")}</p>`

				let oFormattedText = new sap.m.FormattedText({
					htmlText: sNotificationMsg
				});
				oFragment.removeAllItems()
				oFragment.insertItem(oFormattedText);
			}

		if(!this.bHigherNodeNotFound){
		const that = this;
		if(this.oNotificationPopover){
			this.oNotificationPopover.close();
		}
		this.oNotificationPopover = new sap.m.ResponsivePopover({
			title: "Notification(1)",
			contentWidth: "500px",
			verticalScrolling:false,
			modal: true,
			content: oFragment,
			placement: sap.m.PlacementType.Top,
			beginButton: new sap.m.Button({
				text: "Yes",
				visible:isHigherNodeNonSelectable ? false:true,
				press: function () {
				if(!that.noSearchResult){
					if(that.higherNodeProfitCenter){
						that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories = [that.higherNodeProfitCenter]
						that.getView().getModel("selectedProfitCenter").refresh(true);
					}
					if(that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.TempTreeTerritories){
						that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.TempTreeTerritories.length = 1;
					}
					if(that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories){
						that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories.length = 1;
					}
				
					that.loadTreeTerritories("treeTerritories",that.getView().getModel("territoriesMaster").getData(),true);
					that.setTerritoryHierarchySelection(false, false, false, true);
					let nodeUpdate = function nodeUpdate(newValue, that) {
						for (const child of newValue.nodes) {
							if (child.isCheckBox && child.isResourceProfile) {
								child.IsSelected = true;
								let oSelectedProfitCenter = Models._setProfitCenterObj(child);
								that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories.push(
									oSelectedProfitCenter);
								that.getView().getModel("selectedProfitCenter").refresh(true);
							}
							nodeUpdate(child, that);
						}
						that.getView().getModel("selectedProfitCenter").refresh(true);
						that.getView().getModel("treeTerritories").refresh(true);
					}
					that.oNotificationPopover.destroy();
					if (that.aSelectedParentNode) {
						let oSelectedPFCDesc = Models._setProfitCenterObj(that.aSelectedParentNode);
						that.getView().getModel("selectedProfitCenter").setProperty("/selectedPfc",oSelectedPFCDesc);
						if(that.aSelectedParentNode.isChildNodeEnable){
							nodeUpdate(that.aSelectedParentNode, that);
						}
						that.getView().getModel("selectedProfitCenter").refresh(true);
						that.getView().getModel("treeTerritories").refresh(true);
						that.onSearchResourceManagers(that);
						const aSelectedTerritories = that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories;
						for (let i = 0; i < aSelectedTerritories.length; i++) {
							if (!aSelectedTerritories[i].isCheckBox || !aSelectedTerritories[i].isResourceProfile) {
								that.aNonSelectableParentNode =aSelectedTerritories[0]; 
								aSelectedTerritories.splice(i, 1)
							}
						}
						that.getView().getModel("selectedProfitCenter").refresh();
					}
				else {
					let sResource = that.getView().getModel("employee").getProperty("/isResource");
					if (sResource !== "notFound") {
						let oFormattedText = new sap.m.FormattedText({
									htmlText: i18nModel.getText("noResourcesNotification")
								});
								that.noSearchResult = true;
								that.oNotificationPopover._getPopup().getContent().getContent()[0].removeAllItems();
								that.oNotificationPopover._getPopup().getContent().getContent()[0].insertItem(oFormattedText);
								that.oNotificationPopover.getBeginButton().setVisible(true);
							} else {
								let sNotificationMsg = `<p>${i18nModel.getText("processorNotFoundIn")} <strong>${aSearchMsg.join(" , ")}</strong> ${i18nModel.getText("modifyOrDeleteMsForWard")}</p>`
								let oFormattedText = new sap.m.FormattedText({
									htmlText: sNotificationMsg
								});
								that.oNotificationPopover._getPopup().getContent().getContent()[0].removeAllItems();
								that.oNotificationPopover._getPopup().getContent().getContent()[0].insertItem(oFormattedText);
								that.oNotificationPopover.getEndButton().setText("OK")
								that.oNotificationPopover.getBeginButton().setVisible(false);
							}

						}
					} else {
						that.oNotificationPopover.destroy();
					}
				}
			}),
			endButton: new sap.m.Button({
				text: isHigherNodeNonSelectable ? "OK":"No",
				press: function (oEvent) {
					if (oEvent.getSource().getText() !== "OK") {
						let sResource = that.getView().getModel("employee").getProperty("/isResource")
						let aResourceContext = that.getView().getModel("employee").getProperty("/resourceContext");
						let aSearchMsg = [];
					if (sResource === "notFound") {
						aResourceContext.forEach(function (context) {
							aSearchMsg.push(
								`${context.sSearchText}`
							);
						});
						//let sNotificationMsg = `${i18nModel.getText("processorNotFoundIn")} ${aSearchMsg.join(" , ")} ${i18nModel.getText("modifyOrDeleteMsg")}`;
						let sNotificationMsg = `<p>${i18nModel.getText("processorNotFoundIn")} <strong>${aSearchMsg.join(" , ")}</strong> ${i18nModel.getText("modifyOrDeleteMsForWard")}</p>`
		
						let oFormattedText = new sap.m.FormattedText({
							htmlText: sNotificationMsg
						});
						that.oNotificationPopover._getPopup().getContent().getContent()[0].removeAllItems();
						that.oNotificationPopover._getPopup().getContent().getContent()[0].insertItem(oFormattedText);
						that.oNotificationPopover.getEndButton().setText("OK")
						that.oNotificationPopover.getBeginButton().setVisible(false);
					} else {
						const sVal = that.getView().getModel("employee").getProperty("/approverId");
						that.openResProfileDialog(that, sVal,true);
						that.oNotificationPopover.destroy();
						}
						that.getView().getModel("employee").refresh()
					} else {
						that.isNotificationPopOverClose = true;
						that.oNotificationPopover.destroy();
					}
				}
				
			}),
			afterClose: function () {
				// that.oNotificationPopover.destroy();
			}
		});
		that.getView().addDependent(that.oNotificationPopover);
		this.oNotificationPopover.openBy(that.byId("idOnSearchResourcesButton"));
		sap.ui.core.BusyIndicator.hide();
	}
	}.bind(this));
	
},
/*Set ORE resource model*/
setResourcesOREModel: function (appdata, self, sVal,aApproversArray) {
	  let aSubstituteFinalApprover = this._getSubstituteDetails(appdata,true);
	let approverArray = [];
	let appValue = appdata;
	for (let i = 0; i < appValue.length; i++) {
		let obj = appValue[i];
		approverArray.push(obj.Id);
	}
	const appinfoORE = appValue.map(function (obj) {
		return {
			email: obj.ManagerEmail,
			ID: obj.ManagerId,
			fullName: obj.ManagerName
		};
	});
	const uniqueManagers = appinfoORE.filter((obj, index) => {
		return index === appinfoORE.findIndex(o => obj.ID === o.ID);
	});
	this.getView().getModel("resourceModel").getData().push({
		isResourceFound:true,
		searchType:"ore",
		sNotificationMsg:this._setNotificationMsg(sVal),
		iCount:uniqueManagers.length,
		sSearchText:this.getView().getModel("employee").getProperty(`/searchFieldsText`),   
		ApproverDetails:uniqueManagers,
        aApprovers:aApproversArray
	});
	this.getView().getModel("resourceModel").refresh(true);
	this.isResourceProfile = true;
	const employeeData = this.getView().getModel("employee").getData().TempEmployee;
	employeeData.SelectedHubs = employeeData.SelectedHubs.map(obj => {
		let newObj = {};

		Object.keys(obj).forEach(key => {
			newObj[key] = obj[key];
		});
		newObj.hubs = obj.HubDescL3 ? `${obj.HubDescL1} >${obj.HubDescL2} >${obj.HubDescL3}` : `${obj.HubDescL1} >${obj.HubDescL2}`;

		return newObj;
	});
	//Set Payload for Resource profile details
	const ResourceProfileDetails = {
		Role_GUID: this.getView().getModel("employee").getProperty("/TempEmployee/TempRoles"),
		RoleArea_P_GUID: this.getView().getModel("employee").getProperty("/TempEmployee/TempRoleAreas")[0],
		BAIndustries: employeeData.BAIndustries,
		SolutionAreas:employeeData.SolutionAreas,
		SelectedRole:this.getView().getModel("employee").getProperty("/aFinalRolePaylod")
	};
	if(!this.getView().getModel("employee").getProperty(`/BAIndustrySelectable`)){
		//reset industry
		ResourceProfileDetails.BAIndustries = [];
	}

	if(!this.getView().getModel("employee").getProperty(`/SolnAreaSelectable`)){
		//reset solution area
		ResourceProfileDetails.SolutionAreas = [];
	}

	//MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
            //get IAC (Internal Account Classification) and Role,Role Area mapping #git84
			const oSelectRoleAreaID = this.getView().getModel("employee").getProperty("/TempEmployee/TempRoleAreas")[0].ID;
            const oSelectedIACRoleArea = this.getView().getModel("IACRoleAreaModel").getData().find(item => item.RoleAreaId === oSelectRoleAreaID);
			let uniqueSubs = Array.from(new Map(aSubstituteFinalApprover.map(aSubstituteFinalApprover => [aSubstituteFinalApprover.ID, aSubstituteFinalApprover])).values());
			uniqueSubs = uniqueSubs ? uniqueSubs.filter(item => !aApproversArray.some(aItem => aItem.ID === item.ID)) : [];
            const aResourceProfileApprovers = {
				aApprovers:aApproversArray,
                ApproverDetails: uniqueManagers,
				  //update substitute array to the context
				SubstituteApproverDetails:uniqueSubs,
                ResourceProfileDetails: ResourceProfileDetails,
                IAC: [{
                    "IAC_Desc": oSelectedIACRoleArea.IacDesc,
                    "IAC_ID": oSelectedIACRoleArea.IacId,
                    "IAC_RoleMap_GUID": oSelectedIACRoleArea.IacMapGuid
                }]
            };
            //MR: [GRP02-03] GTM25 Resource Profile alignment #84 end

	this.aResourceProfileApprovers = aResourceProfileApprovers;
	this.aReqAreas = [];
	this.isResourceProfile = true;
	this.openResProfileDialog(this, sVal);
},
onPressEmpEmail: function (oEvent) {
const sUrl = oEvent.getSource().getProperty("text");
URLHelper.triggerEmail(sUrl, "Info Request - MRR", false, false, false, true);
},
_getApproversBaseURL: function (self) {
           return Models._getLSRuntimeBaseURL(self) + "/sap/opu/odata/sap/YROSTER_SRV;v=0002/YC_DS_T_RESOURCE_PROFILE";
        },
		_getOREApproversBaseURL: function (bForwardRes) {
			if (!bForwardRes) {
				return this._getRuntimeBaseURL() + "/int_ls/sap/opu/odata/sap/YROSTER_SRV;v=0002/YC_DS_T_NAMED_CONTACT";
			} else {
				return this._getRuntimeBaseURL() + "/int_ls/sap/opu/odata/sap/YROSTER_SRV;v=0002/YC_DS_T_PRSONPRO"
			}
		},
_getOREResourcesBaseURL: function () {
return this._getRuntimeBaseURL() + "/int_ls/sap/opu/odata/sap/YROSTER_SRV;v=0002/YC_DS_T_DIRECT_REPORTEES"
},
_getRuntimeBaseURL: function () {
const appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
const appPath = appId.replaceAll(".", "/");
const appModulePath = sap.ui.require.toUrl(appPath);
return appModulePath;
},
/*Set Error dialog*/
errorMessageDailog: function (error) {
let oErrorData =error ;
Models._setErrorMsgPopOver(this, "searchResourcesManager", oErrorData);
sap.ui.core.BusyIndicator.hide();

},
/*Close Forward Request Dialog*/
onCloseForwardReqDialog: function (evt) {
this._pForwardReqialog.then(function (oDialog) {
oDialog.close();
});
},
/*Cancel Forward Request*/
onCancelResForward: function () {
this.onCloseForwardReqDialog()
},
/*Open Resource profile manager popover*/
onClickResourceProfileDialog: function (oEvent) {
if (!this._resourceProfilePopover) {
this._resourceProfilePopover = sap.ui.xmlfragment("com.sap.bpm.PresalesRequestApproval.fragments.ResourceProfileSearchPopover", this);
this.getView().addDependent(this._resourceProfilePopover);
}
this.getResProfileDetails();
this._resourceProfilePopover.openBy(oEvent.getSource());
},
/*Set Resource profile Details PopOver*/
getResProfileDetails: function () {
	const aResProfile =this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails;
	let sSolutionAreaDesc;
	const descStringBAindustry = aResProfile.BAIndustries.map(function (obj) {
		return obj.Desc;
	}).join(',');
	if (aResProfile.SolutionAreas) {
		if (aResProfile.SolutionAreas.length) {
			 sSolutionAreaDesc = aResProfile.SolutionAreas.map(function (obj) {
				return obj.soln_name;
			}).join(',');
		}
	}else{
		sSolutionAreaDesc = "";
	}
	const descPC = this.getView().getModel().getData().selectedProfitCenter[0].SelectedDesc;
	let listItems = [];
	const sProfitCenterI18n = this.i18nModel.getText("profitCenter");
	const sSLAi18n = this.i18nModel.getText("solutionArea");
	const sRoleAreaI18n = this.i18nModel.getText("roleAreaPrimary");
	const sBAIi18n = this.i18nModel.getText("businessAreaIndustryPrimary");
	const sRoleI18n = this.i18nModel.getText("rolePrimary");
	const aSelectedPFC = this.getView().getModel().getData().selectedProfitCenter;
	const trpDesc = `${aSelectedPFC[0].desc}-${aSelectedPFC[0].TrpcId}`;
	let data = [
		{ Name: sProfitCenterI18n, Desc: descPC, trpDesc: trpDesc, queryParams: "TrpcDesc" },
		 { Name: sRoleAreaI18n, Desc: aResProfile.Role_GUID.RoleAreaDesc, trpDesc: "", queryParams: "RoleDesc" },
		 { Name: sBAIi18n, Desc: descStringBAindustry, trpDesc: "", queryParams: "BaIndDesc" },
		 { Name: sSLAi18n, Desc: sSolutionAreaDesc, trpDesc: "", queryParams: "SolAreaDesc"  }
	 ];
	 const that = this;
	 if(this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.SelectedRole){
		let sRoleDesc ;
                if (that.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RolesData.length > 1) {
                      sRoleDesc = that.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RolesData.map(function (obj) {
                        return obj.RoleDesc;
                    }).join(',');
                }else{
                    sRoleDesc = that.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.Desc;
                }
		 data = [
	   { Name: sProfitCenterI18n, Desc: descPC, trpDesc: trpDesc, queryParams: "TrpcDesc" },
		{ Name: sRoleAreaI18n, Desc: aResProfile.Role_GUID.RoleAreaDesc, trpDesc: "", queryParams: "RoleAreaDesc" },
		{ Name: sRoleI18n, Desc: sRoleDesc, trpDesc: "", queryParams: "RoleDesc" },
		{ Name: sBAIi18n, Desc: descStringBAindustry, trpDesc: "", queryParams: "BaIndDesc" },
		{ Name: sSLAi18n, Desc: sSolutionAreaDesc, trpDesc: "", queryParams: "SolAreaDesc"  }
	];
	}
	data.forEach(function (item) {
		if (item.Desc) {
			let listItem = {
				Name: item.Name,
				Desc: item.Desc,
				queryParams: item.queryParams
			};
			listItems.push(listItem);
		}
	});
	let oModelResPr = new sap.ui.model.json.JSONModel();
	oModelResPr.setData(
		listItems
	);

	this.getView().setModel(oModelResPr, "ResProfileModel");
},
/*Open Error Popover for Named Contacts*/
_onOpenErrorPopOverNamedContact:function(){
this._onOpenErrorPopOver("namedContact");

},
_onOpenErrorPopOver: function (sNamedContact) {
const that = this;
if (!this.pErrorPopOver) {
that.pErrorPopOver = that.loadFragment({
	name: "com.sap.bpm.PresalesRequestApproval.fragments.ErrorNotification"
});
}
that.pErrorPopOver.then(function (oDialog) {
if(sNamedContact === "namedContact"){
	oDialog.openBy(that.getView().byId("idNotificationNamedContactBadgedButton"));
}else{
	oDialog.openBy(that.getView().byId("idNotificationBadgedButton"));
}

});
},
/*Close Error Popover*/
_onClosePopOverList: function () {
this._onClosePopOver();
const oErrorModel = this.getView().getModel("errorMsgModel");
this.getView().byId("idNotificationBadgedButton").setVisible(false);
oErrorModel.setProperty("/errorInformation", [])
this.getView().byId("idNotificationBadgedButton").setVisible(false);
},
_onClosePopOver: function () {
const that = this;
if (this.pErrorPopOver) {
this.pErrorPopOver.then(function (oDialog) {
	oDialog.destroy();
	delete that.pErrorPopOver;
});
}
},

_getOREResourceServiceUrl: function (ApproversOREUrl) {
const oModel = this.getView().getModel();
const sProfitCenterId = oModel.getProperty("/selectedProfitCenter/0/TrpcId");

const filterValues = {
"ProfitCenterGUID": sProfitCenterId,
"Manager_Level": "non-managerial",
"Role_GUID": oModel.getProperty("/aResourceProfileApprovers/ResourceProfileDetails/Role_GUID/ID"),
"RoleArea_P_GUID": oModel.getProperty("/aResourceProfileApprovers/ResourceProfileDetails/RoleArea_P_GUID/ID")
};
const cross_CVRG_P_GUIDArray = oModel.getProperty("/aResourceProfileApprovers/ResourceProfileDetails/cross_CVRG_P_GUIDArray");
const crossBAGuid = oModel.getProperty("/aResourceProfileApprovers/ResourceProfileDetails/BASegments");
const baIndustriesGuid = oModel.getProperty("/aResourceProfileApprovers/ResourceProfileDetails/BAIndustries");
const baLobs = oModel.getProperty("/aResourceProfileApprovers/ResourceProfileDetails/BALoBs");
const hubs = oModel.getProperty("/aResourceProfileApprovers/ResourceProfileDetails/Hubs");
const sSearchOre = " and (ManagerLevel eq 'non-managerial')";
const generateFilterConditions = (propertyName, values) => {
return values.length ? `${values.map(guid => `${propertyName} eq '${guid}'`).join(' or ')}` : "";
};
let finalFilterString = `$filter=(Trtrypc eq '${filterValues.ProfitCenterGUID}' or SecTrtrypc eq '${filterValues.ProfitCenterGUID}') and (RoleId eq '${filterValues.Role_GUID}' or SecRoleId eq '${filterValues.Role_GUID}') and (RoleAreaId eq '${filterValues.RoleArea_P_GUID}' or SecRoleAreaId eq '${filterValues.RoleArea_P_GUID}')+${sSearchOre}`;
if (cross_CVRG_P_GUIDArray.length) {
const cross_CVRG_P_GUIDs = cross_CVRG_P_GUIDArray.map(item => item.ID);
const filterCondition3 = generateFilterConditions('CrossCvrgId', cross_CVRG_P_GUIDs);
const filterCondition8 = generateFilterConditions('SecCrossCvrgId', cross_CVRG_P_GUIDs);
finalFilterString += ` and (${filterCondition3} or ${filterCondition8})`;
}
if (crossBAGuid.length) {
const crossBAGuidGuids = crossBAGuid.map(item => item.ID);
const filterCondition4 = generateFilterConditions('BaSegId', crossBAGuidGuids);
const filterCondition9 = generateFilterConditions('SecBaSegId', crossBAGuidGuids);
finalFilterString += ` and (${filterCondition4} or ${filterCondition9})`;
}
if (baIndustriesGuid.length) {
const baIndustries_GUIDs = baIndustriesGuid.map(item => item.BaIndTechID);
const filterCondition1 = generateFilterConditions('BaIndId', baIndustries_GUIDs);
const filterCondition6 = generateFilterConditions('SecBaIndId', baIndustries_GUIDs);
finalFilterString += ` and (${filterCondition1} or ${filterCondition6})`;
}
if (baLobs.length) {
const baLobs_GUIDs = baLobs.map(item => item.ID);
const filterCondition2 = generateFilterConditions('BaLobId', baLobs_GUIDs);
const filterCondition7 = generateFilterConditions('SecBaLobId', baLobs_GUIDs);
finalFilterString += ` and (${filterCondition2} or ${filterCondition7})`;
}
if (hubs.length) {
let filterConditions = [];
let filterConditions21 =[];
let filterConditions31 = [];
let filterConditions41 = [];

for (let i = 0; i < hubs.length; i++) {
	const hubGuid = hubs[i].ID;
	if (hubs[i].Type === "INDUSTRY") {
		filterConditions21.push(generateFilterConditions('HubIndId', [hubGuid]));
		filterConditions21.push(generateFilterConditions('SecHubIndId', [hubGuid]));
	} else if (hubs[i].Type === "LOB") {
		filterConditions31.push(generateFilterConditions('HubLobId', [hubGuid]));
		filterConditions31.push(generateFilterConditions('SecHubLobId', [hubGuid]));
	} else if (hubs[i].Type === "ROLE") {
		filterConditions41.push(generateFilterConditions('HubRoleId', [hubGuid]));
		filterConditions41.push(generateFilterConditions('SecHubRoleId', [hubGuid]));
	}
}

filterConditions21 = filterConditions21.filter(condition => condition);
filterConditions31 = filterConditions31.filter(condition => condition);
filterConditions41 = filterConditions41.filter(condition => condition);
if (filterConditions21.length) {
	finalFilterString += ` and (${filterConditions21.join(' or ')})`;
}
if (filterConditions31.length) {
	finalFilterString += ` and (${filterConditions31.join(' or ')})`;
}
if (filterConditions41.length) {
	finalFilterString += ` and (${filterConditions41.join(' or ')})`;
}
}
//	finalFilterString += "&$select=Id,EmpName,EmailId,ManagerLevel";
return finalFilterString;
},
_callOREResourceService: function () {
	if (this.getView().getModel().getData().isResourceProfile && this.getView().getModel().getData().currentStepID ===
		"MANAPP") {
		const oRole = this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.Role_GUID;
		const oRoleArea = this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.RoleArea_P_GUID;
		const usersArray = this.getView().getModel().getData().aResourceProfileApprovers.ApproverDetails;
		const emailToFind = sap.ushell.Container.getService("UserInfo").getEmail();
		let userId;
		for (let i = 0; i < usersArray.length; i++) {
			if (usersArray[i].email === emailToFind) {
				userId = usersArray[i].ID;
			}
		}
		const workflowBaseurl = this._getOREResourcesBaseURL();
		let filterResources = `?$filter=ManagerId eq '${userId}' and MelodyRequest eq 'X'&$orderby=CapEmpNme asc`
		let sUrl = workflowBaseurl + filterResources;
		this.getResources(sUrl, this);

	}
	const oResourceModel = this.getView().getModel("resourceModel");
	if (this.getView().getModel().getData().isResourceProfile && this.getView().getModel().getData().currentStepID === "MANAPP") {
		oResourceModel.getData().availableResources = this.getView().getModel("resourcesOREModel").getData();
		oResourceModel.getData().resourceHeaderCount = this.getView().getModel("resourcesOREModel").getData().length;
		oResourceModel.getData().Skip_Resource_Approver = this.getView().getModel().getProperty("/Skip_Resource_Approver");
	}
	oResourceModel.refresh();
	const aResources = this.getView().getModel("resourceModel").getData().availableResources;
	const aSelectedNominees = this.oContextAssignmentObj.PreviousSelectedNominees;
	aResources.forEach(function (resource) {
		for (let i = 0; i < aSelectedNominees.length; i++) {
			if (resource.fullName === aSelectedNominees[i].fullName &&
				resource.email === aSelectedNominees[i].email) {
				resource.selected = true;
				return true;
			}
		}
	});
},
_onOpenOREResourceDialog: function (evt) {
	// this._callOREResourceService();
			 let that = this;
		if (!this.pORESelectDialog) {
			evt.getSource().setBusy(true);
			this.pORESelectDialog = this.loadFragment({
	name: "com.sap.bpm.PresalesRequestApproval.fragments.ResourcesPFC"
			});
			evt.getSource().setBusy(false);
		}
		const oModelData = this.getView().getModel("assignmentsModel").getData().assignments;
		let allNominees = oModelData.flatMap(obj => obj.selectedNominees);

		let uniqueNominees = Array.from(
			new Map(allNominees.map(item => [item.userId, item])).values()
		);
		this.oContextAssignmentObj.PreviousSelectedNominees = uniqueNominees;
		this.getView().getModel("assignmentsModel").refresh();

  that.pORESelectDialog.then(function (oORESelectDialog) {
	  that.aSelectionResArray = [];
			 
			oORESelectDialog.addStyleClass(that.getOwnerComponent().getContentDensityClass());
			that.getView().getModel("resourceModel").setProperty("/resourceHeaderCount",0);
			that.getView().getModel("resourceModel").setProperty("/availableResources",[]);
			that.getView().getModel("resourceModel").refresh()
			if(that.getView().getModel("CAModel")){
				that.getView().getModel("CAModel").setProperty("/customerHeaderCount",0);
			}
			oORESelectDialog.open();
	
			that._resetSearchField(); 
			if(that.getView().getModel("CAModel")){
				that.getView().getModel("CAModel").setData([]);
			}
			if(that.getView().getModel("resourcesCAModel")){
				that.getView().getModel("resourcesCAModel").setData([]);
			}
			 if(that.getView().getModel("searchResourcesCAModel")){
				that.getView().getModel("searchResourcesCAModel").setData([]);
			}
			if(this.getView().getModel("resourceModel")){
				this.getView().getModel("resourceModel").setData([]);
			}
			if(this.getView().getModel("resourcesOREModel")){
				this.getView().getModel("resourcesOREModel").setData([]);
			}
			 if(this.getView().getModel("searchResourcesOREModel")){
				this.getView().getModel("searchResourcesOREModel").setData([]);
			}
			that.getView().byId("idTabSegmentedButton").setSelectedKey("directReports");	
			that.onTabSelect();
			
	
		}.bind(this));
	},
_resetSearchField: function () {
this.getView().byId("idOreSearchField").setValue("");
this.getView().byId("idCustomerAdvisoryField").setValue("");
},

_attachTableEvents: function () {
const that = this;
const oTable = this.getView().byId("EmpDetailsTableID");
oTable.getBinding("rows").attachChange(function (oEvent) {
that._updateCount( "resourceModel", "/resourceHeaderCount", "/resourceCount");
});

const oCustomerTable = this.getView().byId("customerAdvisoryID");
oCustomerTable.getBinding("rows").attachChange(function (oEvent) {
that._updateCount("CAModel", "/customerHeaderCount", "/customerCount");
});
},

_updateCount: function (modelName, headerProp, countProp) {
const oModel = this.getView().getModel(modelName);
let iCount = 0;
let that = this;

if (modelName === "resourceModel") {
const usersArray = this.getView().getModel().getData().aResourceProfileApprovers.ApproverDetails;
const emailToFind = sap.ushell.Container.getService("UserInfo").getEmail();

const user = usersArray.find(user => user.email === emailToFind);
const userId = user ? user.ID : null;

if (userId) {
	const workflowBaseurl = this._getOREResourcesBaseURL();
	const sUrl = `${workflowBaseurl}/$count?$filter=ManagerId eq '${userId}' and MelodyRequest eq 'X'&$orderby=CapEmpNme asc`;

	iCount = this.getResourcesCount(sUrl, this); 
	that.getView().getModel("resourceModel").setProperty(headerProp, iCount, null, true);
that.getView().getModel("resourceModel").setProperty(countProp, iCount, null, true);
}
} else {
const ApproversOREUrl = this._getOREApproversBaseURL();
const OREFilterUrl = "/$count?$filter=(MelodyRequest eq 'X')&$orderby=CapEmpNme asc";
const serviceUrlORE = ApproversOREUrl + OREFilterUrl;

iCount = this.getResourcesCount(serviceUrlORE, this);
that.getView().getModel("CAModel").setProperty(headerProp, iCount, null, true);
that.getView().getModel("CAModel").setProperty(countProp, iCount, null, true);
}
},

getResourcesCount: function (url, self) {
let result = 0;
$.ajax({
url: url,
async: false, 
dataType: 'json',
method: "GET",
success: function (data) {
  
	result = data; 
},
error: function (error) {
	ErrorHandle.setErrorMessage(error, self);
}
});
return result; 
},

_updateAvailableResources: function (sSearchValue) {
    const oView = this.getView();
    const oAssignmentModel = oView.getModel("assignmentsModel");
    const oResourceModel = oView.getModel("resourceModel");
    const oUserModel = this.getOwnerComponent().getModel("userDetails");
    const oMainModel = oView.getModel();
const oResouceCAModelData = this.getView().getModel("resourcesCAModel") ? this.getView().getModel("resourcesCAModel").getData().filter(item => item.selected === true) : [];
    const oResouceOREModelData = this.getView().getModel("resourcesOREModel") ? this.getView().getModel("resourcesOREModel").getData().filter(item => item.selected === true) : [];
    let oSelectedCustomers = oResouceCAModelData;
      oSelectedCustomers = oSelectedCustomers.concat(oResouceOREModelData);
    
    const oAssignmentData = oAssignmentModel.getProperty("/assignments") || [];
    let oSelectedResources = oAssignmentData.flatMap(a => a.selectedNominees);
oSelectedResources = oSelectedResources.concat(oSelectedCustomers);
    const isResourceProfile = oMainModel.getProperty("/isResourceProfile");
    const currentStepID = oMainModel.getProperty("/currentStepID");
const workflowBaseurl = this._getOREResourcesBaseURL();
    if (isResourceProfile && currentStepID === "MANAPP") {
        const oProfileDetails = oMainModel.getProperty("/aResourceProfileApprovers/ResourceProfileDetails");
        const usersArray = oMainModel.getProperty("/aResourceProfileApprovers/ApproverDetails");
        const emailToFind = sap.ushell.Container.getService("UserInfo").getUser().getEmail();
let sUrl;
       let filterResources ;
        
        if (oProfileDetails && usersArray && emailToFind) {
            const user = usersArray.find(user => user.email === emailToFind);
            if (user) {
                
                if(sSearchValue){
                    filterResources = `&$filter=ManagerId eq '${user.ID}' and MelodyRequest eq 'X'&$orderby=CapEmpNme asc`
                     sUrl = workflowBaseurl + "?search=" + sSearchValue + filterResources;
                    this.getResources(sUrl, this , sSearchValue);
                }else{
                    filterResources = `?$filter=ManagerId eq '${user.ID}' and MelodyRequest eq 'X'&$orderby=CapEmpNme asc`
                    sUrl = workflowBaseurl + filterResources;
                    this.getResources(sUrl, this);
                }
            }
        }

       const oResourcesOREModel = sSearchValue ? oView.getModel("searchResourcesOREModel") : oView.getModel("resourcesOREModel");
        if (oResourcesOREModel) {
            const oResourcesData = oResourcesOREModel.getData();
            oResourceModel.setProperty("/availableResources", oResourcesData);
            oResourceModel.setProperty("/Skip_Resource_Approver", oMainModel.getProperty("/Skip_Resource_Approver"));
        }
    }

    oResourceModel.refresh();

    const aResources = oResourceModel.getProperty("/availableResources") || [];
    let aSelectedNominees = this.oContextAssignmentObj && this.oContextAssignmentObj.selectedNominees ? this.oContextAssignmentObj.selectedNominees  : [];
oSelectedResources = oSelectedResources.concat(aResources);
    aSelectedNominees = aSelectedNominees.concat(oSelectedResources);
    oResourceModel.refresh();
    oAssignmentModel.refresh();
     const oModelData = this.getView().getModel("assignmentsModel").getData().assignments;
            let allNominees = oModelData.flatMap(obj => obj.selectedNominees);

 
    // let oSelectedNominees = uniqueNominees.length ? uniqueNominees : this.oContextAssignmentObj.selectedNominees;
    let oSelectedNominees = aSelectedNominees.length ? aSelectedNominees.filter(item => item.selected === true) : [];
    // //skip resource
    if (this.getView().getModel().getProperty("/Skip_Resource_Approver") && aResources.length) {
        this._updateSkipResSelectBtn(aResources);
    }
   oSelectedNominees.forEach(prevNominee => {
    let found =  this.oContextAssignmentObj.PreviousSelectedNominees && this.oContextAssignmentObj.PreviousSelectedNominees.length ? this.oContextAssignmentObj.PreviousSelectedNominees.find(uniqueObj => uniqueObj.userId === prevNominee.userId):false;
    if (found) {
        found.enabled = false;
        found.btnEnabled = false;
    }
    if(this.oContextAssignmentObj.selectedNominees.filter(item=> item.userId === prevNominee.userId).length){
        found.enabled = true;
        found.btnEnabled = true;
    }
});
    let uniqueNominees = Array.from(
    new Map(oSelectedNominees.map(item => [item.userId, item])).values()
);
           if (uniqueNominees.length) {
    aResources.forEach(function (resource) {
        for (let i = 0; i < uniqueNominees.length; i++) {
            if (resource.fullName === uniqueNominees[i].fullName &&
                resource.email === uniqueNominees[i].email) {
                
                resource.selected = true;
                resource.enabled = uniqueNominees[i].enabled;
                resource.btnEnabled = uniqueNominees[i].btnEnabled;
                return; 
            }
        }
    });
}
let that = this;
if(that.aSelectionResArray.length && aResources.length){
    aResources.forEach(function (resource) {
        for (let i = 0; i < that.aSelectionResArray.length; i++) {
            if (resource.fullName === that.aSelectionResArray[i].fullName &&
                resource.email === that.aSelectionResArray[i].email) {
                resource.selected = that.aSelectionResArray[i].tempSelect;
            }
        }
    });
}
oResourceModel.refresh();
    
},
        _updateSkipResSelectBtn: function (aResources) {
            let that = this
            let aPrevSelect = [];
            this.oContextAssignmentObj.selectedNominees.forEach(function (seleRes) {
                if (seleRes) {
                    let prevEmpObj = that.oContextAssignmentObj.PreviousSelectedNominees.filter(item => item.userId !== seleRes.userId);
                    aPrevSelect = aPrevSelect.concat(prevEmpObj);
                    return;
                }
            });
            aResources.forEach(function (skipRes) {
                if (aPrevSelect.length && aPrevSelect.filter(item => item.userId === skipRes.userId).length) {
                    skipRes.enabled = false;
                    skipRes.btnEnabled = false;
                } else if (!aPrevSelect.length && that.oContextAssignmentObj.PreviousSelectedNominees.length
                    && that.oContextAssignmentObj.PreviousSelectedNominees.filter(item => item.userId === skipRes.userId).length) {
                    skipRes.enabled = false;
                    skipRes.btnEnabled = false;
                }else{
                    skipRes.enabled = true;
                    skipRes.btnEnabled = true;
                }
            });
        
        },
		_updateAvailableCustomers: function (sSearchValue) {
			const oView = this.getView();
			const oAssignmentData = oView.getModel("assignmentsModel").getData().assignments;
			const oSelectedNominees = oAssignmentData.flatMap(a => a.selectedNominees);
			const oResouceCAModelData = this.getView().getModel("resourcesCAModel") ? this.getView().getModel("resourcesCAModel").getData().filter(item => item.selected === true) : [];
			const oResouceOREModelData = this.getView().getModel("resourcesOREModel") ? this.getView().getModel("resourcesOREModel").getData().filter(item => item.selected === true) : [];
			let oSelectedCustomers = oSelectedNominees.concat(oResouceCAModelData);
			  oSelectedCustomers = oSelectedCustomers.concat(oResouceOREModelData);
			oSelectedCustomers = oSelectedCustomers.concat(oSelectedNominees);
			oSelectedCustomers = oSelectedCustomers.concat(this.oContextAssignmentObj.selectedNominees);
			const ApproversOREUrl = this._getOREApproversBaseURL();
			const serviceUrlORE = sSearchValue
				? `${ApproversOREUrl}?search=${sSearchValue}&$filter=(MelodyRequest eq 'X')&$orderby=CapEmpNme asc`
				: `${ApproversOREUrl}?$filter=(MelodyRequest eq 'X')&$orderby=CapEmpNme asc`;
			this.getCAResources(serviceUrlORE, this, sSearchValue);
			const oCAModel = oView.getModel("CAModel");
			const oResourcesCAModelData = sSearchValue ? oView.getModel("searchResourcesCAModel").getData() : oView.getModel("resourcesCAModel").getData();
			oCAModel.setProperty("/availableResources", oResourcesCAModelData);
		
			oCAModel.getData().resourceHeaderCount = oView.getModel("resourcesOREModel").getData().length;
			oCAModel.getData().Skip_Resource_Approver = oView.getModel().getProperty("/Skip_Resource_Approver");
		
			const oCustomerList = oCAModel.getProperty("/availableResources");
		 let aSelectedNominees = oSelectedCustomers.length ? oSelectedCustomers.filter(item => item.selected === true) : [];
		 if (this.getView().getModel().getProperty("/Skip_Resource_Approver") && oCustomerList.length) {
			this._updateSkipResSelectBtn(oCustomerList);
		}
		 let uniqueNominees = Array.from(
			new Map(aSelectedNominees.map(item => [item.userId, item])).values()
		);
		   uniqueNominees.forEach(prevNominee => {
			let found = this.oContextAssignmentObj.PreviousSelectedNominees.find(uniqueObj => uniqueObj.userId === prevNominee.userId);
			if (found) {
				found.enabled = false;
				found.btnEnabled = false;
			}
			if(this.oContextAssignmentObj.selectedNominees.filter(item=> item.userId === prevNominee.userId).length){
				prevNominee.enabled = true;
				prevNominee.btnEnabled = true;
			}
		});
			if (uniqueNominees.length) {
			oCustomerList.forEach(function (resource) {
				for (let i = 0; i < uniqueNominees.length; i++) {
					if (resource.fullName === uniqueNominees[i].fullName &&
						resource.email === uniqueNominees[i].email) {
						
						resource.selected = true;
						resource.enabled = uniqueNominees[i].enabled;
						resource.btnEnabled = uniqueNominees[i].btnEnabled;
						return; 
					}
				}
			});
		}
		let that = this;
		if(that.aSelectionResArray.length && oCustomerList.length){
			oCustomerList.forEach(function (resource) {
				for (let i = 0; i < that.aSelectionResArray.length; i++) {
					if (resource.fullName === that.aSelectionResArray[i].fullName &&
						resource.email === that.aSelectionResArray[i].email) {
						resource.selected = that.aSelectionResArray[i].tempSelect;
					}
				}
			});
		}
			oCAModel.refresh();
		},

onTabSelect: function (oEvent) {
    sap.ui.core.BusyIndicator.show();
    const sSelectedKey = this.getView().byId("idTabSegmentedButton").getSelectedKey();
    
    let that = this;
    const oView = this.getView();
    this._resetSearchField();
    const toggleVisibility = (showDirectReports) => {
        oView.byId("idDirectReportsBox").setVisible(showDirectReports);
        oView.byId("idCustomerAdvisoryBox").setVisible(!showDirectReports);
    };

    const resetModel = (modelName, currentPageProp, updateFn, headerCountProp, countProp , that) => {
        const oModel = oView.getModel(modelName);
        if (oModel.getProperty(currentPageProp)) {
            oModel.setProperty(currentPageProp, 0);
        }
        updateFn.call(that);
        that._updateCount(modelName, headerCountProp, countProp);
        oModel.refresh(true);
    };

    switch (sSelectedKey) {
        case "directReports":
             sap.ui.core.BusyIndicator.show();
            setTimeout(function() {
						   
            toggleVisibility(true);
            resetModel("resourceModel", "/currentPage", that._updateAvailableResources, "/resourceHeaderCount", "/resourceCount", that);
               
                  sap.ui.core.BusyIndicator.hide();
             },1000);
            break;

        case "customerAdvisory":
             sap.ui.core.BusyIndicator.show();
            setTimeout(function() {
			 toggleVisibility(false);
            
            resetModel("CAModel", "/currentCAPage", that._updateAvailableCustomers, "/customerHeaderCount", "/customerCount" , that);
               
                sap.ui.core.BusyIndicator.hide();
                },1000);
            
            
            break;

        default:
            break;
    }

    oView.getModel("resourceModel").refresh(true);
    oView.getModel("CAModel").refresh(true);
},

onSelectOREResources: function (evt) {
	sap.ui.core.BusyIndicator.show();

    const sModelName = this.getView().byId("idTabSegmentedButton").getSelectedKey() === "directReports"
        ? "resourceModel"
        : "CAModel";
 const aModelName = this.getView().byId("idTabSegmentedButton").getSelectedKey() === "directReports"
        ? "resourcesOREModel"
        : "resourcesCAModel";
    let oResourceModelData = this.getView().getModel("resourceModel").getProperty("/availableResources");
    let oResourceCAModelData = this.getView().getModel("CAModel") && this.getView().getModel("CAModel").getData().length ? this.getView().getModel("CAModel").getProperty("/availableResources") : [];
    let aResourcesOREModel = this.getView().getModel("resourcesOREModel") ? this.getView().getModel("resourcesOREModel").getData() : [];
    let aResourcesCAOREModel = this.getView().getModel("resourcesCAModel") && this.getView().getModel("resourcesCAModel").getData().length ? this.getView().getModel("resourcesCAModel").getData() : [];
    let aSearchResourceModel = this.getView().getModel("searchResourcesOREModel") && this.getView().getModel("searchResourcesOREModel").getData().length ? this.getView().getModel("searchResourcesOREModel").getData() : [];
    let aSearchCAModel = this.getView().getModel("searchResourcesCAModel") && this.getView().getModel("searchResourcesCAModel").getData().length ? this.getView().getModel("searchResourcesCAModel").getData() : [];
    let that = this;
     let aDeletedResources = [];
    if (this.oContextAssignmentObj.selectedNominees.length && this.aSelectionResArray.length) {
        aDeletedResources = [];
        for(let i=0;i<that.oContextAssignmentObj.selectedNominees.length;i++){
            // Filter the array of selected resources (aSelectionResArray) to find any user that matches the userId 
            // of the current nominee being processed (oContextAssignmentObj.selectedNominees[i]).
            // The result is stored in the variable bUser.
            let bUser = that.aSelectionResArray.filter(item => that.oContextAssignmentObj.selectedNominees[i].userId === item.userId);
                if (bUser.length && !bUser[0].tempSelect) {
                    aDeletedResources.push(that.oContextAssignmentObj.selectedNominees.filter(item=> item.userId === bUser[0].userId)[0])
                }
        }
        const aDeletedArray = new Set(aDeletedResources.map((el) => el.userId));
        // This ensures that each user ID is only stored once, eliminating duplicates.
        that.oContextAssignmentObj.selectedNominees = that.oContextAssignmentObj.selectedNominees.filter((el) => !aDeletedArray.has(el.userId));
    }
    this.getView().getModel("assignmentsModel").refresh();
var combinedResources = this.oContextAssignmentObj.selectedNominees.concat(oResourceModelData);
combinedResources = combinedResources.concat(aResourcesOREModel);
    combinedResources = combinedResources.concat(oResourceCAModelData);
    combinedResources = combinedResources.concat(aResourcesCAOREModel);
    combinedResources = combinedResources.concat(aSearchResourceModel);
    combinedResources = combinedResources.concat(aSearchCAModel);

    if(aDeletedResources.length && combinedResources.length){   
        combinedResources.forEach(function(cmbRes){
            if(aDeletedResources.filter(item=> item.userId === cmbRes.userId).length){
                cmbRes.selected = false;
            }
        });
    }

   let aFinalCombinedResources = combinedResources.filter(user => user.selected === true && user.enabled === true);
    let uniqueUsers = aFinalCombinedResources.filter(
    (resource, index, self) =>
        index === self.findIndex((r) => r.userId === resource.userId)
);
let aAssignments =  this.getView().getModel("assignmentsModel").getData().assignments,
aAssignmentsNomArray = [];
aAssignments.forEach(item=>item.selectedNominees.length ? aAssignmentsNomArray.push(true):false);
let aToken = aAssignmentsNomArray.length > 1 && this.oContextAssignmentObj.PreviousSelectedNominees && this.oContextAssignmentObj.PreviousSelectedNominees.length ? uniqueUsers.filter(element => this.oContextAssignmentObj.PreviousSelectedNominees.some(item => item.userId != element.userId)) : uniqueUsers;
    aToken.forEach(item => item.tempSelect = true);
	setTimeout(function() {
        that._onSelectResources(aToken);
       
    },1000);
    this.onCloseOREResource();
},
onCloseOREResource: function (oEvent) {
	if(oEvent && !this.getView().getModel().getProperty("/Skip_Resource_Approver")) {
		this.oContextAssignmentObj.selectedNominees = this.oContextAssignmentObj.selectedNominees ? this.oContextAssignmentObj.selectedNominees.filter(item => item.tempSelection === false) : [];
	}
	this.getView().getModel("assignmentsModel").refresh();
	if (this.pORESelectDialog) {
		this.pORESelectDialog.then(function (oDialog) {
			oDialog.close();
		});
	}
},
onORESearchResources: function (oEvent, isLiveSearch) {
	const isDirectReports = this.getView().byId("idTabSegmentedButton").getSelectedKey() === "directReports";
	const sModelName = isDirectReports ? "resourceModel" : "CAModel";
	const aModelName = isDirectReports ? "resourcesOREModel" : "resourcesCAModel";
	this.getView().byId("customerAdvisoryID").setBusy(true);

	const sSearchValue = isLiveSearch 
		? oEvent.getParameter("newValue") 
		: oEvent.getParameter("query");

	const oModel = this.getView().getModel(sModelName);
	oModel.setProperty(isDirectReports ? "/currentPage" : "/currentCAPage", 1);

	
		const oResourcesOREModel = this.getView().getModel(aModelName);
		const oResourceModel = this.getView().getModel(sModelName);
		const availableResources = oResourceModel.getProperty("/availableResources") || [];

		let aUpdatedData = oResourcesOREModel.getData() || [];

		aUpdatedData.forEach(updatedItem => {
			const matchedResource = availableResources.find(resource => 
				resource.userId === updatedItem.userId && resource.selected
			);
			if (matchedResource) updatedItem.selected = true;
		});

		availableResources.forEach(resource => {
			if (!aUpdatedData.some(item => item.userId === resource.userId)) {
				aUpdatedData.push(resource);
			}
		});

		aUpdatedData = [...new Map(aUpdatedData.map(item => [item.userId, item])).values()];

		aUpdatedData.sort((a, b) => (b.selected === true) - (a.selected === true));

		oResourcesOREModel.setData(aUpdatedData);

		if (oResourcesOREModel) {
			oResourceModel.setProperty("/availableResources", aUpdatedData);
			oResourceModel.setProperty(
				"/Skip_Resource_Approver",
				this.getView().getModel().getProperty("/Skip_Resource_Approver")
			);
		}

		oResourceModel.refresh();
	if(sSearchValue) {
		isDirectReports
			? this._updateAvailableResources(sSearchValue)
			: this._updateAvailableCustomers(sSearchValue);
	}
	 this.getView().byId("customerAdvisoryID").setBusy(false);
},

_onSelectResources:function(aToken){
const bSkipResources = this.getView().getModel().getProperty("/Skip_Resource_Approver");
const oAssignmentsModel = this.getView().getModel("assignmentsModel");

this.oContextAssignmentObj.selectedNominees = aToken;
  //call ORE service to fetch role,roleArea, manager level etc
  for(let i=0; i<aToken.length;i++){
	const sResourceId = aToken[i].userId;
	const workflowBaseurl = this._getOREReporteesBaseURL();
	const that = this;
	const sUrl = workflowBaseurl + `?$filter=ManagerId eq '${sResourceId}' and ManagerLevel eq 'non-managerial' and MelodyRequest eq 'X' and ( not(RoleId eq '0001') or not(RoleId eq '0016') )&$select=ResourceId,ManagerLevel,RoleId,RoleAreaId,BaLobDesc,CrossCvrgDesc,BaIndDesc,BaId&$orderby=CapEmpNme asc`;

	$.ajax({
		url: sUrl,
		dataType: 'json',
		async: false,
		method: "GET",
		success: function (data) {
			const oData = data.d.results,
				  aResourceData = oData.filter((resource) => resource.ResourceId === aToken[i].userId),
				  sRoleId = aResourceData.length ? aResourceData[0].RoleId :"",
				  sRoleAreaId = aResourceData.length ? aResourceData[0].RoleAreaId :"",
				  sManagerLevel = aResourceData.length ?aResourceData[0].ManagerLevel:"";
				  let sBAId = false;
                        if (aResourceData.length) {
                            sBAId = aResourceData[0].BaId ? aResourceData[0].BaId : false;
                        };
				let sFilterUrl = `$filter=(role_ID eq '${sRoleId}' and role_Area_ID eq '${sRoleAreaId}' and manager_level eq '${sManagerLevel}' and (BA_ID eq '${sBAId}' or BA_ID eq '*'))&$orderby=BA_ID desc&$top=1`;
				let sFinalUrl = that._getRuntimeBaseURL() + `/resources/req-area-api-/Presales_role?${sFilterUrl}`;
				 if(aResourceData.length){
					aToken[i].oREData = false;
					$.ajax({
						contentType: "application/json",
						url: sFinalUrl,
						async: false,
						type: "GET",
						success: function (response) {
							if(response.value.length){
								aToken[i].oREData = true;
								aToken[i].assignedRoleData = {
									name: response.value[0].CRM_Role_Desc,
									id: response.value[0].CRM_Role_ID
								}
							}else{
								aToken[i].oREData = false;
							}
						},
						error: function (oError) {
							ErrorHandle.setErrorMessage(oError, that);
						}
					});
				 }else{
					aToken[i].oREData = false;
				 }
		},
		error: function (error) {
			ErrorHandle.setErrorMessage(error, that);
		}
	});  
}
const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
const aNotOREData = aToken.filter((res) => !res.oREData);
if(aNotOREData.length){
	//Resource not maintained in ORE - resource should not add trigger validation
	this.sSelectedRes = "";
	let aValidatedRes = [];
	let that = this;
	aToken.forEach(function(nom){
		if(!nom.oREData){
			let sUserName = nom.fullName;
			let sUserId = nom.userId ?  nom.userId:"";
			let sUser = `- ${sUserName} (${sUserId})`;
			that.sSelectedRes = that.sSelectedRes + "\n" +sUser
		}else{
			aValidatedRes.push(nom);
		}
	});
	const sOreResourceValidationStartMsg = i18nModel.getText("oreResourceValidationStart");
	MessageBox.warning(`${sOreResourceValidationStartMsg} \n${this.sSelectedRes}`);
	this.oContextAssignmentObj.selectedNominees = aValidatedRes;
}else{
	this.oContextAssignmentObj.selectedNominees = aToken;
} 
if (this.getView().getModel().getProperty("/RequestType") === "Opportunity") {
	const orgType =  this.getModel().getProperty("/OrgType");
	const sOrgID =(orgType !== "PC") ? this.getModel().getProperty("/OrgID"):this.getModel().getProperty("/oppOrgId");
	const sFinalOrgID = this.getModel().getProperty("/oppOrgId") ?  this.getModel().getProperty("/oppOrgId"):this.getModel().getProperty("/OrgID");
const sSalesOrg = sFinalOrgID.replace('SORG-', '');
const that = this;
aToken.forEach(function (token, iIndex) {
	let sUserId = token.userId.toUpperCase();
	if (that.oContextAssignmentObj.isIOStaffing) {
		Models._CallautoStaffingAPI(sUserId, 100, 0, that, sSalesOrg, token);
		//	token.isAutoStaffing = false;
		if (!token.isAutoStaffing) {
			 //Change Request to IO Staffing Working for EMEA #93 start
			 //check company code eq to sales org for the resource and auto staffing
			let bSkipIOFlag = that.getView().getModel("WFRoutingSkipIOAPIData").getProperty("/value/0/operationalStatus");
			if (token.sCompanyCode === sSalesOrg || !bSkipIOFlag) {
				that.oContextAssignmentObj.isStaffingFields = true;
				token.isAutoStaffingCompanyCode = token.sCompanyCode === sSalesOrg ? true : false;
				token.isStaffing = true;
				that.oContextAssignmentObj.staffingPurposeVisible = true;
				that.oContextAssignmentObj.expectedTimeInvstementVisible = false;
				that.oContextAssignmentObj.ioOwnerFieldVisible  = that.oContextAssignmentObj.isOppOwnerActive;
				that.oContextAssignmentObj.ioOwnerTextFieldVisible  = true;
				that.oContextAssignmentObj.staffingDateRangeVisible = true;
				that.oContextAssignmentObj.maxNoOfDaysToBookIOVisible = true;
				that.oContextAssignmentObj.taskLevelVisible = true;
			}else if(!bSkipResources){
				//company code not eq to sales org --> hide staffing fields --> no IO trigger for staffing
				token.isAutoStaffingCompanyCode = false;
				token.isStaffing = false;
				Models._callExceptionTable(token.sCompanyCode, token.sCostCenter, sSalesOrg, sUserId, that, that.fnExceptionCallback, that.fnExceptionErrorCallback, token);
			}
			  //Change Request to IO Staffing Working for EMEA #93 end
			if (bSkipResources) {
				//skip resources ---> Presales Manager Approval task to completes the wf
				if (token.sCompanyCode === sSalesOrg) {
					//company code of the resources matches sales org of the opportunity
					token.isAutoStaffingCompanyCode = true;
					//Call userSearchHelps to fetch the perner number for staffing
					Models._callUserSearchHelps(token.userId, that, that.fnSuccessUserSearchHelpsCallBack, that.fnErrorUserSearchHelpsCallBack, token);
				} else {
					//check exception table maintained
					token.isAutoStaffingCompanyCode = false;
					Models._callExceptionTable(token.sCompanyCode, token.sCostCenter, sSalesOrg, sUserId, that, that.fnExceptionSuccessCallback, that.fnExceptionErrorCallback, token);
				}

			}
		}else{
			that.oContextAssignmentObj.expectedTimeInvstementVisible = true;
		}
	}

});
}
this.getView().getModel("assignmentsModel").refresh();
this._fnResourceValidation(this.oContextAssignmentObj.selectedNominees, this.oContextAssignmentObj);
oAssignmentsModel.refresh(true);  
sap.ui.core.BusyIndicator.hide();

},
_setStaffingMsg:function(aSelectedResource,oAssignments){
	let bSkipIOFlag = this.getView().getModel("WFRoutingSkipIOAPIData").getProperty("/value/0/operationalStatus");
	const bSkipResources = this.getView().getModel().getProperty("/Skip_Resource_Approver"),
		  aFilteredResources = aSelectedResource.filter(res => !res.isStaffing);
	if (aFilteredResources.length && bSkipIOFlag) {
		const aSelectedNom = aFilteredResources.map(nom => nom.fullName),
			sNomNames = aSelectedNom.toString(),
			sI18nStartMsg = this.i18nModel.getText("staffingMsgStart"),
			sI18nEndMsg = this.i18nModel.getText("staffingMsgEnd");
		// oAssignments.staffingMsg = bSkipResources ? `${sI18nStartMsg} (${sNomNames}) ${sI18nEndMsg}` : `${sI18nStartMsg}(s)(${sNomNames}) ${sI18nEndMsg}`;
		if(this.getOwnerComponent().getModel("appConstants").getProperty("/ManualStaffing/0/Operational_Status")){
			oAssignments.staffingMsgVisible = true;
		}
	   
	}else{
		 oAssignments.staffingMsgVisible = false;
	}
	 this.getView().getModel("assignmentsModel").refresh();
},
_getOREReporteesBaseURL: function () {
	return this._getRuntimeBaseURL() + "/int_ls/sap/opu/odata/sap/YROSTER_SRV;v=0002/YC_DS_T_DIRECT_REPORTEES"
},
onSelectSkipResource: function (evt) {
	sap.ui.core.BusyIndicator.show();
    let that = this;

	const sSelectedKey = this.getView().byId("idTabSegmentedButton").getSelectedKey();
	const oSource = evt.getSource();
	let aToken = [];

	if (sSelectedKey === "directReports" || sSelectedKey === "customerAdvisory") {
		const sModelName = sSelectedKey === "directReports" ? "resourceModel" : "CAModel";
		aToken = [oSource.getBindingContext(sModelName).getObject()];
	}
	this.oContextAssignmentObj.PreviousSelectedNominees = aToken;
	setTimeout(function() {
		that._onSelectResources(aToken);
	   
	},1000);
	this.onCloseOREResource();
},
		/* MR: [GRP02-03] GTM25 Resource Profile alignment #84 start */
		// This function handles the selection of the solution area (Level 1)
		fnHandleLevel1Change: function(oEvent) {
			const oSelectedSLA1Context = oEvent.getParameter("selectedItem").getBindingContext("SLAMasterDataL1").getObject();
			// Set the busy state for the master data levels model
			this.getOwnerComponent().getModel("SLAMasterDataLevels").setProperty("/isGridLayBusy", true);
			// Clear the selected solution areas
			this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas", []);
			this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA", false);
			this.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
			// Fetch the SLA levels based on the selected context
			Models._getSLALevels(this, oSelectedSLA1Context);
		},
		// This function handles the change event for solution areas
		onChangeSolutionAreas: function(evt) {
			const aSelectedSLA = this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aTokenSelectedSolutionAreas");
			// Update the temporary employee model with selected solution areas
			this.getView().getModel("employee").setProperty(`/TempEmployee/SolutionAreas`, aSelectedSLA);
			let oSelectParams = {
				"bIndustry":false,
				"minSelect":this.getView().getModel("employee").getProperty(`/minSelect`),
				"maxSelect":this.getView().getModel("employee").getProperty(`/maxSelect`),
			};
			this._onManageIndSolSelection(oSelectParams);
			this._setSearchFieldText();
			this._onEnableSearchResources(oSelectParams);
			this.oSLASearchContext = false;
			// Close the SLA value help dialog
			this.pSLAValueHelpDialog.then(function(oDialog) {
				oDialog.close();
			});
		},
		// This function handles the deletion of SLA tokens
		onDeleteSLAToken: function(oEvent) {
			const oModel = this.getView().getModel("employee");
			// Clear the temporary employee model for solution areas
			oModel.setProperty(`/TempEmployee/SolutionAreas`, "");
			let oSelectParams = {
				"bIndustry":false,
				"minSelect":oModel.getProperty(`/minSelect`),
				"maxSelect":oModel.getProperty(`/maxSelect`),
			}
			this._onManageIndSolSelection(oSelectParams,true);
			this._setSearchFieldText();
			this._onEnableSearchResources(oSelectParams);
		},
		
		// This function deletes the solution area master data selection
		fnDeleteSolMatTokens: function(oEvent) {
			const oContext = oEvent.getParameter("removedTokens")[0].getBindingContext("SLAMasterDataL1").getObject();
			// Clear the selected solution areas
			if (!this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aSelectedSolutionAreas").length) {
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA", false);
			} else {
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA", true);
			}
			this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas", "");
			this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aTokenSelectedSolutionAreas", "");
			this.getOwnerComponent().getModel("SLAMasterDataLevels").refresh();
			this.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
			this._OnUpdateSlaSelection();
		},
		// This function sets the OData model for ISP (Integrated Service Provider)
		systemLSDataModel: function(self) {
			// Set the OData model for the ISP service
			const componentName = this.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
			const componentPath = sap.ui.require.toUrl(componentName);
			// Call ymr_srv service for solution areas
			const oDataModel = new ODataModel({
				serviceUrl: `${componentPath}/int_ls/sap/opu/odata/sap/ymr_srv`
			});
			return oDataModel;
		},
		onSelectCACheckBox: function (evt) {
            evt.getSource().getParent()._setSelected(evt.getParameter("selected"));
          //  evt.getSource().getParent().getBindingContext("CAModel").getObject().tempSelection = true;
            if(!evt.getParameter("selected")){
                evt.getSource().getParent().getBindingContext("CAModel").getObject().tempSelection = true;
                evt.getSource().getParent().getBindingContext("CAModel").getObject().tempSelect = false;
                //this.oContextAssignmentObj.selectedNominees.length ? this.oContextAssignmentObj.selectedNominees.filter(item => item.userId !== evt.getSource().getParent().getBindingContext("CAModel").getObject().userId) : [];
           }else{
                evt.getSource().getParent().getBindingContext("CAModel").getObject().tempSelection = false;
                evt.getSource().getParent().getBindingContext("CAModel").getObject().tempSelect = true;
                //  this.oContextAssignmentObj.selectedNominees.push(evt.getSource().getParent().getBindingContext("CAModel").getObject());
           }
            let bTempSelect
          if( this.aSelectionResArray.length){
            this.aSelectionResArray.forEach(function(res){
                if(res.userId === evt.getSource().getParent().getBindingContext("CAModel").getObject().userId ){
                    res.tempSelect = evt.getSource().getParent().getBindingContext("CAModel").getObject().tempSelect;
                }else{
                    bTempSelect = true;
                }
            });
          }else{
            bTempSelect = true;
          }
          if(bTempSelect){
            this.aSelectionResArray.push(evt.getSource().getParent().getBindingContext("CAModel").getObject());
          }
        },
onHighlightOreResources:function(evt){
const aTableRows = this.byId("EmpDetailsTableID").getRows();
const that = this;
for(var i=0; i<aTableRows.length;i++){
if(aTableRows[i].getBindingContext("resourceModel").getObject().selected){
	that.byId("EmpDetailsTableID").getRows()[i]._setSelected(true);
}else{
	that.byId("EmpDetailsTableID").getRows()[i]._setSelected(false);
}
}
},
onSelectORECheckBox: function (evt) {
	evt.getSource().getParent()._setSelected(evt.getParameter("selected"));
   // evt.getSource().getParent().getBindingContext("resourceModel").getObject().tempSelection = true;
	if(!evt.getParameter("selected")){
		evt.getSource().getParent().getBindingContext("resourceModel").getObject().tempSelection = true;
		evt.getSource().getParent().getBindingContext("resourceModel").getObject().tempSelect = false; 
	   // this.oContextAssignmentObj.selectedNominees.length ? this.oContextAssignmentObj.selectedNominees.filter(item => item.userId !== evt.getSource().getParent().getBindingContext("resourceModel").getObject().userId) : [];
	}else{
		evt.getSource().getParent().getBindingContext("resourceModel").getObject().tempSelection = false;
		evt.getSource().getParent().getBindingContext("resourceModel").getObject().tempSelect = true;
	  //  this.oContextAssignmentObj.selectedNominees.push(evt.getSource().getParent().getBindingContext("resourceModel").getObject());
   }
   let bTempSelect
  if( this.aSelectionResArray.length){
	this.aSelectionResArray.forEach(function(res){
		if(res.userId === evt.getSource().getParent().getBindingContext("resourceModel").getObject().userId ){
			res.tempSelect = evt.getSource().getParent().getBindingContext("resourceModel").getObject().tempSelect;
		}else{
			bTempSelect = true;
		}
	});
  }else{
	bTempSelect = true;
  }
  if(bTempSelect){
	this.aSelectionResArray.push(evt.getSource().getParent().getBindingContext("resourceModel").getObject());
  }
},
onBAIndChange:function(oEvent){
	let oModel;
	if (oEvent.getParameter("selectedItem")) {
		 oModel = oEvent.getParameter("selectedItem").getBindingContext("employee").oModel;
		const oBAIndustry = oEvent.getParameter("selectedItem").getBindingContext("employee").getObject();
		const aEmployeeBAIndustries = [];
		aEmployeeBAIndustries.push({
			Guid: oBAIndustry.Guid,
			Desc: oBAIndustry.Desc,
			ClusterGuid: oBAIndustry.ClusterGuid,
			ClusterDesc: oBAIndustry.ClusterDesc,
			IsPrimary: oBAIndustry.IsPrimary,
			BaIndTechID: oBAIndustry.BaIndTechID,
			BaIndId: oBAIndustry.BaIndId
		});
		this.getView().getModel("employee").setProperty(`/TempEmployee/TempBAIndustries`, aEmployeeBAIndustries);
		this.getView().getModel("employee").setProperty(`/TempEmployee/BAIndustries`, aEmployeeBAIndustries);
		this.getView().getModel("employee").refresh(true);
	} else {
		this.getView().getModel("employee").setProperty(`/TempEmployee/TempBAIndustries`, []);
		this.getView().getModel("employee").setProperty(`/TempEmployee/BAIndustries`, []);
		oModel = this.getView().getModel("employee");
	}
	 this._setSearchFieldText();
	 this._onEnableSearchResources();
},
_setSearchFieldText:function(){
	const aSearchItem= this.getView().getModel("employee").getProperty(`/TempEmployee`);
	const aSearchParams = [];
	const aSolArea = [];
	const aBAInd = [];
	if(aSearchItem.SolutionAreas && aSearchItem.SolutionAreas.length){
		aSearchItem.SolutionAreas.forEach(function(sol){
			aSolArea.push(sol.soln_name);
		})
	}
	if( aSearchItem.TempBAIndustries.length){
		aSearchItem.TempBAIndustries.forEach(function(Ind){
			aBAInd.push(Ind.Desc);
		})
	}
	aSearchItem.TempRoleAreas.length ? aSearchParams.push(aSearchItem.TempRoleAreas[0].Desc) :false;
	aSearchItem.SolutionAreas && aSearchItem.SolutionAreas.length ? aSearchParams.push(aSolArea.join()) :false;
	aSearchItem.TempBAIndustries.length ? aSearchParams.push(aBAInd.join()) :false;
	// aSearchItem.TempBALoBs.length ? aSearchParams.push(aSearchItem.TempBALoBs[0].Desc) :false;
	// aSearchItem.TempCrossCvg.length ? aSearchParams.push(aSearchItem.TempCrossCvg[0].Desc) :false;
	const sSearchText = aSearchParams.join(" | ");
	this.getView().getModel("employee").setProperty(`/searchFieldsText`,`[${sSearchText}]`);
	this.getView().getModel("employee").refresh(true);
},
onAfterOpenPopover: function () {
	let oTreeTable = this.byId("territoriesTableId");
   
	let oBinding = oTreeTable.getBinding("rows");

	if (oBinding.getLength() > 0) {
		oTreeTable.expand(0);
	}
},
//MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
		//Select Solution Area (L1)
          onSelectSLA:function(oEvent){
              const oBindingContextSLA = oEvent.getSource().getBindingContext("SLAMasterDataLevels").getObject();
              this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas" , "");
			  let aSelectedSLA = !this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aSelectedSolutionAreas") ? [] : this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aSelectedSolutionAreas");
              if (oEvent.getParameter("selected")) {
                  aSelectedSLA.push(oBindingContextSLA);
                  this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA", true);
              } else if (aSelectedSLA.length) {
                  aSelectedSLA = aSelectedSLA.filter(item => item.soln_guid !== oBindingContextSLA.soln_guid);
                  this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA", true);
              }else{
                  this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA", false);
              }
                  let aSLALevel2 = this.getOwnerComponent().getModel("SLAMasterDataLevels").getData();
                  aSLALevel2.results.forEach(function (data) {
                      if (data.soln_guid === oBindingContextSLA.soln_guid) {
                          data.IsSelected = true;
                          data.isPartiallySelected = false;
                      } else {
                          data.IsSelected = false;
                      }
                  });
                  const removeDuplicateSLAObjects = aSelectedSLA.filter((value, index) => {
                      const _value = JSON.stringify(value);
                      return index === aSelectedSLA.findIndex(obj => {
                        return JSON.stringify(obj) === _value;
                      });
                    });
              
					this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",removeDuplicateSLAObjects);
                    this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aTokenSelectedSolutionAreas",removeDuplicateSLAObjects);
                  this.getOwnerComponent().getModel("SLAMasterDataLevels").refresh(true);
                  this.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
                  this._OnUpdateSlaSelection();
              
          },
          onCloseSolutionArea: function () {
              const that = this;
              this.pSLAValueHelpDialog.then(function (oDialog) {
                  oDialog.close();
                  that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",that.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`));
				  that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aTokenSelectedSolutionAreas",that.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`));
				that.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
              });
          },
        _OnUpdateSlaSelection: function () {
            let aSLALevel2 = this.getOwnerComponent().getModel("SLAMasterDataLevels").getData();
            let that = this;
            let aSelectedSLA = this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aSelectedSolutionAreas");
            aSLALevel2.results.forEach(function (data) {
                data.isSelected = false;
                data.isPartiallySelected = false;
                if (data.is_ChildLoaded && data.to_Child.length) {
                    data.to_Child.forEach(function (child) {
                        child.isSelected = false;
                        child.isPartiallySelected = false;
						child.solnFinalName = child.SolAreal2Desc;
                    });
                }
            });
            if (aSelectedSLA.length) {
                aSelectedSLA.forEach(function (oContextSolutionArea) {
                    aSLALevel2.results.forEach(function (data) {
                        //data.isSelected = false;
                        that.oParentData = data;
                        if (oContextSolutionArea.soln_guid === data.soln_guid) {
                            data.isSelected = true;
                            data.isPartiallySelected = false;
                        }
                        if (data.is_ChildLoaded && data.to_Child.length) {
                            data.to_Child.forEach(function (child) {
                                //child.isSelected = false;
                                if (oContextSolutionArea.soln_guid === child.soln_guid) {
                                    child.isSelected = true;
                                    child.isPartiallySelected = false;
                                }
                                if (child.isSelected && !that.oParentData.isSelected && !that.oParentData.isPartiallySelected) {
                                    //	oContextSolutionArea.isSelected = true;
                                    that.oParentData.isSelected = true;
                                    that.oParentData.isPartiallySelected = true;
                                }
                            });
                        }else if(!data.is_ChildLoaded && oContextSolutionArea.soln_prnt_guid === that.oParentData.soln_guid ){
                            let aFilteredSelectedSLA = aSelectedSLA.filter(item=> item.soln_guid === that.oParentData.soln_guid);
                            if(!aFilteredSelectedSLA.length){
                                that.oParentData.isSelected = true;
                                that.oParentData.isPartiallySelected = true;
								that.getOwnerComponent().getModel("SLAMasterDataL1").getData().aSelectedSolutionAreas.push(that.oParentData);
                            }
                        }
                    });
                })
                this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA", true);
            } else {
                this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA", false);
            }

            this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas", aSelectedSLA)
            this.getOwnerComponent().getModel("SLAMasterDataLevels").refresh();
			if(this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aSelectedSolutionAreas").length > 1){
				let filteredData = this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aTokenSelectedSolutionAreas").filter(item => item.to_Child.length === 0)
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aTokenSelectedSolutionAreas" , filteredData);
			}
            this.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
            this.getOwnerComponent().getModel("SLAMasterDataLevels").refresh();
        },
          onAfterOpenSLAPopover: function () {
              const oTree = this.byId("idSolutionTreeOnCreate");
              let aSelectedItems = oTree.getItems();
              let aSelectedIndices = [];
              for (var i = 0; i < aSelectedItems.length; i++) {
                  aSelectedIndices.push(oTree.indexOfItem(aSelectedItems[i]));
              }
              oTree.collapse(aSelectedIndices);
          },
	  //filter soution area based on solution name
	  onSearchSolutionArea: function (oEvent) {
		const query = oEvent ? oEvent.getSource().getValue().trim():"";
		const oTree = this.byId("idSolutionTreeOnCreate");
		oTree.getBinding("items").filter(
			query
				? new sap.ui.model.Filter({
					path: "soln_name",
					operator: sap.ui.model.FilterOperator.Contains,
					value1: query,
				})
				: null
		);
		oTree.expandToLevel(query ? 99 : 0);
		if(!query){
			oTree.collapseAll();
		}
	},
	onShowInfoMessage:function(oEvent){
		const sKey = oEvent.getSource().getCustomData()[0].getKey(),
			oAppConfigModel = this.getOwnerComponent().getModel("mrrAppConfigModel").getData(),
			that = this,
	 		oSource = oEvent.getSource();
			
		let oBoundObj = sKey !== "midSectionText" ? oAppConfigModel[sKey][0].fieldDesc : "";
		if (sKey === "midSectionText") {
			//set mid section text
			let oBindingSearchContext = this.getView().getId().includes("App") ?
				this.getView().getModel("employee").getData() : oEvent.getSource().getParent().getBindingContext("employee").getObject(),
				sRoleArea = oBindingSearchContext.TempEmployee.TempRoleAreas.length ? oBindingSearchContext.TempEmployee.TempRoleAreas[0].ID : "";
			switch (sRoleArea) {
				case "0006":
					oBoundObj = oAppConfigModel["Role_ArchAdvsory_InfoBubble"][0].fieldDesc;
					break;
				case "0003":
					oBoundObj = oAppConfigModel["Role_SolnAdvsory_InfoBubble"][0].fieldDesc;
					break;
				default:
					break;
			}
		}
		this.getView().setModel(new JSONModel({
			HTML : oBoundObj
		}),"infoMsgModel")
	
		if (!this.pInfoPopOverDialog) {
			this.pInfoPopOverDialog = this.loadFragment({
				name: "com.sap.bpm.PresalesRequestApproval.fragments.InfoMessagePopOver"
			});
		}

		this.pInfoPopOverDialog.then(function (oDialog) {
			oDialog.openBy(oSource);
		});
	}
});
});
