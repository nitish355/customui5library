sap.ui.define([
	"com/sap/bpm/PresalesRequestApproval/test/unit/controller/App.controller"
], function () {
	"use strict";
});
