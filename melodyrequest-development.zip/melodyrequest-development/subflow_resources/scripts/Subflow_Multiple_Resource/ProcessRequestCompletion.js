$.context.lastActivityDate = new Date();
$.context.currentState = $.context.CurrentStateValue.REQCOM.Value;