$.context.lastAcceptorComments = "" ; 
var Role = "Assignment ID " + $.context.AssignmentID + " - eAsigne";
if (!$.context.ResSendBackDecision) {
    $.context.ResSendBackDecision = "Send back to Processor";
}
var decision = {
    "UserId":$.context.currentProcessor.id, //Userid for approvalHistory
    "UserName": $.context.currentProcessor.fullName,
    "Role": Role, //$.context.currentProcessorRole,
    "StepName": $.context.CurrentStepValue.RESAPP.Value,//"Presales Resource Approval", //$.context.currentStepName,
    "StepID": $.context.CurrentStepValue.RESAPP.ID,
    "Decision": $.context.ResSendBackDecision, //$.context.decision,
    "Comments": $.context.comments,
    "Date": new Date()
};
$.context.approvalHistory.push(decision);

for (var i = 0; i < $.context.NominatedResources.length; i++) { 
    if ($.context.NominatedResources[i].email == $.context.currentProcessor.email) {
        $.context.NominatedResources[i].NomResRejectComment =  $.context.comments ? $.context.comments : "";
        $.context.NominatedResources[i].NomResRejectDecision = "Reject";
    }
}

$.context.lastAcceptorComments = $.context.comments ? $.context.comments : "";
$.context.comments = "";

var resources = $.context.NominatedResourcesIds.split(',');
var filtered = resources.filter(function (val) {
    // return val !== $.usertasks.usertask3.last.processor
    return val !== $.usertasks.usertask1.last.processor
});
$.context.NominatedResourcesIds = filtered.join(',');
$.context.NominatedResourcesCount -= 1;

$.context.lastActivityDate = new Date();
