var decision = {
    "UserId": $.context.currentProcessor.id, // userId for approvalHistory
    "UserName": $.context.currentProcessor.fullName,
    "Role": $.context.currentProcessorRole,
    "StepName": $.context.currentStepName,
    "StepID": $.context.currentStepID,
    "Decision": $.context.decision,
    "Comments": $.context.comments,
    "Date": new Date()
};

$.context.approvalHistory.push(decision);
$.context.lastAcceptorComments = $.context.comments ? $.context.comments : "";
$.context.isRework = true;

$.context.currentState = $.context.CurrentStateValue.REESUB.Value;
$.context.lastActivityDate = new Date();

$.context.currentProcessorRole = "Requestor"
$.context.currentProcessor = $.context.requesterDetails;