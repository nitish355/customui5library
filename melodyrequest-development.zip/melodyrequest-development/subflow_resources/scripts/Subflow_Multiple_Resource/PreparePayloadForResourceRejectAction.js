$.context.User_NotifDBCallPayload = {};
var users = {};
var UserNotifpayload = {};
UserNotifpayload.notif_Id = "10";
UserNotifpayload.notifVal_Id = "0002";
if ( $.context.approverData.id && $.context.approverData.email) {
  users.processor = [{
    userId: $.context.approverData.id,
    email: $.context.approverData.email
  }];
}
if ( Object.keys(users).length > 0) {
  UserNotifpayload.users = users;
  $.context.User_NotifDBCallPayload = UserNotifpayload;
}