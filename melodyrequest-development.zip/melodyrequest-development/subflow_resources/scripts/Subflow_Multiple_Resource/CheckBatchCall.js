
var responses = $.context.DBCallSF.Response.responses;
$.context.retry = false;

responses.forEach(function (response) {
    if (!(response.status >= 200 && response.status <= 300)) {
        $.context.retry = true;
    }
});

