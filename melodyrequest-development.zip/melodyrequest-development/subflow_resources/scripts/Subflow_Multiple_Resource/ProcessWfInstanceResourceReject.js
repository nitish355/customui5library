var now = new Date();
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');

if (!$.context.DBCallSF) {
    $.context.DBCallSF = {};
}
$.context.DBCallSF.Request = {};
$.context.DBCallSF.Request.requests = [];
var aplen = $.context.approvalHistory.length;
// prepare data for wf history 

var resourcetaskID = "";
resourcetaskID = $.usertasks.usertask1.last.id;
var ReqHistory_data = {};
ReqHistory_data.InstanceID = $.context.WfID_PresalesRequestApproval;
ReqHistory_data.UserTaskID = resourcetaskID;
ReqHistory_data.AssignmentID = $.context.AssignmentID;
ReqHistory_data.User_ID = $.context.currentProcessor.id;
ReqHistory_data.User_Name = $.context.currentProcessor.fullName;
ReqHistory_data.User_EMail = $.context.currentProcessor.email;
ReqHistory_data.StateID = $.context.CurrentStateValue.WRESAP.ID;
ReqHistory_data.StepID = $.context.CurrentStepValue.RESAPP.ID;
ReqHistory_data.ActionTaken = "Sent the request back to the processor.";
ReqHistory_data.Role = "Resource";
ReqHistory_data.Decision = $.context.decision_ID;
ReqHistory_data.Comments = $.context.approvalHistory[aplen-1].Comments;
ReqHistory_data.Date = date;
ReqHistory_data.Time = time;
if (!$.context.UT_refID) {
    $.context.UT_refID = 1;
}
else {
    $.context.UT_refID += 1;
}
ReqHistory_data.UT_refID = $.context.UT_refID;

$.context.DBCallSF.Request.requests.push({
    id: "1",
    method: "POST",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WFHistory",
    body: ReqHistory_data
});