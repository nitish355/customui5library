//code  for managing Older requests available in My inbox.

if ($.context.RequestType == "Opportunity") {
	$.context.Opp_ID = "Opportunity ID:" ;
    $.context.CRev_L = "Cloud Revenue:" ;
    $.context.OpRev_L = "On Premise Revenue:" ;

	// code for dynamic email
	$.context.CRev = $.context.dealInfo.cloudRevenueFormatted;
	$.context.OpRev = $.context.dealInfo.onPremRevenueFormatted;

	$.context.isAccount = false;

	
}
if (!$.context.processor_email) {
   $.context.processor_email = $.context.extSystemsUrls.MRRInboxURL + "ManagerDetailPage/" + $.info.workflowInstanceId;
}

//code for email template
if ($.context.isResourceProfile === true) {
    if (!$.context.resourcecomment) {
        $.context.resourcecomment = [];
    }
    while ($.context.resourcecomment.length < 10) {
        var reqResource = [{ class: "hidden-row" }];
        var assignedActivity = [];
        for (var i = 0; i < 5; i++) {
            assignedActivity.push({ class: "hidden-row" });
        }
        $.context.resourcecomment.push({
            reqResource: reqResource,
            assignedActivity: assignedActivity,
            ActivityHide: "hidden-row",
            comment: "",
            class: "hidden-row"
        });
    }
}

//  code to delete draft activity 
var AssignmentID = $.context.NominatedResources && $.context.NominatedResources.length > 0 ? $.context.NominatedResources[0].AssignmentID : "";
var AllAssignmentDetails = [];
$.context.ActivityLists = [];
if ($.context.AllAssignmentDetails && $.context.AllAssignmentDetails.length > 0) {
    AllAssignmentDetails = $.context.AllAssignmentDetails;
}
for (var i = 0; i < AllAssignmentDetails.length; i++) {
    var activitylists = AllAssignmentDetails[i].activityLists ? AllAssignmentDetails[i].activityLists : [];
    activitylists.forEach(function (val) {
        if (val.assignmentID == AssignmentID) {
            $.context.ActivityLists.push(val);
        }
    });
}
if ($.context.ActivityLists && $.context.ActivityLists.length > 0) {
    $.context.deleteActivityListData = {};
    var objectTypeActvtPayload = {};
    var ActivityPayload = {};
    $.context.deleteActvityList = true;
    $.context.ActvtAssignmentID = $.context.ActivityLists[0].assignmentID;
    ActivityPayload.ActivityListsData = [];
    objectTypeActvtPayload.AssignmentID = $.context.ActvtAssignmentID;
    objectTypeActvtPayload.INSTANCE_GUID = $.context.WfID_PresalesRequestApproval;
    ActivityPayload.ActivityListsData.push(objectTypeActvtPayload);
    $.context.deleteActivityListData = ActivityPayload;
}
else { $.context.deleteActvityList = false; }
