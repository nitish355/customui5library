var aAssignedPresalesData = $.context.NominatedResources,
    sAssigneeIntro = "Dear " + aAssignedPresalesData[0].fullName + ",",
    sAssigneeEmails = aAssignedPresalesData[0].email,
    sAssigneeIds = aAssignedPresalesData[0].userId;

if (aAssignedPresalesData.length > 1) {
    for (var i = 1; i < aAssignedPresalesData.length; i++) {
        sAssigneeIntro += "\nDear " + aAssignedPresalesData[i].fullName + ",";
        sAssigneeEmails += "," + aAssignedPresalesData[i].email;
        sAssigneeIds += "," + aAssignedPresalesData[i].userId;
    }
}

$.context.NominatedResourcesCount = aAssignedPresalesData.length;

$.context.notifyResourceEmailIntro = sAssigneeIntro;
$.context.NominatedResourcesEmails = sAssigneeEmails;
$.context.NominatedResourcesIds    = sAssigneeIds;


//temporary code 
if (!$.context.RequestType) {
	$.context.Opp_ID = "Opportunity ID:" ;
    $.context.CRev_L = "Cloud Revenue:" ;
    $.context.OpRev_L = "On Premise Revenue:" ;

	// code for dynamic email
	$.context.CRev = $.context.dealInfo.cloudRevenueFormatted;
	$.context.OpRev = $.context.dealInfo.onPremRevenueFormatted;

}

if ($.context.NewOppDetails) {
    $.context.Opp_Sales_Office = $.context.NewOppDetails.Opp_Sales_Office ? $.context.NewOppDetails.Opp_Sales_Office : "";
    $.context.Opp_Partner = $.context.NewOppDetails.Opp_Partner ? $.context.NewOppDetails.Opp_Partner : "";
    $.context.Opp_SalesOrg_Name = $.context.NewOppDetails.Opp_SalesOrg_Name ? $.context.NewOppDetails.Opp_SalesOrg_Name : "";
    $.context.Opp_SalesGroupName = $.context.NewOppDetails.Opp_SalesGroupName ? $.context.NewOppDetails.Opp_SalesGroupName : "";
}
//code for email template
if($.context.isResourceProfile === true)
    {
    
    $.context.User_NotifDBCallPayload = {};
    var users = {};
    var UserNotifpayload = {};
    UserNotifpayload.notif_Id = "10";
    UserNotifpayload.notifVal_Id = "0002";
    if (aAssignedPresalesData[0].userId && aAssignedPresalesData[0].email) {
        users.resource = [{
            userId: aAssignedPresalesData[0].userId.toUpperCase(),
            email: aAssignedPresalesData[0].email
        }];
    }
    if (Object.keys(users).length > 0) {
        UserNotifpayload.users = users;
        $.context.User_NotifDBCallPayload = UserNotifpayload;
    }
    
    if (!$.context.resourcecomment) {
        $.context.resourcecomment = [];	
    }   
    
    while ($.context.resourcecomment.length < 10) {
        var reqResource = [{ class: "hidden-row" }];  
        var  assignedActivity =[];
        for (var i = 0; i < 5; i++) {
            assignedActivity.push({ class: "hidden-row" });
        }
        $.context.resourcecomment.push({
            reqResource: reqResource,
            assignedActivity: assignedActivity,
            comment: "",
            class: "hidden-row"
        });
    }
    if($.context.AllAssignmentDetails){
        $.context.Assignment = $.context.AllAssignmentDetails;
    }
    }
if (!$.context.EmailTemplateVars) {
    $.context.EmailTemplateVars = {};
    $.context.EmailTemplateVars.FBSStyle = "";
    if ($.context.aResourceProfileApprovers.ResourceProfileDetails.SolutionAreas && $.context.aResourceProfileApprovers.ResourceProfileDetails.SolutionAreas.length > 0) {
        var SelectedSol = {}
        SelectedSol = $.context.aResourceProfileApprovers.ResourceProfileDetails.SolutionAreas[0];
    }
    if ($.context.aResourceProfileApprovers.ResourceProfileDetails.BAIndustries && $.context.aResourceProfileApprovers.ResourceProfileDetails.BAIndustries.length > 0) {
        var SelectedIndustry = {}
        SelectedIndustry = $.context.aResourceProfileApprovers.ResourceProfileDetails.BAIndustries[0];
    }
     if ($.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedGroup && $.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedGroup.length > 0) {
        var SelectedGroup = {}
        SelectedGroup = $.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedGroup[0];
    }
    $.context.EmailTemplateVars.Solution_Area = SelectedSol ? SelectedSol.SelectedSolutionArea : "Not selected";
    $.context.EmailTemplateVars.BA_Industry = SelectedIndustry ? SelectedIndustry.Desc : "Not selected";
    $.context.EmailTemplateVars.Requestor_need = $.context.requestDetails.typeOfSupport ? $.context.requestDetails.typeOfSupport : "Not specified by Requestor";
    $.context.EmailTemplateVars.supportType = $.context.requestDetails.supportType ? $.context.requestDetails.supportType : "Not specified by Requestor";
    $.context.EmailTemplateVars.Group = SelectedGroup ? SelectedGroup.SelectedGroup : "Not selected";
    if ($.context.RequestType == "Account") {
        $.context.EmailTemplateVars.OppHide = "hidden-row";
    }
}
$.context.HistoryClass =  (!$.context.EmailTemplateVars.approvalHistoryEmail) ? "hidden-row" : "history-table";
if (!$.context.EmailTemplateVars.EmailSubject) {
    if ($.context.RequestType === 'Account') {
        $.context.EmailTemplateVars.EmailSubject = $.context.accountName;
    }
    else {
        $.context.EmailTemplateVars.EmailSubject = $.context.Opp_Desc + ", " + $.context.accountName;
    }
}