var currentProcessor = "",
    currentProcessorEmail = "",
    currentProcessorID = "";

// Arrays to store IDs, emails, and names to remove from the processor list
var idsToRemove = [],
    emailsToRemove = [],
    namesToRemove = [],
    WFInsProcessorURL = [];
var count = 0;
var roleData = true;
var currentId = ($.context.currentProcessor.id || "").trim().toLowerCase();
var currentEmail = ($.context.currentProcessor.email || "").trim().toLowerCase();
var currentName = ($.context.currentProcessor.fullName || "").trim().toLowerCase();

var WfInsAssingnmentData = [];
var wfdata = $.context.WFInsCurrentProcessorDBCall.Response;

$.context.assignedCRMRoleData = {};

if ($.context.WfInstanceAssignmentDBCall) {
    WfInsAssingnmentData = $.context.WfInstanceAssignmentDBCall.Response.value;
}

if (!$.context.DBCallWFIns) {
    $.context.DBCallWFIns = {};
}
$.context.DBCallWFIns.Request = {};
$.context.DBCallWFIns.Request.requests = [];
if (typeof $.context.assignedRoleData === 'undefined') {
    roleData = false;
}
if (!roleData) {
    for (var i = 0; i < $.context.NominatedResources.length; i++) {
        if ($.context.currentProcessor.id === $.context.NominatedResources[i].userId) {
            $.context.assignedCRMRoleData = $.context.NominatedResources[i].assignedRoleData;
        }
    }
} else {
    $.context.assignedCRMRoleData = $.context.assignedRoleData;
}

// Iterate through all workflow assignment entries to identify matching records
for (var i = 0; i < WfInsAssingnmentData.length; i++) {
    var assgn = WfInsAssingnmentData[i];

    // Extract and normalize IDs, emails, and names
    var ids = assgn.reqResource_ID ? assgn.reqResource_ID.split(';').map(function (s) {
        return s.trim().toLowerCase();
    }) : [];
    var emails = assgn.reqResource_EMail ? assgn.reqResource_EMail.split(';').map(function (s) {
        return s.trim().toLowerCase();
    }) : [];
    var names = assgn.reqResource_Name ? assgn.reqResource_Name.split(';').map(function (s) {
        return s.trim().toLowerCase();
    }) : [];

    // Check for match using ID or email
    var matched = ids.some(function (id) {
        return id === currentId;
    }) || emails.some(function (email) {
        return email === currentEmail;
    });

    if (matched) {
        if ($.context.decision === "Approve") {  // If approved, remove all listed IDs; otherwise, remove only current user
            idsToRemove = ids;
            emailsToRemove = emails;
            namesToRemove = names;
        } else {
            idsToRemove = [currentId];
            emailsToRemove = [currentEmail];
            namesToRemove = [currentName];
        }
        break;
    }
}
// Filter out removed users from current processor fields
currentProcessorID = filterWfInsCurrentProcessorValues(wfdata.currentProcessorID, idsToRemove);
currentProcessorEmail = filterWfInsCurrentProcessorValues(wfdata.currentProcessorEmail, emailsToRemove);
currentProcessor = filterWfInsCurrentProcessorValues(wfdata.currentProcessor, namesToRemove);

function filterWfInsCurrentProcessorValues(rawString, removeList) { // function to remove specified values from comma-separated string
    count = 1;
    if (!rawString) return "";
    var result = "";
    rawString.split(',').forEach(function (val) {
        var trimmed = val.trim();
        if (removeList.indexOf(trimmed.toLowerCase()) === -1) {
            result += trimmed + ",";
        }
    });
    return result.slice(0, -1);
}
// Prepare data for WFINSTANCE New Table

var wfIns_data = {};
wfIns_data.currentProcessorID = currentProcessorID;
wfIns_data.currentProcessor = currentProcessor;
wfIns_data.currentProcessorEmail = currentProcessorEmail;
if (!$.context.DelWfinsResource) {
    $.context.DelWfinsResource = false;
}
else {
    $.context.DelWfinsResource = false;
}
if (count != 0) { // If any processor update is needed
    $.context.DBCallWFIns.Request.requests.push({
        id: "1",
        method: "PATCH",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: "/WfInstance(instance_GUID='" + $.context.WfID_PresalesRequestApproval + "',parentInstance_GUID='" + $.context.parentInstanceID + "')",
        body: wfIns_data
    });

    if ($.context.WfInsProc_DelURLs) {
        var len_wfInsProc_DelURL = $.context.WfInsProc_DelURLs.length;
        for (var a = 0; a < len_wfInsProc_DelURL; a++) {
            var url = $.context.WfInsProc_DelURLs[a];
            var regex = /currentProcessorID='([^']+)'/; // Extract processor ID from URL
            var match = url.match(regex);
            if (match && match[1]) {
                var userId = match[1].toLowerCase();
                if (idsToRemove.indexOf(userId) === -1) {  // If userId is not in removal list, keep the URL
                    WFInsProcessorURL.push($.context.WfInsProc_DelURLs[a]);
                }
                else {
                    $.context.DBCallWFIns.Request.requests.push({
                        id: (a + 2).toString(),
                        dependsOn: ["1"],
                        method: "DELETE",
                        headers: { "content-type": "application/json;IEEE754Compatible=true" },
                        url: $.context.WfInsProc_DelURLs[a]
                    });                 
                }

            }
        }
        $.context.WfInsProc_DelURLs = [];
        $.context.WfInsProc_DelURLs = WFInsProcessorURL;

    }
    $.context.DelWfinsResource = true;
}
$.context.PostComment = false;
if( $.context.comments && $.context.comments.trim() !== "" )
{  
    $.context.PostComment = true;
    var UserTaskRole = "";  
    var newdate = new Date().toISOString();   
        if($.context.UserTaskLabelValue)
        {
            UserTaskRole = $.context.UserTaskLabelValue.Resource.userTask;
        }
 
        $.context.DBCallWFIns.Request.requests.push({
        id: ( 3 + len_wfInsProc_DelURL).toString(),
        dependsOn: ["1"],
        method: "POST",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: "/Comments",
        body: {
            instanceID: $.context.WfID_PresalesRequestApproval,
            actionId: $.context.decision_ID,
            commentText: $.context.comments,
            userID: $.context.currentProcessor.id,
            userEmail: $.context.currentProcessor.email,
            userName: $.context.currentProcessor.fullName,
            userRole: UserTaskRole,
            createdAt: newdate,
            modifiedAt: newdate
        }
        });
}