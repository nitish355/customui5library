var response =$.context.User_NotifDBCallPayload.Response;
 
$.context.ProcessorEmail_Notif = "";
$.context.ResourceEmail_Notif = "";
$.context.ResourceEmailNotif_flag = false;
$.context.ProcessorEmailNotif_flag = false;
 
if (response.processor && response.processor.length > 0) {
  $.context.ProcessorEmail_Notif = collectEmails("processor", false);
  $.context.ProcessorEmailNotif_flag = true;
}
 
if (response.resource && response.resource.length > 0) {
  $.context.ResourceEmail_Notif = collectEmails("resource", false);
  $.context.ResourceEmailNotif_flag = true;
}

function collectEmails(role, single) {
  var users = response[role];
  if (!Array.isArray(users)) return single ? "" : [];
 
  var emails = users
    .filter(function (u) { return u.email; })
    .map(function (u) { return u.email; });
 
  return single ? (emails[0] || "") : emails.join(",");
}
 