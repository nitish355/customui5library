{
	"contents": {
		"a0e1d2c2-8105-4850-acb1-08abc5055d9f": {
			"classDefinition": "com.sap.bpm.wfs.Model",
			"id": "subflow_multiple_resource",
			"subject": "Subflow_Multiple_Resource",
			"name": "Subflow_Multiple_Resource",
			"documentation": "Subflow for Multiple Resource Assignment",
			"lastIds": "62d7f4ed-4063-4c44-af8b-39050bd44926",
			"events": {
				"11a9b5ee-17c0-4159-9bbf-454dcfdcd5c3": {
					"name": "StartEvent1"
				},
				"2798f4e7-bc42-4fad-a248-159095a2f40a": {
					"name": "EndEvent1"
				}
			},
			"activities": {
				"02cee87b-fbf5-4f04-beba-abe85ca92cca": {
					"name": "Notify Resources"
				},
				"14089458-8940-4621-817d-da88209f2c4b": {
					"name": "Process Nominated Resources"
				},
				"4510f6bb-efd0-4b72-b846-5c8374a6c24c": {
					"name": "Resource Form"
				},
				"7e1f6577-bca2-4429-a795-ffc0757f3a36": {
					"name": "What is Decision?"
				},
				"6edbcce2-945d-460f-af4f-7ba2fb546403": {
					"name": "Notify Approver About Rejection"
				},
				"214d8e00-0a09-4a9d-9cf6-592cf643705c": {
					"name": "Process Resouce's Reject Decision"
				},
				"af509d04-1d5d-4dba-a9a4-72fe260bcd24": {
					"name": "Process WfInstance Resource Reject"
				},
				"de7988d8-145b-4d17-9fea-61059b175820": {
					"name": "Delete Resource"
				},
				"e0265025-8e37-495b-b48e-1a78ea457451": {
					"name": "Check Batch Call"
				},
				"84330708-bf74-4b3c-8a91-d1482c13d8f2": {
					"name": "retry?"
				},
				"d8bd1025-a7ec-46ef-a175-e5b74eb07b1f": {
					"name": "All Rejected?"
				},
				"ed106f0e-a0b1-4220-9e9f-686487bd56d1": {
					"name": "Resource Content for Older tasks"
				},
				"a8a7412f-1c9a-4d7c-9236-1dcb1319aaf1": {
					"name": "Get WFInstance Processor"
				},
				"54190a97-7e3a-41cb-a39e-447bf534e5ea": {
					"name": "Update WFInstance"
				},
				"47401a69-0537-48eb-8903-edd1fb99f13b": {
					"name": "Process WfInstance Delete Resource"
				},
				"a07d59af-1ac7-4a02-a245-4b3a872af66d": {
					"name": "Check Delete Resource Flag"
				},
				"d94a6108-e2d8-4920-b1b2-c528619ac7f2": {
					"name": "Is Resource Profile?"
				},
				"8490c210-a2f6-45be-b54d-fbed78fbb978": {
					"name": "Notify Request Area Resources"
				},
				"8a7fc8ce-e8c2-4200-b1e6-e670e600b32f": {
					"name": "Is Resource Profile"
				},
				"0c4f1636-9279-472e-9abf-4610b6f29de8": {
					"name": "Notify Approver About Rejection"
				},
				"b8205b69-42e1-4fa4-b7f9-397f7391116d": {
					"name": "GET WF Assignment Data"
				},
				"beca4899-4b61-4fde-8151-f202d1db2ba7": {
					"name": "Delete Activity Lists ? "
				},
				"756836dd-59b9-4056-a62e-32c60417cb81": {
					"name": "Delete Activity Lists ? "
				},
				"3eebed83-ca32-4b92-a0a3-3e409b0d36d8": {
					"name": "Delete Activity Data for Rework Action"
				},
				"b3b52f55-7ed3-4eea-bab4-867547e98fd0": {
					"name": "Delete Activity Data for Reject Action"
				},
				"da1a686d-5c4d-4949-8ba4-2628b470c140": {
					"name": "Process Resource Approval History"
				},
				"7379a9e1-faeb-4679-87f8-ae88e5d54d79": {
					"name": "Update Request History"
				},
				"de0a8b6a-c6b1-4d3c-b106-7d8135e5bb78": {
					"name": "Is New Request?"
				},
				"274e3e88-6e4c-4ef4-831e-51e6dd85a7c5": {
					"name": "ServiceTask14"
				},
				"32e4c5cd-c54e-462a-9913-7341ba388692": {
					"name": "Process User Notif Data"
				},
				"9a3aaa67-24d3-4576-8013-e313460292ec": {
					"name": "ScriptTask17"
				},
				"b00fbd2e-3b77-4d4a-a188-a273f070bc03": {
					"name": "ServiceTask15"
				},
				"e315c185-2e77-413e-9638-76481488e4cb": {
					"name": "Process User Notif Data"
				},
				"a63b187a-5f1f-40c8-bedd-a46b4a8d510d": {
					"name": "Email Flag"
				},
				"0a21d22d-d581-4cc1-a836-8e56c5455dbc": {
					"name": "Email Flag"
				},
				"19ab9486-10fc-491a-adb3-1a57f04318d7": {
					"name": "Process Update Resource History"
				}
			},
			"sequenceFlows": {
				"c6b99f32-5fe6-4ab6-b60a-80fba1b9ae0f": {
					"name": "SequenceFlow1"
				},
				"34051c3e-abaf-47f1-9791-6aae0a39af1b": {
					"name": "SequenceFlow3"
				},
				"a8b3d8e1-df6e-4195-926b-a29120840cd0": {
					"name": "SequenceFlow6"
				},
				"0ce50fb9-721a-4f08-9412-e8e4a5fa5baa": {
					"name": "Approve"
				},
				"b1dd1a05-34e9-4a19-9ded-b40694ab794a": {
					"name": "Rework"
				},
				"b8b2e870-3dd1-404a-b7ac-1f2f3fded5ce": {
					"name": "Reject"
				},
				"ff89babf-b61a-4f0c-baf1-7f2c726a14d8": {
					"name": "SequenceFlow22"
				},
				"1ecc1d60-f8eb-417e-97ab-25ae6d61a6a8": {
					"name": "SequenceFlow24"
				},
				"933e4603-68f8-4257-87ad-5a11d6ca713a": {
					"name": "SequenceFlow26"
				},
				"4b9a4283-8481-4eaf-bf71-4ebff94d1d3d": {
					"name": "Yes"
				},
				"3d12c092-a2f1-4cbe-8c16-b478cec1a83e": {
					"name": "SequenceFlow32"
				},
				"2a6e1437-3647-42be-980b-ea2bf6cf4337": {
					"name": "SequenceFlow33"
				},
				"5493dbb1-f0da-412c-9f00-de5d75d9dbb8": {
					"name": "No"
				},
				"a17e1efa-a6c3-4b6d-9f8c-8853ff8f2093": {
					"name": "Yes"
				},
				"adb2a1cb-02bf-4e5b-b679-8a7998140bae": {
					"name": "No"
				},
				"be674fda-109f-4464-acdd-eec8aae34864": {
					"name": "SequenceFlow41"
				},
				"28aa0537-532b-4ee2-bf44-35cd8aa10166": {
					"name": "SequenceFlow43"
				},
				"1861fe72-b085-4173-b07d-3d297a4c9b8f": {
					"name": "SequenceFlow46"
				},
				"b8e63169-7bb2-4fe3-915f-53196d38ed92": {
					"name": "SequenceFlow47"
				},
				"bf9741e2-107a-482c-a41f-092aa7428993": {
					"name": "Yes"
				},
				"025aca44-a8b5-41bc-b90e-4d47b7dee35a": {
					"name": "No"
				},
				"f39393e3-4c67-48b5-b9e0-c840b7dee493": {
					"name": "Yes"
				},
				"05cc7836-e46b-4b6a-9b14-8307fe7078b7": {
					"name": "No"
				},
				"d3602680-fe12-484b-8b75-389174bbafa0": {
					"name": "SequenceFlow55"
				},
				"c04947fd-a1a0-4d8c-8a6f-02735fc580eb": {
					"name": "Yes"
				},
				"5121690d-2600-428b-a4e8-6bd1243fe5f8": {
					"name": "No"
				},
				"588f44fd-21e6-4980-83c3-7e2d87059e9c": {
					"name": "SequenceFlow58"
				},
				"638e472d-05ba-4b10-ab9f-ff65b59f18c5": {
					"name": "SequenceFlow59"
				},
				"24727bf7-8b7a-46c1-ae7e-4a3ba52c3e6a": {
					"name": "No"
				},
				"eb4a2fbf-34df-41f2-bea4-c2e5818638ea": {
					"name": "No"
				},
				"495b2320-e123-4258-a84d-920c0e50c9a5": {
					"name": "Yes"
				},
				"88c28f8f-9a75-4a47-b56c-62f6cad0bfb7": {
					"name": "SequenceFlow65"
				},
				"4852ad78-4e78-43aa-9bc3-4afab793d582": {
					"name": "Yes"
				},
				"33752f92-6237-4112-aa39-c66ca8a179cd": {
					"name": "SequenceFlow67"
				},
				"4cf9d317-6a6b-4441-8827-3f02fcd50a44": {
					"name": "SequenceFlow68"
				},
				"7bc4de2e-dd1c-4e14-9e8e-c4c50dc5db6e": {
					"name": "SequenceFlow69"
				},
				"e7e1a4e0-2783-40f4-b109-deb3ad30d171": {
					"name": "Yes"
				},
				"7dae2e9e-eb91-4e78-a1e9-e7f8d6bf9ea5": {
					"name": "No"
				},
				"29adf2b8-3330-475f-8ee4-11d16f089357": {
					"name": "SequenceFlow74"
				},
				"ff8b305f-9f7c-485e-bfd8-7299f02d04c3": {
					"name": "SequenceFlow75"
				},
				"ed429373-68d9-4609-99e5-4ec04c576245": {
					"name": "SequenceFlow76"
				},
				"c41f2da4-50d5-437f-92aa-00b20c8e2866": {
					"name": "SequenceFlow77"
				},
				"ce36f30e-d962-412e-adcc-362c9178fee7": {
					"name": "SequenceFlow78"
				},
				"5427d89f-a62a-4bd5-a6c6-f0acc66641cb": {
					"name": "SequenceFlow79"
				},
				"81d01947-c49f-4961-9a8a-6bf1e1cb0f5b": {
					"name": "yes"
				},
				"e66d136c-c4e6-4794-ba66-4d4b38b5524d": {
					"name": "No"
				},
				"d324ca29-aecc-4880-8169-dd84ead5bf3b": {
					"name": "yes"
				},
				"14420dba-30a7-4d6e-a997-97e2a3b1c21b": {
					"name": "SequenceFlow83"
				},
				"62dacb45-e198-4ab6-837a-59d31ba5abd9": {
					"name": "SequenceFlow84"
				}
			},
			"diagrams": {
				"42fa7a2d-c526-4a02-b3ba-49b5168ba644": {}
			}
		},
		"11a9b5ee-17c0-4159-9bbf-454dcfdcd5c3": {
			"classDefinition": "com.sap.bpm.wfs.StartEvent",
			"id": "startevent1",
			"name": "StartEvent1"
		},
		"2798f4e7-bc42-4fad-a248-159095a2f40a": {
			"classDefinition": "com.sap.bpm.wfs.EndEvent",
			"id": "endevent1",
			"name": "EndEvent1"
		},
		"02cee87b-fbf5-4f04-beba-abe85ca92cca": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask1",
			"name": "Notify Resources",
			"mailDefinitionRef": "942bbcfb-f289-45fb-957a-77dc3b495564"
		},
		"14089458-8940-4621-817d-da88209f2c4b": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Subflow_Multiple_Resource/ProcessNominatedResources.js",
			"id": "scripttask1",
			"name": "Process Nominated Resources"
		},
		"4510f6bb-efd0-4b72-b846-5c8374a6c24c": {
			"classDefinition": "com.sap.bpm.wfs.UserTask",
			"subject": "Approve Assignment for ${context.accNameFormatted} ${context.Approval_subject}",
			"priority": "MEDIUM",
			"isHiddenInLogForParticipant": false,
			"supportsForward": false,
			"userInterface": "sapui5://dealsupportapp.comsapbpmPresalesRequestApproval/com.sap.bpm.PresalesRequestApproval",
			"recipientUsers": "${context.NominatedResourcesIds}",
			"id": "usertask1",
			"name": "Resource Form"
		},
		"7e1f6577-bca2-4429-a795-ffc0757f3a36": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway1",
			"name": "What is Decision?",
			"default": "0ce50fb9-721a-4f08-9412-e8e4a5fa5baa"
		},
		"6edbcce2-945d-460f-af4f-7ba2fb546403": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask4",
			"name": "Notify Approver About Rejection",
			"mailDefinitionRef": "6f0465ef-313f-4927-b02a-6a806acf07f6"
		},
		"214d8e00-0a09-4a9d-9cf6-592cf643705c": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Subflow_Multiple_Resource/ProcessResouceRejectDecision.js",
			"id": "scripttask7",
			"name": "Process Resouce's Reject Decision"
		},
		"af509d04-1d5d-4dba-a9a4-72fe260bcd24": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Subflow_Multiple_Resource/ProcessWfInstanceResourceReject.js",
			"id": "scripttask8",
			"name": "Process WfInstance Resource Reject"
		},
		"de7988d8-145b-4d17-9fea-61059b175820": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"xsrfPath": "",
			"requestVariable": "${context.DBCallSF.Request}",
			"responseVariable": "${context.DBCallSF.Response}",
			"headers": [{
				"name": "Content-Type",
				"value": "application/json;IEEE754Compatible=true"
			}],
			"id": "servicetask3",
			"name": "Delete Resource"
		},
		"e0265025-8e37-495b-b48e-1a78ea457451": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Subflow_Multiple_Resource/CheckBatchCall.js",
			"id": "scripttask9",
			"name": "Check Batch Call"
		},
		"84330708-bf74-4b3c-8a91-d1482c13d8f2": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway3",
			"name": "retry?",
			"default": "5493dbb1-f0da-412c-9f00-de5d75d9dbb8"
		},
		"d8bd1025-a7ec-46ef-a175-e5b74eb07b1f": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway4",
			"name": "All Rejected?",
			"default": "adb2a1cb-02bf-4e5b-b679-8a7998140bae"
		},
		"ed106f0e-a0b1-4220-9e9f-686487bd56d1": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Subflow_Multiple_Resource/ResourceContentforOldertasks.js",
			"id": "scripttask12",
			"name": "Resource Content for Older tasks"
		},
		"a8a7412f-1c9a-4d7c-9236-1dcb1319aaf1": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "wf/WfInstance(instance_GUID='${context.WfID_PresalesRequestApproval}',parentInstance_GUID='${context.parentInstanceID}')",
			"httpMethod": "GET",
			"responseVariable": "${context.WFInsCurrentProcessorDBCall.Response}",
			"id": "servicetask4",
			"name": "Get WFInstance Processor"
		},
		"54190a97-7e3a-41cb-a39e-447bf534e5ea": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.DBCallWFIns.Request}",
			"responseVariable": "${context.DBCallWFIns.Response}",
			"id": "servicetask6",
			"name": "Update WFInstance"
		},
		"47401a69-0537-48eb-8903-edd1fb99f13b": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Subflow_Multiple_Resource/ProcessWfInstanceDeleteResource.js",
			"id": "scripttask14",
			"name": "Process WfInstance Delete Resource"
		},
		"a07d59af-1ac7-4a02-a245-4b3a872af66d": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway7",
			"name": "Check Delete Resource Flag",
			"default": "025aca44-a8b5-41bc-b90e-4d47b7dee35a"
		},
		"d94a6108-e2d8-4920-b1b2-c528619ac7f2": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway8",
			"name": "Is Resource Profile?",
			"default": "05cc7836-e46b-4b6a-9b14-8307fe7078b7"
		},
		"8490c210-a2f6-45be-b54d-fbed78fbb978": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask6",
			"name": "Notify Request Area Resources",
			"mailDefinitionRef": "aad90f77-7426-4c10-abfc-96729adcbf30"
		},
		"8a7fc8ce-e8c2-4200-b1e6-e670e600b32f": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway9",
			"name": "Is Resource Profile",
			"default": "5121690d-2600-428b-a4e8-6bd1243fe5f8"
		},
		"0c4f1636-9279-472e-9abf-4610b6f29de8": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask7",
			"name": "Notify Approver About Rejection",
			"mailDefinitionRef": "fc5c3e54-80e1-45dd-ae7b-68d67938ef2c"
		},
		"b8205b69-42e1-4fa4-b7f9-397f7391116d": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/WfInstanceAssignment?$filter=InstanceID eq ('${context.WfID_PresalesRequestApproval}')",
			"httpMethod": "GET",
			"responseVariable": "${context.WfInstanceAssignmentDBCall.Response}",
			"id": "servicetask8",
			"name": "GET WF Assignment Data"
		},
		"beca4899-4b61-4fde-8151-f202d1db2ba7": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway12",
			"name": "Delete Activity Lists ? ",
			"default": "24727bf7-8b7a-46c1-ae7e-4a3ba52c3e6a"
		},
		"756836dd-59b9-4056-a62e-32c60417cb81": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway13",
			"name": "Delete Activity Lists ? ",
			"default": "eb4a2fbf-34df-41f2-bea4-c2e5818638ea"
		},
		"3eebed83-ca32-4b92-a0a3-3e409b0d36d8": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/activity-/deleteActivtyList",
			"httpMethod": "POST",
			"requestVariable": "${context.deleteActivityListData}",
			"responseVariable": "${context.deleteActivityListData.response}",
			"id": "servicetask11",
			"name": "Delete Activity Data for Rework Action"
		},
		"b3b52f55-7ed3-4eea-bab4-867547e98fd0": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/activity-/deleteActivtyList",
			"httpMethod": "POST",
			"requestVariable": "${context.deleteActivityListData}",
			"responseVariable": "${context.deleteActivityListData.response}",
			"id": "servicetask12",
			"name": "Delete Activity Data for Reject Action"
		},
		"da1a686d-5c4d-4949-8ba4-2628b470c140": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Subflow_Multiple_Resource/ProcessResourceApprovalHistory.js",
			"id": "scripttask15",
			"name": "Process Resource Approval History"
		},
		"7379a9e1-faeb-4679-87f8-ae88e5d54d79": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.WFHistory.Request}",
			"responseVariable": "${context.WFHistory.Response}",
			"id": "servicetask13",
			"name": "Update Request History"
		},
		"de0a8b6a-c6b1-4d3c-b106-7d8135e5bb78": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway14",
			"name": "Is New Request?",
			"default": "7dae2e9e-eb91-4e78-a1e9-e7f8d6bf9ea5"
		},
		"274e3e88-6e4c-4ef4-831e-51e6dd85a7c5": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/GetUserNotificationSettings",
			"httpMethod": "POST",
			"requestVariable": "${context.User_NotifDBCallPayload}",
			"responseVariable": "${context.User_NotifDBCallPayload.Response}",
			"id": "servicetask14",
			"name": "ServiceTask14"
		},
		"32e4c5cd-c54e-462a-9913-7341ba388692": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Subflow_Multiple_Resource/ProcessUserNotifData.js",
			"id": "scripttask16",
			"name": "Process User Notif Data"
		},
		"9a3aaa67-24d3-4576-8013-e313460292ec": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Subflow_Multiple_Resource/PreparePayloadForResourceRejectAction.js",
			"id": "scripttask17",
			"name": "ScriptTask17"
		},
		"b00fbd2e-3b77-4d4a-a188-a273f070bc03": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/GetUserNotificationSettings",
			"httpMethod": "POST",
			"requestVariable": "${context.User_NotifDBCallPayload}",
			"responseVariable": "${context.User_NotifDBCallPayload.Response}",
			"id": "servicetask15",
			"name": "ServiceTask15"
		},
		"e315c185-2e77-413e-9638-76481488e4cb": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Subflow_Multiple_Resource/ProcessUserNotifData.js",
			"id": "scripttask18",
			"name": "Process User Notif Data"
		},
		"a63b187a-5f1f-40c8-bedd-a46b4a8d510d": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway15",
			"name": "Email Flag",
			"default": "e66d136c-c4e6-4794-ba66-4d4b38b5524d"
		},
		"0a21d22d-d581-4cc1-a836-8e56c5455dbc": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway16",
			"name": "Email Flag",
			"default": "14420dba-30a7-4d6e-a997-97e2a3b1c21b"
		},
		"19ab9486-10fc-491a-adb3-1a57f04318d7": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Subflow_Multiple_Resource/ProcessUpdateResourceHistory.js",
			"id": "scripttask19",
			"name": "Process Update Resource History"
		},
		"c6b99f32-5fe6-4ab6-b60a-80fba1b9ae0f": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow1",
			"name": "SequenceFlow1",
			"sourceRef": "11a9b5ee-17c0-4159-9bbf-454dcfdcd5c3",
			"targetRef": "14089458-8940-4621-817d-da88209f2c4b"
		},
		"34051c3e-abaf-47f1-9791-6aae0a39af1b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow3",
			"name": "SequenceFlow3",
			"sourceRef": "02cee87b-fbf5-4f04-beba-abe85ca92cca",
			"targetRef": "4510f6bb-efd0-4b72-b846-5c8374a6c24c"
		},
		"a8b3d8e1-df6e-4195-926b-a29120840cd0": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow6",
			"name": "SequenceFlow6",
			"sourceRef": "4510f6bb-efd0-4b72-b846-5c8374a6c24c",
			"targetRef": "ed106f0e-a0b1-4220-9e9f-686487bd56d1"
		},
		"0ce50fb9-721a-4f08-9412-e8e4a5fa5baa": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow7",
			"name": "Approve",
			"sourceRef": "7e1f6577-bca2-4429-a795-ffc0757f3a36",
			"targetRef": "de0a8b6a-c6b1-4d3c-b106-7d8135e5bb78"
		},
		"b1dd1a05-34e9-4a19-9ded-b40694ab794a": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.decision  == \"Send Back to Requestor\"}",
			"id": "sequenceflow8",
			"name": "Rework",
			"sourceRef": "7e1f6577-bca2-4429-a795-ffc0757f3a36",
			"targetRef": "756836dd-59b9-4056-a62e-32c60417cb81"
		},
		"b8b2e870-3dd1-404a-b7ac-1f2f3fded5ce": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.decision  == \"Reject\"}",
			"id": "sequenceflow21",
			"name": "Reject",
			"sourceRef": "7e1f6577-bca2-4429-a795-ffc0757f3a36",
			"targetRef": "beca4899-4b61-4fde-8151-f202d1db2ba7"
		},
		"ff89babf-b61a-4f0c-baf1-7f2c726a14d8": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow22",
			"name": "SequenceFlow22",
			"sourceRef": "6edbcce2-945d-460f-af4f-7ba2fb546403",
			"targetRef": "214d8e00-0a09-4a9d-9cf6-592cf643705c"
		},
		"1ecc1d60-f8eb-417e-97ab-25ae6d61a6a8": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow24",
			"name": "SequenceFlow24",
			"sourceRef": "214d8e00-0a09-4a9d-9cf6-592cf643705c",
			"targetRef": "af509d04-1d5d-4dba-a9a4-72fe260bcd24"
		},
		"933e4603-68f8-4257-87ad-5a11d6ca713a": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow26",
			"name": "SequenceFlow26",
			"sourceRef": "af509d04-1d5d-4dba-a9a4-72fe260bcd24",
			"targetRef": "de7988d8-145b-4d17-9fea-61059b175820"
		},
		"4b9a4283-8481-4eaf-bf71-4ebff94d1d3d": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.retry}",
			"id": "sequenceflow31",
			"name": "Yes",
			"sourceRef": "84330708-bf74-4b3c-8a91-d1482c13d8f2",
			"targetRef": "e0265025-8e37-495b-b48e-1a78ea457451"
		},
		"3d12c092-a2f1-4cbe-8c16-b478cec1a83e": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow32",
			"name": "SequenceFlow32",
			"sourceRef": "de7988d8-145b-4d17-9fea-61059b175820",
			"targetRef": "e0265025-8e37-495b-b48e-1a78ea457451"
		},
		"2a6e1437-3647-42be-980b-ea2bf6cf4337": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow33",
			"name": "SequenceFlow33",
			"sourceRef": "e0265025-8e37-495b-b48e-1a78ea457451",
			"targetRef": "84330708-bf74-4b3c-8a91-d1482c13d8f2"
		},
		"5493dbb1-f0da-412c-9f00-de5d75d9dbb8": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow34",
			"name": "No",
			"sourceRef": "84330708-bf74-4b3c-8a91-d1482c13d8f2",
			"targetRef": "d8bd1025-a7ec-46ef-a175-e5b74eb07b1f"
		},
		"a17e1efa-a6c3-4b6d-9f8c-8853ff8f2093": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.NominatedResourcesCount == 0}",
			"id": "sequenceflow35",
			"name": "Yes",
			"sourceRef": "d8bd1025-a7ec-46ef-a175-e5b74eb07b1f",
			"targetRef": "2798f4e7-bc42-4fad-a248-159095a2f40a"
		},
		"adb2a1cb-02bf-4e5b-b679-8a7998140bae": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow36",
			"name": "No",
			"sourceRef": "d8bd1025-a7ec-46ef-a175-e5b74eb07b1f",
			"targetRef": "4510f6bb-efd0-4b72-b846-5c8374a6c24c"
		},
		"be674fda-109f-4464-acdd-eec8aae34864": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow41",
			"name": "SequenceFlow41",
			"sourceRef": "ed106f0e-a0b1-4220-9e9f-686487bd56d1",
			"targetRef": "b8205b69-42e1-4fa4-b7f9-397f7391116d"
		},
		"28aa0537-532b-4ee2-bf44-35cd8aa10166": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow43",
			"name": "SequenceFlow43",
			"sourceRef": "a8a7412f-1c9a-4d7c-9236-1dcb1319aaf1",
			"targetRef": "47401a69-0537-48eb-8903-edd1fb99f13b"
		},
		"1861fe72-b085-4173-b07d-3d297a4c9b8f": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow46",
			"name": "SequenceFlow46",
			"sourceRef": "54190a97-7e3a-41cb-a39e-447bf534e5ea",
			"targetRef": "7e1f6577-bca2-4429-a795-ffc0757f3a36"
		},
		"b8e63169-7bb2-4fe3-915f-53196d38ed92": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow47",
			"name": "SequenceFlow47",
			"sourceRef": "47401a69-0537-48eb-8903-edd1fb99f13b",
			"targetRef": "a07d59af-1ac7-4a02-a245-4b3a872af66d"
		},
		"bf9741e2-107a-482c-a41f-092aa7428993": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.DelWfinsResource || context.PostComment}",
			"id": "sequenceflow50",
			"name": "Yes",
			"sourceRef": "a07d59af-1ac7-4a02-a245-4b3a872af66d",
			"targetRef": "54190a97-7e3a-41cb-a39e-447bf534e5ea"
		},
		"025aca44-a8b5-41bc-b90e-4d47b7dee35a": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow51",
			"name": "No",
			"sourceRef": "a07d59af-1ac7-4a02-a245-4b3a872af66d",
			"targetRef": "7e1f6577-bca2-4429-a795-ffc0757f3a36"
		},
		"f39393e3-4c67-48b5-b9e0-c840b7dee493": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isResourceProfile}",
			"id": "sequenceflow53",
			"name": "Yes",
			"sourceRef": "d94a6108-e2d8-4920-b1b2-c528619ac7f2",
			"targetRef": "274e3e88-6e4c-4ef4-831e-51e6dd85a7c5"
		},
		"05cc7836-e46b-4b6a-9b14-8307fe7078b7": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow54",
			"name": "No",
			"sourceRef": "d94a6108-e2d8-4920-b1b2-c528619ac7f2",
			"targetRef": "8490c210-a2f6-45be-b54d-fbed78fbb978"
		},
		"d3602680-fe12-484b-8b75-389174bbafa0": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow55",
			"name": "SequenceFlow55",
			"sourceRef": "8490c210-a2f6-45be-b54d-fbed78fbb978",
			"targetRef": "4510f6bb-efd0-4b72-b846-5c8374a6c24c"
		},
		"c04947fd-a1a0-4d8c-8a6f-02735fc580eb": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isResourceProfile}",
			"id": "sequenceflow56",
			"name": "Yes",
			"sourceRef": "8a7fc8ce-e8c2-4200-b1e6-e670e600b32f",
			"targetRef": "19ab9486-10fc-491a-adb3-1a57f04318d7"
		},
		"5121690d-2600-428b-a4e8-6bd1243fe5f8": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow57",
			"name": "No",
			"sourceRef": "8a7fc8ce-e8c2-4200-b1e6-e670e600b32f",
			"targetRef": "0c4f1636-9279-472e-9abf-4610b6f29de8"
		},
		"588f44fd-21e6-4980-83c3-7e2d87059e9c": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow58",
			"name": "SequenceFlow58",
			"sourceRef": "0c4f1636-9279-472e-9abf-4610b6f29de8",
			"targetRef": "214d8e00-0a09-4a9d-9cf6-592cf643705c"
		},
		"638e472d-05ba-4b10-ab9f-ff65b59f18c5": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow59",
			"name": "SequenceFlow59",
			"sourceRef": "b8205b69-42e1-4fa4-b7f9-397f7391116d",
			"targetRef": "a8a7412f-1c9a-4d7c-9236-1dcb1319aaf1"
		},
		"24727bf7-8b7a-46c1-ae7e-4a3ba52c3e6a": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow62",
			"name": "No",
			"sourceRef": "beca4899-4b61-4fde-8151-f202d1db2ba7",
			"targetRef": "8a7fc8ce-e8c2-4200-b1e6-e670e600b32f"
		},
		"eb4a2fbf-34df-41f2-bea4-c2e5818638ea": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow63",
			"name": "No",
			"sourceRef": "756836dd-59b9-4056-a62e-32c60417cb81",
			"targetRef": "2798f4e7-bc42-4fad-a248-159095a2f40a"
		},
		"495b2320-e123-4258-a84d-920c0e50c9a5": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.deleteActvityList}",
			"id": "sequenceflow64",
			"name": "Yes",
			"sourceRef": "756836dd-59b9-4056-a62e-32c60417cb81",
			"targetRef": "3eebed83-ca32-4b92-a0a3-3e409b0d36d8"
		},
		"88c28f8f-9a75-4a47-b56c-62f6cad0bfb7": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow65",
			"name": "SequenceFlow65",
			"sourceRef": "3eebed83-ca32-4b92-a0a3-3e409b0d36d8",
			"targetRef": "2798f4e7-bc42-4fad-a248-159095a2f40a"
		},
		"4852ad78-4e78-43aa-9bc3-4afab793d582": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.deleteActvityList}",
			"id": "sequenceflow66",
			"name": "Yes",
			"sourceRef": "beca4899-4b61-4fde-8151-f202d1db2ba7",
			"targetRef": "b3b52f55-7ed3-4eea-bab4-867547e98fd0"
		},
		"33752f92-6237-4112-aa39-c66ca8a179cd": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow67",
			"name": "SequenceFlow67",
			"sourceRef": "b3b52f55-7ed3-4eea-bab4-867547e98fd0",
			"targetRef": "8a7fc8ce-e8c2-4200-b1e6-e670e600b32f"
		},
		"4cf9d317-6a6b-4441-8827-3f02fcd50a44": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow68",
			"name": "SequenceFlow68",
			"sourceRef": "da1a686d-5c4d-4949-8ba4-2628b470c140",
			"targetRef": "7379a9e1-faeb-4679-87f8-ae88e5d54d79"
		},
		"7bc4de2e-dd1c-4e14-9e8e-c4c50dc5db6e": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow69",
			"name": "SequenceFlow69",
			"sourceRef": "7379a9e1-faeb-4679-87f8-ae88e5d54d79",
			"targetRef": "2798f4e7-bc42-4fad-a248-159095a2f40a"
		},
		"e7e1a4e0-2783-40f4-b109-deb3ad30d171": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.NewRequest}",
			"id": "sequenceflow70",
			"name": "Yes",
			"sourceRef": "de0a8b6a-c6b1-4d3c-b106-7d8135e5bb78",
			"targetRef": "da1a686d-5c4d-4949-8ba4-2628b470c140"
		},
		"7dae2e9e-eb91-4e78-a1e9-e7f8d6bf9ea5": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow71",
			"name": "No",
			"sourceRef": "de0a8b6a-c6b1-4d3c-b106-7d8135e5bb78",
			"targetRef": "2798f4e7-bc42-4fad-a248-159095a2f40a"
		},
		"29adf2b8-3330-475f-8ee4-11d16f089357": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow74",
			"name": "SequenceFlow74",
			"sourceRef": "274e3e88-6e4c-4ef4-831e-51e6dd85a7c5",
			"targetRef": "32e4c5cd-c54e-462a-9913-7341ba388692"
		},
		"ff8b305f-9f7c-485e-bfd8-7299f02d04c3": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow75",
			"name": "SequenceFlow75",
			"sourceRef": "32e4c5cd-c54e-462a-9913-7341ba388692",
			"targetRef": "a63b187a-5f1f-40c8-bedd-a46b4a8d510d"
		},
		"ed429373-68d9-4609-99e5-4ec04c576245": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow76",
			"name": "SequenceFlow76",
			"sourceRef": "14089458-8940-4621-817d-da88209f2c4b",
			"targetRef": "d94a6108-e2d8-4920-b1b2-c528619ac7f2"
		},
		"c41f2da4-50d5-437f-92aa-00b20c8e2866": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow77",
			"name": "SequenceFlow77",
			"sourceRef": "9a3aaa67-24d3-4576-8013-e313460292ec",
			"targetRef": "b00fbd2e-3b77-4d4a-a188-a273f070bc03"
		},
		"ce36f30e-d962-412e-adcc-362c9178fee7": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow78",
			"name": "SequenceFlow78",
			"sourceRef": "b00fbd2e-3b77-4d4a-a188-a273f070bc03",
			"targetRef": "e315c185-2e77-413e-9638-76481488e4cb"
		},
		"5427d89f-a62a-4bd5-a6c6-f0acc66641cb": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow79",
			"name": "SequenceFlow79",
			"sourceRef": "e315c185-2e77-413e-9638-76481488e4cb",
			"targetRef": "0a21d22d-d581-4cc1-a836-8e56c5455dbc"
		},
		"81d01947-c49f-4961-9a8a-6bf1e1cb0f5b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.ResourceEmailNotif_flag}",
			"id": "sequenceflow80",
			"name": "yes",
			"sourceRef": "a63b187a-5f1f-40c8-bedd-a46b4a8d510d",
			"targetRef": "02cee87b-fbf5-4f04-beba-abe85ca92cca"
		},
		"e66d136c-c4e6-4794-ba66-4d4b38b5524d": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow81",
			"name": "No",
			"sourceRef": "a63b187a-5f1f-40c8-bedd-a46b4a8d510d",
			"targetRef": "4510f6bb-efd0-4b72-b846-5c8374a6c24c"
		},
		"d324ca29-aecc-4880-8169-dd84ead5bf3b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.ProcessorEmailNotif_flag}",
			"id": "sequenceflow82",
			"name": "yes",
			"sourceRef": "0a21d22d-d581-4cc1-a836-8e56c5455dbc",
			"targetRef": "6edbcce2-945d-460f-af4f-7ba2fb546403"
		},
		"14420dba-30a7-4d6e-a997-97e2a3b1c21b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow83",
			"name": "SequenceFlow83",
			"sourceRef": "0a21d22d-d581-4cc1-a836-8e56c5455dbc",
			"targetRef": "214d8e00-0a09-4a9d-9cf6-592cf643705c"
		},
		"62dacb45-e198-4ab6-837a-59d31ba5abd9": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow84",
			"name": "SequenceFlow84",
			"sourceRef": "19ab9486-10fc-491a-adb3-1a57f04318d7",
			"targetRef": "9a3aaa67-24d3-4576-8013-e313460292ec"
		},
		"42fa7a2d-c526-4a02-b3ba-49b5168ba644": {
			"classDefinition": "com.sap.bpm.wfs.ui.Diagram",
			"symbols": {
				"df898b52-91e1-4778-baad-2ad9a261d30e": {},
				"53e54950-7757-4161-82c9-afa7e86cff2c": {},
				"6bb141da-d485-4317-93b8-e17711df4c32": {},
				"76a9c944-9553-49a6-936c-8f0783213a72": {},
				"caffadf3-7417-48d2-8323-908779c6ef63": {},
				"736f2478-e19f-4d3b-b84c-483ac5f5fb1f": {},
				"f33c1b4f-f42a-4d65-ad68-021b969470d9": {},
				"8859d0bc-a1e6-4981-9052-173bf368f87f": {},
				"0f030749-5888-4a00-9219-e5452f26ac51": {},
				"640abf11-f029-44ad-b059-ec0624d0e374": {},
				"a16a89b4-7e8f-498a-ac54-d5eb7457421e": {},
				"88651092-afdf-4f6d-9ea1-d776c67f52b8": {},
				"59a74829-7d43-4fdc-a08c-a10e24387908": {},
				"3cf1c842-e4c7-46a7-bf84-25b22c675674": {},
				"1eb476ad-6f4c-4622-83fa-39c3af520ae0": {},
				"a31fbefe-70c3-4746-8efd-35b4aa35bc6b": {},
				"7a447769-d895-43d8-ac66-bc4af92451b4": {},
				"7666ff48-51b2-4b6a-8fa9-3bffc528f4a3": {},
				"5e4a2c6a-2f2d-4a11-a845-8c16e34010ca": {},
				"afa3178e-2cc1-44e0-bfed-68c25ffe9274": {},
				"43b14e4c-03ff-4103-b4d3-ff3a292800b8": {},
				"17a302c5-5bf3-4de1-a1c9-9e831498d9f2": {},
				"88767d31-bf2e-42ed-8643-2f148aa1c2fd": {},
				"1f7ac8b9-98af-4f4f-87e7-6e866fa97497": {},
				"e035a85f-ca3b-4d6f-b22c-ff4efbdd102d": {},
				"dbb477ac-d0e6-4e39-949a-e3f46b983f3d": {},
				"6cb05804-658b-4b9b-a87b-8ba39340f790": {},
				"da16369c-cf2f-413c-b949-edc9c661ecf4": {},
				"a33f9c9d-02d1-4bd2-b1c6-644754f7aa11": {},
				"d4985e42-3b31-4f51-b4e0-392d7be9aa91": {},
				"7923e1b1-cda0-44be-8807-66250111d24d": {},
				"177df4d6-51db-4a07-b95a-04e5b2c3b278": {},
				"76a95f41-9529-4bd1-bfb9-a2fd07871613": {},
				"fb2a44c9-f8ba-4532-831b-c287f58af8e6": {},
				"00484b9b-1f22-4057-9c63-efcb712d549c": {},
				"d850bb42-430b-43d3-8bac-7ec5c7d2a365": {},
				"54ac7c33-65cb-4f98-8c29-a7aad665f4b1": {},
				"bfb31ee9-3dc1-4d15-87ca-6aa217b2c57b": {},
				"b42ece3f-b0dd-4592-963d-f42ca5223c61": {},
				"e2ccc661-17fc-448e-9c2f-b2f76ba77585": {},
				"e5284d75-42ae-4b0a-aa52-7cd1d56108a5": {},
				"571e59d5-de28-40a8-92d6-fcc2e64adb15": {},
				"93a883fd-82d3-401f-bead-a44308801d94": {},
				"c232bb93-6edb-4c78-89f9-06415bf475ca": {},
				"065c3fe6-b6b9-4af9-9896-23470a1f50a9": {},
				"e609052a-f33a-4ce4-ac90-dc6d2a093ed5": {},
				"f9bbdac9-f2b4-4bda-b3ed-9a9a960dea35": {},
				"0d80af45-7adb-4e39-8d27-34c6feadb2ac": {},
				"0bf70d0e-d535-4beb-849b-238b292f407f": {},
				"0364d37d-0c0d-4c5a-a083-527f1566293c": {},
				"eac06030-610e-4852-8170-2fd33266cfbb": {},
				"13b7bdc8-c7fd-42e9-9c64-1bc1c615cab8": {},
				"c75489dd-0546-4ce7-bc62-04cce8209abc": {},
				"9acf62a1-657e-4940-8204-96f86dcb1bfb": {},
				"de448e57-473d-4639-b0ae-b3b02e198faa": {},
				"63e6e0de-6f20-4eb5-9d62-2b4faf78803f": {},
				"804fac8b-c2e6-4e36-9754-144f3980a20f": {},
				"0dd1db2f-42fa-4630-9399-ac6b2bf1804a": {},
				"c73d2224-7669-4eee-86c7-13d79a0ad774": {},
				"a524f629-a1e7-47a5-b35a-6dcfd1311eab": {},
				"393130f1-0469-4357-b7e8-c8a4bcc56f6a": {},
				"01054669-8147-4840-b961-3342fee36d34": {},
				"309d5a8f-5ede-4106-9161-8a2820320ae4": {},
				"6917e9cb-b8c0-4839-b6ed-9229b3096366": {},
				"eff51212-039b-4334-b1d7-e72af29cb4a2": {},
				"a0bb657e-62c3-4be9-9813-a2ab1027c954": {},
				"759a896a-7102-445a-bd03-af6376ca2e1e": {},
				"64282813-cf58-484e-bc58-a8de5ff95201": {},
				"916e6dba-b366-47f2-89c9-efb0f28f98f0": {},
				"90cb5fa6-a8ed-40f4-81b1-ca4ec8f61222": {},
				"bec12255-b1cd-4052-8f65-cda2d07b0e66": {},
				"a6c95416-c1f5-4071-a3dc-6fe81b8abc2d": {},
				"e986c6cf-9a5e-41b1-ac4d-1a3bf6e4bc0c": {},
				"bc9aaab5-82c6-4c33-b8b3-e56dc05cea14": {},
				"f7f8bc0c-2da4-442e-89e3-37f4d0cbe722": {},
				"108ea90e-c434-4f42-ba64-90d46ad69ef7": {},
				"e98115e7-6b64-4f6c-b9f9-58f73a0195ec": {},
				"70696fa6-8170-45cf-bad7-b957afa13deb": {},
				"6fe7359d-8456-4cd4-b258-76123023f858": {},
				"68f44d15-b9ea-439a-ab0f-2b8130dcb94b": {},
				"72fcfedf-ae5f-4736-a9b7-73317486ab9b": {},
				"b9c9a8cd-857f-4e2b-bbb4-922bc16a452e": {},
				"467e405b-e307-487d-9391-c4f46501a19b": {},
				"0d279f79-8759-410b-beab-fcc3994a8f3c": {},
				"8500002d-9edc-4289-a23d-995b5793787c": {},
				"393a823b-b154-44e5-85b0-42bb691bc763": {},
				"f10f506a-6168-4486-860c-0614211dc6c4": {}
			}
		},
		"df898b52-91e1-4778-baad-2ad9a261d30e": {
			"classDefinition": "com.sap.bpm.wfs.ui.StartEventSymbol",
			"x": -1089,
			"y": 101,
			"width": 32,
			"height": 32,
			"object": "11a9b5ee-17c0-4159-9bbf-454dcfdcd5c3"
		},
		"53e54950-7757-4161-82c9-afa7e86cff2c": {
			"classDefinition": "com.sap.bpm.wfs.ui.EndEventSymbol",
			"x": 2466,
			"y": 107,
			"width": 35,
			"height": 35,
			"object": "2798f4e7-bc42-4fad-a248-159095a2f40a"
		},
		"6bb141da-d485-4317-93b8-e17711df4c32": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1073,117 -979,117",
			"sourceSymbol": "df898b52-91e1-4778-baad-2ad9a261d30e",
			"targetSymbol": "736f2478-e19f-4d3b-b84c-483ac5f5fb1f",
			"object": "c6b99f32-5fe6-4ab6-b60a-80fba1b9ae0f"
		},
		"76a9c944-9553-49a6-936c-8f0783213a72": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": -438,
			"y": 87,
			"width": 100,
			"height": 60,
			"object": "02cee87b-fbf5-4f04-beba-abe85ca92cca"
		},
		"caffadf3-7417-48d2-8323-908779c6ef63": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-388,117 -245,117",
			"sourceSymbol": "76a9c944-9553-49a6-936c-8f0783213a72",
			"targetSymbol": "f33c1b4f-f42a-4d65-ad68-021b969470d9",
			"object": "34051c3e-abaf-47f1-9791-6aae0a39af1b"
		},
		"736f2478-e19f-4d3b-b84c-483ac5f5fb1f": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -1029,
			"y": 87,
			"width": 100,
			"height": 60,
			"object": "14089458-8940-4621-817d-da88209f2c4b"
		},
		"f33c1b4f-f42a-4d65-ad68-021b969470d9": {
			"classDefinition": "com.sap.bpm.wfs.ui.UserTaskSymbol",
			"x": -295,
			"y": 87,
			"width": 100,
			"height": 60,
			"object": "4510f6bb-efd0-4b72-b846-5c8374a6c24c"
		},
		"8859d0bc-a1e6-4981-9052-173bf368f87f": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-245,117 -53,117",
			"sourceSymbol": "f33c1b4f-f42a-4d65-ad68-021b969470d9",
			"targetSymbol": "a33f9c9d-02d1-4bd2-b1c6-644754f7aa11",
			"object": "a8b3d8e1-df6e-4195-926b-a29120840cd0"
		},
		"0f030749-5888-4a00-9219-e5452f26ac51": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 1113,
			"y": 87,
			"object": "7e1f6577-bca2-4429-a795-ffc0757f3a36"
		},
		"640abf11-f029-44ad-b059-ec0624d0e374": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1134,106 1452.5,106 1452.5,127 1771,127",
			"sourceSymbol": "0f030749-5888-4a00-9219-e5452f26ac51",
			"targetSymbol": "a0bb657e-62c3-4be9-9813-a2ab1027c954",
			"object": "0ce50fb9-721a-4f08-9412-e8e4a5fa5baa"
		},
		"a16a89b4-7e8f-498a-ac54-d5eb7457421e": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1132,108 1132,-119 1993,-119",
			"sourceSymbol": "0f030749-5888-4a00-9219-e5452f26ac51",
			"targetSymbol": "9acf62a1-657e-4940-8204-96f86dcb1bfb",
			"object": "b1dd1a05-34e9-4a19-9ded-b40694ab794a"
		},
		"88651092-afdf-4f6d-9ea1-d776c67f52b8": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": 1685,
			"y": 426,
			"width": 100,
			"height": 60,
			"object": "6edbcce2-945d-460f-af4f-7ba2fb546403"
		},
		"59a74829-7d43-4fdc-a08c-a10e24387908": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1132,108 1132,228",
			"sourceSymbol": "0f030749-5888-4a00-9219-e5452f26ac51",
			"targetSymbol": "13b7bdc8-c7fd-42e9-9c64-1bc1c615cab8",
			"object": "b8b2e870-3dd1-404a-b7ac-1f2f3fded5ce"
		},
		"3cf1c842-e4c7-46a7-bf84-25b22c675674": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1735,456 1860,456",
			"sourceSymbol": "88651092-afdf-4f6d-9ea1-d776c67f52b8",
			"targetSymbol": "1eb476ad-6f4c-4622-83fa-39c3af520ae0",
			"object": "ff89babf-b61a-4f0c-baf1-7f2c726a14d8"
		},
		"1eb476ad-6f4c-4622-83fa-39c3af520ae0": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 1810,
			"y": 426,
			"width": 100,
			"height": 60,
			"object": "214d8e00-0a09-4a9d-9cf6-592cf643705c"
		},
		"a31fbefe-70c3-4746-8efd-35b4aa35bc6b": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1860,456 1993,456",
			"sourceSymbol": "1eb476ad-6f4c-4622-83fa-39c3af520ae0",
			"targetSymbol": "7a447769-d895-43d8-ac66-bc4af92451b4",
			"object": "1ecc1d60-f8eb-417e-97ab-25ae6d61a6a8"
		},
		"7a447769-d895-43d8-ac66-bc4af92451b4": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 1943,
			"y": 426,
			"width": 100,
			"height": 60,
			"object": "af509d04-1d5d-4dba-a9a4-72fe260bcd24"
		},
		"7666ff48-51b2-4b6a-8fa9-3bffc528f4a3": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1993,456 2111,456",
			"sourceSymbol": "7a447769-d895-43d8-ac66-bc4af92451b4",
			"targetSymbol": "5e4a2c6a-2f2d-4a11-a845-8c16e34010ca",
			"object": "933e4603-68f8-4257-87ad-5a11d6ca713a"
		},
		"5e4a2c6a-2f2d-4a11-a845-8c16e34010ca": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 2061,
			"y": 426,
			"width": 100,
			"height": 60,
			"object": "de7988d8-145b-4d17-9fea-61059b175820"
		},
		"afa3178e-2cc1-44e0-bfed-68c25ffe9274": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 2192,
			"y": 426,
			"width": 100,
			"height": 60,
			"object": "e0265025-8e37-495b-b48e-1a78ea457451"
		},
		"43b14e4c-03ff-4103-b4d3-ff3a292800b8": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 2341,
			"y": 435,
			"object": "84330708-bf74-4b3c-8a91-d1482c13d8f2"
		},
		"17a302c5-5bf3-4de1-a1c9-9e831498d9f2": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 2463,
			"y": 435,
			"object": "d8bd1025-a7ec-46ef-a175-e5b74eb07b1f"
		},
		"88767d31-bf2e-42ed-8643-2f148aa1c2fd": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "2362,476.5 2362,536.5 2242,536.5 2242,485.5",
			"sourceSymbol": "43b14e4c-03ff-4103-b4d3-ff3a292800b8",
			"targetSymbol": "afa3178e-2cc1-44e0-bfed-68c25ffe9274",
			"object": "4b9a4283-8481-4eaf-bf71-4ebff94d1d3d"
		},
		"1f7ac8b9-98af-4f4f-87e7-6e866fa97497": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "2160.5,456 2192.5,456",
			"sourceSymbol": "5e4a2c6a-2f2d-4a11-a845-8c16e34010ca",
			"targetSymbol": "afa3178e-2cc1-44e0-bfed-68c25ffe9274",
			"object": "3d12c092-a2f1-4cbe-8c16-b478cec1a83e"
		},
		"e035a85f-ca3b-4d6f-b22c-ff4efbdd102d": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "2291.5,456 2349,456",
			"sourceSymbol": "afa3178e-2cc1-44e0-bfed-68c25ffe9274",
			"targetSymbol": "43b14e4c-03ff-4103-b4d3-ff3a292800b8",
			"object": "2a6e1437-3647-42be-980b-ea2bf6cf4337"
		},
		"dbb477ac-d0e6-4e39-949a-e3f46b983f3d": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "2382.5,456 2463.5,456",
			"sourceSymbol": "43b14e4c-03ff-4103-b4d3-ff3a292800b8",
			"targetSymbol": "17a302c5-5bf3-4de1-a1c9-9e831498d9f2",
			"object": "5493dbb1-f0da-412c-9f00-de5d75d9dbb8"
		},
		"6cb05804-658b-4b9b-a87b-8ba39340f790": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "2483.75,456 2483.75,141.5",
			"sourceSymbol": "17a302c5-5bf3-4de1-a1c9-9e831498d9f2",
			"targetSymbol": "53e54950-7757-4161-82c9-afa7e86cff2c",
			"object": "a17e1efa-a6c3-4b6d-9f8c-8853ff8f2093"
		},
		"da16369c-cf2f-413c-b949-edc9c661ecf4": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "2484,476.5 2484,598 -245,598 -245,146.5",
			"sourceSymbol": "17a302c5-5bf3-4de1-a1c9-9e831498d9f2",
			"targetSymbol": "f33c1b4f-f42a-4d65-ad68-021b969470d9",
			"object": "adb2a1cb-02bf-4e5b-b679-8a7998140bae"
		},
		"a33f9c9d-02d1-4bd2-b1c6-644754f7aa11": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -103,
			"y": 87,
			"width": 100,
			"height": 60,
			"object": "ed106f0e-a0b1-4220-9e9f-686487bd56d1"
		},
		"d4985e42-3b31-4f51-b4e0-392d7be9aa91": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-53,117 126,117",
			"sourceSymbol": "a33f9c9d-02d1-4bd2-b1c6-644754f7aa11",
			"targetSymbol": "0364d37d-0c0d-4c5a-a083-527f1566293c",
			"object": "be674fda-109f-4464-acdd-eec8aae34864"
		},
		"7923e1b1-cda0-44be-8807-66250111d24d": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 264,
			"y": 87,
			"width": 100,
			"height": 60,
			"object": "a8a7412f-1c9a-4d7c-9236-1dcb1319aaf1"
		},
		"177df4d6-51db-4a07-b95a-04e5b2c3b278": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "314,117 452,117",
			"sourceSymbol": "7923e1b1-cda0-44be-8807-66250111d24d",
			"targetSymbol": "00484b9b-1f22-4057-9c63-efcb712d549c",
			"object": "28aa0537-532b-4ee2-bf44-35cd8aa10166"
		},
		"76a95f41-9529-4bd1-bfb9-a2fd07871613": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 649,
			"y": 87,
			"width": 100,
			"height": 60,
			"object": "54190a97-7e3a-41cb-a39e-447bf534e5ea"
		},
		"fb2a44c9-f8ba-4532-831b-c287f58af8e6": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "699,117 931.25,117 931.25,108 1134,108",
			"sourceSymbol": "76a95f41-9529-4bd1-bfb9-a2fd07871613",
			"targetSymbol": "0f030749-5888-4a00-9219-e5452f26ac51",
			"object": "1861fe72-b085-4173-b07d-3d297a4c9b8f"
		},
		"00484b9b-1f22-4057-9c63-efcb712d549c": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 402,
			"y": 87,
			"width": 100,
			"height": 60,
			"object": "47401a69-0537-48eb-8903-edd1fb99f13b"
		},
		"d850bb42-430b-43d3-8bac-7ec5c7d2a365": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "452,119 571,119",
			"sourceSymbol": "00484b9b-1f22-4057-9c63-efcb712d549c",
			"targetSymbol": "54ac7c33-65cb-4f98-8c29-a7aad665f4b1",
			"object": "b8e63169-7bb2-4fe3-915f-53196d38ed92"
		},
		"54ac7c33-65cb-4f98-8c29-a7aad665f4b1": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 550,
			"y": 100,
			"object": "a07d59af-1ac7-4a02-a245-4b3a872af66d"
		},
		"bfb31ee9-3dc1-4d15-87ca-6aa217b2c57b": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "571,119 699,119",
			"sourceSymbol": "54ac7c33-65cb-4f98-8c29-a7aad665f4b1",
			"targetSymbol": "76a95f41-9529-4bd1-bfb9-a2fd07871613",
			"object": "bf9741e2-107a-482c-a41f-092aa7428993"
		},
		"b42ece3f-b0dd-4592-963d-f42ca5223c61": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "571,100.5 571,50 943,50 943,108 1113.5,108",
			"sourceSymbol": "54ac7c33-65cb-4f98-8c29-a7aad665f4b1",
			"targetSymbol": "0f030749-5888-4a00-9219-e5452f26ac51",
			"object": "025aca44-a8b5-41bc-b90e-4d47b7dee35a"
		},
		"e2ccc661-17fc-448e-9c2f-b2f76ba77585": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -848,
			"y": 96,
			"object": "d94a6108-e2d8-4920-b1b2-c528619ac7f2"
		},
		"e5284d75-42ae-4b0a-aa52-7cd1d56108a5": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-827,117 -720,117",
			"sourceSymbol": "e2ccc661-17fc-448e-9c2f-b2f76ba77585",
			"targetSymbol": "916e6dba-b366-47f2-89c9-efb0f28f98f0",
			"object": "f39393e3-4c67-48b5-b9e0-c840b7dee493"
		},
		"571e59d5-de28-40a8-92d6-fcc2e64adb15": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-820,117 -820,275 -572,275",
			"sourceSymbol": "e2ccc661-17fc-448e-9c2f-b2f76ba77585",
			"targetSymbol": "93a883fd-82d3-401f-bead-a44308801d94",
			"object": "05cc7836-e46b-4b6a-9b14-8307fe7078b7"
		},
		"93a883fd-82d3-401f-bead-a44308801d94": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": -622,
			"y": 239,
			"width": 100,
			"height": 60,
			"object": "8490c210-a2f6-45be-b54d-fbed78fbb978"
		},
		"c232bb93-6edb-4c78-89f9-06415bf475ca": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-572,269 -244,269 -244,117",
			"sourceSymbol": "93a883fd-82d3-401f-bead-a44308801d94",
			"targetSymbol": "f33c1b4f-f42a-4d65-ad68-021b969470d9",
			"object": "d3602680-fe12-484b-8b75-389174bbafa0"
		},
		"065c3fe6-b6b9-4af9-9896-23470a1f50a9": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 1113,
			"y": 335,
			"object": "8a7fc8ce-e8c2-4200-b1e6-e670e600b32f"
		},
		"e609052a-f33a-4ce4-ac90-dc6d2a093ed5": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1134,356 1063,356 1063,464 1140,464",
			"sourceSymbol": "065c3fe6-b6b9-4af9-9896-23470a1f50a9",
			"targetSymbol": "393a823b-b154-44e5-85b0-42bb691bc763",
			"object": "c04947fd-a1a0-4d8c-8a6f-02735fc580eb"
		},
		"f9bbdac9-f2b4-4bda-b3ed-9a9a960dea35": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1134,358 1482.5,358 1482.5,349 1860,349",
			"sourceSymbol": "065c3fe6-b6b9-4af9-9896-23470a1f50a9",
			"targetSymbol": "0d80af45-7adb-4e39-8d27-34c6feadb2ac",
			"object": "5121690d-2600-428b-a4e8-6bd1243fe5f8"
		},
		"0d80af45-7adb-4e39-8d27-34c6feadb2ac": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": 1810,
			"y": 326,
			"width": 100,
			"height": 60,
			"object": "0c4f1636-9279-472e-9abf-4610b6f29de8"
		},
		"0bf70d0e-d535-4beb-849b-238b292f407f": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1860,356 1860,456",
			"sourceSymbol": "0d80af45-7adb-4e39-8d27-34c6feadb2ac",
			"targetSymbol": "1eb476ad-6f4c-4622-83fa-39c3af520ae0",
			"object": "588f44fd-21e6-4980-83c3-7e2d87059e9c"
		},
		"0364d37d-0c0d-4c5a-a083-527f1566293c": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 76,
			"y": 87,
			"width": 100,
			"height": 60,
			"object": "b8205b69-42e1-4fa4-b7f9-397f7391116d"
		},
		"eac06030-610e-4852-8170-2fd33266cfbb": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "126,117 314,117",
			"sourceSymbol": "0364d37d-0c0d-4c5a-a083-527f1566293c",
			"targetSymbol": "7923e1b1-cda0-44be-8807-66250111d24d",
			"object": "638e472d-05ba-4b10-ab9f-ff65b59f18c5"
		},
		"13b7bdc8-c7fd-42e9-9c64-1bc1c615cab8": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 1109,
			"y": 207,
			"object": "beca4899-4b61-4fde-8151-f202d1db2ba7"
		},
		"c75489dd-0546-4ce7-bc62-04cce8209abc": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1132,228 1132,356",
			"sourceSymbol": "13b7bdc8-c7fd-42e9-9c64-1bc1c615cab8",
			"targetSymbol": "065c3fe6-b6b9-4af9-9896-23470a1f50a9",
			"object": "24727bf7-8b7a-46c1-ae7e-4a3ba52c3e6a"
		},
		"9acf62a1-657e-4940-8204-96f86dcb1bfb": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 1972,
			"y": -140,
			"object": "756836dd-59b9-4056-a62e-32c60417cb81"
		},
		"de448e57-473d-4639-b0ae-b3b02e198faa": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1993,-119 2480,-119 2480,124.5",
			"sourceSymbol": "9acf62a1-657e-4940-8204-96f86dcb1bfb",
			"targetSymbol": "53e54950-7757-4161-82c9-afa7e86cff2c",
			"object": "eb4a2fbf-34df-41f2-bea4-c2e5818638ea"
		},
		"63e6e0de-6f20-4eb5-9d62-2b4faf78803f": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 1943,
			"y": -20,
			"width": 100,
			"height": 60,
			"object": "3eebed83-ca32-4b92-a0a3-3e409b0d36d8"
		},
		"804fac8b-c2e6-4e36-9754-144f3980a20f": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 939,
			"y": 198,
			"width": 100,
			"height": 60,
			"object": "b3b52f55-7ed3-4eea-bab4-867547e98fd0"
		},
		"0dd1db2f-42fa-4630-9399-ac6b2bf1804a": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1993,-119 1993,0",
			"sourceSymbol": "9acf62a1-657e-4940-8204-96f86dcb1bfb",
			"targetSymbol": "63e6e0de-6f20-4eb5-9d62-2b4faf78803f",
			"object": "495b2320-e123-4258-a84d-920c0e50c9a5"
		},
		"c73d2224-7669-4eee-86c7-13d79a0ad774": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "2042.5,10 2480,10 2480,107.5",
			"sourceSymbol": "63e6e0de-6f20-4eb5-9d62-2b4faf78803f",
			"targetSymbol": "53e54950-7757-4161-82c9-afa7e86cff2c",
			"object": "88c28f8f-9a75-4a47-b56c-62f6cad0bfb7"
		},
		"a524f629-a1e7-47a5-b35a-6dcfd1311eab": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1109.5,228 1031,228",
			"sourceSymbol": "13b7bdc8-c7fd-42e9-9c64-1bc1c615cab8",
			"targetSymbol": "804fac8b-c2e6-4e36-9754-144f3980a20f",
			"object": "4852ad78-4e78-43aa-9bc3-4afab793d582"
		},
		"393130f1-0469-4357-b7e8-c8a4bcc56f6a": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "989,257.5 989,356 1113.5,356",
			"sourceSymbol": "804fac8b-c2e6-4e36-9754-144f3980a20f",
			"targetSymbol": "065c3fe6-b6b9-4af9-9896-23470a1f50a9",
			"object": "33752f92-6237-4112-aa39-c66ca8a179cd"
		},
		"01054669-8147-4840-b961-3342fee36d34": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 1872,
			"y": 90,
			"width": 100,
			"height": 60,
			"object": "da1a686d-5c4d-4949-8ba4-2628b470c140"
		},
		"309d5a8f-5ede-4106-9161-8a2820320ae4": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1922,120 2085,120",
			"sourceSymbol": "01054669-8147-4840-b961-3342fee36d34",
			"targetSymbol": "6917e9cb-b8c0-4839-b6ed-9229b3096366",
			"object": "4cf9d317-6a6b-4441-8827-3f02fcd50a44"
		},
		"6917e9cb-b8c0-4839-b6ed-9229b3096366": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 2035,
			"y": 90,
			"width": 100,
			"height": 60,
			"object": "7379a9e1-faeb-4679-87f8-ae88e5d54d79"
		},
		"eff51212-039b-4334-b1d7-e72af29cb4a2": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "2085,115 2483.5,115",
			"sourceSymbol": "6917e9cb-b8c0-4839-b6ed-9229b3096366",
			"targetSymbol": "53e54950-7757-4161-82c9-afa7e86cff2c",
			"object": "7bc4de2e-dd1c-4e14-9e8e-c4c50dc5db6e"
		},
		"a0bb657e-62c3-4be9-9813-a2ab1027c954": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 1750,
			"y": 104,
			"object": "de0a8b6a-c6b1-4d3c-b106-7d8135e5bb78"
		},
		"759a896a-7102-445a-bd03-af6376ca2e1e": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1771,122.5 1922,122.5",
			"sourceSymbol": "a0bb657e-62c3-4be9-9813-a2ab1027c954",
			"targetSymbol": "01054669-8147-4840-b961-3342fee36d34",
			"object": "e7e1a4e0-2783-40f4-b109-deb3ad30d171"
		},
		"64282813-cf58-484e-bc58-a8de5ff95201": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1768,131 1768,190 2482,190 2482,131",
			"sourceSymbol": "a0bb657e-62c3-4be9-9813-a2ab1027c954",
			"targetSymbol": "53e54950-7757-4161-82c9-afa7e86cff2c",
			"object": "7dae2e9e-eb91-4e78-a1e9-e7f8d6bf9ea5"
		},
		"916e6dba-b366-47f2-89c9-efb0f28f98f0": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -770,
			"y": 87,
			"width": 100,
			"height": 60,
			"object": "274e3e88-6e4c-4ef4-831e-51e6dd85a7c5"
		},
		"90cb5fa6-a8ed-40f4-81b1-ca4ec8f61222": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -649,
			"y": 87,
			"width": 100,
			"height": 60,
			"object": "32e4c5cd-c54e-462a-9913-7341ba388692"
		},
		"bec12255-b1cd-4052-8f65-cda2d07b0e66": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-720,117 -599,117",
			"sourceSymbol": "916e6dba-b366-47f2-89c9-efb0f28f98f0",
			"targetSymbol": "90cb5fa6-a8ed-40f4-81b1-ca4ec8f61222",
			"object": "29adf2b8-3330-475f-8ee4-11d16f089357"
		},
		"a6c95416-c1f5-4071-a3dc-6fe81b8abc2d": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-599,115 -497,115",
			"sourceSymbol": "90cb5fa6-a8ed-40f4-81b1-ca4ec8f61222",
			"targetSymbol": "68f44d15-b9ea-439a-ab0f-2b8130dcb94b",
			"object": "ff8b305f-9f7c-485e-bfd8-7299f02d04c3"
		},
		"e986c6cf-9a5e-41b1-ac4d-1a3bf6e4bc0c": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-940,112 -842,112",
			"sourceSymbol": "736f2478-e19f-4d3b-b84c-483ac5f5fb1f",
			"targetSymbol": "e2ccc661-17fc-448e-9c2f-b2f76ba77585",
			"object": "ed429373-68d9-4609-99e5-4ec04c576245"
		},
		"bc9aaab5-82c6-4c33-b8b3-e56dc05cea14": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 1230,
			"y": 430,
			"width": 100,
			"height": 60,
			"object": "9a3aaa67-24d3-4576-8013-e313460292ec"
		},
		"f7f8bc0c-2da4-442e-89e3-37f4d0cbe722": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1280,458 1401,458",
			"sourceSymbol": "bc9aaab5-82c6-4c33-b8b3-e56dc05cea14",
			"targetSymbol": "108ea90e-c434-4f42-ba64-90d46ad69ef7",
			"object": "c41f2da4-50d5-437f-92aa-00b20c8e2866"
		},
		"108ea90e-c434-4f42-ba64-90d46ad69ef7": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 1351,
			"y": 426,
			"width": 100,
			"height": 60,
			"object": "b00fbd2e-3b77-4d4a-a188-a273f070bc03"
		},
		"e98115e7-6b64-4f6c-b9f9-58f73a0195ec": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1401,458 1522,458",
			"sourceSymbol": "108ea90e-c434-4f42-ba64-90d46ad69ef7",
			"targetSymbol": "70696fa6-8170-45cf-bad7-b957afa13deb",
			"object": "ce36f30e-d962-412e-adcc-362c9178fee7"
		},
		"70696fa6-8170-45cf-bad7-b957afa13deb": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 1472,
			"y": 430,
			"width": 100,
			"height": 60,
			"object": "e315c185-2e77-413e-9638-76481488e4cb"
		},
		"6fe7359d-8456-4cd4-b258-76123023f858": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1522,458 1608,458",
			"sourceSymbol": "70696fa6-8170-45cf-bad7-b957afa13deb",
			"targetSymbol": "467e405b-e307-487d-9391-c4f46501a19b",
			"object": "5427d89f-a62a-4bd5-a6c6-f0acc66641cb"
		},
		"68f44d15-b9ea-439a-ab0f-2b8130dcb94b": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -518,
			"y": 92,
			"object": "a63b187a-5f1f-40c8-bedd-a46b4a8d510d"
		},
		"72fcfedf-ae5f-4736-a9b7-73317486ab9b": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-497,115 -388,115",
			"sourceSymbol": "68f44d15-b9ea-439a-ab0f-2b8130dcb94b",
			"targetSymbol": "76a9c944-9553-49a6-936c-8f0783213a72",
			"object": "81d01947-c49f-4961-9a8a-6bf1e1cb0f5b"
		},
		"b9c9a8cd-857f-4e2b-bbb4-922bc16a452e": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-497,113 -497,215 -266,215 -266,113",
			"sourceSymbol": "68f44d15-b9ea-439a-ab0f-2b8130dcb94b",
			"targetSymbol": "f33c1b4f-f42a-4d65-ad68-021b969470d9",
			"object": "e66d136c-c4e6-4794-ba66-4d4b38b5524d"
		},
		"467e405b-e307-487d-9391-c4f46501a19b": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 1587,
			"y": 435,
			"object": "0a21d22d-d581-4cc1-a836-8e56c5455dbc"
		},
		"0d279f79-8759-410b-beab-fcc3994a8f3c": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1608,456 1735,456",
			"sourceSymbol": "467e405b-e307-487d-9391-c4f46501a19b",
			"targetSymbol": "88651092-afdf-4f6d-9ea1-d776c67f52b8",
			"object": "d324ca29-aecc-4880-8169-dd84ead5bf3b"
		},
		"8500002d-9edc-4289-a23d-995b5793787c": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1629,462 1629,543 1809.5,543 1809.5,462",
			"sourceSymbol": "467e405b-e307-487d-9391-c4f46501a19b",
			"targetSymbol": "1eb476ad-6f4c-4622-83fa-39c3af520ae0",
			"object": "14420dba-30a7-4d6e-a997-97e2a3b1c21b"
		},
		"393a823b-b154-44e5-85b0-42bb691bc763": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 1090,
			"y": 426,
			"width": 100,
			"height": 60,
			"object": "19ab9486-10fc-491a-adb3-1a57f04318d7"
		},
		"f10f506a-6168-4486-860c-0614211dc6c4": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1140,458 1280,458",
			"sourceSymbol": "393a823b-b154-44e5-85b0-42bb691bc763",
			"targetSymbol": "bc9aaab5-82c6-4c33-b8b3-e56dc05cea14",
			"object": "62dacb45-e198-4ab6-837a-59d31ba5abd9"
		},
		"62d7f4ed-4063-4c44-af8b-39050bd44926": {
			"classDefinition": "com.sap.bpm.wfs.LastIDs",
			"maildefinition": 6,
			"sequenceflow": 84,
			"startevent": 1,
			"endevent": 1,
			"usertask": 1,
			"servicetask": 15,
			"scripttask": 19,
			"mailtask": 7,
			"exclusivegateway": 16,
			"parallelgateway": 1
		},
		"942bbcfb-f289-45fb-957a-77dc3b495564": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition1",
			"to": "${context.ResourceEmail_Notif}",
			"cc": "",
			"subject": "Melody Request - Action Required ${context.RequestID.value} - ${context.EmailTemplateVars.EmailSubject}",
			"reference": "/webcontent/Resource_review.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition1"
		},
		"6f0465ef-313f-4927-b02a-6a806acf07f6": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition3",
			"to": "${context.ProcessorEmail_Notif}",
			"subject": "Melody Request - Action Required ${context.RequestID.value} - ${context.EmailTemplateVars.EmailSubject}",
			"reference": "/webcontent/Resource_Rejection.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition3"
		},
		"aad90f77-7426-4c10-abfc-96729adcbf30": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition5",
			"to": "${context.NominatedResourcesEmails}",
			"cc": "",
			"subject": "Melody Request ${context.RequestID.value} is waiting for review - System Generated Email",
			"reference": "/webcontent/Resource_reqArea_review.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition5"
		},
		"fc5c3e54-80e1-45dd-ae7b-68d67938ef2c": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition6",
			"to": "${context.approverData.email}",
			"subject": "Melody Request ${context.RequestID.value} has been Sent back to Processor - System Generated Email",
			"reference": "/webcontent/Resource_Rejection_RA.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition6"
		}
	}
}