sap.ui.define([
	"com/sap/bpm/IOownerForm/test/unit/controller/App.controller"
], function () {
	"use strict";
});
