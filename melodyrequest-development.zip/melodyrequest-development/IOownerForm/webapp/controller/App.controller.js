sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/ui/core/format/DateFormat",
    "com/sap/bpm/IOownerForm/model/formatter",
    "sap/m/MessageBox",
    "com/sap/bpm/IOownerForm/model/models",
    "sap/m/Dialog",
    "sap/m/DialogType",
    "sap/m/Button",
    "sap/m/ButtonType",
    "sap/ui/core/syncStyleClass",
    "sap/m/TextArea",
    "sap/ui/core/Fragment"
], function (BaseController, JSONModel, MessageToast, DateFormat, formatter, MessageBox, Models,Dialog,DialogType,Button,ButtonType,syncStyleClass,TextArea,Fragment) {
    var workflowInstanceId,
        token;
    "use strict";
    return BaseController.extend("com.sap.bpm.IOownerForm.controller.App", {
        formatter: formatter,

        onAfterRendering: function(){
            var that = this;
            setTimeout(function(that) {
                const oDetailView = that.getComponentData().inboxHandle.inboxDetailView;
                const aFooterBtns = oDetailView.getView().getContent()[0].getFooter().getContentRight();
                const aClaimBtn = aFooterBtns.filter((btn) => btn.getText() === "Claim");
                let oAppConstantsModel = that.getOwnerComponent().getModel("appConstants");
                let sDownTimeFlag = oAppConstantsModel.getProperty("/DownTime/0/Operational_Status");
                if (sDownTimeFlag) {
                    oDetailView.getView().getContent()[0].setFooter(false);
                }
                if (aClaimBtn.length) {
                    aClaimBtn[0].setVisible(false);
                }
                oDetailView.getView().byId("myInbox_SHARE").setVisible(false);
                oDetailView.getView().byId("LogButtonID").setVisible(false);
            }, 1000, this);
        },

        onInit: function () {
            this.getContentDensityClass();
            let oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
            let sDownTimeFlag = oAppConstantsModel.getProperty("/DownTime/0/Operational_Status");
            if (!sDownTimeFlag) {
            //add OrgId,OrgType,RequestType for older tasks
            if (typeof (this.getModel().getData()["SalesOrgID"]) === "string") {
                this.getModel().getData()["OrgID"] = this.getModel().getData()["SalesOrgID"];
                this.getModel().getData()["OrgType"] = "SORG";
                this.getModel().getData()["RequestType"] = "Opportunity"
            }
            if(!this.getModel().getProperty("/currentStepID") && this.getModel().getProperty("/currentStepName") === "Presales Manager Approval"){
                this.getModel().setProperty("/currentStepID","MANAPP")
            }
            // document service interaction
            this.oAttachmentsModel = new JSONModel();
            this.oAttachmentsModel.downloadEnabled = false;
            this.setModel(this.oAttachmentsModel, "attachmentsModel");
           // this.loadAttachments();
            var oModel = this.getModel();
            if(oModel.getProperty("/approvalHistory")){
                oModel.getProperty("/approvalHistory").reverse();
            }
            oModel.setProperty("/namesOfPartiesVisible", false);
            var aInvolvedPartiesKeys = oModel.getProperty("/requestDetails/involvedPartiesKeys");
            if (aInvolvedPartiesKeys && aInvolvedPartiesKeys.length > 0) {
                if (aInvolvedPartiesKeys.includes("1") || aInvolvedPartiesKeys.includes("2") || aInvolvedPartiesKeys.includes("3")) { // if SAP Partner, SAP Consulting or Customer Advisory is selected
                    oModel.setProperty("/namesOfPartiesVisible", true);
                }
            }
            this.parseGetOppDataResponse(this.getModel().getProperty("/CPICalls/getDataFromCRM/Response/d/"));
            this._fetchFormActions(this);
            this.configureView(this.getModel().getProperty("/currentStepID"));
            this.i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();

            const oReqAreaModel = new JSONModel(this._getRequestAreaBaseURL());
            this.getView().setModel(oReqAreaModel, "RequestAreaAPIData");

            const oConstantsModel = new JSONModel(this._getConstantsBaseURL());
            this.getView().setModel(oConstantsModel, "ConstantsAPIData");

            const oRejectionCodeModel = new JSONModel(this._getRejectionCodeBaseURL());
            this.getView().setModel(oRejectionCodeModel, "RejectionCodeAPIData");

            /* Start of Code for CurrentTask Instance ID Update  */
            this.updateCurrentInstance();
            /* End of Code for CurrentTask Instance ID Update  */

            this._initializeAssignments();

            this._fetchFormConfigData(this);

                //setAttachment url visibility
                if (this.getModel().getProperty("/requestDetails/attachmentUrls")) {
                    const bAttachmentUrl = this.getModel().getProperty("/requestDetails/attachmentUrls").length ? true : false;
                    this.getModel().setProperty("/isAttachmentUrl", bAttachmentUrl);
                    if (bAttachmentUrl) {
                        const aFinalAttachmentUrl = this.getView().getModel().getProperty("/requestDetails/attachmentUrls");
                        let bAttachmentFinalUrl = true;
                        aFinalAttachmentUrl.forEach(function (item, iIndex) {
                            if (!item.url && !item.urlName) {
                                bAttachmentFinalUrl = false;
                            }
                        });
                        this.getView().getModel().setProperty("/isAttachmentUrl", bAttachmentFinalUrl);
                    }
                }

            //fetch internal order from context
            let sInternalOrder1 = this.getModel().getProperty("/INTERNAL_ORDER1");
            let sInternalOrder2 = this.getModel().getProperty("/INTERNAL_ORDER2");
            let aInternalOrder = [
                sInternalOrder1 ?sInternalOrder1:"",
                sInternalOrder2 ? sInternalOrder2: ""
            ].filter(io =>io);

            const oInternalOrderModel = new JSONModel(aInternalOrder);
            this.getView().setModel(oInternalOrderModel, "internalOrderModel");

            const oStaffingReqSection = this.getView().byId("idIOownerObjectLayout").getSections()[4];
            this.getView().byId("idIOownerObjectLayout").setSelectedSection(oStaffingReqSection);
        }else{
            this.getOwnerComponent().getRouter().navTo(
				"NotFound"
			);
        }

        },
        _initializeAssignments: function () {
            //initialize assignments model
            const oAssignments = {
                "assignments": [this.getView().getModel().getProperty("/io_OwnerResource")]
            };
            const oModel = new JSONModel(oAssignments);
            this.getView().setModel(oModel, "assignmentsModel");
        },
        _fetchFormActions: function (self) {
			var oModel = this.getView().getModel().getData();
			let sOrgID;
			if(oModel.OrgType === "SORG"){
				sOrgID = 'ParentOrgID' in  oModel? this.getView().getModel().getProperty("/ParentOrgID") : this.getView().getModel().getProperty("/OrgID");
			}else{
			    sOrgID = this.getView().getModel().getProperty("/OrgID");
			}
            const sOrgType = self.getModel().getProperty("/OrgType");
            const sUserTask = "IO_Owner";
            const sFormatOrgID = self._getOrgIDnumber(sOrgID, sOrgType);
            const sUrl = self._getRuntimeBaseURL() + `/resources/req-area-api-/Action?$filter=(orgID eq '${sFormatOrgID}' and orgType eq '${sOrgType}') and (UserTask eq '${sUserTask}')`;
            $.ajax({
                contentType: "application/json",
                url: sUrl,
                async: false,
                type: "GET",
                success: function (oData) {
                    const aFormActionsValues = oData.value;
                    const oFormValue = aFormActionsValues.reduce(function (formVal, val) {
                        (formVal[val.Action_ID] = formVal[val.Action_ID] || []).push(val);
                        return formVal;
                    }, {})
                    const oFormActionsConfigModel = new JSONModel(oFormValue);
                    self.getView().setModel(oFormActionsConfigModel, "formActionsConfigModel");

                },
                error: function (oError) {

                }
            });
        },
        _getOrgIDnumber: function (sOrgID, sOrgType) {
            if (sOrgType === "SORG") {
                return Number(sOrgID.replace('SORG-', '')).toString();
            } else {
                return sOrgID;
            }
        },
        //set form configurable model
        _fetchFormConfigData: function (self) {
			const sOrgID = 'ParentOrgID' in self.getModel().getData() ? self.getModel().getProperty("/ParentOrgID") : self.getModel().getProperty("/OrgID");
            const sOrgType = self.getModel().getProperty("/OrgType");
            const sFormatOrgID = self._getOrgIDnumber(sOrgID, sOrgType);
            const sUrl = self._getRuntimeBaseURL() + `/resources/req-area-api-/Form_Tab?$expand=Fields&&$filter=orgID eq '${sFormatOrgID}' and orgType eq '${sOrgType}'`;

            $.ajax({
                contentType: "application/json",
                url: sUrl,
                async: false,
                type: "GET",
                success: function (oData) {
                    const aDataNew = [];

                    for (var i = 0; i < oData.value.length; i++) {
                        if (!aDataNew[oData.value[i].ID]) {
                            aDataNew[oData.value[i].ID] = [];
                        }
                        aDataNew[oData.value[i].ID] = oData.value[i];
                        const aDataNewFields = [];
                        for (var j = 0; j < oData.value[i].Fields.length; j++) {

                            if (!aDataNew[oData.value[i].Fields[j].ID]) {
                                aDataNewFields[oData.value[i].Fields[j].ID] = [];
                            }
                            aDataNewFields[oData.value[i].Fields[j].ID] = oData.value[i].Fields[j];
                            // aDataNew[oConfigData.value[i].ID].Fields = aDataNewFields[oConfigData.value[i].Fields[j].ID
                        }
                        aDataNew[oData.value[i].ID].Fields = aDataNewFields;
                    }
                    const oFormConfigModel = new JSONModel(aDataNew);
                    self.getView().setModel(oFormConfigModel, "formConfigModel");
                },
                error: function (oError) {

                }
            });
        },
        formatFormConfigVisibility: function (sVal) {
            if (sVal === "X") {
                return true;
            } else {
                return false;
            }
        },
        formatFormConfigReqAreaVisibility(sVal , sReqArea){
			return sReqArea !== "" && sVal === "X";
		},
        formatFieldForNonRise: function (isRise, formVisibility) {
            if (formVisibility === "X") {
                var isRiseVisibility = !isRise;
                return isRiseVisibility;
            } else {
                return false;
            }
        },
        formatFieldBasedOnMultipleProperties: function (bVal, formVisibility) {
            if (formVisibility === "X") {
                return bVal;
            } else {
                return false;
            }
        },
        formatFieldSelectField: function (bVal, formVisibility, isMeetingPlanned) {
            if (formVisibility && isMeetingPlanned) {
                return bVal;
            } else {
                return false;
            }
        },
        parseGetOppDataResponse: function (data) {
            if (data) {
                const oDealInfo = {
                    accName: data.ACCOUNT_NAME,
                    oppName: data.DESCRIPTION,
                    decision: data.DECISION,
                    reviewerName: data.DQReview.REVIEWER1_NAME,
                    forecast: data.FORECAST,
                    onPremRevenue: data.LICENSE_REVENUE,
                    cloudRevenue: data.CLOUD_REVENUE,
                    currency: data.CURRENCY,
                    CURR_PHASE: data.CURR_PHASE,
                    STATUS: data.STATUS,
                    TCV: data.Items.results.length ? data.Items.results[0].TOTAL_TCV : ""
                };

                //set dates
                const jsonClosingDate = data.EXPECT_END,
                    closingDateFull = jsonClosingDate ? new Date(parseInt(jsonClosingDate.substr(6))) : null;
                oDealInfo.closingDate = closingDateFull;

                const jsonReviewDate = data.DQReview.REVIEW_DATE1,
                    reviewDateFull = jsonReviewDate ? new Date(parseInt(jsonReviewDate.substr(6))) : null;
                oDealInfo.reviewDate = reviewDateFull;

                //process Notes
                const aNotes = data.Notes.results;
                for (let i = 0; i < aNotes.length; i++) {
                    switch (aNotes[i].TDID) {
                        case "ZD01":
                            oDealInfo.compelEventText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD02":
                            oDealInfo.fundingText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD03":
                            oDealInfo.custStakeText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD04":
                            oDealInfo.custChallengesText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD05":
                            oDealInfo.custBusDriversText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD06":
                            oDealInfo.solutionText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD07":
                            oDealInfo.competitorsText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD08":
                            oDealInfo.partnersText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD10":
                            oDealInfo.execSummary = aNotes[i].CONC_LINES;
                            break;
                        default:
                    }
                }

                //process Attributes
                const aAttributes = data.Attributes.results;
                for (let i = 0; i < aAttributes.length; i++) {
                    switch (aAttributes[i].ATTR_CODE) {
                        case "AS0103":
                            oDealInfo.compelEventQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0104":
                            oDealInfo.fundingQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0105":
                            oDealInfo.custStakeQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0106":
                            oDealInfo.custChallengesQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0107":
                            oDealInfo.custBusDriversQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0108":
                            oDealInfo.solutionQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0109":
                            oDealInfo.competitorsQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0110":
                            oDealInfo.partnersQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0132":
                            oDealInfo.decision = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0133":
                            oDealInfo.reviewerName = aAttributes[i].ATTR_DESCR;
                            break;
                        case "AS0134":
                            oDealInfo.reviewDate = new Date(aAttributes[i].ATTR_VALUE.slice(0, 4) + "-" + aAttributes[i].ATTR_VALUE.slice(4, 6) + "-" + aAttributes[i].ATTR_VALUE.slice(-2));
                            break;
                        default:
                    }
                }
                oDealInfo.attributes = aAttributes;
                this.getModel().setProperty("/dealInfo", oDealInfo);
                this.getModel().refresh();
            }
        },
        configureView: function (sStep) {
            const that = this;
            const startupParameters = this.getComponentData().startupParameters;
            const taskInstanceModel = this.getModel("taskInstanceModel");
            const approveText = this.getMessage("APPROVE");
            const rejectText = this.getMessage("REJECT");
            const forwardText = this.getMessage("FORWARD");
            const sSubject = taskInstanceModel.getData().subject;
            const oModel = this.getModel();
            const oFormActionsModelData = this.getView().getModel("formActionsConfigModel").getData();
            this.byId("presalesRequestApprovalPageHeader").setObjectTitle(sSubject);

             //add approve button

             const aApproveActionBtn = {
                sBtnTxt: approveText,
                enabled: true,
                visible: "true",
                onBtnPressed: function () {
                    that._onCallUserSearchHelps(that);
                }
            };
             // Add 'Approve' action to the task
            if (oFormActionsModelData.idapprove[0].Visibility === "X") {
                startupParameters.inboxAPI.addAction({
                    action: "approve",
                    label: oFormActionsModelData.idapprove[0].Label,
                    type: "Accept"
                },
                    // Set the onClick function
                    aApproveActionBtn.onBtnPressed);
            }

            //Send back to processor button

            const oRejectAction = {
                sBtnTxt: rejectText,
                onBtnPressed: function () {
                    that._onValidateAssignment("reject");
                }
            };
            //add reject action
            if (oFormActionsModelData.idreject[0].Visibility === "X") {
                startupParameters.inboxAPI.addAction({
                    action: "reject",
                    label: oFormActionsModelData.idreject[0].Label,
                    type: "Emphasized"
                }, oRejectAction.onBtnPressed);
            }

            //add Reject(close) button
            const oClosedRejectBtn = {
                sBtnTxt: "close",
                onBtnPressed: function () {
                    that._onValidateAssignment("Close");
                }
            };
            if (oFormActionsModelData.idclose && oFormActionsModelData.idclose[0].Visibility === "X") {
                startupParameters.inboxAPI.addAction({
                    action: "close",
                    label: oFormActionsModelData.idclose[0].Label,
                    type: "Reject"
                }, oClosedRejectBtn.onBtnPressed);
            }

            
        //  const bForwardVisible = (oModel.getData().io_OwnerResource.NominatedResources[0].ioOwnerDetails.IOOwnerEmail === oModel.getData().oppOwnerDetails.email);

        //     const oForwardAction = {
        //         sBtnTxt: forwardText,
        //         visible:bForwardVisible,
        //         onBtnPressed: function (oEvent) {
        //             const oModel = that.getModel();
        //             oModel.refresh(true);
        //             const processContext = oModel.getData();

        //             // Call a local method to perform further action
        //             that._selectIOownerDialog(
        //                 processContext,
        //                 startupParameters.taskModel.getData().InstanceID,
        //                 "Forward"
        //             );
        //         }
        //     };
        //     if (bForwardVisible) {
        //         startupParameters.inboxAPI.addAction({
        //             // confirm is a positive action
        //             action: "Forward",
        //             label: oForwardAction.sBtnTxt
        //         },
        //             // Set the onClick function
        //             oForwardAction.onBtnPressed);
        //     }else{
        //         startupParameters.inboxAPI.removeAction("Forward");
        //     }

        },
        _selectIOownerDialog: function (processContext, taskId, sDecision) {
            const oIoOwnerData = new JSONModel([]);
            const that = this
            this.getView().setModel(oIoOwnerData, "ioOwnerModel");
            if (!this.pIOOwnerSelectDialog) {
                this.pIOOwnerSelectDialog = this.loadFragment({
                    name: "com.sap.bpm.IOownerForm.view.IOOwneSelectDialog"
                });
            }
            this.pIOOwnerSelectDialog.then(function (oIOOwnerSelectDialog) {
                that._IoOwnerDialog = oIOOwnerSelectDialog;
                // oIOOwnerSelectDialog._getOkButton().setText(that.getMessage("FORWARD"));
                // oIOOwnerSelectDialog._getOkButton().setEnabled(false)
                // oIOOwnerSelectDialog._searchField.setPlaceholder(that.getMessage("SEARCH_IO_OWNER"));
                that.getModel().setProperty("/forWardEnabled",false);
                that.getModel().refresh(true);
                    oIOOwnerSelectDialog.open();
                    return;
            }.bind(this));

        },
        onIOOwnerSearch: function (oEvent) {
            const sSearchQuery = oEvent.getParameter("query");
            this.getModel().setProperty("/ioOwnerListBusy",true);
            this.getModel().setProperty("/ioOwnerListBusy",false);
            if (sSearchQuery) {
                Models._callEmployeeService(sSearchQuery, 100, 0, this);
            } else {
                this.getModel().setProperty("/forWardEnabled",false);
                this.getView().setModel(new JSONModel([]), "ioOwnerModel");
            }
            this.getModel().refresh();
        },
        onSelectIOOwner:function(evt){
            let oSelectedContext = evt.getParameter("listItem").getBindingContext("ioOwnerModel").getObject()
            this.getModel().setProperty("/forWardIoOwnerDetails",oSelectedContext);
            this.getModel().setProperty("/forWardEnabled",true);
            this.getModel().refresh();  
        },
        handleForwardRequest:function(evt){
           const sTaskId = this.getComponentData().startupParameters.taskModel.getData().InstanceID;
           const oAssignmentsModel = this.getView().getModel("assignmentsModel");
           const aAssignments =  oAssignmentsModel.getData().assignments;
           const oSelectedOwnerDetails =  this.getModel().getProperty("/forWardIoOwnerDetails");
           const iOownerDetails =  {
            "IOOwnerName":`${oSelectedOwnerDetails.firstName} ${oSelectedOwnerDetails.lastName}`,
            "IOOwnerEmail": oSelectedOwnerDetails.email,
            "IOOwnerUserId":oSelectedOwnerDetails.ID
            }
           aAssignments[0].NominatedResources[0].ioOwnerDetails = iOownerDetails;
           this._triggerComplete(aAssignments,sTaskId,"Forward")
           this._IoOwnerDialog.close();
        },
        handleCancelForward:function(){
            this._IoOwnerDialog.close();
        },
        // This method is called when the confirm button is click by the end user
        _triggerComplete: function (assignmentData, taskId, sDecision) {
            const oThisController = this;
            const cFLPUserInfo = sap.ushell.Container.getService("UserInfo").getUser();
            const workflowBaseurl = this._getWorkflowRuntimeBaseURL();
            assignmentData[0].NominatedResources[0].Io_Decision = sDecision;
            this.setBusy(true);

            $.ajax({
                // Call workflow API to get the xsrf token
                url: workflowBaseurl + "/xsrf-token",
                method: "GET",
                headers: {
                    "X-CSRF-Token": "Fetch"
                },
                success: function (result, xhr, data) {

                    // After retrieving the xsrf token successfully
                    const token = data.getResponseHeader("X-CSRF-Token");

                    // form the context that will be updated
                    const oBasicData = {
                        context: {
                            "IOUserTaskID" : oThisController.getView().getModel("taskInstanceModel").getProperty("/id"),
                            "decision": sDecision,
                            "io_OwnerResource": assignmentData[0],
                            "currentProcessor": {
                                "email": cFLPUserInfo.getEmail(),
                                "fullName": cFLPUserInfo.getFullName(),
                                "id": oThisController.getView().getModel().getData().io_OwnerIds
                            }
                        },
                        "status": "COMPLETED"
                    };
                    switch(sDecision) {
						case "Approve":
						  oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idapprove[0].ID;
						  break;
						case "Forward":
						  oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idforward[0].ID;
						  break;
						case "Reject":
						  oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idreject[0].ID;
						  break;
                        case "Close":
                            oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idclose[0].ID;
                            break;
                        case "Proceed":
                            oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idproceed[0].ID;
                            break;
						default:
						   oBasicData.context.decision_ID = ""
						  break;
					  }
                    
                    //update refrence id for older request
                    if (typeof oThisController.getModel().getData().RequestID !== "object") {
                        if (oThisController.getModel().getProperty("/updatedRefId")) {
                            oBasicData.context.RequestID = {
                                "value": oThisController.getModel().getProperty("/updatedRefId")
                            }
                        }
                    }
                    $.ajax({
                        // Call workflow API to complete the task
                        url: workflowBaseurl + "/task-instances/" + taskId,
                        method: "PATCH",
                        contentType: "application/json",
                        // pass the updated context to the API
                        data: JSON.stringify(oBasicData),
                        headers: {
                            // pass the xsrf token retrieved earlier
                            "X-CSRF-Token": token
                        },
                        // refreshTask needs to be called on successful completion
                        success: function (result, xhr, data) {
                            oThisController._refreshTask();
                            oThisController.setBusy(false);
                            sap.ui.core.BusyIndicator.hide();
                        }

                    });
                }
            });

        },
        // Request Inbox to refresh the control once the task is completed
        _refreshTask: function () {
            const taskId = this.getComponentData().startupParameters.taskModel.getData().InstanceID;
            this.getComponentData().startupParameters.inboxAPI.updateTask("NA", taskId);
        },

        /**
         * DOCUMENT SERVICE INTEGRATION
         */
        loadAttachments: function () {
            // get workflow ID
            const taskInstanceModel = this.getModel("taskInstanceModel");
            workflowInstanceId = taskInstanceModel.getData().workflowInstanceId;
            const workflowFileUploadId = this.getModel().getProperty("/workflowFileUploadId") ? this.getModel().getProperty("/workflowFileUploadId") : workflowInstanceId;
            const docServieBaseUrl = this._getDocServiceRuntimeBaseURL();
            const sUrl = docServieBaseUrl + "/WorkflowManagement/HarmonyPresalesRequests/" + workflowFileUploadId + "/?succinct=true";
            const oSettings = {
                "url": sUrl,
                "method": "GET",
                // "async": false
            };
            const oThisController = this;
            $.ajax(oSettings)
                .done(function (results) {
                    oThisController._mapAttachmentsModel(results);
                })
                .fail(function (err) {
                    if (err !== undefined) {
                        const oErrorResponse = $.parseJSON(err.responseText);
                        MessageToast.show(oErrorResponse.message, {
                            duration: 6000
                        });
                    } else {
                        MessageToast.show("Unknown error!");
                    }
                });
        },
        // assign data to attachments model
        _mapAttachmentsModel: function (data) {
            data.downloadEnabled = data && data.objects && data.objects.length > 0;
            this.oAttachmentsModel.setData(data);
            this.oAttachmentsModel.refresh();
            this.getView().setBusy(false);
        },

        // formatting functions
        formatTimestampToDate: function (timestamp) {
            const oFormat = DateFormat.getDateTimeInstance();
            return oFormat.format(new Date(timestamp));
        },
        formatFileLength: function (fileSizeInBytes) {
            let i = -1;
            const byteUnits = [' kB', ' MB', ' GB', ' TB', 'PB', 'EB', 'ZB', 'YB'];
            do {
                fileSizeInBytes = fileSizeInBytes / 1024;
                i++;
            } while (fileSizeInBytes > 1024);

            return Math.max(fileSizeInBytes, 0.1).toFixed(1) + byteUnits[i];
        },

        formatDownloadUrl: function (objectId) {
            const docServieBaseUrl = this._getDocServiceRuntimeBaseURL();
            return docServieBaseUrl + "/WorkflowManagement/HarmonyPresalesRequests/"
                + workflowInstanceId + "?objectId=" + objectId + "&cmisselector=content";
        },
        _getRuntimeBaseURL: function () {
            var appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
            var appPath = appId.replaceAll(".", "/");
            var appModulePath = sap.ui.require.toUrl(appPath);
            return appModulePath;
        },
        _getWorkflowRuntimeBaseURL: function () {
            return this._getRuntimeBaseURL() + "/workflowruntime/v1";
        },
        _getDocServiceRuntimeBaseURL: function () {
            return this._getRuntimeBaseURL() + "/docservice";
        },
        _getRequestAreaBaseURL: function () {
            let sSalesOrgID = 'ParentOrgID' in this.getView().getModel().getData() ? this.getView().getModel().getData().ParentOrgID : this.getView().getModel().getData().OrgID;
            if(this.getModel().getProperty("/OrgType") === 'SORG'){
                sSalesOrgID = Number(sSalesOrgID.replace('SORG-', '')).toString();
            }
            return this._getRuntimeBaseURL() + "/resources/req-area-api-/Public_ReqArea?$filter=orgID eq '" + sSalesOrgID + "'";
        },
        _getConstantsBaseURL: function () {
            return this._getRuntimeBaseURL() + "/resources/req-area-api-/Parameter";
        },
        _getRejectionCodeBaseURL: function () {
            let sSalesOrgID = 'ParentOrgID' in this.getView().getModel().getData() ? this.getView().getModel().getData().ParentOrgID : this.getView().getModel().getData().OrgID;
            if(this.getModel().getProperty("/OrgType") === 'SORG'){
                sSalesOrgID = Number(sSalesOrgID.replace('SORG-', '')).toString();
            }
            const sManagerORresource = this.getModel().getProperty("/currentStepID") === "MANAPP" ? "4" : "5";
            return this._getRuntimeBaseURL() + "/resources/req-area-api-/Rejection_Codes?$filter=OrgID eq '" + sSalesOrgID + "' and UserTask_ID eq '" + sManagerORresource + "'";
        },
        onSupportlinkpress: function () {
            const aConstants = this.getView().getModel("ConstantsAPIData").getData().value;
            aConstants.forEach(function (item) {
                if (item.Type_desc === "supporturl" && item.Operational_Status) {
                    sap.m.URLHelper.redirect(item.Value, true);
                    return;
                }
            });
        },
        _onValidateAssignment: function (sDecision) {
            let oAssignmentsModel = this.getView().getModel("assignmentsModel");
            const that = this;
          
                const sTaskId = this.getComponentData().startupParameters.taskModel.getData().InstanceID;
                const aStaffingData = [];
                oAssignmentsModel.getData().assignments.forEach(function (assignments) {
                    const aNominatedResource = assignments.NominatedResources[0];
                    if (sDecision === "Approve") {
                        aStaffingData.push(aNominatedResource);
                        that._formStaffingPayload(that, aStaffingData);
                    }
                });
                if (sDecision === "reject" && !aStaffingData.length) {
                    // that._triggerComplete(oAssignmentsModel.getData().assignments, sTaskId, "Submit");
                    that._openSubmitDialog(
                        oAssignmentsModel.getData().assignments,
                        sTaskId,
                        "Reject"
                    );
                }
                if(sDecision === "Close"){
                    that._openSubmitDialog(
                        oAssignmentsModel.getData().assignments,
                        sTaskId,
                        "Close"
                    );
                }

        },
        /* Start of Code for CurrentTask Instance ID Update  */

        updateCurrentInstance: function () {
            const WfExt_data = {};
            var URL = this._getRuntimeBaseURL() + "/resources/wf/WfInstance";
            var oModelData = this.getView().getModel().getData();
            const sStep = this.getModel().getProperty("/currentStepID");
            const oContextModelData = this.getModel();
                WfExt_data.instance_GUID = oContextModelData.getProperty("/WfID_PresalesRequestApproval");
            WfExt_data.parentInstance_GUID = oContextModelData.getProperty("/parentInstanceID");
            if(!WfExt_data.parentInstance_GUID){
                const sURL = `${URL}?$filter=instance_GUID eq ('${WfExt_data.instance_GUID}')`
                this.getWfInstanceModel(sURL, this);
                WfExt_data.parentInstance_GUID = this.getView().getModel("WfInstanceModel").getData()[0].parentInstance_GUID;
            }
            WfExt_data.currentTaskInstanceID = this.getParentModel("taskInstanceModel").getProperty("/id");
            WfExt_data.currentTaskURL = window.location.href;
            const instGuid = `(instance_GUID='${WfExt_data.instance_GUID}',parentInstance_GUID='${WfExt_data.parentInstance_GUID}')`;
            let that = this;
            
            $.ajax({
                url: URL,
                type: "GET",
                async: true,
                beforeSend: function (xhr) {
                    xhr.setRequestHeader("X-CSRF-Token", "Fetch");
                },
                complete: function (xhr) {
                    token = xhr.getResponseHeader("X-CSRF-Token"); const oSettings = {
                        "url": URL + instGuid,
                        "method": "PATCH",
                        "async": false,
                        "data": JSON.stringify(WfExt_data),
                        "headers": {
                            'X-CSRF-Token': token
                        },
                        "contentType": "application/json",
                    };
                    $.ajax(oSettings)
                        .done(function (results) { 
                            if(typeof that.getView().getModel().getData().RequestID !== "object" && typeof results === "object"){
                                if(results.refID){
                                    oContextModelData.setProperty("/updatedRefId" ,results.refID);
                                }
                            }
                         })
                        .fail(function (err) {
                            MessageBox.error("Current user Instance ID update failed!");
                        });
                }
            });
        },
        getWfInstanceModel: function(sUrl, self){
            $.ajax({
                            async: false,
                            contentType: "application/json",
                            url: sUrl,
                            type: "GET",
                            success: function (oData) {
                                 const aResult = oData.value;
                                    const oWfInstanceModel = new JSONModel();
                                    oWfInstanceModel.setData(aResult);
                                    self.getView().setModel(oWfInstanceModel, "WfInstanceModel");
         
                            }.bind(this),
                            error: function (oError) {
                            }
                        });
        },
        // change event for io owner decision 'Approve' or 'Reject'
        _onCallUserSearchHelps: function (oThisController) {
            //call userSearchHelps to get perner no
            const oAssignmentsModel = oThisController.getView().getModel("assignmentsModel");
            const oBindingContextObj = oAssignmentsModel.getData().assignments[0].NominatedResources[0];
            Models._callUserSearchHelps(oBindingContextObj.userId, oThisController, oThisController.fnSuccessUserSearchHelpsCallBack, oThisController.fnErrorUserSearchHelpsCallBack, oBindingContextObj);
            oAssignmentsModel.refresh(true);
        },
        fnErrorUserSearchHelpsCallBack: function (oError, oController) {
            oController.fnErrorMessage(oError.responseText);
        },
        fnErrorMessage: function (errorText) {
            MessageBox.error(errorText, {
                contentWidth: "600px"
            });
            sap.ui.core.BusyIndicator.hide();
        },
        //staffing calll
        _formStaffingPayload: function (self, oNominatedResources) {
            let oFinalPayload = [];
            oNominatedResources.forEach(function (nominatedResource) {
                //set staffing payload
                oFinalPayload.push(self._setStaffingPayload(self, nominatedResource));
            });
            sap.ui.core.BusyIndicator.show(0);
            Models._postStaffingDetails(oFinalPayload, self, self.fnSuccessPostStaffing, self.fnErrorPostStaffing)
        },
        //convert date to milliseconds
        formatDateToMilliSeconds: function (dateVal) {
            const iDate = Date.parse(new Date(dateVal));
            return `\/Date(${iDate})\/`;
        },
        //convert date to date string
        getDateString: function (date) {
            const year = date.getFullYear();
            let month_append;
            let dat_append;
            const month = date.getMonth() + 1;
            if (month < 10) {
                 month_append = "0";
            } else {
                 month_append = "";
            }
            const dat = date.getDate();
            if (dat < 10) {
                 dat_append = "0";
            } else {
                 dat_append = "";
            }
            return (year + "" + month_append + "" + month + "" + dat_append + "" + dat);
        },
        //set staffing payload
        _setStaffingPayload: function (self, oNominatedResources) {
            const oStaffingPayload = {
                "Actexp": oNominatedResources.staffingPurposeKey ? oNominatedResources.staffingPurposeKey:"",
                "ActexpStr": oNominatedResources.staffingPurpose ? oNominatedResources.staffingPurpose : "",
                "Action": "2",
                "Begda": oNominatedResources.dateValue ? self.formatDateToMilliSeconds(oNominatedResources.dateValue) : "00000000",
                "BegdaStr": oNominatedResources.dateValue ? self.getDateString(new Date(oNominatedResources.dateValue)) : "00000000",
                "Bukrs": oNominatedResources.sCompanyCode ? oNominatedResources.sCompanyCode : "",
                "CostObjType": "IO",
                "Endda": oNominatedResources.secondDateValue ? self.formatDateToMilliSeconds(oNominatedResources.secondDateValue) : "00000000",
                "EnddaStr": oNominatedResources.secondDateValue ? self.getDateString(new Date(oNominatedResources.secondDateValue)) : "00000000",
                "EntryId": "O",
                "LogSystem": "CRM_MTR",
                "Name": oNominatedResources.fullName,
                "Snote": "",
                "Objnr": "",
                "Pernr": "00000000",
                "PernrStr": oNominatedResources.Pernr,
                "Posnr": "",
                "ReadOnly": false,
                "TaskLevel": oNominatedResources.staffingPurposeKey!=="E" ?  oNominatedResources.taskLevelKey : "NONE",
                "Tasktype": "",
                "TasktypeStr": "",
                "Trtkl": "",
                "UserType": "",
                "Vbeln": oNominatedResources.internalOrder ? oNominatedResources.internalOrder.toString() : "",
                "Zexpdays": oNominatedResources.maxNoOfDaysToBookIO ? oNominatedResources.maxNoOfDaysToBookIO.toString() : ""

            }
            return oStaffingPayload;
        },
        //Sucess staffing POST call
        fnSuccessPostStaffing: function (response, self) {
            sap.ui.core.BusyIndicator.hide();
            const oAssignmentsModel = self.getView().getModel("assignmentsModel");
            const sTaskId = self.getComponentData().startupParameters.taskModel.getData().InstanceID;
            try {
                if (JSON.parse(response.headers["sap-message"]).severity === "error") {
                    //Show warning message to proceed for Wf triifer
                    const sMsg = `${JSON.parse(response.headers["sap-message"]).message}.${self.i18nModel.getText("staffingGenericError")}`
                    self._proceedToWfService(self, sMsg);
                } else {
                    self._showStaffingSuccessMessage(self.i18nModel.getText("staffingSuccessMsg"));
                    //proceed wf trigger
                    self._triggerComplete(oAssignmentsModel.getData().assignments, sTaskId, "Approve");
                }
            } catch (err) {
                //show success message
                self._showStaffingSuccessMessage(self.i18nModel.getText("staffingSuccessMsg"));
                //proceed wf trigger
                self._triggerComplete(oAssignmentsModel.getData().assignments, sTaskId, "Approve");
            }
        },
        //show staffing POST success message
        _showStaffingSuccessMessage: function (sMsg) {
            MessageBox.show(
                sMsg, {
                icon: MessageBox.Icon.SUCCESS,
                title: "Success"
            });

        },
        //error call back for POST staffing
        fnErrorPostStaffing: function (error, self) {
            sap.ui.core.BusyIndicator.hide();
            const sMsg = self.i18nModel.getText("staffingErrorCallBackText");
            //proceed wf trigger
            self._proceedToWfService(self, sMsg);

        },
        //proceed wf trigger
        _proceedToWfService: function (self, sMsg) {
            const oAssignmentsModel = self.getView().getModel("assignmentsModel");
            const sTaskId = self.getComponentData().startupParameters.taskModel.getData().InstanceID;
            //show warning message for POST staffing
            const sBtnText = self.getView().getModel("formActionsConfigModel").getData().idproceed[0].Label;
            MessageBox.show(
                sMsg, {
                icon: MessageBox.Icon.WARNING,
                title: "Warning",
                actions: [sBtnText, MessageBox.Action.CANCEL],
                emphasizedAction: sBtnText,
                onClose: function (oAction) {
                    if (oAction === sBtnText) {
                        self._triggerComplete(oAssignmentsModel.getData().assignments, sTaskId, "Proceed");
                    }
                }
            }
            );
        },
        //Success GET call for UserSearchHelps
        fnSuccessUserSearchHelpsCallBack: function (data, self, oAssignmentContext) {
            const sStep = self.getModel().getProperty("/currentStepID");
            const sMsg = self.i18nModel.getText("pernerServiceNoErrorMsg");
            if (data) {
                if (data.d.results.length) {
                    if (data.d.results[0].Pernr) {
                        //add perner number to assignmentcontext
                        oAssignmentContext.Pernr = data.d.results[0].Pernr;
                        self._onValidateAssignment("Approve");
                    }
                }else{
                    self._showErrorMsg(self, sMsg);
                }
            } else {
                if (sStep !== "MANAPP") {
                    self._showErrorMsg(self, sMsg);
                }
            }
        },
        //generic error message
        _showErrorMsg: function (self, sMsg) {
            MessageBox.show(
                sMsg, {
                icon: MessageBox.Icon.WARNING,
                title: "Warning",
                actions: [MessageBox.Action.OK],
                emphasizedAction: MessageBox.Action.OK,

            }
            );
        },
        _setCommentTexts:function(sDecision){
            let oFieldText = {};
            switch(sDecision) {
                case "Approve":
                 oFieldText.placeholder =  this.getMessage("staffingApproveCommentMsg");
                 oFieldText.commentValueStateText = "";
                  break;
                case "Close":
                    oFieldText.placeholder =  this.getMessage("ENTER_TEXT_OPT");
                    oFieldText.commentValueStateText = this.getMessage("rejectReasonRequired");
                  break;
                default:
                oFieldText.placeholder =  this.getMessage("ENTER_COMMENT");
                oFieldText.commentValueStateText = this.getMessage("commentValueState");
                  break;
              }
              return oFieldText;

        },
        _openSubmitDialog: function (assignments, taskId, sDecision) {
            const oModel = this.getModel();
            oModel.setProperty("/IOownerComments", "");
            const that = this;
            let oFieldText = this._setCommentTexts(sDecision)
            // if (!this.oSubmitDialog) {
                assignments[0].NominatedResources[0].IOownerComments = false;
            this.oSubmitDialog = new Dialog({
                type: DialogType.Message,
                title: this.getMessage("ENTER_COMMENT"),
                content: [
                    new TextArea("submissionNote", {
                        width: "100%",
                        value: '{/IOownerComments}',
                        placeholder:oFieldText.placeholder,
                        valueState: '{/commentsState}',
                        valueStateText: oFieldText.commentValueStateText,
                        liveChange: function (oEvent) {
                            const sComment = oEvent.getParameter("value").trim();
                            this.oSubmitDialog.getBeginButton().setEnabled(sComment.length > 0);
                            assignments[0].NominatedResources[0].IOownerComments = sComment;
                            if((sDecision === "Close" || sDecision === "Reject") && sComment.length > 0){
                                oModel.setProperty("/commentsState", "None");
                            }else{
                                oModel.setProperty("/commentsState", "Error");
                            }
                            oModel.setProperty("/comments", sComment);
                        }.bind(this)
                    })
                ],
                beginButton: new Button({
                    type: ButtonType.Emphasized,
                    text: this.getMessage("OK"),
                    press: function () {
                        if(assignments[0].NominatedResources[0].IOownerComments){
                        that._triggerComplete(assignments, taskId, sDecision); 
                        }else{
                             oModel.setProperty("/commentsState", "Error");
                        }
                    }.bind(this)
                }),
                endButton: new Button({
                    text: this.getMessage("CANCEL"),
                    press: function () {
                        this.oSubmitDialog.close();
                        this.oSubmitDialog.destroy();
                    }.bind(this)
                })
            });
            //to get access to the controller's model
            this.getView().addDependent(this.oSubmitDialog);
            // }
            // toggle compact style
            syncStyleClass("sapUiSizeCompact", this.getView(), this.oSubmitDialog);
            this.oSubmitDialog.open();
        },
        //format attachment visibility
				formatAttachmentVisibility: function (bConfig,isAttachment) {
					if (bConfig === "X" && isAttachment) {
						return true;
					} else {
						return false;
					}
				}
    });
});