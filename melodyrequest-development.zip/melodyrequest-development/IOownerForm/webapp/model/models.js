sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"sap/m/MessageBox",
	"sap/ui/model/odata/v2/ODataModel",
	"com/sap/bpm/IOownerForm/control/ErrorHandle"
], function (JSONModel, Device, MessageBox,ODataModel,ErrorHandle) {
	"use strict";

	return {
		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		_getRuntimeBaseURL: function (self, isComponentScope) {
                var componentName =
                    isComponentScope ? self.getManifestEntry("/sap.app/id").replaceAll(".", "/")
                        : self.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
                var componentPath = sap.ui.require.toUrl(componentName);
                return componentPath;
            },
		_callEmployeeService: function (sUserId, topValue, skipValue, oController) {
			//sap employee service call to get employee details
			const sBaseEmployeeServiceurl = this._getRuntimeBaseURL(oController) + "/sapit-employee-data";
			jQuery.ajax({
				contentType: "application/json",
				async:false,
				type: "GET",
				url: `${sBaseEmployeeServiceurl}/Employees?$count=true&$search="${sUserId}"&$skip=${skipValue}&$top=${topValue}`,
				success: function (response) {
					const oIoOwnerData = new JSONModel(response);
					oController.getModel().setProperty("/ioOwnerListBusy",false);
					oController.getModel().refresh(true);
					oController.getView().setModel(oIoOwnerData, "ioOwnerModel");
					
				}.bind(this),
				error: function (oError) {
					ErrorHandle.setErrorMessage(oError, oController);

				}
			});
		},
		_callUserSearchHelps:function(sUserId,oController,fnSuccess,fnError,oAssignmentContext){
			//call userSearchHelps to get perner no
			const sRooturl = this._getRuntimeBaseURL(oController) + "/intis";
			jQuery.ajax({
				async: false,
				dataType: 'json',
				url: `${sRooturl}/sap/opu/odata/sap/ZSTAFFING_APP_2_SRV/UserSearchHelps?$filter=uname eq '${sUserId}'`,
				type: "GET",
				success: function (oData) {
					return fnSuccess(oData,oController,oAssignmentContext);

				}.bind(this),
				error: function (oError) {
					return fnError(oError,oController,oAssignmentContext);
					ErrorHandle.setErrorMessage(oError, oController);
				}
			});

		},
		systemStaffingODataModel: function (self) {
			//set ISP oDataModel
			const componentName = self.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
			const componentPath = sap.ui.require.toUrl(componentName);
			const oDataModel = new ODataModel({
				serviceUrl: `${componentPath}/intis/sap/opu/odata/sap/ZSTAFFING_APP_2_SRV`
			});
			return oDataModel;
		},
		_postStaffingDetails:function(aPayload,oController,fnSuccess,fnError){
			//POST staffing request
			const oStaffingoDataModel = this.systemStaffingODataModel(oController);
			oStaffingoDataModel.setUseBatch(true);
			const aDeferredGroup = oStaffingoDataModel.getDeferredGroups().push("batchCreate");
			oStaffingoDataModel.setDeferredGroups(aDeferredGroup);
			const that = this;
			this.aPostedReq = [];
			aPayload.forEach(function(payload){
				oStaffingoDataModel.create("/ReqDetails", payload,{
					groupId: "batchCreate",
					success: function (oData, oResponse) {
						that.aPostedReq.push(oResponse);
						if (that.aPostedReq.length === aPayload.length) {
							return fnSuccess(oResponse, oController)
						}
					},
					error: function (oError) {
						that.aPostedReq.push(oError);
						that.aPostedReq = [];
						return fnError(oError, oController)
					}
				})
			});
			oStaffingoDataModel.submitChanges();
		},
		getAppConstants: function (fnSuccess, self) {
			const sFormattedUrl = self.getManifestEntry("/sap.app/id").replaceAll(".", "/");
			const componentPath = sap.ui.require.toUrl(sFormattedUrl);
			const sFinalUrl = componentPath + "/resources";
			jQuery.ajax({
				async: false,
				contentType: "application/json",
				url: `${sFinalUrl}/req-area-api-/Parameter`,
				type: "GET",
				success: function (oData) {
					return fnSuccess(oData, self);

				}.bind(this),
				error: function (oError) {
					ErrorHandle.setErrorMessage(oError, self);
				}
			});

		},
		_getWfServiceRuntimeBaseURL: function (self, isComponentScope) {
                return this._getRuntimeBaseURL(self, isComponentScope) + "/resources";
            },
		 //service call for MRR application related config (MRR Tab)
		 getMRRAppData: function (fnSuccess, self, isComponentScope) {
			const sBaseurl = this._getWfServiceRuntimeBaseURL(self, isComponentScope);
			jQuery.ajax({
				async: true,
				contentType: "application/json",
				url: `${sBaseurl}/req-area-api-/MR_App_Label`,
				type: "GET",
				success: function (oData) {
					return fnSuccess(oData, self);

				}.bind(this),
				error: function (oError) {
					ErrorHandle.setErrorMessage(oError, self);
				}
			});
		},

	};
});