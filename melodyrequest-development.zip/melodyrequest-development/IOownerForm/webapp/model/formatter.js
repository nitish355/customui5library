sap.ui.define([
], function () {
    "use strict";
    return {
        getForecastText: function (sForecastNumVal) {
            switch (sForecastNumVal) {
                case "1":
                    return "Committed";
                case "2":
                    return "Probable";
                case "3":
                    return "Upside";
                case "4":
                    return "Excluded from Pipeline";
                default:
                    return "Not known";
            }
        },

        getDecisionText: function (sAttrValue) {
            switch (sAttrValue) {
                case "G":
                    return this.getMessage("GO");
                case "N":
                    return this.getMessage("NO_GO");
                case "Q":
                    return this.getMessage("RE_QUALIFY");
                default:
                    return "-";
            }
        },

        /**
		 * Find the State of ObjectStatus as per the attribute value
		 * @function lqColorCode
		 * @public
		 * @param {String} sAttrValue - String which holds attribute value
		 * @return {String} State of ObjectStatus
		 **/
        getQualText: function (sAttrValue, sAttrText) {
            switch (sAttrValue) {
                case "2":
                    return this.getMessage(sAttrText + "_STRONG");
                case "1":
                    return this.getMessage(sAttrText + "_MOD");
                case "0":
                    return this.getMessage(sAttrText + "_WEAK");
                default:
                    return this.getMessage("NA");
            }
        },
        /**
		 * Find the State of ObjectStatus as per the attribute value
		 * @function lqColorCode
		 * @public
		 * @param {String} sAttrValue - String which holds attribute value
		 * @return {String} State of ObjectStatus
		 **/
        getQualState: function (sAttrValue) {
            if (sAttrValue === "2") {
                return "Success";
            } else if (sAttrValue === "1") {
                return "Warning";
            } else if (sAttrValue === "0") {
                return "Error";
            }
            return "None";
        },
        /**
		 * calculate the score based on selected values
		 * @function getDealScore
		 * @public
		 * @param {array} results
		 **/
        getDealScore: function (results) {
            let iScore = 0;
            if (results) {
                const aScoreJSON = {
                    "0": 0,
                    "1": 6.25,
                    "2": 12.5
                };
                results.forEach(function (val) {
                    if (val.ATTR_VALUE === "0" || val.ATTR_VALUE === "1" || val.ATTR_VALUE === "2") {
                        iScore += aScoreJSON[val.ATTR_VALUE];
                    } else {
                        iScore += aScoreJSON["0"];
                    }
                });
            }
            return iScore;
        },
		/**
		 * get highlight for element based on given score
		 * @function getDealScoreState
		 * @public
		 * @param {array} results
		 **/
        getDealScoreState: function (results) {
            let iScore = 0;
            if (results) {
                const aScoreJSON = {
                    "0": 0,
                    "1": 6.25,
                    "2": 12.5
                };
                results.forEach(function (val) {
                    if (val.ATTR_VALUE === "0" || val.ATTR_VALUE === "1" || val.ATTR_VALUE === "2") {
                        iScore += aScoreJSON[val.ATTR_VALUE];
                    } else {
                        iScore += aScoreJSON["0"];
                    }
                });
            }
            if (iScore === 0) {
                return "None";
            } else if (iScore > 0 && iScore < 37.5) {
                return "Error";
            } else if (iScore >= 37.5 && iScore < 68.5) {
                return "Warning";
            }
            return "Success";
        },
        formatUrlNameDisplay: function(sUrlName , sUrl){
            if(sUrlName){
                return sUrlName;
            }else if(sUrl){
                return sUrl;
            }
        }
    };
});