sap.ui.define([
    "sap/m/MessageBox"
], function (MessageBox) {
    "use strict";

    return {

        //Handling Error Messages 
        setErrorMessage: function(oError, self){
            sap.ui.core.BusyIndicator.hide();
            let i18nModel = self.getOwnerComponent().getModel("i18n").getResourceBundle();
			let sErrorMess = i18nModel.getText("Somethingwentwrong");
            if (oError.responseText) {
                sap.ui.core.BusyIndicator.hide();
                MessageBox.error(oError.responseText, {
                });
            }else {
                MessageBox.error( sErrorMess , {
                });
            }
        }
       
    };
});
