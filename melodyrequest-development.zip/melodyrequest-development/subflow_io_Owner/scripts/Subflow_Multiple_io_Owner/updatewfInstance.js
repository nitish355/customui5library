var now = new Date();
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');

var CurrentProcessor = "",
    currentProcessorEmail = "",
    count = 0;

var io_OwnerDetails = $.context.io_OwnerResource.NominatedResources[0].ioOwnerDetails,
    io_OwnerIntro = "Dear " + io_OwnerDetails.IOOwnerName,
    io_OwnerEmails = io_OwnerDetails.IOOwnerEmail,
    io_OwnerIds = io_OwnerDetails.IOOwnerUserId,
    io_OwnerNames = io_OwnerDetails.IOOwnerName;

var wfdata = $.context.WfInstanceDBCall.Response;

wfdata.currentProcessor.split(',').forEach(function (val) {
    if (val == $.context.io_OwnerNames && count == 0) {
        count += 1;
        CurrentProcessor += io_OwnerDetails.IOOwnerName + ",";
    } else {
        CurrentProcessor += val + ",";

    }
});

count = 0;

wfdata.currentProcessorEmail.split(',').forEach(function (val) {
    if (val == $.context.io_OwnerEmails && count == 0) {
        count += 1;
        currentProcessorEmail += io_OwnerDetails.IOOwnerEmail + ",";
    } else {
        currentProcessorEmail += val + ",";

    }
});
CurrentProcessor = CurrentProcessor.slice(0, -1);
currentProcessorEmail = currentProcessorEmail.slice(0, -1);
var io_Decision = $.context.io_OwnerNames + " forwarded this request to ";

$.context.io_OwnerNames = io_OwnerNames;
$.context.notifyIo_OwnerEmailIntro = io_OwnerIntro;
$.context.io_OwnerEmails = io_OwnerEmails;
$.context.io_OwnerIds = io_OwnerIds;
io_Decision += $.context.io_OwnerNames;

var decision = {
    //"UserId": $.context.currentProcessor.id, // Userid for approvalHistory
    "UserName": $.context.currentProcessor.fullName,
    "Role": "IO Owner",
    "StepName": $.context.CurrentStepValue.IOOAPP.Value,//"Presales IO Owner Approval",
    "StepID": $.context.CurrentStepValue.IOOAPP.ID,
    "Decision": io_Decision,
    "Comments": $.context.io_OwnerResource.NominatedResources[0].IOownerComments,
    "Date": new Date()
};

$.context.approvalHistory.push(decision);

// Prepare data for WFINSTANCE New Table
var wfIns_data = {};
wfIns_data.dtLastActivity_tdate = date;
wfIns_data.dtLastActivity_ttime = time;
//wfIns_data.currentProcessorID = $.context.currentProcessor.id;
wfIns_data.currentProcessor = CurrentProcessor;
wfIns_data.currentProcessorEmail = currentProcessorEmail;

$.context.DBCall = {};
$.context.DBCall.Request = {};
$.context.DBCall.Request.requests = [];

var wfRequest = {
    id: "1",
    method: "PATCH",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WfInstance(instance_GUID='" + $.context.WfID_PresalesRequestApproval + "',parentInstance_GUID='" + $.context.parentInstanceID + "')",
    body: wfIns_data
};

$.context.DBCall.Request.requests.push(wfRequest);

var AssignData = {};
AssignData.DTLastActivity_tdate = date;
AssignData.DTLastActivity_ttime = time;
AssignData.CurrentProcessor = $.context.io_OwnerNames;

var aAssignmentID = $.context.io_OwnerResource.AssignmentID;
var WfAssignPatchURL = "/WfInstanceAssignment(InstanceID='" + $.context.WfID_PresalesRequestApproval + "',AssignmentID='" + aAssignmentID + "')";

var wfAssignRequest = {
    id: "2",
    dependsOn: ["1"],
    method: "PATCH",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: WfAssignPatchURL,
    body: AssignData
};
$.context.DBCall.Request.requests.push(wfAssignRequest);

