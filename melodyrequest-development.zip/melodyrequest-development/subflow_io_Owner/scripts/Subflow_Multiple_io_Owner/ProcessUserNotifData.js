var response =$.context.User_NotifDBCallPayload.Response;
 
$.context.RequesterEmail_Notif = "";
$.context.ProcessorEmail_Notif = "";
$.context.ResourceEmail_Notif = "";
$.context.ResProcessEmailNotif_flag = false;
$.context.ReqTypeOwnerEmail_Notif = "";

if (response.requester && response.requester.length > 0) {
 
  $.context.RequesterEmail_Notif = collectEmails("requester", true);
}
 
if (response.processor && response.processor.length > 0) {
  $.context.ProcessorEmail_Notif = collectEmails("processor", false);
}
 
if (response.resource && response.resource.length > 0) {
  $.context.ResourceEmail_Notif = collectEmails("resource", false);
}
if(response.reqTypeOwner && response.reqTypeOwner.length > 0)
{
   $.context.ReqTypeOwnerEmail_Notif = collectEmails("reqTypeOwner", true);   
}
if(response.processor && response.processor.length > 0 && response.resource && response.resource.length > 0)
{
  $.context.ResProcessEmailNotif_flag = true;
}
function collectEmails(role, single) {
  var users = response[role];
  if (!Array.isArray(users)) return single ? "" : [];
 
  var emails = users
    .filter(function (u) { return u.email; })
    .map(function (u) { return u.email; });
 
  return single ? (emails[0] || "") : emails.join(",");
}