// Io Owner details 
var io_OwnerDetails = $.context.io_OwnerResource.NominatedResources[0].ioOwnerDetails;
var
	io_OwnerIntro = "Dear " + io_OwnerDetails.IOOwnerName,
	io_OwnerEmails = io_OwnerDetails.IOOwnerEmail,
	io_OwnerIds = io_OwnerDetails.IOOwnerUserId,
	io_OwnerNames = io_OwnerDetails.IOOwnerName;

$.context.io_OwnerNames = io_OwnerNames;
$.context.notifyIo_OwnerEmailIntro = io_OwnerIntro;
$.context.io_OwnerEmails = io_OwnerEmails;
$.context.io_OwnerIds = io_OwnerIds;

// Nominated Resource Staffing Data for Email Notification
var NominatedAssignedPresales = $.context.io_OwnerResource.NominatedResources[0];

$.context.ResourceName = NominatedAssignedPresales.fullName;
$.context.ResourceEmail = NominatedAssignedPresales.email
$.context.ResourceUserId = NominatedAssignedPresales.userId
$.context.ResourceAssignedRole = $.context.io_OwnerResource.ResAssignedRoleData.name;
$.context.ResourceStaffingPurpose = NominatedAssignedPresales.staffingPurpose;
$.context.ResourceTaskLevel = NominatedAssignedPresales.taskLevelVal;
$.context.ResourceMaxNoOfDays = NominatedAssignedPresales.maxNoOfDaysToBookIO;
var DataRange = NominatedAssignedPresales.staffingDateRange.split("-");
$.context.startDateRange = DataRange[0].trim();
$.context.EndDateRange = DataRange[1].trim();
$.context.IO_Number = NominatedAssignedPresales.internalOrder;

if ($.context.NewOppDetails) {
	$.context.Opp_Sales_Office = $.context.NewOppDetails.Opp_Sales_Office ? $.context.NewOppDetails.Opp_Sales_Office : "";
	$.context.Opp_Partner = $.context.NewOppDetails.Opp_Partner ? $.context.NewOppDetails.Opp_Partner : "";
	$.context.Opp_SalesOrg_Name = $.context.NewOppDetails.Opp_SalesOrg_Name ? $.context.NewOppDetails.Opp_SalesOrg_Name : "";
	$.context.Opp_SalesGroupName = $.context.NewOppDetails.Opp_SalesGroupName ? $.context.NewOppDetails.Opp_SalesGroupName : "";
}
//code for email template
if($.context.isResourceProfile === true)
    {
    
    if (!$.context.resourcecomment) {
        $.context.resourcecomment = [];	
    }   
    
    while ($.context.resourcecomment.length < 10) {
        var reqResource = [{ class: "hidden-row" }];  
        var  assignedActivity =[];
        for (var i = 0; i < 5; i++) {
            assignedActivity.push({ class: "hidden-row" });
        }
        $.context.resourcecomment.push({
            reqResource: reqResource,
            assignedActivity: assignedActivity,
            ActivityHide: "hidden-row",
            comment: "",
            class: "hidden-row"
        });
    }
    }
if (!$.context.EmailTemplateVars) {
    $.context.EmailTemplateVars = {};
    $.context.EmailTemplateVars.FBSStyle = "";
    if ($.context.aResourceProfileApprovers.ResourceProfileDetails.SolutionAreas && $.context.aResourceProfileApprovers.ResourceProfileDetails.SolutionAreas.length > 0) {
        var SelectedSol = {}
        SelectedSol = $.context.aResourceProfileApprovers.ResourceProfileDetails.SolutionAreas[0];
    }
    if ($.context.aResourceProfileApprovers.ResourceProfileDetails.BAIndustries && $.context.aResourceProfileApprovers.ResourceProfileDetails.BAIndustries.length > 0) {
        var SelectedIndustry = {}
        SelectedIndustry = $.context.aResourceProfileApprovers.ResourceProfileDetails.BAIndustries[0];
    }
    if ($.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedGroup && $.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedGroup.length > 0) {
        var SelectedGroup = {}
        SelectedGroup = $.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedGroup[0];
    }
    $.context.EmailTemplateVars.Solution_Area = SelectedSol ? SelectedSol.SelectedSolutionArea : "Not selected";
    $.context.EmailTemplateVars.BA_Industry = SelectedIndustry ? SelectedIndustry.Desc : "Not selected";
    $.context.EmailTemplateVars.Requestor_need = $.context.requestDetails.typeOfSupport ? $.context.requestDetails.typeOfSupport : "Not specified by Requestor";
    $.context.EmailTemplateVars.supportType = $.context.requestDetails.supportType ? $.context.requestDetails.supportType : "Not specified by Requestor";
    $.context.EmailTemplateVars.Group = SelectedGroup ? SelectedGroup.SelectedGroup : "Not selected";
    if ($.context.RequestType == "Account") {
        $.context.EmailTemplateVars.OppHide = "hidden-row";
    }
}
$.context.HistoryClass =  (!$.context.EmailTemplateVars.approvalHistoryEmail) ? "hidden-row" : "history-table";
if (!$.context.EmailTemplateVars.EmailSubject) {
    if ($.context.RequestType === 'Account') {
        $.context.EmailTemplateVars.EmailSubject = $.context.accountName;
    }
    else {
        $.context.EmailTemplateVars.EmailSubject = $.context.Opp_Desc + ", " + $.context.accountName;
    }
}