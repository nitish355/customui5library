$.context.DBCall = {};
$.context.DBCall.Request = {};
$.context.DBCall.Request.requests = [];
$.context.ioForward = false;
$.context.ioApprove = false;
$.context.ioReject = false;
var io_ActionDecision = $.context.io_OwnerResource.NominatedResources[0].Io_Decision;
if ($.context.EmailTemplateVars && $.context.EmailTemplateVars.approvalHistoryEmail) {
    $.context.history = {};
    $.context.history.StepName = 'Review - IO Owner';
    $.context.history.class = "";
    $.context.history.HistoryData = "History-Data";
    var now = new Date();
    var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var day = ("0" + now.getUTCDate()).slice(-2), month = months[now.getUTCMonth()],year = now.getUTCFullYear();
    $.context.history.DateUTC = month + " " + day + ", " + year;
    var hours = now.getUTCHours(), minutes = ("0" + now.getUTCMinutes()).slice(-2),ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; 
    $.context.history.TimeUTC = hours + ":" + minutes + " " + ampm + " UTC"; 
    $.context.history.UserName = $.context.io_OwnerNames;
    $.context.history.LastStep = 'Review - IO Owner'
}
if (io_ActionDecision == "Forward") {

    $.context.ioForward = true;
}
if (io_ActionDecision == "Reject") {
    if ($.context.EmailTemplateVars && $.context.EmailTemplateVars.approvalHistoryEmail) {
        $.context.history.StepName = 'Review - IO Owner' + " - Sent Back to Processor"
        $.context.history.Decision = "The staffing request of " + $.context.ResourceName + " is Sent back to processor by " + $.context.io_OwnerNames ;
        $.context.history.Comments = $.context.io_OwnerResource.NominatedResources[0].IOownerComments? $.context.io_OwnerResource.NominatedResources[0].IOownerComments: "";
        $.context.EmailTemplateVars.approvalHistoryEmail.splice($.context.EmailTemplateVars.HistoryCount, 0, $.context.history);
        while ($.context.EmailTemplateVars.approvalHistoryEmail.length < 20) {
            $.context.EmailTemplateVars.approvalHistoryEmail.push({ class: "hidden-row", HistoryData: "hide-row" });
        }
        $.context.EmailTemplateVars.HistoryCount++;
    }

}
if (io_ActionDecision == "Approve" || io_ActionDecision == "Proceed") {
    if ($.context.EmailTemplateVars && $.context.EmailTemplateVars.approvalHistoryEmail) {
        $.context.history.StepName = 'Review - IO Owner' + " - Staffing Approved"
        $.context.history.Decision = "The staffing request of " + $.context.ResourceName + " is approved by " + $.context.io_OwnerNames;
        $.context.history.Comments = $.context.io_OwnerResource.NominatedResources[0].IOownerComments? $.context.io_OwnerResource.NominatedResources[0].IOownerComments: "";
        $.context.EmailTemplateVars.approvalHistoryEmail.splice($.context.EmailTemplateVars.HistoryCount, 0, $.context.history);
        while ($.context.EmailTemplateVars.approvalHistoryEmail.length < 20) {
            $.context.EmailTemplateVars.approvalHistoryEmail.push({ class: "hidden-row", HistoryData: "hide-row" });
        }
        $.context.EmailTemplateVars.HistoryCount++;
    }
    $.context.ioApprove = true;
    if ($.context.isSubstitute === true) {
        $.context.requestState = $.context.CurrentStateValue.RSBCOM.Value;
    }
    else {
        $.context.requestState = $.context.CurrentStateValue.REQCOM.Value;
    }
}
if (io_ActionDecision == "Close") {
    if ($.context.EmailTemplateVars && $.context.EmailTemplateVars.approvalHistoryEmail) {
        $.context.history.StepName = 'Review - IO Owner' + " - Staffing Rejected";
        $.context.history.Decision = "The staffing request of " + $.context.ResourceName + " is Rejected by " + $.context.io_OwnerNames;
        $.context.history.Comments = $.context.io_OwnerResource.NominatedResources[0].IOownerComments? $.context.io_OwnerResource.NominatedResources[0].IOownerComments: "";
        $.context.EmailTemplateVars.approvalHistoryEmail.splice($.context.EmailTemplateVars.HistoryCount, 0, $.context.history);
        while ($.context.EmailTemplateVars.approvalHistoryEmail.length < 20) {
            $.context.EmailTemplateVars.approvalHistoryEmail.push({ class: "hidden-row", HistoryData: "hide-row" });
        }
        $.context.EmailTemplateVars.HistoryCount++;
    }
    $.context.ioReject = true;
}
if ($.context.EmailTemplateVars && $.context.EmailTemplateVars.approvalHistoryEmail) {
$.context.EmailTemplateVars.LastActionDateTime = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].DateUTC + " at " + $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].TimeUTC;
$.context.EmailTemplateVars.LastAction = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].UserName +" – "+ $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].LastStep+" – "+$.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].Decision;
$.context.EmailTemplateVars.LastActionComment = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].Comments;
}
//prepare WFHistory Data 
var now = new Date();
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');
var ReqHistory_data = {};
ReqHistory_data.InstanceID = $.context.WfID_PresalesRequestApproval;
ReqHistory_data.UserTaskID = $.usertasks.usertask1.last.id
ReqHistory_data.AssignmentID = $.context.io_OwnerResource.AssignmentID;
ReqHistory_data.User_ID = $.context.io_OwnerIds;
ReqHistory_data.User_Name = $.context.io_OwnerNames;
ReqHistory_data.User_EMail = $.context.io_OwnerEmails;
ReqHistory_data.StateID = $.context.CurrentStateValue.WIOAPP.ID;
ReqHistory_data.StepID = $.context.CurrentStepValue.IOOAPP.ID;
if ($.context.decision === "Close") {
    ReqHistory_data.ActionTaken = "The staffing request of " + $.context.ResourceName + " is Rejected by " + $.context.io_OwnerNames + ".";
} else if ($.context.decision === "Proceed" || $.context.decision == "Approve") {
    ReqHistory_data.ActionTaken = "The staffing request of " + $.context.ResourceName + " is approved by " + $.context.io_OwnerNames + ".";
}
else if ($.context.decision === "Reject") {
    ReqHistory_data.ActionTaken = "The staffing request of " + $.context.ResourceName + " is Sent back to processor by " + $.context.io_OwnerNames + ".";
}
ReqHistory_data.Role = "IO Owner";
ReqHistory_data.Decision = $.context.decision_ID;//$.context.io_OwnerResource.NominatedResources[0].Io_Decision;
ReqHistory_data.Comments = $.context.history.Comments = $.context.io_OwnerResource.NominatedResources[0].IOownerComments? $.context.io_OwnerResource.NominatedResources[0].IOownerComments: "";
ReqHistory_data.Date = date;
ReqHistory_data.Time = time;
if (!$.context.UT_refID) {
    $.context.UT_refID = 1;
}
else {
    $.context.UT_refID += 1;
}
ReqHistory_data.UT_refID = $.context.UT_refID;

$.context.DBCall.Request.requests.push({
    id: "1",
    method: "POST",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WFHistory",
    body: ReqHistory_data
});

if (!$.context.io_Owner_email) {
    $.context.io_Owner_email = $.context.extSystemsUrls.MRRInboxURL + "IOOwnerDetailPage/" + $.info.workflowInstanceId;
    $.context.processor_email = $.context.extSystemsUrls.MRRInboxURL + "ManagerDetailPage/" + $.info.workflowInstanceId;
}
//code for email template
if ($.context.isResourceProfile === true) {

    if (!$.context.resourcecomment) {
        $.context.resourcecomment = [];
    }

    while ($.context.resourcecomment.length < 10) {
        var reqResource = [{ class: "hidden-row" }];
        var assignedActivity = [];
        for (var i = 0; i < 5; i++) {
            assignedActivity.push({ class: "hidden-row" });
        }
        $.context.resourcecomment.push({
            reqResource: reqResource,
            assignedActivity: assignedActivity,
            ActivityHide: "hidden-row",
            comment: "",
            class: "hidden-row"
        });
    }
}
if (!$.context.requestState) {
    if ($.context.isSubstitute === true) {
        $.context.requestState = $.context.CurrentStateValue.WSUBMN.Value;
    }
    else {
        $.context.requestState = $.context.CurrentStateValue.WMNAPP.Value;
    }
}


if ($.context.io_OwnerResource.NominatedResources[0].IOownerComments && $.context.io_OwnerResource.NominatedResources[0].IOownerComments.trim() !== "") {
    var UserTaskRole = "";
    var newdate = new Date().toISOString();
    if ($.context.UserTaskLabelValue) {
        UserTaskRole = $.context.UserTaskLabelValue.IoOwner.userTask;
    }
    $.context.DBCall.Request.requests.push({
        id: "2",
        method: "POST",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: "/Comments",
        body: {
            instanceID: $.context.WfID_PresalesRequestApproval,
            actionId: $.context.decision_ID,
            commentText: $.context.io_OwnerResource.NominatedResources[0].IOownerComments,
            userID: $.context.io_OwnerIds,
            userEmail: $.context.io_OwnerEmails,
            userName: $.context.io_OwnerNames,
            userRole: UserTaskRole,
            createdAt: newdate,
            modifiedAt: newdate
        }
    });
}

