{
	"contents": {
		"504749de-b69d-4500-97f9-8a75fa5bcc9c": {
			"classDefinition": "com.sap.bpm.wfs.Model",
			"id": "subflow_multiple_io_owner",
			"subject": "Subflow_Multiple_io_Owner",
			"name": "Subflow_Multiple_io_Owner",
			"documentation": "Subflow for IO Owner",
			"lastIds": "62d7f4ed-4063-4c44-af8b-39050bd44926",
			"events": {
				"11a9b5ee-17c0-4159-9bbf-454dcfdcd5c3": {
					"name": "StartEvent1"
				},
				"2798f4e7-bc42-4fad-a248-159095a2f40a": {
					"name": "EndEvent1"
				}
			},
			"activities": {
				"434180ae-1e60-49bb-afaa-91129d72cfa8": {
					"name": "Process Nominated IO Owners"
				},
				"fdf8dcce-78b0-4c63-b043-4d7a0f84b22d": {
					"name": "IO Owner Form"
				},
				"73f0c6fe-0c67-444d-b17e-ecfd612043cf": {
					"name": "Notify IO Owner "
				},
				"e28172d7-87ba-4493-aa2d-e11a6772a334": {
					"name": "What is a decision"
				},
				"789a6af2-7375-47b2-82e3-4958975b8ca5": {
					"name": "Process IO Owner Decision"
				},
				"88c1fb28-48e2-4e3e-b040-d2cc3930079e": {
					"name": "Notify IO Owner Send Back To Processor Decision"
				},
				"6a090fd8-8f84-4852-a0d1-fe0a6e88cbb2": {
					"name": "Notify IO Owner Approve Decision"
				},
				"deb8796b-aa55-472a-a720-d9858bfe69f9": {
					"name": "Get Data from WfInstance"
				},
				"bf190354-861f-4755-aa16-db6634650cbf": {
					"name": "Update wfInstance"
				},
				"d984fc6a-66db-428f-aa2b-fd40888b85cf": {
					"name": "Update WfInstance"
				},
				"a8a40fbf-ab5c-4029-ae54-574f774d920d": {
					"name": "WFHistory Update"
				},
				"0e388c33-e4ac-4c7d-ab5e-9a6d3dc172f7": {
					"name": "Notify IO Owner Reject Decision"
				},
				"707eda34-6cc2-4400-9847-a45d46902663": {
					"name": "Is Resource Profile"
				},
				"f021edc2-2941-44e7-965c-8725c04cd52b": {
					"name": "Notify Req Area IO Owner"
				},
				"45781e21-2b65-403d-9d63-31284b397ea5": {
					"name": "Is Resource Profile?"
				},
				"88d8f6c5-79ae-4951-bd50-4200f6cc9a1f": {
					"name": "Notify Request Area IO Owner Reject Decision"
				},
				"4c983399-1066-49cf-8423-f5168fcf4f1d": {
					"name": "Is Resource Profile?"
				},
				"0c6ba501-8616-400d-a2db-50a6acd0f0f6": {
					"name": "Notify IO Owner Send Back To Processor Decision"
				},
				"0bc1d5ef-179f-4911-8504-3189a674a8ba": {
					"name": "Notify IO Owner Approve Decision"
				},
				"9382c631-0326-4f34-930c-eb92367d7da0": {
					"name": "ExclusiveGateway6"
				},
				"632d73eb-fc24-4666-8908-dff7db7ef3b4": {
					"name": "Payload For IoOwner UserNotif Action"
				},
				"60a08b02-0804-43ce-a2ef-2ba2b50afe2e": {
					"name": "ServiceTask8"
				},
				"8a6b69c1-8f73-4a53-a19e-3b33b0d0a442": {
					"name": "Process User Notif Data"
				},
				"75cd6abb-96f0-48ab-89f9-de647649a7eb": {
					"name": "Email Flag"
				}
			},
			"sequenceFlows": {
				"c6b99f32-5fe6-4ab6-b60a-80fba1b9ae0f": {
					"name": "SequenceFlow1"
				},
				"938eb0c2-69f4-482d-b737-440bf5355e4d": {
					"name": "SequenceFlow2"
				},
				"2a17a2f1-95be-4fa7-81d9-3bb0749785f4": {
					"name": "SequenceFlow4"
				},
				"4f402bd3-1c75-470d-afc8-4ce46c0b064c": {
					"name": "Approve"
				},
				"e0a86ed7-f6db-4cf9-997e-e56c10da225e": {
					"name": "Forward"
				},
				"d4ca2265-f915-4367-aa2a-17a137972b71": {
					"name": "SequenceFlow8"
				},
				"72c0ea58-40b5-4bea-929a-10d788f1e40b": {
					"name": "Send Back To Processor"
				},
				"e354bf5c-60c2-4b5f-821e-f07dec3501f9": {
					"name": "SequenceFlow10"
				},
				"a73562c3-257b-4866-a75d-774d19e055ca": {
					"name": "SequenceFlow11"
				},
				"bf2fff19-0e99-4b3c-b5d9-a417f166b3fd": {
					"name": "SequenceFlow13"
				},
				"023546d2-776b-4031-871a-f9cbc0e6a6a4": {
					"name": "SequenceFlow14"
				},
				"2be19e2b-af24-4900-bde3-b572c78e5ed4": {
					"name": "SequenceFlow15"
				},
				"efa2f939-becf-4a87-bdc3-87a7ac892abe": {
					"name": "SequenceFlow16"
				},
				"d3618ffd-e407-41cf-91c6-800c41c9317d": {
					"name": "Reject"
				},
				"7663739d-14ba-4015-b761-71ab2d656e9b": {
					"name": "SequenceFlow19"
				},
				"c0dfacd2-e26d-4a14-bf79-aeb9f09d82fc": {
					"name": "SequenceFlow24"
				},
				"871d75eb-604b-462a-a6fc-834cc5ff1c89": {
					"name": "Yes"
				},
				"7ede1118-740a-4828-a64d-41cd719170c7": {
					"name": "No"
				},
				"5e553df6-46b3-49b7-8f8e-142fabaac846": {
					"name": "SequenceFlow28"
				},
				"d56effd0-4eea-4892-9a14-6b73374ae7ff": {
					"name": "Yes"
				},
				"ba723116-7b27-4d7b-8a5f-100d75213ab9": {
					"name": "No"
				},
				"6cd0cbe9-24ad-482e-9c92-c96df68b210f": {
					"name": "SequenceFlow32"
				},
				"e5c148de-7462-4058-990d-ea00faf01b9e": {
					"name": "Yes"
				},
				"31e7b968-c06c-4092-85dd-b3716ddfdd43": {
					"name": "Yes"
				},
				"f04bbec0-a2ac-4883-8710-f03c97b6ec10": {
					"name": "No"
				},
				"6946ea20-0f60-43bd-81ce-10b221301737": {
					"name": "SequenceFlow36"
				},
				"14065926-0b00-4b54-9747-603a1f4aeaba": {
					"name": "No"
				},
				"c543d699-8527-4216-8557-bb9ccf0f9498": {
					"name": "SequenceFlow38"
				},
				"9ace9e07-c064-4d98-aeef-b4938234037a": {
					"name": "SequenceFlow41"
				},
				"991ab06f-f00b-4802-9749-23ca58629f06": {
					"name": "SequenceFlow42"
				},
				"92f52a10-04d9-4c89-ab14-1c7ba0393bbc": {
					"name": "SequenceFlow43"
				},
				"8e124c63-a18a-465b-9e24-f46baa8b4807": {
					"name": "yes"
				},
				"c05b45f0-6710-4a03-a56e-a4945a57453b": {
					"name": "No"
				}
			},
			"diagrams": {
				"42fa7a2d-c526-4a02-b3ba-49b5168ba644": {}
			}
		},
		"11a9b5ee-17c0-4159-9bbf-454dcfdcd5c3": {
			"classDefinition": "com.sap.bpm.wfs.StartEvent",
			"id": "startevent1",
			"name": "StartEvent1"
		},
		"2798f4e7-bc42-4fad-a248-159095a2f40a": {
			"classDefinition": "com.sap.bpm.wfs.EndEvent",
			"id": "endevent1",
			"name": "EndEvent1"
		},
		"434180ae-1e60-49bb-afaa-91129d72cfa8": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Subflow_Multiple_io_Owner/ProcessNominatedIO_OwnersRequest.js",
			"id": "scripttask1",
			"name": "Process Nominated IO Owners"
		},
		"fdf8dcce-78b0-4c63-b043-4d7a0f84b22d": {
			"classDefinition": "com.sap.bpm.wfs.UserTask",
			"subject": "Approve Request for Staffing ${context.accNameFormatted} ${context.Approval_subject}",
			"priority": "MEDIUM",
			"isHiddenInLogForParticipant": false,
			"supportsForward": false,
			"userInterface": "sapui5://dealsupportapp.comsapbpmIOownerForm/com.sap.bpm.IOownerForm",
			"recipientUsers": "${context.io_OwnerIds}",
			"id": "usertask1",
			"name": "IO Owner Form"
		},
		"73f0c6fe-0c67-444d-b17e-ecfd612043cf": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask2",
			"name": "Notify IO Owner ",
			"mailDefinitionRef": "a2e6c210-5405-473d-95c6-fb40f022d24e"
		},
		"e28172d7-87ba-4493-aa2d-e11a6772a334": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway1",
			"name": "What is a decision",
			"default": "72c0ea58-40b5-4bea-929a-10d788f1e40b"
		},
		"789a6af2-7375-47b2-82e3-4958975b8ca5": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Subflow_Multiple_io_Owner/ProcessIO_OwnerDecision.js",
			"id": "scripttask2",
			"name": "Process IO Owner Decision"
		},
		"88c1fb28-48e2-4e3e-b040-d2cc3930079e": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask3",
			"name": "Notify IO Owner Send Back To Processor Decision",
			"mailDefinitionRef": "9023d70a-1a46-43a9-bae1-03d46b48cd7d"
		},
		"6a090fd8-8f84-4852-a0d1-fe0a6e88cbb2": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask4",
			"name": "Notify IO Owner Approve Decision",
			"mailDefinitionRef": "b5b7bf93-6e1d-4287-b5c7-f05e67f47ba3"
		},
		"deb8796b-aa55-472a-a720-d9858bfe69f9": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "wf/WfInstance(instance_GUID='${context.WfID_PresalesRequestApproval}',parentInstance_GUID='${context.parentInstanceID}')",
			"httpMethod": "GET",
			"responseVariable": "${context.WfInstanceDBCall.Response}",
			"id": "servicetask1",
			"name": "Get Data from WfInstance"
		},
		"bf190354-861f-4755-aa16-db6634650cbf": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Subflow_Multiple_io_Owner/updatewfInstance.js",
			"id": "scripttask4",
			"name": "Update wfInstance"
		},
		"d984fc6a-66db-428f-aa2b-fd40888b85cf": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.DBCall.Request}",
			"responseVariable": "${context.DBCall.Response}",
			"id": "servicetask2",
			"name": "Update WfInstance"
		},
		"a8a40fbf-ab5c-4029-ae54-574f774d920d": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.DBCall.Request}",
			"responseVariable": "${context.DBCall.Response}",
			"id": "servicetask3",
			"name": "WFHistory Update"
		},
		"0e388c33-e4ac-4c7d-ab5e-9a6d3dc172f7": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask5",
			"name": "Notify IO Owner Reject Decision",
			"mailDefinitionRef": "b3d62195-23cc-49a3-9115-45ca614ccfa6"
		},
		"707eda34-6cc2-4400-9847-a45d46902663": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway3",
			"name": "Is Resource Profile",
			"default": "7ede1118-740a-4828-a64d-41cd719170c7"
		},
		"f021edc2-2941-44e7-965c-8725c04cd52b": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask6",
			"name": "Notify Req Area IO Owner",
			"mailDefinitionRef": "8ac46f25-c153-45e7-92f1-9eaa74ad6c09"
		},
		"45781e21-2b65-403d-9d63-31284b397ea5": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway4",
			"name": "Is Resource Profile?",
			"default": "ba723116-7b27-4d7b-8a5f-100d75213ab9"
		},
		"88d8f6c5-79ae-4951-bd50-4200f6cc9a1f": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask8",
			"name": "Notify Request Area IO Owner Reject Decision",
			"mailDefinitionRef": "231eeb16-c78f-4bd1-b876-9c790e7877ef"
		},
		"4c983399-1066-49cf-8423-f5168fcf4f1d": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway5",
			"name": "Is Resource Profile?",
			"default": "14065926-0b00-4b54-9747-603a1f4aeaba"
		},
		"0c6ba501-8616-400d-a2db-50a6acd0f0f6": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask9",
			"name": "Notify IO Owner Send Back To Processor Decision",
			"mailDefinitionRef": "2061ef76-3e8b-433c-926f-c1b8dbdedb0b"
		},
		"0bc1d5ef-179f-4911-8504-3189a674a8ba": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask10",
			"name": "Notify IO Owner Approve Decision",
			"mailDefinitionRef": "2c763fd1-a859-4dfb-9e8b-7d42154cb586"
		},
		"9382c631-0326-4f34-930c-eb92367d7da0": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway6",
			"name": "ExclusiveGateway6",
			"default": "f04bbec0-a2ac-4883-8710-f03c97b6ec10"
		},
		"632d73eb-fc24-4666-8908-dff7db7ef3b4": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Subflow_Multiple_io_Owner/PreparePayloadForioOwnerUserNotifAction.js",
			"id": "scripttask7",
			"name": "Payload For IoOwner UserNotif Action"
		},
		"60a08b02-0804-43ce-a2ef-2ba2b50afe2e": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/GetUserNotificationSettings",
			"httpMethod": "POST",
			"requestVariable": "${context.User_NotifDBCallPayload}",
			"responseVariable": "${context.User_NotifDBCallPayload.Response}",
			"id": "servicetask8",
			"name": "ServiceTask8"
		},
		"8a6b69c1-8f73-4a53-a19e-3b33b0d0a442": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Subflow_Multiple_io_Owner/ProcessUserNotifData.js",
			"id": "scripttask8",
			"name": "Process User Notif Data"
		},
		"75cd6abb-96f0-48ab-89f9-de647649a7eb": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway7",
			"name": "Email Flag",
			"default": "c05b45f0-6710-4a03-a56e-a4945a57453b"
		},
		"c6b99f32-5fe6-4ab6-b60a-80fba1b9ae0f": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow1",
			"name": "SequenceFlow1",
			"sourceRef": "11a9b5ee-17c0-4159-9bbf-454dcfdcd5c3",
			"targetRef": "434180ae-1e60-49bb-afaa-91129d72cfa8"
		},
		"938eb0c2-69f4-482d-b737-440bf5355e4d": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow2",
			"name": "SequenceFlow2",
			"sourceRef": "434180ae-1e60-49bb-afaa-91129d72cfa8",
			"targetRef": "707eda34-6cc2-4400-9847-a45d46902663"
		},
		"2a17a2f1-95be-4fa7-81d9-3bb0749785f4": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow4",
			"name": "SequenceFlow4",
			"sourceRef": "73f0c6fe-0c67-444d-b17e-ecfd612043cf",
			"targetRef": "fdf8dcce-78b0-4c63-b043-4d7a0f84b22d"
		},
		"4f402bd3-1c75-470d-afc8-4ce46c0b064c": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.ioApprove}",
			"id": "sequenceflow5",
			"name": "Approve",
			"sourceRef": "e28172d7-87ba-4493-aa2d-e11a6772a334",
			"targetRef": "9382c631-0326-4f34-930c-eb92367d7da0"
		},
		"e0a86ed7-f6db-4cf9-997e-e56c10da225e": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.ioForward}",
			"id": "sequenceflow7",
			"name": "Forward",
			"sourceRef": "e28172d7-87ba-4493-aa2d-e11a6772a334",
			"targetRef": "deb8796b-aa55-472a-a720-d9858bfe69f9"
		},
		"d4ca2265-f915-4367-aa2a-17a137972b71": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow8",
			"name": "SequenceFlow8",
			"sourceRef": "789a6af2-7375-47b2-82e3-4958975b8ca5",
			"targetRef": "a8a40fbf-ab5c-4029-ae54-574f774d920d"
		},
		"72c0ea58-40b5-4bea-929a-10d788f1e40b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow9",
			"name": "Send Back To Processor",
			"sourceRef": "e28172d7-87ba-4493-aa2d-e11a6772a334",
			"targetRef": "4c983399-1066-49cf-8423-f5168fcf4f1d"
		},
		"e354bf5c-60c2-4b5f-821e-f07dec3501f9": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow10",
			"name": "SequenceFlow10",
			"sourceRef": "88c1fb28-48e2-4e3e-b040-d2cc3930079e",
			"targetRef": "2798f4e7-bc42-4fad-a248-159095a2f40a"
		},
		"a73562c3-257b-4866-a75d-774d19e055ca": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow11",
			"name": "SequenceFlow11",
			"sourceRef": "6a090fd8-8f84-4852-a0d1-fe0a6e88cbb2",
			"targetRef": "2798f4e7-bc42-4fad-a248-159095a2f40a"
		},
		"bf2fff19-0e99-4b3c-b5d9-a417f166b3fd": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow13",
			"name": "SequenceFlow13",
			"sourceRef": "deb8796b-aa55-472a-a720-d9858bfe69f9",
			"targetRef": "bf190354-861f-4755-aa16-db6634650cbf"
		},
		"023546d2-776b-4031-871a-f9cbc0e6a6a4": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow14",
			"name": "SequenceFlow14",
			"sourceRef": "bf190354-861f-4755-aa16-db6634650cbf",
			"targetRef": "d984fc6a-66db-428f-aa2b-fd40888b85cf"
		},
		"2be19e2b-af24-4900-bde3-b572c78e5ed4": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow15",
			"name": "SequenceFlow15",
			"sourceRef": "d984fc6a-66db-428f-aa2b-fd40888b85cf",
			"targetRef": "73f0c6fe-0c67-444d-b17e-ecfd612043cf"
		},
		"efa2f939-becf-4a87-bdc3-87a7ac892abe": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow16",
			"name": "SequenceFlow16",
			"sourceRef": "a8a40fbf-ab5c-4029-ae54-574f774d920d",
			"targetRef": "632d73eb-fc24-4666-8908-dff7db7ef3b4"
		},
		"d3618ffd-e407-41cf-91c6-800c41c9317d": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.ioReject}",
			"id": "sequenceflow17",
			"name": "Reject",
			"sourceRef": "e28172d7-87ba-4493-aa2d-e11a6772a334",
			"targetRef": "45781e21-2b65-403d-9d63-31284b397ea5"
		},
		"7663739d-14ba-4015-b761-71ab2d656e9b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow19",
			"name": "SequenceFlow19",
			"sourceRef": "0e388c33-e4ac-4c7d-ab5e-9a6d3dc172f7",
			"targetRef": "2798f4e7-bc42-4fad-a248-159095a2f40a"
		},
		"c0dfacd2-e26d-4a14-bf79-aeb9f09d82fc": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow24",
			"name": "SequenceFlow24",
			"sourceRef": "fdf8dcce-78b0-4c63-b043-4d7a0f84b22d",
			"targetRef": "789a6af2-7375-47b2-82e3-4958975b8ca5"
		},
		"871d75eb-604b-462a-a6fc-834cc5ff1c89": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isResourceProfile}",
			"id": "sequenceflow26",
			"name": "Yes",
			"sourceRef": "707eda34-6cc2-4400-9847-a45d46902663",
			"targetRef": "73f0c6fe-0c67-444d-b17e-ecfd612043cf"
		},
		"7ede1118-740a-4828-a64d-41cd719170c7": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow27",
			"name": "No",
			"sourceRef": "707eda34-6cc2-4400-9847-a45d46902663",
			"targetRef": "f021edc2-2941-44e7-965c-8725c04cd52b"
		},
		"5e553df6-46b3-49b7-8f8e-142fabaac846": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow28",
			"name": "SequenceFlow28",
			"sourceRef": "f021edc2-2941-44e7-965c-8725c04cd52b",
			"targetRef": "fdf8dcce-78b0-4c63-b043-4d7a0f84b22d"
		},
		"d56effd0-4eea-4892-9a14-6b73374ae7ff": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isResourceProfile}",
			"id": "sequenceflow29",
			"name": "Yes",
			"sourceRef": "45781e21-2b65-403d-9d63-31284b397ea5",
			"targetRef": "0e388c33-e4ac-4c7d-ab5e-9a6d3dc172f7"
		},
		"ba723116-7b27-4d7b-8a5f-100d75213ab9": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow30",
			"name": "No",
			"sourceRef": "45781e21-2b65-403d-9d63-31284b397ea5",
			"targetRef": "88d8f6c5-79ae-4951-bd50-4200f6cc9a1f"
		},
		"6cd0cbe9-24ad-482e-9c92-c96df68b210f": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow32",
			"name": "SequenceFlow32",
			"sourceRef": "88d8f6c5-79ae-4951-bd50-4200f6cc9a1f",
			"targetRef": "2798f4e7-bc42-4fad-a248-159095a2f40a"
		},
		"e5c148de-7462-4058-990d-ea00faf01b9e": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isResourceProfile}",
			"id": "sequenceflow33",
			"name": "Yes",
			"sourceRef": "4c983399-1066-49cf-8423-f5168fcf4f1d",
			"targetRef": "75cd6abb-96f0-48ab-89f9-de647649a7eb"
		},
		"31e7b968-c06c-4092-85dd-b3716ddfdd43": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isResourceProfile}",
			"id": "sequenceflow34",
			"name": "Yes",
			"sourceRef": "9382c631-0326-4f34-930c-eb92367d7da0",
			"targetRef": "6a090fd8-8f84-4852-a0d1-fe0a6e88cbb2"
		},
		"f04bbec0-a2ac-4883-8710-f03c97b6ec10": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow35",
			"name": "No",
			"sourceRef": "9382c631-0326-4f34-930c-eb92367d7da0",
			"targetRef": "0bc1d5ef-179f-4911-8504-3189a674a8ba"
		},
		"6946ea20-0f60-43bd-81ce-10b221301737": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow36",
			"name": "SequenceFlow36",
			"sourceRef": "0bc1d5ef-179f-4911-8504-3189a674a8ba",
			"targetRef": "2798f4e7-bc42-4fad-a248-159095a2f40a"
		},
		"14065926-0b00-4b54-9747-603a1f4aeaba": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow37",
			"name": "No",
			"sourceRef": "4c983399-1066-49cf-8423-f5168fcf4f1d",
			"targetRef": "0c6ba501-8616-400d-a2db-50a6acd0f0f6"
		},
		"c543d699-8527-4216-8557-bb9ccf0f9498": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow38",
			"name": "SequenceFlow38",
			"sourceRef": "0c6ba501-8616-400d-a2db-50a6acd0f0f6",
			"targetRef": "2798f4e7-bc42-4fad-a248-159095a2f40a"
		},
		"9ace9e07-c064-4d98-aeef-b4938234037a": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow41",
			"name": "SequenceFlow41",
			"sourceRef": "632d73eb-fc24-4666-8908-dff7db7ef3b4",
			"targetRef": "60a08b02-0804-43ce-a2ef-2ba2b50afe2e"
		},
		"991ab06f-f00b-4802-9749-23ca58629f06": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow42",
			"name": "SequenceFlow42",
			"sourceRef": "60a08b02-0804-43ce-a2ef-2ba2b50afe2e",
			"targetRef": "8a6b69c1-8f73-4a53-a19e-3b33b0d0a442"
		},
		"92f52a10-04d9-4c89-ab14-1c7ba0393bbc": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow43",
			"name": "SequenceFlow43",
			"sourceRef": "8a6b69c1-8f73-4a53-a19e-3b33b0d0a442",
			"targetRef": "e28172d7-87ba-4493-aa2d-e11a6772a334"
		},
		"8e124c63-a18a-465b-9e24-f46baa8b4807": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.ResProcessEmailNotif_flag}",
			"id": "sequenceflow44",
			"name": "yes",
			"sourceRef": "75cd6abb-96f0-48ab-89f9-de647649a7eb",
			"targetRef": "88c1fb28-48e2-4e3e-b040-d2cc3930079e"
		},
		"c05b45f0-6710-4a03-a56e-a4945a57453b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow45",
			"name": "No",
			"sourceRef": "75cd6abb-96f0-48ab-89f9-de647649a7eb",
			"targetRef": "2798f4e7-bc42-4fad-a248-159095a2f40a"
		},
		"42fa7a2d-c526-4a02-b3ba-49b5168ba644": {
			"classDefinition": "com.sap.bpm.wfs.ui.Diagram",
			"symbols": {
				"df898b52-91e1-4778-baad-2ad9a261d30e": {},
				"53e54950-7757-4161-82c9-afa7e86cff2c": {},
				"6bb141da-d485-4317-93b8-e17711df4c32": {},
				"6951f6ca-e734-42e0-95af-0b15ef8ec1da": {},
				"9a8cadd6-e5a0-4cad-ab20-ba6aaf03ed7c": {},
				"1f41a0eb-ab60-4e2c-9825-24d2b24f841d": {},
				"c69f18ad-ae33-4688-bb62-d4d4e764b59b": {},
				"8b6ca1d7-3516-4f70-a18c-4b99c552ccc8": {},
				"b9ba38cb-8e2f-4231-adb0-ee34dcf0e840": {},
				"304f33c8-359a-402d-b7e8-a7099399bde6": {},
				"e45fa444-be7f-4b45-a38a-7d59e2023dbd": {},
				"72bb79da-4e89-4697-9517-fa7b1850ea0e": {},
				"87d4ec8f-376f-40d4-90ad-7fd2eb46e417": {},
				"9291435c-34cc-4a7d-aead-14ad042bf409": {},
				"b721179e-c11d-4929-ac48-e1333f3a5ad5": {},
				"9d9fdf60-3e00-4816-8c90-bfeab36a182c": {},
				"3bdfc72f-469a-4587-9549-a2ba23c7521b": {},
				"c4859a67-68a1-4b85-b703-139dbe88bd94": {},
				"b48684de-fcaf-4272-8d33-2dd62c641f03": {},
				"682b58de-6af3-4efc-a005-26413c8e5dbd": {},
				"793a5b18-be4c-4847-b968-703065ba07d6": {},
				"b9cd352a-7701-451f-8036-9a36354a4be5": {},
				"f9819bdb-e00d-46e4-a416-0fc9c9eb45dc": {},
				"660eeaf9-8f55-4e8f-82d9-d9bee6c6bab5": {},
				"02af4dd0-7fcf-49b6-bf6b-c7a2022148e5": {},
				"79099aa0-d7ea-432e-9545-255053021514": {},
				"ce0e67aa-5313-4351-9b97-32a0a203fdec": {},
				"8369bc64-efc9-4e91-8576-5197c51957cf": {},
				"0eddeaf2-cc41-4712-b0b8-e1e0cdf2ac41": {},
				"117f5dec-f27b-4fb8-9c3d-ab1a7a1c7ef2": {},
				"25bd590a-94f7-4731-b237-2357b90b3825": {},
				"1addf09c-be0f-4e79-8eae-6321b014b1d1": {},
				"7bf87f3d-7f14-453c-8908-375aa2d86b18": {},
				"711e43f2-f38c-4d7b-87ee-3a5ff8dd7ebc": {},
				"dd00f4a2-8813-45e5-9219-cf024adca271": {},
				"63ebae70-d21f-42f4-9626-7ac53b780784": {},
				"87d52c84-6644-483e-aa49-98babc728e11": {},
				"06f3c048-25a4-423f-ae1c-6dfc3197de12": {},
				"bcf58330-7163-4bee-91e8-05e6d62c6940": {},
				"62d0732c-0c99-4fca-9192-933c5d331dcf": {},
				"7f2df68a-58ac-4895-98f9-716b33e65dec": {},
				"1b76ab8d-c4d1-402b-89b3-69cd496ee4c4": {},
				"b5792d26-8c66-4980-b52a-a27e64332907": {},
				"7bbd5c4c-2b0c-4a2c-a6d0-af33bf061979": {},
				"60ae817e-4345-4ea7-81fc-d22274eb2738": {},
				"d49b9767-0c2e-4bf3-afd1-7237f4f4b308": {},
				"4b615ca6-ada7-49e0-bf6c-225c3a827a36": {},
				"3bcbd1e7-ead0-4504-83e4-67f33fba4fce": {},
				"10c5be8b-db04-4636-a45e-fd54758b85a3": {},
				"9927b323-c785-48ce-9f65-752babf9a47d": {},
				"61161d3a-888c-4a6c-aeda-e8f05cd20a6c": {},
				"00855b66-2fdc-43d0-bad9-d833155635d1": {},
				"3bccb17a-af24-436b-8e2a-9b271bac658d": {},
				"51d74898-16fe-409f-a7ae-ea8d5c7e19f6": {},
				"1b49ab67-370c-41f5-a6ba-8e5f16ecae87": {},
				"5adb228a-dfb8-4737-a9ab-38eb01477cd7": {},
				"a473db88-4cf0-44bf-95f7-857dff1a2343": {},
				"6c39c494-1b04-4516-8684-7b2fd86dc0c4": {},
				"0e2af364-63f1-453b-a479-7eeafa2906bf": {}
			}
		},
		"df898b52-91e1-4778-baad-2ad9a261d30e": {
			"classDefinition": "com.sap.bpm.wfs.ui.StartEventSymbol",
			"x": -44,
			"y": 102,
			"width": 32,
			"height": 32,
			"object": "11a9b5ee-17c0-4159-9bbf-454dcfdcd5c3"
		},
		"53e54950-7757-4161-82c9-afa7e86cff2c": {
			"classDefinition": "com.sap.bpm.wfs.ui.EndEventSymbol",
			"x": 1934,
			"y": 91,
			"width": 35,
			"height": 35,
			"object": "2798f4e7-bc42-4fad-a248-159095a2f40a"
		},
		"6bb141da-d485-4317-93b8-e17711df4c32": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-28,118 83,118",
			"sourceSymbol": "df898b52-91e1-4778-baad-2ad9a261d30e",
			"targetSymbol": "6951f6ca-e734-42e0-95af-0b15ef8ec1da",
			"object": "c6b99f32-5fe6-4ab6-b60a-80fba1b9ae0f"
		},
		"6951f6ca-e734-42e0-95af-0b15ef8ec1da": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 33,
			"y": 88,
			"width": 100,
			"height": 60,
			"object": "434180ae-1e60-49bb-afaa-91129d72cfa8"
		},
		"9a8cadd6-e5a0-4cad-ab20-ba6aaf03ed7c": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "83,118.5 200,118.5",
			"sourceSymbol": "6951f6ca-e734-42e0-95af-0b15ef8ec1da",
			"targetSymbol": "25bd590a-94f7-4731-b237-2357b90b3825",
			"object": "938eb0c2-69f4-482d-b737-440bf5355e4d"
		},
		"1f41a0eb-ab60-4e2c-9825-24d2b24f841d": {
			"classDefinition": "com.sap.bpm.wfs.ui.UserTaskSymbol",
			"x": 492,
			"y": 88,
			"width": 100,
			"height": 60,
			"object": "fdf8dcce-78b0-4c63-b043-4d7a0f84b22d"
		},
		"c69f18ad-ae33-4688-bb62-d4d4e764b59b": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": 306,
			"y": 88,
			"width": 100,
			"height": 60,
			"object": "73f0c6fe-0c67-444d-b17e-ecfd612043cf"
		},
		"8b6ca1d7-3516-4f70-a18c-4b99c552ccc8": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "356,118 542,118",
			"sourceSymbol": "c69f18ad-ae33-4688-bb62-d4d4e764b59b",
			"targetSymbol": "1f41a0eb-ab60-4e2c-9825-24d2b24f841d",
			"object": "2a17a2f1-95be-4fa7-81d9-3bb0749785f4"
		},
		"b9ba38cb-8e2f-4231-adb0-ee34dcf0e840": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 1441,
			"y": 91,
			"object": "e28172d7-87ba-4493-aa2d-e11a6772a334"
		},
		"304f33c8-359a-402d-b7e8-a7099399bde6": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1462,110 1572,110",
			"sourceSymbol": "b9ba38cb-8e2f-4231-adb0-ee34dcf0e840",
			"targetSymbol": "60ae817e-4345-4ea7-81fc-d22274eb2738",
			"object": "4f402bd3-1c75-470d-afc8-4ce46c0b064c"
		},
		"e45fa444-be7f-4b45-a38a-7d59e2023dbd": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1461,112 1461,251 773,251",
			"sourceSymbol": "b9ba38cb-8e2f-4231-adb0-ee34dcf0e840",
			"targetSymbol": "b48684de-fcaf-4272-8d33-2dd62c641f03",
			"object": "e0a86ed7-f6db-4cf9-997e-e56c10da225e"
		},
		"72bb79da-4e89-4697-9517-fa7b1850ea0e": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 655,
			"y": 88,
			"width": 100,
			"height": 60,
			"object": "789a6af2-7375-47b2-82e3-4958975b8ca5"
		},
		"87d4ec8f-376f-40d4-90ad-7fd2eb46e417": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "705,118 932,118",
			"sourceSymbol": "72bb79da-4e89-4697-9517-fa7b1850ea0e",
			"targetSymbol": "02af4dd0-7fcf-49b6-bf6b-c7a2022148e5",
			"object": "d4ca2265-f915-4367-aa2a-17a137972b71"
		},
		"9291435c-34cc-4a7d-aead-14ad042bf409": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1463.5,112 1463.5,-56",
			"sourceSymbol": "b9ba38cb-8e2f-4231-adb0-ee34dcf0e840",
			"targetSymbol": "7f2df68a-58ac-4895-98f9-716b33e65dec",
			"object": "72c0ea58-40b5-4bea-929a-10d788f1e40b"
		},
		"b721179e-c11d-4929-ac48-e1333f3a5ad5": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": 1657,
			"y": -148,
			"width": 100,
			"height": 60,
			"object": "88c1fb28-48e2-4e3e-b040-d2cc3930079e"
		},
		"9d9fdf60-3e00-4816-8c90-bfeab36a182c": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1707,-118 1966,-118 1966,108.5",
			"sourceSymbol": "b721179e-c11d-4929-ac48-e1333f3a5ad5",
			"targetSymbol": "53e54950-7757-4161-82c9-afa7e86cff2c",
			"object": "e354bf5c-60c2-4b5f-821e-f07dec3501f9"
		},
		"3bdfc72f-469a-4587-9549-a2ba23c7521b": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": 1645,
			"y": 82,
			"width": 100,
			"height": 60,
			"object": "6a090fd8-8f84-4852-a0d1-fe0a6e88cbb2"
		},
		"c4859a67-68a1-4b85-b703-139dbe88bd94": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1695,110.25 1951.5,110.25",
			"sourceSymbol": "3bdfc72f-469a-4587-9549-a2ba23c7521b",
			"targetSymbol": "53e54950-7757-4161-82c9-afa7e86cff2c",
			"object": "a73562c3-257b-4866-a75d-774d19e055ca"
		},
		"b48684de-fcaf-4272-8d33-2dd62c641f03": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 723,
			"y": 220,
			"width": 100,
			"height": 60,
			"object": "deb8796b-aa55-472a-a720-d9858bfe69f9"
		},
		"682b58de-6af3-4efc-a005-26413c8e5dbd": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "773,248.5 654,248.5",
			"sourceSymbol": "b48684de-fcaf-4272-8d33-2dd62c641f03",
			"targetSymbol": "793a5b18-be4c-4847-b968-703065ba07d6",
			"object": "bf2fff19-0e99-4b3c-b5d9-a417f166b3fd"
		},
		"793a5b18-be4c-4847-b968-703065ba07d6": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 586,
			"y": 220,
			"width": 100,
			"height": 60,
			"object": "bf190354-861f-4755-aa16-db6634650cbf"
		},
		"b9cd352a-7701-451f-8036-9a36354a4be5": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "636,249 521,249",
			"sourceSymbol": "793a5b18-be4c-4847-b968-703065ba07d6",
			"targetSymbol": "f9819bdb-e00d-46e4-a416-0fc9c9eb45dc",
			"object": "023546d2-776b-4031-871a-f9cbc0e6a6a4"
		},
		"f9819bdb-e00d-46e4-a416-0fc9c9eb45dc": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 456,
			"y": 220,
			"width": 100,
			"height": 60,
			"object": "d984fc6a-66db-428f-aa2b-fd40888b85cf"
		},
		"660eeaf9-8f55-4e8f-82d9-d9bee6c6bab5": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "496,246 430.75,246 430.75,118 355,118",
			"sourceSymbol": "f9819bdb-e00d-46e4-a416-0fc9c9eb45dc",
			"targetSymbol": "c69f18ad-ae33-4688-bb62-d4d4e764b59b",
			"object": "2be19e2b-af24-4900-bde3-b572c78e5ed4"
		},
		"02af4dd0-7fcf-49b6-bf6b-c7a2022148e5": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 882,
			"y": 88,
			"width": 100,
			"height": 60,
			"object": "a8a40fbf-ab5c-4029-ae54-574f774d920d"
		},
		"79099aa0-d7ea-432e-9545-255053021514": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "932,115 1090,115",
			"sourceSymbol": "02af4dd0-7fcf-49b6-bf6b-c7a2022148e5",
			"targetSymbol": "61161d3a-888c-4a6c-aeda-e8f05cd20a6c",
			"object": "efa2f939-becf-4a87-bdc3-87a7ac892abe"
		},
		"ce0e67aa-5313-4351-9b97-32a0a203fdec": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1477,112 1477,191 1577,191",
			"sourceSymbol": "b9ba38cb-8e2f-4231-adb0-ee34dcf0e840",
			"targetSymbol": "63ebae70-d21f-42f4-9626-7ac53b780784",
			"object": "d3618ffd-e407-41cf-91c6-800c41c9317d"
		},
		"8369bc64-efc9-4e91-8576-5197c51957cf": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": 1788,
			"y": 161,
			"width": 100,
			"height": 60,
			"object": "0e388c33-e4ac-4c7d-ab5e-9a6d3dc172f7"
		},
		"0eddeaf2-cc41-4712-b0b8-e1e0cdf2ac41": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1838,191 1956,191 1956,108.5",
			"sourceSymbol": "8369bc64-efc9-4e91-8576-5197c51957cf",
			"targetSymbol": "53e54950-7757-4161-82c9-afa7e86cff2c",
			"object": "7663739d-14ba-4015-b761-71ab2d656e9b"
		},
		"117f5dec-f27b-4fb8-9c3d-ab1a7a1c7ef2": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "542,118 705,118",
			"sourceSymbol": "1f41a0eb-ab60-4e2c-9825-24d2b24f841d",
			"targetSymbol": "72bb79da-4e89-4697-9517-fa7b1850ea0e",
			"object": "c0dfacd2-e26d-4a14-bf79-aeb9f09d82fc"
		},
		"25bd590a-94f7-4731-b237-2357b90b3825": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 179,
			"y": 98,
			"object": "707eda34-6cc2-4400-9847-a45d46902663"
		},
		"1addf09c-be0f-4e79-8eae-6321b014b1d1": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "200,118.5 356,118.5",
			"sourceSymbol": "25bd590a-94f7-4731-b237-2357b90b3825",
			"targetSymbol": "c69f18ad-ae33-4688-bb62-d4d4e764b59b",
			"object": "871d75eb-604b-462a-a6fc-834cc5ff1c89"
		},
		"7bf87f3d-7f14-453c-8908-375aa2d86b18": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "199,119 199,36 356,36",
			"sourceSymbol": "25bd590a-94f7-4731-b237-2357b90b3825",
			"targetSymbol": "711e43f2-f38c-4d7b-87ee-3a5ff8dd7ebc",
			"object": "7ede1118-740a-4828-a64d-41cd719170c7"
		},
		"711e43f2-f38c-4d7b-87ee-3a5ff8dd7ebc": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": 306,
			"y": 12,
			"width": 100,
			"height": 60,
			"object": "f021edc2-2941-44e7-965c-8725c04cd52b"
		},
		"dd00f4a2-8813-45e5-9219-cf024adca271": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "356,42 449.25,42 449.25,118 542,118",
			"sourceSymbol": "711e43f2-f38c-4d7b-87ee-3a5ff8dd7ebc",
			"targetSymbol": "1f41a0eb-ab60-4e2c-9825-24d2b24f841d",
			"object": "5e553df6-46b3-49b7-8f8e-142fabaac846"
		},
		"63ebae70-d21f-42f4-9626-7ac53b780784": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 1556,
			"y": 170,
			"object": "45781e21-2b65-403d-9d63-31284b397ea5"
		},
		"87d52c84-6644-483e-aa49-98babc728e11": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1577,191 1838,191",
			"sourceSymbol": "63ebae70-d21f-42f4-9626-7ac53b780784",
			"targetSymbol": "8369bc64-efc9-4e91-8576-5197c51957cf",
			"object": "d56effd0-4eea-4892-9a14-6b73374ae7ff"
		},
		"06f3c048-25a4-423f-ae1c-6dfc3197de12": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1577,191 1577,304 1809,304",
			"sourceSymbol": "63ebae70-d21f-42f4-9626-7ac53b780784",
			"targetSymbol": "bcf58330-7163-4bee-91e8-05e6d62c6940",
			"object": "ba723116-7b27-4d7b-8a5f-100d75213ab9"
		},
		"bcf58330-7163-4bee-91e8-05e6d62c6940": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": 1759,
			"y": 274,
			"width": 100,
			"height": 60,
			"object": "88d8f6c5-79ae-4951-bd50-4200f6cc9a1f"
		},
		"62d0732c-0c99-4fca-9192-933c5d331dcf": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1809,304 1950.75,304 1950.75,108.5",
			"sourceSymbol": "bcf58330-7163-4bee-91e8-05e6d62c6940",
			"targetSymbol": "53e54950-7757-4161-82c9-afa7e86cff2c",
			"object": "6cd0cbe9-24ad-482e-9c92-c96df68b210f"
		},
		"7f2df68a-58ac-4895-98f9-716b33e65dec": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 1444,
			"y": -77,
			"object": "4c983399-1066-49cf-8423-f5168fcf4f1d"
		},
		"1b76ab8d-c4d1-402b-89b3-69cd496ee4c4": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1448,-56 1448,-118 1559,-118",
			"sourceSymbol": "7f2df68a-58ac-4895-98f9-716b33e65dec",
			"targetSymbol": "a473db88-4cf0-44bf-95f7-857dff1a2343",
			"object": "e5c148de-7462-4058-990d-ea00faf01b9e"
		},
		"b5792d26-8c66-4980-b52a-a27e64332907": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": 1657,
			"y": -71,
			"width": 100,
			"height": 60,
			"object": "0c6ba501-8616-400d-a2db-50a6acd0f0f6"
		},
		"7bbd5c4c-2b0c-4a2c-a6d0-af33bf061979": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": 1657,
			"y": 4,
			"width": 100,
			"height": 60,
			"object": "0bc1d5ef-179f-4911-8504-3189a674a8ba"
		},
		"60ae817e-4345-4ea7-81fc-d22274eb2738": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 1551,
			"y": 87,
			"object": "9382c631-0326-4f34-930c-eb92367d7da0"
		},
		"d49b9767-0c2e-4bf3-afd1-7237f4f4b308": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1572,110 1695,110",
			"sourceSymbol": "60ae817e-4345-4ea7-81fc-d22274eb2738",
			"targetSymbol": "3bdfc72f-469a-4587-9549-a2ba23c7521b",
			"object": "31e7b968-c06c-4092-85dd-b3716ddfdd43"
		},
		"4b615ca6-ada7-49e0-bf6c-225c3a827a36": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1564,108 1564,40 1707,40",
			"sourceSymbol": "60ae817e-4345-4ea7-81fc-d22274eb2738",
			"targetSymbol": "7bbd5c4c-2b0c-4a2c-a6d0-af33bf061979",
			"object": "f04bbec0-a2ac-4883-8710-f03c97b6ec10"
		},
		"3bcbd1e7-ead0-4504-83e4-67f33fba4fce": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1707,34 1845.75,34 1845.75,108 1946,108",
			"sourceSymbol": "7bbd5c4c-2b0c-4a2c-a6d0-af33bf061979",
			"targetSymbol": "53e54950-7757-4161-82c9-afa7e86cff2c",
			"object": "6946ea20-0f60-43bd-81ce-10b221301737"
		},
		"10c5be8b-db04-4636-a45e-fd54758b85a3": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1465,-56 1571.5,-56 1571.5,-41 1707,-41",
			"sourceSymbol": "7f2df68a-58ac-4895-98f9-716b33e65dec",
			"targetSymbol": "b5792d26-8c66-4980-b52a-a27e64332907",
			"object": "14065926-0b00-4b54-9747-603a1f4aeaba"
		},
		"9927b323-c785-48ce-9f65-752babf9a47d": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1705,-32 1845.75,-32 1845.75,108.5 1951.5,108.5",
			"sourceSymbol": "b5792d26-8c66-4980-b52a-a27e64332907",
			"targetSymbol": "53e54950-7757-4161-82c9-afa7e86cff2c",
			"object": "c543d699-8527-4216-8557-bb9ccf0f9498"
		},
		"61161d3a-888c-4a6c-aeda-e8f05cd20a6c": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 1040,
			"y": 82,
			"width": 100,
			"height": 60,
			"object": "632d73eb-fc24-4666-8908-dff7db7ef3b4"
		},
		"00855b66-2fdc-43d0-bad9-d833155635d1": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1090,112 1232,112",
			"sourceSymbol": "61161d3a-888c-4a6c-aeda-e8f05cd20a6c",
			"targetSymbol": "3bccb17a-af24-436b-8e2a-9b271bac658d",
			"object": "9ace9e07-c064-4d98-aeef-b4938234037a"
		},
		"3bccb17a-af24-436b-8e2a-9b271bac658d": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 1182,
			"y": 82,
			"width": 100,
			"height": 60,
			"object": "60a08b02-0804-43ce-a2ef-2ba2b50afe2e"
		},
		"51d74898-16fe-409f-a7ae-ea8d5c7e19f6": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1232,112 1359,112",
			"sourceSymbol": "3bccb17a-af24-436b-8e2a-9b271bac658d",
			"targetSymbol": "1b49ab67-370c-41f5-a6ba-8e5f16ecae87",
			"object": "991ab06f-f00b-4802-9749-23ca58629f06"
		},
		"1b49ab67-370c-41f5-a6ba-8e5f16ecae87": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 1309,
			"y": 82,
			"width": 100,
			"height": 60,
			"object": "8a6b69c1-8f73-4a53-a19e-3b33b0d0a442"
		},
		"5adb228a-dfb8-4737-a9ab-38eb01477cd7": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1359,112 1462,112",
			"sourceSymbol": "1b49ab67-370c-41f5-a6ba-8e5f16ecae87",
			"targetSymbol": "b9ba38cb-8e2f-4231-adb0-ee34dcf0e840",
			"object": "92f52a10-04d9-4c89-ab14-1c7ba0393bbc"
		},
		"a473db88-4cf0-44bf-95f7-857dff1a2343": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 1538,
			"y": -139,
			"object": "75cd6abb-96f0-48ab-89f9-de647649a7eb"
		},
		"6c39c494-1b04-4516-8684-7b2fd86dc0c4": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1559,-118 1707,-118",
			"sourceSymbol": "a473db88-4cf0-44bf-95f7-857dff1a2343",
			"targetSymbol": "b721179e-c11d-4929-ac48-e1333f3a5ad5",
			"object": "8e124c63-a18a-465b-9e24-f46baa8b4807"
		},
		"0e2af364-63f1-453b-a479-7eeafa2906bf": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1549,-123 1549,-198 1981,-198 1981,102 1949,102",
			"sourceSymbol": "a473db88-4cf0-44bf-95f7-857dff1a2343",
			"targetSymbol": "53e54950-7757-4161-82c9-afa7e86cff2c",
			"object": "c05b45f0-6710-4a03-a56e-a4945a57453b"
		},
		"62d7f4ed-4063-4c44-af8b-39050bd44926": {
			"classDefinition": "com.sap.bpm.wfs.LastIDs",
			"maildefinition": 8,
			"sequenceflow": 45,
			"startevent": 1,
			"endevent": 1,
			"usertask": 1,
			"servicetask": 8,
			"scripttask": 8,
			"mailtask": 10,
			"exclusivegateway": 7
		},
		"a2e6c210-5405-473d-95c6-fb40f022d24e": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition1",
			"to": "${context.io_OwnerEmails}",
			"subject": "Melody Request - Action Required ${context.RequestID.value} - ${context.EmailTemplateVars.EmailSubject}",
			"reference": "/webcontent/Subflow_Multiple_io_Owner/IO_Owner_review.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition1"
		},
		"9023d70a-1a46-43a9-bae1-03d46b48cd7d": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition2",
			"to": "${context.ProcessorEmail_Notif},${context.ResourceEmail_Notif}",
			"subject": "Melody Request - Action Required ${context.RequestID.value} - ${context.EmailTemplateVars.EmailSubject}",
			"reference": "/webcontent/Subflow_Multiple_io_Owner/Review.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition2"
		},
		"b5b7bf93-6e1d-4287-b5c7-f05e67f47ba3": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition3",
			"to": "${context.ProcessorEmail_Notif},${context.RequesterEmail_Notif},${context.io_OwnerEmails}",
			"cc": "",
			"subject": "Melody Request - Closed ${context.RequestID.value} - ${context.EmailTemplateVars.EmailSubject}",
			"reference": "/webcontent/Subflow_Multiple_io_Owner/Resource_assigned_processor.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition3"
		},
		"b3d62195-23cc-49a3-9115-45ca614ccfa6": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition4",
			"to": "${context.RequesterEmail_Notif}",
			"cc": "${context.ReqTypeOwnerEmail_Notif},${context.ProcessorEmail_Notif},${context.io_OwnerEmails}",
			"subject": "Melody Request - Closed ${context.RequestID.value} - ${context.EmailTemplateVars.EmailSubject}",
			"reference": "/webcontent/Subflow_Multiple_io_Owner/IO_Rejected.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition4"
		},
		"8ac46f25-c153-45e7-92f1-9eaa74ad6c09": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition5",
			"to": "${context.io_OwnerEmails}",
			"subject": "Melody Request ${context.RequestID.value} is waiting for review - System Generated Email",
			"reference": "/webcontent/Subflow_Multiple_io_Owner/IO_Owner_RA_review.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition5"
		},
		"231eeb16-c78f-4bd1-b876-9c790e7877ef": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition6",
			"to": "${context.approverData.email},${context.ResourceEmail}",
			"cc": "",
			"subject": "Melody Request ${context.RequestID.value} has been closed in Melody - System Generated Email",
			"reference": "/webcontent/Subflow_Multiple_io_Owner/IO_RA_Rejected.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition6"
		},
		"2061ef76-3e8b-433c-926f-c1b8dbdedb0b": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition7",
			"to": "${context.approverData.email},${context.ResourceEmail}",
			"subject": "Melody Request ${context.RequestID.value} is waiting for review - System Generated Email",
			"reference": "/webcontent/Subflow_Multiple_io_Owner/Review_RA.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition7"
		},
		"2c763fd1-a859-4dfb-9e8b-7d42154cb586": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition8",
			"to": "${context.approverData.email},${context.ResourceEmail},${context.io_OwnerEmails}",
			"subject": "Melody Request ${context.RequestID.value} has been closed in Melody - System Generated Email",
			"reference": "/webcontent/Subflow_Multiple_io_Owner/IO Owner Approve RA.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition8"
		}
	}
}