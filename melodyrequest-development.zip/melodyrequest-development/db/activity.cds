namespace app.activity;

using app.ReqArea_API from '../db/ReqArea_API';

entity YMAC_M_INITIATIV {
    key INITIATIVE_ID          : Integer;
        INITIATIVE_CATEGORY_ID : Integer;
        INITIATIVE_NAME        : String(150);
        INITIATIVE_DESCRIPTION : String(500);
        ACTIVE                 : String(1);
}

entity YMAC_M_INIT_CAT {
    key INITIATIVE_CATEGORY_ID   : Integer;
        INITIATIVE_CATEGORY_NAME : String(40);
        ACTIVE                   : String(1);
}

entity YMAC_M_LANDSCAPE {
    key LANDSID          : String(10);
    key LANDSCAPEID      : String(100);
        DESCRIPTION      : String(150);
        LTYPE            : String(2);
        LOCATION         : String(10);
        PRODUCT          : String(50);
        END_DATE         : Timestamp;
        OPERATION_STATUS : String(1);
}

entity YMAC_M_LTYPE {

    key LTYPE            : String(2);
        DESCRIPTION      : String(150);
        OPERATION_STATUS : String(1);
}

entity YMD_M_ACTPRP_DTS {

    key ACT_PFCG_ID     : String(10);
    key PRPRTY_FIELD_ID : String(10);
        SORT_ORDER      : String(4);
        ACTIVE          : String(1);
}

entity YMD_M_ACT_PFCG {
    key ACT_PFCG_ID      : String(10);
    key PFCG_ROLEMPNG_ID : String(3);
    key ACTTYPEID        : String(4);
        ACTIVE           : String(1);
}

entity YMD_M_PROPERTY {
    key PROPERTY_ID   : String(4);
        PROJECT_TYPE  : String(10);
        PROPERTY_DESC : String(250);
        SERVICE_NAME  : String(30);
        IS_INDEXED    : String(1);
        ACTIVE        : String(1);
}

entity YMD_M_PRPRTY_FLD {
    key PRPRTY_FIELD_ID : String(10);
    key PROPERTY_ID     : String(4);
    key FIELD_ID        : String(4);
        FIELD_VALUE     : String(500);
        ACTIVE          : String(1);
}

entity YUT_M_STATUS {
    key PROJECT_TYPE : String(10);
    key STATUS_ID    : String(2);
        STATUS_DESC  : String(200);
        OPP_STATUS   : String(1);
}

entity YMAC_M_RISK {
    key RA_ID            : String(2);
        DESCRIPTION      : String(150);
        COLORCODE        : String(10);
        OPERATION_STATUS : String(1);

}

entity YMAC_M_ACT_TYPE {
    key ACTTYPEID        : String(4);
    key ACTTYPE_CATZN_ID : String(4);
        DESCRIPTION      : String(150);
        OPERATION_STATUS : String(1);
}

entity YMAC_M_ACTVTASTD {
    key ASSTD_ID      : String(3);
        ASSTD_DESCPTN : String(255);
}

entity YMAC_M_FRMLAYOUT {
    key FRMLAYOUT_ID     : String(5);
        PARENT_LAYOUT_ID : String(5);
        FRMLAYOUT_DESC   : String(125);
        FRM_STRING       : LargeString;
        TIMEREC_LAYOUT   : String(1);
}

entity YROLE_FORM_TYPE {

    key PFCG_ROLEMPNG_ID : String(3);
    key ACTTYPEID        : String(4);
    key ASSTD_ID         : String(3);
    key APPN_TYPE        : String(10);
        FRMLAYOUT_ID     : String(5);
        OPERATION_STATUS : String(1);
}

entity YMR_DF_ACTIVITY {
    key INSTANCE_GUID        : String(64);
    key AssignmentID         : String(4);
    key ACTIVITY_GUID        : UUID;
        ACTIVITYID           : String(10);
        ASSTD_ID             : String(3);
        PFCG_ROLEMPNG_ID     : String(3);
        REQUESTOR            : String(12);
        REQUESTOR_MAIL_ID     : String(241);
        REQUESTOR_NAME : String(241);
        ACTIVITY_LEAD        : String(12);
        ACT_LEAD_MAIL_ID     : String(241);
        Act_LEAD_NAME : String(241);
        ACCOUNT_EXECUTIVE    : String(12);
        ACC_EXEC_MAIL_ID     : String(241);
        ACTIVITY_SUPPORT     : String(12);
        METHODID             : String(2);
        ACTSET_ID            : String(16);
        ACTTYPEID            : String(4);
        MAIN_SOLUTION_ID     : String(4);
        EXTERNAL_FLAG        : String(1);
        OPPORTUNITYNO        : String(16);
        STARTAT              : Timestamp;
        ENDAT                : Timestamp;
        ARCHIVED             : String(1);
        STATUS               : String(2);
        ACTVT_STATUS         : String(2);
        ACTVT_NAME           : String(500);
        ACTVT_CNTRY          : String(3);
        IMPACT_ID            : String(4);
        NUMBER_ATTENDEES     : Integer;
        DEALTYPE             : String(1);
        MEETING_INVITEES     : String(1);
        CREATEDAT            : Timestamp;
        LASTCHANGEDBY        : String(12);
        LASTCHANGEDAT        : Timestamp;
        DESCRIPTION          : LargeString;
        VS_ID                : String(4);
        ROOMNO               : String(10);
        RA_ID                : String(2);
        RA_COMMENT           : String(1000);
        DC_ID                : String(4);
        SURVEY_RECPT         : String(12);
        REQUESTED_DELIVERY   : Timestamp;
        DRY_RUN              : Timestamp;
        DISCOVERY_COMPLT     : String(3);
        GLOBAL_ULTIMATE_ID   : String(20);
        REGION               : String(4);
        SCP_ACCOUNT          : String(1);
        POTENTIAL_CLOSE_DATE : Timestamp;
        TARGET_VALUE         : String(20);
        REQ_MGR_ID           : String(12);
        TOP_DEAL_FLAG        : String(1);
        EXISTING_CLIENT      : String(1);
        STATUS_CHANGED_AT    : Timestamp;
        REQUESTOR_PFCG       : String(3);
        ActvtExt             : Composition of many YMR_DF_ACTVT_EXT
                                   on ActvtExt.Actvt = $self;
        Taxonomy             : Composition of many YMR_DF_ACTVT_SOL_TXNMY
                                   on Taxonomy.Actvt = $self;
        Material             : Composition of many YMR_DF_ACTVT_SOL_MTRL
                                   on Material.Actvt = $self;
        LSCAPE               : Composition of many YMR_DF_ACTVTLSCAPE
                                   on LSCAPE.Actvt = $self;
        Initiative           : Composition of many YMR_DF_ACTVT_INIT
                                   on Initiative.Actvt = $self;
        AddOpp               : Composition of many YMR_DF_ACTVT_ADD_OPP
                                   on AddOpp.Actvt = $self;
        ActTeam              : Composition of many YMR_DF_ACTVT_TEAM
                                   on ActTeam.Actvt = $self;
        to_AFiles            : Composition of many YMD_FILE_UPLOAD
                                   on to_AFiles.Actvt = $self;


}

entity YMR_DF_ACTVT_EXT {
    key Actvt         : Association to YMR_DF_ACTIVITY;
        CVJ_PHASE_ID  : String(4); 
        OPP_STATUS_ID : String(5);
        OPP_STATUS_DESC : String(120);
}

entity YMD_FILE_UPLOAD {
    key Actvt            : Association to YMR_DF_ACTIVITY;
    key PROJECT_TYPE     : String(10);
    key FILE_ID          : UUID;
        UP_DATE          : Date;
        UP_TIME          : Time;
        FILE_NAME        : String(255);
        FILE_TYPE        : String(128);
        USER_UPLOADED    : String(12);
        THUMBNAIL_IMG    : LargeString;
        FILE_CONTENT     : LargeString;
        ATTACH_TYPE      : String(4);
        THUMBNAIL_URL    : String(1033);
        URL              : String(1033);
        ADD_INFO         : String(1);
        ATTACH_DESC      : String(200);
        OPERATION_STATUS : String(1);
        FILE_SIZE        : String(255);
        STATUS_ID        : String(2);
};


entity YMR_DF_ACTVT_SOL_TXNMY {
    key Actvt      : Association to YMR_DF_ACTIVITY;
    key SOLN_ID_L2 : String(40);
    key SOLN_ID_L3 : String(40);
    key SOLN_ID_L4 : String(40);
    key SOLN_ID_L5 : String(40);
    key SOLN_ID_L6 : String(40);
    key SOLN_ID_L7 : String(40);
    key SOLN_ID_L8 : String(40);
}

entity YMR_DF_ACTVT_SOL_MTRL {
    key Actvt    : Association to YMR_DF_ACTIVITY;
    key MAT_ID   : String(40);
    key SOL_YEAR : String(4);
}

entity YMR_DF_ACTVTLSCAPE {
    key Actvt   : Association to YMR_DF_ACTIVITY;
    key LANDSID : String(10);
}

entity YMR_DF_ACTVT_INIT {
    key Actvt         : Association to YMR_DF_ACTIVITY;
    key INITIATIVE_ID : Integer;
}

entity YMR_DF_ACTVT_ADD_OPP {
    key Actvt         : Association to YMR_DF_ACTIVITY;
    key OPPORTUNITYNO : String(16);
}

entity YMR_DF_ACTVT_TEAM {
    key Actvt  : Association to YMR_DF_ACTIVITY;
    key USERID : String(12);
    key ROLE   : String(10);
    key EMAIL  : String(241);
        NAME   : String(100);
}


// View Code 
view YI_MR_T_ACT_INIT as
    select from YMR_DF_ACTVT_INIT as init {
        key init.Actvt.ACTIVITY_GUID as ActivityGuid,
        key init.INITIATIVE_ID       as InitiativeId
    };

view YI_MR_M_INITIATIV as
    select from YMAC_M_INITIATIV as INITIATIV {
        key INITIATIV.INITIATIVE_ID          as InitiativeId,
            INITIATIV.INITIATIVE_CATEGORY_ID as InitiativeCategoryId,
            INITIATIV.INITIATIVE_NAME        as InitiativeName,
            INITIATIV.INITIATIVE_DESCRIPTION as InitiativeDescription,
            INITIATIV.ACTIVE                 as Active
    }
    where
        INITIATIV.ACTIVE = 'X';

view YI_MR_M_INIT_CAT as
    select from YMAC_M_INIT_CAT as cat {
        key cat.INITIATIVE_CATEGORY_ID   as InitiativeCategoryId,
            cat.INITIATIVE_CATEGORY_NAME as InitiativeCategoryName,
            cat.ACTIVE                   as Active
    }
    where
        cat.ACTIVE = 'X';

@cds.autoexpose
view YC_MR_T_ACT_INIT as
    select from YI_MR_T_ACT_INIT as ActivityInitiative
    inner join YI_MR_M_INITIATIV as Initiative
        on ActivityInitiative.InitiativeId = Initiative.InitiativeId
    inner join YI_MR_M_INIT_CAT as InitiativeCategory
        on Initiative.InitiativeCategoryId = InitiativeCategory.InitiativeCategoryId
    {
        key ActivityInitiative.ActivityGuid,
       key LPAD(TO_VARCHAR(ActivityInitiative.InitiativeId), 4, '0') AS InitiativeId:String(4),
       // key ActivityInitiative.InitiativeId,
            Initiative.InitiativeName,
            Initiative.InitiativeDescription,
           // Initiative.InitiativeCategoryId,
            LPAD(TO_VARCHAR(Initiative.InitiativeCategoryId), 4, '0') AS InitiativeCategoryId:String(4),
            InitiativeCategory.InitiativeCategoryName
    };


view YI_MR_M_LANDSCAPE as
    select from YMAC_M_LANDSCAPE as LANDSCAPE {
        key LANDSCAPE.LANDSID          as LandsId,
        key LANDSCAPE.LANDSCAPEID      as LandscapeId,
            LANDSCAPE.DESCRIPTION      as Description,
            LANDSCAPE.LOCATION         as Location,
            LANDSCAPE.LTYPE            as Ltype,
            LANDSCAPE.PRODUCT          as Product,
            LANDSCAPE.END_DATE         as EndDate,
            LANDSCAPE.OPERATION_STATUS as OperationStatus


    };

view YI_MR_M_LTYPE as
    select from YMAC_M_LTYPE as Ltype {
        key Ltype.LTYPE            as Ltype,
            Ltype.DESCRIPTION      as Description,
            Ltype.OPERATION_STATUS as OperationStatus
    };

view YI_MR_M_LANDSCAPE_DTL as
    select from YI_MR_M_LANDSCAPE as l
    inner join YI_MR_M_LTYPE as lt
        on l.Ltype = lt.Ltype
    {
        l.LandsId,
        l.LandscapeId,
        l.Description  as LandDescription,
        l.Location,
        l.Ltype,
        l.Product,
        lt.Description as LTypeDescription,
        l.OperationStatus
    };

view YI_MR_T_ACTLSCAPE as
    select from YMR_DF_ACTVTLSCAPE as ActLan {
        key ActLan.Actvt.ACTIVITY_GUID as ActivityGuid,
        key ActLan.LANDSID             as LandsId
    };

@cds.autoexpose
view YC_MR_T_Landscapes as
    select from YI_MR_T_ACTLSCAPE as _ActLan
    left outer join YI_MR_M_LANDSCAPE_DTL as _Lan
        on _ActLan.LandsId = _Lan.LandsId
    {

        key _ActLan.ActivityGuid,
        key _ActLan.LandsId,
        key _Lan.LandscapeId,
            _Lan.LandDescription,
            _Lan.Location,
            _Lan.Ltype,
            _Lan.Product,
            _Lan.LTypeDescription,
            CASE WHEN _Lan.OperationStatus = 'X' THEN true ELSE false END AS OperationStatus:Boolean
           // _Lan.OperationStatus
    };


view YI_MR_T_SOL_TXNMY as
    select from YMR_DF_ACTVT_SOL_TXNMY as tax {
        key tax.Actvt.ACTIVITY_GUID as ActivityGuid,
            tax.SOLN_ID_L2,
            tax.SOLN_ID_L3,
            tax.SOLN_ID_L4,
            tax.SOLN_ID_L5,
            tax.SOLN_ID_L6,
            tax.SOLN_ID_L7,
            tax.SOLN_ID_L8
    };

view YI_MR_M_SOL_TXNMY as
    select from ReqArea_API.YMR_M_SOL_TXNMY as txnmy {
        key txnmy.PROJECT_TYPE   as ProjectType,
        key txnmy.SOLN_GUID      as SolnGuid,
            txnmy.SOLN_ID        as SolnId,
            txnmy.SOLN_NAME      as SolnName,
            txnmy.SOLN_PRNT_GUID as SolnParentGuid,
            txnmy.ACTIVE         as Active,
            txnmy.IS_FINAL       as IsFinal
    };

@cds.autoexpose
view YC_MR_T_SOL_TXNMY as
    select from YI_MR_T_SOL_TXNMY as tax
    left outer join YI_MR_M_SOL_TXNMY as L2
        on tax.SOLN_ID_L2 = L2.SolnId
    left outer join YI_MR_M_SOL_TXNMY as L3
        on tax.SOLN_ID_L3 = L3.SolnId
    left outer join YI_MR_M_SOL_TXNMY as L4
        on tax.SOLN_ID_L4 = L4.SolnId
    left outer join YI_MR_M_SOL_TXNMY as L5
        on tax.SOLN_ID_L5 = L5.SolnId
    left outer join YI_MR_M_SOL_TXNMY as L6
        on tax.SOLN_ID_L6 = L6.SolnId
    left outer join YI_MR_M_SOL_TXNMY as L7
        on tax.SOLN_ID_L7 = L7.SolnId
    left outer join YI_MR_M_SOL_TXNMY as L8
        on tax.SOLN_ID_L8 = L8.SolnId
    {
        key tax.ActivityGuid,
            tax.SOLN_ID_L2 as L2Id,
            L2.SolnName    as L2Desc,
            tax.SOLN_ID_L3 as L3Id,
            L3.SolnName    as L3Desc,
            tax.SOLN_ID_L4 as L4Id,
            L4.SolnName    as L4Desc,
            tax.SOLN_ID_L5 as L5Id,
            L5.SolnName    as L5Desc,
            tax.SOLN_ID_L6 as L6Id,
            L6.SolnName    as L6Desc,
            tax.SOLN_ID_L7 as L7Id,
            L7.SolnName    as L7Desc,
            tax.SOLN_ID_L8 as L8Id,
            L8.SolnName    as L8Desc

    };


view YI_MR_M_SOL_MATERL as
    select from ReqArea_API.YMR_M_SOL_MATERL as mtrl {
        key mtrl.MAT_ID     as MatId,
            mtrl.MAT_DESC   as MatDesc,
            mtrl.MAT_STATUS as MatStatus
    };

view YI_MR_ACTVT_T_SOL_MTRL as
    select from YMR_DF_ACTVT_SOL_MTRL as solmat {
        key solmat.Actvt.ACTIVITY_GUID as ActivityGuid,
        key solmat.MAT_ID              as MatId,
            solmat.SOL_YEAR            as SolYear

    };

@cds.autoexpose
view YC_MR_T_SOL_MTRL as
    select from YI_MR_ACTVT_T_SOL_MTRL as mat
    left outer join YI_MR_M_SOL_MATERL as solMat
        on mat.MatId = solMat.MatId
    {
        key mat.ActivityGuid,
        key mat.MatId,
            solMat.MatDesc,
            mat.SolYear
    };


view YI_MR_T_ACTVT_EXT as
    select from YMR_DF_ACTVT_EXT as ext {
        key ext.Actvt.ACTIVITY_GUID as ActivityGuid,
            ext.CVJ_PHASE_ID        as CvjPhaseId,
            ext.OPP_STATUS_ID       as OppStatusId,
            ext.OPP_STATUS_DESC     as OppStatusDesc
    };

view YI_MR_T_ACTVT_MAIN as
    select from YMR_DF_ACTIVITY as Actvt {
        key Actvt.INSTANCE_GUID        as Instance_Guid,
        key Actvt.AssignmentID,
        key Actvt.ACTIVITY_GUID        as ActivityGuid,
            Actvt.ACTIVITYID           as ActivityId,
            Actvt.ASSTD_ID             as AsstdId,
            Actvt.PFCG_ROLEMPNG_ID     as Pfcg_Rolempng_Id,
            Actvt.REQUESTOR            as Requestor,
            Actvt.REQUESTOR_MAIL_ID    as RequestorName,
            Actvt.REQUESTOR_NAME       as RequestorEmailId,
            Actvt.ACTIVITY_LEAD        as ActivityLead,
            Actvt.Act_LEAD_NAME        as ActivityLeadName,
            Actvt.ACT_LEAD_MAIL_ID     as ActivityLeadEmailId,
            Actvt.ACCOUNT_EXECUTIVE    as AccountExecutive,
            Actvt.ACC_EXEC_MAIL_ID     as AccountExecutiveEmailId,
            Actvt.ACTIVITY_SUPPORT     as Activity_Support,
            Actvt.METHODID             as MethodId,
            Actvt.ACTSET_ID            as Actset_Id,
            Actvt.ACTTYPEID            as ActTypeId,
            Actvt.MAIN_SOLUTION_ID     as Main_Solution_Id,
            Actvt.EXTERNAL_FLAG        as External_Flag,
            Actvt.OPPORTUNITYNO        as OpportunityNo,
            Actvt.STARTAT              as StartAt,
            Actvt.ENDAT                as EndAt,
            Actvt.STATUS               as Status,
            Actvt.DEALTYPE             as DealType,
            Actvt.CREATEDAT            as CreatedAt,
            Actvt.LASTCHANGEDBY        as LastChangedBy,
            Actvt.DESCRIPTION          as Description,
            Actvt.VS_ID                as Vs_Id,
            Actvt.ROOMNO               as RoomNo,
            Actvt.RA_ID                as Ra_Id,
            Actvt.RA_COMMENT           as Ra_Comment,
            Actvt.DC_ID                as Dc_Id,
            Actvt.LASTCHANGEDAT        as LastChangedAt,
            Actvt.SURVEY_RECPT         as Survey_Recpt,
            Actvt.REQUESTED_DELIVERY   as Requested_Delivery,
            Actvt.ACTVT_STATUS         as Actvt_Status,
            Actvt.GLOBAL_ULTIMATE_ID   as Global_Ultimate_Id,
            Actvt.REGION               as Region,
            Actvt.SCP_ACCOUNT          as ScpAccount,
            Actvt.POTENTIAL_CLOSE_DATE as PotentialCloseDate,
            Actvt.TARGET_VALUE         as TargetValue,
            Actvt.REQ_MGR_ID           as ReqMgrId,
            Actvt.DRY_RUN              as DryRun,
            Actvt.DISCOVERY_COMPLT     as DiscoveryComplt,
            Actvt.TOP_DEAL_FLAG        as TopDealFlag,
            Actvt.MEETING_INVITEES     as MeetingInvitees,
            Actvt.EXISTING_CLIENT      as ExistingClient,
            Actvt.ACTVT_CNTRY          as ActvtCntry,
            Actvt.ACTVT_NAME           as ActvtName,
          //  Actvt.NUMBER_ATTENDEES     as NmbrOfAttnds,
            LPAD(TO_VARCHAR(Actvt.NUMBER_ATTENDEES), 10, '0') AS NmbrOfAttnds:String(10),
            Actvt.IMPACT_ID            as ImpactId,
            Actvt.ARCHIVED             as Archived,
            Actvt.STATUS_CHANGED_AT    as StatusChangedAt

    };

view YI_MR_M_PROPERTY as
    select from YMD_M_PROPERTY {

        key PROPERTY_ID   as PropertyId,
            PROJECT_TYPE  as ProjectType,
            PROPERTY_DESC as PropertyDesc,
            SERVICE_NAME  as ServiceName,
            IS_INDEXED    as IsIndexed,
            ACTIVE        as Active
    };

view YI_MR_M_PROPERTY_FIELD as
    select from YMD_M_PRPRTY_FLD {

        key PRPRTY_FIELD_ID as PrprtyFieldId,
            PROPERTY_ID     as PropertyId,
            FIELD_ID        as FieldId,
            FIELD_VALUE     as FieldValue,
            ACTIVE          as Active
    };

view YI_MR_M_ACT_PROPERTY_DTS as
    select from YMD_M_ACTPRP_DTS {

        key ACT_PFCG_ID     as ActPfcgId,
        key PRPRTY_FIELD_ID as PrprtyFieldId,
            SORT_ORDER      as SortOrder,
            ACTIVE          as Active
    };

view YI_MR_M_ACTVT_PFCG as
    select from YMD_M_ACT_PFCG {

        key ACT_PFCG_ID      as ActPfcgId,
            PFCG_ROLEMPNG_ID as PfcgRolempngId,
            ACTTYPEID        as Acttypeid,
            ACTIVE           as Active
    };

view YI_MR_M_ACT_PROPERTY_DETAIL as
    select from YI_MR_M_PROPERTY as prpty
    inner join YI_MR_M_PROPERTY_FIELD as prptyfld
        on prpty.PropertyId = prptyfld.PropertyId
    inner join YI_MR_M_ACT_PROPERTY_DTS as actprpty
        on prptyfld.PrprtyFieldId = actprpty.PrprtyFieldId
    inner join YI_MR_M_ACTVT_PFCG as actpfcg
        on actprpty.ActPfcgId = actpfcg.ActPfcgId
    {
        key prpty.PropertyId,
            prpty.ProjectType,
            prpty.PropertyDesc,
            prpty.ServiceName,
            prpty.IsIndexed,
            prptyfld.PrprtyFieldId,
            actprpty.ActPfcgId,
            actprpty.SortOrder,
            actpfcg.Acttypeid,
            actpfcg.PfcgRolempngId,
            prptyfld.FieldId,
            prptyfld.FieldValue,
            case
                when prpty.Active = 'X'
                     and prptyfld.Active = 'X'
                     and actprpty.Active = 'X'
                     and actpfcg.Active = 'X'
                     then 'X'
                else ''
            end as Active


    };

view YC_MR_M_CVJ_PHASE as
    select from YI_MR_M_ACT_PROPERTY_DETAIL {
        key Acttypeid      as Acttypeid,
            PfcgRolempngId as RoleMpngID,
            FieldId        as CvjPhaseId,
            FieldValue     as CvjPhaseDesc,
            SortOrder,
            Active
    }
    where
        PropertyId = '0001';

view YI_MR_M_ACT_TYPE as
    select from YMAC_M_ACT_TYPE {

        key ACTTYPEID        as ActivityTypeId,
        key ACTTYPE_CATZN_ID as ActivtyTypeCatznID,
            DESCRIPTION      as Description,
            OPERATION_STATUS as OperationStatus

    };

view YI_MR_M_RISK as
    select from YMAC_M_RISK {

        key RA_ID            as Ra_Id,
            DESCRIPTION      as Description,
            COLORCODE        as ColorCode,
            OPERATION_STATUS as OperationStatus
    };

view YI_MR_M_STATUS as
    select from YUT_M_STATUS {

        key PROJECT_TYPE as ProjectType,
        key STATUS_ID    as StatusId,
            STATUS_DESC  as StatusDesc,
            OPP_STATUS   as OppStatus
    }
    where
        PROJECT_TYPE = 'MSL';

view YI_MR_M_ACTVTASTD as
    select from YMAC_M_ACTVTASTD {
        key ASSTD_ID      as ActSetId,
            ASSTD_DESCPTN as ActSetDesc
    };

view YI_MR_T_ADD_OPP as
    select from YMR_DF_ACTVT_ADD_OPP {

        key Actvt.ACTIVITY_GUID as ActivityGuid,
        key OPPORTUNITYNO       as OpportunityNo
    };

@cds.autoexpose
view YC_MR_T_ADD_OPP as
    select from YI_MR_T_ADD_OPP {
        key ActivityGuid,
            @EndUserText.label: 'Additional Opportunities'
        key OpportunityNo

    };

view YI_MR_ACTVT_T_TEAM as
    select from YMR_DF_ACTVT_TEAM {
        key Actvt.ACTIVITY_GUID as ActivityGuid,
        key USERID,
        key ROLE,
        key EMAIL,
            NAME
    };

@cds.autoexpose
view YC_MR_ACTVT_T_TEAM as
    select from YI_MR_ACTVT_T_TEAM {
        key ActivityGuid,
        key USERID as ID,
        key ROLE,
        key EMAIL,
            NAME
    };


view YI_MR_M_FORM_LAYOUT as
    select from YMAC_M_FRMLAYOUT {
        key FRMLAYOUT_ID     as FormLayoutID,
            PARENT_LAYOUT_ID as ParentLayoutId,
            FRMLAYOUT_DESC   as FormLayoutDesc,
            FRM_STRING       as FormLayoutString,
            TIMEREC_LAYOUT   as IsTimeRecLayout,
    };

view YI_ROLE_ACTVT_TYPEMAPNG as
    select from YROLE_FORM_TYPE {
        key PFCG_ROLEMPNG_ID,
        key ACTTYPEID,
        key ASSTD_ID,
            FRMLAYOUT_ID,
            OPERATION_STATUS
    }
    where
        APPN_TYPE = 'ACTVT';

view YI_MR_T_ACTMAIN as
    select from YI_MR_T_ACTVT_MAIN as main
    left outer join YI_MR_M_ACT_TYPE as actType
        on main.ActTypeId = actType.ActivityTypeId

    left outer join YI_MR_M_RISK as risk
        on main.Ra_Id = risk.Ra_Id

    left outer join YI_MR_M_STATUS as status
        on main.Status = status.StatusId

    left outer join YI_MR_T_ACTVT_EXT as ext
        on ext.ActivityGuid = main.ActivityGuid

    left outer join YI_ROLE_ACTVT_TYPEMAPNG as _ActRole
        on  main.ActTypeId        = _ActRole.ACTTYPEID
        and main.Pfcg_Rolempng_Id = _ActRole.PFCG_ROLEMPNG_ID
        and main.AsstdId          = _ActRole.ASSTD_ID

    left outer join YI_MR_M_FORM_LAYOUT as _AfrmLayout
        on _ActRole.FRMLAYOUT_ID = _AfrmLayout.FormLayoutID

    {
        key main.Instance_Guid,
        key main.AssignmentID,
        key main.ActivityGuid,
            main.ActivityId,
            main.AsstdId,
            main.Pfcg_Rolempng_Id,
            main.Requestor,
            main.RequestorName,
            main.RequestorEmailId,
            main.ActivityLead,
            main.ActivityLeadName,
            main.ActivityLeadEmailId,
            main.AccountExecutive,
            main.AccountExecutiveEmailId,
            main.Activity_Support,
            main.MethodId,
            main.Actset_Id,
            main.ActTypeId      as ActivityTypeId,
            actType.Description as ActivityTypeDescription,
            _AfrmLayout.FormLayoutID,
            main.Main_Solution_Id,
            main.External_Flag,
            main.OpportunityNo,
            main.StartAt,
            main.EndAt,
            main.Status,
            status.StatusDesc   as Status_Desc,
            main.DealType,
            main.CreatedAt,
            main.LastChangedBy,
            main.Description,
            main.Vs_Id,
            main.RoomNo,
            main.Ra_Id          as RiskAssessId,
            risk.Description    as RiskDescription,
            risk.ColorCode      as RiskColorCode,
            main.Ra_Comment,
            main.Dc_Id,
            main.LastChangedAt,
            main.Survey_Recpt,
            main.Requested_Delivery,
            main.Global_Ultimate_Id,
            main.Region,
            main.ScpAccount,
            main.PotentialCloseDate,
            main.TargetValue,
            main.ReqMgrId,
            main.DryRun,
            main.DiscoveryComplt,
            main.TopDealFlag,
            main.MeetingInvitees,
            main.ExistingClient,
            main.ActvtCntry,
            main.ActvtName,
            main.NmbrOfAttnds,
            main.ImpactId,
            main.Archived,
            main.StatusChangedAt,
            ext.CvjPhaseId,
            ext.OppStatusId,
            ext.OppStatusDesc


    };

view YI_MR_FILE_UPLOAD as
    select from YMD_FILE_UPLOAD as upload
    left outer join YI_MR_T_ACTMAIN
        on  YI_MR_T_ACTMAIN.ActivityGuid  = upload.Actvt.ACTIVITY_GUID
        and YI_MR_T_ACTMAIN.Instance_Guid = upload.Actvt.INSTANCE_GUID
        and YI_MR_T_ACTMAIN.AssignmentID  = upload.Actvt.AssignmentID
    {
        key upload.Actvt.ACTIVITY_GUID     as ActivityGuid,
        key upload.PROJECT_TYPE            as ProjectType,
        key upload.FILE_ID                 as FileId,
            upload.UP_DATE                 as FileDate,
            upload.UP_TIME                 as FileTime,
            upload.FILE_NAME               as FileName,
            upload.FILE_TYPE               as FileType,
            upload.USER_UPLOADED           as UserUploaded,
            upload.THUMBNAIL_IMG           as ThumbnailImg,
            upload.FILE_CONTENT            as File_Content,
            upload.ATTACH_TYPE             as AttachType,
            upload.THUMBNAIL_URL           as ThumbnailUrl,
            upload.URL                     as Url,
            upload.ATTACH_DESC             as AttachDesc,
            upload.OPERATION_STATUS        as Operational_Status,
            upload.FILE_SIZE               as FileSize,
            upload.STATUS_ID               as Status,
            YI_MR_T_ACTMAIN.ActivityTypeId as ActivityTypeId

    };

@cds.autoexpose
view YC_MR_FILE_UPLOAD as
    select from YI_MR_FILE_UPLOAD {
        ActivityGuid,
        ProjectType,
        cast ('' as String(12)) as FileId,
        cast ('' as String(50)) as RequestId,
        FileDate,
        FileTime,
        FileName,
        FileType,
        UserUploaded,
        ThumbnailImg,
        AttachType,
        ThumbnailUrl,
        Url,
        AttachDesc,
        FileSize,
        Status,
        ActivityTypeId

    };

view YC_MR_T_Act_Main as
    select from YI_MR_T_ACTMAIN as mainact
    left outer join YC_MR_M_CVJ_PHASE as phase
        on  mainact.CvjPhaseId       = phase.CvjPhaseId
        and mainact.ActivityTypeId   = phase.Acttypeid
        and mainact.Pfcg_Rolempng_Id = phase.RoleMpngID
    left outer join YI_MR_M_FORM_LAYOUT as layout
        on mainact.FormLayoutID = layout.FormLayoutID
    {
        key mainact.Instance_Guid,
        key mainact.AssignmentID,
        key mainact.ActivityGuid,
            mainact.ActivityId,
            mainact.AsstdId            as ActvtAsstdID,
            mainact.Pfcg_Rolempng_Id   as RoleMpngID,
            mainact.Requestor,
            mainact.RequestorName,
            mainact.RequestorEmailId,
            //need to user detail
            mainact.ActivityLead,
            mainact.ActivityLeadName,
            mainact.ActivityLeadEmailId,
            //need to user detail
            mainact.AccountExecutive,
            mainact.AccountExecutiveEmailId,
            mainact.Activity_Support   as ActivitySupport,
            mainact.MethodId,
            mainact.Actset_Id          as ActivitySetId,
            mainact.ActivityTypeId,
            mainact.ActivityTypeDescription,
            mainact.Main_Solution_Id   as MainSolutionId,
            mainact.External_Flag      as external_flag,
            mainact.OpportunityNo      as OpportunityNumber,
            mainact.StartAt            as StartDate,
            mainact.EndAt              as EndDate,
            mainact.Status,
            mainact.Status_Desc,
            mainact.DealType,
            mainact.CreatedAt          as CreateDate,
            mainact.LastChangedAt,
            mainact.Description,
            case
                when layout.ParentLayoutId <> ''
                     then layout.ParentLayoutId
                else layout.FormLayoutID
            end                        as FormLayoutId : String(5),
            layout.FormLayoutID        as ChildFrmLayoutId,
            mainact.Vs_Id              as VirtualStudioId,
            mainact.RoomNo             as BoardRoomNumber,
            mainact.RiskAssessId,
            mainact.RiskColorCode,
            mainact.Ra_Comment         as RiskComment,
            mainact.Dc_Id              as DcId,
            mainact.Survey_Recpt       as SurveyRecpt,
            mainact.Requested_Delivery as RequestedDelivery,
            mainact.Global_Ultimate_Id as GlobalUltimateID,
            mainact.Region,
            mainact.ScpAccount         as SCPAccount,
            mainact.PotentialCloseDate,
            mainact.TargetValue,
            mainact.ReqMgrId           as RequestorManagerID,
            mainact.DryRun             as DryRunDate,
            mainact.DiscoveryComplt    as DiscoveryCompleted,
            mainact.TopDealFlag,
            mainact.MeetingInvitees,
            mainact.ExistingClient,
            mainact.ActvtCntry         as CntryID,
            mainact.ActvtName,
            mainact.NmbrOfAttnds,
            mainact.ImpactId           as ImpactID,
            case
                when mainact.Archived = 'X'
                     then true
                else false
            end                        as Archived     : Boolean,
            mainact.StatusChangedAt,
            mainact.CvjPhaseId,
            phase.CvjPhaseDesc,
            mainact.OppStatusId,
            mainact.OppStatusDesc,
            _AAddOpp     : Association to many YC_MR_T_ADD_OPP
                               on _AAddOpp.ActivityGuid = ActivityGuid,

            _AInitiative : Association to many YC_MR_T_ACT_INIT
                               on _AInitiative.ActivityGuid = ActivityGuid,

            _ALand       : Association to many YC_MR_T_Landscapes
                               on _ALand.ActivityGuid = ActivityGuid,

            _AMaterial   : Association to many YC_MR_T_SOL_MTRL
                               on _AMaterial.ActivityGuid = ActivityGuid,

            _ATaxonomy   : Association to many YC_MR_T_SOL_TXNMY
                               on _ATaxonomy.ActivityGuid = ActivityGuid,

            _ATeam       : Association to many YC_MR_ACTVT_T_TEAM
                               on _ATeam.ActivityGuid = ActivityGuid,

            _AFiles      : Association to many YC_MR_FILE_UPLOAD
                               on _AFiles.ActivityGuid = ActivityGuid


    };