namespace app.wf;

type TOpportunityID   : String(64);
type TInstanceID      : String(64);
type string_64        : String(64);

using {Currency} from '@sap/cds/common';
using app.resources from '../db/resources';
using app.ReqArea_API from '../db/ReqArea_API';
using app.ORE_API from '../db/ORE_API';
using { cuid } from '@sap/cds/common';

type TEmpID           : String(64);

type TEmployee {
    ID    : TEmpID;
    Name  : String(1000) @(title: 'Requester');
    EMail : String(1000);
};

type TDateTime {
    tdate : Date not null @(title: 'Creation Date');
    ttime : Time not null;
}

type TRequestAreaName : String(1000);

type TRequestArea {
    name : TRequestAreaName;
    path : String(1000) @(title: 'Request Area Path');
};

type TInstanceStatus  : String(30) enum {
    inProcess;
    complete;
    terminated;
    error;
};

type TRoleType        : String(100) enum {
    Approver;
    Resource;
    Requestor;
};

type TAssignStatus    : String(100) enum {
    proposed;
    confirmed;
};

type TAccount {
    ID   : String(64) not null;
    name : String(100) not null;
};

type TResource {
    ID    : String(10);
    Name  : String(100) @(title: 'Resource');
    EMail : String(100);
};

type TAmount          : Decimal(19, 2);
type TdefinitionID    : String(50);
type TBusinessStatus  : String(100);
type TWIStepName      : String(100);
type TSystemID        : String(10);
type TDealScore       : Decimal(5, 2);
type TDecision        : String(64);
type TExtSystemsUrl   : String(255);


entity SalesGroup2Emp {
    key SalesGroup     : String(64);
    key EmpID          : TEmpID;
        SalesGroupName : String(100);
        EmpName        : String(100);
}

entity WeekEnd {
    key Date : Date;
}

entity YMRR_WFIns_Parent {
    key instance_GUID   : TInstanceID;
        refID           : Integer64;
        definitionID    : TdefinitionID;
        orgID           : string_64;
        orgType         : String(10);
        orgID_L         : String(9);
        reqTypeID       : String(4);
        eng_type_ID   : String(4);
        opportunityID   : TOpportunityID;
        opportunityDesc : String(1000);
        account         : TAccount;
        empRequester    : TEmployee;
        systemID        : TSystemID;
        industryName    : String(100);
        pE_Name         : String(100);
        extSystemsUrl   : TExtSystemsUrl;
};
entity YMRR_WfInstance {
    key instance_GUID             : TInstanceID;
    key parentInstance_GUID       : TInstanceID;
        refID                     : Integer64;
        currentTaskInstanceID     : TInstanceID;
        definitionID              : String(4);
        technicalStateID          : String(4);
        currentStateID            : String(6);
        currentStepID             : String(6);
        userTaskID                : String(4);
        currentProcessorID        : String(500) not null;
        currentProcessor          : LargeString not null;
        currentProcessorEmail     : LargeString;
        dtCreation                : TDateTime;
        dtLastActivity            : TDateTime;
        reqAreaGUID               : UUID;
        IAC_RoleMap_GUID          : string_64;
        substituteProcessorID        : String(500) ;
        substituteProcessor          : LargeString;
        substituteProcessorEmail  : LargeString;
        approvers                 : LargeString;
        reqApprover               : TEmployee;
        reqResources              : String(500);
        reqIOApprover             : String(500);
        decisionID                : String(20);
        currency                  : String(3);
        revenueCloud              : TAmount;
        revenuePremise            : TAmount;
        dealScore                 : TDealScore;
        // Fields from Submit Request Form
        need_from_CustAdvisory    : String(5000);
        cust_asked_forMeeting     : String(1);
        meetingTypeID             : String(100);
        comments                  : String(5000);
        solution_Models           : String(1000);
        custAdvisory_Resource     : String(1000);
        meeting_Goal              : String(5000);
        meetingLocation           : String(1000);
        meetingDate               : String(100);
        meetingTime               : String(100);
        involved_SAP_Parties_Name : String(5000);
        participants_Type_Details : String(5000);
        isAttachment              : String(1);
        currentTaskURL            : String(2000);

};

entity YMR_T_Wfinstance_Ext {
    key instance_Guid       : string_64;
        group_ID               : String(4);
        Opp_Number          : String(250);
        io_Number           : String(250);
        contact_Prsn_Id     : String(150);
        contact_Prsn_Email  : String(500);
        need_From_Fbs       : String(5000);
        c2c_Deal            : String(1);
        oppclosing_Date     : Date;
        contract_Start_Date : Date;
        contract_End_Date   : Date;
        supp_Type_FBS_Id       : String(4);
        supp_Type_Pqa_Id    : String(4);
        solution_Id         : String(4);
        est_Acv             : String(4);
        model_Id            : String(4);
        isp_Id              : String(4);
        opp_Origin_Id       : String(4);

}


entity WfInstanceAssignment {
    key InstanceID          : TInstanceID;
    key AssignmentID        : String(4);
        //TechnicalState      : TInstanceStatus not null;
        technicalStateID    : String(4);
        currentStateID      : String(6); //not null;
        //CurrentState        : TBusinessStatus not null;
        CurrentStepName     : TWIStepName; //not null;
        currentStepID       : String(6);
        CurrentProcessor    : String(1000); //not null;
        reqResource         : TEmployee; 
        staffingPurpose     : String(100);
        staffingDateRange   : String(50);
        maxNoOfDaysToBookIO : String(4);
        taskLevel           : String(30);
        comments            : String(5000);
        DTCreation          : TDateTime;
        DTLastActivity      : TDateTime;
        //Decision            : TDecision;
        decisionID          : String(20);
};

entity YMRR_Account {
    key guid        : UUID @(title: 'GUID');
        wfInstance  : String(64);
        accountID   : String(64);
        accountName : String(100);
        //orgID       : String(4);
        orgID       : string_64;
        reqArea     : String(1000);
        roleID      : String(20);
        date        : Date not null;
        time        : Time not null;
        resource    : TResource;
}

entity YMRR_WfInsProcessor {
    key InstanceID            : UUID @(title: 'GUID');
    key assignmentID          : String(4);
    key currentProcessorID    : String(40);
        currentProcessorName  : String(100);
        currentProcessorEmail : String(100);
}

entity YMRR_ReqHistory {
    key InstanceID   : UUID @(title: 'GUID');
    key UserTaskID   : UUID;
        AssignmentID : String(4);
        User         : TEmployee;
        StateID      : String(50);
        StepID       : String(50);
        UT_refID     : Integer;
        Role         : String(50);
        Decision     : String(20);
        ActionTaken  : String(1000);
        RejID        : String(4);
        Comments     : String(5000);
        Date         : Date;
        Time         : Time;
}

// Table for Resource Profile Selection - Header Data
entity YMRR_ResProfileSel_Header {
    key InstanceID        : UUID;
    key role_ID         : String(4);
    key roleArea_ID     : String(4);        
        BA_Segment_ID   : String(4);
        role_Desc         : String(100);
        roleArea_Desc     : String(100);
        BA_Segment_Desc   : String(100);
        ProfitCenter_GUID : UUID;
};
 
// Table for Resource Profile Selection - Busniess Area LOB
entity YMRR_ResProfileSel_BALOB {
    key InstanceID  : UUID;
    key BA_LOB_ID : String(4);
        BA_LOB_Desc : String(100);
};
 
// Table for Resource Profile Selection - Cross Coverage
entity YMRR_ResProfileSel_CrossCvrg {
    key InstanceID  : UUID;
    key crossCoverage_ID : String(4);
        crossCoverage_Desc : String(100);
};
 
// Table for Resource Profile Selection - Hub LOB
entity YMRR_ResProfileSel_HubLOB {
    key InstanceID      : UUID;
    key hub_LOB_ID    : String(4);
        hub_LOB_Desc    : String(100);
        hub_Type        : String(50);
};
 
// Table for Resource Profile Selection - BA Industry
entity YMRR_ResProfileSel_BAIndustry {
    key InstanceID  : UUID;
    key BA_Industry_ID : String(4);
        BA_Industry_Desc : String(100);
};

// Table for Resource Profile Selection - Solution Area
entity YMRR_ResProfileSel_SolArea {
    key InstanceID    : UUID;
    key solution_Guid : String(64);
        is_MainSoln   : String(1);
};

entity YMR_T_Sol_Mtrl {
    key InstanceID : UUID;
    key MAT_ID     : String(40);
    key SOL_YEAR   : String(4);

}

// Table for Submit Request Form - Support Type
entity YMRR_ReqForm_SupportType {
    key InstanceID    : UUID;
    key supportTypeID : String(100);
};
 
// Table for Submit Request Form - Participant Type
entity YMRR_ReqForm_PartcpType {
    key InstanceID      : UUID;
    key participantTypeID : String(100);
};
 
// Table for Submit Request Form - Language
entity YMRR_ReqForm_Language {
    key InstanceID : UUID;
    key languageID   : String(50);
};
 
// Table for Submit Request Form - Involved SAP Parties
entity YMRR_ReqForm_InvSAP_Party {
    key InstanceID           : UUID;
    key involved_SAP_PartiesID : String(50);
};

//Table for Submit Request Form - URL

entity YMRR_WfinsURL {
    key instance_GUID : TInstanceID;
    key urlCountID    : Integer;
        urlName       : String(200);
        url           : String(5000);

}

// Table for user comments

entity YMR_Comment : cuid {
    key instanceID      : TInstanceID;
        actionId : String(4);
        commentText     : String(5000);
        userID          : String(100);
        userEmail       : String(100);
        userName        : String(100);
        userRole        : String(100);
        createdAt       : Timestamp;
        modifiedAt      : Timestamp;

}

entity YMR_M_CommentPrefix {
    key commentId : String(4);
        commentPrefix   : String(150);
        isActive        : String(1);
}
entity YMR_Variant {
    key variantGuid     : UUID;
        variantName     : String(120);
        author          : String(12);
        type            : String(1);
        executeOnSelect : String(1);
        filterString    : LargeString;
        includeTeam     : String(1);
        operationFlag   : String(1);
        _toUserVariant  : Composition of many YMR_T_User_Variant
                              on _toUserVariant.variantGuid = $self.variantGuid
}

entity YMR_T_User_Variant {
   key variantGuid : UUID;
    key userId      : String(12);
     isDefault       : String(1);
     
}
entity YMR_T_User_Notif {
 key   userId : String(12);
 key   notif_Id :String(4);
       notif_Val_Id : String(4);
 
}

view YI_MR_Variant as
    select from YMR_Variant {
        key variantGuid     as VariantGuid,
            variantName     as VariantName,
            author          as Author,
            type            as Type,
            executeOnSelect as ExecuteOnSelect,
            filterString    as FilterString,
            includeTeam     as IncludeTeam,
            operationFlag   as OperationFlag
    };

view YI_MR_T_User_Variant as select from  YMR_T_User_Variant {
   key variantGuid  as VariantGuid,
    key userId      as userID,
     isDefault       as IsDefault

};

view YI_UserHasDefault as
  select from YI_MR_T_User_Variant
{
    userID,
    max(
        case 
            when IsDefault = 'X' then 1
            else 0
        end
    ) as userHasDefault  
}
where userID <> 'SAP_ALL'
group by userID ;

view YC_MR_Variant as
    select from YI_MR_Variant as v
    left outer join YI_MR_T_User_Variant as uv
        on  v.VariantGuid = uv.VariantGuid
       and uv.userID = $user.id

    left outer join YI_MR_T_User_Variant as uvSap
        on uvSap.VariantGuid = v.VariantGuid
       and uvSap.userID = 'SAP_ALL'

     left outer join YI_UserHasDefault as udef
    on udef.userID = $user.id
    {
        key v.VariantGuid,
            VariantName,
            Author,
            Type,
            ExecuteOnSelect,
            FilterString,
            IncludeTeam,
case
        when uv.IsDefault = 'X' then 'X'                                 
        when (uv.IsDefault is null or uv.IsDefault = '') 
             and uvSap.IsDefault = 'X'
             and coalesce(udef.userHasDefault,0) = 0 then 'X'            
        else ''
    end as IsDefault : String(1),

            OperationFlag,
            case
                when v.Author = $user.id then 'X'
                else ''
            end as Editable:String(1)

    }
    where
                    v.OperationFlag =  'X'
        and (
            (
                    v.Author        =  'SAP_ALL'
            )
            or (
                    v.Author        <> 'SAP_ALL'
                and uv.userID       =  $user.id
            )
        ); 

view YC_MR_ManagedVariant as
    select from YI_MR_Variant as v
    left outer join YI_MR_T_User_Variant as uv
        on  v.VariantGuid = uv.VariantGuid
        and uv.userID = $user.id
    left outer join YI_MR_T_User_Variant as uvSap
        on uvSap.VariantGuid = v.VariantGuid
       and uvSap.userID = 'SAP_ALL'

   left outer join YI_UserHasDefault as udef
    on udef.userID = $user.id

        {
        key  v.VariantGuid,
            VariantName,
            Author,
             Type,
           ExecuteOnSelect,
           FilterString,
           IncludeTeam,
           OperationFlag,
case
        when uv.IsDefault = 'X' then 'X'                                
        when (uv.IsDefault is null or uv.IsDefault = '')
             and uvSap.IsDefault = 'X'
             and coalesce(udef.userHasDefault,0) = 0 then 'X'            
        else ''
    end as IsDefault : String(1),
    
          case
            when v.Author = $user.id then 'X' 
            else ''
        end as Editable:String(1),
        case 
           when uv.userID = $user.id then 'X'
           else ''
           end as Favourite:String(1)

    }

   where
        v.OperationFlag = 'X'
        and (
            v.Author = 'SAP_ALL'
            or (v.Author <> 'SAP_ALL' and v.Type = 'S')
            or (v.Author = $user.id)
        );
view YI_MR_M_CommentPrefix as
    select from YMR_M_CommentPrefix as prefix {
        key commentId,
            commentPrefix,
            isActive
    };

view YI_MR_T_Comment as
    select from YMR_Comment as comment {
        key comment.ID,
            instanceID,
            actionId,
            commentText,
            userID,
            userEmail,
            userName,
            userRole,
            createdAt,
            modifiedAt
    };

view YI_MR_M_Action as
    select from ReqArea_API.YMRR_Action as action {
        key ID,
            UserTaskID,
            eng_type_ID,
            orgID,
            orgType,
            Action_ID,
            commentId,
            Active,
    };

view YC_MR_T_Comment as select from YI_MR_T_Comment as comment 
left outer join YI_MR_M_Action as action 
on comment.actionId = action.ID

left outer join YI_MR_M_CommentPrefix as prefix 
on action.commentId = prefix.commentId
{
   key comment.ID, 
    comment.instanceID,
    comment.actionId,
    //concat(Prefix.commentPrefix,comment.commentText) as commentText: String(5000),
    concat(ifnull(prefix.commentPrefix, ''), comment.commentText) as commentText : LargeString,
    comment.userID,
    comment.userName,
    comment.userEmail,
    comment.userRole,
    comment.createdAt,
    comment.modifiedAt

};

@cds.autoexpose view YC_MR_T_Matrial as select from YMR_T_Sol_Mtrl as tmtrl
inner join ReqArea_API.YMR_M_SOL_MATERL as mtrl
on tmtrl.MAT_ID = mtrl.MAT_ID
{
    tmtrl.InstanceID,
    tmtrl.MAT_ID,
    mtrl.MAT_DESC,
    tmtrl.SOL_YEAR
};

@cds.autoexpose view YC_MR_T_Solutions as
    select from YMRR_ResProfileSel_SolArea as solArea
    left outer join ReqArea_API.YMR_M_SOL_TXNMY as L5
        on solArea.solution_Guid = L5.SOLN_GUID
    left outer join ReqArea_API.YMR_M_SOL_TXNMY as L4
        on L5.SOLN_PRNT_GUID = L4.SOLN_GUID
    left outer join ReqArea_API.YMR_M_SOL_TXNMY as L3
        on L4.SOLN_PRNT_GUID = L3.SOLN_GUID
    left join ReqArea_API.YMR_M_SOL_TXNMY as L2
        on L3.SOLN_PRNT_GUID = L2.SOLN_GUID
    left outer join ReqArea_API.YMR_M_SOL_TXNMY as L1
        on L2.SOLN_PRNT_GUID = L1.SOLN_GUID
    left outer join ReqArea_API.YMR_M_SOL_TXNMY as SelectedSoln
        on solArea.solution_Guid = SelectedSoln.SOLN_GUID
    {
        key solArea.InstanceID,
        key solArea.solution_Guid,
            SelectedSoln.SOLN_NAME as solution_Desc,
    case
      when solArea.solution_Guid = L5.SOLN_GUID then
        (case when L1.SOLN_NAME is not null and L1.SOLN_NAME <> '' then L1.SOLN_NAME else '' end) ||
        (case when L2.SOLN_NAME is not null and L2.SOLN_NAME <> '' then 
                (case when L1.SOLN_NAME is not null and L1.SOLN_NAME <> '' then ' > ' else '' end) || L2.SOLN_NAME
              else '' end) ||
        (case when L3.SOLN_NAME is not null and L3.SOLN_NAME <> '' then
                (case when (L1.SOLN_NAME is not null and L1.SOLN_NAME <> '') or (L2.SOLN_NAME is not null and L2.SOLN_NAME <> '') then ' > ' else '' end) || L3.SOLN_NAME
              else '' end) ||
        (case when L4.SOLN_NAME is not null and L4.SOLN_NAME <> '' then
                (case when (L1.SOLN_NAME is not null and L1.SOLN_NAME <> '') or (L2.SOLN_NAME is not null and L2.SOLN_NAME <> '') or (L3.SOLN_NAME is not null and L3.SOLN_NAME <> '') then ' > ' else '' end) || L4.SOLN_NAME
              else '' end) ||
        (case when L5.SOLN_NAME is not null and L5.SOLN_NAME <> '' then
                (case when (L1.SOLN_NAME is not null and L1.SOLN_NAME <> '') or (L2.SOLN_NAME is not null and L2.SOLN_NAME <> '') or (L3.SOLN_NAME is not null and L3.SOLN_NAME <> '') or (L4.SOLN_NAME is not null and L4.SOLN_NAME <> '') then ' > ' else '' end) || L5.SOLN_NAME
              else '' end)

      when solArea.solution_Guid = L4.SOLN_GUID then
        (case when L1.SOLN_NAME is not null and L1.SOLN_NAME <> '' then L1.SOLN_NAME else '' end) ||
        (case when L2.SOLN_NAME is not null and L2.SOLN_NAME <> '' then 
                (case when L1.SOLN_NAME is not null and L1.SOLN_NAME <> '' then ' > ' else '' end) || L2.SOLN_NAME
              else '' end) ||
        (case when L3.SOLN_NAME is not null and L3.SOLN_NAME <> '' then
                (case when (L1.SOLN_NAME is not null and L1.SOLN_NAME <> '') or (L2.SOLN_NAME is not null and L2.SOLN_NAME <> '') then ' > ' else '' end) || L3.SOLN_NAME
              else '' end) ||
        (case when L4.SOLN_NAME is not null and L4.SOLN_NAME <> '' then
                (case when (L1.SOLN_NAME is not null and L1.SOLN_NAME <> '') or (L2.SOLN_NAME is not null and L2.SOLN_NAME <> '') or (L3.SOLN_NAME is not null and L3.SOLN_NAME <> '') then ' > ' else '' end) || L4.SOLN_NAME
              else '' end)

      when solArea.solution_Guid = L3.SOLN_GUID then
        (case when L1.SOLN_NAME is not null and L1.SOLN_NAME <> '' then L1.SOLN_NAME else '' end) ||
        (case when L2.SOLN_NAME is not null and L2.SOLN_NAME <> '' then 
                (case when L1.SOLN_NAME is not null and L1.SOLN_NAME <> '' then ' > ' else '' end) || L2.SOLN_NAME
              else '' end) ||
        (case when L3.SOLN_NAME is not null and L3.SOLN_NAME <> '' then
                (case when (L1.SOLN_NAME is not null and L1.SOLN_NAME <> '') or (L2.SOLN_NAME is not null and L2.SOLN_NAME <> '') then ' > ' else '' end) || L3.SOLN_NAME
              else '' end)

      when solArea.solution_Guid = L2.SOLN_GUID then
        (case when L1.SOLN_NAME is not null and L1.SOLN_NAME <> '' then L1.SOLN_NAME else '' end) ||
        (case when L2.SOLN_NAME is not null and L2.SOLN_NAME <> '' then 
                (case when L1.SOLN_NAME is not null and L1.SOLN_NAME <> '' then ' > ' else '' end) || L2.SOLN_NAME
              else '' end)

      else
        (case when L1.SOLN_NAME is not null and L1.SOLN_NAME <> '' then L1.SOLN_NAME else '' end)
    end as solution_Hierarchy   : LargeString,
 

        solArea.is_MainSoln
    };
view YI_ResProfileRoleSelection as select from YMRR_ResProfileSel_Header as Header
{
    Header.InstanceID,  
    
    // Concatenate BA_Segment values with '; ' separator
    (select string_agg(Segment.BA_Segment_ID, '; ') as BA_Segment_ID
     from YMRR_ResProfileSel_Header as Segment
     where Segment.InstanceID = Header.InstanceID) as BA_Segment_ID : String(255),

    (select string_agg(Segment.BA_Segment_Desc, '; ') as BA_Segment_Desc
     from YMRR_ResProfileSel_Header as Segment
     where Segment.InstanceID = Header.InstanceID) as BA_Segment_Desc : String(255),

    // Concatenate BA_LOB values with '; ' separator
    (select string_agg(Lob.BA_LOB_ID, '; ') as BA_LOB_ID
     from YMRR_ResProfileSel_BALOB as Lob
     where Lob.InstanceID = Header.InstanceID) as BA_LOB_ID : String(255),

    (select string_agg(Lob.BA_LOB_Desc, '; ') as BA_LOB_Desc
     from YMRR_ResProfileSel_BALOB as Lob
     where Lob.InstanceID = Header.InstanceID) as BA_LOB_Desc : String(255),

    // Concatenate crossCoverage values with '; ' separator
    (select string_agg(Cvrg.crossCoverage_ID, '; ') as crossCoverage_ID
     from YMRR_ResProfileSel_CrossCvrg as Cvrg
     where Cvrg.InstanceID = Header.InstanceID) as crossCoverage_ID : String(255),

    (select string_agg(Cvrg.crossCoverage_Desc, '; ') as crossCoverage_Desc
     from YMRR_ResProfileSel_CrossCvrg as Cvrg
     where Cvrg.InstanceID = Header.InstanceID) as crossCoverage_Desc : String(255),

    // Concatenate BA_Industry values with '; ' separator
    (select string_agg(Industry.BA_Industry_ID, '; ') as BA_Industry_ID 
     from YMRR_ResProfileSel_BAIndustry as Industry
     where Industry.InstanceID = Header.InstanceID) as BA_Industry_ID : String(255),

    (select string_agg(Industry.BA_Industry_Desc, '; ') as BA_Industry_Desc
     from YMRR_ResProfileSel_BAIndustry as Industry
     where Industry.InstanceID = Header.InstanceID) as BA_Industry_Desc : String(255),     

     // Concatenate Solution Area values with '; ' separator
    (select string_agg(solArea.solution_Guid, '; ') as SolArea_ID
     from YC_MR_T_Solutions as solArea
     where solArea.InstanceID = Header.InstanceID and solArea.is_MainSoln = 'X') as SolArea_ID : String(255),

     (select string_agg(solArea.solution_Desc, '; ') as Solution_Desc
     from YC_MR_T_Solutions as solArea
     where solArea.InstanceID = Header.InstanceID and solArea.is_MainSoln = 'X') as Solution_Desc : String(1000),
     
     (select string_agg(Role.role_ID, '; ') as Role_ID
     from YMRR_ResProfileSel_Header as Role
     where Role.InstanceID = Header.InstanceID) as Role_ID : String(255),

     (select string_agg(Role.role_Desc, '; ') as Role_Desc
     from YMRR_ResProfileSel_Header as Role
     where Role.InstanceID = Header.InstanceID) as Role_Desc : String(255),
}
group by Header.InstanceID;

view YI_ResProfileRoleSelection_Details as select from YMRR_ResProfileSel_Header as Header    
left outer join YI_ResProfileRoleSelection as Details on Header.InstanceID = Details.InstanceID
{
    
    Header.InstanceID,
    Header.ProfitCenter_GUID,
    max(Details.Role_ID) as Role_ID :String(255),
    max(Details.Role_Desc) as Role_Desc  : String(255),
    max(Header.roleArea_ID) as roleArea_ID  : String(255),
    max(Header.roleArea_Desc) as roleArea_Desc  : String(255),
    max(Details.BA_Segment_ID) as BA_Segment_ID  : String(255),
    max(Details.BA_Segment_Desc) as BA_Segment_Desc  : String(255),
    max(Details.BA_LOB_ID) as BA_LOB_ID  : String(255),
    max(Details.BA_LOB_Desc) as BA_LOB_Desc  : String(255),
    max(Details.crossCoverage_ID) as crossCoverage_ID  : String(255),
    max(Details.crossCoverage_Desc) as crossCoverage_Desc  : String(255),
    max(Details.BA_Industry_ID) as BA_Industry_ID  : String(255),
    max(Details.BA_Industry_Desc) as BA_Industry_Desc  : String(255),   
    max(Details.SolArea_ID) as SolArea_ID  : String(255),
    max(Details.Solution_Desc) as Solution_Desc  : String(1000)   
}
group by Header.InstanceID, Header.ProfitCenter_GUID;


view YI_ReqForm_Values as
    select from YI_ReqForm_SupportType as Stype
    left outer join YI_ReqForm_PartcpType as prtcptyp
    on Stype.InstanceID = prtcptyp.InstanceID
{ 
    Stype.InstanceID,
    // Concatenate supportTypeID with ';' separator
    (select string_agg(SupportTypeID, '; ') as SupportTypeIDs
     from YI_ReqForm_SupportType
     where InstanceID = Stype.InstanceID ) as SupportTypeIDs : String(255),
      // Concatenate supportTypeDesc with ';' separator
    (select string_agg(SupportType, '; ') as SupportTypeDesc
     from YI_ReqForm_SupportType
     where InstanceID = Stype.InstanceID ) as SupportTypeDesc : String(255),

    // Concatenate participantTypeID with ';' separator
    (select string_agg(ParticipantTypeID, '; ') as ParticipantTypeIDs
     from YI_ReqForm_PartcpType
     where InstanceID = Stype.InstanceID ) as ParticipantTypeIDs : String(255),
     // Concatenate participantTypeDesc with ';' separator
    (select string_agg(ParticipantType, '; ') as ParticipantTypeDesc
     from YI_ReqForm_PartcpType
     where InstanceID = Stype.InstanceID ) as ParticipantTypeDesc : String(255),
    
    // Concatenate languageID with ';' separator
    (select string_agg(LanguageID, '; ') as languageIDs
     from YI_ReqForm_Language
     where InstanceID = Stype.InstanceID ) as LanguageIDs : String(255),
      // Concatenate languageDesc with ';' separator
    (select string_agg(Language, '; ') as languageDesc
     from YI_ReqForm_Language
     where InstanceID = Stype.InstanceID ) as LanguageDesc : String(255),
    
    // Concatenate involved_SAP_PartiesID with ';' separator
    (select string_agg(Involved_SAP_PartiesID, '; ') as involved_SAP_PartiesIDs
     from YI_ReqForm_InvSAP_Party 
     where InstanceID = Stype.InstanceID ) as Involved_SAP_PartiesIDs : String(255),
      // Concatenate involved_SAP_PartiesDesc with ';' separator
    (select string_agg(Involved_SAP_Parties, '; ') as involved_SAP_PartiesDesc
     from YI_ReqForm_InvSAP_Party 
     where InstanceID = Stype.InstanceID ) as Involved_SAP_PartiesDesc : String(255)

}
group by Stype.InstanceID;
//Interface view for ReqHistory table to get last action taken data
view YI_ReqHistory as 
select from (
    select 
        MRhistory.InstanceID,
        MRhistory.UserTaskID,
        MRhistory.UT_refID,
        MRhistory.AssignmentID,
        MRhistory.User,
        MRhistory.Role,
        MRhistory.StateID,
        MRhistory.Date,
        MRhistory.Time,
        MRhistory.Decision,
        MRhistory.Comments,
        row_number() over (partition by MRhistory.InstanceID 
                           order by MRhistory.UT_refID desc) as RankNum
    from YMRR_ReqHistory as MRhistory
) as RankedHistory
where RankedHistory.RankNum = 1;


//Interface View for Parent & Child WfInstance Table
view YI_WfInstance as
    select from YMRR_WFIns_Parent as wfIns_par
    inner join YMRR_WfInstance as wfIns
        on wfIns_par.instance_GUID = wfIns.parentInstance_GUID
    {
        wfIns.instance_GUID             as InstanceID,
        wfIns_par.instance_GUID         as ParentInstanceID,
        wfIns.definitionID              as WorkflowDefinitionID,
        wfIns_par.refID                 as Parent_RefrenceID,
        wfIns.refID                     as RefrenceID,
        wfIns_par.orgID                 as OrgID,
        wfIns_par.orgType               as OrgType,
        wfIns.technicalStateID          as TechnicalStateID,
        wfIns.currentStateID            as currentStateID,
        wfIns.currentStepID             as CurrentStepID,
        wfIns.decisionID                as DecisionID,
        wfIns_par.reqTypeID             as RequestTypeID,
        wfIns_par.eng_type_ID           as EngagementTypeID,
        wfIns.userTaskID                as UserTaskID,
        wfIns_par.opportunityID         as OpportunityID @(title: 'Opportunity ID'),
        wfIns_par.opportunityDesc       as OpportunityDesc,
        wfIns_par.account               as Account,
        wfIns_par.systemID              as SystemID,
        wfIns.currentProcessor          as CurrentProcessor,
        wfIns.currentProcessorID        as CurrentProcessorID,
        wfIns.currentProcessorEmail     as CurrentProcessorEmail,
        wfIns.dtCreation                as DTCreation,
        wfIns.dtLastActivity            as DTLastActivity,
        wfIns.reqAreaGUID               as ReqAreaGUID,
        wfIns.IAC_RoleMap_GUID          as IAC_RoleMap_GUID,
        wfIns.substituteProcessor       as substituteProcessor,
        wfIns.substituteProcessorID     as substituteProcessorID,
        wfIns.substituteProcessorEmail  as substituteProcessorEmail,
        wfIns.approvers as approvers,
        wfIns_par.empRequester.ID       as EmpRequester_ID,
        wfIns_par.empRequester.Name     as EmpRequester_Name,
        wfIns_par.empRequester.EMail    as EmpRequester_EMail,
        wfIns.reqApprover.ID            as ReqApproverID,
        wfIns.reqApprover.Name          as ReqApproverName,
        wfIns.reqApprover.EMail         as ReqApproverEmail,
        wfIns.reqResources              as ReqResourcesID,
        wfIns.reqIOApprover             as ReqIOApproverID,
        wfIns_par.extSystemsUrl         as ExtSystemsUrl,
        wfIns.currency                  as Currency,
        wfIns.revenueCloud              as RevenueCloud,
        wfIns.revenuePremise            as RevenuePremise,
        wfIns.dealScore                 as DealScore,
        wfIns.currentTaskInstanceID     as CurrentTaskInstanceID,
        wfIns_par.industryName          as IndustryName,
        wfIns_par.pE_Name               as PE_Name,
        wfIns.currentTaskURL            as CurrentTaskURL,
        // Fields from Submit Request Form
        wfIns.need_from_CustAdvisory    as Need_From_CustomerAdvisory,
        wfIns.cust_asked_forMeeting     as Customer_asked_forMeeting,
        wfIns.comments                  as comments,
        wfIns.solution_Models           as Solution_Models,
        wfIns.custAdvisory_Resource     as Customer_Advisory_Resource,
        wfIns.meetingTypeID             as MeetingTypeID,
        wfIns.meeting_Goal              as Meeting_Goal,
        wfIns.meetingLocation           as Meeting_Location,
        wfIns.meetingDate               as Meeting_Date,
        wfIns.meetingTime               as Meeting_Time,
        wfIns.involved_SAP_Parties_Name as Involved_SAP_Parties_Name,
        wfIns.participants_Type_Details as Participants_Type_Details,
        wfIns.isAttachment              as Attachment
    };
    

    
view YC_MR_T_Wfinstance_Ext  as
select from wf.YMR_T_Wfinstance_Ext as ext 
  left outer join YI_WfInstance as wfins on wfins.InstanceID = ext.instance_Guid
  left outer join ReqArea_API.YC_MR_M_FRM_CONFIG_VAL as suppTypeFBS on  suppTypeFBS.ID = ext.supp_Type_FBS_Id and suppTypeFBS.orgID = wfins.OrgID and suppTypeFBS.field_Label_ID = '0036'
  left outer join ReqArea_API.YC_MR_M_FRM_CONFIG_VAL as suppTypePQA on  suppTypePQA.ID = ext.supp_Type_Pqa_Id and suppTypePQA.orgID = wfins.OrgID and suppTypePQA.field_Label_ID = '0022'
  left outer join ReqArea_API.YC_MR_M_FRM_CONFIG_VAL as soln on soln.ID = ext.solution_Id and soln.orgID = wfins.OrgID and soln.field_Label_ID = '0026'
  left outer join ReqArea_API.YC_MR_M_FRM_CONFIG_VAL as acv on acv.ID = ext.est_Acv and acv.orgID = wfins.OrgID and acv.field_Label_ID = '0027'
  left outer join ReqArea_API.YC_MR_M_FRM_CONFIG_VAL as model on model.ID = ext.model_Id and model.orgID = wfins.OrgID and model.field_Label_ID = '0028'
  left outer join ReqArea_API.YC_MR_M_FRM_CONFIG_VAL as isp on isp.ID = ext.isp_Id and isp.orgID = wfins.OrgID and isp.field_Label_ID = '0029'
  left outer join ReqArea_API.YC_MR_M_FRM_CONFIG_VAL as oppOrigin on  oppOrigin.ID = ext.opp_Origin_Id and oppOrigin.orgID = wfins.OrgID and oppOrigin.field_Label_ID = '0024'
  left outer join ReqArea_API.YMR_M_Group as GRP on GRP.group_ID = ext.group_ID
  {
    ext.instance_Guid,  
    ext.Opp_Number,
    ext.io_Number,
    ext.contact_Prsn_Id,
    ext.contact_Prsn_Email,
    ext.need_From_Fbs,
    ext.c2c_Deal,
    ext.oppclosing_Date,
    ext.contract_Start_Date,
    ext.contract_End_Date,
    ext.group_ID as GroupID,
    GRP.group_Desc as GroupDesc,  
    suppTypeFBS.ID as FBSSupportTypeID,
    suppTypeFBS.Value as FBSSupportTypeDesc:String(100),
    suppTypePQA.ID as SuppTypePQAID,
    suppTypePQA.Value as SuppTypePQADesc:String(100),
    soln.ID as SolutionID,
    soln.Value as SolutionDesc:String(100),
    acv.ID as EstimatedACVID,
    acv.Value as EstimatedACVDesc:String(100),
    model.ID as BusinessModelID,
    model.Value as BusinessModelDesc:String(100),
    isp.ID as InfraStructureProviderID,
    isp.Value as InfraStructureProviderDesc:String(100),
    oppOrigin.ID as OpportunityOriginID,
    oppOrigin.Value as OpportunityOriginDesc:String(100)
  };
view YI_WfInstanceExt as
    // select from YMRR_WfInstanceExt as wfExt
    // inner join WfInstance as wfIns
    //     on wfExt.InstanceID = wfIns.InstanceID
    select from YI_WfInstance as wfIns
    left outer join resources.Sales_Org as sOrg
        on  wfIns.OrgID   = sOrg.ID
        and wfIns.OrgType = 'SORG'
    left outer join resources.YMRR_MarketUnit as mu
        on  wfIns.OrgID   = mu.id
        and wfIns.OrgType = 'MUID'
    left outer join ORE_API.YMRR_ProfitCenter as pc
        on wfIns.OrgID = pc.profitCenterGUID
        and wfIns.OrgType = 'PC'
    left outer join ReqArea_API.YMRR_CurrentState as currState
        on wfIns.currentStateID = currState.ID
    //inner join YI_WfIns_FormDDValues as formVal
    //    on wfIns.InstanceID = formVal.InstanceID
    left outer join ReqArea_API.V_RequestArea as reqArea
        on wfIns.ReqAreaGUID = reqArea.GUID
    left outer join ReqArea_API.YMRR_TechnicalState as techState
        on wfIns.TechnicalStateID = techState.ID
    left outer join ReqArea_API.YMRR_WF_Defination as wfDef
        on wfIns.WorkflowDefinitionID = wfDef.ID
    left outer join ReqArea_API.YMRR_RequestType as reqType
        on wfIns.RequestTypeID = reqType.ID
    left outer join ReqArea_API.YMR_M_Engagement as EngType
     on wfIns.EngagementTypeID = EngType.eng_type_ID
    left outer join ReqArea_API.YC_MR_M_ACTION  as decision //Join for Decision
        on wfIns.DecisionID = decision.ID
    left outer join ReqArea_API.YMRR_CurrentStep as crntStp
        on wfIns.CurrentStepID = crntStp.ID
    // left outer join YMRR_WfInsProcessor as proc
    //     on wfIns.InstanceID = proc.InstanceID
    left outer join YI_ResProfileRoleSelection_Details as roleDetails
    on wfIns.InstanceID = roleDetails.InstanceID
    left outer join ReqArea_API.YMRR_UserTask as userTask
    on wfIns.currentStateID = userTask.stateID
     left outer join YI_ReqHistory as ReqHistory
        on wfIns.InstanceID = ReqHistory.InstanceID
    left outer join YC_MR_T_Wfinstance_Ext as wfInsExtn
    on wfIns.InstanceID = wfInsExtn.instance_Guid
    {
        wfIns.InstanceID,
        wfIns.ParentInstanceID,
        case
            when
                exists(select from YI_WfInstance as wfinsext {
                    wfinsext.ParentInstanceID,
                }
                where
                    wfinsext.ParentInstanceID = wfIns.ParentInstanceID
                group by wfinsext.ParentInstanceID
                having
                    SUM(
                        case
                            when
                                wfinsext.TechnicalStateID = 'COMP'
                            then
                                1
                        end
                    ) = COUNT(
                        wfinsext.ParentInstanceID
                    )
                )
            then
                'RQCO'
            when
                wfIns.InstanceID           = wfIns.ParentInstanceID
                and wfIns.TechnicalStateID = 'INPR'
            then
                'RQCR'
            else
                'RQIP'
        end                 as Overall_WF_Status:String(20),
        wfIns.Parent_RefrenceID,
        wfIns.RefrenceID,
        wfIns.WorkflowDefinitionID,
        wfDef.wf_Defination             as WorkflowDefinition,
        wfIns.OrgType,
        wfIns.OrgID,
                case
            when
                wfIns.OrgType = 'SORG'
            then
                sOrg.Desc
            when
                wfIns.OrgType  = 'MUID'
            then
                mu.desc
            when
                wfIns.OrgType  = 'PC'
            then
                pc.profitCenterDesc
        end                             as orgName : String(100) @(title: 'Org Name'),
        wfIns.TechnicalStateID,
        techState.technicalState        as TechnicalState,
        wfIns.currentStateID,
        currState.Value                 as CurrentState          @(title: 'Current State'),
        wfIns.CurrentStepID,
        crntStp.currentStep             as CurrentStepName,
	    currState.taskOwnerRole  as taskOwnerRole,  
        wfIns.DecisionID,
        decision.Label                  as Decision,
	    decision.Label_Desc          as Decision_Desc,
        wfIns.RequestTypeID,     
        reqType.requestType             as RequestType,
        wfIns.EngagementTypeID, 
        EngType.eng_type_Desc as EngagementType,
         wfIns.UserTaskID,
        userTask.userTaskName    as UserTaskName,
        wfIns.OpportunityID @(title: 'Opportunity ID'),
        wfIns.OpportunityDesc,
        wfIns.Account,
        wfIns.SystemID,
        wfIns.CurrentProcessor,
        wfIns.CurrentProcessorID,
        wfIns.CurrentProcessorEmail,
        wfIns.DTCreation,
        wfIns.DTLastActivity,
        wfIns.ReqAreaGUID,
        reqArea.Request_Area            as RequestArea,
        wfIns.IAC_RoleMap_GUID,
        wfIns.substituteProcessor,     
        wfIns.substituteProcessorID,     
        wfIns.substituteProcessorEmail, 
        wfIns.approvers,
        wfIns.EmpRequester_ID,
        wfIns.EmpRequester_Name,
        wfIns.EmpRequester_EMail,
        wfIns.ReqApproverID,
        wfIns.ReqApproverName,
        wfIns.ReqApproverEmail,
        wfIns.ReqResourcesID,
        wfIns.ReqIOApproverID,
        ReqHistory.User.ID       as LastActionTaken_UserID,
        ReqHistory.User.Name     as LastActionTaken_UserName,
        ReqHistory.User.EMail    as LastActionTaken_UserEmail,
        ReqHistory.Role          as LastActionTaken_UserRole,
        wfIns.ExtSystemsUrl,
        wfIns.Currency,
        wfIns.RevenueCloud,
        wfIns.RevenuePremise,
        wfIns.DealScore,
        wfIns.CurrentTaskInstanceID,
        wfIns.IndustryName,
        wfIns.PE_Name,
        wfIns.CurrentTaskURL,
        // Fields from Submit Request Form
        wfIns.Need_From_CustomerAdvisory,
        wfIns.Customer_asked_forMeeting,
        wfIns.MeetingTypeID,
        // formVal.meetType_ID,
        // formVal.Meeting_Type,
        // formVal.Language_ID,
        // formVal.Language,
        // formVal.ParticipantType_ID,
        // formVal.ParticipantType,
        wfIns.comments,
        wfIns.Solution_Models,
        wfIns.Customer_Advisory_Resource,
        wfIns.Meeting_Goal,
        // formVal.SupportType_ID,
        // formVal.SupportType,
        wfIns.Meeting_Location,
        wfIns.Meeting_Date,
        wfIns.Meeting_Time,
        // formVal.Involved_SAP_Parties_ID,
        // formVal.Involved_SAP_Parties,
        wfIns.Involved_SAP_Parties_Name,
        wfIns.Participants_Type_Details,
        wfIns.Attachment,
        wfInsExtn.Opp_Number     as additionalOpp,
        wfInsExtn.io_Number,
        wfInsExtn.contact_Prsn_Id,
        wfInsExtn.contact_Prsn_Email,
        wfInsExtn.need_From_Fbs,
        wfInsExtn.c2c_Deal,
        wfInsExtn.oppclosing_Date,
        wfInsExtn.contract_Start_Date,
        wfInsExtn.contract_End_Date,
        wfInsExtn.GroupID,
        wfInsExtn.GroupDesc,
        wfInsExtn.FBSSupportTypeID,
        wfInsExtn.FBSSupportTypeDesc,
        wfInsExtn.SuppTypePQAID,
        wfInsExtn.SuppTypePQADesc,
        wfInsExtn.SolutionID,
        wfInsExtn.SolutionDesc,
        wfInsExtn.EstimatedACVID,
        wfInsExtn.EstimatedACVDesc,
        wfInsExtn.BusinessModelID,
        wfInsExtn.BusinessModelDesc,
        wfInsExtn.InfraStructureProviderID,
        wfInsExtn.InfraStructureProviderDesc,
        wfInsExtn.OpportunityOriginID,
        wfInsExtn.OpportunityOriginDesc,
        roleDetails.Role_ID,
        roleDetails.Role_Desc,
        roleDetails.roleArea_ID,
        roleDetails.roleArea_Desc,
        roleDetails.BA_LOB_ID,
        roleDetails.BA_LOB_Desc,
        roleDetails.BA_Industry_ID,
        roleDetails.BA_Industry_Desc,       
        roleDetails.BA_Segment_ID,
        roleDetails.BA_Segment_Desc,
        roleDetails.crossCoverage_ID,
        roleDetails.crossCoverage_Desc,
        roleDetails.SolArea_ID,   
        roleDetails.Solution_Desc
 
    };
view WfInstanceAssignment_Agg as
    select from WfInstanceAssignment
    {
        InstanceID,
        cast(string_agg(reqResource.ID, '; ')    as String(1000)) as ResourceIDs,
        cast(string_agg(reqResource.Name, '; ')  as String(1000)) as ResourceNames,
        cast(string_agg(reqResource.EMail, '; ') as String(1000)) as ResourceEmail
    }
    group by InstanceID;

view YC_WfInstanceExt as
    select from YI_WfInstanceExt as wfIns
    left outer join YI_ReqForm_Values as reqform
        on wfIns.InstanceID = reqform.InstanceID

    left outer join ReqArea_API.YMRR_TechnicalState as techState
        on wfIns.Overall_WF_Status = techState.ID

    left outer join WfInstanceAssignment_Agg as wfAssign
    on wfIns.InstanceID = wfAssign.InstanceID
    {
       
    key wfIns.InstanceID,
        wfIns.ParentInstanceID,
        wfIns.Overall_WF_Status,
        techState.technicalState as OverallMainReqStatus,
        wfIns.Parent_RefrenceID,
        wfIns.RefrenceID,
        wfIns.WorkflowDefinitionID,
        wfIns.WorkflowDefinition,
        wfIns.OrgType,
        wfIns.OrgID,
        wfIns.orgName       @(title: 'Org Name'),
        wfIns.TechnicalStateID,
        wfIns.TechnicalState,
        wfIns.currentStateID,
        wfIns.CurrentState  @(title: 'Current State'),
        wfIns.CurrentStepID,
        wfIns.CurrentStepName,
        wfIns.taskOwnerRole as taskOwnerRole,
        wfIns.DecisionID,
        wfIns.Decision,
        wfIns.Decision_Desc,
        wfIns.RequestTypeID,
        wfIns.RequestType,
        wfIns.EngagementTypeID,       
        wfIns.EngagementType,
        wfIns.UserTaskID,
        wfIns.UserTaskName,
        wfIns.OpportunityID @(title: 'Opportunity ID'),
        wfIns.OpportunityDesc,
        wfIns.Account,
        wfIns.SystemID,
        wfIns.CurrentProcessor,
        wfIns.CurrentProcessorID,
        wfIns.CurrentProcessorEmail,
        wfIns.DTCreation,
        wfIns.DTLastActivity,
        wfIns.ReqAreaGUID,
        wfIns.RequestArea,
        wfIns.IAC_RoleMap_GUID,
        wfIns.substituteProcessor,
        wfIns.substituteProcessorID ,
        wfIns.substituteProcessorEmail,
        wfIns.approvers,
        wfIns.EmpRequester_ID,
        wfIns.EmpRequester_Name,
        wfIns.EmpRequester_EMail,
        wfIns.ReqApproverID,
        wfIns.ReqApproverName,
        wfIns.ReqApproverEmail,
        wfIns.ReqResourcesID,
        wfIns.ReqIOApproverID,
        wfIns.LastActionTaken_UserID,
        wfIns.LastActionTaken_UserName,
        wfIns.LastActionTaken_UserEmail,
        wfIns.LastActionTaken_UserRole,
	    wfAssign.ResourceIDs,
        wfAssign.ResourceNames,
        wfAssign.ResourceEmail,
        wfIns.ExtSystemsUrl,
        wfIns.Currency,
        wfIns.RevenueCloud,
        wfIns.RevenuePremise,
        wfIns.DealScore,
        wfIns.CurrentTaskInstanceID,
        wfIns.IndustryName,
        wfIns.PE_Name,
        wfIns.CurrentTaskURL,
        // Fields from Submit Request Form
        wfIns.Need_From_CustomerAdvisory,
        wfIns.Customer_asked_forMeeting,
        wfIns.MeetingTypeID,
        wfIns.comments,
        wfIns.Solution_Models,
        wfIns.Customer_Advisory_Resource,
        wfIns.Meeting_Goal,
        wfIns.Meeting_Location,
        wfIns.Meeting_Date,
        wfIns.Meeting_Time,
        wfIns.Involved_SAP_Parties_Name,
        wfIns.Participants_Type_Details,
        reqform.Involved_SAP_PartiesIDs,
        reqform.Involved_SAP_PartiesDesc,
        reqform.LanguageIDs,
        reqform.LanguageDesc,
        reqform.ParticipantTypeIDs,
        reqform.ParticipantTypeDesc,
        reqform.SupportTypeIDs,
        reqform.SupportTypeDesc,
        wfIns.Attachment,
        wfIns.additionalOpp     as additionalOpp,
        wfIns.io_Number,
        wfIns.contact_Prsn_Id,
        wfIns.contact_Prsn_Email,
        wfIns.need_From_Fbs,
        wfIns.c2c_Deal,
        wfIns.oppclosing_Date,
        wfIns.contract_Start_Date,
        wfIns.contract_End_Date,
        wfIns.GroupID,
        wfIns.GroupDesc,
        wfIns.FBSSupportTypeID,
        wfIns.FBSSupportTypeDesc,
        wfIns.SuppTypePQAID,
        wfIns.SuppTypePQADesc,
        wfIns.SolutionID,
        wfIns.SolutionDesc,
        wfIns.EstimatedACVID,
        wfIns.EstimatedACVDesc,
        wfIns.BusinessModelID,
        wfIns.BusinessModelDesc,
        wfIns.InfraStructureProviderID,
        wfIns.InfraStructureProviderDesc,
        wfIns.OpportunityOriginID,
        wfIns.OpportunityOriginDesc,
        wfIns.Role_ID,
        wfIns.Role_Desc,
        wfIns.roleArea_ID,
        wfIns.roleArea_Desc,
        wfIns.BA_LOB_ID,
        wfIns.BA_LOB_Desc,
        wfIns.BA_Industry_ID,
        wfIns.BA_Industry_Desc,       
        wfIns.BA_Segment_ID,
        wfIns.BA_Segment_Desc,
        wfIns.crossCoverage_ID,
        wfIns.crossCoverage_Desc,
        wfIns.SolArea_ID,
        wfIns.Solution_Desc,

        _Solution : Association to many YC_MR_T_Solutions
                              on _Solution.InstanceID = InstanceID 
        

    };
view YC_MR_T_CURNTQTR_DTLS as
select from YC_WfInstanceExt
{       
    currentStateID,   
    case
    when  currentStateID = 'WIOAPP'  then 'In Review'
    when  currentStateID = 'WMNAPP'  then 'In Review'
    when  currentStateID = 'WSUBMN'  then 'In Review'
    when  currentStateID = 'REESUB'  then 'In Review'
    when  currentStateID = 'WRESAP'  then 'In Review'
    when  currentStateID = 'REQTER'  then 'Rejected/Cancelled'
    when  currentStateID = 'IOREJT'  then 'Rejected/Cancelled'
    when  currentStateID = 'REQREJ'  then 'Rejected/Cancelled'
    when  currentStateID = 'RSBREJ'  then 'Rejected/Cancelled'
    when  currentStateID = 'REQCOM'  then 'Completed/Assigned'
    when  currentStateID = 'RSBCOM'  then 'Completed/Assigned'
    else 'Not Specified'
    end as State: String(30), 
    DTCreation.tdate as CreationDate,
    // Compute quarter as a scalar column
    case
        when month(DTCreation.tdate) between 1 and 3  then 1
        when month(DTCreation.tdate) between 4 and 6  then 2
        when month(DTCreation.tdate) between 7 and 9  then 3
        else 4
    end as Quarter: Int16,
    year(DTCreation.tdate) as Year
}        
where WorkflowDefinitionID = '2';
view YC_MR_T_CURNTQTR_DTLS_CNT as
select from YC_MR_T_CURNTQTR_DTLS
{
    State,     
    Quarter,
    count(*) as RequestCount : Int16  
}
where
    Year = year($now)
    and Quarter = (floor((month($now)-1)/3) + 1)
group by   
    Quarter,
    State;
    

view YC_MR_T_CURNTQTR_DTLS_PERC as
select from YC_MR_T_CURNTQTR_DTLS_CNT
{   
    State, 
    Quarter,
    RequestCount,    
    ( RequestCount * 100 / SUM(RequestCount) OVER () ) AS Percentage: Decimal(5, 2),
};
  
view YC_WfInstance_Details as
    select from YI_WfInstanceExt as wfIns
    left outer join YI_ReqForm_Values as reqform
        on wfIns.InstanceID = reqform.InstanceID

    left outer join ReqArea_API.YMRR_TechnicalState as techState
        on wfIns.Overall_WF_Status = techState.ID

    left outer join YI_ResProfileRoleSelection_Details as roleDetails
    on wfIns.InstanceID = roleDetails.InstanceID 
    {
       
        wfIns.InstanceID,
        wfIns.ParentInstanceID,
        wfIns.Overall_WF_Status,
        techState.technicalState as WFStatusDescription,
        wfIns.Parent_RefrenceID,
        wfIns.RefrenceID,
        wfIns.WorkflowDefinitionID,
        wfIns.WorkflowDefinition,
        wfIns.OrgType,
        wfIns.OrgID,
        wfIns.orgName       @(title: 'Org Name'),
        wfIns.TechnicalStateID,
        wfIns.TechnicalState,
        wfIns.currentStateID,
        wfIns.CurrentState  @(title: 'Current State'),
        wfIns.CurrentStepID,
        wfIns.CurrentStepName,
        wfIns.taskOwnerRole as taskOwnerRole,
        wfIns.DecisionID,
        wfIns.Decision,
        wfIns.Decision_Desc,
        wfIns.RequestTypeID,
        wfIns.RequestType,
        wfIns.EngagementTypeID,
        wfIns.EngagementType,        
        wfIns.UserTaskID,
        wfIns.UserTaskName,
        wfIns.OpportunityID @(title: 'Opportunity ID'),
        wfIns.OpportunityDesc,
        wfIns.Account,
        wfIns.SystemID,
        wfIns.CurrentProcessor,
        wfIns.CurrentProcessorID,
        wfIns.CurrentProcessorEmail,
        wfIns.DTCreation,
        wfIns.DTLastActivity,
        wfIns.ReqAreaGUID,
        wfIns.RequestArea,
        wfIns.IAC_RoleMap_GUID,
        wfIns.substituteProcessor,
        wfIns.substituteProcessorID ,
        wfIns.substituteProcessorEmail,
        wfIns.approvers,
        wfIns.EmpRequester_ID,
        wfIns.EmpRequester_Name,
        wfIns.EmpRequester_EMail,
        wfIns.ReqApproverID,
        wfIns.ReqApproverName,
        wfIns.ReqApproverEmail,
        wfIns.ReqResourcesID,
        wfIns.ReqIOApproverID,
        wfIns.ExtSystemsUrl,
        wfIns.Currency,
        wfIns.RevenueCloud,
        wfIns.RevenuePremise,
        wfIns.DealScore,
        wfIns.CurrentTaskInstanceID,
        wfIns.IndustryName,
        wfIns.PE_Name,
        wfIns.CurrentTaskURL,
        // Fields from Submit Request Form
        wfIns.Need_From_CustomerAdvisory,
        wfIns.Customer_asked_forMeeting,
        wfIns.MeetingTypeID,
        wfIns.comments,
        wfIns.Solution_Models,
        wfIns.Customer_Advisory_Resource,
        wfIns.Meeting_Goal,
        wfIns.Meeting_Location,
        wfIns.Meeting_Date,
        wfIns.Meeting_Time,
        wfIns.Involved_SAP_Parties_Name,
        wfIns.Participants_Type_Details,
        reqform.Involved_SAP_PartiesIDs,
        reqform.Involved_SAP_PartiesDesc,
        reqform.LanguageIDs,
        reqform.LanguageDesc,
        reqform.ParticipantTypeIDs,
        reqform.ParticipantTypeDesc,
        reqform.SupportTypeIDs,
        reqform.SupportTypeDesc,
        wfIns.Attachment,
        wfIns.additionalOpp     as additionalOpp,
        wfIns.io_Number,
        wfIns.contact_Prsn_Id,
        wfIns.contact_Prsn_Email,
        wfIns.need_From_Fbs,
        wfIns.c2c_Deal,
        wfIns.oppclosing_Date,
        wfIns.contract_Start_Date,
        wfIns.contract_End_Date,
        wfIns.GroupID,
        wfIns.GroupDesc,
        wfIns.FBSSupportTypeID,
        wfIns.FBSSupportTypeDesc,
        wfIns.SuppTypePQAID,
        wfIns.SuppTypePQADesc,
        wfIns.SolutionID,
        wfIns.SolutionDesc,
        wfIns.EstimatedACVID,
        wfIns.EstimatedACVDesc,
        wfIns.BusinessModelID,
        wfIns.BusinessModelDesc,
        wfIns.InfraStructureProviderID,
        wfIns.InfraStructureProviderDesc,
        wfIns.OpportunityOriginID,
        wfIns.OpportunityOriginDesc,
        wfIns.Role_ID,
        wfIns.Role_Desc,
        roleDetails.roleArea_ID,
        roleDetails.roleArea_Desc,
        wfIns.BA_LOB_ID,
        wfIns.BA_LOB_Desc,
        wfIns.BA_Industry_ID,
        wfIns.BA_Industry_Desc,        
        roleDetails.BA_Segment_ID,
        roleDetails.BA_Segment_Desc,
        roleDetails.crossCoverage_ID,
        roleDetails.crossCoverage_Desc,
        roleDetails.SolArea_ID,
        roleDetails.Solution_Desc

    };

view YC_WfInstanceAssignment as
    //select from WfInstance as wf
    select from YI_WfInstance as wfIns
    left outer join WfInstanceAssignment as wfAssign
        on wfIns.InstanceID = wfAssign.InstanceID
    left outer join ReqArea_API.V_RequestArea as reqArea
        on wfIns.ReqAreaGUID = reqArea.GUID
    left outer join ReqArea_API.YMRR_CurrentState as currState
        on wfIns.currentStateID = currState.ID
    left outer join ReqArea_API.YMRR_TechnicalState as techState
        on wfAssign.technicalStateID = techState.ID
    left outer join ReqArea_API.YC_MR_M_ACTION  as decision  //Join for Decision
        on wfAssign.decisionID = decision.ID
    {
        wfIns.InstanceID,
        wfIns.Parent_RefrenceID,
        wfAssign.AssignmentID        as AssignmentID,
        wfAssign.technicalStateID    as TechnicalStateID,
        techState.technicalState     as TechnicalState,
        wfAssign.currentStateID as CurrentStateID,
        currState.Value              as CurrentState        @(title: 'Current State'),
        wfAssign.CurrentStepName     as CurrentStepName,
        wfAssign.CurrentProcessor as CurrentProcessor,
        wfIns.OpportunityID,
        wfIns.Account,
        wfIns.SystemID,
        wfIns.DTCreation.tdate,
        wfIns.DTCreation.ttime,
        wfAssign.staffingPurpose     as staffingPurpose,
        wfAssign.staffingDateRange   as staffingDateRange,
        wfAssign.maxNoOfDaysToBookIO as maxNoOfDaysToBookIO,
        wfAssign.taskLevel           as taskLevel,
        wfAssign.comments            as comments,
        case
            when
                wfAssign.currentStateID is null
            then
                wfIns.DTCreation.tdate
            else
                wfAssign.DTLastActivity.tdate
        end                          as DTLastActivity_tdate : Date,
        case
            when
                wfAssign.currentStateID is null
            then
                wfIns.DTLastActivity.ttime
            else
                wfAssign.DTLastActivity.ttime
        end                          as DTLastActivity_ttime : Time,
        wfIns.ReqAreaGUID,
        reqArea.Request_Area         as Request_Area,
        wfIns.EmpRequester_ID           as EmpRequester_ID,
        wfIns.EmpRequester_Name,
        wfIns.EmpRequester_EMail,
        wfIns.ExtSystemsUrl,
        wfAssign.decisionID          as DecisionID,
        decision.Label               as Decision,
	    decision.Label_Desc          as Decision_Desc,
        wfIns.Currency,
        wfIns.RevenueCloud,
        wfIns.RevenuePremise,
        wfIns.DealScore
    };
define view YI_MR_M_SuppType 
  as select from ReqArea_API.YC_MR_M_FRM_CONFIG_VAL as suppType
{
    suppType.ID,
    suppType.field_Label_ID,
    suppType.Field_ID,
    suppType.Field_Name,
    suppType.eng_Type_ID,
    suppType.Eng_Type_Desc,
    min(suppType.Role_ID) as role_ID,   
    suppType.reqTypeID,
    suppType.reqType,
    suppType.orgID,
    suppType.orgDesc,
    suppType.orgType,
    suppType.Value,
    suppType.Default_Flag,
    suppType.Operational_Status
}
group by
    suppType.ID,
    suppType.field_Label_ID,
    suppType.Field_ID,
    suppType.Field_Name,
    suppType.eng_Type_ID,
    suppType.Eng_Type_Desc,
    suppType.reqTypeID,
    suppType.reqType,
    suppType.orgID,
    suppType.orgDesc,
    suppType.orgType,
    suppType.Value,
    suppType.Default_Flag,
    suppType.Operational_Status;

// View for Submit Request Form - Support Type
view YI_ReqForm_SupportType as
    select from YMRR_ReqForm_SupportType as supTy
    left outer join YI_WfInstance AS wfins 
    on wfins.InstanceID = supTy.InstanceID
    left outer join ReqArea_API.YMRR_Form_Config_Values as formConf
        on formConf.ID = supTy.supportTypeID
    left outer join YI_MR_M_SuppType as form_values
        on form_values.ID = supTy.supportTypeID and form_values.orgID = wfins.OrgID and form_values.field_Label_ID='0001' and form_values.reqTypeID = wfins.RequestTypeID
    {
        supTy.InstanceID,
        supTy.supportTypeID as SupportTypeID,
        case
            when formConf.Value is not null then formConf.Value
            else form_values.Value
        end as  SupportType
    };        

// View for Submit Request Form - Participant Type
    view YI_ReqForm_PartcpType as
    select from YMRR_ReqForm_PartcpType as parTy
    left outer join YI_WfInstance AS wfins 
    on wfins.InstanceID = parTy.InstanceID
    left outer join ReqArea_API.YMRR_Form_Config_Values as formConf
        on formConf.ID = parTy.participantTypeID
    left outer join ReqArea_API.YC_MR_M_FRM_CONFIG_VAL as form_values
        on form_values.ID = parTy.participantTypeID and form_values.orgID = wfins.OrgID and form_values.field_Label_ID='0007'
    {
        parTy.InstanceID,
        parTy.participantTypeID as ParticipantTypeID,
        case
            when formConf.Value is not null then formConf.Value
            else form_values.Value
        end as ParticipantType
    };

// View for Submit Request Form - Language
view YI_ReqForm_Language as
    select from YMRR_ReqForm_Language as lang
    left outer join ReqArea_API.YMRR_Language as MRlang
        on lang.languageID = MRlang.language_ID
    {
        lang.InstanceID,
        lang.languageID as LanguageID,
        MRlang.language_Desc  as Language
    };
 
// View for Submit Request Form - Involved SAP Parties

view YI_ReqForm_InvSAP_Party as
    select from YMRR_ReqForm_InvSAP_Party as invSAP
    left outer join YI_WfInstance AS wfins 
    on wfins.InstanceID = invSAP.InstanceID
    left outer join ReqArea_API.YMRR_Form_Config_Values as formConf
        on formConf.ID = invSAP.involved_SAP_PartiesID
    left outer join ReqArea_API.YC_MR_M_FRM_CONFIG_VAL as form_values
        on form_values.ID = invSAP.involved_SAP_PartiesID and form_values.orgID = wfins.OrgID and form_values.field_Label_ID='0004'
    {
        invSAP.InstanceID,
        invSAP.involved_SAP_PartiesID as Involved_SAP_PartiesID,
        case
            when formConf.Value is not null then formConf.Value
            else form_values.Value
        end as Involved_SAP_Parties
    };
view YC_WfParent_status as
    select from YI_WfInstanceExt as wf {
        wf.InstanceID,
        wf.ParentInstanceID,
        wf.TechnicalStateID,
        case
            when
                exists(select from YI_WfInstanceExt as wfinsext {
                    wfinsext.ParentInstanceID,
                }
                where
                    wfinsext.ParentInstanceID = wf.ParentInstanceID
                group by wfinsext.ParentInstanceID
                having
                    SUM(
                        case
                            when
                                wfinsext.TechnicalStateID = 'COMP'
                            then
                                1
                        end
                    ) = COUNT(
                        wfinsext.ParentInstanceID
                    )
                )
            then
                'COMPLETED'
            else
                'INPROCESS'
        end                 as STATUS,
 
        wf.DTCreation as ReqCreate,        
        (
            select from YI_WfInstanceExt {
                max(DTLastActivity.tdate) as LastChange_date,
            }
            where
                ParentInstanceID = wf.ParentInstanceID 
        )                   as ReqLastChange_Date,
        (
            select from YI_WfInstanceExt {
                max(DTLastActivity.ttime) as LastChange_time,
            }
            where
                    DTLastActivity.tdate in (
                    select from YI_WfInstanceExt {
                        max(DTLastActivity.tdate) as lastChange_date,
                    }
                    where
                        ParentInstanceID = wf.ParentInstanceID
                )
                and ParentInstanceID     =  wf.ParentInstanceID
        )                   as ReqLastChange_Time
    }
    where
        wf.ParentInstanceID = wf.InstanceID;

//View for History Table
view YC_history as select from YMRR_ReqHistory as History
//inner join WfInstance as wf
inner join YMRR_WfInstance as wf
on History.InstanceID = wf.instance_GUID
left outer join ReqArea_API.YMRR_CurrentStep as CurrStep on History.StepID = CurrStep.ID
left outer join ReqArea_API.YMRR_RejCodes as  Rej on History.RejID =  Rej.RejID
{
History.InstanceID,
History.UserTaskID,
  concat (
      wf.refID, concat (
              '-', History.UT_refID )
                  ) as RefrenceID: Integer64,
                  History.UT_refID,
                  History.AssignmentID,
                  History.User.ID as UserId,
                  History.User.Name as UserName,
                  History.User.EMail as UserEmail,
                  History.Role,
                  History.StateID,
                  History.StepID,
                  CurrStep.currentStep as StepName,
                  History.Date || 'T' || History.Time || '.000Z' as Date : String(50),
                  History.Decision as DecisionID,
                  History.ActionTaken as Decision,
                  History.RejID,
                  Rej.Rej_Reason as RejectionReason,
                  History.Comments
                  };
 
view YC_Resprofile_sel as
    select from YI_WfInstanceExt as Ext
    inner join YMRR_ResProfileSel_Header as Header
        on Ext.InstanceID = Header.InstanceID
    left outer join YMRR_ResProfileSel_BAIndustry as BAIND
        on Ext.InstanceID = BAIND.InstanceID    
    left outer join YMRR_ResProfileSel_BALOB as LOB
        on Ext.InstanceID = LOB.InstanceID
    left outer join YMRR_ResProfileSel_CrossCvrg as cc
        on Ext.InstanceID = cc.InstanceID
    left outer join YC_MR_T_Solutions as solArea
        on Ext.InstanceID = solArea.InstanceID
    {
    
        Ext.InstanceID,
        Ext.ParentInstanceID,
        Header.ProfitCenter_GUID,
        Header.role_ID,
        Header.role_Desc,
        BAIND.BA_Industry_ID,
        BAIND.BA_Industry_Desc,        
        LOB.BA_LOB_ID,
        LOB.BA_LOB_Desc,
        cc.crossCoverage_ID,
        cc.crossCoverage_Desc,
        solArea.solution_Guid,
        solArea.solution_Desc
    };

view YC_MR_T_WfHistory as
        select from YC_history {

            key InstanceID      as InstanceID,
                UserTaskID      as UserTaskID,
                RefrenceID      as RefrenceID,
                UT_refID        as UT_refID,
                AssignmentID    as AssignmentID,
                UserId          as UserId,
                UserName        as UserName,
                UserEmail       as UserEmail,
                Role            as Role,
                StateID         as StateID,
                StepID          as StepID,
                StepName        as StepName,
                cast(Date as Timestamp) as Date,
                DecisionID      as DecisionID,
                Decision        as Decision,
                RejID           as RejID,
                RejectionReason as RejectionReason,
                Comments        as Comments,
                cast('ACTION' as String(10)) as EventType
        }

    union all

        select from YC_MR_T_Comment {

            key instanceID  as InstanceID,
                null        as UserTaskID,
                null        as RefrenceID,
                null        as UT_refID,
                null        as AssignmentID,
                userID      as UserId,
                userName    as UserName,
                userEmail   as UserEmail,
                userRole    as Role,
                null        as StateID,
                null        as StepID,
                null        as StepName,
                createdAt as  Date,
                null        as DecisionID,
                null        as Decision,
                null        as RejID,
                null        as RejectionReason,
                commentText as Comments,
                cast('CHAT' as String(10)) as EventType
        }
        where
            actionId is null or actionId = '';
