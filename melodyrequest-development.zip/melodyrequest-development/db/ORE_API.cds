namespace app.ORE_API;

using app.resources from '../db/resources';
using app.ReqArea_API from '../db/ReqArea_API';

type TAccount {
    ID   : String(64) not null;
    name : String(100) not null;
};
entity YMRR_ResProfile_Master {
    key resProfile_Master_GUID : String(32);
        manager_Level          : String(25);
        role_ID                : String(4);
        roleArea_ID            : String(4);
        bA_Industry_ID         : String(4);
        bA_Lob_ID              : String(4);
        cross_CVRG_ID          : String(4);
        bA_Seg_ID              : String(4);
        hub_ID                 : String(4);
        solnArea_ID            : String(64);
        subSolnArea_ID        : String(64);
}
entity YMR_M_ResPro_Cfg {
    key field_id    : String(4);
        field_name  : String(50);
        active : String(1);
};

entity YMR_M_ResProfile {
    key res_sel_guid : String(64);
    key field_id          : String(4);
        field_value      : String(50);
        active   : String(1);
}

entity YMRR_ResProfile_PC {
    key profitCenterGUID       : UUID;
    key resProfile_Master_GUID : String(64);
    key eng_type_ID   : String(4);
    key tableTypeID            : String(4);
    key userTypeID             : String(4);
    key userID                 : String(10);
        userName               : String(30);
        userEmail              : String(40);
        operationStatus        : String(1);
}

entity sorg_PC_Map {
    key sOrg              : String(4);
    key profitCenterGuid  : UUID;
    key eng_type_ID   : String(4);
    key sales_office_code :String(20);
        isResourceProfile : String(1);
        isPC_Viewable     : String(1);
        isPC_Selectable   : String(1);
        isParentNodeEnable : String(1);
        isChildNodeEnable  : String(1);
        default_Flag       : String(1);
}

entity YMRR_ProfitCenter {
    key profitCenterGUID : UUID;
        profitCenterID   : String(20);
        profitCenterDesc : String(150);
}

//Draft Table for Submit Request Form
entity YMRR_DF_WFIns_Parent {
    key parentInstance_GUID   : String(64);
        refID           : Integer;
        orgID           : String(64);
        orgType         : String(10);
        orgID_L         : String(9);
        reqTypeID       : String(4);
        eng_type_ID   : String(4);
        OpportunityID   :  String(64);
        opportunityDesc : String(1000);
        Account         : TAccount;
        SystemID        : String(10);
        industryName    : String(100);
        pE_Name         : String(100);
        ExtSystemsUrl   : String(255);
      
};
entity YMRR_DF_WFIns {
    key instanceDF_GUID           : String(64);
    key parentInstance_GUID       : String(64);
        tabID                     : String(100);
        technicalStateID          : String(4);
        reqAreaGUID               : String(64);
        create_Date               : Date;
        create_Time               : Time;
        change_Date               : Date;
        change_Time               : Time;
        decisionID                : String(20);
        // Fields From Search Criteria
        role_ID                   : String(10);
        bA_LOB_ID                 : String(10);
        crossCoverage_ID          : String(10);
        bA_Industry_ID            : String(10);
        group_ID : String(10);
        solution_Guid             : String(64);
        // Fields from Submit Request Form
        need_from_CustAdvisory    : String(5000);
        cust_asked_forMeeting     : String(1);
        meetingTypeID             : String(100);
        comments                  : String(5000);
        solution_Models           : String(1000);
        custAdvisory_Resource     : String(1000);
        Meeting_Goal              : String(5000);
        meetingLocation           : String(1000);
        meetingDate               : String(100);
        meetingTime               : String(100);
        involved_SAP_Parties_Name : String(5000);
        Participants_Type_Details : String(5000);
        Opp_Number          : String(100);
        io_Number           : String(250);
        contact_Prsn_Id     : String(150);
        contact_Prsn_Email  : String(500);
        need_From_Fbs       : String(5000);
        c2c_Deal            : String(1);
        oppclosing_Date     : Date;
        contract_Start_Date : Date;
        contract_End_Date   : Date;
        supp_Type_FBS       : String(4);
        supp_Type_Pqa_Id    : String(4);
        solution_Id         : String(4);
        est_Acv             : String(4);
        model_Id            : String(4);
        isp_Id              : String(4);
        opp_Origin_Id       : String(4);
        isAttachment              : String(1);
        language                  : Composition of many YMRR_DF_ReqForm_Language
                                        on language.WFIns = $self;
        SupportType               : Composition of many YMRR_DF_ReqForm_SupportType
                                        on SupportType.WFIns = $self;
        PartcpType                : Composition of many YMRR_DF_ReqForm_PartcpType
                                        on PartcpType.WFIns = $self;
        InvSAP_Party              : Composition of many YMRR_DF_ReqForm_InvSAP_Party
                                        on InvSAP_Party.WFIns = $self;
        WfinsURL                  : Composition of many YMRR_DF_WfinsURL
                                        on WfinsURL.WFIns = $self;
};

entity YMRR_DF_ReqForm_SupportType {
    key WFIns : Association to YMRR_DF_WFIns;
    key supportTypeID      : String(100);

};

entity YMRR_DF_ReqForm_PartcpType {
    key WFIns : Association to YMRR_DF_WFIns;
    key participantTypeID  : String(100);
};

entity YMRR_DF_ReqForm_Language {
    key WFIns : Association to YMRR_DF_WFIns;
    key languageID         : String(100);
};

entity YMRR_DF_ReqForm_InvSAP_Party {
    key WFIns : Association to YMRR_DF_WFIns;
    key involved_SAP_PartiesID : String(100);
};
entity YMRR_DF_WfinsURL {
    key WFIns : Association to YMRR_DF_WFIns;
    key urlCountID      : Integer;
        tabID              : String(100);
        urlName         : String(200);
        url             : String(5000);
};

entity YMRR_ReqArea_ResPro_Map {
    key reqArea_GUID     : UUID;
        profitCenterGUID : UUID;
        role_ID          : String(4);
        roleArea_ID      : String(4);
        bA_Seg_ID        : String(4);
        bA_Lob_ID        : String(4);
        cross_CVRG_ID    : String(4);
        bA_Industry_ID   : String(4);
}

// End of Code for ENTITY

// Start of Code for VIEW
view YI_DF_ReqForm as
    select from YMRR_DF_WFIns as dftype
    left outer join YMRR_DF_ReqForm_SupportType as SupportType
    on dftype.parentInstance_GUID = SupportType.WFIns.parentInstance_GUID
    and dftype.instanceDF_GUID = SupportType.WFIns.instanceDF_GUID
    left outer join YMRR_DF_ReqForm_PartcpType as prtcptyp
    on dftype.parentInstance_GUID = prtcptyp.WFIns.parentInstance_GUID
    and dftype.instanceDF_GUID = prtcptyp.WFIns.instanceDF_GUID
     left outer join YMRR_DF_ReqForm_Language as languages
    on dftype.parentInstance_GUID = languages.WFIns.parentInstance_GUID
    and dftype.instanceDF_GUID = languages.WFIns.instanceDF_GUID
     left outer join YMRR_DF_ReqForm_InvSAP_Party as involved_SAP_Parties
    on dftype.parentInstance_GUID = involved_SAP_Parties.WFIns.parentInstance_GUID
    and dftype.instanceDF_GUID = involved_SAP_Parties.WFIns.instanceDF_GUID
    
{
    key dftype.instanceDF_GUID,
    key dftype.parentInstance_GUID,

    // Concatenate supportTypeID with ';' separator
    (select string_agg(supportTypeID, '; ') as SupportTypeIDs
     from YMRR_DF_ReqForm_SupportType
     where  WFIns.instanceDF_GUID = dftype.instanceDF_GUID
       and WFIns.parentInstance_GUID = dftype.parentInstance_GUID) as SupportTypeIDs : String(255),

    // Concatenate participantTypeID with ';' separator
    (select string_agg(participantTypeID, '; ') as ParticipantTypeIDs
     from YMRR_DF_ReqForm_PartcpType
     where WFIns.instanceDF_GUID = dftype.instanceDF_GUID
       and WFIns.parentInstance_GUID = dftype.parentInstance_GUID) as ParticipantTypeIDs : String(255),
    
    // Concatenate languageID with ';' separator
    (select string_agg(languageID, '; ') as languageIDs
     from YMRR_DF_ReqForm_Language
     where WFIns.instanceDF_GUID = dftype.instanceDF_GUID
       and WFIns.parentInstance_GUID = dftype.parentInstance_GUID) as LanguageIDs : String(255),
    
    // Concatenate involved_SAP_PartiesID with ';' separator
    (select string_agg(involved_SAP_PartiesID, '; ') as involved_SAP_PartiesIDs
     from YMRR_DF_ReqForm_InvSAP_Party 
     where WFIns.instanceDF_GUID = dftype.instanceDF_GUID
       and WFIns.parentInstance_GUID = dftype.parentInstance_GUID) as Involved_SAP_PartiesIDs : String(255)

}
where ((SupportType.WFIns.instanceDF_GUID is not null) or (prtcptyp.WFIns.instanceDF_GUID is not null) or 
        (languages.WFIns.instanceDF_GUID is not null) or (involved_SAP_Parties.WFIns.instanceDF_GUID is not null) )
group by dftype.instanceDF_GUID, dftype.parentInstance_GUID;

view YC_dFWfins_Details as select from YMRR_DF_WFIns as WFIns
left outer join YMRR_DF_WFIns_Parent as parent
on WFIns.parentInstance_GUID = parent.parentInstance_GUID
left outer join YI_DF_ReqForm as YI_ReqForm
on  WFIns.parentInstance_GUID = YI_ReqForm.parentInstance_GUID and WFIns.instanceDF_GUID = YI_ReqForm.instanceDF_GUID

{
        WFIns.instanceDF_GUID,
        WFIns.parentInstance_GUID,
        WFIns.tabID,
        WFIns.technicalStateID,
        parent.orgType,
        parent.orgID,
        parent.reqTypeID,
        parent.eng_type_ID,
        WFIns.reqAreaGUID,
        WFIns.create_Date,
        WFIns.create_Time,
        WFIns.change_Date,
        WFIns.change_Time,
        WFIns.decisionID,
        WFIns.role_ID,
        WFIns.bA_LOB_ID,
        WFIns.crossCoverage_ID,
        WFIns.bA_Industry_ID,
        WFIns.group_ID,
        WFIns.need_from_CustAdvisory,
        WFIns.cust_asked_forMeeting,
        WFIns.meetingTypeID,
        WFIns.comments,
        WFIns.solution_Models,
        WFIns.custAdvisory_Resource,
        WFIns.Opp_Number as additionalOpp,
        WFIns.io_Number ,
        WFIns.contact_Prsn_Id,  
        WFIns.contact_Prsn_Email,
        WFIns.need_From_Fbs,
        WFIns.c2c_Deal,
        WFIns.oppclosing_Date,
        WFIns.contract_Start_Date,
        WFIns.contract_End_Date,
        WFIns.supp_Type_FBS,
        WFIns.supp_Type_Pqa_Id,
        WFIns.solution_Id, 
        WFIns.est_Acv,
        WFIns.model_Id,
        WFIns.isp_Id,
        WFIns.opp_Origin_Id,
        YI_ReqForm.SupportTypeIDs,
        YI_ReqForm.LanguageIDs,
        WFIns.Meeting_Goal,
        WFIns.meetingLocation,
        WFIns.meetingDate,
        WFIns.meetingTime,
        WFIns.involved_SAP_Parties_Name,
        YI_ReqForm.Involved_SAP_PartiesIDs, 
        WFIns.Participants_Type_Details,
        YI_ReqForm.ParticipantTypeIDs,
        WFIns.isAttachment 
};
view YC_SORg_PC_Map as
    select from sorg_PC_Map as pc_map
    left outer join resources.Sales_Org as sorg
        on pc_map.sOrg = sorg.ID
    left outer join YMRR_ProfitCenter as pc
        on pc_map.profitCenterGuid = pc.profitCenterGUID
    left outer join ReqArea_API.YMR_M_Engagement as EngType
     on pc_map.eng_type_ID = EngType.eng_type_ID
    {
        pc_map.sOrg              as SOrg,
        pc_map.profitCenterGuid  as ProfitCenterGuid,       
        sorg.Desc                as SOrg_Desc,
        pc.profitCenterDesc      as ProfitCenterDesc,
        pc_map.eng_type_ID as eng_Type_ID,
        EngType.eng_type_Desc as eng_Type_Desc,
        pc_map.sales_office_code as sales_office_code,
        pc_map.isResourceProfile as isResourceProfile,
        pc_map.isPC_Viewable     as isPC_Viewable,
        pc_map.isPC_Selectable   as isPC_Selectable,
        pc_map.isParentNodeEnable as isParentNodeEnable,
        pc_map.isChildNodeEnable as isChildNodeEnable,
        pc_map.default_Flag       as default_Flag

    };

view YI_ResProfile_PC as
    select from YMRR_ResProfile_PC as pc
    left outer join ReqArea_API.V_Parameter as para_table
        on pc.tableTypeID = para_table.ID
    left outer join ReqArea_API.V_Parameter as para_user
        on pc.userTypeID = para_user.ID
    left outer join ReqArea_API.YMR_M_Engagement as EngType
     on pc.eng_type_ID = EngType.eng_type_ID
    {
        pc.profitCenterGUID,
        pc.resProfile_Master_GUID,
        pc.eng_type_ID,
        EngType.eng_type_Desc as Eng_Type_Desc,
        pc.tableTypeID,
        para_table.Value     as TableType,
        pc.userTypeID,
        para_user.Value      as userType,
        pc.userID,
        pc.userName,
        pc.userEmail,
        para_table.Type_ID   as table_Type_ID,
        para_table.Type_desc as table_Type_Desc,
        para_user.Type_ID    as User_Type_ID,
        para_user.Type_desc  as User_Type_Desc
    }
    where
        pc.operationStatus = 'X';
    
view YI_MRR_Resprofile_Master as
    select
        master.res_sel_guid,        
       
        max(case when master.field_id = '0001' then master.field_value end) as RoleID:String(4),
        max(case when master.field_id = '0002' then master.field_value end) as RoleAreaID:String(4),
        max(case when master.field_id = '0003' then master.field_value end) as IndustryID:String(4),
        max(case when master.field_id = '0004' then master.field_value end) as BALobID:String(4),   
        max(case when master.field_id = '0005' then master.field_value end) as BASegID:String(4),
        max(case when master.field_id = '0006' then master.field_value end) as CrossCvrgID:String(25),
        max(case when master.field_id = '0007' then master.field_value end) as ManagerLevel:String(25),
        max(case when master.field_id = '0008' then master.field_value end) as SolutionAreaL1:String(100),
        max(case when master.field_id = '0009' then master.field_value end) as SolutionAreaL2:String(100),         
        max(case when master.field_id = '0010' then master.field_value end) as IacValue:String(4)
    from YMR_M_ResProfile as master
    inner join YMR_M_ResPro_Cfg as field
        on master.field_id = field.field_id
    where
        field.active = 'X'
    group by
        master.res_sel_guid;

view YC_FrontStop_BackStop as
    select from YI_ResProfile_PC as pc
    inner join YI_MRR_Resprofile_Master as master
        on pc.resProfile_Master_GUID = master.res_sel_guid
    left outer join YMRR_ProfitCenter as prof
        on pc.profitCenterGUID = prof.profitCenterGUID
    {
        pc.profitCenterGUID       as ProfitCenterGUID,
        prof.profitCenterDesc     as ProfitCenterDesc,
        pc.resProfile_Master_GUID as ResProfile_Master_GUID,
        pc.eng_type_ID            as Eng_Type_ID,
        pc.Eng_Type_Desc            as Eng_Type_Desc,
        pc.tableTypeID            as TableTypeID,
        pc.TableType              as TableType,
        pc.userTypeID             as UserTypeID,
        pc.userType               as UserType,
        pc.userID                 as UserID,
        pc.userName               as UserName,
        pc.userEmail              as UserEmail,
        master.ManagerLevel       as Manager_Level,
        master.RoleID             as Role_ID,
        master.RoleAreaID         as RoleArea_ID,
        master.IndustryID         as BA_Industry_ID,
        master.BALobID            as BA_Lob_ID,
        master.CrossCvrgID        as Cross_CVRG_ID,
        master.BASegID            as BA_Seg_ID,       
        master.SolutionAreaL1     as SolAreaL1ID,
        master.SolutionAreaL2     as SolAreaL2ID,
        master.IacValue    as IacValue,
       
    };

    view YC_ReqArea_ResProfile_Map as
    select from YMRR_ReqArea_ResPro_Map as ReqArea_ResMap
    inner join ReqArea_API.V_RequestArea as reqArea
        on ReqArea_ResMap.reqArea_GUID = reqArea.GUID
    left outer join YMRR_ProfitCenter as pc
        on ReqArea_ResMap.profitCenterGUID = pc.profitCenterGUID
    {
        ReqArea_ResMap.reqArea_GUID as ReqArea_GUID,
        ReqArea_ResMap.profitCenterGUID,
        reqArea.orgID,
        reqArea.orgName,
        reqArea.orgType,
        reqArea.Request_Area,
        pc.profitCenterID,
        pc.profitCenterDesc,
        ReqArea_ResMap.role_ID,
        ReqArea_ResMap.roleArea_ID,
        ReqArea_ResMap.bA_Seg_ID,
        ReqArea_ResMap.bA_Lob_ID,
        ReqArea_ResMap.cross_CVRG_ID,
        ReqArea_ResMap.bA_Industry_ID
    };