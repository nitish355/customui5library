namespace app.ReqArea_API;

type longstring : String(1000);
type string_4   : String(4);
type string_100 : String(100);
type string_10  : String(10);
type flag       : String(1);
type string_64  : String(64);

using app.resources from '../db/resources';
using app.ORE_API from '../db/ORE_API';
using app.wf from '../db/wf';

// Start of Code for ENTITY
entity ReqArea {
    key ID        : string_4;
        Name      : string_100;
        Is_Active : flag @(title: 'Is Active?');
}

entity ReqArea_Node {
    key Node         : string_10;
        ReqArea_ID_1 : Association to ReqArea;
        ReqArea_ID_2 : Association to ReqArea;
        ReqArea_ID_3 : Association to ReqArea;
        ReqArea_ID_4 : Association to ReqArea;
}

entity ReqArea_Map {
    key GUID      : UUID     @(title: 'GUID');
        //Sales_Org : Association to resources.Sales_Org @(title: 'Sales Org ID');
        //orgID     : string_4 @(title: 'Org ID');
        orgID     : string_64 @(title: 'Org ID');
        orgType   : string_10;
        Node      : Association to ReqArea_Node;
        Is_Active : flag     @(title: 'Is Active?');
}

entity YMRR_MASTER_TYPE {
    key Type_ID            : string_4;
        Value              : string_100;
        Operational_Status : flag;
}

entity YMRR_PARAMETER {
    key ID                 : string_4;
        Type_ID            : string_4;
        Value              : longstring;
        Operational_Status : flag;
}

entity YMRR_RejCodes {
    key RejID              : string_4;
        Type_ID            : string_4;
        //orgID              : string_4;
        orgID              : string_64;
        orgType            : string_10;
        orgID_L            : String(9);
        Rej_Reason         : String(100);
        Operational_Status : flag;
}

entity YMRR_CurrentState {
    key ID                 : String(6);
        Type_ID            : string_4;
        Value              : String(100);
        taskOwnerRole      : String(200);
        Operational_Status : flag;
}

entity YMRR_TechnicalState {
    key ID                 : String(4);
        technicalState     : String(20);
        Operational_Status : flag;
}

entity YMRR_WF_Defination {
    key ID                 : String(4);
        wf_Defination      : String(30);
        isActive           : flag;
}

entity YMRR_RequestType {
    key ID                 : String(4);
        requestType        : String(30);
        isActive           : flag;
}

entity YMRR_CurrentStep {
    key ID                 : String(6);
        currentStep              : String(100);
        Operational_Status : flag;
}

entity YMRR_Email_Delegates {
    key ID                 : string_4;
        //orgID              : string_4;
        orgID              : string_64;
        orgType            : string_10;
        orgID_L            : String(9);
        Type_ID            : string_4;
        Value              : String(1000);
        Operational_Status : flag;
}

//Entities for Form Config
entity YMRR_Form_Tab {
    key ID         : String(50);
    //key orgID      : string_4;
    key orgID      : string_64;
    key orgType    : string_10;
        Label      : string_100;
        Visibility : flag;
        Fields     : Association to many YMRR_Form_Config
                         on Fields.Tab = $self;
}

entity YMRR_Form_Config {
    key ID           : String(50);
    key Tab          : Association to YMRR_Form_Tab;
        Label        : longstring;
        Control_Type : string_10;
        Placeholder  : longstring;
        Visibility   : flag;
        Mandatory    : flag;
        Cust_meat    : flag;       
}

entity YMRR_Form_Config_Values {
    key ID                 : string_4;
        Field_ID           : String(50);
        //orgID              : string_4;
        orgID              : string_64;
        orgType            : string_10;
        Value              : String(1000);
        Default_Flag       : flag;
        Operational_Status : flag;
}
entity YMR_M_Form_Tab_Details{
    key tab_Id: string_4;
    tab_Id_UI_Key:String(50);
    tab_Name:string_100;
    Active: flag;
}
entity YMR_M_Form_Tab_Config {
    key tabconfig_Id : string_4;
    tab_Id       : string_4;
    orgID        : string_64;
    orgType      : string_10;
    eng_type_ID  : string_4;
    Active       : flag

}
entity YMR_M_Form_Field_Type{
    key fieldtype_Id :string_4;
    fieldtype_Desc:String(50);
    Active:flag
}
entity YMR_M_Form_Field_Label {
    key field_Label_Id   : string_4;
        field_Label_UI_Key: String(50);
        field_Label_Name : string_100;
        fieldtype_Id     : string_4;
        Placeholder  : longstring;
        Active   : flag;       
}

entity YMR_M_Form_Field_LabelValues{
    key field_Label_Value_Id : string_10;
    field_Label_Id       : string_4;
    value_Id             : string_4;
    value                : string_100;
    is_Default           : flag;
    Active               : flag;
}
entity YMR_M_Form_Tab_LabelValues_Config {
    key tabconfig_Id         : string_4;
    key field_Label_Value_Id : string_10;
    key role_ID :String(4);
    key reqTypeID       : String(4);
    mandatory    : flag;
    cust_meat    : flag;
    Active       : flag;
}
// End of Form Config Entities

entity YMRR_Presales_Roles {
    key ID            : string_4;
        role_ID       : String(4);
        role_Area_ID  : String(4);
        manager_level : String(150);
        BA_ID         : String(4);
        CRM_Role_ID   : String(10);
        CRM_Role_Desc : String(150);
        operational_Status : flag;
}
entity YMR_M_From_ActionLabel{
    key Action_ID  : String(4);
    Action_key_UI: String(50);
    Label      : String(100);
    Label_Desc : String(100);
    Action_Message : String(150);
    Active     : flag;
}

entity YMRR_Action {
    key ID : string_4;
    UserTaskID   : String(50);
    eng_type_ID   : string_4;
    orgID      : string_64;
    orgType    : string_10;
    Action_ID  : String(50);
    commentId : String(4);
    Active : flag;
}
 
//Entity for Workflow Path based on Sales Org
entity YMRR_WF_Routing {
    key id                : string_4;
        eng_type_ID       : string_4;
        orgID             : string_64;
        orgType           : string_10;
        orgID_L           : String(9);
        routing           : String(24);
        operationalStatus : flag;
}

//Entity for Approver Reminder Email based on ORG ID and Dynamic Hours
entity YMRR_RemindMail {
    key ID                 : string_4;
        eng_type_ID        : string_4;
        orgID              : string_64;
        orgType            : string_4;
        remindAfter        : Integer;  //Hours 
        isActive           : flag;
}


entity YMRR_ioStaffExcep {
    key bukrs             : string_4;
    // key kostl             : String(10);
    // key usrId             : String(30);
    key eng_type_ID     : string_4;
    key sorg             : string_4;
        zflag             : flag;
        actExp            : flag;       

}
entity YMR_M_Engagement {
    key eng_type_ID   : string_4;
        eng_type_Desc : String(50);
        is_default    : String(1);
        active        : flag;
}
entity YMR_M_Group{
    key group_ID   : string_4;
        group_Desc : String(250);        
        active        : flag;
}

entity YMRR_internalOrder   {
key internalOrder : String(12);
    io_Owner : String(20);

}

// End of Code for ENTITY

entity YMRR_UserTask {
    key userTaskID          : String(4);
        stateID             : String(6);
        userTask            : String(100);
        userTaskName        : String(100);
        isActive            : flag;
}

entity YMRR_App_Tab {
    key tab_ID    : String(4);
        tab_Name  : String(50);
        tabLabel_Desc : String(50);
        is_active : String(1);
}

entity YMRR_Language {
    key language_ID   : String(4);
        language_Desc : String(50);
        operational_Status      : String(1);

}

entity YMRR_Language_PCMap {
    key language_ID        : String(4);
    key orgID              : String(64);
    key orgType            : String(10);
        default_Flag       : String(1);
        operational_Status : String(1);

}
entity YMRR_AppLabel_Type{
    key typeID   : String(4);
        typeDesc : String(200);
        isActive : String(1);

}
entity YMRR_AppLabel_Field {
    key id   : String(4);
        fieldID   : String(100);
        fieldDesc : String(5000);
        defaultFilter : String(1);
        defaultColumn : String(1);
        mandatory : String(1);
        isActive  : String(1);
}

entity YMRR_AppLabel_Map {
    key mapID    : String(4);
    key typeID   : String(4);
    key id       : String(4);
        isActive : String(1);

}
entity YMR_M_SOL_TXNMY {
    key PROJECT_TYPE   : String(10);
    key SOLN_GUID      : UUID;
        SOLN_ID        : String(40);
        SOLN_NAME      : String(150);
        SOLN_PRNT_GUID : UUID;
        ACTIVE         : flag;
        IS_FINAL       : flag;
}

entity YMR_M_SOL_MATERL {
    key MAT_ID     : String(40);
    MAT_DESC   : String(255);
    MAT_STATUS : String(10);
}
entity YMR_T_CRM_Req_Dtls {
    key propertyName : String(50);
        sequence         : Integer;
}

// Start of Code for VIEW

view YC_MRLangauage as
    select from YMRR_Language_PCMap as PCMap
    inner join YMRR_Language as lang
        on PCMap.language_ID = lang.language_ID
    left outer join resources.Sales_Org as SalesOrg
        on PCMap.orgID = SalesOrg.ID
    left outer join ORE_API.YMRR_ProfitCenter as profitCenter
        on PCMap.orgID = profitCenter.profitCenterGUID
    {
        PCMap.language_ID as ID,
        lang.language_Desc as Value,
        PCMap.orgID,
        case
            when
                PCMap.orgType = 'SORG'
            then
                SalesOrg.Desc
            when
                PCMap.orgType = 'PC'
            then
                profitCenter.profitCenterDesc
            else
                null
        end as Org_Desc : String(100),
        PCMap.orgType,
        PCMap.default_Flag as Default_Flag,
        PCMap.operational_Status as Operational_Status
    }
    where
        PCMap.operational_Status = 'X';

view V_SalesOrg as
    select from resources.YMR_M_Harmony_Routing as HarmonyRouting
    left outer join resources.Sales_Org as sorg on HarmonyRouting.sales_org_ID = sorg.ID
    left outer join ReqArea_API.YMR_M_Engagement as EngType on HarmonyRouting.eng_type_ID = EngType.eng_type_ID
    left outer join resources.YMRR_SORG_CompCode_Map as CompCodeMap
        on sorg.ID = CompCodeMap.salesOrg
    {
        'SORG' || '-' || LPAD(
            sorg.ID, 4, '0'
        )                            as Parent_SorgID   : String(9),
        sorg.Desc                    as Sales_org_name, // @(title: 'Sales Org Name'),
        'SORG' || '-' || LPAD(
            sorg.ID, 4, '0'
        )                            as Sales_org_ID  : String(9),
        HarmonyRouting.eng_type_ID as EngagementType,
        HarmonyRouting.sales_office,
        HarmonyRouting.sales_group,
        EngType.eng_type_Desc as EngagementDesc,
        CompCodeMap.company_Code     as company_Code  : String(9),
        CompCodeMap.company_CodeDesc as company_CodeDesc,
        HarmonyRouting.is_active @(title: 'Is Active?')
    };

view V_RequestArea as
    select from ReqArea_Map as map
    left outer join resources.Sales_Org as sOrg
        on  map.orgID   = sOrg.ID
        and map.orgType = 'SORG'
    left outer join resources.YMRR_MarketUnit as mu
        on  map.orgID   = mu.id
        and map.orgType = 'MUID'
    {
        map.GUID                                 @(title: 'GUID'),
        map.orgID ,
        map.orgType,
        case
            when
                map.orgType = 'SORG'
            then
                'SORG' || '-' || LPAD( sOrg.ID, 4, '0' )
            when
                map.orgType = 'MUID'
            then
                 'MUID' || '-' || LPAD( mu.id, 4, '0' )
        end as orgID_L  : String(9),
        case
            when
                map.orgType = 'SORG'
            then
                sOrg.Desc
            when
                map.orgType = 'MUID'
            then
                mu.desc
        end as orgName  : String(100) @(title: 'Org Name'),
        map.Node.ReqArea_ID_1.Name as Ra1            @(title: 'Request Area 1'),
        map.Node.ReqArea_ID_2.Name as Ra2            @(title: 'Request Area 2'),
        map.Node.ReqArea_ID_3.Name as Ra3            @(title: 'Request Area 3'),
        map.Node.ReqArea_ID_4.Name as Ra4            @(title: 'Request Area 4'),
        case
            when
                map.Node.ReqArea_ID_4.Name     is not null
                and map.Node.ReqArea_ID_3.Name is not null
                and map.Node.ReqArea_ID_2.Name is not null
            then
                concat(
                    concat(
                        concat(
                            map.Node.ReqArea_ID_1.Name, concat(
                                '-', map.Node.ReqArea_ID_2.Name
                            )
                        ), concat(
                            '-', map.Node.ReqArea_ID_3.Name
                        )
                    ), concat(
                        '-', map.Node.ReqArea_ID_4.Name
                    )
                )
            when
                map.Node.ReqArea_ID_4.Name     is     null
                and map.Node.ReqArea_ID_3.Name is not null
                and map.Node.ReqArea_ID_2.Name is not null
            then
                concat(
                    concat(
                        map.Node.ReqArea_ID_1.Name, concat(
                            '-', map.Node.ReqArea_ID_2.Name
                        )
                    ), concat(
                        '-', map.Node.ReqArea_ID_3.Name
                    )
                )
            when
                map.Node.ReqArea_ID_4.Name     is     null
                and map.Node.ReqArea_ID_3.Name is     null
                and map.Node.ReqArea_ID_2.Name is not null
            then
                concat(
                    map.Node.ReqArea_ID_1.Name, concat(
                        '-', map.Node.ReqArea_ID_2.Name
                    )
                )
            when
                map.Node.ReqArea_ID_2.Name is null
            then
                map.Node.ReqArea_ID_1.Name
        end                    as Request_Area : string_100,
        map.Is_Active
    }
    where
        map.Is_Active = 'X';

view V_Parameter as
    select from ReqArea_API.YMRR_PARAMETER
    join YMRR_MASTER_TYPE
        on YMRR_PARAMETER.Type_ID = YMRR_MASTER_TYPE.Type_ID
    {
        YMRR_PARAMETER.ID,
        YMRR_PARAMETER.Type_ID,
        YMRR_MASTER_TYPE.Value as Type_desc,
        YMRR_PARAMETER.Value,
        YMRR_PARAMETER.Operational_Status
    };

view V_RejectionCode as
    select from ReqArea_API.YMRR_RejCodes as Rej
    join YMRR_MASTER_TYPE as MasterType
        on Rej.Type_ID = MasterType.Type_ID
    {
        Rej.RejID              as RejID,
        Rej.Type_ID            as UserTask_ID,
        MasterType.Value       as UserTask_Desc,
        Rej.orgID              as OrgID,
        Rej.orgType            as OrgType,
        Rej.orgID_L            as OrgID_L,
        Rej.Rej_Reason         as Rejection_Reason,
        Rej.Operational_Status as Rejection_Op_Status
    }
    where Rej.Operational_Status='X';

view V_CurrentState as
    select from ReqArea_API.YMRR_CurrentState as CurrSt
    join YMRR_MASTER_TYPE as MasterType
        on CurrSt.Type_ID = MasterType.Type_ID
    {
        CurrSt.ID                 as ID,
        CurrSt.Type_ID            as Type_ID,
        MasterType.Value          as Type_ID_Desc,
        CurrSt.Value              as Current_State,
        CurrSt.taskOwnerRole      as Task_Owner_Role,
        case 
        when CurrSt.ID      =  'REQREJ' or 
            CurrSt.ID      =  'REQCOM'or 
            CurrSt.ID      =  'REQTER'
        then 
            'complete'
            else
            'inProcess' 
            end as Technical_state : String(50),
        CurrSt.Operational_Status as CurrentState_OpStatus
    };

view V_Email_Delegates as
    select from ReqArea_API.YMRR_Email_Delegates as email
    join YMRR_MASTER_TYPE as MasterType
        on email.Type_ID = MasterType.Type_ID
    {
        email.ID                 as ID,
        email.orgID              as orgID,
        email.orgType            as orgType,
        email.orgID_L            as orgID_L,
        email.Type_ID            as Type_ID,
        MasterType.Value         as Type_ID_Desc,
        email.Value              as Email_Delegates,
        email.Operational_Status as Email_OpStatus

    };

view V_Presales_Roles as
    select from YMRR_Presales_Roles {
        ID,
        role_ID,
        role_Area_ID,
        manager_level,
        BA_ID,
        CRM_Role_ID,
        CRM_Role_Desc,
        operational_Status
    }
    where
        operational_Status = 'X';

//View for Workflow Routing
view V_WF_Routing as
    select from YMRR_WF_Routing {
        id,
        eng_type_ID as eng_Type_ID,
        orgID,
        orgType,
        orgID_L,
        routing,
        operationalStatus
    };
    

view V_RemindMail as
    select from YMRR_RemindMail {
        ID          as ID,
        eng_type_ID  as eng_Type_ID,
        orgID       as OrgID,
        orgType     as OrgType,
        remindAfter as RemindAfter
    }
    where
        isActive = 'X';

view YC_AppLabel_Map as
    select from ReqArea_API.YMRR_AppLabel_Map as label_map
    join YMRR_AppLabel_Type as label_type
        on label_map.typeID = label_type.typeID
    join YMRR_AppLabel_Field as label_field
        on label_map.id = label_field.id
    {
        label_map.mapID,
        label_map.typeID,
        label_type.typeDesc,       
        label_map.id,
        label_field.fieldID,
        label_field.fieldDesc,
        label_field.defaultFilter,
        label_field.defaultColumn,
        label_field.mandatory,
        label_map.isActive
    };

view YC_MR_M_ACTION  as
    select from YMRR_Action as Action
    left outer join YMR_M_From_ActionLabel as Action_label
        on Action.Action_ID = Action_label.Action_ID
     left outer join resources.Sales_Org as sOrg
        on  Action.orgID   = sOrg.ID
        and Action.orgType = 'SORG'    
    left outer join ORE_API.YMRR_ProfitCenter as pc
        on Action.orgID  = pc.profitCenterGUID
        and Action.orgType = 'PC' 
    left outer join YMR_M_Engagement as EngType 
    on EngType.eng_type_ID = Action.eng_type_ID
    {
        Action.ID,
        Action.UserTaskID  as UserTask,
        Action.eng_type_ID as eng_Type_ID,
        EngType.eng_type_Desc as Eng_Type_Desc,
        Action.orgType     as orgType,
        Action.orgID       as orgID,
        case
            when
                Action.orgType = 'SORG'
            then
                sOrg.Desc            
            when
                Action.orgType  = 'PC'
            then
                pc.profitCenterDesc
        end                            as orgDesc : String(100),         
        Action.Action_ID   as Action,
        Action_label.Action_key_UI as Action_ID,
        Action_label.Label       as Label,
        Action_label.Label_Desc  as Label_Desc,
        Action_label.Action_Message,
        Action.Active  as Visibility,
        Action_label.Active      as Active
    };
view YC_MR_R_ACTION  as
    select from  YC_MR_M_ACTION    
    {
        ID,
        UserTask,
        eng_Type_ID,
        Eng_Type_Desc,
        orgID,
        orgDesc,
        orgType,
        Action,
        Action_ID,
        Label,
        Label_Desc,
        Visibility,
        Active
    };

view YC_MR_M_Form_Tab as
    select from YMR_M_Form_Tab_Config as tab_config
    left outer join YMR_M_Form_Tab_Details as form_tab
        on tab_config.tab_Id = form_tab.tab_Id
    left outer join ReqArea_API.YMR_M_Engagement as EngType
        on tab_config.eng_type_ID = EngType.eng_type_ID
    {
        key tab_config.tabconfig_Id,
        tab_config.tab_Id      as tab_ID,
        form_tab.tab_Id_UI_Key as ID,
        tab_config.eng_type_ID as eng_Type_ID,
        tab_config.orgID,
        tab_config.orgType,
        form_tab.tab_Name      as Label,
        tab_config.Active      as Visibility,
        Fields : Association to many YC_MR_M_Form_Config
                              on Fields.Tab = tabconfig_Id
    };

view YI_Form_tab_values as
    select from YMR_M_Form_Tab_LabelValues_Config as tab_label_val
    left outer join YMR_M_Form_Field_LabelValues as label_val
        on tab_label_val.field_Label_Value_Id = label_val.field_Label_Value_Id
    left outer join YMR_M_Form_Field_Label as field_label
        on label_val.field_Label_Id = field_label.field_Label_Id
    left outer join YMR_M_Form_Field_Type as field_type
        on field_label.fieldtype_Id = field_type.fieldtype_Id
    left outer join YMR_M_Form_Tab_Config as tab_config
        on tab_label_val.tabconfig_Id = tab_config.tabconfig_Id
    left outer join YMR_M_Form_Tab_Details as tab
        on tab_config.tab_Id = tab.tab_Id
    {
        tab_label_val.tabconfig_Id,
        tab_label_val.field_Label_Value_Id,
        tab_config.orgID,
        tab_config.orgType,
        tab_config.eng_type_ID,
        tab_config.tab_Id         as Tab_ID,
        label_val.field_Label_Id  as ID,
        field_label.field_Label_Name,
        tab_label_val.role_ID as Role_ID,
        tab_label_val.reqTypeID as reqTypeID,
        label_val.value_Id        as Field_ID,
        label_val.value,
        field_label.fieldtype_Id,
        field_type.fieldtype_Desc as Control_Type,
        field_label.Placeholder,
        field_label.Active        as Visibility,
        label_val.is_Default,
        label_val.Active          as field_active,
        tab_label_val.mandatory,
        tab_label_val.cust_meat,
        tab_label_val.Active      as tab_active,
    };

view YI_Field_label as
 select from YMR_M_Form_Field_LabelValues as field_label_val
{
    key field_label_val.field_Label_Id,
    min( field_label_val.field_Label_Value_Id ) as field_Label_Value_Id
    }    
group by field_label_val.field_Label_Id;

view YC_MR_M_Form_Config as
    select from YC_MR_M_Form_Tab as tab_details
    left outer join YMR_M_Form_Tab_LabelValues_Config as tab_label_val on tab_details.tabconfig_Id = tab_label_val.tabconfig_Id
    inner join YI_Field_label as field_val
        on tab_label_val.field_Label_Value_Id = field_val.field_Label_Value_Id
    left outer join YMR_M_Form_Field_Label as field_label
        on field_val.field_Label_Id = field_label.field_Label_Id    
    left outer join YMR_M_Form_Field_Type as field_type
        on field_label.fieldtype_Id = field_type.fieldtype_Id
    {
         key   tab_details.tabconfig_Id       as Tab,
        field_label.field_Label_UI_Key as ID,
        field_label.field_Label_Id     as field_Label_ID,    
        tab_details.ID                 as Tab_ID,
        tab_details.eng_Type_ID,
        tab_details.orgID              as Tab_orgID,
        tab_details.orgType            as Tab_orgType,
        field_label.field_Label_Name   as Label,
        field_type.fieldtype_Desc      as Control_Type,
        field_label.Placeholder,
        field_label.Active            as Visibility,
        tab_label_val.mandatory,
        tab_label_val.cust_meat
    };
   

view YC_MR_M_FRM_CONFIG_VAL as
    select from YMR_M_Form_Field_Label as field_label
    left outer join YI_Form_tab_values as tab_values
        on field_label.field_Label_Id = tab_values.ID
    left outer join resources.Sales_Org as sOrg
        on  tab_values.orgID   = sOrg.ID
        and tab_values.orgType = 'SORG'    
    left outer join ORE_API.YMRR_ProfitCenter as pc
        on tab_values.orgID  = pc.profitCenterGUID
        and tab_values.orgType = 'PC'    
    left outer join YMRR_RequestType as ReqType 
    on ReqType.ID = tab_values.reqTypeID
    left outer join YMR_M_Engagement as EngType 
    on EngType.eng_type_ID = tab_values.eng_type_ID
    {
        tab_values.Field_ID            as ID,
        field_label.field_Label_Id     as field_Label_ID,
        field_label.field_Label_UI_Key as Field_ID,
        field_label.field_Label_Name as Field_Name,
        tab_values.eng_type_ID as eng_Type_ID,
        EngType.eng_type_Desc as Eng_Type_Desc,
        tab_values.Role_ID as Role_ID,
        tab_values.reqTypeID as reqTypeID,
        ReqType.requestType as reqType,
        tab_values.orgID,   
        tab_values.orgType,     
        case
            when
                tab_values.orgType = 'SORG'
            then
                sOrg.Desc            
            when
                tab_values.orgType  = 'PC'
            then
                pc.profitCenterDesc
        end                            as orgDesc : String(100),        
        tab_values.value               as Value,
        tab_values.is_Default          as Default_Flag,
        tab_values.tab_active        as Operational_Status
    };
view YC_MR_R_FRM_CONFIG_VAL as
    select from wf.YI_MR_M_SuppType

    {
        ID,
        field_Label_ID,
        Field_ID,
        Field_Name,
        eng_Type_ID,
        Eng_Type_Desc,
        reqTypeID,
        reqType,
        orgID,
        orgDesc,
        orgType,
        Value,
        Default_Flag,
        Operational_Status
    };
view YC_MR_Rep_Action  as
    select from YMRR_Action as Action
    left outer join YMR_M_From_ActionLabel as Action_label
        on Action.Action_ID = Action_label.Action_ID
     left outer join resources.Sales_Org as sOrg
        on  Action.orgID   = sOrg.ID
        and Action.orgType = 'SORG'    
    left outer join ORE_API.YMRR_ProfitCenter as pc
        on Action.orgID  = pc.profitCenterGUID
        and Action.orgType = 'PC' 
    left outer join YMR_M_Engagement as EngType 
    on EngType.eng_type_ID = Action.eng_type_ID
    {        
        Action.UserTaskID  as User_Task,        
        EngType.eng_type_Desc as Engagement_Type,
        Action.orgType     as Org_Type,       
        case
            when
                Action.orgType = 'SORG'
            then
                sOrg.Desc            
            when
                Action.orgType  = 'PC'
            then
                pc.profitCenterDesc
        end                            as Org_Type_Name : String(100), 
        Action_label.Label       as Action_Name,
        Action.Active  as Visibility
        
 };
view YC_MR_Rep_RemindMail as
    select from V_RemindMail as remindMail
    left outer join resources.Sales_Org as sOrg
        on  remindMail.OrgID   = sOrg.ID
        and remindMail.OrgType = 'SORG'
    left outer join ORE_API.YMRR_ProfitCenter as pc
        on  remindMail.OrgID   = pc.profitCenterGUID
        and remindMail.OrgType = 'PC'
    left outer join YMR_M_Engagement as EngType
        on EngType.eng_type_ID = remindMail.eng_Type_ID
    {
        EngType.eng_type_Desc  as Engagement_Type,
        remindMail.OrgType    as Org_Type,
        case
            when remindMail.OrgType = 'SORG'
                 then sOrg.Desc
            when remindMail.OrgType = 'PC'
                 then pc.profitCenterDesc
        end                    as Org_Type_Name : String(100),
        remindMail.RemindAfter as Remind_After
    };

view YC_MR_Rep_WF_Routing as
    select from V_WF_Routing as routing
    left outer join resources.Sales_Org as sOrg
        on  routing.orgID   = sOrg.ID
        and routing.orgType = 'SORG'
    left outer join ORE_API.YMRR_ProfitCenter as pc
        on  routing.orgID   = pc.profitCenterGUID
        and routing.orgType = 'PC'
    left outer join YMR_M_Engagement as EngType
        on EngType.eng_type_ID = routing.eng_Type_ID
    {
        EngType.eng_type_Desc     as Engagement_Type,
        routing.orgType           as Org_Type,
        case
            when routing.orgType = 'SORG'
                 then sOrg.Desc
            when routing.orgType = 'PC'
                 then pc.profitCenterDesc
        end                       as Org_Type_Name : String(100),
        routing.routing           as Routing,
        routing.operationalStatus as Active
    };
view YC_MR_Rep_ioStaffExcep as
    select from YMRR_ioStaffExcep as excep
    left outer join resources.Sales_Org as sorg
        on LPAD(sorg.ID, 4, '0') = excep.sorg
    left outer join ReqArea_API.YMR_M_Engagement as EngType
        on EngType.eng_type_ID = excep.eng_type_ID
    left outer join resources.YMRR_SORG_CompCode_Map as CompCodeMap on CompCodeMap.company_Code = excep.bukrs {
        EngType.eng_type_Desc as Engagement_Type,
        excep.bukrs as Company_Code,
        // CompCodeMap.company_CodeDesc as Company_Code_Desc,     
        excep.sorg as Sales_Org_ID,
        // sorg.Desc as Sales_Org_Desc,
        excep.zflag as Active,        
    };