namespace app.resources;
type TLongString: String(1000);
type string_4: String(4);
type string_100 : String(100);
type string_10 : String(10);
type flag : String(1);
type string_64 : String(64);

using app.ReqArea_API from '../db/ReqArea_API';

// Start of Code for ENTITY 
entity Sales_Org {
    key ID           : string_4    @(title : 'Sales Org ID');
        Desc         : string_100  @(title : 'Sales Org Name'); 
        is_active    : flag        @(title : 'Is Active?');   
 };

entity YMR_M_Harmony_Routing {
    key sales_org_ID : string_4;
    key eng_type_ID  : string_4;
    key sales_office : String(20);
        sales_group  : String(20);
        is_active    : flag;
};

entity YMRR_SORG_CompCode_Map {
    key salesOrg         : string_4   @(title: 'Sales Org ID');
    key company_Code     : string_100 @(title: 'Company Code');
        company_CodeDesc : string_100 @(title: 'Company Code Name');
        is_active        : String(1);
};
 entity YMRR_MarketUnit {
    key id           : string_4    @(title : 'Market Unit ID');
        desc         : string_100  @(title : 'Market Unit Name'); 
        is_active    : flag        @(title : 'Is Active?');   
 };

entity Resources {
    key GUID                 : UUID @(title : 'GUID');
       // SalesOrgID           : Association to Sales_Org @(title : 'Sales Org ID') ;
       // orgID                : string_4    @(title : 'Org ID') ;
        //orgType              : string_10;
        RequestArea          : TLongString @(title : 'Request Area');
        Resources            : TLongString @(title : 'Resources');
        Approvers            : TLongString @(title : 'Approvers');
        SubstituteApprovers  : TLongString @(title : 'Substitute Approvers');
}; 

entity Email_Body {
    //key SalesOrgID           : Association to Sales_Org @(title : 'Sales Org ID');
    //key orgID                : string_4;
    key orgID                : string_64;
    key orgType              : string_10;
    key Parameter            : String(100);
        Email_Text           : TLongString @(title : 'Email Text');
};

entity YMR_M_Int_AccSeg {
    key id       : string_4;
        name     : String(150);
        isActive : String(1);
};

entity YMR_M_IACRA_Cfg {
    key field_id    : string_4;
        field_name  : String(50);
        active : String(1);
};
 
entity YMR_M_IAC_ACVMap {
    key iac_acvmap_guid : string_64;
        eng_type_ID     : string_4;
        reqtype_id      : String(3);
        iac_id          : string_4;
        acv_min         : Integer;
        acv_max         : Integer;
};
 
entity  YMR_M_IAC_RAMap {   
  key iac_map_guid    : string_64 ;
  key iac_acvmap_guid : string_64 ;
  key field_id        : string_4 ;
  field_value         : string_100;
};
entity YMR_M_RAMap {
    key roleareamapid : string_4;
    key roleareaid    : string_4;
    key field_id      : string_4;
    key role_id       : string_4;
        active        : String(1);
};
// End of Code for ENTITY 
//Code for View
view Yc_Resources as
    select from Resources as res
    //inner join ReqArea_API.ReqArea_Map as map
    inner join ReqArea_API.V_RequestArea as map
        on res.GUID = map.GUID
    {
       key res.GUID                as GUID,
        map.orgID               as orgID,
        map.orgType             as orgType,
        map.Request_Area        as RequestArea,
        res.Resources           as Resources,
        res.Approvers           as Approvers,
        res.SubstituteApprovers as SubstituteApprovers
    };
 
view YI_MRR_IAC_FieldMapping as
    select
        mapping.iac_map_guid,
        mapping.iac_acvmap_guid,
        max(case when mapping.field_id = '0001' then mapping.field_value end) as RoleAreaID:String(4),
        max(case when mapping.field_id = '0002' then mapping.field_value end) as RoleID:String(4),        
        max(case when mapping.field_id = '0003' then mapping.field_value end) as SolutionAreaL1:String(100),
        max(case when mapping.field_id = '0004' then mapping.field_value end) as SolutionAreaL2:String(100),  
        max(case when mapping.field_id = '0005' then mapping.field_value end) as IndustryID:String(4),      
        max(case when mapping.field_id = '0006' then mapping.field_value end) as RoleAreaSubstitute:String(4),
        max(case when mapping.field_id = '0007' then mapping.field_value end) as RoleSubstitute:String(4),
        max(case when mapping.field_id = '0008' then mapping.field_value end) as rolemap_id:String(4),
        max(case when mapping.field_id = '0009' then mapping.field_value end) as SolnAreaSelectable:String(4),
        max(case when mapping.field_id = '0010' then mapping.field_value end) as SolnAreaMandatory:String(4),
        max(case when mapping.field_id = '0011' then mapping.field_value end) as BAIndustrySelectable:String(4),
        max(case when mapping.field_id = '0012' then mapping.field_value end) as BAIndustryMandatory:String(4),
        max(case when mapping.field_id = '0013' then mapping.field_value end) as MinSelect:String(4),
        max(case when mapping.field_id = '0014' then mapping.field_value end) as MaxSelect:String(4)
        
    from YMR_M_IAC_RAMap as mapping
    inner join YMR_M_IACRA_Cfg as field
        on mapping.field_id = field.field_id
    where field.active = 'X'
    group by mapping.iac_map_guid, mapping.iac_acvmap_guid;  

view YC_MRR_IAC_ACV_FieldMap as
    select from YI_MRR_IAC_FieldMapping as YI_MRR
    inner join YMR_M_IAC_ACVMap as acvmap
        on YI_MRR.iac_acvmap_guid = acvmap.iac_acvmap_guid
    left outer join YMR_M_Int_AccSeg as IAC_type
        on acvmap.iac_id = IAC_type.id
    left outer join ReqArea_API.YMRR_RequestType as reqtype
        on acvmap.reqtype_id = reqtype.ID
    left outer join ReqArea_API.YMR_M_Engagement as EngType
     on acvmap.eng_type_ID = EngType.eng_type_ID
    {
        YI_MRR.iac_map_guid       as IacMapGuid,
        acvmap.eng_type_ID        as eng_Type_ID,
        EngType.eng_type_Desc as eng_Type_Desc,
        reqtype.requestType       as RequestType,
        acvmap.iac_id             as IACID,
        IAC_type.name             as IACDesc,
        acvmap.acv_min            as ACVMIN,
        acvmap.acv_max            as ACVMAX,
        YI_MRR.RoleAreaID         as RoleArea_ID,
        // YI_MRR.RoleID             as Role_ID,
        YI_MRR.rolemap_id         as rolemap_id,
        YI_MRR.SolutionAreaL1     as SolutionAreaL1_ID,
        YI_MRR.SolutionAreaL2     as SolutionAreaL2_ID,
        YI_MRR.IndustryID         as BAIndustry_ID,
        YI_MRR.RoleAreaSubstitute as RoleAreaSubstitute_ID,
        YI_MRR.SolnAreaSelectable     as SolnAreaSelectable,
        YI_MRR.SolnAreaMandatory     as SolnAreaMandatory,
        YI_MRR.BAIndustrySelectable        as BAIndustrySelectable,
        YI_MRR.BAIndustryMandatory as BAIndustryMandatory,
        YI_MRR.MinSelect as MinSelect,
        YI_MRR.MaxSelect as MaxSelect

        // YI_MRR.RoleSubstitute     as RoleSubstitute_ID
    };
