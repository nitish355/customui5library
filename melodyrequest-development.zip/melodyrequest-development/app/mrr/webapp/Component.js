var roleFlag;
sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "com/dealsupport/melodyrequest/model/models",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "com/dealsupport/melodyrequest/control/Common"
],
    function (UIComponent, Device, models, JSONModel , MessageBox, CommonJS) {
        "use strict";
        return UIComponent.extend("com.dealsupport.melodyrequest.Component", {
            common:CommonJS,
            metadata: {
                manifest: "json"
            },

            /**
             * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
             * @public
             * @override
             */
            getContentDensityClass() {
                return Device.support.touch ? "sapUiSizeCompact" : "sapUiSizeCompact";
            },
            init: function () {
                // call the base component's init function
                UIComponent.prototype.init.apply(this, arguments);

                // enable routing
                this.getRouter().initialize();
                  //Call ore masterdata for filter
                CommonJS._callOreMasterData(this,"MASTER_DATA");
                // set the device model
                this.setModel(models.createDeviceModel(), "device");
                this.setModel(models.createFilterUrlModel(), "filterUrl");
                this.setModel(new JSONModel(), "wfInstanceModel");
                this.setModel(new JSONModel(), "currentStateModel");
                //MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
                //set solution area model
                this.setModel(new JSONModel({results:[],aSelectedSolutionAreas:[]}), "SLAMasterDataL1");
                this.setModel(new JSONModel({results:[]}), "SLAMasterDataLevels");
                this.setModel(new JSONModel({solHierarchy:[]}), "SolutionAreaMasterData"); 
                this.getModel("SolutionAreaMasterData").setSizeLimit(99999);           
                 //MR: [GRP02-03] GTM25 Resource Profile alignment #84 end
                this._getUserDetails();
                this._getUserRoleDetails();
                var isComponentScope = true;
                models.getSalesOrgLists(this.fnSalesOrgSuccessCallback, this.fnSalesOrgErrorCallback, this, isComponentScope);
                models.getAppConstants(this.fnSuccessAppConstantsCallback, this,isComponentScope);
                //service call for MRR application related config (MRR Tab)
                models.getMRRAppData(this.fnSuccessMRRAppDataCallback, this,isComponentScope);
                models.getMRREngData(this.fnSuccessMRREngDataCallback, this,isComponentScope);
                // set Create Request Config Visibility Code 
                // Performance Optimization
                //call current state List
                models.getCurrentStateLists(this.fnCurrentStateSuccessCallback,this, isComponentScope);
                // set Create Request Config Visibility Code 
                this.getSalesOrgId(this);
                // this.onCreateOperationalValue(this);
                this.setAppRuntimeBaseURL();
                const oRoleMasterModel = new sap.ui.model.json.JSONModel();
                this.setModel(oRoleMasterModel,"roleMasterData");
                const oManagerLevelMasterModel = new sap.ui.model.json.JSONModel();
                this.setModel(oManagerLevelMasterModel,"managerLevelMasterData");
                const oPFCMasterModel = new sap.ui.model.json.JSONModel();
                this.setModel(oPFCMasterModel,"territoriesPFCMaster");
                models.getManagerLevel(this,isComponentScope);

                const oRoleModelData = new sap.ui.model.json.JSONModel({
                    value:[]
                });
                this.setModel(oRoleModelData, "rolesModel");
                const oSalesOrgMaster = new sap.ui.model.json.JSONModel([]);
                this.setModel(oSalesOrgMaster, "PCSalesOrgMasterData");  
                //get salesOrg Map for legacy or old requests to map with sales org profit center
                models.getSalesOrgProfitCenter(this,isComponentScope);
            },
            fnCurrentStateSuccessCallback: function (oResult, self) {
                //initiate current state model
                self.getModel("currentStateModel").setData(oResult);
                const data = oResult.value; 
                const uniqueObjects = [];
                const seenRoles = new Set();

                data.forEach(item => {
                    if (!seenRoles.has(item.Task_Owner_Role)) {
                        seenRoles.add(item.Task_Owner_Role);
                        uniqueObjects.push(item);
                    }
                });
                self.setModel(new JSONModel(), "uniqueCurrentStateModel");
                self.getModel("uniqueCurrentStateModel").setData(uniqueObjects);
            },
            getSalesOrgId: function (self) {
                const sUserEmail = self.getModel("userDetails").getData().email;
                const userId =  self.getModel("userDetails").getData().user_name;
                const workflowBaseurl = this._getWfServiceRuntimeBaseURL(self);
                jQuery.ajax({
                    url: `${workflowBaseurl}/Employees?$count=true&$filter=(email eq '${sUserEmail}')`,
                    dataType: 'json',
                    async: false,
                    method: "GET",
                    success: function (oData) {
                        const sSalesOrgID = oData.value[0].company.ID;
                        self.getModel("userDetails").getData().salesOrgID = sSalesOrgID;
                        models.getPublicSalesOrg(self, this.getParentSalesOrg , true);
    
                    }.bind(this),
                    error: function (oError) {
                      models.getLSUserDetails(self, userId)
                    }
                });
            },
            getParentSalesOrg: function (response, self) {

                const sSalesOrg = self.getModel("userDetails").getData().salesOrgID;
                let sOrg;
                for (var i = 0; i < response.value.length; i++) {
                    if (response.value[i].company_Code === sSalesOrg) {
                        sOrg = response.value[i].Parent_SorgID;
                    }
                }
                self.getModel("userDetails").getData().salesOrgID = sOrg;

            },
            onCreateOperationalValue: function (self) {
                const sSalesOrg = self.getModel("userDetails").getData().salesOrgID;
                var workflowBaseurl = this._getWfServiceRuntimeBaseURLResource(self);
                jQuery.ajax({
                    url: `${workflowBaseurl}/resources/WF_Routing?$filter=(eng_Type_ID eq '0001' and orgID_L eq '${sSalesOrg}')`,
                    dataType: 'json',
                    async: false,
                    method: "GET",
                    success: function (response) {
                        const data = response.value ;
                        function getOperationalStatus(data, routing) {
                            const obj = data.find(item => item.routing === routing);
                            return obj ? true : false ;
                          }
                          const sAccountOperationalStatus = true;
                          const sOpportunityOperationalStatus = true;
                          
                          self.getModel("userDetails").setProperty("/AccountOperationalStatus" , sAccountOperationalStatus);
                          self.getModel("userDetails").setProperty("/OpportunityOperationalStatus" , sOpportunityOperationalStatus);


                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            // set Create Request Config Visibility Code Ends
            fnSuccessAppConstantsCallback: function (oResult, self) {
                var sValues = oResult.value;
                var oResult = sValues.reduce(function (r, a) {
                    r[a.Type_desc] = r[a.Type_desc] || [];
                    r[a.Type_desc].push(a);
                    return r;
                }, Object.create(null));
                var oModel = new sap.ui.model.json.JSONModel();
                oModel.setData(oResult);
                self.setModel(oModel, "appConstants");
            },
            // set application related config
            fnSuccessMRRAppDataCallback: function (oResponse, self) {
                let sValues = oResponse.value;
                let oResult = sValues.reduce(function (r, a) {
                    r[a.fieldID] = r[a.fieldID] || [];
                    r[a.fieldID].push(a);
                    return r;
                }, Object.create(null));
                let oModel = new sap.ui.model.json.JSONModel();
                oModel.setData(oResult);
                self.setModel(oModel, "mrrAppConfigModel");
                let oTaskBasedResult = sValues.reduce(function (r, b) {
                    r[b.typeDesc] = r[b.typeDesc] || [];
                    r[b.typeDesc].push(b);
                    return r;
                }, Object.create(null));
                // Object.keys(oTaskBasedResult).forEach(key => {
                //     oTaskBasedResult[key] = oTaskBasedResult[key].reduce(function (r, a) {
                //         r[a.fieldID] = r[a.fieldID] || [];
                //         r[a.fieldID].push(a);
                //         return r;
                //     }, Object.create(null));
                // });
                   let oModelMR = new sap.ui.model.json.JSONModel();
                   oModelMR.setData(sValues)
                self.setModel(oModelMR, "MRLabelConfigModel");
            },
            fnSuccessMRREngDataCallback: function (oResponse, self) {
                let aEngagements = oResponse.value || [];
                let aActiveEngagements = aEngagements.filter(e => e.active === 'X');
                const oModel = new sap.ui.model.json.JSONModel({ "engagementList": aActiveEngagements });
                self.setModel(oModel, "mrrAppEngModel");
            },
            fnSalesOrgSuccessCallback: function (oResult, self) {
                var oModel = new sap.ui.model.json.JSONModel();
                oModel.setData(oResult);
                self.setModel(oModel, "salesOrgModel");
            },
            fnSalesOrgErrorCallback: function (oError, self) {
                MessageBox.error(oError.responseText, {
                    contentWidth: "600px"
                });
                sap.ui.core.BusyIndicator.hide();
            } ,
            _getUserRoleDetails: function () {
                var workflowBaseurl = this._getWfServiceRuntimeBaseURLForUserInfo();
                var that = this;
                
                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    url: `${workflowBaseurl}/user-info/userInfo()`,
                    type: "GET",
                    success: function (oData) {
                        var oRoles = oData.value.isRoles;
                        if(oRoles.isMelodyRequestResourceAdmin == false && oRoles.isMelodyRequestResourceApprover == false && oRoles.isMelodyRequestResourceAdminGermany == false && oRoles.isMelodyRequestResourceAdminSwitzerland == false && oRoles.isMelodyRequestResourceAdminAustria == false && oRoles.isMelodyRequestResourceAdminIndia == false && oRoles.isMelodyRequestResourceAdminSpain == false && oRoles.isMelodyRequestResourceAdminTurkiye == false                   
                            && oRoles.isMelodyRequestResourceAdminCR == false && oRoles.isMelodyRequestResourceAdminPoland == false && oRoles.isMelodyRequestResourceAdminHungary == false && oRoles.isMelodyRequestResourceAdminRomania == false && oRoles.isMelodyRequestResourceAdminBulgaria == false && oRoles.isMelodyRequestResourceAdminUkraine == false && oRoles.isMelodyRequestResourceAdminKasachstan == false && oRoles.isMelodyRequestResourceAdminWestBalkans == false && oRoles.isMelodyRequestResourceAdminSlovenia == false && oRoles.isMelodyRequestResourceAdminSlovensko == false && oRoles.isMelodyRequestResourceAdminAzerbaijan == false && oRoles.isMelodyRequestResourceAdminHrvatska == false  && oRoles.isMelodyRequestResourceAreaAdmin == false 
                            && oRoles.isMelodyRequestResourceAdminCsCanada == false && oRoles.isMelodyRequestResourceAdminCsMidwest == false && oRoles.isMelodyRequestResourceAdminCsNortheast == false && oRoles.isMelodyRequestResourceAdminCsRegulated == false && oRoles.isMelodyRequestResourceAdminCsSouth == false && oRoles.isMelodyRequestResourceAdminCsWest == false && oRoles.isMelodyRequestResourceAdminCsNorthAmerica == false){
                               return roleFlag= false;
                           }else{
                               return roleFlag= true;
                           
                           }

                    }.bind(this),
                    error: function (oError) {
                        MessageBox.error("No Authorization", {
                            contentWidth: "600px"
                          });
                          sap.ui.core.BusyIndicator.hide();
                    }
                });
            },           
            _getUserDetails: function () {
                var workflowBaseurl = this._getWfServiceRuntimeBaseURLForUserInfo();
                var that = this;
                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    url: `${workflowBaseurl}/user-info/userInfoUAA()`,
                    type: "GET",
                    success: function (oData) {
                        oData.value.user_name = oData.value.user_name.toUpperCase();
                        var userModel = new JSONModel(oData.value);
                        that.setModel(userModel, "userDetails");
                        var userId = oData["value"]["user_name"];
                        that.fnSetOREViewVisible(userId, userModel);

                    }.bind(this),
                    error: function (oError) {
                        MessageBox.error("No Authorization", {
                            contentWidth: "600px"
                          });
                          sap.ui.core.BusyIndicator.hide();
                    }
                });
            },
            _getWfServiceRuntimeBaseURLForUserInfo: function () {
                return this._getRuntimeBaseURL() + "/adminresources";
            },
            _getRuntimeBaseURL: function () {
                var componentName = this.getManifestEntry("/sap.app/id").replaceAll(".", "/");
                var componentPath = sap.ui.require.toUrl(componentName);
                return componentPath;

            },
            _getWfServiceRuntimeBaseURLResource: function (self) {
                return this._getRuntimeBaseURL(self) + "/cap";
            },
            _getWfServiceRuntimeBaseURL: function (self) {
                return this._getRuntimeBaseURL(self) + "/sapit-employee-data";
            },
            fnSetOREViewVisible: function (userId, userModel) {
                var OREModel = this.getModel("OREModel");
                if (
                  userId === "I056567" ||
                  userId === "C5245240" ||
                  userId === "C5334763" ||
                  userId === "C5202494" ||
                  userId === "C5275953"
                ) {
                  OREModel.setProperty("/ORETabVisible", true);
                } else {
                  OREModel.setProperty("/ORETabVisible", false);
                }
                sap.ui.getCore().setModel(OREModel, "OREModel");
              },
              setAppRuntimeBaseURL: function () {
                let WFInstanceModel = this.getModel("WFInstanceModel");
                let componentName = this.getManifestEntry("/sap.app/id").replaceAll(".", "/");
                let componentPath = sap.ui.require.toUrl(componentName);
                let sWFDestPath = componentPath + "/capSrv";
                let sInboxDestPath = componentPath + "/workflowruntime/rest/v1/workflow-instances";
                WFInstanceModel.setProperty("/sComponentPath", componentPath);
                WFInstanceModel.setProperty("/sWFDestPath", sWFDestPath);
                WFInstanceModel.setProperty("/sInboxDestPath", sInboxDestPath);
                sap.ui.getCore().setModel(WFInstanceModel, "WFInstanceModel");
            }
        });
    }
);