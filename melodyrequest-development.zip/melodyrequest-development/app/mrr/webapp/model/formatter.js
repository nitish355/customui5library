sap.ui.define([
	"sap/ui/core/format/DateFormat"
], function (DateFormat) {
    return {
        formatUrl: function (currentProcessor, loggedInUser, technicalState,CurrentState) {
            var bEnableUrlView = false;
            var aCurrentProcessor = currentProcessor ? currentProcessor.split(",") : "";
            if (CurrentState !== "REQSUB" && CurrentState !== "REESUB") {
                if (technicalState === 'inProcess') {
                    for (var i = 0; i < aCurrentProcessor.length; i++) {
                        if (loggedInUser.toLowerCase() === aCurrentProcessor[i].toLowerCase()) {
                            bEnableUrlView = true;
                        }
                    }
                } else {
                    bEnableUrlView = false;
                }
            }
            return bEnableUrlView;

        },
        formatSubmitPageUrl: function (currentProcessor, loggedInUser, technicalState,CurrentState) {
            var bEnableUrlView = false;
            var aCurrentProcessor = currentProcessor ? currentProcessor.split(",") : "";
            if (CurrentState === "REQSUB" || CurrentState === "REESUB") {
                if (technicalState === 'inProcess') {
                    for (var i = 0; i < aCurrentProcessor.length; i++) {
                        if (loggedInUser.toLowerCase() === aCurrentProcessor[i].toLowerCase()) {
                            bEnableUrlView = true;
                        }
                    }
                } else {
                    bEnableUrlView = false;
                }
            }
            return bEnableUrlView;

        },
        formatSubmitBtn: function (RequestorID, loggedInUser, technicalState,CurrentState) {
            var bEnableUrlView = false;
            if (CurrentState === "REQSUB" || CurrentState === "REESUB") {
                if (technicalState === 'inProcess') {
                    if(RequestorID === loggedInUser){
                        bEnableUrlView = true;
                    }
                } else {
                    bEnableUrlView = false;
                }
            }
            return bEnableUrlView;

        },
        // Create config Button Visibility
        createButtonVisibility: function(bAcc , bOpp){
            return !(bAcc == false && bOpp == false);
        },
        createRadioButtVisibility: function(bVal){
            return bVal;
        },
        // Ends here
        formatCurrenStateText: function (currentProcessor, loggedInUser, technicalState) {
            var bEnableTextView = true;
            var aCurrentProcessor = currentProcessor ? currentProcessor.split(",") : "";
            if (technicalState === 'inProcess') {
                for (var i = 0; i < aCurrentProcessor.length; i++) {
                    if (loggedInUser.toLowerCase() === aCurrentProcessor[i].toLowerCase()) {
                        bEnableTextView = false;
                    }
                }
            } else {
                bEnableTextView = true;
            }
            return bEnableTextView;
        },
        orgFieldTypeLabel: function(salesOrg, profitCenter, orgType) {
            if (orgType === 'SORG') {
                return salesOrg;
            } else if (orgType === 'PC') {
                return profitCenter;
            } else {
                return '';
            }
        },
        formatDate: function (date,time) {
            if (date && time) {
                 const timeStamp = `${date}T${time}Z`
                        localDateTime = new Date(timeStamp),
                        month = localDateTime.toLocaleString('default', { month: 'short' }),
                        day = localDateTime.getDate(),
                        year = localDateTime.getFullYear(),
                        sFinalDate = `${month} ${day}, ${year}`;
                return sFinalDate;
            }
        },
        formatDateExcel: function (date, time) {
            if (date && time) {
                function formatDateExcel(dateStr) {
                    const [year, month, day] = dateStr.split('-');
                    return `${day}/${month}/${year}`;
                }

                const formattedDate = formatDateExcel(date);
                return formattedDate;
            }
        },
        formatTimeZone:function(time,date){
            if (date && time) {
                const timeStamp = `${date}T${time}Z`,
                localDateTime = new Date(timeStamp),
                sTimeZone = localDateTime.toString().match(/([A-Z]+[\+-][0-9]+)/)[1],
                sRegion = localDateTime.toTimeString().match(/\((.*)\)/)[1].split(/\s/).reduce((response,word)=> response+=word.slice(0,1),'');
               return `${sTimeZone} (${sRegion})`
            }
             
        },
        setCountForWfHistory: function (iCount) {
            const aCount = iCount ? iCount : 0
            var resourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            var sTitle = resourceBundle.getText("wfHistoryTitleCount", [aCount]);
            return sTitle;
        },
        setCountForReqArea: function (iCount) {
            var resourceBundle = appView.getOwnerComponent().getModel("i18n").getResourceBundle();
            var sTitle = resourceBundle.getText("reqAreaTitleCount", [iCount]);
            return sTitle;
        },
        setCountForMyRequestes: function (iCount) {
            var resourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            var sTitle = resourceBundle.getText("MyRequestsCount", [iCount]);
            return sTitle;
        },
        getTextForDisplay: function (sText) {
            return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(sText);
        },
        formatTechincalState: function (sTechnicaStatus) {
            if (sTechnicaStatus === "inProcess") {
                return "Warning";
            } else if (sTechnicaStatus === "complete") {
                return "Success";
            }
        },
        contactsListNum: function (sUsers, sCurrentProcessor) {
            var arr = [];
            if (sUsers) {
                if (sUsers.includes(',')) {
                    arr = sUsers.split(",");
                } else {
                    arr = sUsers.split(";");
                }
            }
            return arr.length;
        },
       wfHistorycontactsListNum: function (sUsers, sCurrentProcessor,currentStepId,currentStateID,reqResourceId) {
            var arr = [];
            let sUserList;
            if(!currentStateID || currentStateID === 'WRESAP'){
                sUserList = sUsers ? sUsers : sCurrentProcessor;
            }else if(currentStateID){
                 sUserList = reqResourceId;
            }
            if ((!currentStepId || currentStepId === "MANAPP") || (currentStateID)) {
                if (sUserList) {
                    if (sUserList.includes(',')) {
                        arr = sUserList.split(",");
                    } else {
                        arr = sUserList.split(";");
                    }
                } 
                return arr.length;
            } else  {
                return 1;
            } 
        },
        formatCurrentProcessorIcon: function (sUserEmail) {
            if (sUserEmail) {
                return true;
            } else {
                return false;
            }
        },
        formatCurrentProcessorText: function (sUserEmail) {
            if (sUserEmail) {
                return false;
            } else {
                return true;
            }
        },
        iconDisplay: function (sRequester) {
            if (!sRequester) {
                return "";
            } else {
                return ("sap-icon://personnel-view");
            }
        },
        formatContactIcon: function (sUserData) {
            if (sUserData) {
                return true;
            } else {
                return false;
            }
        },

        currentStatusRename:function (sStatus,sPage) {
            let getCurrentStateById = function (id, aCurrStates) {
				if(aCurrStates){
                for (let i = 0; i < aCurrStates.length; i++) {
                    if (aCurrStates[i].ID === id) {
                        return aCurrStates[i].Current_State;
                    }
                }
                return null;
				}
            };
            const aCurrStates = sPage !== "myInbox" ? this.getView().getModel("currentStateModel").getData().value :
            this.getOwnerComponent().getModel("currentStateModel").getData().value;
            const currentState = getCurrentStateById(sStatus, aCurrStates);

            return currentState;
        },
        currentStatusRenameTitle: function (sStatus,sPage) {
            let getCurrentStateById = function (id, aCurrStates) {
				if(aCurrStates){
                for (let i = 0; i < aCurrStates.length; i++) {
                    if (aCurrStates[i].ID === id) {
                        return `${aCurrStates[i].Current_State}`;
                    }
                }
                return null;
				}
            };
            const aCurrStates = sPage !== "myInbox" ? this.getView().getModel("currentStateModel").getData().value :
            this.getOwnerComponent().getModel("currentStateModel").getData().value;
            const currentState = getCurrentStateById(sStatus, aCurrStates);
            return currentState;
        },
        currentStepRename:function (sStatus) {
            if(sStatus === "Request Submition") {
                return "Request Submission";
            } else if(sStatus === "Request Re-Submition") {
                return "Request Re-Submission";
            }
            return sStatus;
        },

        currentStatusDisplay: function (oValue) {
            switch (oValue) {
                case "WRESAP":
                    return "Warning";
                    break;
                case "WIOAPP":
                        return "Warning";
                        break;     
                case "REQSUB":
                    return "Warning";
                    break;
                case "WMNAPP":
                    return "Warning";
                    break;
                case "WSUBMN":
                    return "Warning"
                    break;
                case "REQFWD":
                    return "Warning";
                    break;
                case "REQREJ":
                    return "Error";
                    break;
                case "REQCOM":
                    return "Success";
                    break;
                case "REQCRT":
                    return "Success";
                    break;
                case "REESUB":
                    return "Warning"
                    break;
                case "REQTER":
                    return "Error";
                    break;
                case "REQSUB":
                    return "Warning"
                    break;
                default:
                    return "None";
                    break;
            }

        },
        //my opprotunities
        formatRevenue: function (sRevenueArgs, sCurrency) {
            const sRevenue = sRevenueArgs ? sRevenueArgs : "0";
            const oCurrFormatter = new sap.ui.model.type.Currency({
                showMeasure: false,
                decimals: 2,
                preserveDecimals: false
            });
            oCurrFormatter.setConstraints({
                maximum: "9999999999999.99",
                minimum: "0"
            });
            const sFormattedRev = oCurrFormatter.formatValue([sRevenue, sCurrency], "string");
            // remove the decimal places if currency it is for Korea or Indonesia
            if (sCurrency === "WON" || sCurrency === "RP" || sCurrency === "JPY") {
                const sRevenueTrunc = sFormattedRev.split(".")[0];
                return sRevenueTrunc;
            }
            return sFormattedRev;
        },
        formatListSize: function (fcllayout, ssize) {
            if (fcllayout === "TwoColumnsBeginExpanded" && ssize < 3500) {
                return true;

            } else if (fcllayout === "OneColumn" && ssize > 1024) {
                return true;
            } else if (fcllayout === "TwoColumnsBeginExpanded") {
                return true;
            }
            return false;
        },
        formatWithValueHelp: function (sValue, that) {
            var that = that ? that : this;
            var aStatus = that.getView().getModel("HarmonyConfig").getData().STATUS;
            var result = aStatus.find(({ KEY }) => KEY === sValue);
            return result.VALUE;
        },
        closeDateText: function (status, constants, dealType, isLean, userInSalesTeam, mainQuote, closedateFlag) {
            //Lean Deals
            var mode = false;
            if (isLean) {
                return !mode || !userInSalesTeam;
            } else if (dealType) { //HDM Deals
                return !mode || !userInSalesTeam || !mainQuote || !closedateFlag;
            }
            //CRM Deals
            return true;
        },
        formatCloseDate: function (dEndDate) {
            if (dEndDate) {
                var num = parseInt(dEndDate.replace(/[^0-9]/g, ""));
                dEndDate = new Date(num);
            }
            let dCloseDate = dEndDate;
            const oFormat = sap.ui.core.format.DateFormat.getDateInstance({
                pattern: "yyyyMMdd",
                UTC: true
            });
            if (dCloseDate) {
                dCloseDate = Number(oFormat.format(dCloseDate));
            }
            let dToday = new Date();
            dToday = Number(oFormat.format(dToday));
            if (dCloseDate < dToday) {
                return "Error";
            }
            return "None";
        },
        getOrigin: function (value, that) {
            var that = that ? that : this;
            var aSource = that.getView().getModel("HarmonyConfig").getData().SOURCE;
            var oKey = aSource.find(({ KEY }) => KEY === value);
            const sOrigin = (oKey) ? oKey.VALUE : "";
            if (sOrigin === "Deal Desk Managed") {
                return "Services Deal Desk Managed";
            }
            return sOrigin;
        },
        setCountForMyDeals: function (iCount) {
            var resourceBundle = this.getView().getModel("i18n").getResourceBundle();
            var sTitle = resourceBundle.getText("myDealsTitleCount", [iCount]);
            return sTitle;
        },
        formatCloseDateText: function (dEndDate) {
            if (dEndDate) {
                var num = parseInt(dEndDate.replace(/[^0-9]/g, "")),
                    date = new Date(num),
                    month = date.toLocaleString('default', { month: 'short' }),
                    day = date.getDate(),
                    year = date.getFullYear(),
                    sFinalDate = `${month} ${day}, ${year}`;
                return sFinalDate;
            }
        },
        formatCreateRequestBtn: function (dispAuth, isLean, sSalesOrgShrt) {
            let isEnableCreateReq = false;
            if (dispAuth) {
                isEnableCreateReq = true;
            }
            return isEnableCreateReq;
        },
        workFlowLength: function (value) {
            if (value > 0) {
                return "Requested (" + value + ")";
            }
            return "Not requested";
        },
        formatRoleName: function (sStepName,sStepID) {
            var sRole;

            switch (sStepName) {
                case (sStepName === "Request Submition" || sStepID === "REQSUB"):
                    sRole = "Requester";
                    break;
                case (sStepName === "Presales Manager Approval" || sStepID === "MANAPP"):
                    sRole = "Presales Manager";
                    break;
                case (sStepName === "Request Re-Submition" || sStepID === "REESUB"):
                    sRole = "Requester";
                    break;
                case  (sStepName === "Presales Resource Approval" || sStepID === "RESAPP"):
                    sRole = "Presales Resource";
                    break;
                default:
                    sRole = sStepName;
                    break;
            }
            return sRole;

        },
        setTimeLineTitle: function (sDecision, sStepName,sStepID,eventType,Role) {
            let sTimelineTitle;
            const resourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            const i18nReSubmittedReq = resourceBundle.getText("reSubmittedReq");
            const i18nSubmittedReq = resourceBundle.getText("submittedReq");
            const i18nApprovedReq = resourceBundle.getText("approvedReq");
            const i18nAcknowledgedReq = resourceBundle.getText("acknowledgedReq");
            const i18nAssignedReq = resourceBundle.getText("assignedReq");
            const i18nRejectedReq = resourceBundle.getText("rejectedReq");
            const i18nSentBackToReq =resourceBundle.getText("sentBackToReq");
            const i18nForwardedReq = resourceBundle.getText("forwardedReq");
            const i18nAssignedRes = resourceBundle.getText("assignedRes");
            const oWfInstanceModel =  this.getView().getModel("wfInstanceModel").getData();
            let sRequestTitle;
            if (eventType !== 'CHAT') {
                if (oWfInstanceModel['RequestType'] === "Account") {
                    sRequestTitle = ` for Account ${oWfInstanceModel['Account_ID']}`
                } else {
                    sRequestTitle = ` for Opportunity ${oWfInstanceModel['OpportunityID']}`
                }

                if (sStepName === "Request Re-Submition" || (sStepID === "REESUB" && sDecision === "Submit Request")) {
                    sTimelineTitle = i18nReSubmittedReq;
                } else {                    
                        switch (sDecision) {
                            case "Submit Request":
                                sTimelineTitle = i18nSubmittedReq + sRequestTitle;
                                break;
                            case "Approve":
                                sTimelineTitle = sStepName.includes("Processor") ? i18nAssignedReq + sRequestTitle : sStepName.includes("Resource") ? i18nAcknowledgedReq + sRequestTitle : i18nApprovedReq + sRequestTitle;
                                break;
                            case "Reject":
                                sTimelineTitle = i18nRejectedReq + sRequestTitle;
                                break;
                            case "Send Back to Requestor":
                                sTimelineTitle = i18nSentBackToReq;
                                break;
                            case "Forwarded":
                                sTimelineTitle = i18nForwardedReq;
                                break;
                            default:
                                sTimelineTitle = sDecision;
                                break;
                        }                    
                }

                if (sTimelineTitle) {
                    return `- ${sTimelineTitle}`;
                }
            } else {
                return `(${Role})`
            }

        },
        setTimeLineIcon: function (sDecision,sEventType) {
            var sIcon;
        if(sEventType !== "CHAT"){
            switch (sDecision) {
                case "Submit Request":
                    sIcon = "sap-icon://request";
                    break;
                case "Approve":
                    sIcon = "sap-icon://task";
                    break;
                case "Reject":
                    sIcon = "sap-icon://employee-rejections";
                    break;
                case "Send Back to Requestor":
                    sIcon = "sap-icon://workflow-tasks";
                    break;
                case "Forwarded":
                    sIcon = "sap-icon://forward";
                    break;
                default:
                    sIcon = "sap-icon://workflow-tasks";
                    break;
            }


            return sIcon;
        }else{
            return "sap-icon://notification-2";
        }

        },
        setTimeLineStatus: function (sDecision) {
            var sStatus;

            switch (sDecision) {
                case "Submit Request":
                    sStatus = "Information";
                    break;
                case "Approve":
                    sStatus = "Success";
                    break;
                case "Reject":
                    sStatus = "Error";
                    break;
                case "Send Back to Requestor":
                    sStatus = "Warning";
                    break;
                case "Forwarded":
                    sStatus = "Information";
                    break;
                default:
                    sStatus = "Information";
                    break;
            }


            return sStatus;

        },
        formatReqArea: function (sReqArea) {
            if (sReqArea) {
                var aReqArea = sReqArea.split(",");
                if (aReqArea.length > 1) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        },
        formatReqAreaText: function (sReqArea) {
            if (sReqArea) {
                var aReqArea = sReqArea.split(",");
                return aReqArea[0];
            }
        },
        hideMessagePage: function (pendingReqCount, MyReqCount) {
            var bShowMsgPage = false;
                if (pendingReqCount === 0) {
                    bShowMsgPage = true;
                }
          
            return bShowMsgPage;
        },
        hideDetailPage: function (pendingReqCount, MyReqCount) {
            var bShowDetailPage = true;
                if (pendingReqCount === 0) {
                    bShowDetailPage = false;
                }
            return bShowDetailPage;
        },
        hideNotFoundPage: function (pendingReqCount, MyReqCount) {
            var bShowDetailPage = false;
                if (pendingReqCount === 0) {
                    bShowDetailPage = true;
                }
            return bShowDetailPage;
        },
        formatDealInfo: function (sReqType, sCurrentState) {
            var bShowDealInfo;
            if (sReqType !== "Account") {
                if (sCurrentState !== "REQSUB" && sCurrentState !== "REQTER" && sCurrentState !== "REQCRT") {
                    bShowDealInfo = true;
                } else {
                    bShowDealInfo = false;
                }
            } else {
                bShowDealInfo = false;
            }
            return bShowDealInfo;
        },
        wfHistoryOppColumn: function (oppID, accID) {
            if (!oppID) {
                return accID;
            } else {
                return oppID;
            }
        },
        formatDetailPageTitle: function (sReqType, sAccountName, sOppDesc, sOppId, sAccId) {
            if (sReqType === "Account") {
                return `${sAccountName} / ${sAccId}`;
            } else if (sReqType === "Opportunity") {
                if (sOppDesc) {
                    return `${sOppDesc} / ${sOppId}`;
                } else {
                    return `Opportunity - ${sOppId}`;
                }
            } else {
                return `Opportunity - ${sOppId}`;
            }

        },
        formatRequesType: function(sReqType , sLob , sIndustry){
            let sPrefix = sReqType === "Opportunity" ? "Opp" : "Account";

            if (sLob && sIndustry) {
                return `${sPrefix} - ${sLob} , ${sIndustry}`;
            } else if (sIndustry) {
                return `${sPrefix} - ${sIndustry}`;
            } else if (sLob) {
                return `${sPrefix} - ${sLob}`;
            }
            
            
        },
        formatTaskHistoryBtn: function (sCurrentState) {
            if (sCurrentState === "REQSUB" || sCurrentState === "REQTER" || sCurrentState === "REQCRT") {
                return false;
            } else {
                return true;
            }
        },
        formatIndusPE: function (sAccType, sName) {
            if (sAccType === "Opportunity") {
                return false;
            } else if (!sName) {
                return false;
            } else {
                return true;
            }
        },
        formatOppAccountUrl: function (sRequestType, sAccount_ID, sHarmonyUrl, sExtSystemsUrl) {
            if (sRequestType === "Account") {
                return `${sHarmonyUrl}Account/${sAccount_ID}`;
            } else {
                return sExtSystemsUrl;
            }

        },
        formatSalesOrgShort: function(sSalesOrgShort){
            var aSalesOrg = this.getView().getModel("publicSalesOrgModel").getData().value;
            var sSalesOrgFilter = aSalesOrg.filter((org) => org.Sales_org_ID === sSalesOrgShort);
            if (sSalesOrgShort !== "" && sSalesOrgFilter.length > 0) {
                return aSalesOrg.filter((org) => org.Sales_org_ID === sSalesOrgShort)[0].Sales_org_name;
            }
        },
        formatOREDates: function (date) {
            if(date){
                var formatDate = date.split("(")[1].split("+")[0];
                formatDate = parseInt(formatDate);
                formatDate = new Date(formatDate);

                var dateFormat = DateFormat.getDateInstance({
                    style: "medium"
                });
                if (formatDate && formatDate !== null && formatDate !== "") {
                    if (typeof date === "string") {
                        formatDate = new Date(formatDate);
                    }
                    return dateFormat.format(formatDate);
                } else {
                    return null;
                }
            } else {
                return null;
            }            
        }, 
        getTreeTerritoryPrimary: function(aValue) {
            if (!aValue || aValue.length === 0) {
              return "";
            }   
        },
        /*Set Role Type text */
        setRoleTypeTextToRoles: function (Desc, RoleTypeGuid) {
            if (!Desc) {
                return "";
            }
            if (Desc && !RoleTypeGuid) {
                return Desc;
            }
            const oRolesModel = this.getView().getModel("roles");
            const aRoleTypes = oRolesModel.getProperty("/RoleTypes");
            const oRoleType = aRoleTypes.find(item => RoleTypeGuid && item.Guid === RoleTypeGuid);
            if (Desc && oRoleType && oRoleType.Desc.toUpperCase() !== "STANDARD") {
                return Desc + " (" + oRoleType.Desc + ")";
            }
            return Desc;
        },
         /*get Role primary */
        getRolePrimary: function (aValue) {
            if (!aValue || aValue.length === 0) {
                return "";
            }

            const oValue = aValue.find(item => item.IsPrimary);
            if (!oValue || oValue.IsNonFocused) {
                return "";

            }
            const oRolesModel = this.getView().getModel("roleMaster");
            const aRoleTypes = oRolesModel.getData();
            const oSelectedRole = aRoleTypes.find(item => item.Guid === oValue.Guid && item.RoleTypeGuid === oValue.RoleTypeGuid);

            if (oSelectedRole && oSelectedRole.ExceptionFlag === true) {
                return oValue.Desc + " (" + oValue.RoleTypeDesc + ")" + " (Primary)";

            }
            return oValue.Desc + " (Primary)";
        },
        getPrimary: function (aValue) {
            if (!aValue || aValue.length === 0) {
                return "";
            }

            const oValue = aValue.find(item => item.IsPrimary);

            if (!oValue || oValue.IsNonFocused) {
                return "";
            }


            return oValue.Desc + " (Primary)";
        },
        setBAIndAndLoBCheckBoxSelection: function (oValue) {
            if (!oValue) {
                return false;
            }
            oValue = oValue.filter(item => item.IsNonFocused === false);
            const aSelectedList = oValue.filter(item => item.IsSelected === true);
            if (oValue.length === aSelectedList.length) {
                return true;
            } else {
                return false;
            }
        },
        setRoleCount: function setRoleCount(sDesc, aRole) {
            if (!aRole) {
              return sDesc + " (" + 0 + ")";
            }
      
            var aSelected = aRole.filter(function (item) {
              return item.IsVisible;
            });
            return sDesc + " (" + aSelected.length + ")";
          },
          getTempHubDesc: function (sGuid) {
			if (!sGuid) {
				return "";
			}
			const oModel = this.getView().getModel("employee");
			const aSelectedHubs = oModel.getProperty("/TempEmployee/TempSelectedHubs");
 
			const oValue = aSelectedHubs.find(item => item.HubGuid === sGuid);
 
			if (!oValue) {
				return "";
			}
 
			let sDesc = "";
			if (oValue.HubDescL1 && oValue.HubDescL1 !== "") {
				sDesc += oValue.HubDescL1;
			}
 
			if (oValue.HubDescL2 && oValue.HubDescL2 !== "") {
				sDesc += " >" + oValue.HubDescL2;
			}
 
			if (oValue.HubDescL3 && oValue.HubDescL3 !== "") {
				sDesc += " >" + oValue.HubDescL3;
			}
			return sDesc;
		},
        formatBALOBText: function formatBALOBText(BALobDesc, BALobClsrDesc) {
            if (BALobClsrDesc == "" || BALobClsrDesc == BALobDesc || BALobDesc == "Non-LoB Focused") {
              BALobDesc = BALobDesc;
            } else {
              BALobDesc = BALobClsrDesc + " > " + BALobDesc;
            }
      
            return BALobDesc;
          },
        /*Set manager visibility */
        setManagerVisibility:function(sManagerLevel){
            if(sManagerLevel === "non-managerial"){
                return true;
            }
            return false;
        },
        /*get Hub description */
        getHubDesc: function getHubDesc(sGuid) {
            if (!sGuid) {
              return "";
            }
      
            var oModel = this.getView().getModel("employee");
            var aSelectedHubs = oModel.getProperty("/TempEmployee/SelectedHubs");
            var oValue = aSelectedHubs.find(function (item) {
              return item.HubGuid === sGuid;
            });
      
            if (!oValue) {
              return "";
            }
      
            var sDesc = "";
      
            if (oValue.HubDescL1 && oValue.HubDescL1 !== "") {
              sDesc += oValue.HubDescL1;
            }
      
            if (oValue.HubDescL2 && oValue.HubDescL2 !== "") {
              sDesc += " >" + oValue.HubDescL2;
            }
      
            if (oValue.HubDescL3 && oValue.HubDescL3 !== "") {
              sDesc += " >" + oValue.HubDescL3;
            }
      
            return sDesc;
          },
          setBaIndustriesText: function (clstDesc, desc, techId) {
            if(desc === "Non-Industry Focused"){
                return desc;
            }else if (techId != "") {
                return clstDesc + " > " + desc + " (" + techId + ")";
            } else {
                return clstDesc + " > " + desc;
            }
        },
        formatCreationTime:function(time,date){
            if (date && time) {
                const timeStamp = `${date}T${time}Z`,
                    localDateTime = new Date(timeStamp),
                    sCreationTime = localDateTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                    sTimeZone = localDateTime.toString().match(/([A-Z]+[\+-][0-9]+)/)[1],
                    sRegion = localDateTime.toTimeString().match(/\((.*)\)/)[1].split(/\s/).reduce((response,word)=> response+=word.slice(0,1),'');
                return `${sCreationTime} - ${sTimeZone} (${sRegion})`
            }

        },
        formatDetCreationTime:function(time,date){
            if (date && time) {
                const timeStamp = `${date}T${time}Z`,
                    localDateTime = new Date(timeStamp),
                    sCreationTime = localDateTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                   
                return `${sCreationTime}`
            }

        },
        formatWfCreationTime: function (time, date) {
            if (date && time) {
                const timeStamp = `${date}T${time}Z`,
                                      localDateTime = new Date(timeStamp),
                                      sCreationTime = localDateTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit'}),
                                      sTimeZone = localDateTime.toString().match(/([A-Z]+[\+-][0-9]+)/)[1],
                                      sRegion = localDateTime.toTimeString().match(/\((.*)\)/)[1].split(/\s/).reduce((response,word)=> response+=word.slice(0,1),'');
                                     return `${sCreationTime} - ${sTimeZone} (${sRegion})`
                           }

        },
        formatFooter: function (EmpRequester_ID, user_name, TechnicalState, currentStateID, CurrentProcessorEmail, email) {
            if (this.formatter.formatTaskHistoryBtn(currentStateID) || this.formatter.formatUrl(CurrentProcessorEmail, email, TechnicalState, currentStateID) ||
            this.formatter.formatSubmitBtn(EmpRequester_ID, user_name, TechnicalState, currentStateID)) {
                return true;
            } else {
                return false;
            }
        },
        formatTimelineDate: function (sDate,si18nTextTD,si18nTextYD) {
            if (sDate) {
                const localDateTime = new Date(sDate),
                    oTDDate = new Date(),
                    sCreationTime = localDateTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                    sTimeZone = localDateTime.toString().match(/([A-Z]+[\+-][0-9]+)/)[1],
                    sRegion = localDateTime.toTimeString().match(/\((.*)\)/)[1].split(/\s/).reduce((response,word)=> response+=word.slice(0,1),''),
                    sFormattedTime = `${sCreationTime} - ${sTimeZone} (${sRegion})`,
                    fnYesterdayDate = (date) => {
                        date.setDate(date.getDate() - 1)
                        return date
                    },
                    oYDDate = fnYesterdayDate(new Date());
                let sFinalDate;
                let sTDdate = oTDDate.toLocaleDateString();
                let sCurrentDate = localDateTime.toLocaleDateString();
                let sYDdate = oYDDate.toLocaleDateString();
                if (sCurrentDate === sTDdate) {
                    sFinalDate = si18nTextTD;
                } else if (sCurrentDate === sYDdate) {
                    sFinalDate = si18nTextYD;
                } else {
                    const month = localDateTime.toLocaleString('default', { month: 'short' }),
                        day = localDateTime.getDate(),
                        year = localDateTime.getFullYear();
                    sFinalDate = `${month} ${day}, ${year}`;
                }
                return `${sFinalDate} at ${sFormattedTime}`
            }
        },
        formatFormDetailsTab:function(sCurrentState){
            if (sCurrentState === "REQCRT" || sCurrentState === "REQSUB") {
                return false;
            } else {
                return true;
            }
        },
        formatWfLogsResourceCount: function(sResourcesId){
            if(sResourcesId){
                let uniqueArray = [...new Set(sResourcesId.split(';'))];
           let count = uniqueArray.length;
           return count;
           }
        },
        formatORETab:function(ORETabVisible,sDowntime){
            if(sDowntime === "X"){
                return false;
            }else{
                return ORETabVisible;
            }
        },
        getForecastText: function (sForecastNumVal) {
            switch (sForecastNumVal) {
                case "1":
                    return "Committed";
                case "2":
                    return "Probable";
                case "3":
                    return "Upside";
                case "4":
                    return "Excluded from Pipeline";
                default:
                    return "Not known";
            }
        },

        getDecisionText: function (sAttrValue) {
            switch (sAttrValue) {
                case "G":
                    return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("GO");
                case "N":
                    return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("NO_GO");
                case "Q":
                    return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("RE_QUALIFY");
                default:
                    return "-";
            }
        },

        /**
		 * Find the State of ObjectStatus as per the attribute value
		 * @function lqColorCode
		 * @public
		 * @param {String} sAttrValue - String which holds attribute value
		 * @return {String} State of ObjectStatus
		 **/
        getQualText: function (sAttrValue, sAttrText) {
            switch (sAttrValue) {
                case "2":
                    return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(sAttrText + "_STRONG");
                case "1":
                    return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(sAttrText + "_MOD");
                case "0":
                    return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(sAttrText + "_WEAK");
                default:
                    return this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/emptyFieldVal/0/fieldDesc");
            }
         
        },
        formatDealText:function(sVal){
            return sVal ? sVal:   this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/emptyFieldVal/0/fieldDesc");
        },
        /**
		 * Find the State of ObjectStatus as per the attribute value
		 * @function lqColorCode
		 * @public
		 * @param {String} sAttrValue - String which holds attribute value
		 * @return {String} State of ObjectStatus
		 **/
        getQualState: function (sAttrValue) {
            if (sAttrValue === "2") {
                return "Success";
            } else if (sAttrValue === "1") {
                return "Warning";
            } else if (sAttrValue === "0") {
                return "Error";
            }
            return "None";
        },
        /**
		 * calculate the score based on selected values
		 * @function getDealScore
		 * @public
		 * @param {array} results
		 **/
        getDealScore: function (results) {
            let iScore = 0;
            if (results) {
                const aScoreJSON = {
                    "0": 0,
                    "1": 6.25,
                    "2": 12.5
                };
                results.forEach(function (val) {
                    if (val.ATTR_VALUE === "0" || val.ATTR_VALUE === "1" || val.ATTR_VALUE === "2") {
                        iScore += aScoreJSON[val.ATTR_VALUE];
                    } else {
                        iScore += aScoreJSON["0"];
                    }
                });
            }
            return iScore;
        },
		/**
		 * get highlight for element based on given score
		 * @function getDealScoreState
		 * @public
		 * @param {array} results
		 **/
        getDealScoreState: function (results) {
            let iScore = 0;
            if (results) {
                const aScoreJSON = {
                    "0": 0,
                    "1": 6.25,
                    "2": 12.5
                };
                results.forEach(function (val) {
                    if (val.ATTR_VALUE === "0" || val.ATTR_VALUE === "1" || val.ATTR_VALUE === "2") {
                        iScore += aScoreJSON[val.ATTR_VALUE];
                    } else {
                        iScore += aScoreJSON["0"];
                    }
                });
            }
            if (iScore === 0) {
                return "None";
            } else if (iScore > 0 && iScore < 37.5) {
                return "Error";
            } else if (iScore >= 37.5 && iScore < 68.5) {
                return "Warning";
            }
            return "Success";
        },
        formatStaffingTab:function(aNominatedResources){
            if (aNominatedResources) {
                let bIsNotIOStaffing = aNominatedResources.every(val => val.isIOStaffing === false);
                let bIsNotAutoStaffing = aNominatedResources.every(val => val.isAutoStaffing !== true);
                if (!bIsNotIOStaffing) {
                    if (bIsNotAutoStaffing) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            } else {
                return false;
            }

        },
        formatTimelineDate: function (sDate,si18nTextTD,si18nTextYD) {
            if (sDate) {
                const localDateTime = new Date(sDate),
                    oTDDate = new Date(),
                    sCreationTime = localDateTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                    sTimeZone = localDateTime.toString().match(/([A-Z]+[\+-][0-9]+)/)[1],
                    sRegion = localDateTime.toTimeString().match(/\((.*)\)/)[1].split(/\s/).reduce((response,word)=> response+=word.slice(0,1),''),
                    sFormattedTime = `${sCreationTime} - ${sTimeZone} (${sRegion})`,
                    fnYesterdayDate = (date) => {
                        date.setDate(date.getDate() - 1)
                        return date
                    },
                    oYDDate = fnYesterdayDate(new Date());
                let sFinalDate;
                let sTDdate = oTDDate.toLocaleDateString();
                let sCurrentDate = localDateTime.toLocaleDateString();
                let sYDdate = oYDDate.toLocaleDateString();
                if (sCurrentDate === sTDdate) {
                    sFinalDate = si18nTextTD;
                } else if (sCurrentDate === sYDdate) {
                    sFinalDate = si18nTextYD;
                } else {
                    const month = localDateTime.toLocaleString('default', { month: 'short' }),
                        day = localDateTime.getDate(),
                        year = localDateTime.getFullYear();
                    sFinalDate = `${month} ${day}, ${year}`;
                }
                return `${sFinalDate} at ${sFormattedTime}`
            }
        },
        setManagerPageTitle:function(sCurrentStateID,sManagerTitle,sSubsApprovalTitle,sResourceTitle){
            switch (sCurrentStateID) {
                case "WRESAP":
                    return sResourceTitle;
                    break;
                case "WMNAPP":
                    return sManagerTitle;
                    break;
                case "WSUBMN":
                    return sSubsApprovalTitle
                    break;
                default:
                    return sManagerTitle;
                    break;
            }

        },
        setCountForOREResources:function(iCount){
            const resourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            const sTitle = iCount ? resourceBundle.getText("oreResourceCount", [iCount]) : resourceBundle.getText("oreResourceCount", [0]);

            return sTitle;
        },
       
        nameFormatter: function(sName){
            function capitalizeFirstLetter(string) {
                return string.toLowerCase().split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
            }
            if(sName){
                return (capitalizeFirstLetter(sName));
            }
            
        },
       
        firstLastNameFormatter: function(sName1 , sName2){
                function capitalizeFirstLetter(string) {
                    return string.toLowerCase().split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
                }
            if(sName1 || sName2){
                let formattedFirstName = capitalizeFirstLetter(sName1);
                let formattedLastName = capitalizeFirstLetter(sName2);
            
                return `${formattedFirstName} ${formattedLastName}`;
            }
                
          
        }
      ,
      formatPCDisplay: function(sProfitCenter){
        if (sProfitCenter) {
            return sProfitCenter.replace(/,/g, "\n");
        }
        return sProfitCenter;
      },
      PendingReqCount: function(sCount){
        if(sCount){
            return sCount;
        }
       
    },
    searchFieldsVisibility: function(sReqArea , sCurrStepID, sLob , sInd){
        if(sLob == null && sInd == null){
            return false;
        }else{
            return !(sReqArea !== null || sCurrStepID == "REQSUB");
        }
   },
    formatUrlNameDisplay: function(sUrlName , sUrl){
        if(sUrlName){
            return sUrlName;
        }else if(sUrl){
            return sUrl;
        }
    },
    iconTabHeaderText: function(sReqArea, sSearchField , isResProfile){
        if(isResProfile){
            return sSearchField;
        }else{
            return sReqArea;
        }
    },
      /**
     * Determines the visibility of the MR tab based on various conditions.
     *
     * @param {string} sTab - The current tab identifier that indicates if the tab is visible.
     * @param {string} sDowntime - Indicates if the system is in downtime (e.g., "X" for downtime).
     * @param {boolean} bAdminRole - Indicates if the user has admin role privileges.
     * @param {string} typeDesc - Indicates if the tab is request area or not.
     * @returns {boolean} - Returns true if the MRR tab should be visible, false otherwise.
     */
      setMRRTabVisibility: function(sTab, sDowntime, bAdminRole,typeDesc) {
        const bTabVisible = sTab ? true:false;
        if(sDowntime === "X"){
            return false;
        }else if(bTabVisible && typeDesc){
            return bAdminRole ? true:false;
        }else {
            return bTabVisible;
        }
    },
        /**
         * Determines the visibility of the MR settings based on various conditions.
         *
         * @param {string} sTab - The current tab identifier that indicates if the tab is visible.
         * @param {string} sAdminRole - Indicates if the user has admin role privileges.
         * @param {string} sDowntime - Indicates if the system is in downtime (e.g., "X" for downtime).
         * @param {string} sSubstitute - Indicates if the substitute processor tab is visible.
         * @param {string} sReqAreaTab - Indicates if request area tab is visible.
         * @returns {boolean} - Returns true if the MR settings should be visible, false otherwise.
         */
        setMRSettingVisibility: function (sTab, sDowntime, sAdminRole, sSubstitute, sReqAreaTab) {
            const bTabVisible = sTab ? true : false; // Determine if the tab is visible based on the sTab parameter.
            if (sDowntime === "X") { // If the system is in downtime, always return false.
                return false;
            } else if ((!sAdminRole || !sReqAreaTab) && !sSubstitute) { // If the user is neither an admin,requestareaTab not enabled nor a substitute tab disables, return false.
                return false;
            } else {
                return bTabVisible; // Otherwise, return the visibility status of the tab.
            }
        },
    currentStatusTechnicalname: function(sStatus){
        return this.getView().getModel("Technicalstate").getData().value.filter(ts => ts.ID == sStatus)[0].technicalState;
    },
    formatReqAreaSalesOrgName: function(sOrgName , sOrgId){
        let sPCName;
        if(sOrgName){
           sPCName= sOrgName;
        }else{
            let PCdata = this.getView().getModel("ProfitCenterListData").getData().value;
            function getProfitCenterDesc(orgID, values) {
                const result = values.find(item => item.profitCenterGUID === orgID);
                sPCName = result ? result.profitCenterDesc :"";
               
            }
            getProfitCenterDesc(sOrgId, PCdata)
        }
        return sPCName;
    },
    formatProcessorComment:function(bTabVisible,sComments,sCurrentStepID){
        if(sCurrentStepID === "MANAPP"){
            return false;
        }else if(bTabVisible && sComments){
            return true;
        }else{
            return false;
        }
    },
    getCurrentPhase: function(sCurrPhase){
        const salesPhase = {
            "ZP1": "F - Recognize",
            "ZP2": "E - Consider",
            "ZP3": "D - Evaluate",
            "ZP4": "C - Select",
            "ZP5": "B - Negotiate",
            "ZP6": "A - Purchase",
            "ZM1": "D - Evaluate",
            "ZM2": "C - Select",
            "ZM3": "B - Negotiate",
            "ZM4": "A - Purchase",
            "ZM5": "E - Consider",
            "ZF1": "F - Recognize (FS)",
            "ZF2": "E - Consider (FS)",
            "ZF3": "D - Evaluate (FS)",
            "ZF4": "C - Select (FS)",
            "ZF5": "B - Negotiate (FS)",
            "ZF6": "A - Purchase (FS)"
        };
       
        function getFormattedText(sCurrPhase) {
            return salesPhase[sCurrPhase] || sCurrPhase;
        }
        return (getFormattedText(sCurrPhase));
       
    },
    getOppState: function(sCurrstate){
        const oppState = {
           	"E0001": "In Process",
			"E0002": "Discontinued",
			"E0003": "Won",
			"E0004": "Booked",
			"E0005": "Lost",
            "E0007" :"New",
			"E0014": "Discontinuation check"
        };
       
        function getFormattedText(sCurrstate) {
            return oppState[sCurrstate] || sCurrstate;
        }
        return (getFormattedText(sCurrstate));
       
    },
    //substitite starts
    formatSubstiTuteData: function (date) {
        if (date) {
          
            let month = date.toLocaleString('default', { month: 'short' }),
                day = date.getDate(),
                year = date.getFullYear();
            return `${month} ${day}, ${year}`;
        }

    },
    // following function returns true if dateValue is in future else false
    _isFutureDate: function (dateValue) {
        let that = this.formatter ? that.formatter : this;
        if (dateValue) {
            if (that._getDiffWithCurrentTime(dateValue) > 0
                && !that._isCurrentDate(dateValue)
            ) {
                return true;
            }
        }
        return false;
    },
    /* following function returns difference in days between the current date and end date if the rule is active.
    else if the rule is in future, it returns the difference between the current date and start date */

    _getActiveDays: function (bInCurrentDateRange, startDate, endDate) {
        let that = this.formatter ? this.formatter : this;
        let timeDiff = that._getDiffWithCurrentTime(bInCurrentDateRange ? endDate : startDate) / (1000 * 60 * 60 * 24);
        if (timeDiff > 1) {
            return Math.floor(timeDiff);
        }
        else if (timeDiff > 0) {
            return Math.ceil(timeDiff);
        }
    },
    _isCurrentDate: function (dateValue) {
        if (dateValue) {
            let oCurrentDate = new Date();
            if ((oCurrentDate.getDate() === dateValue.getDate())
                && (oCurrentDate.getMonth() === dateValue.getMonth())
                && (oCurrentDate.getYear() === dateValue.getYear())
            ) {
                return true;
            }
        }
    },
    _getDiffWithCurrentTime: function (dateValue) {
        if (dateValue) {
            let today = new Date();
            // var formattedDate = parseInt(dateValue.match(/\((\d+)\)/)[1]);
            // let dateNewVal = new Date(dateValue);
            let deadline = new Date(dateValue.getFullYear(), dateValue.getMonth(), dateValue.getDate(), 24, 0, 0);
            let diff = deadline.getTime() - (today.getTime());
            return diff;
        }
    },
    formatterTimeDuration: function (beginDate, endDate, sText) {
        if (endDate == null || endDate == undefined) { // eslint-disable-line eqeqeq
            return sText ? "" : "None";
        }
        let bInCurrentDateRange = !this.formatter._isFutureDate(beginDate);
        let iTotalDays = this.formatter._getActiveDays(bInCurrentDateRange, beginDate, endDate);
        let oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
        if (bInCurrentDateRange) {
            if (iTotalDays === 1) {
                iTotalDays = sText ? oResourceBundle.getText("substn.table.one_day_left") : "Success";
            }
            else if (iTotalDays > 1 && iTotalDays <= 60) {
                iTotalDays = sText ? oResourceBundle.getText("substn.table.days_left", iTotalDays) : "Success";
            }
            else if (iTotalDays > 60 && iTotalDays < 3650) {
                iTotalDays = sText ? oResourceBundle.getText("substn.table.months_left", Math.floor(iTotalDays / 30)) : "Success";
            }
            else if (iTotalDays > 3650) {
                iTotalDays = sText ? oResourceBundle.getText("substn.table.forever_left") : "Success";
            } else {
                return sText ? oResourceBundle.getText("substn.table.completes") : "Error";
            }

            return iTotalDays;
        }
        else {
            if (iTotalDays === 1) {
                iTotalDays = sText ? oResourceBundle.getText("substn.table.starts_in_one_day") : "Warning";
            }
            else if (iTotalDays > 1 && iTotalDays <= 60) {
                iTotalDays = sText ? oResourceBundle.getText("substn.table.starts_in_days", iTotalDays) : "Warning";
            }
            else if (iTotalDays > 60) {
                iTotalDays = sText ? oResourceBundle.getText("substn.table.starts_in_months", Math.floor(iTotalDays / 30)) : "Warning";
            }
            return iTotalDays;
        }

    },

    formatSubstStatusText: function (beginDate) {
        return "Active";
    },
    formatSubstStatus: function (BeginDate) {
        return "Success";

    },
    currentReqMasterStatusRename:function (sStatus, sSubsIDs, sTaskOwnerRole,self) {
        let getCurrentStateById = function (id, aCurrStates) {
            if(aCurrStates){
            for (let i = 0; i < aCurrStates.length; i++) {
                if (aCurrStates[i].ID === id) {
                    return aCurrStates[i].Current_State;
                }
            }
            return null;
            }
        };
        let that = self ? self:this;
        const aCurrStates =  that.getView().getModel("currentStateModel").getData().value;
             let currentState = getCurrentStateById(sStatus, aCurrStates);
            if(sSubsIDs && sStatus === "WMNAPP"){
			const sLoggedInUserId = that.getView().getModel("userDetails").getProperty("/user_name");
			const sSubsState = !sTaskOwnerRole ? aCurrStates.find(item => item.ID === "WSUBMN")?.Current_State:
            aCurrStates.find(item => item.ID === "WSUBMN")?.Task_Owner_Role;
			currentState = sSubsIDs.includes(sLoggedInUserId) ? sSubsState : currentState ;
            }
            return currentState;
    },
    //format account description
    formatCreateReqAccountDesc:function(accountName,accountId){
        if(accountId){
            return `${accountName} - ${accountId}`
        }else{
            return accountName;
        }
    },
    //set resprofile description mid text based on  industry and solution area
    formatResProfileFieldVisibility:function(bIsSoln,bIsIndustry){
        if(bIsSoln || bIsIndustry){
            return true;
        }else{
            return false;
        }
    },
    formatOppSalesOrg:function(OrgID,oppSalesOrg){
        let sNoValMsg = appView.getOwnerComponent().getModel("i18n").getResourceBundle().getText("unavailable");
        if(OrgID){
            let sOppNumber = Number(OrgID.replace('SORG-', '')).toString(),
                sOppSalesOrgDesc = oppSalesOrg ?  `${oppSalesOrg} - ${sOppNumber}`:sOppNumber;
            return sOppSalesOrgDesc;
        }else if(oppSalesOrg){
             return oppSalesOrg;
        }else{
            return sNoValMsg;
        }
    },
        formatAccountSalesOrg: function (OrgID, oppSalesOrg, accountSalesOrg) {
            let sNoValMsg = appView.getOwnerComponent().getModel("i18n").getResourceBundle().getText("unavailable");
            //format account sales org
            if (OrgID && !accountSalesOrg) {
                let sOppNumber = Number(OrgID.replace('SORG-', '')).toString(),
                    sOppSalesOrgDesc = oppSalesOrg ? `${oppSalesOrg} - ${sOppNumber}` : sOppNumber;
                return sOppSalesOrgDesc;
            } else if (oppSalesOrg && !accountSalesOrg) {
                return oppSalesOrg;
            } else {
                return sNoValMsg;
            }
        },
        formatProcessorList: function (processorList,reqApproverList,currentStepId,currentStateID) {
            //sort processor name (tooltip)
            let sProcessorList =  !currentStateID ? processorList : reqApproverList;
            if (sProcessorList) {
                let aProcessorList = sProcessorList.includes(";") ? sProcessorList.split(";") : sProcessorList.split(",");
                aProcessorList.sort((a, b) => {
                    const empNameA = a.toUpperCase(); // ignore upper and lowercase
                    const empNameB = b.toUpperCase(); // ignore upper and lowercase
                    if (empNameA < empNameB) {
                        return -1;
                    }
                    if (empNameA > empNameB) {
                        return 1;
                    }

                    // names must be equal
                    return 0;
                })
                return (!currentStepId || currentStepId === 'MANAPP' || currentStateID) ? aProcessorList.join(","):reqApproverList;
            } else {
                return ""
            }

        },
          /**
		 * format date (Ex: date from  '/Date(1650326400000)/' format to 'Mar 20, 2022')
		 * @function _setDateFormat
		 * @public
		 * @param {object} date - String which holds date value
		 * @return {String} formatted date
		 **/
          _setDateFormat:function(date){
            if(date){
                const oFinalDate = (typeof(date) === 'object') ? date:new Date(parseInt(date.substr(6))),
                    options = {
                        year: 'numeric',
                        month: 'long', // 'long' for full month name (e.g., "July"), 'short' for abbreviated (e.g., "Jul")
                        day: 'numeric'
                    };
				 return oFinalDate.toLocaleDateString('en-US', options)
            }else{
                return ""
            }
        },
        /**Git 132 (Form template changes + add new opp fields)
         * format header sub title
         * @param {string} requestType - Request type (Opportunity or Account)
         * @param {string} accountName - Account name
         * @param {string} oppName - Opportunity name
         */
        formatSubtitle:function(requestType,accountName,oppName){
            if(requestType === 'Opportunity'){
                return `${accountName} - ${oppName}`;
            }else{
                return `${accountName}`;
            }
        },
        /**Git 132 (Form template changes + add new opp fields)
         * format request area visibility
         * @param {string} sVal - Request area
         * @param {boolean} isResourceProfile -Resource profile flag
         */
        formatFormConfigReqAreaVisibility(sVal, isResourceProfile) {
            return sVal === "X" && !(isResourceProfile);
        },
          /**Git 132 (Form template changes + add new opp fields)
         * format 'Rise' field
         * @param {boolean} isRise - rise field flag
         * @param {string} formVisibility - form visibility
         *  @param {string} typeOfSupport - support type
         */
        formatFieldForNonRise: function (isRise, formVisibility,typeOfSupport) {
            if (typeOfSupport && formVisibility === "X") {
                const isRiseVisibility = !isRise;
                return isRiseVisibility;
            } else {
                return false;
            }
        },
          /**Git 132 (Form template changes + add new opp fields)
         * @param {boolean} bVal - form value flag
         * @param {string} formVisibility - form visibility
         *  @param {string} value - form value
         */
        formatFieldBasedOnMultipleProperties: function (bVal, formVisibility,value) {
            if (value && formVisibility === "X") {
                return bVal;
            } else {
                return false;
            }
        },
            /**Git 132 (Form template changes + add new opp fields)
         * format form fields visibility
         * @param {string} sVal - form value flag
         *  @param {string} value - form value
         */
        formatFormConfigVisibility: function (sVal,value) {
            if (value && sVal === "X") {
                return true;
            } else {
                return false;
            }
        },
         /**Git 132 (Form template changes + add new opp fields)
         * format form select field visibility
         * @param {boolean} bVal - form val flag
         * @param {boolean} formVisibility - form visibility
         *  @param {string} isMeetingPlanned - meeting planned value
         */
        formatFieldSelectField: function (bVal, formVisibility, isMeetingPlanned) {
            if (formVisibility && isMeetingPlanned) {
                return bVal;
            } else {
                return false;
            }
        },
             /**Git 132 (Form template changes + add new opp fields)
         * format attachment visibility
         * @param {string} bConfig - form config flag
         * @param {boolean} isAttachment - attachement visibility
         */
           formatAttachmentVisibility: function (bConfig, isAttachment) {
            if (bConfig === "X" && isAttachment) {
                return true;
            } else {
                return false;
            }
        },
          /**Git 132 (Form template changes + add new opp fields)
         *open user profile url
         * @param {object} oEvent - link event details
         */
        onOpenUrl:function(oEvent){
            const oBindingContext = oEvent.getSource().getBindingContext("headerModel").getObject();
            window.open(`${oBindingContext["url"]}`,"_blank");
        },
        /**Git 132 (Form template changes + add new opp fields)
       *format date with OrdinalNumberSuffixes (th,rd,st)
       * @param {string} sDate - link event details
       */
        formatDateWithOrdinalNumberSuffixes:function(sDate){
            if (sDate) {
                const dateObj = new Date(sDate),
                    day = dateObj.getDate(),
                    month = dateObj.toLocaleString("default", { month: "long" }),
                    year = dateObj.getFullYear(),
                    nthNumber = (number) => {
                        if (number > 3 && number < 21) return "th";
                        switch (number % 10) {
                            case 1:
                                return "st";
                            case 2:
                                return "nd";
                            case 3:
                                return "rd";
                            default:
                                return "th";
                        }
                    };
                return `${month} ${day}${nthNumber(day)}, ${year}`;
            }

        },
            /**Git 132 (Form template changes + add new opp fields)
         *format date with OrdinalNumberSuffixes (th,rd,st)
        * @param {string} sId - id of control
        * @param {object} oContextData - binding context
        */
        createProcessorItem: function (sId, oContextData) {
            const iIndex = parseInt(oContextData.getPath().split("/")[oContextData.getPath().split("/").length - 1]),
                oContextObj = oContextData.getObject(),
                that = this;
                //split path
                aPathSplit = oContextData.getPath().split("/"),
                userId = oContextObj["ID"] ? oContextObj["ID"] : oContextObj["userId"];
            //remove late path val
            aPathSplit.pop();
            let aProcessorDisplayText = oContextData.getProperty(aPathSplit.join("/"));
            //control declaration
            let oLinkUserControl = new sap.m.Link({
                text: oContextObj["fullName"],
                href: `https://people.wdf.sap.corp/profiles/${userId}`,
                target: "_blank"
            }),
                oLinkSperatorControl
                    = new sap.m.Link({
                        text: ","
                    }),
                oToolBarSpacerControl = new sap.m.ToolbarSpacer({
                    width: "2px"
                });

            if (aProcessorDisplayText.length >= 2) {
                //if processor more than or equal to 2 => add 3 controls (Link (Approver),toolBarSpacer, Link(,))
                switch (iIndex) {
                    case 0:
                        return new sap.m.HBox(sId, {
                            items: [
                                oLinkUserControl,
                                oToolBarSpacerControl,
                                oLinkSperatorControl
                            ]
                        });
                    case 1:
                        return new sap.m.HBox({
                            items: [
                                oToolBarSpacerControl,
                                oLinkUserControl,
                                oToolBarSpacerControl
                            ]
                        });
                    default:// display more link to show more processor
                        let oMoreLink = new sap.m.Link({
                            text: oContextObj["fullName"],
                            emphasized: true,
                            press: function (oEvent) {
                                const aModels = [oEvent.getSource().getBindingContext("requestHeaderModel"),oEvent.getSource().getBindingContext("assignmentsModel"),oEvent.getSource().getBindingContext("subtaskModel")],
                                      oContextModel = aModels.filter(oModel=>oModel)[0],
                                    aPathSplit = oContextModel.getPath().split("/");
                                aPathSplit.splice(-2, 2);
                                const sPath = aPathSplit.join("/"),
                                    sFinalPath = sPath ? sPath:'/',
                                    oCurrentScope =oContextModel.getProperty(sFinalPath)["currentScope"] ?oContextModel.getProperty(sFinalPath)["currentScope"]:that;
                                const oUserListModel = new sap.ui.model.json.JSONModel();
                                oUserListModel.setData(
                                    oContextModel.getProperty(sFinalPath)
                                );
                                //set header model
                                oCurrentScope.getView().setModel(oUserListModel, "requestFormModel");
                                oCurrentScope.onPressUserList(oEvent);
                            }
                        });
                  return oMoreLink;
                }
            } else {
                //if processor is 1 => add 1 control (Link (Approver))
                return new sap.m.HBox(sId, {
                    items: [
                        oLinkUserControl
                    ]
                });
            }
        },
             /**Git 238 (Sub requests)
         *format role
        * @param {string} role - role
        */
        formatSubTaskRole: function (role) {
            return role ? role.split(";")[0] : ""
        },
             /**Git 132 (Form template changes)
         *format role
        * @param {string} DTCreation_tdate - submission date
        *  @param {string} sReqSubmissionField - submission field
        */
        formatReqSubDate: function (DTCreation_tdate, sReqSubmissionField) {
            const sReqDateFormat = DTCreation_tdate ? new Date(DTCreation_tdate) : "";
            sDateConversion = this.formatter.formatDateWithOrdinalNumberSuffixes(sReqDateFormat);
            return sDateConversion ? `${sReqSubmissionField}: ${sDateConversion}` : "";
        },
        setProfileUrl:function(userId,id){
            return userId ? `https://people.wdf.sap.corp/profiles/${userId}`:`https://people.wdf.sap.corp/profiles/${id}`;
        },
        onUserClick:function(oEvent){
            const oBindingContext = oEvent.getSource().getBindingContext("userCommentsModel").getObject();
            window.open(`https://people.wdf.sap.corp/profiles/${oBindingContext["userID"]}`,"blank");
        },
        formatSL1SL2:function(sl1,sl2){
            let solHierarchyMap = this.getOwnerComponent().getModel("SolutionAreaMasterData").getProperty("/solHierarchyMap")
            if (solHierarchyMap) {
                if (sl2 && sl1 && solHierarchyMap.get(sl1)&& solHierarchyMap.get(sl2)) {
                    return solHierarchyMap.get(sl1).soln_name + " > " + solHierarchyMap.get(sl2).soln_name
                } else if (sl1 && solHierarchyMap.get(sl1)) {
                    return solHierarchyMap.get(sl1).soln_name
                }
            } else {
                const aSln = this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`)
                if (aSln && aSln.length) {
                    return aSln[0].SelectedSolutionArea
                }
            }
            

        },   
         formatIsoDate: function (date) {
            if (date) {
                date = new Date(date);
                let month = date.toLocaleString('default', { month: 'short' }),
                    day = date.getDate(),
                    year = date.getFullYear();
                return `${month} ${day}, ${year}`;
            }
 
        }  ,
         //function to get Activity Status Text
        fnSetActivityStatusText: function (status) {
            switch (status) {
                case "01": //Registered
                    return "Registered";
                case "02": //Cancelled
                    return "Cancelled";
                case "10": //Recommended
                    return "Recommended";
                case "11": //Planned
                    return "Planned";
                case "12": //Completed
                    return "Completed";
                case "13": //Required
                    return "Required";
                case "14": // Validated
                    return "Validated";
                case "15": //Not Applicable
                    return "Not Applicable";
                case "16": //Started
                    return "Started";
                case "17": //Progressing
                    return "Progressing";
                case "18": //Presented
                    return "Presented";
                default: //Recommended
                    return "Recommended";
            }
        },
        //function to set Activity Status Icon
        fnSetActStatusIcon: function (status) {
            if (status === "14") {
                return "sap-icon://sys-enter";
            } else {
                return "sap-icon://accept";
            }
        },
        //function to get Activity Status Icon Visiblity
        fnSetVisiblityIcon: function (status) {
            let aChangeStatus = ["12", "17", "16", "18", "14"];
            if (status && aChangeStatus.indexOf(status) !== -1) {
                return true;
            } else {
                return false;
            }
 
        },
        fnSetIconColor: function (status) {
            if (status === "12") {
                return "#507d2a";
            } else {
                return "#346187";
            }
        },    
        createAddSolnItem: function (sId, oContextData) {
            const iIndex = parseInt(oContextData.getPath().split("/")[oContextData.getPath().split("/").length - 1]),
                oContextObj = oContextData.getObject(),
                that = this;
                //split path
                aPathSplit = oContextData.getPath().split("/"),
                userId = oContextObj["ID"] ? oContextObj["ID"] : oContextObj["userId"];
            //remove late path val
            aPathSplit.pop();
            let aSolnDisplayText = oContextData.getProperty(aPathSplit.join("/"));
            //control declaration
            let oTextUserControl = new sap.m.Text({
                text: oContextObj["name"]
            }),
                oTextSperatorControl
                    = new sap.m.Link({
                        text: ","
                    }),
                oToolBarSpacerControl = new sap.m.ToolbarSpacer({
                    width: "2px"
                });
 
            if (aSolnDisplayText.length >= 2) {
                //if processor more than or equal to 2 => add 3 controls (Link (Approver),toolBarSpacer, Link(,))
                switch (iIndex) {
                    case 0:
                        return new sap.m.HBox(sId, {
                            items: [
                                oTextUserControl,
                                oToolBarSpacerControl,
                                oTextSperatorControl
                            ]
                        });
                    case 1:
                        return new sap.m.HBox({
                            items: [
                                oToolBarSpacerControl,
                                oTextUserControl,
                                oToolBarSpacerControl
                            ]
                        });
                    default:// display more link to show more processor
                        let oMoreLink = new sap.m.Link({
                            text: oContextObj["name"],
                            emphasized: true,
                            press: function (oEvent) {
                                const aModels = [oEvent.getSource().getBindingContext("requestHeaderModel"),oEvent.getSource().getBindingContext("assignmentsModel"),oEvent.getSource().getBindingContext("subtaskModel")],
                                      oContextModel = aModels.filter(oModel=>oModel)[0],
                                    aPathSplit = oContextModel.getPath().split("/");
                                aPathSplit.splice(-2, 2);
                                const sPath = aPathSplit.join("/"),
                                    sFinalPath = sPath ? sPath:'/',
                                    oCurrentScope =oContextModel.getProperty(sFinalPath)["currentScope"] ?oContextModel.getProperty(sFinalPath)["currentScope"]:that;
                                const oUserListModel = new sap.ui.model.json.JSONModel();
                                oUserListModel.setData(
                                    oContextModel.getProperty(sFinalPath)
                                );
                                //set header model
                                oCurrentScope.getView().setModel(oUserListModel, "requestFormModel");
                                oCurrentScope.onPressUserList(oEvent);
                            }
                        });
                  return oMoreLink;
                }
            } else {
                //if processor is 1 => add 1 control (Link (Approver))
                return new sap.m.HBox(sId, {
                    items: [
                        oTextUserControl
                    ]
                });
            }
        },
        formatActivitySlnDesc: function (L2Desc, L3Desc, L4Desc, L5Desc, L6Desc) {
            switch (L6Desc ||L5Desc|| L4Desc || L3Desc|| L2Desc) {
                case L6Desc:
                    return L6Desc;
                    break;
                case L5Desc:
                    return L5Desc;
                    break;
                case L4Desc:
                    return L4Desc;
                    break;
                case L3Desc:
                    return L3Desc;
                    break;
                case L2Desc:
                    return L2Desc;
                    break;
                default:
                    return "";
            }

        },
        	//Function to set Risk Assesment Toggle button type for Risk Color
		fnFormatActRiskBtnType: function (RiskAssementID) {
			var type;
			switch (RiskAssementID) {
				case "01":
					type = sap.m.ButtonType.Reject;
					break;
				case "02":
					type = sap.m.ButtonType.Attention;
					break;
				case "03":
					type = sap.m.ButtonType.Accept;
					break;
				default:
					type = sap.m.ButtonType.Transparent;
			}
			return type;
		},
        fnSetRiskAssesmenBtn: function (SelectedRAId, CurrentRAId) {
			if (SelectedRAId === CurrentRAId) {
				return true;
			} else {
				return false;
			}
		},

        formatRiskIconState: function (RiskAssessId) {
			if (RiskAssessId === "01") {
				return "Negative";
			} else if (RiskAssessId === "02") {
				return "Critical";
			} else if (RiskAssessId === "03") {
				return "Positive";
			}
		},
        formatRiskButtonText: function (riskId) {
			var riskBtnTxt = "";
			if (riskId === "01") {
				riskBtnTxt = "Red";
			} else if (riskId === "02") {
				riskBtnTxt = "Yellow";
			} else if (riskId === "03") {
				riskBtnTxt = "Green";
			}
			return riskBtnTxt;
		},
        setReqDetailsFBSFormVisibility:function(engType){
            if(engType && engType=='0002'){
                return true
            }else{
                return false
            }
        },
        setReqDetailsFieldsVisibilityFBS:function(fieldVal){
            if(fieldVal && fieldVal!=''){
                return true
            }else{
                return false
            }
        },
        /**
         * Set activity details visibility
         * @function formatDisplayActivity
         * @param {object} activities - Activities
         * @param {String} currentStepID -  Current step Id (IOOAPP - For IO Owner task )
         * @param {boolean} isDisplayOnly -  isDisplayOnly true for Display page in Request View
         * @returns {boolean}
         **/
        formatDisplayActivity:function(activities,currentStepID,isDisplayOnly){
            if(!activities || (!isDisplayOnly && currentStepID == "IOOAPP")){
                //if activities are not present or if the open task is IO Owner approval then hide activity layout
                return false;
            }else{
                return true;
            }
 
        },
         /**
         * format request Id subtitle
         * @function formatReqIdSubtitle
         * @param {string} reqIdMainLabel - main req id label
         * @param {String} Parent_RefrenceID -  Main request refrence ID
         * @param {string} reqIdSubLabel -  sub req id label
         * @param {string} SubRefrenceID -  Sub request refrence id
         * @param {string} isRework - false for draft and true for In review requestor
         * @returns {string}
         **/
        formatReqIdSubtitle: function (reqIdMainLabel, Parent_RefrenceID, reqIdSubLabel, SubRefrenceID, isRework) {
            if (isRework) {
                //append main and sub req id for In review requestore
                return `${reqIdMainLabel} ${Parent_RefrenceID} - ${reqIdSubLabel} ${SubRefrenceID}`;
            } else {
                //for draft request show only main request id
                return `${reqIdMainLabel} ${Parent_RefrenceID}`;
            }
        },
        formatMinMaxdate:function(selDate){
            if(selDate){
                return new Date(selDate)
            }
        },
        //to remove the default placeholder from datepicker
        formatDatePlaceholder:function(placeholder){
            if(placeholder){
                return placeholder
            }else{
                return " "
            }
        },
          /**
         * Activity Detail Page: Function to convert drodown data to string
         * @function formatArrayToString
         * @param {object} oArray - bounded context
         * @param {Array} aOldSols -  Prev selected solutions
         * @returns {string}
         **/
		formatArrayToString: function (oArray, aOldSols) {
			var str = "";
			if (oArray && Array.isArray(oArray)) {
				oArray.filter(function (obj) {
					if (obj.hasOwnProperty("Description")) {
						str = str + obj.Description + "\n";
					} else if (obj.hasOwnProperty("BsnsAreaEngdDesc")) {
						str = str + obj.BsnsAreaEngdDesc + "\n";
					} else if (obj.hasOwnProperty("LevelDesc")) {
						str = str + obj.LevelDesc + "\n";
					} else if (obj.hasOwnProperty("SolutionDesc")) {
						str = str + obj.SolutionDesc + "\n";
					} else if (obj.hasOwnProperty("CrossTopicDesc")) {
						str = str + obj.CrossTopicDesc + "\n";
					} else if (obj.hasOwnProperty("content_id")) {
						str = str + obj.content_desc + "\n";
					} else if (obj.hasOwnProperty("OpportunityNo")) {
						str = str + obj.OpportunityNo + "\n";
					} else if (obj.hasOwnProperty("PhaseId")) {
						str = str + obj.PhaseDesc + "\n";
					} else if (obj.hasOwnProperty("Url")) {
						str = str + obj.Url + "\n";
					} else if (obj.hasOwnProperty("RegionMu")) {
						str = str + obj.RegionMu + "\n";
					} else if (obj.hasOwnProperty("IndustryDesc")) {
						str = str + obj.IndustryDesc + "\n";
					} else if (obj.hasOwnProperty("SrvReqstDesc")) {
						str = str + obj.SrvReqstDesc + "\n";
					} else if (obj.hasOwnProperty("InitiativeName")) {
						str = str + obj.InitiativeName + "\n";
					} else if(obj.hasOwnProperty("LandDescription")){
                        str = str + obj.LandDescription + "\n";
                    }
				});
				if (aOldSols) {
					if (aOldSols.length > 0) {
						aOldSols.filter(function (solObj) {
							str = str + solObj + "\n";
						});
					}
				}
			}
			return str;
		},
        manageDefaultvariant: function (defaultvalue) {
            if (defaultvalue) {
                return true;
            } else {
                return false;
            }
        },
        formatMainSln:function(aSolutions){
            return  aSolutions && aSolutions.filter(item => item.is_MainSoln).length ? aSolutions.filter(item => item.is_MainSoln)[0].solution_Hierarchy:""
        },
        manageFavouritevariant:function(isDefault,isFavourite){
            return (isFavourite || isDefault) ?  true :false;
        },
        formatReqIdTooltip:function(reqId){
            if(reqId){
            return reqId.toString();
            }
        },
         /**
         * format account and opp value for masterpage
         * @function formatAccountOpp
         * @param {string} requestType - request type (opp or account)
         * @param {String} accountName -  Account name
         * @param {string} oppID -  opportunity ID
         * @returns {string}
         **/
        formatAccountOpp: function (requestType, accountName, oppID) {
            if (requestType === 'Opportunity') {
                return `${accountName} / ${oppID}`;
            } else {
                return `${accountName}`;
            }
        },
          /**
         * Format  Profit center - Role text for master page
         * @function showAvailableValues
         * @param {string} value1 - Profit center
         * @param {String} value1 -  Role
         * @returns {string}
         **/
        showAvailableValues: function (value1, value2) {
            value2 = value2 ? value2
                .split(";")
                .map(s => s.trim())
                .join(", "):""; //Split roles and form string as comma seperated
            let sValue = value1 ? value1 : value2;
            return value1 && value2 ? `${value1} - ${value2}` : sValue
        },
         /**
         * format request ID text for master page
         * @function formatReqIdMasterPage
         * @param {integer} Parent_RefrenceID - Parent Req Id
         * @param {integer} SubRefrenceID -  Sub Req Id
         * @param {string} currentStateID -  current state ID
         * @returns {string}
         **/
        formatReqIdMasterPage: function (Parent_RefrenceID, SubRefrenceID, currentStateID, ReqMainSub, ReqIDSub) {
            if (currentStateID !== "REQSUB") {
                //append main and sub req id for In review requestore
                return `${ReqMainSub} ${Parent_RefrenceID}/${SubRefrenceID}`;
            } else {
                //for draft request show only main request id
                return `${ReqIDSub} ${Parent_RefrenceID}`;
            }
        },
        /**
         * format escape characters from the comment string entered in feed input
         * @function formatEscCharActionHistroy
         * @param {integer} escapedText - string received from the event object of comment feed input         
         * @returns {string}
         **/
        formatEscCharActionHistroy:function(escapedText){
            if(escapedText){
                return escapedText.replace(/&gt;/g,">").replace(/&lt;/g,"<").replace(/&amp;/g,"&")                
            }
        },
        formatOreGroup: function (g1, g2, g3) {
            const input = { oGroup1: g1, oGroup2: g2, oGroup3: g3 };
            return Object.values(input)
                .filter(v => v)     // remove empty values
                .join(" > ");

        },
        formatGroupSelectionVisibilityRadioBtn:function(isSelectableLevel,isFilter){
            if(isFilter==false && isSelectableLevel){
                return true
            }else{
                return false
            }

        },
        formatGroupSelectionVisibilityCheckBox:function(isSelectableLevel,isFilter){
            if(isFilter && isSelectableLevel){
                return true
            }else{
                return false
            }
        },
        setProcessorTokenVisibility: function (aProcessors, bIsAdvancedSearch) {
            return aProcessors && aProcessors.length > 0 && bIsAdvancedSearch ? true : false;

        },
        formatSelGrpMultiInputFilter:function(dialogselGroup,isFilter){
            if(isFilter && dialogselGroup){
                return isFilter && dialogselGroup.length>0;
            }else{
                return false
            }

        },
        formatSelGrpMultiInput:function(isFilter){
            return !isFilter;
        },
        /**
		 * @function setGroupVisibility		 
		 * @description function to set the visibility of group dialog in create req and forward req 
         * @param {boolean} isPanelExpanded - more field panel expanded or not
         * @param {boolean} isGrpSelectable - group is selectable to selected PC or not
		 */
        setGroupVisibility:function(isPanelExpanded,isGrpSelectable){
            if(isPanelExpanded && isGrpSelectable){
                return true;
            }else{
                return false;
            }
        },
          /**
		 * @function formatBullets		 
		 * @description function to format dynamic text in to bullets point
         * @param {object} items - opportunity error details
		 */
        formatBullets: function (items,sConstant) {
            if (!items || !items.length) {
                return "";
            }

            let html = "<ul>";

            items.forEach(function (item) {
                html += "<li>" + item.message + "</li>";
            });

            html += "</ul>";

            return sConstant ? sConstant + html : html;
        },
         /**
		 * @function formatActivityId		 
		 * @description remove leading zeros from activityId
         * @param {string} activityId - activityId
		 */
        formatActivityId: function (activityId,bIsActivityDetailPage) {
            return !bIsActivityDetailPage ? activityId?.replace(/^0+/, '') : `(${activityId?.replace(/^0+/, '')})`;
        },
         /**
		 * @function formatActivityUrl		 
		 * @description remove leading zeros from activityId and form activity url
         * @param {string} activityId - activityId
         * @param {string} ActivityURL - activity base url constant
		 */
        formatActivityUrl: function (activityId, ActivityURL) {
            let sActivityId = activityId?.replace(/^0+/, '');
            return `${ActivityURL}${sActivityId}`;
        }

    };
});