jQuery.sap.declare("com.dealsupport.melodyrequest.model.enterKey");
sap.ui.define([

], function () {
	"use strict";
	var onCallEvent;
	var oView;
	var bEmptySearchFlag;
	return {
		_enterPressKeyBind: function (oViewContext, oControl, onCallmethod, bEmptySearch) {
			oView = oViewContext;
			onCallEvent = onCallmethod;
			bEmptySearchFlag = bEmptySearch;
			oControl.onsapenter = function (e) {
				if (sap.m.InputBase.prototype.onsapenter) {
					sap.m.InputBase.prototype.onsapenter.apply(this, arguments);
					if (bEmptySearchFlag === false) {
						if (this.getValue()) {
								onCallEvent.call(oView);
						}
					} else {
						onCallEvent.call(oView);
					}
				}
			};
		}
	};
});
