sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "sap/ui/Device",
    "sap/m/MessageBox",
    "com/dealsupport/melodyrequest/control/ErrorHandle",
    "sap/ui/model/odata/v2/ODataModel",
    "sap/m/MessageToast",
    "com/dealsupport/melodyrequest/model/formatter",
    "sap/base/security/sanitizeHTML",
    "sap/ui/model/odata/v4/ODataModel"
],
    /**
     * provide app-view type models (as in the first "V" in MVVC)
     * 
     * @param {typeof sap.ui.model.json.JSONModel} JSONModel
     * @param {typeof sap.ui.Device} Device
     * 
     * @returns {Function} createDeviceModel() for providing runtime info for the device the UI5 app is running on
     */
    function (JSONModel, Device, MessageBox, ErrorHandle,ODataModel,MessageToast,formatter,sanitizeHTML,ODataV4Model) {
        "use strict";

        return {
            createDeviceModel: function () {
                var oModel = new JSONModel(Device);
                oModel.setDefaultBindingMode("OneWay");
                return oModel;
            },
            createFilterUrlModel: function () {
                var sFilterUrl = {
                    "adminViewFilterUrl": `/AdminResources?$count=true`,
                    "wfHistoryFikterUrl": ""
                };
                var oModel = new JSONModel(sFilterUrl);
                oModel.setDefaultBindingMode("OneWay");
                return oModel;
            },
            _getWfServiceRuntimeBaseURLRoleBased: function (self, isComponentScope) {
                return this._getRuntimeBaseURL(self, isComponentScope) + "/adminresources";
            },
            _getWfServiceRuntimeBaseURL: function (self, isComponentScope) {
                return this._getRuntimeBaseURL(self, isComponentScope) + "/cap";
            },
            _getAdminWfServiceRuntimeBaseURL: function (self, isComponentScope) {
                return this._getRuntimeBaseURL(self, isComponentScope) + "/adminresources/resources";
            },
            _getOpportunitiesRuntimeBaseURL: function (self, isComponentScope) {
                return this._getRuntimeBaseURL(self, isComponentScope) + "/int_ic";
            },
            _getAppValueHelpRuntimeBaseURL: function (self, isComponentScope) {
                return this._getRuntimeBaseURL(self, isComponentScope) + "/ext_harmony";
            },
            _getRuntimeBaseURL: function (self, isComponentScope) {
                var componentName =
                    isComponentScope ? self.getManifestEntry("/sap.app/id").replaceAll(".", "/")
                        : self.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
                var componentPath = sap.ui.require.toUrl(componentName);
                return componentPath;
            },

            getWfInstanceLists: function (fnSuccess, fnError, self) {
                var workflowBaseurl = this._getWfServiceRuntimeBaseURLRoleBased(self);
                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    url: `${workflowBaseurl}/wf/V_WfInstance_Ext`,
                    type: "GET",
                    success: function (oData) {
                        return fnSuccess(oData, self);

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            getCurrentStateLists: function (fnSuccess, self, isComponentScope) {
                var workflowBaseurl = this._getWfServiceRuntimeBaseURL(self, isComponentScope);
                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    url: `${workflowBaseurl}/req-area-api-/Current_State`,
                    type: "GET",
                    success: function (oData) {
                        return fnSuccess(oData, self);

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);

                    }
                });
            },
            getPendingCurrentStateLists: function (fnSuccess, fnError, self) {
                var workflowBaseurl = this._getWfServiceRuntimeBaseURL(self);
                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    url: `${workflowBaseurl}/req-area-api-/Current_State?$filter=Technical_state eq 'inProcess'`,
                    type: "GET",
                    success: function (oData) {
                        return fnSuccess(oData, self);

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            getTechnicalState: function(self, isComponentScope){
                var workflowBaseurl = this._getWfServiceRuntimeBaseURL(self, isComponentScope);
                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    url: `${workflowBaseurl}/resources/TechnicalState`,
                    type: "GET",
                    success: function (oData) {
                        const oTechData = new JSONModel();
                        oTechData.setData(oData);
                        self.getView().setModel(oTechData, "Technicalstate");
                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            getSalesOrgLists: function (fnSuccess, fnError, self, isComponentScope) {
                var workflowBaseurl = this._getWfServiceRuntimeBaseURLRoleBased(self, isComponentScope);
                jQuery.ajax({
                    async: true,
                    contentType: "application/json",
                    url: `${workflowBaseurl}/resources/SRV_Sales_Org`,
                    type: "GET",
                    success: function (oData) {
                        return fnSuccess(oData, self);

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            getReqAreaLists: function (fnSuccess, fnError, self, sUrl) {
                var workflowBaseurl = this._getWfServiceRuntimeBaseURL(self);
                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    url: `${workflowBaseurl}/req-area-api-${sUrl}`,
                    type: "GET",
                    success: function (oData) {
                        return fnSuccess(oData, self);

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },

            //Remove IO Owners duplicacy
            removeIODuplicacy: function(oData){
                for (let i = 0; i < oData.value.length; i++) {
                    if (oData.value[i].currentStateID == "WIOAPP") {
                        const currProc =  oData.value[i].CurrentProcessor ? oData.value[i].CurrentProcessor.split(","):[];
                        const currProcEm = oData.value[i].CurrentProcessorEmail ? oData.value[i].CurrentProcessorEmail.split(","):[];
                        const removeDuplicateObjects = (currProc) => {
                            const uniqueObjects = Array.from(new Set(currProc.map(JSON.stringify))).map(JSON.parse);
                            return uniqueObjects;
                        }
                        const removeDuplicateObjectsEmail = (currProcEm) => {
                            const uniqueObjectsEmail = Array.from(new Set(currProcEm.map(JSON.stringify))).map(JSON.parse);
                            return uniqueObjectsEmail;
                        }
                        const oCurrProc = removeDuplicateObjects(currProc);
                        oData.value[i].CurrentProcessor = oCurrProc.join(",");
                        const oCurrProcEmail = removeDuplicateObjectsEmail(currProcEm);
                        oData.value[i].CurrentProcessorEmail = oCurrProcEmail.join(",");
                    }
                }
                return oData;
            },
            getWfInstanceFilterLists: function (fnSuccess, fnError, self, sFilterQuery, bInitialLoad) {
                var workflowBaseurl = this._getWfServiceRuntimeBaseURLRoleBased(self);
                jQuery.ajax({
                    async: true,
                    contentType: "application/json",
                    url: `${workflowBaseurl}${sFilterQuery}&$expand=_Solution`,
                    type: "GET",
                    success: function (oData) {
                        sap.ui.core.BusyIndicator.hide()
                        this.removeIODuplicacy(oData);                    
                        return fnSuccess(oData, self, bInitialLoad);

                    }.bind(this),
                    error: function (oError) {
                        sap.ui.core.BusyIndicator.hide()
                        self.getView().byId("id-table-wfHistory").setBusy(false);
                        return fnError(oError, self)
                    }
                });

            },
            getInboxWfInstanceFilterLists: function (fnSuccess, fnError, self, sFilterQuery,sUrlInstanceId,skip,top) {
                var workflowBaseurl = this._getWfServiceRuntimeBaseURLRoleBased(self);
                const sFilterQueryVal = sFilterQuery;
                 sFilterQuery = `${sFilterQuery}&$expand=_Solution`;
                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    url: `${workflowBaseurl}${sFilterQuery}`,
                    type: "GET",
                    success: function (oData) { 
                        this.removeIODuplicacy(oData);
                        //set count for tabs
                        oData.count = oData["@odata.count"];
                        let oModel = new sap.ui.model.json.JSONModel();
                        let oCount = {}
                        oCount.pendingReqCount = self.count;
                        oCount.MyReqCount = oData.count;
                        self.getOwnerComponent().getModel("appConstants").setProperty("/pendingReqCount", oCount.MyReqCount);
                        self.getOwnerComponent().getModel("appConstants").setProperty("/openTaskCount", oCount.MyReqCount);
                        if (sUrlInstanceId) {
                              if(this.loadedData){
                            this.loadedData = this.loadedData.concat(oData.value);
                        }else{
                            this.loadedData = oData.value;
                        }
                            oData.value =  this.loadedData;
                            this.removeIODuplicacy(oData);
                            if (oData.value.filter(history => history.InstanceID === sUrlInstanceId).length || oData["@odata.count"] <= this.loadedData.length) {
                                this.loadedData = false;
                                return fnSuccess(oData, self);
                            } else {
                                this.skipNew = 20+skip;
								if(this.skipNew<=  oData["@odata.count"] ){
                                this.getInboxWfInstanceFilterLists(self.fnSuccessFilterCallback, self.fnErrorFilterCallback, self, sFilterQueryVal, sUrlInstanceId,this.skipNew,top);
								}
                            }
                        }else{
                            this.loadedData = false;
                            if (this.skipNew) {
                                self.getView().byId("id-list-pendingRequests").setGrowingThreshold(this.skipNew + 20)
                            }
                            return fnSuccess(oData, self,)
                        }
                    }.bind(this),
                    error: function (oError) {
                        return fnError(oError, self)
                    }
                });

            },
            getWfSearchLists: function (fnSuccess, fnError, self, sQuery) {
                var workflowBaseurl = this._getWfServiceRuntimeBaseURLRoleBased(self);
                var sSearchUrl = `${workflowBaseurl}/wf/V_WfInstance_Ext?$count=true&$search=${sQuery}`;
                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    url: sSearchUrl,
                    type: "GET",
                    success: function (oData) {
                        return fnSuccess(oData, self);

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });

            },
            getMyInboxInstanceDetails: function (fnSuccess, fnError, self, sInstanceID) {
                var workflowBaseurl = this._getWfServiceRuntimeBaseURLRoleBased(self);
                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    url: `${workflowBaseurl}/wf/V_WfInstance_Inbox?$filter=InstanceID eq ('${sInstanceID}')`,
                    type: "GET",
                    success: function (oResponse) {
                        this.removeIODuplicacy(oResponse);
                        return fnSuccess(oResponse, self);

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            getInstanceDetails: function (fnSuccess, fnError, self, sInstanceID) {
                var workflowBaseurl = this._getWfServiceRuntimeBaseURLRoleBased(self);
                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    url: `${workflowBaseurl}/wf/V_WfInstance_Ext?$filter=InstanceID eq ('${sInstanceID}')`,
                    type: "GET",
                    success: function (oResponse) {
                        this.removeIODuplicacy(oResponse);
                        return fnSuccess(oResponse, self,sInstanceID);

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            //admin view starts here
            getAdminViewFilterLists: function (fnSuccess, fnError, self, sFilterQuery, oPostPayload, sPostUrl, that) {
                var workflowBaseurl = this._getAdminWfServiceRuntimeBaseURL(self);
                jQuery.ajax({
                    contentType: "application/json",
                    url: `${workflowBaseurl}${sFilterQuery}&$skip=0&$top=20`,
                    type: "GET",
                    success: function (oData) {
                        return fnSuccess(oData, self, oPostPayload, sPostUrl, that);

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });

            },
            getAdminViewDetail: function (fnSuccess, fnError, self, sUrl, sMode, that) {
                var workflowBaseurl = this._getAdminWfServiceRuntimeBaseURL(self);
                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    url: `${workflowBaseurl}${sUrl}`,
                    type: "GET",
                    success: function (oData) {
                        return fnSuccess(oData, self, sMode, that);

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });

            },
            postAdminDetails: function (fnSuccess, fnError, self, oPayload, sUrl, that) {
                var workflowBaseurl = this._getAdminWfServiceRuntimeBaseURL(self);
                jQuery.ajax({
                    contentType: "application/json",
                    url: `${workflowBaseurl}${sUrl}`,
                    data: JSON.stringify(oPayload),
                    type: "PATCH",
                    success: function () {
                        return fnSuccess(self , that);

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            createAdminGUID: function (fnSuccess, fnError, self) {
                var workflowBaseurl = this._getAdminWfServiceRuntimeBaseURL(self);
                var data = {};
                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    data: JSON.stringify(data),
                    url: `${workflowBaseurl}/AdminResources`,
                    type: "POST",
                    success: function (data) {
                        return fnSuccess(data, self);

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });

            },
            deleteAdminGUID: function (fnSuccess, fnError, self, sUrl, isCompleteAPICalls) {
                var workflowBaseurl = this._getAdminWfServiceRuntimeBaseURL(self);
                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    url: `${workflowBaseurl}${sUrl}`,
                    type: "DELETE",
                    success: function (data) {
                        return fnSuccess(data, self, isCompleteAPICalls);

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });

            },
            getAppConstants: function (fnSuccess, self, isComponentScope) {
                var workflowBaseurl = this._getWfServiceRuntimeBaseURL(self, isComponentScope);
                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    url: `${workflowBaseurl}/req-area-api-/Parameter`,
                    type: "GET",
                    success: function (oData) {
                        return fnSuccess(oData, self);

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });

            },
            //my Opportunities
            _closeBusyIndicator: function (self) {
                var oTable = self.getView().byId("id-table-myOpportunity");
                oTable.setBusy(false);
            },
            getEmployeePartnerDetails: function (self, sUserId, fnSuccess) {
                var OpportunitiesBaseUrl = this._getOpportunitiesRuntimeBaseURL(self);
                var sFilterUrl = `&search-focus=PARTNER&search=${sUserId}&$select=NAME,PARTNER,ADDRESS`
                jQuery.ajax({
                    url: `${OpportunitiesBaseUrl}/sap/opu/odata/sap/zharmony_callidus_srv/EmployeeSearch?${sFilterUrl}`,
                    dataType: 'json',
                    method: "GET",
                    success: function (response) {
                        return fnSuccess(response, self);

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            getMyOpportunities: function (self, sOppFilterQuery, fnSuccess,createCall) {
                var OpportunitiesBaseUrl = this._getOpportunitiesRuntimeBaseURL(self);
                const that = this;
                jQuery.ajax({
                    url: `${OpportunitiesBaseUrl}/sap/opu/odata/sap/zharmony_callidus_srv/Opportunities?$skip=0&$top=20&${sOppFilterQuery}&$select=IS_FAVORITE,GUID,ACCOUNT_NAME,ACCOUNT,DEAL_TYPE,OPPT_ID,CHANGED_AT,URL,PROCESS_TYPE,PARTNER,PARTNER_NAME,IS_LEAN,BUSINESS_MODEL,DIS_CHANNEL,SOURCE,REVENUE_TYPE,HARMONY_TYPE,ERROR,HDM_MIG_STA,DESCRIPTION,EXPECTED_VALUE,DISP_AUTH,CURRENCY,MAINQUOTE,CPQ_QUOTE,CPQ_SYSTEM_ID,LICENSE_REVENUE,SERVICES_REVENUE,CLOUD_REVENUE,STATUS,OWNER_NAME,OWNER,USR_IN_SLS_TEAM,FORECAST,EXPECT_END,CLOSE_DATE_EDITABLE,CURR_PHASE,ORDER_ID,SALES_ORG_SHORT`,
                    dataType: 'json',
                    async:false,
                    method: "GET",
                    success: function (data) {
                        jQuery.ajax({
                            url: `${OpportunitiesBaseUrl}/sap/opu/odata/sap/zharmony_callidus_srv/Opportunities/$count?${sOppFilterQuery}`,
                            dataType: 'json',
                            async:false,
                            method: "GET",
                            success: function (count) {
                                data.d.count = count;
                                sap.ui.core.BusyIndicator.hide();
                                if(!sOppFilterQuery.includes("OPPT_ID")){
                                    appView._alreadyLoadedOppCount = data.d.results.length;
                                    const oOppTempModel = new sap.ui.model.json.JSONModel();
                                    oOppTempModel.setData(data.d);
                                    self.getView().setModel(oOppTempModel, "oppTempModel");
                                    self.getView().getModel("oppTempModel").refresh();
                                    self.bOppSearch = false;
                                }else{
                                    self.bOppSearch = true;
                                }
                                return fnSuccess(data, self);

                            }.bind(this),
                            error: function (oError) {
                                sap.ui.core.BusyIndicator.hide();
                                ErrorHandle.setErrorMessage(oError, self);
                                if(createCall){
                                    self._openCreateReqDialog(self);
                                }
                            }
                        });
                    }.bind(this),
                    error: function (oError) {
                        sap.ui.core.BusyIndicator.hide();
                        ErrorHandle.setErrorMessage(oError, self);
                        if(createCall){
                            self._openCreateReqDialog(self);
                        }
                    }
                });

            },
            getPublicSalesOrg: function (self, fnSuccess , isComponentScope) {
                var workflowBaseurl = this._getWfServiceRuntimeBaseURL(self , isComponentScope);
                jQuery.ajax({
                    url: `${workflowBaseurl}/req-area-api-/Public_SOrg`,
                    async: false,
                    dataType: 'json',
                    method: "GET",
                    success: function (response) {
                        return fnSuccess(response, self);

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            getPublicReqArea: function (self, sSalesOrg, fnSuccess, oContext) {
                var workflowBaseurl = this._getWfServiceRuntimeBaseURL(self);
                const that = this;
                jQuery.ajax({
                    url: `${workflowBaseurl}/req-area-api-/Public_ReqArea?$filter=orgID eq '${sSalesOrg}'`,
                    async: false,
                    dataType: 'json',
                    method: "GET",
                    success: function (response) {
                        if(fnSuccess){
                        return fnSuccess(response, self, oContext);
                        }else{
                            const aResult = response.value;
                            const aModel = {};
                            aModel.data = self._setReqAreasTree(aResult);
                            const oUpdatedReqArea = new JSONModel();
                            oUpdatedReqArea.setData(aModel);
                            self.getView().setModel(oUpdatedReqArea, "myPresaleModel");
                            self._configRequestDialog()
                        }

                    }.bind(this),
                    error: function (oError) {
                        that._setErrorMsgPopOver(appView,"RequestAreas",oError);
                    }
                });
            },
            _getWorkflowRuntimeBaseURL: function (self) {
                return this._getRuntimeBaseURL(self) + "/workflowruntime/rest/v1/workflow-instances";
            },
            _getWorkflowRuntimeSubAccountBaseURL: function (self) {
                return this._getRuntimeBaseURL(self) + "/workflowruntime/";
            },
            callWorkflowSrv: function (oPayload, oController, self, fnSuccess) {
                var workflowBaseurl = this._getWorkflowRuntimeSubAccountBaseURL(oController);
                $.ajax({
                    url: `${workflowBaseurl}rest/v1/xsrf-token`,
                    method: "GET",
                    headers: {
                        "X-CSRF-Token": "Fetch"
                    },
                    success: function (result, xhr, data) {
                        var token = data.getResponseHeader("X-CSRF-Token");
                        $.ajax({
                            url: `${workflowBaseurl}rest/v1/workflow-instances/`,
                            method: "POST",
                            data: JSON.stringify(oPayload),
                            headers: {
                                "X-CSRF-Token": token,
                                "Content-Type": "application/json"
                            },
                            success: function (result, xhr, data) {
                                return fnSuccess(result, self);
                            }.bind(this),
                            error: function (oError) {
                                ErrorHandle.setErrorMessage(oError, self);
                            }
                        });
                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            _getWorkflowInstances: function (self, sOppID, fnSuccess) {
                var workflowBaseurl = this._getWorkflowRuntimeBaseURL(self);
                jQuery.ajax({
                    url: `${workflowBaseurl}?status=RUNNING,%20ERRONEOUS,%20SUSPENDED,%20CANCELED,%20COMPLETED&$orderby=startedAt%20desc&$top=1000&containsText=${sOppID}`,
                    dataType: 'json',
                    async: false,
                    method: "GET",
                    success: function (response) {
                        return fnSuccess(response, self, sOppID);

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            _getRuleServiceRuntimeBaseURL: function (self) {
                return this._getRuntimeBaseURL(self) + "/businessrules";
            },
            callBusinessRulesSrv: function (oPayload, oController, self, fnSuccess) {
                var workflowBaseurl = this._getRuleServiceRuntimeBaseURL(oController);
                $.ajax({
                    url: `${workflowBaseurl}/rest/v2/xsrf-token`,
                    method: "GET",
                    async: false,
                    headers: {
                        "X-CSRF-Token": "Fetch"
                    },
                    success: function (result, xhr, data) {
                        var token = data.getResponseHeader("X-CSRF-Token");
                        $.ajax({
                            url: `${workflowBaseurl}/rest/v2/rule-services`,
                            method: "POST",
                            async: false,
                            data: JSON.stringify(oPayload),
                            headers: {
                                "X-CSRF-Token": token,
                                "Content-Type": "application/json"
                            },
                            success: function (result, xhr, data) {
                                return fnSuccess(result, self);
                            }
                        });
                    }
                });
            },
            _getGetWfContextDetails: function (self, sParentInstanceId, fnSuccess) {
                var workflowBaseurl = this._getWorkflowRuntimeBaseURL(self);
                jQuery.ajax({
                    url: `${workflowBaseurl}/${sParentInstanceId}/context`,
                    dataType: 'json',
                    async: true,
                    method: "GET",
                    success: function (response) {
                        return fnSuccess(response, self);

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });


            },
            _getRequestHistory: function (oController, id, fnSuccess) {
                var workflowBaseurl = this._getWorkflowRuntimeBaseURL(oController);
                jQuery.ajax({
                    url: `${workflowBaseurl}/${id}/context`,
                    dataType: 'json',
                    async: true,
                    method: "GET",
                    success: function (response) {
                        return fnSuccess(response, id);

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, oController);
                    }
                });
            },
            _getWfTaskDetails: function (self, taskId, fnSuccess) {
                //write your odata code 
                //after getting the values you have close the dialog
                var workflowBaseurl = this._getWorkflowRuntimeSubAccountBaseURL(self);
                //var that = this;
                //  var taskId = this.getComponentData().startupParameters.taskModel.getData().InstanceID;
                $.ajax({
                    // Call workflow API to complete the task
                    url: workflowBaseurl + "rest/v1/task-instances/" + taskId,
                    async: false,
                    method: "GET",
                    // refreshTask needs to be called on successful completion
                    success: function (result, xhr, data) {
                        // read task instance model & bind it to retrieve workflowInstanceId later
                        return fnSuccess(result, self)
                    },
                    error: function (err) {
                        ErrorHandle.setErrorMessage(err, self);

                    }

                });

            },
            _getWfTaskContextDetails: function (self, taskId, fnSuccess) {
                //write your odata code 
                //after getting the values you have close the dialog
                var workflowBaseurl = this._getWorkflowRuntimeSubAccountBaseURL(self);
                //var that = this;
                //  var taskId = this.getComponentData().startupParameters.taskModel.getData().InstanceID;
                $.ajax({
                    // Call workflow API to complete the task
                    url: workflowBaseurl + "rest/v1/task-instances/" + taskId + "/context",
                    async: false,
                    method: "GET",
                    // refreshTask needs to be called on successful completion
                    success: function (result, xhr, data) {
                        // read task instance model & bind it to retrieve workflowInstanceId later
                        return fnSuccess(result, self)
                    },
                    error: function (err) {
                          self?.common?._closeBusyIndicator(self);
                        ErrorHandle.setErrorMessage(err, self);

                    }

                });

            },
            _getWfTaskContextDetails: function (self, taskId, fnSuccess) {
                //write your odata code 
                //after getting the values you have close the dialog
                var workflowBaseurl = this._getWorkflowRuntimeSubAccountBaseURL(self);
                //var that = this;
                //  var taskId = this.getComponentData().startupParameters.taskModel.getData().InstanceID;
                $.ajax({
                    // Call workflow API to complete the task
                    url: workflowBaseurl + "rest/v1/task-instances/" + taskId + "/context",
                    async: false,
                    method: "GET",
                    // refreshTask needs to be called on successful completion
                    success: function (result, xhr, data) {
                        // read task instance model & bind it to retrieve workflowInstanceId later
                        return fnSuccess(result, self)
                    },
                    error: function (err) {
                          self?.common?._closeBusyIndicator(self);
                        ErrorHandle.setErrorMessage(err, self);

                    }

                });

            },
            _getWfExecutionLogs: function (self, id, fnSuccess) {
                const workflowBaseurl = this._getWorkflowRuntimeSubAccountBaseURL(self),
                    that = this;
                jQuery.ajax({
                    url: `${workflowBaseurl}/rest/v1/workflow-instances/${id}/execution-logs`,
                    dataType: 'json',
                    async: false,
                    method: "GET",
                    success: function (response) {
                        return fnSuccess(response, self);

                    }.bind(this),
                    error: function (oError) {
                        self?.common?._closeBusyIndicator(self);
                        sap.ui.core.BusyIndicator.hide();
                        self.getView().setBusy(false);
                        if(oError.responseText.includes("bpm.workflowruntime.rest.instance.not.found")){
                            that.oldReqMessageTemplate(self);
                        }else{
                            ErrorHandle.setErrorMessage(oError, self);
                        }
                    }
                });
            },
             /**
             * execute for old request (Prev version of App)
             *
             * @param {Object} self - The current context or controller instance.
             */
            oldReqMessageTemplate: function (self) {
                //set old request flag
                self.getOwnerComponent().getModel("appConstants").setProperty("/isOldVersionReq", true);
                self.getOwnerComponent().getModel("appConstants").refresh();
                const sProfitCenterI18n = self.i18nModel.getText("profitCenter"),
                      sRoleAreaI18n = self.i18nModel.getText("roleAreaPrimary"),
                      sRoleI18n = self.i18nModel.getText("rolePrimary"),
                      sBAIi18n = self.i18nModel.getText("businessAreaIndustryPrimary"),
                      sOppId = self.i18nModel.getText("taskMsgOppID"),
                      sOppName = self.i18nModel.getText("taskMsgOppDesc"),
                      sAccount = self.i18nModel.getText("taskMsgOppDesc"),
                      oWfInstanceModel =self.getView().getModel("wfInstanceModel"),
                      sProfitCenter = oWfInstanceModel.getProperty("/orgName"),
                      sOppVal = oWfInstanceModel.getProperty("/OpportunityID")? oWfInstanceModel.getProperty("/OpportunityID"):"",
                      sOppDesc = oWfInstanceModel.getProperty("/OpportunityDesc")? oWfInstanceModel.getProperty("/OpportunityDesc"):"",
                      sAccountVal = oWfInstanceModel.getProperty("/RequestType") === "Account" ? `${oWfInstanceModel.getProperty("/Account_ID")} - ${oWfInstanceModel.getProperty("/Account_name")}`:"",
                      sRoleArea = oWfInstanceModel.getProperty("/roleArea_Desc"),
                      sRole = oWfInstanceModel.getProperty("/Role_Desc") ? oWfInstanceModel.getProperty("/Role_Desc").split(";").join():"",
                      sIndustry = oWfInstanceModel.getProperty("/BA_Industry_Desc"),
                      sInstanceID = oWfInstanceModel.getProperty("/InstanceID"),
                      oAppConstantsModel = self.getOwnerComponent().getModel("appConstants"),
			          sOppUrl = `${oAppConstantsModel.getProperty("/HarmonyURL/0/Value")}Opportunity/${sOppVal}`,
                      //form array for old request header
                      aFields = [
                     { Name: sOppName, Desc: sOppDesc , queryParams: "", active:false, url:""},
                     { Name: sOppId, Desc: sOppVal , queryParams: "", active:true,url:sOppUrl },
                     { Name: sAccount, Desc: sAccountVal , queryParams: "", active:false,url:"" },
                     { Name: sProfitCenterI18n, Desc: sProfitCenter , queryParams: "TrpcDesc", active:false,url:""},
                     { Name: sRoleAreaI18n, Desc: sRoleArea, queryParams: "RoleAreaDesc", active:false,url:""  },
                     { Name: sRoleI18n, Desc: sRole, queryParams: "RoleDesc",active:false,url:""  },
                     { Name: sBAIi18n, Desc: sIndustry, queryParams: "BaIndDesc",active:false,url:"" },
                 ];
                 let aListItems = [];
                 //create new object and set the model
                 aFields.forEach(function (item) {
                    if (item.Desc) {
                        let listItem = {
                            Name: item.Name,
                            Desc: item.Desc,
                            Active:item.active,
                            Url:item.url,
                            queryParams: item.queryParams
                        };
                        aListItems.push(listItem);
                    }
                });
                let oModelResPr = new sap.ui.model.json.JSONModel();
                oModelResPr.setData(
                    aListItems
                );
                self.getView().setModel(oModelResPr, "ResSearchField");
                //Set messagestrip model
                let oLegacyTaskModel = new JSONModel({
                    urlToOpp: `${self.getOwnerComponent().getModel("appConstants").getProperty("/oldAppUrl/0/Value")}/HomePage/${self.getOwnerComponent().getModel("appConstants").getProperty("/routePath")}/${sInstanceID}`
                });
                self.getView().setModel(oLegacyTaskModel, "legacyReqMessage");       
            },
              /**
             * event trigger for old request opp routing
             *
             * @param {Object} evt -event object
             */
            _handleUrlRouting: function (evt) {
                const oBoundModelData = evt.getSource().getModel("ResSearchField").getData(),
                    sOppId = evt.getSource().getText(),
                    aBoundObj = oBoundModelData.filter(item => item.Desc === sOppId);
                window.open(aBoundObj[0].Url, "_blank");
            },
            getAccountlData: function (appView, self, sAccountId, fnSuccess) {
                var OpportunitiesBaseUrl = this._getOpportunitiesRuntimeBaseURL(appView);
                const that = this;
                jQuery.ajax({
                    url: `${OpportunitiesBaseUrl}/sap/opu/odata/sap/zharmony_callidus_srv/BusinessPartnerAttribSet('${sAccountId}')`,
                    dataType: 'json',
                    method: "GET",
                    async:false,
                    success: function (response) {
                        sap.ui.core.BusyIndicator.hide();
                        //Set IAC details
                        const IAC = response.d.TG_ACCOUNT_DESC ? response.d.TG_ACCOUNT_DESC.trim() : "";
                        appView.oFinalData.iacValue = IAC;
                        var accountOwner = response.d.PARENT_ACC_OWNR_NM;
                        if (accountOwner) {
                            jQuery.ajax({
                                url: `${OpportunitiesBaseUrl}/sap/opu/odata/sap/zharmony_callidus_srv/BusinessPartners?search=${response.d.PARENT_ACC_OWNER}&$filter=TYPE eq 'E'`,
                                dataType: 'json',
                                method: "GET",
                                async:false,
                                success: function (response) {
                                    sap.ui.core.BusyIndicator.hide();
                                    return fnSuccess(response, accountOwner);
                                }.bind(this),
                                error: function (oError) {
                                    that._setErrorMsgPopOver(appView,"Account",oError);
                                }
                            });
                        } else {
                            return fnSuccess(response, accountOwner);
                        }
                    }.bind(this),
                    error: function (oError) {
                        that._setErrorMsgPopOver(appView,"Account",oError);
                    }
                });
            },

            getAccountModelData: function (self, sVal) {
                sap.ui.core.BusyIndicator.show(0);
                var OpportunitiesBaseUrl = this._getOpportunitiesRuntimeBaseURL(self);
                jQuery.ajax({
                    url: `${OpportunitiesBaseUrl}/sap/opu/odata/sap/zharmony_callidus_srv/BusinessPartners?$skip=0&$top=117&search-focus=PARTNER&search=${sVal}&$select=NAME%2cPARTNER%2cUSERID%2cADDRESS%2cNAME`,
                    dataType: 'json',
                    method: "GET",
                    success: function (oData) {
                        sap.ui.core.BusyIndicator.hide();
                        var sValue = oData.d.results;
                        var oUsermodel = new sap.ui.model.json.JSONModel(sValue);
                        self._ovalueHelpAccFragment.getTableAsync().then(function (oTable) {
                            oTable.setModel(oUsermodel);

                            if (oTable.bindRows) {
                                oTable.bindAggregation("rows", "/");
                            }
                            self._ovalueHelpAccFragment.update();
                        }.bind(self));
                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            getPartnerModelData: function (self, sVal) {
                sap.ui.core.BusyIndicator.show(0);
                var OpportunitiesBaseUrl = this._getOpportunitiesRuntimeBaseURL(self);
                jQuery.ajax({
                    url: `${OpportunitiesBaseUrl}/sap/opu/odata/sap/zharmony_callidus_srv/ChPartnerSearchSet?$skip=0&$top=112&search-focus=PARTNER&search=${sVal}&$select=NAME%2cPARTNER%2cCH_PARTNER_TYPE%2cCOUNTRY_NAME%2cADDRESS%2cNAME`,
                    dataType: 'json',
                    method: "GET",
                    success: function (oData) {
                        var sValue = oData.d.results;
                        var oUsermodel = new sap.ui.model.json.JSONModel(sValue);
                        self._ovalueHelpPartnerFragment.getTableAsync().then(function (oTable) {
                            oTable.setModel(oUsermodel);

                            if (oTable.bindRows) {
                                oTable.bindAggregation("rows", "/");
                            }
                            self._ovalueHelpPartnerFragment.update();
                        }.bind(self));
                        sap.ui.core.BusyIndicator.hide();
                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            getSalesTeamModelData: function (self, sVal) {
                var OpportunitiesBaseUrl = this._getOpportunitiesRuntimeBaseURL(self);
                jQuery.ajax({
                    url: `${OpportunitiesBaseUrl}/sap/opu/odata/sap/zharmony_callidus_srv/EmployeeSearch?$skip=0&$top=112&search-focus=PARTNER&search=${sVal}&$select=NAME%2cPARTNER%2cUSERID%2cADDRESS%2cNAME`,
                    async: false,
                    dataType: 'json',
                    method: "GET",
                    success: function (oData) {
                        var sValue = oData.d.results;
                        var oUsermodel = new sap.ui.model.json.JSONModel(sValue);
                        self._ovalueHelpSalesTeamFragment.getTableAsync().then(function (oTable) {
                            oTable.setModel(oUsermodel);

                            if (oTable.bindRows) {
                                oTable.bindAggregation("rows", "/");
                            }
                            self._ovalueHelpSalesTeamFragment.update();
                        }.bind(self));
                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            getAppValueHelpsModelData: function (self, fnSuccess) {
                var OpportunitiesBaseUrl = this._getOpportunitiesRuntimeBaseURL(self);
                jQuery.ajax({
                    url: `${OpportunitiesBaseUrl}/sap/opu/odata/sap/zharmony_callidus_srv/AppValueHelps?$filter=(ENTITY_NAME%20eq%20%27OPPORTUNITY%27%20or%20ENTITY_NAME%20eq%20%27GENERAL%27)`,
                    async: false,
                    dataType: 'json',
                    method: "GET",
                    success: function (oData) {
                        return fnSuccess(oData, self);
                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            _getLSRuntimeBaseURL: function (self,isComponentScope) {
                return this._getRuntimeBaseURL(self,isComponentScope) + "/int_pc";
            },

            getfnFetchOREData: function (self, sUserId) {
                var OREModel = self.OREModel;
                OREModel.setProperty("/isBusy", true);
                var OpportunitiesBaseUrl = this._getLSRuntimeBaseURL(self);
                var sFilterUrl = `$expand=to_dataowner,to_ete,to_leads,to_rba,to_time,to_trtry&$top=500&$orderby=EmployeeName ASC&search=${sUserId}&$filter=RecStatus eq 'all'`;
                jQuery.ajax({
                    url: `${OpportunitiesBaseUrl}/sap/opu/odata/sap/YROSTER_SRV;v=0002/YC_OR_T_EMP_LIST?${sFilterUrl}`,
                    dataType: "json",
                    method: "GET",
                    success: function (response) {
                        var oData = response.d.results[0];
                        var OREModel = self.OREModel;
                        OREModel.setData(oData);
                        OREModel.setProperty("/isBusy", false);
                        self.getView().byId("SimpleForm").setBusy(false);
                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    },
                });
            },
            getTerritoryMasterData: function (appView,isComponentScope) {
                const OpportunitiesBaseUrl = this._getLSRuntimeBaseURL(appView,isComponentScope);
                const sUrl = `/YC_OR_M_TRTRYPC`;
                const that=this;
                sap.ui.core.BusyIndicator.show();
                jQuery.ajax({
                     async: false,
                     url: `${OpportunitiesBaseUrl}/sap/opu/odata/sap/YROSTER_SRV;v=0002/${sUrl}`,
                    dataType: "json",
                    method: "GET",
                    success: function (response) {
                       // sap.ui.core.BusyIndicator.hide();
                        appView.getModel("territoriesPFCMaster").setData(response.d.results);
                    }.bind(this),
                    error: function (oError) {
                        sap.ui.core.BusyIndicator.hide();
                        ErrorHandle.setErrorMessage(oError, self);
                        return;
                    },
                });
            },
              /**Git 181 (SalesOrg + SalesOffice mapping)
             * Retrieves the profit center master data from the specified endpoint.
             *
             * @param {Object} self - The current context or controller instance.
             * @param {string} sPFCUrlEndPoint - The endpoint URL for fetching profit center data.
             * @param {Function} fnSuccess - Callback function to be executed on successful data retrieval.
             * @param {Object} oUrlParams -  Optional URL parameters that may be used to filter or modify the request.
             * @param {boolean} bNoDefaultProfitCenter - Flag indicating whether to ignore the default profit center.
             * @param {boolean} bIsForward - Flag indicating whether the request is for a forward operation.
             */
          _getProfitCenterMasterData:async function(self,sPFCUrlEndPoint,fnSuccess,oUrlParams,bNoDefaultProfitCenter,bIsForward,sEngagementType){
                //profit center master data call LS system
                const oResourcesSystemModel = this.systemLSDataModel(appView),
                    that = this;
                var data
                try {
                    if (appView.getOwnerComponent().getModel("mrrAppEngModel").getProperty("/previousServiceCallResponses")) {
                        if (appView.getOwnerComponent().getModel("mrrAppEngModel").getProperty("/previousServiceCallResponses").get(sPFCUrlEndPoint + JSON.stringify(oUrlParams))) {
                            data = appView.getOwnerComponent().getModel("mrrAppEngModel").getProperty("/previousServiceCallResponses").get(sPFCUrlEndPoint + JSON.stringify(oUrlParams))
                        } else {
                            data = await this._callGETOdata(oResourcesSystemModel, sPFCUrlEndPoint, oUrlParams)
                            var mPrevServiceCallRespMap = appView.getOwnerComponent().getModel("mrrAppEngModel").getProperty("/previousServiceCallResponses")
                            mPrevServiceCallRespMap.set(sPFCUrlEndPoint + JSON.stringify(oUrlParams), data)
                            appView.getOwnerComponent().getModel("mrrAppEngModel").setProperty("/previousServiceCallResponses", mPrevServiceCallRespMap)
                        }
                    } else {
                        data = await this._callGETOdata(oResourcesSystemModel, sPFCUrlEndPoint, oUrlParams)
                        var mPrevServiceCallRespMap = new Map()
                        mPrevServiceCallRespMap.set(sPFCUrlEndPoint + JSON.stringify(oUrlParams), data)
                        appView.getOwnerComponent().getModel("mrrAppEngModel").setProperty("/previousServiceCallResponses", mPrevServiceCallRespMap)
                    }
                    sap.ui.core.BusyIndicator.hide();
                    let aDefaultProfitCenter,
                        oFinalProfitCenter;
                    //set default profit center 
                    if(oUrlParams && oUrlParams["$filter"].includes("IsDefault")) {
                        aDefaultProfitCenter = data.results.length ? data.results : [];
                    }else{
                        aDefaultProfitCenter = data.results.filter(item => item.IsDefault).length ? data.results.filter(item => item.IsDefault) : [];
                    }
                    if (!bNoDefaultProfitCenter && aDefaultProfitCenter.length) {
                        const oProfitCenter = that._setProfitCenterObj(aDefaultProfitCenter[0], true);
                        oFinalProfitCenter = { "TempProfitCenter": { "Territories": [oProfitCenter] }, "filteredProfitCenter": [oProfitCenter] }
                        if(!aDefaultProfitCenter[0].isPC_Selectable || !aDefaultProfitCenter[0].isPC_Viewable) {
                            //ignore selected profit center if isPC_Viewable or isPC_Selectable is disabled
                            oFinalProfitCenter = { "TempProfitCenter": { "Territories": [] }, "filteredProfitCenter": [] }
                        }
                    } else {
                        oFinalProfitCenter = { "TempProfitCenter": { "Territories": [] }, "filteredProfitCenter": [] }
                    }

                    appView.getView().getModel("selectedProfitCenter").setData(oFinalProfitCenter);
                    appView.getView().getModel("selectedProfitCenter").refresh()
                    // if (!appView.getOwnerComponent().getModel("territoriesPFCMaster").getData().length) {
                    appView.getOwnerComponent().getModel("territoriesPFCMaster").setData(data.results);
                    appView.getView().getModel("territoriesMaster").setData(data.results);
                    appView.getOwnerComponent().getModel("mrrAppEngModel").setProperty("/TerritoryMasterDataEngType", sEngagementType)
                    //Update profitcenter masterdata
                    that._setSalesOrgProfitCenter(self, bIsForward);
                    if (!bIsForward) {
                        //only for create request
                        //ignore for managerpage forward
                        //update default profitcenter model
                        that.getFilteredSalesOrgProfitCenter(self);
                    }
                    if(fnSuccess){
                        return fnSuccess();
                    }
                }catch(oError) {
                    sap.ui.core.BusyIndicator.hide();
                    if(appView.onCloseBusyDialog){
                        appView.onCloseBusyDialog();
                        sap.ui.core.BusyIndicator.hide();
                    }
                    ErrorHandle.setErrorMessage(oError, appView);
                }

            },
 
             /**Git 181 (SalesOrg + SalesOffice mapping)
             * Set the profit center object based on the provided element and territory flag.
             *
             * @param {Object} element - The element containing profit center data set.
             * @param {boolean} bTerritory - Flag indicating if the context is related to a profitcenter master data or default profit center.
             * @returns {Object} - The constructed profit center object with relevant properties.
             */
          _setProfitCenterObj:function(element,bTerritory){
                const Guid =  bTerritory? element.TrpcGuid :  element.guid;
                const Desc = bTerritory ? element.TrpcDesc :  element.TrpcDesc;
                const TrpcL1Desc = bTerritory ? element.TGlobal : element.TrpcL1Desc;
                const TrpcL2Desc = bTerritory ? element.Region :  element.TrpcL2Desc;
                const TrpcL3Desc =bTerritory ? element.Mu :element.TrpcL3Desc;
                const TrpcL4Desc = bTerritory? element.MuBelow : element.TrpcL4Desc;
                const TrpcId = bTerritory ? element.TrpcId :  element.id;
                const IsPrimary = bTerritory ? element.IsPrimary : false;
                const GrpSelectable = bTerritory ? element.GRP_Selectable : element.GrpSelectable;
                const ParentGroupSelectable =  element.ParentGroupSelectable;
               
                let sSelectedDesc = "";

                if (TrpcL1Desc && TrpcL1Desc !== "") {
                    sSelectedDesc += TrpcL1Desc;

                    if (TrpcL2Desc && TrpcL2Desc !== "") {
                        sSelectedDesc += " > " + TrpcL2Desc;

                        if (TrpcL3Desc && TrpcL3Desc !== "") {
                            sSelectedDesc += " > " + TrpcL3Desc;

                            if (TrpcL4Desc && TrpcL4Desc !== "") {
                                sSelectedDesc += " > " + TrpcL4Desc;
                            }
                        }
                    }
                }
                return {
                    Desc: Desc,
                    desc:Desc,
                    SelectedDesc: sSelectedDesc,
                    SelectedGuid:Guid,
                    TrpcL1Desc:  TrpcL1Desc,
                    TrpcL2Desc: TrpcL2Desc,
                    TrpcL3Desc:  TrpcL3Desc,
                    TrpcL4Desc:TrpcL4Desc,
                    TrpcId: TrpcId,
                    guid:Guid,
                    isResourceProfile:element.isResourceProfile,
                    isCheckBox:bTerritory ?element.isPC_Selectable : element.isCheckBox,
                    isParentNodeEnable:element.isParentNodeEnable,
                    isChildNodeEnable:element.isChildNodeEnable,
                    GrpSelectable: GrpSelectable,
                    ParentGroupSelectable:ParentGroupSelectable
                };
            },
              /**Git 181 (SalesOrg + SalesOffice mapping)
             * Retrieves the Sales Organization Profit Center details.
             *
             * @param {Object} self - The current context or controller instance.
             * @param {boolean} isComponentScope - Flag indicating whether the scope is at the component level.
             * This function only reponsible for legacy to map profit center and sales org
             */
            getSalesOrgProfitCenter: function (self,isComponentScope){
                //sales org mapping for old requests or legacy
                const sBaseUrl = this._getWfServiceRuntimeBaseURL(self,isComponentScope);
                    const that = this;
                    jQuery.ajax({
                        async: false,
                        contentType: "application/json",
                        url: `${sBaseUrl}/ore-api-/SOrg_PC_Map`,
                        type: "GET",
                        success: function (response) {
                            const oValue = response.value;
                            self.getModel("PCSalesOrgMasterData").setData(oValue);
                        }.bind(this),
                        error: function (oError) {
                            sap.ui.core.BusyIndicator.hide();
                            ErrorHandle.setErrorMessage(oError, self);
                        }
                    });
            },
              /**Git 181 (SalesOrg + SalesOffice mapping)
             * Fetches the details of a specific opportunity based on the provided opportunity ID.
             *
             * @param {Object} appView - The application view instance that contains the context for the operation.
             * @param {string} oppId - The unique identifier of the opportunity id whose details are to be fetched.
             * @param {Object} oUrlParams - Optional URL parameters that may be used to filter or modify the request.
             * @param {Function} fnSuccess - Callback function to be executed upon successful retrieval of opportunity details.
             */
            _getMyOpportunityDetails:function(appView,oppId,oUrlParams,fnSuccess){
                //opportunity details service call
                const oResourcesSystemModel = this.systeminticDataModel(appView);
                this._callGETOdata(oResourcesSystemModel, `/Opportunities('${oppId}')`, oUrlParams).
                then(function (data) {
                    sap.ui.core.BusyIndicator.hide();
                    return fnSuccess(data,appView,true);
                })
                .catch(function (oError) {
                    sap.ui.core.BusyIndicator.hide();
                    ErrorHandle.setErrorMessage(oError, appView);
                });
            },
            
              /**
             * Sets the profit center for the sales organization based on the provided context.
             *
             * @param {Object} self - The current context or controller instance.
             * @param {boolean} isManagerPage - A flag indicating whether the current view is the manager page.
             *
             * This function processes the sales organization profit center data and updates the relevant models
             * depending on whether the view is in manager(Forward) mode or not. It handles the logic for setting
             * the profit center based on the current view context.
             */
            _setSalesOrgProfitCenter:function(self,isManagerPage){
                const aTerritories = appView.getView().getModel("territoriesMaster").getData();
                const that = this;
                aTerritories.map(function (element) {
                    element.isCheckBox = element.isPC_Selectable ? true : false;
                        element.isFiltered = true;
                });
                appView.getOwnerComponent().getModel("territoriesPFCMaster").refresh();
                    if (!isManagerPage) {
                    that.getFilteredSalesOrgProfitCenter(self);
                    }
                    if(isManagerPage){
                    //Git 181
                    //Set profitcenter model
                    appView.getView().getModel("territoriesMaster").setData(aTerritories);
                    self.getView().getModel("territoriesMaster").setData(aTerritories);
                    self.getView().getModel("territoriesMaster").refresh();
                    appView.getView().getModel("territoriesMaster").refresh();
                }
            },
             /**Git 181 (SalesOrg + SalesOffice mapping)
             * Retrieves and filters the Sales Organization Profit Center based on the current view context.
             *
             * @param {Object} self - The current context or controller instance.
             * @param {boolean} isDetailView - A flag indicating whether the current view is a detail view.
             *
             * This function processes the selected profit center for the create request.
             * It updates the relevant models and refreshes the data displayed in the UI.
             */

            getFilteredSalesOrgProfitCenter:function(self,isDetailView){
                const oModel = !isDetailView ? appView.getView().getModel("selectedProfitCenter") :
                appView.detailViewScreen.getView().getModel("employee");
            const oFinalData = oModel.getData();
       
                if(!isDetailView){
                    let oPfcListModel = new sap.ui.model.json.JSONModel(oFinalData);
                    self.getView().setModel(oPfcListModel, "selectedProfitCenter");
                    self.getView().getModel("selectedProfitCenter").setProperty("/selectedPfc",oFinalData.TempProfitCenter.Territories[0]);
                }else if(oFinalData.TempProfitCenter.Territories.length && oFinalData.TempProfitCenter.Territories[0].isResourceProfile){
                    appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/TempProfitCenter",oFinalData.TempProfitCenter);
                    appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/selectedPfc",oFinalData.TempProfitCenter.Territories[0]);
                }else if(isDetailView){
                    let oPfcObj = { "TempProfitCenter": { "Territories": [] }, "filteredProfitCenter": [] }
                    appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/TempProfitCenter",oPfcObj.TempProfitCenter);
                    appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/selectedPfc","");
                }
                oModel.refresh(true);
                appView.oFinalData.oppDefaultSalesOrg = appView.bIsSelectOppVal ? oFinalData:{ "TempProfitCenter": { "Territories": [] }, "filteredProfitCenter": [] };
            },
            getManagerPageFilteredSalesOrgProfitCenter:function(self,sSalesOrgNumber,sOrgType){
                const that = this;
                const oModel = self.getView().getModel("selectedProfitCenter");
                //git 181
                //filter selected profit center for manager page forward
                const oSalesOrgMappingModelData =  self.getOwnerComponent().getModel("territoriesPFCMaster").getData();
                let aTempTerritory =[],
                aFilteredArray=oSalesOrgMappingModelData.filter(obj=> obj.TrpcGuid == sSalesOrgNumber),
                oProfitCenter,
                oFinalData;
                if(aFilteredArray.length){
                    oProfitCenter = that._setProfitCenterObj(aFilteredArray[0], true);
                    aTempTerritory.push(oProfitCenter);
                    oFinalData = { "TempProfitCenter": { "Territories": [aTempTerritory[0]] }, "filteredProfitCenter": aTempTerritory }
				}else{
                    oFinalData = { "TempProfitCenter": { "Territories": [] }, "filteredProfitCenter": [] }
                }
        
                oModel.setData(oFinalData);
                oModel.refresh(true);
                let oPfcListModel = new sap.ui.model.json.JSONModel(oFinalData);
                self.getView().setModel(oPfcListModel, "selectedProfitCenter");
				self._setResourceProfileData(self);
				self.getView().getModel("profileViewParameters").setProperty("/isProfitCenterInputVisible",true);
				self.getView().getModel("profileViewParameters").refresh(true);
    
		  },
            _setErrorMsgPopOver:function(appView,sTitle,oError,isPromise){
                appView.onCloseBusyDialog();
                const oErrorModel =  appView.getView().getModel("errorMsgModel");
                const sErrorMsg = ErrorHandle.setErrorMessage(oError, appView,true);
                const si18nPFC = this._getI18nText(appView,sTitle);
                const si18nError = this._getI18nText(appView,"errors");
                appView.getView().byId("idNotificationBadgedButton").setVisible(true);
                appView.getView().getModel("createReqFooterModel").setProperty("/footerButtons/errorBtnType","Negative");
                appView.getView().getModel("createReqFooterModel").setProperty("/footerButtons/errorBtnIcon","sap-icon://error");
                appView.getView().getModel("createReqFooterModel").refresh();
                if (oErrorModel.getData().errorInformation && oError !== "Complete") {
                    oErrorModel.getData().errorInformation.push({
                        "title": si18nPFC,
                        "error": sErrorMsg
                    });
                    oErrorModel.getData().errorInformation = oErrorModel.getData().errorInformation.filter((value, index) => {
                        const _value = JSON.stringify(value);
                        return index === oErrorModel.getData().errorInformation.findIndex(obj => {
                            return JSON.stringify(obj) === _value;
                        });
                    });
                    oErrorModel.setProperty("/count", oErrorModel.getData().errorInformation.length);
                    oErrorModel.setProperty("/errorPriority", "High");
                    oErrorModel.setProperty("/errorHeader",`${si18nError}`);
                }
                oErrorModel.refresh(true);
                if (!isPromise) {
                    appView._onOpenErrorPopOver();
                }
            },
            _resetErrorPopOver:function(appView){
                const oErrorModel =  appView.getView().getModel("errorMsgModel");
                appView.getView().byId("idNotificationBadgedButton").setVisible(false);
                oErrorModel.setProperty("/errorInformation",[]);
            },
            _getI18nText:function(self,sText){
                const i18nModel = self.getOwnerComponent().getModel("i18n").getResourceBundle();
                return i18nModel.getText(sText);
            },
         
            getMyOpportunitiesIO: function (self ,oOppId,processContext,taskId,currentDecision){
                const OpportunitiesBaseUrl = this._getOpportunitiesRuntimeBaseURL(self);
                const sI18nOppText =  self.getOwnerComponent().getModel("i18n").getResourceBundle().getText("oppBusyIndicatorText");
                self?.common?._OpenBusyIndicator(self,sI18nOppText);
                let that = this;
                jQuery.ajax({
                    url: `${OpportunitiesBaseUrl}/sap/opu/odata/sap/zharmony_callidus_srv/Opportunities('${oOppId}')?$expand=Notes,PartiesInvolved,DQReview,Attributes,CloseplanActivities,DocFlow,Attachments,Items,Pricing,RevenueSplitPlanH,RevenueSplitPlanI,SalesTeamWF,CustomerIncentive,S2SActivities,S2SActivities/PartiesInvolved,S2SActivities/Goals,RenewalExecution`,
                    dataType: 'json',
                    async: processContext !== "ioFetch" ? false:true,
                    method: "GET",
                    success: function (data,textStatus, jqXHR){
                        if (self && self.getView().getModel()) {
                            self.getView().getModel().setProperty("/OPP_DATA", data);
                        }
                        if(processContext !== "ioFetch") {
                            self.INTERNAL_ORDER1 = data.d.INTERNAL_ORDER1;
                            self.INTERNAL_ORDER2 = data.d.INTERNAL_ORDER2;
                            let aInternalOrder = [];
                            data.d.INTERNAL_ORDER1 = data.d.INTERNAL_ORDER1 ? Number(data.d.INTERNAL_ORDER1) : "";
                            data.d.INTERNAL_ORDER2 = data.d.INTERNAL_ORDER2 ? Number(data.d.INTERNAL_ORDER2) : "";
                            data.d.INTERNAL_ORDER1 ? aInternalOrder.push(data.d.INTERNAL_ORDER1) : false;
                            data.d.INTERNAL_ORDER2 ? aInternalOrder.push(data.d.INTERNAL_ORDER2) : false;
                            let OppDetails = {
                                STATUS: data.d.STATUS,
                                CURR_PHASE: data.d.CURR_PHASE,
                                STATUS_DESC: formatter.getOppState(data.d.STATUS),
                                CURR_PHASE_DESC: formatter.getCurrentPhase(data.d.CURR_PHASE),
                                CLOSE_DATE: formatter._setDateFormat(data.d.EXPECT_END),
                                Opp_Sales_Office: data.d.SALES_OFFICE_TEXT,
                                Opp_Partner: data.d.PARTNER_NAME,
                                Opp_SalesGroupName: data.d.SALES_GROUP_TEXT,
                                Opp_InternalOrder: aInternalOrder.length ? aInternalOrder.toString() : "",
                                Opp_SalesOrg_Name: processContext.NewOppDetails ? processContext.Opp_SalesOrg_Name : "",
                                Executive_Summary: data.d.Notes.results.length ? data.d.Notes.results[0]["CONC_LINES"] : "",
                                forecast: data.d.FORECAST,
                                cloudRevenue: data.d.CLOUD_REVENUE,
                                currency: data.d.CURRENCY,
                                TCV: data.d.Items.results.length ? data.d.Items.results[0].TOTAL_TCV : "",
                                onPremRevenue: data.d.LICENSE_REVENUE,
                                accName: data.d.ACCOUNT_NAME,
                                accountId: data.d.ACCOUNT,
                                oppName: data.d.DESCRIPTION,
                                OPPT_ID: data.d.OPPT_ID
                            };
                            //process Attributes
                            const aAttributes = data.d.Attributes.results;
                            for (let i = 0; i < aAttributes.length; i++) {
                                switch (aAttributes[i].ATTR_CODE) {
                                    case "AS0103":
                                        OppDetails.compelEventQual = aAttributes[i].ATTR_VALUE;
                                        break;
                                    case "AS0104":
                                        OppDetails.fundingQual = aAttributes[i].ATTR_VALUE;
                                        break;
                                    case "AS0105":
                                        OppDetails.custStakeQual = aAttributes[i].ATTR_VALUE;
                                        break;
                                    case "AS0106":
                                        OppDetails.custChallengesQual = aAttributes[i].ATTR_VALUE;
                                        break;
                                    case "AS0107":
                                        OppDetails.custBusDriversQual = aAttributes[i].ATTR_VALUE;
                                        break;
                                    case "AS0108":
                                        OppDetails.solutionQual = aAttributes[i].ATTR_VALUE;
                                        break;
                                    case "AS0109":
                                        OppDetails.competitorsQual = aAttributes[i].ATTR_VALUE;
                                        break;
                                    case "AS0110":
                                        OppDetails.partnersQual = aAttributes[i].ATTR_VALUE;
                                        break;
                                    case "AS0132":
                                        OppDetails.decision = aAttributes[i].ATTR_VALUE;
                                        break;
                                    case "AS0133":
                                        OppDetails.reviewerName = aAttributes[i].ATTR_DESCR;
                                        break;
                                    case "AS0134":
                                        OppDetails.reviewDate = new Date(aAttributes[i].ATTR_VALUE.slice(0, 4) + "-" + aAttributes[i].ATTR_VALUE.slice(4, 6) + "-" +
                                            aAttributes[i].ATTR_VALUE.slice(-2));
                                        break;
                                    default:
                                }
                            }

                            OppDetails.attributes = aAttributes;
                            processContext !== "oppInfoPopOver" ? self.getView().getModel("multiReqModel").setProperty("/NewOppDetails", OppDetails) :
                                self.getView().getModel("oppInfoPopOverModel").setData(OppDetails);
                            self.getView().getModel("multiReqModel");
                            if(processContext === "oppInfoPopOver"){
                                self.getView().getModel("oppInfoPopOverModel").setProperty("/Opp_SalesOrg_Name",data.d.SALES_ORG_TEXT);
                                const ointicSystemModel = that.systeminticDataModel(self);
                                that._callGETOdata(ointicSystemModel, `/BusinessPartnerAttribSet('${data.d.ACCOUNT}')`)
                                    .then(function (data) {
                                        const IAC = data.TG_ACCOUNT_DESC ? data.TG_ACCOUNT_DESC.trim() : "";
                                        self.getView().getModel("oppInfoPopOverModel").setProperty("/iacOppVal",IAC);
                                        if(self.oOppInfoPopOver){
                                            self.oOppInfoPopOver.setBusy(false);
                                        }
                                      
                                    }.bind(self))
                                    .catch(function (error) {
                                          if(self.oOppInfoPopOver){
                                            self.oOppInfoPopOver.setBusy(false);
                                        }
                                          ErrorHandle.setErrorMessage(oError, self,false,true);
                                    });
                            }
                            if (processContext !== "oppInfoPopOver" && processContext) {
                                     self._fnTriggerFinalSubmitCall(processContext, taskId, currentDecision, self)
                            }
                        }else{
                            self.getView().getModel().setProperty("/INTERNAL_ORDER1", data.d.INTERNAL_ORDER1);
                            self.getView().getModel().setProperty("/INTERNAL_ORDER2", data.d.INTERNAL_ORDER2);
                            if(data.d.Items.results && data.d.Items.results.length){
                                data.d.Items.results.forEach(function (item) {
                                        switch ( item.SA_LEVEL_4 || item.SA_LEVEL_3 || item.SUB_SOLUTION_AREA || item.SOLUTION_AREA ) {
                                        case item.SA_LEVEL_4:
                                            item.final_soln_area = item.SA_LEVEL_4
                                            break;
                                        case item.SA_LEVEL_3:
                                            item.final_soln_area = item.SA_LEVEL_3
                                            break;
                                        case item.SUB_SOLUTION_AREA:
                                            item.final_soln_area = item.SUB_SOLUTION_AREA
                                            break;
                                        case item.SOLUTION_AREA:
                                            item.final_soln_area = item.SOLUTION_AREA
                                            break;
                                        default:
                                        item.final_soln_area = ""
                                    }

                                })
                            }
                            let aOppTeam = data.d?.PartiesInvolved?.results ?? [];
                            self.getView().getModel().setProperty("/OPP_TEAM",aOppTeam);
                            self.getView().getModel().setProperty("/OPP_SOLN_AREA", data.d.Items.results);
                            self.getView().getModel().refresh();
                            let aSapMessage = [];
                            if (jqXHR.getResponseHeader && jqXHR.getResponseHeader("sap-message")) {
                                //opportunity error details
                                const sResponseHeaderString = jqXHR.getResponseHeader("sap-message");
                                const oSapMessage = jQuery.parseJSON(sResponseHeaderString);
                                //push only error notification
                                aSapMessage = oSapMessage.details.filter(item => item.severity === "error");
                                if(oSapMessage.severity === "error" && oSapMessage.message){
                                    aSapMessage.unshift({
                                        message:oSapMessage.message,
                                        severity:oSapMessage.severity 
                                    });
                                }
                            }
                            //set opportunity error model
                            self.getView().getModel().setProperty("/OPP_ERROR",aSapMessage);
                        }
                           self?.common?._closeBusyIndicator(self);
                    }.bind(this),
                    error: function (oError) {
                      //  self._closeBusyIndicator(self);
                        self.getView().setBusy(false);
                        self?.common?._closeBusyIndicator(self);
                        ErrorHandle.setErrorMessage(oError, self,false,true);
                    }
                });
            },
            getfnFetchNewOREData: function (self, sUserId) {
                var OpportunitiesBaseUrl = this._getLSRuntimeBaseURL(self);
                var sUrl = `/YC_OR_T_MR_PRSONSPRO?$filter=Id eq '${sUserId}'`;
                jQuery.ajax({
                    url: `${OpportunitiesBaseUrl}/sap/opu/odata/sap/YROSTER_SRV;v=0002/${sUrl}`,
                    dataType: "json",
                    method: "GET",
                    success: function (response) {
                        var oData = response.d.results[0];
                        var OREModel = self.OREModel;
                        OREModel.setProperty("/data", oData);
                        OREModel.setProperty("/isBusy", false);
                        self.getView().byId("SimpleForm").setBusy(false);
                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    },
                });
            },
            //get manager-level
            getManagerLevel: function (appView,isComponentScope) {
                const sBaseUrl = this._getLSRuntimeBaseURL(appView,isComponentScope);
                const sUrl = `YC_DS_M_MANAGER_LVL`;
                const that = this;
                jQuery.ajax({
                     async: true,
                    url: `${sBaseUrl}/sap/opu/odata/sap/YROSTER_SRV;v=0002/${sUrl}`,
                    dataType: "json",
                    method: "GET",
                    success: function (response) {
                        // appView.getView().getModel("managerLevelMasterData").setData(response.d.results);
                        appView.getModel("managerLevelMasterData").setData(response.d.results);
                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    },
                });
            },
            getResourceProfileMasterData: function (oEntity,appView,sText,isPromise) {
                const sBaseUrl = this._getLSRuntimeBaseURL(appView);
                const that = this;
                return new Promise((resolve, reject) => {
                    jQuery.ajax({
                        async: false,
                       url: `${sBaseUrl}/sap/opu/odata/sap/YROSTER_SRV;v=0002/${oEntity}`,
                       dataType: "json",
                       method: "GET",
                       success: function (response) {
                        switch (oEntity) {
                            case "YC_OR_M_CROSSCVRG":
                                appView.getView().getModel("crossCvgMasterData").setData(response);
                                break;
                            case "YC_OR_M_BA_LOB":
                                appView.getView().getModel("baLoBMasterData").setData(response);
                                break;
                            case "YC_OR_M_BA_INDUSTRY":
                                appView.getView().getModel("baIndMasterData").setData(response);
                                break;
                            default:
                                resolve(response);
                                break;
                            }
                       }.bind(this),
                       error: function (oError) {
                        that._setErrorMsgPopOver(appView,sText,oError,isPromise);
                        if(oEntity !== "YC_OR_M_CROSSCVRG" && oEntity !== "YC_OR_M_BA_LOB"  && oEntity !== "YC_OR_M_BA_INDUSTRY" ){
                            reject(oError)
                        }
                           
                       },
                   });
                  })
                
            },
        //presales manager section
        systemISPDataModel: function (self) {
            //set oData model for ISP
            const componentName = self.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
            const componentPath = sap.ui.require.toUrl(componentName);
            const oDataModel = new ODataModel({
                serviceUrl: `${componentPath}/intis/sap/opu/odata/sap/ZSTAFFING_APP_2_SRV`
            });
            return oDataModel;
        },
        _getActExpData:function(oController){
            //get actExp data - Staffing purpose
            const oStaffingModel = this.systemISPDataModel(oController);
            oStaffingModel.setUseBatch(false);
            oStaffingModel.read("/DdlbValues", {
                success: function (data) {
                    const  oActivityModel = new JSONModel(data);
                    oController.getView().setModel(oActivityModel, "ddlbModelActexp");
                },
                error: function (oError) {
                    ErrorHandle.setErrorMessage(oError, oController);
                }
            });
        },
        	//get io owner details
		_getIOOwnerDetails:function(oController,sInternalOrder){
			//get task level 
			const oStaffingModel = this.systemISPDataModel(oController);
			const iInternalOrder = Number(sInternalOrder);
			const that = this;
			oStaffingModel.setUseBatch(false);
			oStaffingModel.read('/InternalOrderHeaderSet', {
				urlParameters: {
					'$filter': `(Aufnr eq '${iInternalOrder}' and Logsystem eq 'CRM_MTR')`
				}, 
				success: function (data) {
					if(data.results.length){
						const ioOwnerId = data.results[0].Zzverakuid;
						that._callEmployeeService(ioOwnerId, 100, 0, oController, false,true);
					}
				
				},
				error: function (oError) {
					ErrorHandle.setErrorMessage(oError, oController);
				}
			});

		},
        _getTaskLevelSet:function(oController,Vbeln){
            //get task level 
            const oStaffingModel = this.systemISPDataModel(oController);
            oStaffingModel.setUseBatch(false);
            oStaffingModel.read('/TaskLevelValueSet', {
                urlParameters: {
                    '$filter': `Vbeln eq '${Vbeln}' and CostObjType eq 'IO' and Posnr eq '000000'`
                }, 
                success: function (data) {
                    const oTaskLevelModel = new JSONModel(data);
                    oController.getView().setModel(oTaskLevelModel, "TaskLevelDdlb");
                },
                error: function (oError) {
                    ErrorHandle.setErrorMessage(oError, oController);
                }
            });

        },
        _postStaffingDetails:function(aPayload,oController,fnSuccess,fnError){
            //POST staffing request
            const oStaffingModel = this.systemISPDataModel(oController)
            oStaffingModel.setUseBatch(true);
            const aDeferredGroup = oStaffingModel.getDeferredGroups().push("ReqCreate");
            oStaffingModel.setDeferredGroups(aDeferredGroup);
            const that = this;
            this.aPostedReq = [];
            aPayload.forEach(function(payload){
                oStaffingModel.create("/ReqDetails", payload,{
                    groupId: "ReqCreate",
                    success: function (oData, oResponse) {
                        that.aPostedReq.push(oResponse);
                        if (that.aPostedReq.length === aPayload.length) {
                            return fnSuccess(oResponse, oController)
                        }
                    },
                    error: function (oError) {
                        that.aPostedReq.push(oError);
                        that.aPostedReq = [];
                        return fnError(oError, oController)
                    }
                })
            });
            oStaffingModel.submitChanges();
        },
        _callUserSearchHelps:function(sUserId,oController,fnSuccess,fnError,oAssignmentContext){
            //call userSearchHelps to get perner no
            const sRooturl = this._getRuntimeBaseURL(oController) + "/intis";
            jQuery.ajax({
                async: false,
                dataType: 'json',
                url: `${sRooturl}/sap/opu/odata/sap/ZSTAFFING_APP_2_SRV/UserSearchHelps?$filter=uname eq '${sUserId}'`,
                type: "GET",
                success: function (oData) {
                    return fnSuccess(oData,oController,oAssignmentContext);

                }.bind(this),
                error: function (oError) {
                    return fnError(oError,oController,oAssignmentContext);
                }
            });

        },
        _callEmployeeService: function (sUser, topValue, skipValue, oController,oList,isIoOwner) {
            //sap employee service api to get employee details
            const sBaseEmployeeServiceurl = this._getRuntimeBaseURL(oController) + "/sapit-employee-data";
            jQuery.ajax({
                contentType: "application/json",
                async: false,
                type: "GET",
                url: `${sBaseEmployeeServiceurl}/Employees?$count=true&$search="${sUser}"&$skip=${skipValue}&$top=${topValue}`,
                success: function (response) {
                    const oIoOwnerData = new JSONModel(response);
                    if (!isIoOwner) {
                        //trigger for io owner search dialog
                        oList.setBusy(false);
                        oController.getView().setModel(oIoOwnerData, "ioOwnerModel");
                    }else{
                        oController.getView().getModel("ioOwnerDetails").setData(response.value);
                    }
                }.bind(this),
                error: function (oError) {
                    if (!isIoOwner) {
                        oList.setBusy(false);
                    }
                    ErrorHandle.setErrorMessage(oError, self);
                }
            });
        },
        _CallautoStaffingAPI: function (sUser, topValue, skipValue, oController,sSalesOrg,token) {
            const sBaseEmployeeServiceurl = this._getRuntimeBaseURL(oController) + "/sapit-employee-data";
            const salesOrg = sSalesOrg;
            //employee service call to get compnay code and cost center
            jQuery.ajax({
                contentType: "application/json",
                async: false,
                type: "GET",
                url: `${sBaseEmployeeServiceurl}/Employees?$count=true&$search="${sUser}"&$skip=${skipValue}&$top=${topValue}`,
                success: function (response) {
                    const sCostCenterID = response.value[0].costCenter.ID;
                    const sCompanyCode = response.value[0].company.ID;
                    oController.sCompanyCode = sCompanyCode;
                    oController.sCostCenter = sCostCenterID;
                    const sBaseISPurl = this._getRuntimeBaseURL(oController) + "/intis";
                    oController.sCompanyCode = sCompanyCode;
                    if(token){
                        token.sCompanyCode = sCompanyCode;
                        token.sCostCenter = sCostCenterID;
                    }
                    //auto staffing /ZsolccApiSet call to check for auto staffing
                    jQuery.ajax({
                        contentType: "application/json",
                        dataType: 'json',
                        async: false,
                        type: "GET",
                        url: `${sBaseISPurl}/sap/opu/odata/sap/ZSTAFFING_APP_2_SRV/ZsolccApiSet(Bukrs='${salesOrg}',Kostl='${sCostCenterID}')`,
                        success: function (response) {
                            let bAutoStaffingFlag = response.d.Zflag;
                            const sMessage = response.d.Zmsg
                            if (sMessage === "Record exists in ZSOL_CC") {
                                //auto staffing => true
                                bAutoStaffingFlag = true;
                            }
                            if(token){
                                token.isAutoStaffing = bAutoStaffingFlag;
                            }

                        }.bind(this),
                        error: function (oError) {
                            try {
                                if (oError.responseJSON.error.message.value === "Record does not exists in ZSOL_CC") {
                                    if(token){
                                        //auto staffing => false
                                        token.isAutoStaffing = false;
                                    }
        
                                }
                            } catch (err) {
                                ErrorHandle.setErrorMessage(oError, oController);
                            };
                        }
                    });

                }.bind(this),
                error: function (oError) {
                    ErrorHandle.setErrorMessage(oError, oController);
                    return false;

                }
            });
        },
        _callExceptionTable: function (burks, Kostl, sResEngagementType, sSalesOrg,sUserId,oController,fnSuccess,fnError,oAssignmentContext) {
            //check data(salesOrg,costCenter,userId,companyCode) maintained in exception table for staffing
            const sRooturl = this._getRuntimeBaseURL(oController) + "/cap";
            jQuery.ajax({
                async: false,
                contentType: "application/json",
                url: `${sRooturl}/resources/IOStaffException?$filter=bukrs eq '${burks}' and sorg eq '${sSalesOrg}' and eng_type_ID eq '${sResEngagementType}' and zflag eq 'X'`,
                type: "GET",
                success: function (oData) {
                    return fnSuccess(oData,oController,oAssignmentContext);
 
                }.bind(this),
                error: function (oError) {
                    return fnError(oError,oController,oAssignmentContext);
                }
            });
 
        },
        //get IO owner from ISP table
        _getIoOwnerData:function(oController,iInternalOrder){
            const sRooturl = this._getRuntimeBaseURL(oController) + "/cap";
            const that = this;
            jQuery.ajax({
                async: false,
                contentType: "application/json",
                url: `${sRooturl}/req-area-api-/InternalOrder?$filter=internalOrder eq '${iInternalOrder}'`,
                type: "GET",
                success: function (data) {
                    if(data.value.length){
                        const sUserId = data.value[0].io_Owner;
                        that._callEmployeeService(sUserId, 100, 0, oController, false,true);
                    }
                }.bind(this),
                error: function (oError) {
                    ErrorHandle.setErrorMessage(oError, oController);
                }
            });
        },
         //Save Draft
         postSaveDraftFormDetails: function (appView,oPayload,sServiceEndPoint,sMethod) {
            const sBaseUrl = this._getWfServiceRuntimeBaseURL(appView);
            const that = this;
            const sGetTokenUrl = (sServiceEndPoint === "DF_WFIns_Parent") ? "DF_WFIns_Parent":"DF_WFIns";
            $.ajax({
                url: `${sBaseUrl}/ore-api-/${sGetTokenUrl}`,
                async: true,
                method:"GET",
                headers: {
                    "X-CSRF-Token": "Fetch"
                },
                success: function (result, xhr, data) {
                    var token = data.getResponseHeader("X-CSRF-Token");
                    $.ajax({
                        url: `${sBaseUrl}/ore-api-/${sServiceEndPoint}`,
                        method: sMethod,
                        async: true,
                        data: JSON.stringify(oPayload),
                        headers: {
                            "X-CSRF-Token": token,
                            "Content-Type": "application/json"
                        },
                        success: function (result, xhr, data) {
                            if(sServiceEndPoint !== "DF_WFIns_Parent"){
                                appView.getView().setBusy(false);
                                const sI18nText = that._getI18nText(appView,"draftSuccess");
                                MessageToast.show(sI18nText);
                            }
                        }.bind(this),
                        error: function (oError) {
                            appView.getView().setBusy(false);
                            ErrorHandle.setErrorMessage(oError, self);
                        }
                    });
                }.bind(this),
                error: function (oError) {
                    ErrorHandle.setErrorMessage(oError, self);
                }
            });
        },
           //delete Draft
        deleteSaveDraftFormDetails: function (appView, sServiceEndPoint, sMethod) {
            const sBaseUrl = this._getWfServiceRuntimeBaseURL(appView);
            $.ajax({
                url: `${sBaseUrl}/ore-api-/${sServiceEndPoint}`,
                method: "GET",
                async: true,
                headers: {
                    "X-CSRF-Token": "Fetch"
                },
                success: function (result, xhr, data) {
                    var token = data.getResponseHeader("X-CSRF-Token");
                    $.ajax({
                        url: `${sBaseUrl}/ore-api-/${sServiceEndPoint}`,
                        method: sMethod,
                        async: true,
                        headers: {
                            "X-CSRF-Token": token,
                            "Content-Type": "application/json"
                        },
                        success: function (result, xhr, data) {
                            // MessageToast.show("Draft saves successfully");
                        }.bind(this),
                        error: function (oError) {
                            ErrorHandle.setErrorMessage(oError, self);
                        }
                    });
                }.bind(this),
                error: function (oError) {
                    ErrorHandle.setErrorMessage(oError, self);
                }
            });
        },
        //get draft details
            getSaveDraftFormDetails: function (instanceId, fnSuccess, self, isSaveDraft) {
                const sBaseUrl = this._getWfServiceRuntimeBaseURL(appView);
                $.ajax({
                    url: `${sBaseUrl}/ore-api-/YC_dFWfins_Details?$filter=parentInstance_GUID eq '${instanceId}'`,
                    method: "GET",
                    async: false,
                    headers: {
                        "X-CSRF-Token": "Fetch"
                    },
                    success: function (result, xhr, data) {
                        $.ajax({
                            url: `${sBaseUrl}/ore-api-/DF_ReqForm_URL?$filter=WFIns_parentInstance_GUID eq '${instanceId}'`,
                            method: "GET",
                            async: false,
                            headers: {
                                "X-CSRF-Token": "Fetch"
                            },
                            success: function (urlResponse, xhr, data) {
                                 return fnSuccess(result,self,isSaveDraft,urlResponse);

                            }.bind(this),
                            error: function (oError) {
                                ErrorHandle.setErrorMessage(oError, self);
                            }
                        });

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
             //service call for MRR application related config (MRR Tab)
             getMRRAppData: function (fnSuccess, self, isComponentScope) {
                const sBaseurl = this._getWfServiceRuntimeBaseURL(self, isComponentScope);
                jQuery.ajax({
                    async: true,
                    contentType: "application/json",
                    url: `${sBaseurl}/req-area-api-/MR_App_Label`,
                    type: "GET",
                    success: function (oData) {
                        return fnSuccess(oData, self);

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            getMRREngData: function (fnSuccess, self, isComponentScope) {
                const sBaseurl = this._getWfServiceRuntimeBaseURL(self, isComponentScope);
                jQuery.ajax({
                    async: true,
                    contentType: "application/json",
                    url: `${sBaseurl}/resources/EngagementType`,
                    type: "GET",
                    success: function (oData) {
                        return fnSuccess(oData, self);
 
                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            setTasksModel: function(self, isComponentScope){
                var workflowBaseurl = this._getWfServiceRuntimeBaseURL(self, isComponentScope);
                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    url: `${workflowBaseurl}/resources/MR_UserTask`,
                    type: "GET",
                    success: function (oData) {
                        oData.value = oData.value.filter((obj1, i, arr) =>
                            arr.findIndex(obj2 => (obj2.userTask === obj1.userTask)) === i
                          )
                        const oTaskData = new JSONModel();
                        oTaskData.setData(oData);
                        let oTData = oTaskData.getData();

                        if (oTData && oTData.Tasks) {
                            const desiredOrder = ["0001", "0002", "0003", "0004", "0005"];

                            oTData.Tasks.sort((a, b) => {
                                return desiredOrder.indexOf(a.TaskName) - desiredOrder.indexOf(b.TaskName);
                            });

                            oTaskData.setData(oTData);
                        }

                        self.getView().setModel(oTaskData, "currentTaskModel");

                        let oDropdown = self.getView().byId("id-filter-task");
                        oDropdown.bindItems({
                            path: "currentTaskModel>/value",
                            template: new sap.ui.core.Item({
                                key: "{currentTaskModel>userTaskID}",
                                text: "{currentTaskModel>userTaskName}"
                            })
                        });
                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
             //service call for MRR application form Page Language related config
             getMRRLanugaueData: function (fnSuccess, self, isComponentScope, sOrgID) {
                const sBaseurl = this._getWfServiceRuntimeBaseURL(self, isComponentScope);
                jQuery.ajax({
                    async: true,
                    contentType: "application/json",
                    url: `${sBaseurl}/req-area-api-/MR_Language?$filter=orgID eq '${sOrgID}'`,
                    type: "GET",
                    success: function (oData) {
                        return fnSuccess(oData, self);

                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            //get profit center master data
            getProfitCenterList: function(self){
                const sBaseurl = this._getWfServiceRuntimeBaseURL(self);
                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    url: `${sBaseurl}/ore-api-/ProfitCenter`,
                    type: "GET",
                    success: function (oData) {
                        const oPCData = new JSONModel();
                        oPCData.setData(oData);
                        self.getView().setModel(oPCData, "ProfitCenterListData");
 
                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            /**Git 132 (Form template changes + add new opp fields)
             *get comments
            * @param {object} self - controller scope
            * @param {string} sInstanceID - workflow instance id
            * @param {string} method - service method (POST or GET)
            * @param {object} oPayload - pass opayload for create(POST) comment
            */
            _getUserComments: function(self,sInstanceID,method,oPayload){
                const sBaseurl = this._getWfServiceRuntimeBaseURL(self),
                      sUrl = method === "GET" ? `YC_MR_T_Comment?$filter=instanceID eq '${sInstanceID}'`:`UserCommentUpdate`,
                      that = this;
                jQuery.ajax({
                    async: true,
                    contentType: "application/json",
                    url: `${sBaseurl}/wf/${sUrl}`,
                    data: method === "POST" ? JSON.stringify(oPayload):null,
                    type: method,
                    success: function (oData) {
                        if(method === "GET"){
                            const oJsonModel = new JSONModel();
                            if(oData.value.length){
                                oData.value.sort(function (a, b) {
                                    let c = new Date(a.createdAt);
                                    let d = new Date(b.createdAt);
                                    return c - d;
                                }).reverse();
                                // SANITIZE HERE
                                oData.value.forEach(function (item) {
                                    if (item.commentText) {
                                        //sanitize will protect the app from XSS(Cross site scripting) 
                                        item.commentText = sanitizeHTML(item.commentText);
                                    }
                                });
                            }
                            oJsonModel.setData(oData);
                            self.getView().setModel(oJsonModel, "userCommentsModel");
                            if(self.getView().byId("idCommentsSec")){
                                 self.getView().byId("idCommentsSec").setBusy(false);
                            }
                             if(self.getView().byId("idUserCommentSec")){
                                 self.getView().byId("idUserCommentSec").setBusy(false);
                            }
                        }else{
                            self.common._setActionHistoryModel(self, true, true,true);
                            that._getUserComments(self,sInstanceID,"GET")
                        }
                       
 
                    }.bind(this),
                    error: function (oError) {
                        if (self.getView().byId("idCommentsSec")) {
                            self.getView().byId("idCommentsSec").setBusy(false);
                        }
                        if (self.getView().byId("idUserCommentSec")) {
                            self.getView().byId("idUserCommentSec").setBusy(false);
                        }
                        if(oError && method === "POST" && oError["status"] === 400){
                            oError["responseText"] = self.getOwnerComponent().getModel("appConstants").getProperty("/commentValidationMsg/0/Value");
                        }
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            //reusable function to call oData
            _callGETOdata: function (oModel, sPath,sUrlParams) {
                const sUrlParameters = sUrlParams ? sUrlParams:[];
                return new Promise(function (resolve, reject) {
                    oModel.read(sPath, {
                        urlParameters:sUrlParameters,
                        success: function (data) {
                            resolve(data);
                        },
                        error: function (oError) {
                            reject(oError)
                        }
                    });
                });
            },
            //post oData
            _callPOSTOdata: function (oModel, sPath, oEntry) {
                return new Promise(function (resolve, reject) {
                    oModel.create(sPath, oEntry, {
                        success: function (data) {
                            appView.getView().getModel("userIdModel").setProperty("/substMessageStripVisible", false);
                            resolve(data);
                        },
                        error: function (oError) {
                            reject(oError)
                            sap.ui.core.BusyIndicator.hide();
                            try {
                                let that = this;
                                let oErrorResponse = JSON.parse(oError.responseText);
                                let sBackendMessage = oErrorResponse?.error?.message?.value || "";

                                if (sBackendMessage.includes("Entry already exists")) {
                                    appView.getView().getModel("userIdModel").setProperty("/substMessageStripVisible", true)
                                }else{
                                    ErrorHandle.setErrorMessage(oError, appView);
                                }
                            } catch (e) {
                                console.error("Error parsing response:", e);
                            }

                            
                        }
                    });
                });
            },
             //delete oData
             _callDeleteOdata: function (oModel, sPath) {
                return new Promise(function (resolve, reject) {
                    oModel.remove(sPath,{
                        success: function (data) {
                            resolve(data);
                        },
                        error: function (oError) {
                            reject(oError)
                        }
                    });
                });
            },
            systeminticDataModel: function (self) {
                //set oData model for ISP
                const componentName = self.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
                const componentPath = sap.ui.require.toUrl(componentName);
                const oDataModel = new ODataModel({
                    serviceUrl: `${componentPath}/int_ic/sap/opu/odata/sap/zharmony_callidus_srv`
                });
                return oDataModel;

            },
            systemResourcesDataModel: function (self) {
                //set oData model for ISP
                const componentName = self.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
                const componentPath = sap.ui.require.toUrl(componentName);
                // call ymr_srv service for solution areas
                const oDataModel = new ODataModel({
                    serviceUrl: `${componentPath}/int_pc/sap/opu/odata/sap/ymr_srv`
                });
                return oDataModel;

            },
              /**
             *get Activity team details
            * @param {object} self - controller scope
            * @param {Array} aFilters - filter parameter to get team user details
            */
            getActTeamMemberDetails: function (aFilters,self) {
                const oIntLSModel = this.systemActivityDataModel(self);
                let mParameters = {
                    filters: aFilters
                };
                return this.odata("/Yc_MD_Usersearch", oIntLSModel).get(mParameters);
            },
              /**
             *odata common call with all methods
            * @param {string} url - service url
            * @param {object} oModel - oData model
            */
            odata: function (url, oModel, sData) {
                var core = {
                    ajax: function (type, surl, data, parameters, sModel) {
                        var promise = new Promise(function (resolve, reject) {
                            var args = [];
                            var params = {};
                            args.push(surl);
                            if (data) {
                                args.push(data);
                            }
                            if (parameters) {
                                params = parameters;
                            }
                            params.success = function (result, response) {
                                resolve({
                                    data: result,
                                    response: response
                                });
                            };
                            params.error = function (error) {
                                reject(error);
                            };
                            args.push(params);
                            sModel[type].apply(sModel, args);
                        });
                        return promise;
                    }
                };
                return {
                    "get": function (params) {
                        return core.ajax("read", url, false, params, oModel);
                    },
                    "post": function (data, params) {
                        return core.ajax("create", url, data, params, oModel);
                    },
                    "put": function (data, params) {
                        return core.ajax("update", url, data, params, oModel);
                    },
                    "delete": function (params) {
                        return core.ajax("remove", url, false, params, oModel);
                    }
                };
            },

            systemLSDataModel: function (self) {
                //set oData model for ISP
                const componentName = self.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
                const componentPath = sap.ui.require.toUrl(componentName);
                // call ymr_srv service for solution areas
                const oDataModel = new ODataModel({
                    serviceUrl: `${componentPath}/int_pc/sap/opu/odata/sap/ymr_srv`
                });
                return oDataModel;
    
            },
             systemLSUserDetailsDataModel: function (self,oController) {
                //set oData model for ISP
                const componentName = !oController ? self.getManifestEntry("/sap.app/id").replaceAll(".", "/"):self.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
                const componentPath = sap.ui.require.toUrl(componentName);
                const oDataModel = new ODataModel({
                    serviceUrl: `${componentPath}/int_pc/sap/opu/odata/sap/YROSTER_SRV;v=0002`
                });
                return oDataModel;
    
            },
            //Get Solution Area initial level Master Data (Solution Area L1)
            _getSLAMasterData: function (oController) {
                const oLSSystemModel = this.systemLSDataModel(oController);
                oLSSystemModel.setUseBatch(true);
                this._callGETOdata(oLSSystemModel, "/YC_MR_M_SOL_HIERARCHY_DETAILS").then(function (oData) {
                    //convert flat structure to tree structure
                    let aSolutionAreas = oData.results,
                        aSAList = [];
                    for (let i = 0; i < aSolutionAreas.length; i++) {
                        let oL1 = aSAList.find(item => item.Guid === aSolutionAreas[i].SolL1Guid);
                        if (!oL1 && aSolutionAreas[i].SolL1Guid && aSolutionAreas[i].SolL1Guid !== "" && aSolutionAreas[i].SolL1Guid !==
                            "00000000-0000-0000-0000-000000000000" && aSolutionAreas[i].SolL1Viewable.toUpperCase() === "X") {
                            oL1 = {
                                soln_guid: aSolutionAreas[i].SolL1Guid,
                                soln_id: aSolutionAreas[i].SolL1Id,
                                soln_name: aSolutionAreas[i].SolL1Desc,
                                solnFinalName: aSolutionAreas[i].SolL1Desc,
                                is_selectable: aSolutionAreas[i].SolL1Selectable,
                                is_viewable: aSolutionAreas[i].SolL1Viewable,
                                soln_prnt_guid:"00000000-0000-0000-0000-000000000000",
                                isPartiallySelected: false,
                                is_ChildLoaded: true,
                                to_Child: [],
                                Guid: aSolutionAreas[i].SolL1Guid,
                                ID: aSolutionAreas[i].SolL1Id,
                                Desc: aSolutionAreas[i].SolL1Desc,
                                LevelId: 1,
                                SolAreal1Guid: aSolutionAreas[i].SolL1Guid,
                                SolAreal1Desc: aSolutionAreas[i].SolL1Desc,
                                DisplayGuid: aSolutionAreas[i].SolL1Guid,
                                DisplayDesc: aSolutionAreas[i].SolL1Desc,
                                Levels: [],
                            };
                            aSAList.push(oL1);
                            aSAList.sort((a, b) => a.soln_name.localeCompare(b.soln_name));
                        }
                        if (oL1) {
                            let oL2 = oL1.Levels.find(item => item.Guid === aSolutionAreas[i].SolL2Guid);
                            if (!oL2 && aSolutionAreas[i].SolL2Guid && aSolutionAreas[i].SolL2Guid !== "" && aSolutionAreas[i].SolL2Guid !==
                                "00000000-0000-0000-0000-000000000000" && aSolutionAreas[i].SolL2Viewable.toUpperCase() === "X") {
                                oL2 = {
                                    soln_guid: aSolutionAreas[i].SolL2Guid,
                                    soln_id: aSolutionAreas[i].SolL2Id,
                                    soln_name: aSolutionAreas[i].SolL2Desc,
                                    solnFinalName: aSolutionAreas[i].SolL2Desc,
                                    prnt_soln_id:aSolutionAreas[i].SolL1Id,
                                    soln_prnt_guid:aSolutionAreas[i].SolL1Guid,
                                    isPartiallySelected: false,
                                    is_selectable: aSolutionAreas[i].SolL2Selectable,
                                    is_viewable: aSolutionAreas[i].SolL2Viewable,
                                    is_ChildLoaded: false,
                                    to_Child: [],
                                    LevelId: 2,
                                    SolAreal1Guid: aSolutionAreas[i].SolL1Guid,
                                    SolAreal1Desc: aSolutionAreas[i].SolL1Desc,
                                    SolAreal2Guid: aSolutionAreas[i].SolL2Guid,
                                    SolAreal2Desc: aSolutionAreas[i].SolL2Desc
                                };
                                oL1.to_Child.push(oL2);
                                oL1.to_Child.sort((a, b) => a.soln_name.localeCompare(b.soln_name));
                            }
                        }
                    }

                    //set default child for all masterData
                    oController.getOwnerComponent().getModel("SLAMasterDataLevels").setData(
                        {
                            "results": aSAList
                        });
                    oController._OnUpdateSlaSelection(true);
                })
                    .catch(function (oError) {
                        ErrorHandle.setErrorMessage(oError, oController);
                    });

            },          
             // getUserDetails from ORE
            getLSUserDetails:function(oController, userId){
                const oLSSystemModel = this.systemLSUserDetailsDataModel(oController);
                let that = this;
                oLSSystemModel.setUseBatch(true);
                 const sUrlParams = {
                    $filter: `Id eq '${userId}'`
               };
                this._callGETOdata(oLSSystemModel,"/YC_DS_T_NAMED_CONTACT", sUrlParams).then(function(oData){
                    const sSalesOrgID = oData.results[0].CompanyCode;
                    oController.getModel("userDetails").getData().salesOrgID = sSalesOrgID;
                    that.getPublicSalesOrg(oController, oController.getParentSalesOrg , true);
                })
                .catch(function(oError){
                    ErrorHandle.setErrorMessage(oError, oController);
                });
               
            },
            //get Solution Area levels
            _getSLALevels:function(oController,oContext,sPath,evt){
                const oLSSystemModel = this.systemLSDataModel(oController);
                let sGuid = sPath ? oContext.soln_guid : oContext.SolGuid;
                const sUrlParams = {
                    $filter: `soln_guid eq (guid'${sGuid}')`,
                    $expand:"to_Child"
               };

                oLSSystemModel.setUseBatch(true);
                this._callGETOdata(oLSSystemModel,"/YC_MR_M_SOL_HIERARCHY", sUrlParams).then(function(oData){
                    const oResponse =oData.results[0].to_Child;
                        //set default child for all masterData
                        oResponse.results.forEach(function(data){
                            data.is_final = false;
                            data.isSelectable = true;
                            data.is_ChildLoaded = false;
                            data.is_ChildLoaded = true;
                            data.isPartiallySelected = false;
                            data.solnFinalName = oContext.soln_name ? `${oContext.soln_name} > ${data.soln_name} `:data.soln_name;
                            let oSelectedSLA = oController.getView().getModel("employee").getProperty(`/searchItems/${oController.getView().getModel("masterDataModel").getProperty("/iIndex")}/TempEmployee/SolutionAreas/0`);
                            if(oSelectedSLA && data.soln_guid === oSelectedSLA.soln_guid){
                                data.isSelected = true;
                            }
                            if(!sPath){
                                data.to_Child = [{
                                    "soln_name": "Loading...",
                                    "is_selectable":false,
                                    "is_viewable":"X"
                             }];
                             delete data.to_Child; //till L2
                            }
                           
                        });
                        if(sPath){
                            //more levels
                            const oSelectedContext = oController.getOwnerComponent().getModel("SLAMasterDataLevels").getProperty(sPath);
                            oSelectedContext.is_final = true;
                            oResponse.results.forEach(function(data){
                                if(data.to_Child){
                                    delete data.to_Child;
                                }
                            });
                            oSelectedContext.is_ChildLoaded = true;
                            oSelectedContext.to_Child = oResponse.results;
                            oController.getOwnerComponent().getModel("SLAMasterDataLevels").refresh(true);

                        }else{
                            oController.getOwnerComponent().getModel("SLAMasterDataLevels").setData(oResponse);
                        }
                       
                        oController.getOwnerComponent().getModel("SLAMasterDataLevels").setProperty("/isGridLayBusy",false);
                        oController.getOwnerComponent().getModel("SLAMasterDataLevels").refresh();
                        oController._OnUpdateSlaSelection();
                })
                .catch(function(oError){
                    ErrorHandle.setErrorMessage(oError, oController);
                });
                
            },
            //get active users from ore
            getOreActiveUsers: function(self , query , fnSuccess, sVal , data, i){
                var OpportunitiesBaseUrl = this._getLSRuntimeBaseURL(self);
                jQuery.ajax({
                    async: false,
                    url: `${OpportunitiesBaseUrl}/sap/opu/odata/sap/YROSTER_SRV;v=0002/YC_DS_T_RESOURCE_PROFILE${query}`,
                    dataType: "json",
                    method: "GET",
                    success: function (response) {
                        const aActiveUsersData = response.d.results;
                        const sActiveUsersIds = aActiveUsersData.map(user => user.UserId);
                        const filteredArray = data.filter(user => sActiveUsersIds.includes(user.UserID));
                        return fnSuccess(filteredArray, self, sVal, i);
                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    },
                });
            },
            //substitute
            _CallSubsEmployeeService:function(fnSuccess,sInputVal,oController){
                const ApproversOREUrl = this._getRuntimeBaseURL(oController) + "/int_pc/sap/opu/odata/sap/YROSTER_SRV;v=0002/YC_DS_T_NAMED_CONTACT",
                serviceUrlORE = ApproversOREUrl + "?search=" + sInputVal + "&$filter=(MelodyRequest eq 'X')";
                jQuery.ajax({
                    url: `${serviceUrlORE}&$top=20&$skip=0`,
                    dataType: 'json',
                    async: false,
                    type: "GET",
                    success: function (response) {
                        return fnSuccess(response,oController);
                    }.bind(this),
                    error: function (oError) {
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
                /**Git 238 (Sub-Requests display )
            * Call  service for wfinstance and filter sub requests
            * @param {object} self -controller scope.
            */
            getSubTaskInstanceDetails: function (self) {
                const workflowBaseurl = this._getWfServiceRuntimeBaseURLRoleBased(self),
                    oWfInstanceModel = self.getView().getModel("wfInstanceModel")
                        ? self.getView().getModel("wfInstanceModel") : self.getOwnerComponent().getModel("wfInstanceModel"),
                    sParentInstanceId = oWfInstanceModel.getProperty("/ParentInstanceID"),
                    sCurrentInstanceId = oWfInstanceModel.getProperty("/InstanceID");


                jQuery.ajax({
                    async: true,
                    contentType: "application/json",
                    url: `${workflowBaseurl}/wf/V_WfInstance_Inbox?$filter=ParentInstanceID eq ('${sParentInstanceId}')&$expand=_Solution`,
                    type: "GET",
                    success: function (oResponse) {


                        const oValue = oResponse.value;
                        if (oValue.length) {
                            //filter sub-requests where instance id neq current task and current task not a draft-request
                            const aFilteredSubtasks = oValue.filter(val => (val.InstanceID !== sCurrentInstanceId) && (val.InstanceID !== sParentInstanceId) && (val.CurrentStepID !== "REQSUB"));
                            //set current processorList

                            for (let i = 0; i < aFilteredSubtasks.length; i++) {
                                if (aFilteredSubtasks[i].approvers) {
                                    //approvers
                                    const aApprovers = aFilteredSubtasks[i].approvers,
                                        aSplitApproverId = aApprovers.split("),"),
                                        aFinalApproverList = [];
                                    aSplitApproverId.forEach(function (user) {
                                        let aSplitUser = user.split("(");
                                        let oApproverData = {
                                            "fullName": aSplitUser[0] ? aSplitUser[0].trim() : "",
                                            "ID": aSplitUser.length > 1 ? aSplitUser[1].replace(/,.*/, "").trim() : ""
                                        }
                                        aFinalApproverList.push(oApproverData);
                                    });
                                    aFinalApproverList.length ? aFinalApproverList[0].bIsTitle = true : false;
                                    //sort processor list
                                    self.common._empSort(aFinalApproverList, "fullName");
                                    let aProcessorShortList = [],
                                        aProcessorMoreList = [],
                                        sMoreProcessorText;
                                    if (aFinalApproverList.length > 2) {
                                        const iProcessorMoreCount = (aFinalApproverList.length - 2).toString(),
                                            si18nMoreText = self.getOwnerComponent().getModel("i18n").getResourceBundle().getText("more");
                                        sMoreProcessorText = `(${iProcessorMoreCount} ${si18nMoreText})`;
                                        aProcessorShortList = aFinalApproverList.slice(0, 2); // visible approver list ( max 2 processors)
                                        aProcessorMoreList = aFinalApproverList.slice(2);// array point to link to show more processors	
                                    } else {
                                        aProcessorShortList = aFinalApproverList;
                                    }
                                    //create object for processor list
                                    aFilteredSubtasks[i].processorList = {
                                        processorShortList: aProcessorShortList,
                                        processorMoreList: aProcessorMoreList,
                                        currentScope: self,
                                        moreProcessorText: sMoreProcessorText,
                                        processorDisplayList: sMoreProcessorText ? aProcessorShortList.concat([{
                                            ID: "idMoreText",
                                            fullName: sMoreProcessorText
                                        }]) : aProcessorShortList
                                    }
                                    aFilteredSubtasks[i].approverVisible = true;
                                } else {
                                    aFilteredSubtasks[i].approverVisible = false;
                                }
                                if (aFilteredSubtasks[i].ResourceNames && (aFilteredSubtasks[i].CurrentStepID === "RESAPP" || aFilteredSubtasks[i].CurrentStepID === "REQCOM" || aFilteredSubtasks[i].CurrentStepID === "IOOAPP")) {
                                    //resource list
                                    const sCurrentResName = aFilteredSubtasks[i].ResourceNames,
                                        sCurrrentResID = aFilteredSubtasks[i].ResourceIDs,
                                        aCurrentResName = sCurrentResName ? sCurrentResName.split(";") : [],
                                        aCurrrentResrID = sCurrrentResID ? sCurrrentResID.split(";") : [],
                                        aResourceList = aCurrentResName.map((value, index) => ({
                                            fullName: value,
                                            ID: aCurrrentResrID[index]
                                        }));
                                    aResourceList.length ? aResourceList[0].bIsTitle = true : false;
                                    //sort processor list
                                    self.common._empSort(aResourceList, "fullName");
                                    let aResourceShortList = [],
                                        aResourceMoreList = [],
                                        sMoreResourceText;
                                    if (aResourceList.length > 2) {
                                        const iResourceMoreCount = (aResourceList.length - 2).toString(),
                                            si18nMoreText = self.getOwnerComponent().getModel("i18n").getResourceBundle().getText("more");
                                        sMoreResourceText = `(${iResourceMoreCount} ${si18nMoreText})`;
                                        aResourceShortList = aResourceList.slice(0, 2); // visible approver list ( max 2 processors)
                                        aResourceMoreList = aResourceList.slice(2);// array point to link to show more processors	
                                    } else {
                                        aResourceShortList = aResourceList;
                                    }
                                    //create object for Resource list
                                    aFilteredSubtasks[i].resourceList = {
                                        processorShortList: aResourceShortList,
                                        processorMoreList: aResourceMoreList,
                                        currentScope: self,
                                        moreProcessorText: sMoreResourceText,
                                        processorDisplayList: sMoreResourceText ? aResourceShortList.concat([{
                                            ID: "idMoreText",
                                            fullName: sMoreResourceText
                                        }]) : aResourceShortList
                                    }
                                    aFilteredSubtasks[i].resourceVisible = true
                                } else {
                                    aFilteredSubtasks[i].resourceVisible = false;
                                }
                                // if(additionalSolMap.get(aFilteredSubtasks[i].InstanceID)){
                                //     aFilteredSubtasks[i].addSolutions=additionalSolMap.get(aFilteredSubtasks[i].InstanceID)
                                // }else{
                                //     aFilteredSubtasks[i].addSolutions=aFilteredSubtasks[i]._Solution
                                // }
                                aFilteredSubtasks[i].addSolutions = aFilteredSubtasks[i]._Solution.filter(item => !item.is_MainSoln)
                                aFilteredSubtasks[i].Solution_Desc = aFilteredSubtasks[i]._Solution.filter(item => item.is_MainSoln).length ? aFilteredSubtasks[i]._Solution.filter(item => item.is_MainSoln)[0].solution_Hierarchy:""
                            }
                            oResponse.value = aFilteredSubtasks;
                            if(aFilteredSubtasks.length){
                                aFilteredSubtasks.sort((a, b) => a.RefrenceID - b.RefrenceID);
                            }
                            const oSubtaskModel = new JSONModel();
                            oSubtaskModel.setData(oResponse);
                            const oBaseModel = self.getView().getModel("multiReqModel") ? self.getView().getModel("multiReqModel") : self.getView().getModel();
                            aFilteredSubtasks.length ? oBaseModel.setProperty("/subTaskVisibility", true) :
                                oBaseModel.setProperty("/subTaskVisibility", false);
                            self.getView().setModel(oSubtaskModel, "subtaskModel");
                            self.getView().getModel("subtaskModel").refresh();
                        }
                        if( self.getView().byId("idSubTaskSec")){
                            self.getView().byId("idSubTaskSec").setBusy(false);
                        }
                        if (self.getView().byId("idReqSubTaskSec")) {
                            self.getView().byId("idReqSubTaskSec").setBusy(false);
                        }
                        
                    }.bind(this),
                    error: function (oError) {
                         if( self.getView().byId("idSubTaskSec")){
                            self.getView().byId("idSubTaskSec").setBusy(false);
                        }
                        if (self.getView().byId("idReqSubTaskSec")) {
                            self.getView().byId("idReqSubTaskSec").setBusy(false);
                        }
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                })

            },
              getSolutionAreaMasterData: function (oController,bIsSearch) {
                const oLSSystemModel = this.systemLSDataModel(oController);
                oLSSystemModel.setUseBatch(true);
                this._callGETOdata(oLSSystemModel, "/YC_MR_M_SOL_ROOT").then(function (oData) {
                    let aSolutionAreasL1 = oData.results
                    //let mSolutionHierarchyMap=new Map()
                     if(oController.getOwnerComponent().getModel("SolutionAreaMasterData").getProperty("/solHierarchyMap")){
                        var mSolutionHierarchyMap=oController.getOwnerComponent().getModel("SolutionAreaMasterData").getProperty("/solHierarchyMap")
                        
                     }else{
                         var mSolutionHierarchyMap=new Map()
                     }
                    let mMaterialMap=new Map()
                    for (let i = 0; i < aSolutionAreasL1.length; i++) {
                        aSolutionAreasL1[i].soln_guid = aSolutionAreasL1[i].SolGuid
                        aSolutionAreasL1[i].soln_id = aSolutionAreasL1[i].SolnId
                        aSolutionAreasL1[i].soln_name = aSolutionAreasL1[i].SolName
                        aSolutionAreasL1[i].full_sol_name = aSolutionAreasL1[i].SolName
                        aSolutionAreasL1[i].full_sol_guid = aSolutionAreasL1[i].SolGuid
                         aSolutionAreasL1[i].full_sol_id = aSolutionAreasL1[i].soln_id
                        if(bIsSearch){
                             aSolutionAreasL1[i]
                        }                    
                        aSolutionAreasL1[i].LevelId = 1
                        aSolutionAreasL1[i].levels = [{ "soln_name": "Loading..." }]
                        if(!mSolutionHierarchyMap.get(aSolutionAreasL1[i].soln_guid)){
                            mSolutionHierarchyMap.set(aSolutionAreasL1[i].soln_guid,aSolutionAreasL1[i])
                        }
                    }
                    aSolutionAreasL1.sort(function(a,b){
					return a.SolName.localeCompare(b.SolName)
				    })
                    oController.bDisableExpandAPICall = false;
                    if (bIsSearch) {
                        oController.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/solHierarchy", aSolutionAreasL1)
                       oController.getView().getId().includes("Worklist") ? oController.getView().byId("idSolutionTree").collapseAll() : oController.SADialog.getContent()[1].getContent()[0].getItems()[0].getContent()[0].collapseAll();
                         oController.getOwnerComponent().getModel("SolutionAreaMasterData").refresh();
                    } else {
                        oController.getOwnerComponent().getModel("SolutionAreaMasterData").setData(
                            {
                                // "level1Data": aSolutionAreasL1
                                "solHierarchy": aSolutionAreasL1
                            });
                    }
                   
                    
                    oController.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/solHierarchyMap",mSolutionHierarchyMap)
                    oController.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/materialMap",mMaterialMap)
                    if (bIsSearch && oController.getView().getId().includes("Worklist")) {
                        let aSolutionAreas = oController.getView().getModel("employee").getData().TempEmployee.SolutionAreas,
                            aSolutionMasterData = oController.getOwnerComponent().getModel("SolutionAreaMasterData").getData(),
                            aSelectedSla = [];
                        aSolutionMasterData.solHierarchy.forEach(function (item) {
                            let aFilteredSln = aSolutionAreas.filter(val => val.soln_guid === item.soln_guid)
                            if (aFilteredSln.length) {
                                item.selected = true;
                                aSelectedSla.push(item)
                            }
                        })  
                      oController.getView().getModel("employee").setProperty("/solutionForFilter",aSolutionAreas);
                       oController.getView().getModel("employee").refresh();
                           let aSolutionFilter = oController.getView().getModel("employee").getProperty("/solutionForFilter");
                        aSolutionFilter.forEach(function (item) {
                            if (item.LevelId === 2) {
                                let sParentGuid = item.soln_prnt_guid;
                                aSolutionMasterData.solHierarchy.forEach(function (sol) {
                                    if (sol.soln_guid === sParentGuid) {
                                        sol.selected = true;
                                        sol.partialSelection = !sol.selected
                                    }
                                })
                            }
                        })
                    oController.getOwnerComponent().getModel("SolutionAreaMasterData").refresh();

                    }
                    // oController._OnUpdateSlaSelection(true);
                })
                    .catch(function (oError) {
                        ErrorHandle.setErrorMessage(oError, oController);
                    });

            },
            _loadChildren:function(oController,sSelectedObj,oEvent,bIsL1Change,l2guidCreateReq){
                let sSelectedKeyGuid=sSelectedObj.soln_guid
                let oSAMaterDataModel=oController.getOwnerComponent().getModel("SolutionAreaMasterData")
                let mSolutionHierarchyMap=oSAMaterDataModel.getProperty("/solHierarchyMap")
                let solHierarchy = [];
                let bAddSolAreaMaterialState=oSAMaterDataModel.getProperty("/showDisplayMaterials")
                var l2forCreateReqPopulate
                let  aAddSlns = oSAMaterDataModel.getProperty("/displayTokensAdditionalSolution") ? oSAMaterDataModel.getProperty("/displayTokensAdditionalSolution") : [];
                 let aAddSlnLevels = aAddSlns.length ? [...new Set(aAddSlns.flatMap(item => item.full_sol_guid.split(" > ")))] :[];
                oSAMaterDataModel.setProperty("/isSolDialogBusy",true)
                const oLSSystemModel = this.systemLSDataModel(oController);                
                const sUrlParams = {
                    $filter: `project_type eq 'ACTVT' and soln_guid eq (guid'${sSelectedKeyGuid}')`,
                    $expand:"to_Child"
                };
                oLSSystemModel.setUseBatch(true);
                // if (!(mSolutionHierarchyMap.get(sSelectedKeyGuid).levels.length && mSolutionHierarchyMap.get(sSelectedKeyGuid).levels[0].soln_guid)) {
                    this._callGETOdata(oLSSystemModel, "/YC_MR_M_SOL_HIERARCHY", sUrlParams).then(function (oData) {
                        let oResponse = oData.results[0].to_Child;
                        oResponse.results.forEach(resp=>{
                            if (aAddSlnLevels.length) {
                                const aNodeCheck = aAddSlnLevels.filter(guid => guid === resp.soln_guid);
                                if (aNodeCheck.length) {
                                    resp.selected = true;
                                }
                            }
                            if (oController.getView().getId().includes("Worklist")) {
                                let aSolutionAreas = oController.getView().getModel("employee").getData().TempEmployee.SolutionAreas;
                                if (aSolutionAreas && aSolutionAreas.length) {
                                    const aNodFiltereCheck = aSolutionAreas.filter(obj => obj.soln_guid === resp.soln_guid);
                                    if (aNodFiltereCheck.length) {
                                    resp.selected = true;
                                }
                                }

                            }
                            
                            resp.id=resp.soln_guid
                            resp.name=resp.soln_name
                            resp.full_sol_name=sSelectedObj.full_sol_name +" > "+ resp.soln_name
                            resp.full_sol_guid=sSelectedObj.full_sol_guid +" > "+ resp.soln_guid
                            resp.full_sol_id=sSelectedObj.full_sol_id +" > "+ resp.soln_id
                            // resp.selected=sSelectedObj.selected?true:false
                            delete resp.to_Child
                            delete resp.__metadata
                        })
                        for (let i = 0; i < oResponse.results.length; i++) {
                            if(l2guidCreateReq && oResponse.results[i].soln_guid==l2guidCreateReq){
                                l2forCreateReqPopulate=oResponse.results[i]
                            }
                            oResponse.results[i].LevelId = mSolutionHierarchyMap.get(sSelectedKeyGuid).LevelId + 1
                           oResponse.results[i].levels = bAddSolAreaMaterialState? oResponse.results[i].is_final ?  [] : [{ "soln_name": "Loading..." }]: [];
                            mSolutionHierarchyMap.set(oResponse.results[i].soln_guid, oResponse.results[i])
                            // oResponse.results[i].isParent = true;                                                                                                                     
                        }
                        if(l2forCreateReqPopulate)
                            this.getMaterials(oController,l2forCreateReqPopulate,true)
                        solHierarchy = oResponse.results
                        mSolutionHierarchyMap.get(sSelectedKeyGuid).levels = solHierarchy
                        // if (bIsL1Change)
                        //     oSAMaterDataModel.setProperty('/solHierarchy', $.extend(true, [], solHierarchy))
                        // else {
                            let path = oEvent.getParameter("itemContext").getPath();
                            oSAMaterDataModel.setProperty(path + '/levels', $.extend(true, [], solHierarchy))
                        // }
                        oSAMaterDataModel.setProperty("/isSolDialogBusy",false)
                    }.bind(this))
                // } else {
                    // solHierarchy = mSolutionHierarchyMap.get(sSelectedKeyGuid).levels
                    // // let bFullSASelected = oSAMaterDataModel.getProperty("/showDisplayMaterials")
                    // solHierarchy.forEach(obj=>{
                    //         if(l2guidCreateReq && obj.soln_guid==l2guidCreateReq){
                    //             l2forCreateReqPopulate=obj
                    //         }
                    // })
                    // if(l2forCreateReqPopulate)
                    //     this.getMaterials(oController,l2forCreateReqPopulate,true)
                    
                    // // if (bIsL1Change){
                    // //   solHierarchy.forEach(item => {
                    // //     item.levels = bAddSolAreaMaterialState? [{ "soln_name": "Loading..." }] : []
                    // // })
                    // //     oSAMaterDataModel.setProperty('/solHierarchy', $.extend(true, [], solHierarchy))
                    // // }
                    
                    // // else {
                    //     let path = oEvent.getParameter("itemContext").getPath();
                    //     oSAMaterDataModel.setProperty(path + '/levels', $.extend(true, [], solHierarchy))
                    // // }
                    oSAMaterDataModel.setProperty("/isSolDialogBusy",false)
               // }
                
                
            },                                 
            getMaterials:function(oController,oSelectedObj,bIsSelected){
               var sSelectedKeyGuid=oSelectedObj.soln_guid
                let mMaterialMap=oController.getOwnerComponent().getModel("SolutionAreaMasterData").getProperty("/materialMap")
                var aMaterials=oController.getOwnerComponent().getModel("SolutionAreaMasterData").getProperty("/materials")
                let mSolutionHierarchyMap=oController.getOwnerComponent().getModel("SolutionAreaMasterData").getProperty("/solHierarchyMap")
                var solHierarchy=oController.getOwnerComponent().getModel("SolutionAreaMasterData").getProperty("/solHierarchy")
                var displayTokensMaterial=oController.getOwnerComponent().getModel("SolutionAreaMasterData").getProperty("/displayTokensMaterial")
                var currentSelectedL2=oController.getOwnerComponent().getModel("SolutionAreaMasterData").getProperty("/selectedLevel2Id")
                var selectedLevel1Guid=oController.getOwnerComponent().getModel("SolutionAreaMasterData").getProperty("/selectedLevel1Guid")
                var aIdOfMatToBeUnselected=[]
                oController.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/isSolDialogBusy",true)
                if(!aMaterials){
                    aMaterials=[]
                }
                if(bIsSelected){
                if(oSelectedObj.LevelId==3){
                    // if(oSelectedObj.levels.length>0 && oSelectedObj.levels[0].soln_guid){
                    //         oSelectedObj.levels.forEach(child=>{
                    //             aMaterials=aMaterials.filter(item=>item.triggeredBy!=child.soln_guid)
                    //             aIdOfMatToBeUnselected.push(child.soln_guid)
                    //         })
                    //     }
                    if(oSelectedObj.levels.length>0 && oSelectedObj.levels[0].soln_guid){
                            var isSelectedCount=oSelectedObj.levels.filter(c=>c.selected).length
                            if(isSelectedCount>0){
                             oController.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/isSolDialogBusy",false)
                                return
                            }
                        }
                    aMaterials=aMaterials.filter(item=>item.triggeredBy!=oSelectedObj.soln_prnt_guid)
                    aIdOfMatToBeUnselected.push(oSelectedObj.soln_prnt_guid)
                    if(mSolutionHierarchyMap.get(oSelectedObj.soln_prnt_guid)){
                    var ol1=mSolutionHierarchyMap.get(oSelectedObj.soln_prnt_guid).soln_prnt_guid
                    // if(currentSelectedL2!=ol1){
                    //     aMaterials=[]
                    // }
                    aMaterials=aMaterials.filter(item=>item.triggeredBy!=ol1)
                    aIdOfMatToBeUnselected.push(ol1)
                    }
                }else if(oSelectedObj.LevelId==4){
                    aMaterials=aMaterials.filter(item=>item.triggeredBy!=oSelectedObj.soln_prnt_guid)
                    aIdOfMatToBeUnselected.push(oSelectedObj.soln_prnt_guid)
                    if(mSolutionHierarchyMap.get(oSelectedObj.soln_prnt_guid)){
                        var l2guid=mSolutionHierarchyMap.get(oSelectedObj.soln_prnt_guid).soln_prnt_guid
                        aMaterials=aMaterials.filter(item=>item.triggeredBy!=l2guid)
                        aIdOfMatToBeUnselected.push(l2guid)
                        
                    }
                    if(mSolutionHierarchyMap.get(l2guid)){
                    var ol1=mSolutionHierarchyMap.get(l2guid).soln_prnt_guid
                    //  if(currentSelectedL2!=ol1){
                    //     aMaterials=[]
                    // }
                    aMaterials=aMaterials.filter(item=>item.triggeredBy!=ol1)
                    aIdOfMatToBeUnselected.push(ol1)
                        
                    }
                }else if(oSelectedObj.LevelId==2){
                    aMaterials=[]
                }
                }else{
                    
                    if(oSelectedObj.LevelId==3){
                        aMaterials=aMaterials.filter(item=>item.triggeredBy!=oSelectedObj.soln_guid)
                        aIdOfMatToBeUnselected.push(oSelectedObj.soln_guid)
                        // if(oSelectedObj.levels.length>0 && oSelectedObj.levels[0].soln_guid){
                        //     oSelectedObj.levels.forEach(child=>{
                        //         aMaterials=aMaterials.filter(item=>item.triggeredBy!=child.soln_guid)
                        //         aIdOfMatToBeUnselected.push(child.soln_guid)
                        //     })
                        // }
                        var isSelectedCount
                        if(oSelectedObj.levels.length && oSelectedObj.levels[0].soln_guid){
                            isSelectedCount=oSelectedObj.levels.filter(c=>c.selected).length
                        }
                        if(isSelectedCount==0){
                            
                        var l2Obj=mSolutionHierarchyMap.get(oSelectedObj.soln_prnt_guid)
                        var l1Obj=mSolutionHierarchyMap.get(l2Obj.soln_prnt_guid)
                        solHierarchy.forEach(l1data=>{
                            if(l1data.soln_guid==l1Obj.soln_guid){
                                l1data.levels.forEach(l2Data=>{
                                    if(l2Data.soln_guid==l2Obj.soln_guid){
                                        var isSelectedCount=l2Data.levels.filter(c=>c.selected).length
                                        if(isSelectedCount==0){
                                            oSelectedObj=l2Data
                                            sSelectedKeyGuid=l2Data.soln_guid
                                            bIsSelected=true
                                        }
                                    }
                                })
                                
                            }
                        })
                        
                        // solHierarchy.forEach(l2data=>{
                        //     if(l2data.soln_guid==oSelectedObj.soln_prnt_guid){
                                
                        //         var isSelectedCount=l2data.levels.filter(c=>c.selected).length
                        //         if(isSelectedCount==0){
                        //             oSelectedObj=l2data
                        //             sSelectedKeyGuid=l2data.soln_guid
                        //             bIsSelected=true
                        //         }
                        //     }
                        // })
                        }
                    }
                    else if(oSelectedObj.LevelId==4){
                        aMaterials=aMaterials.filter(item=>item.triggeredBy!=oSelectedObj.soln_guid)
                        aIdOfMatToBeUnselected.push(oSelectedObj.soln_guid)
                        if(mSolutionHierarchyMap.get(oSelectedObj.soln_prnt_guid)){
                            var oL3Guid=mSolutionHierarchyMap.get(oSelectedObj.soln_prnt_guid).soln_guid
                            if(mSolutionHierarchyMap.get(oL3Guid)){
                                var oL2Guid= mSolutionHierarchyMap.get(oL3Guid).soln_prnt_guid
                                if(mSolutionHierarchyMap.get(oL2Guid)){
                                    var oL1Guid= mSolutionHierarchyMap.get(oL2Guid).soln_prnt_guid
                                }
                            }
                        }
                        solHierarchy.forEach(l1data=>{
                            if(l1data.soln_guid==oL1Guid){                               
                                l1data.levels.forEach(l2data=>{
                                    if(l2data.soln_guid==oL2Guid){
                                        var oL2Obj=l2data
                                        l2data.levels.forEach(l3data=>{
                                            if(l3data.soln_guid==oL3Guid){
                                                var oL3Obj=l3data
                                                var isSelectedCount=l3data.levels.filter(c=>c.selected).length
                                                if(isSelectedCount==0){
                                                    oSelectedObj=oL3Obj.selected ? oL3Obj : oL2Obj
                                                    sSelectedKeyGuid=oSelectedObj.soln_guid
                                                    bIsSelected=true
                                                }
                                            }
                                        })
                                    }
                                })
                            }
                        })
                        
                        
                    }
                    oController.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/materials",aMaterials)
                }
                // mMaterialMap.forEach((value,key)=>{
                //     if(aIdOfMatToBeUnselected)
                // })
                displayTokensMaterial=displayTokensMaterial.filter(item=>!aIdOfMatToBeUnselected.includes(item.triggeredBy))
                mMaterialMap.forEach((value,key)=>{
                    if(aIdOfMatToBeUnselected.includes(key)){
                        value.forEach(mat=>{
                            mat.selected=false
                        })
                    }
                })
                oController.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/isSolDialogBusy",false)
                // if(bIsSelected){

                //     const oLSSystemModel = this.systemLSDataModel(oController);                
                //     const sUrlParams = {                        
                //         $filter: `P_ParentGuid eq (guid'${sSelectedKeyGuid}')`
                        
                //     };
                //     oLSSystemModel.setUseBatch(true);
                    // if (!(mMaterialMap.get(sSelectedKeyGuid))) {    
                    //     this._callGETOdata(oLSSystemModel, "/YC_MR_M_MATERIAL_DTS(P_ParentGuid=guid'"+sSelectedKeyGuid+"')/Set").then(function (oData) {
                    //         if(oData.results.length>0){
                    //             oData.results.forEach(mat=>{
                    //                 mat.id=mat.MatId
                    //                 mat.name=mat.MatDesc
                    //                 mat.isMaterial=true
                    //                 mat.selected=false
                    //                 mat.triggeredBy=sSelectedKeyGuid
                    //             })
                    //             mMaterialMap.set(sSelectedKeyGuid,oData.results)
                    //             aMaterials=[...aMaterials,...oData.results]
                    //         }
                    //         oController.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/materials",aMaterials)
                    //         oController.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/materialMap",mMaterialMap)
                    //         oController.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/displayTokensMaterial",displayTokensMaterial)                            
                    //         oController.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/isSolDialogBusy",false)
                    //         oController.getOwnerComponent().getModel("SolutionAreaMasterData").refresh(true)
                    //     })
                    // }else{
                        // aMaterials=[...aMaterials,...mMaterialMap.get(sSelectedKeyGuid)]
                        // oController.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/materials",aMaterials)
                        // oController.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/materialMap",mMaterialMap)
                        // oController.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/displayTokensMaterial",displayTokensMaterial)
                        // oController.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/isSolDialogBusy",false)
                        // oController.getOwnerComponent().getModel("SolutionAreaMasterData").refresh(true)
                        
                    // }
                // }else{
                    // oController.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/materials",aMaterials)
                    // oController.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/materialMap",mMaterialMap)
                    // oController.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/displayTokensMaterial",displayTokensMaterial)
                    // oController.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/isSolDialogBusy",false)
                    // oController.getOwnerComponent().getModel("SolutionAreaMasterData").refresh(true)
                    //  let matToBeRemoved=mMaterialMap.get(sSelectedKeyGuid)?mMaterialMap.get(sSelectedKeyGuid):[]
                    //     aMaterials=aMaterials.filter(function(item1){
                    //         return !matToBeRemoved.some(function(item2){
                    //             return item2.MatId==item1.MatId
                    //         })
                    //     })
                    //     mMaterialMap.delete(sSelectedKeyGuid)
                    //     oController.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/materials",aMaterials)
               // }
                
                
                
            },
            // _callActivityTempDataService: function (self,oActivityPaylod,method) {
            //     const sBaseurl = this._getWfServiceRuntimeBaseURL(self),
            //         sInstanceID = self.getView().getModel("wfInstanceModel").getProperty("/InstanceID"),
            //         sUrl = method === "GET" ? `MR_ActivityTemp?$filter=(instanceID eq '${sInstanceID}')` : `MR_ActivityTemp`,
            //         that = this;
            //     jQuery.ajax({
            //         async: false,
            //         contentType: "application/json",
            //         url: `${sBaseurl}/wf/${sUrl}`,
            //         data: method === "POST" ? JSON.stringify(oActivityPaylod) : null,
            //         type: method,
            //         success: function (oData) {
            //             if (method === "GET") {
            //                 const oActivityModel = new JSONModel();
            //                 oActivityModel.setData(oData);
            //                 self.getView().setModel(oActivityModel, "activityTempModel");
 
            //             } else {
            //                   return oData;
            //             }
 
 
            //         }.bind(this),
            //         error: function (oError) {
                     
            //             ErrorHandle.setErrorMessage(oError, self);
            //         }
            //     });
 
            // },
        systemActivityTempDataModel: function (self) {
            //set oData model for ISP
            const componentName = self.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
            const componentPath = sap.ui.require.toUrl(componentName);
            const oDataModel = new ODataModel({
                serviceUrl: `${componentPath}/intis/sap/opu/odata/sap/ZSTAFFING_APP_2_SRV`
            });
            return oDataModel;
        },
        systemActivityDataModel: function (self) {
                //set oData model for ISP
                const componentName = self.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
                const componentPath = sap.ui.require.toUrl(componentName);
                // call ymr_srv service for solution areas
                const oDataModel = new ODataModel({
                    serviceUrl: `${componentPath}/int_pc/sap/opu/odata/sap/YACTIVITY_SRV`
                });
                return oDataModel;
 
            },
            _callActivityTempDataService: function (self, oActivityPaylod, sMethod) {
                const sBaseUrl = this._getWfServiceRuntimeBaseURL(self),
                    that = this,
                    sInstanceID = self.getView().getModel("wfInstanceModel").getProperty("/InstanceID"),
                    sUrl = sMethod === "GET" ? `MR_Activity_Details?$filter=Instance_Guid eq '${sInstanceID}'&$expand=_AInitiative,_AAddOpp,_ALand,_AMaterial,_ATaxonomy,_ATeam,_AFiles` : `MR_T_Activity`;

                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    url: `${sBaseUrl}/activity-/${sUrl}`,
                    data: sMethod === "POST" ? JSON.stringify(oActivityPaylod) : null,
                    type: sMethod,
                    success: function (oData) {
                        if (sMethod === "GET") {

                            if (oData.value.length) {
                                oData.value = oData.value.map(obj => {
                                    return {
                                        ...obj,
                                        to_AAddOpp: ("_AAddOpp" in obj) ? obj._AAddOpp : [],
                                        to_AInitiative: ("_AInitiative" in obj) ? obj._AInitiative : [],
                                        to_ALand: ("_ALand" in obj) ? obj._ALand : [],
                                        to_AMaterial: ("_AMaterial" in obj) ? obj._AMaterial : [],
                                        to_ATeam: ("_ATeam" in obj) ? obj._ATeam : [],
                                        to_AFiles: ("_AFiles" in obj) ? obj._AFiles : [],
                                        to_ATaxonomy: ("_ATaxonomy" in obj) ? obj._ATaxonomy : []
                                    };

                                });
                            }
                            const oActivityModel = new JSONModel();
                            oActivityModel.setData(oData);
                            self.getView().setModel(oActivityModel, "activityTempModel");

                        } else {
                            self.activityPostResData = Array.isArray( self.activityPostResData) && self.activityPostResData.length ? self.activityPostResData:[];
                            self.activityPostResData.push(oData)
                            return oData;
                        }


                    }.bind(this),
                    error: function (oError) {

                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            _getVariantData: function (self, isUpdateVariant) {
                const sBaseurl = this._getWfServiceRuntimeBaseURLRoleBased(self),
                    that = this;
                jQuery.ajax({
                    async: true,
                    contentType: "application/json",
                    url: `${sBaseurl}/wf/Yc_MR_Variant`,
                    type: "GET",
                    success: function (oData) {
                         sap.ui.core.BusyIndicator.hide();
                        if(!oData.value.filter(item => item.IsDefault).length){
                            //if no defualt varinat then set to all requests
                            oData.value.filter(item => item.Author === "SAP_ALL") && oData.value.filter(item => item.Author === "SAP_ALL").length ? oData.value.filter(item => item.Author === "SAP_ALL")[0].IsDefault = "X" : oData.value[0].IsDefault = "X" ;
                            
                        }
                        let oVariantMasterModel = new sap.ui.model.json.JSONModel();
                        let oDefaultVariant = oData.value.filter(item => item.IsDefault).length ? oData.value.filter(item => item.IsDefault)[0] : [];
                        oVariantMasterModel.setData({ results: oData.value });
                        self.getView().setModel(oVariantMasterModel, "mroDataVariant");
                        // oData.value[0].FilterString = "{'globalsearch':{'key':'globalsearch','value':'','visible':true},'account':[],'opportunity':[],'reqType':[],'reqId':[],'reqStatus':[],'task':[],'taskOwnerName':[],'taskOwnerRole':[],'salesOrg':[],'reqNameId':[]}";
                        if (!isUpdateVariant) {
                            let sFilterString = oDefaultVariant.FilterString.replace(/'/g, '"'),  // Replace single quotes around keys/values with double quotes
                                oFinalFilter = JSON.parse(sFilterString);  // Parse into
                             oFinalFilter.reqStartDate = oFinalFilter.reqStartDate ? new Date(oFinalFilter.reqStartDate) : null;
                            oFinalFilter.reqEndDate = oFinalFilter.reqEndDate ? new Date(oFinalFilter.reqEndDate) : null;
                            let oVaraiantDisplayModel = new sap.ui.model.json.JSONModel();
                            oVaraiantDisplayModel.setData(oFinalFilter);
                            self.variantId = oDefaultVariant.VariantGuid;
                            self.getView().setModel(oVaraiantDisplayModel, "variant");
                            self.getView().getModel("variants").setData(oDefaultVariant);
                            self.getView().getModel("variants").refresh();
                            self.getView().byId("variantButton").setText(oDefaultVariant.VariantName);
                            self.getView().byId("variantButton").data("VariantGuid", oDefaultVariant.VariantGuid);
                            let sSearchValue = self.getView().getModel("variant").getProperty("/globalsearch/value") ? self.getView().getModel("variant").getProperty("/globalsearch/value") : "";
                            self.getView().byId("filterbar")._oBasicSearchField.setValue(sSearchValue);
                            self.getView().getModel("variant").refresh();
                            self._setVariantData(oDefaultVariant);
                            self.getView().setBusy(false);
                        }else{
                             self.getView().setBusy(false);
                        }
                    }.bind(this),
                    error: function (oError) {
                        sap.ui.core.BusyIndicator.hide();
                        self.getView().setBusy(false);
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            _getManageVariantData: function (self, isDefaultVariant) {
                self.getView().setBusy(true);
                const sBaseurl = this._getWfServiceRuntimeBaseURLRoleBased(self),
                    that = this;
                jQuery.ajax({
                    async: true,
                    contentType: "application/json",
                    url: `${sBaseurl}/wf/Yc_MR_ManagedVariant`,
                    type: "GET",
                    success: function (oData) {
                       if(!oData.value.filter(item => item.IsDefault).length){
                            //if no defualt varinat then set to all requests
                             oData.value.filter(item => item.Author === "SAP_ALL") && oData.value.filter(item => item.Author === "SAP_ALL").length ? oData.value.filter(item => item.Author === "SAP_ALL")[0].IsDefault = "X" : oData.value[0].IsDefault = "X" ;
                            oData.value.filter(item => item.Author === "SAP_ALL") && oData.value.filter(item => item.Author === "SAP_ALL").length ? oData.value.filter(item => item.Author === "SAP_ALL")[0].Favourite = "X" : oData.value[0].Favourite = "X" ;
                            
                        }
                        self.getView().getModel("mroDataVariant").setData({ results: oData.value });
                        self.getView().getModel("mroDataVariant").refresh();
                        self.getView().setBusy(false);

                    }.bind(this),
                    error: function (oError) {
                        self.getView().setBusy(false);
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            _createVariantData: function (self, oEntry) {
                const sBaseurl = this._getWfServiceRuntimeBaseURL(self),
                    that = this;
                this.isDefault = oEntry._toUserVariant[0].isDefault;
                self.getView().setBusy(true);
                jQuery.ajax({
                    async: true,
                    contentType: "application/json",
                    url: `${sBaseurl}/wf/Variant`,
                    data: JSON.stringify(oEntry),
                    type: "POST",
                    success: function (oData) {
                        if (that.isDefault) {
                            let oVariantData = self.getView().getModel("mroDataVariant").getData().results,
                                oNewVariantGuid = oData.variantGuid,
                                aVariantPayload = oVariantData && oVariantData.length ? oVariantData.map(item => {
                                    // Create a new object to avoid mutating the original
                                    return {
                                        "variantGuid": item.VariantGuid,
                                        "isDefault": ""
                                    };
                                }) : [];
                            aVariantPayload.push({
                                "variantGuid": oNewVariantGuid,
                                "isDefault": "X"
                            })
                            let oFinalPayload = {
                                "userId": oData.author,
                                "VariantDetails": aVariantPayload
                            }
                            that._saveOrUpdateVariantData(self, oFinalPayload,true)
                        } else {
                            that._getVariantData(self);
                        }
                    }.bind(this),
                    error: function (oError) {
                        self.getView().setBusy(false);
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            _updateVariantData: function (self, oEntry, isSave) {
                const sBaseurl = this._getWfServiceRuntimeBaseURL(self),
                    that = this;
                jQuery.ajax({
                    async: true,
                    contentType: "application/json",
                    url: `${sBaseurl}/wf/Variant(${oEntry.variantGuid})`,
                    data: JSON.stringify(oEntry),
                    type: "PATCH",
                    success: function (oData) {
                        if (!isSave) {
                            self.getView().setBusy(false)
                            return oData;
                        } else {
                            if (oEntry._toUserVariant[0].isDefault) {
                                let oVariantData = self.getView().getModel("mroDataVariant").getData().results,
                                    oNewVariantGuid = oData.variantGuid,
                                    aVariantPayload = oVariantData && oVariantData.length ? oVariantData.map(item => {
                                        // Create a new object to avoid mutating the original
                                        return {
                                            "variantGuid": item.VariantGuid,
                                            "isDefault": ""
                                        };
                                    }) : [];
                                aVariantPayload.filter(item=>item.variantGuid === oEntry.variantGuid)[0].isDefault = "X";
                                let oFinalPayload = {
                                    "userId": oData.author,
                                    "VariantDetails": aVariantPayload
                                }
                                that._saveOrUpdateVariantData(self, oFinalPayload,false)
                            } else {
                                that._getVariantData(self);
                            }
                        }

                    }.bind(this),
                    error: function (oError) {
                        self.getView().setBusy(false);
                        return false;
                        ErrorHandle.setErrorMessage(oError, self);

                    }
                });
            },
            _deleteVariantData: function (self, variantGuid) {
                const sBaseurl = this._getWfServiceRuntimeBaseURL(self),
                    that = this;
                jQuery.ajax({
                    async: true,
                    contentType: "application/json",
                    url: `${sBaseurl}/wf/Variant(${variantGuid})`,
                    type: "DELETE",
                    success: function (oData) {
                      
                        //that._getManageVariantData(self);
                          that._getVariantData(self)
                          that._getManageVariantData(self);
                    }.bind(this),
                    error: function (oError) {
                        self.getView().setBusy(false);
                        ErrorHandle.setErrorMessage(oError, self);

                    }
                });
            },
            _saveOrUpdateVariantData: function (self, oPayload,isUpdateVariant) {
                const sBaseurl = this._getWfServiceRuntimeBaseURLRoleBased(self),
                    that = this;
                jQuery.ajax({
                    async: true,
                    contentType: "application/json",
                    url: `${sBaseurl}/wf/SaveUserVariantData`,
                    data: JSON.stringify(oPayload),
                    type: "POST",
                    success: function (oData) {
                        that._getVariantData(self,isUpdateVariant);

                    }.bind(this),
                    error: function (oError) {
                        self.getView().setBusy(false);
                        ErrorHandle.setErrorMessage(oError, self);
                    }
                });
            },
            fnGetActionHistory: function (sInstanceID, self) {
                var workflowBaseurl = this._getWfServiceRuntimeBaseURL(self);
                return new Promise(function (resolve, reject) {
                    $.ajax({
                        url: workflowBaseurl + "/wf/YC_MR_T_WfHistory?$orderby=Date desc&$filter=InstanceID eq " + sInstanceID,
                        dataType: 'json',
                        async: false,
                        method: "GET",
                        success: function (data) {
                            resolve(data.value)
                        },
                        error: function (err) {
                            reject(err)
                        }

                    })
                })

            },
            /**
            * set CPI destination
            * @param {obj} self controller scope
            * @function _getCPIEndPoint
            */
            _getCPIEndPoint: function (self) {
                return this._getRuntimeBaseURL(self) + "/ext_CPI";
            },
            		   /**
         * 
         * Call CPI Service to add current manager or resource
         * @param {obj} self controller scope
         * @param {obj} processContext Worklow payload
         * @param {string} taskId Workflow instance id
         * @param {string} sDecision Decision of user task (Approve)
         * @function _updateVATCpi
         */
            _updateVATCpi: function (self, oApprover, processContext, taskId, sDecision) {
                let workflowBaseurl = this._getCPIEndPoint(self);
                delete oApprover.userId;
                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    url: `${workflowBaseurl}/http/presales/cp-workflow-req`,
                    data: JSON.stringify(oApprover),
                    type: "POST",
                    success: function (oData) {
                        //set updated opportunity data
                        let oModel = self.getView().getModel();
                        oModel.setProperty("/OPP_DATA/d/GUID", oData.d.GUID);
                        oModel.setProperty("/OPP_DATA/d/CHANGED_AT", oData.d.CHANGED_AT);
                        oModel.setProperty("/OPP_DATA/d/EXPECT_END", oData.d.EXPECT_END);
                        oModel.setProperty("/OPP_DATA/d/EXPECT_END", oData.d.EXPECT_END);
                        if (oData.d.PartiesInvolved && oData.d.PartiesInvolved.results) {
                            oModel.setProperty("/OPP_DATA/d/PartiesInvolved", oData.d.PartiesInvolved);
                        }
                        oModel.refresh(true);
                        //Call VAT Team member servoce
                        self._callAllActivityRegServices(self, processContext, taskId, sDecision);

                    }.bind(this),
                    error: function (oError) {
                        //exception handling
                        self._setVATExceptionMsg(processContext, taskId, sDecision, oError)
                        sap.ui.core.BusyIndicator.hide();
                    }
                });
            },
              /**
         * 
         * @description Check opp/account owner is active or not
         * @param {obj} oController controller scope
         * @param {obj} aEmpIds  opp/account owner Ids
         * @function checkUserActive
         */
            checkUserActive: function (oController, aEmpIds) {
                const oLSSystemModel = this.systemLSUserDetailsDataModel(oController,true);
                // Create individual filters
                if (aEmpIds.length) {
                    let aFilters = aEmpIds.map(function (sId) {
                        return new sap.ui.model.Filter("EmpId", sap.ui.model.FilterOperator.EQ, sId);
                    });
                    // Combine filters with OR logic
                    let oCombinedFilter = new sap.ui.model.Filter({
                        filters: aFilters,
                        and: false  // false = OR, true = AND
                    });

                    return new Promise(function (resolve, reject) {
                        oLSSystemModel.read("/YC_OR_T_PERSONBOOK", {
                            filters: [oCombinedFilter],
                            success: function (oData) {
                               resolve(oData);
                            },
                            error: function (oError) {
                                 ErrorHandle.setErrorMessage(oError, oController);
                            }
                        });

                    });
                } else {
                    let oData = {
                        results: []
                    }
                    return oData;
                }
            }
        }
    });


