sap.ui.define([
	"sap/m/library",
	"sap/ui/model/json/JSONModel",
	"com/dealsupport/melodyrequest/model/models",
    "sap/m/MessageBox"
], function (mobileLibrary, JSONModel, errorHandling, MessageBox) {
	"use strict";
	var URLHelper = mobileLibrary.URLHelper;
	return {
		ErrorMessageBox: function (sMsg) {
			sap.m.MessageBox.error(sMsg, {
				title: "Error",
				onClose: null,
				styleClass: "",
				initialFocus: null,
				textDirection: sap.ui.core.TextDirection.Inherit
			});
		},

		callUserApi: function (sSearch, topValue, skipValue, oController) {
			sap.ui.core.BusyIndicator.show(0);
			var workflowBaseurl = this._getWfServiceRuntimeBaseURL(oController);
			$.ajax({
				contentType: "application/json",
				type: "GET",
				url: `${workflowBaseurl}/Employees?$count=true&$search="${sSearch}"&$skip=${skipValue}&$top=${topValue}`,
				success: function (data) {
					var oData = data.value;
					for (var i = 0; i < oData.length; i++) {
						oData[i].fullName = `${oData[i].firstName} ${oData[i].lastName}`;
					}
					var oUsermodel = new JSONModel(oData);
					oController._ovalueHelpUserFragment.getTableAsync().then(function (oTable) {
						oTable.setModel(oUsermodel);

						if (oTable.bindRows) {
							oTable.bindAggregation("rows", "/");
						}
						oController._ovalueHelpUserFragment.update();
					}.bind(oController));
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide();
					errorHandling._showErrorMessageBox(oError, oController);

				}
			});
		},
		_getWfServiceRuntimeBaseURL: function (self) {
			return this._getRuntimeBaseURL(self) + "/sapit-employee-data";
		},
		_getRuntimeBaseURL: function (self) {
			var componentName = appView.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
			var componentPath = sap.ui.require.toUrl(componentName);
			return componentPath;
		},
		callEmpApi: function (userId, oevt, self, sName, oValType,isListView) {
			var sQuery = "/Employees?$count=true&$filter=";
			var arr;
			if (sName !== "Recipients") {
			    arr = oValType === "ID" ? userId.split(";") : userId.split(",");
			}else{
				arr = userId;
			}
			var array = [];
			var sArr = [];
			var sArrLen = arr.length;
			for (var i = 0; i < arr.length; i++) {
				var searchUserId = arr[i].trim();
				if (oValType === "ID") {
					var sQueryApi = `${sQuery}(ID eq '${searchUserId}')`
					this.funcApi(searchUserId, sQueryApi, this.empData, oevt, self, array, sArrLen, sArr, sName,isListView, this.funcerror, i);
				} else if (oValType === "Email") {
					var sQueryApi = `${sQuery}(email eq '${searchUserId}')`
					this.funcApi(searchUserId, sQueryApi, this.empData, oevt, self, array, sArrLen, sArr, sName,isListView, this.funcerror, i);
				}
			}
		},
		funcApi: function (searchUserId, sQueryApi, empData, oevt, self, array, sArrLen, sArr, sName,isListView, funcerror, i) {
			var workflowBaseurl = this._getWfServiceRuntimeBaseURL(self);
			jQuery.ajax({
				contentType: "application/json",
				url: `${workflowBaseurl}${sQueryApi}`,
				type: "GET",
				success: function (oData) {
					var value = oData.value[0];
					return empData(value, oevt, self, array, sArrLen, sArr, sName,isListView);

				}.bind(this),
				error: function (oError) {
					if(sArrLen-1 === i){
						return funcerror(oError);
					}
				}
			});
		},
		empData: function (value, oevt, self, array, sArrLen, sArr, sName,isListView) {
			var arr = value;
			sArr.push(arr);
			if(value !== undefined){
				array.push(arr)
			}
			var oModel = new sap.ui.model.json.JSONModel();
			if (sArr.length == sArrLen) {
				for(var i=0 ; i< array.length ; i++){
					function capitalizeFirstLetter(sName) {
                     return sName.toLowerCase().split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
                }
            
                let formattedFirstName = capitalizeFirstLetter(array[i].firstName);
                let formattedLastName = capitalizeFirstLetter(array[i].lastName);
                    array[i].firstName = formattedFirstName;
					array[i].lastName = formattedLastName;
					array[i].fullName = formattedLastName ? `${formattedFirstName} ${formattedLastName}` : formattedFirstName;
				}
				array.sort((a, b) => {
					const empNameA = a["fullName"].toUpperCase(); // ignore upper and lowercase
					const empNameB = b["fullName"].toUpperCase(); // ignore upper and lowercase
					if (empNameA < empNameB) {
					  return -1;
					}
					if (empNameA > empNameB) {
					  return 1;
					}
				  
					// names must be equal
					return 0;
				  })
	
				oModel.setData(array);
				//    self.getView().setModel(oModel, "EmployeeDetails");
				if (isListView) {
					self.QuickListView(oModel, oevt, self, sName);
				} else {
					self.QuickViewCard(oModel, oevt, self, sName);
				}

			}

		},
		funcerror: function (oError, self) {
			MessageBox.error(oError.statusText, {
				contentWidth: "300px"
			});
			sap.ui.core.BusyIndicator.hide();
		},
		_contactslistFragment: function (EmployeeDetails, oevt, self, sName) {
			if (!this._contactFragmentsList) {
				this._contactFragmentsList = sap.ui.xmlfragment("com.dealsupport.melodyrequest.fragments.EmployeesDetail", this);
				self.getView().addDependent(this._contactFragmentsList);
			}
			var aModel = new sap.ui.model.json.JSONModel(EmployeeDetails);
			this._contactFragmentsList.setModel(aModel);
			this._contactFragmentsList.setProperty("title", sName);
			return this._contactFragmentsList;
		},
		onHandleokPress: function () {
			// this.EmpDetailsFrag.close();
			this._contactslistFragment().close();
		},
		updateImmediateDelegate: function (oDeleData) {
			// jQuery.ajax({
			// 	async: false,
			// 	contentType: "application/json",
			// 	url: 'https://sapit-presales-dev-presales-engagement-presales-germany4a2cc93c.cfapps.eu10.hana.ondemand.com/resources/Substitute_tab',
			// 	data: oDeleData,
			// 	processData: true,
			// 	type: "POST",
			// 	success: function (data) {
			// 		console.log("success" + data);
			// 	}.bind(this),
			// 	error: function (oError) {
			// 		return funcerror(oError);
			// 	}
			// });
		},

		currentAvatarDisplay: function (oEvent) {
			var userId = oEvent;
			return "https://avatars.wdf.sap.corp/avatar/" + userId;
		},

		onPressEmpEmail: function(oEvent){
			var sUrl = oEvent.getSource().getProperty("text");
            URLHelper.triggerEmail(sUrl, "Info Request - MRR", false, false, false, true);
		},
		_setPFCdesc: function (element) {
				if(element){
			const TrpcL1Desc = element.TGlobal 
			const TrpcL2Desc = element.Region
			const TrpcL3Desc = element.Mu 
			const TrpcL4Desc =  element.MuBelow
		   
			//var sSelectedGuid = element && element.Guid ? element.Guid : "00000000-0000-0000-0000-000000000000";
			let sSelectedDesc = "";

			if (TrpcL1Desc && TrpcL1Desc !== "") {
				sSelectedDesc += TrpcL1Desc;

				if (TrpcL2Desc && TrpcL2Desc !== "") {
					sSelectedDesc += " > " + TrpcL2Desc;

					if (TrpcL3Desc && TrpcL3Desc !== "") {
						sSelectedDesc += " > " + TrpcL3Desc;

						if (TrpcL4Desc && TrpcL4Desc !== "") {
							sSelectedDesc += " > " + TrpcL4Desc;
						}
					}
				}
			}
			return sSelectedDesc;
		}else{
			return "";
		}
		},
		getProcessorsUserInfo: function (sUserIdArr , self,isNamedContact) {
			var workflowBaseurl = this._getWfServiceRuntimeBaseURL(self);
			const results = [];
			const that=this;
			function fetchDataForElement(element) {
				//const sUrl = isNamedContact ? element.UserID : element;
				return new Promise((resolve, reject) => {
							const value = {
								email: element.Email,
								ID: element.UserId,
								fullName: element.EmpFullName
							};
							
							const oPFCMasterData = self.getView().getModel("territoriesMaster").getData();
							const oFilterPFCMasterData = oPFCMasterData.filter((pfc) => pfc.TrpcId === element.TrpcId)[0];
							oFilterPFCMasterData.formattedDesc = that._setPFCdesc(oFilterPFCMasterData);
							value.ProfitCenterDetails = oFilterPFCMasterData;
							results.push(value);
							resolve(value);
				});
			}
			

			function fetchDataForAllElements() {
				const promises = sUserIdArr.map(element => fetchDataForElement(element));
				return Promise.all(promises);
			}
			fetchDataForAllElements()
				.then(approversData => {
					return approversData
				})
				.catch(error => {
				});
				return results;
		},
		getUserInfo: function (sUserIdArr , self) {
			var workflowBaseurl = this._getWfServiceRuntimeBaseURL(self);
			const results = [];
			function fetchDataForElement(element) {
				return new Promise((resolve, reject) => {
					
					jQuery.ajax({
						contentType: "application/json",
						url: `${workflowBaseurl}/Employees?$count=true&$filter=(ID eq '${element}')`,
						type: "GET",
						async: false,
						success: function (oData) {
							var value = oData.value[0];
							results.push(value);
							resolve(value);
						},
						error: function (oError) {
							reject(oError);
						}
					});
				});
			}
			

			function fetchDataForAllElements() {
				const promises = sUserIdArr.map(element => fetchDataForElement(element));
				return Promise.all(promises);
			}
			fetchDataForAllElements()
				.then(approversData => {
					// console.log("Data fetched for all elements:", data);
					return approversData
				})
				.catch(error => {
					console.error("Error fetching data for all elements:", error);
				});
				return results;
		}

	};

});

