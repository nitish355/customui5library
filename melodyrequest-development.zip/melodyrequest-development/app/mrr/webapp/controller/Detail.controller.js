sap.ui.define(
  [
    "sap/m/library",
    "sap/ui/core/mvc/Controller",
    "com/dealsupport/melodyrequest/model/models",
    "com/dealsupport/melodyrequest/model/users",
    'sap/ui/core/Fragment',
    "sap/m/MessageBox",
    "com/dealsupport/melodyrequest/model/formatter",
    "com/dealsupport/melodyrequest/control/ValueHelpUserCommon",
    "sap/m/Token",
    "com/dealsupport/melodyrequest/control/Common",
    "sap/m/MessageToast"
  ],
  function (mobileLibrary, BaseController, models, users, Fragment, MessageBox, formatter, UserCommon, Token, Common, MessageToast) {
    "use strict";
    var URLHelper = mobileLibrary.URLHelper;
    return BaseController.extend("com.dealsupport.melodyrequest.controller.Detail", {
      formatter: formatter,
      onInit() {
        this.getView().addStyleClass(appView.getOwnerComponent().getContentDensityClass());
        var oAppConstantsModel = appView.getOwnerComponent().getModel("appConstants");
        var sDownTimeFlag = oAppConstantsModel.getProperty("/DownTime/0/Operational_Status");
        if (sDownTimeFlag) {
          appView.getOwnerComponent().getRouter().navTo("NotFound");
        } else {
          this._onObjectMatched();
        }
      },
      _onObjectMatched: function (oEvent) {
        appView.getOwnerComponent().getModel("appConstants").setProperty("/AdminDetail",this);
        var sGUID = appView.getView().getModel("AdminResources").getData().selectedGuid;
        var sMode = "Edit";
        this._resetAllValidation();
        this._getAdminDetails(sGUID, sMode);
        appView._setSelectedMenuKey();
      },
      onCreate: function () {
        this.onSave();
      },
      _getAdminDetails: function (sGUID, sMode) {
        sap.ui.core.BusyIndicator.show(0);
        var oObjectPage = this.getView().byId("idReqAreaDetailObjectPage");
        // oObjectPage.setShowFooter(false);
        this.getView().byId("idFooter").setVisible(false);
        var sUrl =
          `/AdminResources?$filter=GUID eq (${sGUID})`;
        models.getAdminViewDetail(this.fnSuccessCallback, this.fnErrorCallback, appView, sUrl, sMode, this);
      },
    
      fnSuccessCallback: function (oResponse, self, sMode, that) {
        var oModel = new sap.ui.model.json.JSONModel();
        var oResponse = oResponse.value[0];
        var aPublicSalesOrg  = self.getView().getModel("salesOrgModel").getData().value;               
        const sPublisSalesOrg = aPublicSalesOrg.filter((org) => org.ID === oResponse.orgID);
         //code for no mapping #82
        if (sPublisSalesOrg.length) {
          oResponse.orgName = sPublisSalesOrg[0].Desc;
        }
        oModel.setData(oResponse);
        self.getView().setModel(oModel, "AdminDetailModel");
        var oModel = self.getView().getModel("AdminDetailModel");
        if (sMode === "Create" && !oResponse.orgID) {
          oModel.setProperty("/displayMode", false);
          oModel.setProperty("/editMode", true);
          oModel.setProperty("/required", true);
          oModel.setProperty("/updateMode", false);
          oModel.setProperty("/createMode", true);
          self.onDetailEdit(sMode);
        } else {
          oModel.setProperty("/displayMode", true);
          oModel.setProperty("/editMode", false);
          oModel.setProperty("/required", false);
        }
        sap.ui.core.BusyIndicator.hide();
        var sSalesOrg_ID = oModel.getProperty("/orgID") ?
                          oModel.getProperty("/orgID") :
                          self.getView().byId("id-reqArea-selectSalesOrg").getSelectedKey();
                          that._callRequestAreaAPI(sSalesOrg_ID, self, that);
      },
      _callRequestAreaAPI:function(sSalesOrg_ID, self, that){
        const sUrl =`/Public_ReqArea?$filter=orgID eq '${sSalesOrg_ID}'`;
        models.getReqAreaLists(that.fnReqAreaSuccessCallback, that.fnReqAreaErrorCallback, self, sUrl);

      },
      fnErrorCallback: function (oError, self) {
        MessageBox.error(oError.responseText, {
          contentWidth: "600px"
        });
        sap.ui.core.BusyIndicator.hide();
      },
      SalesOrgDesc: function (oValue) {
        switch (oValue) {
          case "71":
            return ("India");
            break;
          case "23":
            return ("Germany");
            break;
          case "2":
            return ("Switzerland");
            break;
          case "3":
            return ("Austria");
            break;
          case "6":
            return ("Spain");
            break;
          default:
            return oValue;
            break;
        }
      },
      onDetailEdit: function (sMode) {
        var oModel = this.getView().getModel("AdminDetailModel");
        this._resetAllValidation();
        if (sMode !== "Create") {
          oModel.setProperty("/displayMode", false);
          oModel.setProperty("/editMode", true);
          oModel.setProperty("/required", true);
          oModel.setProperty("/updateMode", true);
          oModel.setProperty("/createMode", false);
        }
        var oObjectPage = this.getView().byId("idReqAreaDetailObjectPage");
        this.getView().byId("idFooter").setVisible(true);
        var oMultiInputResources = this.getView().byId("id-reqArea-multiInput-resources");
        var oMultiInputApprovers = this.getView().byId("id-reqArea-multiInput-approvers");
        var oMultiInputSubApprovers = this.getView().byId("id-reqArea-multiInput-subApprovers");
        var oInputReqAreas = this.getView().byId("id-Admin-InputRequestArea");
        var sResources = oModel.getProperty("/Resources");
        var aResources = sMode !== "Create" ? sResources.split(';') : [];
        var sApprovers = oModel.getProperty("/Approvers");
        var aApprovers = sMode !== "Create" ? sApprovers.split(';') : [];
        var sSubApprovers = oModel.getProperty("/SubstituteApprovers");
        var aSubApprovers = sMode !== "Create" ? sSubApprovers.split(';') : [];
        var sReqArea = sMode !== "Create" ? oModel.getProperty("/RequestArea") : "";
        var sSalesOrg = sMode !== "Create" ? oModel.getProperty("/orgID") : "";

        //add resources token
        this.setUserMultiInputValue(oMultiInputResources, aResources);
        //add approvers token
        this.setUserMultiInputValue(oMultiInputApprovers, aApprovers);
        //add sub approvers token
        this.setUserMultiInputValue(oMultiInputSubApprovers, aSubApprovers);

        this.getView().byId("id-reqArea-selectSalesOrg").setSelectedKey(sSalesOrg);
        oInputReqAreas.setValue(sReqArea);

      },
      setUserMultiInputValue: function (oMultiInput, aUsers) {
        oMultiInput.removeAllTokens();
        aUsers.forEach(function (subApprover) {
          oMultiInput.addToken(new Token({
            key: subApprover,
            text: subApprover
          }));
        });
      },
      onCancelRequest: function () {
        var oModel = this.getView().getModel("AdminDetailModel");
        this.getView().byId("idFooter").setVisible(false);
        oModel.setProperty("/displayMode", true);
        oModel.setProperty("/editMode", false);
        oModel.setProperty("/required", false);
        var sSalesOrg_ID = oModel.getProperty("orgID") ?
        oModel.getProperty("orgID") :
        this.getView().byId("id-reqArea-selectSalesOrg").getSelectedKey();
        this._callRequestAreaAPI(sSalesOrg_ID,this);
        this._resetAllValidation();
      },
      onDiscard: function () {
        var that = this;
        that._onDelete(that);
      },
      _onDelete: function (that) {
        var oModel = that.getView().getModel("AdminDetailModel");
        var sGUID = oModel.getProperty("/GUID");
        sap.ui.core.BusyIndicator.show(0);
        var sUrl =
          `/AdminResources(GUID=${sGUID})`
        models.deleteAdminGUID(that.fnSuccessDeleteAdminGUIDDeleteCallback, that.fnErrorDeleteAdminGUIDCallback, that, sUrl);
      },
      onDelete: function () {
        var oModel = this.getView().getModel("AdminDetailModel");
        var sReqArea = oModel.getProperty("/RequestArea");
        var sSalesOrgName = oModel.getProperty("/orgName");
        var that = this;
        MessageBox.show(
          `Are you sure want to delete the configuration ( ${sReqArea}(${sSalesOrgName}) )?`, {
          icon: MessageBox.Icon.WARNING,
          title: "Delete Confirmation",
          actions: [MessageBox.Action.YES, MessageBox.Action.NO],
          emphasizedAction: MessageBox.Action.YES,
          onClose: function (oAction) {
            if (oAction === MessageBox.Action.YES) {
              that._onDelete(that);
            }
          }
        }
        );
      },
      fnSuccessDeleteAdminGUIDDeleteCallback: function (oResponse, self, sMode) {
        sap.ui.core.BusyIndicator.hide();
        self.getOwnerComponent().getRouter().navTo("ReqArea");
      },
      fnErrorDeleteAdminGUIDCallback: function (oError, self) {
        MessageBox.error(oError.responseText, {
          contentWidth: "600px"
        });
        sap.ui.core.BusyIndicator.hide();
      },
      onSavedet: function () {
        // var sCountry = this.byId("idSelect").mProperties.selectedKey;
        var sRequestArea = this.byId("idInpReqArea").getValue();
        var sApprovers = this.byId("idInpApprovers").getValue();
        var sSubsApp = this.byId("idInpSubsApp").getValue();
        var sResources = this.byId("idInpResources").getValue();
        var mydata = {
          "Approvers": sApprovers,
          "RequestArea": sRequestArea,
          "Resources": sResources,
          "SubstituteApprovers": sSubsApp
        };
        var bValidationError = false;
        if (!this.byId("idInpReqArea").getValue()) {
          this.byId("idInpReqArea").setValueState("Error");
          bValidationError = true;
        }
        if (!this.byId("idInpApprovers").getValue()) {
          this.byId("idInpApprovers").setValueState("Error");
          bValidationError = true;
        }
        if (!this.byId("idInpSubsApp").getValue()) {
          this.byId("idInpSubsApp").setValueState("Error");
          bValidationError = true;
        }
        if (!this.byId("idInpResources").getValue()) {
          this.byId("idInpResources").setValueState("Error");
          bValidationError = true;
        }
        if (!bValidationError) {
          var sInstanceID = this.getView().getModel("AdminDetail").oData.GUID;
          var sIsActiveEntity = this.getView().getModel("AdminDetail").oData.IsActiveEntity;
          sap.ui.core.BusyIndicator.show(0);
          this.sQueryParams = "/AdminResources(GUID=" + sInstanceID + ",IsActiveEntity=" + sIsActiveEntity +
            ")/ResourcesService.draftPrepare";
          this.sFinalQueryParams = `${this.sQueryParams}`;
          //GET Call for wf instance details
          models.getAdminEditDetail(this.fnSuccessUpdater, this.fnErrorFilterCallback, appView, this.sFinalQueryParams, mydata);
          this.getView().getModel("AdminDetail").refresh();
        } else {
          sap.m.MessageToast.show("Fill all the details");
        }
      },
      fnSuccessUpdater: function () {
        this.getView().getModel("AdminDetail").refresh();
      },
      //user dialog
      onUserValueHelpRequested: function (oEvent) {
        let isUserID = true;
        this.oMultiInputID = oEvent.getParameter("id");
        const oMultiInput = this.getView().byId(this.oMultiInputID);
        const i18nModel = appView.getOwnerComponent().getModel("i18n").getResourceBundle();
        let sLabel;
        switch (true) {
          case this.oMultiInputID.includes("id-reqArea-multiInput-approvers"):
            sLabel = i18nModel.getText("approvers");
            break;
          case this.oMultiInputID.includes("id-reqArea-multiInput-resources"):
            sLabel = i18nModel.getText("resources");
            break;
          case this.oMultiInputID.includes("id-reqArea-multiInput-subApprovers"):
            sLabel = i18nModel.getText("subApprovers");
            break;
          default:
            sLabel = i18nModel.getText("users");
            break;  
        }
        Common._onUserValueHelpRequested(this, oMultiInput, isUserID,sLabel);
      },
      onFilterBarUserSearch: function () {
        Common._onFilterBarUserSearch(this)
      },
      _onAddSelectedUser: function (evt, that) {
        Common.__onAddSelectedUser(evt, that)
      },
      onValueHelpUserCancelPress: function () {
        UserCommon._onValueHelpUserCancelPress(this);
      },
      onUserSearchValueChange: function (oEvent) {
        UserCommon._onUserSearchValueChange(oEvent, this._ovalueHelpUserFragment);
      },
      onValueHelpUserAfterClose: function () {
        UserCommon._onValueHelpUserAfterClose(this);
      },
      onValueHelpUserOkPress: function (oEvent) {
        var oMultiInput = this.getView().byId(this.oMultiInputID);
        if (oEvent.getParameter("tokens").length) {
          oMultiInput.setValueState("None");
        } else {
          oMultiInput.setValueState("Error");
        }
        Common._onValueHelpUserOkPress(oEvent, oMultiInput, this)
      },
      onUserTokenUpdate: function (oEvent) {
        if (oEvent.getSource().getTokens().length === 1) {
          oEvent.getSource().setValueState("Error");
        } else {
          oEvent.getSource().setValueState("None");
        }
      },
      //valueHelp dialog for Request Area
      onRequestAreaValueHelpRequested: function (oEvent) {
        var isSingleSelect = true;
        this.sIdMultiInputReqArea = oEvent.getParameter("id");
        Common._onRequestAreaValueHelpRequested(oEvent, this, isSingleSelect);
      },
      handleReqAreaValueHelpSearch: function (evt) {
        Common._handleReqAreaValueHelpSearch(evt);
      },
      handleReqAreaValueHelpClose: function (evt) {
        var isSingleSelect = true;
        var oMultiInputReqArea = this.getView().byId(this.sIdMultiInputReqArea);
        if (evt.getParameter("selectedItem").length) {
          oMultiInputReqArea.setValueState("Error");
        } else {
          oMultiInputReqArea.setValueState("None");
        }
        Common._handleReqAreaValueHelpClose(evt, oMultiInputReqArea, isSingleSelect);
      },
      onSave: function () {
        var oModel = this.getView().getModel("AdminDetailModel");
        var sGUID = oModel.getProperty("/GUID");
        var sSalesOrgId = this.byId("id-reqArea-selectSalesOrg").getSelectedKey();
        const sReqArea = oModel.getData().RequestArea;;

        var aResourceTokens = this.byId("id-reqArea-multiInput-resources").getTokens();
        var aApproverTokens = this.byId("id-reqArea-multiInput-approvers").getTokens();
        var aSubApproverTokens = this.byId("id-reqArea-multiInput-subApprovers").getTokens();
        var sResources = this.formUserPayloadText(aResourceTokens);
        var sApprovers = this.formUserPayloadText(aApproverTokens);
        var sSubApprovers = this.formUserPayloadText(aSubApproverTokens);
        var bValidationError = false;
        var i18nModel = appView.getOwnerComponent().getModel("i18n").getResourceBundle();
        if (!aResourceTokens.length) {
          this.byId("id-reqArea-multiInput-resources").setValueState("Error");
          bValidationError = true;
        }
        if (!aApproverTokens.length) {
          this.byId("id-reqArea-multiInput-approvers").setValueState("Error");
          bValidationError = true;
        }
        if (!aSubApproverTokens.length) {
          this.byId("id-reqArea-multiInput-subApprovers").setValueState("Error");
          bValidationError = true;
        }
        if (!bValidationError) {
          sap.ui.core.BusyIndicator.show(0);
          var sPostUrl =
            `/UpdateResources(GUID=${sGUID})`
          var oPostPayload = {
            "Resources": sResources,
            "Approvers": sApprovers,
            "SubstituteApprovers": sSubApprovers
          }
          if (oModel.getProperty("/orgID") === sSalesOrgId && oModel.getProperty("/RequestArea") === sReqArea) {
            models.postAdminDetails(this.fnSuccessPostCallback, this.fnErrorPostCallback, appView, oPostPayload, sPostUrl, this);
          } else {
            var sFilterParams = `(RequestArea eq '${sReqArea}') and (orgID eq '${sSalesOrgId}')`,
            sFilterParams = sFilterParams.replaceAll("&", "%26"),
            sUrl = `/AdminResources?$count=true&$filter=${sFilterParams}`;
            models.getAdminViewFilterLists(this.fnSuccessFilterCallback, this.fnErrorFilterCallback, appView, sUrl,oPostPayload,sPostUrl, this);
          }


        } else {
          MessageToast.show(i18nModel.getText("genericValidationMsg"));
        }

      },
      fnSuccessFilterCallback: function (oResult, self, oPostPayload,sPostUrl, that) {
        var oSalesOrgSelect = self.getView().byId("id-reqArea-selectSalesOrg");
        var sReqArea = oPostPayload.RequestArea;
        var sSalesOrgName = oSalesOrgSelect ? oSalesOrgSelect.getSelectedItem().getText() : "";
       
        if (oResult.value.length) {
          var sWarningMessage = oSalesOrgSelect
            ? `The Request Area "${sReqArea}" for Sales Org "${sSalesOrgName}" Configuration already exists.`
            : `The Request Area for "${sSalesOrgName}" Configuration already exists.`;
       
          MessageBox.warning(sWarningMessage);
        } else {
          models.postAdminDetails(that.fnSuccessPostCallback, that.fnErrorPostCallback,self,oPostPayload,sPostUrl,that);
        }
                sap.ui.core.BusyIndicator.hide();
      },
      fnErrorFilterCallback: function (oError, self) {
        MessageBox.error(oError.responseText, {
          contentWidth: "600px"
        });
        sap.ui.core.BusyIndicator.hide();
      },

      _resetAllValidation: function () {
        this.byId("id-Admin-InputRequestArea").setValueState("None");
        this.byId("id-reqArea-multiInput-resources").setValueState("None");
        this.byId("id-reqArea-multiInput-approvers").setValueState("None");
        this.byId("id-reqArea-multiInput-subApprovers").setValueState("None");
      },
      onChange: function (oEvent) {
        var oInput = oEvent.getSource();
        if (oEvent.getParameter("value")) {
          oInput.setProperty("valueState", "None");
        }
      },
      fnSuccessPostCallback: function (self , that) {
        var oModel = self.getView().getModel("AdminDetailModel");
        var sGUID = oModel.getProperty("/GUID");
        that._getAdminDetails(sGUID);
      },
      fnErrorPostCallback: function (oError, self) {
        MessageBox.error(oError.responseText, {
          contentWidth: "600px"
        });
        sap.ui.core.BusyIndicator.hide();
      },
      formUserPayloadText: function (aResourceTokens) {
        var aTokenKeys = [];
        aResourceTokens.forEach(function (sToken) {
          aTokenKeys.push(sToken.getKey())
        });
        return aTokenKeys.join(';');
      },
      toAdminHomePage: function () {
        var oDialog = this.byId("userReqDetailDialog");
				if (oDialog) {
					oDialog.close();
				}
      },

      onResourceContactlisticon: function (oEvent) {
        sap.ui.core.BusyIndicator.show(0);
        var sResources = oEvent.getSource().getModel("AdminDetailModel").oData.Resources;
        var sName = "Resources";
        var oValType = "ID"
        users.callEmpApi(sResources, oEvent, this, sName, oValType);

      },
      onAppContactlisticon: function (oEvent) {
        sap.ui.core.BusyIndicator.show(0);
        var sResources = oEvent.getSource().getModel("AdminDetailModel").oData.Approvers;
        var sName = "Approvers"
        var oValType = "ID"
        users.callEmpApi(sResources, oEvent, this, sName, oValType);

      },
      onSubsAppContactlisticon: function (oEvent) {
        sap.ui.core.BusyIndicator.show(0);
        var sResources = oEvent.getSource().getModel("AdminDetailModel").oData.SubstituteApprovers;
        var sName = "Substitute Approvers"
        var oValType = "ID"
        users.callEmpApi(sResources, oEvent, this, sName, oValType);

      },
      QuickViewCard: function (oModel, oevt, self, sName) {
        var oButton = oevt.getSource();
        self.getView().setModel(oModel, "EmpDetails");
        var EmployeeDetails = this.getView().getModel("EmpDetails");
        users._contactslistFragment(EmployeeDetails, oevt, self, sName).openBy(oButton);
        sap.ui.core.BusyIndicator.hide();
      },


      onPressEmpEmail: function (oEvent) {
        var sUrl = oEvent.getSource().getProperty("text");
        URLHelper.triggerEmail(sUrl, "Info Request - MRR", false, false, false, true);
      },
      onImmediateDelegation: function (oEvent) {
        var oView = this.getView();
        var oDeleDialog = oView.byId("newVariantFragment");
        if (!oDeleDialog) {
          oDeleDialog = sap.ui.xmlfragment(oView.getId(), "com.dealsupport.melodyrequest.fragments.DelegateFragment", this);
          oView.addDependent(oDeleDialog);
        }
        var oButton = oEvent.getSource();
        oDeleDialog.open(oButton);
      },
      onSelectDelegation: function () {
        this.byId("idDeleCalender").setVisible(true);
        this.byId("idDeleLabel").setVisible(true);
        this.byId("id-reqArea-multiInput-delegate").setVisible(true);
      },

      handleCalendarSelect: function (oEvent) {
        var oCalendar = oEvent.getSource();
        oCalendar.getSelectedDates()[0];
      },
      handleImmediateDelePress: function (oEvent) {
        var sStartDate = this.getView().byId("idDeleCalender").getSelectedDates()[0].getProperty("startDate");
        var sEndDate = this.getView().byId("idDeleCalender").getSelectedDates()[0].getProperty("endDate");
        var sDelegate = this.getView().byId("id-reqArea-multiInput-delegate").getProperty("_semanticFormValue");
        var sGUID = this.getView().getModel("AdminDetailModel").getData().GUID;
        var sOwner = this.getView().getModel("userDetails").getData().user_name;
        var sSalesOrgId = this.getView().getModel("AdminDetailModel").getData().SalesOrgID.ID;
        var oDeleData = {
          "GUID": sGUID,
          "OWNER": sOwner,
          "DATEFROM": sStartDate,
          "DATETO": sEndDate,
          "SUBSTITUTE": sDelegate,
          "SALESORGID": sSalesOrgId
        }
        users.updateImmediateDelegate(oDeleData);
      },

      handleWeekNumberSelect: function (oEvent) {
        var oDateRange = oEvent.getParameter("weekDays"),
          iWeekNumber = oEvent.getParameter("weekNumber");

        if (iWeekNumber % 5 === 0) {
          oEvent.preventDefault();
          MessageToast.show("You are not allowed to select this calendar week!");
        } else {
          this._updateText(oDateRange);
        }
      },

      handleCreateVariantCancel: function () {
        this.oDeleDialog.close();
      },
      onSalesOrgSelect:function(oEvent){
        var oSelectedContexts = oEvent.getParameter('selectedItem');
        var sSalesOrg_ID = oSelectedContexts.getBindingContext("salesOrgModel").getProperty("ID");
        this.getView().byId("id-Admin-InputRequestArea").setValue("");
        this._callRequestAreaAPI(sSalesOrg_ID,this);
      },
      fnReqAreaSuccessCallback: function (oResult, self) {
        let newArray = [];
        let uniqueObject = {};
        for (let i in oResult.value) {
          var objTitle = oResult.value[i]['Request_Area'];
          uniqueObject[objTitle] = oResult.value[i];
        }
        for (var i in uniqueObject) {
          newArray.push(uniqueObject[i]);
        }
        oResult.value = newArray;
        var oModel = new sap.ui.model.json.JSONModel();
        oModel.setData(oResult);
        self.getView().setModel(oModel, "reqAreaModel");
        oModel.refresh();
        sap.ui.core.BusyIndicator.hide();
      },
      fnReqAreaErrorCallback: function (oError) {
        MessageBox.error(oError.responseText, {
          contentWidth: "600px"
        });
        sap.ui.core.BusyIndicator.hide();
      }


    });
  }
);