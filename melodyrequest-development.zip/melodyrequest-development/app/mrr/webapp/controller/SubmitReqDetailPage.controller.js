sap.ui.define([
	"sap/m/library",
	"sap/ui/core/mvc/Controller",
	"com/dealsupport/melodyrequest/model/models",
	"com/dealsupport/melodyrequest/model/users",
	"com/dealsupport/melodyrequest/model/formatter",
	"sap/ui/core/Fragment",
	"sap/m/MessageBox",
	'sap/ui/model/json/JSONModel',
	"sap/m/MessageToast",
	"sap/m/UploadCollectionParameter",
	"sap/ui/core/format/DateFormat",
	"sap/ui/core/library",
	"com/dealsupport/melodyrequest/control/Common",
	"sap/m/library"
],
	function (mobileLibrary, Controller, models, users, formatter, Fragment, MessageBox, JSONModel, MessageToast, UploadCollectionParameter, DateFormat, library, CommonJS,mLibrary) {
		"use strict";
		var URLHelper = mobileLibrary.URLHelper;
		var workflowInstanceId,
			token,
			ValueState = library.ValueState;
		return Controller.extend("com.dealsupport.melodyrequest.controller.SubmitReqDetailPage", {
			formatter: formatter,
			common:CommonJS,
			onInit: function () {
				this.bInitialLoad = true;
				this.getOwnerComponent().getModel("appConstants").setProperty("/isAfterWfAction",false);
				if (this.getOwnerComponent().getRouter().getRoute("SubmitReqDetailPage")) {
					this.getOwnerComponent().getRouter().getRoute("SubmitReqDetailPage").attachPatternMatched(this._onObjectMatched, this);
				}
				if (this.getOwnerComponent().getRouter().getRoute("SubmitReqView")) {
					this.getOwnerComponent().getRouter().getRoute("SubmitReqView").attachPatternMatched(this._onObjectMatched, this);
				}
			},
			navToReqView:function(){
				this.getOwnerComponent().getRouter().navTo("Worklist");
			},
			addNavButtoninWF: function(){
				var oExpTitleText = this.getView().byId("idExpTitleHeading");
				var oSnapTitleText = this.getView().byId("idSnapTitleHeading");
				var oHBoxExp = this.getView().byId("hboxExpTitle");
				var oHBoxSnap = this.getView().byId("hboxSnapTitle");
				if (this.oButtonExp) {
					oHBoxExp.removeItem(this.oButtonExp);
					this.oButtonExp.destroy();
					this.oButtonExp = null;
				}

				if (this.oButtonSnap) {
					oHBoxSnap.removeItem(this.oButtonSnap);
					this.oButtonSnap.destroy();
					this.oButtonSnap = null;
				}

				if (this.getOwnerComponent().getModel("appConstants").getProperty("/isReqView")) {
					if (!this.oButtonExp) {
					var oButtonExp = new sap.m.Button({
						type:"Back",
						visible: true,
						press: this.navToReqView.bind(this)
					}).addStyleClass("customBackBtnClassReqView");

					var oButtonSnap = new sap.m.Button({
						type:"Back",
						visible: true,
						press: this.navToReqView.bind(this)
					}).addStyleClass("customBackBtnClassReqView");

					
					oHBoxExp.insertItem(oButtonExp, 0);
					oHBoxSnap.insertItem(oButtonSnap, 0);
				}
					oExpTitleText.addStyleClass("sapUiTinyMarginTop");
					oSnapTitleText.addStyleClass("sapUiTinyMarginTop");

					this.getView().byId("idSubHeaderCnt").addStyleClass("customStyleHeaderCntClass");
                	this.getView().byId("idSubDynamicHeader").addStyleClass("customStyleObjTitleClass");
					this.getView().byId("idSubHeaderCnt").removeStyleClass("customStyleHeaderCntClassSub");

					
					this.oButtonExp = oButtonExp;
					this.oButtonSnap = oButtonSnap;
				} else {
					
					oExpTitleText.removeStyleClass("sapUiTinyMarginTop");
					oSnapTitleText.removeStyleClass("sapUiTinyMarginTop");

					this.getView().byId("idSubHeaderCnt").removeStyleClass("customStyleHeaderCntClass");
                 	this.getView().byId("idSubDynamicHeader").removeStyleClass("customStyleObjTitleClass");
						this.getView().byId("idSubHeaderCnt").addStyleClass("customStyleHeaderCntClassSub");
				}

			},
			fnCurrentStateSuccessCallback: function (oResult, self) {
				//initiate current state model
				self.getOwnerComponent().getModel("currentStateModel").setData(oResult);
				sap.ui.core.BusyIndicator.hide();
			},
			fnCurrentStateErrorCallback: function (oError, self) {
				MessageBox.error(oError.responseText, {
					contentWidth: "600px"
				});
				sap.ui.core.BusyIndicator.hide();
			},
			_onObjectMatched: function (evt) {
				this.getView().byId("formPage").setShowHeader(false);
				this.getView().byId("submitPageDynamicSideContent").setVisible(true);
				this.getOwnerComponent().getModel("appConstants").setProperty("/isOldVersionReq", false);
				this.getOwnerComponent().getModel("appConstants").refresh();
				this.getView().setVisible(true);
				this.getOwnerComponent().getModel("appConstants").setProperty("/routePath","SubmitReq");
				if(evt.getParameter("name") === "SubmitReqView"){
					this.getOwnerComponent().getModel("appConstants").setProperty("/isReqView",true);
				}else{
					this.getOwnerComponent().getModel("appConstants").setProperty("/isReqView",false);
				}
				this.addNavButtoninWF();
				this.sRootInstanceId = evt.getParameter("arguments").ID;
				this.aWfLogs = false;
				this.getOwnerComponent().getModel("appConstants").setProperty("/urlInstanceID", this.sRootInstanceId)
				this.i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				//this.getView().setBusy(true);sap.ui.core.BusyIndicator
				const sInstanceID = evt.getParameter("arguments").ID;
				this.getView().setBusy(true);
				setTimeout(function() {
				if (this.bInitialLoad || evt.getParameter("name") === "SubmitReqView" ||  this.getOwnerComponent().getModel("appConstants").getProperty("/isAfterWfAction")) {
					models.getMyInboxInstanceDetails(this.fnSuccessCallback, this.fnErrorCallback, this, sInstanceID);
				}
				const sLoggedInUser = this.getOwnerComponent().getModel("userDetails").getProperty("/email");
				const oContextObject = this.getOwnerComponent().getModel("wfInstanceModel").getData();
				const sOrgID = oContextObject.OrgID;
				var isComponentScope = false;
				models.getMRRLanugaueData(this.fnLangSuccess, this, isComponentScope, sOrgID);
				const isCurrentProcesser = oContextObject ? formatter.formatSubmitPageUrl(oContextObject.CurrentProcessorEmail, sLoggedInUser, oContextObject.TechnicalState, oContextObject.currentStateID):false;
				// if (oContextObject.CurrentProcessorEmail === sLoggedInUser) {
				if (isCurrentProcesser) {
					this.getView().byId("idSubmitDetailMsg").setVisible(false);
					this.getView().byId("idSubmitFormContainer").setVisible(true);
					if (this.multiReqModel) {
						//multi requests
						this.getView().getModel("multiReqModel").setData([]);
						this.getView().getModel("multiReqModel").refresh(true);
					}
					this.onLoadRequest();
					//hide Action history content
				} else {
					this.getView().setBusy(false);
					this.getView().byId("submitPageDynamicSideContent").setVisible(false);
					 appView.onOpenTaskProcessedMsgDialog();
				}
				if (oContextObject.currentStateID === "REESUB") {
					this.getView().byId("openSideContentBtnSubmitPage").setVisible(true);
				} else {
					this.getView().byId("openSideContentBtnSubmitPage").setVisible(false);
				}
				this.getOwnerComponent().getModel("wfInstanceModel").refresh();
				this.bInitialLoad = false;
				this.getOwnerComponent().getModel("appConstants").setProperty("/isAfterWfAction",false);
			}.bind(this),1000)
			},
            fnSuccessCallback: function (oResponse, self) {
				self.getOwnerComponent().getModel("wfInstanceModel").setData(oResponse.value[0]);
				self.getOwnerComponent().getModel("wfInstanceModel").refresh();
			},
			fnLangSuccess: function(oResponse, self){
                let sValues = oResponse.value;
                let oModel = new sap.ui.model.json.JSONModel();
				//sort the values alphabetically except "other"
				sValues.sort((a, b) => {
					let isSpecA = a.Value.toLowerCase() == 'other'
					let isSpecB = b.Value.toLowerCase() == 'other'
					if (isSpecA && !isSpecB)
						return 1;
					if (!isSpecA && isSpecB)
						return -1
					return a.Value.localeCompare(b.Value)
				})
                oModel.setData(sValues);
                self.getOwnerComponent().setModel(oModel, "mrrLanguageConfigModel");
                sap.ui.core.BusyIndicator.hide();
			},
			fnErrorCallback: function (oError, self) {
				MessageBox.error(oError.responseText, {
					contentWidth: "600px"
				});
				sap.ui.core.BusyIndicator.hide();
			},
			onLoadRequest: function () {
				this.getView().setBusy(true);
				setTimeout(function() {
				models._getWfExecutionLogs(this, this.sRootInstanceId, this.fnSuccessGetWfExecutionLogs);
				}.bind(this),1000);
			},
			fnSuccessGetWfExecutionLogs: function (result, self) {
				self.userTaskId = result[result.length - 1].taskId;
				const i18nModel = self.getOwnerComponent().getModel("i18n").getResourceBundle();
				self.getView().setBusy(false);
				if(result[result.length-1].type.includes("FAILED")){
					self.getView().setBusy(false);
					self.getView().byId("submitPageDynamicSideContent").setVisible(false);
					self.getView().byId("idSubmitDetailMsg").setVisible(true);
					self.getView().byId("idSubmitDetailMsg").setTitle(i18nModel.getText("taskFailed"));
					self.getView().byId("idSubmitDetailMsg").setDescription(i18nModel.getText("taskFailedDesc"));
					self.getView().byId("idSubmitDetailMsg").setIllustrationType("sapIllus-ErrorScreen");
					self.getView().byId("formPage").setShowFooter(false);
					if (self.getOwnerComponent().getModel("appConstants").getProperty("/isReqView")) {
						 //execute on Request view
						self.getView().byId("formPage").setShowHeader(true);
					} else {
						 //execute on Open task view
						self.getView().byId("formPage").setShowHeader(false);
					}
				}else if(result[result.length-1].type.includes("WORKFLOW_CANCELED")){
					//workflow termination
					self.getView().setBusy(false);
					self.getView().byId("submitPageDynamicSideContent").setVisible(false);
					self.getView().byId("idSubmitDetailMsg").setVisible(true);
					self.getView().byId("idSubmitDetailMsg").setTitle(i18nModel.getText("taskTerminatedDesc"));
					self.getView().byId("idSubmitDetailMsg").setDescription(i18nModel.getText("taskTerminated"));
					self.getView().byId("idSubmitDetailMsg").setIllustrationType("sapIllus-ErrorScreen");
					self.getView().byId("formPage").setShowFooter(false);
					if (self.getOwnerComponent().getModel("appConstants").getProperty("/isReqView")) {
						 //execute on Request view
						self.getView().byId("formPage").setShowHeader(true);
					} else {
						 //execute on Open task view
						self.getView().byId("formPage").setShowHeader(false);
					}
				}
				else{
					self.getView().byId("submitPageDynamicSideContent").setVisible(true);
					self.getView().byId("idSubmitDetailMsg").setVisible(false);
					if (!self.userTaskId) {
						self.getView().setBusy(true);
						setTimeout(function () {
							models._getWfExecutionLogs(self, self.sRootInstanceId, self.fnSuccessGetWfExecutionLogs);
						}.bind(self), 1000);
					} else {
						self.getView().setBusy(true);
						//models._getWfTaskDetails(self, self.userTaskId, self.fnSuccessGetWfTaskDetails);
					 	models._getGetWfContextDetails(self, self.sRootInstanceId, self.fnSuccessGetContextDetails);
					}
				}
			},
			fnSuccessGetWfTaskDetails: function (result, that) {
				//initaite task-history model
				that.getView().byId("formPage").setShowFooter(true);
				let taskInstanceModel = new JSONModel(result);
				taskInstanceModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
				that.getView().setModel(taskInstanceModel, "taskInstanceModel");
				//models._getGetWfContextDetails(that, that.sRootInstanceId, that.fnSuccessGetContextDetails);
			},
			getParentModel: function (sName) {
				let oMdl = this.getOwnerComponent().getModel(sName);
				return oMdl;
			},
			onClickApproversList: function (oEvent) {

				if (!this.getView().getModel("multiReqModel").getData().subcontext[0].isResourceProfile) {
					this.onRequesterContactIcon(oEvent, this);
				} else {
					let oContextObj = oEvent.getSource().getBindingContext("multiReqModel").getObject().aResourceProfileApprovers.ApproverDetails
				    CommonJS._empSort(oContextObj,"fullName");
					let empDataApp = new JSONModel(oContextObj);
					this.getView().setModel(empDataApp, "EmpListDetails");
					let oView = this.getView();
					if (!this._pApproversPopover) {
						Fragment.load({
							id: oView.getId(),
							name: "com.dealsupport.melodyrequest.fragments.ApproversSubmitPageList",
							controller: this
						}).then(function (oPopover) {
							oView.addDependent(oPopover);
							this._pApproversPopover = oPopover;
							oPopover.openBy(oEvent.getSource());
						}.bind(this));
					} else {
						this._pApproversPopover.openBy(oEvent.getSource());
					}
				}

			},
			onHandleokPress: function () {
				if (this._pApproversPopover) {
					this._pApproversPopover.close();
				}
			},
			onRequesterContactIcon: function (oEvent, self) {
				sap.ui.core.BusyIndicator.show(0);

				let sName = "Approvers";
				let subcontext = self.getView().getModel("multiReqModel").getData().subcontext;
				let selectedReqArea = self.getView().byId("iconTabHeader").getSelectedKey();
				function findIndexWithRequestArea(array) {
					return array.findIndex(obj => obj.requestArea === selectedReqArea);
				}

				let index = findIndexWithRequestArea(subcontext);
				let sRequester = self.getView().getModel("multiReqModel").getData().subcontext[index].legacyApprovers[index];
				let oValType = "ID";
				users.callEmpApi(sRequester, oEvent, self, sName, oValType);

			},
			QuickViewCard: function (oModel, oevt, self, sName) {
				let oButton = oevt.getSource();
				self.getView().setModel(oModel, "EmpDetails");
				let EmployeeDetails = self.getView().getModel("EmpDetails");
				users._contactslistFragment(EmployeeDetails, oevt, self, sName).openBy(oButton);
				sap.ui.core.BusyIndicator.hide();
			},
			currentAvatarDisplay: function (userId) {
				return this.getOwnerComponent().getModel("appConstants").getProperty("/userImg/0/Value") + userId;
			},
			onPressEmpEmail: function (oEvent) {
				const sUrl = oEvent.getSource().getProperty("text");
				URLHelper.triggerEmail(sUrl, "Info Request - MRR", false, false, false, true);
			},
			fnSuccessAppCallback: function (oData, self, sMode) {
				self.getView().getModel("multiReqModel").getData().legacyApprovers[sMode] = oData.value[0].Approvers;

			},
			fnSuccessGetContextDetails: function (result, that) {
				result.EngagementType = result.EngagementType ? result.EngagementType : '0001'
				const i18nModel = that.getOwnerComponent().getModel("i18n").getResourceBundle();
				
				if (result.approvalHistory) {
					const firstDecision = result.approvalHistory[0].Decision;
					const lastDecision = result.approvalHistory[result.approvalHistory.length - 1].Decision;
					const lastStepID = result.approvalHistory[result.approvalHistory.length - 1].StepID;
				
					if (firstDecision === "Submit Request" || lastDecision === "Send Back to Requestor") {
						if (lastStepID === "REQSUB") {
							that.getView().setBusy(false);
							that.getView().byId("submitPageDynamicSideContent").setVisible(false);
							const detailMsg = that.getView().byId("idSubmitDetailMsg");
							detailMsg.setVisible(true);
							detailMsg.setTitle(i18nModel.getText("pleasewaitandrefresh"));
							// detailMsg.setDescription(i18nModel.getText("refreshScreen"));
							// detailMsg.setIllustrationType("sapIllus-ErrorScreen");
							that.getView().byId("formPage").setShowFooter(false);
							that.getView().byId("idBtnDetSubmitRefresh").setVisible(true);
							return; 
						}
					}
					that.fnsetContextDetailModelData(result, that);
				}else{
					that.fnsetContextDetailModelData(result, that);
				}
				
				
			},
			onRefreshDetailPage: function(oEvent){
				this.getOwnerComponent().getModel("appConstants").getProperty("/ReqMasterPage").onSearch();
			},
			fnsetContextDetailModelData: function(result, that){
				that.getView().setBusy(false);
				sap.ui.core.BusyIndicator.hide();
				//that.getView().byId("idReqSection").setBusy(true);
				appView.sInstanceID = "";
				that.unSavedData = [];
				let contextModel = new JSONModel(result);
				that.getView().setModel(contextModel, "multiReqModel");
				if (!contextModel.getData().isResourceProfile) {
					contextModel.getData().legacyApprovers = []
					if (!contextModel.getData().isRework) {

						for (let i = 0; i < contextModel.getData().aReqAreas.length; i++) {
							const sGUID = contextModel.getData().aReqAreas[i].GUID;
							let sUrl = `/ReadResources?$filter=GUID eq (${sGUID})`;
							let sMode = i;
							models.getAdminViewDetail(that.fnSuccessAppCallback, that.fnErrorAppCallback, that, sUrl, sMode);

						}
					} else {
						const sGUID = contextModel.getData().GUID;
						let sUrl = `/ReadResources?$filter=GUID eq (${sGUID})`;
						let sMode = 0;
						models.getAdminViewDetail(that.fnSuccessAppCallback, that.fnErrorAppCallback, that, sUrl, sMode);
					}
				}
				const oMcommonModel = new JSONModel();
				that.getView().getModel("mCommon").refresh();
				oMcommonModel.loadData("model/Property.json")
				that.getView().setModel(oMcommonModel, "mCommon");
				let oModelData = that.getView().getModel("multiReqModel").getData();
				//add OrgId,OrgType,RequestType for older tasks
				if (typeof (oModelData["SalesOrgID"]) === "string") {
					oModelData["OrgID"] = oModelData["SalesOrgID"];
					oModelData["OrgType"] = "SORG";
					oModelData["RequestType"] = "Opportunity"
				}
				let oMultiReqModel = {};
				that.multiReqModel = true;
				let sKey
				//restructuring the response
				if (oModelData.aReqAreas && oModelData.aReqAreas.length) {
					let aFormattedContext = [];
					sKey = oModelData.aReqAreas[0].requestArea;
					for (let i = 0; i < oModelData.aReqAreas.length; i++) {
						//format search text
						if(oModelData.isResourceProfile){
							let aSearchItem = [];
							oModelData.aReqAreas[i].aResourceProfileApprovers.ResourceProfileDetails.RoleArea_P_GUID.Desc ? aSearchItem.push(oModelData.aReqAreas[i].aResourceProfileApprovers.ResourceProfileDetails.RoleArea_P_GUID.Desc):false;
						    oModelData.aReqAreas[i].aResourceProfileApprovers.ResourceProfileDetails.SolutionAreas.length ? aSearchItem.push(oModelData.aReqAreas[i].aResourceProfileApprovers.ResourceProfileDetails.SolutionAreas[0].SelectedSolutionArea):false;
						    oModelData.aReqAreas[i].aResourceProfileApprovers.ResourceProfileDetails.BAIndustries.length ? aSearchItem.push(oModelData.aReqAreas[i].aResourceProfileApprovers.ResourceProfileDetails.BAIndustries[0].Desc):false;
						    oModelData.aReqAreas[i].aResourceProfileApprovers.ResourceProfileDetails?.SelectedGroup?.length ? aSearchItem.push(oModelData.aReqAreas[i].aResourceProfileApprovers.ResourceProfileDetails.SelectedGroup[0].GroupDesc):false;					
							oModelData.aReqAreas[i].searchFieldsText = aSearchItem.length ?  `[${aSearchItem.join(" | ")}]`:"";
						}
						let oContextNew = Object.assign(oModelData.aReqAreas[i], oModelData);
						delete oContextNew.aReqAreas;
						aFormattedContext.push(oContextNew);
					}
					oMultiReqModel["subcontext"] = aFormattedContext;
				} else {
					sKey = oModelData.requestArea;
					oMultiReqModel["subcontext"] = [oModelData];
				}
				that.getView().byId("iconTabHeader").setSelectedKey(sKey);

				that.getView().getModel("multiReqModel").setData(oMultiReqModel);

				 //Git 132 (Form template/standardization ) - Get user comments
				if(oMultiReqModel["subcontext"][0].isRework){
					const sInstanceID = that.getOwnerComponent().getModel("wfInstanceModel").getProperty("/InstanceID");
					that.getView().byId("idReqSubTaskSec").setBusy(true);
					models.getSubTaskInstanceDetails(that);
					that.getView().byId("idUserCommentSec").setBusy(true);
					models._getUserComments(that,sInstanceID,"GET");
				}else{
					oMultiReqModel["subTaskVisibility"] = false;
				
				}
			    that.getOwnerComponent().getModel("wfInstanceModel").setProperty("/bIsUserCommentInput",true);
				that.getOwnerComponent().getModel("wfInstanceModel").refresh();	
				// document service interaction
				that.oAttachmentsModel = new JSONModel();
				that.getView().setModel(that.oAttachmentsModel, "attachmentsModel");
				that._fetchFormConfigData(that);

				/*fetch and set dropdown values*/
				that._fetchFormValues(that);
				that._fetchFormActions(that);

				

				workflowInstanceId = that.getView().getModel("wfInstanceModel").getProperty("/InstanceID");

				/* Start of Code for CurrentTask Instance ID Update  */
				that.updateCurrentInstance();
				/* End of Code for CurrentTask Instance ID Update  */

				let oMrqModelData = that.getView().getModel("multiReqModel").getData().subcontext;
				var that = that;
				let oMdlCommon = that.getView().getModel("mCommon");
				// check if 'WorkflowManagement' folder exists
				// that.checkIfFolderExists("WorkflowManagement", that, true);
				// that.loadAttachments(oMrqModelData[0], that);

				for (let i = 0; i < oMrqModelData.length; i++) {
					if (oMrqModelData[i].EngagementType && oMrqModelData[i].EngagementType == '0002') {
						if (that.getView().getModel("formValConfigModel").getProperty("/idsupp_type_fbs")) {
						let sDefaultSupportType = that.fnGetDefaultValFBS(that.getView().getModel("formValConfigModel").getProperty("/idsupp_type_fbs"));
						if(sDefaultSupportType)
							oMrqModelData[i].supp_Type_FBS = sDefaultSupportType;
						}
						if (that.getView().getModel("formValConfigModel").getProperty("/idsupp_type_PQA")) {
						let sDefaultSupportTypePQA = that.fnGetDefaultValFBS(that.getView().getModel("formValConfigModel").getProperty("/idsupp_type_PQA"));
						if(sDefaultSupportTypePQA)
							oMrqModelData[i].supp_Type_Pqa_Id = sDefaultSupportTypePQA;
						}
						if (that.getView().getModel("formValConfigModel").getProperty("/opp_origin")) {
						let sOppOrigin = that.fnGetDefaultValFBS(that.getView().getModel("formValConfigModel").getProperty("/opp_origin"));
						if(sOppOrigin)
							oMrqModelData[i].opp_Origin_Id = sOppOrigin;
						}
						if (that.getView().getModel("formValConfigModel").getProperty("/main_sol")) {
						let sSolnID = that.fnGetDefaultValFBS(that.getView().getModel("formValConfigModel").getProperty("/main_sol"));
						if(sSolnID)
							oMrqModelData[i].solution_Id = sSolnID;
						}
						if (that.getView().getModel("formValConfigModel").getProperty("/est_acv")) {
						let sEstAcv = that.fnGetDefaultValFBS(that.getView().getModel("formValConfigModel").getProperty("/est_acv"));
						if(sEstAcv)
							oMrqModelData[i].est_Acv = sEstAcv;
						}
						if (that.getView().getModel("formValConfigModel").getProperty("/business_model")) {
						let sBusinessModel = that.fnGetDefaultValFBS(that.getView().getModel("formValConfigModel").getProperty("/business_model"));
						if(sBusinessModel)
							oMrqModelData[i].model_Id = sBusinessModel;
						}
						if (that.getView().getModel("formValConfigModel").getProperty("/infra_structure_provider")) {
						let sIspId = that.fnGetDefaultValFBS(that.getView().getModel("formValConfigModel").getProperty("/infra_structure_provider"));
						if(sIspId)
							oMrqModelData[i].isp_Id = sIspId;
						}
						that._createWorkFlowFileUploadId(oMrqModelData[i], that);
						if (that.getView().getModel("multiReqModel").getProperty("/subcontext/0/approvalHistory")) {
							that.getView().getModel("multiReqModel").getProperty("/subcontext/0/approvalHistory").reverse();
							if (oMrqModelData[i].isRework) {
								that._setPrevioslySelectedValues(oMrqModelData[i], oMrqModelData[i].requestDetails, true);
								oMrqModelData[i].attachmentUrls = oMrqModelData[i].attachmentUrls ? oMrqModelData[i].attachmentUrls : [];
								if (!oMrqModelData[i].attachmentUrls.length) {
									that.onAddNewUrl(false, i);
								}
							}
						}
						
					}else{
						
					
					that._createWorkFlowFileUploadId(oMrqModelData[i], that);
					oMrqModelData[i].namesOfPartiesVisible = false;
					oMrqModelData[i].isParticipantTypeSelected = false;
					if (oMrqModelData[i].requestArea && oMrqModelData[i].isResourceProfile) {
						let aReqAreaSplit = oMrqModelData[i].requestArea.split("-");
						if (aReqAreaSplit[aReqAreaSplit.length - 1] == "RISE") {
							oMrqModelData[i].isRISE = true;
						} else {
							oMrqModelData[i].isRISE = false;
						}
					} else {
						oMrqModelData[i].isRISE = false;
					}
					that.onSwitchStateChange("", that, true);
					if (oMrqModelData[i].requestAreaPath && oMrqModelData[i].isResourceProfile) {
						let aReqAreaPathSplit = oMrqModelData[i].requestAreaPath.split("-");
						if (aReqAreaPathSplit[0] == "Solution Large Enterprise" || aReqAreaPathSplit[0] == "Midmarket") {
							oMrqModelData[i].isSolutionRelated = true;
						} else {
							oMrqModelData[i].isSolutionRelated = false;
						}
					} else {
						oMrqModelData[i].isSolutionRelated = false;
					}

					if (oMdlCommon.getProperty("/DefaultMeetingType")) {
						let sDefMTKey = oMdlCommon.getProperty("/DefaultMeetingType")[0];
						let aMeetingTypes = oMdlCommon.getProperty("/MeetingTypes");
						aMeetingTypes.forEach(meetingType => {
							if (that.i18nModel.getText(meetingType.key) === sDefMTKey) {
								let sMeetTypeText = that.i18nModel.getText(meetingType.text);
								oMrqModelData[i].meetingType = sMeetTypeText;
								let meetTypes = that.getView().getModel("formValConfigModel").getData().idmeet_type;
								let matchingType = meetTypes.find(type => type.Value === sMeetTypeText);
								if (matchingType) {
									oMrqModelData[i].meetingTypeKey = matchingType.ID;
								}
							}
						});
					}

					if (that.getView().getModel("formValConfigModel").getProperty("/idmeet_type")) {
						let sDefaultMeetingType = that.formatFormMultiDefaultSelect(that.getView().getModel("formValConfigModel").getProperty(
							"/idmeet_type"));
						oMrqModelData[i].meetingTypeKey = sDefaultMeetingType;
						let meetingTypes = that.getView().getModel("formValConfigModel").getData().idmeet_type;
						let matchingMeetingType = meetingTypes.find(meetType => meetType.ID ===  sDefaultMeetingType);
						if (matchingMeetingType) {
							oMrqModelData[i].meetingType = matchingMeetingType.Value;
						}
					}


					that.getView().getModel("formValConfigModel").setProperty("/idlang" , that.getView().getModel("mrrLanguageConfigModel").getData());
					if (that.getView().getModel("formValConfigModel").getProperty("/idlang")) {
						let sDefaultLanguageType = that.formatFormMultiDefaultSelect(that.getView().getModel("mrrLanguageConfigModel").getData());
						let sLangKey = sDefaultLanguageType[0];
						oMrqModelData[i].languageKey = sLangKey;
						let langTypes = that.getView().getModel("mrrLanguageConfigModel").getData();
						let matchingLang = langTypes.find(lang => lang.ID === sLangKey);
						if (matchingLang) {
							oMrqModelData[i].language = matchingLang.Value;
						}
					}

					if (that.getView().getModel("formValConfigModel").getProperty("/idsupp_type")) {
						let sDefaultSupportType = that.formatFormMultiDefaultSelect(that.getView().getModel("formValConfigModel").getProperty(
							"/idsupp_type"));
						oMrqModelData[i].supportType = sDefaultSupportType[0];
					}
					if (i !== 0) {
						oMrqModelData[i].copyContentCheckBox = true;
						oMrqModelData[i].selected = false;
						if(oMrqModelData[i].isResourceProfile){
							oMrqModelData[i].copyContentLabel = "Copy content from " + oMrqModelData[i - 1].searchFieldsText + " - Request";
						}else{
							oMrqModelData[i].copyContentLabel = "Copy content from " + oMrqModelData[i - 1].requestArea + " - Request";
						}
					} else {
						oMrqModelData[i].copyContentCheckBox = false;
						oMrqModelData[i].selected = false;
					}
					if (oMrqModelData[i].isRework) {
						that._setPrevioslySelectedValues(oMrqModelData[i], oMrqModelData[i].requestDetails, true);
						oMrqModelData[i].attachmentUrls = oMrqModelData[i].attachmentUrls ? oMrqModelData[i].attachmentUrls:[];
						if(!oMrqModelData[i].attachmentUrls.length){
							that.onAddNewUrl(false,i);
						}
					} else {
						oMrqModelData[i].isMeetingPlanned = false;
					}
					if (that.getView().getModel("multiReqModel").getProperty("/subcontext/0/approvalHistory")) {
						that.getView().getModel("multiReqModel").getProperty("/subcontext/0/approvalHistory").reverse();
					}
				}

				}
				const oDynamicSideView = that.getView().byId("submitPageDynamicSideContent");
				const oOPSideContentBtn = that.getView().byId("openSideContentBtnSubmitPage");
				oDynamicSideView.setShowSideContent(false);
				if (that.getOwnerComponent().getModel("wfInstanceModel").getProperty("/currentStateID") === "REESUB") {
					// oOPSideContentBtn.setVisible(true);
					that.handleSCBtnPress()
				} else {
					that.handleSideContentHide()
				}
				that.getView().getModel("multiReqModel").refresh(true);

				// set min date for calendar
				that.getView().byId("meetingDateInputMrq").setMinDate(new Date());
				if(that.getView().getModel("multiReqModel").getData().subcontext[0].EngagementType==='0001')
					that._setDefaultFormValue();
				// // check if 'WorkflowManagement' folder exists
				// that.checkIfFolderExists("WorkflowManagement", that, true);
				// that.loadAttachments(oMrqModelData[0], that);
			
					that.getResProfileDetails(0);
				
				 //Git 132 (Form template/standardization ) start
				if(!that.getView().getModel()){
                    that.getView().setModel(new sap.ui.model.json.JSONModel());
                }
				that.getView().getModel().setProperty("/NewOppDetails",that.getView().getModel("multiReqModel").getProperty("/subcontext/0/NewOppDetails"));
				that.getView().getModel().setProperty("/aResourceProfileApprovers",that.getView().getModel("multiReqModel").getProperty("/subcontext/0/aResourceProfileApprovers"));
				that.getView().getModel().setProperty("/SalesOrg",that.getView().getModel("multiReqModel").getProperty("/subcontext/0/SalesOrg"));
				that.getView().getModel().setProperty("/opportunityId",that.getView().getModel("multiReqModel").getProperty("/subcontext/0/opportunityId"));
				if (!that.getView().getModel("multiReqModel").getProperty("/subcontext/0/NewOppDetails/DealInfo") && that.getView().getModel("multiReqModel").getProperty("/subcontext/0/RequestType") === 'Opportunity') {
					//update new opp details for request created before the git 132 changes
					const oUrlParams = {
						$expand: 'Notes,PartiesInvolved,DQReview,Attributes,CloseplanActivities,DocFlow,Attachments,Items,Pricing,RevenueSplitPlanH,RevenueSplitPlanI,SalesTeamWF,CustomerIncentive,S2SActivities,S2SActivities/PartiesInvolved,S2SActivities/Goals,RenewalExecution,OppHandover'
					};
					that.getView().byId("idDealInfoSec").setBusy(true)
					models._getMyOpportunityDetails(that, that.getView().getModel("multiReqModel").getProperty("/subcontext/0/opportunityId"), oUrlParams, CommonJS.parseGetOppDataResponse);
				} else if (that.getView().getModel("multiReqModel").getProperty("/subcontext/0/RequestType") === 'Opportunity') {
					//update deal info
					CommonJS.parseGetOppDataResponse(that.getView().getModel("multiReqModel").getProperty("/subcontext/0/NewOppDetails/DealInfo"), that);
				}
					 //Git 132 (Form template/standardization ) end
				if(that.getView().getModel("multiReqModel").getProperty("/subcontext/0/RequestType") !== 'Opportunity' ||  that.getView().getModel("multiReqModel").getProperty("/subcontext/0/currentStepID") === "REESUB"){
				    //set account/opp owner details
					let oAccountOwnerDetails = {accOwnerDetails:{}};
           			let oOppOwnerDetails = {oppOwnerDetails: {
					}};
					that.getView().getModel("multiReqModel").getProperty("/subcontext/0/RequestType") !== 'Opportunity'
					oAccountOwnerDetails.accOwnerDetails = that.getView().getModel("multiReqModel").getProperty("/subcontext/0/RequestType") !== 'Opportunity' && that.getView().getModel("multiReqModel").getProperty("/subcontext/0/currentStepID") !== "REESUB"
						? {
							id: that.getView().getModel("multiReqModel").getProperty("/subcontext/0/AccountOwnerUserId"),
							name: that.getView().getModel("multiReqModel").getProperty("/subcontext/0/AccountOwner"),
							email: that.getView().getModel("multiReqModel").getProperty("/subcontext/0/AccountOwnerEmail"),
						} :
						that.getView().getModel("multiReqModel").getProperty("/subcontext/0/accOwnerDetails");
					oOppOwnerDetails.oppOwnerDetails = that.getView().getModel("multiReqModel").getProperty("/subcontext/0/RequestType") === 'Opportunity' && that.getView().getModel("multiReqModel").getProperty("/subcontext/0/currentStepID") === "REESUB" ?
						 that.getView().getModel("multiReqModel").getProperty("/subcontext/0/oppOwnerDetails"): {};
					 let aEmpIds = [
                        oAccountOwnerDetails?.accOwnerDetails?.id,
                        oOppOwnerDetails?.oppOwnerDetails?.id
                    ].filter(Boolean);
					//check account/opp owner details
                    CommonJS.checkUserActive(that,aEmpIds,oAccountOwnerDetails,oOppOwnerDetails,true);
				}
				//get draft details
				const sInstanceId =  that.getView().getModel("wfInstanceModel").getProperty("/InstanceID");
				models.getSaveDraftFormDetails(sInstanceId,that.fnSuccessCallbackGetDraft,that);
				//pre select draft tab
				if (that.getView().getModel("multiReqModel").getData().subcontext.length > 1 && that.getView().getModel("draftTable").getData().length) {
					let aTabIdSort = that.getView().getModel("draftTable").getData().sort((a, b) =>
						a.tabID.localeCompare(b.tabID));
					let oNavContainer = that.getView().byId("idNavContainerMrq");
					let currentPageId = oNavContainer._pageStack[0].id;
					let tabId = Number(aTabIdSort[aTabIdSort.length - 1].tabID);
					let iPageTabId;
					let iCurrenrPagTabId;
					if (that.getView().getModel("multiReqModel").getData().subcontext.length === tabId) {
						iPageTabId = tabId - 1;
						iCurrenrPagTabId = tabId - 2;
					} else {
						iPageTabId = tabId;
						iCurrenrPagTabId = tabId - 1;
					}
					let sNextPageId = currentPageId.replace(/\idNavContainerMrq[^\s]*/g, "") + "idNavContainerMrq-" + (iPageTabId).toString();
					let aPageStack = [{
						data: {},
						id: currentPageId.replace(/\idNavContainerMrq[^\s]*/g, "") + "idNavContainerMrq-" + (iCurrenrPagTabId).toString(),
						transition:
							"slide"
					}];
					oNavContainer._pageStack = aPageStack
					that.navtoReqArea(sNextPageId, "next");
				}
  				CommonJS.setHeaderDetails(that);
				setTimeout(function () {
					that.getView().setBusy(false);
				}, 1000, this);
				//initialize attachment urls
				if (!oMrqModelData[0].isRework) {
					that._initializeUrls(0);
				}else{
					  //Git 132 (Form template/standardization )
					  const oRequestSubmissionDet = oMrqModelData[0].approvalHistory.length ? oMrqModelData[0].approvalHistory.filter(item => item.StepID === "REQSUB") : [],
					  sReqSubmissionDate = oRequestSubmissionDet.length ? oRequestSubmissionDet[0]["Date"] : "",
					  sFinalDate = formatter.formatDateWithOrdinalNumberSuffixes(sReqSubmissionDate);
						  oMrqModelData[0].requestSubmissionDate =
						  `${this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/RequestSubmissionDate/0/fieldDesc")}: ${sFinalDate}`;
				}
				sap.ui.core.BusyIndicator.hide();
				that.getView().getModel("multiReqModel").refresh();
				that.getView().setBusy(false);
			},
			fnSuccessCallbackGetDraft: function (result, that,isSaveDraft,urlResponse) {
				let groupedUrls = [];
				if(urlResponse.value.length){
					const aUrlDraftData = urlResponse.value;
					 groupedUrls = Object.entries(
						// What you have done
						aUrlDraftData.reduce((urlData, { urlName,urlCountID, tabID, url,instanceDF_GUID,parentInstanceGUID }) => {
						  // Group initialization
						  if (!urlData[tabID]) {
							urlData[tabID] = [];
						  }
						  
						  // Grouping
						  // FIX: only pushing the object that contains urlName and url
						  urlData[tabID].push({ urlName,urlCountID, url,instanceDF_GUID,parentInstanceGUID });
					  
						  return urlData;
						}, {})
					  ).map(([tabID, attachmentUrls]) => ({ tabID, attachmentUrls }));
					if (!isSaveDraft) {
						groupedUrls.forEach(function (data) {
							const aSubContext = that.getView().getModel("multiReqModel").getData().subcontext;
							const iIndex = aSubContext[0].isRework ? 0 : Number(data.tabID) - 1
							aSubContext[iIndex].attachmentUrls = data.attachmentUrls;
						});
					}
				}
				if (result.value.length && !isSaveDraft) {
					var aSubContext = that.getView().getModel("multiReqModel").getData().subcontext;
					if (aSubContext[0].EngagementType == '0002') {
						const aDraftData = result.value;
						aDraftData.forEach(function (data) {
							
							const iIndex = aSubContext[0].isRework ? 0 : Number(data.tabID) - 1
							var suppTypeDataText = data.supp_Type_FBS ? that.getView().getModel("formValConfigModel").getData()["idsupp_type_fbs"].filter(obj => obj.ID == data.supp_Type_FBS)[0].Value : ""
							var suppTypePQADataText = data.supp_Type_Pqa_Id ? that.getView().getModel("formValConfigModel").getData()["idsupp_type_PQA"].filter(obj => obj.ID == data.supp_Type_Pqa_Id)[0].Value : ""
							var oppOriginDataText = data.opp_Origin_Id ? that.getView().getModel("formValConfigModel").getData()["opp_origin"].filter(obj => obj.ID == data.opp_Origin_Id)[0].Value : ""
							var mainSolDataText = data.solution_Id ? that.getView().getModel("formValConfigModel").getData()["main_sol"].filter(obj => obj.ID == data.solution_Id)[0].Value : ""
							var estACVDataText = data.est_Acv ? that.getView().getModel("formValConfigModel").getData()["est_acv"].filter(obj => obj.ID == data.est_Acv)[0].Value : ""
							var businessModelDataText = data.model_Id ? that.getView().getModel("formValConfigModel").getData()["business_model"].filter(obj => obj.ID == data.model_Id)[0].Value : ""
							var ispDataText = data.isp_Id ? that.getView().getModel("formValConfigModel").getData()["infra_structure_provider"].filter(obj => obj.ID == data.isp_Id)[0].Value : ""

							aSubContext[iIndex].need_From_Fbs = data.need_From_Fbs ? data.need_From_Fbs : "";
							// aSubContext[iIndex].supportTypeKey = data.supportTypeKey ? data.supportTypeKey : "";
							aSubContext[iIndex].supp_Type_FBS = data.supp_Type_FBS ? data.supp_Type_FBS : "";
							aSubContext[iIndex].supp_Type_Pqa_Id = data.supp_Type_Pqa_Id ? data.supp_Type_Pqa_Id : "";
							aSubContext[iIndex].c2c_Deal = data.c2c_Deal=='X' ? true : false;
							aSubContext[iIndex].opp_Origin_Id = data.opp_Origin_Id ? data.opp_Origin_Id : "";
							aSubContext[iIndex].Opp_Number = data.additionalOpp ? data.additionalOpp : "";
							aSubContext[iIndex].solution_Id = data.solution_Id ? data.solution_Id : "";
							aSubContext[iIndex].est_Acv = data.est_Acv ? data.est_Acv : "";
							aSubContext[iIndex].model_Id = data.model_Id ? data.model_Id : "";
							aSubContext[iIndex].isp_Id = data.isp_Id ? data.isp_Id : "";
							aSubContext[iIndex].io_Number = data.io_Number ? data.io_Number : "";
							aSubContext[iIndex].contact_Prsn_Id = data.contact_Prsn_Id ? data.contact_Prsn_Id : "";
							aSubContext[iIndex].contact_Prsn_Email = data.contact_Prsn_Email ? data.contact_Prsn_Email : "";
							aSubContext[iIndex].oppclosing_Date = data.oppclosing_Date ? data.oppclosing_Date : null;
							aSubContext[iIndex].contract_Start_Date = data.contract_Start_Date ? data.contract_Start_Date : null;
							aSubContext[iIndex].contract_End_Date = data.contract_End_Date ? data.contract_End_Date : null;
							aSubContext[iIndex].supportTypeText = suppTypeDataText;
							aSubContext[iIndex].suppTypePQAText = suppTypePQADataText;
							aSubContext[iIndex].oppOriginText = oppOriginDataText;
							aSubContext[iIndex].mainSolutionText = mainSolDataText;
							aSubContext[iIndex].estAcvText = estACVDataText;
							aSubContext[iIndex].businessModelText = businessModelDataText;
							aSubContext[iIndex].ispIdText = ispDataText;
							aSubContext[iIndex].comments = data.comments ? data.comments : "";
						});
					} else {
						const aDraftData = result.value;
						aDraftData.forEach(function (data) {
							const aSubContext = that.getView().getModel("multiReqModel").getData().subcontext;
							const iIndex = aSubContext[0].isRework ? 0 : Number(data.tabID) - 1
							aSubContext[iIndex].typeOfSupport = data.need_from_CustAdvisory ? data.need_from_CustAdvisory : "";
							aSubContext[iIndex].isMeetingPlanned = data.cust_asked_forMeeting ? true : false;
							aSubContext[iIndex].meetingTypeID = data.meetingTypeKey ? data.meetingTypeKey : "";
							aSubContext[iIndex].comments = data.comments ? data.comments : "";
							aSubContext[iIndex].solutionsInScope = data.solution_Models ? data.solution_Models : "";
							aSubContext[iIndex].preferredPresales = data.custAdvisory_Resource ? data.custAdvisory_Resource : "";
							aSubContext[iIndex].meetingGoal = data.Meeting_Goal ? data.Meeting_Goal : "";
							aSubContext[iIndex].meetingLocation = data.meetingLocation ? data.meetingLocation : "";
							aSubContext[iIndex].meetingDate = data.meetingDate ? data.meetingDate : "";
							aSubContext[iIndex].meetingTime = data.meetingDate ? data.meetingTime : "";
							aSubContext[iIndex].involvedPartiesNames = data.involved_SAP_Parties_Name ? data.involved_SAP_Parties_Name : "";
							aSubContext[iIndex].participantTypeDetails = data.Participants_Type_Details ? data.Participants_Type_Details : "";
							aSubContext[iIndex].supportTypeKey = data.SupportTypeIDs ? data.SupportTypeIDs : "";
							aSubContext[iIndex].supportType = data.SupportTypeIDs ? that.getDropDownValues(data.SupportTypeIDs, "supportType") : "";

							if (aSubContext[iIndex].isMeetingPlanned) {
								aSubContext[iIndex].involvedPartiesKey = data.Involved_SAP_PartiesIDs ? data.Involved_SAP_PartiesIDs : "";
								aSubContext[iIndex].involvedPartiesKeys = data.Involved_SAP_PartiesIDs ? data.Involved_SAP_PartiesIDs.split(";").join().split(",") : [];
								aSubContext[iIndex].involvedParties = data.Involved_SAP_PartiesIDs ? that.getDropDownValues(data.Involved_SAP_PartiesIDs, "involvedParties") : "";
								aSubContext[iIndex].languageKey = data.LanguageIDs ? data.LanguageIDs : "";
								aSubContext[iIndex].language = data.LanguageIDs ? that.getDropDownValues(data.LanguageIDs, "language") : "";
								aSubContext[iIndex].participantTypeKey = data.ParticipantTypeIDs ? data.ParticipantTypeIDs : "";
								aSubContext[iIndex].participantType = data.ParticipantTypeIDs ? that.getDropDownValues(data.ParticipantTypeIDs, "participantType") : "";
								aSubContext[iIndex].meetingTypeKey = data.meetingTypeID ? data.meetingTypeID : "";
								aSubContext[iIndex].meetingType = data.meetingTypeID ? that.getDropDownValues(data.meetingTypeID, "meetingType") : "";
							}

						});
					}
					that._setPrevioslySelectedValues(that.getView().getModel("multiReqModel").getData().subcontext[0], that.getView().getModel("multiReqModel").getData().subcontext[0]);

				}
				const oModel = new sap.ui.model.json.JSONModel();
				oModel.setData(result.value);
				that.getView().setModel(oModel, "draftTable");
				sap.ui.core.BusyIndicator.hide();
				that.getView().getModel("multiReqModel").refresh();

				//set drafturl
				const oUrlModel = new sap.ui.model.json.JSONModel();
				oUrlModel.setData(groupedUrls);
				that.getView().setModel(oUrlModel, "draftUrlTable");
				sap.ui.core.BusyIndicator.hide();
			},
			getDropDownValues:function(values,fieldName){
				const oFormModelData = this.getView().getModel("formValConfigModel").getData();
				const aSupportTypes = oFormModelData["idsupp_type"],
				aMeetingTypes = oFormModelData["idmeet_type"],
				aLanguages = oFormModelData["idlang"],
				aParticipantTypes = oFormModelData["idparticpnt_type"],
				aInvolvedParties = oFormModelData["idsap_parties"],
				aSupportTypesRISE = oFormModelData["idrise_dealphase"];
				if (fieldName === "involvedParties") {
					const aInvolvedPartiesKey = values.split(";");
					const aInvolvedPartiesDesc = [];
					aInvolvedPartiesKey.forEach(function (key) {
						const sDesc = aInvolvedParties.filter((item) => item.ID === key.trim())[0].Value;
						aInvolvedPartiesDesc.push(sDesc);
					})
					return aInvolvedPartiesDesc.join("; ")
				}
				if (fieldName === "language") {
					const aLanguageKey = values.split(";");
					const aLanguagesDesc = [];
					aLanguageKey.forEach(function (key) {
						const sDesc = aLanguages.filter((item) => item.ID === key.trim())[0].Value;
						aLanguagesDesc.push(sDesc);
					})
					return aLanguagesDesc.join("; ")
				}
				if (fieldName === "supportType") {
					const aSupportTypeKey = values.split(";");
					const aSupportTypeDesc = [];
					aSupportTypeKey.forEach(function (key) {
						var suppType=aSupportTypes.filter((item) => item.ID === key.trim())
						if(suppType.length){
							const sDesc = suppType[0].Value;
						aSupportTypeDesc.push(sDesc);
						}						
						// aSupportTypeDesc.push(sDesc);
					})
					return aSupportTypeDesc.join("; ")
				}
				if (fieldName === "participantType") {
					const aParticipantTypeKey = values.split(";");
					const aParticipantTypeDesc = [];
					aParticipantTypeKey.forEach(function (key) {
						const sDesc = aParticipantTypes.filter((item) => item.ID === key.trim())[0].Value;
						aParticipantTypeDesc.push(sDesc);
					})
					return aParticipantTypeDesc.join("; ")
				}
				if (fieldName === "meetingType") {
					const aMeetingTypeKey = values.split(";");
					const aMeetingTypeDesc = [];
					aMeetingTypeKey.forEach(function (key) {
						const sDesc = aMeetingTypes.filter((item) => item.ID === key.trim())[0].Value;
						aMeetingTypeDesc.push(sDesc);
					})
					return aMeetingTypeDesc.join("; ")
				}
			},
			_createWorkFlowFileUploadId: function (oModelData, that) {
				//generating unique id for fileUploader
				let workflowInstanceId = that.getView().getModel("wfInstanceModel").getProperty("/InstanceID");
				let aSubContext = that.getView().getModel("multiReqModel").getData().subcontext;

				if (aSubContext.length > 1) {
					let aReqArea = oModelData.requestArea;
					let sFormattedId = aReqArea.replace(/[\s~`!@#$%^&*()_+\-={[}\]|\\:;"'<,>.?/]+/g, '-').toLowerCase();
					oModelData.workflowFileUploadId = workflowInstanceId + sFormattedId;
				} else if (oModelData.workflowFileUploadId) {
					oModelData.workflowFileUploadId = oModelData.workflowFileUploadId;
				} else {
					oModelData.workflowFileUploadId = workflowInstanceId;
				}
				that.getView().getModel("multiReqModel").refresh(true);
				that.getView().byId("idSubmitFormContainer").setVisible(true);
			},
			_fetchFormActions: function (self) {
				let sOrgID = self.getView().getModel("multiReqModel").getData().subcontext[0].OrgID;
				let sOrgType = self.getView().getModel("multiReqModel").getData().subcontext[0].OrgType;
				let sEngagementType=self.getView().getModel("multiReqModel").getData().subcontext[0].EngagementType
				let sUsertask = "Requester";
				let sFormatOrgID = self._getOrgIDnumber(sOrgID, sOrgType);
				let sUrl = self._getRuntimeBaseURL() +
					`/cap/req-area-api-/Action?$filter=eng_Type_ID eq '${sEngagementType}' and (orgID eq '${sFormatOrgID}' and orgType eq '${sOrgType}') and (UserTask eq '${sUsertask}')`;

				$.ajax({
					contentType: "application/json",
					url: sUrl,
					async: false,
					type: "GET",
					success: function (oData) {
						let aFormActionsValues = oData.value;
						let oFormValue = aFormActionsValues.reduce(function (formVal, val) {
							(formVal[val.Action_ID] = formVal[val.Action_ID] || []).push(val);
							return formVal;
						}, {})
						let oFormActionsConfigModel = new JSONModel(oFormValue);
						self.getView().setModel(oFormActionsConfigModel, "formActionsConfigModel");
						self.configureFooterButtons(self);
						self.getView().byId("idReqSection").setBusy(false);
					},
					error: function (oError) {
						self.getView().byId("idReqSection").setBusy(false);
					}
				});

			},
			_fetchFormValues: function (self) {
				let sOrgID = self.getView().getModel("multiReqModel").getData().subcontext[0].OrgID;
				let sOrgType = self.getView().getModel("multiReqModel").getData().subcontext[0].OrgType;
				let sEngagementType=self.getView().getModel("multiReqModel").getData().subcontext[0].EngagementType
				let sFormatOrgID = self._getOrgIDnumber(sOrgID, sOrgType);
				let sUrl = self._getRuntimeBaseURL() +
					`/cap/req-area-api-/Form_values?$filter=(orgID eq '${sFormatOrgID}' and orgType eq '${sOrgType}') and eng_Type_ID eq '${sEngagementType}' and Operational_Status eq 'X'`;
				$.ajax({
					contentType: "application/json",
					url: sUrl,
					async: false,
					type: "GET",
					success: function (oData) {
						let aFormValues = oData.value;
						let oFormValue = aFormValues.reduce(function (formVal, val) {
							(formVal[val.Field_ID] = formVal[val.Field_ID] || []).push(val);
							return formVal;
						}, {})
						var aValNotToBeSorted = ["other", "not applicable"]
						let dropDownIDs = ["business_model", "est_acv", "idsupp_type_PQA", "idsupp_type_fbs", "infra_structure_provider", "main_sol", "opp_origin"]
						dropDownIDs.forEach(obj => {
							if (oFormValue[obj]) {
								oFormValue[obj].sort((a, b) => {
									let aValNotToBeSorted = ["other", "not applicable"]
									let isSpecA = aValNotToBeSorted.includes(a.Value.toLowerCase())
									let isSpecB = aValNotToBeSorted.includes(b.Value.toLowerCase())
									if (isSpecA && !isSpecB)
										return 1;
									if (!isSpecA && isSpecB)
										return -1
									return a.Value.localeCompare(b.Value)
								})
								if (obj == 'est_acv') {
									oFormValue[obj].forEach(acvObj => {
										if (aValNotToBeSorted.includes(acvObj.Value.toLowerCase())) {
											acvObj.mainText = acvObj.Value
										} else {


											let index = acvObj.Value.indexOf("(")
											let part1 = acvObj.Value.substring(0, index)
											let part2 = acvObj.Value.substring(index)
											acvObj.mainText = part1.trim()
											acvObj.addText = part2
										}
									})
								}
							}
						})	
						//sort drop down values alphabetically
						if(oFormValue["idsupp_type"]){
							oFormValue["idsupp_type"].sort((a, b) => {
								return a.Value.localeCompare(b.Value)
							})			
						}		
						// if(oFormValue["idlang"]){
						// 	oFormValue["idlang"].sort((a, b) => {
						// 		return a.Value.localeCompare(b.Value)
						// 	})			
						// }		
						if(oFormValue["idparticpnt_type"]){
							oFormValue["idparticpnt_type"].sort((a, b) => {
								return a.Value.localeCompare(b.Value)
							})			
						}		
						if(oFormValue["idsap_parties"]){
							oFormValue["idsap_parties"].sort((a, b) => {
							let isSpecA = a.Value.toLowerCase() == 'none'
							let isSpecB = b.Value.toLowerCase() == 'none'
							if (isSpecA && !isSpecB)
								return 1;
							if (!isSpecA && isSpecB)
								return -1
							return a.Value.localeCompare(b.Value)
							})		
						}	
						
						let oFormValConfigModel = new JSONModel(oFormValue);
						self.getView().setModel(oFormValConfigModel, "formValConfigModel");
						self.getOwnerComponent().getModel("mrrAppEngModel").setProperty("/FormValues",oFormValue)
						self.updateSuppTypeValuesCA()
					},
					error: function (oError) {

					}
				});

			},
			/**
			 * This method is called to set the supp type values based on selected roles in case of CA			 
			 * @param {number} index - index of the req or sub req			 			 
			 */
			updateSuppTypeValuesCA: function (index) {
				if(index!=undefined){
					var iIndex=index
				}else{								
				let oNavContainer = this.getView().byId("idNavContainerMrq");
				let currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
				var iIndex = Number(currentPageId.slice(-1));	
				}
				let sEngagementType = this.getView().getModel("multiReqModel").getData().subcontext[iIndex].EngagementType
				var oFormValue=this.getOwnerComponent().getModel("mrrAppEngModel").getProperty("/FormValues")
				var oFormValuesDeepCopy= jQuery.extend(true, {} ,oFormValue )
				var aRolesIDs=[]
				this.getView().getModel("multiReqModel").getData().subcontext[iIndex].aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RolesData.forEach(obj=>{aRolesIDs.push(obj.RoleID)})
				if (sEngagementType == '0001') {
					var sReqType=this.getView().getModel("multiReqModel").getData().subcontext[iIndex].RequestType
					oFormValuesDeepCopy["idsupp_type"] = oFormValuesDeepCopy["idsupp_type"].filter(item => aRolesIDs.includes(item.Role_ID) && item.reqType===sReqType)
							
				oFormValuesDeepCopy["idsupp_type"]=[...new Map(oFormValuesDeepCopy["idsupp_type"].map(item=>[item.ID,item])).values()]
				this.getView().getModel("formValConfigModel").setData(oFormValuesDeepCopy)	
				}
				this.getView().getModel("formValConfigModel").refresh(true)
				
				
			},
			formatFormMultiDefaultSelect: function (formVal) {
				if (formVal) {
					let aSelectedKeys = [];
					for (let i = 0; i < formVal.length; i++) {
						if (formVal[i].Default_Flag === "X") {
							aSelectedKeys.push(formVal[i].ID);
							if (formVal[i].Field_ID === "idmeet_type") {
								aSelectedKeys = formVal[i].ID;
							}
						}
					}
					return aSelectedKeys;
				}

			},
			//start code of form config
			//set form configurable model

			_getOrgIDnumber: function (sOrgID, sOrgType) {
				if (sOrgType === "SORG") {
					return Number(sOrgID.replace('SORG-', '')).toString();
				} else {
					return sOrgID;
				}

			},
			_fetchFormConfigData: function (self) {
				let sOrgID = self.getView().getModel("multiReqModel").getData().subcontext[0].OrgID;
				let sOrgType = self.getView().getModel("multiReqModel").getData().subcontext[0].OrgType;
				let sEngagementType=self.getView().getModel("multiReqModel").getData().subcontext[0].EngagementType
				let sFormatOrgID = self._getOrgIDnumber(sOrgID, sOrgType);
				let sUrl = self._getRuntimeBaseURL() +
					`/cap/req-area-api-/Form_Tab?$expand=Fields&&$filter=orgID eq '${sFormatOrgID}' and orgType eq '${sOrgType}' and eng_Type_ID eq '${sEngagementType}'`;
				$.ajax({
					contentType: "application/json",
					url: sUrl,
					async: true,
					type: "GET",
					success: function (oData) {
						let aDataNew = [];

						for (let i = 0; i < oData.value.length; i++) {
							if (!aDataNew[oData.value[i].ID]) {
								aDataNew[oData.value[i].ID] = [];
							}
							aDataNew[oData.value[i].ID] = oData.value[i];
							let aDataNewFields = [];
							for (let j = 0; j < oData.value[i].Fields.length; j++) {

								if (!aDataNew[oData.value[i].Fields[j].ID]) {
									aDataNewFields[oData.value[i].Fields[j].ID] = [];
								}
								aDataNewFields[oData.value[i].Fields[j].ID] = oData.value[i].Fields[j];
							}
							aDataNew[oData.value[i].ID].Fields = aDataNewFields;
						}
						let oFormConfigModel = new JSONModel(aDataNew);
						self.getView().setModel(oFormConfigModel, "formConfigModel");

						let oMrqModelData = self.getView().getModel("multiReqModel").getData().subcontext;
						let oReqAreaLabel = self.getView().getModel("formConfigModel").getProperty("/idrequestdetails/Fields/idreqarea/Label");
						if (oMrqModelData.length !== 1) {
							for (let i = 0; i < oMrqModelData.length; i++) {
								oMrqModelData[i].reqAreaLabel = oReqAreaLabel + " #" + [i + 1];
							}
						} else {
							oMrqModelData[0].reqAreaLabel = oReqAreaLabel;
						}
						self.getView().getModel("multiReqModel").refresh(true);
					},
					error: function (oError) {

					}
				});
			},
			formatFormConfigVisibility: function (sVal) {
				if (sVal === "X") {
					return true;
				} else {
					return false;
				}
			},
			formatFormConfigReqAreaVisibility: function (sVal, isResourceProfile) {
				return sVal === "X" && !(isResourceProfile);
			},
			formatFieldForNonRise: function (isRise, formVisibility) {
				if (formVisibility === "X") {
					let isRiseVisibility = !isRise;
					return isRiseVisibility;
				} else {
					return false;
				}
			},
			formatFieldBasedOnMultipleProperties: function (bVal, formVisibility) {
				if (formVisibility === "X") {
					return bVal;
				} else {
					return false;
				}
			},
			formatFieldSelectField: function (bVal, formVisibility, isMeetingPlanned) {
				if (formVisibility === "X") {
					if (isMeetingPlanned === true) {
						return bVal;
					} else {
						return false;
					}
				} else {
					return false;
				}
			},

			//end code of form config
			_onCopyContent: function (oModel, iIndex, that) {
				let bSelected = oModel.subcontext[iIndex].selected;
				let oContextData = oModel.subcontext[iIndex];
				var oModelData ;
				if(this.getView().getModel("multiReqModel").getData().subcontext[0].isRework){
					 oModelData = this.getView().getModel("multiReqModel").getData().subcontext[0].requestDetails;
				}else{
					 oModelData = this.getView().getModel("multiReqModel").getData().subcontext
				}
				let prevObject = oModelData[iIndex - 1];
				let oFormModelData = this.getView().getModel("formValConfigModel").getData();

				oContextData.meetingGoal = (prevObject.meetingGoal && bSelected) ? prevObject.meetingGoal : "";
				oContextData.supportType = (prevObject.supportType && bSelected) ? prevObject.supportType : oFormModelData[
					"supp_type"];
				oContextData.meetingType = (prevObject.meetingType && bSelected) ? prevObject.meetingType : "";
				oContextData.meetingLocation = (prevObject.meetingLocation && bSelected) ? prevObject.meetingLocation : "";
				oContextData.meetingDate = (prevObject.meetingDate && bSelected) ? prevObject.meetingDate : "";
				oContextData.meetingTime = (prevObject.meetingTime && bSelected) ? prevObject.meetingTime : "";
				oContextData.language = (prevObject.language && bSelected) ? prevObject.language : oFormModelData["lang"];
				oContextData.participantType = (prevObject.participantType && bSelected) ? prevObject.participantType : oFormModelData[
					"particpnt_type"];
				oContextData.participantTypeDetails = (prevObject.participantTypeDetails && bSelected) ? prevObject.participantTypeDetails : "";
				oContextData.involvedParties = (prevObject.involvedParties && bSelected) ? prevObject.involvedParties : oFormModelData[
					"sap_parties"];
				oContextData.involvedPartiesKeys = (prevObject.involvedPartiesKeys && bSelected) ? prevObject.involvedPartiesKeys : [];
				oContextData.involvedPartiesNames = (prevObject.involvedPartiesNames && bSelected) ? prevObject.involvedPartiesNames : "";
				oContextData.preferredPresales = (prevObject.preferredPresales && bSelected) ? prevObject.preferredPresales : "";
				oContextData.supportTypeRISE = (prevObject.supportTypeRISE && bSelected) ? prevObject.supportTypeRISE : oFormModelData[
					"support_rise"];
				oContextData.isMeetingPlanned = (prevObject.isMeetingPlanned && bSelected) ? true : false;
				oContextData.isMeetingPlannedText = (prevObject.isMeetingPlannedText && bSelected) ? prevObject.isMeetingPlannedText : "";
				oContextData.typeOfSupport = (prevObject.typeOfSupport && bSelected) ? prevObject.typeOfSupport : "";
				oContextData.solutionsInScope = (prevObject.solutionsInScope && bSelected) ? prevObject.solutionsInScope : "";
				oContextData.isParticipantTypeSelected = (prevObject.isParticipantTypeSelected && bSelected) ? true : false

				oContextData.supportTypeKey = (prevObject.supportTypeKey && bSelected) ? prevObject.supportTypeKey : "";
				oContextData.participantTypeKey = (prevObject.participantTypeKey && bSelected) ? prevObject.participantTypeKey : "";
				oContextData.languageKey = (prevObject.languageKey && bSelected) ? prevObject.languageKey : "";
				oContextData.involvedPartiesKey = (prevObject.involvedPartiesKey && bSelected) ? prevObject.involvedPartiesKey : "";
				oContextData.meetingTypeKey = (prevObject.meetingTypeKey && bSelected) ? prevObject.meetingTypeKey : "";
				oContextData.comments = (prevObject.comments && bSelected) ? prevObject.comments : "";
				oContextData.attachmentUrls = (prevObject.attachmentUrls.length && bSelected) ? JSON.parse(JSON.stringify(prevObject.attachmentUrls)) : 
				[{
					"urlName": "",
					"url": "",
					"urlDelete": false,
					"urlNameValueState": "None",
					"urlValueStateText":"",
					"urlValueState": "None"
				}];
				var oModelData = that.getView().getModel("multiReqModel").getData().subcontext[iIndex];
				that._setPrevioslySelectedValues(oContextData, oContextData);
				if (bSelected) {
					that._validateFormFields(oContextData);
				}

			},

			onCopyContent: function (oEvent) {
				//copy the content from prev reqArea
				let oBindingContext = oEvent.getSource().getBindingContext("multiReqModel");
				let sBindingContextPath = oBindingContext.getPath();
				let iIndex = Number(sBindingContextPath.slice(-1));
				let oModelData = this.getView().getModel("multiReqModel").getData();
				this._onCopyContent(oModelData, iIndex, this);
			},
			_setDefaultFormValue: function () {
				//set default dropDown value for form fields
				let aDefaultSupportTypes = this.getView().getModel("formValConfigModel").getProperty("/idsupp_type").filter(obj => {
					return obj.Default_Flag === "X";
				}),
					aDefaultMeetingTypes = this.getView().getModel("formValConfigModel").getProperty("/idmeet_type").filter(obj => {
						return obj.Default_Flag === "X";
					}),
					aDefaultLanguages = this.getView().getModel("formValConfigModel").getProperty("/idlang").filter(obj => {
						return obj.Default_Flag === "X";
					}),
					aDefaultParticipantTypes = this.getView().getModel("formValConfigModel").getProperty("/idparticpnt_type").filter(obj => {
						return obj.Default_Flag === "X";
					}),
					aDefaultInvolvedParties = this.getView().getModel("formValConfigModel").getProperty("/idsap_parties").filter(obj => {
						return obj.Default_Flag === "X";
					}),
					aDefaultSupportRise = this.getView().getModel("formValConfigModel").getProperty("/idrise_dealphase").filter(obj => {
						return obj.Default_Flag === "X";
					}),
					oFormModel = this.getView().getModel("formValConfigModel").getData();
				oFormModel.supp_type = [];
				oFormModel.meet_type = [];
				oFormModel.lang = [];
				oFormModel.particpnt_type = [];
				oFormModel.sap_parties = [];
				oFormModel.support_rise = [];

				aDefaultSupportTypes.forEach(function (defValue) {
					oFormModel.supp_type.push(defValue.Value)
				});
				oFormModel.supp_type = oFormModel.supp_type.join("; ")

				aDefaultMeetingTypes.forEach(function (defValue) {
					oFormModel.meet_type.push(defValue.Value)
				});
				oFormModel.meet_type = oFormModel.meet_type.join("; ")

				aDefaultLanguages.forEach(function (defValue) {
					oFormModel.lang.push(defValue.Value)
				});
				oFormModel.lang = oFormModel.lang.join("; ")

				aDefaultParticipantTypes.forEach(function (defValue) {
					oFormModel.particpnt_type.push(defValue.Value)
				});
				oFormModel.particpnt_type = oFormModel.particpnt_type.join("; ")

				aDefaultInvolvedParties.forEach(function (defValue) {
					oFormModel.sap_parties.push(defValue.Value)
				});
				oFormModel.sap_parties = oFormModel.sap_parties.join("; ")

				aDefaultSupportRise.forEach(function (defValue) {
					oFormModel.support_rise.push(defValue.Value)
				});
				oFormModel.support_rise = oFormModel.support_rise.join("; ")

				this.getView().getModel("formValConfigModel").refresh(true);
			},
			// set previously selected values if the request was sent back
			_setPrevioslySelectedValues: function (oModelData, oRequestDetails, bNavigation, bInitialLoad) {
				if (oModelData.EngagementType === '0002') {
					oModelData["need_From_Fbs"] = oRequestDetails.need_From_Fbs;
					oModelData["supp_Type_FBS"] = oRequestDetails.supp_Type_FBS;
					oModelData["supp_Type_Pqa_Id"] = oRequestDetails.supp_Type_Pqa_Id;
					oModelData["c2c_Deal"] = oRequestDetails.c2c_Deal;
					oModelData["opp_Origin_Id"] = oRequestDetails.opp_Origin_Id;
					oModelData["Opp_Number"] = oRequestDetails.Opp_Number;
					oModelData["solution_Id"] = oRequestDetails.solution_Id;
					oModelData["est_Acv"] = oRequestDetails.est_Acv;
					oModelData["model_Id"] = oRequestDetails.model_Id;
					oModelData["isp_Id"] = oRequestDetails.isp_Id;
					oModelData["io_Number"] = oRequestDetails.io_Number;
					oModelData["contact_Prsn_Id"] = oRequestDetails.contact_Prsn_Id;
					oModelData["contact_Prsn_Email"] = oRequestDetails.contact_Prsn_Email;
					oModelData["oppclosing_Date"] = oRequestDetails.oppclosing_Date;
					oModelData["contract_Start_Date"] = oRequestDetails.contract_Start_Date;
					oModelData["contract_End_Date"] = oRequestDetails.contract_End_Date;					
					oModelData["comments"] = oRequestDetails.comments;	
					oModelData["attachmentUrls"] = oRequestDetails.attachmentUrls;				

				} else {
					let oFormModelData = this.getView().getModel("formValConfigModel").getData();
					//set values for Inputs
					oModelData["meetingGoal"] = oRequestDetails.meetingGoal;
					oModelData["meetingDate"] = oRequestDetails.meetingDate;
					oModelData["meetingTime"] = oRequestDetails.meetingTime;
					oModelData["preferredPresales"] = oRequestDetails.preferredPresales;
					oModelData["isMeetingPlanned"] = oRequestDetails.isMeetingPlanned;
					oModelData["solutionsInScope"] = oRequestDetails.solutionsInScope;
					oModelData["typeOfSupport"] = oRequestDetails.typeOfSupport;
					oModelData["participantTypeDetails"] = oRequestDetails.participantTypeDetails;
					oModelData["isParticipantTypeSelected"] = oRequestDetails.isParticipantTypeSelected;
					oModelData["meetingLocation"] = oRequestDetails.meetingLocation;
					oModelData["language"] = oRequestDetails.language;
					oModelData["languageKey"] = oRequestDetails.languageKey;
					oModelData["supportTypeKey"] = oRequestDetails.supportTypeKey;
					oModelData["supportType"] = oRequestDetails.supportType;
					oModelData["participantType"] = oRequestDetails.participantType;
					oModelData["participantTypeKey"] = oRequestDetails.participantTypeKey;
					oModelData["involvedParties"] = oRequestDetails.involvedParties;
					oModelData["involvedPartiesKey"] = oRequestDetails.involvedPartiesKey;
					oModelData["involvedPartiesKeys"] = oRequestDetails.involvedPartiesKeys;
					oModelData["involvedPartiesNames"] = oRequestDetails.involvedPartiesNames;
					oModelData["meetingGoal"] = oRequestDetails.meetingGoal;
					oModelData["attachmentUrls"] = oRequestDetails.attachmentUrls;
					oModelData["comments"] = oModelData["isRework"] ? oModelData["comments"] : oRequestDetails.comments;

					//set values for Selects
					let aSupportTypes = oFormModelData["idsupp_type"],
						aMeetingTypes = oFormModelData["idmeet_type"],
						aLanguages = oFormModelData["idlang"],
						aParticipantTypes = oFormModelData["idparticpnt_type"],
						aInvolvedParties = oFormModelData["idsap_parties"],
						aSupportTypesRISE = oFormModelData["idrise_dealphase"];

					let aSupportTypesKeys = [];
					for (let i = 0; i < aSupportTypes.length; i++) {
						aSupportTypes[i].Default_Flag = "";
						if (oRequestDetails.supportType) {
							let aSupportTypesValues = oRequestDetails.supportType.split("; ");
							for (let j = 0; j < aSupportTypesValues.length; j++) {
								if (this.i18nModel.getText(aSupportTypes[i].Value) === aSupportTypesValues[j]) {
									aSupportTypes[i].Default_Flag = "X";
									aSupportTypesKeys.push(aSupportTypes[i]);
								}
							}
						}
					}
					if (aMeetingTypes) {
						for (let i = 0; i < aMeetingTypes.length; i++) {
							aMeetingTypes[i].Default_Flag = "";
							if (this.i18nModel.getText(aMeetingTypes[i].Value) === oRequestDetails.meetingType) {
								this.byId("MeetingTypeSelectMrq").setSelectedKey(aMeetingTypes[i].key);
								oRequestDetails["meetingType"] = oRequestDetails.meetingType;
								aMeetingTypes[i].Default_Flag = "X";
							}
						}
					}
					let aLanguageKeys = [];
					for (let i = 0; i < aLanguages.length; i++) {
						aLanguages[i].Default_Flag = "";
						if (oRequestDetails.language) {
							let aLanguageValues = oRequestDetails.language.split("; ");
							for (let j = 0; j < aLanguageValues.length; j++) {
								if (this.i18nModel.getText(aLanguages[i].Value) === aLanguageValues[j]) {
									aLanguages[i].Default_Flag = "X";
									aLanguageKeys.push(aLanguages[i]);
								}
							}
						}
					}
					let aParticipantTypesKeys = [];
					for (let i = 0; i < aParticipantTypes.length; i++) {
						aParticipantTypes[i].Default_Flag = "";
						if (oRequestDetails.participantType) {
							let aParticipantTypesValues = oRequestDetails.participantType.split("; ");
							for (let j = 0; j < aParticipantTypesValues.length; j++) {
								if (this.i18nModel.getText(aParticipantTypes[i].Value) === aParticipantTypesValues[j]) {
									aParticipantTypes[i].Default_Flag = "X";
									aParticipantTypesKeys.push(aParticipantTypes[i]);
								}
							}
						}
					}

					if (oModelData["participantType"]) {
						oModelData["isParticipantTypeSelected"] = true;
					} else {
						oModelData["isParticipantTypeSelected"] = false;
					}

					let aInvolvedPartiesKeys = [];
					for (let i = 0; i < aInvolvedParties.length; i++) {
						aInvolvedParties[i].Default_Flag = "";
						if (oRequestDetails.involvedParties) {
							let aInvolvedPartiesValues = oRequestDetails.involvedParties.split("; ");
							for (let j = 0; j < aInvolvedPartiesValues.length; j++) {
								if (this.i18nModel.getText(aInvolvedParties[i].Value) === aInvolvedPartiesValues[j]) {
									aInvolvedParties[i].Default_Flag = "X";
									aInvolvedPartiesKeys.push(aInvolvedParties[i].Value);
								}
							}
						}
					}

					if (aInvolvedPartiesKeys.length > 0) {
						if (!aInvolvedPartiesKeys.includes("None")) {
							oModelData["namesOfPartiesVisible"] = true;
						} else {
							oModelData["namesOfPartiesVisible"] = false;
						}

					} else {
						oModelData["namesOfPartiesVisible"] = false;
					}

					let aSupportTypesRISEKeys = [];
					for (let i = 0; i < aSupportTypesRISE.length; i++) {
						aSupportTypesRISE[i].Default_Flag = "";
						if (oRequestDetails.supportTypeRISE) {
							let aSupportTypesRISEValues = oRequestDetails.supportTypeRISE.split("; ");
							for (let j = 0; j < aSupportTypesRISEValues.length; j++) {
								if (this.i18nModel.getText(aSupportTypesRISE[i].Value) === aSupportTypesRISEValues[j]) {
									aSupportTypesRISE[i].Default_Flag = "X";
									aSupportTypesRISEKeys.push(aSupportTypesRISE[i].Value);
								}
							}
						}
					}
					oModelData["supportTypeRISE"] = oRequestDetails.supportTypeRISE;
					this.onSwitchStateChange("", this, bInitialLoad);
				}
				this.getView().getModel("multiReqModel").refresh(true);
				if (bNavigation !== true) {
					this.getView().getModel("formValConfigModel").refresh(true);
				}
			},
			configureFooterButtons: function (that) {
				let oFormActionsModelData = that.getView().getModel("formActionsConfigModel").getData();
				let oModel = that.getView().getModel("multiReqModel").getData();
				let oSubmitButton = that.getView().byId("idSubmitBtn");
				let oCancelButton = that.getView().byId("idCancelBtn");
				let oNextReqButton = that.getView().byId("idNextReqAreaBtn");
				let oPrevReqButton = that.getView().byId("idPrevReqAreaBtn");
				let oSaveDraftButton = that.getView().byId("idSaveDraft");

				if (that.getView().getModel("multiReqModel").getData().subcontext.length === 1) {
					// Implementation for the sendRequest action
					oNextReqButton.setVisible(false);
					oPrevReqButton.setVisible(false);
					oSaveDraftButton.setVisible(true);
					if (oFormActionsModelData.idsubmit[0].Visibility === "X") {
						// Add 'SendRequest' action to the task
						oSubmitButton.setVisible(true);
					}

					if (oFormActionsModelData.idterminate[0].Visibility === "X") {
						oCancelButton.setVisible(true);
						oCancelButton.setText(oFormActionsModelData.idterminate[0].Label);
					}
				} else {
					//multiple req area

					that._setMultiReqAreaFooterButtons(that, true);

				}
			},
			_setMultiReqAreaFooterButtons: function (that, bInitialLoad) {
				let oFormActionsModelData = that.getView().getModel("formActionsConfigModel").getData();
				let iIndex;
				if (!bInitialLoad) {
					let oNavContainer = that.getView().byId("idNavContainerMrq");
					let currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
					iIndex = Number(currentPageId.slice(-1));
				} else {
					iIndex = 0;
				}
				let oModel = that.getView().getModel("multiReqModel").getData();
				let oSubmitButton = that.getView().byId("idSubmitBtn");
				let oCancelButton = that.getView().byId("idCancelBtn");
				let oNextReqButton = that.getView().byId("idNextReqAreaBtn");
				let oPrevReqButton = that.getView().byId("idPrevReqAreaBtn");
				let oSaveDraftButton = that.getView().byId("idSaveDraft");
				let navtoPageId;

				//remove all buttons
				oSubmitButton.setVisible(false);
				oCancelButton.setVisible(false);
				oNextReqButton.setVisible(false);
				oSaveDraftButton.setVisible(true);
				oPrevReqButton.setVisible(false);

				//Add terminate action
				if (oFormActionsModelData.idterminate[0].Visibility === "X") {
					oCancelButton.setVisible(true);
					oCancelButton.setText(oFormActionsModelData.idterminate[0].Label);
				}
				if (oModel.subcontext[iIndex + 1]) {
					if (iIndex !== 0) {
						// Add 'Previous Request Area' action to the task
						oPrevReqButton.setVisible(true);
					}
					// Add 'Next Request Area' action to the task
					oNextReqButton.setVisible(true);
					oSaveDraftButton.setVisible(false);
				} else {
					// Add 'SendRequest' action to the task
					oSubmitButton.setVisible(true);

					// Add 'Previous Request Area' action to the task
					oPrevReqButton.setVisible(true)
				}
			},
			navtoReqArea: function (navtoPageId, sAction) {
				//navingation to reqArea
				//let startupParameters = this.getComponentData().startupParameters;
				let iMultiReqContextIndex;
				let oView = this.getView();
				let oNavContainer = oView.byId("idNavContainerMrq")
				let oModel = this.getView().getModel("multiReqModel").getData();
				let currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
				let iIndex = Number(currentPageId.slice(-1));
				oNavContainer.to(navtoPageId);
				let sKey = this.getView().byId(navtoPageId).getBindingContext("multiReqModel").getProperty("requestArea");
				this.getView().byId("iconTabHeader").setSelectedKey(sKey);
				this._setMultiReqAreaFooterButtons(this);
				this.getView().getModel("multiReqModel").refresh(true);
				let i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				var that = this;
				if (sAction === "next") {
					iMultiReqContextIndex = iIndex + 1;
					//attachment urls
					this._initializeUrls(iMultiReqContextIndex);
					
						this.getResProfileDetails(iMultiReqContextIndex);
				
					oModel.subcontext[iIndex].requestCopyDetails = this._formRequestDetails(oModel.subcontext[iIndex]);
					if (oModel.subcontext[iMultiReqContextIndex].currentRequestDetails) {
						if (oModel.subcontext[iIndex + 1].selected) {
							if (oModel.subcontext[iIndex].requestCopyDetails.attachmentUrls) {
								if (!oModel.subcontext[iIndex].requestCopyDetails.attachmentUrls.length) {
									oModel.subcontext[iIndex].requestCopyDetails.attachmentUrls = [{
										"urlName": "",
										"url": "",
										"urlDelete": false,
										"urlNameValueState": "None",
										"urlValueStateText": "",
										"urlValueState": "None"
									}];
								}
							}
							if (JSON.stringify(oModel.subcontext[iIndex].requestCopyDetails) !==
								JSON.stringify(oModel.subcontext[iMultiReqContextIndex].currentRequestDetails)) {
								const sCopyMsg = oModel.subcontext[iIndex].isResourceProfile ? i18nModel.getText("searchReqMsg") : i18nModel.getText("reqAreaMsg");
								let sAreaText;
								let sCurrentSearchText;
								if(oModel.subcontext[iIndex].isResourceProfile){
								    sAreaText = oModel.subcontext[iIndex].searchFieldsText;
									sCurrentSearchText = oModel.subcontext[iIndex+1].searchFieldsText;
								}else{
									sAreaText = oModel.subcontext[iIndex].requestAreaPath;
									sCurrentSearchText = oModel.subcontext[iIndex+1].requestAreaPath;
								}
								MessageBox.show(
									`The form values on ${sCopyMsg} '${sAreaText}' has been changed.\n Do you want to overwrite same on ${sCopyMsg} '${sCurrentSearchText}' ?`, {
									icon: MessageBox.Icon.WARNING,
									title: `${i18nModel.getText("copyConfirmation")}`,
									actions: [MessageBox.Action.YES, MessageBox.Action.NO],
									emphasizedAction: MessageBox.Action.YES,
									onClose: function (oAction) {
										if (oAction === MessageBox.Action.YES) {
											that._onCopyContent(oModel, iMultiReqContextIndex, that);

										} else {
											oModel.subcontext[iMultiReqContextIndex].selected = false;
											that.getView().getModel("multiReqModel").refresh(true);
										}

									}
								}
								);
							}

						}
					}
				} else {
					iMultiReqContextIndex = iIndex - 1;
					
						this.getResProfileDetails(iMultiReqContextIndex);
				
					
					//attachment urls
					this._initializeUrls(iMultiReqContextIndex);
					oModel.subcontext[iIndex].currentRequestDetails = this._formRequestDetails(oModel.subcontext[iIndex]);
				}
				let oContextData = this.getView().getModel("multiReqModel").getData().subcontext[iMultiReqContextIndex];
				this._setPrevioslySelectedValues(oContextData, oContextData);
				//this.checkIfFolderExists("WorkflowManagement", this);
				//this.loadAttachments(oContextData, that);
			},
			_setMultiReqButtons: function (startupParameters) {
				let oFormActionsModelData = this.getView().getModel("formActionsConfigModel").getData();
				let oNavContainer = this.getView().byId("idNavContainerMrq");
				let currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
				let oModel = this.getView().getModel("multiReqModel").getData();
				let iIndex = Number(currentPageId.slice(-1));
				let sPrevReqAreaButtonText = this.i18nModel.getText("PREV_REQAREA_BTN_TEXT");
				let sNextReqAreaButtonText = this.i18nModel.getText("NEXT_REQAREA_BTN_TEXT");
				let sendRequestText = this.i18nModel.getText("SUBMIT_REQUEST");
				let terminateRequestText = this.i18nModel.getText("TERMINATE");
				var that = this;
				let navtoPageId;
				var startupParameters = this.getComponentData().startupParameters;
				//remove all buttons
				startupParameters.inboxAPI.removeAction(sPrevReqAreaButtonText);
				startupParameters.inboxAPI.removeAction(sNextReqAreaButtonText);
				startupParameters.inboxAPI.removeAction(oFormActionsModelData.idsubmit[0].Label);
				startupParameters.inboxAPI.removeAction(oFormActionsModelData.idterminate[0].Label);
				// Implementation for the prevReqArea action
				let oPrevReqAreaButton = {
					sBtnTxt: sPrevReqAreaButtonText,
					onBtnPressed: function () {
						navtoPageId = currentPageId.replace(/\idNavContainerMrq[^\s]*/g, "") + "idNavContainerMrq-" + (iIndex - 1).toString();
						that.navtoReqArea(navtoPageId, "prev");
						that.getView().getModel("multiReqModel").refresh(true);
					}
				};

				// Implementation for the nextReqArea action
				let oNextReqAreaButton = {
					sBtnTxt: sNextReqAreaButtonText,
					type: "Emphasized",
					onBtnPressed: function () {
						let processContext = that.getView().getModel("multiReqModel").getData().subcontext[iIndex];
						navtoPageId = currentPageId.replace(/\idNavContainerMrq[^\s]*/g, "") + "idNavContainerMrq-" + (iIndex + 1).toString();
						that._validateInput(processContext, startupParameters.taskModel.getData().InstanceID, "Next", navtoPageId);
					}
				};
				// Implementation for the Submit Request action
				let oSendRequestAction = {
					sBtnTxt: sendRequestText,
					onBtnPressed: function () {
						let model = that.getView().getModel("multiReqModel");
						model.refresh(true);
						let processContext = model.getData().subcontext[iIndex];
						navtoPageId = currentPageId.replace(/\idNavContainerMrq[^\s]*/g, "") + "idNavContainerMrq-" + (iIndex + 1).toString();

						// Call a local method to perform further action
						that._validateInput(
							processContext,
							startupParameters.taskModel.getData().InstanceID,
							"Submit Request",
							"Complete"
						);
					}
				};
				// Implementation for the terminate action
				let oTerminateRequestAction = {
					sBtnTxt: terminateRequestText,
					onBtnPressed: function () {
						let model = that.getView().getModel("multiReqModel");
						model.refresh(true);
						let processContext = model.getData().subcontext[0];

						// Call a local method to perform further action
						that._triggerComplete(
							processContext,
							startupParameters.taskModel.getData().InstanceID,
							"Terminate"
						);
					}
				};
				//Add terminate action
				if (oFormActionsModelData.idterminate[0].Visibility === "X") {
					// Add 'Terminate' action to the task
					startupParameters.inboxAPI.addAction({
						action: oFormActionsModelData.idterminate[0].Label,
						label: oFormActionsModelData.idterminate[0].Label,
						type: "Reject"
					},
						// Set the onClick function
						oTerminateRequestAction.onBtnPressed);
				}
				if (oModel.subcontext[iIndex + 1]) {
					if (iIndex !== 0) {
						// Add 'Previous Request Area' action to the task
						startupParameters.inboxAPI.addAction({
							action: sPrevReqAreaButtonText,
							label: sPrevReqAreaButtonText,
							type: "Accept"
						},
							// Set the onClick function
							oPrevReqAreaButton.onBtnPressed);
					}

					// Add 'Next Request Area' action to the task
					startupParameters.inboxAPI.addAction({
						action: sNextReqAreaButtonText,
						label: sNextReqAreaButtonText,
						type: "Accept"
					},
						// Set the onClick function
						oNextReqAreaButton.onBtnPressed);
				} else {
					// Add 'SendRequest' action to the task
					startupParameters.inboxAPI.addAction({
						action: oFormActionsModelData.idsubmit[0].Label,
						label: oFormActionsModelData.idsubmit[0].Label,
						type: "Accept"
					},
						// Set the onClick function
						oSendRequestAction.onBtnPressed);
					// Add 'Previous Request Area' action to the task
					startupParameters.inboxAPI.addAction({
						action: sPrevReqAreaButtonText,
						label: sPrevReqAreaButtonText,
						type: "Accept"
					},
						// Set the onClick function
						oPrevReqAreaButton.onBtnPressed);

				}
			},
			getMessage: function (sText) {
				let resourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				return resourceBundle.getText(sText);

			},
			   /**
         * Validate submit form page
         * @param {object} processContext - context details
         * @param {boolean} bIsSaveDraft - Action 'Save Draft' => bIsSaveDraft 'true'
         */
			_validateFormFields: function (processContext,bIsSaveDraft) {
				this.errorExist = false;
				let oThisController = this,
					oMCommon = oThisController.getView().getModel("mCommon");
				let requestDetailsFields = this._configFormValidation(processContext);
				if (processContext.comments) {
					processContext.comments = processContext.comments.trim();
				}
				let requestDetailsValue;
				if (!bIsSaveDraft) {
					//Save and proceed or submit request action validation
					for (let i = 0; i < requestDetailsFields.length; i++) {
						requestDetailsValue = processContext[requestDetailsFields[i]];
						if (requestDetailsValue && requestDetailsValue.trim() && requestDetailsValue !== "" && requestDetailsValue !== "undefined" &&
							requestDetailsValue !==
							"null") {																				
							oMCommon.setProperty("/" + requestDetailsFields[i] + "State", "None");
						} else {
							oThisController.errorExist = true;
							if (requestDetailsFields[i] === "supportTypeRISE") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_SUPPORT_TYPE_RISE");
							}
							if (requestDetailsFields[i] === "supportType") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_SUPPORT_TYPE");
							}
							if (requestDetailsFields[i] === "involvedParties") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_INVOLVED_PARTIES");
							}
							if (requestDetailsFields[i] === "typeOfSupport") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_TYPE_OF_SUPPORT");
							}
							if (requestDetailsFields[i] === "solutionsInScope") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_SOLUTIONS_IN_SCOPE");
							}
							if (requestDetailsFields[i] === "participantTypeDetails") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_PARTICIPANT_TYPE_DETAILS");
							}
							if (requestDetailsFields[i] === "preferredPresales") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_PREFERRED_PRESALES");
							}
							if (requestDetailsFields[i] === "meetingGoal") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_MEETING_GOAL_TEXT");
							}
							if (requestDetailsFields[i] === "language") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_LANGUAGE");
							}
							if (requestDetailsFields[i] === "meetingDate") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_MEETING_DATE");
							}
							if (requestDetailsFields[i] === "meetingLocation") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_MEETING_LOCATION");
							}
							if (requestDetailsFields[i] === "meetingTime") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_MEETING_TIME");
							}
							if (requestDetailsFields[i] === "participantType") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_PARTICIPANT_TYPE");
							}
							if (requestDetailsFields[i] === "requestArea" && !processContext.isResourceProfile) {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_REQUEST_AREA");
							}
							if (requestDetailsFields[i] === "involvedPartiesNames") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_INVOLVED_SAP_NAMES");
							}
							if (requestDetailsFields[i] === "comments") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_COMMENTS");
							}
							if (requestDetailsFields[i] === "meetingType") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_MEETING_TYPE");
							}
							if (requestDetailsFields[i] === "supp_Type_FBS") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION");
							}
							if (requestDetailsFields[i] === "est_Acv") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION");
							}
							if (requestDetailsFields[i] === "supp_Type_Pqa_Id") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION");
							}
							if (requestDetailsFields[i] === "opp_Origin_Id") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION");
							}
							if (requestDetailsFields[i] === "solution_Id") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION");
							}
							if (requestDetailsFields[i] === "contact_Prsn_Id") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION");
							}
							if (requestDetailsFields[i] === "contact_Prsn_Email") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION");
							}
							if (requestDetailsFields[i] === "oppclosing_Date") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION");
							}
							if (requestDetailsFields[i] === "contract_Start_Date") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION");
							}
							if (requestDetailsFields[i] === "contract_End_Date") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION");
							}
							if (requestDetailsFields[i] === "need_From_Fbs") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION");
							}
							// if (requestDetailsFields[i] === "c2c_Deal") {
							// 	oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION");
							// }
							if (requestDetailsFields[i] === "Opp_Number") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION");
							}
							if (requestDetailsFields[i] === "io_Number") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION");
							}
							if (requestDetailsFields[i] === "model_Id") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION");
							}
							if (requestDetailsFields[i] === "isp_Id") {
								oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION");
							}
							oMCommon.setProperty("/" + requestDetailsFields[i] + "State", "Error");
						}
					}
				}
				if (processContext.isMeetingPlanned && processContext.meetingGoal) {
					if (processContext.meetingGoal.length > 5000) {
						oThisController.errorExist = true;
						oMCommon.setProperty("/meetingGoalStateText", "FIELD_EXCEED_TEXT");
						oMCommon.setProperty("/meetingGoal", "Error");
					}
				}
				if (processContext.typeOfSupport) {
					if (processContext.typeOfSupport.length > 5000) {
						oThisController.errorExist = true;
						oMCommon.setProperty("/typeOfSupportStateText", "FIELD_EXCEED_TEXT");
						oMCommon.setProperty("/typeOfSupportState", "Error");
					}
				}
				if (processContext.isMeetingPlanned && processContext.participantTypeDetails && processContext.participantType) {
					if (processContext.participantTypeDetails.length > 5000) {
						oThisController.errorExist = true;
						oMCommon.setProperty("/participantTypeDetailsStateText", "FIELD_EXCEED_TEXT");
						oMCommon.setProperty("/participantTypeDetailsState", "Error");
					}
				}
				if (processContext.isMeetingPlanned && processContext.involvedPartiesNames) {
					if (processContext.involvedPartiesNames.length > 5000) {
						oThisController.errorExist = true;
						oMCommon.setProperty("/involvedPartiesNamesStateText", "FIELD_EXCEED_TEXT");
						oMCommon.setProperty("/involvedPartiesNames", "Error");
					}
				}
				if (processContext.comments) {
					if (processContext.comments.length > 5000) {
						oThisController.errorExist = true;
						oMCommon.setProperty("/commentsStateText", "FIELD_EXCEED_TEXT");
						oMCommon.setProperty("/commentsState", "Error");
					}
				}
				if (processContext.contact_Prsn_Email) {
					if (!oThisController.validateEmail(processContext.contact_Prsn_Email)) {
						oThisController.errorExist = true;
						oMCommon.setProperty("/contact_Prsn_EmailStateText", "INVALID_EMAIL");
						oMCommon.setProperty("/contact_Prsn_EmailState", "Error");
					}
				}
				
				if(bIsSaveDraft && !this.errorExist){
					//Save draft action validation
					this._onSaveDraft();
				}
			},
			onChangeLengthValidation: function (oEvent) {
				const oInput = oEvent.getSource();
				if (oEvent.getParameter("value") && oEvent.getParameter("value").length < 5000) {
					oInput.setProperty("valueState", "None");
				}
				if (oEvent.getParameter("value").length > 5000) {
					oInput.setProperty("valueStateText", this.i18nModel.getText("FIELD_EXCEED_TEXT"));
				}
				this._setUnsavedData();
			},
			/**
			 * Convenience method for all Input validation errors.
			 * @public
			 * @returns Validate all the required input fields.
			 */
			onNavtoNextRequestArea: function () {				
				let oNavContainer = this.getView().byId("idNavContainerMrq");
				let currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
				let iIndex = Number(currentPageId.slice(-1));
				let processContext = this.getView().getModel("multiReqModel").getData().subcontext[iIndex];
				let taskId = this.userTaskId;
				let navtoPageId = currentPageId.replace(/\idNavContainerMrq[^\s]*/g, "") + "idNavContainerMrq-" + (iIndex + 1).toString();
				//attachment urls
				//remove empty url object
				this._removeEmptyUrl(iIndex);
				this._validateInput(processContext, taskId, "Next", navtoPageId,false,iIndex);				
			},
			onNavtoPrevRequestArea: function () {
				let oNavContainer = this.getView().byId("idNavContainerMrq");
				let currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
				let iIndex = Number(currentPageId.slice(-1));
				const oContextData = this.getView().getModel("multiReqModel").getData().subcontext[iIndex];
				let navtoPageId = currentPageId.replace(/\idNavContainerMrq[^\s]*/g, "") + "idNavContainerMrq-" + (iIndex - 1).toString();
				this.updateSuppTypeValuesCA(iIndex - 1)
				this.navtoReqArea(navtoPageId, "prev");
				let processContext = this.getView().getModel("multiReqModel").getData().subcontext[iIndex];
				let taskId = this.userTaskId;
				
				this.getView().getModel("multiReqModel").refresh(true);
			// 	for (let i = 0; i < this.unSavedData.length; i++) {
			// 	if (this.unSavedData[i].iIndex === iIndex) {
			// 		this.unSavedData.splice(i, 1)
			// 	}
				// }

				if (this.getView().getModel("multiReqModel").getData().subcontext.length > 1 && this.unSavedData.length) {
				const that = this;
				const si18nDraftMsg1 = that.i18nModel.getText("draftPropmptMsg1");
				const si18nDraftMsg2 = that.i18nModel.getText("draftPropmptMsg2");
				const si18nDraftMsg3 = that.i18nModel.getText("draftPropmptMsg3");
				let sCurrentReq;
					if(oContextData.isResourceProfile){
						 sCurrentReq = oContextData.searchFieldsText ? oContextData.searchFieldsText :"";
					}else{
						sCurrentReq = oContextData.requestArea ? oContextData.requestArea :"";
					}
				// const sCurrentSearchField = oContextData.searchFieldsText ? oContextData.searchFieldsText :"";
				// const sCurrentReq = `${oContextData.requestArea} ${sCurrentSearchField}`
				let aMsgs = [];
				that.unSavedData.forEach(function(data){
					const sSearchFieldText = data.searchFieldsText ?  data.searchFieldsText:"";
					aMsgs.push(`${data.requestArea} ${sSearchFieldText}`)
				});
				let sDraftDynamicMsg =aMsgs.join(" , "); 
				MessageBox.show(
					`${si18nDraftMsg1} ${sCurrentReq}`, {
					icon: MessageBox.Icon.WARNING,
					title:"Warning",
					contentWidth:"600px",
					actions: [MessageBox.Action.OK],
					onClose: function (oAction) {
						if (oAction === MessageBox.Action.OK) {
							// that._onSaveDraft();
							that.unSavedData = [];

						} 
					}
				}
				);
			}else{
				this.unSavedData = [];
			}

			},
			onSubmitRequest: function () {
				let oNavContainer = this.getView().byId("idNavContainerMrq");
				let currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
				let iIndex = Number(currentPageId.slice(-1));
				let model = this.getView().getModel("multiReqModel");
				model.refresh(true);
				let processContext = model.getData().subcontext[iIndex];
				let taskId = this.userTaskId;

				//attachment urls
				this._removeEmptyUrl(0);

				// Call a local method to perform further action
				this._validateInput(
					processContext,
					taskId,
					"Submit Request",
					"Complete",
					false,
					0
				);
			},
			onCancelRequest: function () {
				let taskId = this.userTaskId;
				let model = this.getView().getModel("multiReqModel");
				model.refresh(true);
				let processContext = model.getData().subcontext[0];

				// Call a local method to perform further action
				this._triggerComplete(
					processContext,
					taskId,
					"Terminate"
				);
			},
			_validateInput: function (processContext, taskId, sDecision, navtoPageId, sFormAction,iIndex) {
				let oThisController = this;
				this.getView().setBusy(true);
				this._validateFormFields(processContext);
				//attachment urls
				const oAttchementUrls = this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls;
				if (oAttchementUrls) {
					const aUrlValidation = oAttchementUrls.filter(item => item.urlValueState === "Error");
					if (aUrlValidation.length) {
						this.errorExist = true;
					}
				}
				if (this.errorExist) {
					let sGenericErrorText = oThisController.i18nModel.getText("FIELD_VALIDATION_ERROR_GENERIC");
					MessageToast.show(sGenericErrorText)
					oThisController.getView().setBusy(false);
					return;
				} else {
					if (sFormAction === "Complete") {
						oThisController._triggerComplete(processContext, taskId, sDecision);
					} else {
						if (sDecision === "Submit Request") {
							oThisController._triggerComplete(processContext, taskId, sDecision);
						} else {
							oThisController.onSaveDraft();
							this.updateSuppTypeValuesCA(iIndex+1)
							oThisController.navtoReqArea(navtoPageId, "next");
						}

						oThisController.getView().setBusy(false);
					}
				}
			},
			_configFormValidation: function (processContext) {
				let oFormModelData = this.getView().getModel("formConfigModel").getData();
				let aMandtInputs = [];
				if (oFormModelData.idrequestdetails) {
					let oRequestDetailFields = oFormModelData.idrequestdetails.Fields;
					let oRequestDetailFieldValues = Object.values(oRequestDetailFields);
					oRequestDetailFieldValues.forEach(function (reqDetField) {
						switch (reqDetField.ID) {
							case "idcustad_resorc":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {
									aMandtInputs.push("preferredPresales")
								}
								break;
							case "idcustadd":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {
									if (!processContext.isRISE) {
										aMandtInputs.push("typeOfSupport")
									}
								}
								break;
							case "idgoalmeet":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {
									if (processContext.isMeetingPlanned) {
										aMandtInputs.push("meetingGoal");
									}
								}
								break;
							case "idlang":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {
									if (processContext.isMeetingPlanned) {
										aMandtInputs.push("language");
									}
								}
								break;
							case "idmeet_date":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {
									if (processContext.isMeetingPlanned) {
										aMandtInputs.push("meetingDate");
									}
								}
								break;
							case "idmeet_loc":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {
									if (processContext.isMeetingPlanned) {
										aMandtInputs.push("meetingLocation");
									}
								}
								break;
							case "idmeet_time":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {
									if (processContext.isMeetingPlanned) {
										aMandtInputs.push("meetingTime");
									}
								}
								break;
							case "idmeet_type":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {
									if (processContext.isMeetingPlanned) {
										aMandtInputs.push("meetingType");
									}
								}
								break;
							case "idparticpnt_det":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {
									if (processContext.isMeetingPlanned) {
										if (processContext.isParticipantTypeSelected) {
											aMandtInputs.push("participantTypeDetails");
										}
									}

								}
								break;
							case "idparticpnt_type":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {
									if (processContext.isMeetingPlanned) {
										aMandtInputs.push("participantType");
									}
								}
								break;
							case "idreqarea":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X" && !processContext.isResourceProfile) {
									aMandtInputs.push("requestArea")
								}
								break;
							case "idsap_party":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {
									aMandtInputs.push("involvedPartiesNames")
								}
								break;
							case "idsap_parties":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {
									if (processContext.isMeetingPlanned) {
										aMandtInputs.push("involvedParties");
									}
								}
								break;
							case "idsolmod":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {
									if (processContext.isSolutionRelated) {
										aMandtInputs.push("solutionsInScope")
									}
								}
								break;
							case "idsupp_type":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {
									// if (processContext.isMeetingPlanned) {
										aMandtInputs.push("supportType")
									// }
								}
								break;
							case "idrise_dealphase":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {
									if (processContext.isRISE) {
										aMandtInputs.push("supportTypeRISE")
									}
								}
								break;
							case "idsupp_type_fbs":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {									
										aMandtInputs.push("supp_Type_FBS")									
								}
								break;
							case "est_acv":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {									
										aMandtInputs.push("est_Acv")									
								}
								break;
							case "idsupp_type_PQA":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {									
										aMandtInputs.push("supp_Type_Pqa_Id")									
								}
								break;
							case "opp_origin":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {									
										aMandtInputs.push("opp_Origin_Id")									
								}
								break;
							case "main_sol":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {									
										aMandtInputs.push("solution_Id")									
								}
								break;
							case "contact_it_id":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {									
										aMandtInputs.push("contact_Prsn_Id")									
								}
								break;
							case "contact_it_email":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {									
										aMandtInputs.push("contact_Prsn_Email")									
								}
								break;
							case "opp_closing_date":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {									
										aMandtInputs.push("oppclosing_Date")									
								}
								break;
							case "contract_start_date":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {									
										aMandtInputs.push("contract_Start_Date")									
								}
								break;
							case "contract_end_date":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {									
										aMandtInputs.push("contract_End_Date")									
								}
								break;
							case "need_from_fbs":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {									
										aMandtInputs.push("need_From_Fbs")									
								}
								break;
							// case "is_c2c":
							// 	if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {									
							// 			aMandtInputs.push("c2c_Deal")									
							// 	}
							// 	break;
							case "opp_number":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {									
										aMandtInputs.push("Opp_Number")									
								}
								break;
							case "initial_order":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {									
										aMandtInputs.push("io_Number")									
								}
								break;
							case "business_model":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {									
										aMandtInputs.push("model_Id")									
								}
								break;
							case "infra_structure_provider":
								if (reqDetField.Visibility === "X" && reqDetField.mandatory === "X") {									
										aMandtInputs.push("isp_Id")									
								}
								break;
						}

					})

				}
				if (oFormModelData.idcomment) {
					if (oFormModelData.idcomment.Visibility && oFormModelData.mandatory === "X") {
						aMandtInputs.push("comments")
					}
				}
				return aMandtInputs;
			},
			onNavigationFinished: function () {
				this.getView().getModel("formValConfigModel").refresh(true);
			},
			_formRequestDetails: function (processContext) {
				var sEngagementType = this.getView().getModel("multiReqModel").getData().subcontext[0].EngagementType
				if (sEngagementType == '0002') {
					var suppTypeDataText = processContext.supp_Type_FBS ? this.getView().getModel("formValConfigModel").getData()["idsupp_type_fbs"].filter(obj => obj.ID == processContext.supp_Type_FBS)[0].Value : ""
					var suppTypePQADataText = processContext.supp_Type_Pqa_Id ? this.getView().getModel("formValConfigModel").getData()["idsupp_type_PQA"].filter(obj => obj.ID == processContext.supp_Type_Pqa_Id)[0].Value : ""
					var oppOriginDataText = processContext.opp_Origin_Id ? this.getView().getModel("formValConfigModel").getData()["opp_origin"].filter(obj => obj.ID == processContext.opp_Origin_Id)[0].Value : ""
					var mainSolDataText = processContext.solution_Id ? this.getView().getModel("formValConfigModel").getData()["main_sol"].filter(obj => obj.ID == processContext.solution_Id)[0].Value : ""
					var estACVDataText = processContext.est_Acv ? this.getView().getModel("formValConfigModel").getData()["est_acv"].filter(obj => obj.ID == processContext.est_Acv)[0].Value : ""
					var businessModelDataText = processContext.model_Id ? this.getView().getModel("formValConfigModel").getData()["business_model"].filter(obj => obj.ID == processContext.model_Id)[0].Value : ""
					var ispDataText = processContext.isp_Id ? this.getView().getModel("formValConfigModel").getData()["infra_structure_provider"].filter(obj => obj.ID == processContext.isp_Id)[0].Value : ""
					var oFormValues = {
						// "EngagementType": sEngagementType,
						"need_From_Fbs": processContext.need_From_Fbs ? processContext.need_From_Fbs : "",
						// "supportTypeKey": processContext.supportTypeKey ? processContext.supportTypeKey : "",
						"supp_Type_FBS": processContext.supp_Type_FBS ? processContext.supp_Type_FBS : "",
						"supportTypeText": suppTypeDataText,
						"supp_Type_Pqa_Id": processContext.supp_Type_Pqa_Id ? processContext.supp_Type_Pqa_Id : "",
						"suppTypePQAText": suppTypePQADataText,
						"c2c_Deal": processContext.c2c_Deal,
						"opp_Origin_Id": processContext.opp_Origin_Id ? processContext.opp_Origin_Id : "",
						"oppOriginText": oppOriginDataText,
						"Opp_Number": processContext.Opp_Number ? processContext.Opp_Number : "",
						"solution_Id": processContext.solution_Id ? processContext.solution_Id : "",
						"mainSolutionText": mainSolDataText,
						"est_Acv": processContext.est_Acv ? processContext.est_Acv : "",
						"estAcvText": estACVDataText,
						"model_Id": processContext.model_Id ? processContext.model_Id : "",
						"businessModelText": businessModelDataText,
						"isp_Id": processContext.isp_Id ? processContext.isp_Id : "",
						"ispIdText": ispDataText,
						"io_Number": processContext.io_Number ? processContext.io_Number : "",
						"contact_Prsn_Id": processContext.contact_Prsn_Id ? processContext.contact_Prsn_Id : "",
						"contact_Prsn_Email": processContext.contact_Prsn_Email ? processContext.contact_Prsn_Email : "",
						"oppclosing_Date": processContext.oppclosing_Date ? processContext.oppclosing_Date : null,
						"contract_Start_Date": processContext.contract_Start_Date ? processContext.contract_Start_Date : null,
						"contract_End_Date": processContext.contract_End_Date ? processContext.contract_End_Date : null,
						"RequestType": processContext.RequestType,
						"isAttachment": processContext.isAttachment ? true : false,
						"attachmentUrls": processContext.attachmentUrls ? processContext.attachmentUrls : [],
						"comments": processContext.comments ? processContext.comments : "",
					}

				} else {
					var oFormValues = {
						// "EngagementType": sEngagementType,
						"comments": processContext.comments ? processContext.comments : "",
						"meetingGoal": processContext.meetingGoal ? processContext.meetingGoal : "",
						"supportType": processContext.supportType ? processContext.supportType : "",
						"supportTypeKey": processContext.supportTypeKey ? processContext.supportTypeKey : "",
						"meetingType": processContext.meetingType ? processContext.meetingType : "",
						"meetingTypeKey": processContext.meetingTypeKey ? processContext.meetingTypeKey : "",
						"meetingLocation": processContext.meetingLocation ? processContext.meetingLocation : "",
						"meetingDate": processContext.meetingDate ? processContext.meetingDate : "",
						"meetingTime": processContext.meetingTime ? processContext.meetingTime : "",
						"language": processContext.language ? processContext.language : "",
						"languageKey": processContext.languageKey ? processContext.languageKey : "",
						"participantType": processContext.participantType ? processContext.participantType : "",
						"participantTypeKey": processContext.participantTypeKey ? processContext.participantTypeKey : "",
						"participantTypeDetails": processContext.participantTypeDetails ? processContext.participantTypeDetails : "",
						"involvedParties": processContext.involvedParties ? processContext.involvedParties : "",
						"involvedPartiesKey": processContext.involvedPartiesKey ? processContext.involvedPartiesKey : "",
						"involvedPartiesKeys": processContext.involvedPartiesKeys ? processContext.involvedPartiesKeys : [],
						"involvedPartiesNames": processContext.involvedPartiesNames ? processContext.involvedPartiesNames : "",
						"preferredPresales": processContext.preferredPresales ? processContext.preferredPresales : "",
						"isRISE": processContext.isRISE ? true : false,
						"supportTypeRISE": processContext.supportTypeRISE ? processContext.supportTypeRISE : "",
						"isMeetingPlanned": processContext.isMeetingPlanned ? true : false,
						"isMeetingPlannedText": processContext.isMeetingPlannedText ? processContext.isMeetingPlannedText : "No",
						"typeOfSupport": processContext.typeOfSupport ? processContext.typeOfSupport : "",
						"solutionsInScope": processContext.solutionsInScope ? processContext.solutionsInScope : "",
						"isSolutionRelated": processContext.isSolutionRelated ? true : false,
						"isParticipantTypeSelected": processContext.isParticipantTypeSelected ? true : false,
						"RequestType": processContext.RequestType,
						"isAttachment": processContext.isAttachment ? true : false,
						"attachmentUrls": processContext.attachmentUrls ? processContext.attachmentUrls : [],
					};
				}
				if (processContext.RequestType === "Account") {
					oFormValues.PE_Name = processContext.PE_Name;
					oFormValues.IndustryName = processContext.IndustryName;
					oFormValues.AccountOwner = processContext.AccountOwner;
					oFormValues.AccountOwnerUserId = processContext.AccountOwnerUserId;
					oFormValues.AccountOwnerEmail = processContext.AccountOwnerEmail;
					oFormValues.accountUrl = processContext.accountUrl
				} else if (processContext.RequestType === "Opportunity") {
					oFormValues.Opp_Desc = processContext.Opp_Desc;
				}
				return oFormValues;
			},
			_validateParentInstanceID: function (oThisController, sInstanceID, aReqArea) {
				let workflowBaseurl = this._getWfServiceRuntimeBaseURLRoleBased(this);
				sap.ui.core.BusyIndicator.show();
				jQuery.ajax({
					async: true,
					contentType: "application/json",
					url: `${workflowBaseurl}/wf/V_WfInstance_Inbox?$filter=ParentInstanceID eq ('${sInstanceID}')`,
					type: "GET",
					success: function (oResponse) {
						let oData = oResponse.value;
						oData.forEach(function (data) {
							if (data.currentStateID !== "WMNAPP") {
								oThisController.isRequestUpdated = false;
							}
						})

						const aCurrentState = oData.filter(function (item) {
							return item.currentStateID === "WMNAPP"
						});
						if (aCurrentState.length !== aReqArea.length) {
							oThisController._validateParentInstanceID(oThisController, sInstanceID, aReqArea);
						} else {
							oThisController._fetchAPICalls();
						}
					}.bind(oThisController),
					error: function (oError) {
						sap.ui.core.BusyIndicator.hide();
						if (oError.responseText) {
							sap.ui.core.BusyIndicator.hide();
							MessageBox.error(oError.responseText, {});
						} else {
							MessageBox.error("Something went wrong", {});
						}
					}
				});
			},
			_getWfServiceRuntimeBaseURLRoleBased: function (self) {
				return self._getRuntimeBaseURL() + "/adminresources";
			},
			  /**
			 * This method is called when the confirm button is click by the end user
			 *
			 * @param {object} processContext - Payload data for submit request
			 * @param {string} taskId - indicates workflow instance ID
			 * @param {string} currentDecision - Indicates the decision of workflow trigger (Submit or Terminate)
			 * 
			 */
			_triggerComplete: function (processContext, taskId, currentDecision) {
				this.getView().setBusy(true);
				sap.ui.core.BusyIndicator.show();
				let oThisController = this;
				if (processContext.RequestType === "Opportunity") {
					const oOppId = processContext.opportunityId;
					setTimeout(function() {
					//call opportunity service
					models.getMyOpportunitiesIO(oThisController, oOppId,processContext,taskId,currentDecision);
				}, 1000, this);
				}else{
					//Request type 'Account'
					//Call workflow service
					this._fnTriggerFinalSubmitCall(processContext,taskId,currentDecision,this)
				}
			},
			  /**
			 * Worfkflow service call
			 *
			 * @param {object} processContext - Payload data for submit request
			 * @param {string} taskId - indicates workflow instance ID
			 * @param {string} currentDecision - Indicates the decision of workflow trigger (Submit or Terminate)
			 * @param {object} self - controller scope
			 */
			_fnTriggerFinalSubmitCall:function(processContext, taskId, currentDecision,self){
				let oThisController = self;
				oThisController.getView().setBusy(true);
				sap.ui.core.BusyIndicator.show();
				let workflowBaseurl = self._getWorkflowRuntimeBaseURL();
				let oModelData = oThisController.getView().getModel("multiReqModel").getData().subcontext;
				let oRequestDetails;
				
				setTimeout(function() {
					$.ajax({
						// Call workflow API to get the xsrf token
						url: workflowBaseurl + "rest/v1/xsrf-token",
						method: "GET",
						async:false,
						headers: {
							"X-CSRF-Token": "Fetch"
						},
						success: function (result, xhr, data) {
	
							// After retrieving the xsrf token successfully
							let token = data.getResponseHeader("X-CSRF-Token");
	
							// form the context that will be updated
							let oPayloadContext;
							let aMultipleRequestAreaContext = [];
							let decisionID;
									if (currentDecision === "Submit Request") {
										decisionID = oThisController.getView().getModel("formActionsConfigModel").getData().idsubmit[0].ID;
									} else if (currentDecision === "Terminate") {
										decisionID = oThisController.getView().getModel("formActionsConfigModel").getData().idterminate[0].ID;
									}
							var sEngType=oThisController.getView().getModel("multiReqModel").getData().subcontext[0].EngagementType
							if (!oModelData[0].isRework) {
								for (let i = 0; i < oModelData.length; i++) {
									let oParentContext = {};
									processContext = oModelData[i];
									oRequestDetails = oThisController._formRequestDetails(processContext);
									//add payload for attachmentUrl
									if(processContext.attachmentUrls){
										if(!processContext.attachmentUrls[0] || !processContext.attachmentUrls[0].url){
											processContext.attachmentUrls = [];
										}
										
									}
									oParentContext.systemId = processContext.systemId;
									oParentContext.accountName = processContext.accountName;
									oParentContext.accountId = processContext.accountId;
									oParentContext.AccountOwner = processContext.AccountOwner;
									oParentContext.RequestType = processContext.RequestType;
									oParentContext.opportunityId = processContext.opportunityId;
									oParentContext.extSystemsUrls = processContext.extSystemsUrls;
									oParentContext.requesterDetails = processContext.requesterDetails;
									oParentContext.aResourceProfileApprovers = processContext.aResourceProfileApprovers;
									oParentContext.isResourceProfile = processContext.isResourceProfile;
									oParentContext.isRoleAreaSelection = processContext.isRoleAreaSelection;
									oParentContext.selectedProfitCenter = processContext.selectedProfitCenter;
									oParentContext.iacValue = processContext.iacValue;
									oParentContext.OrgID = processContext.OrgID;
									oParentContext.oppOrgId = processContext.oppOrgId;
									const hasParentOrgID = 'ParentOrgID' in processContext;
									if (hasParentOrgID) { oParentContext.ParentOrgID = processContext.ParentOrgID; }
									oParentContext.OrgType = processContext.OrgType;
									oParentContext.SalesOrgID = processContext.SalesOrgID;
									oParentContext.GUID = processContext.GUID;
									oParentContext.requestArea = processContext.requestArea;
									oParentContext.uploadUrl = oParentContext.uploadUrl;
									oParentContext.requestAreaPath = processContext.requestAreaPath;
									oParentContext.requestDetails = oRequestDetails;
									oParentContext.requestDetails.attachmentUrls = processContext.attachmentUrls;
									oParentContext.searchFieldsText = processContext.searchFieldsText;
									oParentContext.comments = processContext.comments;
									oParentContext.decision = "Submit Request";
									oParentContext.decision_ID = decisionID;
									// if (currentDecision === "Submit Request") {
									// 	oParentContext.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idsubmit[0].ID;
									// } else if (currentDecision === "Terminate") {
									// 	oParentContext.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idterminate[0].ID;
									// }
									oParentContext.submitPageUserTaskID = oThisController.userTaskId;
									// oParentContext.isLegacy = true
									oParentContext.workflowFileUploadId = processContext.workflowFileUploadId;
	
									oParentContext.FirstIterationRA = true;
									if (processContext.RequestType === "Account") {
										oParentContext.PE_Name = processContext.PE_Name;
										oParentContext.IndustryName = processContext.IndustryName;
										oParentContext.AccountOwner = processContext.AccountOwner;
										oParentContext.AccountOwnerUserId = processContext.AccountOwnerUserId;
										oParentContext.AccountOwnerEmail = processContext.AccountOwnerEmail;
										oParentContext.accountUrl = processContext.accountUrl
										//set account owner details
										oParentContext.accOwnerDetails = processContext.accOwnerDetails ? processContext.accOwnerDetails:{
											id:"",
											email:"",
											fullName:""
										};
										//set opportunity owner details
										oParentContext.oppOwnerDetails = {
											id:"",
											email:"",
											fullName:""
										};
									} else if (processContext.RequestType === "Opportunity") {
										oParentContext.Opp_Desc = processContext.Opp_Desc;
										oParentContext.INTERNAL_ORDER1 = oThisController.INTERNAL_ORDER1;
										oParentContext.INTERNAL_ORDER2 = oThisController.INTERNAL_ORDER2;
										//set account owner details
										oParentContext.accOwnerDetails = processContext.accOwnerDetails && Object.keys(processContext.accOwnerDetails).length > 0 ? processContext.accOwnerDetails:{
											id:"",
											email:"",
											fullName:""
										};
										//set opportunity owner details
										oParentContext.oppOwnerDetails = processContext.oppOwnerDetails && Object.keys(processContext.oppOwnerDetails).length > 0 ? processContext.oppOwnerDetails:{
											id:"",
											email:"",
											fullName:""
										};
									}
									//update orgid,orgtype and requesttype for older task
									if (typeof (processContext["SalesOrgID"]) === "string") {
										oParentContext["OrgID"] = processContext["SalesOrgID"];
										oParentContext["OrgType"] = "SORG";
										oParentContext["RequestType"] = "Opportunity"
										//update areapath call
										let OrgID_Num = oThisController._getOrgIDnumber(oParentContext["OrgID"], oParentContext["OrgType"]);
										let aAreaPathCallRequests = [{
											id: "1",
											method: "GET",
											url: "/Resources(GUID=" + processContext.GUID + ",IsActiveEntity=true)",
											headers: { "content-type": "application/json;IEEE754Compatible=true" }
										},
										// To fetch Email template details
										{
											id: "2",
											method: "GET",
											url: "/Email_Body?$filter=orgID eq '" + OrgID_Num + "' and orgType eq '" + oParentContext["OrgType"] + "'",
											headers: { "content-type": "application/json;IEEE754Compatible=true" }
										},
										// End of code for Melody Resource Request Tool Sprint 1
										// to fetch Email Delegates Details
										{
											id: "3",
											method: "GET",
											url: "/Email_Delegates?$filter=orgID eq '" + oParentContext["OrgID"] + "'",
											headers: { "content-type": "application/json;IEEE754Compatible=true" }
										},
										// to check routing flags 
										{
											id: "4",
											method: "GET",
											url: "/WF_Routing?$filter=eng_Type_ID eq '"+sEngType+"' and orgID eq '" + oParentContext["OrgID"] + "'",
											headers: { "content-type": "application/json;IEEE754Compatible=true" }
										}];
										oParentContext.areaPathCall = {
											"Request": {
												"requests": aAreaPathCallRequests
											}
										};
									};
									aMultipleRequestAreaContext.push(oParentContext)
								}
								oPayloadContext = {
									"context": {
										"ReqFormDelDraftUrl":oThisController.requestDraftUrls ? oThisController.requestDraftUrls:[],
										"CountMultiReqArea": 0,
										"aReqAreas": aMultipleRequestAreaContext,
										"decision": currentDecision,
										"decision_ID" : decisionID
									},
									"status": "COMPLETED"
								};
	
							} else {
								processContext = oModelData[0];
								if(processContext.attachmentUrls){
									if(!processContext.attachmentUrls[0] || (processContext.attachmentUrls.length && !processContext.attachmentUrls[0]["url"])){
										processContext.attachmentUrls = [];
									}
									
								}
								processContext.submitPageUserTaskID = oThisController.userTaskId;
								oRequestDetails = oThisController._formRequestDetails(processContext);
								oRequestDetails.attachmentUrls = processContext.attachmentUrls;
								oPayloadContext = {
									"context": {
										"ReqFormDelDraftUrl":oThisController.requestDraftUrls ? oThisController.requestDraftUrls:[],
										"workflowFileUploadId": processContext.workflowFileUploadId,
										"accOwnerDetails": processContext.accOwnerDetails ? processContext.accOwnerDetails:{
											id:"",
											email:"",
											fullName:""
										},
								        "oppOwnerDetails": processContext.RequestType === "Opportunity"  &&  processContext.oppOwnerDetails ? processContext.oppOwnerDetails:{
											id:"",
											email:"",
											fullName:""
										},
										"requestDetails": oRequestDetails,
										"comments": processContext.comments ? processContext.comments : "",
										//attachment urls
										"attachmentUrls": processContext.attachmentUrls,
										"decision": currentDecision,
										"submitPageUserTaskID": oThisController.userTaskId,
										"decision_ID": oThisController.getView().getModel("formActionsConfigModel").getData().idsubmit[0].ID
									},
									"status": "COMPLETED"
								};
								if (processContext.RequestType === "Opportunity") {
									oPayloadContext.context.Opp_Desc = processContext.Opp_Desc;
									oPayloadContext.context.INTERNAL_ORDER1 = oThisController.INTERNAL_ORDER1;
									oPayloadContext.context.INTERNAL_ORDER2 = oThisController.INTERNAL_ORDER2;
								}
								//update orgid,orgtype and requesttype for older task
								if (typeof (processContext["SalesOrgID"]) === "string") {
									oPayloadContext.context.OrgID = processContext["SalesOrgID"];
									oPayloadContext.context.OrgType = "SORG";
									oPayloadContext.context.RequestType = "Opportunity";
	
									//update areapath call
									let OrgID_Num = oThisController._getOrgIDnumber(oPayloadContext.context.OrgID, oPayloadContext.context.OrgType);
									let aAreaPathCallRequests = [{
										id: "1",
										method: "GET",
										url: "/Resources(GUID=" + processContext.GUID + ",IsActiveEntity=true)",
										headers: { "content-type": "application/json;IEEE754Compatible=true" }
									},
									// To fetch Email template details
									{
										id: "2",
										method: "GET",
										url: "/Email_Body?$filter=orgID eq '" + OrgID_Num + "' and orgType eq '" + oPayloadContext.context.OrgType + "'",
										headers: { "content-type": "application/json;IEEE754Compatible=true" }
									},
									// End of code for Melody Resource Request Tool Sprint 1
									// to fetch Email Delegates Details
									{
										id: "3",
										method: "GET",
										url: "/Email_Delegates?$filter=orgID eq '" + oPayloadContext.context.OrgID + "'",
										headers: { "content-type": "application/json;IEEE754Compatible=true" }
									},
									// to check routing flags 
									{
										id: "4",
										method: "GET",
										url: "/WF_Routing?$filter=eng_Type_ID eq '"+sEngType+"' and orgID eq '" + oPayloadContext.context.OrgID + "'",
										headers: { "content-type": "application/json;IEEE754Compatible=true" }
									}];
									oPayloadContext.context.areaPathCall.Request.requests = aAreaPathCallRequests;
									oPayloadContext.context.areaPathCall = {
										"Request": {
											"requests": aAreaPathCallRequests
										}
									};
								}
	
							}
							 //update refrence id for older request
							 if (oThisController.getView().getModel("multiReqModel").getData().subcontext[0].isRework && typeof oThisController.getView().getModel("multiReqModel").getData().subcontext[0].RequestID !== "object") {
								if( oThisController.getView().getModel("multiReqModel").getProperty("/subcontext/0/updatedRefId")){
									oPayloadContext.context.RequestID = {
										"value": oThisController.getView().getModel("multiReqModel").getProperty("/subcontext/0/updatedRefId")
									}
								}
							}
							//old request befor substitute functionality
							if(oModelData[0].RequestType=== "Opportunity" && !oModelData[0]["NewOppDetails"]){
								oPayloadContext.context.NewOppDetails = oThisController.getView().getModel("multiReqModel").getProperty("/NewOppDetails");
							}
							if(oModelData[0].RequestType !== "Opportunity" && !oModelData[0]["NewOppDetails"]){
								oPayloadContext.context.NewOppDetails = {
									STATUS:"",
									CURR_PHASE: "",
									STATUS_DESC: "",
									CURR_PHASE_DESC: "",
									CLOSE_DATE:""
								};
							}
							oPayloadContext.context.EngagementType=sEngType
							$.ajax({
								// Call workflow API to complete the task
								url: workflowBaseurl + "rest/v1/task-instances/" + oThisController.userTaskId,
								method: "PATCH",
								async:false,
								contentType: "application/json",
								// pass the updated context to the API
								data: JSON.stringify(oPayloadContext),
								headers: {
									// pass the xsrf token retrieved earlier
									"X-CSRF-Token": token
								},
								// refreshTask needs to be called on successful completion
								success: function (result, xhr, data) {
									oThisController.getView().getModel("multiReqModel").setData([]);
									// if (currentDecision === "Submit Request") {
									appView.byId("idSubmitFormPage").setVisible(false);
									sap.ui.core.BusyIndicator.hide();
									if (currentDecision === "Terminate") {
										MessageToast.show(oThisController.i18nModel.getText("requestCancelled"));
									} else {
										MessageToast.show(oThisController.i18nModel.getText("requestSubmitted"));
									}
	
									if(oThisController.getOwnerComponent().getModel("appConstants").getProperty("/isReqView")){
										oThisController.navToReqView();
									}else{
										oThisController.getOwnerComponent().getModel("appConstants").setProperty("/isAfterWfAction",true);
										setTimeout(function () {
											CommonJS._refreshTask(oThisController);
										}, 1000)
									}
								},
								error: function (err) {
									oThisController.getView().setBusy(false);
									MessageToast.show(oThisController.i18nModel.getText("WORKFLOW_ACCESS_TOKEN_ERROR "));
								}
	
							});
						},
						error: function (err) {
							oThisController.getView().setBusy(false);
							MessageToast.show(oThisController.i18nModel.getText("WORKFLOW_SERVICE_ERROR"));
						}
					});
					
			 }, 1000, this);

			},

			// Request Inbox to refresh the control once the task is completed
			_refreshTask: function () {
				let taskId = this.getComponentData().startupParameters.taskModel.getData().InstanceID;
				this.getComponentData().startupParameters.inboxAPI.updateTask("NA", taskId);
				console.log("task is refreshed");
			},

			onDateRangeChange: function (oEvent) {
				let sFrom = oEvent.getParameter("from"),
					sTo = oEvent.getParameter("to"),
					bValid = oEvent.getParameter("valid"),
					oEventSource = oEvent.getSource();

				if (bValid) {
					oEventSource.setValueState(ValueState.None);
				} else {
					oEventSource.setValueState(ValueState.Error);
				}
				this._setUnsavedData();
			},

			onTimeChange: function (oEvent) {
				let oTP = oEvent.getSource(),
					bValid = oEvent.getParameter("valid");

				if (bValid) {
					oTP.setValueState(ValueState.None);
				} else {
					oTP.setValueState(ValueState.Error);
				}
			},
			onSelectTab: function () {
				let oNavContainer = this.getView().byId("idNavContainerMrq");
				let currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;

				let sKey = this.getView().byId(currentPageId).getBindingContext("multiReqModel").getProperty("requestArea");
				this.getView().byId("iconTabHeader").setSelectedKey(sKey);

			},

			onSelectChange: function (oEvent) {

				let oModel = this.getParentModel();
				let sSelectedItemText = oEvent.getSource().getSelectedItem().getText();
				let oBindingContext = oEvent.getSource().getBindingContext("multiReqModel");
				let oContextData = oBindingContext.getObject();
				let sSelectedItemKey = oEvent.getSource().getSelectedItem().getKey();
				let oInput = oEvent.getSource();
				let sId = oInput.getId();

				if (sId.includes("MeetingTypeSelectMrq") === true) {
					oContextData["meetingType"] = sSelectedItemText;
					oContextData["meetingTypeKey"] = sSelectedItemKey;
				}

				if (sSelectedItemText.length > 0) {
					oInput.setProperty("valueState", "None");
				}
				this._setUnsavedData();
			},

			onSwitchStateChange: function (evt, that, bInitialLoad) {
				var that = evt ? this : that;
				let oView = that.getView();
				let omrqModelData;
				let oNavContainer = oView.byId("idNavContainerMrq")
				if (!oNavContainer._pageStack) {
					let currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
					let iIndex = Number(currentPageId.slice(-1));
					omrqModelData = that.getView().getModel("multiReqModel").getData().subcontext[iIndex];
				} else {
					omrqModelData = that.getView().getModel("multiReqModel").getData().subcontext[0];
				}
				let isMeetingPlanned = omrqModelData.isMeetingPlanned;

				if (isMeetingPlanned) {
					omrqModelData.isMeetingPlannedText = that.i18nModel.getText("YES");
				} else {
					omrqModelData.isMeetingPlannedText = that.i18nModel.getText("NO");
				}
				if (evt) {
					this._setUnsavedData();
				}
			},

			onMultiComboBoxChange: function (oEvent) {
				let aSelectedItems = oEvent.getParameter("selectedItems");
				let sSelectedItemsTexts = "";
				let sSelectedItemsKeys = "";

				if (aSelectedItems.length > 0) {
					sSelectedItemsTexts = aSelectedItems[0].getText();
					sSelectedItemsKeys = aSelectedItems[0].getKey();
				}
				for (let i = 1; i < aSelectedItems.length; i++) {
					sSelectedItemsTexts += "; " + aSelectedItems[i].getText();
					sSelectedItemsKeys += "; " + aSelectedItems[i].getKey();
				}

				let sId = oEvent.getSource().getId();

				let oNavContainer = this.getView().byId("idNavContainerMrq");
				let currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
				var iIndex = Number(currentPageId.slice(-1));
				var oModelData;
					 oModelData = this.getView().getModel("multiReqModel").getData().subcontext
				if (sId.includes("ParticipantTypeSelectMrq")) {
					oModelData[iIndex].participantType = sSelectedItemsTexts;
					oModelData[iIndex].participantTypeKey = sSelectedItemsKeys;
					oModelData[iIndex].isParticipantTypeSelected = aSelectedItems.length > 0;
				} else if (sId.includes("InvolvedPartiesSelectMrq")) {
					oModelData[iIndex].involvedParties = sSelectedItemsTexts;
					oModelData[iIndex].involvedPartiesKey = sSelectedItemsKeys;
					let aInvolvedPartiesKeys = [];
					for (let j = 0; j < aSelectedItems.length; j++) {
						aInvolvedPartiesKeys.push(aSelectedItems[j].getKey());
					}
					oModelData[iIndex].involvedPartiesKeys = aInvolvedPartiesKeys;
					if (!aInvolvedPartiesKeys.includes("None")) {
						oModelData[iIndex].namesOfPartiesVisible = true;
					} else {
						oModelData[iIndex].namesOfPartiesVisible = false;
					}
				} else if (sId.includes("LanguageSelectMrq")) {
					oModelData[iIndex].language = sSelectedItemsTexts;
					oModelData[iIndex].languageKey = sSelectedItemsKeys;
				} else if (sId.includes("SupportTypeSelectRISEMrq")) {
					oModelData[iIndex].supportTypeRISE = sSelectedItemsTexts;
					oModelData[iIndex].supportTypeRISEKey = sSelectedItemsKeys;
				} else if (sId.includes("SupportTypesSelectMrq")) {
					oModelData[iIndex].supportType = sSelectedItemsTexts;
					oModelData[iIndex].supportTypeKey = sSelectedItemsKeys;
					let aSupportTypeKeys = [];
					for (let j = 0; j < aSelectedItems.length; j++) {
						aSupportTypeKeys.push(aSelectedItems[j].getKey());
					}
					if (aSupportTypeKeys.includes("9")) { // Others
						MessageToast.show(this.i18nModel.getText("SUPPORT_TYPE_OTHERS_INFO"));
					}
				}

				if (sSelectedItemsTexts.length > 0) {
					oEvent.getSource().setProperty("valueState", "None");
				}
				let oBindingContext = oEvent.getSource().getBindingContext("multiReqModel");
				let sBindingContextPath = oBindingContext.getPath();
				let oContextData = oBindingContext.getObject();
				var iIndex = Number(sBindingContextPath.slice(-1));
				this.getView().getModel("multiReqModel").refresh(true);
				var oModelData = this.getView().getModel("multiReqModel").getData().subcontext[iIndex];
				if (aSelectedItems.length > 1) {
					this._setPrevioslySelectedValues(oContextData, oContextData, true);
				}
				this._setUnsavedData();
			},
			onChange: function (oEvent) {
				let oInput = oEvent.getSource();
				if (oEvent.getParameter("value")) {
					oInput.setProperty("valueState", "None");
				}
				this._setUnsavedData();
			},
			_setUnsavedData:function(){
				const oNavContainer = this.getView().byId("idNavContainerMrq");
				const currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
				const iIndex = Number(currentPageId.slice(-1));
				const oContextData = this.getView().getModel("multiReqModel").getData().subcontext[iIndex];
				const isUnsavedData = this.unSavedData.filter((data) => data.iIndex === iIndex);
				if (!isUnsavedData.length) {
					this.unSavedData.push({
						iIndex: iIndex,
						searchFieldsText: oContextData.searchFieldsText ? oContextData.searchFieldsText : "",
						requestArea: oContextData.requestArea
					})
				}

			},

			/*
			 * DOCUMENT SERVICE INTERACTIONS
			 */
			// check if folder with a given name exists
			checkIfFolderExists: function (folderName, that, bInitialLoad) {
				let iIndex;
				let oUploadCollection = that.getView().byId("UploadCollectionMrq");
				oUploadCollection.setBusy(true);
				let responseStatusCode;
				let docServieBaseUrl = that._getDocServiceRuntimeBaseURL();
				let oModelData = that.getView().getModel("multiReqModel").getData().subcontext;
				if (!bInitialLoad) {
					let oNavContainer = that.getView().byId("idNavContainerMrq")
					let currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
					iIndex = Number(currentPageId.slice(-1));
				} else {
					iIndex = 0;
				}
				let sUrl;
				if (folderName == "WorkflowManagement") {
					sUrl = docServieBaseUrl + "/WorkflowManagement/";
				} else if (folderName == "HarmonyPresalesRequests") {
					 sUrl = docServieBaseUrl + "/WorkflowManagement/HarmonyPresalesRequests/";
				} else {
					 sUrl = docServieBaseUrl + "/WorkflowManagement/HarmonyPresalesRequests/" + folderName + "/";
				}
				let oSettings = {
					"url": sUrl,
					"method": "GET",
					"async": false,
					"headers": {
						"ContentType": 'application/json',
						"Accept": 'application/json',
						"cache": false,
						'X-CSRF-Token': 'Fetch'
					}
				};

				let oThisController = that;

				$.ajax(oSettings)
					.done(function (results, textStatus, request) {
						token = request.getResponseHeader('X-Csrf-Token');
						responseStatusCode = request.status;
					})
					.fail(function (err) {
						token = err.getResponseHeader('X-Csrf-Token');
						responseStatusCode = err.status;
						if (responseStatusCode != 404) {
							if (err !== undefined) {
							
							} else {
								
							}
						}
					});

				if (folderName == "WorkflowManagement") {
					if (responseStatusCode == 404) {
						that.createFolder(folderName, that, bInitialLoad);
					} else if (responseStatusCode == 200) {
						console.log("folder 'root/WorkflowManagement' already exisits");
						that.checkIfFolderExists("HarmonyPresalesRequests", that, bInitialLoad);
					} else {
						console.log("something is wrong");
					}
				} else if (folderName == "HarmonyPresalesRequests") {
					if (responseStatusCode == 404) {
						that.createFolder(folderName, that, bInitialLoad);
					} else if (responseStatusCode == 200) {
						console.log("folder with a name 'HarmonyPresalesRequests' already exisits");
						that.checkIfFolderExists(oModelData[iIndex].workflowFileUploadId, that, bInitialLoad);
					} else {
						console.log("something is wrong");
					}
				} else {
					if (responseStatusCode == 200) {
						console.log("target folder is already there");
						let oUploadCollection = oThisController.getView().byId("UploadCollectionMrq");
						let sAttachmentsUploadURL = docServieBaseUrl + "/WorkflowManagement/HarmonyPresalesRequests/" + folderName + "/";
						that.loadAttachments(oModelData[iIndex], oThisController);
					} else if (responseStatusCode == 404) {
						oThisController.createFolder(oModelData[iIndex].workflowFileUploadId, that, bInitialLoad);
					} else {
						console.log("something is wrong");
					}
				}
			},

			// create folder with a given name
			createFolder: function (folderName, that, bInitialLoad) {

				let oThisController = that;
				let docServieBaseUrl = that._getDocServiceRuntimeBaseURL();
				let oModelData = that.getView().getModel("multiReqModel").getData().subcontext;
				let iIndex;
				if (!bInitialLoad) {
					let oNavContainer = that.getView().byId("idNavContainerMrq")
					let currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
					iIndex = Number(currentPageId.slice(-1));
				} else {
					iIndex = 0;
				}
				let sUrl;
				if (folderName == "WorkflowManagement") {
					console.log("creating a folder 'root/WorkflowManagement'");
					 sUrl = docServieBaseUrl + "/";
				} else if (folderName == "HarmonyPresalesRequests") {
					console.log("creating a folder 'root/WorkflowManagement/HarmonyPresalesRequests'");
					 sUrl = docServieBaseUrl + "/WorkflowManagement/";
				} else {
					console.log("creating a folder with a name '" + folderName + "'");
					 sUrl = docServieBaseUrl + "/WorkflowManagement/HarmonyPresalesRequests/";
				}
				let oFormData = new window.FormData();
				oFormData.append("cmisAction", "createFolder");
				oFormData.append("succinct", "true");
				oFormData.append("propertyId[0]", "cmis:name");
				oFormData.append("propertyValue[0]", folderName);
				oFormData.append("propertyId[1]", "cmis:objectTypeId");
				oFormData.append("propertyValue[1]", "cmis:folder");
				let oSettings = {
					"url": sUrl,
					"method": "POST",
					"async": false,
					"data": oFormData,
					"cache": false,
					"contentType": false,
					"processData": false,
					"headers": {
						'X-CSRF-Token': token
					}
				};
				$.ajax(oSettings)
					.done(function (results) {
						if (folderName == "WorkflowManagement") {
							oThisController.checkIfFolderExists("HarmonyPresalesRequests", oThisController);
						} else if (folderName == "HarmonyPresalesRequests") {
							oThisController.checkIfFolderExists(oModelData[iIndex].workflowFileUploadId, oThisController);

						} else {
							// tempFolderObjId = results.succinctProperties["cmis:objectId"];
							oThisController.loadAttachments(oModelData[iIndex], oThisController);
						}
					})
					.fail(function (err) {
						if (err !== undefined) {
							// let oErrorResponse = $.parseJSON(err.responseText);
							// MessageToast.show(oErrorResponse.message, {
							// 	duration: 6000
							// });
						} else {
							//MessageToast.show(oThisController.i18nModel.getText("UNKNOWN_ERROR"));
						}
					});
			},

			loadAttachments: function (modelData, that) {
				let oUploadCollection = that.getView().byId("UploadCollectionMrq");
				that.sAttachmentsUploadURL = that.formatFileUploadUrl(modelData,that);
				const sUrl = that.sAttachmentsUploadURL + "?succinct=true";
				let oSettings = {
					"url": sUrl,
					"method": "GET",
					"async": false
				};
				that.modelData = modelData;
				let oThisController = that;

				$.ajax(oSettings)
					.done(function (results) {
						oThisController._mapAttachmentsModel(results, oThisController);
						if (results.objects && results.objects.length) {
							oThisController.modelData.isAttachment = true;
						} else {
							oThisController.modelData.isAttachment = false;
						}
						oUploadCollection.setBusy(false);
						//attachment urls
					if(!oThisController.modelData.attachmentUrls){
						const aUploadedUrlObj = results.objects;
						if (modelData.isRework && aUploadedUrlObj.length) {
							let oAppConstantsModel = oThisController.getOwnerComponent().getModel("appConstants");
							let sAttachmentRouteUrl = oAppConstantsModel.getProperty("/AttachmentRouteURL/0/Value");
							oThisController.modelData.attachmentUrls = [];
							aUploadedUrlObj.forEach(function (obj) {
								//form uploaded attachment url
								const objectId = obj.object.succinctProperties["cmis:objectId"];
								const sFileName = obj.object.succinctProperties["cmis:name"];
								const sQuery = `?objectId=${objectId}&cmisselector=content`;
								const oUrl = {
									"urlName": sFileName,
									"url": `${sAttachmentRouteUrl}${oThisController.sAttachmentsUploadURL.replace(/^\./, "")}${sQuery}`,
									"urlDelete": true,
									"urlNameValueState": "None",
									"urlValueStateText": "",
									"urlValueState": "None"
								}
								modelData.attachmentUrls.push(oUrl);
								
				
							});
						}
					}else if(modelData.isRework){
						oThisController._initializeUrls(0);
					}
					oThisController.getView().getModel("multiReqModel").refresh();
					})
					.fail(function (err) {
						if (err !== undefined) {
							// let oErrorResponse = $.parseJSON(err.responseText);
							// MessageToast.show(oErrorResponse.message, {
							// 	duration: 6000
							// });
						} else {
							//MessageToast.show(oThisController.i18nModel.getText("UNKNOWN_ERROR"));
						}
					});

			},

			uploadFile: function (oFile, sFileName, oEvent) {

				let oUploadCollection = this.getView().byId("UploadCollectionMrq");
				let oContextData;
				if (!oEvent.workflowFileUploadId) {
					oContextData = oEvent.getSource().getBindingContext("multiReqModel").getObject();
				} else {
					oContextData = oEvent;
				}
				let sUrl = this.formatFileUploadUrl(oContextData, this);

				let oThisController = this;
				oUploadCollection.setBusy(true);

				let oFormData = new window.FormData();
				oFormData.append("cmisAction", "createDocument");
				oFormData.append("propertyId[0]", "cmis:objectTypeId");
				oFormData.append("propertyValue[0]", "cmis:document");
				oFormData.append("propertyId[1]", "cmis:name");
				oFormData.append("propertyValue[1]", sFileName);
				oFormData.append("uploadCollectionMrq", oFile, sFileName);

				let oSettings = {
					"url": sUrl,
					"method": "POST",
					// "async": false,
					"data": oFormData,
					"cache": false,
					"contentType": false,
					"processData": false,
					"headers": {
						'X-CSRF-Token': token
					}
				};

				$.ajax(oSettings)
					.done(function (results) {
						oUploadCollection.setBusy(false);
						oThisController.loadAttachments(oContextData, oThisController)
						MessageToast.show(oThisController.i18nModel.getText("FILE_IS_UPLOADED"));
					})
					.fail(function (err) {
						oUploadCollection.setBusy(false);
						oThisController.loadAttachments(oContextData, oThisController);
						if (err !== undefined) {
							let oErrorResponse = JSON.parse(err.responseText);
							MessageToast.show(oErrorResponse.message, {
								duration: 6000
							});
						} else {
							MessageToast.show(oThisController.i18nModel.getText("UNKNOWN_ERROR"));
						}
					});
			},

			// assign data to attachments model
			_mapAttachmentsModel: function (data, that) {
				let oUploadCollection = that.getView().byId("UploadCollectionMrq");
				oUploadCollection.destroyItems();

				that.oAttachmentsModel = that.getView().getModel("attachmentsModel");
				that.oAttachmentsModel.setData(data);
				that.oAttachmentsModel.refresh();
			},

			// set parameters that are rendered as a hidden input field and used in ajax requests
			onAttachmentsChange: function (oEvent) {
				let oNavContainer = this.getView().byId("idNavContainerMrq");
				let currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
				let iIndex = Number(currentPageId.slice(-1));
				let oModel = this.getView().getModel("multiReqModel").getData().subcontext;
				let oThisController = this;
				let reader = new FileReader();
				let file = oEvent.getParameter("files")[0];

				reader.onload = function (e) {
					let oFile = new Blob([e.target.result]); // creating blob...
					let sFileName = file.name;
					// oThisController.openBusyDialog();
					oThisController.uploadFile(oFile, sFileName, oModel[iIndex]);
				};

				reader.onerror = function (e) {
					sap.m.MessageToast.show("error");
				};
				reader.readAsArrayBuffer(file);
			},

			// show message when user attempts to attach file with size more than 10 MB
			onFileSizeExceed: function (oEvent) {
				let maxSize = oEvent.getSource().getMaximumFileSize();
				let sFileSizeErrorText = this.i18nModel.getText("FILE_SIZE_EXCEEDED_ERROR");
				MessageToast.show(sFileSizeErrorText + " " + maxSize + " MB");
			},

			// set parameters and headers before upload
			onBeforeUploadStarts: function (oEvent) {
				let oUploadCollection = this.getView().byId("UploadCollectionMrq"),
					oFileUploader = oUploadCollection._getFileUploader();

				// use multipart content (multipart/form-data) for posting files
				oFileUploader.setUseMultipart(true);
				oFileUploader.setButtonText(this.i18nModel.getText("UPLOAD"));

				console.log("Before Upload starts");

				// ad csrf token to header of request
				let oTokenHeader = new UploadCollectionParameter({
					name: "X-CSRF-Token",
					value: token
				});
				oEvent.getParameters().addHeaderParameter(oTokenHeader);
			},

			// refresh attachments collection after file was uploaded
			onUploadComplete: function (oEvent) {

				// workaround to remove busy indicator
				let oUploadCollection = this.byId("UploadCollectionMrq"),
					cItems = oUploadCollection.aItems.length,
					i;
				let oContextData = oEvent.getSource().getBindingContext("multiReqModel").getObject();

				for (i = 0; i < cItems; i++) {
					if (oUploadCollection.aItems[i]._status === "uploading") {
						oUploadCollection.aItems[i]._percentUploaded = 100;
						oUploadCollection.aItems[i]._status = oUploadCollection._displayStatus;
						oUploadCollection._oItemToUpdate = null;
						break;
					}
				}
				if (oEvent.getParameter("files")[0].status != 201) {
					let response = JSON.parse(oEvent.getParameter("files")[0].responseRaw);
					MessageToast.show(response.message);
				}
				oUploadCollection.getBinding("items").refresh();
				this.loadAttachments(oContextData, this);
			},

			formatUploadUrl: function (workflowFileUploadId) {
				let docServieBaseUrl = this._getDocServiceRuntimeBaseURL();
				return docServieBaseUrl + "/WorkflowManagement/HarmonyPresalesRequests/" + workflowFileUploadId + "/"
			},
			formatFileUploadUrl: function (oModelData, that) {
				let docServieBaseUrl = that._getDocServiceRuntimeBaseURL();
				return docServieBaseUrl + "/WorkflowManagement/HarmonyPresalesRequests/" + oModelData.workflowFileUploadId + "/"
			},

			// attributes formatting functions
			formatTimestampToDate: function (timestamp) {
				let oFormat = DateFormat.getDateTimeInstance();
				return oFormat.format(new Date(timestamp));
			},

			formatFileLength: function (fileSizeInBytes) {
				let i = -1;
				let byteUnits = [' kB', ' MB', ' GB', ' TB', 'PB', 'EB', 'ZB', 'YB'];
				do {
					fileSizeInBytes = fileSizeInBytes / 1024;
					i++;
				} while (fileSizeInBytes > 1024);

				return Math.max(fileSizeInBytes, 0.1).toFixed(1) + byteUnits[i];
			},

			formatDownloadUrl: function (objectId) {
				let oUploadCollection = this.byId("UploadCollectionMrq");
				let sAttachmentsUploadURL = oUploadCollection.getUploadUrl();

				return sAttachmentsUploadURL + "?objectId=" + objectId + "&cmisselector=content";
			},

			// delete document from temp folder based on users' input
			onDeletePressed: function (oEvent) {
				//let sAttachmentsUploadURL = this.byId("UploadCollectionMrq").getUploadUrl();
				let oContextData = oEvent.getSource().getBindingContext("multiReqModel").getObject();
				let sAttachmentsUploadURL = this.formatFileUploadUrl(oContextData, this);
				let item = oEvent.getSource().getBindingContext("attachmentsModel").getModel("attachmentsModel")
					.getProperty(oEvent.getSource().getBindingContext("attachmentsModel").getPath());
				let objectId = item.object.succinctProperties["cmis:objectId"];
				let fileName = item.object.succinctProperties["cmis:name"];

				let oThisController = this;

				let oFormData = new window.FormData();
				oFormData.append("cmisAction", "delete");
				oFormData.append("objectId", objectId);

				let oSettings = {
					"url": sAttachmentsUploadURL,
					"method": "POST",
					"async": false,
					"data": oFormData,
					"cache": false,
					"contentType": false,
					"processData": false,
					"headers": {
						'X-CSRF-Token': token
					}
				};

				$.ajax(oSettings)
					.done(function (results) {
						MessageToast.show("File '" + fileName + "' is deleted");
					})
					.fail(function (err) {
						if (err !== undefined) {
							let oErrorResponse = $.parseJSON(err.responseText);
							MessageToast.show(oErrorResponse.message, {
								duration: 6000
							});
						} else {
							MessageToast.show(oThisController.i18nModel.getText("UNKNOWN_ERROR"));
						}
					});

				this.loadAttachments(oContextData, this);

			},

			_getRuntimeBaseURL: function () {
				let appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
				let appPath = appId.replaceAll(".", "/");
				let appModulePath = sap.ui.require.toUrl(appPath);
				return appModulePath;
			},

			_getWorkflowRuntimeBaseURL: function () {
				return this._getRuntimeBaseURL(self) + "/workflowruntime/";
			},

			_getDocServiceRuntimeBaseURL: function () {
				return this._getRuntimeBaseURL() + "/docservice";
			},

			_getConstantsBaseURL: function () {
				return this._getRuntimeBaseURL() + "/cap/req-area-api-/Parameter";
			},

			/* Start of Code for CurrentTask Instance ID Update  */
			updateCurrentInstance: function () {
				var WfExt_data = {};
				var URL = this._getRuntimeBaseURL() + "/cap/wf/WfInstance";
				var oModelData = this.getView().getModel("multiReqModel").getData().subcontext[0];
				WfExt_data.instance_GUID = this.getView().getModel("wfInstanceModel").getProperty("/InstanceID");
				let that = this;
				if(oModelData.isRework){
					WfExt_data.parentInstance_GUID = oModelData.parentInstanceID;
				}else{
					WfExt_data.parentInstance_GUID = this.getView().getModel("wfInstanceModel").getProperty("/InstanceID");
				}
				const instGuid = `(instance_GUID='${WfExt_data.instance_GUID}',parentInstance_GUID='${WfExt_data.parentInstance_GUID}')`
				WfExt_data.currentTaskInstanceID = this.userTaskId;
				WfExt_data.currentTaskURL = window.location.href;	
				$.ajax({
					url: URL+`?&$filter=instance_GUID eq ''`,
					type: "GET",
					async: true,
					beforeSend: function (xhr) {
						xhr.setRequestHeader("X-CSRF-Token", "Fetch");
					},
					complete: function (xhr) {
						token = xhr.getResponseHeader("X-CSRF-Token");
						var oSettings = {
							"url": URL + instGuid,
							"method": "PATCH",
							"async": false,
							"data": JSON.stringify(WfExt_data),
							"headers": {
								'X-CSRF-Token': token
							},
							"contentType": "application/json",
						};
						$.ajax(oSettings)
							.done(function (results) {
								if (that.getView().getModel("multiReqModel").getData().subcontext[0].isRework && typeof that.getView().getModel("multiReqModel").getData().subcontext[0].RequestID !== "object" && typeof results === "object") {
									if (results.refID) {
										that.getView().getModel("multiReqModel").setProperty("/subcontext/0/updatedRefId", results.refID);
									}
								}

							})
							.fail(function (err) {
								MessageBox.error("Current user Instance ID update failed!");
							});
					}
				});
			},
			getResProfileDetails: function (iIndex) {
				const bResProfile = this.getView().getModel("multiReqModel").getData().subcontext[0].isResourceProfile;
				let aResProfile,
					sSolutionAreaDesc,
					aProcessorShortList = [],
					aProcessorMoreList = [],
					descStringBAindustry,
					sMoreProcessorText,
					addSolutions;
				if(bResProfile){
				aResProfile =this.getView().getModel("multiReqModel").getData().subcontext[iIndex].aResourceProfileApprovers.ResourceProfileDetails;
				descStringBAindustry = aResProfile.BAIndustries.map(function (obj) {
					return obj.Desc;
				}).join(',');
				if (aResProfile.SolutionAreas) {
					if (aResProfile.SolutionAreas.length) {
						 sSolutionAreaDesc = aResProfile.SolutionAreas.map(function (obj) {
							return obj.SelectedSolutionArea;
						}).join(',');
					}
				}else{
					sSolutionAreaDesc = "";
				}				
				const descPC = this.getView().getModel("multiReqModel").getData().subcontext[0].selectedProfitCenter[0].SelectedDesc;
				let listItems = [];
				const sProfitCenterI18n = this.i18nModel.getText("profitCenter");
				const sSLAi18n = this.i18nModel.getText("solutionArea");
				const sRoleAreaI18n = this.i18nModel.getText("roleAreaPrimary");
				const sRoleI18n = this.i18nModel.getText("rolePrimary");
				const sBAIi18n = this.i18nModel.getText("businessAreaIndustryPrimary");
			
				let data = [
					{ Name: sProfitCenterI18n, Desc: descPC },
					{ Name: sRoleAreaI18n, Desc: aResProfile.Role_GUID.RoleAreaDesc },
					{ Name: sSLAi18n, Desc: sSolutionAreaDesc },
					{ Name: sBAIi18n, Desc: descStringBAindustry }
				];
				if(this.getView().getModel("multiReqModel").getData().subcontext[iIndex].aResourceProfileApprovers.ResourceProfileDetails.SelectedRole){
					let sRoleDesc; 
					if (this.getView().getModel("multiReqModel").getData().subcontext[iIndex].aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RolesData.length > 1) {
						sRoleDesc = this.getView().getModel("multiReqModel").getData().subcontext[iIndex].aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RolesData.map(function (obj) {
						  return obj.RoleDesc;
					  }).join(',');
				  }else{
					  sRoleDesc =  this.getView().getModel("multiReqModel").getData().subcontext[iIndex].aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.Desc;
				  }
					 data = [
						{ Name: sProfitCenterI18n, Desc: descPC },
					{ Name: sRoleAreaI18n, Desc: aResProfile.Role_GUID.RoleAreaDesc },
					{ Name: sRoleI18n, Desc: sRoleDesc },
					{ Name: sSLAi18n, Desc: sSolutionAreaDesc },
					{ Name: sBAIi18n, Desc: descStringBAindustry }
				   
				];
				}
				data.forEach(function (item) {
					if (item.Desc) {
						let listItem = {
							Name: item.Name,
							Desc: item.Desc
						};
						listItems.push(listItem);
					}
				});
				let oModelResPr = new sap.ui.model.json.JSONModel();
				oModelResPr.setData(
					listItems
				);

				this.getView().setModel(oModelResPr, "ResProfileModel");	
				//Git 132 (Form template/standardization ) start
				//set request page header
				//processor list
				let aProcessorList = this.getView().getModel("multiReqModel").getData().subcontext[iIndex].aResourceProfileApprovers.ApproverDetails;
				aProcessorList.length ? aProcessorList[0].bIsTitle = true : false;
				//sort processor list
				CommonJS._empSort(aProcessorList,"fullName");
				if(aProcessorList.length > 2){
				   const iProcessorMoreCount = (aProcessorList.length - 2).toString(),
				         si18nMoreText = this.i18nModel.getText("more");
						sMoreProcessorText = `(${iProcessorMoreCount} ${si18nMoreText})`;
					aProcessorShortList = aProcessorList.slice(0, 2); // visible approver list ( max 2 processors)
					aProcessorMoreList = aProcessorList.slice(2);// array point to link to show more processors	
				} else {
					aProcessorShortList = aProcessorList;
				}
			}
			
				//set object for request header model
				const oHeaderFields = {
					profitCenterHeader:bResProfile ? this.getView().getModel("multiReqModel").getData().subcontext[0].selectedProfitCenter[0].desc:"",
					// roleHeader:bResProfile ? aResProfile.Role_GUID.RoleDesc:"",
					roleHeader: bResProfile ? aResProfile.Role_GUID.SelectedRoleDesc ? aResProfile.Role_GUID.SelectedRoleDesc : aResProfile.Role_GUID.RolesData.map(obj => { return obj.RoleDesc }).join(", ") : "",
					solnHeader:bResProfile ? sSolutionAreaDesc:"",
					// addSolutions:bResProfile ? addSolutions:"",
					addSolutions:bResProfile && aResProfile.AdditionalSolutions && aResProfile.AdditionalSolutions.length? aResProfile.AdditionalSolutions:[],
					indHeader:bResProfile ?descStringBAindustry:"",
					rolAreaHeader:bResProfile ?aResProfile.Role_GUID.RoleAreaDesc:"",
					reqNameHeader:this.getView().getModel("multiReqModel").getData().subcontext[iIndex].requesterDetails,
					processorShortList:bResProfile? aProcessorShortList:[],
					processorMoreList:bResProfile? aProcessorMoreList:[],
					moreProcessorText:bResProfile ?sMoreProcessorText:[],
					groupDesc: bResProfile && aResProfile?.SelectedGroup?.length ? aResProfile.SelectedGroup[0].GroupDesc : "",
					isRes:true,
					currentScope:this,
					processorDisplayList:bResProfile && sMoreProcessorText ? aProcessorShortList.concat([{
						ID:"idMoreText",
						fullName:sMoreProcessorText
					}]):aProcessorShortList,
					urlToProfile:`${this.getOwnerComponent().getModel("appConstants").getProperty("/userProfileUrl/0/Value")}${this.getView().getModel("multiReqModel").getData().subcontext[iIndex].requesterDetails["id"]}`
				}
			
				//set request page header model
				const oModelHeader = new sap.ui.model.json.JSONModel();
				oModelHeader.setData(
					oHeaderFields
				);
				//set header model
				this.getView().setModel(oModelHeader, "requestHeaderModel");
				//Git 132 (Form template/standardization ) end
			},
			
			handleSCBtnPress: function () {
				const oDynamicSideView = this.getView().byId("submitPageDynamicSideContent");
				const oOPSideContentBtn = this.getView().byId("openSideContentBtnSubmitPage");
				//GIT 277- common function to fetch the action history
				CommonJS._setActionHistoryModel(this, oDynamicSideView, oOPSideContentBtn);
			},
			handleSideContentHide: function () {
				const oDynamicSideView = this.getView().byId("submitPageDynamicSideContent");
				const sCurrentBreakpoint = oDynamicSideView.getCurrentBreakpoint();
				const oOPSideContentBtn = this.getView().byId("openSideContentBtnSubmitPage");
				if (sCurrentBreakpoint === "S") {
					oDynamicSideView.toggle();
				} else {
					oDynamicSideView.setShowSideContent(false);
				}
				if (this.getOwnerComponent().getModel("wfInstanceModel").getProperty("/currentStateID") === "REESUB") {
					oOPSideContentBtn.setVisible(true);
				}


				setTimeout(() => {
					const element = this.byId("openSideContentBtnSubmitPage").focus();
					if (element) {
						element.focus();
					}
				}, 0);
			},
			firstLastNameFormatter: function(sName1 , sName2){
                function capitalizeFirstLetter(word) {
                    return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
                }
            
                let formattedFirstName = capitalizeFirstLetter(sName1);
                let formattedLastName = capitalizeFirstLetter(sName2);
            
                return `${formattedFirstName} ${formattedLastName}`;
          
        },
		onSaveDraft:function(){
			const oNavContainer = this.getView().byId("idNavContainerMrq");
			const currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
			const iIndex = Number(currentPageId.slice(-1));
			const oContextData = this.getView().getModel("multiReqModel").getData().subcontext[iIndex];
			//remove unsaved data after save draft
			//for (let i = 0; i < this.unSavedData.length; i++) {
				//if (this.unSavedData[i].iIndex === iIndex) {
			//		this.unSavedData.splice(i, 1)
				//}
			//}
			//validate form fields before save draft
			this._validateFormFields(oContextData,true);		
		},
		_onSaveDraft:function(){
			this.getView().setBusy(true);
			const oNavContainer = this.getView().byId("idNavContainerMrq");
			const currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
			const iIndex = Number(currentPageId.slice(-1));
			const oContextData = this.getView().getModel("multiReqModel").getData().subcontext[iIndex];
			const oRequestDetails = this._formRequestDetails(oContextData);
			const sInstanceID = this.getView().getModel("wfInstanceModel").getProperty("/InstanceID");
			const sMilliSeconds = new Date().getUTCMilliseconds();
			const sTabId = iIndex + 1;
			models.getSaveDraftFormDetails(sInstanceID,this.fnSuccessCallbackGetDraft,this,true)
			const oDraftModel = this.getView().getModel("draftTable").getData();
			const aDraftTable =  oDraftModel.filter((draft) => draft.tabID ===  sTabId.toString());	
			const sSearchGuid = aDraftTable.length ? aDraftTable[0].instanceDF_GUID : `${sInstanceID}${sMilliSeconds}${sTabId}`;
			const that = this;
			if (!that.requestDraftUrls) {
				that.requestDraftUrls = [];
			} else {
                that.requestDraftUrls = [...new Set(that.requestDraftUrls)];
			}
			//Post parent constant table
			if (!oDraftModel.length) {
				const oDF_WFInsParentPayload = {};
				oDF_WFInsParentPayload.parentInstance_GUID = sInstanceID ? sInstanceID : "";
				oDF_WFInsParentPayload.refID = oContextData.UT_refID;
				oDF_WFInsParentPayload.orgID = oContextData.OrgID ? oContextData.OrgID : "";
				oDF_WFInsParentPayload.orgType = oContextData.OrgType ? oContextData.OrgType : "";
				oDF_WFInsParentPayload.reqTypeID = oContextData.RequestTypeValue ? oContextData.RequestTypeValue.ID : "";
				oDF_WFInsParentPayload.OpportunityID = oContextData.opportunityId ? oContextData.opportunityId : "";
				oDF_WFInsParentPayload.opportunityDesc = oContextData.Opp_Desc ? oContextData.Opp_Desc : "";
				oDF_WFInsParentPayload.Account_ID = oContextData.accountId ? oContextData.accountId : "",
					oDF_WFInsParentPayload.Account_name = oContextData.accountName ? oContextData.accountName : "",
					oDF_WFInsParentPayload.SystemID = oContextData.systemId ? oContextData.systemId : "";
				oDF_WFInsParentPayload.industryName = oContextData.IndustryName ? oContextData.IndustryName : "";
				oDF_WFInsParentPayload.pE_Name = oContextData.PE_Name ? oContextData.PE_Name : "";
				oDF_WFInsParentPayload.ExtSystemsUrl = oContextData.extSystemsUrls ? oContextData.extSystemsUrls.harmony : "";
				oDF_WFInsParentPayload.eng_type_ID=oContextData.EngagementType
				that.requestDraftUrls.push(`/DF_WFIns_Parent(parentInstance_GUID='${oDF_WFInsParentPayload.parentInstance_GUID}')`);
				models.postSaveDraftFormDetails(this, oDF_WFInsParentPayload, "DF_WFIns_Parent", "POST");
			}

			//Post main table
			const oDF_WFInsPayload = this._formDF_WFInsPayload(oContextData,oRequestDetails,iIndex,sSearchGuid);
			const sMethod = aDraftTable.length ? "PATCH":"POST";
			that.requestDraftUrls.push(`/DF_WFIns(instanceDF_GUID='${oDF_WFInsPayload.instanceDF_GUID}',parentInstance_GUID='${oDF_WFInsPayload.parentInstance_GUID}')`);
			const sPostUrl = (sMethod === "POST") ? "DF_WFIns" : `DF_WFIns(instanceDF_GUID='${oDF_WFInsPayload.instanceDF_GUID}',parentInstance_GUID='${oDF_WFInsPayload.parentInstance_GUID}')`;
			models.postSaveDraftFormDetails(this, oDF_WFInsPayload,sPostUrl,sMethod);
		},
			_formDF_WFInsPayload: function (oContextData, oRequestDetails, iIndex, sSearchGuid) {
				const oWfInstanceModel = this.getView().getModel("wfInstanceModel");
				const now = new Date();
				const sCurrentDate = now.toISOString().split('T')[0];
				const sCurrentTime = now.toISOString().split('T')[1].replace('Z', '');
				const sCreationDate = oWfInstanceModel.getProperty("/DTCreation_tdate");
				const sCreationTime = oWfInstanceModel.getProperty("/DTCreation_ttime");
				const sInstanceID = this.getView().getModel("wfInstanceModel").getProperty("/InstanceID");
				const sTabId = iIndex + 1;
				const oFormActionsModelData = this.getView().getModel("formActionsConfigModel").getData();
				const sDecisionId = oFormActionsModelData.iddraft[0].ID;
				if (oContextData.EngagementType === '0002') {	
					const aWfInsUrls = [];
					const aAttachmentUrls = oRequestDetails.attachmentUrls;
						for (let i = 0; i < aAttachmentUrls.length; i++) {
							let oPayload = {
								"urlCountID": i + 1,
								"tabID": sTabId.toString(),
								"url": aAttachmentUrls[i].url,
								"urlName": aAttachmentUrls[i].urlName,
							}
							aWfInsUrls.push(oPayload);
						}				
					return {
						instanceDF_GUID: sSearchGuid,
						tabID: sTabId.toString(),
						parentInstance_GUID: sInstanceID,
						technicalStateID: oWfInstanceModel.getProperty("/TechnicalStateID"),
						reqAreaGUID: oContextData.reqAreaGUID ? oContextData.reqAreaGUID : "",
						create_Date: sCreationDate,
						create_Time: sCreationTime,
						change_Date: sCurrentDate,
						change_Time: sCurrentTime,
						decisionID: sDecisionId,
						// supportTypeKey: oRequestDetails.supportTypeKey ? oRequestDetails.supportTypeKey : "",
						need_From_Fbs: oRequestDetails.need_From_Fbs ? oRequestDetails.need_From_Fbs : "",
						supp_Type_FBS: oRequestDetails.supp_Type_FBS ? oRequestDetails.supp_Type_FBS : "",
						supp_Type_Pqa_Id: oRequestDetails.supp_Type_Pqa_Id ? oRequestDetails.supp_Type_Pqa_Id : "",
						c2c_Deal: oRequestDetails.c2c_Deal ? "X":"",
						opp_Origin_Id: oRequestDetails.opp_Origin_Id ? oRequestDetails.opp_Origin_Id : "",
						Opp_Number: oRequestDetails.Opp_Number ? oRequestDetails.Opp_Number : "",
						solution_Id: oRequestDetails.solution_Id ? oRequestDetails.solution_Id : "",
						est_Acv: oRequestDetails.est_Acv ? oRequestDetails.est_Acv : "",
						model_Id: oRequestDetails.model_Id ? oRequestDetails.model_Id : "",
						isp_Id: oRequestDetails.isp_Id ? oRequestDetails.isp_Id : "",
						io_Number: oRequestDetails.io_Number ? oRequestDetails.io_Number : "",
						contact_Prsn_Id: oRequestDetails.contact_Prsn_Id ? oRequestDetails.contact_Prsn_Id : "",
						contact_Prsn_Email: oRequestDetails.contact_Prsn_Email ? oRequestDetails.contact_Prsn_Email : "",
						oppclosing_Date: oRequestDetails.oppclosing_Date ? oRequestDetails.oppclosing_Date : null,
						contract_Start_Date: oRequestDetails.contract_Start_Date ? oRequestDetails.contract_Start_Date : null,
						contract_End_Date: oRequestDetails.contract_End_Date ? oRequestDetails.contract_End_Date : null,
						comments: oContextData.comments,
						WfinsURL: aWfInsUrls
					}

				} else {


					//language
					const sLanguageKey = oRequestDetails.languageKey;
					const aLanguage = [];
					if (oRequestDetails.isMeetingPlanned && sLanguageKey) {
						const aLanguageKeys = sLanguageKey.split(";");
						aLanguageKeys.forEach(function (key) {
							const oDF_ReqForm_LanguagePayload = {
								"languageID": key.trim()

							};
							aLanguage.push(oDF_ReqForm_LanguagePayload);
						});
					}
					//support type
					const aSupportType = [];
					const sSupportKey = oRequestDetails.supportTypeKey;
					if (sSupportKey) {
						const aSupportKeys = sSupportKey.split(";");
						aSupportKeys.forEach(function (key) {
							const oDF_ReqForm_SupportTypePayload = {
								"supportTypeID": key.trim()
							};
							aSupportType.push(oDF_ReqForm_SupportTypePayload);
						});
					}

					//Participant type
					const aPartcpType = [];
					const sParticipantTypeKey = oRequestDetails.participantTypeKey;
					if (oRequestDetails.isMeetingPlanned && sParticipantTypeKey) {
						const aParticipantTypeKeys = sParticipantTypeKey.split(";")
						aParticipantTypeKeys.forEach(function (key) {
							const oDF_ReqForm_PartcpTypePayload = {
								"participantTypeID": key.trim()
							};
							aPartcpType.push(oDF_ReqForm_PartcpTypePayload);
						});
					}

					//Involved sap parties
					const aInvSAP_Party = [];
					const sInvSap = oRequestDetails.involvedPartiesKey;
					if (oRequestDetails.isMeetingPlanned && sInvSap) {
						const aInvSapKeys = sInvSap.split(";");
						aInvSapKeys.forEach(function (key) {
							const oDF_ReqForm_InvSAP_PartyPayload = {
								"involved_SAP_PartiesID": key.trim()
							};
							aInvSAP_Party.push(oDF_ReqForm_InvSAP_PartyPayload);

						});
					}
					//attachmentUrls
					const aWfInsUrls = [];
					if (!oRequestDetails.attachmentUrls[0]) {
						oRequestDetails.attachmentUrls = [{
							"urlName": "",
							"url": "",
							"urlDelete": false,
							"urlNameValueState": "None",
							"urlValueStateText": "",
							"urlValueState": "None"
						}];
					}
					if (oRequestDetails.attachmentUrls) {
						oRequestDetails.attachmentUrls.forEach(function (item, iIndex) {
							if (!item.url && !item.urlName) {
								oRequestDetails.attachmentUrls.splice(iIndex, 1);
							}
						});
						const aAttachmentUrls = oRequestDetails.attachmentUrls;
						for (let i = 0; i < aAttachmentUrls.length; i++) {
							let oPayload = {
								"urlCountID": i + 1,
								"tabID": sTabId.toString(),
								"url": aAttachmentUrls[i].url,
								"urlName": aAttachmentUrls[i].urlName,
							}
							aWfInsUrls.push(oPayload);
						}
					}
					return {
						instanceDF_GUID: sSearchGuid,
						tabID: sTabId.toString(),
						parentInstance_GUID: sInstanceID,
						technicalStateID: oWfInstanceModel.getProperty("/TechnicalStateID"),
						reqAreaGUID: oContextData.reqAreaGUID ? oContextData.reqAreaGUID : "",
						create_Date: sCreationDate,
						create_Time: sCreationTime,
						change_Date: sCurrentDate,
						change_Time: sCurrentTime,
						decisionID: sDecisionId,
						need_from_CustAdvisory: oRequestDetails.typeOfSupport,
						cust_asked_forMeeting: oRequestDetails.isMeetingPlanned ? "X" : "",
						meetingTypeID: oRequestDetails.isMeetingPlanned ? oRequestDetails.meetingTypeKey : "",
						comments: oContextData.comments,
						solution_Models: oRequestDetails.solutionsInScope,
						custAdvisory_Resource: oRequestDetails.preferredPresales,
						Meeting_Goal: oRequestDetails.isMeetingPlanned ? oRequestDetails.meetingGoal : "",
						meetingLocation: oRequestDetails.isMeetingPlanned ? oRequestDetails.meetingLocation : "",
						meetingDate: oRequestDetails.isMeetingPlanned ? oRequestDetails.meetingDate : "",
						meetingTime: oRequestDetails.isMeetingPlanned ? oRequestDetails.meetingTime : "",
						involved_SAP_Parties_Name: oRequestDetails.isMeetingPlanned ? oRequestDetails.involvedPartiesNames : "",
						Participants_Type_Details: oRequestDetails.isMeetingPlanned ? oRequestDetails.participantTypeDetails : "",
						language: aLanguage,
						SupportType: aSupportType,
						PartcpType: aPartcpType,
						InvSAP_Party: aInvSAP_Party,
						WfinsURL: aWfInsUrls
					}
				}
			},
		//initialize url model//attachment urls
		_initializeUrls: function (iIndex) {
			//initialize urls model
			//mychange
			if(this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls){
				if(!this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls[0]){
					this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls = [{
						"urlName": "",
						"url": "",
						"urlDelete": false,
						"urlNameValueState": "None",
						"urlValueStateText":"",
						"urlValueState": "None"
					}];
				}
			}
			if (!this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls && this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].currentStepID === "REQSUB") {
				this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls = [];
				this.onAddNewUrl(false,iIndex);
			} else if (this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls) {
				const oContextUrls = this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls;
				oContextUrls.forEach(function (obj, iIndex) {
					const oFinalUrlContext = {

					}
					//initialize assignment properties
					oFinalUrlContext.urlNameValueState = "None";
					oFinalUrlContext.urlValueState = "None";
					oFinalUrlContext.urlName = obj.urlName;
					oFinalUrlContext.url = obj.url;
				});
				this._setUrlDeleBtn(oContextUrls);
			} else {
				this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls = [];
				this.onAddNewUrl(false,iIndex);
			}
			
		},
		//add new url
		onAddNewUrl: function (evt,iIndex) {
			if (evt) {
				const oBindingContext = evt.getSource().getBindingContext("multiReqModel").getPath();
				const sIndex = oBindingContext.split('/subcontext/')[1];
				iIndex = Number(sIndex);
			}
			const oModelData = this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls;
			const oUrl = {
				"urlName": "",
				"url": "",
				"urlDelete": true,
				"urlNameValueState": "None",
				"urlValueStateText":"",
				"urlValueState": "None"
			}
			oModelData.push(oUrl);
			this._setUrlDeleBtn(oModelData);
			this.getView().getModel("multiReqModel").refresh(true);
		},
		_setUrlDeleBtn: function (oModelData) {
			if (oModelData.length === 1) {
				oModelData[0].urlDelete = false;
			} else {
				oModelData.forEach(function (val) {
					val.urlDelete = true;
				});
			}
		},
		//delete attachment url
		onDeleteUrl: function (evt) {
			const oContextPath = evt.getSource().getBindingContext("multiReqModel").getPath();
			const oUrlObj = evt.getSource().getBindingContext("multiReqModel").getObject();
			const iIndex = Number(oContextPath.split('/')[2]);
			const oModelData = this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls;
			const filteredArray = oModelData.filter(e => e !== oUrlObj);
			if (filteredArray.length === 1) {
				filteredArray[0].urlDelete = false;
			} else {
				filteredArray.forEach(function (val) {
					val.urlDelete = true;
				});
			}
			this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls = filteredArray;
			this.getView().getModel("multiReqModel").refresh(true);
		},
		//live change attachment url input
		onUrlChange:function(evt){
			const sValue = evt.getParameter("value");
			const oContextPath = evt.getSource().getBindingContext("multiReqModel").getPath();
			const oUrlObj = evt.getSource().getBindingContext("multiReqModel").getObject();
			const iIndex = Number(oContextPath.split('/')[2]);
			const iUrlObjIndex = Number(oContextPath.split('/')[4]);
			const oModelData = this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls;
			const i18nModel =  this.getOwnerComponent().getModel("i18n").getResourceBundle();
			let bUrlDuplicate;
			oUrlObj.url = sValue;
			oModelData.forEach(function(item,index){
				if(index !==iUrlObjIndex &&  oUrlObj.url === item.url){
					bUrlDuplicate = true;
				}
			});
			//regexp for checking valid url
			const bValidUrl = new RegExp(
                /((([A-Za-z]{3,9}:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)/
 
              ).test(oUrlObj.url);
			if(sValue && !bValidUrl){
				//invalid url
				oUrlObj.urlValueState = "Error";
				oUrlObj.urlValueStateText = i18nModel.getText("INVALID_URL")
			}else if(sValue && bUrlDuplicate){
				//duplicate url
				oUrlObj.urlValueState = "Error";
				oUrlObj.urlValueStateText = i18nModel.getText("URL_ALREADY_EXIST")
			}else{
				oUrlObj.urlValueState = "None";
			}
			this.getView().getModel("multiReqModel").refresh();
		},
		//remove the empty url objects
		_removeEmptyUrl:function(iIndex){
			const i18nModel =  this.getOwnerComponent().getModel("i18n").getResourceBundle();
			const oModelData = this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls;
			const isAllUrlEmpty = oModelData.every(v => v.url === "");
			if (!isAllUrlEmpty) {
				const aFinalUrls = oModelData.filter(item => item.url !== "");
				this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls = aFinalUrls;
			}else{
				this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls.length = 1;
			}
			this.getView().getModel("multiReqModel").refresh(true);
			const aDuplicates = oModelData.filter((item, index) => oModelData.some((elem, idx) => elem.url === item.url && idx !== index));
			if(!aDuplicates.length){
				oModelData.forEach(function(item){
					if(item.urlValueStateText === i18nModel.getText("URL_ALREADY_EXIST")){
						item.urlValueState = "None"
					}
				})
			}
			this.getView().getModel("multiReqModel").refresh(true);
		},
		onPreviewUrl:function(evt){
			const oUrlObj = evt.getSource().getBindingContext("multiReqModel").getObject();
			const URLHelper = mLibrary.URLHelper;
			if(oUrlObj.url && oUrlObj.urlValueState === "None"){
				URLHelper.redirect(oUrlObj.url, true);
			}
		},
		 /**
           * event trigger for old request opp routing
           *
           * @param {Object} evt -event object
           */
		 handleUrlRouting:function(evt){
			models._handleUrlRouting(evt);
		 },
		 /**Git 132 (Form template changes + add new opp fields)
         *press event to show more processor list
         * @param {object} oEvent -The current control(link) event
         */
		onPressUserList: function (oEvent) {
			const oView = this.getView(),
				  that = this;
			if (!this._pMoreUerListPopOver) {
				//load userList more fragment
				this._pMoreUerListPopOver = Fragment.load({
					id: oView.getId(),
					name: "com.dealsupport.melodyrequest.fragments.userListMore",
					controller: this
				}).then(function (oMoreUerListDialog) {
					that._moreUserListDialog = oMoreUerListDialog;
					oView.addDependent(oMoreUerListDialog);
					return oMoreUerListDialog;
				});
			}

			this._pMoreUerListPopOver.then(function (oMoreUerListDialog) {
				  oMoreUerListDialog.openBy(oEvent.getSource());
			});

		},
			 /**Git 132 (Form template changes + add new opp fields)
         *press event to close processor popover list
         */
		onCloseMoreLisPopOver:function(){
			if(this._moreUserListDialog){
				this._moreUserListDialog.close();
			}
		},
		onComboBoxSelectionChange:function(oEvent){
			if(oEvent.getSource().getSelectedKey()!="")
				oEvent.getSource().setProperty("valueState", "None");
		},
		onDatePickerChange:function(oEvent){
			if(oEvent.getParameter("valid"))
				oEvent.getSource().setValueState(ValueState.None);
			setTimeout(function () {
				oEvent.getSource().$("inner").blur()
			},0)
		},	
		fnGetDefaultValFBS: function (formVal) {
			if (formVal) {
				for (let i = 0; i < formVal.length; i++) {
					if (formVal[i].Default_Flag === "X") {
						return formVal[i].ID
					}
				}
				return null;
			}
		},
		onChangeValidateFBSFormEmail:function(oEvent){
			var email = oEvent.getSource().getValue()
			var rexMail = /^\w+[\w-+\.]*\@\w+([-\.]\w+)*\.[a-zA-Z]{2,}$/;
			if (email) {
				if (!email.match(rexMail)) {
					oEvent.getSource().setValueState("Error")
				} else {
					oEvent.getSource().setValueState("None")
				}
			}else{
				oEvent.getSource().setValueState("None")				
			}
		},
		validateEmail: function (email) {
			var rexMail = /^\w+[\w-+\.]*\@\w+([-\.]\w+)*\.[a-zA-Z]{2,}$/;
			if (!email.match(rexMail)) {
				return false
			} else {
				return true
			}
		},
		onChangeComboBoxFBS: function (oEvent) {
			if (oEvent.getSource().getValue()) {
				let binding = oEvent.getSource().getBinding("items").oList
				let value = oEvent.getSource().getValue()
				let bState = false
				binding.forEach(obj => {
					if(obj.mainText){
						if (obj.mainText.includes(value)) {
						bState = true
						}
					}else{
						if (obj.Value.includes(value)) {
						bState = true
						}
					}
				})
				if (bState) {
					oEvent.getSource().setValueState("None")
				} else {
					oEvent.getSource().setValueState("Error")
				}
			} else {
				oEvent.getSource().setValueState("None")
			}
		}			


	});
});