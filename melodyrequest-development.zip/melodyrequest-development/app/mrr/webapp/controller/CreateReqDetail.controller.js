sap.ui.define([
	"sap/m/library",
	"sap/ui/core/mvc/Controller",
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
	"com/dealsupport/melodyrequest/model/models",
	"com/dealsupport/melodyrequest/model/formatter",
	"com/dealsupport/melodyrequest/model/users",
	"com/dealsupport/melodyrequest/control/Common",
	"sap/ui/model/odata/v2/ODataModel",
	"com/dealsupport/melodyrequest/control/ErrorHandle",

], function (mobileLibrary, Controller, Filter, FilterOperator, models, formatter, users,CommonJS, ODataModel,ErrorHandle) {
	"use strict";
	var URLHelper = mobileLibrary.URLHelper;
	//Initate detail page
	return Controller.extend("com.dealsupport.melodyrequest.controller.CreateReqDetail", {
				formatter: formatter,
				common:CommonJS,
		onInit: function () {
			this.getView().addStyleClass(appView.getOwnerComponent().getContentDensityClass());
			this.bus = appView.getOwnerComponent().getEventBus();
			appView.detailViewScreen = this;
		},
				//Search event for  Request Area
		onItemSearchInHierarchy: function (oEvent) {
			const sQUery = oEvent.getParameter("newValue").trim();
			let oPresaleTable = {};
			oPresaleTable = this.byId("idTree");
			const oPresaleTextFilter = new Filter("text", FilterOperator.Contains, sQUery);
			const oPresaleFilter = new Filter({
				filters: [oPresaleTextFilter],
				and: false
			});
			oPresaleTable.getBinding("items").filter(oPresaleFilter);
		},
		//nav back to Audience for ipad
		onBackToAudience: function () {
			appView.bus.publish("flexible", "setListPage");

		},
		/*Resource profile screen*/
		/*Open Business Area Industry Fragment*/
		onOpenBAIndustryValueHelpDialog: function (oEvent) {
			const oBindingIndex = Number(oEvent.getSource().getBindingContext("employee").getPath().split('/')[2]);
			this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/iIndex`, oBindingIndex);
			const that = this;
			if (!this.pBAIndustryValueHelpDialog) {
				this.pBAIndustryValueHelpDialog = this.loadFragment({
					name: "com.dealsupport.melodyrequest.fragments.resourceProfile.BAIndustryValueHelpDialog"
				});
				this.getView().getModel("employee").refresh();
				this._callBusinessAreaIndustryMasterData(oBindingIndex);
			}else{
				const oModel = this.getView().getModel("employee");
				const oModelData = oModel.getProperty("/searchItems");
				oModelData.forEach(function (data) {
					if (data.TempEmployee.BAIndustriesList) {
						if (data.TempEmployee.BAIndustriesList.length) {
							oModel.setProperty(`/searchItems/${oBindingIndex}/TempEmployee/BAIndustriesList`, data.TempEmployee.BAIndustriesList);
						}
					}
				});
			}
			this.pBAIndustryValueHelpDialog.then(function (oDialog) {
				that.getView().setModel(new sap.ui.model.json.JSONModel(), "masterDataModel");
				const oMasterDataModel = that.getView().getModel("masterDataModel");
				oMasterDataModel.setData(that.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}`));
				that.getView().getModel("masterDataModel").refresh();
				that.filterBAIndustries(oBindingIndex);
				oDialog.openBy(oEvent.getSource());
				
			});
		},
		//MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
		/*Open Solution Area  Fragment*/
		onOpenSLAPopOver: function (oEvent) {
			this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/results",[]);
			const that = this,
				 oBindingIndex = Number(oEvent.getSource().getBindingContext("employee").getPath().split('/')[2]),
				 aSLAMasterData =   this.getOwnerComponent().getModel("SLAMasterDataL1").getData().results;
				 that.getView().setModel(new sap.ui.model.json.JSONModel(), "masterDataModel");
				const oMasterDataModel = that.getView().getModel("masterDataModel");
				if(this.oSLASearchContext){
					this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas`,this.oSLASearchContext)
				}
			if (this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas`)) {
				this.oSLASearchContext = JSON.parse(JSON.stringify(this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas`)));
			}
				oMasterDataModel.setData(that.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}`));
				oMasterDataModel.refresh();
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",[]);
			if (!this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas/0`)) {
				//set defualy solution area L1
				//this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/selectedSolAreaL1",aSLAMasterData[0].SolGuid);
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",aSLAMasterData);
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA",false)
			}else if(this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas/0`)){
				//set selected solution area L1
				this.oContextSolutionArea = this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas/0`);
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/selectedSolAreaL1",
				this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas/0/soln_prnt_guid`));
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas`));
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA",true)
			}
			this.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
			this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/iIndex`, oBindingIndex);
			this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/TempEmployee/slaBusy`,true);
			if (!this.pSLAValueHelpDialog) {
				this.pSLAValueHelpDialog = this.loadFragment({
					name: "com.dealsupport.melodyrequest.fragments.resourceProfile.SolutionArea"
				});
			}
			this.pSLAValueHelpDialog.then(function (oDialog) {
				that.onAfterOpenSLAPopover();
				oDialog.setPlacement("Left");
				oDialog.openBy(oEvent.getSource());
				that.getView().getModel("employee").setProperty(`/searchItems/${that.getView().getModel("masterDataModel").getProperty("/iIndex")}/TempEmployee/slaBusy`, false);
				if(that.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas`)){
					that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",that.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas`));
				}
				
				that.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
				that._OnUpdateSlaSelection();
				that.byId("idSolutionTreeOnCreate").getHeaderToolbar().getContent()[0].setValue("")
				that.onSearchSolutionArea(false)
			});
		
          //  this.filterAndExpandTree(oTree, "");
			this.getView().getModel("employee").refresh();
		},
		//MR: [GRP02-03] GTM25 Resource Profile alignment #84 end
		/*Call BusinessAreaIndustry MasterData*/
		_callBusinessAreaIndustryMasterData: function (oBindingIndex) {
			const oModel = this.getView().getModel("employee");
			const oTempEmployee = oModel.getProperty(`/searchItems/${oBindingIndex}/TempEmployee`);
			const that = this;
			const data = appView.getView().getModel("baIndMasterData").getData();

			if (data && data.d && data.d.results) {
				const aBAIndustry = data.d.results;
				oTempEmployee.BAIndustriesList = [];
				aBAIndustry.map((element, index, array) => {
					oTempEmployee.BAIndustriesList.push({
						Guid: element.BaIndGuid,
						ID: element.BaIndId,
						Desc: element.BaIndDesc,
						ClusterGuid: element.IndClstrGuid,
						ClusterDesc: element.IndClstrDesc,
						IsDefault: (element.DefaultSel && element.DefaultSel === "X") ? true : false,
						IsNonFocused: (element.DisplayGroup && element.DisplayGroup === "2") ? true : false,
						IsPrimary: false,
						IsEnabled: (element.DisplayGroup !== "4"),
						IsSelected: false,
						BaIndTechID: element.BaIndTechId,
						BaIndId: element.BaIndId
					});
				});
			}
			oTempEmployee.BAIndustriesList.sort((i, j) => i.ClusterDesc.localeCompare(j.ClusterDesc));
			oTempEmployee.BAIndustriesList.unshift(oTempEmployee.BAIndustriesList.splice(oTempEmployee.BAIndustriesList.findIndex(item => item.ID === "0025"), 1)[0]);
			oModel.refresh(true);
			that.filterBAIndustries(oBindingIndex);
		},
		
		/*Filter business area industries*/
		filterBAIndustries: function (oBindingIndex) {
			const oModel = this.getView().getModel("employee");
			const oTempEmployee = oModel.getProperty(`/searchItems/${oBindingIndex}/TempEmployee`);
			let aBAIndustries = [];
			aBAIndustries = JSON.parse(JSON.stringify(oTempEmployee.BAIndustriesList));
			let aEmployeeBAIndustries = JSON.parse(JSON.stringify(oModel.getProperty(`/searchItems/${oBindingIndex}/TempEmployee/BAIndustries`)));
			oModel.setProperty(`/searchItems/${oBindingIndex}/NonIndustryFocused`, {
				Guid: "",
				IsSelected: false,
				IsVisible: false,
				ID : ""
			});
			aBAIndustries.map(function (element, index, array) {
				const oEmployeeBAIndustry = aEmployeeBAIndustries.find(item => item.Guid === element.Guid);
				if (oEmployeeBAIndustry) {
					element.IsSelected = true;
					element.IsPrimary = false;
					oEmployeeBAIndustry.ClusterGuid = element.ClusterGuid;
					oEmployeeBAIndustry.ClusterDesc = element.ClusterDesc;
					oEmployeeBAIndustry.BaIndTechID = element.BaIndTechID;
					oEmployeeBAIndustry.BaIndId = element.BaIndId;
				} else {
					element.IsSelected = false;
					element.IsPrimary = false;
				}
				if (element.IsNonFocused) {
					oModel.setProperty(`/searchItems/${oBindingIndex}/NonIndustryFocused`, {
						Guid: element.Guid,
						IsSelected: false,
						IsVisible: true,
						ID: element.ID
					});
					if (oEmployeeBAIndustry && oEmployeeBAIndustry.Guid === element.Guid) {
						aEmployeeBAIndustries = [{
							Guid: element.Guid,
							Desc: element.Desc,
							IsPrimary: false,
							IsNonFocused: true,
							ID: element.ID
						}];
						oModel.setProperty(`/searchItems/${oBindingIndex}/NonIndustryFocused`, {
							Guid: element.Guid,
							IsSelected: true,
							IsVisible: true,
							ID: element.ID
						});
					}
				}
			});
			let aFilteredEmployeeBAIndustries = JSON.parse(JSON.stringify(aEmployeeBAIndustries));
			for (let i = 0; i < aEmployeeBAIndustries.length; i++) {
				const iIndex = aBAIndustries.findIndex(item => item.Guid === aEmployeeBAIndustries[i].Guid);
				if (iIndex === -1) {
					aFilteredEmployeeBAIndustries = aFilteredEmployeeBAIndustries.filter(item => item.Guid !== aEmployeeBAIndustries[i].Guid);
				}
			}
			oModel.setProperty(`/searchItems/${oBindingIndex}/TempEmployee/BAIndustries`, aFilteredEmployeeBAIndustries);

			oModel.setProperty(`/searchItems/${oBindingIndex}/TempEmployee/TempBAIndustries`, JSON.parse(JSON.stringify(oTempEmployee.BAIndustries)));
			oModel.setProperty(`/searchItems/${oBindingIndex}/BAIndustries`, aBAIndustries);
			oModel.refresh(true);
		},
		/*Load Role type master data*/
		loadRoleTypeData: function (type, results) {
			//MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
			//get IAC (Internal Account Classification) and Role,Role Area mapping #git84
			this.oSLASearchContext = false;
			this.getView().setModel(new sap.ui.model.json.JSONModel([]), "IACRoleAreaModel");
			sap.ui.core.BusyIndicator.show();
			const ointicSystemModel = models.systeminticDataModel(this);
			const oResourcesSystemModel = models.systemResourcesDataModel(this);
			this.getOwnerComponent().getModel("appConstants").setProperty("/IAC_ENABLE/0/isIACQueryRemove", false);
			const that = this;
			const isIACEnabled = this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/Operational_Status");
			var sEngagementType=this.getOwnerComponent().getModel("mrrAppEngModel").getData().engagementSelectedKey
			if (isIACEnabled) {
				const IAC = appView.oFinalData.iacValue;
				const sUrlParams = IAC ? {
					$filter: `EngTypeId eq '${sEngagementType}' and IacDesc eq '${IAC}' and RequestType eq '${appView.oFinalData.RequestType}'`,
					$expand: 'to_rolemap,to_subrolemap'
				} : {
					$filter: `EngTypeId eq '${sEngagementType}' and IacDesc eq 'Non-IAC Focused' and RequestType eq '${appView.oFinalData.RequestType}'`,
					$expand: 'to_rolemap,to_subrolemap'
				};
				if (!IAC) {
					that.getOwnerComponent().getModel("appConstants").setProperty("/IAC_ENABLE/0/isIACQueryRemove", true);
				}
				that._formRoleRoleAreaData(oResourcesSystemModel, sUrlParams, that);
			} else {
				//IAC Not enabled for Role, Role Area mapping
				let sUrlParams = {
					$filter: `EngTypeId eq '${sEngagementType}' and IacDesc eq 'Non-IAC Focused' and RequestType eq '${appView.oFinalData.RequestType}'`,
					$expand:'to_rolemap,to_subrolemap'
				};
				that.getOwnerComponent().getModel("appConstants").setProperty("/IAC_ENABLE/0/isIACQueryRemove", true);
				that._formRoleRoleAreaData(oResourcesSystemModel, sUrlParams, that);
			}
		},
		_formRoleRoleAreaData: async function (oResourcesSystemModel,sUrlParams,that) {
			var data
			try {
				if (appView.getOwnerComponent().getModel("mrrAppEngModel").getProperty("/previousServiceCallResponses")) {
					if (appView.getOwnerComponent().getModel("mrrAppEngModel").getProperty("/previousServiceCallResponses").get("/YC_MR_M_IAC_ACV_RAMAP" + JSON.stringify(sUrlParams))) {
						data = appView.getOwnerComponent().getModel("mrrAppEngModel").getProperty("/previousServiceCallResponses").get("/YC_MR_M_IAC_ACV_RAMAP" + JSON.stringify(sUrlParams))
					} else {
						data = await models._callGETOdata(oResourcesSystemModel, `/YC_MR_M_IAC_ACV_RAMAP`, sUrlParams)
						var mPrevServiceCallRespMap = appView.getOwnerComponent().getModel("mrrAppEngModel").getProperty("/previousServiceCallResponses")
						mPrevServiceCallRespMap.set("/YC_MR_M_IAC_ACV_RAMAP" + JSON.stringify(sUrlParams), data)
						appView.getOwnerComponent().getModel("mrrAppEngModel").setProperty("/previousServiceCallResponses", mPrevServiceCallRespMap)
					}
				} else {
					data = await models._callGETOdata(oResourcesSystemModel, `/YC_MR_M_IAC_ACV_RAMAP`, sUrlParams)
					var mPrevServiceCallRespMap = new Map()
					mPrevServiceCallRespMap.set("/YC_MR_M_IAC_ACV_RAMAP" + JSON.stringify(sUrlParams), data)
					appView.getOwnerComponent().getModel("mrrAppEngModel").setProperty("/previousServiceCallResponses", mPrevServiceCallRespMap)
				}
				sap.ui.core.BusyIndicator.hide();
				that.getView().getModel("IACRoleAreaModel").setData(data.results);
				const aIACRoleArea = that.getView().getModel("IACRoleAreaModel").getData(),
					aFilteredRoleRoleArea = [];
				let aRoleMasterWithoutDuplicates;
				aIACRoleArea.forEach(function (item) {
					let aIACRoleAreaList = item.to_rolemap.results;
					let aIACRoleAreaSubList = item.to_subrolemap.results;
					let aRolesData = [];
					let aSubst = [];
					aIACRoleAreaSubList.forEach(function (sub) {
						let oSubst = {
							"RoleID": sub.RoleSubstitute_ID,
							"RoleAreaID": sub.RoleAreaSubstitute_ID,
							"RoleDesc": sub.RoleSubstitute_Desc
						}
						aSubst.push(oSubst);
					});
					item.aSubstituteRoleRoleArea = aSubst;
					aIACRoleAreaList.forEach(function (rolesData) {
						let oRolesList = {
							"RoleID": rolesData.Role_ID,
							"RoleDesc": rolesData.Role_Desc,
							"RoleAreaID": item.RoleAreaId
						}
						aRolesData.push(oRolesList);
					});
					item.RolesData = aRolesData;
				});
				aIACRoleArea.forEach(function (data) {
					aRoleMasterWithoutDuplicates = {
						"RoleID": data.to_rolemap.results[0].Role_ID,
						"RoleDesc": data.to_rolemap.results[0].Role_Desc,
						"RolesData": data.RolesData,
						"RoleAreaID": data.RoleAreaId,
						"RoleAreaDesc": data.RoleAreaDesc,
						"aSubstituteRoleRoleArea": data.aSubstituteRoleRoleArea,
						"minSelect": Number(data.MinSelect),
						"maxSelect": Number(data.MaxSelect),
						"SolnAreaMandatory": data.SolnAreaMandatory,
						"SolnAreaSelectable": data.SolnAreaSelectable == 'X' ? true : false,
						"BAIndustryMandatory": data.BAIndustryMandatory,
						"BAIndustrySelectable": data.BAIndustrySelectable == 'X' ? true : false,
						"RoleAreas": [
							{
								"ID": data.RoleAreaId,
								"Desc": data.RoleAreaDesc,
								"RoleDesc": data.to_rolemap.results[0].Role_Desc
							}
						],
						"ID": data.to_rolemap.results[0].Role_ID,
						"Desc": data.to_rolemap.results[0].Role_Desc
					}
					aFilteredRoleRoleArea.push(aRoleMasterWithoutDuplicates);
				});
				const i18nModel = that.getOwnerComponent().getModel("i18n").getResourceBundle();
				var sEngagementType = that.getOwnerComponent().getModel("mrrAppEngModel").getData().engagementSelectedKey
				if (!aFilteredRoleRoleArea.length) {
					//IAC is invalid or no Role, Role Area mapping
					//call non-iac focused(default) to fetch all the role,roleArea master data
					that.getOwnerComponent().getModel("appConstants").setProperty("/IAC_ENABLE/0/isIACQueryRemove", true);
					let sUrlParams = {
						$filter: `EngTypeId eq '${sEngagementType}' and IacDesc eq 'Non-IAC Focused' and RequestType eq '${appView.oFinalData.RequestType}'`,
						$expand: 'to_rolemap,to_subrolemap'
					};
					that._formRoleRoleAreaData(oResourcesSystemModel, sUrlParams, that);
					return;
				}
				that.fnMasterDataSuccess("roleMasterWithoutDuplicate", aFilteredRoleRoleArea);
				that.fnMasterDataSuccess("roleMaster", aFilteredRoleRoleArea);
				that.fnMasterDataSuccess("roleAreas", aFilteredRoleRoleArea);
				//get solution Area master data
				if (!that.getOwnerComponent().getModel("SolutionAreaMasterData").getData().solHierarchy.length && sEngagementType !== '0002') {
					models.getSolutionAreaMasterData(that)
				}
				//MR: [GRP02-03] GTM25 Resource Profile alignment #84 end

			} catch (oError) {
				sap.ui.core.BusyIndicator.hide();
				ErrorHandle.setErrorMessage(oError, that);
			}			
		},
		fnMasterDataSuccess: function (sModelName, aResults) {			
			this.getView().setModel(new sap.ui.model.json.JSONModel(), sModelName);
			const oModel = this.getView().getModel(sModelName);
			oModel.setData(aResults);
			if(this.getOwnerComponent().getModel("mrrAppEngModel").getData().engagementSelectedKey=='0002' && sModelName=="roleAreas"){
				this.getView().getModel("employee").getData().searchItems[0].SelectedRoleAreasKey=aResults[0].RoleAreaID
				this.getView().getModel("employee").refresh(true)
				this.getView().byId("inputExtended").setSelectedItem(aResults[0])
				this.getView().byId("inputExtended").fireSelectionChange({selectedItem:aResults[0]})
			}
		},
		/*Search event for business area industries*/
		onSearchBAIndustry: function (oEvent) {
			let sQuery = "";
			if (oEvent) {
				sQuery = oEvent.getSource().getValue();
			}
			let allFilter = [];
			if (sQuery && sQuery.length > 0) {
				const oFilter1 = new sap.ui.model.Filter("Desc", sap.ui.model.FilterOperator.Contains, sQuery);
				const oFilter2 = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.Contains, sQuery);
				const oFilter3 = new sap.ui.model.Filter("ClusterDesc", sap.ui.model.FilterOperator.Contains, sQuery);
				allFilter = new sap.ui.model.Filter([oFilter1, oFilter2, oFilter3], false);
			}
			this.fnFilterNonFocusedTableData(sQuery, "baIndustrytableId", allFilter);
		},
		/*Select event for business area industries*/
		onSelectBAIndustry: function (oEvent) {
			const oSource = oEvent.getSource();
			const oBinding = oSource.getBindingInfo("selected").binding;
			const oContext = oBinding.getContext();
			const oModel = oContext.getModel();
			const oBAIndustry = oModel.getProperty(oContext.getPath());
			const bSelected = oEvent.getParameter("selected");
			const aEmployeeBAIndustries = oModel.getProperty("/TempEmployee/TempBAIndustries");
			const iIndex = aEmployeeBAIndustries.findIndex(item => item.Guid === oBAIndustry.Guid);
			const aBAIndustries = oModel.getProperty("/BAIndustries");
			aBAIndustries.forEach(item => item.IsSelected = false);
			aEmployeeBAIndustries.length = 0; 
		
			oBAIndustry.IsSelected = true;
			
			aEmployeeBAIndustries.push({
				Guid: oBAIndustry.Guid,
				Desc: oBAIndustry.Desc,
				ClusterGuid: oBAIndustry.ClusterGuid,
				ClusterDesc: oBAIndustry.ClusterDesc,
				IsPrimary: true,
				BaIndTechID: oBAIndustry.BaIndTechID,
				BaIndId: oBAIndustry.BaIndId
			});
		
			oModel.refresh(true);
		},
		/*Select All Business area industies*/
		onSelectAllBAIndustry: function (oEvent) {
			const oModel = this.getView().getModel("employee");
			const bSelected = oEvent.getParameter("selected");
			let aBAIndustries = oModel.getProperty("/BAIndustries");
			let aEmployeeBAIndustries = [];
			aBAIndustries.map(function (item) {
				item.IsSelected = bSelected;
				item.IsPrimary = (bSelected === true && item.IsPrimary === true) ? true : false;
				if (bSelected && item.IsNonFocused === false) {
					aEmployeeBAIndustries.push({
						Guid: item.Guid,
						Desc: item.Desc,
						ClusterGuid: item.ClusterGuid,
						ClusterDesc: item.ClusterDesc,
						IsPrimary: false,
						BaIndTechID: item.BaIndTechID,
						BaIndId: item.BaIndId
					});
				}
			});
			oModel.setProperty("/TempEmployee/TempBAIndustries", aEmployeeBAIndustries);
			oModel.refresh(true);
		},
		/*Update business area industries*/
		onChangeBAIndustries: function (oEvent) {
			const oModel = this.getView().getModel("masterDataModel");
			const oBindingIndex = oModel.getProperty("/iIndex");
			const aEmployeeBAIndustries = oModel.getProperty("/TempEmployee/TempBAIndustries");
			const oEmployeeModel = this.getView().getModel("employee");
			oEmployeeModel.setProperty(`/searchItems/${oBindingIndex}/TempEmployee/BAIndustries`, JSON.parse(JSON.stringify(aEmployeeBAIndustries)));
			if(oEvent)
				this.onCloseBAIndustryValueHelpDialog();
			let oSelectParams = {
				"bIndustry":true,
				"iBindingIndex":oBindingIndex,
				"minSelect":oEmployeeModel.getProperty(`/searchItems/${oBindingIndex}/minSelect`),
				"maxSelect":oEmployeeModel.getProperty(`/searchItems/${oBindingIndex}/maxSelect`),
			}
			this._onManageIndSolSelection(oSelectParams);
			this._onEnableSearchResources(oBindingIndex,oSelectParams);
			this._setSearchFieldText(oBindingIndex);
		},
		//manage selection for industry and solution area
		_onManageIndSolSelection:function(oSelectParams,bDelete){
			let oModel =  this.getView().getModel("employee"),
				iBindingIndex = oSelectParams["iBindingIndex"]
			if(oSelectParams["maxSelect"] === 1 && !bDelete){
				oSelectParams["bIndustry"] ? oModel.setProperty(`/searchItems/${iBindingIndex}/solnAreaEnable`,false) : 
				oModel.setProperty(`/searchItems/${iBindingIndex}/industryEnable`,false);
			}else if(oSelectParams["maxSelect"] === 2 || bDelete){
				oModel.setProperty(`/searchItems/${iBindingIndex}/solnAreaEnable`,true);
				oModel.setProperty(`/searchItems/${iBindingIndex}/industryEnable`,true);
			}
			if (oModel.getProperty(`/searchItems/${iBindingIndex}/industryEnable`) && oSelectParams["maxSelect"] === 1 && !bDelete) {
				oModel.setProperty(`/searchItems/${iBindingIndex}/TempEmployee/SolutionAreas`, [])
			} else if (oSelectParams["maxSelect"] === 1 && bDelete) {
				oModel.setProperty(`/searchItems/${iBindingIndex}/TempEmployee/BAIndustries`, []);
				this.getView().getModel("employee").setProperty(`/searchItems/${iBindingIndex}/TempEmployee/TempBAIndustries`, []);
			}
			oModel.refresh();
		},
		/*Close business area industries fragment*/
		onCloseBAIndustryValueHelpDialog: function () {
			const oModel = this.getView().getModel("masterDataModel");
			const oBindingIndex = oModel.getProperty("/iIndex");
			const aEmployeeBAIndustries = oModel.getProperty("/TempEmployee/BAIndustries");
			const oEmployeeModel = this.getView().getModel("employee");
			oEmployeeModel.setProperty(`/searchItems/${oBindingIndex}/TempEmployee/TempBAIndustries`, JSON.parse(JSON.stringify(aEmployeeBAIndustries)));
			this.getView().getModel("employee").setProperty("/sSearchBoxText", "");
			const that = this;
			this.pBAIndustryValueHelpDialog.then(function (oDialog) {
				that.onSearchBAIndustry();
				oDialog.close();

			});
		},
		/*Change selection to NonIndustyFoused*/
		onChangeNonIndustryFocused: function (oEvent) {
			const oModel = this.getView().getModel("masterDataModel");
			const oBindingIndex = oModel.getProperty("/iIndex");
			const oEmployeeModel = this.getView().getModel("employee");
			const bSelected = oEvent.getParameter("state");
			const aBAIndustries = oModel.getProperty("/BAIndustries");
			let oNonIndustryFocused;
			aBAIndustries.map(function (element, index, array) {
				if (bSelected && element.IsNonFocused) {
					element.IsSelected = true;
					element.IsPrimary = true;
					oNonIndustryFocused = element;
				} else {
					element.IsSelected = false;
					element.IsPrimary = false;
				}
			});

			if (bSelected && oNonIndustryFocused) {
				oModel.setProperty("/TempEmployee/TempBAIndustries", [{
					Guid: oNonIndustryFocused.Guid,
					Desc: oNonIndustryFocused.Desc,
					IsPrimary: false,
					IsNonFocused: true,
					BaIndTechID: oNonIndustryFocused.ID,
					BaIndId: oNonIndustryFocused.ID
				}]);
				oEmployeeModel.setProperty(`/searchItems/${oBindingIndex}/TempEmployee/TempBAIndustries`, [{
					Guid: oNonIndustryFocused.Guid,
					Desc: oNonIndustryFocused.Desc,
					IsPrimary: false,
					IsNonFocused: true,
					BaIndTechID: oNonIndustryFocused.ID,
					BaIndId: oNonIndustryFocused.ID
				}]);
				oModel.setProperty("/NonIndustryFocused", {
					Guid: oNonIndustryFocused.Guid,
					IsSelected: true,
					IsVisible: true
				});
				oEmployeeModel.setProperty(`/searchItems/${oBindingIndex}/NonIndustryFocused`, {
					Guid: oNonIndustryFocused.Guid,
					IsSelected: true,
					IsVisible: true
				});
			} else {
				oModel.setProperty("/TempEmployee/TempBAIndustries", []);
				oEmployeeModel.setProperty(`/searchItems/${oBindingIndex}/TempEmployee/TempBAIndustries`, []);
				oModel.setProperty("/NonIndustryFocused", {
					Guid: "",
					IsSelected: false,
					IsVisible: true
				});
				oEmployeeModel.setProperty(`/searchItems/${oBindingIndex}/NonIndustryFocused`, {
					Guid: "",
					IsSelected: false,
					IsVisible: true
				});
			}
		},
		fnFilterNonFocusedTableData: function (sQuery, tableId, allFilter) {
			const oNonFocusedFilter = new sap.ui.model.Filter("IsNonFocused", sap.ui.model.FilterOperator.EQ, false);
			const aFilters = new sap.ui.model.Filter([allFilter, oNonFocusedFilter], true);
			this.getView().byId(tableId).getBinding().filter(aFilters);
		},
		/*Token updated delete Business Area Industry*/
		onDeleteBAIndToken: function (oEvent) {
			const oSource = oEvent.getSource();
			const oBindingIndex = Number(oSource.getBindingContext("employee").getPath().split('/')[2]);
			this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/iIndex`, oBindingIndex);
			const oModel = this.getView().getModel("employee");
			const oTempEmployee = oModel.getProperty(`/searchItems/${oBindingIndex}/TempEmployee`);
			const oParameters = oEvent.getParameters();
			if (oParameters.type === "removed") {
				const aTokens = oParameters.removedTokens;
				for (let i = 0; i < aTokens.length; i++) {
					const iIndex = oTempEmployee.BAIndustries.findIndex(item => item.Guid === aTokens[i].getKey());
					if (iIndex !== -1) {
						oTempEmployee.BAIndustries.splice(iIndex, 1);
						oTempEmployee.TempBAIndustries = oTempEmployee.BAIndustries;
						oModel.refresh(true);
					}
				}
			}
			this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}`)
			let oSelectParams = {
				"bIndustry":true,
				"iBindingIndex":oBindingIndex,
				"minSelect":oModel.getProperty(`/searchItems/${oBindingIndex}/minSelect`),
				"maxSelect":oModel.getProperty(`/searchItems/${oBindingIndex}/maxSelect`),
			}
			this._onManageIndSolSelection(oSelectParams,true)
			this._setSearchFieldText(oBindingIndex);
			this._onEnableSearchResources(oBindingIndex,oSelectParams);
		},
		_getServiceUrl: function (i,ApproversBaseUrl, sProfitcenter, tableTypeId, isSubsFlag) {
			const filterValues = {
				"TableTypeID": tableTypeId,
				"Manager_Level": "non-managerial",
				"aRoles":this.getView().getModel("employee").getProperty(`/searchItems/${i}/TempEmployee/TempRoles`).RolesData,
				"aSubsRoles":this.getView().getModel("employee").getProperty(`/searchItems/${i}/TempEmployee/TempRoles`).aSubstituteRoleRoleArea,
			};
			const sManagerLevel = `(ManagerLevel eq 'non-managerial')`;
			const aSolAreas = this.getView().getModel("employee").getData().searchItems[i].TempEmployee.SolutionAreas;
			const baIndustriesGuid = this.getView().getModel("employee").getData().searchItems[i].TempEmployee.BAIndustries;
			const baIndustries_GUIDs = baIndustriesGuid.map(item => item.BaIndId);
			const filterCondition1 = baIndustries_GUIDs.length ? `(${baIndustries_GUIDs.map(BaIndId => `(BaIndId eq '${BaIndId}')`).join(' or ')})` :
				`(BaIndId eq '')`;
			const aSolAreas_GUIDs = aSolAreas ? aSolAreas.map(item => item.soln_id) : [];
			const parentSolIds = aSolAreas ? aSolAreas.map(item => item.prnt_soln_id) : [];
			let filterConditionSolAreas = "";
			let filterParts = [];

			aSolAreas_GUIDs.forEach((soln_id, index) => {
				const relatedArea = aSolAreas[index];
				const parentSolId = parentSolIds[index];
				if (relatedArea?.soln_prnt_guid === "00000000-0000-0000-0000-000000000000") {
					filterParts.push(`(SolAreaL1Id eq '${soln_id}' and SolAreaL2Id eq '')`);
				} else {
					filterParts.push(`(SolAreaL2Id eq '${soln_id}' and SolAreaL1Id eq '${parentSolId}')`);
				}
			});

			filterConditionSolAreas = filterParts.length
				? `(${filterParts.join(' or ')})`
				: `(SolAreaL1Id eq '' and SolAreaL2Id eq '')`;
			//multiple profit center
			const aSelectedProfitCenter = JSON.parse(JSON.stringify(this.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories));
			for (let i = 0; i < aSelectedProfitCenter.length; i++) {
				if (!aSelectedProfitCenter[i].isCheckBox || !aSelectedProfitCenter[i].isResourceProfile) {
					aSelectedProfitCenter.splice(i, 1)
				}
			}
			const aFinalPfc = aSelectedProfitCenter.filter((obj1, i, arr) =>
				arr.findIndex(obj2 => (obj2.SelectedGuid === obj1.SelectedGuid)) === i
			);
			const aSelectedPfcGuids = aFinalPfc.map(item => item.TrpcId);
			const filterCondition5 = aSelectedPfcGuids.length ? `(${aSelectedPfcGuids.map(SelectedGuid => `(TrpcId eq '${SelectedGuid}')`).join(' or ')})` : `(TrpcId  eq '')`;
			//role data
			const aRoleIds = isSubsFlag ? filterValues.aSubsRoles.map(item => item.RoleID):filterValues.aRoles.map(item => item.RoleID);
			const aUniqueRoleIds = aRoleIds.filter((item, index) => aRoleIds.indexOf(item) === index);
			const filterConditionForRoles = aUniqueRoleIds.length ? `(${aUniqueRoleIds.map(roleId => `RoleId eq '${roleId}'`).join(' or ')})` :
				`(RoleId eq '')`;

			//filter condition for Role Areas
			const aRoleAreaIds = isSubsFlag ? filterValues.aSubsRoles.map(item => item.RoleAreaID) : filterValues.aRoles.map(item => item.RoleAreaID);
			const aUniqueRoleAreaIds = aRoleAreaIds.filter((item, index) => aRoleAreaIds.indexOf(item) === index);
			const filterConditionForRoleArea = aUniqueRoleAreaIds.length ? `(${aUniqueRoleAreaIds.map(roleAreaId => `RoleAreaId eq '${roleAreaId}'`).join(' or ')})` :
				`(RoleAreaId eq '')`;
			//set Role payload
			const aFinaRole = isSubsFlag ? filterValues.aSubsRoles:filterValues.aRoles;
			this.getView().getModel("employee").setProperty("/aFinalRolePaylod",aFinaRole);
			let finalFilterString =
			`$filter=${sManagerLevel} and (TableTypeId eq '${filterValues.TableTypeID}') and 
						${filterConditionForRoles} and ${filterConditionForRoleArea} and (RecordStatus eq '01')`;
			
			let aIACID = this.getView().getModel("IACRoleAreaModel").getData() ? this.getView().getModel("IACRoleAreaModel").getData()[0].IacId : "";
			let filterConditionIAC = `(IacValue eq '${aIACID}')`;
			const filterConditions = [filterCondition5];
			if(this.getView().getModel("employee").getProperty(`/searchItems/${i}/BAIndustrySelectable`)){
				//push only if industry field is selectable/visible
				filterConditions.push(filterCondition1);
			}
			if(this.getView().getModel("employee").getProperty(`/searchItems/${i}/SolnAreaSelectable`)){
				//push only if solution area is selectable/visible
				filterConditions.push(filterConditionSolAreas);
			}
			if(this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/Operational_Status") && !this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/isIACQueryRemove") && (this.getOwnerComponent().getModel("mrrAppEngModel").getData().engagementSelectedKey!=='0002')){
				filterConditions.push(filterConditionIAC)
			}
			const nonEmptyFilters = filterConditions.filter(condition => condition !== '');

			if (nonEmptyFilters.length > 0) {
				finalFilterString += ' and ';
				finalFilterString += nonEmptyFilters.join(' and ');
			}
			return `${finalFilterString}&$expand=to_substitute`;
		},
		/*Enable Search resources*/
		_onEnableSearchResources: function (oBindingIndex,oSelectedParams) {
			const oModel = this.getView().getModel("employee");
			const oTempEmployee = oModel.getProperty(`/searchItems/${oBindingIndex}/TempEmployee`);
			const oSearchItem = oModel.getProperty(`/searchItems/${oBindingIndex}`);
			if(this.getOwnerComponent().getModel("mrrAppEngModel").getData().engagementSelectedKey=='0002' && oSearchItem.selectedPfc && oSearchItem.SelectedRoleAreasKey!=""){
				oModel.setProperty(`/searchItems/${oBindingIndex}/isValidation`, true);
			}else{
			if ((oSearchItem.selectedPfc && oTempEmployee["TempRoles"] && oTempEmployee.TempRoles.RoleAreaID && (!oSearchItem.SolnAreaMandatory || !oSearchItem.SolnAreaSelectable) &&
				(!oSearchItem.BAIndustryMandatory || !oSearchItem.BAIndustryMandatory)) || (oSearchItem.selectedPfc && oTempEmployee["TempRoles"] && oTempEmployee.TempRoles.RoleAreaID && (oSearchItem.SolnAreaMandatory && oTempEmployee.SolutionAreas.length) &&
					(oSearchItem.BAIndustryMandatory && oTempEmployee.BAIndustries.length)) ||
				(oSearchItem.selectedPfc && oTempEmployee["TempRoles"] && oTempEmployee.TempRoles.RoleAreaID && oTempEmployee.TempRoles.RoleAreaID && (!oSearchItem.SolnAreaMandatory || !oSearchItem.SolnAreaSelectable) &&
					(oSearchItem.BAIndustryMandatory && oTempEmployee.BAIndustries.length)) ||
				(oSearchItem.selectedPfc && oTempEmployee["TempRoles"]  && oTempEmployee.TempRoles.RoleAreaID && (oSearchItem.SolnAreaMandatory && oTempEmployee.SolutionAreas.length) && (!oSearchItem.BAIndustryMandatory || !oSearchItem.BAIndustryMandatory))) {
				//if industry and solution area optional or non selectable enable create draft
				oModel.setProperty(`/searchItems/${oBindingIndex}/isValidation`, true);
			} else {
				oModel.setProperty(`/searchItems/${oBindingIndex}/isValidation`, false);
			}
			if(!oSelectedParams && oModel.getProperty(`/searchItems/${oBindingIndex}/isValidation`) && this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/minSelect`) !== 0){
				oModel.setProperty(`/searchItems/${oBindingIndex}/isValidation`, false);
			}
			if((oSelectedParams && oModel.getProperty(`/searchItems/${oBindingIndex}/isValidation`) && oSelectedParams["minSelect"] == 1 && (!oTempEmployee.BAIndustries.length && !oTempEmployee.SolutionAreas.length)) || (oSelectedParams && oModel.getProperty(`/searchItems/${oBindingIndex}/isValidation`) && oSelectedParams["minSelect"] == 2 && (!oTempEmployee.BAIndustries.length || !oTempEmployee.SolutionAreas.length))){
				oModel.setProperty(`/searchItems/${oBindingIndex}/isValidation`, false);
			}
			}
			this._searchResourceValidation();
		},
		//search resource validation
		_searchResourceValidation:function(){
			const aSearchItems = this.getView().getModel("employee").getProperty("/searchItems");
			const isAllValidated = aSearchItems.every(element => element.isValidation === true);
			if(isAllValidated){
				appView.getView().getModel("createReqFooterModel").setProperty
				("/footerButtons/searchResourceButtonEnabled", true);
			}else{
				appView.getView().getModel("createReqFooterModel").setProperty
				("/footerButtons/searchResourceButtonEnabled", false);
			}
			appView.getView().getModel("createReqFooterModel").refresh();	
		},
		/*Select event for Roles*/
		onRoleChange: function (oEvent) {
			const oSource = oEvent.getSource();
			const oBindingIndex =oSource.getBindingContext("employee")? Number(oSource.getBindingContext("employee").getPath().split('/')[2]):0
			this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/iIndex`, oBindingIndex);
			const oModel = this.getView().getModel("employee");
			const oSelectectedItem = oSource.getSelectedItem()?oSource.getSelectedItem():oEvent.getParameter("selectedItem")
			const oTempEmployee = oModel.getProperty(`/searchItems/${oBindingIndex}/TempEmployee`);
			let tempRoleArea = [];
			if (oSelectectedItem) {
				
				if(oSelectectedItem.ID){
					 var oContextObj=oSelectectedItem
				}else{
					var oContext = oSelectectedItem.getBindingContext("roleAreas");
					 var oContextObj = oContext.getObject();
				}
				//set field config based on role area
				this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/BAIndustryMandatory`,oContextObj.BAIndustryMandatory);
				this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/BAIndustrySelectable`,oContextObj.BAIndustrySelectable);
				this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/SolnAreaMandatory`,oContextObj.SolnAreaMandatory);
				this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/SolnAreaSelectable`,oContextObj.SolnAreaSelectable);
				this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/minSelect`,oContextObj.minSelect);
				this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/maxSelect`,oContextObj.maxSelect);
				if(oContextObj.RoleAreaID === "0006" || oContextObj.RoleAreaID === "0003" ){
					this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/fieldSelectionMidInfoIcon`,true);
				}else{
					this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/fieldSelectionMidInfoIcon`,false);
				}

				if(oContextObj.RoleAreaID === "0005"){
					//for industry advisory
					this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/midSectionDesc`,
						appView.getOwnerComponent().
							getModel("mrrAppConfigModel").getProperty("/Ind_SelectionText/0/fieldDesc")
					);
				}else{
					this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/midSectionDesc`,
						appView.getOwnerComponent().
							getModel("mrrAppConfigModel").getProperty("/SolnInd_SelectionText/0/fieldDesc")
					);
				}
				
				this.getView().getModel("employee").refresh();
				if(!oContext){
					var oRole=oSelectectedItem
					oTempEmployee.Roles.push(oRole)
				tempRoleArea.push(...oRole.RoleAreas);
				}else{
				var oRoleModel = oContext.getModel();
				var oRole = oRoleModel.getProperty(oContext.getPath());
				oTempEmployee.Roles.push(oRole)
				tempRoleArea.push(...oRole.RoleAreas);
				}
				this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/TempEmployee/TempRoles`,oRole)
			}else{
				var bEngagementType=this.getOwnerComponent().getModel("mrrAppEngModel").getData().engagementSelectedKey==='0001'?true:false
				this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/BAIndustryMandatory`,false);
				this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/BAIndustrySelectable`,bEngagementType);
				this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/SolnAreaSelectable`,bEngagementType);
				this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/minSelect`,0);
				this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/maxSelect`,2);
				this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/fieldSelectionMidInfoIcon`,false);
				this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/midSectionDesc`,appView.getOwnerComponent().
                getModel("mrrAppConfigModel").getProperty("/SolnInd_SelectionText/0/fieldDesc"));
				this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/TempEmployee/TempRoles`,[])
				this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/solnIndRequired`, false);
			}
			this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/TempEmployee/BAIndustries`, []);
			this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas`, []);
			this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/TempEmployee/AdditionalSolutions`, []);
			this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/TempEmployee/Materials`, []);
			this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/TempEmployee/TempBAIndustries`, []);
			this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas`, []);
			this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/solnAreaEnable`, true);
			this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/industryEnable`, true);
			if(this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/minSelect`) === 0){
				this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/solnIndRequired`, false);
			}else{
				this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/solnIndRequired`, true);
			}
			
			let aNewRoleArea = [];
			let map = new Map();
			for (let item of tempRoleArea) { //Removing dupliated from aray..
				if (!map.has(item.Guid)) {
					map.set(item.Guid, true);
					aNewRoleArea.push(item);
				}
			}
			oModel.setProperty(`/searchItems/${oBindingIndex}/SelectedRoleAreasKey`, "");
			if (aNewRoleArea && aNewRoleArea.length === 1) {
				oTempEmployee.RoleAreas.push(aNewRoleArea[0]);
				oModel.setProperty(`/searchItems/${oBindingIndex}/SelectedRoleAreasKey`, aNewRoleArea[0].ID);
			}
			oModel.setProperty(`/searchItems/${oBindingIndex}/aRoleAreas`, aNewRoleArea);
			this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/TempEmployee/TempRoleAreas`,aNewRoleArea)
			oModel.refresh(true);
			// if (!(oSelectectedItem && oContextObj.RoleAreaID === "0005" && appView.oFinalData.INDUSTRY_MASTERCODE)) {
			this._setSearchFieldText(oBindingIndex);
			this._onEnableSearchResources(oBindingIndex);
			// }
			if (oSelectectedItem && oContextObj.RoleAreaID === "0005" && appView.oFinalData.INDUSTRY_MASTERCODE) {
				let aIndMasterData = this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/BAIndustries`);
				let aDefOppIndustry = aIndMasterData.filter(item => Number(item.BaIndTechID) === Number(appView.oFinalData.INDUSTRY_MASTERCODE));
				if (aDefOppIndustry.length) {
					// if (!this.getView().getModel("masterDataModel")) {
						this.getView().setModel(new sap.ui.model.json.JSONModel(), "masterDataModel");
						const oMasterDataModel = this.getView().getModel("masterDataModel");
						oMasterDataModel.setData(this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}`));
						this.getView().getModel("masterDataModel").refresh();
					// }
					const aEmployeeBAIndustries = [{
						Guid: aDefOppIndustry[0].Guid,
						Desc: aDefOppIndustry[0].Desc,
						ClusterGuid: aDefOppIndustry[0].ClusterGuid,
						ClusterDesc: aDefOppIndustry[0].ClusterDesc,
						IsPrimary: true,
						BaIndTechID: aDefOppIndustry[0].BaIndTechID,
						BaIndId: aDefOppIndustry[0].BaIndId
					}];
					this.getView().getModel("masterDataModel").setProperty("/TempEmployee/TempBAIndustries", JSON.parse(JSON.stringify(aEmployeeBAIndustries)));
					this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/TempEmployee/TempBAIndustries`, JSON.parse(JSON.stringify(aEmployeeBAIndustries)));
					this.onChangeBAIndustries();
				}
			}
		},
		/*Select event for Role area*/
		onRoleAreaChange: function (oEvent) {
			const oSource = oEvent.getSource();
			const oModel = this.getView().getModel("employee");
			const oSelectectedItem = oSource.getSelectedItem();
			const oTempEmployee = oModel.getProperty("/TempEmployee");
			let tempRoleArea = [];
			if (oSelectectedItem) {
				const oContext = oSelectectedItem.getBindingContext("employee");
				const oRoleAreaModel = oContext.getModel();
				const oRoleArea = oRoleAreaModel.getProperty(oContext.getPath());
				oTempEmployee.RoleAreas.push(oRoleArea)
				this.getView().getModel("employee").setProperty("/TempEmployee/TempRoleAreas",[oRoleArea])
			}
			oModel.refresh(true);
			this._onEnableSearchResources();
		},
		/*Set ORE Service Url for search managers*/
		_getOREServiceUrl: function (i,ApproversOREUrl, sProfitcenter, sSearchOre,isSubsFlag) {
			const sProfitCenterId = appView.listView.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories.length ? appView.listView.getView().getModel("selectedProfitCenter").getData().
				TempProfitCenter.Territories[0].TrpcId : appView.listView.getView().getModel("selectedProfitCenter").getData().
					filteredProfitCenter[0].TrpcId;
			const filterValues = {
				"ProfitCenterGUID": sProfitCenterId,
				"Manager_Level": "non-managerial",
				"aRoles":this.getView().getModel("employee").getProperty(`/searchItems/${i}/TempEmployee/TempRoles`).RolesData,
				"aSubsRoles":this.getView().getModel("employee").getProperty(`/searchItems/${i}/TempEmployee/TempRoles`).aSubstituteRoleRoleArea
			};
			const baIndustriesGuid = this.getView().getModel("employee").getData().searchItems[i].TempEmployee.BAIndustries;
			
			const generateFilterConditions = (propertyName, values) => {
				return values.length ? `${values.map(guid => `${propertyName} eq '${guid}'`).join(' or ')}` : "";
			};
			//multiple profit center
			const aSelectedProfitCenter = JSON.parse(JSON.stringify(this.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories));
			for (let i = 0; i < aSelectedProfitCenter.length; i++) {
				if (!aSelectedProfitCenter[i].isCheckBox || !aSelectedProfitCenter[i].isResourceProfile) {
					aSelectedProfitCenter.splice(i, 1)
				}
			}
			const aFinalPfc = aSelectedProfitCenter.filter((obj1, i, arr) =>
				arr.findIndex(obj2 => (obj2.SelectedGuid === obj1.SelectedGuid)) === i
			);
			//filter condition for Roles
			const aRoleIds = isSubsFlag ? filterValues.aSubsRoles.map(item => item.RoleID):filterValues.aRoles.map(item => item.RoleID);
			const aUniqueRoleIds = aRoleIds.filter((item, index) => aRoleIds.indexOf(item) === index);
			const filterConditionForRoles = aUniqueRoleIds.length ? `(${aUniqueRoleIds.map(roleId => `RoleId eq '${roleId}'`).join(' or ')})` :
				`(RoleId eq '')`;
			//filter condition for Role Areas
			const aRoleAreaIds = isSubsFlag ? filterValues.aSubsRoles.map(item => item.RoleAreaID) : filterValues.aRoles.map(item => item.RoleAreaID);
			const aUniqueRoleAreaIds = aRoleAreaIds.filter((item, index) => aRoleAreaIds.indexOf(item) === index);
			const filterConditionForRoleArea = aUniqueRoleAreaIds.length ? `(${aUniqueRoleAreaIds.map(roleAreaId => `RoleAreaId eq '${roleAreaId}'`).join(' or ')})` :
				`(RoleAreaId eq '')`;
			let finalFilterString = `$filter=${filterConditionForRoles} and ${filterConditionForRoleArea} and (MelodyRequest eq 'X')` + sSearchOre;
			if (aFinalPfc.length) {
				const multiple_pfc_GUIDs = aFinalPfc.map(item => item.TrpcId);
				const filterCondition10 = generateFilterConditions('Trtrypc', multiple_pfc_GUIDs);
				const filterCondition11 = generateFilterConditions('SecTrtrypc', multiple_pfc_GUIDs);
				finalFilterString += ` and (${filterCondition10} or ${filterCondition11})`;
			}
			if (baIndustriesGuid.length && this.getView().getModel("employee").getProperty(`/searchItems/${i}/BAIndustrySelectable`)) {
				const baIndustries_GUIDs = baIndustriesGuid.map(item => item.BaIndId);
				const filterCondition1 = generateFilterConditions('BaIndId', baIndustries_GUIDs);
				const filterCondition6 = generateFilterConditions('SecBaIndId', baIndustries_GUIDs);
				finalFilterString += ` and (${filterCondition1} or ${filterCondition6})`;
			}
			const aSolAreas = this.getView().getModel("employee").getData().searchItems[i].TempEmployee.SolutionAreas;
			
			if(aSolAreas.length && this.getView().getModel("employee").getProperty(`/searchItems/${i}/SolnAreaSelectable`)){
				const aSolAreas_GUIDs = aSolAreas ? aSolAreas.map(item => item.soln_id) : [];
				const parentSolIds = aSolAreas ? aSolAreas.map(item => item.prnt_soln_id) : [];
				let filterConditionSolAreas = "";
				let filterParts = [];
				
				aSolAreas_GUIDs.forEach((soln_id, index) => {
				  const relatedArea = aSolAreas[index];
					const parentSolId = parentSolIds[index]; 
				  if (relatedArea?.soln_prnt_guid === "00000000-0000-0000-0000-000000000000") {
					filterParts.push(`(SolL1Id eq '${soln_id}') or (SecSolL1Id eq '${soln_id}')`);
				  } else {
					filterParts.push(`(SolL2Id eq '${soln_id}' or SecSolL2Id eq '${soln_id}') and (SolL1Id eq '${parentSolId}' or SecSolL1Id eq '${parentSolId}')`);
				  }
				});
				filterConditionSolAreas = filterParts.length
				? `(${filterParts.join(' or ')})` : ``;
				finalFilterString += ` and ${filterConditionSolAreas}`;
			}
			let aIACID = this.getView().getModel("IACRoleAreaModel").getData() ? this.getView().getModel("IACRoleAreaModel").getData()[0].IacId : "";
			if(this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/Operational_Status") && !this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/isIACQueryRemove") && (this.getOwnerComponent().getModel("mrrAppEngModel").getData().engagementSelectedKey!=='0002')){
				finalFilterString += ` and (IacId eq '${aIACID}' or SecIacId eq '${aIACID}')`;
			}
			if(sProfitcenter[0].GrpSelectable === 'X'){
				let aSelGroup=this.getView().getModel("employee").getData().searchItems[i].TempEmployee?.SelectedGroup;
				if(aSelGroup?.length){
					finalFilterString+= ` and (GroupL${aSelGroup[0].LevelId}_ID eq '${aSelGroup[0].GroupID}' )`
				}
			}
			// let sEngagementType=this.getOwnerComponent().getModel("mrrAppEngModel").getData().engagementSelectedKey
			// finalFilterString += ` and (EngTypeId eq '${sEngagementType}')`
			finalFilterString += "&$select=Id,EmpName,EmailId,ManagerLevel,ManagerId,ManagerName,ManagerEmail,to_substitute";
			//set Role payload
			const aFinaRole = isSubsFlag ? filterValues.aSubsRoles:filterValues.aRoles;
			this.getView().getModel("employee").setProperty("/aFinalRolePaylod",aFinaRole);
			return `${finalFilterString}&$expand=to_substitute`;
		},
		_getServiceBSUrl: function(i,ApproversBaseUrl, sProfitcenter, tableTypeId,isSubsFlag) {
			const filterValues = {
                "TableTypeID": tableTypeId,
                "Manager_Level": "non-managerial",
				"aRoles":this.getView().getModel("employee").getProperty(`/searchItems/${i}/TempEmployee/TempRoles`).RolesData,
				"aSubsRoles":this.getView().getModel("employee").getProperty(`/searchItems/${i}/TempEmployee/TempRoles`).aSubstituteRoleRoleArea
            };
            const sManagerLevel = `((ManagerLevel eq 'non-managerial') or (ManagerLevel eq '*'))`;
            const baIndustriesGuid = this.getView().getModel("employee").getData().searchItems[i].TempEmployee.BAIndustries;
            const baIndustries_GUIDs = baIndustriesGuid.map(item => item.BaIndId);
			
            let filterCondition1 = baIndustries_GUIDs.length ? `(${baIndustries_GUIDs.map(BaIndId => `(BaIndId eq '${BaIndId}')`).join(' or ')} or (BaIndId eq '*'))` :
                "(BaIndId eq '')";
			let aSolAreas = this.getView().getModel("employee").getData().searchItems[i].TempEmployee.SolutionAreas;
			let filterConditionSolAreas = "";
			
			if (aSolAreas.length) {
				const filterParts = aSolAreas.map(item => {
					if (item.soln_prnt_guid === "00000000-0000-0000-0000-000000000000") {
						return `(SolAreaL1Id eq '${item.soln_id}' or SolAreaL1Id eq '*') and (SolAreaL2Id eq '')`;
					} else {
						return `(SolAreaL2Id eq '${item.soln_id}' or SolAreaL2Id eq '*') and (SolAreaL1Id eq '${item.prnt_soln_id}' or SolAreaL1Id eq '*')`
					}

				});
				filterConditionSolAreas = filterParts.join();
			}else{
				filterConditionSolAreas = "(SolAreaL2Id eq '' ) and (SolAreaL1Id eq '')";
			}


			  //multiple profit center
			  const aSelectedProfitCenter = JSON.parse(JSON.stringify(this.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories));
			  for (let i = 0; i < aSelectedProfitCenter.length; i++) {
				  if (!aSelectedProfitCenter[i].isCheckBox || !aSelectedProfitCenter[i].isResourceProfile) {
					  aSelectedProfitCenter.splice(i, 1)
				  }
			  }
			  const aFinalPfc = aSelectedProfitCenter.filter((obj1, i, arr) => 
				  arr.findIndex(obj2 => (obj2.SelectedGuid === obj1.SelectedGuid)) === i
				);
			const aSelectedPfcGuids = aFinalPfc.map(item => item.TrpcId);
			//filter condition for Roles
			const aRoleIds = isSubsFlag ? filterValues.aSubsRoles.map(item => item.RoleID):filterValues.aRoles.map(item => item.RoleID);
			const aUniqueRoleIds = aRoleIds.filter((item, index) => aRoleIds.indexOf(item) === index);
			const filterConditionForRoles = aUniqueRoleIds.length ? `(${aUniqueRoleIds.map(roleId => `RoleId eq '${roleId}'`).join(' or ')})` :
				`(RoleId eq '*')`;
			//filter condition for Role Areas
			const aRoleAreaIds = isSubsFlag ? filterValues.aSubsRoles.map(item => item.RoleAreaID) : filterValues.aRoles.map(item => item.RoleAreaID);
			const aUniqueRoleAreaIds = aRoleAreaIds.filter((item, index) => aRoleAreaIds.indexOf(item) === index);
			const filterConditionForRoleArea = aUniqueRoleAreaIds.length ? `(${aUniqueRoleAreaIds.map(roleAreaId => `RoleAreaId eq '${roleAreaId}'`).join(' or ')})` :
				`(RoleAreaId eq '*')`;
			const filterCondition5 = aSelectedPfcGuids.length ? `(${aSelectedPfcGuids.map(SelectedGuid => `(TrpcId eq '${SelectedGuid}')`).join(' or ')})` : "";
           //set Role payload
			const aFinaRole = isSubsFlag ? filterValues.aSubsRoles:filterValues.aRoles;
			this.getView().getModel("employee").setProperty("/aFinalRolePaylod",aFinaRole);
			let finalFilterString =
                `$filter=${sManagerLevel} and (TableTypeId eq '${filterValues.TableTypeID}') and
                (${filterConditionForRoles} or (RoleId eq '*')) and (${filterConditionForRoleArea} or  (RoleAreaId eq '*')) and (RecordStatus eq '01')`;

			let aIACID = this.getView().getModel("IACRoleAreaModel").getData() ? this.getView().getModel("IACRoleAreaModel").getData()[0].IacId : "";
			let filterConditionIAC = `(IacValue eq '${aIACID}' or IacValue eq '*')`;
			const filterConditions = [filterCondition5,filterCondition1,filterConditionSolAreas];
			if(this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/Operational_Status") && !this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/isIACQueryRemove") && (this.getOwnerComponent().getModel("mrrAppEngModel").getData().engagementSelectedKey!=='0002')){
				filterConditions.push(filterConditionIAC)
			}
            const nonEmptyFilters = filterConditions.filter(condition => condition !== '');
 
            if (nonEmptyFilters.length > 0) {
                finalFilterString += ' and ';
                finalFilterString += nonEmptyFilters.join(' and ');
            }
			let sEngagementType=this.getOwnerComponent().getModel("mrrAppEngModel").getData().engagementSelectedKey
			finalFilterString += ` and (EngTypeId eq '${sEngagementType}')`
			if(sProfitcenter[0].GrpSelectable === 'X'){
				let aSelGroup=this.getView().getModel("employee").getData().searchItems[i].TempEmployee?.SelectedGroup;
				if(aSelGroup?.length){
					finalFilterString+= ` and (GroupValue eq '${aSelGroup[0].GroupID}' or GroupValue eq '*')`
				}else{
					finalFilterString+= ` and (GroupValue eq '')`
				}
			}
            return `${finalFilterString}&$expand=to_substitute`;
		},
				
		/*Trigger ORE or BS Service for search managers*/
		onSearchResourceManagers: function () {
			let that = this;
			sap.ui.core.BusyIndicator.show()
					setTimeout(function() {
			const aSearchItems = that.getView().getModel("employee").getProperty("/searchItems");
			const uniqueValues = new Set(aSearchItems.map(v => v.searchFieldsText));
			if (uniqueValues.size < aSearchItems.length) {
				that._onOpenValidationNotificationPopOver(uniqueValues);
			}
			else {
				const ApproversBaseUrl = that._getApproversBaseURL(that);
				const ApproversOREUrl = that._getOREApproversBaseURL(that);
				const sProfitcenter = appView.listView.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories.length ? appView.listView.getView().getModel("selectedProfitCenter").getData().
					TempProfitCenter.Territories : appView.listView.getView().getModel("selectedProfitCenter").getData().
					filteredProfitCenter;
				const oResourceModel = new sap.ui.model.json.JSONModel();
				sap.ui.core.BusyIndicator.show();
				that.getView().setModel(oResourceModel, "resourceModel");
				that.getView().getModel("resourceModel").setData([]);
				appView.oFinalData.aReqAreas = [];
				for (let i = 0; i < aSearchItems.length; i++) {
					const serviceUrlFS = that._getServiceUrl(i, ApproversBaseUrl, sProfitcenter, "0001");
					const serviceUrlBS = that._getServiceBSUrl(i, ApproversBaseUrl, sProfitcenter, "0002");
					const serviceUrlExactFS = that._getServiceBSUrl(i, ApproversBaseUrl, sProfitcenter, "0001");
					const sSearchOre = " and (ManagerLevel eq 'MMM' or ManagerLevel eq 'MMT')";
					const sSearchres = " and (ManagerLevel eq 'non-managerial')";
					const serviceUrlOREApp = that._getOREServiceUrl(i, ApproversOREUrl, sProfitcenter, sSearchres);
					const sPrimaryRoleArea = aSearchItems[i].TempEmployee.TempRoles.RoleAreaID;
					const sPrimaryRoleId = 	aSearchItems[i].TempEmployee.TempRoles.ID;
					//multipleRoles
					let aRolesData = aSearchItems[i].TempEmployee.TempRoles.RolesData;
					let aSubstRoleData = aSearchItems[i].TempEmployee.TempRoles.aSubstituteRoleRoleArea;
					let RoleSubstiTute;
					//role data
					const aRoleData = aRolesData.map(item => item.RoleID);
					const aUniqueRoleIds = aRoleData.filter((item, index) => aRoleData.indexOf(item) === index);
					const filterConditionForRoles = aUniqueRoleIds.length ? `(${aUniqueRoleIds.map(roleId => `RoleId eq '${roleId}'`).join(' or ')})` :
						`(RoleId eq '')`;
					const aRoleDataSubs = aSubstRoleData.map(item => item.RoleID);
					const aUniqueRoleIdsSubs = aRoleDataSubs.filter((item, index) => aRoleDataSubs.indexOf(item) === index);
					const filterConditionForRolesSubs = aUniqueRoleIdsSubs.length ? `(${aUniqueRoleIdsSubs.map(roleId => `RoleId eq '${roleId}'`).join(' or ')})` :
						`(RoleId eq '')`;
					
					if(filterConditionForRoles !== filterConditionForRolesSubs ){
						RoleSubstiTute = true;
					}
					let data;
					let roleAreaSubs = that.getView().getModel("employee").getProperty(`/searchItems/${i}/TempEmployee/TempRoles`).subStituteRoleRoleArea;
					function fetchData(url) {
						return new Promise((resolve, reject) => {
							$.ajax({
								url: url,
								async: false,
								dataType: 'json',
								method: "GET",
								success: function (data) {
									resolve(data);
								},
								error: function (error) {
									reject(error);
								}
							});
						});
					}

			function handleData(data, sVal) {
    let approverArray = data.filter(obj => obj.UserTypeId === "0001");
   //Fetch approvers crm role and user details
    const appInfoUniqueArray = Array.from(
        new Set(approverArray.map(obj => JSON.stringify({
            email: obj.Email,
            ID: obj.UserId,
            fullName: obj.EmpFullName,
			roleId:obj.CrmRoleId,
            roleDesc:obj.CrmRoleDesc
        })))
    ).map(JSON.parse);

    that.setResourcesModel(data, that, sVal, i, appInfoUniqueArray);
}
   //Fetch approvers crm role and user details
function handleOREData(oOREappData, sVal) {
    const uniqueManagers = oOREappData.reduce((acc, obj) => {
        if (!acc.some(o => o.ID === obj.ManagerId)) {
            acc.push({
                email: obj.ManagerEmail,
                ID: obj.ManagerId,
                fullName: obj.ManagerName,
				roleId:obj.Manager_CrmRoleId,
                roleDesc:obj.Manager_CrmRoleDesc
            });
        }
        return acc;
    }, []);

    that.setResourcesOREModel(i, oOREappData, that, sVal, uniqueManagers);
}

					//MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
					//get IAC (Internal Account Classification) and Role,Role Area mapping #git84
					fetchData(`${ApproversBaseUrl}?${serviceUrlExactFS}`)
						.then((data) => {
							if (data.d.results.length) {
								handleData.call(that, data.d.results, "0001");
								return Promise.resolve();
							}
							throw new Error("No data found in first fetch");
						})
						.catch(() => {
							return fetchData(`${ApproversOREUrl}?${serviceUrlOREApp}`)
								.then((data) => {
									if (data.d?.results?.length) {
										handleOREData.call(that, data.d.results, 20);
										return Promise.resolve();
									}
									throw new Error("No data found in third fetch");
								});
						})
						.catch(async () => {
							if (RoleSubstiTute) {
								const serviceUrlSubsNotExactFS = that._getServiceBSUrl(i, ApproversBaseUrl, sProfitcenter, "0001", true);
								const retryFSData = await fetchData(`${ApproversBaseUrl}?${serviceUrlSubsNotExactFS}`);
								if (retryFSData.d.results.length) {
									handleData.call(that, retryFSData.d.results, "0001");
									return Promise.resolve();
								}
							}
							throw new Error("No data found in retry fetch");
						})
						.catch(async () => {
							if (RoleSubstiTute) {
								const serviceUrlSubsORE = that._getOREServiceUrl(i, ApproversOREUrl, sProfitcenter, sSearchres, true);
								const retryOREData = await fetchData(`${ApproversOREUrl}?${serviceUrlSubsORE}`);
								if (retryOREData.d?.results?.length) {
									handleOREData.call(that, retryOREData.d.results, 20);
									return Promise.resolve();
								}
							}
							throw new Error("No data found in retry ORE fetch");
						})
						.catch(() => {
							return fetchData(`${ApproversBaseUrl}?${serviceUrlBS}`)
								.then((data) => {
									if (data) {
										handleData.call(that, data.d.results, "0002");
										return Promise.resolve();
									}
									throw new Error("No data found in fallback fetch");
								});
						})
						.catch((error) => {
							that.errorMessageDailog(error);
							console.error("Error occurred:", error);
						});
					//MR: [GRP02-03] GTM25 Resource Profile alignment #84 end
				}
			}
		},1000)
		},

		_onOpenValidationNotificationPopOver: function (uniqueValues) {
			const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			const sMsg = i18nModel.getText("searchFieldvalidationError");
			const sDuplicatesMsg  =  i18nModel.getText("searchResoureDuplicates");
			const sFinalMsg = `${sMsg} ${uniqueValues.values().toArray().join(" , ")}`
			const that = this;
			sap.ui.core.Fragment.load({
				name: "com.dealsupport.melodyrequest.fragments.validationNotification",
				controller: this
			}).then(function (oFragment) {
				const contentVBox = new sap.m.VBox({
					items: [
						oFragment
					]
				});
				oFragment.getItems()[0].getItems()[0].setTitle(sFinalMsg);
				oFragment.getItems()[0].getItems()[0].setDescription(sDuplicatesMsg);
				
				this.oValidationPopover = new sap.m.ResponsivePopover({
					title: "Notification(1)",
					contentWidth: "auto",
					verticalScrolling:false,
					modal: true,
					content: oFragment,
					placement: sap.m.PlacementType.Top,
					beginButton: new sap.m.Button({
						text: "OK",
						press: function () {
							that.oValidationPopover.destroy();
						}
					}),
					afterClose: function () {
						that.oValidationPopover.destroy();
					}
				});
				this.getView().addDependent(this.oValidationPopover);
				this.oValidationPopover.openBy(appView.byId("idOnSearchResourcesButton"));
				sap.ui.core.BusyIndicator.hide();
			}.bind(this));
		},
		/*Set Error dialog*/
		errorMessageDailog: function (error,data) {
			let oErrorData =data?data: error;
			models._setErrorMsgPopOver(appView,"searchResourcesManager",oErrorData);
			sap.ui.core.BusyIndicator.hide();

		},
		 /**
         * Set Resource Model for FS and BS
         * 001 => FS, 002=BS and ORE=> ORE service key
         * @param {object} data -response from service
		 * @param {object} self -Controller context
		 * @param {string} sVal -Front Stop (001), Back stop(BS) (002)
		 * @param {object} aApproversArray -Approvers list
		 * @param {number} i -iteration of resource approvers
         */
		setResourcesModel: function (data, self, sVal, i, aApproversArray) {
			//data => Resource cordinator or administration
			//set the properties
			data = data.map(obj => {
                return { ...obj, isManagerDet:true , serviceId:sVal };
            });
			let aSubstituteFinalApprover = CommonJS._getSubstituteDetails(data);
			let approverArray = [];
			let value = data;
			for (let i = 0; i < value.length; i++) {
				let obj = value[i];
				switch (obj.UserTypeId) {
					case "0001":
						approverArray.push(obj);	
					default:
						break;
				}
			}
			//Fetch approvers crm role and user details
			const appinfo = approverArray.map(function (obj) {
				return {
					email: obj.Email,
					ID: obj.UserId,
					fullName: obj.EmpFullName,
					roleId:obj.CrmRoleId,
                    roleDesc:obj.CrmRoleDesc,
					isDelegates:!obj.isManagerDet,
					serviceId:obj.serviceId
				};
			});
			//remove duplicates based on ID
			//if duplicates exist one in manager and other in substitute then update only manager record
			const appInfoUniqueArray = Object.values(
				appinfo.reduce((acc, item) => ({
					...acc,
					[item.ID]: acc[item.ID]?.isDelegates === false
						? acc[item.ID]
						: item
				}), {})
			);
			let sContentWidth;
			if(self.getView().getModel("employee").getProperty("/searchItems").length === 2){
				sContentWidth = "850px";
			}else if(self.getView().getModel("employee").getProperty("/searchItems").length > 1){
				sContentWidth = "900px";
			}else{
				sContentWidth = "420px"
			}
			const sSearchType = sVal === "0002" ?   "resource": "FS";
			self.getView().getModel("resourceModel").getData().push({
				searchTitle :self.getView().getModel("employee").getProperty(`/searchItems/${i}/searchTitle`),
				searchType:sSearchType,
				isResourceFound:false,
				iSearchIndex : i,
				sNotificationMsg:self._setNotificationMsg(sVal),
				iCount:appInfoUniqueArray.length,
				sSearchText:self.getView().getModel("employee").getProperty(`/searchItems/${i}/searchFieldsText`),
				containerWidth:sContentWidth,
				isHeaderVisible:self.getView().getModel("employee").getProperty("/searchItems").length > 1?true:false,
				ApproverDetails:appInfoUniqueArray,
				aApprovers: aApproversArray,
				bIsGroupSelected: self.getView().getModel("employee").getData().searchItems[i].TempEmployee?.SelectedGroup?.length > 0 ? true : false
			});
			self.getView().getModel("resourceModel").refresh(true);
			appView.oFinalData.isResourceProfile = true;
			const employeeData = self.getView().getModel("employee").getData().searchItems[i].TempEmployee;
			self.getView().getModel("employee").setProperty(`/searchItems/${i}/TempEmployee/TempRoles/SelectedRoleDesc`,self.getView().getModel("employee").getProperty("/aFinalRolePaylod").map(obj => { return obj.RoleDesc }).join(", "));
			//Set Payload for Resource profile details
			const ResourceProfileDetails = {
				Role_GUID: self.getView().getModel("employee").getProperty(`/searchItems/${i}/TempEmployee/TempRoles`),
				RoleArea_P_GUID: self.getView().getModel("employee").getProperty(`/searchItems/${i}/TempEmployee/TempRoleAreas`)[0],
				BAIndustries: employeeData.BAIndustries,
				SolutionAreas:employeeData.SolutionAreas,				
				AdditionalSolutions:employeeData.AdditionalSolutions,				
				Materials:employeeData.Materials,				
				SelectedRole:self.getView().getModel("employee").getProperty("/aFinalRolePaylod"),
				SelectedGroup:employeeData?.SelectedGroup ? employeeData.SelectedGroup:[]
			};
			if(!self.getView().getModel("employee").getProperty(`/searchItems/${i}/BAIndustrySelectable`)){
				//reset industry
				ResourceProfileDetails.BAIndustries = [];
			}

			if(!self.getView().getModel("employee").getProperty(`/searchItems/${i}/SolnAreaSelectable`)){
				//reset solution area
				ResourceProfileDetails.SolutionAreas = [];
			}

			//MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
			//get IAC (Internal Account Classification) and Role,Role Area mapping #git84
			const oSelectRoleAreaID = self.getView().getModel("employee").getProperty(`/searchItems/${i}/TempEmployee/TempRoleAreas`)[0].ID;
            const oSelectedIACRoleArea = self.getView().getModel("IACRoleAreaModel").getData().find(item => item.RoleAreaId === oSelectRoleAreaID);
			let uniqueSubs = Array.from(new Map(aSubstituteFinalApprover.map(aSubstituteFinalApprover => [aSubstituteFinalApprover.ID, aSubstituteFinalApprover])).values());
			uniqueSubs = uniqueSubs ? uniqueSubs.filter(item => !aApproversArray.some(aItem => aItem.ID === item.ID)) : [];
            const aResourceProfileApprovers = {
				aApprovers: aApproversArray,
                ApproverDetails: appInfoUniqueArray,
                ResourceProfileDetails: ResourceProfileDetails,
				//update substitute array to the context
				SubstituteApproverDetails:uniqueSubs,
                IAC: [{
					"IAC_Desc": oSelectedIACRoleArea.IacDesc,
                    "IAC_ID": oSelectedIACRoleArea.IacId,
                    "IAC_RoleMap_GUID": oSelectedIACRoleArea.IacMapGuid
                }]
            };
			//MR: [GRP02-03] GTM25 Resource Profile alignment #84 end
			appView.oFinalData.aReqAreas.push({
				searchFieldsText:self.getView().getModel("employee").getProperty(`/searchItems/${i}/searchFieldsText`),
				requestArea:self.getView().getModel("employee").getProperty(`/searchItems/${i}/searchTitle`),
				requestAreaPath:self.getView().getModel("employee").getProperty(`/searchItems/${i}/searchTitle`),
				aResourceProfileApprovers:aResourceProfileApprovers
			})
			const aSearchItems = self.getView().getModel("employee").getProperty("/searchItems");
			appView.getView().getModel("createReqFooterModel").setProperty("/approverId",sVal);
		
			
			if(aSearchItems.length === i+1){
				//if final search completed
				self.openResProfileDialog(self, sVal);
				
			}
		
		},
		//GIT: 720 - update to show standardized message for FS,BS and ORE resource profile search
		_setNotificationMsg: function () {
			const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			return i18nModel.getText("commonResMessDescFSBSORE");

		},
		/*Open Resource profile manager popover*/
		openResProfileDialog: function (self, sVal,bShowResourceModel,isOpenCreateReqFragment) {
			const aResource = [];
            const aResourceData = this.getView().getModel("resourceModel").getData();
            const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            const notifyDesc = i18nModel.getText("notificationMess");
            const savenNext = i18nModel.getText("saveAndNext");
            const backtext = i18nModel.getText("back");
            const nextSearchtext = i18nModel.getText("nextSearch");
            const prevSearchtext = i18nModel.getText("prevSearchtext");
			const sNotificationMiddleText =  i18nModel.getText("notificationMiddleText");
            let resourceMessDesc;
            const aResourceModelData = this.getView().getModel("resourceModel").getData();
        if(!isOpenCreateReqFragment){
            if (aResourceModelData.length > 1) {
                for (let i = 0; i < aResourceModelData.length; i++) {
                    if (i === 0) {
                        aResourceModelData[0].isNextRequestBtnVisible = true;
                        aResourceModelData[0].isPrevRequestBtnVisible = false;
                    } else if (aResourceModelData.length === i + 1) {
                        aResourceModelData[0].isNextRequestBtnVisible = false;
                        aResourceModelData[0].isPrevRequestBtnVisible = true;
                    } else {
                        aResourceModelData[0].isNextRequestBtnVisible = true;
                        aResourceModelData[0].isPrevRequestBtnVisible = true;
                    }
 
                }
            } else {
                aResourceModelData[0].isNextRequestBtnVisible = false;
                aResourceModelData[0].isPrevRequestBtnVisible = false;
            }
            this.getView().getModel("resourceModel").refresh(true);
            appView.oFinalData.selectedProfitCenter =
                appView.listView.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories")
 
            if (sVal === "0001") {
                resourceMessDesc = i18nModel.getText("resMessDescFS");
            } else if (sVal === 20) {
                resourceMessDesc = i18nModel.getText("resMessDescORE");
            } else if (sVal === "0002") {
                resourceMessDesc = i18nModel.getText("resMessDescBS");
            }
        }
            const applength = "(" + this.getView().getModel("resourceModel").getData().length + ")";
 
            sap.ui.core.Fragment.load({
                name: "com.dealsupport.melodyrequest.fragments.resourceProfileApprovers",
                controller: this
            }).then(function (oFragment) {
             if(!isOpenCreateReqFragment){
                appView.getView().getModel("createReqFooterModel").setProperty("/isResource", false);
                let bApproverNotFound = aResourceData.some(function (resource) {
                    return !resource.ApproverDetails.length
                });
                if (!bApproverNotFound) {
                    //data from back stop table
                    aResourceData.forEach(function (resource) {
                        if (resource.searchType === "resource") {
                            appView.getView().getModel("createReqFooterModel").setProperty("/isResource", "resourceAdmin");
                        }
                    });
                } else {
                    //no managers or resource cordinator
                    aResourceData.forEach(function (resource) {
                        if (!resource.ApproverDetails.length) {
                            appView.getView().getModel("createReqFooterModel").setProperty("/isResource", "notFound");
                            aResource.push(resource);
                            appView.getView().getModel("createReqFooterModel").setProperty("/resourceContext", aResource);
                        }
                    });
                }
            }
                appView.getView().getModel("createReqFooterModel").refresh();
                if(!isOpenCreateReqFragment && !appView.listView.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories/0/isParentNodeEnable") && appView.getView().getModel("createReqFooterModel").getProperty("/isResource") === "notFound"){
                    this._onOpenApproverNotificationPopOver(true);
                    sap.ui.core.BusyIndicator.hide();
                }else if (!isOpenCreateReqFragment && appView.getView().getModel("createReqFooterModel").getProperty("/isResource") && !bShowResourceModel && appView.listView.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories/0/isParentNodeEnable")) {
                    this._onOpenApproverNotificationPopOver();
                }else{
                    const that = this;
                    //add the footer buttons
                    //next search button
                    const oNextSearchBtn = new sap.m.Button({
                        text:nextSearchtext,
                        customData:new sap.ui.core.CustomData({
                            key:"next"
                        }),
                        type: "Emphasized",
                        press: function () {
                            const iActiveIndex = that.oPopover.getContent()[0]._getActivePageIndex();
                            that.onCarouselChanged(false,"next",iActiveIndex);
                        }
                    });
                    //prev search button
                    const oPrevSearchBtn = new sap.m.Button({
                        text:prevSearchtext,
                        type: "Emphasized",
                        customData:new sap.ui.core.CustomData({
                            key:"prev"
                        }),
                        press: function () {
                            const iActiveIndex = that.oPopover.getContent()[0]._getActivePageIndex();
                            that.onCarouselChanged(false,"prev",iActiveIndex);
                        }
                    });
                    //modify search btn
                    const oModifySearchBtn =  new sap.m.Button({
                            text: backtext,
                            customData:new sap.ui.core.CustomData({
                                key:"modify"
                            }),
                            press: function () {
                                //modify search
                                that.oPopover.close();
                                const iSelectedCrslIndex = that.oPopover.getContent()[0]._getActivePageIndex();
                                const oSelectedContext = that.getView().getModel("resourceModel").getData()[iSelectedCrslIndex];
                                that.iModiFiedIndex = iSelectedCrslIndex;
                                const aSearchItems = that.getView().getModel("employee").getProperty("/searchItems");
                                aSearchItems.forEach(function(item){
                                    //panel expand based on modify search
                                    if(item.searchTitle === oSelectedContext.searchTitle){
                                        item.isExpanded = true;
                                    }else{
                                        item.isExpanded = false;
                                    }
                                });
								that.getView().byId("idResourceProfileContainer").getItems().forEach(obj=>{
									if(obj.getBindingContext("employee").getObject().searchTitle==oSelectedContext.searchTitle){
										obj.setExpanded(true)
									}else{
										obj.setExpanded(false)
									}
								})
                                that.getView().getModel("employee").refresh(true);
                            }
                        });
                    //create request button
                    const oCreateReqBtn = new sap.m.Button({
                        text: savenNext,
                        customData:new sap.ui.core.CustomData({
                            key:"createReq"
                        }),
                        type: "Emphasized",
                        press: function () {
                            appView.getView().getModel("createReqFooterModel").setProperty("/footerButtons/createReqButtonEnabled", true)
                            appView.getView().getModel("createReqFooterModel").refresh();
                            appView.onCreateRequest();
                            that.oPopover.close();
                        }
                    });
                    if (that.getView().getModel("resourceModel").getData().length > 1) {
                        oCreateReqBtn.setVisible(false);
                        oPrevSearchBtn.setVisible(false);
                        oNextSearchBtn.setVisible(true);
                    }else{
                        oCreateReqBtn.setVisible(true);
                        oPrevSearchBtn.setVisible(false);
                        oNextSearchBtn.setVisible(false);
                    }
                    //toolbar spacer
                    const oToolbarSpacer  = new sap.m.ToolbarSpacer({customData:new sap.ui.core.CustomData({
                        key:"spacer"
                    }),});
                    const overflowToolbar = new sap.m.OverflowToolbar({
                        content :[
                            oToolbarSpacer,
                            oPrevSearchBtn,
                            oCreateReqBtn,
                            oNextSearchBtn,
                            oModifySearchBtn
                        ]
 
                    });
                    const contentVBox = new sap.m.VBox({
                        items: [
                            oFragment
                        ]
                    });
					const sNotificationTitle = this.getView().getModel("resourceModel").getData().length > 1 ? notifyDesc + " " + "(1 "+sNotificationMiddleText+" "+ this.getView().getModel("resourceModel").getData().length + ")":notifyDesc + " " + "(" + this.getView().getModel("resourceModel").getData().length + ")";
					const oCustomHeader = new sap.m.OverflowToolbar({
                        content: [
                            new sap.m.Title({
                                text:sNotificationTitle,
                            }),
                            new sap.m.ToolbarSpacer({
 
                            }),
                            new sap.m.Button({
                                icon: "sap-icon://decline",
                                press: function (evt) {
                                    that.oPopover.destroy();
                                }
                            })
                        ]
                    });
                    this.oPopover = new sap.m.Popover({
                        title: notifyDesc + " " + "(" + this.getView().getModel("resourceModel").getData().length + ")",
                        contentWidth: "auto",
                        verticalScrolling: false,
                        modal: true,
                        content: oFragment,
						customHeader: oCustomHeader,
                        placement: sap.m.PlacementType.Top,
                        footer:overflowToolbar,
                        afterClose: function () {
                            that.oPopover.destroy();
                        }
                    });
                    this.oCrsl = oFragment;
                    this.oPopover.addStyleClass("customPopover");
                    this.getView().addDependent(this.oPopover);
                    this.oPopover.openBy(appView.byId("idOnSearchResourcesButton"));
 
                    if (this.getView().getModel("resourceModel").getData().length > 1) {
                        this._remeAllCarouselStyleClass();
                        this.oCrsl.addStyleClass("customStyleRightBtnCarouselVisible");
                    } else {
                        this._remeAllCarouselStyleClass();
                        this.oCrsl.addStyleClass("customStyleAllBtnCarouselhidden");
                    }
                    this.getView().getModel("resourceModel").refresh(true);
                    const aResourceData = this.getView().getModel("resourceModel").getData();
                    aResourceData.sort(({ iSearchIndex: a }, { iSearchIndex: b }) => a - b);
                    for (let i = 0; i < aResourceData.length; i++) {
                        if (i === 0) {
                            aResourceData[i].isConatinerVisible = true;
                        } else {
                            aResourceData[i].isConatinerVisible = false;
                        }
                    }
                    aResourceData[0].scrollHeight = "auto";
                    this.oPopover.setVerticalScrolling(true);
                    if(this.iModiFiedIndex){
                        oFragment.setActivePage(oFragment.getPages()[this.iModiFiedIndex].getId());
                    }
                    this.getView().getModel("resourceModel").refresh(true);
 
                    sap.ui.core.BusyIndicator.hide();
                }
            }.bind(this));
		},
	_onOpenApproverNotificationPopOver: function (isHigherNodeNonSelectable){
   const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
   this.noSearchResult = false;
   this.bHigherNodeNotFound = false;
   sap.ui.core.Fragment.load({
    name: "com.dealsupport.melodyrequest.fragments.ApproverNotification",
    controller: this
   }).then(function (oFragment) {
    const contentVBox = new sap.m.VBox({
     items: [
      oFragment
     ]
    });
    this.getView().getModel("resourceModel").getData().forEach(obj=>{
     if(obj.bIsGroupSelected && appView.listView.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories[0]?.ParentGroupSelectable!='X'){
      isHigherNodeNonSelectable=true;
     }
    })
    if (!isHigherNodeNonSelectable) {
     if (appView.listView.aNonSelectableParentNode) {
      appView.listView.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories.unshift(appView.listView.aNonSelectableParentNode)
     }
     
     //parent node => check lower node selection false and isChecBox is false or is legacy
     const oProfitCenterMasterData = appView.listView.getView().getModel("treeTerritories").getData().territories;
     this.nodeParentCheck = false;
     this.higherNodeProfitCenter = false;
     this.higherNodeItreation = false;
     this.bHigherNodeNotFound = false;
     let nodeParentCheck = function nodeUpdate(newValue, that,isItreation) {
      let oPFCMasterData = appView.listView.getView().getModel("treeTerritories").getData().territories;
      let aSelectedPFC =  isItreation ? that.higherNodeProfitCenter : that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories[0];
      let aNodeDes = aSelectedPFC.SelectedDesc.split(">");
      aNodeDes.pop();
      let sDescription = aNodeDes.join(">");
      if(!sDescription){
       that.higherNodeItreation = false;
       that.bHigherNodeNotFound = true;
      }
      else if(oPFCMasterData[0].displaydesc === sDescription.trim()){
       if (!oPFCMasterData[0].isChildNodeEnable && (!oPFCMasterData[0].isCheckBox || !oPFCMasterData[0].isResourceProfile)) {
        that.higherNodeItreation = false;
        that.bHigherNodeNotFound = true;

       }
      }else{
      for (const child of newValue.nodes) {
       if (sDescription.trim() == child.displaydesc && !child.isChildNodeEnable && (!child.isCheckBox || !child.isResourceProfile)) {
        child.IsSelected = true;
        that.nodeParentCheck = true;
        let oSelectedProfitCenter = models._setProfitCenterObj(child);
        that.higherNodeProfitCenter = oSelectedProfitCenter;
        that.higherNodeItreation = true;

       } else if (sDescription.trim() == child.displaydesc) {
        that.higherNodeItreation = false;
       }
       if(!that.nodeParentCheck){
        //select child nodes
        nodeUpdate(child, that);
       }
       
      }
     }
      
     }
     nodeParentCheck(oProfitCenterMasterData[0], this);
     if(this.higherNodeItreation){
      nodeParentCheck(oProfitCenterMasterData[0], this,true);
     }

     if(!this.bHigherNodeNotFound){
      //higher parent node not exist
      const aSelectedPFC = this.higherNodeProfitCenter ? this.higherNodeProfitCenter : this.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories[0];
      const sDesc = aSelectedPFC.SelectedDesc;
      const aNodeDesc = sDesc.split(">");
      aNodeDesc.pop();
      const sParentNode = aNodeDesc.join(">");
      // let sNotificationMsg = `<p>${i18nModel.getText("approverNotification")} <strong>${sParentNode}</strong> ${i18nModel.getText("allSearch")}</p>`;
      let sNotificationMsg;
      if(appView.oFinalData.aReqAreas[0].aResourceProfileApprovers.ApproverDetails.length){
        sNotificationMsg = `<p>${i18nModel.getText("approverNotification")} <strong>${sParentNode}</strong> ${i18nModel.getText("allSearch")}</p>`;
      }else{
       sNotificationMsg = `<p>${i18nModel.getText("approverNotificationNoRes")} <strong>${sParentNode}</strong> ${i18nModel.getText("allSearch")}</p>`;
      }
      let oFormattedText = new sap.m.FormattedText({
       htmlText: sNotificationMsg
      });
      oFragment.removeAllItems()
      oFragment.insertItem(oFormattedText);

     }else if(appView.getView().getModel("createReqFooterModel").getProperty("/isResource") === "notFound"){
      this._onOpenApproverNotificationPopOver(true);
     }else{
      this.openResProfileDialog(false,false,false,true);
     }
    } else {
      let sResource = appView.getView().getModel("createReqFooterModel").getProperty("/isResource")
      let aResourceContext = appView.getView().getModel("createReqFooterModel").getProperty("/resourceContext");
      let aSearchMsg = [];
      aResourceContext.forEach(function (context) {
       aSearchMsg.push(
        `${context.searchTitle} ${context.sSearchText}`
       );
      });
      let sNotificationMsg = `<p>${i18nModel.getText("processorNotFoundIn")} <strong>${aSearchMsg.join(" , ")}</strong> ${i18nModel.getText("modifyOrDeleteMsg")}</p>`

      let oFormattedText = new sap.m.FormattedText({
       htmlText: sNotificationMsg
      });
      oFragment.removeAllItems()
      oFragment.insertItem(oFormattedText);
     }
     
    if(!this.bHigherNodeNotFound){
     const that = this;
     if(this.oNotificationPopover){
      this.oNotificationPopover.close();
     }
     this.oNotificationPopover = new sap.m.ResponsivePopover({
      title: "Notification(1)",
      contentWidth: "500px",
      verticalScrolling:false,
      modal: true,
      content: oFragment,
      placement: sap.m.PlacementType.Top,
      beginButton: new sap.m.Button({
       text: "Yes",
      visible:isHigherNodeNonSelectable ? false:true,
       press: function () {
        if(!that.noSearchResult){
       if(that.higherNodeProfitCenter){
        appView.listView.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories = [that.higherNodeProfitCenter]
        appView.listView.getView().getModel("selectedProfitCenter").refresh(true);
       }
       if(that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.TempTreeTerritories){
        that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.TempTreeTerritories.length = 1;
       }
       if(that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories){
        that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories.length = 1;
       }
      
       appView.listView.loadTreeTerritories("treeTerritories",appView.getView().getModel("territoriesMaster").getData(),true);
       appView.listView.setTerritoryHierarchySelection(false, false, false, true);
       var bGrpSelect=that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories[0]?.GrpSelectable=='X'?true:false;
       that.getView().getModel("employee").getData().searchItems.forEach(obj=>{
        obj.GrpSelectable=bGrpSelect
       });
       that.getView().getModel("employee").refresh(true);       
       let nodeUpdate = function nodeUpdate(newValue, that) {
        for (const child of newValue.nodes) {
         if (child.isCheckBox && child.isResourceProfile) {
          child.IsSelected = true;
          let oSelectedProfitCenter = models._setProfitCenterObj(child);
          that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories.push(
           oSelectedProfitCenter);
          that.getView().getModel("selectedProfitCenter").refresh(true);
         }
         nodeUpdate(child, that);
        }
        appView.listView.getView().getModel("selectedProfitCenter").refresh(true);
        appView.listView.getView().getModel("treeTerritories").refresh(true);
       }
         that.oNotificationPopover.destroy();
       if (appView.listView.aSelectedParentNode) {
        let oSelectedPFCDesc = models._setProfitCenterObj(appView.listView.aSelectedParentNode);
        appView.listView.getView().getModel("selectedProfitCenter").setProperty("/selectedPfc",oSelectedPFCDesc);
        if(appView.listView.aSelectedParentNode.isChildNodeEnable){
         nodeUpdate(appView.listView.aSelectedParentNode, that);
        }
        appView.listView.getView().getModel("selectedProfitCenter").refresh(true);
        appView.listView.getView().getModel("treeTerritories").refresh(true);
        that.onSearchResourceManagers(that);
        const aSelectedTerritories = appView.listView.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories;
        for (let i = 0; i < aSelectedTerritories.length; i++) {
         if (!aSelectedTerritories[i].isCheckBox || !aSelectedTerritories[i].isResourceProfile) {
          appView.listView.aNonSelectableParentNode =aSelectedTerritories[0]; 
          aSelectedTerritories.splice(i, 1)
         }
        }
        appView.listView.getView().getModel("selectedProfitCenter").refresh();
        appView.detailViewScreen.getView().setModel(new sap.ui.model.json.JSONModel(appView.listView.getView().getModel("selectedProfitCenter").getData()),"selectedProfitCenter")
        appView.detailViewScreen.getView().getModel("selectedProfitCenter").refresh();
        }
       else {
        let sResource = appView.getView().getModel("createReqFooterModel").getProperty("/isResource");
        if (sResource !== "notFound") {
         let oFormattedText = new sap.m.FormattedText({
            htmlText: i18nModel.getText("noResourcesNotification")
           });
           that.noSearchResult = true;
           that.oNotificationPopover._getPopup().getContent().getContent()[0].removeAllItems();
           that.oNotificationPopover._getPopup().getContent().getContent()[0].insertItem(oFormattedText);
           that.oNotificationPopover.getBeginButton().setVisible(true);
          } else {
           let sNotificationMsg = `<p>${i18nModel.getText("processorNotFoundIn")} <strong>${aSearchMsg.join(" , ")}</strong> ${i18nModel.getText("modifyOrDeleteMsg")}</p>`
           let oFormattedText = new sap.m.FormattedText({
            htmlText: sNotificationMsg
           });
           that.oNotificationPopover._getPopup().getContent().getContent()[0].removeAllItems();
           that.oNotificationPopover._getPopup().getContent().getContent()[0].insertItem(oFormattedText);
           that.oNotificationPopover.getEndButton().setText("OK")
           that.oNotificationPopover.getBeginButton().setVisible(false);
          }
 
         }
       } else {
        that.oNotificationPopover.destroy();
       }
      }
     }),
     endButton: new sap.m.Button({
      text: isHigherNodeNonSelectable ? "OK":"No",
      press: function (oEvent) {
       if (oEvent.getSource().getText() !== "OK") {
        let sResource = appView.getView().getModel("createReqFooterModel").getProperty("/isResource")
        let aResourceContext = appView.getView().getModel("createReqFooterModel").getProperty("/resourceContext");
        let aSearchMsg = [];
       if (sResource === "notFound") {
        aResourceContext.forEach(function (context) {
         aSearchMsg.push(
          `${context.searchTitle} ${context.sSearchText}`
         );
        });
        let sNotificationMsg = `<p>${i18nModel.getText("processorNotFoundIn")} <strong>${aSearchMsg.join(" , ")}</strong> ${i18nModel.getText("modifyOrDeleteMsg")}</p>`
    
        let oFormattedText = new sap.m.FormattedText({
         htmlText: sNotificationMsg
        });
        that.oNotificationPopover._getPopup().getContent().getContent()[0].removeAllItems();
        that.oNotificationPopover._getPopup().getContent().getContent()[0].insertItem(oFormattedText);
        that.oNotificationPopover.getEndButton().setText("OK")
        that.oNotificationPopover.getBeginButton().setVisible(false);
       } else {
        const sVal = appView.getView().getModel("createReqFooterModel").getProperty("/approverId");
        that.openResProfileDialog(that, sVal,true);
        that.oNotificationPopover.destroy();
        }
        appView.getView().getModel("createReqFooterModel").refresh()
       } else {
        that.isNotificationPopOverClose = true;
        that.oNotificationPopover.destroy();
       }
      }
      
     }),
     afterClose: function () {
     }
    });
    this.getView().addDependent(this.oNotificationPopover);
    this.oNotificationPopover.openBy(appView.byId("idOnSearchResourcesButton"));
    sap.ui.core.BusyIndicator.hide();
   }
   }.bind(this));
   
  },
		 /**
         * Set ORE Resource
         * @param {object} appdata -response from service
		 * @param {object} self -Controller context
		 * @param {string} sVal - ORE Key
		 * @param {object} aApproversArray -Approvers list
		 * @param {number} i -iteration of resource approvers
         */
		setResourcesOREModel: function (i,appdata, self, sVal, aApproversArray) {
			//data => Managers
			//set the properties
			appdata = appdata.map(obj => {
                return { ...obj, isManagerDet:true,serviceId:"ORE" };
            })
			let aSubstituteFinalApprover = CommonJS._getSubstituteDetails(appdata,true);
			let approverArray = [];
			let appValue = appdata;
			for (let i = 0; i < appValue.length; i++) {
				let obj = appValue[i];
				approverArray.push(obj.Id);
			}
			//Fetch approvers crm role and user details
			const appinfoORE = appValue.map(function (obj) {
				return {
					email: obj.ManagerEmail,
					ID: obj.ManagerId,
					fullName: obj.ManagerName,
					roleId:obj.Manager_CrmRoleId,
                    roleDesc:obj.Manager_CrmRoleDesc,
					isDelegates:!obj.isManagerDet,
					serviceId:obj.serviceId
				};
			});
			//remove duplicates based on ID
			//if duplicates exist one in manager and other in substitute then update only manager record
			const uniqueManagers =  Object.values(
				appinfoORE.reduce((acc, item) => ({
					...acc,
					[item.ID]: acc[item.ID]?.isDelegates === false
						? acc[item.ID]
						: item
				}), {})
			);
			let sContentWidth;
			if(this.getView().getModel("employee").getProperty("/searchItems").length === 2){
				sContentWidth = "850px";
			}else if(this.getView().getModel("employee").getProperty("/searchItems").length > 1){
				sContentWidth = "900px";
			}else{
				sContentWidth = "420px"
			}

			this.getView().getModel("resourceModel").getData().push({
				searchTitle :this.getView().getModel("employee").getProperty(`/searchItems/${i}/searchTitle`),
				isResourceFound:true,
				searchType:"ore",
				iSearchIndex :i,
				sNotificationMsg:this._setNotificationMsg(sVal),
				iCount:uniqueManagers.length,
				sSearchText:this.getView().getModel("employee").getProperty(`/searchItems/${i}/searchFieldsText`),
				containerWidth:sContentWidth,
				isHeaderVisible:this.getView().getModel("employee").getProperty("/searchItems").length > 1?true:false,
				ApproverDetails:uniqueManagers,
				aApprovers:aApproversArray,
				bIsGroupSelected: this.getView().getModel("employee").getData().searchItems[i].TempEmployee?.SelectedGroup?.length > 0 ? true : false
			});
			this.getView().getModel("resourceModel").refresh(true);
			appView.oFinalData.isResourceProfile = true;
			const employeeData = this.getView().getModel("employee").getData().searchItems[i].TempEmployee;
			self.getView().getModel("employee").setProperty(`/searchItems/${i}/TempEmployee/TempRoles/SelectedRoleDesc`,self.getView().getModel("employee").getProperty("/aFinalRolePaylod").map(obj => { return obj.RoleDesc }).join(", "));
			//Set Payload for Resource profile details
			const ResourceProfileDetails = {
				Role_GUID: this.getView().getModel("employee").getProperty(`/searchItems/${i}/TempEmployee/TempRoles`),
				RoleArea_P_GUID: this.getView().getModel("employee").getProperty(`/searchItems/${i}/TempEmployee/TempRoleAreas`)[0],
				BAIndustries: employeeData.BAIndustries,
				SolutionAreas:employeeData.SolutionAreas,
				AdditionalSolutions:employeeData.AdditionalSolutions,				
				Materials:employeeData.Materials,
				SelectedRole:self.getView().getModel("employee").getProperty("/aFinalRolePaylod"),
				SelectedGroup: employeeData?.SelectedGroup ? employeeData.SelectedGroup:[]
			};
			if(!this.getView().getModel("employee").getProperty(`/searchItems/${i}/BAIndustrySelectable`)){
				//reset industry
				ResourceProfileDetails.BAIndustries = [];
			}

			if(!this.getView().getModel("employee").getProperty(`/searchItems/${i}/SolnAreaSelectable`)){
				//reset solution area
				ResourceProfileDetails.SolutionAreas = [];
			}

			//MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
			//get IAC (Internal Account Classification) and Role,Role Area mapping #git84
			const oSelectRoleAreaID = self.getView().getModel("employee").getProperty(`/searchItems/${i}/TempEmployee/TempRoleAreas`)[0].ID;
            const oSelectedIACRoleArea = self.getView().getModel("IACRoleAreaModel").getData().find(item => item.RoleAreaId === oSelectRoleAreaID);
			let uniqueSubs = Array.from(new Map(aSubstituteFinalApprover.map(aSubstituteFinalApprover => [aSubstituteFinalApprover.ID, aSubstituteFinalApprover])).values());
			uniqueSubs = uniqueSubs ? uniqueSubs.filter(item => !aApproversArray.some(aItem => aItem.ID === item.ID)) : [];
            const aResourceProfileApprovers = {
				aApprovers:aApproversArray,
                ApproverDetails: uniqueManagers,
                ResourceProfileDetails: ResourceProfileDetails,
				//update substitute array to the context
				SubstituteApproverDetails:uniqueSubs,
                IAC: [{
                    "IAC_Desc": oSelectedIACRoleArea.IacDesc,
                    "IAC_ID": oSelectedIACRoleArea.IacId,
                    "IAC_RoleMap_GUID": oSelectedIACRoleArea.IacMapGuid
                }]
            };
			//MR: [GRP02-03] GTM25 Resource Profile alignment #84 end

			
			appView.oFinalData.aReqAreas.push({
				searchFieldsText:this.getView().getModel("employee").getProperty(`/searchItems/${i}/searchFieldsText`),
				requestArea:this.getView().getModel("employee").getProperty(`/searchItems/${i}/searchTitle`),
				requestAreaPath:this.getView().getModel("employee").getProperty(`/searchItems/${i}/searchTitle`),
				aResourceProfileApprovers:aResourceProfileApprovers
			})

			const aSearchItems = this.getView().getModel("employee").getProperty("/searchItems");
			if(aSearchItems.length === i+1){
				appView.oFinalData.isResourceProfile = true;
				this.openResProfileDialog(this, sVal);
			}
		
		},
		currentAvatarDisplay: function (userId) {
			return this.getOwnerComponent().getModel("appConstants").getProperty("/userImg/0/Value") + userId;
		},
		onPressEmpEmail: function (oEvent) {
			const sUrl = oEvent.getSource().getProperty("text");
			URLHelper.triggerEmail(sUrl, "Info Request - MRR", false, false, false, true);
		},
		_getApproversBaseURL: function (self) {
			return models._getLSRuntimeBaseURL(self) + "/sap/opu/odata/sap/YROSTER_SRV;v=0002/YC_DS_T_RESOURCE_PROFILE";
		},
		_getOREApproversBaseURL: function () {
			return this._getRuntimeBaseURL() + "/int_pc/sap/opu/odata/sap/YROSTER_SRV;v=0002/YC_DS_T_PRSONPRO"
		},
		_getRuntimeBaseURL: function () {
			const appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
			const appPath = appId.replaceAll(".", "/");
			const appModulePath = sap.ui.require.toUrl(appPath);
			return appModulePath;
		},
		//add new resource profile
		addNewResourceProfile:function(oEvent){
			const oModel = this.getView().getModel("employee");
			const aSearchItems = oModel.getProperty("/searchItems");
			const iCurrentIndex = Number(oEvent.getSource().getBindingContext("employee").getPath().split('/')[2]);
			const oResourceSearchObj = CommonJS._setNewResourceProfileObj(this);
			oResourceSearchObj.TempEmployee.AdditionalSolutions=[]
			oResourceSearchObj.TempEmployee.Materials=[]
			const oNewSearchProfile = JSON.parse(JSON.stringify(this.getView().getModel("employee").getData()));
			oResourceSearchObj.TempEmployee = oNewSearchProfile.searchItems[iCurrentIndex].TempEmployee;			
			oResourceSearchObj.CrossCvg = oNewSearchProfile.searchItems[iCurrentIndex].CrossCvg;
			oResourceSearchObj.BALoBs =  oNewSearchProfile.searchItems[iCurrentIndex].BALoBs;
			//copy of profit center add
			oResourceSearchObj.TempProfitCenter =  oNewSearchProfile.searchItems[iCurrentIndex].TempProfitCenter;
			//MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
			//updated selected solution area
			oResourceSearchObj.SolutionAreas = oNewSearchProfile.searchItems[iCurrentIndex].SolutionAreas;
			//MR: [GRP02-03] GTM25 Resource Profile alignment #84 end
			oResourceSearchObj.BAIndustries = oNewSearchProfile.searchItems[iCurrentIndex].BAIndustries;
			oResourceSearchObj.RoleAreas = oNewSearchProfile.searchItems[iCurrentIndex].RoleAreas;
			oResourceSearchObj.SelectedRoleKey = oNewSearchProfile.searchItems[iCurrentIndex].SelectedRoleKey;
			oResourceSearchObj.SelectedRoleAreasKey = oNewSearchProfile.searchItems[iCurrentIndex].SelectedRoleAreasKey;
			oResourceSearchObj.isBALobRequired = oNewSearchProfile.searchItems[iCurrentIndex].isBALobRequired;
			oResourceSearchObj.isSolnAreaRequired = oNewSearchProfile.searchItems[iCurrentIndex].isSolnAreaRequired;
			oResourceSearchObj.isCrossCoverageRequired = oNewSearchProfile.searchItems[iCurrentIndex].isCrossCoverageRequired;
			oResourceSearchObj.isBAIndustryRequired = oNewSearchProfile.searchItems[iCurrentIndex].isBAIndustryRequired;
			oResourceSearchObj.selAtleaseoneValueVisibility = oNewSearchProfile.searchItems[iCurrentIndex].selAtleaseoneValueVisibility;
			oResourceSearchObj.searchTitle = `Search ${aSearchItems.length}`
			oResourceSearchObj.searchFieldsText = oNewSearchProfile.searchItems[iCurrentIndex].searchFieldsText;
			oResourceSearchObj.selectedPfc = oNewSearchProfile.searchItems[iCurrentIndex].selectedPfc;
			oResourceSearchObj.isPfcSelected = oNewSearchProfile.searchItems[iCurrentIndex].isPfcSelected;
			oResourceSearchObj.BAIndustryMandatory = oNewSearchProfile.searchItems[iCurrentIndex].BAIndustryMandatory;
			oResourceSearchObj.BAIndustrySelectable = oNewSearchProfile.searchItems[iCurrentIndex].BAIndustrySelectable;
			oResourceSearchObj.SolnAreaMandatory = oNewSearchProfile.searchItems[iCurrentIndex].SolnAreaMandatory;
			oResourceSearchObj.SolnAreaSelectable = oNewSearchProfile.searchItems[iCurrentIndex].SolnAreaSelectable;
			oResourceSearchObj.fieldSelectionMidInfoIcon = oNewSearchProfile.searchItems[iCurrentIndex].fieldSelectionMidInfoIcon;
			oResourceSearchObj.solnAreaEnable = oNewSearchProfile.searchItems[iCurrentIndex].solnAreaEnable;
			oResourceSearchObj.industryEnable = oNewSearchProfile.searchItems[iCurrentIndex].industryEnable;
			oResourceSearchObj.maxSelect= oNewSearchProfile.searchItems[iCurrentIndex].maxSelect;
			oResourceSearchObj.minSelect= oNewSearchProfile.searchItems[iCurrentIndex].minSelect;
			oResourceSearchObj.solnIndRequired= oNewSearchProfile.searchItems[iCurrentIndex].solnIndRequired;
			oResourceSearchObj.GrpSelectable= oNewSearchProfile.searchItems[iCurrentIndex].GrpSelectable;
			oResourceSearchObj.isValidation= oNewSearchProfile.searchItems[iCurrentIndex].isValidation;
			aSearchItems.push(oResourceSearchObj);
			for(let i=0;i<aSearchItems.length;i++){
				aSearchItems[i].searchTitle = `Search ${i+1}`
			}
			oModel.refresh(true);
			//this._onEnableSearchResources(aSearchItems.length-1)
		},
		//delete search profile panel content
		onDeleteProfile: function(oEvent) {
			this.iModiFiedIndex = false;
			const oBindingIndex = Number(oEvent.getSource().getBindingContext("employee").getPath().split('/')[2]);
			const aSearchItems = this.getView().getModel("employee").getProperty(`/searchItems`);
			aSearchItems.splice(oBindingIndex,1)
			if(!aSearchItems.length){
				appView.listView.onTokenUpdate();
				//reset opp id and opp info icon
				appView.listView.byId("multiInputNewOpp").setOpportunityId("")
				appView.listView.byId("multiInputNewOpp").getAggregation("_icon").setVisible(false);
				appView.listView.byId("multiInputNewOpp").getAggregation("_clearIcon").setVisible(false);
				appView.listView.byId("multiInputAccount").setTokens([]);
				appView.listView.getView().byId("multiInputAccount").setWidth("60%");
				appView.oCreateDialog.setContentHeight("350px");
				appView.oCreateDialog.setContentWidth("800px");
				appView.getOwnerComponent().getModel("appConstants").setProperty("/oppAccConatinerVisible",false)
				appView.getOwnerComponent().getModel("appConstants").refresh();
				
			}
			for(let i=0;i<aSearchItems.length;i++){
				aSearchItems[i].searchTitle = `Search ${i+1}`
			}
			this.getView().getModel("employee").refresh();
			this._searchResourceValidation();
		},
		//set search field header text based on search values
		_setSearchFieldText:function(iIndex){
			const aSearchItem= this.getView().getModel("employee").getProperty(`/searchItems/${iIndex}/TempEmployee`);
            const aSearchParams = [];
			const aSolArea = [];
			const aBAInd = [];
			if(aSearchItem.SolutionAreas.length && this.getView().getModel("employee").getProperty(`/searchItems/${iIndex}/SolnAreaSelectable`)){
				aSearchItem.SolutionAreas.forEach(function(sol){
					aSolArea.push(sol.SelectedSolutionArea);
				})
			}
			if( aSearchItem.TempBAIndustries.length && this.getView().getModel("employee").getProperty(`/searchItems/${iIndex}/BAIndustrySelectable`)){
				aSearchItem.TempBAIndustries.forEach(function(Ind){
					aBAInd.push(Ind.Desc);
				})
			}
			
			//this.getView().getModel("employee").getProperty(`/searchItems/${iIndex}/TempProfitCenter/Territories`) && this.getView().getModel("employee").getProperty(`/searchItems/${iIndex}/TempProfitCenter/Territories`).length ? aSearchParams.push(this.getView().getModel("employee").getProperty(`/searchItems/${iIndex}/TempProfitCenter/Territories`)[0].Desc) :false;
            aSearchItem.TempRoleAreas.length ? aSearchParams.push(aSearchItem.TempRoleAreas[0].Desc) :false;
			aSearchItem.SolutionAreas.length ? aSearchParams.push(aSolArea.join()) :false;
            aSearchItem.TempBALoBs.length ? aSearchParams.push(aSearchItem.TempBALoBs[0].Desc) :false;
            aSearchItem.TempCrossCvg.length ? aSearchParams.push(aSearchItem.TempCrossCvg[0].Desc) :false;
            aSearchItem.TempBAIndustries.length ? aSearchParams.push(aBAInd.join()) :false;
            this.getView().getModel("employee").getProperty(`/searchItems/${iIndex}/GrpSelectable`) && aSearchItem?.SelectedGroup?.length  ? aSearchParams.push(aSearchItem.SelectedGroup[0].GroupDesc) :false;
            const sSearchText = aSearchParams.join(" | ");
            this.getView().getModel("employee").setProperty(`/searchItems/${iIndex}/searchFieldsText`,`[${sSearchText}]`);
            this.getView().getModel("employee").refresh(true);
		},
		//change event for BA Industry comboBox
		onBAIndChange: function (oEvent) {
			var oModel = this.getView().getModel("employee");
			const iIndex = oEvent.getSource().getBindingContext("employee").getPath().split("/")[2];
			var sSelectedBAIndustry = oModel.getProperty(`/searchItems/${iIndex}/TempEmployee/selectedBAIndustry`);
			if (oEvent.getParameter("selectedItem")) {
				const oBAIndustry = oEvent.getParameter("selectedItem").getBindingContext("employee").getObject();
				const aEmployeeBAIndustries = [];
				aEmployeeBAIndustries.push({
					Guid: oBAIndustry.Guid,
					Desc: oBAIndustry.Desc,
					ClusterGuid: oBAIndustry.ClusterGuid,
					ClusterDesc: oBAIndustry.ClusterDesc,
					IsPrimary: oBAIndustry.IsPrimary,
					BaIndTechID: oBAIndustry.BaIndTechID,
					BaIndId: oBAIndustry.BaIndId
				});
				this.getView().getModel("employee").setProperty(`/searchItems/${iIndex}/TempEmployee/TempBAIndustries`, aEmployeeBAIndustries);
				this.getView().getModel("employee").setProperty(`/searchItems/${iIndex}/TempEmployee/BAIndustries`, aEmployeeBAIndustries);
				this.getView().getModel("employee").refresh(true);
			} else {
				this.getView().getModel("employee").setProperty(`/searchItems/${iIndex}/TempEmployee/TempBAIndustries`, []);
				this.getView().getModel("employee").setProperty(`/searchItems/${iIndex}/TempEmployee/BAIndustries`, []);
			}
			this._setSearchFieldText(iIndex);
			this._onEnableSearchResources(iIndex);

		},
		navToNextRequest:function(oEvent){
			const iIndex = Number(oEvent.getSource().getBindingContext("resourceModel").getPath().split("/")[1]);
			const oNavContainer = this.getView().byId("idResNavContainer")
			const currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
			const navtoPageId = currentPageId.replace(/\idResNavContainer[^\s]*/g, "") + "idResNavContainer-" + (iIndex + 1).toString();
			oNavContainer.to(navtoPageId);
			this.getView().byId("resourceModel").refresh(true);
		},
		navToPrevRequest:function(oEvent){
			const iIndex = Number(oEvent.getSource().getBindingContext("resourceModel").getPath().split("/")[1]);
			const oNavContainer = this.getView().byId("idResNavContainer")
			const currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
			const navtoPageId = currentPageId.replace(/\idResNavContainer[^\s]*/g, "") + "idResNavContainer-" + (iIndex - 1).toString();
			oNavContainer.to(navtoPageId);
			this.getView().byId("resourceModel").refresh(true);
		},
		//event for carousel change
		onCarouselChanged:function(oEvent,btnDesc,iActiveInd){
			const iActivePageIndex = oEvent ? oEvent.getSource()._getActivePageIndex() : iActiveInd;
            const aResourceModelData = this.getView().getModel("resourceModel").getData();
            const oFooter = this.oPopover.getFooter().getContent();
            if(iActivePageIndex+1 === aResourceModelData.length){
                //this.oPopover.getBeginButton().setVisible(true);
                this._remeAllCarouselStyleClass();
                this.oCrsl .addStyleClass("customStyleLeftBtnCarouselVisible");
                oFooter.forEach(function(control){
                    if(control.getCustomData()[0].getKey() === "prev"){
                        control.setVisible(true);
                    }
                    if(control.getCustomData()[0].getKey() === "next"){
                        control.setVisible(false);
                    }
                    if(control.getCustomData()[0].getKey() === "createReq"){
                        control.setVisible(true);
                    }
                })
            }else {
                //this.oPopover.getBeginButton().setVisible(false);
            }
            if(iActivePageIndex !== 0 && (iActivePageIndex+1 !== aResourceModelData.length)){
                this._remeAllCarouselStyleClass();
                this.oCrsl.addStyleClass("customStyleAllBtnCarouselVisible");
                oFooter.forEach(function(control){
                    if(control.getCustomData()[0].getKey() === "prev"){
                        control.setVisible(true);
                    }
                    if(control.getCustomData()[0].getKey() === "next"){
                        control.setVisible(true);
                    }
                    if(control.getCustomData()[0].getKey() === "createReq"){
                        control.setVisible(false);
                    }
                })
            }else if(iActivePageIndex === 0){
                this._remeAllCarouselStyleClass();
                this.oCrsl.addStyleClass("customStyleRightBtnCarouselVisible");
                oFooter.forEach(function(control){
                    if(control.getCustomData()[0].getKey() === "prev"){
                        control.setVisible(false);
                    }
                    if(control.getCustomData()[0].getKey() === "next"){
                        control.setVisible(true);
                    }
                    if(control.getCustomData()[0].getKey() === "createReq"){
                        control.setVisible(false);
                    }
                })
            }
            const aResourceData = this.getView().getModel("resourceModel").getData();
            // aResourceData.forEach(function(item){
            //     item.isConatinerVisible = false;
            // });
            aResourceModelData[iActivePageIndex].isConatinerVisible = true;
			aResourceData[0].scrollHeight = "auto";
			this.oPopover.setVerticalScrolling(true);
            if (btnDesc) {
                if (btnDesc === "next" && iActiveInd + 1 !== aResourceModelData.length) {
                    this.oPopover.getContent()[0].setActivePage(this.oPopover.getContent()[0].getPages()[ iActiveInd + 1].getId())
                }else if(btnDesc === "prev" && iActiveInd !== 0 ){
                    this.oPopover.getContent()[0].setActivePage(this.oPopover.getContent()[0].getPages()[ iActiveInd - 1].getId())
                }
            }
            this.getView().getModel("resourceModel").refresh(true);
			const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			const notifyDesc = i18nModel.getText("notificationMess");
			const sNotificationMiddleText =  i18nModel.getText("notificationMiddleText");
			let iCurrentPageIndex;
			if (btnDesc === "next") {
				iCurrentPageIndex = iActivePageIndex + 2;
			} else if (btnDesc === "prev") {
				iCurrentPageIndex = iActivePageIndex;
			} else if (oEvent) {
				iCurrentPageIndex = oEvent.getParameter("activePages")[0] + 1
			}
			const sTitle = `${notifyDesc} (${iCurrentPageIndex} ${sNotificationMiddleText} ${this.getView().getModel("resourceModel").getData().length})`
			this.oPopover.getCustomHeader().getContent()[0].setText(sTitle);
		},
		//remove style class for carousel
		_remeAllCarouselStyleClass:function(){
			this.oCrsl .removeStyleClass("customStyleLeftBtnCarouselVisible");
			this.oCrsl .removeStyleClass("customStyleRightBtnCarouselVisible");
			this.oCrsl .removeStyleClass("customStyleAllBtnCarouselVisible");
			this.oCrsl .removeStyleClass("customStyleAllBtnCarouselhidden");
		},
		//MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
		//Select Solution Area (L1)
		fnHandleLevel1Change:function(oEvent){
		  const oSelectedSLA1Context = oEvent.getParameter("selectedItem").getBindingContext("SLAMasterDataL1").getObject();
		  this.getOwnerComponent().getModel("SLAMasterDataLevels").setProperty("/isGridLayBusy",true);
		  this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",[]);
		  this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA",false);
		  this.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
		  models._getSLALevels(this,oSelectedSLA1Context);

		},
		onSelectSLA:function(oEvent){
			const oBindingContextSLA = oEvent.getSource().getBindingContext("SLAMasterDataLevels").getObject();
			this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas" , "");
			let aSelectedSLA = !this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aSelectedSolutionAreas") ? [] : this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aSelectedSolutionAreas");
			//format selected solution area based on hierachy levels
			oBindingContextSLA.SelectedSolutionArea = !oBindingContextSLA.SolAreal2Desc ? `${oBindingContextSLA.SolAreal1Desc}` : 
			 `${oBindingContextSLA.SolAreal1Desc} > ${oBindingContextSLA.SolAreal2Desc}`;
			if (oEvent.getParameter("selected")) {
				aSelectedSLA.push(oBindingContextSLA);
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA", true);
			} else if (aSelectedSLA.length) {
				aSelectedSLA = aSelectedSLA.filter(item => item.soln_guid !== oBindingContextSLA.soln_guid);
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA", true);
			}else{
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA", false);
			}
				let aSLALevel2 = this.getOwnerComponent().getModel("SLAMasterDataLevels").getData();
				aSLALevel2.results.forEach(function (data) {
					if (data.soln_guid === oBindingContextSLA.soln_guid) {
						data.IsSelected = true;
						data.isPartiallySelected = false;
					} else {
						data.IsSelected = false;
					}
				});
				const removeDuplicateSLAObjects = aSelectedSLA.filter((value, index) => {
					const _value = JSON.stringify(value);
					return index === aSelectedSLA.findIndex(obj => {
					  return JSON.stringify(obj) === _value;
					});
				  });
			
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",removeDuplicateSLAObjects);
			    this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aTokenSelectedSolutionAreas",removeDuplicateSLAObjects)
				this.getOwnerComponent().getModel("SLAMasterDataLevels").refresh(true);
				this.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
				this._OnUpdateSlaSelection();
			
		},
		onChangeSolutionAreas:function(evt){
			const oModel = this.getView().getModel("masterDataModel"),
				oBindingIndex = oModel.getProperty("/iIndex");
				// aSelectedSLA = this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aTokenSelectedSolutionAreas");
				const oSolAreaMasterDataModel=this.getOwnerComponent().getModel("SolutionAreaMasterData")
				let sL1guid=oSolAreaMasterDataModel.getProperty("/selectedLevel1Guid")
				let sL2guid=oSolAreaMasterDataModel.getProperty("/selectedLevel2Id")
				let solHierarchyMap=oSolAreaMasterDataModel.getProperty("/solHierarchyMap")
				let displayTokensMaterial=oSolAreaMasterDataModel.getProperty("/displayTokensMaterial")
				let displayTokensAdditionalSolution=oSolAreaMasterDataModel.getProperty("/displayTokensAdditionalSolution") ? oSolAreaMasterDataModel.getProperty("/displayTokensAdditionalSolution"):[];
				let oL1Data=solHierarchyMap.get(sL1guid)
				let oL2Data=solHierarchyMap.get(sL2guid)
				var aSelAddSol=oSolAreaMasterDataModel.getProperty("/displayTokensAdditionalSolution") ? oSolAreaMasterDataModel.getProperty("/displayTokensAdditionalSolution"):[];
                var aSolFinalNames=[];
				let aSolFullGuids = [];
				let aSolFullIds = [];
                if(aSelAddSol.length>0){
                    aSelAddSol.forEach(addSol=>{
                        aSolFinalNames.push(addSol.full_sol_name)
						aSolFullGuids.push(addSol.full_sol_guid)
						aSolFullIds.push(addSol.full_sol_id)
                    })
                    
                }
				var oPayload={}
				if (oL2Data) {
					 oPayload = {
								
									SelectedSolutionArea:oL1Data.soln_name+" > "+oL2Data.soln_name,
									soln_guid: oL2Data.soln_guid,
                                    soln_id: oL2Data.soln_id,
                                    soln_name: oL2Data.soln_name,
                                    solnFinalName: oL2Data.soln_name,
                                    prnt_soln_id:oL1Data.soln_id,
                                    soln_prnt_guid:oL1Data.soln_guid,                                                                     
                                    LevelId: 2,
                                    SolAreal1Guid: oL1Data.soln_guid,
                                    SolAreal1Desc: oL1Data.soln_name,
                                    SolAreal2Guid: oL2Data.soln_guid,
                                    SolAreal2Desc: oL2Data.soln_name,
									AllSelectedSolutions: aSolFinalNames.length>0 ? aSolFinalNames.join(" , ") : oL2Data.full_sol_name,
									AllSelectedGuids:aSolFullGuids.length>0  ? aSolFullGuids.join(" , ") : oL2Data.full_sol_guid,
									AllSelectedIds:aSolFullIds.length >0  ? aSolFullIds.join(" , ") : oL2Data.full_sol_id
					}
				} else if(oL1Data) {
					 oPayload = {
								SelectedSolutionArea:oL1Data.soln_name,
                                soln_guid: oL1Data.soln_guid,
                                soln_id: oL1Data.soln_id,
                                soln_name: oL1Data.soln_name,
                                solnFinalName: oL1Data.soln_name,
                                
                                soln_prnt_guid:"00000000-0000-0000-0000-000000000000",
                               
                               
                                Guid: oL1Data.soln_guid,
                                ID: oL1Data.soln_id,
                                Desc: oL1Data.soln_name,
                                LevelId: 1,
                                SolAreal1Guid: oL1Data.soln_guid,
                                SolAreal1Desc: oL1Data.soln_name,
                                DisplayGuid: oL1Data.soln_guid,
                                DisplayDesc: oL1Data.soln_name,
								AllSelectedSolutions:  oL1Data.full_sol_name,
								AllSelectedGuids:oL1Data.full_sol_guid,
								AllSelectedIds:oL1Data.full_sol_id
                                
                            };
				}
				
				
			let aSelectedSLA = []
			if (oL2Data || oL1Data) {
				aSelectedSLA.push(oPayload)
			}
				// let aAddSolutions=[]		
				// let aMaterials=[]
				oSolAreaMasterDataModel.setProperty("/selectedLevel2Id",null)
				oSolAreaMasterDataModel.setProperty("/selectedLevel1Guid",null)
				
				
				// displayTokens.forEach(token=>{
				// 	token.isMaterial ? aMaterials.push(token) : aAddSolutions.push(token)																					
				// })
				this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas`,aSelectedSLA);
				this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/TempEmployee/AdditionalSolutions`,displayTokensAdditionalSolution);
				this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/TempEmployee/Materials`,displayTokensMaterial);
				
				let oSelectParams = {
					"bIndustry":false,
					"iBindingIndex":oBindingIndex,
					"minSelect":this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/minSelect`),
					"maxSelect":this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/maxSelect`),
				};
				this._onManageIndSolSelection(oSelectParams);
				this._setSearchFieldText(oBindingIndex);
				this._onEnableSearchResources(oBindingIndex,oSelectParams);
				this.oSLASearchContext = false;
				const that = this;
				// this.solutionHierarchyDialog.close()
				// this.solutionHierarchyDialog=false
				this.solutionHierarchyDialog.then(function (oDialog) {
					oDialog.destroy();
        models.getSolutionAreaMasterData(that)

					that.solutionHierarchyDialog = false;
				});
		},
		onCloseSolutionArea: function () {
			const that = this;
			this.pSLAValueHelpDialog.then(function (oDialog) {
				oDialog.destroy();
          models.getSolutionAreaMasterData(that)
				that.pSLAValueHelpDialog = false;
				const oModel = that.getView().getModel("masterDataModel"),
				oBindingIndex = oModel.getProperty("/iIndex");
				that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",that.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas`));
				that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aTokenSelectedSolutionAreas",that.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas`));
				that.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
			});
		},
		/*Token updated delete Solution Area*/
		onDeleteSLAToken: function (oEvent) {
			const oSource = oEvent.getSource();
			const oBindingIndex = Number(oSource.getBindingContext("employee").getPath().split('/')[2]);
			this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/iIndex`, oBindingIndex);
			const oModel = this.getView().getModel("employee");
			oModel.setProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas`, "");
			oModel.setProperty(`/searchItems/${oBindingIndex}/TempEmployee/AdditionalSolutions`, []);
			this.oSLASearchContext = false;
			let oSelectParams = {
				"bIndustry":false,
				"iBindingIndex":oBindingIndex,
				"minSelect":oModel.getProperty(`/searchItems/${oBindingIndex}/minSelect`),
				"maxSelect":oModel.getProperty(`/searchItems/${oBindingIndex}/maxSelect`),
			}
			
			this._onManageIndSolSelection(oSelectParams,true)
			this._setSearchFieldText(oBindingIndex);
			this._onEnableSearchResources(oBindingIndex,oSelectParams);
	
		},
		_OnUpdateSlaSelection:function(){
			let aSLALevel2 = this.getOwnerComponent().getModel("SLAMasterDataLevels").getData();
			let that = this;
			let aSelectedSLA = this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aSelectedSolutionAreas");
			aSLALevel2.results.forEach(function (data) {
				data.isSelected = false;
				data.isPartiallySelected = false;
				if (data.is_ChildLoaded && data.to_Child.length) {
					data.to_Child.forEach(function (child) {
						child.isSelected = false;
						child.isPartiallySelected = false;
						child.solnFinalName = child.SolAreal2Desc;
					});
				}
			});
			if(aSelectedSLA.length){
				aSelectedSLA.forEach(function(oContextSolutionArea){
					aSLALevel2.results.forEach(function (data) {
						//data.isSelected = false;
						that.oParentData = data;
						if(oContextSolutionArea.soln_guid === data.soln_guid){
							data.isSelected = true;
							data.isPartiallySelected = false;
						}
						if (data.is_ChildLoaded && data.to_Child.length) {
							data.to_Child.forEach(function (child) {
								//child.isSelected = false;
								if(oContextSolutionArea.soln_guid === child.soln_guid){
									child.isSelected = true;
									child.isPartiallySelected = false;
								}
								if(child.isSelected && !that.oParentData.isSelected && !that.oParentData.isPartiallySelected){
								//	oContextSolutionArea.isSelected = true;
									that.oParentData.isSelected = true;
									that.oParentData.isPartiallySelected = true;
									that.getOwnerComponent().getModel("SLAMasterDataL1").getData().aSelectedSolutionAreas.push(that.oParentData);
								}
							});
						}
					});
				})	

				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA", true);
			}else{
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA", false);
			}
		
			this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",aSelectedSLA)
			if(this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aSelectedSolutionAreas").length > 1){
				let filteredData = this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aTokenSelectedSolutionAreas").filter(item => item.to_Child.length === 0)
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aTokenSelectedSolutionAreas" , filteredData);
			}
			this.getOwnerComponent().getModel("SLAMasterDataLevels").refresh();
			this.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
		},
		//delete solution area master data selection
		fnDeleteSolMatTokens:function(oEvent){
			const oContext = oEvent.getParameter("removedTokens")[0].getBindingContext("SLAMasterDataL1").getObject();
			if(!this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aSelectedSolutionAreas").length){
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA",false);
			}else{
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA",true);
			}
			this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas" , "");
			this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aTokenSelectedSolutionAreas" , "");
			this.getOwnerComponent().getModel("SLAMasterDataLevels").refresh();
			this.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
			this._OnUpdateSlaSelection();
		},
		onAfterOpenSLAPopover: function () {
			const oTree = this.byId("idSolutionTreeOnCreate");
			let aSelectedItems = oTree.getItems();
			let aSelectedIndices = [];
			for (var i = 0; i < aSelectedItems.length; i++) {
				aSelectedIndices.push(oTree.indexOfItem(aSelectedItems[i]));
			}
			oTree.collapse(aSelectedIndices);
		},
		systemLSDataModel: function (self) {
            //set oData model for ISP
            const componentName = this.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
            const componentPath = sap.ui.require.toUrl(componentName);
            // call ymr_srv service for solution areas
            const oDataModel = new ODataModel({
                serviceUrl: `${componentPath}/int_pc/sap/opu/odata/sap/ymr_srv`
            });
            return oDataModel;
 
        },
		//filter soution area based on solution name
		onSearchSolutionArea: function (oEvent) {
			const query = oEvent ? oEvent.getSource().getValue().trim():"";
			const oTree = this.byId("idSolutionTreeOnCreate");
			oTree.getBinding("items").filter(
				query
					? new sap.ui.model.Filter({
						path: "soln_name",
						operator: sap.ui.model.FilterOperator.Contains,
						value1: query,
					})
					: null
			);
			oTree.expandToLevel(query ? 99 : 0);
		    if(!query){
				oTree.collapseAll();
			}
		},
		onOpenLegacyTerritoryValueHelpDialog:function(oEvent){
			appView.listView.onOpenTerritoryValueHelpDialog(oEvent);
		},
		onOpenTerritoryValueHelpDialog: function(oEvent) {
			const that = this,
			 	  oModel = appView.listView.getView().getModel("selectedProfitCenter"),
				  oBindingIndex = Number(oEvent.getSource().getBindingContext("employee").getPath().split('/')[2]);
			
			this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/iIndex`, oBindingIndex);
			this.bSelectPfc = false;
			this.iBindingIndex = oBindingIndex;
			if (!this.pTerritoryValueHelpDialog) {
				this.pTerritoryValueHelpDialog = this.loadFragment({
					name:"com.dealsupport.melodyrequest.fragments.TerritoryValueHelpDialog"
				});
			}

			this.pTerritoryValueHelpDialog.then(function (oDialog) {
				that.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/legacyValidation`,false);
				that.getView().byId("territoriesTableId").getExtension()[0].getContent()[0].setValue();
				that.filterTerritories();
				that.getView().setModel(new sap.ui.model.json.JSONModel(that.getView().getModel("treeTerritories").getData()), "treeTerritories");
				oModel.refresh(true);
				oDialog.openBy(oEvent.getSource());
				that.getView().setModel(new sap.ui.model.json.JSONModel(), "masterDataModel");
				const oMasterDataModel = that.getView().getModel("masterDataModel");
				oMasterDataModel.setData(that.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}`));
				that.getView().getModel("masterDataModel").refresh();
			});

		  },
		  /*Filter Profit center master data*/
		filterTerritories: function (initLoad, isRegionMUChange) {
			const oModel = this.getView().getModel("employee");
			const oTerritoryModel = appView.getView().getModel("territoriesMaster");
			const aTerritories = oTerritoryModel.getData();
			let oTempEmployee;
			if(!oModel.getProperty(`/searchItems/${this.iBindingIndex}/TempProfitCenter`)){
				 const oFinalData =  { "Territories": [] }
				 oModel.setProperty(`/searchItems/${this.iBindingIndex}/TempProfitCenter`,oFinalData);
				 oModel.setProperty(`/searchItems/${this.iBindingIndex}/selectedPfc`,"");
				 oTempEmployee = oModel.getProperty(`/searchItems/${this.iBindingIndex}/TempProfitCenter`);
			}else{
				 oTempEmployee = oModel.getProperty(`/searchItems/${this.iBindingIndex}/TempProfitCenter`);
			}
			let aEmployeeTerritories = oTempEmployee ? oTempEmployee.Territories :[];
			oTempEmployee.TempTreeTerritories = oTempEmployee.Territories;

			//remove parent node if checkbox selection or isResourceProfile false;

			const aSelectedPfc = oModel.getProperty(`/searchItems/${this.iBindingIndex}/TempProfitCenter/Territories`);
			let isResourceProfileFound = aSelectedPfc.some(function (resource) {
				return resource.isResourceProfile;
			});
			if (aSelectedPfc.length > 1) {
				for (let i = 0; i < aSelectedPfc.length; i++) {
					if (!aSelectedPfc[i].isCheckBox || !aSelectedPfc[i].isResourceProfile&& isResourceProfileFound) {
						aSelectedPfc.splice(i, 1)
					}
				}
			}

			if (isRegionMUChange) {
				aEmployeeTerritories = oTempEmployee.TempTreeTerritories;
			}

			let aTempTerritory = [];
			let bSelected = oModel.getProperty(`/searchItems/${this.iBindingIndex}/TempEmployee/TempMuRegionFlg`);
			let aFilteredTerritories = aTerritories;

			if (bSelected) {
				aFilteredTerritories = aTerritories.filter(function (item) {
					return item.MuBelow === "";
				});
			}
			this.loadTreeTerritories("treeTerritories",aFilteredTerritories);
			oModel.refresh(true);
			
			appView.detailViewScreen.getView().getModel("selectedProfitCenter").getData()
			//this.setTerritoryHierarchySelection(false,true);
		},
		loadTreeTerritories: function (type, results, bParentNodeSelection) {
			let aTerritories = [];
			let aSlectedProfitCenter = this.getView().getModel("employee").getProperty(`/searchItems/${this.iBindingIndex}/TempProfitCenter/Territories`);
			if(!this.getView().getModel("treeTerritories")){
				let _loop = function _loop(i) {
					if (results[i].isFiltered) {
						let oCluster = aTerritories.find(function (item) {
							return item.TrpcL1Desc === results[i].TGlobal;
						});
	
						if (!oCluster && results[i].TGlobal && results[i].TGlobal !== "") {
							let oPCCluster = results.find(function (item) {
								return item.TrpcDesc.toUpperCase().trim() === results[i].TGlobal.toUpperCase().trim();
							});
							oCluster = {
								guid: oPCCluster.TrpcGuid,
								id: oPCCluster.TrpcId,
								isResourceProfile: oPCCluster.isResourceProfile,
								desc: results[i].TGlobal,
								TrpcDesc: oPCCluster.TrpcDesc,
								Name: oPCCluster.Name,
								displaydesc: results[i].TGlobal,
								IsPrimary: false,
								IsEnabled: false,
								IsSelected: false,
								bPrimaryRole: results[i].bPrimaryRole,
								bSelectedRole: results[i].bSelectedRole,
								isRadioBtVisible: results[i].isRadioBtVisible,
								isPrimary: results[i].isPrimary,
								nodes: [],
								LevelId: "0001",
								TrpcL1Desc: results[i].TGlobal,
								isCheckBox: oPCCluster.isCheckBox,
								isChildNodeEnable: oPCCluster.isChildNodeEnable,
								isParentNodeEnable: oPCCluster.isParentNodeEnable,
								GrpSelectable: oPCCluster.GRP_Selectable,
								ParentGroupSelectable: ""
							};
							if (aSlectedProfitCenter.length && aSlectedProfitCenter[0].SelectedGuid === results[i].TrpcGuid) {
								oCluster.IsSelected = true;
							}
							aTerritories.push(oCluster);
							aTerritories.sort(function (a, b) {
								return a.desc.localeCompare(b.desc);
							});
						}
	
						if (oCluster) {
							let aL1 = oCluster.nodes;
							let oL1 = aL1.find(function (item) {
								return item.TrpcL2Desc === results[i].Region;
							});
	
							if (!oL1 && results[i].Region && results[i].Region !== "") {
								// const oPCL1 = results.find(item => item.Name.includes(results[i].Region));
								let oPCL1 = results.find(function (item) {
									return item.TrpcDesc.toUpperCase().trim() === results[i].Region.toUpperCase().trim();
								});
								oL1 = {
									guid: oPCL1.TrpcGuid,
									id: oPCL1.TrpcId,
									desc: results[i].Region,
									TrpcDesc: oPCL1.TrpcDesc,
									isResourceProfile: oPCL1.isResourceProfile,
									isCheckBox: oPCL1.isCheckBox,
									isChildNodeEnable: oPCL1.isChildNodeEnable,
									isParentNodeEnable: oPCL1.isParentNodeEnable,
									Name: oPCL1.Name,
									displaydesc: results[i].TGlobal + " > " + results[i].Region,
									IsPrimary: false,
									IsEnabled: false,
									IsSelected: false,
									bPrimaryRole: results[i].bPrimaryRole,
									bSelectedRole: results[i].bSelectedRole,
									isRadioBtVisible: results[i].isRadioBtVisible,
									isPrimary: results[i].isPrimary,
									nodes: [],
									LevelId: "0002",
									TrpcL1Desc: results[i].TGlobal,
									TrpcL2Desc: results[i].Region,
									GrpSelectable: oPCL1.GRP_Selectable,
									ParentGroupSelectable: oCluster.GrpSelectable
								};
								if (aSlectedProfitCenter.length && aSlectedProfitCenter[0].SelectedGuid === results[i].TrpcGuid) {
									oL1.IsSelected = true;
								}
								aL1.push(oL1);
								aL1.sort(function (a, b) {
									return a.desc.localeCompare(b.desc);
								});
							}
	
							if (oL1) {
								let aL2 = oL1.nodes;
								let oL2 = aL2.find(function (item) {
									return item.TrpcL3Desc === results[i].Mu;
								});
	
								if (!oL2 && results[i].Mu && results[i].Mu !== "") {
									let oPCL2 = results.find(function (item) {
										return item.TrpcDesc.toUpperCase().trim() === results[i].Mu.toUpperCase().trim();
									}); 
	
									if (!oPCL2) {
										oPCL2 = results[i];
									}
	
									oL2 = {
										guid: oPCL2.TrpcGuid,
										id: oPCL2.TrpcId,
										isResourceProfile: oPCL2.isResourceProfile,
										isCheckBox: oPCL2.isCheckBox,
										isParentNodeEnable: oPCL2.isParentNodeEnable,
										isChildNodeEnable: oPCL2.isChildNodeEnable,
										desc: results[i].Mu,
										TrpcDesc: oPCL2.TrpcDesc,
										Name: oPCL2.Name,
										displaydesc: results[i].TGlobal + " > " + results[i].Region + " > " + results[i].Mu,
										IsPrimary: false,
										IsEnabled: false,
										IsSelected: false,
										bPrimaryRole: results[i].bPrimaryRole,
										bSelectedRole: results[i].bSelectedRole,
										isRadioBtVisible: results[i].isRadioBtVisible,
										isPrimary: results[i].isPrimary,
										nodes: [],
										LevelId: "0003",
										TrpcL1Desc: results[i].TGlobal,
										TrpcL2Desc: results[i].Region,
										TrpcL3Desc: results[i].Mu,
										GrpSelectable: oPCL2.GRP_Selectable,
										ParentGroupSelectable: oL1.GrpSelectable
									};
									if (aSlectedProfitCenter.length && aSlectedProfitCenter[0].SelectedGuid === results[i].TrpcGuid) {
										oL2.IsSelected = true
									};
									aL2.push(oL2);
									aL2.sort(function (a, b) {
										return a.desc.localeCompare(b.desc);
									});
								}
	
								if (oL2) {
									let aL3 = oL2.nodes;
									let oL3 = aL3.find(function (item) {
										return item.TrpcL4Desc === results[i].MuBelow;
									});
	
									if (!oL3 && results[i].MuBelow && results[i].MuBelow !== "") {
										// const oPCL3 = results.find(item => item.Name.includes(results[i].MuBelow));
										let oPCL3 = results.find(function (item) {
											return item.TrpcDesc.toUpperCase().trim() === results[i].MuBelow.toUpperCase().trim();
										});
	
										if (!oPCL3) {
											oPCL3 = results[i];
										}
	
										oL3 = {
											guid: oPCL3.TrpcGuid,
											id: oPCL3.TrpcId,
											isResourceProfile: oPCL3.isResourceProfile,
											isCheckBox: oPCL3.isCheckBox,
											isChildNodeEnable: oPCL3.isChildNodeEnable,
											isParentNodeEnable: oPCL3.isParentNodeEnable,
											desc: results[i].MuBelow,
											TrpcDesc: oPCL3.TrpcDesc,
											Name: oPCL3.Name,
											displaydesc: results[i].TGlobal + " > " + results[i].Region + " > " + results[i].Mu + " > " + results[i].MuBelow,
											IsPrimary: false,
											IsEnabled: false,
											IsSelected: false,
											bPrimaryRole: results[i].bPrimaryRole,
											bSelectedRole: results[i].bSelectedRole,
											isRadioBtVisible: results[i].isRadioBtVisible,
											isPrimary: results[i].isPrimary,
											TrpcL1Desc: results[i].TGlobal,
											TrpcL2Desc: results[i].Region,
											TrpcL3Desc: results[i].Mu,
											TrpcL4Desc: results[i].MuBelow,
											nodes: [],
											LevelId: "0004",
											GrpSelectable: oPCL3.GRP_Selectable,
											ParentGroupSelectable: oL2.GrpSelectable
										};
										if (aSlectedProfitCenter.length && aSlectedProfitCenter[0].SelectedGuid === results[i].TrpcGuid) {
											oL3.IsSelected = true;
										}
										aL3.push(oL3);
										aL3.sort(function (a, b) {
											return a.desc.localeCompare(b.desc);
										});
									}
								}
							}
						}
					}
				};
	
				for (let i = 0; i < results.length; i++) {
					_loop(i);
				}
				const oTreeTerritoriesModel = new sap.ui.model.json.JSONModel({
					type: type,
					territories: aTerritories,
					leadTerritories: aTerritories
				});
				var oModel = oTreeTerritoriesModel;
				var oData = oModel.getData();
	
				function updateNodes(nodes) {
					nodes.forEach(function (node) {
						node.isMargin = (!node.nodes || node.nodes.length === 0);
						if (node.nodes && node.nodes.length > 0) {
							updateNodes(node.nodes);
						}
					});
				}
				if (oData.territories && oData.territories.length > 0) {
					updateNodes(oData.territories);
				}
	
				oModel.setData(oData);
				this.getView().setModel(oTreeTerritoriesModel, "treeTerritories");
			}else{
				let aTerritories = this.getView().getModel("treeTerritories").getData();
				function updateTreeNodes(nodes,isResetNodes) {
					nodes.forEach(function (node) {
						node.IsSelected = false;
						 if(aSlectedProfitCenter.length && node.guid === aSlectedProfitCenter[0]["SelectedGuid"]){
							node.IsSelected = true;
						}
						if (node.nodes && node.nodes.length > 0) {
							updateTreeNodes(node.nodes);
						}
						
						
					});
				}
				if (aTerritories.territories && aTerritories.territories.length > 0) {
					updateTreeNodes(aTerritories.territories);
				}
				
				this.getView().getModel("treeTerritories").setData(aTerritories);
				this.getView().getModel("treeTerritories").refresh();

			}
			

		},
		/*Set hierachy selection for profit center*/
		setTerritoryHierarchySelection: function (initLoad, forceReset, oBindingContext, bParanetNodeSelection, initialSelection) {
			const oModel = this.getView().getModel("employee");
			const oTempEmployee = oModel.getProperty(`/searchItems/${this.iBindingIndex}/TempProfitCenter`);
			const aTempTreeTerritories = bParanetNodeSelection ? oTempEmployee.Territories : oTempEmployee.TempTreeTerritories;
			const oTerritoryHierarchyModel = this.getView().getModel("treeTerritories");
			let that = this;
			let aTerritoryHierarchies = oTerritoryHierarchyModel.getData();
			aTerritoryHierarchies = aTerritoryHierarchies.territories;
			aTerritoryHierarchies = this.selectIfTerritoryExists(aTerritoryHierarchies, [], 0, forceReset, bParanetNodeSelection, initialSelection);
			let aTerritory = [];
			for (let i = 0; i < aTempTreeTerritories.length; i++) {
				let aDesc = aTempTreeTerritories[i].SelectedDesc.split(">");

				if (initLoad) {
					let territory = {};
					territory.Desc = aTempTreeTerritories[i].Desc;
					territory.Guid = aTempTreeTerritories[i].Guid;
					territory.IsPrimary = aTempTreeTerritories[i].IsPrimary;
					territory.TrpcId = aTempTreeTerritories[i].TrpcId;

					for (let j = 1; j <= 5; j++) {
						territory["TrpcL" + j + "Desc"] = aTempTreeTerritories[i]["TrpcL" + j + "Desc"];
					}

					let oTerritory = models._setProfitCenterObj(oTerritory);
					aTerritory.push(oTerritory);
				}

				aTerritoryHierarchies = this.selectIfTerritoryExists(aTerritoryHierarchies, aDesc, 0, false, bParanetNodeSelection, initialSelection);
			}

			if (initLoad) {
				oTempEmployee.Territories = aTerritory;
				oModel.setProperty(`/searchItems/${that.iBindingIndex}/TempEmployee/TRPCPGUIDValueState`, "None");
			}

			oModel.refresh(true);
			if (oBindingContext) {
				let root = oBindingContext.getObject();
				let nodeUpdate = function nodeUpdate(newValue, that) {
					for (const child of newValue.nodes) {
						if (child.isCheckBox && child.isResourceProfile) {
							child.IsSelected = true;
							let oSelectedProfitCenter = models._setProfitCenterObj(child);
							that.getView().getModel("employee").getProperty(`/searchItems/${that.iBindingIndex}/TempProfitCenter/TempTreeTerritories`).push(
								oSelectedProfitCenter);
							that.getView().getModel("employee").refresh(true);
						}
						nodeUpdate(child, that);
					}
				}
				if (root.isResourceProfile && root.isChildNodeEnable) {
					//select child nodes if isResourceProfile true for parent node
					nodeUpdate(root, that);
				}
			}
			oTerritoryHierarchyModel.refresh(true);
		},
		/*Check if profit center exist or not*/
		selectIfTerritoryExists: function (Territory, desc, index, forceReset, bParentNodeSelection, initialSelection) {
			if (!Territory || Territory.length === 0) {
				return [];
			}
			const that = this;
			const oModel = this.getView().getModel("employee");
			const oTempEmployee = oModel.getProperty(`/searchItems/${this.iBindingIndex}/TempProfitCenter`);
			const aTempTreeTerritories = oTempEmployee.TempTreeTerritories;
			let oPrimaryTerritory;
			if(!bParentNodeSelection){
				oPrimaryTerritory = aTempTreeTerritories.find(function (item) {
					return item.IsPrimary;
				});

			}
			for (let j = 0; j < Territory.length; j++) {
				let territory = Territory[j];
				if (!forceReset) {
					if (territory.desc.toUpperCase().trim() === (desc && desc[index] && desc[index].toUpperCase().trim())) {
					if(bParentNodeSelection && !initialSelection){
						if(desc.length-2 === index){
								territory.IsSelected = true;
								let oSelectedProfitCenter = models._setProfitCenterObj(territory);
								that.getView().getModel("employee").setProperty(`/searchItems/${that.iBindingIndex}/TempProfitCenter/Territories`,[oSelectedProfitCenter]);
								that.aSelectedParentNode = territory;
							}
						} else if (desc.length - 1 === index && !bParentNodeSelection) {
							that.aSelectedParentNode = territory;
							territory.IsSelected = true;
						}


						if (territory.desc.toUpperCase().trim() === desc[desc.length - 1].toUpperCase().trim()) {
					if(initialSelection){
								this.aSelectedParentNode = territory;
							}
							territory.IsEnabled = true;
						} else {
							territory.IsEnabled = false;
						}
				if(!bParentNodeSelection){
							if (territory.IsSelected && aTempTreeTerritories.length === 1 && aTempTreeTerritories[0].Desc.toUpperCase().trim() === territory.desc.toUpperCase().trim()) {
								territory.IsPrimary = aTempTreeTerritories[0].IsPrimary;
							} else if (oPrimaryTerritory && oPrimaryTerritory.Desc.toUpperCase().trim() === territory.desc.toUpperCase().trim()) {
								territory.IsPrimary = true;
							} else {
								territory.IsPrimary = false;
							}
						}

						if (territory.nodes && territory.nodes.length > 0) {
					territory.nodes = this.selectIfTerritoryExists(territory.nodes, desc, index + 1,false,bParentNodeSelection,initialSelection);
						}
					}
				} else {
					territory.IsSelected = false;
					territory.IsPrimary = false;
				territory.nodes = this.selectIfTerritoryExists(territory.nodes, desc, index + 1, true,bParentNodeSelection,initialSelection);
				}

				Territory[j] = territory;
			}

			return Territory;
		},
		/*Update selected profit center*/
		onChangeTerritories: function onChangeTerritories(oEvent) {
			if (this.bSelectPfc) {
				this.aNonSelectableParentNode = false;
				appView._onDestroyAllResourcePopOvers();
				appView.onOpenBusyDialog();
				const oModel = this.getView().getModel("employee");
				const oTempEmployee = oModel.getProperty(`/searchItems/${this.iBindingIndex}/TempProfitCenter`);
				if(!appView.detailViewScreen.getView().getModel("selectedProfitCenter").getData()){
					appView.detailViewScreen.getView().setModel(new sap.ui.model.json.JSONModel(),"selectedProfitCenter");
				}
				appView.detailViewScreen.getView().getModel("selectedProfitCenter").setProperty("/TempProfitCenter",oTempEmployee)
				appView.detailViewScreen.getView().getModel("selectedProfitCenter").setProperty("/selectedPfc",oModel.getProperty(`/searchItems/${this.iBindingIndex}/selectedPfc`))
				let aTerritory = [];
				const aEmployeeTerritories = oTempEmployee.TempTreeTerritories;
				const iPrimaryIndex = aEmployeeTerritories.findIndex(function (item) {
					return item.IsPrimary;
				});

				for (let i = 0; i < aEmployeeTerritories.length; i++) {
					let territory = {};
					territory.Desc = aEmployeeTerritories[i].Desc;
					territory.guid = aEmployeeTerritories[i].guid;
					territory.IsPrimary = aEmployeeTerritories[i].IsPrimary;
					territory.id = aEmployeeTerritories[i].TrpcId;
					territory.TrpcDesc = aEmployeeTerritories[i].Desc;
					territory.isResourceProfile = aEmployeeTerritories[i].isResourceProfile;
					territory.isCheckBox = aEmployeeTerritories[i].isCheckBox;
					territory.isChildNodeEnable = aEmployeeTerritories[i].isChildNodeEnable;
					territory.isParentNodeEnable = aEmployeeTerritories[i].isParentNodeEnable;
					territory.GrpSelectable =aEmployeeTerritories[i].GrpSelectable;
					territory.ParentGroupSelectable =aEmployeeTerritories[i].ParentGroupSelectable;

					for (let j = 1; j <= 5; j++) {
						territory["TrpcL" + j + "Desc"] = aEmployeeTerritories[i]["TrpcL" + j + "Desc"];
					}

					const oTerritory = models._setProfitCenterObj(territory);
					aTerritory.push(oTerritory);
				}

				oTempEmployee.Territories = aTerritory;
				this.onCloseTerritoryValueHelpDialog();
				//this.getView().byId("idProfitCenterFormattedText").setVisible(true);
				if (appView.detailViewScreen && appView.detailViewScreen.getView().getModel("employee")) {
					this.sStatus = "changePFC";
				} else {
					this.sStatus = "initialLoad";
				}
				let sorgID;
				appView.listView.getView().getModel("PCSalesOrgMaster").getData().find(function (item) {
					if (item.ProfitCenterGuid === oTempEmployee.Territories[0].guid) {
						sorgID = item.SOrg;
					}
				});
				appView.oFinalData.OrgID = "SORG-" + ('0000' + sorgID).slice(-4);
				if (sorgID === "NOMP") {
					sorgID = oTempEmployee.Territories[0].guid;
					appView.oFinalData.OrgID = sorgID;
					appView.oFinalData.isNoMP = true;
					appView.oFinalData.OrgType = "PC";
				}
				//this.getView().byId("idProfitCenterAccountFormattedText").setVisible(true);
				// if (appView.listView.getView().byId("multiInputAccount").getTokens().length) {
				// 	appView.oFinalData.OrgID = oTempEmployee.Territories[0].guid;
				// 	//this._setDetailScreen(sorgID);
				// } else if (appView.listView.getView().byId("idOppRadioBtn").getSelected()) {
				// 	//this._setDetailScreen(sorgID);
				// } else {
				// 	//appView.bus.publish("flexible", "setListPage");
				// }
				//this._setDetailScreen(sorgID);
				oModel.refresh(true);
				this.getView().getModel("employee").setProperty(`/searchItems/${this.iBindingIndex}/selectedPfc`, this.getView().getModel("employee").getProperty(`/searchItems/${this.iBindingIndex}/TempProfitCenter/Territories/0`));
				appView.onCloseBusyDialog();
			} else {
				appView.onCloseBusyDialog();
				this.onCloseTerritoryValueHelpDialog();
			}
			if (this.getView().getModel("employee").getProperty(`/searchItems/${this.iBindingIndex}/selectedPfc`)) {
				//set profit center text
				this.getView().getModel("employee").setProperty(`/searchItems/${this.iBindingIndex}/isPfcSelected`, true);
			} else {
				this.getView().getModel("employee").setProperty(`/searchItems/${this.iBindingIndex}/isPfcSelected`, false);
			}
			this.getView().getModel("employee").refresh();
			this._setSearchFieldText(this.iBindingIndex);
			let oModel = this.getView().getModel("employee");
			if(appView.detailViewScreen.getView().getModel("selectedProfitCenter") && !appView.detailViewScreen.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories/0/isResourceProfile") && appView.oFinalData.OrgID){
				appView.oFinalData.isResourceProfile = false;
				appView.listView.getView().setModel(new sap.ui.model.json.JSONModel({
					TempProfitCenter:oModel.getProperty(`/searchItems/${this.iBindingIndex}/TempProfitCenter`)
					}),"selectedProfitCenter");
				appView.listView.getView().getModel("selectedProfitCenter").setProperty("/selectedPfc",oModel.getProperty(`/searchItems/${this.iBindingIndex}/selectedPfc`));
				appView.listView.getView().getModel("selectedProfitCenter").refresh();
				appView.listView._setFooterButton(appView.oFinalData.isResourceProfile);
				appView.isResourceProfileScreen = false;
				let orgId;
				
				if (appView.oFinalData.OrgID.includes("SORG")) {
					orgId = Number(appView.oFinalData.OrgID.replace('SORG-', '')).toString();
				} else {
					orgId = appView.oFinalData.OrgID;;
				}
					models.getPublicReqArea(appView, orgId, appView.listView.fnSuccessPublicReqAreaCallback);
			}
			this._onEnableSearchResources(this.iBindingIndex);
		},
		onCloseTerritoryValueHelpDialog: function(evt) {
			this.pTerritoryValueHelpDialog.then(function (oDialog) {
			  oDialog.close();
			});
		  },
		  /*Select profit center*/
		onSelectTerritory: function (oEvent) {
			this.bSelectPfc = true;
			this.selectIfTerritoryExists(this.getView().getModel("treeTerritories").getData().territories, [], 0, true);
			const oModel = this.getView().getModel("employee");
			const oSource = oEvent.getSource();
			let bSelected = oEvent.getParameter("selected");
			let sSelectedDesc = oSource.data("displaydesc");
			const oBindingContext = oSource.getBindingContext("treeTerritories");
			const oTerritoryModel = oBindingContext.getModel();
			const sPath = oBindingContext.getPath();
			const oTerritory = oTerritoryModel.getProperty(sPath);
			oTerritory.IsSelected = true;
			this.oSelectedPFCNode = oTerritory.nodes;
			if(!oBindingContext.getObject().isResourceProfile){
				//legacy profit center
				this.getView().getModel("masterDataModel").setProperty("/legacyValidation",true);
			}else{
				this.getView().getModel("masterDataModel").setProperty("/legacyValidation",false);
			}
			this.getView().getModel("masterDataModel").refresh();
			oTerritory.nodes = this.selectIfTerritoryExists(oTerritory.nodes, [], 0, false);
			const oTempEmployee = oModel.getProperty(`/searchItems/${this.iBindingIndex}/TempProfitCenter`);
			let aEmployeeTerritories = oTempEmployee.TempTreeTerritories;
			aEmployeeTerritories = aEmployeeTerritories.filter(function (item) {
				return !item.Desc.includes(sSelectedDesc);
			});
			let iIndex = aEmployeeTerritories.findIndex(function (item) {
				return item.Desc.toUpperCase().trim() === oTerritory.displaydesc.toUpperCase().trim();
			});

			if (iIndex !== -1 && !bSelected) {
				aEmployeeTerritories.splice(iIndex, 1);
				oTerritory.IsPrimary = false;
			} else if (iIndex === -1 && bSelected) {
				if (aEmployeeTerritories.length === 0) {
					oTerritory.IsPrimary = true;
				} else if (aEmployeeTerritories.length === 1 && aEmployeeTerritories[0].IsPrimary) {
					aEmployeeTerritories[0].IsPrimary = false;
				}
				aEmployeeTerritories = [];
				const oProfitCenter = models._setProfitCenterObj(oTerritory);
				aEmployeeTerritories.push(oProfitCenter);
			} else {
				if (iIndex !== -1) {
					aEmployeeTerritories.splice(iIndex, 1);
				}
			}

			oModel.setProperty(`/searchItems/${this.iBindingIndex}/TempProfitCenter/TempTreeTerritories`, aEmployeeTerritories);
			const oMasterDataModel = this.getView().getModel("masterDataModel");
			oMasterDataModel.setData(this.getView().getModel("employee").getProperty(`/searchItems/${this.iBindingIndex}`));
			this.getView().getModel("masterDataModel").refresh();
			oModel.refresh(true);
			oTerritoryModel.refresh(true);
			this.setTerritoryHierarchySelection(false, false, oBindingContext);
		},
		/*Search profit center*/
		onSearchTerritory: function onSearchTerritory(oEvent) {
			const query = oEvent.getSource().getValue().trim();
			const TableId = oEvent.getSource().getParent().getParent();
			TableId.getBinding("rows").filter(query ? new Filter({
			  path: "desc",
			  operator: "Contains",
			  value1: query
			}) : null);
			TableId.expandToLevel(query ? 99 : 0);
		  },
		//show info/hint message
		onShowInfoMessage:function(evt){
			if(evt.getSource().getCustomData()[0].getKey().includes('Role_InfoBubble')){
				if(this.getOwnerComponent().getModel("mrrAppEngModel").getData().engagementSelectedKey=='0002'){
                    evt.getSource().getCustomData()[0].setKey("Role_InfoBubbleFBS")
                }else{
                    evt.getSource().getCustomData()[0].setKey("Role_InfoBubble")
                }
			}				
			CommonJS._onShowInfoMessage(evt,this);
		},
		//valuehelp request of new solution hierarchy
		onOpenSolutionHierarchy: async function(oEvent){
    //  models.getSolutionAreaMasterData(this)
			this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/results",[]);
			const that = this,
				 oBindingIndex = Number(oEvent.getSource().getBindingContext("employee").getPath().split('/')[2]),
				 aSLAMasterData =   this.getOwnerComponent().getModel("SLAMasterDataL1").getData().results;
				 that.getView().setModel(new sap.ui.model.json.JSONModel(), "masterDataModel");
				const oMasterDataModel = that.getView().getModel("masterDataModel");
			// 	if(this.oSLASearchContext){
			// 		this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas`,this.oSLASearchContext)
			// 	}
			// if (this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas`)) {
			// 	this.oSLASearchContext = JSON.parse(JSON.stringify(this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas`)));
			// }
				oMasterDataModel.setData(that.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}`));
				oMasterDataModel.refresh();
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",[]);
			if (!this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas/0`)) {
				//set defualy solution area L1
				//this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/selectedSolAreaL1",aSLAMasterData[0].SolGuid);
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",aSLAMasterData);
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA",false)
			}else if(this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas/0`)){
				//set selected solution area L1
				this.oContextSolutionArea = this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas/0`);
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/selectedSolAreaL1",
				this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas/0/soln_prnt_guid`));
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas`));
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA",true)
			}
			this.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
			this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/iIndex`, oBindingIndex);
			// this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/TempEmployee/slaBusy`,true);

			if(that.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas`)){
					that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",that.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/SolutionAreas`));
				}
			let oModel=this.getOwnerComponent().getModel("SolutionAreaMasterData")
			if (!this.solutionHierarchyDialog) {
				this.solutionHierarchyDialog = this.loadFragment({
					name: "com.dealsupport.melodyrequest.fragments.resourceProfile.SolutionHierarchy",
				});				
			}
			this.solutionHierarchyDialog.then(function (oDialog) {
				oDialog.open()
				this.SADialog = oDialog;
				// var aSolnL1Data = oModel.getProperty("/level1Data")
				// aSolnL1Data.sort(function (a, b) {
				// 	return a.SolName.localeCompare(b.SolName)
				// })
				oModel.setProperty("/materialsContainerVisible",false);
				this.byId("idSlnFormGrid").addStyleClass("customStyleSlnSmallGrid");
				this.byId("idSlnFormGrid").removeStyleClass("customStyleSlnGrid");
				this.byId("idSlnTree").getContent()[0].addStyleClass("styleSlnTreeScroll")
				this.byId("idSlnTree").setDefaultSpan("XL12 L12 M12 S12");
				this.byId("idSlnToolbarGrid").setDefaultSpan("XL12 L12 M12 S12");
					oDialog.setContentWidth("52%")
				let prevSelData = this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee`)
				let prevSelSolArea = prevSelData.SolutionAreas ? prevSelData.SolutionAreas : []
				
				var solHierarchyMap = oModel.getProperty("/solHierarchyMap")
				if (prevSelSolArea.length > 0) {
					if (prevSelSolArea[0].soln_prnt_guid == '00000000-0000-0000-0000-000000000000') {
						oModel.setProperty("/selectedLevel1Guid", prevSelSolArea[0].soln_guid)
						oModel.setProperty("/showDisplayMaterials", false)
					let mMaterialMap = oModel.getProperty("/materialMap") ? oModel.getProperty("/materialMap"):[];
					mMaterialMap.forEach((arr, key) => {
						arr.forEach(value => {
							value.selected = false
						})
					})
					oModel.setProperty("/materials", [])
					oModel.setProperty("/displayTokensMaterial", [])
					oModel.setProperty("/displayTokensAdditionalSolution", [])
						this.onChangeDisplayFullSolHierarchy(false)
						// var foundL1 = aSolnL1Data.find(item => item.soln_guid == prevSelSolArea[0].soln_guid)
						// models._loadChildren(this, foundL1, null, true)
					

					} else {
						oModel.setProperty("/displayTokensAdditionalSolution", this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/AdditionalSolutions`))
						oModel.setProperty("/selectedLevel1Guid", prevSelSolArea[0].soln_prnt_guid)
						oModel.setProperty("/selectedLevel2Id", prevSelSolArea[0].soln_guid)
						oModel.setProperty("/showDisplayMaterials", false)
					let mMaterialMap = oModel.getProperty("/materialMap") ?  oModel.getProperty("/materialMap"):[];
					mMaterialMap.forEach((arr, key) => {
						arr.forEach(value => {
							value.selected = false
						})
					})
					oModel.setProperty("/materials", [])
					oModel.setProperty("/displayTokensMaterial", [])
				
						// var foundL1 = aSolnL1Data.find(item => item.soln_guid == prevSelSolArea[0].soln_prnt_guid)
						// models._loadChildren(this, foundL1, null, true,prevSelSolArea[0].soln_guid)
					let bFillSol = this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/AdditionalSolutions`) && this.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}/TempEmployee/AdditionalSolutions`).length ? true:false;
					if(bFillSol){
						oDialog.getContent()[0].getContent()[0].getItems()[0].getItems()[0].setState(true);
					}else{
						oDialog.getContent()[0].getContent()[0].getItems()[0].getItems()[0].setState(false);
					}
					this.onChangeDisplayFullSolHierarchy(bFillSol)
					}
					

					// if (prevSelAddSol.length > 0 || prevSelMaterial.length > 0) {
					// 	oModel.setProperty("/showDisplayMaterials", true)
					// } else {
					// 	oModel.setProperty("/showDisplayMaterials", false)
					// }
					// if(prevSelAddSol.length>0) 
					// 	models._loadChildren(this,oSelGuid,oEvent,false)
				} else {
					// oModel.setProperty("/selectedLevel1Guid", aSolnL1Data[0].SolGuid)
					oModel.setProperty("/showDisplayMaterials", false)
					let mMaterialMap = oModel.getProperty("/materialMap") ? oModel.getProperty("/materialMap"):[];
					mMaterialMap.forEach((arr, key) => {
						arr.forEach(value => {
							value.selected = false
						})
					})
					oModel.setProperty("/materials", [])
					oModel.setProperty("/displayTokensMaterial", [])
					oModel.setProperty("/displayTokensAdditionalSolution", [])
				oModel.refresh();
					// oModel.setProperty("/selectedLevel2Id",null)	


					// models._loadChildren(this, aSolnL1Data[0], null, true)
				



				}
			}.bind(this))
			
			
				
			
			// let aSelectedTokens=oModel.getProperty("displayTokens")
			
		},
		onChangeSLAMasterSelection:function(oEvent){
			let selectedObj = oEvent.getSource().getSelectedItem().getBindingContext("SolutionAreaMasterData").getObject()
			// let sSelectedKey=oEvent.getSource().getSelectedKey()
			const oSolAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData")
			oSolAreaDataModel.setProperty("/selectedLevel2Id", null)
			oSolAreaDataModel.setProperty("/materials", [])
			oSolAreaDataModel.setProperty("/displayTokensMaterial", [])
			oSolAreaDataModel.setProperty("/displayTokensAdditionalSolution", [])
			let mMaterialMap = oSolAreaDataModel.getProperty("/materialMap") ? oSolAreaDataModel.getProperty("/materialMap"):[];
			mMaterialMap.forEach((arr, key) => {
				arr.forEach(value => {
					value.selected = false
				})
			})
			models._loadChildren(this, selectedObj, oEvent, true)
			models.getMaterials(this,selectedObj,true);
			const solutionTree = this.byId("idSolutionTree")
			solutionTree.removeSelections();
			solutionTree.collapseAll();
		},
		onExpandHierarchy:function(oEvent){
			const oSelGuid = oEvent.getParameter("itemContext").getObject()
            let bAddSolAreaMaterialState=this.getOwnerComponent().getModel("SolutionAreaMasterData").getProperty("/showDisplayMaterials")
            // if(!bAddSolAreaMaterialState){
            //     let index=oEvent.getParameter("itemIndex")
            //     oEvent.getSource().collapse(index)
            //     sap.m.MessageToast.show("Please enable additional solution hierarchy/materials")
            // }else{
			if(oEvent.getParameter("expanded")  &&  !this.bDisableExpandAPICall)
				models._loadChildren(this,oSelGuid,oEvent,false)                
            //}
		},
		//when L3,L4 is selected in new solution hierarchy
		onSelectSolution:function(oEvent){
		// 	this.getOwnerComponent().getModel("SolutionAreaMasterData").getData().selectedLevel1Guid = ""
        //   this.getOwnerComponent().getModel("SolutionAreaMasterData").getData().selectedLevel2Id = ""
			let bIsSelected=oEvent.getSource().getSelected()
			let oSelectedRow=oEvent.getSource().getBindingContext('SolutionAreaMasterData').getObject()
			let solutionAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData");
			let mSolHierarchyMap = solutionAreaDataModel.getProperty('/solHierarchyMap');
			let solHierarchy = solutionAreaDataModel.getProperty('/solHierarchy');			
			let currentSelectedL2=solutionAreaDataModel.getProperty("/selectedLevel2Id")
			this.onL3L4Select(oEvent,oSelectedRow,bIsSelected,solutionAreaDataModel)
			models.getMaterials(this,oSelectedRow,bIsSelected)	
			 this.getOwnerComponent().getModel("SolutionAreaMasterData").refresh();		
			
          
		},
		  onSolAreaRadioSelect: function (oEvent) {
            const oSolAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData"),
                aAddSolns = oSolAreaDataModel.getProperty("/displayTokensAdditionalSolution") ? oSolAreaDataModel.getProperty("/displayTokensAdditionalSolution") : [],
                sSelectedLv1Id = oSolAreaDataModel.getProperty("/selectedLevel1Guid"),
                sSelectedLevel2Id = oSolAreaDataModel.getProperty("/selectedLevel2Id");
            if (aAddSolns.length) {
                let sContextSelectedId = oEvent.getSource().getBindingContext("SolutionAreaMasterData").getObject().soln_guid;
                this.prevRadioSelect = (sSelectedLevel2Id === sContextSelectedId) || (sSelectedLv1Id === sContextSelectedId) ? oEvent : this.prevRadioSelect;
                if (!((sSelectedLevel2Id === sContextSelectedId) || (sSelectedLv1Id === sContextSelectedId))) {
                    this.prevRadioSelect.getSource().setSelected(true);
                    oEvent.getSource().setSelected(false);
                    this.newRadioSelect = oEvent;
                }
                
             
                if (this.newRadioSelect) {
                  CommonJS._onOpenSolutionSelectConfimDialog(this);

                }
            } else {
                this.onSolAreaRadioSelectConfirm(oEvent)
            }


        },
		//when L1,L2 radio button is selected in new solution hierarchy
		onSolAreaRadioSelectConfirm: function (oEvent) {
		 //this.getOwnerComponent().getModel("SolutionAreaMasterData").getData().selectedLevel1Guid = ""
         this.getOwnerComponent().getModel("SolutionAreaMasterData").refresh();
            if (oEvent.getParameter("selected")) {
                let selectedRadioItem = oEvent.getSource().getBindingContext("SolutionAreaMasterData").getObject()
                const oSolAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData")
                let solHierarchy = oSolAreaDataModel.getProperty("/solHierarchy")
                this.clearSASelection(solHierarchy)
                if (selectedRadioItem.LevelId==1) {
                    // let selectedObj = oEvent.getSource().getSelectedItem().getBindingContext("SolutionAreaMasterData").getObject()
                    // let sSelectedKey=oEvent.getSource().getSelectedKey()
                    
                    oSolAreaDataModel.setProperty("/selectedLevel1Guid", selectedRadioItem.soln_guid)
                    oSolAreaDataModel.setProperty("/selectedLevel2Id", null)
                    oSolAreaDataModel.setProperty("/materials", [])
                    oSolAreaDataModel.setProperty("/displayTokensMaterial", [])
                    oSolAreaDataModel.setProperty("/displayTokensAdditionalSolution", [])
                    let mMaterialMap = oSolAreaDataModel.getProperty("/materialMap") ? oSolAreaDataModel.getProperty("/materialMap"):[];
                    mMaterialMap.forEach((arr, key) => {
                        arr.forEach(value => {
                            value.selected = false
                        })
                    })
                    const solutionTree = this.byId("idSolutionTree")
                    solutionTree.removeSelections();
                    // solutionTree.collapseAll();
                    // Models._loadChildren(this, selectedRadioItem, oEvent, true)
                    models.getMaterials(this, selectedRadioItem, true);
                } else {


                    oSolAreaDataModel.setProperty("/selectedLevel1Guid", selectedRadioItem.soln_prnt_guid)
                    // const oSolAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData");
                    let mMaterialMap = oSolAreaDataModel.getProperty("/materialMap") ? oSolAreaDataModel.getProperty("/materialMap"):[];
                    let materials = oSolAreaDataModel.getProperty("/materials")
                    let displayTokensMaterial = oSolAreaDataModel.getProperty("/displayTokensMaterial")
                    let prevSelectedL2 = oSolAreaDataModel.getProperty("/selectedLevel2Id")
                    // if(prevSelectedL2!=selectedRadioItem.soln_guid){
                    // oSolAreaDataModel.setProperty("/materials",[])
                    // oSolAreaDataModel.setProperty("/displayTokens",[])
                    // }
                    // let solHierarchy = oSolAreaDataModel.getProperty("/solHierarchy")

                    oSolAreaDataModel.setProperty("/selectedLevel2Id", selectedRadioItem.soln_guid)
                    oSolAreaDataModel.setProperty("/displayTokensMaterial", [])
                    oSolAreaDataModel.setProperty("/displayTokensAdditionalSolution", [])
                    oSolAreaDataModel.setProperty("/materials", [])
                    // if(mMaterialMap.get(prevSelectedL2))	
                    // 	mMaterialMap.get(prevSelectedL2).forEach(child=>{child.selected=false})
                    mMaterialMap.forEach((arr, key) => {
                        arr.forEach(value => {
                            // if(value.triggeredBy != selectedRadioItem.soln_prnt_guid)
                            value.selected = false
                        })
                    })
                    // materials = mMaterialMap.get(selectedRadioItem.soln_prnt_guid) ? mMaterialMap.get(selectedRadioItem.soln_prnt_guid) : []
                    // materials = []
                    // displayTokensMaterial = displayTokensMaterial.filter(each => each.triggeredBy == selectedRadioItem.soln_prnt_guid)
                    models.getMaterials(this, selectedRadioItem, true)

                    // solHierarchy.forEach(function (level2Master) {
                    //     if (level2Master.soln_guid != selectedRadioItem.soln_guid) {
                    //         level2Master.selected = false

                    //         if (level2Master.levels.length && level2Master.levels[0].soln_guid) {
                    //             level2Master.levels.forEach(child => {
                    //                 child.selected = false
                    //                 child.partialSelection = false
                    //                 if (child.levels.length && child.levels[0].soln_guid) {
                    //                     child.levels.forEach(grandChild => {
                    //                         grandChild.selected = false

                    //                     })
                    //                 }
                    //             })
                    //         }
                    //     }
                    // })
                }
                // oSolAreaDataModel.refresh(true)
            }
        },		
		//function to implement selection logic of L3,L4 and filtering of selected add sol tokens
		onL3L4Select:function(oEvent,oSelectedRow,bIsSelected,solutionAreaDataModel,bIsConfirm){
			// var oContext=oEvent.getSource().getBindingContext("SolutionAreaMasterData")
			// var sPath=oContext.getPath()
			// var sParentPath=sPath.substring(0,sPath.lastIndexOf("/levels"))
			let solHierarchyMap=solutionAreaDataModel.getProperty("/solHierarchyMap")
			// var oParent=oContext.getModel().getProperty(sParentPath)
			var solHierarchy=solutionAreaDataModel.getProperty("/solHierarchy")
			var mMaterialMap=solutionAreaDataModel.getProperty("/materialMap") ? solutionAreaDataModel.getProperty("/materialMap"):[];
			var materials=solutionAreaDataModel.getProperty("/materials")
			var displayTokensMaterial=[];
			var displayTokensAdditionalSolution=solutionAreaDataModel.getProperty("/displayTokensAdditionalSolution") ?solutionAreaDataModel.getProperty("/displayTokensAdditionalSolution") :[];
			var tokensToBeAdded=[]
			var tokensToBeRemoved=[]
			var materialTokensToBeRem=[]
			let bIsDifferntL2;
            if(oEvent && !bIsConfirm && displayTokensAdditionalSolution.length){
                const sSelectedLevel2Id = solutionAreaDataModel.getProperty("/selectedLevel2Id"),
                      oBindingContext = oEvent.getSource().getBindingContext("SolutionAreaMasterData").getObject();
                bIsDifferntL2 = sSelectedLevel2Id && !oBindingContext.full_sol_guid.includes(sSelectedLevel2Id);
                if(bIsDifferntL2){
                    oEvent.getSource().setSelected(false);
                    CommonJS._onOpenSolutionSelectConfimDialog(this,oEvent,oSelectedRow,bIsSelected,solutionAreaDataModel);

                }
            }
            if(!bIsDifferntL2){
			
			// var oParent=solHierarchyMap.get(oSelectedRow.soln_prnt_guid)
			let tempParent=solHierarchyMap.get(oSelectedRow.soln_prnt_guid)
            var aGuids=[]
            aGuids.push(oSelectedRow.soln_prnt_guid)
			while(tempParent && tempParent.LevelId!=1){
				tempParent=solHierarchyMap.get(tempParent.soln_prnt_guid)
                aGuids.push(tempParent.soln_guid)
			}
            aGuids.reverse()
           
			// var sL2Path=sParentPath
			// while(sL2Path.includes("/levels")){				
			// 	sL2Path=sL2Path.substring(0,sL2Path.lastIndexOf("/levels"))								
			// }
			// var oL2=oContext.getModel().getProperty(sL2Path)
            var oL1;
			var oL2;
            var oL3;
			let oL4;
			solHierarchy.forEach(sol=>{
				if(sol.soln_guid && sol.soln_guid==aGuids[0]){
					oL1=sol
					sol.levels.forEach(child=>{
						if(child.soln_guid && child.soln_guid==aGuids[1]){
                            oL2=child
							if(child.levels &&  child.levels.length){
                            child.levels.forEach(l3child=>{
                                if(l3child.soln_guid && l3child.soln_guid==aGuids[2]){
                                    oL3=l3child
                                }
                                if(l3child.levels && l3child.levels.length){
                                l3child.levels.forEach(l4child=>{
									if(l4child.soln_guid && l4child.soln_guid==aGuids[3]){
																		oL4=l4child
														}
								});
                            }


                            })
						}
                        }
                        
				})
				}
			})					
			// solHierarchy.forEach(sol=>{
			// 	if(sol.soln_guid==tempParent.soln_guid){
			// 		oL2=sol
			// 		sol.levels.forEach(child=>{
			// 			if(child.soln_guid==oParent.soln_guid)
			// 				oParent=child
			// 	})
			// 	}
			// })			
			// var currentL2guid=solutionAreaDataModel.getProperty("/selectedLevel2Id")
			// if(currentL2guid!=null && currentL2guid!=oL2.soln_guid){
			// 	displayTokens=[]
			// }
			var currentL1=solutionAreaDataModel.getProperty("/selectedLevel1Guid")
			var currentL2=solutionAreaDataModel.getProperty("/selectedLevel2Id")
            // oSolAreaDataModel.setProperty("/selectedLevel2Id", null)
			// oSolAreaDataModel.setProperty("/materials", [])
			// oSolAreaDataModel.setProperty("/displayTokensMaterial", [])
			// oSolAreaDataModel.setProperty("/displayTokensAdditionalSolution", [])
			//checking if the new L3,L4 selection is from a different L1 or not
            if(oL1 && currentL1!=null && currentL1!=oL1.soln_guid){
                materials=[]
                displayTokensMaterial =[]
                displayTokensAdditionalSolution = []
                mMaterialMap.forEach((arr,key)=>{
					arr.forEach(value=>{						
						value.selected = false
					})					
				})
                if(mMaterialMap.get(currentL1))
					materialTokensToBeRem.push(...mMaterialMap.get(currentL1))
                if(mMaterialMap.get(currentL2))
					materialTokensToBeRem.push(...mMaterialMap.get(currentL2))
                oL1.selected=true
                oL2.selected=true
				//change by rk
                // solutionAreaDataModel.setProperty("/selectedLevel1Guid",oL1.soln_guid)
                // solutionAreaDataModel.setProperty("/selectedLevel2Id",oL2.soln_guid)
                
            }
			//checking if the new L3,L4 selection is from a different L2 or not
			else if(currentL2!=null &&oL2&& currentL2!=oL2.soln_guid){
                materials=[]
				// displayTokens=[]
				displayTokensMaterial = displayTokensMaterial.filter(each => each.triggeredBy == oL2.soln_prnt_guid)
				displayTokensAdditionalSolution = displayTokensAdditionalSolution.filter(each => each.triggeredBy == oL2.soln_prnt_guid)
				mMaterialMap.forEach((arr,key)=>{
					arr.forEach(value=>{
						if(value.triggeredBy != oL2.soln_prnt_guid)
							value.selected = false
					})					
				})
				if(mMaterialMap.get(currentL2))
					materialTokensToBeRem.push(...mMaterialMap.get(currentL2))
                oL2.selected=true
				//change by rk
                //solutionAreaDataModel.setProperty("/selectedLevel2Id",oL2.soln_guid)
			}
			//change by rk
			if (oL1) {
				solutionAreaDataModel.setProperty("/selectedLevel1Guid", oL1.soln_guid)
			}
			if (oL2) {
				solutionAreaDataModel.setProperty("/selectedLevel2Id", oL2.soln_guid)
			}
            solHierarchy.forEach(function (level1Master) {
                // if (level1Master.soln_guid != oL1.soln_guid) {
                //     level1Master.selected = false
                    if (level1Master.levels.length && level1Master.levels[0].soln_guid) {
                        level1Master.levels.forEach(level2Master => {
                            if (level2Master.soln_guid != oL2.soln_guid) {
                            level2Master.selected = false
                            if (level2Master.levels.length && level2Master.levels[0].soln_guid) {
                                level2Master.levels.forEach(level3Master => {
                                    level3Master.selected = false
                                    level3Master.partialSelection = false
                                    if (level3Master.levels.length && level3Master.levels[0].soln_guid) {
                                        level3Master.levels.forEach(level4Master => {
                                            level4Master.selected = false
                                             if(level4Master.levels.length && level4Master.levels[0].soln_guid){
                                                level4Master.levels.forEach(level5Master => {
                                                    level5Master.selected = false;
                                                });
                                             }
                                        })
                                    }


                                })
                            }
                            }
                        })
                    }
                
            })
			if(oSelectedRow.LevelId==3){
				oSelectedRow.selected=bIsSelected
				bIsSelected?tokensToBeAdded.push(oSelectedRow):tokensToBeRemoved.push(oSelectedRow)
				oSelectedRow.partialSelection=false                
                oSelectedRow.explicitlySelected=bIsSelected
				// bIsSelected?tokensToBeAdded.push(oSelectedRow):tokensToBeRemoved.push(oSelectedRow)
				// if(oSelectedRow.levels.length && oSelectedRow.levels[0].soln_guid){
				// 	oSelectedRow.levels.forEach(child=>{
				// 		tokensToBeRemoved.push(child)
				// 		child.selected=bIsSelected
				// 		child.partialSelection=false
				// 	})
				// }
			}
			if(oSelectedRow.LevelId==4){
				oSelectedRow.selected=bIsSelected
				bIsSelected ? tokensToBeAdded.push(oSelectedRow) : tokensToBeRemoved.push(oSelectedRow)
				var aL3Level= oL3 ? oL3.levels:[];
				var isSelectedCount=aL3Level.filter(c=>c.selected).length;
				 if(oL3){
                    oL3.selected=true
                }
				if(isSelectedCount==0){
                    if(oL3 && !oL3.explicitlySelected){
				oL3.selected=false
					oL3.partialSelection=false
					}
    				
                    
				}else if(isSelectedCount==aL3Level.length){
					oL3.selected=true
					oL3.partialSelection=false
				}else{
					// if(!bIsSelected && oParent.selected==true){						
					// 	tokensToBeAdded.push(...oParent.levels)
                        
     //                }					
					// // tokensToBeRemoved.push(oParent)
					// oL3.selected=false
					  if(oL3){
					oL3.partialSelection=true
                    }
				}
			}
			    if (oSelectedRow.LevelId == 5) {
                oSelectedRow.selected = bIsSelected
                bIsSelected ? tokensToBeAdded.push(oSelectedRow) : tokensToBeRemoved.push(oSelectedRow)
                var aL4Level = oL4 ? oL4.levels:[];
                var isSelectedCount = aL4Level.filter(c => c.selected).length;
                if(oL4){
                    oL4.selected = true;
                }
                if(oL3){
                oL3.selected = true;
                }
                if (isSelectedCount == 0) {
                    if (oL4) {
                        if(!oL4.explicitlySelected){
                        oL4.selected = false
                        oL4.partialSelection = false
                        }
                    }

             } else if (oL4 && (isSelectedCount == aL4Level.length)) {
                    oL4.selected = true
                    oL4.partialSelection = false
                } else {
                    // if(!bIsSelected && oParent.selected==true){						
                    // 	tokensToBeAdded.push(...oParent.levels)

                    //                }					
                    // // tokensToBeRemoved.push(oParent)

                     if(oL4){
                        oL4.partialSelection = true
                    }
                }
                var aL3Level =oL3  ? oL3.levels:[];
                var isSelectedCount = aL3Level.filter(c => c.selected).length;
                if(oL3){
                oL3.selected = true
                }
                if (isSelectedCount == 0) {
                     if(oL3){
                    if (!oL3.explicitlySelected){
                        oL3.selected = false
                    oL3.partialSelection = false
                    }
                }
                 } else if (oL3 && (isSelectedCount == aL3Level.length)) {
                    oL3.selected = true
                    oL3.partialSelection = false
                } else {
                    // if(!bIsSelected && oParent.selected==true){						
                    // 	tokensToBeAdded.push(...oParent.levels)

                    //                }					
                    // // tokensToBeRemoved.push(oParent)
                    // oL3.selected=false
                    if(oL3){
                    oL3.partialSelection = true
                    }
                }
			}
			
			
			tokensToBeAdded.forEach(token => {
				token.isMaterial ? displayTokensMaterial.push(token) : displayTokensAdditionalSolution.push(token)
				// displayTokens.push(token)
				// if (mMaterialMap.get(token.id))
				// 	materials.push(...mMaterialMap.get(token.id))
			})
			
			
			tokensToBeRemoved.forEach(obj=>{
				if(mMaterialMap.get(obj.id)){
					mMaterialMap.get(obj.id).forEach(child=>{child.selected=false})
					materialTokensToBeRem.push(...mMaterialMap.get(obj.id))
				}
			})
			tokensToBeRemoved.push(...materialTokensToBeRem)
			const idsToBeRemoved = new Set(tokensToBeRemoved.map(item => item.id))
			displayTokensMaterial = displayTokensMaterial.filter(item => !idsToBeRemoved.has(item.id))
			displayTokensAdditionalSolution = displayTokensAdditionalSolution.filter(item => !idsToBeRemoved.has(item.id))
			// materials = materials.filter(item => !idsToBeRemoved.has(item.id))
			
			
			solutionAreaDataModel.setProperty("/displayTokensMaterial",displayTokensMaterial)
			solutionAreaDataModel.setProperty("/displayTokensAdditionalSolution",displayTokensAdditionalSolution)
			solutionAreaDataModel.setProperty("/materials",materials)
			solutionAreaDataModel.setProperty("/materialMap",mMaterialMap)
			solutionAreaDataModel.refresh(true)
		}


		},
		//invoked when new solution hierarchy dialog is closed
		closeSolutionHierarchy: function () {         
			const oSolAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData")
			let solHierarchy = oSolAreaDataModel.getProperty("/solHierarchy");
			let solHierarchyMap = oSolAreaDataModel.getProperty("/solHierarchyMap");
			let mMaterialMap = oSolAreaDataModel.getProperty("/materialMap") ? oSolAreaDataModel.getProperty("/materialMap"):[];
			solHierarchy.forEach(item => {
				solHierarchyMap.get(item.soln_guid).levels = []
			})
			mMaterialMap.forEach((arr, key) => {
				arr.forEach(value => {					
					value.selected = false
				})
			})
			

			oSolAreaDataModel.setProperty("/solHierarchyMap",solHierarchyMap)
			oSolAreaDataModel.setProperty("/selectedLevel2Id",null)
			oSolAreaDataModel.setProperty("/selectedLevel1Guid", null)
			oSolAreaDataModel.setProperty("/showDisplayMaterials",false)
			oSolAreaDataModel.setProperty("/materials",[])
			oSolAreaDataModel.setProperty("/displayTokensMaterial",[])
			oSolAreaDataModel.setProperty("/displayTokensAdditionalSolution",[])
			oSolAreaDataModel.refresh(true)
         	const solutionTree = this.byId("idSolutionTree");
          	solutionTree.removeSelections();
          	solutionTree.collapseAll();
          	// this.solutionHierarchyDialog.close()
			const that=this
			this.solutionHierarchyDialog.then(function (oDialog) {
             models.getSolutionAreaMasterData(that)

				oDialog.destroy();
				that.solutionHierarchyDialog = false;
				
				
			});
        },
		//called when "show full hierarchy" checkbox is selected in new solution hierarchy
		onChangeDisplayFullSolHierarchy: function (oEvent) {
			     this.getView().byId("idSolutionTree").collapseAll();
				    this.bDisableExpandAPICall = false;
						const solutionAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData");			
			 solutionAreaDataModel.setProperty("/isSolDialogBusy",true)
				   solutionAreaDataModel.refresh();
						let solHierarchy = solutionAreaDataModel.getProperty("/solHierarchy");
			let solHierarchyMap = solutionAreaDataModel.getProperty("/solHierarchyMap");
			let materialMap = solutionAreaDataModel.getProperty("/materialMap") ? solutionAreaDataModel.getProperty("/materialMap"):[];
			let displayTokensMaterial=solutionAreaDataModel.getProperty("/displayTokensMaterial");
			let  materials=solutionAreaDataModel.getProperty("/materials");
			// solutionAreaDataModel.setProperty("/displayTokensAdditionalSolution",[]);
			// solutionAreaDataModel.setProperty("/materials",[]);
			// solutionAreaDataModel.setProperty("/selectedLevel2Id",null)

			// this.clearSASelection(solHierarchy)
			if(typeof(oEvent)=='object')
				var bShowFullSolHierarchy=oEvent.getParameter("state");
			else{
				var bShowFullSolHierarchy=oEvent
			}
				  
			let that = this;
				   	setTimeout(function() {
			if(!bShowFullSolHierarchy){
			
				// materials=materials.filter(function(item){
				// 	if(solHierarchyMap.get(item.triggeredBy)){
				// 		return (solHierarchyMap.get(item.triggeredBy).LevelId==3 || solHierarchyMap.get(item.triggeredBy).LevelId==4)
						
				// 	}
				// })
			
				// displayTokensMaterial=displayTokensMaterial.filter(function(item){
				// 	if(solHierarchyMap.get(item.triggeredBy)){
				// 		return (solHierarchyMap.get(item.triggeredBy).LevelId==3 || solHierarchyMap.get(item.triggeredBy).LevelId==4)
						
				// 	}
				// })
				solutionAreaDataModel.setProperty("/displayTokensAdditionalSolution",[]);
                solutionAreaDataModel.setProperty("/displayTokensMaterial",[]);
				solutionAreaDataModel.setProperty("/materialsContainerVisible",false);
				that.byId("idSlnFormGrid").addStyleClass("customStyleSlnSmallGrid");
				// that.byId("idSlnFormGrid").removeStyleClass("customStyleSlnGrid");
				that.byId("idSlnTree").setDefaultSpan("XL12 L12 M12 S12");
				that.byId("idSlnToolbarGrid").setDefaultSpan("XL12 L12 M12 S12");
				that.byId("idSlnTree").getContent()[0].addStyleClass("styleSlnTreeScroll")
				that.SADialog.setContentWidth("52%")

				solHierarchyMap.forEach((item,key)=>{
				
				if(item.LevelId==3){
					item.selected=false
				
					item.partialSelection=false
				}else if(item.LevelId==4){
					item.selected=false
				}else if(item.LevelId==5){
                    item.selected=false
                }
			    })
                materialMap.forEach((item,key)=>{
                    item.forEach(mat=>{
                        mat.selected=false
                    })
                })
            }else{
				// that.SADialog.setContentWidth("900px");
				//  that.byId("idSlnTree").getContent()[0].removeStyleClass("styleSlnTreeScroll")
				//  that.byId("idSlnTree").setDefaultSpan("XL5 L6 M6 S12");
				//  that.byId("idSlnToolbarGrid").setDefaultSpan("XL6 L6 M6 S12");
				// solutionAreaDataModel.setProperty("/materialsContainerVisible",true);
				//  that.byId("idSlnFormGrid").removeStyleClass("customStyleSlnSmallGrid");
				//  that.byId("idSlnFormGrid").addStyleClass("customStyleSlnGrid");		 
			}
			solHierarchy.forEach(item => {	
                if(item.levels.length && item.levels[0].soln_guid){
                    item.levels.forEach(l2children=>{
                        l2children.levels = bShowFullSolHierarchy ? [{ "soln_name": "Loading..." }] 	:	[]					
                    })	
                }		
			})
			
			//that.byId("idSolutionTree").collapseAll()
			solutionAreaDataModel.refresh(true)
			  solutionAreaDataModel.setProperty("/isSolDialogBusy",false)
			     solutionAreaDataModel.refresh();
				 	},1200);

		},
		clearSASelection:function(solHierarchy){		
			solHierarchy.forEach(function(obj){
				obj.selected=false
				if(obj.LevelId==3)
					obj.partialSelection=false
				if(obj.levels.length && obj.levels[0].soln_guid){
					this.clearSASelection(obj.levels)
				}
			}.bind(this))
		},		
		onDeleteDisplayTokens:function(oEvent){
			let deletedToken = oEvent.getParameter("removedTokens")[0];
			let deletedObj = deletedToken.getBindingContext("SolutionAreaMasterData").getObject();
			const oSolutionAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData");
			let propName = deletedObj.isMaterial ? '/displayTokensMaterial' : '/displayTokensAdditionalSolution'
			let displayTokens=oSolutionAreaDataModel.getProperty(propName)
			let materials = oSolutionAreaDataModel.getProperty("/materials");
			displayTokens = displayTokens.filter(each => each.id !== deletedObj.id);
			oSolutionAreaDataModel.setProperty(propName, displayTokens);
			if (deletedObj.isMaterial) {
				let material = materials.find(each => each.id === deletedObj.id);
				if(material) 
					material.selected = false;
				oSolutionAreaDataModel.setProperty("/materials", materials)
				oSolutionAreaDataModel.refresh(true)
			}
			else {
				this.onL3L4Select(null,deletedObj,false,oSolutionAreaDataModel)
				models.getMaterials(this,deletedObj,false)
			}
		},
		onSelectMaterial:function(oEvent){
			 const oSolutionAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData");
          let displayTokensMaterial = oSolutionAreaDataModel.getProperty("/displayTokensMaterial");
          const isSelected = oEvent.getSource().getSelected();
          const selectedRow = oEvent.getSource().getBindingContext('SolutionAreaMasterData').getObject();
          if (isSelected)
            displayTokensMaterial.push(selectedRow);
          else
            displayTokensMaterial = displayTokensMaterial.filter(each => each.id !== selectedRow.id)
          oSolutionAreaDataModel.setProperty("/displayTokensMaterial", displayTokensMaterial)
		  oSolutionAreaDataModel.refresh(true)
		},
		onSearchSlnHierachy: function (evt) {
			CommonJS.onSearchSlnHierachy(evt, this)
		},
		/**
		 * @function onOpenGroupValueHelpDialog
		 * @description Event handler for group dialog create req
		 * @param {object} oEvent - event object of value help request	
		 */
		onOpenGroupValueHelpDialog: function (oEvent) {
			CommonJS.valueHelpRequestGroup(this, false,oEvent,true);
		},
		/**
		 * @function oncloseGroupDialog		 
		 * @description Event handler for create req group dialog cancel button press 
		 */
		oncloseGroupDialog: function () {
			const oModel = this.getView().getModel("masterDataModel");
			const oBindingIndex = oModel.getProperty("/iIndex");
			const oEmployeeModel = this.getView().getModel("employee");
			const aSelectedGroup = oEmployeeModel.getProperty(`/searchItems/${oBindingIndex}/TempEmployee/SelectedGroup`);
			oModel.setProperty("/TempEmployee/TempGroup",JSON.parse(JSON.stringify(aSelectedGroup)));
			// this.getView().getModel("employee").setProperty("/sSearchBoxText", "");			
			this.getOwnerComponent().getModel("grpHierarchyForFilter").setProperty("/selectedGrpID",aSelectedGroup?.[0]?.id)
			const that=this;
			this._pFilterGroup.then(function (oDialog) {
				// oDialog.close();
				oDialog.destroy();
                that._pFilterGroup=false;	
			});

		},
		/**
		 * @function onDeleteGroupToken
		 * @description Event handler for create req group dialog token delete
		 * @param {object} oEvent - event object of token update 			 
		 */
		onDeleteGroupToken:function(oEvent){
			const oSource = oEvent.getSource();
			const oBindingIndex = Number(oSource.getBindingContext("employee").getPath().split('/')[2]);
			this.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/iIndex`, oBindingIndex);
			const oModel = this.getView().getModel("employee");
			const oTempEmployee = oModel.getProperty(`/searchItems/${oBindingIndex}/TempEmployee`);
			const oParameters = oEvent.getParameters();
			if (oParameters.type === "removed") {
				oTempEmployee.SelectedGroup=[];
				this.getOwnerComponent().getModel("grpHierarchyForFilter").setProperty("/selectedGrpID","")
				oTempEmployee.TempGroup=[];
				this._setSearchFieldText(oBindingIndex);
				oModel.refresh(true);
			}
		},
		/**
		 * @function onSelectGroup
		 * @description when any group is selected in create req group dialog
		 * @param {object} oEvent - event object of select event of any group in create req			 
		 */
		onSelectGroup:function(oEvent){
			const oModel = this.getView().getModel("masterDataModel");
			const oSelectedGroup = oEvent.getSource().getBindingContext("grpHierarchyForFilter").getObject();
			// oSelectedGroup.selectedLead=true
			
			oModel.setProperty("/TempEmployee/TempGroup",[oSelectedGroup]);
			this.getOwnerComponent().getModel("grpHierarchyForFilter").setProperty("/selectedGrpID",oSelectedGroup.id)
			
			
			
			oModel.refresh(true);
			
		},
		/**
		 * @function onConfirmGroup		 
		 * @description called when ok button is pressed after group is selected in create req group dialog
		 */
		onConfirmGroup: function () {
			const oModel = this.getView().getModel("masterDataModel");
			const oBindingIndex = oModel.getProperty("/iIndex");
			const aSelectedGroup = oModel.getProperty("/TempEmployee/TempGroup");
			const oEmployeeModel = this.getView().getModel("employee");
			if(aSelectedGroup.length){

				oEmployeeModel.setProperty(`/searchItems/${oBindingIndex}/TempEmployee/SelectedGroup`, JSON.parse(JSON.stringify([
					{
						"GroupID":aSelectedGroup[0].id,
						"GroupDesc":aSelectedGroup[0].desc,
						"SelectedGroup":aSelectedGroup[0].desc,									
						"SelectedGroupHierarchy":aSelectedGroup[0].display,
						"LevelId":aSelectedGroup[0].LevelId,
						"display":aSelectedGroup[0].display,
						"id":aSelectedGroup[0].id
					}])));
				this.getOwnerComponent().getModel("grpHierarchyForFilter").setProperty("/selectedGrpID",aSelectedGroup[0].id)
			}	
			oEmployeeModel.refresh(true);
			const that=this;
			this._setSearchFieldText(oBindingIndex);
			this._pFilterGroup.then(function (oDialog) {
				// oDialog.close();	
				oDialog.destroy();
                that._pFilterGroup=false;			
			});
			
			
			
		},
		/**
		 * @function onSearchGroupFilter
		 * @description search in create req group dialog
		 * @param {object} oEvent - event object of search event of group search field 			 
		 */
		onSearchGroupFilter: function (oEvent) {
             const query = oEvent ? oEvent.getSource().getValue().trim():"";
            const TableId = this.byId("grpFilterHierarchyTableId");
            TableId.getBinding("items").filter(query ? new Filter({
                path: "desc",
                operator: "Contains",
                value1: query
            }) : null);
            TableId.expandToLevel(query ? 99 : 0);
		}	


	});
});