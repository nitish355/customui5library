sap.ui.define([
	"sap/m/library",
	"com/dealsupport/melodyrequest/controller/BaseController",
	"com/dealsupport/melodyrequest/model/models",
	"com/dealsupport/melodyrequest/model/users",
	"sap/m/MessageBox",
	"com/dealsupport/melodyrequest/model/formatter",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"com/dealsupport/melodyrequest/control/Common",
	"com/melody/lib/service/ActivityService",
	 "com/dealsupport/melodyrequest/control/ErrorHandle",
], function (mobileLibrary, BaseController, models, users, MessageBox, formatter, Fragment, JSONModel, CommonJS,ActivityService,ErrorHandle) {
	"use strict";
	var URLHelper = mobileLibrary.URLHelper;
	return BaseController.extend("com.dealsupport.melodyrequest.controller.Object", {
		formatter: formatter,
		common:CommonJS,
		onInit: function () {
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
			var oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
			var sDownTimeFlag = oAppConstantsModel.getProperty("/DownTime/0/Operational_Status");
			if (sDownTimeFlag) {
				this.getOwnerComponent().getRouter().navTo("NotFound");
			} else {
				this.getOwnerComponent().getRouter().getRoute("Object").attachPatternMatched(this._onObjectMatched, this);
			}
		},
		fnCurrentStateSuccessCallback: function (oResult, self) {
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData(oResult);
			self.getOwnerComponent().setModel(oModel, "currentStateModel");
			sap.ui.core.BusyIndicator.hide();
		},
		fnCurrentStateErrorCallback: function (oError, self) {
			MessageBox.error(oError.responseText, {
				contentWidth: "600px"
			});
			sap.ui.core.BusyIndicator.hide();
		},
		_onObjectMatched: function (oEvent) {			
			this.getView().setVisible(true);
			var that = this;
			var sInstanceID = oEvent.getParameter("arguments").ID;
			this.getOwnerComponent().getModel("appConstants").setProperty("/isReqView",true)
			sap.ui.core.BusyIndicator.show(0);
			//reset approval history flag
			this.aWfLogs = false;
			//hide action history
			this.handleSideContentHide();
			models.getInstanceDetails(that.fnSuccessCallback, that.fnErrorCallback, that, sInstanceID);
			appView._setSelectedMenuKey();

		},
		toWfHistoryHomePage: function () {
			sap.ui.core.BusyIndicator.show(0);
			this.getOwnerComponent().getRouter().navTo("Worklist");
		},
		fnSuccessCallback: function (oResponse, self,sInstanceID) {
			var oModel = new sap.ui.model.json.JSONModel();
			//GIT 277- If the user is unauthorized to view the req,fetch the req details from V_WfInstance_Inbox
			if(oResponse.value.length>0){
				oModel.setData(oResponse.value[0]);
				self.getView().setModel(oModel, "wfInstanceModel");
				var oDynamicSideView = self.getView().byId("idObjInfoDynamicSideContent");
				oDynamicSideView.setShowSideContent(false);
				self.onCurrProcContactlisticon();
				const sInstanceId = self.getView().getModel("wfInstanceModel").getData()["InstanceID"];
				models._getGetWfContextDetails(self, sInstanceId, self.fnSuccessGetContextDetails);
				sap.ui.core.BusyIndicator.hide();
			}else{
				models.getMyInboxInstanceDetails(self.fnSuccessCallbackInbox, self.fnErrorCallback, self, sInstanceID);
			}
		},
		/**Git 277 
         * call back function of V_WfInstance_Inbox service call and trigger unauthorized popup
         * @param {object} oResponse - service call response
         * @param {object} self -The context of the calling contollrer object, typically the controller.
         */
		fnSuccessCallbackInbox:function(oResponse, self,sInstanceID){
			self.getOwnerComponent().getModel("wfInstanceModel").setData(oResponse.value[0]);
            self.getOwnerComponent().getModel("wfInstanceModel").refresh();
            sap.ui.core.BusyIndicator.hide();
			appView.onOpenTaskProcessedMsgDialog();

		},
		 /**Git 132 (Form template changes + add new opp fields)
         * set deal info fields (Opportunity details)
         * @param {object} result - context response
         * @param {object} that -The context of the calling contollrer object, typically the controller.
         */
		fnSuccessGetContextDetails: function (result, that) {
			//Git 132 (Form template/standardization ) - Set header fields
			//change the template for object page ( Same as manager page)
			sap.ui.core.BusyIndicator.hide();
			result.EngagementType = result.EngagementType ? result.EngagementType : '0001'
			if(result.EngagementType==='0002')
				result.requestDetails.c2c_DealText = result.requestDetails.c2c_Deal ? "Yes" : "No"
			const oContextModel = new sap.ui.model.json.JSONModel(result);
			that.getView().setModel(oContextModel);
			//add OrgId,OrgType,RequestType for older tasks
			if (typeof (oContextModel.getData()["SalesOrgID"]) === "string") {
				oContextModel.getData()["OrgID"] = oContextModel.getData()["SalesOrgID"];
				oContextModel.getData()["OrgType"] = "SORG";
				oContextModel.getData()["RequestType"] = "Opportunity"
			}
			that.oAttachmentsModel = new JSONModel();
			that.oAttachmentsModel.downloadEnabled = false;
			that.getView().setModel(that.oAttachmentsModel, "attachmentsModel");

			oContextModel.setProperty("/namesOfPartiesVisible", false);
			const aInvolvedPartiesKeys = oContextModel.getProperty("/requestDetails/involvedPartiesKeys");
			if (aInvolvedPartiesKeys && aInvolvedPartiesKeys.length > 0) {
				if (aInvolvedPartiesKeys.includes("1") || aInvolvedPartiesKeys.includes("2") || aInvolvedPartiesKeys.includes("3")) { // if SAP Partner, SAP Consulting or Customer Advisory is selected
					oContextModel.setProperty("/namesOfPartiesVisible", true);
				}
			}
			//i18n model
			that.i18nModel = that.getOwnerComponent().getModel("i18n").getResourceBundle();

			if (!that.getView().getModel().getProperty("/NewOppDetails/Opp_SalesOrg_Name") && that.getView().getModel().getProperty("/RequestType") === 'Opportunity') {
				//update new opp details for request created before the git 132 changes
				const oUrlParams = {
					$expand: 'Notes,PartiesInvolved,DQReview,Attributes,CloseplanActivities,DocFlow,Attachments,Items,Pricing,RevenueSplitPlanH,RevenueSplitPlanI,SalesTeamWF,CustomerIncentive,S2SActivities,S2SActivities/PartiesInvolved,S2SActivities/Goals,RenewalExecution,OppHandover'
				};
				models._getMyOpportunityDetails(that, that.getView().getModel().getProperty("/opportunityId"), oUrlParams, CommonJS.parseGetOppDataResponse);
			} else {
				//update deal info
				CommonJS.parseGetOppDataResponse(oContextModel.getProperty("/CPICalls/getDataFromCRM/Response/d/"), that);
			}
			const oDefaultSection = that.getView().byId("idObjInfoPageLayout").getSections()[0];
			that.getView().byId("idObjInfoPageLayout").setSelectedSection(oDefaultSection);


			 //Git 132 (Form template/standardization ) - Set header fields
			    if (that.getView().getModel().getData().isResourceProfile) {
			CommonJS.setHeaderDetails(that);
				}
			/*initialize assignments */
			if((that.getView().getModel().getProperty("/AssignmentApprove") || that.getView().getModel().getProperty("/Assignment")) &&  that.getView().getModel("wfInstanceModel").getProperty("/currentStateID") !== "REQREJ"){
				that._initializeAssignments();
			}else{
				that.getView().byId("idObjInfoAssignmentsSection").setVisible(false);
			}
			 CommonJS.getResFieldDetails(that);
			
			//comment
			const oWfInstanceModel = that.getView().getModel("wfInstanceModel"),
				sLoggedInUserId = that.getOwnerComponent().getModel("userDetails").getProperty("/user_name"),
				bIsbCurrentProcessor = (typeof oWfInstanceModel.getProperty("/CurrentProcessorID") === "string" && oWfInstanceModel.getProperty("/CurrentProcessorID").includes(sLoggedInUserId)),
				sTechnicalState = that.getView().getModel("wfInstanceModel").getProperty("/TechnicalStateID"),
				bIsReqApproverId = (typeof oWfInstanceModel.getProperty("/ReqApproverID") === "string" && oWfInstanceModel.getProperty("/ReqApproverID").includes(sLoggedInUserId)),
				bIsReqIOApproverID = (typeof oWfInstanceModel.getProperty("/ReqIOApproverID")  === "string" && oWfInstanceModel.getProperty("/ReqIOApproverID").includes(sLoggedInUserId)),
				bIsReqResourcesID = (typeof oWfInstanceModel.getProperty("/ReqResourcesID")  === "string" && oWfInstanceModel.getProperty("/ReqResourcesID").includes(sLoggedInUserId)),
				bIsEmpRequester_ID = (typeof oWfInstanceModel.getProperty("/EmpRequester_ID")  === "string" && oWfInstanceModel.getProperty("/EmpRequester_ID").includes(sLoggedInUserId));
			that.getView().getModel("wfInstanceModel").setProperty("/bIsUserCommentInput", true)
			if ((sTechnicalState === "INPR" && !bIsbCurrentProcessor) ||
				(sTechnicalState === "COMP" && !bIsEmpRequester_ID && !bIsbCurrentProcessor && !bIsReqApproverId && !bIsReqIOApproverID && !bIsReqResourcesID)) {
				//if the task is in progress and logged in user is not a part of this task or if the task is closed and logged in user is not a workflow participant then hide comment input
				that.getView().getModel("wfInstanceModel").setProperty("/bIsUserCommentInput", false)
			}
			that.getView().getModel("wfInstanceModel").refresh()

			//setAttachment url visibility
			if (that.getView().getModel().getProperty("/requestDetails/attachmentUrls")) {
				const bAttachmentUrl = that.getView().getModel().getProperty("/requestDetails/attachmentUrls").length ? true : false;
				that.getView().getModel().setProperty("/isAttachmentUrl", bAttachmentUrl);
				if (bAttachmentUrl) {
					const aFinalAttachmentUrl = that.getView().getModel().getProperty("/requestDetails/attachmentUrls");
					let bAttachmentFinalUrl = true;
					aFinalAttachmentUrl.forEach(function (item, iIndex) {
						if (!item.url && !item.urlName) {
							bAttachmentFinalUrl = false;
						}
					});
					that.getView().getModel().setProperty("/isAttachmentUrl", bAttachmentFinalUrl);
				}

			}

			/*initialize assignments */
			that._fetchFormConfigData(that);

			that.getView().getModel().getData().isResourceProfile = (that.getView().getModel().getData().isResourceProfile) ? true : false;
			/* Set footer model for resource profile screen*/
			//set pfc data in initial load
			if(that.getView().getModel().getProperty("/approvalHistory"))
				that.getView().getModel().getProperty("/approvalHistory").reverse();
			that.getView().getModel().setProperty("/isDisplayOnly",true);			
			that.getView().getModel().refresh();
			// that.getView().byId("idPanelEditProfile").setVisible(false)
			const formActionsConfigModel = new JSONModel([]);
			that.getView().setModel(formActionsConfigModel, "formActionsConfigModel");
			var currentStateID=that.getOwnerComponent().getModel("wfInstanceModel").getData().currentStateID
			 if(!(currentStateID === 'REQSUB' || currentStateID === 'REQTER' || currentStateID === 'REQCRT')){
                that.handleSCBtnPress()
            }else{
                that.handleSideContentHide()
            }
			  //user comments
			  const sInstanceID = that.getView().getModel("wfInstanceModel").getData()["InstanceID"];
			  that.getView().getModel
			  models._getUserComments(that,sInstanceID,"GET")
  			
  			  //call task service to filter sub-tasks
       		models.getSubTaskInstanceDetails(that);
			setTimeout(function () {
				that.getView().setBusy(false);
			}, 1000, this);
			sap.ui.core.BusyIndicator.hide();
			that.getView().setBusy(false);

		},
		  /**Git 132 (Form template changes + add new opp fields)
         *get Org id number
         * @param {string} sOrgID - Sales org Id
         * @param {string} sOrgType - Org Type (PC or legacy);
         */
		_getOrgIDnumber: function (sOrgID, sOrgType) {
			if (sOrgType === "SORG") {
				return Number(sOrgID.replace('SORG-', '')).toString();
			} else {
				return sOrgID;
			}
		},
		/**Git 132 (Form template changes + add new opp fields)
			*get base url for service calls
			*/
		_getRuntimeBaseURL: function () {
			const appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
			const appPath = appId.replaceAll(".", "/");
			const appModulePath = sap.ui.require.toUrl(appPath);
			return appModulePath;
		},
		/**Git 132 (Form template changes + add new opp fields)
			*call form config service - Form tab
			*  * @param {object} self -The context of the calling contollrer object, typically the controller.
			*/
		_fetchFormConfigData: function (self) {
			const sOrgID = 'ParentOrgID' in self.getView().getModel().getData() ? self.getView().getModel().getProperty("/ParentOrgID") : self.getView().getModel().getProperty(
				"/OrgID");
			const sOrgType = self.getView().getModel().getProperty("/OrgType");
			const sEngagementType = self.getView().getModel().getProperty("/EngagementType");
			const sFormatOrgID = self._getOrgIDnumber(sOrgID, sOrgType);
			const sUrl = self._getRuntimeBaseURL() +
				`/cap/req-area-api-/Form_Tab?$expand=Fields&&$filter=orgID eq '${sFormatOrgID}' and orgType eq '${sOrgType}' and eng_Type_ID eq '${sEngagementType}'`;

			$.ajax({
				contentType: "application/json",
				url: sUrl,
				async: false,
				type: "GET",
				success: function (oData) {
					let aDataNew = [];

					for (let i = 0; i < oData.value.length; i++) {
						if (!aDataNew[oData.value[i].ID]) {
							aDataNew[oData.value[i].ID] = [];
						}
						aDataNew[oData.value[i].ID] = oData.value[i];
						let aDataNewFields = [];
						for (let j = 0; j < oData.value[i].Fields.length; j++) {

							if (!aDataNew[oData.value[i].Fields[j].ID]) {
								aDataNewFields[oData.value[i].Fields[j].ID] = [];
							}
							aDataNewFields[oData.value[i].Fields[j].ID] = oData.value[i].Fields[j];
						}
						aDataNew[oData.value[i].ID].Fields = aDataNewFields;
					}
					const oFormConfigModel = new JSONModel(aDataNew);
					self.getView().setModel(oFormConfigModel, "formConfigModel");
				},
				error: function (oError) {

				}
			});
		},
		fnErrorCallback: function (oError, self) {
			MessageBox.error(oError.responseText, {
				contentWidth: "600px"
			});
			sap.ui.core.BusyIndicator.hide();
		},
		onExit: function () {
			var oEventBus = sap.ui.getCore().getEventBus();
		},
		onOpenMyInbox: function () {
			var sInstanceID = this.getView().getModel("wfInstanceModel").getData()["InstanceID"];
			models._getWfExecutionLogs(this, sInstanceID, this.fnSuccessGetExecutionLogs);
		},
		//Get Subflow execution logs
		fnSuccessGetSubFlowExecutionLogs:function(result,self){
			if (result[result.length - 1].recipientUsers) {
				const sLoggedInUserId = self.getOwnerComponent().getModel("userDetails").getProperty("/user_name").toUpperCase();
				const aRecipentUser = result[result.length - 1].recipientUsers.filter((user) => user.toUpperCase() === sLoggedInUserId);
				if (aRecipentUser.length) {
					const sUserTaskId = result[result.length - 1].taskId
					const oAppConstantsModel = self.getOwnerComponent().getModel("appConstants");
					const sInboxUrl = oAppConstantsModel.getProperty("/MyInboxURL/0/Value");
					const sFinalUrl =`${sInboxUrl}?sap-ui-app-id-hint=cross.fnd.fiori.inbox&substitution=true&userSearch=false&/detail/NA/${sUserTaskId}/TaskCollection(SAP__Origin='NA',InstanceID='${sUserTaskId}')`
					window.open(sFinalUrl, "_blank");
					return true;
				}
			}
			
		},
		fnSuccessGetExecutionLogs: function (result, self) {
		//Get Wf execution logs to track task history
			if (result[result.length - 1].subflow) {
				for (let i = 0; i < result.length; i++) {
					if (result[i].subflow) {
						if (result[i].subflow.workflowInstanceId) {
							models._getWfExecutionLogs(self, result[i].subflow.workflowInstanceId, self.fnSuccessGetSubFlowExecutionLogs);
						}
					}
				}
			} else {
				const sUserTaskId = result[result.length - 1].taskId;
				const oAppConstantsModel = self.getOwnerComponent().getModel("appConstants");
				const sInboxUrl = oAppConstantsModel.getProperty("/MyInboxURL/0/Value");
				const sFinalUrl =
					`${sInboxUrl}?sap-ui-app-id-hint=cross.fnd.fiori.inbox&substitution=true&userSearch=false&/detail/NA
				/${sUserTaskId}/TaskCollection(SAP__Origin='NA',InstanceID='${sUserTaskId}')`
				window.open(sFinalUrl, "_blank");
			}

		},
		//trigger mail to requester
		onEmailToRequester: function (evt) {
			URLHelper.triggerEmail(evt.getSource().getText(), false, false, false, true);
		},
		onCurrProcContactlisticon: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var sName = i18nModel.getText("currProcessor");
			var sCurrentProcessorEmail = this.getView().getModel("wfInstanceModel").getData().CurrentProcessorEmail;
			var sCurrentProcessor =  this.getView().getModel("wfInstanceModel").getData().CurrentProcessor;
			var oValType = "Email"
			var isListView = true;
			var self = this;
			if (!sCurrentProcessorEmail) {
				sap.ui.core.BusyIndicator.hide();
				if (sCurrentProcessor) {
					var aCurrentProcessor = sCurrentProcessor.split(",");
					var array = []
					var sArrLen = aCurrentProcessor.length
					for (var i = 0; i < aCurrentProcessor.length; i++) {
						var value = {
							"firstName": aCurrentProcessor[i]
						};
						users.empData(value, oEvent, self, array, sArrLen, sName,isListView);
					}
				}
			} else {
				users.callEmpApi(sCurrentProcessorEmail, oEvent, this, sName, oValType,isListView);
			}
		},
		currentAvatarDisplay: function (userId) {
			return this.getOwnerComponent().getModel("appConstants").getProperty("/userImg/0/Value") + userId;
		},
		
		QuickViewCard: function (oModel, oevt, self, sName) {
			var oButton = oevt.getSource();
			self.getView().setModel(oModel, "EmpDetails");
			var EmployeeDetails = this.getView().getModel("EmpDetails");
			users._contactslistFragment(EmployeeDetails, oevt, self, sName).openBy(oButton);
			sap.ui.core.BusyIndicator.hide();
		},
		QuickListView: function (oModel, oevt, self, sName) {
				self.getView().setModel(oModel, "EmpListDetails");
				var EmployeeDetails = this.getView().getModel("EmpListDetails");
				sap.ui.core.BusyIndicator.hide();
		},
		onPressEmpEmail: function (oEvent) {
			var sUrl = oEvent.getSource().getProperty("text");
			URLHelper.triggerEmail(sUrl, "Info Request - MRR", false, false, false, true);
		},
		handleStatusPressed: function (oEvent) {
			var sInstanceID = this.getView().getModel("wfInstanceModel").getData()["InstanceID"];
			models._getWfExecutionLogs(this, sInstanceID, this.fnSuccessGetExecutionLogs);
		},
		handleOppStatusPressed: function () {
			var aOppUrl = this.getView().getModel("wfInstanceModel").getData()["ExtSystemsUrl"];
			window.open(aOppUrl, "_blank");
		},
		handleAccountStatusPressed: function () {
			var sAccount = this.getView().getModel("wfInstanceModel").getData()["Account_ID"];
			var oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
			var sAccountBaseUrl = oAppConstantsModel.getProperty("/HarmonyURL/0/Value");
			var sFinalUrl = `${sAccountBaseUrl}Account/${sAccount}`
			window.open(sFinalUrl, "_blank");
		},
		   //Git 132 (Form template/standardization ) - action history button press
		handleSCBtnPress: function () {
			const oDynamicSideView = this.getView().byId("idObjInfoDynamicSideContent");
			const oOPSideContentBtn = this.getView().byId("openSideContentBtnObjInfo");
			//GIT 277- common function to fetch the action history
			CommonJS._setActionHistoryModel(this, oDynamicSideView, oOPSideContentBtn);
		},
		fnSuccessGetExecutionLogsData: function (result, self) {
			var sUserTaskId;
			result.forEach(function(logs){
				if(logs.taskId){
					sUserTaskId = logs.taskId
				}
			});
			if(sUserTaskId){
				models._getWfTaskContextDetails(self, sUserTaskId, self.fnSuccessGetWfLogkDetails);
			}
				
		},
		fnSuccessGetWfLogkDetails:function(result,that){
			var aApprovalHistory = result.approvalHistory;
			result.aApproverData  = [];
			if(result.approverDetails){
				result.aApproverData = result.approverDetails
			}
			if(result.substituteApproverDetails){
				result.aApproverData = result.aApproverData.concat(result.substituteApproverDetails);
			}
			if(result.AssignmentApprove){
				var aAssignments = result.AssignmentApprove;
				aAssignments.forEach(function(assignments){
					if(assignments.NominatedResources){
						assignments.NominatedResources.forEach(function(resource){
							result.aApproverData = result.aApproverData.concat(resource);
						})
					}
				});
			}
			try {
				for (var i = 0; i < aApprovalHistory.length; i++) {
					aApprovalHistory[i].userId = result.aApproverData.filter((user) => user.fullName.toLowerCase() === aApprovalHistory[i].UserName.toLowerCase())[0].userId;
				}
			} catch (err) {

			}
			if (result.Skip_Resource_Approver) {
				let aAssignments = [];
				aApprovalHistory.forEach(function (history, index, object) {
					if(!history.StepID && history.StepName === "Presales Resource Approval"){
						history.StepID = "RESAPP";
					}
					if (history.StepID === "RESAPP") {
						aAssignments.push(history.UserId);
						object.splice(index, 1);
					}
				});
				if (aApprovalHistory) {
					if (!aApprovalHistory[aApprovalHistory.length - 1].StepID && aApprovalHistory[aApprovalHistory.length - 1].StepName === "Presales Manager Approval") {
						aApprovalHistory[aApprovalHistory.length - 1].StepID = "MANAPP";
					}
					if (aApprovalHistory[aApprovalHistory.length - 1].StepID === "MANAPP") {
						aApprovalHistory[aApprovalHistory.length - 1].Skip_Resource_Approver = result.Skip_Resource_Approver;
						aApprovalHistory[aApprovalHistory.length - 1].resourceCount = aAssignments.length;
						aApprovalHistory[aApprovalHistory.length - 1].resourcesId = aAssignments.join(";");
					}
				}
			}
		
			var oWfLogs = aApprovalHistory.reverse();
			// oWfLogs.forEach(function(logs,i) {
			// 	logs.step = i
			// });
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData(oWfLogs);
			that.getView().setModel(oModel, "wfLogs");
			var oDynamicSideView = that.getView().byId("DynamicSideContentObjectPage");
			var sCurrentBreakpoint = oDynamicSideView.getCurrentBreakpoint();
			var oOPSideContentBtn = that.getView().byId("openSideContentBtnObjectPage");
			if (sCurrentBreakpoint === "S") {
				oDynamicSideView.toggle();
			} else {
				oDynamicSideView.setShowSideContent(true);
			}

			oOPSideContentBtn.setVisible(false);
		},
		onOpenResourceDetails:function(oEvent){
            sap.ui.core.BusyIndicator.show(0);
            var sName = "Resource List";
            var sResourceUserId = oEvent.getSource().getBindingContext("wfLogs").getObject().resourcesId;
            let uniqueIds = [...new Set(sResourceUserId.split(';'))].join(';');
            var oValType = "ID";
            users.callEmpApi(uniqueIds, oEvent, this, sName, oValType);
        },
		_getActivityData: function (aActivities) {
			const aActivityData = aActivities.map(item => item.activity_GUID || item.ActivityGuid);
			const sFilterCondition = `(${aActivityData.map(actGuid => `(ActivityGuid eq guid'${actGuid}')`).join(' or ')})`,
			sUrlParams = {
				$filter: `${sFilterCondition}`,
				$expand:`to_ATaxonomy,to_AFiles,to_AIndustry,to_AInitiative,to_ALand,to_AMaterial,to_ATeam,to_AAddOpp`
			}
			              let aActivityFormLayout = [];
			//oData get call for substitute
			const oIntLSModel = models.systemActivityDataModel(this),
				that = this;
				this.getView().getModel("assignmentsModel").setProperty("/cardBusy",true);
				this.getView().getModel("assignmentsModel").refresh();
			models._callGETOdata(oIntLSModel, `/Yc_Mac_T_Act_Main`, sUrlParams).
				then(function (data) {
					this.getView().getModel("assignmentsModel").setProperty("/cardBusy",false);
				this.getView().getModel("assignmentsModel").refresh();
					if (data.results.length) {
						that.getView().getModel().setProperty("/aAllActivities", data.results);
						that.getView().getModel().refresh();
					}
					const aAllRegisteredActvts = data.results;
					let aAssignmentData =  that.getView().getModel("assignmentsModel").getData().assignments,
						    aActivities =  that.getView().getModel("activityTempModel").getData().value.length ? that.getView().getModel("activityTempModel").getData().value:
							aAssignmentData.flatMap(obj => obj.activityLists.map(function (innerObj) {
								const aFilteredActivity = aAllRegisteredActvts.filter(item => innerObj.ActivityGuid === item.ActivityGuid).length ? aAllRegisteredActvts.filter(item => innerObj.ActivityGuid === item.ActivityGuid) : [];
								if(aFilteredActivity.length){
									aFilteredActivity[0].to_ALand =aFilteredActivity[0].to_ALand.results;
									aFilteredActivity[0].to_AInitiative =aFilteredActivity[0].to_AInitiative.results;
									aFilteredActivity[0].to_AFiles =aFilteredActivity[0].to_AFiles.results;
									aFilteredActivity[0].to_ATaxonomy =aFilteredActivity[0].to_ATaxonomy.results;
									aFilteredActivity[0].to_AMaterial =aFilteredActivity[0].to_AMaterial.results;
									aFilteredActivity[0].to_ATeam = aFilteredActivity[0].to_ATeam.results;
									aFilteredActivity[0].to_AAddOpp = aFilteredActivity[0].to_AAddOpp.results;
								}
								
								return {
									activit_Payload:aFilteredActivity[0],
									activity_GUID: innerObj.ActivityGuid,
									AssignmentID: innerObj.assignmentID,
									instanceID: that.getView().getModel("wfInstanceModel").getData()["InstanceID"]
								};

							})).flat();
				
					if (aActivities.length) {
						aActivities.forEach(function (item) {
							const aUpdatedActivityLists = aAllRegisteredActvts.filter(subItem => item.ActivityGuid === subItem.ActivityGuid);
							if (aUpdatedActivityLists.length) {
								aUpdatedActivityLists[0].to_ALand =aUpdatedActivityLists[0].to_ALand.results;
								aUpdatedActivityLists[0].to_AInitiative =aUpdatedActivityLists[0].to_AInitiative.results;
								aUpdatedActivityLists[0].to_AFiles =aUpdatedActivityLists[0].to_AFiles.results;
								aUpdatedActivityLists[0].to_ATaxonomy =aUpdatedActivityLists[0].to_ATaxonomy.results;
								aUpdatedActivityLists[0].to_AMaterial =aUpdatedActivityLists[0].to_AMaterial.results;
								aUpdatedActivityLists[0].to_ATeam = aUpdatedActivityLists[0].to_ATeam.results;
								aUpdatedActivityLists[0].to_AAddOpp = aUpdatedActivityLists[0].to_AAddOpp.results;
								item.activit_Payload = aUpdatedActivityLists[0];
							}
						})
					}
					for (let i = 0; i < aAssignmentData.length; i++) {
						if (aAssignmentData[i].enableActivityRegister) {
							let aContextActivity = aActivities.filter(item => item.AssignmentID.toString() === aAssignmentData[i].AssignmentID.toString()),
								aUpdatedActivities = [];
							 let aActivityList =  aAssignmentData[i].activityLists &&  aAssignmentData[i].activityLists.length ? aAssignmentData[i].activityLists:[];
							aContextActivity.forEach(function (item,iIndex) {
								let sActivityDesc = item.activit_Payload ? item.activit_Payload.ActivityTypeDescription :item.ActivityTypeDescription;
								const oUpdatedActivity = {
									"activityPaylod": item.activit_Payload ? item.activit_Payload:item,
                                    "assignmentID": item.AssignmentID,
                                    "activity_GUID": item.ActivityGuid,
                                    "instanceID": item.Instance_Guid,
								    "ActivityTypeInfo":aActivityList.length && aActivityList.filter(act=>act.ActivityDesc === sActivityDesc) ?  aActivityList.filter(act=>act.ActivityDesc === sActivityDesc)[0].ActivityTypeInfo :"",
                                    "resourceList": aAssignmentData[i].resourceList,
								}
								oUpdatedActivity.to_ALandVisible = oUpdatedActivity.activityPaylod.to_ALand && oUpdatedActivity.activityPaylod.to_ALand.length ? true : false;
								oUpdatedActivity.to_AInitiativeVisible = oUpdatedActivity.activityPaylod.to_AInitiative && oUpdatedActivity.activityPaylod.to_AInitiative.length ? true : false;
								oUpdatedActivity.to_AFilesVisible = oUpdatedActivity.activityPaylod.to_AFiles && oUpdatedActivity.activityPaylod.to_AFiles.length ? true : false,
								oUpdatedActivity.to_ATaxonomyVisible = oUpdatedActivity.activityPaylod.to_ATaxonomy && oUpdatedActivity.activityPaylod.to_ATaxonomy.length ? true : false,
								oUpdatedActivity.to_AMaterialVisible = oUpdatedActivity.activityPaylod.to_AMaterial && oUpdatedActivity.activityPaylod.to_AMaterial.length ? true : false;
								oUpdatedActivity.to_AAddOppVisible = oUpdatedActivity.activityPaylod.to_AAddOpp && oUpdatedActivity.activityPaylod.to_AAddOpp.length ? true : false;
								oUpdatedActivity.bIsExpanded = (iIndex === 0) ? true:false;
								aUpdatedActivities.push(oUpdatedActivity);

								if(oUpdatedActivity.activityPaylod.Status){
									oUpdatedActivity.activityPaylod.Status_Desc = formatter.fnSetActivityStatusText(oUpdatedActivity.activityPaylod.Status)
								}

								   if(oUpdatedActivity.activityPaylod.ChildFrmLayoutId){
                                    aActivityFormLayout.push(oUpdatedActivity.activityPaylod.ChildFrmLayoutId);
                                }

                                const aSolns = JSON.parse(JSON.stringify(oUpdatedActivity.activityPaylod.to_ATaxonomy));
                                aSolns.forEach(function(item){
                                    switch ( item.L5Desc || item.L4Desc || item.L3Desc || item.L2Desc ) {
                                        case item.L5Desc:
                                            item.SolutionDesc = item.L5Desc
                                            break;
                                        case item.L4Desc:
                                            item.SolutionDesc = item.L4Desc
                                            break;
                                        case item.L3Desc:
                                            item.SolutionDesc = item.L3Desc
                                            break;
                                        case item.L2Desc:
                                            item.SolutionDesc = item.L2Desc
                                            break;
                                        default:
                                        item.SolutionDesc = ""
                                    }
                                })
                                const aMateriaData =    JSON.parse(JSON.stringify(oUpdatedActivity.activityPaylod.to_AMaterial));
                                aMateriaData.forEach(item => {
                                    item.SolutionDesc = item.MatDesc;
                                });
                                oUpdatedActivity.solnMaterialData = aSolns.concat(aMateriaData);

								//processor list
								const aActTeamMember = oUpdatedActivity.activityPaylod.to_ATeam,
									aProcessorList = aActTeamMember.length ? aActTeamMember.map(({
										NAME: fullName,
										EMAIL: email,
										...rest
									}) => ({
										fullName, email,
										...rest
									})):[];

								aProcessorList.length ? aProcessorList[0].bIsTitle = true : false;
								//sort processor list
								CommonJS._empSort(aProcessorList, "fullName");
								let aProcessorShortList = [],
									aProcessorMoreList = [],
									sMoreProcessorText;
								if (aProcessorList.length > 2) {
									const iProcessorMoreCount = (aProcessorList.length - 2).toString(),
										si18nMoreText = that.getOwnerComponent().getModel("i18n").getResourceBundle().getText("more");
									sMoreProcessorText = `(${iProcessorMoreCount} ${si18nMoreText})`;
									aProcessorShortList = aProcessorList.slice(0, 2); // visible approver list ( max 2 processors)
									aProcessorMoreList = aProcessorList.slice(2);// array point to link to show more processors	
								} else {
									aProcessorShortList = aProcessorList;
								}
								//set object for request header model
								oUpdatedActivity.actTeamList = {
									processorShortList: aProcessorShortList,
									processorMoreList: aProcessorMoreList,
									moreProcessorText: sMoreProcessorText,
									processorDisplayList: sMoreProcessorText ? aProcessorShortList.concat([{
										ID: "idMoreText",
										fullName: sMoreProcessorText
									}]) : aProcessorShortList
								}
								oUpdatedActivity.actTeamList.currentScope = that;
							});
							sap.ui.core.BusyIndicator.hide();
							aAssignmentData[i].activities = aUpdatedActivities;
							that.getView().getModel("assignmentsModel").refresh();
							if (aActivityFormLayout.length) {
								// Build filter array
								let aFilters = aActivityFormLayout.map(function (sValue) {
									return new sap.ui.model.Filter("FormLayoutID", sap.ui.model.FilterOperator.EQ, sValue);
								});
								this.fnGetLayoutData(aFilters, this, true);
							}
						}
					}
						
				}.bind(that))
				.catch(function (oError) {
					ErrorHandle.setErrorMessage(oError, that);
				});
		},
		  /**
         * Git #230 Activity integration start
         * get the rapid reg layout fields config
         * @param {object}  aFilter - Passing activity type id as filter.
         * @param {object}  that - controller scope.
         * @function fnGetLayoutData
         */
        fnGetLayoutData: function (aFilter,that) {
            function getFormLayout() {
                return new Promise((resolve) => {
                    //Call activity library service to get activity form layout
                    const response =  ActivityService.fnGetLayoutData(aFilter);
                    resolve(response);
                }).then(function (response) {
                    if(response && response.length){
                            let oAssignmentModelData =  this.getView().getModel("assignmentsModel").getData().assignments;
                            oAssignmentModelData.forEach(function(item){
                                if(item.activities && item.activities.length){
                                    item.activities.forEach(function(obj){
                                        if("activityPaylod" in obj){
                                            const aFilteredLayout = response.filter(layout=>layout.FormLayoutID === obj.activityPaylod.ChildFrmLayoutId);
                                            if(aFilteredLayout.length){
                                                obj.SelectedLayout = JSON.parse(aFilteredLayout[0].FormLayoutString);
                                            }
                                            
                                        }
                                    });
                                }
                            })
                             this.getView().getModel("assignmentsModel").refresh();
                    }
                   
                }.bind(that));
            }
            return getFormLayout();

        },
		//Git 132 (Form template/standardization ) - get resource assigned details
		 _initializeAssignments: function () {
            //initialize assignments model
            let oAssignments = {
                "assignments": []
            };
            this.getView().byId("idObjInfoAssignmentsSection").setVisible(true);
            const oModel = new JSONModel(oAssignments);
            this.getView().setModel(oModel, "assignmentsModel");
            let oAssignmentData = this.getView().getModel().getProperty("/AssignmentApprove")?.length ? this.getView().getModel().getProperty("/AssignmentApprove") : this.getView().getModel().getProperty("/Assignment");
            if (oAssignmentData) {
                oAssignments.assignments = CommonJS._setResourceAssignment(oAssignmentData,this);
                  models._callActivityTempDataService(this,false,"GET",true);
                 
                let aAssignmentData = this.getView().getModel("assignmentsModel").getData().assignments,
                    bIsNoActivityRegister = aAssignmentData.every(val => !val.enableActivityRegister),
                    aActivities = [];
                if (!bIsNoActivityRegister) {
                    aActivities = this.getView().getModel("activityTempModel").getData().value.length ? this.getView().getModel("activityTempModel").getData().value : aAssignmentData.map(obj => obj.activityLists).flat();
                    this._getActivityData(aActivities)
 
                }
 
 
                // aAssignmentData.map(function (obj) {
                //  return {
                //      obj.activityLists
 
                //  };
                // });
 
 
 
               
            }
            if ((oAssignmentData && !oAssignmentData.length) ||   this.getView().getModel().getProperty("/currentStepID") === "MANAPP") {
                this.getView().byId("idObjInfoAssignmentsSection").setVisible(false);
            } else {
                this.getView().byId("idObjInfoAssignmentsSection").setVisible(true);
            }
       
            this.getView().getModel("assignmentsModel").refresh(true);
        },
		handleSideContentHide: function () {
            sap.ui.core.BusyIndicator.show(0);
            const oDynamicSideView = this.getView().byId("idObjInfoDynamicSideContent");
            const sCurrentBreakpoint = oDynamicSideView.getCurrentBreakpoint();
            const oOPSideContentBtn = this.getView().byId("openSideContentBtnObjInfo");
            if (sCurrentBreakpoint === "S") {
                oDynamicSideView.toggle();
            } else {
                oDynamicSideView.setShowSideContent(false);
                sap.ui.core.BusyIndicator.hide();
            }
            oOPSideContentBtn.setVisible(true);

            setTimeout(function () {
                this.byId("openSideContentBtnObjInfo").focus();
            }.bind(this));
            sap.ui.core.BusyIndicator.hide();
        },
		onOpenReqAreDetailPopOver: function (oEvent) {
			var oButton = oEvent.getSource(),
				sContextReqArea = this.getView().getModel("wfInstanceModel").getData().RequestArea,
				aReqArea = sContextReqArea.split(","),
				oView = this.getView(),
				oModel = new sap.ui.model.json.JSONModel();
			aReqArea.shift();
			oModel.setData(aReqArea);
			this.getView().setModel(oModel, "reqAreaPopoVerModel");

			// create popover
			if (!this._pReqAreaPopover) {
				this._pReqAreaPopover = Fragment.load({
					id: oView.getId(),
					name: "com.dealsupport.melodyrequest.fragments.ReqAreaPopOver",
					controller: this
				}).then(function (oPopover) {
					oView.addDependent(oPopover);
					return oPopover;
				});
			}

			this._pReqAreaPopover.then(function (oPopover) {
				oPopover.openBy(oButton);
			});
		},

		formatObjectPageTitle:function(sReqType , sOppID , sAccID , sCreationDate,sCreationTime){
			var sTitle;
			var formattedDate = formatter.formatDate(sCreationDate,sCreationTime);
				switch (sReqType) {
					case 'Opportunity':
						sTitle = `${formattedDate} - Opportunity ${sOppID}`;
						break;
					case 'Account':
						sTitle = `${formattedDate} - Account ${sAccID}`;
						break;
					default:
						sTitle = `Workflow History`;
				}
                return sTitle;
			
		},
		onIconTabBarSelect: function (oEvent) {
			const sSelectedKey = oEvent.getParameter("selectedKey");
			const oGeneralInfoVBox = this.byId("idObjReqDetailsForm");
			const oAdditionalInfoVBox = this.byId("idObjTechDetailsForm");

			if (sSelectedKey === "RequestDetailsTab") {
				this._expandVBox(oGeneralInfoVBox);
				//this._collapseVBox(oAdditionalInfoVBox);
			} else if (sSelectedKey === "TechDetailsTab") {
				this._expandVBox(oAdditionalInfoVBox);
				//this._collapseVBox(oGeneralInfoVBox);
			}
		},
		_collapseVBox: function (oVBox) {
			oVBox.setVisible(false);
		},

		_expandVBox: function (oVBox) {
			oVBox.setVisible(true);
		},
     /**Git 132 (Form template changes + add new opp fields)
         *press event to show more processor list
         * @param {object} oEvent -The current control(link) event
         */
		onPressUserList: function (oEvent) {
			const oView = this.getView(),
				  that = this;
			if (!this._pMoreUerListPopOver) {
				//load userList more fragment
				this._pMoreUerListPopOver = Fragment.load({
					id: oView.getId(),
					name: "com.dealsupport.melodyrequest.fragments.userListMore",
					controller: this
				}).then(function (oMoreUerListDialog) {
					that._moreUserListDialog = oMoreUerListDialog;
					oView.addDependent(oMoreUerListDialog);
					return oMoreUerListDialog;
				});
			}

			this._pMoreUerListPopOver.then(function (oMoreUerListDialog) {
				  oMoreUerListDialog.openBy(oEvent.getSource());
			});

		},
		 /**Git 132 (Form template changes + add new opp fields)
         *press event to close processor popover list
         */
		onCloseMoreLisPopOver:function(){
			if(this._moreUserListDialog){
				this._moreUserListDialog.close();
			}
		},
		handleDetaillOpenInfoPress: function (oEvent) {
			let sRiskId = oEvent.getSource().getBindingContext("assignmentsModel").getObject().activityPaylod.RiskAssessId;
			this.getView().setModel(new JSONModel({
					"RiskAssessId":sRiskId
			}),"default");
			if (!this.detailRiskInfoPopup) {
				this.detailRiskInfoPopup = sap.ui.xmlfragment(this.getView().getId(),
					"com.dealsupport.melodyrequest.fragments.riskInfo", this);
				this.getView().addDependent(this.detailRiskInfoPopup);
			}
			this.detailRiskInfoPopup.openBy(oEvent.getSource());
		},

		handleDetailRiskInfoOkPress: function () {
			this.detailRiskInfoPopup.close();
		},
		   onDisplayActLeadInfo: function (oEvent) {
           CommonJS.onDisplayActLeadInfo(oEvent, this)

        },
        onTeamDetailPressed: function (oEvent) {
            CommonJS.onTeamDetailPressed(oEvent, this)
        },
        handleSendMailClick: function (oEvent) {
            CommonJS.handleSendMailClick(oEvent, this)
        },
        handleCallClick: function (evt) {
           CommonJS.handleCallClick(evt, this)
        },
        //Function to view list of team members in pop-up
        viewDetails: function (oEvent) {
             CommonJS.viewDetails(oEvent, this)
        },
		   onShowActivityInfo: function (evt) {
            const oAppConfigModel = this.getOwnerComponent().getModel("mrrAppConfigModel").getData();
            if (evt.getSource().getBindingContext("assignmentsModel").getObject().ActivityTypeInfo) {
                oAppConfigModel.ActivityType_InfoBubble = [{
                    "fieldDesc": evt.getSource().getBindingContext("assignmentsModel").getObject().ActivityTypeInfo
                }];
                CommonJS._onShowInfoMessage(evt, this);
            }

        }
	});

});