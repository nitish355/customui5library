sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/ui/core/Fragment',
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
	'sap/m/Token',
	"com/dealsupport/melodyrequest/model/models",
	"com/dealsupport/melodyrequest/model/formatter",
	"sap/m/MessageBox",
	"com/dealsupport/melodyrequest/control/Common",
	"com/dealsupport/melodyrequest/control/ErrorHandle"
], function (Controller, Fragment, Filter, FilterOperator, Token, models, formatter,MessageBox,CommonJS,ErrorHandle) {
	"use strict";

	return Controller.extend("com.dealsupport.melodyrequest.controller.CreateReqList", {
		formatter: formatter,
		onInit: function (evt) {
			this.getView().addStyleClass(appView.getOwnerComponent().getContentDensityClass());
			//initiate list-page
			appView.oDataResource = false;
			appView.listView = this;
			this.sStatus = "initialLoad";
			this.bus = appView.getOwnerComponent().getEventBus();
			//set model for  salesOrg Map for legacy or old requests to map with sales org profit center
			let opcmodel = new sap.ui.model.json.JSONModel( appView.getOwnerComponent().getModel("PCSalesOrgMasterData").getData());
            this.getView().setModel(opcmodel, "PCSalesOrgMaster");
			//reset all fields
			this._setModels();
			if(appView.oRouting){
				//Get and Set opportunity details from harmony
				this.fnGetSelectedOppoDetails(false,true)
				//appView.oRouting = false;
			}
		},
		/* Set Models*/
		_setModels:function(){
			let oAccountSearchModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oAccountSearchModel, "oAccountSearchModel");
			let cvaAccountModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(cvaAccountModel, "cvaAccountModel");
		},
		fnSuccessPublicSalesOrg: function (oData, self) {
			//set sales org model
			const oPublicReqAreaModel = new sap.ui.model.json.JSONModel();
						oPublicReqAreaModel.setData(oData);
			self.getView().setModel(oPublicReqAreaModel, "publicSalesOrgModel");
		},
		fnSuccessEmployeePartnerCallback: function (oData, self) {
			//get partner details
			self.sPartnerID = oData.d.results[0].PARTNER;
			self.sFinalQueryParams =
				`$filter=SALES_TEAM_MEMBER eq '${self.sPartnerID}' and (STATUS eq 'E0001' or STATUS eq 'E0007' or STATUS eq 'E0003') and (FORECAST eq '1' or FORECAST eq '4' or FORECAST eq '2' or FORECAST eq '3')& search-focus=ACCOUNT&search=`
			//call opportunity service based on the partner
			models.getMyOpportunities(self, self.sFinalQueryParams, self.fnSuccessOpportunitiesCallback,appView);
		},
		fnSuccessOpportunitiesCallback: function (oData, self) {
			//get opportunities and set model 'myOppDialogModel'
			const oMyOppModel = new sap.ui.model.json.JSONModel();
			oMyOppModel.setData(oData.d);
			self.getView().setModel(oMyOppModel, "myOppDialogModel");
			self.getView().getModel("myOppDialogModel").refresh();
		},
		setAccountModel: function (self) {
			//set account model 'myAccountModel'
			let aMyOpportunities = self.getView().getModel("myOppDialogModel").getData().results;
			let aAccount = [];
			aMyOpportunities.forEach(function (opp) {
				if (self.formatter.formatCreateRequestBtn(opp.DISP_AUTH, opp.IS_LEAN, opp.SALES_ORG_SHORT, self)) {
					aAccount.push({
						"ACCOUNT": opp.ACCOUNT,
						"ACCOUNT_NAME": opp.ACCOUNT_NAME
					});
				}
			});
			const oMyAccountModel = new sap.ui.model.json.JSONModel();
			oMyAccountModel.setData(aAccount);
			self.getView().setModel(oMyAccountModel, "myAccountModel");

		},
		handleValueHelpMyAccount: function (oEvent) {
			//initate value help dialog
			let oView = this.getView();
			const oButton = oEvent.getSource();
			let oAccSrchDataObj = {
				accounts: [],
				Industry: [],
				Region: [],
				Country: [],
				resultAccounts: [],
				lastUpdatedIndex: 0,
				sPlanningEntities: false,
				sGlobalUltimate: false,
				sIndustryKey: "",
				sRegionKey: "",
				sCountryKey: "",
				sSearchQuery: "",
				letiantid: "",
				simpleSrch: "",
				simpleSrchVisible: true,
				advancedSrchVisisble: false,
				aPrevStateQueryData: {},
				aPrevStateQueryIndex: 0
			};
			//set account model
			let oAccountSearchModel = this.getView().getModel("oAccountSearchModel");
			this.getView().setModel(oAccountSearchModel, "oAccountSearchModel");
			oAccountSearchModel.setProperty("/", oAccSrchDataObj);
			this.oAccountSearchModel = oAccountSearchModel;

			this.oAccountSearchModel.setProperty("/Industry", []);

			let cvaDataObj = {
				accounts: [],
				isAccountDialogBusy: false
			};
			let cvaAccountModel = this.getView().getModel("cvaAccountModel");
			this.getView().setModel(cvaAccountModel, "cvaAccountModel");
			cvaAccountModel.setProperty("/", cvaDataObj);
			this.cvaAccountModel = cvaAccountModel;

			// create value help dialog
			if (!this._pAccountValueHelpDialog) {
				this.sStatus = "initialLoad";
				this._pAccountValueHelpDialog = Fragment.load({
					id: oView.getId(),
					name: "com.dealsupport.melodyrequest.fragments.AccountSearch",
					controller: this
				}).then(function (oAccountValueHelpDialog) {
					oView.addDependent(oAccountValueHelpDialog);
					return oAccountValueHelpDialog;
				});
			}
			let that = this;

			this._pAccountValueHelpDialog.then(function (oAccountValueHelpDialog) {
				that.accountDialog = oAccountValueHelpDialog;
				that.getView().getModel("oAccountSearchModel").setProperty("/visibleRowCount",5);
				that.byId("ACCOUNT_SIMPLE_SEARCH").getHeaderToolbar().getContent()[0].setValue();
				that.byId("ICON_TAB_ADV_SEARCH").setSelectedKey("ADV_SEARCH");
				that.byId("ICON_TAB_ADV_SEARCH").fireSelect();
				that.oAccountSearchModel.refresh(true);
				oAccountValueHelpDialog.openBy(oButton);
			});
		},
		_getOpportunitiesRuntimeBaseURL: function (appView) {
			return this._getRuntimeBaseURL(appView) + "/int_ic";
		},
		_getRuntimeBaseURL: function (appView) {
			let componentName = appView.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
			let componentPath = sap.ui.require.toUrl(componentName);
			return componentPath;
		},
		searchAccounts: function (sValue, cvaFlag, accntList, searchType, sPrevQueryState) {
			//search account details based on accountName and accoundId
			let that = this;
			this.cvaFlag = cvaFlag;
			this.idAccntList = accntList;
			this.sValue = sValue;
			let oAccountSearchModel = that.getView().getModel("oAccountSearchModel");
			oAccountSearchModel.setProperty("/isAccountDialogBusy", true);
			let OpportunitiesBaseUrl = this._getOpportunitiesRuntimeBaseURL(appView, this);
			jQuery.ajax({
				url: `${OpportunitiesBaseUrl}/sap/opu/odata/sap/zharmony_callidus_srv/BusinessPartners?search=${sValue}&$filter=TYPE eq 'A'`,
				dataType: 'json',
				method: "GET",
				success: function (data) {
					data = data.d;
					var oData = [],
						obj = {};
					$.each(data.results, function (index, item) {
						obj.ACCOUNT_NAME = item.NAME;
						obj.ACCOUNT = item.PARTNER;
						oData.push(obj);
						obj = {};
					});
					let aFilter = new Filter({
						filters: [
							new Filter("ACCOUNT_NAME", "Contains", that.sValue),
							new Filter("ACCOUNT", "Contains", that.sValue)
						],
						and: false
					});
					if (that.cvaFlag) {
						let sSearchval = that.sValue.toLowerCase();
						let oFilteredData = [];
						oData.filter(function (accObj) {
							let Account = accObj.ACCOUNT;
							let AccountName = accObj.ACCOUNT_NAME.toLowerCase();
							if (Account.includes(sSearchval) || AccountName.includes(sSearchval)) {
								oFilteredData.push(accObj);
							}
						});
						that.cvaAccountModel.setData({
							"accounts": oFilteredData
						}, true);
						let cvaModel = that.getView().getModel("cvaModel");
						if (searchType === "ADV_SEARCH") {
							let oAccountSearchModel = that.getView().getModel("oAccountSearchModel");
							oAccountSearchModel.setProperty("/accounts", []);
							let aPrevStateQueryData = oAccountSearchModel.getProperty("/aPrevStateQueryData");
							if (oFilteredData.length) {
								let length = oFilteredData.length;
								if (oFilteredData.length > 100) {
									length = 100; 
								}
								for (let i = 0; i < length; i++) {
									let oTempObj = {
										Account: oFilteredData[i].ACCOUNT,
										AccountName: oFilteredData[i].ACCOUNT_NAME,
									};
									if (sPrevQueryState === "CONTAINS_QUERY") {
										let aPrevStateQueryIndex = oAccountSearchModel.getProperty("/aPrevStateQueryIndex");
										let oSearchedObj = that.fnFindSameAccountObject("Account", oFilteredData[i].ACCOUNT, aPrevStateQueryIndex);
										if (oSearchedObj) {
											if (oSearchedObj.hasOwnProperty("GlobalUltimate")) {
												oAccountSearchModel.getProperty("/accounts").push(oSearchedObj);
											} else {
												oAccountSearchModel.getProperty("/accounts").push(oTempObj);
												that.fnGetAcountDetails(i);
											}
										} else {
											oAccountSearchModel.getProperty("/accounts").push(oTempObj);
											that.fnGetAcountDetails(i);
										}
										oAccountSearchModel.setProperty("/isAccountDialogBusy", false);
										if (i + 1 === length) {
											oAccountSearchModel.setProperty("/lastUpdatedIndex", i);
											oAccountSearchModel.setProperty("/aPrevStateQueryData", aPrevStateQueryData);
											that.fnSetAccountMasterData();
										}
									} else {
										oAccountSearchModel.setProperty("/lastUpdatedIndex", i);
										oAccountSearchModel.getProperty("/accounts").push(oTempObj);
										that.fnGetAcountDetails(i, oFilteredData[i].ACCOUNT);
									}
								}
							} else {
								if (cvaModel) {
									cvaModel.setData({
										"accounts": []
									}, true);
								}
								that.cvaAccountModel.setData({
									"accounts": []
								}, true);
								let sAccounts = $.extend(true, [], oFilteredData);
								let sSearchQuery = oAccountSearchModel.getProperty("/sSearchQuery");
								sSearchQuery = sSearchQuery.split(" ").join("");
								sSearchQuery = sSearchQuery.toLowerCase();
								aPrevStateQueryData[sSearchQuery] = sAccounts;
								oAccountSearchModel.setProperty("/aPrevStateQueryData", aPrevStateQueryData);
								oAccountSearchModel.setProperty("/isAccountDialogBusy", false);
								oAccountSearchModel.refresh(true);
							}
						} else if (searchType === "SIMPLE_SEARCH") {
							if (cvaModel) {
								cvaModel.setData({
									"accounts": oData
								}, true);
								cvaModel.setProperty("/isAccountDialogBusy", false);
							}
							that.oOpportunityModel.setData({
								"accounts": oData
							}, true);
							that.idAccntList.getBinding("items").filter(aFilter);
							that.oOpportunityModel.setProperty("/isAccountDialogBusy", false);
						}
						that.getView().getModel("cvaAccountModel").setProperty("/isAccountDialogBusy", false);
					} else {
						that.oOpportunityModel.setData({
							"accounts": oData
						}, true);
						that.idAccntList.getBinding("items").filter(aFilter);
						that.oOpportunityModel.setProperty("/isAccountDialogBusy", false);
					}
				}.bind(this),
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide();
					if (oError.responseText) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error(oError.responseText, {});
					} else {
						MessageBox.error("Something went wrong", {});
					}
				}
			});
		},

		//Function to get Account Details by passing Account ID
		fnGetAcountDetails: function (accountIndex, accountID, isMyAccounts) {
			let that = this;
			let selDataObj = {};
			let oAccountSearchModel = that.getView().getModel("oAccountSearchModel");
			oAccountSearchModel.setProperty("/isAccountDialogBusy", true);
			if (isMyAccounts) {
				selDataObj = oAccountSearchModel.getProperty("/myAccounts/" + accountIndex);
			} else {
				selDataObj = oAccountSearchModel.getProperty("/accounts/" + accountIndex);
			}
			let accountId = selDataObj.Account;
			let OpportunitiesBaseUrl = this._getOpportunitiesRuntimeBaseURL(appView, this);
			jQuery.ajax({
				url: `${OpportunitiesBaseUrl}/sap/opu/odata/sap/zharmony_callidus_srv/Z1S_CRM_BUPA_INFOSet('${accountID}')`,
				dataType: 'json',
				method: "GET",
				success: function (oData) {
					var oData = oData.d;
					let street = oData.HouseNo ? "#" + oData.HouseNo + ", " : "";
					street = street + oData.Street;
					if (street) {
						street = oData.ZipCode ? street + ", " + oData.ZipCode : street;
					} else {
						street = oData.ZipCode ? oData.ZipCode : "";
					}
					oAccountSearchModel.getProperty("/accounts")[accountIndex].GlobalUltimate = oData.GlobalUltimateId === selDataObj.Account ?
						"true" : "false";
					oAccountSearchModel.getProperty("/accounts")[accountIndex].Street = street;
					oAccountSearchModel.getProperty("/accounts")[accountIndex].Country = oData.Country;
					oAccountSearchModel.getProperty("/accounts")[accountIndex].IndustryName = oData.IndustryName;
					oAccountSearchModel.getProperty("/accounts")[accountIndex].IndustryCode = oData.Industry;
					oAccountSearchModel.getProperty("/accounts")[accountIndex].IsPlanningEntity = oData.PlanningEntityId ? "true" : "false";
					oAccountSearchModel.getProperty("/accounts")[accountIndex].PE_ID = oData.PlanningEntityId;
					oAccountSearchModel.getProperty("/accounts")[accountIndex].PE_Name = oData.PlanningEntityName;
					oAccountSearchModel.getProperty("/accounts")[accountIndex].City = oData.City;
					oAccountSearchModel.getProperty("/accounts")[accountIndex].RegionCode = oData.Region;
					oAccountSearchModel.getProperty("/accounts")[accountIndex].GlobalRegion = oData.Region;

					let lastAccountObj = {};
					let lastUpdateIndex = oAccountSearchModel.getProperty("/lastUpdatedIndex");
					if (isMyAccounts) {
						lastAccountObj = oAccountSearchModel.getProperty("/myAccounts/" + lastUpdateIndex + "/Account");
					} else {
						lastAccountObj = oAccountSearchModel.getProperty("/accounts/" + lastUpdateIndex + "/Account");
					}
					if (oData.IndustryName && oData.Industry) {
						let oIndustryObj = {
							Description: oData.IndustryName,
							IndustryId: oData.Industry
						};
						let aIndustryArr = oAccountSearchModel.getProperty("/Industry");
						let isIndustryPresent = that.fnFindSameAccountObject("IndustryId", oData.Industry, aIndustryArr);
						if (!isIndustryPresent) {
							aIndustryArr.push(oIndustryObj);
						}
					}
					oAccountSearchModel.setProperty("/isAccountDialogBusy", false);
					oAccountSearchModel.refresh();
					that.fnFilterAdvSearchAccounts();
				}.bind(this),
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide();
					if (oError.responseText) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error(oError.responseText, {});
					} else {
						MessageBox.error("Something went wrong", {});
					}
				}
			});
		},
		fnGetIndustryFromAccount: function (sUrl) {

			return new Promise(function (resolve, reject) {
				jQuery.ajax({
					url: sUrl,
					dataType: 'json',
					method: "GET",
					success: function (oData) {
						resolve(oData?.d?.Industry ? oData.d.Industry : "");

					},
					error: function (oError) {
						if (oError.responseText) {							
							reject(oError.responseText);
						} else {							
							reject("Something went wrong")
						}
					}
				});

			})

		},
		fnFindSameAccountObject: function (oProperty, oValue, oArray) {
			let oSearchedObj = oArray.find(function (object) {
				return object[oProperty] === oValue;
			});
			return oSearchedObj;
		},
		//Function to set total accounts count in Icon tab bar
		fnSetAccountCount: function (lastUpdatedIndex, oAccounts, simpleSrchVisible) {
			let oAccountSearchModel = this.oAccountSearchModel;
			let oTxt = "Advanced Search";
			let isMyAccountsCountVisible = oAccountSearchModel.getProperty("/isMyAccountsCountVisible");
			let sSearchQuery = oAccountSearchModel.getProperty("/sSearchQuery");
			sSearchQuery = sSearchQuery.split(" ").join("");
			sSearchQuery = sSearchQuery.toLowerCase();
			let aPrevStateQueryData = oAccountSearchModel.getProperty("/aPrevStateQueryData");
			let allAaccounts = aPrevStateQueryData[sSearchQuery + "_AllAccounts"];
			var lastUpdatedIndex = aPrevStateQueryData[sSearchQuery + "_LastUpdatedIndex"];
			if (simpleSrchVisible) {
				return oTxt;
			} else {
				if (allAaccounts) {
					let oLength = allAaccounts.length;
					if (oLength) {
						lastUpdatedIndex = lastUpdatedIndex + 1;
						if (lastUpdatedIndex > oLength) {
							return oTxt + " (" + oLength + "/" + oLength + ")";
						} else {
							return oTxt + " (" + lastUpdatedIndex + "/" + oLength + ")";
						}
					} else {
						return oTxt;
					}
				} else {
					if (isMyAccountsCountVisible) {
						let accounts = oAccountSearchModel.getProperty("/accounts");
						if (accounts.length > 0) {
							return oTxt + " (" + accounts.length + "/" + accounts.length + ")";
						} else {
							return oTxt;
						}
					} else {
						return oTxt;
					}
				}
			}
		},
		handleAccountSearch: function (oEvent) {
			this.getView().getModel("oAccountSearchModel").setProperty("/Industry", []);
			let sValue = "";
			let eventType = typeof (oEvent);
			if (eventType === "object") {
				sValue = oEvent.getSource().getValue();
			} else if (eventType === "string") {
				sValue = oEvent;
			}
			let searchQuery = sValue;
			let i18nModel = appView.getOwnerComponent().getModel("i18n").getResourceBundle();
			//sValue = sValue.split(" ").join("");
			sValue = sValue.toLowerCase();
			let oAccountSearchModel = this.oAccountSearchModel;
			this.myAccounts = this.cvaAccountModel.getProperty("/myAccounts");
			if (sValue.length >= 3) {
				this.cvaAccountModel.setProperty("/accounts", []);
				this.cvaAccountModel.setProperty("/isAccountDialogBusy", true);
				oAccountSearchModel.setProperty("/accounts", []);
				oAccountSearchModel.setProperty("/isMyAccountsCountVisible", false);
				this.searchAccounts(sValue, true, "", "ADV_SEARCH");

			} else if (sValue === "") {
				this.fnClearFilterAdvSearchAccounts();
				oAccountSearchModel.setProperty("/accounts", []);
				oAccountSearchModel.setProperty("/isMyAccountsCountVisible", true);
				oAccountSearchModel.setProperty("/sSearchQuery", "");
			} else {
				const sValidationMsg = i18nModel.getText("searchValidationMsg");
				sap.m.MessageToast.show(sValidationMsg);
			}
		},
		//Function to filter Accounts in Advanced search 
		fnFilterAdvSearchAccounts: function (oEvent) {
			let aFilter = [],
				sPlanningEntitiesKey = "",
				sGlobalUltimateKey = "";
			let oAccountSearchModel = this.oAccountSearchModel;
			let table = this.byId("ACCOUNT_ADV_SEARCH_TBL");
			table.getBinding("rows").filter([]);
			let sPlanningEntities = oAccountSearchModel.getProperty("/sPlanningEntities");
			let sGlobalUltimate = oAccountSearchModel.getProperty("/sGlobalUltimate");
			let sIndustryKey = oAccountSearchModel.getProperty("/sIndustryKey");
			let sRegionKey = oAccountSearchModel.getProperty("/sRegionKey");
			let sCountryKey = oAccountSearchModel.getProperty("/sCountryKey");
			if (oEvent) {
				if (oEvent.getSource().getMetadata().getElementName() === "sap.m.CheckBox") {
					if (sPlanningEntities) {
						if (oEvent.getSource().getName() === "PLANNING_ENTITY" || sPlanningEntities) {
							sPlanningEntitiesKey = (sPlanningEntities === true) ? "true" : "false";
						}
					}
					if (sGlobalUltimate) {
						if (oEvent.getSource().getName() === "GLOBAL_ULTIMATE" || sGlobalUltimate) {
							sGlobalUltimateKey = (sGlobalUltimate === true) ? "true" : "false";
						}
					}
				} else {
					if (sPlanningEntities) {
						sPlanningEntitiesKey = (sPlanningEntities === true) ? "true" : "false";
					}
					if (sGlobalUltimate) {
						sGlobalUltimateKey = (sGlobalUltimate === true) ? "true" : "false";
					}
				}
			} else {
				if (sPlanningEntities) {
					sPlanningEntitiesKey = (sPlanningEntities === true) ? "true" : "false";
				}
				if (sGlobalUltimate) {
					sGlobalUltimateKey = (sGlobalUltimate === true) ? "true" : "false";
				}
			}
			if (sPlanningEntitiesKey) {
				aFilter.push(new sap.ui.model.Filter("IsPlanningEntity", "EQ", sPlanningEntitiesKey));
			}
			if (sGlobalUltimateKey) {
				aFilter.push(new sap.ui.model.Filter("GlobalUltimate", "EQ", sGlobalUltimateKey));
			}
			if (sIndustryKey) {
				aFilter.push(new sap.ui.model.Filter("IndustryCode", "EQ", sIndustryKey));
			}
			if (sRegionKey) {
				aFilter.push(new sap.ui.model.Filter("GlobalRegion", "EQ", sRegionKey));
			}
			if (sCountryKey) {
				aFilter.push(new sap.ui.model.Filter("Country", "EQ", sCountryKey));
			}
			table.getBinding("rows").filter(aFilter);

			let noOfRows = table.getBinding("rows").getLength();
			if (noOfRows === 0) {
				this.oAccountSearchModel.setProperty("/visibleRowCount", 1);
				this.byId("ACCOUNT_ADV_SEARCH_TBL").setVisibleRowCountMode("Fixed");
			} else if (noOfRows > 0 && noOfRows <= 5) {
				this.oAccountSearchModel.setProperty("/visibleRowCount", noOfRows);
				this.byId("ACCOUNT_ADV_SEARCH_TBL").setVisibleRowCountMode("Fixed");
			} else {
				this.byId("ACCOUNT_ADV_SEARCH_TBL").setVisibleRowCountMode("Auto");
			}
		},
		onSelectAccountTab: function (oEvent) {
			let selectedTab = "SIMPLE_SEARCH";
			let oAccountSearchModel = this.oAccountSearchModel;
			if (oEvent) {
				selectedTab = oEvent.getSource().getSelectedKey();
			}
			if (selectedTab === "SIMPLE_SEARCH") {
				oAccountSearchModel.setProperty("/simpleSrchVisible", true);
				oAccountSearchModel.setProperty("/advancedSrchVisisble", false);
				let cvaModel = this.getOwnerComponent().getModel("cvaModel");
				let myAccounts = this.oOpportunityModel.getProperty("/myAccounts");
				if (cvaModel) {
					cvaModel.setProperty("/accounts", myAccounts);
				}
				this.oOpportunityModel.setProperty("/accounts", myAccounts);
			} else if (selectedTab === "ADV_SEARCH") {
				oAccountSearchModel.setProperty("/simpleSrchVisible", false);
				oAccountSearchModel.setProperty("/advancedSrchVisisble", true);
				let sValue = oAccountSearchModel.getProperty("/sSearchQuery");
				if (sValue) {
					this.handleAccountSearch(sValue);
				}
			}
			oAccountSearchModel.refresh(true);
		},

		fnClearFilterAdvSearchAccounts: function () {
			//reset account dialogs
			let oAccountSearchModel = this.oAccountSearchModel;
			oAccountSearchModel.setProperty("/sPlanningEntities", false);
			oAccountSearchModel.setProperty("/sGlobalUltimate", false);
			oAccountSearchModel.setProperty("/sIndustryKey", "");
			oAccountSearchModel.setProperty("/sRegionKey", "");
			oAccountSearchModel.setProperty("/sCountryKey", "");
			this.fnFilterAdvSearchAccounts();
		},
		_handleValueHelpAccountClose: function (evt,oAccountInfo) {
			appView.oFinalData.RequestType = "Account";
			appView.oFinalData.accountSalesOrg = false;
			appView.onOpenBusyDialog();
			//select account
			this.aSelectedReqAreas = [];
			this.getView().byId("multiInputAccount").setTokens([]);
			let oSelectedItem;
			if(!oAccountInfo){
				oSelectedItem = evt.getSource().getBindingContext("oAccountSearchModel").getObject();
			}else{
				oSelectedItem = oAccountInfo;
			}
			let sTitle = oSelectedItem['Account'];
			let oMultiInput;
			oMultiInput = this.byId("multiInputAccount");
			oMultiInput.setTokens([]);
			this.aAccount = [];
			let that = this;
			if (oSelectedItem) {
				oMultiInput.addToken(new Token({
					text: sTitle
				}));
				that.aAccount.push(sTitle);
			}
			// Retrieve the selected key from the Sales Organization dropdown
			let sSalesOrg = appView.oFinalData.OrgID;

			let sAccount =  oSelectedItem['Account'];
			let oAppConstantsModel = appView.getOwnerComponent().getModel("appConstants");
			let sAccountBaseUrl = oAppConstantsModel.getProperty("/HarmonyURL/0/Value");
			let sAccountUrl = `${sAccountBaseUrl}Account/${sAccount}`;
			let isPFCSelection = oAppConstantsModel.getProperty("/ProfitCenter_Selection/0/Operational_Status");
			if(!isPFCSelection){
				appView.oFinalData.OrgID = sSalesOrg;
				appView.oFinalData.OrgType = "SORG";
			}else{
				appView.oFinalData.OrgType = "PC";
			}

			//set account payload
			appView.oFinalData.accountUrl = sAccountUrl;
			appView.oFinalData.accountName = oSelectedItem['AccountName'] ?  oSelectedItem['AccountName'].trim(): oSelectedItem['AccountName'];
			appView.oFinalData.IndustryName = oSelectedItem['IndustryName'];
			appView.oFinalData.PE_Name = oSelectedItem['PE_Name'];
			appView.oFinalData.accountId = oSelectedItem['Account'];
			appView.oFinalData.RequestType = "Account";
			models.getAccountlData(appView, this, oSelectedItem['Account'], this.fnSuccessAccountCallback);
			if (this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories") && this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories").length) {
				let pcGuid = this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories")[0].guid;
				let sorgID;
				this.getView().getModel("PCSalesOrgMaster").getData().find(function (item) {
					if (item.ProfitCenterGuid === pcGuid) {
						sorgID = item.SOrg;
					}
				});
				//set orgType
				let isResProfile;
                this.getView().getModel("PCSalesOrgMaster").getData().find(function (item) {
                    if (item.ProfitCenterGuid === pcGuid) {
                        isResProfile = item.isResourceProfile;
                    }
                });
				appView.oFinalData.OrgType = isResProfile ? "PC" : "SORG";
				// appView.oFinalData.oppOrgId = "SORG-" + ('0000' + sorgID).slice(-4)
				// appView.oFinalData.OrgID = appView.oFinalData.oppOrgId
			}else{
				this.getView().getModel("selectedProfitCenter").setProperty("/selectedPfc","");
				this.getView().getModel("selectedProfitCenter").refresh();
			}
			if(that.accountDialog){
				that.accountDialog.close();
			}
			if(evt){
				let sPath=evt.getSource().getBindingContext("oAccountSearchModel").getPath();
				let sIndustryCodeAcc=evt.getSource().getModel("oAccountSearchModel").getProperty(sPath).IndustryCode;

				appView.isAccountSelectedFromList=true
				appView.oFinalData.bAccountSelect = true;
				appView.oFinalData.INDUSTRY_MASTERCODE = sIndustryCodeAcc ? sIndustryCodeAcc : '';
				if(appView.oFinalData.oppAccountId !== appView.oFinalData.accountId){
					//reset all the mapping for new account selection
					appView.oFinalData.accountSalesOrg = true;
					appView.oFinalData.Opp_Desc = '';
					appView.oFinalData.oppOrgId = '';
					appView.oFinalData.SalesOrg = '';
					appView.oFinalData.salesOfficeText = '';
					appView.oFinalData.salesGroup='';
					this.getView().getModel("selectedProfitCenter").setData({ "TempProfitCenter": { "Territories": [] }, "filteredProfitCenter": [] })
					this.getView().getModel("selectedProfitCenter").refresh();
				}
			}
			
		
			sap.ui.core.BusyIndicator.show();			
			appView.onCloseBusyDialog();
		},
		fnCloseAccountSearch: function () {
			this.accountDialog.close();
		},
	
		fnSuccessAccountCallback: function (response, sAccountOwner) {
			//get account owner details
			
				//Git 181 start
				//Call profitcenter master data and set saleOrg+SalesOffice mapping
				CommonJS._callProfitCenterMasterData(appView.listView);
				//Git 181 end
			
			if (sAccountOwner) {
				let aPartnerList = response.d.results;
				let oAccountOwnerDetails = aPartnerList.filter((partner) => partner.NAME === sAccountOwner)[0];
				appView.oFinalData.AccountOwner = oAccountOwnerDetails.NAME;
				appView.oFinalData.AccountOwnerUserId = oAccountOwnerDetails.USERID;
				appView.oFinalData.AccountOwnerEmail = oAccountOwnerDetails.EMAIL;
			} else {
				appView.oFinalData.AccountOwner = response.d.PARENT_ACC_OWNR_NM;
				appView.oFinalData.AccountOwnerUserId = "";
				appView.oFinalData.AccountOwnerEmail = "";
			}			
		},
		_handleValueHelpCancel: function () {
			let that = this;
			this._pValueHelpDialog.then(function (oValueHelpDialog) {
				oValueHelpDialog.close();
			});
		},
		onTokenUpdate: function (evt) {
			appView.isDetailPageOpened=false
			this.byId("multiInputNewOpp").removeStyleClass("customLibInputOppSelectStyle");
			this.byId("multiInputNewOpp").addStyleClass("customLibInputOppStyle");
			appView._onDestroyAllResourcePopOvers();
			if(!evt || evt && evt.getParameter("reset")){
				appView.oFinalData = {};
			}
			let oAppConstantsModel = appView.getOwnerComponent().getModel("appConstants");
			let isPFCSelection =  oAppConstantsModel.getProperty("/ProfitCenter_Selection/0/Operational_Status");
			appView.listView.getView().byId("multiInputAccount").setWidth("99%");
			appView.oCreateDialog.setContentHeight("350px");
			appView.oCreateDialog.setContentWidth("800px");
			appView.getOwnerComponent().getModel("appConstants").setProperty("/oppAccConatinerVisible",false);
			appView.getOwnerComponent().getModel("appConstants").refresh();
			appView.oDataResource = false;
			appView.oRouting = false;
			appView.bus.publish("flexible", "setListPage");
			this._onResetFooterButtons();
			appView.oFinalData.opportunityId = "";
			appView.oFinalData.OrgID = "";
			appView.listView.getView().getModel("oppAccInfoModel").setData([]);
			appView.listView.getView().getModel("oppAccInfoModel").refresh();
			//reset opp and account selection field
			this.getView().byId("multiInputAccount").setWidth("99%");
			appView.oCreateDialog.setContentHeight("350px");
			appView.oCreateDialog.setContentWidth("800px");
			appView.getOwnerComponent().getModel("appConstants").setProperty("/oppAccConatinerVisible",false);
			appView.getOwnerComponent().getModel("appConstants").refresh();
		},
		/* on Reset footer model*/
		_onResetFooterButtons:function(){
			appView.getView().getModel("createReqFooterModel").setProperty("/footerButtons/searchResourceButtonVisible",false);
			appView.getView().getModel("createReqFooterModel").setProperty("/footerButtons/searchResourceButtonEnabled",false);
			appView.getView().getModel("createReqFooterModel").setProperty("/footerButtons/createReqButtonVisible",false);
			appView.getView().getModel("createReqFooterModel").setProperty("/footerButtons/createReqButtonEnabled",false);
			appView.getView().getModel("createReqFooterModel").refresh();
		},
		_onResetModels:function(){
			if (appView.getView().getModel("selectedProfitCenter") && !appView.oRouting) {
				appView.listView.getView().getModel("selectedProfitCenter").setProperty("/TempProfitCenter/Territories",[]);
				appView.listView.getView().getModel("selectedProfitCenter").setProperty("/TempProfitCenter/filteredProfitCenter",[]);
				appView.listView.getView().getModel("selectedProfitCenter").refresh(true);
			} if (appView.listView.getView().getModel("treeTerritories") && !appView.oRouting) {
				appView.listView.getView().getModel("treeTerritories").setData([]);
				appView.listView.getView().getModel("treeTerritories").refresh(true);
			}	
			
			// const sSalesOrg = appView.getOwnerComponent().getModel("userDetails").getData().salesOrgID;
			// this.onSetDefautAccProfitCenter(sSalesOrg, this);
		},
		onEngagementChange: function (oEvent) {
			let selectedKey = oEvent.getParameter("selectedItem").getKey();
			appView.oFinalData.EngagementType = selectedKey;			
			this.sStatus = "initialLoad"
			if (appView.isDetailPageOpened){
				var bDisplayDefaultPC= !appView.isAccountSelectedFromList			
				CommonJS._callProfitCenterMasterData(appView.listView,bDisplayDefaultPC);
			}


		},
		onSelectAccount:async function (evt) {
			try{
			appView.isAccountSelectedFromList=false
			appView.bIsSelectOppVal = false;
			if(this.getView().byId("idCreateSegContainer").getSelectedKey() === 'opp'){
					this.sStatus = "initialLoad"
			appView.oFinalData.RequestType = "Account";
			this.getView().getModel("oppAccInfoModel").setData([]);
			this.aSelectedParentNode = false;
			if(appView.oRouting){
				appView.initialRouting = true;
			}
			
			appView._onDestroyAllResourcePopOvers();
			let oAppConstantsModel = appView.getOwnerComponent().getModel("appConstants");
			this.getView().byId("multiInputAccount").setTokens([]);
			appView.listView.getView().byId("multiInputAccount").setWidth("99%");
			appView.getOwnerComponent().getModel("appConstants").setProperty("/oppAccConatinerVisible",false);
			appView.getOwnerComponent().getModel("appConstants").refresh();
			//select event for account
			if(!appView.oRouting){
				this.getView().byId("multiInputNewOpp").setOpportunityId("");
			}
				appView.prevSelectedOppDetails = appView.oFinalData["opportunityId"] ? JSON.parse(JSON.stringify(appView.oFinalData)):false;
				this.getView().byId("idAccountContainer").setVisible(true);
				this.getView().byId("idOppContainer").setVisible(false);
				let sSalesOrg = this.getView().getModel("userDetails").getData().salesOrgID;
			//get salesOrg-profitCenter smapping
				//	this.onSetDefautAccProfitCenter(sSalesOrg, this);
			// }	
			//opp touches
			if (appView.oFinalData.opportunityId) {
				const oAccountInfo = {
					"Account": appView.oFinalData.accountId,
					"AccountName": appView.oFinalData.accountName
				}
				let OpportunitiesBaseUrl = this._getOpportunitiesRuntimeBaseURL(appView);
				let sUrl=`${OpportunitiesBaseUrl}/sap/opu/odata/sap/zharmony_callidus_srv/Z1S_CRM_BUPA_INFOSet('${appView.oFinalData.accountId}')`
				var data;
				if (appView.getOwnerComponent().getModel("mrrAppEngModel").getProperty("/previousServiceCallResponses")) {
					if (appView.getOwnerComponent().getModel("mrrAppEngModel").getProperty("/previousServiceCallResponses").get(sUrl)) {
						data = appView.getOwnerComponent().getModel("mrrAppEngModel").getProperty("/previousServiceCallResponses").get(sUrl)
					} else {
						data = await this.fnGetIndustryFromAccount(sUrl)
						var mPrevServiceCallRespMap = appView.getOwnerComponent().getModel("mrrAppEngModel").getProperty("/previousServiceCallResponses")
						mPrevServiceCallRespMap.set(sUrl, data)
						appView.getOwnerComponent().getModel("mrrAppEngModel").setProperty("/previousServiceCallResponses", mPrevServiceCallRespMap)
					}
				} else {
					data = await this.fnGetIndustryFromAccount(sUrl)
					var mPrevServiceCallRespMap = new Map()
					mPrevServiceCallRespMap.set(sUrl, data)
					appView.getOwnerComponent().getModel("mrrAppEngModel").setProperty("/previousServiceCallResponses", mPrevServiceCallRespMap)
				}
				
				appView.oFinalData.INDUSTRY_MASTERCODE=data
				let sSalesOrg = appView.oFinalData.oppOrgId;
				const sSalesOrgNumber = Number(sSalesOrg.replace('SORG-', '')).toString();
			//Git 181 Start
			// if(appView.getOwnerComponent().getModel("territoriesPFCMaster").getData().length){
			// 	//Update default profitcenter
			// 	this.getView().getModel("selectedProfitCenter").setData(JSON.parse(JSON.stringify(appView.oFinalData.oppDefaultSalesOrg)));
			// 	this.getView().getModel("selectedProfitCenter").refresh();
			// }
			//Git 181 End
			 //removed duplicates call for IAC details
				if(!evt){
				this._getIACInfo(sSalesOrg);
				}else{
					//Route to detail screen
					// this._setDetailScreen(sSalesOrg);
				}
				//get salesOrg-profitCenter smapping
			//	this.onSetDefautAccProfitCenter(sSalesOrg, this);
				this._handleValueHelpAccountClose(false, oAccountInfo)
				
				appView.oFinalData.opportunityId = "";
			}else if(!appView.initialRouting){
				let sSalesOrg = this.getView().getModel("userDetails").getData().salesOrgID;
				//get salesOrg-profitCenter smapping
				//this.onSetDefautAccProfitCenter(sSalesOrg, this);
			}
			}
		} catch (oError) {
				sap.ui.core.BusyIndicator.hide();
				ErrorHandle.setErrorMessage(oError, that);
			}
			
			
		},
		onSetDefautAccProfitCenter: function(sSalesOrg , self){
			if(sSalesOrg){
			//parent selection

			let nodeUpdate = function nodeUpdate(newValue, that) {
				for (const child of newValue.nodes) {
					if (child.isCheckBox && child.isResourceProfile) {
						child.IsSelected = true;
						let oSelectedProfitCenter = models._setProfitCenterObj(child);
						that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories.push(
							oSelectedProfitCenter);
						that.getView().getModel("selectedProfitCenter").refresh(true);
					}
					nodeUpdate(child, that);
				}
			}
			if (self.aSelectedParentNode && self.aSelectedParentNode.isResourceProfile && self.aSelectedParentNode.isChildNodeEnable) {
				//select child nodes if LAC and isResourceProfile true
				nodeUpdate(self.aSelectedParentNode, self);
			}
			self.getView().getModel("selectedProfitCenter").refresh(true);
			self.getView().getModel("treeTerritories").refresh(true);
			self.getView().getModel("selectedProfitCenter").setProperty("/selectedPfc",self.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories[0]);
			}
		},
		onSelectOpp: function (evt) {
			appView.isAccountSelectedFromList=false
			//select event for opportunity
				this.sStatus = "initialLoad"
			appView.oFinalData.RequestType = "Opportunity";
			this.getView().getModel("oppAccInfoModel").setData([]);
			appView.initialRouting = false;
			appView._onDestroyAllResourcePopOvers();
			this._onResetFooterButtons();
			appView.getView().getModel("createReqFooterModel").setProperty("/footerButtons/createReqButtonEnabled",false)
			appView.getView().getModel("createReqFooterModel").refresh();
				
					this.getView().byId("idAccountContainer").setVisible(false);
			
				appView.oFinalData= appView.prevSelectedOppDetails ? appView.prevSelectedOppDetails: appView.oFinalData;
				
					this.getView().byId("idOppContainer").setVisible(true);
				
				appView.listView.getView().getModel("selectedProfitCenter").setProperty("/TempProfitCenter/Territories",[]);
				appView.listView.getView().getModel("selectedProfitCenter").setProperty("/TempProfitCenter/filteredProfitCenter",[]);
				// if(appView.prevSelectedOppDetails){
				// 	appView.prevSelectedOppDetails["OrgID"] = appView.prevSelectedOppDetails["oppOrgId"];
				// 		that._handleValueHelpClose(false,true);
				// }
				this.getView().getModel("selectedProfitCenter").refresh();
				let sSalesOrg = appView.oFinalData.OrgID;
				if(appView.oFinalData.Opp_Desc || appView.prevSelectedOppDetails){
					if(appView.prevSelectedOppDetails)
						appView.prevSelectedOppDetails["OrgID"] = appView.prevSelectedOppDetails["oppOrgId"];
						this.byId("multiInputNewOpp").removeStyleClass("customLibInputOppStyle");
						this.byId("multiInputNewOpp").addStyleClass("customLibInputOppSelectStyle");

					// this._setDetailScreen(sSalesOrg);
					let that = this;
					let oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session), 
						aPcOpp = oStorage.get("pcLibOpportunties") ? oStorage.get("pcLibOpportunties"):[],
						aLibOpp =  oStorage.get("pcLibOpportuntiesMR") ? oStorage.get("pcLibOpportuntiesMR").concat(aPcOpp): oStorage.get("pcLibOpportunties"),//Opportunity details from library storage
						oSelectedOpp = this.byId("multiInputNewOpp").getModel().getProperty("/selectedOpportunity");
					if (aLibOpp && aLibOpp.length && oSelectedOpp) {
						aLibOpp.forEach(function (opp) {
							if (oSelectedOpp.OpportunityId === opp.OpportunityId) {
								//Set status description
								opp.StatusDescription = oSelectedOpp?.StatusDescription ? oSelectedOpp.StatusDescription : ""
							}
						});
						const mapOpp = new Map();

						aLibOpp.forEach(item => {
							if (!mapOpp.has(item.OpportunityId) || item.isMR) {
								mapOpp.set(item.OpportunityId, item);
							}
						});
						aLibOpp = [...mapOpp.values()];
					}
				
					//store updated opportunity details
					oStorage.put("pcLibOpportuntiesMR", aLibOpp)
					that.fnGetSelectedOppoDetails(false, true);
				} else {
					appView.oFinalData ={};
					appView.listView.getView().byId("multiInputNewOpp").removeStyleClass("customLibInputOppSelectStyle");
					appView.listView.getView().byId("multiInputNewOpp").addStyleClass("customLibInputOppStyle");
					appView.oCreateDialog.setContentHeight("350px");
					appView.oCreateDialog.setContentWidth("800px");
					appView.getOwnerComponent().getModel("appConstants").setProperty("/oppAccConatinerVisible",false);
					appView.getOwnerComponent().getModel("appConstants").refresh();
					appView.isDetailPageOpened = false
					appView.bus.publish("flexible", "setListPage");
					
				}
		},
		_handleValueHelpOppSearch:function(evt){
			let sValue = evt.getParameter("query").toLowerCase(),
				oppTempModel = appView.getView().getModel("oppTempModel"),
				oFilter;
			if(sValue){
				let sFilterOppQuery = `$filter=OPPT_ID eq '${sValue}' and DISP_AUTH eq true and SALES_TEAM_MEMBER eq '${appView.sPartnerID}' and (STATUS eq 'E0001' or STATUS eq 'E0007' or STATUS eq 'E0003') and (FORECAST eq '1' or FORECAST eq '4' or FORECAST eq '2' or FORECAST eq '3')& search-focus=ACCOUNT&search=`
				sap.ui.core.BusyIndicator.show();
				setTimeout(function() {
					models.getMyOpportunities(appView, sFilterOppQuery, appView.fnSuccessOpportunitiesCallback,true);
				},1000);
				
				}else{
					appView.getView().getModel("myOppDialogModel").setData(appView.getView().getModel("oppTempModel").getData());
					appView.getView().getModel("myOppDialogModel").refresh()
				}
				
		},
		/**
		 * Get selected opportunity from opp library
		 * @function fnGetSelectedOppoDetails
		 * @param {object} evt - on select control scope
		 * @param {boolean} oRouting - harmony routing flag
		 */
		fnGetSelectedOppoDetails:function(evt,oRouting){
			appView.isAccountSelectedFromList=false
			this.sStatus = "initialLoad";
			this.byId("multiInputNewOpp").getAggregation("_clearIcon").addStyleClass("sapUiTinyMargin");
			this.byId("multiInputNewOpp").removeStyleClass("customLibInputOppStyle");
			this.byId("multiInputNewOpp").addStyleClass("customLibInputOppSelectStyle");
			//Git 181 start
			//set harmony routing flag			
			let bHarmonyRouting = appView.oFinalData.RequestType === "Opportunity" ? oRouting:false;
			appView.bIsSelectOppVal = false;
			//Git 181 end
			appView.oFinalData.RequestType = "Opportunity";
			if (!appView.listView.getView().getModel("oppAccInfoModel")) {
				appView.listView.getView().setModel(new sap.ui.model.json.JSONModel([]), "oppAccInfoModel");
				appView.listView.getView().getModel("oppAccInfoModel").refresh();
			}
			appView.listView.getView().getModel("oppAccInfoModel").setData([]);
			appView.listView.getView().getModel("oppAccInfoModel").refresh();
			appView._onDestroyAllResourcePopOvers();
			appView.onOpenBusyDialog();
			this.aNonSelectableParentNode = false;
			//select opportunity from dialog
			let oBindingContext;
			let sSalesOrg;
			
			this.aSelectedParentNode = false;
			if (this.getView().getModel("selectedProfitCenter")) {
				this.getView().getModel("selectedProfitCenter").setProperty("/TempProfitCenter/Territories", []);
				this.getView().getModel("selectedProfitCenter").setProperty("/TempProfitCenter/filteredProfitCenter", []);
				this.getView().getModel("selectedProfitCenter").refresh(true);
			}
			this.getView().byId("multiInputNewOpp").setOpportunityId("");
			if(evt || !oRouting){
			appView.oRouting = false;
			let aSelectedItems = evt.getParameter("listItem");
			this.oPPortunities = [];
			let that = this;
			if (aSelectedItems && aSelectedItems.length > 0) {
				aSelectedItems.forEach(function (oItem) {
					that.oPPortunities.push(oItem.getTitle());
				});
			}
			oBindingContext =  evt.getParameter("opportunityData");
			appView.getView().getModel("myOppDialogModel").setData(oBindingContext);
			sSalesOrg = oBindingContext.SALES_ORG_SHORT;
			//set opportunity payload
			appView.oFinalData = {};
			appView.oFinalData.accountName = oBindingContext.AccountName ? oBindingContext.AccountName.trim():oBindingContext.AccountName;
			appView.oFinalData.accountId = oBindingContext.AccountId;
			appView.oFinalData.opportunityId = oBindingContext.OpportunityId;
			appView.oFinalData.OrgID = oBindingContext.SALES_ORG_SHORT;
			appView.oFinalData.defaultOrgID = oBindingContext.SALES_ORG_SHORT;
			appView.oFinalData.oppOrgId =   oBindingContext.SALES_ORG_SHORT;
			appView.oFinalData.OrgType = "SORG";
			appView.oFinalData.RequestType = "Opportunity";
			appView.oFinalData.Opp_Desc = oBindingContext.Description;
			appView.oFinalData.SalesOrg = this._getSalesOrgName(appView.oFinalData.OrgID);
			this.getView().byId("multiInputNewOpp").setOpportunityId(appView.oFinalData.opportunityId);
		}else{
			this.getView().byId("multiInputNewOpp").setOpportunityId(appView.oFinalData.opportunityId);
			sSalesOrg = appView.oFinalData.OrgID;
			let oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let aLibOpp =  oStorage.get("pcLibOpportuntiesMR") ?  oStorage.get("pcLibOpportuntiesMR") :  [{OpportunityId:appView.oFinalData.opportunityId}];
			let aFilteredOpp = aLibOpp.filter(item=>item.OpportunityId === appView.oFinalData.opportunityId);
			let aSelectedOpp = aFilteredOpp.length ? aFilteredOpp[0]:{};
			this.getView().byId("multiInputNewOpp").setProperty("selectedOpportunity", aSelectedOpp);
		}
		  //Git 192 Start
		  if(evt || bHarmonyRouting){
			//Change opportunity or routing from harmony
				const oUrlParams = {
						$expand:'Notes,PartiesInvolved,DQReview,Attributes,CloseplanActivities,DocFlow,Attachments,Items,Pricing,RevenueSplitPlanH,RevenueSplitPlanI,SalesTeamWF,CustomerIncentive,S2SActivities,S2SActivities/PartiesInvolved,S2SActivities/Goals,RenewalExecution,OppHandover'
						};
				//get Opportunity Details(Sales-office)
				appView.bIsSelectOppVal = true;
				let that = this;
				//call opportunity service only for harmony routing
					setTimeout(function() {
					bHarmonyRouting ? models._getMyOpportunityDetails(appView,appView.oFinalData.opportunityId,oUrlParams,that.fnSuccessMyOppDetailsCallback):that.fnSuccessMyOppDetailsCallback(oBindingContext,that)
				},2000);
				
			}else{
				//execute when profit center details already loaded
				// this.fnSuccessProfitCenterCallBack(true);
				CommonJS._callProfitCenterMasterData(appView.listView,true);
				}	
		},
		/**
		 * Set opportunity data
		 * @function fnSuccessMyOppDetailsCallback
		 * @param {object} data - opportunity data
		 * @param {boolean} isHarmomyRouting - harmony routing flag
		 */
		fnSuccessMyOppDetailsCallback:function(data,that,isHarmomyRouting){
			//get salesOrg-profitCenter smapping
			appView.oFinalData.salesOfficeText = data.SALES_OFFICE_TEXT;
			appView.oFinalData.salesOfficeId = data.SALES_OFFICE_SHORT;
			appView.oFinalData.sSalesGroupShort = data.SALES_GROUP_SHORT;	//GIT-320 Configuration- Added sales group to PC master data query
			appView.oFinalData.oppPartnerName = data.PARTNER_NAME;
			appView.oFinalData.salesGroup = data.SALES_GROUP_TEXT;
			appView.oFinalData.INDUSTRY_MASTERCODE = data.INDUSTRY_MASTERCODE ? data.INDUSTRY_MASTERCODE : "";
			appView.listView.byId("multiInputNewOpp").removeStyleClass("customLibInputOppStyle");
			appView.listView.byId("multiInputNewOpp").addStyleClass("customLibInputOppSelectStyle");
			//Set opportunity details and update same in opportunity library storage for future use
			let oSelectedOpp = appView.listView.byId("multiInputNewOpp").getSelectedOpportunity() ?  appView.listView.byId("multiInputNewOpp").getSelectedOpportunity():{},
				oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session),
				aLibOpp = oStorage.get("pcLibOpportuntiesMR") ?oStorage.get("pcLibOpportuntiesMR"):[] ,
				sPhaseVal;
			if (!isHarmomyRouting) {
				data.CURR_PHASE = data && data.Phase ? data.Phase : "";
				sPhaseVal = oSelectedOpp && oSelectedOpp.Phase ? formatter.getCurrentPhase(oSelectedOpp.Phase) : data.CURR_PHASE;
				let sOwnerName = oSelectedOpp && oSelectedOpp.OWNER_NAME ? oSelectedOpp.OWNER_NAME : "";
				oSelectedOpp.OWNER_NAME = oSelectedOpp && oSelectedOpp.OwnerName ? oSelectedOpp.OwnerName : sOwnerName;
				oSelectedOpp.OwnerName = oSelectedOpp && oSelectedOpp.OwnerName ? oSelectedOpp.OwnerName :oSelectedOpp.OWNER_NAME;
				oSelectedOpp.StatusDescription = data && data.Status ? formatter.getOppState(data.Status) : "";
				oSelectedOpp.Industry_MasterCode_Text = data?.INDUSTRY_MASTERCODE_TEXT ? data.INDUSTRY_MASTERCODE_TEXT:"";
				oSelectedOpp.INDUSTRY_MASTERCODE_TEXT = oSelectedOpp.Industry_MasterCode_Text;
				if (oSelectedOpp) {
					aLibOpp.push(oSelectedOpp)
				}
				data.STATUS = data && data.Status ? data.Status : "";
			} else {
				appView.oFinalData.Opp_Desc = data.DESCRIPTION;
				appView.oFinalData.accountName =  data.ACCOUNT_NAME ? data.ACCOUNT_NAME.trim(): data.ACCOUNT_NAME;
				appView.oFinalData.defaultOrgID = data.SALES_ORG_SHORT;
				data.CURR_PHASE = data.CURR_PHASE ? data.CURR_PHASE : "";
				sPhaseVal = oSelectedOpp && oSelectedOpp.CURR_PHASE ? formatter.getCurrentPhase(oSelectedOpp.CURR_PHASE) :	formatter.getCurrentPhase(data.CURR_PHASE);
				oSelectedOpp.OWNER_NAME = data && data.OWNER_NAME ? data.OWNER_NAME : "";
				oSelectedOpp.Industry_MasterCode_Text = data?.INDUSTRY_MASTERCODE_TEXT ? data.INDUSTRY_MASTERCODE_TEXT:"";
				oSelectedOpp.INDUSTRY_MASTERCODE_TEXT = oSelectedOpp.Industry_MasterCode_Text;
			}
			oSelectedOpp.PhaseValue = sPhaseVal;
			oSelectedOpp.Sales_Org_Desc = data["SALES_ORG_TEXT"];
			if (aLibOpp && aLibOpp.length && oSelectedOpp) {
				aLibOpp.forEach(function (opp) {
					if (oSelectedOpp.OpportunityId === opp.OpportunityId) {
						//update new opportunity property OWNER_NAME,PhaseValue,Sales_Org_Desc
						opp.isMR = true;
						if (!isHarmomyRouting) {
							opp.OWNER_NAME = oSelectedOpp && oSelectedOpp.OwnerName ? oSelectedOpp.OwnerName:"";
							opp.StatusDescription =  data && data.Status ? formatter.getOppState(data.Status) :"";
						}else{
							opp.OWNER_NAME = data && data.OWNER_NAME ? data.OWNER_NAME:"";
							opp.StatusDescription =  data && data.STATUS ? formatter.getOppState(data.STATUS) :"";
						}
						opp.PhaseValue = sPhaseVal;
						opp.Sales_Org_Desc = data["SALES_ORG_TEXT"];
					}
				});
			oStorage.put("pcLibOpportuntiesMR", aLibOpp)
			}
			//update the storage
		

			if (isHarmomyRouting) {
				//harmony routing
				oSelectedOpp.StatusDescription = data && data.STATUS ? formatter.getOppState(data.STATUS) : "";
				oStorage.put("pcLibOpportuntiesMR", [oSelectedOpp])
			}
			//that.getModel().refresh();
			let aInternalOrder = [];
			let sInternalOrder1 = isHarmomyRouting ? data.INTERNAL_ORDER1 : data.InternalOrder1;
			let sInternalOrder2 = isHarmomyRouting ? data.INTERNAL_ORDER2 : data.InternalOrder2;
			data.INTERNAL_ORDER1 = sInternalOrder1 ? sInternalOrder1 : "";
			data.INTERNAL_ORDER2 = sInternalOrder2 ? sInternalOrder2 : "";
			data.INTERNAL_ORDER1 ? aInternalOrder.push(data.INTERNAL_ORDER1) : false;
			data.INTERNAL_ORDER2 ? aInternalOrder.push(data.INTERNAL_ORDER2) : false;
			appView.oFinalData.executiveSummary = data.Notes && data.Notes.results && data.Notes.results.length ? data.Notes.results[0]["CONC_LINES"] : "";
			appView.oFinalData.internalOrder = aInternalOrder.length ? aInternalOrder.toString() : "";
			sap.ui.core.BusyIndicator.hide();
			appView.getView().getModel("myOppDialogModel").setData(data);
			// Call the function to retrieve and set the profit center master data.
			// The second parameter 'true' to indicate if the request is for a forward operation or create request
			CommonJS._callProfitCenterMasterData(appView.listView,true);
		},
		 //Git 192 End
		 //Git 181 Start
		fnSuccessProfitCenterCallBack:function(bIsOppTabChange){
			//Execute after profitcenter sales office mapping
			const sSalesOrg = appView.oFinalData.OrgID,
				 that = appView.listView;
			if (bIsOppTabChange) {
				that.getView().getModel("selectedProfitCenter").setData(JSON.parse(JSON.stringify(appView.oFinalData.oppDefaultSalesOrg)));
			}
 		//Git 181 End
			//parent selection
			that.loadTreeTerritories("treeTerritories", appView.getView().getModel("territoriesMaster").getData(), true);
			that.setTerritoryHierarchySelection(false, false, false,true,true);			
			let nodeUpdate = function nodeUpdate(newValue, that) {
				for (const child of newValue.nodes) {
					if (child.isCheckBox && child.isResourceProfile) {
						child.IsSelected = true;
						let oSelectedProfitCenter = models._setProfitCenterObj(child);
						that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories.push(
							oSelectedProfitCenter);
						that.getView().getModel("selectedProfitCenter").refresh(true);
					}
					nodeUpdate(child, that);
				}
			}
			if (that.aSelectedParentNode && that.aSelectedParentNode.isResourceProfile && that.aSelectedParentNode.isChildNodeEnable) {
				//select child nodes if LAC and isResourceProfile true
				nodeUpdate(that.aSelectedParentNode, that);
			}
			appView.oFinalData.oppAccountId  = appView.oFinalData.accountId;
			sap.ui.core.BusyIndicator.show();
			that._getIACInfo(sSalesOrg);	
			appView.onCloseBusyDialog();
			if (that._pValueHelpDialog) {
				that._pValueHelpDialog.then(function (oValueHelpDialog) {
					oValueHelpDialog.close();
				});
			}
		},
		//call IAC Val
		_getIACInfo:async function(sSalesOrg){
			let that = this;
			const ointicSystemModel = models.systeminticDataModel(appView);
			sap.ui.core.BusyIndicator.show();
			var data
			try {
				if (appView.getOwnerComponent().getModel("mrrAppEngModel").getProperty("/previousServiceCallResponses")) {
					if (appView.getOwnerComponent().getModel("mrrAppEngModel").getProperty("/previousServiceCallResponses").get(`/BusinessPartnerAttribSet('${appView.oFinalData.accountId}')`)) {
						data = appView.getOwnerComponent().getModel("mrrAppEngModel").getProperty("/previousServiceCallResponses").get(`/BusinessPartnerAttribSet('${appView.oFinalData.accountId}')`)
					} else {
						data = await models._callGETOdata(ointicSystemModel, `/BusinessPartnerAttribSet('${appView.oFinalData.accountId}')`)
						var mPrevServiceCallsRespMap = appView.getOwnerComponent().getModel("mrrAppEngModel").getProperty("/previousServiceCallResponses")
						mPrevServiceCallsRespMap.set(`/BusinessPartnerAttribSet('${appView.oFinalData.accountId}')`, data)
						appView.getOwnerComponent().getModel("mrrAppEngModel").setProperty("/previousServiceCallResponses", mPrevServiceCallsRespMap)
					}
				} else {
					data = await models._callGETOdata(ointicSystemModel, `/BusinessPartnerAttribSet('${appView.oFinalData.accountId}')`)
					var mPrevServiceCallsRespMap = new Map()
					mPrevServiceCallsRespMap.set(`/BusinessPartnerAttribSet('${appView.oFinalData.accountId}')`, data)
					appView.getOwnerComponent().getModel("mrrAppEngModel").setProperty("/previousServiceCallResponses", mPrevServiceCallsRespMap)

				}
				sap.ui.core.BusyIndicator.hide();
				const IAC = data.TG_ACCOUNT_DESC ? data.TG_ACCOUNT_DESC.trim() : "";
				appView.oFinalData.iacValue = IAC;
				if(appView.onRouteBusyDialogClosed){
					//close the busy indicator dialog after harmony routing
					appView.onRouteBusyDialogClosed();
				}
				that._setDetailScreen(sSalesOrg);
			} catch (oError) {
				sap.ui.core.BusyIndicator.hide();
				models._setErrorMsgPopOver(appView, "Opportunity", oError);
			}
			
		},
		/*Set Footer property*/
		_setFooterButton:function(isResourceProfile){
			appView.getView().getModel("createReqFooterModel").setProperty("/footerButtons/searchResourceButtonVisible",isResourceProfile);
			appView.getView().getModel("createReqFooterModel").setProperty("/footerButtons/searchResourceButtonEnabled",false);
			appView.getView().getModel("createReqFooterModel").setProperty("/footerButtons/createReqButtonVisible",!isResourceProfile);
			appView.getView().getModel("createReqFooterModel").setProperty("/footerButtons/createReqButtonEnabled",false);
			appView.getView().getModel("createReqFooterModel").refresh();
		},
		/*Set detail screen for Resource profile or Request Area*/
		_setDetailScreen:function(sSalesOrg){
			appView.bIsSelectOppVal = false;	
			if(sSalesOrg){
                let isResourceProfile;
                if(this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories") && this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories").length){
                    isResourceProfile =this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories/0/isResourceProfile")?true:false;
                }else{
                    isResourceProfile = true;
                }
                appView.oFinalData.isResourceProfile = isResourceProfile;
                this._setFooterButton(isResourceProfile);
                appView.isResourceProfileScreen = isResourceProfile;
                if(!isResourceProfile){
                    appView.isResourceProfileScreen = false;
                    let orgId;
					if (sSalesOrg.includes("SORG")) {
						orgId = Number(sSalesOrg.replace('SORG-', '')).toString();
					} else {
						orgId = sSalesOrg;;
					}
					this._setFooterButton(false);
					models.getPublicReqArea(appView, orgId, this.fnSuccessPublicReqAreaCallback);
                }else{
					this._setFooterButton(true);
                    this.bus.publish("flexible", "setDetailPage",true);
                }
                 
			}else if(!sSalesOrg){
				//resource profile
				appView.oFinalData.isResourceProfile = "X";
				appView.detailViewScreen.getView().byId("idReqAreaContainer").setVisible(false);
				appView.detailViewScreen.getView().byId("idResIntro").setVisible(true);
				appView.detailViewScreen.getView().byId("idResProfitCenter").setVisible(true);
				appView.detailViewScreen.getView().byId("idResourceProfileContainer").setVisible(true);
				appView.listView.getView().getModel("selectedProfitCenter").setData()
			   	this.bus.publish("flexible", "setDetailPage",true);
				this._setFooterButton(true);
			}
        },
		/*Reset profit center selection */
		onResetProfitCenterSelection:function(){
			this.selectIfTerritoryExists(this.getView().getModel("treeTerritories").getData().territories, [], 0, true);
			this.getView().getModel("treeTerritories").refresh();
			this.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.TempTreeTerritories = [];
			this.getView().getModel("selectedProfitCenter").refresh();
		},
		_getSalesOrgName: function (sSalesOrgID) {
			//get sales org details
			if (sSalesOrgID) {
				const aSalesOrg = this.getView().getModel("publicSalesOrgModel").getData().value;
				if (aSalesOrg.some(obj => obj.Parent_SorgID === sSalesOrgID)) {
					return aSalesOrg.filter((org) => org.Parent_SorgID === sSalesOrgID)[0].Sales_org_name;
				}
			}
		},
		fnSuccessPublicReqAreaCallback: function (oData, self) {
			//initiate detailpage
			appView.oDataResource = oData;
			self.bus.publish("flexible", "setDetailPage", oData);
		},
		proceedToResourceType:function(){
			this.bus.publish("flexible", "setDetailPage", appView.oDataResource);
		},
		/*Open Profit center view selection dialog*/
		onOpenTerritoryValueHelpDialog: function(oEvent) {
			const that = appView.listView;
			const oModel = appView.listView.getView().getModel("selectedProfitCenter");
				
			this.bSelectPfc = false;
			if (!this.pTerritoryValueHelpDialog) {
				this.pTerritoryValueHelpDialog = this.loadFragment({
					name:"com.dealsupport.melodyrequest.fragments.TerritoryValueHelpDialog"
				});
			}

			this.pTerritoryValueHelpDialog.then(function (oDialog) {
				that.getView().byId("territoriesTableId").getExtension()[0].getContent()[0].setValue();
				that.filterTerritories();
				oModel.refresh(true);
				oDialog.openBy(oEvent.getSource());
			});
			
		  },
		/*Filter Profit center master data*/
		filterTerritories: function (initLoad, isRegionMUChange) {
			const oModel = appView.listView.getView().getModel("selectedProfitCenter");
			const oTerritoryModel = appView.getView().getModel("territoriesMaster");
			const aTerritories = oTerritoryModel.getData();
			const oTempEmployee = oModel.getProperty("/TempProfitCenter");
			let aEmployeeTerritories = oTempEmployee.Territories;
			oTempEmployee.TempTreeTerritories = oTempEmployee.Territories;

			//remove parent node if checkbox selection or isResourceProfile false;

			const aSelectedPfc = oModel.getData().TempProfitCenter.Territories;
			let isResourceProfileFound = aSelectedPfc.some(function (resource) {
				return resource.isResourceProfile;
			});
			if (aSelectedPfc.length > 1) {
				for (let i = 0; i < aSelectedPfc.length; i++) {
					if (!aSelectedPfc[i].isCheckBox || !aSelectedPfc[i].isResourceProfile && isResourceProfileFound) {
						aSelectedPfc.splice(i, 1)
					}
				}
			}

			if (isRegionMUChange) {
				aEmployeeTerritories = oTempEmployee.TempTreeTerritories;
			}

			let aTempTerritory = [];
			let bSelected = oModel.getProperty("/TempEmployee/TempMuRegionFlg");
			let aFilteredTerritories = aTerritories;

			if (bSelected) {
				aFilteredTerritories = aTerritories.filter(function (item) {
					return item.MuBelow === "";
				});
			}
			appView.listView.loadTreeTerritories("treeTerritories", aFilteredTerritories);
			oModel.refresh(true);
			appView.listView.setTerritoryHierarchySelection(false, true);
			this.getView().setModel(new sap.ui.model.json.JSONModel({
				"legacyValidation": false,
				"TempProfitCenter": oTempEmployee
			}), "masterDataModel");
			this.getView().getModel("masterDataModel").refresh();
		},
		/*Select profit center*/
		onSelectTerritory: function(oEvent) {
			this.bSelectPfc = true;
			this.selectIfTerritoryExists(this.getView().getModel("treeTerritories").getData().territories, [], 0, true);
			const oModel = this.getView().getModel("selectedProfitCenter");
			const oSource = oEvent.getSource();
			let bSelected = oEvent.getParameter("selected");
			let sSelectedDesc = oSource.data("displaydesc");
			const oBindingContext = oSource.getBindingContext("treeTerritories");
			const oTerritoryModel = oBindingContext.getModel();
			const sPath = oBindingContext.getPath();
			const oTerritory = oTerritoryModel.getProperty(sPath);
			oTerritory.IsSelected = true;
			this.oSelectedPFCNode = oTerritory.nodes;
			oTerritory.nodes = this.selectIfTerritoryExists(oTerritory.nodes, [], 0, false);
			const oTempEmployee = oModel.getProperty("/TempProfitCenter");
			let aEmployeeTerritories = oTempEmployee.TempTreeTerritories;
			aEmployeeTerritories = aEmployeeTerritories.filter(function (item) {
			  return !item.Desc.includes(sSelectedDesc);
			});
			let iIndex = aEmployeeTerritories.findIndex(function (item) {
			  return item.Desc.toUpperCase().trim() === oTerritory.displaydesc.toUpperCase().trim();
			});
	  
			if (iIndex !== -1 && !bSelected) {
			  aEmployeeTerritories.splice(iIndex, 1);
			  oTerritory.IsPrimary = false;
			} else if (iIndex === -1 && bSelected) {
			  if (aEmployeeTerritories.length === 0) {
				oTerritory.IsPrimary = true;
			  } else if (aEmployeeTerritories.length === 1 && aEmployeeTerritories[0].IsPrimary) {
				aEmployeeTerritories[0].IsPrimary = false;
			  }
				aEmployeeTerritories = [];
				const oProfitCenter = models._setProfitCenterObj(oTerritory);
			  aEmployeeTerritories.push(oProfitCenter);
			} else {
			  if (iIndex !== -1) {
				aEmployeeTerritories.splice(iIndex, 1);
			  }
			}
	  
			oModel.setProperty("/TempProfitCenter/TempTreeTerritories", aEmployeeTerritories);
			oModel.refresh(true);
			oTerritoryModel.refresh(true);
			this.getView().getModel("masterDataModel").setProperty("/TempProfitCenter",oModel.getProperty("/TempProfitCenter"));
			this.getView().getModel("masterDataModel").refresh();
		
		  },
		  /*Close profit center view selection fragment*/
		  onCloseTerritoryValueHelpDialog: function(evt) {
			this.pTerritoryValueHelpDialog.then(function (oDialog) {
			  oDialog.close();
			});
		  },
		  dialogAfterclose: function(oEvent) {//function called after Dialog is closed
			this._oDialog.destroy();//destroy only the content inside the Dialog
		 },
		 /*Set hierachy selection for profit center*/
		setTerritoryHierarchySelection: function(initLoad,forceReset,oBindingContext,bParanetNodeSelection,initialSelection) {
			const oModel = this.getView().getModel("selectedProfitCenter");
			const oTempEmployee = oModel.getProperty("/TempProfitCenter");
			const aTempTreeTerritories = bParanetNodeSelection ?   oTempEmployee.Territories:oTempEmployee.TempTreeTerritories;
			const oTerritoryHierarchyModel = this.getView().getModel("treeTerritories");
			let that = this;
			let aTerritoryHierarchies = oTerritoryHierarchyModel.getData();
			aTerritoryHierarchies = aTerritoryHierarchies.territories;
			aTerritoryHierarchies = this.selectIfTerritoryExists(aTerritoryHierarchies, [], 0, forceReset,bParanetNodeSelection,initialSelection);
			let aTerritory = [];
			for (let i = 0; i < aTempTreeTerritories.length; i++) {
			  let aDesc = aTempTreeTerritories[i].SelectedDesc.split(">");
	  
			  if (initLoad) {
				let territory = {};
				territory.Desc = aTempTreeTerritories[i].Desc;
				territory.Guid = aTempTreeTerritories[i].Guid;
				territory.IsPrimary = aTempTreeTerritories[i].IsPrimary;
				territory.TrpcId = aTempTreeTerritories[i].TrpcId;
	  
				for (let j = 1; j <= 5; j++) {
				  territory["TrpcL" + j + "Desc"] = aTempTreeTerritories[i]["TrpcL" + j + "Desc"];
				}
	  
				let oTerritory =  models._setProfitCenterObj(oTerritory);
				aTerritory.push(oTerritory);
			  }
	  
			  aTerritoryHierarchies = this.selectIfTerritoryExists(aTerritoryHierarchies, aDesc, 0,false,bParanetNodeSelection,initialSelection);
			}
	  
			if (initLoad) {
			  oTempEmployee.Territories = aTerritory;
			  oModel.setProperty("/TempEmployee/TRPCPGUIDValueState", "None");
			}
	  
			oModel.refresh(true);
			if(oBindingContext){
			let root = oBindingContext.getObject();
			let nodeUpdate = function nodeUpdate(newValue,that) {
				for (const child of newValue.nodes) {
					if(child.isCheckBox && child.isResourceProfile){
						child.IsSelected = true;
						let oSelectedProfitCenter = models._setProfitCenterObj(child);
						that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.TempTreeTerritories.push(
							oSelectedProfitCenter);
						that.getView().getModel("selectedProfitCenter").refresh(true);
					}
					nodeUpdate(child,that);
				}
			}
			if(root.isResourceProfile && root.isChildNodeEnable){
				//select child nodes if isResourceProfile true for parent node
				nodeUpdate(root,that);
			}
		}
			oTerritoryHierarchyModel.refresh(true);
		  },
		  /*Check if profit center exist or not*/
		  selectIfTerritoryExists: function(Territory, desc, index, forceReset,bParentNodeSelection,initialSelection) {
			if (!Territory || Territory.length === 0) {
			  return [];
			}
			const that = this;
			const oModel = this.getView().getModel("selectedProfitCenter");
			const oTempEmployee = oModel.getProperty("/TempProfitCenter");
			const aTempTreeTerritories = oTempEmployee.TempTreeTerritories;
			let oPrimaryTerritory;
			if(!bParentNodeSelection){
		     oPrimaryTerritory = aTempTreeTerritories.find(function (item) {
			  return item.IsPrimary;
			});
	  
		}
			for (let j = 0; j < Territory.length; j++) {
			  let territory = Territory[j];
			  if (!forceReset) {
				if (territory.desc.toUpperCase().trim() === (desc && desc[index] && desc[index].toUpperCase().trim())) {
					if(bParentNodeSelection && !initialSelection){
						if(desc.length-2 === index){
							territory.IsSelected = true;
							let oSelectedProfitCenter = models._setProfitCenterObj(territory);
							that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories = [oSelectedProfitCenter];
							that.aSelectedParentNode = territory;
					  }
					} else if (desc.length - 1 === index && !bParentNodeSelection) {
						that.aSelectedParentNode = territory;
						territory.IsSelected = true;
					}
			
	  
				  if (territory.desc.toUpperCase().trim() === desc[desc.length - 1].toUpperCase().trim()) {
					if(initialSelection){
						this.aSelectedParentNode = territory;
					}
					territory.IsEnabled = true;
				  } else {
					territory.IsEnabled = false;
				  }
				if(!bParentNodeSelection){
				  if (territory.IsSelected && aTempTreeTerritories.length === 1 && aTempTreeTerritories[0].Desc.toUpperCase().trim() === territory.desc.toUpperCase().trim()) {
					territory.IsPrimary = aTempTreeTerritories[0].IsPrimary;
				  } else if (oPrimaryTerritory && oPrimaryTerritory.Desc.toUpperCase().trim() === territory.desc.toUpperCase().trim()) {
					territory.IsPrimary = true;
				  } else {
					territory.IsPrimary = false;
				  }
				}
	  
				  if (territory.nodes && territory.nodes.length > 0) {
					territory.nodes = this.selectIfTerritoryExists(territory.nodes, desc, index + 1,false,bParentNodeSelection,initialSelection);
				  }
				}
			  } else {
				territory.IsSelected = false;
				territory.IsPrimary = false;
				territory.nodes = this.selectIfTerritoryExists(territory.nodes, desc, index + 1, true,bParentNodeSelection,initialSelection);
			  }
	  
			  Territory[j] = territory;
			}
	  
			return Territory;
		  },
		  /*Update selected profit center*/
		  onChangeTerritories: function onChangeTerritories(oEvent) {
			this.sStatus = "initialLoad";
			if(	this.bSelectPfc){
			this.aNonSelectableParentNode = false;
			appView._onDestroyAllResourcePopOvers();
			appView.onOpenBusyDialog();
			const oModel = this.getView().getModel("selectedProfitCenter");
			const oTempEmployee = oModel.getProperty("/TempProfitCenter");
			let aTerritory = [];
			const aEmployeeTerritories = oTempEmployee.TempTreeTerritories;
			const iPrimaryIndex = aEmployeeTerritories.findIndex(function (item) {
			  return item.IsPrimary;
			});
	  
			for (let i = 0; i < aEmployeeTerritories.length; i++) {
			  let territory = {};
			  territory.Desc = aEmployeeTerritories[i].Desc;
			  territory.guid = aEmployeeTerritories[i].guid;
			  territory.IsPrimary = aEmployeeTerritories[i].IsPrimary;
			  territory.id = aEmployeeTerritories[i].TrpcId;
			  territory.TrpcDesc = aEmployeeTerritories[i].Desc;
			  territory.isResourceProfile = aEmployeeTerritories[i].isResourceProfile;
			  territory.isCheckBox = aEmployeeTerritories[i].isCheckBox;
			  territory.isChildNodeEnable = aEmployeeTerritories[i].isChildNodeEnable;
			  territory.isParentNodeEnable =aEmployeeTerritories[i].isParentNodeEnable;
			  territory.GrpSelectable =aEmployeeTerritories[i].GrpSelectable;
			  territory.ParentGroupSelectable =aEmployeeTerritories[i].ParentGroupSelectable;
	  
			  for (let j = 1; j <= 5; j++) {
				territory["TrpcL" + j + "Desc"] = aEmployeeTerritories[i]["TrpcL" + j + "Desc"];
			  }
	  
			  const oTerritory =  models._setProfitCenterObj(territory);
			  aTerritory.push(oTerritory);
			}
	  
			oTempEmployee.Territories = aTerritory;
			this.onCloseTerritoryValueHelpDialog();
			  let sorgID;
			  this.getView().getModel("PCSalesOrgMaster").getData().find(function (item) {
				  if (item.ProfitCenterGuid === oTempEmployee.Territories[0].guid) {
					  sorgID = item.SOrg;
				  }
			  });
			  appView.oFinalData.OrgID = "SORG-"+('0000' + sorgID).slice(-4);
			  if(sorgID === "NOMP"){
				sorgID = oTempEmployee.Territories[0].guid;
				appView.oFinalData.OrgID = sorgID;
				appView.oFinalData.isNoMP = true;
				appView.oFinalData.OrgType = "PC";
			}
			oModel.refresh(true);
			this.getView().getModel("selectedProfitCenter").setProperty("/selectedPfc",this.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories[0]);	
			appView.onCloseBusyDialog();
		}else{
			appView.onCloseBusyDialog();
			this.onCloseTerritoryValueHelpDialog();
		}
	
		
			  let oSelectedProfitCenter = this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories/0");
			  appView.oFinalData.isResourceProfile = "X"
			  if(appView.detailViewScreen){
				appView.detailViewScreen.getView().setModel(new sap.ui.model.json.JSONModel(appView.listView.getView().getModel("selectedProfitCenter").getData()),"selectedProfitCenter")
				appView.detailViewScreen.getView().getModel("selectedProfitCenter").refresh();
				this._setDetailScreen(appView.oFinalData.OrgID);
			}
		  },
	
		getInstance: function getInstance() {
			if (!instance) {
			  // create new instance of Application Object
			  instance = new Application();
			}
	  
			return instance;
		  },
		  /*Load profit center master data*/
		loadTreeTerritories: function(type, results,bParentNodeSelection) {
			let aTerritories = []; 
			let aSlectedProfitCenter = this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories");

			let _loop = function _loop(i) {
				if(results[i].isFiltered){
				let oCluster = aTerritories.find(function (item) {
					return item.TrpcL1Desc === results[i].TGlobal;
				});

				if (!oCluster && results[i].TGlobal && results[i].TGlobal !== "") {
					let oPCCluster = results.find(function (item) {
						return item.TrpcDesc.toUpperCase().trim() === results[i].TGlobal.toUpperCase().trim();
					});
					oCluster = {
						guid: oPCCluster.TrpcGuid,
						id: oPCCluster.TrpcId,
						isResourceProfile:oPCCluster.isResourceProfile,
						desc: results[i].TGlobal,
						TrpcDesc: oPCCluster.TrpcDesc,
						Name: oPCCluster.Name,
						displaydesc: results[i].TGlobal,
						IsPrimary: false,
						IsEnabled: false,
						IsSelected: false,
						bPrimaryRole: results[i].bPrimaryRole,
						bSelectedRole: results[i].bSelectedRole,
						isRadioBtVisible: results[i].isRadioBtVisible,
						isPrimary: results[i].isPrimary,
						nodes: [],
						LevelId: "0001",
						TrpcL1Desc: results[i].TGlobal,
						isCheckBox: oPCCluster.isCheckBox,
						isChildNodeEnable: oPCCluster.isChildNodeEnable,
						isParentNodeEnable: oPCCluster.isParentNodeEnable,
						GrpSelectable: oPCCluster.GRP_Selectable,
						ParentGroupSelectable: ""
					};
					if(aSlectedProfitCenter.length && aSlectedProfitCenter.SelectedGuid === results[i].TrpcGuid){
						oCluster.IsSelected = true;
					}
					aTerritories.push(oCluster);
					aTerritories.sort(function (a, b) {
						return a.desc.localeCompare(b.desc);
					});
				}

				if (oCluster) {
					let aL1 = oCluster.nodes;
					let oL1 = aL1.find(function (item) {
						return item.TrpcL2Desc === results[i].Region;
					});

					if (!oL1 && results[i].Region && results[i].Region !== "") {
						// const oPCL1 = results.find(item => item.Name.includes(results[i].Region));
						let oPCL1 = results.find(function (item) {
							return item.TrpcDesc.toUpperCase().trim() === results[i].Region.toUpperCase().trim();
						});
						oL1 = {
							guid: oPCL1.TrpcGuid,
							id: oPCL1.TrpcId,
							desc: results[i].Region,
							TrpcDesc: oPCL1.TrpcDesc,
							isResourceProfile:oPCL1.isResourceProfile,
							isCheckBox: oPCL1.isCheckBox,
							isChildNodeEnable: oPCL1.isChildNodeEnable,
							isParentNodeEnable: oPCL1.isParentNodeEnable,
							Name: oPCL1.Name,
							displaydesc: results[i].TGlobal + " > " + results[i].Region,
							IsPrimary: false,
							IsEnabled: false,
							IsSelected: false,
							bPrimaryRole: results[i].bPrimaryRole,
							bSelectedRole: results[i].bSelectedRole,
							isRadioBtVisible: results[i].isRadioBtVisible,
							isPrimary: results[i].isPrimary,
							nodes: [],
							LevelId: "0002",
							TrpcL1Desc: results[i].TGlobal,
							TrpcL2Desc: results[i].Region,
							GrpSelectable: oPCL1.GRP_Selectable,
							ParentGroupSelectable: oCluster.GrpSelectable
						};
						if(aSlectedProfitCenter.length && aSlectedProfitCenter.SelectedGuid === results[i].TrpcGuid){
							oL1.IsSelected = true;
						}
						aL1.push(oL1);
						aL1.sort(function (a, b) {
							return a.desc.localeCompare(b.desc);
						});
					}

					if (oL1) {
						let aL2 = oL1.nodes;
						let oL2 = aL2.find(function (item) {
							return item.TrpcL3Desc === results[i].Mu;
						});

						if (!oL2 && results[i].Mu && results[i].Mu !== "") {
							let oPCL2 = results.find(function (item) {
								return item.TrpcDesc.toUpperCase().trim() === results[i].Mu.toUpperCase().trim();
							});

							if (!oPCL2) {
								oPCL2 = results[i];
							}

							oL2 = {
								guid: oPCL2.TrpcGuid,
								id: oPCL2.TrpcId,
								isResourceProfile:oPCL2.isResourceProfile,
								isCheckBox: oPCL2.isCheckBox,
								isParentNodeEnable: oPCL2.isParentNodeEnable,
								isChildNodeEnable: oPCL2.isChildNodeEnable,
								desc: results[i].Mu,
								TrpcDesc: oPCL2.TrpcDesc,
								Name: oPCL2.Name,
								displaydesc: results[i].TGlobal + " > " + results[i].Region + " > " + results[i].Mu,
								IsPrimary: false,
								IsEnabled: false,
								IsSelected: false,
								bPrimaryRole: results[i].bPrimaryRole,
								bSelectedRole: results[i].bSelectedRole,
								isRadioBtVisible: results[i].isRadioBtVisible,
								isPrimary: results[i].isPrimary,
								nodes: [],
								LevelId: "0003",
								TrpcL1Desc: results[i].TGlobal,
								TrpcL2Desc: results[i].Region,
								TrpcL3Desc: results[i].Mu,
								GrpSelectable: oPCL2.GRP_Selectable,
								ParentGroupSelectable: oL1.GrpSelectable
							};
							if(aSlectedProfitCenter.length && aSlectedProfitCenter.SelectedGuid === results[i].TrpcGuid){
								oL2.IsSelected = true
							};
							aL2.push(oL2);
							aL2.sort(function (a, b) {
								return a.desc.localeCompare(b.desc);
							});
						}

						if (oL2) {
							let aL3 = oL2.nodes;
							let oL3 = aL3.find(function (item) {
								return item.TrpcL4Desc === results[i].MuBelow;
							});

							if (!oL3 && results[i].MuBelow && results[i].MuBelow !== "") {
								// const oPCL3 = results.find(item => item.Name.includes(results[i].MuBelow));
								let oPCL3 = results.find(function (item) {
									return item.TrpcDesc.toUpperCase().trim() === results[i].MuBelow.toUpperCase().trim();
								});

								if (!oPCL3) {
									oPCL3 = results[i];
								}

								oL3 = {
									guid: oPCL3.TrpcGuid,
									id: oPCL3.TrpcId,
									isResourceProfile:oPCL3.isResourceProfile,
									isCheckBox: oPCL3.isCheckBox,
									isChildNodeEnable: oPCL3.isChildNodeEnable,
									isParentNodeEnable: oPCL3.isParentNodeEnable,
									desc: results[i].MuBelow,
									TrpcDesc: oPCL3.TrpcDesc,
									Name: oPCL3.Name,
									displaydesc: results[i].TGlobal + " > " + results[i].Region + " > " + results[i].Mu + " > " + results[i].MuBelow,
									IsPrimary: false,
									IsEnabled: false,
									IsSelected: false,
									bPrimaryRole: results[i].bPrimaryRole,
									bSelectedRole: results[i].bSelectedRole,
									isRadioBtVisible: results[i].isRadioBtVisible,
									isPrimary: results[i].isPrimary,
									TrpcL1Desc: results[i].TGlobal,
									TrpcL2Desc: results[i].Region,
									TrpcL3Desc: results[i].Mu,
									TrpcL4Desc: results[i].MuBelow,
									nodes: [],
									LevelId: "0004",
									GrpSelectable: oPCL3.GRP_Selectable,
									ParentGroupSelectable: oL2.GrpSelectable
								};
								if(aSlectedProfitCenter.length && aSlectedProfitCenter.SelectedGuid === results[i].TrpcGuid){
									oL3.IsSelected = true;
								}
								aL3.push(oL3);
								aL3.sort(function (a, b) {
									return a.desc.localeCompare(b.desc);
								});
							}
						}
					}
				}
				}
			};
			
			for (let i = 0; i < results.length; i++) {
				_loop(i);
			}
			const oTreeTerritoriesModel = new sap.ui.model.json.JSONModel({
				type: type,
				territories: aTerritories,
				leadTerritories: aTerritories
			});
			var oModel = oTreeTerritoriesModel;
    var oData = oModel.getData();

    function updateNodes(nodes) {
        nodes.forEach(function (node) {
            node.isMargin = (!node.nodes || node.nodes.length === 0);
			if (node.nodes && node.nodes.length > 0) {
                updateNodes(node.nodes); 
            }
        });
    }
    if (oData.territories && oData.territories.length > 0) {
        updateNodes(oData.territories); 
    }

    oModel.setData(oData);
			this.getView().setModel(oTreeTerritoriesModel, "treeTerritories");
				
		},
	/*Search profit center*/
		onSearchTerritory: function onSearchTerritory(oEvent) {
			const query = oEvent.getSource().getValue().trim();
			const TableId = oEvent.getSource().getParent().getParent();
			TableId.getBinding("rows").filter(query ? new Filter({
			  path: "desc",
			  operator: "Contains",
			  value1: query
			}) : null);
			TableId.expandToLevel(query ? 99 : 0);
		  },
		  _InitializeBusyIndicator:function(){
			if (!appView.pBusyIndicator) {
				appView.pBusyIndicator = appView.loadFragment({
					name: "com.dealsupport.melodyrequest.fragments.BusyDialog"
				});
			}
		   
		},
		onAfterOpenPopover: function () {
			var oTreeTable = this.byId("territoriesTableId");
			
			var oBinding = oTreeTable.getBinding("rows");
		
			if (oBinding.getLength() > 0) {
				oTreeTable.expand(0); 
			}
		},
		onSelectReqType:function(evt){
			const oSelectedProfitCenter = this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories/0");
			if(evt.getParameter("selectedIndex") === 1){
				//resource profile
				appView.detailViewScreen.getView().byId("idReqAreaContainer").setVisible(false);
				appView.detailViewScreen.getView().byId("idResIntro").setVisible(true);
				appView.detailViewScreen.getView().byId("idResProfitCenter").setVisible(true);
				appView.detailViewScreen.getView().byId("idResourceProfileContainer").setVisible(true);
				appView.isResourceProfile = "X";
				appView.oFinalData.isResourceProfile = "X";
				this.bus.publish("flexible", "setDetailPage",true);
				this._setFooterButton(true);
			}else{
				appView.oFinalData.isResourceProfile = "";
				appView.bus.publish("flexible", "setListPage");
				this.getView().byId("multiInputAccount").setWidth("99%");
				appView.oCreateDialog.setContentHeight("350px");
			appView.oCreateDialog.setContentWidth("800px");
			appView.getOwnerComponent().getModel("appConstants").setProperty("/oppAccConatinerVisible",false);
			appView.getOwnerComponent().getModel("appConstants").refresh();
				let oSelectedProfitCenter = this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories/0");
				 if (oSelectedProfitCenter && !oSelectedProfitCenter["isResourceProfile"]) {
					this._setDetailScreen(appView.oFinalData.oppOrgId);
				}else{
					const oFinalData = { "TempProfitCenter": { "Territories": [] }, "filteredProfitCenter": [] }
					this.getView().getModel("selectedProfitCenter").setData(oFinalData);
					this.getView().getModel("selectedProfitCenter").setProperty("/selectedPfc","")
					this.getView().getModel("selectedProfitCenter").refresh();
					this.getView().byId("multiInputAccount").setWidth("99%");
					appView.oCreateDialog.setContentHeight("350px");
			appView.oCreateDialog.setContentWidth("800px");
			appView.getOwnerComponent().getModel("appConstants").setProperty("/oppAccConatinerVisible",false);
			appView.getOwnerComponent().getModel("appConstants").refresh();
					this.bus.publish("flexible", "setListPage");
				}
			}

		},
		//show info/hint message
		onShowInfoMessage:function(evt){
			CommonJS._onShowInfoMessage(evt,this);
		},
		//opp pagination
		onUpdateFinished: function (oEvent) {
			//Pagination in the OppList page
			const oList = oEvent.getSource();
			const oOppModelData = appView.getView().getModel("myOppDialogModel").getData();
			if (oOppModelData) {
				const iTotalLen = oOppModelData.count;
				if (iTotalLen !== null && iTotalLen !== undefined && iTotalLen > 20) {
					//Setting the value for iBindingLength = oBinding.getLength() which is the total count of items.
					oList.getBindingInfo("items").binding.iLength = iTotalLen;
					if (oList.getGrowingInfo().actual === appView._alreadyLoadedOppCount && oList.getGrowingInfo().actual <
						iTotalLen && oEvent.getParameter("reason") === "Growing") {
						this._requestAndAppendMoreOppLists(appView._alreadyLoadedOppCount);
					}
				}
			}
		},
		_requestAndAppendMoreOppLists: function (alreadyLoadedOppCount) {
				//To load more data ( pagination )
				const iSkip = parseInt(alreadyLoadedOppCount, [10]),
				 	  iTop = 10,
				 	  that = this,
					  OpportunitiesBaseUrl = this._getOpportunitiesRuntimeBaseURL(appView),
				      sOppFilterQuery =`$filter=SALES_TEAM_MEMBER eq '${appView.sPartnerID}' and (STATUS eq 'E0001' or STATUS eq 'E0007' or STATUS eq 'E0003') and (FORECAST eq '1' or FORECAST eq '4' or FORECAST eq '2' or FORECAST eq '3')& search-focus=ACCOUNT&search=`;

				jQuery.ajax({
					async: false,
					contentType: "application/json",
					url: `${OpportunitiesBaseUrl}/sap/opu/odata/sap/zharmony_callidus_srv/Opportunities?$skip=${iSkip}&$top=${iTop}&${sOppFilterQuery}&$select=IS_FAVORITE,GUID,ACCOUNT_NAME,ACCOUNT,DEAL_TYPE,OPPT_ID,CHANGED_AT,URL,PROCESS_TYPE,PARTNER,PARTNER_NAME,IS_LEAN,BUSINESS_MODEL,DIS_CHANNEL,SOURCE,REVENUE_TYPE,HARMONY_TYPE,ERROR,HDM_MIG_STA,DESCRIPTION,EXPECTED_VALUE,DISP_AUTH,CURRENCY,MAINQUOTE,CPQ_QUOTE,CPQ_SYSTEM_ID,LICENSE_REVENUE,SERVICES_REVENUE,CLOUD_REVENUE,STATUS,OWNER_NAME,OWNER,USR_IN_SLS_TEAM,FORECAST,EXPECT_END,CLOSE_DATE_EDITABLE,CURR_PHASE,ORDER_ID,SALES_ORG_SHORT`,
                    dataType: 'json',
					type: "GET",
					success: function (oData) {
						appView._alreadyLoadedOppCount = oData.d.results.length + iSkip;
						let oModel = appView.getView().getModel("myOppDialogModel"),
						aOppLists = oModel.getData().results.concat(oData.d.results);
						oModel.setData({
							"count":oModel.getData().count,
							"results":aOppLists
						});
						appView.getView().getModel("myOppDialogModel").refresh();
						appView.getView().getModel("oppTempModel").setData({
							"count":oModel.getData().count,
							"results":aOppLists
						});
						appView.getView().getModel("oppTempModel").refresh();
					}.bind(this),
					error: function (oError) {
						MessageBox.error(oError.responseText, {
							contentWidth: "600px"
						});
						sap.ui.core.BusyIndicator.hide();
						return false;
					}
				});

			},

		
	});
});