var oHomePageView;
sap.ui.define([
	"sap/m/library",
	"sap/ui/core/mvc/Controller",
	"com/dealsupport/melodyrequest/model/models",
	"com/dealsupport/melodyrequest/model/users",
	"com/dealsupport/melodyrequest/model/formatter",
	"sap/ui/core/Fragment",
	"sap/m/MessageBox",
	'sap/ui/model/json/JSONModel',
	"sap/m/MessageToast",
	"sap/m/UploadCollectionParameter",
	"sap/ui/core/format/DateFormat",
	"sap/ui/core/library"
],
	function (mobileLibrary, Controller, models, users, formatter, Fragment, MessageBox, JSONModel, MessageToast, UploadCollectionParameter, DateFormat, library) {
		"use strict";
		var URLHelper = mobileLibrary.URLHelper;
		var workflowInstanceId,
			token,
			ValueState = library.ValueState;
		return Controller.extend("com.dealsupport.melodyrequest.controller.ReqDetailPage", {
			formatter: formatter,
			onInit: function () {
				this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
				if (this.getOwnerComponent().getRouter().getRoute("ReqDetailPage")) {
					this.getOwnerComponent().getRouter().getRoute("ReqDetailPage").attachPatternMatched(this._onObjectMatched, this);
				}
				this._expandVBox(this.byId("idReqDetailsForm"));
				this._collapseVBox(this.byId("idTechDetailsForm"));
				
			},
			_onObjectMatched: function (evt) {
				this.getOwnerComponent().getModel("appConstants").setProperty("/isOldVersionReq", false);
				this.getOwnerComponent().getModel("appConstants").refresh();
				this.getView().setVisible(true);
				const oDynamicSideView = this.getView().byId("DynamicSideContent");
				const sInstanceID = evt.getParameter("arguments").ID;
				this.getOwnerComponent().getModel("appConstants").setProperty("/isReqView",false)
				if (sInstanceID) {
					this.getOwnerComponent().getModel("appConstants").setProperty("/urlInstanceID", sInstanceID);
					models.getMyInboxInstanceDetails(this.fnSuccessCallback, this.fnErrorCallback, this, sInstanceID);
					//hide task history by default
					oDynamicSideView.setShowSideContent(false);
					this.onCurrProcContactlisticon();
					this.getView().byId("openSideContentBtn").setVisible(true);
					this.getView().byId("idNoDataDetailMsg").setVisible(false);
					this.getView().byId("DynamicSideContent").setVisible(true);
				} else {
					const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
					const sNoPendingRequestsDesc = i18nModel.getText("noPendingRequestsDesc");
					const sNoPendingRequestsTitle = i18nModel.getText("noPendingRequestsTitle");
					this.getView().byId("idNoDataDetailMsg").setDescription(sNoPendingRequestsDesc);
					this.getView().byId("idNoDataDetailMsg").setTitle(sNoPendingRequestsTitle);
					this.getView().byId("idNoDataDetailMsg").setVisible(true);
					this.getView().byId("DynamicSideContent").setVisible(false);
				}
			},
			fnSuccessCallback: function (oResponse, self) {
				self.getOwnerComponent().getModel("wfInstanceModel").setData(oResponse.value[0]);
				self.getOwnerComponent().getModel("wfInstanceModel").refresh();
				sap.ui.core.BusyIndicator.hide();
			},
			fnErrorCallback: function (oError, self) {
				MessageBox.error(oError.responseText, {
					contentWidth: "600px"
				});
				sap.ui.core.BusyIndicator.hide();
			},
			onCurrProcContactlisticon: function (oEvent) {
				//show current processor details
				sap.ui.core.BusyIndicator.show(0);
				const sName = "Current Processor";
				const sCurrentProcessorEmail = this.getOwnerComponent().getModel("wfInstanceModel").getData().CurrentProcessorEmail;
				const sCurrentProcessor = this.getOwnerComponent().getModel("wfInstanceModel").getData().CurrentProcessor;
				const oValType = "Email"
				const isListView = true;
				const self = this;
				if (!sCurrentProcessorEmail) {
					sap.ui.core.BusyIndicator.hide();
					if (sCurrentProcessor) {
						const aCurrentProcessor = sCurrentProcessor.split(",");
						const array = []
						const sArrLen = aCurrentProcessor.length
						for (let i = 0; i < aCurrentProcessor.length; i++) {
							const value = {
								"firstName": aCurrentProcessor[i]
							};
							users.empData(value, oEvent, self, array, sArrLen, sName, isListView);
						}
					}
				} else {
					users.callEmpApi(sCurrentProcessorEmail, oEvent, this, sName, oValType, isListView);
				}
			},
			currentAvatarDisplay: function (userId) {
				return this.getOwnerComponent().getModel("appConstants").getProperty("/userImg/0/Value") + userId;
			},
			handleStatusPressed: function (oEvent) {
				const sUrl = oEvent.getSource().getBindingContext("pendingReqModel").getObject().CurrentTaskURL;
				if (sUrl) {
					URLHelper.redirect(sUrl, "_blank");
				} else {
					this.onClickInbox();
				}
			},
			handleStatusPressed: function (oEvent) {
				const sUrl = oEvent.getSource().getModel("wfInstanceModel").getProperty("/CurrentTaskURL");
				URLHelper.redirect(sUrl, "_blank");
			},
			onPressEmpEmail: function (oEvent) {
				const sUrl = oEvent.getSource().getProperty("text");
				URLHelper.triggerEmail(sUrl, "Info Request - MRR", false, false, false, true);
			},
			onEmailToRequester: function (evt) {
				URLHelper.triggerEmail(evt.getSource().getText(), false, false, false, true);
			},
			handleOppStatusPressed: function () {
				const aOppUrl = this.getOwnerComponent().getModel("wfInstanceModel").getData()["ExtSystemsUrl"];
				URLHelper.redirect(aOppUrl, "_blank");
			},
			onGenericDealTagPress: function (oEvent) {
				sap.ui.core.BusyIndicator.show(0);
				const oView = this.getView(),
					oSourceControl = oEvent.getSource();
				if (!this._pDealPopover) {
					this._pDealPopover = Fragment.load({
						id: oView.getId(),
						name: "com.dealsupport.melodyrequest.fragments.DealInfoCard",
					}).then(function (oDealPopover) {
						oView.addDependent(oDealPopover);
						return oDealPopover;
					});
				}

				this._pDealPopover.then(function (oPopover) {
					oPopover.openBy(oSourceControl);
				});
				sap.ui.core.BusyIndicator.hide();
			},
			handleSCBtnPress: function (oEvent) {
				let sInstanceID = this.getOwnerComponent().getModel("wfInstanceModel").getData()["InstanceID"];
				models._getWfExecutionLogs(this, sInstanceID, this.fnSuccessGetExecutionLogsData);
				this.getView().byId("openSideContentBtn").setVisible(false);
				if (!this.getView().byId("openSideContentBtn").getVisible()) {
					this.getView().byId("idReqDetailPageFooter").setVisible(false);
				}
			},			
			handleSideContentHide: function () {
				sap.ui.core.BusyIndicator.show(0);
				const oDynamicSideView = this.getView().byId("DynamicSideContent");
				const sCurrentBreakpoint = oDynamicSideView.getCurrentBreakpoint();
				const oOPSideContentBtn = this.getView().byId("openSideContentBtn");
				if (sCurrentBreakpoint === "S") {
					oDynamicSideView.toggle();
				} else {
					oDynamicSideView.setShowSideContent(false);
					sap.ui.core.BusyIndicator.hide();
				}
				oOPSideContentBtn.setVisible(true);
				this.getView().byId("idReqDetailPageFooter").setVisible(true);

				setTimeout(function () {
					this.byId("openSideContentBtn").focus();
				}.bind(this));
				sap.ui.core.BusyIndicator.hide();
			},
			QuickListView: function (oModel, oevt, self, sName) {
				self.getView().setModel(oModel, "EmpListDetails");
				sap.ui.core.BusyIndicator.hide();
			},
			onOpenReqAreDetailPopOver: function (oEvent) {
				const oButton = oEvent.getSource(),
					sContextReqArea = this.getOwnerComponent().getModel("wfInstanceModel").getData().RequestArea,
					aReqArea = sContextReqArea.split(","),
					oView = this.getView(),
					oModel = new sap.ui.model.json.JSONModel();
				aReqArea.shift();
				oModel.setData(aReqArea);
				this.getView().setModel(oModel, "reqAreaPopoVerModel");

				// create popover
				if (!this._pReqAreaPopover) {
					this._pReqAreaPopover = Fragment.load({
						id: oView.getId(),
						name: "com.dealsupport.melodyrequest.fragments.ReqAreaPopOver",
						controller: this
					}).then(function (oPopover) {
						oView.addDependent(oPopover);
						return oPopover;
					});
				}

				this._pReqAreaPopover.then(function (oPopover) {
					oPopover.openBy(oButton);
				});
			},
			QuickViewCard: function (oModel, oevt, self, sName) {
				let oButton = oevt.getSource();
				self.getView().setModel(oModel, "EmpDetails");
				let EmployeeDetails = this.getView().getModel("EmpDetails");
				users._contactslistFragment(EmployeeDetails, oevt, self, sName).openBy(oButton);
				sap.ui.core.BusyIndicator.hide();
			},
			fnSuccessGetWfLogkDetails: function (result, that) {
				let aApprovalHistory = result.approvalHistory;
				result.aApproverData = [];
				if (result.approverDetails) {
					result.aApproverData = result.approverDetails
				}
				if (result.substituteApproverDetails) {
					result.aApproverData = result.aApproverData.concat(result.substituteApproverDetails);
				}
				if (result.AssignmentApprove) {
					let aAssignments = result.AssignmentApprove;
					aAssignments.forEach(function (assignments) {
						if (assignments.NominatedResources) {
							assignments.NominatedResources.forEach(function (resource) {
								result.aApproverData = result.aApproverData.concat(resource);
							})
						}
					});
				}
				for (let i = 0; i < aApprovalHistory.length; i++) {
					try {
						aApprovalHistory[i].userId = result.aApproverData.filter((user) => user.fullName.toLowerCase() === aApprovalHistory[i].UserName.toLowerCase())[
							0].userId;
					} catch (err) {

					}
				};
				if (result.Skip_Resource_Approver) {
					let aAssignments = [];
					aApprovalHistory.forEach(function (history, index, object) {
						if(!history.StepID && history.StepName === "Presales Resource Approval"){
							history.StepID = "RESAPP";
						}
						if (history.StepID === "RESAPP") {
							aAssignments.push(history.userId);
							object.splice(index, 1);
						}
					});
					if (aApprovalHistory) {
						if (!aApprovalHistory[aApprovalHistory.length - 1].StepID && aApprovalHistory[aApprovalHistory.length - 1].StepName === "Presales Manager Approval") {
							aApprovalHistory[aApprovalHistory.length - 1].StepID = "MANAPP";
						}
						if (aApprovalHistory[aApprovalHistory.length - 1].StepID === "MANAPP") {
							aApprovalHistory[aApprovalHistory.length - 1].Skip_Resource_Approver = result.Skip_Resource_Approver;
							aApprovalHistory[aApprovalHistory.length - 1].resourceCount = aAssignments.length;
							aApprovalHistory[aApprovalHistory.length - 1].resourcesId = aAssignments.join(";");
						}
					}
				}

				let oWfLogs = aApprovalHistory.reverse();
				let oModel = new JSONModel();
				oModel.setData(oWfLogs);
				that.getView().setModel(oModel, "wfLogs");
				let oDynamicSideView = that.getView().byId("DynamicSideContent");
				let sCurrentBreakpoint = oDynamicSideView.getCurrentBreakpoint();
				let oOPSideContentBtn = that.getView().byId("openSideContentBtn");
				if (sCurrentBreakpoint === "S") {
					oDynamicSideView.toggle();
				} else {
					oDynamicSideView.setShowSideContent(true);
				}

				oOPSideContentBtn.setVisible(false);
				sap.ui.core.BusyIndicator.hide();
			},
			onOpenResourceDetails:function(oEvent){
				sap.ui.core.BusyIndicator.show(0);
				let sName = "Resource List";
				let sResourceUserId = oEvent.getSource().getBindingContext("wfLogs").getObject().resourcesId;
				let uniqueIds = [...new Set(sResourceUserId.split(';'))].join(';');
				let oValType = "ID";
				users.callEmpApi(uniqueIds, oEvent, this, sName, oValType);
			},
			fnSuccessGetExecutionLogsData: function (result, self) {
				let sUserTaskId;
				result.forEach(function (logs) {
					if (logs.taskId) {
						sUserTaskId = logs.taskId
					}
				});
				if (sUserTaskId) {
					models._getWfTaskContextDetails(self, sUserTaskId, self.fnSuccessGetWfLogkDetails);
				}else{
					let i18nModel = self.getOwnerComponent().getModel("i18n").getResourceBundle();
			        let sErrorMess = i18nModel.getText("Somethingwentwrong");
					MessageBox.error( sErrorMess , {
                            });
				}

			},
			onIconTabBarSelect: function (oEvent) {
				const sSelectedKey = oEvent.getParameter("selectedKey");
				const oGeneralInfoVBox = this.byId("idReqDetailsForm");
				const oAdditionalInfoVBox = this.byId("idTechDetailsForm");

				if (sSelectedKey === "RequestDetailsTab") {
					this._expandVBox(oGeneralInfoVBox);
				} else if (sSelectedKey === "TechDetailsTab") {
					this._expandVBox(oAdditionalInfoVBox);
				}
			},
			_collapseVBox: function (oVBox) {
				oVBox.setVisible(false);
			},

			_expandVBox: function (oVBox) {
				oVBox.setVisible(true);
			},
			 /**
           * event trigger for old request opp routing
           *
           * @param {Object} evt -event object
           */
			 handleUrlRouting:function(evt){
				Models._handleUrlRouting(evt);
			 }


		});
	});