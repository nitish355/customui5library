sap.ui.define([
    "sap/m/library",
    "sap/ui/core/mvc/Controller",
    'sap/ui/core/Fragment',
    "sap/m/TablePersoController",
    "sap/m/SearchField",
    "./SettingsDialog",
    "com/dealsupport/melodyrequest/model/models",
    "com/dealsupport/melodyrequest/model/users",
    "sap/m/MessageBox",
    "sap/ui/model/type/String",
    "sap/ui/model/type/Date",
    "sap/ui/export/library",
    "sap/ui/export/Spreadsheet",
    "com/dealsupport/melodyrequest/model/formatter",
    "com/dealsupport/melodyrequest/control/ValueHelpUserCommon",
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator',
    "sap/m/Token",
    "com/dealsupport/melodyrequest/control/Common",
    "com/dealsupport/melodyrequest/control/IGroupHeaderListItem",
    "com/dealsupport/melodyrequest/control/ErrorHandle",
    "sap/m/Text",
    "sap/m/Button",
    'sap/ui/comp/library'
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (mobileLibrary, Controller, Fragment, TablePersoController, SearchField, SettingsDialog, models, users, MessageBox, TypeString, TypeDate,
        exportLibrary, Spreadsheet, formatter, UserCommon, Filter, FilterOperator, Token, Common, IGroupHeaderListItem, ErrorHandle,Text,Button,compLibrary) {
        "use strict";
        var URLHelper = mobileLibrary.URLHelper;
        var EdmType = exportLibrary.EdmType;
        var counts = -1;
        return Controller.extend("com.dealsupport.melodyrequest.controller.Worklist", {
            formatter: formatter,
            onInit: function () {
                var oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
                var sDownTimeFlag = oAppConstantsModel.getProperty("/DownTime/0/Operational_Status");
                this.getView().setBusyIndicatorDelay(0);
                  this._maxSelection = 11;
                if (sDownTimeFlag) {
                    this.getOwnerComponent().getRouter().navTo("NotFound");
                } else {
                    this._setBasicSearchBar();
                    this.initialLoad = true;
                    this.getOwnerComponent().getRouter().getRoute("Worklist").attachPatternMatched(this._onObjectMatched, this);
                    //initialize table settings
                    this._oTPC = new TablePersoController({
                        // init and activate controller for personalization 
                        table: this.getView().byId("id-table-wfHistory"),
                        componentName: "settings",
                        persoService: SettingsDialog
                    });
                }
                 this._bSortDescending = false; 
                const that = this;
                //call role(area) master data
                const oLSSystemModel = models.systemLSDataModel(that);
                models._callGETOdata(oLSSystemModel, `/YC_MR_M_ROLEAREA`)
                    .then(function (data) {
                        let oRoleMasterDataModel = new sap.ui.model.json.JSONModel(data);
                        that.getView().setModel(oRoleMasterDataModel, "roleMasterDataFilter");
                    })
                    .catch(function (error) {

                        ErrorHandle.setErrorMessage(oError, that, false, true);
                    });
                         models.getTechnicalState(this, false);
                this.getOREDirectReportees(this);
           
                that.getView().setModel(new sap.ui.model.json.JSONModel({
                    TempEmployee: {
                        "BAIndustries": []
                    },

                }), "employee");
                this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/results", []);
                const oEndDP = this.byId("dpEndDate");

                // Set maximum selectable date = Today
                const today = new Date();
                oEndDP.setMaxDate(today);
            },
          
            onSelectMyRequestTab: function () {
                // //select Master pag Tabs ( My Requests & My Pending Requests)
                this._onResetAllFilter();
                //this._fnWfHistoryAPICalls();
            
                // this._variantFmt.getContent()[0].getSelectedItem().getBindingContext("mroDataVariant").getObject()
                 var oView = this.getView();
                oView.byId("filterbar")._oBasicSearchField.setValue("");
                oView.byId("id-filter-currentState").setSelectedItems("");
                oView.byId("id-filter-reqType").setSelectedItems("");
                oView.byId("id-filter-opportunityID").removeAllTokens();
                oView.byId("id-filter-reqID").removeAllTokens();
                oView.byId("id-filter-accountname").removeAllTokens();
                oView.byId("id-filter-creationDate").removeAllTokens();
                oView.byId("id-filter-reqAreaPath").removeAllTokens();
                oView.byId("id-filter-requester").removeAllTokens();
                oView.byId("id-filter-currentProcessor").removeAllTokens();
                oView.byId("id-filter-task").setSelectedItems("");
                oView.byId("id-filter-reqType").setSelectedItems("");
                oView.byId("id-filter-taskRole").setSelectedItems("");
                oView.byId("id-filter-processor").removeAllTokens();
                oView.byId("id-filter-resource").removeAllTokens();
                oView.byId("id-filter-salesOrg").setSelectedItems("");
                if(!this._variantFmt){
                    //call variant service for initial load
                    models._getVariantData(this);
                }else{
                    //set variant data based on variant selection
                    this._setVariantData(this._variantFmt.getContent()[0].getSelectedItem().getBindingContext("mroDataVariant").getObject());
                }
                
            },
            _getOREResourcesBaseURL: function () {
                return this._getRuntimeBaseURL() + "/int_pc/sap/opu/odata/sap/YROSTER_SRV;v=0002/YC_DS_T_DIRECT_REPORTEES"
            },
            _getRuntimeBaseURL: function () {
                const appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
                const appPath = appId.replaceAll(".", "/");
                const appModulePath = sap.ui.require.toUrl(appPath);
                return appModulePath;
            },
            getOREDirectReportees: function (self) {
                var sLoggedInUserId = this.getOwnerComponent().getModel("userDetails").getProperty("/user_name").toUpperCase();
                const workflowBaseurl = this._getOREResourcesBaseURL();
                const that = this;
                const sUrl = workflowBaseurl + `?$filter=ManagerId eq '${sLoggedInUserId}'&$select=ResourceId,ManagerId,ManagerLevel`;

                $.ajax({
                    url: sUrl,
                    dataType: 'json',
                    async: false,
                    method: "GET",
                    success: function (data) {
                        const filteredarrayData = data.d.results;
                        if(filteredarrayData.length){
                            if (filteredarrayData.find(obj => obj.ResourceId === self.getOwnerComponent().getModel("userDetails").getProperty("/user_name").toUpperCase()).ManagerLevel !== "non-managerial") {
                                self.getOwnerComponent().getModel("userDetails").setProperty("/isManager", true);
                                const dirReporteesID = filteredarrayData.filter(obj => obj.ResourceId !== self.getOwnerComponent().getModel("userDetails").getProperty("/user_name").toUpperCase())
                                    .map(obj => obj.ResourceId);
                                const sDirRep = dirReporteesID.length ? dirReporteesID : [];
                                self.getOwnerComponent().getModel("userDetails").setProperty("/DirectReportees", sDirRep);
                            } else {
                                self.getOwnerComponent().getModel("userDetails").setProperty("/isManager", false);
                            }
                        }else{
                            self.getOwnerComponent().getModel("userDetails").setProperty("/isManager", false);
                        }

                    },
                    error: function (error) {
                        ErrorHandle.setErrorMessage(error, self);
                    }
                });

            },
            _setBasicSearchBar: function () {
                //initialize search toolbar
                let oFilterBar = this.getView().byId('filterbar');
                let that = this;
                let oAppConfigModel = this.getOwnerComponent().getModel("mrrAppConfigModel");
                let oBasicSearch = new SearchField({
                    placeholder:oAppConfigModel.getProperty("/BlankSearch/0/fieldDesc"),
                    search: function (oEvent) {
                        that.onFilter(oEvent);
                        //Fire call to search for value
                    }
                });
                oFilterBar.setBasicSearch(oBasicSearch);
            },
            _onSearch: function (oEvent) {
                //free-text search call
                this.getView().byId("id-table-wfHistory").setBusy(true);
                this._alreadyLoadedCount = 20;
                var sQuery = oEvent.getParameter('query');
                this.sSortQqueryPrams = `&$orderby=DTCreation_tdate desc,DTCreation_ttime desc`;
                var sCurrStateFilterQuery = this.getCurrentStateFilterQuery();
                this.sQueryParams = `/wf/V_WfInstance_Ext?$count=true&$search=${sQuery} and (${sCurrStateFilterQuery})`;
                this.sFinalQueryParams = `${this.sQueryParams}${this.sSortQqueryPrams}&$skip=0&$top=20`;
                models.getWfInstanceFilterLists(this.fnSuccessFilterCallback, this.fnErrorFilterCallback, this, this.sFinalQueryParams);
            },
            getCurrentStateFilterQuery: function () {
                const oModel = this.getView().getModel("currentStateModel");
                const oData = oModel.getData();
                const filteredData = oData.value.filter(item => {
                    const validIDs = ["REQFWD", "WRESAP", "REESUB", "WSUBMN", "WMNAPP", "WIOAPP", "DRAFT", "REQSUB", "REQCOM", "IOREJT" , "REQREJ" , "REQTER","RSBCOM","RSBREJ"];
                    return validIDs.includes(item.ID);
                });

                const currentStateString = filteredData.map(item => {
                    return `CurrentState eq '${item.Current_State}'`;
                }).join(" or ");

                return currentStateString;

            },
            _onObjectMatched: function () {
                this.getView().setVisible(true);
				this.getOwnerComponent().getModel("appConstants").setProperty("/pendingReqCount",   this.getOwnerComponent().getModel("appConstants").getProperty("/openTaskCount"));
                this.getOwnerComponent().getModel("appConstants").refresh();
                if(!this.getOwnerComponent().getModel("appConstants").getProperty("/isReqView") ||  this.initialLoad){
                    let sUrl = "/Public_ReqArea";
                    sap.ui.core.BusyIndicator.show()
                    // models.getCurrentStateLists(this.fnCurrentStateSuccessCallback, this.fnCurrentStateErrorCallback, this);
                    setTimeout(function(){
                        this._onResetAllFilter();
                        //this._fnWfHistoryAPICalls();
                           models.setTasksModel(this, false);
                        this.initialLoad = false;
                        appView._setSelectedMenuKey();
                        this.getView().setVisible(true);
                          const oStartDP = this.byId("dpCreateDate");
                          const oEndDP = this.byId("dpEndDate");
                        oStartDP.setMaxDate(new Date());
                        oEndDP.setMaxDate(new Date());
                        //set variant model
                        const oVariantsModel = new sap.ui.model.json.JSONModel({});
                        this.getView().setModel(oVariantsModel, "variants");
                        models._getVariantData(this)
                        models.getSolutionAreaMasterData(this)
                        const oOppInfoModel = new sap.ui.model.json.JSONModel({});
                        this.getView().setModel(oOppInfoModel, "oppInfoPopOverModel");
                        const oBAIndModel = new sap.ui.model.json.JSONModel();
                        this.getView().setModel(oBAIndModel, "baIndMasterData");
                        this.variants = new sap.ui.model.json.JSONModel();
                        let oVariantModel = this.getView().getModel("variant");
                        this._oTPC.activate();
                        this._oTPC.getTablePersoDialog().getInitialColumnState().sort(function (a, b) {
                            return a.text.localeCompare(b.text);
                        });
                        var oTable = this.byId("id-table-wfHistory");
                        var aCols = oTable.getColumns();

                        var aColsData = aCols.map(function (col) {
                            return {
                                id: col.getId(),
                                text: col.getHeader().getText(),
                                visible: col.getVisible()
                            };
                        });
                        this._oOppIdConditionsInput = this.byId("id-filter-opportunityID");

                        // Bind model for the column list
                        this.aDefaultColumns =JSON.parse(JSON.stringify(aColsData));
                        var oColsModel = new sap.ui.model.json.JSONModel({ columns: aColsData });
                        this.getView().setModel(oColsModel, "colModel");
                       
                        
                    }.bind(this))

                }else{
                    sap.ui.core.BusyIndicator.hide()
                }

            },
            /**
             * Git #269  Request View Update
             * Reset table setting selection
             * @function onToggleRefresh
             */
            onToggleRefresh:function(){
                this.getView().getModel("colModel").setProperty("/columns",this.aDefaultColumns);
                this.getView().getModel("colModel").refresh();
                this.aDefaultColumns =JSON.parse(JSON.stringify( this.getView().getModel("colModel").getProperty("/columns")));      
            },
            /**
             * Git #269  Request View Update
             * sort table setting
             * @function onToggleSort
             */
            onToggleSort: function () {
                this._bSortDescending = !this._bSortDescending;
                var oList =  this._oSettingsValueDialog.getContent()[0];
                var oBinding = oList.getBinding("items");

                // Apply sorter on "header" property
                var oSorter = new sap.ui.model.Sorter("text", this._bSortDescending);
                oBinding.sort(oSorter);

                // Also change the sort button icon to arrow up/down
                var oButton =  this._oSettingsValueDialog.getCustomHeader().getContentRight()[0];
                if (this._bSortDescending) {
                    oButton.setIcon("sap-icon://sort-descending");
                } else {
                    oButton.setIcon("sap-icon://sort-ascending");
                }
            },
             /**
             * Git #269  Request View Update
             * on select table setting column
             * @function onListSelectionChange
             */
            onListSelectionChange: function (oEvent) {
                var oList = oEvent.getSource();
                const item = oEvent.getParameter("listItem");
                const id = item.getBindingContext("colModel").getObject().id

                if (id.includes("idRequestSubId") || id.includes("idCurrentState")) {
                    item.setSelected(true);  
                }
                let aColModelData = this.getView().getModel("colModel").getData().columns;
                let aSelected = aColModelData.filter(item=>item.visible)

                if (aSelected.length > this._maxSelection) {
                    // Too many selected — deselect the last selected item
                    var oChangedItem = oEvent.getParameter("listItem");
                    oChangedItem.setSelected(false);
                    //max column selection - 11
                    new sap.m.MessageToast.show(
                        "Maximum " + this._maxSelection + " columns.",
                        { duration: 3000 }
                    );
                }
            },
            fnReqAreaSuccessCallback: function (oResult, self) {
                let newArray = [];
                let uniqueObject = {};
                for (let i in oResult.value) {
                    var objTitle = oResult.value[i]['Request_Area'];
                    uniqueObject[objTitle] = oResult.value[i];
                }
                for (var i in uniqueObject) {
                    newArray.push(uniqueObject[i]);
                }
                oResult.value = newArray;
                var oModel = new sap.ui.model.json.JSONModel();
                oModel.setData(oResult);
                self.getView().setModel(oModel, "reqAreaModel");
                oModel.refresh();
                sap.ui.core.BusyIndicator.hide();
            },
            fnReqAreaErrorCallback: function (oError) {
                MessageBox.error(oError.responseText, {
                    contentWidth: "600px"
                });
                sap.ui.core.BusyIndicator.hide();
            },
            // _fnWfHistoryAPICalls: function () {
            //     this._onResetAllFilter();
            //     this.filterApplied = false;
            //     models.setTasksModel(this, false);
            //     this.sSortQqueryPrams = `&$orderby=DTCreation_tdate desc,DTCreation_ttime desc`;
            //     var sLoggedInUserId = this.getOwnerComponent().getModel("userDetails").getProperty("/user_name").toUpperCase();
            //     var sCurrStateFilterQuery = this.getCurrentStateFilterQuery();
            //     // SANITIZE
            //     const dirRep = encodeURIComponent(this.getOwnerComponent().getModel("userDetails").getProperty("/DirectReportees"));
            //     if (this.getView().byId("idMyInboxIconTabHeader").getSelectedKey() === "myReqTab") {
            //         if(dirRep.length){
            //             const filterParts = dirRep.map(resourceId =>
            //                 `(contains(EmpRequester_ID,'${resourceId}') or contains(CurrentProcessorID,'${resourceId}') or contains(ReqApproverID,'${resourceId}') or contains(ReqIOApproverID,'${resourceId}') or contains(ReqResourcesID,'${resourceId}'))`
            //             );
    
            //             const combinedFilter = filterParts.join(" or ");
            //             this.sQueryParams = `/wf/V_WfInstance_Ext?$count=true&$filter=${combinedFilter} and (${sCurrStateFilterQuery})`;
            //         } else {
            //             this.sQueryParams = '';
            //             var aModel = new sap.ui.model.json.JSONModel();
            //             this.getOwnerComponent().setModel(aModel, "wfHistoryModel");
            //         }
            //     } else {
            //         this.sQueryParams = `/wf/V_WfInstance_Ext?$count=true&$filter=(contains(EmpRequester_ID,'${sLoggedInUserId}') or contains(CurrentProcessorID,'${sLoggedInUserId}') or contains(ReqApproverID,'${sLoggedInUserId}') or contains(ReqIOApproverID,'${sLoggedInUserId}') or contains(ReqResourcesID,'${sLoggedInUserId}')) and (${sCurrStateFilterQuery})`;
            //     }

            //     if (this.sQueryParams) {
            //         this.sFinalQueryParams = `${this.sQueryParams}${this.sSortQqueryPrams}&$skip=0&$top=20`;
            //         this._alreadyLoadedCount = 20;
            //         setTimeout(function(){
            //             models.getWfInstanceFilterLists(this.fnSuccessFilterCallback, this.fnErrorFilterCallback, this, this.sFinalQueryParams);
            //         }.bind(this),1000);
            //         this._oTPC.activate();
            //     }

            // },
            fnSuccessCallback: function (oResult, self) {
                var oModel = new sap.ui.model.json.JSONModel();
                oResult.count = oResult.value.length;
                oModel.setData(oResult);
                self.getOwnerComponent().setModel(oModel, "wfHistoryModel");
                sap.ui.core.BusyIndicator.hide();
                if (self._oSortDialog) {
                    self._oSortDialog.setSortDescending(true);
                    self._oSortDialog.setSelectedSortItem(
                        self._oSortDialog.getSortItems()[0].sId);
                }
            },
            fnErrorCallback: function (oError, self) {
                MessageBox.error(oError.responseText, {
                    contentWidth: "600px"
                });
                sap.ui.core.BusyIndicator.hide();
            },
            fnCurrentStateSuccessCallback: function (oResult, self) {
                var oModel = new sap.ui.model.json.JSONModel();
                oResult.value = oResult.value.filter(obj => obj.ID !== "REQCRT");
                oModel.setData(oResult);
                self.getOwnerComponent().setModel(oModel, "currentStateModel");
                sap.ui.core.BusyIndicator.hide();
            },
            fnCurrentStateErrorCallback: function (oError, self) {
                MessageBox.error(oError.responseText, {
                    contentWidth: "600px"
                });
                sap.ui.core.BusyIndicator.hide();
            },
            fnReqAreaErrorCallback: function (oError, self) {
                MessageBox.error(oError.responseText, {
                    contentWidth: "600px"
                });
                sap.ui.core.BusyIndicator.hide();
            },
                /**
            * Git #269  Request View Update
            * Open table setting dialog
            * @function onSettingsPress
            */
            onSettingsPress: function (oEvent) {
                //open table column settings dialog
                if (!this.pSettingsalueDialog) {
                    this.pSettingsValueDialog = this.loadFragment({
                        name: "com.dealsupport.melodyrequest.fragments.tableSettingDialog"
                    });
                }
                this.pSettingsValueDialog.then(function (oSettingsValueDialog) {
                    oSettingsValueDialog.open();
                    this._settingsModelData = JSON.parse(JSON.stringify(this.getView().getModel("colModel").getData()));
                    this._oSettingsValueDialog = oSettingsValueDialog;
                }.bind(this));
            },
                 /**
            * Git #269  Request View Update
            * trigger event when table setting dialog colModel updates
            * disable check box selection for request subId and Req status
            * @function onListUpdateFinished
            */
            onListUpdateFinished: function () {
                const aItems = this._oSettingsValueDialog.getContent()[0].getItems();
                aItems.forEach(item => {
                    const id = item.getBindingContext("colModel").getObject().id
                    item.removeStyleClass("disableCheckbox");
                    if (id.includes("idRequestSubId") || id.includes("idCurrentState")) {
                        item.addStyleClass("disableCheckbox");
                    }
                });
            },
                 /**
            * Git #269  Request View Update
            * close the table setting dialog
            * @function onCancelColumns
            */
            onCancelColumns: function () {
                this._oSettingsValueDialog.close();
                this.getView().getModel("colModel").setData(this._settingsModelData);
                this.getView().getModel("colModel").refresh()
            },
                 /**
            * Git #269  Request View Update
            * search event for table setting dialog
            * @param {oEvent} search control event
            * @function onColumnSearch
            */
            onColumnSearch: function (oEvent) {
                var sQuery = oEvent.getParameter("newValue");
                var oList = this._oSettingsValueDialog.getContent()[0];
                var oBinding = oList.getBinding("items");

                if (!sQuery) {
                    oBinding.filter([]);
                } else {
                    var oFilter = new Filter("text", FilterOperator.Contains, sQuery);
                    oBinding.filter([oFilter]);
                }
            },
                /**
            * Git #269  Request View Update
            * add columns
            * @param {oEvent} search control event
            * @function onApplyColumns
            */
            onApplyColumns: function () {
                var oList = this._oSettingsValueDialog.getContent()[0];
                var oBinding = oList.getBinding("items");
                oBinding.filter([]);
                var oTable = this.byId("id-table-wfHistory");
                var aSelected = this._oSettingsValueDialog.getContent()[0].getSelectedItems();

                var oModel = this.getView().getModel("colModel");
                var aCols = oModel.getProperty("/columns");

                aCols.forEach(function (col) {
                    var oCol = sap.ui.getCore().byId(col.id);
                    if (oCol) {
                        oCol.setVisible(false);
                    }
                });

                aSelected.forEach(function (item) {
                    var sId = item.getBindingContext("colModel").getObject().id
                    var oCol = sap.ui.getCore().byId(sId);
                    if (oCol) {
                        oCol.setVisible(true);
                    }
                });

                this._oSettingsValueDialog.close();
            },
            toReportPage: function (oEvent) {
                var oItem = oEvent.getSource();
                const oContextObject =  oItem.getBindingContext("wfHistoryModel").getObject();
                var sInstanceId = oItem.getBindingContext("wfHistoryModel").getProperty("InstanceID");
                const oRouter = this.getOwnerComponent().getRouter();

                const sRoute = this._setDetailPageRoute(oContextObject)
                if (oContextObject) {
                    oRouter.navTo(sRoute, {
                        ID: oContextObject.InstanceID
                    });
                } else {
                    oRouter.navTo("Object", {
                        ID: sInstanceId,
                        oBusy: this
                    });
                }
            },
            _setDetailPageRoute: function (oContextObject) {
                const sLoggedInUser = this.getOwnerComponent().getModel("userDetails").getProperty("/email");
                if (oContextObject) {
                    const isCurrentProcesser = formatter.formatUrl(oContextObject.CurrentProcessorEmail, sLoggedInUser, oContextObject.TechnicalState, oContextObject.currentStateID);
                    if (!isCurrentProcesser && !((oContextObject.currentStateID === "REESUB" || oContextObject.currentStateID === "REQSUB") && oContextObject.CurrentProcessorEmail === sLoggedInUser)) {
                        return "Object";
                    } else {
                        switch (oContextObject.currentStateID) {
                            case "REQSUB":
                                return "SubmitReqView";
                                break;
                            case "REESUB":
                                return "SubmitReqView";
                                break;
                            case "WMNAPP":
                                return "ManagerReqView";
                                break;
                            case "WSUBMN":
                                return "ManagerReqView";
                                break;
                            case "WRESAP":
                                return "ManagerReqView";
                                break;
                            case "WIOAPP":
                                return "IOOwnerReqView";
                                break;
                            default:
                                return "Object";
                                break;
                        }
                    }
                } else {
                    return "Object";
                }
            },
            onFilter: function () {
                //master data filter based on multi fields
                this.getView().setBusyIndicatorDelay(0);
                this.getView().byId("id-table-wfHistory").setBusy(true);
                let oView = this.getView();
                let aCurrentStateTokens = oView.byId("id-filter-currentState").getSelectedItems();
                let aCurrentTaskTokens = oView.byId("id-filter-task").getSelectedItems();
                let aRequestTypeTokens = oView.byId("id-filter-reqType").getSelectedItems();
                let aCurrentTaskRoleTokens = oView.byId("id-filter-taskRole").getSelectedItems();
                let aRoleTokens = oView.byId("id-filter-role").getSelectedItems();
                let aOpporTunityIDTokens = oView.byId("id-filter-opportunityID").getTokens();
                let aAccountIDTokens = oView.byId("id-filter-accountname").getTokens();
                let aRequestIDTokens = oView.byId("id-filter-reqID").getTokens();
                let aCreationDateTokens = oView.byId("id-filter-creationDate").getTokens();
                let aRequestAreaPath = oView.byId("id-filter-reqAreaPath").getTokens();
                let aRequester = oView.byId("id-filter-requester").getTokens();
                let aProcessor = oView.byId("id-filter-processor").getTokens();
                let aResource = oView.byId("id-filter-resource").getTokens();
                let aCurrentProcessor = oView.byId("id-filter-currentProcessor").getTokens();
                let aSalesOrg = oView.byId("id-filter-salesOrg").getSelectedItems();
                let aReqSlns = oView.byId("id-filter-reqSolutions").getTokens();
                let aReqInd = oView.byId("idFilterInd").getTokens();
                let urlCurrentStateParams = "CurrentState";
                let urlOppIDPrams = "OpportunityID";
                let urlAccountIDPrams = "Account_ID";
                let urlTaskparams = "UserTaskName";
                let urlTaskRoleparams = "taskOwnerRole";
                let urlRoleParams = "roleArea_Desc";
                let urlReqIDPrams = "RefrenceID";
                let urlReqTypePrams = "RequestType";
                let urlCreationDateParams = "DTCreation_tdate";
                let urlReqAreaParams = "RequestArea";
                let urlRequesterParams = `contains(EmpRequester_ID,`;
                let urlApproverParams = `contains(ReqApproverID,`;
                let urlResourceParams = `contains(ReqResourcesID,`;
                let urlCurrentProcessorParams = `contains(CurrentProcessorID,`;
                let urlReqSlnsParams = `Solution_Desc`;
                let urlIndParams = `BA_Industry_Desc`;
                let urlSalesOrgParams = "orgName";
                let sOrgType = 'SORG';
                let aFinalFilterParams = [];
                this._alreadyLoadedCount = 20;
                let sBasicSearchValue = oView.byId("filterbar").getBasicSearchValue();
                let convertDate = function convertDate(date) {
                    if (date) {
                        const yyyy = date.getFullYear();
                        const mm = String(date.getMonth() + 1).padStart(2, "0");
                        const dd = String(date.getDate()).padStart(2, "0");

                        return `${yyyy}-${mm}-${dd}`;
                    }
                };
                let reqCreateStartDate = convertDate(this.byId("dpCreateDate").getDateValue());
                let reqEndStartDate = convertDate(this.byId("dpEndDate").getDateValue());

                //start of Current State filter query
                if (aCurrentStateTokens.length) {
                    for (let i = 0; i < aCurrentStateTokens.length; i++) {
                        let sTokenText = aCurrentStateTokens[i].getText();
                        if (aCurrentStateTokens.length === 1) {
                            urlCurrentStateParams = `${urlCurrentStateParams} eq '${sTokenText}'`
                        } else {
                            if (i === 0) {
                                urlCurrentStateParams = `${urlCurrentStateParams} eq '${sTokenText}'`
                            }
                            if (i !== aCurrentStateTokens.length - 1 && i != 0) {
                                urlCurrentStateParams = `${urlCurrentStateParams} or CurrentState eq '${sTokenText}'`
                            } else if (i == aCurrentStateTokens.length - 1) {
                                urlCurrentStateParams = `${urlCurrentStateParams} or CurrentState eq '${sTokenText}'`
                            }
                        }
                    }
                    aFinalFilterParams.push(`(${urlCurrentStateParams})`);
                }
                //end of Current State filter query

                //start of Task filter query
                if (aCurrentTaskTokens.length) {
                    for (let i = 0; i < aCurrentTaskTokens.length; i++) {
                        let sTokenText = aCurrentTaskTokens[i].getText();
                        if (aCurrentTaskTokens.length === 1) {
                            urlTaskparams = `${urlTaskparams} eq '${sTokenText}'`
                        } else {
                            if (i === 0) {
                                urlTaskparams = `${urlTaskparams} eq '${sTokenText}'`
                            }
                            if (i !== aCurrentTaskTokens.length - 1 && i != 0) {
                                urlTaskparams = `${urlTaskparams} or UserTaskName eq '${sTokenText}'`
                            } else if (i == aCurrentTaskTokens.length - 1) {
                                urlTaskparams = `${urlTaskparams} or UserTaskName eq '${sTokenText}'`
                            }
                        }
                    }
                    aFinalFilterParams.push(`(${urlTaskparams})`);
                }
                //end of Task filter query

                //start of Task role filter query
                if (aCurrentTaskRoleTokens.length) {
                    for (let i = 0; i < aCurrentTaskRoleTokens.length; i++) {
                        let sTokenText = aCurrentTaskRoleTokens[i].getText();
                        if (aCurrentTaskRoleTokens.length === 1) {
                            urlTaskRoleparams = `${urlTaskRoleparams} eq '${sTokenText}'`
                        } else {
                            if (i === 0) {
                                urlTaskRoleparams = `${urlTaskRoleparams} eq '${sTokenText}'`
                            }
                            if (i !== aCurrentTaskRoleTokens.length - 1 && i != 0) {
                                urlTaskRoleparams = `${urlTaskRoleparams} or taskOwnerRole eq '${sTokenText}'`
                            } else if (i == aCurrentTaskRoleTokens.length - 1) {
                                urlTaskRoleparams = `${urlTaskRoleparams} or taskOwnerRole eq '${sTokenText}'`
                            }
                        }
                    }
                    aFinalFilterParams.push(`(${urlTaskRoleparams})`);
                }
                //end of Task role filter query

                //start of Request Type filter query
                if (aRequestTypeTokens.length) {
                    for (let i = 0; i < aRequestTypeTokens.length; i++) {
                        let sTokenText = aRequestTypeTokens[i].getText();
                        if (aRequestTypeTokens.length === 1) {
                            urlReqTypePrams = `${urlReqTypePrams} eq '${sTokenText}'`
                        } else {
                            if (i === 0) {
                                urlReqTypePrams = `${urlReqTypePrams} eq '${sTokenText}'`
                            }
                            if (i !== aRequestTypeTokens.length - 1 && i != 0) {
                                urlReqTypePrams = `${urlReqTypePrams} or RequestType eq '${sTokenText}'`
                            } else if (i == aRequestTypeTokens.length - 1) {
                                urlReqTypePrams = `${urlReqTypePrams} or RequestType eq '${sTokenText}'`
                            }
                        }
                    }
                    aFinalFilterParams.push(`(${urlReqTypePrams})`);
                }
                //end of Request Type filter query

                //start of Opportunity ID filter query
                if (aOpporTunityIDTokens.length) {
                    for (let i = 0; i < aOpporTunityIDTokens.length; i++) {
                        let sTokenText = aOpporTunityIDTokens[i].getText().substring(1).replaceAll(/\s/g, '');
                        if (aOpporTunityIDTokens.length === 1) {
                            urlOppIDPrams = `${urlOppIDPrams} eq '${sTokenText}'`
                        } else {
                            if (i === 0) {
                                urlOppIDPrams = `${urlOppIDPrams} eq '${sTokenText}'`
                            }
                            if (i !== aOpporTunityIDTokens.length - 1 && i != 0) {
                                urlOppIDPrams = `${urlOppIDPrams} or OpportunityID eq '${sTokenText}'`
                            } else if (i == aOpporTunityIDTokens.length - 1) {
                                urlOppIDPrams = `${urlOppIDPrams} or OpportunityID eq '${sTokenText}'`
                            }
                        }
                    }
                    aFinalFilterParams.push(`(${urlOppIDPrams})`)
                }
                //end of Opportunity ID filter query

                //start of Account ID filter query
                if (aAccountIDTokens.length) {
                    for (let i = 0; i < aAccountIDTokens.length; i++) {
                        let sTokenText = aAccountIDTokens[i].getKey().replaceAll(/\s/g, '');
                        if (aAccountIDTokens.length === 1) {
                            urlAccountIDPrams = `${urlAccountIDPrams} eq '${sTokenText}'`
                        } else {
                            if (i === 0) {
                                urlAccountIDPrams = `${urlAccountIDPrams} eq '${sTokenText}'`
                            }
                            if (i !== aAccountIDTokens.length - 1 && i != 0) {
                                urlAccountIDPrams = `${urlAccountIDPrams} or Account_ID eq '${sTokenText}'`
                            } else if (i == aAccountIDTokens.length - 1) {
                                urlAccountIDPrams = `${urlAccountIDPrams} or Account_ID eq '${sTokenText}'`
                            }
                        }
                    }
                    aFinalFilterParams.push(`(${urlAccountIDPrams})`)
                }
                //end of Account ID filter query

                //start of Request ID filter query
                if (aRequestIDTokens.length) {
                    for (let i = 0; i < aRequestIDTokens.length; i++) {
                        let sTokenText = aRequestIDTokens[i].getText().substring(1).replaceAll(/\s/g, '');
                        if (aRequestIDTokens.length === 1) {
                            urlReqIDPrams = `${urlReqIDPrams} eq ${sTokenText}`
                        } else {
                            if (i === 0) {
                                urlReqIDPrams = `${urlReqIDPrams} eq ${sTokenText}`
                            }
                            if (i !== aRequestIDTokens.length - 1 && i != 0) {
                                urlReqIDPrams = `${urlReqIDPrams} or RefrenceID eq ${sTokenText}`
                            } else if (i == aRequestIDTokens.length - 1) {
                                urlReqIDPrams = `${urlReqIDPrams} or RefrenceID eq ${sTokenText}`
                            }
                        }
                    }
                    aFinalFilterParams.push(`(${urlReqIDPrams})`)
                }
                //end of Request ID filter query

                //start of Creation Date filter query
                if (aCreationDateTokens.length) {
                    for (let i = 0; i < aCreationDateTokens.length; i++) {
                        let sTokenText = aCreationDateTokens[i].getText().substring(1);
                        let sFormattedDate = this._formatDate(sTokenText);
                        if (aCreationDateTokens.length === 1) {
                            urlCreationDateParams = `${urlCreationDateParams} eq ${sFormattedDate}`
                        } else {
                            if (i === 0) {
                                urlCreationDateParams = `${urlCreationDateParams} eq ${sFormattedDate}`
                            }
                            if (i !== aCreationDateTokens.length - 1 && i != 0) {
                                urlCreationDateParams = `${urlCreationDateParams} or DTCreation_tdate eq ${sFormattedDate}`
                            } else if (i == aCreationDateTokens.length - 1) {
                                urlCreationDateParams = `${urlCreationDateParams} or DTCreation_tdate eq ${sFormattedDate}`
                            }
                        }
                    }
                    aFinalFilterParams.push(`(${urlCreationDateParams})`)
                }
                //end of Creation Date filter query

                //start of Request Area Path filter query
                if (aRequestAreaPath.length) {
                    for (let i = 0; i < aRequestAreaPath.length; i++) {
                        let sTokenText = aRequestAreaPath[i].getText();
                        if (aRequestAreaPath.length === 1) {
                            urlReqAreaParams = `${urlReqAreaParams} eq '${sTokenText}'`
                        } else {
                            if (i === 0) {
                                urlReqAreaParams = `${urlReqAreaParams} eq '${sTokenText}'`
                            }
                            if (i !== aRequestAreaPath.length - 1 && i != 0) {
                                urlReqAreaParams = `${urlReqAreaParams} or RequestArea eq '${sTokenText}'`
                            } else if (i == aRequestAreaPath.length - 1) {
                                urlReqAreaParams = `${urlReqAreaParams} or RequestArea eq '${sTokenText}'`
                            }
                        }
                    }
                    urlReqAreaParams = urlReqAreaParams.replaceAll("&", "%26");
                    aFinalFilterParams.push(`(${urlReqAreaParams})`);
                }
                //end of Request Area Path filter query

                //start of Requester filter query
                if (aRequester.length) {
                    for (let i = 0; i < aRequester.length; i++) {
                        let sTokenText = aRequester[i].getKey().toUpperCase();
                        if (aRequester.length === 1) {
                            urlRequesterParams = `${urlRequesterParams}'${sTokenText}')`
                        } else {
                            if (i === 0) {
                                urlRequesterParams = `${urlRequesterParams}'${sTokenText}')`
                            }
                            if (i !== aRequester.length - 1 && i != 0) {
                                urlRequesterParams = `${urlRequesterParams} or contains(EmpRequester_ID,'${sTokenText}')`
                            } else if (i == aRequester.length - 1) {
                                urlRequesterParams = `${urlRequesterParams} or contains(EmpRequester_ID,'${sTokenText}')`
                            }
                        }
                    }
                    aFinalFilterParams.push(`(${urlRequesterParams})`);
                }
                //end of Requester filter query

                //start of Approver filter query
                if (aProcessor.length) {
                    for (let i = 0; i < aProcessor.length; i++) {
                        let sTokenText = aProcessor[i].getKey().toUpperCase();
                        if (aProcessor.length === 1) {
                            urlApproverParams = `${urlApproverParams}'${sTokenText}')`
                        } else {
                            if (i === 0) {
                                urlApproverParams = `${urlApproverParams}'${sTokenText}')`
                            }
                            if (i !== aProcessor.length - 1 && i != 0) {
                                urlApproverParams = `${urlApproverParams} or contains(ReqApproverID,'${sTokenText}')`
                            } else if (i == aProcessor.length - 1) {
                                urlApproverParams = `${urlApproverParams} or contains(ReqApproverID,'${sTokenText}')`
                            }
                        }
                    }
                    aFinalFilterParams.push(`(${urlApproverParams})`);
                }
                //end of Approver filter query

                //start of Resource filter query
                if (aResource.length) {
                    for (let i = 0; i < aResource.length; i++) {
                        let sTokenText = aResource[i].getKey().toUpperCase();
                        if (aResource.length === 1) {
                            urlResourceParams = `${urlResourceParams}'${sTokenText}')`
                        } else {
                            if (i === 0) {
                                urlResourceParams = `${urlResourceParams}'${sTokenText}')`
                            }
                            if (i !== aResource.length - 1 && i != 0) {
                                urlResourceParams = `${urlResourceParams} or contains(ReqResourcesID,'${sTokenText}')`
                            } else if (i == aResource.length - 1) {
                                urlResourceParams = `${urlResourceParams} or contains(ReqResourcesID,'${sTokenText}')`
                            }
                        }
                    }
                    aFinalFilterParams.push(`(${urlResourceParams})`);
                }
                //end of Resource filter query

                //start of Current Processor filter query
                if (aCurrentProcessor.length) {
                    for (let i = 0; i < aCurrentProcessor.length; i++) {
                        let sTokenText = aCurrentProcessor[i].getKey();
                        if (aCurrentProcessor.length === 1) {
                            urlCurrentProcessorParams = `${urlCurrentProcessorParams}'${sTokenText}')`
                        } else {
                            if (i === 0) {
                                urlCurrentProcessorParams = `${urlCurrentProcessorParams}'${sTokenText}')`
                            }
                            if (i !== aCurrentProcessor.length - 1 && i != 0) {
                                urlCurrentProcessorParams = `${urlCurrentProcessorParams} or contains(CurrentProcessorID,'${sTokenText}')`
                            } else if (i == aCurrentProcessor.length - 1) {
                                urlCurrentProcessorParams = `${urlCurrentProcessorParams} or contains(CurrentProcessorID,'${sTokenText}')`
                            }
                        }
                    }
                    aFinalFilterParams.push(`(${urlCurrentProcessorParams})`);
                }
                //end of Current Processor filter query

                //start of Sales Org filter query
                if (aSalesOrg.length) {
                    for (let i = 0; i < aSalesOrg.length; i++) {
                        let sTokenText = aSalesOrg[i].getText();
                        if (aSalesOrg.length === 1) {
                            urlSalesOrgParams = `(${urlSalesOrgParams} eq '${sTokenText}' and OrgType eq '${sOrgType}')`
                        } else {
                            if (i === 0) {
                                urlSalesOrgParams = `(${urlSalesOrgParams} eq '${sTokenText}' and OrgType eq '${sOrgType}')`
                            }
                            if (i !== aSalesOrg.length - 1 && i != 0) {
                                urlSalesOrgParams = `${urlSalesOrgParams} or (orgName eq '${sTokenText}' and OrgType eq '${sOrgType}')`
                            } else if (i == aSalesOrg.length - 1) {
                                urlSalesOrgParams = `${urlSalesOrgParams} or (orgName eq '${sTokenText}' and OrgType eq '${sOrgType}')`
                            }
                        }
                    }
                    aFinalFilterParams.push(`(${urlSalesOrgParams})`);
                }
                //end of Sales Org filter query
                //start of  role filter query
                if (aRoleTokens.length) {
                    for (let i = 0; i < aRoleTokens.length; i++) {
                        let sTokenText = aRoleTokens[i].getText();
                        if (aRoleTokens.length === 1) {
                            urlRoleParams = `${urlRoleParams} eq '${sTokenText}'`
                        } else {
                            if (i === 0) {
                                urlRoleParams = `${urlRoleParams} eq '${sTokenText}'`
                            }
                            if (i !== aRoleTokens.length - 1 && i != 0) {
                                urlRoleParams = `${urlRoleParams} or taskOwnerRole eq '${sTokenText}'`
                            } else if (i == aRoleTokens.length - 1) {
                                urlRoleParams = `${urlRoleParams} or taskOwnerRole eq '${sTokenText}'`
                            }
                        }
                    }
                    aFinalFilterParams.push(`(${urlRoleParams})`);
                }
                //end of  role filter query


                //start of Solution filter query
                if (aReqSlns.length) {
                    for (let i = 0; i < aReqSlns.length; i++) {
                        let sTokenText = aReqSlns[i].getBindingContext("employee").getObject().soln_name
                        if (aReqSlns.length === 1) {
                            urlReqSlnsParams = `${urlReqSlnsParams} eq '${sTokenText}'`
                        } else {
                            if (i === 0) {
                                urlReqSlnsParams = `${urlReqSlnsParams} eq '${sTokenText}'`
                            }
                            if (i !== aReqSlns.length - 1 && i != 0) {
                                urlReqSlnsParams = `${urlReqSlnsParams} or Solution_Desc eq '${sTokenText}'`
                            } else if (i == aReqSlns.length - 1) {
                                urlReqSlnsParams = `${urlReqSlnsParams} or Solution_Desc eq '${sTokenText}'`
                            }
                        }
                    }
                    aFinalFilterParams.push(`(${urlReqSlnsParams})`);
                }
                //end of Solution filter query

                //  //start of industry filter query
                if (aReqInd.length) {
                    for (let i = 0; i < aReqInd.length; i++) {
                        let sTokenText = aReqInd[i].getBindingContext("employee").getObject().Desc;
                        if (aReqInd.length === 1) {
                            urlIndParams = `${urlIndParams} eq '${sTokenText}'`
                        } else {
                            if (i === 0) {
                                urlIndParams = `${urlIndParams} eq '${sTokenText}'`
                            }
                            if (i !== aReqInd.length - 1 && i != 0) {
                                urlIndParams = `${urlIndParams} or BA_Industry_Desc eq '${sTokenText}'`
                            } else if (i == aReqInd.length - 1) {
                                urlIndParams = `${urlIndParams} or BA_Industry_Desc eq '${sTokenText}'`
                            }
                        }
                    }
                    aFinalFilterParams.push(`(${urlIndParams})`);
                }
                // //end of industry filter query
                //creation date
                if (reqCreateStartDate && reqEndStartDate) {
                    aFinalFilterParams.push(`(DTCreation_tdate ge ${reqCreateStartDate} and DTCreation_tdate le ${reqEndStartDate})`);
                } else if (reqCreateStartDate || reqEndStartDate) {
                    let sDateVal = reqCreateStartDate ? reqCreateStartDate : reqEndStartDate;
                    aFinalFilterParams.push(`(DTCreation_tdate eq ${sDateVal})`);

                }


                //start of filter query
                let sFinalFilterUrl;
                if (aFinalFilterParams.length) {
                    for (let j = 0; j < aFinalFilterParams.length; j++) {
                        let sFilterUrl = aFinalFilterParams[j];
                        if (aFinalFilterParams.length === 1) {
                            sFinalFilterUrl = sFilterUrl;
                        } else {
                            if (j === 0) {
                                sFinalFilterUrl = sFilterUrl;
                            } else {
                                sFinalFilterUrl = `${sFinalFilterUrl} and ${sFilterUrl}`
                            }

                        }
                    }
                } else {
                    sFinalFilterUrl = "";
                }


                this.sSortQqueryPrams = `&$orderby=DTCreation_tdate desc,DTCreation_ttime desc`;
                let sLoggedInUserId = this.getOwnerComponent().getModel("userDetails").getProperty("/user_name").toUpperCase();
                const dirRep = this.getOwnerComponent().getModel("userDetails").getProperty("/DirectReportees");
                this.isDirReportees = true;
                if (this.getView().byId("idMyInboxIconTabHeader").getSelectedKey() === "myReqTab") {
                    if(dirRep.length){
                        this.isDirReportees = true;
                        const filterParts = dirRep.map(resourceId =>
                            `contains(EmpRequester_ID,'${resourceId}') or contains(CurrentProcessorID,'${resourceId}') or contains(ReqApproverID,'${resourceId}') or contains(ReqIOApproverID,'${resourceId}') or contains(ReqResourcesID,'${resourceId}')`
                        );

                        const combinedFilter = filterParts.join(" or ");
                        this.sQueryParams = sFinalFilterUrl ? `/wf/V_WfInstance_Ext?$count=true&$filter=(${combinedFilter}) and ${sFinalFilterUrl}` : `/wf/V_WfInstance_Ext?$count=true&$filter=(${combinedFilter})`;
                }else{
                        this.isDirReportees = false;
                    }
                } else {
                    this.sQueryParams = sFinalFilterUrl ? `/wf/V_WfInstance_Ext?$count=true&$filter=(contains(EmpRequester_ID,'${sLoggedInUserId}') or contains(CurrentProcessorID,'${sLoggedInUserId}') or contains(ReqApproverID,'${sLoggedInUserId}') or contains(ReqIOApproverID,'${sLoggedInUserId}') or contains(ReqResourcesID,'${sLoggedInUserId}')) and ${sFinalFilterUrl}` : `/wf/V_WfInstance_Ext?$count=true&$filter=(contains(EmpRequester_ID,'${sLoggedInUserId}') or contains(CurrentProcessorID,'${sLoggedInUserId}') or contains(ReqApproverID,'${sLoggedInUserId}') or contains(ReqIOApproverID,'${sLoggedInUserId}') or contains(ReqResourcesID,'${sLoggedInUserId}'))`;
                }
                // this.sQueryParams = sFinalFilterUrl ? `/wf/V_WfInstance_Ext?$count=true&$filter=${sFinalFilterUrl}` : `/wf/V_WfInstance_Ext?$count=true`;
                if(!aCurrentStateTokens.length){
                    var sCurrStateFilterQuery = this.getCurrentStateFilterQuery();
                    this.sQueryParams = `${this.sQueryParams} and (${sCurrStateFilterQuery})`;
                }else{
                    this.sQueryParams = `${this.sQueryParams}`;
                }

                if (sBasicSearchValue) {
                    this.sQueryParams = `${this.sQueryParams}&$search=${sBasicSearchValue}`;
                }

                this.sFinalQueryParams = `${this.sQueryParams}${this.sSortQqueryPrams}&$skip=0&$top=20`;

                //end of final filter query
                //backend filter GET call
            
                models.getWfInstanceFilterLists(this.fnSuccessFilterCallback, this.fnErrorFilterCallback, this, this.sFinalQueryParams);
            },
            fnSuccessFilterCallback: function (oResult, self) {

                var oModel = new sap.ui.model.json.JSONModel();
                oResult.count = oResult["@odata.count"];
                oModel.setData(oResult);
                oModel.setData(oResult);
                self.getOwnerComponent().setModel(oModel, "wfHistoryModel");
                sap.ui.core.BusyIndicator.hide();
                if (self._oSortDialog) {
                    self._oSortDialog.setSortDescending(true);
                    self._oSortDialog.setSelectedSortItem(
                        self._oSortDialog.getSortItems()[0].sId);
                }
              //  self.getView().setBusy(false);
                    // setTimeout(function(){
                    //      self.getView().setBusy(false);
                        
                    // },1000, self);
                 self.getView().setBusy(false);
                self.getView().byId("id-table-wfHistory").setBusy(false);
                sap.ui.core.BusyIndicator.hide();
            },
            fnErrorFilterCallback: function (oError, self) {
                MessageBox.error(oError.responseText, {
                    contentWidth: "600px"
                });
                sap.ui.core.BusyIndicator.hide();
            },
            //valueHelp dialog for Account ID
            onAccountIDValueHelpRequested: function () {
                if (!this.pAccIDValueDialog) {
                    this.pAccIDValueDialog = this.loadFragment({
                        name: "com.dealsupport.melodyrequest.fragments.AccIDValueHelpDialogFilterbar"
                    });
                }
                this.pAccIDValueDialog.then(function (oAccIDValueDialog) {
                    oAccIDValueDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
                    if (this._bAccIDValueInitialized) {
                        oAccIDValueDialog.open();
                        return;
                    }
                    this._oAccIDValueDialog = oAccIDValueDialog;
                    this.getView().addDependent(oAccIDValueDialog);
                    oAccIDValueDialog.setRangeKeyFields([{
                        label: "Account Name - ID",
                        key: "accountID",
                        type: "string",
                        typeInstance: new TypeString({}, {

                        })
                    }]);
                    oAccIDValueDialog.setIncludeRangeOperations(["EQ"], "string");
                    oAccIDValueDialog.setMaxExcludeRanges(0);

                    oAccIDValueDialog.setTokens(this.byId("id-filter-accountname").getTokens());
                    this._bAccIDValueInitialized = true;
                    oAccIDValueDialog.open();
                }.bind(this));
            },
            onAccIDValueHelpOkPress: function (oEvent) {
                var aTokens = oEvent.getParameter("tokens");
                aTokens.forEach(function(accToken){
                    accToken.getText().replaceAll(/\s/g,'') 
                });

                this.byId("id-filter-accountname").setTokens(aTokens);
                this._oAccIDValueDialog.close();
            },
            onAccIDValueHelpCancelPress: function () {
                this._oAccIDValueDialog.close();
            },
            onOppIDValueHelpRequested: function () {
                this.loadFragment({
                    name: "com.dealsupport.melodyrequest.fragments.OppIDValueHelpDialogFilterbar"
                }).then(function (oOppIDValueDialog) {
                    const sOppIdLabel = this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/OpportunityID/0/fieldDesc");
                    this._oOppIDValueDialog = oOppIDValueDialog;
                    this.getView().addDependent(oOppIDValueDialog);
                    oOppIDValueDialog.setRangeKeyFields([{
                        label: sOppIdLabel,
                        key: "key",
                        type: "string",
                        typeInstance: new TypeString({}, {
                        })
                    }]);
                    oOppIDValueDialog.setIncludeRangeOperations(["EQ"], "string");
                    oOppIDValueDialog.setMaxExcludeRanges(0);
                    oOppIDValueDialog.setTokens(this.byId("id-filter-opportunityID").getTokens());
                    oOppIDValueDialog.open();
                }.bind(this));
            },
            onOppIDValueHelpOkPress: function (oEvent) {
                var aTokens = oEvent.getParameter("tokens");
                aTokens.forEach(function (oppToken) {
                    oppToken.getText().replaceAll(/\s/g, '')
                });
                this.byId("id-filter-opportunityID").setTokens(aTokens);
                this._oOppIDValueDialog.close();
            },
            onOppIDConditionsAfterClose: function () {
                this._oOppIDValueDialog.destroy();
            },
            onOppIDValueHelpCancelPress: function () {
                this._oOppIDValueDialog.close();
            },
            //valueHelp dialog for Request ID
            onReqIDValueHelpRequested: function () {
               this.loadFragment({
                    name: "com.dealsupport.melodyrequest.fragments.ReqIDValueHelpDialogFilterbar"
                }).then(function (oReqIDValueDialog) {
                    const sReqIdLabel = this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/ReqID/0/fieldDesc");
                    this._oReqIDValueDialog = oReqIDValueDialog;
                    this.getView().addDependent(oReqIDValueDialog);
                    oReqIDValueDialog.setRangeKeyFields([{
                        label: sReqIdLabel,
                        key: "key",
                        type: "string",
                        typeInstance: new TypeString({}, {
                        })
                    }]);
                    oReqIDValueDialog.setIncludeRangeOperations(["EQ"], "string");
                    oReqIDValueDialog.setMaxExcludeRanges(0);
                    oReqIDValueDialog.setTokens( this.byId("id-filter-reqID").getTokens());
                    oReqIDValueDialog.open();
                }.bind(this));
            },
            onReqIDValueHelpOkPress: function (oEvent) {
                let aTokens = oEvent.getParameter("tokens");
                 aTokens.forEach(function (oppToken) {
                    oppToken.getText().replaceAll(/\s/g, '')
                });
			    this.byId("id-filter-reqID").setTokens(aTokens);
                this._oReqIDValueDialog.close();
            },
            onReqIDConditionsAfterClose: function () {
                this._oReqIDValueDialog.destroy();
            },
            onReqIDValueHelpCancelPress: function () {
                this._oReqIDValueDialog.close();
            },
            //valueHelp dialog for Creation Date
            onCDValueHelpRequested: function () {
                if (!this.pCDValueDialog) {
                    this.pCDValueDialog = this.loadFragment({
                        name: "com.dealsupport.melodyrequest.fragments.CDValueHelpDialogFilterbar"
                    });
                }
                this.pCDValueDialog.then(function (oCDValueDialog) {
                    oCDValueDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
                    if (this._bCDValueInitialized) {
                        oCDValueDialog.open();
                        return;
                    }
                    this._oCDValueDialog = oCDValueDialog;
                    this.getView().addDependent(oCDValueDialog);
                    oCDValueDialog.setRangeKeyFields([{
                        label: "Creation Date",
                        key: "creationDate",
                        type: "date",
                        typeInstance: new TypeDate({}, {

                        })
                    }]);
                    oCDValueDialog.setIncludeRangeOperations(["EQ"], "date");
                    oCDValueDialog.setMaxExcludeRanges(0);

                    oCDValueDialog.setTokens(this.byId("id-filter-creationDate").getTokens());
                    this._bCDValueInitialized = true;
                    oCDValueDialog.open();
                }.bind(this));
            },
            onCreationDateValueHelpOkPress: function (oEvent) {
                var aTokens = oEvent.getParameter("tokens");
                const oVariantModel = this.getView().getModel("variant");
                let aCreateDteKeyValue = aTokens.map(item => {
                    // Create a new object to avoid mutating the original
                    return {
                        key: item.getKey(),
                        value: item.getText()
                    };
                });
                this.getView().getModel("variant").setProperty("/reqDate", aCreateDteKeyValue);
                this.getView().getModel("variant").refresh();
                // this.byId("id-filter-creationDate").setTokens(aTokens);
                this._oCDValueDialog.close();
            },
            onCreationDateValueHelpCancelPress: function () {
                this._oCDValueDialog.close();
            },
            _formatDate: function (date) {
                var d = new Date(date),
                    month = '' + (d.getMonth() + 1),
                    day = '' + d.getDate(),
                    year = d.getFullYear();

                if (month.length < 2)
                    month = '0' + month;
                if (day.length < 2)
                    day = '0' + day;

                return [year, month, day].join('-');
            },
            //user dialog
            onUserValueHelpRequested: function (oEvent) {
                const oAppConfigModel = this.getOwnerComponent().getModel("mrrAppConfigModel");
               
                const requester = oAppConfigModel.getProperty("/ReqNameID/0/fieldDesc");
                const requestStatusTaskOwner = oAppConfigModel.getProperty("/TaskOwnerName/0/fieldDesc");
                const sProcessr = oAppConfigModel.getProperty("/ProcessorNameID/0/fieldDesc");
                const sResource = oAppConfigModel.getProperty("/ResourceNameID/0/fieldDesc");
                this.oMultiInputID = oEvent.getParameter("id");
                const oMultiInput = this.getView().byId(this.oMultiInputID);
                let isUserID;
                // if (this.oMultiInputID.includes("id-filter-requester") ) {
                isUserID = true;
                // }
                let sLabel;
                const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
                switch (true) {
                    case this.oMultiInputID.includes("id-filter-requester"):
                        sLabel = requester;
                        break;
                    case this.oMultiInputID.includes("id-filter-currentProcessor"):
                        sLabel = requestStatusTaskOwner;
                        break;
                    case this.oMultiInputID.includes("id-filter-resource"):
                        sLabel = sResource;
                        break;
                    case this.oMultiInputID.includes("id-filter-processor"):
                        sLabel = sProcessr;
                        break;
                    default:
                        sLabel = i18nModel.getText("users");
                        break;
                }
                Common._onUserValueHelpRequested(this, oMultiInput, isUserID, sLabel);
            },
            onFilterBarUserSearch: function () {
                Common._onFilterBarUserSearch(this)
            },
            _onAddSelectedUser: function (evt, that) {
                Common.__onAddSelectedUser(evt, that)
            },
            onValueHelpUserCancelPress: function () {
                UserCommon._onValueHelpUserCancelPress(this);
            },
            onUserSearchValueChange: function (oEvent) {
                UserCommon._onUserSearchValueChange(oEvent, this._ovalueHelpUserFragment);
            },
            onValueHelpUserAfterClose: function () {
                UserCommon._onValueHelpUserAfterClose(this);
            },
            onValueHelpUserOkPress: function (oEvent) {
                var oMultiInput = this.getView().byId(this.oMultiInputID);
                Common._onValueHelpUserOkPress(oEvent, oMultiInput, this)
            },

            //valueHelp dialog for Request Area
            onRequestAreaValueHelpRequested: function (oEvent) {
                this.sIdMultiInputReqArea = oEvent.getParameter("id");
                Common._onRequestAreaValueHelpRequested(oEvent, this);
            },
            handleReqAreaValueHelpSearch: function (evt) {
                Common._handleReqAreaValueHelpSearch(evt);
            },
            handleReqAreaValueHelpClose: function (evt) {
                var oMultiInputReqArea = this.getView().byId(this.sIdMultiInputReqArea);
                Common._handleReqAreaValueHelpClose(evt, oMultiInputReqArea);
            },
            //valueHelp dialog for Requester
            onRequesterValueHelpRequested: function () {
                if (!this.pRequesterValueDialog) {
                    this.pRequesterValueDialog = this.loadFragment({
                        name: "com.dealsupport.melodyrequest.fragments.RequesterValueHelpDialogFilterbar"
                    });
                }
                this.pRequesterValueDialog.then(function (oRequesterValueDialog) {
                    oRequesterValueDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
                    if (this._bRequesterValueInitialized) {
                        oRequesterValueDialog.open();
                        return;
                    }
                    this._oRequesterValueDialog = oRequesterValueDialog;
                    this.getView().addDependent(oRequesterValueDialog);
                    oRequesterValueDialog.setRangeKeyFields([{
                        label: "Requestor",
                        key: "requester",
                        type: "string",
                        typeInstance: new TypeString({}, {

                        })
                    }]);
                    oRequesterValueDialog.setIncludeRangeOperations(["EQ"], "string");

                    oRequesterValueDialog.setTokens(this.byId("id-filter-requester").getTokens());
                    this._bRequesterValueInitialized = true;
                    oRequesterValueDialog.open();
                }.bind(this));
            },
            onRequesterValueHelpOkPress: function (oEvent) {
                var aTokens = oEvent.getParameter("tokens");
                const oVariantModel = this.getView().getModel("variant");
                let aCreateDteKeyValue = aTokens.map(item => {
                    // Create a new object to avoid mutating the original
                    return {
                        key: item.getKey(),
                        value: item.getText()
                    };
                });
                this.getView().getModel("variant").setProperty("/ReqNameID", aCreateDteKeyValue);
                this.getView().getModel("variant").refresh();
                //this.byId("id-filter-requester").setTokens(aTokens);
                this._oRequesterValueDialog.close();
            },
            onRequesterValueHelpCancelPress: function () {
                this._oRequesterValueDialog.close();
            },
            //valueHelp dialog for Sales Org
            onSalesOrgValueHelpRequested: function () {
                if (!this.pSalesOrgValueDialog) {
                    this.pSalesOrgValueDialog = this.loadFragment({
                        name: "com.dealsupport.melodyrequest.fragments.SalesOrgValueHelpDialogFilterbar"
                    });
                }
                this.pSalesOrgValueDialog.then(function (oSalesOrgValueDialog) {
                    oSalesOrgValueDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
                    if (this._bSalesOrgValueInitialized) {
                        oSalesOrgValueDialog.open();
                        return;
                    }
                    this._oSalesOrgValueDialog = oSalesOrgValueDialog;
                    this.getView().addDependent(oSalesOrgValueDialog);
                    oSalesOrgValueDialog.setRangeKeyFields([{
                        label: "Sales Org",
                        key: "salesOrg",
                        type: "string",
                        typeInstance: new TypeString({}, {

                        })
                    }]);
                    oSalesOrgValueDialog.setIncludeRangeOperations(["EQ"], "string");

                    oSalesOrgValueDialog.setTokens(this.byId("id-filter-salesOrg").getTokens());
                    this._bSalesOrgValueInitialized = true;
                    oSalesOrgValueDialog.open();
                }.bind(this));
            },
            onSalesOrgValueHelpOkPress: function (oEvent) {
                var aTokens = oEvent.getParameter("tokens");
                this.byId("id-filter-salesOrg").setTokens(aTokens);
                this._oSalesOrgValueDialog.close();
            },
            onSalesOrgValueHelpCancelPress: function () {
                this._oSalesOrgValueDialog.close();
            },
            _APICallForExportToExcelMoreData: function (sLoadedExportDataCount) {
                //To load more Features
                var iSkip = parseInt(sLoadedExportDataCount, [10]);
                var iTop = 1000;
                var that = this;
                 this.getView().byId("id-table-wfHistory").setBusy(true);
                var workflowBaseurl = models._getWfServiceRuntimeBaseURLRoleBased(this);
                if (!this.sSortQqueryPrams) {
                    this.sSortQqueryPrams = `&$orderby=DTCreation_tdate desc,DTCreation_ttime desc`;
                }
                this.sFinalQueryParams = `${this.sQueryParams}${this.sSortQqueryPrams}`;
                this.getView().setBusy(true);
                jQuery.ajax({
                    async: true,
                    contentType: "application/json",
                    url: `${workflowBaseurl}${this.sFinalQueryParams}&$skip=${iSkip}&$top=${iTop}&$expand=_Solution`,
                    type: "GET",
                    success: function (oData) {
                        models.removeIODuplicacy(oData);
                        that.oExportedData = oData.value.length + iSkip;
                        oData.count = oData["@odata.count"];
                        if (!that.exportedDataLists) {
                            that.exportedDataLists = oData.value;
                        } else {
                            that.exportedDataLists = that.exportedDataLists.concat(oData.value);
                        }
                        if (that.exportedDataLists.length < oData.count) {
                            that._triggerExportToExcelAPI();
                        } else {
                            that._onFinalExportToExcel(that);
                        }
                        that.getView().setBusy(false);
                        that.getView().byId("id-table-wfHistory").setBusy(false);
                    }.bind(this),
                    error: function (oError) {
                        that._closeBusyIndicator(that);
                        MessageBox.error(oError.responseText, {
                            contentWidth: "600px"
                        });
                        that.getView().setBusy(false);
                        that.getView().byId("id-table-wfHistory").setBusy(false);
                        sap.ui.core.BusyIndicator.hide();
                        return false;
                    }
                });
            },
            _onFinalExportToExcel: function (that) {
                var aCols, oSettings, oSheet;
                aCols = that._createColumnConfig();
                const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
                let sMyReqExcel;
                var oDate = new Date();
                var sYear = oDate.getFullYear();
                var sMonth = (oDate.getMonth() + 1).toString().padStart(2, '0');
                var sDay = oDate.getDate().toString().padStart(2, '0');
                var sCurrentDate = sYear + sMonth + sDay;

                if (that.getView().byId("idMyInboxIconTabHeader").getSelectedKey() === "myReqTab") {
                    sMyReqExcel = i18nModel.getText("myTeamRequestExcel")  + sCurrentDate;
                } else {
                    sMyReqExcel = i18nModel.getText("myRequestExcel")  + sCurrentDate;
                }
                oSettings = {
                    workbook: {
                        columns: aCols,
                        hierarchyLevel: "Level"
                    },
                    dataSource: that.exportedDataLists,
                    fileName: sMyReqExcel,
                    worker: false // We need to disable worker because we are using a MockServer 
                };

                oSheet = new Spreadsheet(oSettings);
                oSheet.build().finally(function () {
                    oSheet.destroy();
                });
            },
            _triggerExportToExcelAPI: function () {
                var oModelData = this.getOwnerComponent().getModel("wfHistoryModel").getData();
                var iTotalexportDataLength = oModelData.count;
                if (iTotalexportDataLength !== null && iTotalexportDataLength !== undefined && iTotalexportDataLength) {
                    //Setting the value for iBindingLength = oBinding.getLength() which is the total count of items.
                    if (this.oExportedData <
                        iTotalexportDataLength) {
                        this._APICallForExportToExcelMoreData(this.oExportedData);
                    }
                }
            },
            onExport: function () {
                //Export to Excel
                this.oExportedData = 0;
                this.exportedDataLists = [];
                this._triggerExportToExcelAPI();
            },
            _createColumnConfig: function () {
                var aCols = [];
                for(var i=0 ; i< this.exportedDataLists.length ; i++){
                    const creationTime = this.exportedDataLists[i].DTCreation_ttime;
                    const creationDate = this.exportedDataLists[i].DTCreation_tdate;
                    const lastActTime = this.exportedDataLists[i].DTLastActivity_ttime;
                    const lastActDate = this.exportedDataLists[i].DTLastActivity_tdate;
                    const currentStateID = this.exportedDataLists[i].currentStateID;
                    const substituteProcessorID = this.exportedDataLists[i].substituteProcessorID;
                    const sSolution = this.exportedDataLists[i]._Solution;
                    this.exportedDataLists[i].DTCreation_ttime = formatter.formatWfCreationTime(creationTime, creationDate);
                    this.exportedDataLists[i].DTCreation_tdate = formatter.formatDateExcel(creationDate, creationTime);
                    this.exportedDataLists[i].DTLastActivity_ttime = formatter.formatWfCreationTime(lastActTime, lastActDate);
                    this.exportedDataLists[i].DTLastActivity_tdate = formatter.formatDateExcel(lastActDate, lastActTime);
                    this.exportedDataLists[i].CurrentState = formatter.currentReqMasterStatusRename(currentStateID, substituteProcessorID, false, this);
                    this.exportedDataLists[i].MainSolution = formatter.formatMainSln(sSolution);
                    this.exportedDataLists[i].ReqProcessor = formatter.formatProcessorList(this.exportedDataLists[i].CurrentProcessor, this.exportedDataLists[i].ReqApproverName, this.exportedDataLists[i].CurrentStepID);
                    this.exportedDataLists[i].ReqResource = formatter.formatProcessorList( this.exportedDataLists[i].ReqResourcesID,this.exportedDataLists[i].ResourceNames, this.exportedDataLists[i].CurrentStepID, this.exportedDataLists[i].currentStateID);
                }
                const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
                const oAppConfigModel = this.getOwnerComponent().getModel("mrrAppConfigModel");
                const sCurrentStep = oAppConfigModel.getProperty("/ReqStatus/0/fieldDesc");
                const sReqID = oAppConfigModel.getProperty("/RequestID/0/fieldDesc");
                const oppIdD = oAppConfigModel.getProperty("/OpportunityID/0/fieldDesc");
                const salesOrgpc = oAppConfigModel.getProperty("/ReqProfitCentre/0/fieldDesc");
                const stask = oAppConfigModel.getProperty("/Task/0/fieldDesc");
                const creationDate = oAppConfigModel.getProperty("/ReqCreateDate/0/fieldDesc");
                const reqAreaPath = oAppConfigModel.getProperty("/RequestAreaPath/0/fieldDesc");
                const requester = oAppConfigModel.getProperty("/Requestor/0/fieldDesc");
                const requestStatusTaskOwner = oAppConfigModel.getProperty("/TaskOwnerName/0/fieldDesc");
                const accountName = oAppConfigModel.getProperty("/AcctName/0/fieldDesc");
                const currency = oAppConfigModel.getProperty("/Currency/0/fieldDesc");
                const currentStepName =  oAppConfigModel.getProperty("/ReqStatusTaskOwnerRole/0/fieldDesc");
                const dealScore = oAppConfigModel.getProperty("/DealScore/0/fieldDesc");
                const decision = oAppConfigModel.getProperty("/TaskActionTaken/0/fieldDesc");
                const requestType = oAppConfigModel.getProperty("/ReqType/0/fieldDesc");
                const instanceId = oAppConfigModel.getProperty("/InstanceID/0/fieldDesc");
                const accountID = oAppConfigModel.getProperty("/AcctID/0/fieldDesc");
                const revenuePremise = oAppConfigModel.getProperty("/RevenuePremise/0/fieldDesc");
                const revenueCloud = oAppConfigModel.getProperty("/RevenueCloud/0/fieldDesc");
                const reqId = oAppConfigModel.getProperty("/RequestorID/0/fieldDesc");
                const creationTime = oAppConfigModel.getProperty("/ReqCreateTime/0/fieldDesc");
                const reqMail = oAppConfigModel.getProperty("/ReqEMail/0/fieldDesc");
                const requeststatustState = oAppConfigModel.getProperty("/RequestStatusState/0/fieldDesc");
                const lastActivityDate = oAppConfigModel.getProperty("/ReqLastActionDate/0/fieldDesc");
                const lastActivityTime = oAppConfigModel.getProperty("/ReqLastActionTime/0/fieldDesc");
                const sReqSubId = oAppConfigModel.getProperty("/ReqID/0/fieldDesc");
                const sReqRole = oAppConfigModel.getProperty("/ReqRole/0/fieldDesc");
                const sReqSolution = oAppConfigModel.getProperty("/ReqSolution/0/fieldDesc");
                const sReqIndustry = oAppConfigModel.getProperty("/ReqIndustry/0/fieldDesc");
                const sProcessr = oAppConfigModel.getProperty("/ProcessorNameID/0/fieldDesc");
                const sResource = oAppConfigModel.getProperty("/ResourceNameID/0/fieldDesc");
                const sEngagementType = oAppConfigModel.getProperty("/ReqEngagementType/0/fieldDesc");
                const sReqIdMain = oAppConfigModel.getProperty("/RequestIDMain/0/fieldDesc");
                const sReqRoleArea = oAppConfigModel.getProperty("/ReqRoleArea/0/fieldDesc");
                const sReqStatusMain = oAppConfigModel.getProperty("/ReqStatusMain/0/fieldDesc");

                aCols.push({
                    label: creationDate,
                    property: "DTCreation_tdate",
                    type: EdmType.String
                });
                aCols.push({
                    label: sReqSubId,
                    property: "RefrenceID",
                    type: EdmType.String
                });
                aCols.push({
                    label: requestType,
                    property: "RequestType",
                    type: EdmType.String
                });
                aCols.push({
                    label: oppIdD,
                    property: "OpportunityID",
                    type: EdmType.String

                });
                aCols.push({
                    label: sCurrentStep,
                    property: "CurrentState",
                    type: EdmType.String
                });
                aCols.push({
                    label: sReqRole,
                    property: "roleArea_Desc",
                    type: EdmType.String
                });
                aCols.push({
                    label: sReqSolution,
                    property: "MainSolution",
                    type: EdmType.String
                });
                aCols.push({
                    label: sReqIndustry,
                    property: "BA_Industry_Desc",
                    type: EdmType.String
                });
                aCols.push({
                    label: requester,
                    property: "EmpRequester_Name",
                    type: EdmType.String
                });
                aCols.push({
                    label: reqId,
                    property: "EmpRequester_ID",
                    type: EdmType.String
                });
                aCols.push({
                    label: sProcessr,
                    property: "ReqProcessor",
                    type: EdmType.String
                });
                aCols.push({
                    label: sResource,
                    property: "ReqResource",
                    type: EdmType.String
                });
                aCols.push({
                    label: accountID,
                    property: "Account_ID",
                    type: EdmType.String
                });
                aCols.push({
                    label: accountName,
                    property: "Account_name",
                    type: EdmType.String
                });
                aCols.push({
                    label: creationTime,
                    property: "DTCreation_ttime",
                    type: EdmType.String
                });
                aCols.push({
                    label: sEngagementType,
                    property: "EngagementType",
                    type: EdmType.String
                });
                aCols.push({
                    label: sReqIdMain,
                    property: "Parent_RefrenceID",
                    type: EdmType.String
                });
                aCols.push({
                    label: lastActivityDate,
                    property: "DTLastActivity_tdate",
                    type: EdmType.String
                });
                aCols.push({
                    label: lastActivityTime,
                    property: "DTLastActivity_ttime",
                    type: EdmType.String
                });
                aCols.push({
                    label: salesOrgpc,
                    property: "orgName",
                    type: EdmType.String
                });
                aCols.push({
                    label: sReqRoleArea,
                    property: "Role_Desc",
                    type: EdmType.String
                });
                aCols.push({
                    label: sReqStatusMain,
                    property: "OverallMainReqStatus",
                    type: EdmType.String
                });
                aCols.push({
                    label: stask,
                    property: "UserTaskName",
                    type: EdmType.String
                });
                aCols.push({
                    label: decision,
                    property: "Decision_Desc",
                    type: EdmType.String
                });
                aCols.push({
                    label: requestStatusTaskOwner,
                    property: "CurrentProcessor",
                    type: EdmType.String
                });
                aCols.push({
                    label: currentStepName,
                    property: "taskOwnerRole",
                    type: EdmType.String
                });
                // aCols.push({
                //     label: reqAreaPath,
                //     property: "RequestArea",
                //     type: EdmType.String
                // });


                // aCols.push({
                //     label: currency,
                //     property: "Currency",
                //     type: EdmType.String
                // });

                // aCols.push({
                //     label: dealScore,
                //     property: "DealScore",
                //     type: EdmType.String
                // });
                // aCols.push({
                //     label: instanceId,
                //     property: "InstanceID",
                //     type: EdmType.String
                // });

                // aCols.push({
                //     label: revenuePremise,
                //     property: "RevenuePremise",
                //     type: EdmType.String
                // });
                // aCols.push({
                //     label: revenueCloud,
                //     property: "RevenueCloud",
                //     type: EdmType.String
                // });

                // aCols.push({
                //     label: reqMail,
                //     property: "EmpRequester_EMail",
                //     type: EdmType.String
                // });
                // aCols.push({
                //     label: requeststatustState,
                //     property: "TechnicalState",
                //     type: EdmType.String
                // });
                return aCols;
            },
            handleSortButtonPressed: function () {
                if (!this.pSortDialog) {
                    this.pSortDialog = this.loadFragment({
                        name: "com.dealsupport.melodyrequest.fragments.SortDialog"
                    });
                }
                this.pSortDialog.then(function (oSortDialog) {
                    oSortDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
                    this._oSortDialog = oSortDialog;
                    oSortDialog.open();
                }.bind(this));
            },
            _onResetAllFilter: function () {
                this.exportedDataLists = [];
            },
            onReset: function () {
                var oView = this.getView();
                oView.byId("filterbar")._oBasicSearchField.setValue("");
                oView.byId("id-filter-currentState").setSelectedItems("");
                oView.byId("id-filter-reqType").setSelectedItems("");
                oView.byId("id-filter-opportunityID").removeAllTokens();
                oView.byId("id-filter-reqID").removeAllTokens();
                oView.byId("id-filter-accountname").removeAllTokens();
                oView.byId("id-filter-creationDate").removeAllTokens();
                oView.byId("id-filter-requester").removeAllTokens();
                oView.byId("id-filter-currentProcessor").removeAllTokens();
                oView.byId("id-filter-task").setSelectedItems("");
                oView.byId("id-filter-reqType").setSelectedItems("");
                oView.byId("id-filter-taskRole").setSelectedItems("");
                oView.byId("id-filter-processor").removeAllTokens();
                oView.byId("id-filter-resource").removeAllTokens();
                oView.byId("dpCreateDate").setDateValue(null);
                oView.byId("dpEndDate").setDateValue(null);
                oView.byId("id-filter-role").setSelectedItems("");
                oView.byId("id-filter-reqSolutions").removeAllTokens();
                oView.byId("idFilterInd").removeAllTokens();
                oView.byId("id-filter-accountname").removeAllTokens();
                this.getView().byId("idClearStartDate").setVisible(false);
                this.getView().byId("idClearEndDate").setVisible(false);
                this.getView().getModel("variant").setData({
                    "globalsearch": {
                        "key": "globalsearch",
                        "value": "",
                        "visible": true
                    },
                    "account": [],
                    "opportunity": [],
                    "reqType": [],
                    "reqId": [],
                    "reqStatus": [],
                    "task": [],
                    "taskOwnerName": [],
                    "taskOwnerRole": [],
                    "salesOrg": [],
                    "reqNameId": [],
                    "resourceNameId": [],
                    "processorNameId": [],
                    "reqStartDate": null,
                    "reqEndDate": null
                })
            },
            handleSortDialogConfirm: function (oEvent) {
                this._alreadyLoadedCount = 20;
                var mParams = oEvent.getParameters(),
                    sPath,
                    bDescending,

                    sPath = mParams.sortItem.getKey();
                bDescending = mParams.sortDescending === true ? `desc` : `asc`
                if (sPath === "DTCreation_tdate") {
                    this.sSortQqueryPrams = `&$orderby=${sPath} ${bDescending},DTCreation_ttime ${bDescending}`;
                } else {
                    this.sSortQqueryPrams = `&$orderby=${sPath} ${bDescending}`;
                }

                this.sFinalQueryParams = `${this.sQueryParams}${this.sSortQqueryPrams}&$skip=0&$top=20`;
                if(this.sQueryParams){
                     this.getView().byId("id-table-wfHistory").setBusy(true);
                    models.getWfInstanceFilterLists(this.fnSuccessFilterCallback, this.fnErrorFilterCallback, this, this.sFinalQueryParams);
                }

            },
            onUpdateStartedGrowingTable: function (oEvent) {
                //Pagination in the Worklist page
                var oTable = oEvent.getSource();
                var oWfHistoryData = this.getView().getModel("wfHistoryModel").getData();
                if (oWfHistoryData) {
                    var iTotalLen = oWfHistoryData.count;
                    if (iTotalLen !== null && iTotalLen !== undefined && iTotalLen > 20) {
                        //Setting the value for iBindingLength = oBinding.getLength() which is the total count of items.
                        oTable.getBindingInfo("items").binding.iLength = iTotalLen;
                        if (oTable.getGrowingInfo().actual === this._alreadyLoadedCount && oTable.getGrowingInfo().actual <
                            iTotalLen && oEvent.getParameter("reason") === "Growing") {
                            this._requestAndAppendMoreLists(this._alreadyLoadedCount);
                        }
                    }
                }
            },
            _requestAndAppendMoreLists: function (sAlreadyLoadedTenantCount) {
                //To load more Features
                var iSkip = parseInt(sAlreadyLoadedTenantCount, [10]);
                var iTop = 20;
                var that = this;
                var workflowBaseurl = models._getWfServiceRuntimeBaseURLRoleBased(this);
                if (!this.sSortQqueryPrams) {
                    this.sSortQqueryPrams = `&$orderby=DTCreation_tdate desc,DTCreation_ttime desc`;
                }
                this.sFinalQueryParams = `${this.sQueryParams}${this.sSortQqueryPrams}`;

                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    url: `${workflowBaseurl}${this.sFinalQueryParams}&$skip=${iSkip}&$top=${iTop}&$expand=_Solution`,
                    type: "GET",
                    success: function (oData) {

                        models.removeIODuplicacy(oData);
                        that._alreadyLoadedCount = oData.value.length + iSkip;
                        var oModel = that.getOwnerComponent().getModel("wfHistoryModel");
                        oData.count = oData["@odata.count"];
                        var aWfHistoryLists = oModel.getData().value.concat(oData.value);
                        oModel.setData({
                            "count": oData.count,
                            "value": aWfHistoryLists
                        }, true);
                        that._closeBusyIndicator(that);


                    }.bind(this),
                    error: function (oError) {
                        that._closeBusyIndicator(that);
                        MessageBox.error(oError.responseText, {
                            contentWidth: "600px"
                        });
                        sap.ui.core.BusyIndicator.hide();
                        return false;
                    }
                });

            },
            _closeBusyIndicator: function (self) {
                var oTable = self.getView().byId("id-table-wfHistory");
                oTable.setBusy(false);

            },
            _setMyPendingRequests: function () {
                var oCurrentProcessorMultiInput = this.getView().byId("id-filter-currentProcessor");
                var oCurrentState = this.getView().byId("id-filter-currentState");
                const aSelectedCurrentState = ['WSUBMN', 'WRESAP', 'REQSUB', 'REESUB', 'WMNAPP', 'WIOAPP' ];
                var oUserModel = this.getOwnerComponent().getModel("userDetails");
                var sUserEmail = oUserModel.getProperty("/email");
                var sUserId = oUserModel.getProperty("/user_name");
                //  var sTokenName = `${sUserId} (${sUserName})`;
                appView.byId("idMainHeader").setSelectedKey("Worklist")
                oCurrentProcessorMultiInput.addToken(new Token({
                    key: sUserEmail,
                    text: sUserEmail
                }));
                oCurrentState.setSelectedKeys(aSelectedCurrentState);
                this.onFilter();
                pendingRequests = false;
            },

            onExit: function () {
                this._oTPC.destroy();
                this.aSelectedUsers = [];
            },
            handleStatusPressed: function (oEvent) {
                var sInstanceID = oEvent.getSource().getBindingContext("wfHistoryModel").getObject().InstanceID;
                models._getWfExecutionLogs(this, sInstanceID, this.fnSuccessGetExecutionLogs);
            },
            fnSuccessGetExecutionLogs: function (result, self) {
                if(result[result.length - 1].subflow)
                {
                    var sSubflowInstanceID = result[result.length-1].subflow.workflowInstanceId;
                    models._getWfExecutionLogs(self, sSubflowInstanceID, self.fnSuccessGetExecutionLogs);
                }else{
                    var sUserTaskId = result[result.length - 1].taskId;
                    var oAppConstantsModel = self.getOwnerComponent().getModel("appConstants");
                    var sInboxUrl = oAppConstantsModel.getProperty("/MyInboxURL/0/Value");
                    var sFinalUrl = `${sInboxUrl}?sap-ui-app-id-hint=cross.fnd.fiori.inbox&substitution=true&userSearch=false&/detail/NA/${sUserTaskId}/TaskCollection(SAP__Origin='NA',InstanceID='${sUserTaskId}')`
                    URLHelper.redirect(sFinalUrl, "_blank");
                }

            },

            fnSuccessUrl: function (data, self) {
                var sUrl = data.value[2].Value;
                URLHelper.redirect(sUrl, "_blank");
            },
            fnErrorUrl: function (data, self) {

            },
            onReqContactlisticon: function (oEvent) {
                var sPath = oEvent.getSource().getBindingContext("wfHistoryModel").sPath;
                var str = sPath;
                var matches = str.match(/(\d+)/);
                var sValue = matches[0];
                var sResources = oEvent.getSource().oPropagatedProperties.oBindingContexts.wfHistoryModel.oModel.oData.value[sValue].EmpRequester_ID;
                users.callEmpApi(sResources, oEvent, this);
            },
            onRequesterContactIcon: function (oEvent) {
                sap.ui.core.BusyIndicator.show(0);
                let oAppConfigModel = this.getOwnerComponent().getModel("mrrAppConfigModel");
                let sName = oAppConfigModel.getProperty("/Requestor/0/fieldDesc");
                let sRequester = oEvent.getSource().getBindingContext("wfHistoryModel").getObject().EmpRequester_ID;
                let oValType = "ID";
                users.callEmpApi(sRequester, oEvent, this, sName, oValType);

            },
            onCurrProcContactlisticon: function (oEvent) {
                sap.ui.core.BusyIndicator.show(0);
                let oAppConfigModel = this.getOwnerComponent().getModel("mrrAppConfigModel");
                let sName = oAppConfigModel.getProperty("/ProcessorNameID/0/fieldDesc");
                var sCurrentProcessorEmail = oEvent.getSource().getId().includes("idCurrentProcessorCard") || oEvent.getSource().getBindingContext("wfHistoryModel").getObject().CurrentStepID === "MANAPP" ? oEvent.getSource().getBindingContext("wfHistoryModel").getObject().CurrentProcessorEmail : oEvent.getSource().getBindingContext("wfHistoryModel").getObject().ReqApproverEmail;
                var sCurrentProcessor =  oEvent.getSource().getId().includes("idCurrentProcessorCard") || oEvent.getSource().getBindingContext("wfHistoryModel").getObject().CurrentStepID === "MANAPP" ? oEvent.getSource().getBindingContext("wfHistoryModel").getObject().CurrentProcessor : oEvent.getSource().getBindingContext("wfHistoryModel").getObject().ReqApproverID;
                var oValType = "Email"
                var self = this;
                if (!sCurrentProcessorEmail) {
                    if (sCurrentProcessor) {
                        var aCurrentProcessor = sCurrentProcessor.split(",");
                        var array = []
                        var sArrLen = aCurrentProcessor.length
                        for (var i = 0; i < aCurrentProcessor.length; i++) {
                            var value = {
                                "firstName": aCurrentProcessor[i]
                            };
                            users.empData(value, oEvent, self, array, sArrLen, sName);
                        }
                    }
                } else if(!oEvent.getSource().getId().includes("idCurrentProcessorCard")) {
                    users.callEmpApi(sCurrentProcessorEmail, oEvent, this, sName, oValType);
                }else{
                       sap.ui.core.BusyIndicator.hide();
                }
            },
            onCurrProcTaskOwnerContactlisticon: function (oEvent) {
                sap.ui.core.BusyIndicator.show(0);
                let oAppConfigModel = this.getOwnerComponent().getModel("mrrAppConfigModel");
                let sName = oAppConfigModel.getProperty("/TaskOwnerName/0/fieldDesc");
                var sCurrentProcessorEmail = oEvent.getSource().getBindingContext("wfHistoryModel").getObject().CurrentProcessorEmail;
                var sCurrentProcessor = oEvent.getSource().getBindingContext("wfHistoryModel").getObject().CurrentProcessor;
                var oValType = "Email"
                var self = this;
                if (!sCurrentProcessorEmail) {
                    if (sCurrentProcessor) {
                        var aCurrentProcessor = sCurrentProcessor.split(",");
                        var array = []
                        var sArrLen = aCurrentProcessor.length
                        for (var i = 0; i < aCurrentProcessor.length; i++) {
                            var value = {
                                "firstName": aCurrentProcessor[i]
                            };
                            users.empData(value, oEvent, self, array, sArrLen, sName);
                        }
                    }
                } else {
                    users.callEmpApi(sCurrentProcessorEmail, oEvent, this, sName, oValType);
                }
            },
             onCurrResContactlisticon: function (oEvent) {
                sap.ui.core.BusyIndicator.show(0);
                let oAppConfigModel = this.getOwnerComponent().getModel("mrrAppConfigModel");
                let sName = oAppConfigModel.getProperty("/ResourceNameID/0/fieldDesc");
                var sCurrentProcessor = oEvent.getSource().getBindingContext("wfHistoryModel").getObject().ResourceIDs;
                var oValType = "ID"
                sCurrentProcessor = sCurrentProcessor ? sCurrentProcessor:"";
                if(sCurrentProcessor){
                      users.callEmpApi(sCurrentProcessor, oEvent, this, sName, oValType);
                }else{
                     sap.ui.core.BusyIndicator.hide();
                }
              
            },
            QuickViewCard: function (oModel, oevt, self, sName) {
                var oButton = oevt.getSource();
                self.getView().setModel(oModel, "EmpDetails");
                var EmployeeDetails = this.getView().getModel("EmpDetails");
                users._contactslistFragment(EmployeeDetails, oevt, self, sName).openBy(oButton);
                sap.ui.core.BusyIndicator.hide();
            },
            onPressEmpEmail: function (oEvent) {
                var sUrl = oEvent.getSource().getProperty("text");
                URLHelper.triggerEmail(sUrl, "Info Request - MRR", false, false, false, true);
            },
            getGroup: function (oContext) {
                var sKey = oContext.getProperty("ParentInstanceID");
                var sCreationDate = oContext.getProperty("DTCreation_tdate");
                const sCreationTime =  oContext.getProperty("DTCreation_ttime");
                const sRefrenceId =  oContext.getProperty("Parent_RefrenceID");
                const sStatus =  oContext.getProperty("Overall_WF_Status");
                var formattedDate = formatter.formatDate(sCreationDate,sCreationTime);
                var sOpportunityID = oContext.getProperty("OpportunityID");
                var sAccountID = oContext.getProperty("Account_ID");
                var sRequestType=oContext.getProperty("RequestType");
                const sAccountName = oContext.getProperty("Account_name");
                const sExtSystemsUrl =  oContext.getProperty("ExtSystemsUrl");
                const sOppName = oContext.getProperty("OpportunityDesc");
                var sTechncicalState = this.getView().getModel("Technicalstate").getData().value.filter(ts => ts.ID == sStatus)[0].technicalState;
                var sTitle = this._setGroupHeaderTitle(sRequestType,sOpportunityID,sAccountID,formattedDate, sRefrenceId, sTechncicalState,sAccountName,sOppName);

                return {
                    key: sKey,
                    title: sTitle,
                    statusText:sTechncicalState,
                    statusId:sStatus,
                    accountId:sAccountID,
                    oppId:sOpportunityID,
                    reqType:sRequestType,
                    externalUrl:sExtSystemsUrl
                };
            },
            _setGroupHeaderTitle:function(sRequestType,sOpportunityID,sAccountID,formattedDate,sRefrenceId,sTechncicalState,sAccountName,sOppName){
                let sTitle = sAccountName ? `${formattedDate} - ${sAccountName}  ` : `${formattedDate}`;
                return sTitle;
            },
            getGroupHeader: function (oGroup) {
                const sObjectStatusText = oGroup.statusText ?  oGroup.statusText:"";
                const sStatus = (oGroup.statusId === "RQIP" || oGroup.statusId === "RQCR") ? "Warning" :  "Success";
                const sHarmonyUrl = this.getOwnerComponent().getModel("appConstants").getProperty("/HarmonyURL/0/Value");
                const sExtSystemsUrl = oGroup.externalUrl;
                let sLink = formatter.formatOppAccountUrl(oGroup.reqType, oGroup.accountId, sHarmonyUrl, sExtSystemsUrl);
                let sId;
                let bLinkVisible = true;
                let bStatusVisible = sObjectStatusText ? true:false;
                switch (oGroup.reqType) {
                    case 'Opportunity':
                        sId = ` ${oGroup.oppId}`;
                        break;
                    case 'Account':
                        sId = ` ${oGroup.accountId}`;
                        break;
                    default:
                        sId = ``;
                        bLinkVisible = false;
                        break;
                }
                return   new IGroupHeaderListItem({
                    title: oGroup.title,
                    upperCase: false,
                    link:{
                        text:sId,
                        href:sLink,
                        visible:bLinkVisible,
                        target:"_blank"
                    },
                    customText:{
                        text:"-",
                        visible:bStatusVisible

                    },
                    status: {
                        text: sObjectStatusText,
                        state: sStatus,
                        visible:bStatusVisible
                    },
                })
            },
            handleRefreshButtonPressed: function(){
                this.onFilter();
            },
            /* Set Models*/

            setAccountModel: function (self) {
                //set account model 'myAccountModel'
                let aMyOpportunities = self.getView().getModel("myOppDialogModel").getData().results;
                let aAccount = [];
                aMyOpportunities.forEach(function (opp) {
                    if (self.formatter.formatCreateRequestBtn(opp.DISP_AUTH, opp.IS_LEAN, opp.SALES_ORG_SHORT, self)) {
                        aAccount.push({
                            "ACCOUNT": opp.ACCOUNT,
                            "ACCOUNT_NAME": opp.ACCOUNT_NAME
                        });
                    }
                });
                const oMyAccountModel = new sap.ui.model.json.JSONModel();
                oMyAccountModel.setData(aAccount);
                self.getView().setModel(oMyAccountModel, "myAccountModel");

            },
            handleValueHelpMyAccount: function (oEvent) {
                //initate value help dialog
                let oView = this.getView();
                const oButton = oEvent.getSource();
                let oAccSrchDataObj = {
                    accounts: [],
                    Industry: [],
                    Region: [],
                    Country: [],
                    resultAccounts: [],
                    lastUpdatedIndex: 0,
                    sPlanningEntities: false,
                    sGlobalUltimate: false,
                    sIndustryKey: "",
                    sRegionKey: "",
                    sCountryKey: "",
                    sSearchQuery: "",
                    letiantid: "",
                    simpleSrch: "",
                    simpleSrchVisible: true,
                    advancedSrchVisisble: false,
                    aPrevStateQueryData: {},
                    aPrevStateQueryIndex: 0
                };
                //set account model
                let oAccountSearchModell = new sap.ui.model.json.JSONModel();
                this.getView().setModel(oAccountSearchModell, "oAccountSearchModel");
                let oAccountSearchModel = this.getView().getModel("oAccountSearchModel");
                this.getView().setModel(oAccountSearchModel, "oAccountSearchModel");
                oAccountSearchModel.setProperty("/", oAccSrchDataObj);
                this.oAccountSearchModel = oAccountSearchModel;

                this.oAccountSearchModel.setProperty("/Industry", []);

                let cvaDataObj = {
                    accounts: [],
                    isAccountDialogBusy: false
                };
                let cvaAccountModell = new sap.ui.model.json.JSONModel();
                this.getView().setModel(cvaAccountModell, "cvaAccountModel");
                let cvaAccountModel = this.getView().getModel("cvaAccountModel");
                this.getView().setModel(cvaAccountModel, "cvaAccountModel");
                cvaAccountModel.setProperty("/", cvaDataObj);
                this.cvaAccountModel = cvaAccountModel;

                // create value help dialog
                if (!this._pAccountValueHelpDialog) {
                    this.sStatus = "initialLoad";
                    this._pAccountValueHelpDialog = Fragment.load({
                        id: oView.getId(),
                        name: "com.dealsupport.melodyrequest.fragments.AccountSearchFilter",
                        controller: this
                    }).then(function (oAccountValueHelpDialog) {
                        oView.addDependent(oAccountValueHelpDialog);
                        return oAccountValueHelpDialog;
                    });
                }
                let that = this;

                this._pAccountValueHelpDialog.then(function (oAccountValueHelpDialog) {
                    oAccountValueHelpDialog.addStyleClass(that.getOwnerComponent().getContentDensityClass());
                    that.accountDialog = oAccountValueHelpDialog;
                    that.getView().getModel("oAccountSearchModel").setProperty("/visibleRowCount",5);
                    that.byId("ACCOUNT_SIMPLE_SEARCH").getHeaderToolbar().getContent()[0].setValue();
                    that.byId("ICON_TAB_ADV_SEARCH").setSelectedKey("ADV_SEARCH");
                    that.byId("ICON_TAB_ADV_SEARCH").fireSelect();
                    that.oAccountSearchModel.refresh(true);
                    oAccountValueHelpDialog.open(oButton);
                });
            },
            _getOpportunitiesRuntimeBaseURL: function (appView) {
                return this._getRuntimeBaseURL(appView) + "/int_ic";
            },

            searchAccounts: function (sValue, cvaFlag, accntList, searchType, sPrevQueryState) {
                //search account details based on accountName and accoundId
                let that = this;
                this.cvaFlag = cvaFlag;
                this.idAccntList = accntList;
                this.sValue = sValue;
                let oAccountSearchModel = that.getView().getModel("oAccountSearchModel");
                oAccountSearchModel.setProperty("/isAccountDialogBusy", true);
                let OpportunitiesBaseUrl = this._getOpportunitiesRuntimeBaseURL(appView, this);
                jQuery.ajax({
                    url: `${OpportunitiesBaseUrl}/sap/opu/odata/sap/zharmony_callidus_srv/BusinessPartners?search=${sValue}&$filter=TYPE eq 'A'`,
                    dataType: 'json',
                    method: "GET",
                    success: function (data) {
                        data = data.d;
                        var oData = [],
                            obj = {};
                        $.each(data.results, function (index, item) {
                            obj.ACCOUNT_NAME = item.NAME;
                            obj.ACCOUNT = item.PARTNER;
                            oData.push(obj);
                            obj = {};
                        });
                        let aFilter = new Filter({
                            filters: [
                                new Filter("ACCOUNT_NAME", "Contains", that.sValue),
                                new Filter("ACCOUNT", "Contains", that.sValue)
                            ],
                            and: false
                        });
                        if (that.cvaFlag) {
                            let sSearchval = that.sValue.toLowerCase();
                            let oFilteredData = [];
                            oData.filter(function (accObj) {
                                let Account = accObj.ACCOUNT;
                                let AccountName = accObj.ACCOUNT_NAME.toLowerCase();
                                if (Account.includes(sSearchval) || AccountName.includes(sSearchval)) {
                                    oFilteredData.push(accObj);
                                }
                            });
                            that.cvaAccountModel.setData({
                                "accounts": oFilteredData
                            }, true);
                            let cvaModel = that.getView().getModel("cvaModel");
                            if (searchType === "ADV_SEARCH") {
                                let oAccountSearchModel = that.getView().getModel("oAccountSearchModel");
                                oAccountSearchModel.setProperty("/accounts", []);
                                let aPrevStateQueryData = oAccountSearchModel.getProperty("/aPrevStateQueryData");
                                if (oFilteredData.length) {
                                    let length = oFilteredData.length;
                                    if (oFilteredData.length > 100) {
                                        length = 100;
                                    }
                                    for (let i = 0; i < length; i++) {
                                        let oTempObj = {
                                            Account: oFilteredData[i].ACCOUNT,
                                            AccountName: oFilteredData[i].ACCOUNT_NAME,
                                        };
                                        if (sPrevQueryState === "CONTAINS_QUERY") {
                                            let aPrevStateQueryIndex = oAccountSearchModel.getProperty("/aPrevStateQueryIndex");
                                            let oSearchedObj = that.fnFindSameAccountObject("Account", oFilteredData[i].ACCOUNT, aPrevStateQueryIndex);
                                            if (oSearchedObj) {
                                                if (oSearchedObj.hasOwnProperty("GlobalUltimate")) {
                                                    oAccountSearchModel.getProperty("/accounts").push(oSearchedObj);
                                                } else {
                                                    oAccountSearchModel.getProperty("/accounts").push(oTempObj);
                                                    that.fnGetAcountDetails(i);
                                                }
                                            } else {
                                                oAccountSearchModel.getProperty("/accounts").push(oTempObj);
                                                that.fnGetAcountDetails(i);
                                            }
                                            oAccountSearchModel.setProperty("/isAccountDialogBusy", false);
                                            if (i + 1 === length) {
                                                oAccountSearchModel.setProperty("/lastUpdatedIndex", i);
                                                oAccountSearchModel.setProperty("/aPrevStateQueryData", aPrevStateQueryData);
                                                that.fnSetAccountMasterData();
                                            }
                                        } else {
                                            oAccountSearchModel.setProperty("/lastUpdatedIndex", i);
                                            oAccountSearchModel.getProperty("/accounts").push(oTempObj);
                                            that.fnGetAcountDetails(i, oFilteredData[i].ACCOUNT);
                                        }
                                    }
                                } else {
                                    if (cvaModel) {
                                        cvaModel.setData({
                                            "accounts": []
                                        }, true);
                                    }
                                    that.cvaAccountModel.setData({
                                        "accounts": []
                                    }, true);
                                    let sAccounts = $.extend(true, [], oFilteredData);
                                    let sSearchQuery = oAccountSearchModel.getProperty("/sSearchQuery");
                                    sSearchQuery = sSearchQuery.split(" ").join("");
                                    sSearchQuery = sSearchQuery.toLowerCase();
                                    aPrevStateQueryData[sSearchQuery] = sAccounts;
                                    oAccountSearchModel.setProperty("/aPrevStateQueryData", aPrevStateQueryData);
                                    oAccountSearchModel.setProperty("/isAccountDialogBusy", false);
                                    oAccountSearchModel.refresh(true);
                                }
                            } else if (searchType === "SIMPLE_SEARCH") {
                                if (cvaModel) {
                                    cvaModel.setData({
                                        "accounts": oData
                                    }, true);
                                    cvaModel.setProperty("/isAccountDialogBusy", false);
                                }
                                that.oOpportunityModel.setData({
                                    "accounts": oData
                                }, true);
                                that.idAccntList.getBinding("items").filter(aFilter);
                                that.oOpportunityModel.setProperty("/isAccountDialogBusy", false);
                            }
                            that.getView().getModel("cvaAccountModel").setProperty("/isAccountDialogBusy", false);
                        } else {
                            that.oOpportunityModel.setData({
                                "accounts": oData
                            }, true);
                            that.idAccntList.getBinding("items").filter(aFilter);
                            that.oOpportunityModel.setProperty("/isAccountDialogBusy", false);
                        }
                    }.bind(this),
                    error: function (oError) {
                        sap.ui.core.BusyIndicator.hide();
                        if (oError.responseText) {
                            sap.ui.core.BusyIndicator.hide();
                            MessageBox.error(oError.responseText, {});
                        } else {
                            MessageBox.error("Something went wrong", {});
                        }
                    }
                });
            },

            //Function to get Account Details by passing Account ID
            fnGetAcountDetails: function (accountIndex, accountID, isMyAccounts) {
                let that = this;
                let selDataObj = {};
                let oAccountSearchModel = that.getView().getModel("oAccountSearchModel");
                oAccountSearchModel.setProperty("/isAccountDialogBusy", true);
                if (isMyAccounts) {
                    selDataObj = oAccountSearchModel.getProperty("/myAccounts/" + accountIndex);
                } else {
                    selDataObj = oAccountSearchModel.getProperty("/accounts/" + accountIndex);
                }
                let accountId = selDataObj.Account;
                let OpportunitiesBaseUrl = this._getOpportunitiesRuntimeBaseURL(appView, this);
                jQuery.ajax({
                    url: `${OpportunitiesBaseUrl}/sap/opu/odata/sap/zharmony_callidus_srv/Z1S_CRM_BUPA_INFOSet('${accountID}')`,
                    dataType: 'json',
                    method: "GET",
                    success: function (oData) {
                        var oData = oData.d;
                        let street = oData.HouseNo ? "#" + oData.HouseNo + ", " : "";
                        street = street + oData.Street;
                        if (street) {
                            street = oData.ZipCode ? street + ", " + oData.ZipCode : street;
                        } else {
                            street = oData.ZipCode ? oData.ZipCode : "";
                        }
                        oAccountSearchModel.getProperty("/accounts")[accountIndex].GlobalUltimate = oData.GlobalUltimateId === selDataObj.Account ?
                            "true" : "false";
                        oAccountSearchModel.getProperty("/accounts")[accountIndex].Street = street;
                        oAccountSearchModel.getProperty("/accounts")[accountIndex].Country = oData.Country;
                        oAccountSearchModel.getProperty("/accounts")[accountIndex].IndustryName = oData.IndustryName;
                        oAccountSearchModel.getProperty("/accounts")[accountIndex].IndustryCode = oData.Industry;
                        oAccountSearchModel.getProperty("/accounts")[accountIndex].IsPlanningEntity = oData.PlanningEntityId ? "true" : "false";
                        oAccountSearchModel.getProperty("/accounts")[accountIndex].PE_ID = oData.PlanningEntityId;
                        oAccountSearchModel.getProperty("/accounts")[accountIndex].PE_Name = oData.PlanningEntityName;
                        oAccountSearchModel.getProperty("/accounts")[accountIndex].City = oData.City;
                        oAccountSearchModel.getProperty("/accounts")[accountIndex].RegionCode = oData.Region;
                        oAccountSearchModel.getProperty("/accounts")[accountIndex].GlobalRegion = oData.Region;

                        let lastAccountObj = {};
                        let lastUpdateIndex = oAccountSearchModel.getProperty("/lastUpdatedIndex");
                        if (isMyAccounts) {
                            lastAccountObj = oAccountSearchModel.getProperty("/myAccounts/" + lastUpdateIndex + "/Account");
                        } else {
                            lastAccountObj = oAccountSearchModel.getProperty("/accounts/" + lastUpdateIndex + "/Account");
                        }
                        if (oData.IndustryName && oData.Industry) {
                            let oIndustryObj = {
                                Description: oData.IndustryName,
                                IndustryId: oData.Industry
                            };
                            let aIndustryArr = oAccountSearchModel.getProperty("/Industry");
                            let isIndustryPresent = that.fnFindSameAccountObject("IndustryId", oData.Industry, aIndustryArr);
                            if (!isIndustryPresent) {
                                aIndustryArr.push(oIndustryObj);
                            }
                        }
                        oAccountSearchModel.setProperty("/isAccountDialogBusy", false);
                        oAccountSearchModel.refresh();
                        that.fnFilterAdvSearchAccounts();
                    }.bind(this),
                    error: function (oError) {
                        sap.ui.core.BusyIndicator.hide();
                        if (oError.responseText) {
                            sap.ui.core.BusyIndicator.hide();
                            MessageBox.error(oError.responseText, {});
                        } else {
                            MessageBox.error("Something went wrong", {});
                        }
                    }
                });
            },
            fnFindSameAccountObject: function (oProperty, oValue, oArray) {
                let oSearchedObj = oArray.find(function (object) {
                    return object[oProperty] === oValue;
                });
                return oSearchedObj;
            },
            //Function to set total accounts count in Icon tab bar
            fnSetAccountCount: function (lastUpdatedIndex, oAccounts, simpleSrchVisible) {
                let oAccountSearchModel = this.oAccountSearchModel;
                let oTxt = "Advanced Search";
                let isMyAccountsCountVisible = oAccountSearchModel.getProperty("/isMyAccountsCountVisible");
                let sSearchQuery = oAccountSearchModel.getProperty("/sSearchQuery");
                sSearchQuery = sSearchQuery.split(" ").join("");
                sSearchQuery = sSearchQuery.toLowerCase();
                let aPrevStateQueryData = oAccountSearchModel.getProperty("/aPrevStateQueryData");
                let allAaccounts = aPrevStateQueryData[sSearchQuery + "_AllAccounts"];
                var lastUpdatedIndex = aPrevStateQueryData[sSearchQuery + "_LastUpdatedIndex"];
                if (simpleSrchVisible) {
                    return oTxt;
                } else {
                    if (allAaccounts) {
                        let oLength = allAaccounts.length;
                        if (oLength) {
                            lastUpdatedIndex = lastUpdatedIndex + 1;
                            if (lastUpdatedIndex > oLength) {
                                return oTxt + " (" + oLength + "/" + oLength + ")";
                            } else {
                                return oTxt + " (" + lastUpdatedIndex + "/" + oLength + ")";
                            }
                        } else {
                            return oTxt;
                        }
                    } else {
                        if (isMyAccountsCountVisible) {
                            let accounts = oAccountSearchModel.getProperty("/accounts");
                            if (accounts.length > 0) {
                                return oTxt + " (" + accounts.length + "/" + accounts.length + ")";
                            } else {
                                return oTxt;
                            }
                        } else {
                            return oTxt;
                        }
                    }
                }
            },
            handleAccountSearch: function (oEvent) {
                this.getView().getModel("oAccountSearchModel").setProperty("/Industry", []);
                let sValue = "";
                let eventType = typeof (oEvent);
                if (eventType === "object") {
                    sValue = oEvent.getSource().getValue();
                } else if (eventType === "string") {
                    sValue = oEvent;
                }
                let searchQuery = sValue;
                let i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
                //sValue = sValue.split(" ").join("");
                sValue = sValue.toLowerCase();
                let oAccountSearchModel = this.oAccountSearchModel;
                this.myAccounts = this.cvaAccountModel.getProperty("/myAccounts");
                if (sValue.length >= 3) {
                    this.cvaAccountModel.setProperty("/accounts", []);
                    this.cvaAccountModel.setProperty("/isAccountDialogBusy", true);
                    oAccountSearchModel.setProperty("/accounts", []);
                    oAccountSearchModel.setProperty("/isMyAccountsCountVisible", false);
                    this.searchAccounts(sValue, true, "", "ADV_SEARCH");

                } else if (sValue === "") {
                    this.fnClearFilterAdvSearchAccounts();
                    oAccountSearchModel.setProperty("/accounts", []);
                    oAccountSearchModel.setProperty("/isMyAccountsCountVisible", true);
                    oAccountSearchModel.setProperty("/sSearchQuery", "");
                } else {
                    const sValidationMsg = i18nModel.getText("searchValidationMsg");
                    sap.m.MessageToast.show(sValidationMsg);
                }
            },
            //Function to filter Accounts in Advanced search 
            fnFilterAdvSearchAccounts: function (oEvent) {
                let aFilter = [],
                    sPlanningEntitiesKey = "",
                    sGlobalUltimateKey = "";
                let oAccountSearchModel = this.oAccountSearchModel;
                let table = this.byId("ACCOUNT_ADV_SEARCH_TBL");
                table.getBinding("rows").filter([]);
                let sPlanningEntities = oAccountSearchModel.getProperty("/sPlanningEntities");
                let sGlobalUltimate = oAccountSearchModel.getProperty("/sGlobalUltimate");
                let sIndustryKey = oAccountSearchModel.getProperty("/sIndustryKey");
                let sRegionKey = oAccountSearchModel.getProperty("/sRegionKey");
                let sCountryKey = oAccountSearchModel.getProperty("/sCountryKey");
                if (oEvent) {
                    if (oEvent.getSource().getMetadata().getElementName() === "sap.m.CheckBox") {
                        if (sPlanningEntities) {
                            if (oEvent.getSource().getName() === "PLANNING_ENTITY" || sPlanningEntities) {
                                sPlanningEntitiesKey = (sPlanningEntities === true) ? "true" : "false";
                            }
                        }
                        if (sGlobalUltimate) {
                            if (oEvent.getSource().getName() === "GLOBAL_ULTIMATE" || sGlobalUltimate) {
                                sGlobalUltimateKey = (sGlobalUltimate === true) ? "true" : "false";
                            }
                        }
                    } else {
                        if (sPlanningEntities) {
                            sPlanningEntitiesKey = (sPlanningEntities === true) ? "true" : "false";
                        }
                        if (sGlobalUltimate) {
                            sGlobalUltimateKey = (sGlobalUltimate === true) ? "true" : "false";
                        }
                    }
                } else {
                    if (sPlanningEntities) {
                        sPlanningEntitiesKey = (sPlanningEntities === true) ? "true" : "false";
                    }
                    if (sGlobalUltimate) {
                        sGlobalUltimateKey = (sGlobalUltimate === true) ? "true" : "false";
                    }
                }
                if (sPlanningEntitiesKey) {
                    aFilter.push(new sap.ui.model.Filter("IsPlanningEntity", "EQ", sPlanningEntitiesKey));
                }
                if (sGlobalUltimateKey) {
                    aFilter.push(new sap.ui.model.Filter("GlobalUltimate", "EQ", sGlobalUltimateKey));
                }
                if (sIndustryKey) {
                    aFilter.push(new sap.ui.model.Filter("IndustryCode", "EQ", sIndustryKey));
                }
                if (sRegionKey) {
                    aFilter.push(new sap.ui.model.Filter("GlobalRegion", "EQ", sRegionKey));
                }
                if (sCountryKey) {
                    aFilter.push(new sap.ui.model.Filter("Country", "EQ", sCountryKey));
                }
                table.getBinding("rows").filter(aFilter);

                let noOfRows = table.getBinding("rows").getLength();
                if (noOfRows === 0) {
                    this.oAccountSearchModel.setProperty("/visibleRowCount", 1);
                    this.byId("ACCOUNT_ADV_SEARCH_TBL").setVisibleRowCountMode("Fixed");
                } else if (noOfRows > 0 && noOfRows <= 5) {
                    this.oAccountSearchModel.setProperty("/visibleRowCount", noOfRows);
                    this.byId("ACCOUNT_ADV_SEARCH_TBL").setVisibleRowCountMode("Fixed");
                } else {
                    this.byId("ACCOUNT_ADV_SEARCH_TBL").setVisibleRowCountMode("Auto");
                }
            },
            onSelectAccountTab: function (oEvent) {
                let selectedTab = "SIMPLE_SEARCH";
                let oAccountSearchModel = this.oAccountSearchModel;
                if (oEvent) {
                    selectedTab = oEvent.getSource().getSelectedKey();
                }
                if (selectedTab === "SIMPLE_SEARCH") {
                    oAccountSearchModel.setProperty("/simpleSrchVisible", true);
                    oAccountSearchModel.setProperty("/advancedSrchVisisble", false);
                    let cvaModel = this.getOwnerComponent().getModel("cvaModel");
                    let myAccounts = this.oOpportunityModel.getProperty("/myAccounts");
                    if (cvaModel) {
                        cvaModel.setProperty("/accounts", myAccounts);
                    }
                    this.oOpportunityModel.setProperty("/accounts", myAccounts);
                } else if (selectedTab === "ADV_SEARCH") {
                    oAccountSearchModel.setProperty("/simpleSrchVisible", false);
                    oAccountSearchModel.setProperty("/advancedSrchVisisble", true);
                    let sValue = oAccountSearchModel.getProperty("/sSearchQuery");
                    if (sValue) {
                        this.handleAccountSearch(sValue);
                    }
                }
                oAccountSearchModel.refresh(true);
            },

            fnClearFilterAdvSearchAccounts: function () {
                //reset account dialogs
                let oAccountSearchModel = this.oAccountSearchModel;
                oAccountSearchModel.setProperty("/sPlanningEntities", false);
                oAccountSearchModel.setProperty("/sGlobalUltimate", false);
                oAccountSearchModel.setProperty("/sIndustryKey", "");
                oAccountSearchModel.setProperty("/sRegionKey", "");
                oAccountSearchModel.setProperty("/sCountryKey", "");
                this.fnFilterAdvSearchAccounts();
            },
            _handleValueHelpAccountClose: function (evt) {

                appView.onOpenBusyDialog();
                this.aSelectedReqAreas = [];
                var oView = this.getView();
                this.getView().byId("id-filter-accountname").setTokens([]); // Clear any existing tokens

                var aSelectedIndices = this.getView().byId("ACCOUNT_ADV_SEARCH_TBL").getSelectedIndices();
                var aSelectedItems = [];
                aSelectedIndices.forEach(function (iIndex) {
                    // Get the context of the selected row
                    var oContext = oView.byId("ACCOUNT_ADV_SEARCH_TBL").getContextByIndex(iIndex);
                    var oSelectedData = oContext.getObject();
                    aSelectedItems.push(oSelectedData);
                });

                var oMultiInput = this.byId("id-filter-accountname");

                oMultiInput.setTokens([]);

                this.aAccount = [];
                let aOAccountKeyValue = [];

                var that = this;
                aSelectedItems.forEach(function (oItem) {
                    var sTitle = `${oItem.AccountName}(${oItem.Account})`;
               oMultiInput.addToken(new sap.m.Token({
                        text: sTitle,
                        key:oItem.Account
                    }));

                    that.aAccount.push(sTitle);
                });
                // this.getView().getModel("variant").setProperty("/account", aOAccountKeyValue);
                // this.getView().getModel("variant").refresh();
                that.accountDialog.close();
                appView.onCloseBusyDialog();
            },
            fnCloseAccountSearch: function () {
                this.accountDialog.close();
            },
            onSalesOrgSelect: function () {
                //select sales org
                const sSalesOrg = this.getView().byId("idSelectSalesOrg").getSelectedKey();
                //get salesOrg-profit center mapping
                const sSalesOrgNumber = Number(sSalesOrg.replace('SORG-', '')).toString();
                const sFilterParams = `SOrg eq '${sSalesOrgNumber}' and isPC_Viewable eq 'X'`;
                models.getFilteredSalesOrgProfitCenter(appView,sSalesOrgNumber,this);
                this.getView().byId("multiInputProfitCenterAccount").setVisible(true);
                this.getView().byId("idProfitCenterAccountLabel").setVisible(true);

                if (this.aAccount) {
                    appView.oFinalData.OrgID = sSalesOrg;
                    appView.oFinalData.OrgType = "SORG";
                    appView.oFinalData.SalesOrg = this._getSalesOrgName(appView.oFinalData.OrgID);
                    if(this.byId("id-filter-accountname").getTokens().length !== 0){
                        this.sStatus = "initialLoad";
                        this._setDetailScreen(sSalesOrg);
                    }
                }
            },
            fnSuccessAccountCallback: function (response, sAccountOwner) {
                //get account owner details
                if (sAccountOwner) {
                    let aPartnerList = response.d.results;
                    let oAccountOwnerDetails = aPartnerList.filter((partner) => partner.NAME === sAccountOwner)[0];
                    appView.oFinalData.AccountOwner = oAccountOwnerDetails.NAME;
                    appView.oFinalData.AccountOwnerUserId = oAccountOwnerDetails.USERID;
                    appView.oFinalData.AccountOwnerEmail = oAccountOwnerDetails.EMAIL;
                } else {
                    appView.oFinalData.AccountOwner = response.d.PARENT_ACC_OWNR_NM;
                    appView.oFinalData.AccountOwnerUserId = "";
                    appView.oFinalData.AccountOwnerEmail = "";
                }
            },
                /**
            * Git #269  Request View Update
            * Show variant list
            * @param {object} oEvent - select varaint control scope
            * @function displayVariants
            */
            displayVariants: function (oEvent) {
                if (!this._variantFmt) {
                    this._variantFmt = sap.ui.xmlfragment("com.dealsupport.melodyrequest.fragments.variant", this);

                }
                sap.ui.getCore().byId("variantList").setSelectedKey(this.variantId);
                //reset filteres if no values
                !this.getView().byId("id-filter-requester").getTokens().length ? this.getView().getModel("variant").setProperty("/reqNameId", []) : false;
                !this.getView().byId("id-filter-currentProcessor").getTokens().length ? this.getView().getModel("variant").setProperty("/taskOwnerName", []) : false;
                !this.getView().byId("id-filter-resource").getTokens().length ? this.getView().getModel("variant").setProperty("/resourceNameId", []) : false;
                !this.getView().byId("id-filter-processor").getTokens().length ? this.getView().getModel("variant").setProperty("/processorNameId", []) : false;
                !this.getView().byId("id-filter-opportunityID").getTokens().length ? this.getView().getModel("variant").setProperty("/opportunity", []) : false;
                !this.getView().byId("id-filter-reqSolutions").getTokens().length ? this.getView().getModel("variant").setProperty("/solutionArea", []) : false;
                !this.getView().byId("idFilterInd").getTokens().length ? this.getView().getModel("variant").setProperty("/IndData", []) : false;


                let sReqStatus = this.getView().getModel("variant").getProperty("/reqStatus"),
                    aNewReqStatus = sReqStatus ? sReqStatus.filter(item => item !== 'undefined'):[];
                this.getView().getModel("variant").setProperty("/reqStatus", aNewReqStatus)
                let sReqRole= this.getView().getModel("variant").getProperty("/reqRole"),
                    aNewReqRole = sReqRole ? sReqRole.filter(item => item !== 'undefined'):[];
                this.getView().getModel("variant").setProperty("/reqRole", aNewReqRole)


                this.getView().getModel("mroDataVariant").refresh();
                var oButton = oEvent.getSource();
                this.getView().addDependent(this._variantFmt);
                sap.ui.getCore().byId("variantList").setBusy(false);
                this._variantFmt.openBy(oButton);
                if (this._variantFmt.getContent()[0].getSelectedItem().getBindingContext("mroDataVariant").getObject().Editable === "X") {
                    //enable save button for  only user variant
                    sap.ui.getCore().byId("variantSave").setEnabled(true);
                } else {
                    sap.ui.getCore().byId("variantSave").setEnabled(false);
                }

            },
               /**
            * Git #269  Request View Update
            * Show manage variant
            * @function handleManagePress
            */
            handleManagePress: function () {
                this.getView().setBusy(true);
                models._getManageVariantData(this)
                if (!this._variantManageFmt) {
                    this._variantManageFmt = sap.ui.xmlfragment("com.dealsupport.melodyrequest.fragments.manageVariant", this);
                }
                this.getView().addDependent(this._variantManageFmt);
                this._variantFmt.close();
                var that = this;
                sap.ui.getCore().byId("variantManageTable").getBinding("items").refresh();
                sap.ui.getCore().byId("variantManageTable").getBinding("items").attachDataReceived(function dataRecived(data) {
                    var aFilters = [];
                    aFilters.push(new Filter("view_name", FilterOperator.EQ, that.groupName));
                    sap.ui.getCore().byId("variantManageTable").getBinding("items").filter(aFilters);
                    sap.ui.getCore().byId("variantList").setBusy(false);
                });
                this._variantManageFmt.open();
            },
               /**
            * Git #269  Request View Update
            * open dialog for save new variant
            * @function handleSaveAsPress
            */
            handleSaveAsPress: function () {
                var variantObj = sap.ui.getCore().byId("variantList").getSelectedItem().getBindingContext("mroDataVariant").getObject()
                let oFilterString = JSON.parse(variantObj.FilterString.replace(/'/g, '"'));
                !this.getView().byId("id-filter-requester").getTokens().length ? oFilterString.reqNameId = [] : false;
                !this.getView().byId("id-filter-currentProcessor").getTokens().length ? oFilterString.taskOwnerName = [] : false;
                !this.getView().byId("id-filter-resource").getTokens().length ? oFilterString.resourceNameId = [] : false;
                !this.getView().byId("id-filter-processor").getTokens().length ? oFilterString.processorNameId = [] : false;
                !this.getView().byId("id-filter-reqSolutions").getTokens().length ? oFilterString.solutionArea = [] : false;
                !this.getView().byId("idFilterInd").getTokens().length ? oFilterString.IndData = [] : false;
                !this.getView().byId("dpCreateDate").getDateValue() ? oFilterString.reqStartDate  : null;
                !this.getView().byId("dpEndDate").getDateValue() ? oFilterString.reqEndDate  : null;
                !this.getView().byId("id-filter-opportunityID").getTokens().length ? oFilterString.opportunity = [] : false;
                variantObj.FilterString = JSON.stringify(oFilterString).replace(/"/g, "'");
                this.variantGuid = false;
                this.variants.setData(variantObj);
                if (!this._newVariantFmt) {
                    this._newVariantFmt = sap.ui.xmlfragment("com.dealsupport.melodyrequest.fragments.createVariant", this);
                }
                let oVariantModel = this.getView().getModel("variant"),
                    oSearchVal = this.getView().byId("filterbar")._oBasicSearchField.getValue();
                oVariantModel.setProperty("/globalsearch/value", oSearchVal);
                if(oVariantModel.getProperty("/solutionArea") && oVariantModel.getProperty("/solutionArea").length){
                    oVariantModel.getData().solutionArea.forEach(obj => {
                       obj.levels =  obj.LevelId === 2 ? [] :[{ "soln_name": "Loading..." }];
                       delete obj.__metadata;
                    });

                }
              //update opportunity id tokens in variant model
                 let oppIdTokens = this.getView().byId("id-filter-opportunityID").getTokens();
                    let aOppKeyValue = oppIdTokens.map(item => {
                        return {
                            key:item.getText(),
                            value: item.getText()
                        };
                    });
                 this.getView().getModel("variant").setProperty("/opportunity", aOppKeyValue);
                
                 //update request id tokens in variant model
                let oReqIdTokens = this.getView().byId("id-filter-reqID").getTokens();
                let aReqIdKeyValue = oReqIdTokens.map(item => {
                    return {
                        key: item.getText(),
                        value: item.getText()
                    };
                });
                this.getView().getModel("variant").setProperty("/reqId", aReqIdKeyValue);

                  //update account id tokens in variant model
                 let oAccountTokens = this.getView().byId("id-filter-accountname").getTokens();
                    let aAccountKeyValue = oAccountTokens.map(item => {
                        return {
                            key:item.getKey(),
                            value: item.getText()
                        };
                    });
                 this.getView().getModel("variant").setProperty("/account", aAccountKeyValue);

                oVariantModel.refresh();
                this.getView().getModel("variants").setData({});
                this.getView().getModel("variants").refresh();


                this.getView().addDependent(this._newVariantFmt);
                this._newVariantFmt.open();
                sap.ui.getCore().byId("createVariant").setValueState("None");

            },
            onCreateVariantChange: function (oEvent) {
                if (oEvent) {
                    oEvent.getSource().setValueState("None");
                }

            },
              /**
            * Git #269  Request View Update
            * Delete variant
            * @param {object} oEvent - delete control scope
            * @function handleVariantDelete
            */
            handleVariantDelete: function (oEvent) {
                var that = this;
                that.deleteVariantGuid = oEvent.getSource().getParent().getBindingContext("mroDataVariant").getObject();
                var dialog = new sap.m.Dialog({
                    title: 'Delete',
                    type: 'Message',
                    content: new Text({
                        text: 'Are you sure you want to Delete?'
                    }),
                    beginButton: new Button({
                        text: 'Delete',
                        press: function () {
                            delete oEvent.getSource().getParent().getBindingContext("mroDataVariant").getObject();
                            models._deleteVariantData(that, that.deleteVariantGuid.VariantGuid)
                            dialog.destroy();
                        }
                    }),
                    endButton: new Button({
                        text: 'Cancel',
                        press: function () {
                            dialog.close();
                        }
                    }),
                    afterClose: function () {
                        dialog.destroy();
                    }
                });

                dialog.open();

            },
               /**
            * Git #269  Request View Update
            * Save/update new variant
            * @function handleCreatePress
            */
            handleCreatePress: function () {
                var newVariant = sap.ui.getCore().byId("createVariant").getValue();
                if (newVariant.trim()) {
                    this.getView().setBusy(true);
                    let sLoggedInUserId = this.getOwnerComponent().getModel("userDetails").getProperty("/user_name").toUpperCase();
                    let oEntry = {};
                    let sFilterQuery = JSON.stringify(this.getView().getModel("variant").getData()).replace(/"/g, "'");
                    let executeOnSelect = this.isCheckBoxSelected("executeOnSelect");
                    let defaultVariant = this.isCheckBoxSelected("default");
                    oEntry.variantName = newVariant.trim();
                    oEntry.author = sLoggedInUserId.toUpperCase();
                    oEntry.type = "P";
                    oEntry.filterString = sFilterQuery;
                    oEntry.executeOnSelect = executeOnSelect;
                    oEntry.operationFlag = "X";
                    if (this.variantGuid) {
                        oEntry.variantGuid = this.variants.getData().VariantGuid
                    }
                    oEntry._toUserVariant = [{
                        "userId": sLoggedInUserId.toUpperCase(),
                        "isDefault": defaultVariant
                    }];

                    if (!this.variantGuid) {
                        models._createVariantData(this, oEntry);
                    } else {
                        models._updateVariantData(this, oEntry, true);
                    }

                    this._newVariantFmt.close();
                } else {
                    sap.ui.getCore().byId("createVariant").setValueState("Error");
                }
                this.variantGuid = false;
            },
               /**
            * Git #269  Request View Update
            * Check box select options for variant 'execute on select' or 'default'
            * @param {string} id - id of  'execute on select' or 'default'
            * @function isCheckBoxSelected
            */
            isCheckBoxSelected: function (id) {
                return (sap.ui.getCore().byId(id).getSelected()) ? "X" : "";
            },
            handleCreateVariantCancel: function () {
                this._newVariantFmt.close();
            },
              /**
            * Git #269  Request View Update
            * Manage variant functionality
            * @function handleManageVariantPress
            */
            handleManageVariantPress: function (oEvent) {
                this.getView().setBusy(true);
                var that = this;
                var tableId = sap.ui.getCore().byId("variantManageTable");
                var tableItems = tableId.getItems();
                this.aManagerVariantData = [];
                for (var i in tableItems) {
                    //set object for variant data
                    tableItems[i].getBindingContext("mroDataVariant").getObject();
                    var oEntry = {};
                    oEntry.Editable = tableItems[i].getBindingContext("mroDataVariant").getObject().Editable;
                    if (tableItems[i].getCells()[0].getSelected() || tableItems[i].getCells()[3].getSelected()) {
                        oEntry.Favourite = "X";
                    } else {
                        oEntry.Favourite = "";
                    }
                    oEntry.author = tableItems[i].getBindingContext("mroDataVariant").getObject().Author;
                    if (tableItems[i].getCells()[3].getSelected()) {
                        oEntry.IsDefault = "X";
                    } else {
                        oEntry.IsDefault = "";
                    }
                    if (tableItems[i].getCells()[4].getSelected()) {
                        oEntry.ExecuteOnSelect = "X";
                    } else {
                        oEntry.ExecuteOnSelect = "";
                    }
                    oEntry.FilterString = tableItems[i].getBindingContext("mroDataVariant").getObject().FilterString;
                    oEntry.VariantName = tableItems[i].getBindingContext("mroDataVariant").getObject().VariantName;
                    oEntry.VariantGuid = tableItems[i].getBindingContext("mroDataVariant").getObject().VariantGuid;
                    this.aManagerVariantData.push(oEntry)
                }
                const self = this;
                //update all variant data
                function fnUpdateVariant(items) {
                    return new Promise((resolve) => {
                        let oEntry = {
                            executeOnSelect: items.ExecuteOnSelect,
                            variantName: items.VariantName,
                            variantGuid: items.VariantGuid
                        }
                        let oResponse = models._updateVariantData(self, oEntry)

                        resolve(oResponse);
                    }).then(function () {
                    }.bind(self));
                }
                let aOnUpdateVariantAllPromises = [];
                this.aManagerVariantData.forEach(function (items) {
                    aOnUpdateVariantAllPromises.push(fnUpdateVariant(items));
                })
                Promise.all(aOnUpdateVariantAllPromises)
                    .then(function () {
                        let oVariantData = self.aManagerVariantData;

                        let aFinalVariantData = []
                        oVariantData.forEach(function (variant) {
                            variant.Favourite = variant.IsDefault ? "X" : variant.Favourite;
                            if (variant.Favourite || variant.IsDefault) {
                                //update Favourite or default variant
                                aFinalVariantData.push({
                                    "variantGuid": variant.VariantGuid,
                                    "isDefault": variant.IsDefault,
                                })

                            }
                        })
                        let oFinalPayload = {
                            "userId": this.getOwnerComponent().getModel("userDetails").getProperty("/user_name").toUpperCase(),
                            "VariantDetails": aFinalVariantData
                        }
                        //update default variant
                        models._saveOrUpdateVariantData(self, oFinalPayload)

                    }.bind(self))
                    .then(data => {
                        // 'data' will be an array of the parsed JSON data from each service call

                    })
                    .catch(error => {
                        // One or more promises rejected
                        console.error('Error in one of the service calls:', error);
                    });

                this.getView().getModel("mroDataVariant").refresh();
                this._variantManageFmt.close();
            },
            handleManageVariantCancel: function () {
                // models._getVariantData(this)
                this._variantManageFmt.close();
            },
               _resetAllProperties: function () {
                if(this.getView().getModel("variant")){
                let oVariantModel = this.getView().getModel("variant")
                oVariantModel.setProperty("/opportunity", []);
                oVariantModel.setProperty("/processorNameId", []);
                oVariantModel.setProperty("/reqId", []);
                oVariantModel.setProperty("/reqNameId", []);
                oVariantModel.setProperty("/reqStatus", []);
                oVariantModel.setProperty("/reqType", []);
                oVariantModel.setProperty("/resourceNameId", []);
                oVariantModel.setProperty("/salesOrg", []);
                oVariantModel.setProperty("/task", []);
                oVariantModel.setProperty("/taskOwnerName", []);
                oVariantModel.setProperty("/taskOwnerRole", []);
                this.getView().getModel("variant").refresh();
                }  

                var oMI = this.byId("id-filter-opportunityID");

                // Remove all tokens safely
                oMI.destroyTokens();

                // Remove value if any
                oMI.setValue("");

                // Clear duplicate bindings if needed
                oMI.getBinding("tokens")?.filter([]);

              
            },
             /**
            * Git #269  Request View Update
            * Variant select
            * @param {object} oEvent - variant list control context
            * @param {object} oDefaultVariant - default variant
            * @function variantSelect
            */
            variantSelect: function (oEvent, oDefaultVariant) {
                let varObj = !oDefaultVariant ? oEvent.getParameter("item").getBindingContext("mroDataVariant").getObject() : oDefaultVariant,
                    sFilterString = varObj.FilterString.replace(/'/g, '"'),  // Replace single quotes around keys/values with double quotes
                    oFinalFilter = JSON.parse(sFilterString);  // Parse into JS object
                oFinalFilter.reqStartDate = oFinalFilter.reqStartDate ? new Date(oFinalFilter.reqStartDate) : null;
                oFinalFilter.reqEndDate = oFinalFilter.reqEndDate ? new Date(oFinalFilter.reqEndDate) : null;           
                sap.ui.getCore().byId("variantList").setSelectedKey(varObj.VariantGuid);
                  if (sap.ui.getCore().byId("variantList").getSelectedItem().getBindingContext("mroDataVariant").getObject().Editable === "X") {
                    sap.ui.getCore().byId("variantSave").setEnabled(true);
                } else {
                    sap.ui.getCore().byId("variantSave").setEnabled(false);
                }
                this.getView().byId("filterbar")._oBasicSearchField.setValue(oFinalFilter.globalsearch.value);
                this.variantId = varObj.VariantGuid;
                this.getView().byId("variantButton").setText(varObj.VariantName);
                this.getView().byId("variantButton").data("VariantGuid", varObj.VariantGuid);
                this.getView().getModel("variant").setData(oFinalFilter);
                this.getView().getModel("variants").setData(varObj);
                oEvent.getParameter("item").getParent().setSelectedKey(varObj.VariantGuid)
                this._setVariantData(varObj);
                this._variantFmt.close();
            },
            /**
            * Git #269  Request View Update
            * Open create new varaint dialog and set variant data
            * @function handleSavePress
            */
            handleSavePress: function () {
                var variantObj = sap.ui.getCore().byId("variantList").getSelectedItem().getBindingContext("mroDataVariant").getObject()
                this.variantGuid = true;
                this.getView().getModel("variants").setData(variantObj);
                this.getView().getModel("variants").refresh();
                this.variants.setData(variantObj);
                if (!this._newVariantFmt) {
                    this._newVariantFmt = sap.ui.xmlfragment("com.dealsupport.melodyrequest.fragments.createVariant", this);
                }
                    let oFilterString = JSON.parse(variantObj.FilterString.replace(/'/g, '"'));
                !this.getView().byId("id-filter-requester").getTokens().length ? oFilterString.reqNameId = [] : false;
                !this.getView().byId("id-filter-currentProcessor").getTokens().length ? oFilterString.taskOwnerName = [] : false;
                !this.getView().byId("id-filter-resource").getTokens().length ? oFilterString.resourceNameId = [] : false;
                !this.getView().byId("id-filter-processor").getTokens().length ? oFilterString.processorNameId = [] : false;
                !this.getView().byId("id-filter-reqSolutions").getTokens().length ? oFilterString.solutionArea = [] : false;
                !this.getView().byId("idFilterInd").getTokens().length ? oFilterString.IndData = [] : false;
                !this.getView().byId("dpCreateDate").getDateValue() ? oFilterString.reqStartDate  : null;
                !this.getView().byId("dpEndDate").getDateValue() ? oFilterString.reqEndDate  : null;
                 !this.getView().byId("id-filter-opportunityID").getTokens().length ? oFilterString.opportunity = [] : false;

                  let oVariantModel = this.getView().getModel("variant"),
                    oSearchVal = this.getView().byId("filterbar")._oBasicSearchField.getValue();
                oVariantModel.setProperty("/globalsearch/value", oSearchVal);
                if(oVariantModel.getProperty("/solutionArea") && oVariantModel.getProperty("/solutionArea").length){
                    oVariantModel.getData().solutionArea.forEach(obj => {
                       obj.levels =  obj.LevelId === 2 ? [] :[{ "soln_name": "Loading..." }];
                       delete obj.__metadata;
                    });

                }
                //update opportunity id tokens in variant model
                 let oppIdTokens = this.getView().byId("id-filter-opportunityID").getTokens();
                    let aOppKeyValue = oppIdTokens.map(item => {
                        return {
                            key:item.getText(),
                            value: item.getText()
                        };
                    });
                 this.getView().getModel("variant").setProperty("/opportunity", aOppKeyValue);

                    //update account id tokens in variant model
                 let oAccountTokens = this.getView().byId("id-filter-accountname").getTokens();
                    let aAccountKeyValue = oAccountTokens.map(item => {
                        return {
                            key:item.getKey(),
                            value: item.getText()
                        };
                    });
                 this.getView().getModel("variant").setProperty("/account", aAccountKeyValue);
                
                 //update request id tokens in variant model
                let oReqIdTokens = this.getView().byId("id-filter-reqID").getTokens();
                let aReqIdKeyValue = oReqIdTokens.map(item => {
                    return {
                        key: item.getText(),
                        value: item.getText()
                    };
                });
                this.getView().getModel("variant").setProperty("/reqId", aReqIdKeyValue);

                oVariantModel.refresh();
                
                this.getView().addDependent(this._newVariantFmt);
                this._newVariantFmt.open();
                sap.ui.getCore().byId("createVariant").setValueState("None");

            },
             /**
            * Git #269  Request View Update
            * Set variant data and filters
            * @param {object} varObj - variant context
            * @function _setVariantData
            */
            _setVariantData: function (varObj) {
                this._onResetAllFilter();
                const oStartDP = this.byId("dpCreateDate");
                const oEndDP = this.byId("dpEndDate");
                     const today = new Date();
                let oView = this.getView(),
                    oVariantModel = this.getView().getModel("variant");
             
                if( oVariantModel.getProperty("/reqStartDate")){
                      oStartDP.setDateValue(new Date( oVariantModel.getProperty("/reqStartDate")));
                      oEndDP.setMaxDate(today);
                }
                if(oVariantModel.getProperty("/reqEndDate")){
                      oEndDP.setDateValue(new Date( oVariantModel.getProperty("/reqEndDate")));
                      oEndDP.setMaxDate(today);
                }
                let oOppFilter = this.getView().byId("id-filter-opportunityID");
                oOppFilter.removeAllTokens();
                let aOpp = this.getView().getModel("variant").getProperty("/opportunity");
                let ValueHelpRangeOperation = compLibrary.valuehelpdialog.ValueHelpRangeOperation;
                if (aOpp && aOpp.length) {
                    //set opp filter tokens 
                    aOpp.forEach(function (item,iIndex) {
                        oOppFilter.addToken(new sap.m.Token({
                            key:`iIndex_${iIndex}`,
                            text: item.value
                        }).data("range", {
                            "exclude": false,
                            "operation": ValueHelpRangeOperation.EQ,
                            "keyField": "key",
                            "value1": item.value.replace(/^=/, "")
                        }));
                    });
                }
                let oReqIdFilter = this.getView().byId("id-filter-reqID");
                oReqIdFilter.removeAllTokens();
                let aReqId = this.getView().getModel("variant").getProperty("/reqId");
                if (aReqId && aReqId.length) {
                    //set req id filter tokens 
                    aReqId.forEach(function (item, iIndex) {
                        oReqIdFilter.addToken(new sap.m.Token({
                            key: `iIndex_${iIndex}`,
                            text: item.value
                        }).data("range", {
                            "exclude": false,
                            "operation": ValueHelpRangeOperation.EQ,
                            "keyField": "key",
                            "value1": item.value.replace(/^=/, "")
                        }));
                    });
                }
                let oAccIdFilter = this.getView().byId("id-filter-accountname");
                oAccIdFilter.removeAllTokens();
                let aAccId = this.getView().getModel("variant").getProperty("/account");
                if (aAccId && aAccId.length) {
                    //set acc id filter tokens 
                    aAccId.forEach(function (item, iIndex) {
                        oAccIdFilter.addToken(new sap.m.Token({
                            key: item.key,
                            text: item.value
                        }))
                    })
                }
                oVariantModel.setProperty("/reqStartDate", oStartDP.getDateValue());
                oVariantModel.setProperty("/reqEndDate", oEndDP.getDateValue());
                //Requests – In Process (Last Activity > 3 days)
                if (oVariantModel.getProperty("/inProcessLastActivityThreeDays")) {
                    const aDatesDetails = [];
                 

                    // Today
               

                    // Last 3 days (today - 3)
                    const last3Days = new Date();
                    last3Days.setDate(last3Days.getDate() - 3);

                    // Prefill values
                    oStartDP.setDateValue(last3Days);
                    oEndDP.setDateValue(today);

                    // Also limit end date to today
                    oEndDP.setMaxDate(today);
                    oVariantModel.setProperty("/reqStartDate", oStartDP.getDateValue());
                    oVariantModel.setProperty("/reqEndDate", oEndDP.getDateValue());
                    //oVariantModel.setProperty("/reqDate", aLastActivityDate);
                    let aInprocessRequestKeys = [
                        "REQFWD",
                        "WRESAP",
                        "REESUB",
                        "WSUBMN",
                        "WMNAPP",
                        "WIOAPP"
                    ]
                    oVariantModel.setProperty("/reqStatus", aInprocessRequestKeys);
                }
                //Requests – In Process (Last Activity > 7days)
                if (oVariantModel.getProperty("/inProcessLastActivitySevenDaysDays")) {
                    const oStartDP = this.byId("dpCreateDate");
                    const oEndDP = this.byId("dpEndDate");

                    // Today
                    const today = new Date();

                    // Last 7 days (today - 7)
                    const last3Days = new Date();
                    last3Days.setDate(last3Days.getDate() - 7);

                    // Prefill values
                    oStartDP.setDateValue(last3Days);
                    oEndDP.setDateValue(today);

                    // Also limit end date to today
                    oEndDP.setMaxDate(today);
                    oVariantModel.setProperty("/reqStartDate", oStartDP.getDateValue());
                    oVariantModel.setProperty("/reqEndDate", oEndDP.getDateValue());
                    let aInprocessRequestKeys = [
                        "REQFWD",
                        "WRESAP",
                        "REESUB",
                        "WSUBMN",
                        "WMNAPP",
                        "WIOAPP"
                    ]
                    oVariantModel.setProperty("/reqStatus", aInprocessRequestKeys);
                }
                //Requests – In Process (CustomDate)
                if (oVariantModel.getProperty("/activityDays")) {
                    //set custom days based on activity days
                    let iActivityDays = Number(oVariantModel.getProperty("/activityDays")),
                        aReqStatus = oVariantModel.getProperty("/reqState");

                    const dateNew = new Date();
                    dateNew.setDate(dateNew.getDate() - iActivityDays);

                    // Prefill values
                    oStartDP.setDateValue(dateNew);
                    oEndDP.setDateValue(today);

                    // Also limit end date to today
                    oEndDP.setMaxDate(today);
                    oVariantModel.setProperty("/reqStartDate", oStartDP.getDateValue());
                    oVariantModel.setProperty("/reqEndDate", oEndDP.getDateValue());
                    if(aReqStatus){
                         oVariantModel.setProperty("/reqStatus", aReqStatus);
                    }
                  
                }
                //last month date
                if (oVariantModel.getProperty("/bLastMonthData")) {
                    let  aReqStatus = oVariantModel.getProperty("/reqState");
                    // Get today's date
                    const today = new Date();

                    // Last month (0–11)
                    const lastMonth = today.getMonth() - 1;

                    // Start date of last month
                    const startDate = new Date(today.getFullYear(), lastMonth, 1);

                    // End date of last month
                    // Passing 0 as the day gives the last day of the *previous* month
                    const endDate = new Date(today.getFullYear(), today.getMonth(), 0);
                      // Prefill values
                    oStartDP.setDateValue(startDate);
                    oEndDP.setDateValue(endDate);
                    if (aReqStatus) {
                        oVariantModel.setProperty("/reqStatus", aReqStatus);
                    }

                }
                //year start date and end date
                if (oVariantModel.getProperty("/year")) {
                    const year = Number(oVariantModel.getProperty("/year"))
                    const startDate = new Date(year, 0, 1); // Jan 1
                    const endDate = new Date(year, 12, 0);  // Dec 31
                    const aReqStatus = oVariantModel.getProperty("/reqState")
                    // Prefill values
                    oStartDP.setDateValue(startDate);
                    oEndDP.setDateValue(endDate);
                    if (aReqStatus) {
                        oVariantModel.setProperty("/reqStatus", aReqStatus);
                    }
                }

                this.onStartDateChange();

                let aFilterList = [];
              
              
                this.getView().getModel("employee").refresh();
                //set filter labels based on selection
                oView.byId("filterbar")._oBasicSearchField.getValue() && aFilterList.push("Search");
                oView.byId("dpCreateDate").getDateValue() && aFilterList.push(oView.byId("dpCreateDate").getParent().getParent().getLabel());
                oView.byId("dpEndDate").getDateValue() && aFilterList.push(oView.byId("dpEndDate").getParent().getParent().getLabel());
                oView.byId("id-filter-reqID").getTokens().length && aFilterList.push(oView.byId("id-filter-reqID").getParent().getLabel());
                oView.byId("id-filter-reqType").getSelectedItems().length && aFilterList.push(oView.byId("id-filter-reqType").getParent().getLabel());
                oView.byId("id-filter-opportunityID").getTokens().length && aFilterList.push(oView.byId("id-filter-opportunityID").getParent().getLabel());
                oView.byId("id-filter-currentState").getSelectedItems().length && aFilterList.push(oView.byId("id-filter-currentState").getParent().getLabel());
                oView.byId("id-filter-role").getSelectedItems().length && aFilterList.push(oView.byId("id-filter-role").getParent().getLabel());
                if (oVariantModel.getProperty("/solutionArea") && oVariantModel.getProperty("/solutionArea").length) {
                    this.getView().getModel("employee").setProperty("/TempEmployee/SolutionAreas", oVariantModel.getProperty("/solutionArea"))
                    aFilterList.push(oView.byId("id-filter-reqSolutions").getParent().getLabel());
                    let aSolutionAreas =  this.getView().getModel("employee").getData().TempEmployee.SolutionAreas;
                     this.getView().getModel("employee").setProperty("/solutionForFilter",aSolutionAreas)
                } else {
                    this.getView().getModel("employee").setProperty("/TempEmployee/SolutionAreas", [])
                }
                if (oVariantModel.getProperty("/IndData") && oVariantModel.getProperty("/IndData").length) {
                    this.getView().getModel("employee").setProperty("/TempEmployee/BAIndustries", oVariantModel.getProperty("/IndData"))
                    this.getView().getModel("employee").refresh();
                    aFilterList.push(oView.byId("idFilterInd").getParent().getLabel());
                } else {
                    this.getView().getModel("employee").setProperty("/TempEmployee/BAIndustries", [])
                }
                oView.byId("id-filter-requester").getTokens().length && aFilterList.push(oView.byId("id-filter-requester").getParent().getLabel());
                oView.byId("id-filter-processor").getTokens().length && aFilterList.push(oView.byId("id-filter-processor").getParent().getLabel());
                oView.byId("id-filter-resource").getTokens().length && aFilterList.push(oView.byId("id-filter-resource").getParent().getLabel());
                oView.byId("id-filter-accountname").getTokens().length && aFilterList.push(oView.byId("id-filter-accountname").getParent().getLabel());  
                oView.byId("id-filter-task").getSelectedItems().length && aFilterList.push(oView.byId("id-filter-task").getParent().getLabel());
                oView.byId("id-filter-currentProcessor").getTokens().length && aFilterList.push(oView.byId("id-filter-currentProcessor").getParent().getLabel());
                oView.byId("id-filter-taskRole").getSelectedItems().length && aFilterList.push(oView.byId("id-filter-taskRole").getParent().getLabel());
              
                if (aFilterList.length > 0) {
                    this.byId("expandendContent").setText("Filtered By (" + aFilterList.length + "): " + aFilterList.join(", "));
                    this.byId("snappedContent").setText("Filtered By (" + aFilterList.length + "): " + aFilterList.join(", "));
                } else {
                    this.byId("expandendContent").setText("Filtered By: None");
                    this.byId("snappedContent").setText("Filtered By: None");
                }
                if (varObj.ExecuteOnSelect) {
                    this.onFilter();
                }
                if(oStartDP.getDateValue()){
                    this.getView().byId("idClearStartDate").setVisible(true);
                }else{
                      this.getView().byId("idClearStartDate").setVisible(false);
                }
                  if(oEndDP.getDateValue()){
                    this.getView().byId("idClearEndDate").setVisible(true);
                }else{
                     this.getView().byId("idClearEndDate").setVisible(false);
                }

            },
            onClearFilters: function () {
                var oView = this.getView();
                oView.byId("filterbar")._oBasicSearchField.setValue("");
                oView.byId("id-filter-currentState").setSelectedItems("");
                oView.byId("id-filter-reqType").setSelectedItems("");
                oView.byId("id-filter-opportunityID").removeAllTokens();
                oView.byId("id-filter-reqID").removeAllTokens();
                oView.byId("id-filter-accountname").removeAllTokens();
                oView.byId("id-filter-requester").removeAllTokens();
                oView.byId("id-filter-currentProcessor").removeAllTokens();
                oView.byId("id-filter-task").setSelectedItems("");
                oView.byId("id-filter-reqType").setSelectedItems("");
                oView.byId("id-filter-taskRole").setSelectedItems("");
                oView.byId("id-filter-processor").removeAllTokens();
                oView.byId("id-filter-resource").removeAllTokens();
                oView.byId("dpCreateDate").setDateValue(null);
                oView.byId("dpEndDate").setDateValue(null);

            },
              /**
            * Git #269  Request View Update
            * Clear Start and end date of creation date filter
            * @param {object} oEvent - Start and end date scope
            * @function onClearDate
            */
            onClearDate:function(oEvent){
                if(oEvent.getSource().getId().includes("idClearStartDate")){
                    this.getView().byId("idClearStartDate").setVisible(false);
                    this.getView().byId("dpCreateDate").setDateValue(null);
                }
                 if(oEvent.getSource().getId().includes("idClearEndDate")){
                    this.getView().byId("idClearEndDate").setVisible(false);
                    this.getView().byId("dpEndDate").setDateValue(null);
                }
            },
            onDisplayAddSlnsPopOver: function (oEvent) {
                let oLink = oEvent.getSource(),
                    oView = this.getView(),
                    aSolutions = oEvent.getSource().getBindingContext("wfHistoryModel").getObject()._Solution,
                    oModel = new sap.ui.model.json.JSONModel(),
                    that = this;
                oModel.setData({
                    // addSlns : aSolutions && aSolutions.filter(item => item.is_MainSoln).length ? aSolutions.filter(item => item.is_MainSoln):[],
                    addSlns: aSolutions && aSolutions.filter(item => !item.is_MainSoln).length ? aSolutions.filter(item => !item.is_MainSoln) : [],
                });
                this.getView().setModel(oModel, "addSlnInfModel");
                // create popover
                if (!this._pAddSlnPopover) {
                    this._pAddSlnPopover = Fragment.load({
                        id: oView.getId(),
                        name: "com.dealsupport.melodyrequest.fragments.additionalSolnsPopOver",
                        controller: this
                    }).then(function (oPopover) {
                        that.addInfoPopOver = oPopover;
                        oView.addDependent(oPopover);
                        return oPopover;
                    });
                }
                this._pAddSlnPopover.then(function (oPopover) {
                    oPopover.openBy(oLink);
                });

            },
            onCloseAddSlnPopOverOverInfo: function () {
                this.addInfoPopOver.close();
            },
            onInfoOppPress: function (oEvent) {
                let oInfoIcon = oEvent.getSource(),
                    oView = this.getView(),
                    that = this;
                // create popover
                if (!this._pOppInfoPopover) {
                    this._pOppInfoPopover = Fragment.load({
                        id: oView.getId(),
                        name: "com.dealsupport.melodyrequest.fragments.oppInfoPopver",
                        controller: this
                    }).then(function (oPopover) {
                        that.oOppInfoPopOver = oPopover;
                        oView.addDependent(oPopover);
                        // oPopover.bindElement("/ProductCollection/0");
                        return oPopover;
                    });
                }
                this.sOppId = oEvent.getSource().getBindingContext("wfHistoryModel").getObject().OpportunityID;
                this._pOppInfoPopover.then(function (oPopover) {
                    oPopover.setBusyIndicatorDelay(0);
                    oPopover.setBusy(true);
                    that.getView().getModel("oppInfoPopOverModel").refresh();
                    oPopover.openBy(oInfoIcon);
                });
            },
            onCloseOppPopOverInfo: function () {
                if (this.oOppInfoPopOver) {
                    this.oOppInfoPopOver.close();
                }
            },
            onLoadOppInfo: function () {
                models.getMyOpportunitiesIO(this, this.sOppId, "oppInfoPopOver");

            },
             /**
            * Git #269  Request View Update
            * Show activity popover on click of activity button
            * @param {object} oEvent - Activity button context
            * @function onShowActivityPopOver
            */
            onShowActivityPopOver: function (oEvent) {
                let oInfoButton = oEvent.getSource(),
                    oView = this.getView(),
                    that = this;
                // create popover
                this.activityContext = oEvent.getSource().getBindingContext("wfHistoryModel").getObject();
                if (!this._pActivityInfoPopover) {
                    this._pActivityInfoPopover = Fragment.load({
                        id: oView.getId(),
                        name: "com.dealsupport.melodyrequest.fragments.activityListPopOver",
                        controller: this
                    }).then(function (oPopover) {
                        that.oActVityInfoPopOver = oPopover;
                        oView.addDependent(oPopover);
                        // oPopover.bindElement("/ProductCollection/0");
                        return oPopover;
                    });
                }
                let sInstanceID = oEvent.getSource().getBindingContext("wfHistoryModel").getObject().InstanceID;
                this.common = Common;
                let oModel = new sap.ui.model.json.JSONModel();
                this.sInstanceID = sInstanceID;
                this.getView().setModel(oModel, "activityInfoModel");
                this._pActivityInfoPopover.then(function (oPopover) {
                    oPopover.setBusyIndicatorDelay(0);
                    oPopover.setBusy(true);
                    oPopover.openBy(oInfoButton);
                });
            },
            onCloseActivityPopOverInfo: function () {
                this.oActVityInfoPopOver.close()
            },
              /**
            * Git #269  Request View Update
            * Call activity service and set activity model
            * @function onLoadActivityInfo
            */
            onLoadActivityInfo: function () {
                if ( this.activityContext && (this.activityContext.currentStateID === "WRESAP" || this.activityContext.TechnicalStateID === "COMP")) {
                    //Call context and activity service only for task waiting for resource approval or complete
                    models._getGetWfContextDetails(this, this.sInstanceID, this.fnSuccessGetContextDetails);
                    this.getView().getModel("oppInfoPopOverModel").refresh();
                }else{
                     this.oActVityInfoPopOver.setBusy(false);
                }
            },
             /**
            * Git #269  Request View Update
            * Success call back for context service
            * @param {object} result -response
            * @param {object} that -controller scope
            * @function fnSuccessGetContextDetails
            */
            fnSuccessGetContextDetails: function (result, that) {
                let oAssignments = {
                    "assignments": []
                };

                const oModel = new sap.ui.model.json.JSONModel(oAssignments);
                that.getView().setModel(oModel, "assignmentsModel");
                let oAssignmentData = result.AssignmentApprove ? result.AssignmentApprove : result.Assignment;
                if (oAssignmentData) {
                    oAssignments.assignments = Common._setResourceAssignment(oAssignmentData, that);
                    models._callActivityTempDataService(that, false, "GET", true);

                    let aAssignmentData = oAssignments.assignments,
                        bIsNoActivityRegister = aAssignmentData.every(val => !val.enableActivityRegister),
                        aActivities = [];
                    if (!bIsNoActivityRegister) {
                        aActivities = that.getView().getModel("activityTempModel").getData().value.length ? that.getView().getModel("activityTempModel").getData().value : aAssignmentData.map(obj => obj.activityLists).flat();
                        that._getActivityData(aActivities)

                    } else {
                        that.oActVityInfoPopOver.setBusy(false);
                    }
                } else {
                    that.oActVityInfoPopOver.setBusy(false);
                }


            },
              /**
            * Git #269  Request View Update
            * Final call for activity
            * @param {array} aActivities -activity payload
            * @function aActivities
            */
            _getActivityData: function (aActivities) {
                const aActivityData = aActivities.map(item => item.activity_GUID || item.ActivityGuid);
                const sFilterCondition = `(${aActivityData.map(actGuid => `(ActivityGuid eq guid'${actGuid}')`).join(' or ')})`,
                    sUrlParams = {
                        $filter: `${sFilterCondition}`,
                        $select: `ActivityId,ActivityGuid`
                    }
                let aActivityFormLayout = [];
                const oIntLSModel = models.systemActivityDataModel(this),
                    that = this;
                this.getView().getModel("assignmentsModel").setProperty("/cardBusy", true);
                this.getView().getModel("assignmentsModel").refresh();
                models._callGETOdata(oIntLSModel, `/Yc_Mac_T_Act_Main`, sUrlParams).
                    then(function (data) {
                        this.getView().getModel("assignmentsModel").setProperty("/cardBusy", false);
                        this.getView().getModel("assignmentsModel").refresh();
                        if (data.results.length) {
                            // Sort by the 'ActivityId' property, which is a string representation of a number
                             data.results.sort((a, b) => {
                                const numA = parseInt(a.ActivityId, 10); // Parse string to integer
                                const numB = parseInt(b.ActivityId, 10); // Parse string to integer

                                return numA - numB; // Compare the numeric values
                            });
                            that.getView().getModel("activityInfoModel").setProperty("/aAllActivities", data.results);

                        }
                        that.oActVityInfoPopOver.setBusy(false);
                    }.bind(that))
                    .catch(function (oError) {
                        that.oActVityInfoPopOver.setBusy(false);
                        ErrorHandle.setErrorMessage(oError, that);
                    });
            },
            onOpenSolutionHierarchy: async function (oEvent) {

                const that = this;
                //     aSLAMasterData = this.getOwnerComponent().getModel("SLAMasterDataL1").getData().results;
                // that.getView().setModel(new sap.ui.model.json.JSONModel(), "masterDataModel");
                // const oMasterDataModel = that.getView().getModel("masterDataModel");
                // if (this.oSLASearchContext) {
                //     this.getView().getModel("employee").setProperty(`/TempEmployee/SolutionAreas`, this.oSLASearchContext)
                // }
                // if (this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`)) {
                //     this.oSLASearchContext = JSON.parse(JSON.stringify(this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`)));
                // }
                // if (this.oSearchAddSlnContext) {
                //     this.getView().getModel("employee").setProperty(`/TempEmployee/AdditionalSolutions`, this.oSearchAddSlnContext)
                // }
                // if (this.getView().getModel("employee").getProperty(`/TempEmployee/AdditionalSolutions`)) {
                //     this.oSearchAddSlnContext = JSON.parse(JSON.stringify(this.getView().getModel("employee").getProperty(`/TempEmployee/AdditionalSolutions`)));
                // }

                // oMasterDataModel.setData(that.getView().getModel("employee"));
                // oMasterDataModel.refresh();
                // this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas", []);
                // if (!this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas/0`)) {
                //     //set defualy solution area L1
                //     //this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/selectedSolAreaL1",aSLAMasterData[0].SolGuid);
                //     this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas", aSLAMasterData);
                //     this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA", false)
                // } else if (this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas/0`)) {
                //     //set selected solution area L1
                //     this.oContextSolutionArea = this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas/0`);
                //     this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/selectedSolAreaL1",
                //         this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas/0/soln_prnt_guid`));
                //     this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas", this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`));
                //     this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA", true)
                // }
                // that.getView().getModel("employee").setProperty(`/TempEmployee/slaBusy`, false);
                // if (that.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`)) {
                //     that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas", that.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`));
                // }


                // this.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
                // this.getView().getModel("employee").refresh();
                // // this.getView().getModel("employee").setProperty(`/TempEmployee/slaBusy`,true);

                let oModel = this.getOwnerComponent().getModel("SolutionAreaMasterData")
                this.getView().getModel("employee").setProperty("/isFilter", true);
                   this.getView().getModel("employee").refresh();
                if (!this.solutionHierarchyDialogForward) {
                   // models.getSolutionAreaMasterData(this)
                    this.solutionHierarchyDialogForward = this.loadFragment({
                        name: "com.dealsupport.melodyrequest.fragments.resourceProfile.SolutionHierarchy",
                    });

                }
                    
                // this.solutionHierarchyDialogForward.open()
                this.solutionHierarchyDialogForward.then(function (oDialog) {
                      if (that.onSearchln) {
                        that.onSearchln = false;
                        models.getSolutionAreaMasterData(that, true);
                    }   
                   
                    that.SADialog = oDialog;
                    oModel.setProperty("/materialsContainerVisible", false);
                    that.byId("idSlnTree").getContent()[0].addStyleClass("styleSlnTreeScroll");
                    that.byId("idSlnFormGrid").addStyleClass("customStyleSlnSmallGrid");
                    that.byId("idSlnFormGrid").removeStyleClass("customStyleSlnGrid");
                    that.byId("idSlnTree").setDefaultSpan("XL12 L12 M12 S12");
                    that.byId("idSlnToolbarGrid").setDefaultSpan("XL12 L12 M12 S12");
                    //change by rk

                    oDialog.setContentWidth("52%")
                    oDialog.open()
                    // oModel.setProperty("/materials", [])
                    // oModel.setProperty("/displayTokensMaterial", [])
                    // oModel.setProperty("/displayTokensAdditionalSolution", [])
                    // let prevSelData = that.getView().getModel("employee").getProperty(`/TempEmployee`)
                    // let prevSelSolArea = prevSelData.SolutionAreas ? prevSelData.SolutionAreas : []

                    // var solHierarchyMap = oModel.getProperty("/solHierarchyMap")
                    // if (prevSelSolArea.length > 0) {
                    //     if (prevSelSolArea[0].soln_prnt_guid == '00000000-0000-0000-0000-000000000000') {
                    //         oModel.setProperty("/selectedLevel1Guid", prevSelSolArea[0].soln_guid)
                    //         oModel.setProperty("/showDisplayMaterials", false)
                    //         let mMaterialMap = oModel.getProperty("/materialMap") ? oModel.getProperty("/materialMap") : [];
                    //         mMaterialMap.forEach((arr, key) => {
                    //             arr.forEach(value => {
                    //                 value.selected = false
                    //             })
                    //         })
                    //         oModel.setProperty("/materials", [])
                    //         oModel.setProperty("/displayTokensMaterial", [])
                    //         oModel.setProperty("/displayTokensAdditionalSolution", [])
                    //         that.onChangeDisplayFullSolHierarchy(false)
                    //         // var foundL1 = aSolnL1Data.find(item => item.soln_guid == prevSelSolArea[0].soln_guid)
                    //         // models._loadChildren(this, foundL1, null, true)


                    //     } else {
                    //         let aAddSlns = that.getView().getModel("employee").getProperty(`/TempEmployee/AdditionalSolutions`) ? that.getView().getModel("employee").getProperty(`/TempEmployee/AdditionalSolutions`) : []
                    //         oModel.setProperty("/displayTokensAdditionalSolution", aAddSlns)
                    //         oModel.setProperty("/selectedLevel1Guid", prevSelSolArea[0].soln_prnt_guid)
                    //         oModel.setProperty("/selectedLevel2Id", prevSelSolArea[0].soln_guid)
                    //         oModel.setProperty("/showDisplayMaterials", true)
                    //         let mMaterialMap = oModel.getProperty("/materialMap") ? oModel.getProperty("/materialMap") : [];
                    //         mMaterialMap.forEach((arr, key) => {
                    //             arr.forEach(value => {
                    //                 value.selected = false
                    //             })
                    //         })
                    //         oModel.setProperty("/materials", [])
                    //         oModel.setProperty("/displayTokensMaterial", [])

                    //         // var foundL1 = aSolnL1Data.find(item => item.soln_guid == prevSelSolArea[0].soln_prnt_guid)
                    //         // models._loadChildren(this, foundL1, null, true,prevSelSolArea[0].soln_guid)
                    //         let bFillSol = aAddSlns && aAddSlns.length ? true : false;
                    //         if (bFillSol) {
                    //             that.SADialog.getContent()[0].getContent()[0].getItems()[0].getItems()[0].setState(true);
                    //         } else {
                    //             that.SADialog.getContent()[0].getContent()[0].getItems()[0].getItems()[0].setState(false);
                    //         }
                    //         that.onChangeDisplayFullSolHierarchy(bFillSol)
                    //     }


                    //     // if (prevSelAddSol.length > 0 || prevSelMaterial.length > 0) {
                    //     // 	oModel.setProperty("/showDisplayMaterials", true)
                    //     // } else {
                    //     // 	oModel.setProperty("/showDisplayMaterials", false)
                    //     // }
                    //     // if(prevSelAddSol.length>0) 
                    //     // 	models._loadChildren(this,oSelGuid,oEvent,false)
                    // } else {
                    //     // oModel.setProperty("/selectedLevel1Guid", aSolnL1Data[0].SolGuid)
                    //     oModel.setProperty("/showDisplayMaterials", false)
                    //     let mMaterialMap = oModel.getProperty("/materialMap") ? oModel.getProperty("/materialMap") : [];
                    //     mMaterialMap.forEach((arr, key) => {
                    //         arr.forEach(value => {
                    //             value.selected = false
                    //         })
                    //     })
                    //     oModel.setProperty("/materials", [])
                    //     oModel.setProperty("/displayTokensMaterial", [])
                    //     oModel.setProperty("/displayTokensAdditionalSolution", [])
                    //     oModel.refresh();
                    // }
                    // oModel.refresh();
                    let aSolutionAreas =  that.getView().getModel("employee").getData().TempEmployee.SolutionAreas,
                        aSolutionMasterData = that.getOwnerComponent().getModel("SolutionAreaMasterData").getData(),
                        aSelectedSla = [];
                    aSolutionMasterData.solHierarchy.forEach(function(item){
                        let aFilteredSln = aSolutionAreas.filter(val=>val.soln_guid === item.soln_guid)
                        if(aFilteredSln.length){
                            item.selected = true;
                            aSelectedSla.push(item)
                        }
                    })  
                    that.getView().getModel("employee").setProperty("/solutionForFilter",aSolutionAreas)
                    let aSolutionFilter = that.getView().getModel("employee").getProperty("/solutionForFilter");
                    aSolutionFilter.forEach(function (item) {
                        if (item.LevelId === 2) {
                            let sParentGuid = item.soln_prnt_guid;
                            aSolutionMasterData.solHierarchy.forEach(function (sol) {
                                if (sol.soln_guid === sParentGuid) {
                                    sol.selected = true;
                                    sol.partialSelection = !sol.selected 
                                }
                            })
                        }
                    })

                    //that.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/solutionForFilter",aSolutionAreas)
                    that.getOwnerComponent().getModel("SolutionAreaMasterData").refresh();
                    that.tempSelectedSolution =JSON.parse(JSON.stringify( that.getView().getModel("employee").getProperty("/solutionForFilter")));
                });
            },

            onChangeDisplayFullSolHierarchy: function (oEvent) {
                this.getView().byId("idSolutionTree").collapseAll();
                this.bDisableExpandAPICall = false;
                const solutionAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData");
                solutionAreaDataModel.setProperty("/isSolDialogBusy", true)
                solutionAreaDataModel.refresh();
                let solHierarchy = solutionAreaDataModel.getProperty("/solHierarchy");
                let solHierarchyMap = solutionAreaDataModel.getProperty("/solHierarchyMap");
                let materialMap = solutionAreaDataModel.getProperty("/materialMap") ? solutionAreaDataModel.getProperty("/materialMap") : [];
                let displayTokensMaterial = solutionAreaDataModel.getProperty("/displayTokensMaterial");
                let materials = solutionAreaDataModel.getProperty("/materials");
                if (typeof (oEvent) == 'object')
                    var bShowFullSolHierarchy = oEvent.getParameter("state");
                else {
                    var bShowFullSolHierarchy = oEvent
                }

                let that = this;
                setTimeout(function () {
                    if (!bShowFullSolHierarchy) {
                        solutionAreaDataModel.setProperty("/displayTokensAdditionalSolution", []);
                        solutionAreaDataModel.setProperty("/displayTokensMaterial", []);
                        solutionAreaDataModel.setProperty("/materialsContainerVisible", false);
                        that.byId("idSlnFormGrid").addStyleClass("customStyleSlnSmallGrid");
                        //that.byId("idSlnFormGrid").removeStyleClass("customStyleSlnGrid");
                        that.byId("idSlnTree").setDefaultSpan("XL12 L12 M12 S12");
                        that.byId("idSlnToolbarGrid").setDefaultSpan("XL12 L12 M12 S12");
                        that.byId("idSlnTree").getContent()[0].addStyleClass("styleSlnTreeScroll")
                        that.SADialog.setContentWidth("52%")
                        if (solHierarchyMap) {
                            solHierarchyMap.forEach((item, key) => {

                                if (item.LevelId == 3) {
                                    item.selected = false

                                    item.partialSelection = false
                                } else if (item.LevelId == 4) {
                                    item.selected = false
                                } else if (item.LevelId == 5) {
                                    item.selected = false
                                }
                            })
                        }
                    }
                    solHierarchy.forEach(item => {
                        if (item.levels.length && item.levels[0].soln_guid) {
                            item.levels.forEach(l2children => {
                                l2children.levels = bShowFullSolHierarchy ? [{ "soln_name": "Loading..." }] : []
                            })
                        }
                    })
                    solutionAreaDataModel.setProperty("/isSolDialogBusy", false)
                    solutionAreaDataModel.refresh();
                }, 1200);


            },
            onSearchSlnHierachy: function (evt) {
                this.onSearchln = true;
                Common.onSearchSlnHierachy(evt, this)
            },
            onExpandHierarchy: function (oEvent) {
                const oSelGuid = oEvent.getParameter("itemContext").getObject()
                var oSolAreaDataModel=this.getOwnerComponent().getModel("SolutionAreaMasterData")
                var solHierarchy = oSolAreaDataModel.getProperty("/solHierarchy")
                var bChildrenLoaded=false
                solHierarchy.forEach(obj=>{
                    if(obj.soln_guid === oSelGuid.soln_guid && obj.levels.length && obj.levels[0].soln_guid ){
                        bChildrenLoaded=true
                    }
                })
               
                if (oEvent.getParameter("expanded") && !this.bDisableExpandAPICall && !bChildrenLoaded)
                    models._loadChildren(this, oSelGuid, oEvent, false)
            },
            //when L1,L2 radio button is selected in new solution hierarchy
            onSolAreaRadioSelect: function (oEvent) {
                const oSolAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData"),
                    aAddSolns = oSolAreaDataModel.getProperty("/displayTokensAdditionalSolution") ? oSolAreaDataModel.getProperty("/displayTokensAdditionalSolution") : [],
                    sSelectedLv1Id = oSolAreaDataModel.getProperty("/selectedLevel1Guid"),
                    sSelectedLevel2Id = oSolAreaDataModel.getProperty("/selectedLevel2Id");
                if (aAddSolns.length) {
                    let sContextSelectedId = oEvent.getSource().getBindingContext("SolutionAreaMasterData").getObject().soln_guid;
                    this.prevRadioSelect = (sSelectedLevel2Id === sContextSelectedId) || (sSelectedLv1Id === sContextSelectedId) ? oEvent : this.prevRadioSelect;
                    if (!((sSelectedLevel2Id === sContextSelectedId) || (sSelectedLv1Id === sContextSelectedId))) {
                        this.prevRadioSelect.getSource().setSelected(true);
                        oEvent.getSource().setSelected(false);
                        this.newRadioSelect = oEvent;
                    }
                    if (this.newRadioSelect) {
                        Common._onOpenSolutionSelectConfimDialog(this);

                    }
                } else {
                    this.onSolAreaRadioSelectConfirm(oEvent)
                }


            },
            //when L1,L2 radio button is selected in new solution hierarchy
            onSolAreaRadioSelectConfirm: function (oEvent) {
                this.getOwnerComponent().getModel("SolutionAreaMasterData").refresh()
                this.getOwnerComponent().getModel("SolutionAreaMasterData").refresh();
                if (oEvent.getParameter("selected")) {
                    let selectedRadioItem = oEvent.getSource().getBindingContext("SolutionAreaMasterData").getObject()
                    const oSolAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData")
                    let solHierarchy = oSolAreaDataModel.getProperty("/solHierarchy")
                    this.clearSASelection(solHierarchy)
                    if (selectedRadioItem.LevelId == 1) {
                        oSolAreaDataModel.setProperty("/selectedLevel1Guid", selectedRadioItem.soln_guid)
                        oSolAreaDataModel.setProperty("/selectedLevel2Id", null)
                        oSolAreaDataModel.setProperty("/materials", [])
                        oSolAreaDataModel.setProperty("/displayTokensMaterial", [])
                        oSolAreaDataModel.setProperty("/displayTokensAdditionalSolution", [])
                        let mMaterialMap = oSolAreaDataModel.getProperty("/materialMap") ? oSolAreaDataModel.getProperty("/materialMap") : [];
                        mMaterialMap.forEach((arr, key) => {
                            arr.forEach(value => {
                                value.selected = false
                            })
                        })
                        const solutionTree = this.byId("idSolutionTree")
                        solutionTree.removeSelections();
                        models.getMaterials(this, selectedRadioItem, true);
                    } else {


                        oSolAreaDataModel.setProperty("/selectedLevel1Guid", selectedRadioItem.soln_prnt_guid)
                        let mMaterialMap = oSolAreaDataModel.getProperty("/materialMap") ? oSolAreaDataModel.getProperty("/materialMap") : [];
                        oSolAreaDataModel.setProperty("/selectedLevel2Id", selectedRadioItem.soln_guid)
                        oSolAreaDataModel.setProperty("/displayTokensMaterial", [])
                        oSolAreaDataModel.setProperty("/displayTokensAdditionalSolution", [])
                        oSolAreaDataModel.setProperty("/materials", [])
                        mMaterialMap.forEach((arr, key) => {
                            arr.forEach(value => {
                                value.selected = false
                            })
                        })
                        models.getMaterials(this, selectedRadioItem, true)
                    }
                }
            },
            clearSASelection: function (solHierarchy) {
                solHierarchy.forEach(function (obj) {
                    obj.selected = false
                    if (obj.LevelId == 3)
                        obj.partialSelection = false
                    if (obj.levels.length && obj.levels[0].soln_guid) {
                        this.clearSASelection(obj.levels)
                    }
                }.bind(this))
            },
            //when L3,L4 is selected in new solution hierarchy
            onSelectSolution: function (oEvent) {
                let bIsSelected = oEvent.getSource().getSelected()
                let oSelectedRow = oEvent.getSource().getBindingContext('SolutionAreaMasterData').getObject()
                let solutionAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData");
                this.onL3L4Select(oEvent, oSelectedRow, bIsSelected, solutionAreaDataModel)
                models.getMaterials(this, oSelectedRow, bIsSelected);



            },
            //function to implement selection logic of L3,L4 and filtering of selected add sol tokens
            onL3L4Select: function (oEvent, oSelectedRow, bIsSelected, solutionAreaDataModel, bIsConfirm) {
                let solHierarchyMap = solutionAreaDataModel.getProperty("/solHierarchyMap")
                var solHierarchy = solutionAreaDataModel.getProperty("/solHierarchy")
                var mMaterialMap = solutionAreaDataModel.getProperty("/materialMap") ? solutionAreaDataModel.getProperty("/materialMap") : [];
                var materials = solutionAreaDataModel.getProperty("/materials")
                var displayTokensMaterial = [];
                var displayTokensAdditionalSolution = solutionAreaDataModel.getProperty("/displayTokensAdditionalSolution") ? solutionAreaDataModel.getProperty("/displayTokensAdditionalSolution") : [];
                var tokensToBeAdded = []
                var tokensToBeRemoved = []
                var materialTokensToBeRem = []
                let bIsDifferntL2;
                if (oEvent && !bIsConfirm && displayTokensAdditionalSolution && displayTokensAdditionalSolution.length) {
                    const sSelectedLevel2Id = solutionAreaDataModel.getProperty("/selectedLevel2Id"),
                        oBindingContext = oEvent.getSource().getBindingContext("SolutionAreaMasterData").getObject();
                    bIsDifferntL2 = sSelectedLevel2Id && !oBindingContext.full_sol_guid.includes(sSelectedLevel2Id);
                    if (bIsDifferntL2) {
                        oEvent.getSource().setSelected(false);
                        Common._onOpenSolutionSelectConfimDialog(this, oEvent, oSelectedRow, bIsSelected, solutionAreaDataModel);

                    }
                }
                if (!bIsDifferntL2) {
                    let tempParent = solHierarchyMap.get(oSelectedRow.soln_prnt_guid)
                    var aGuids = []
                    aGuids.push(oSelectedRow.soln_prnt_guid)
                    while (tempParent && tempParent.LevelId != 1) {
                        tempParent = solHierarchyMap.get(tempParent.soln_prnt_guid)
                        aGuids.push(tempParent.soln_guid)
                    }
                    aGuids.reverse()
                    var oL1;
                    var oL2;
                    var oL3;
                    let oL4;
                    solHierarchy.forEach(sol => {
                        if (sol.soln_guid && sol.soln_guid == aGuids[0]) {
                            oL1 = sol
                            sol.levels.forEach(child => {
                                if (child.soln_guid && child.soln_guid == aGuids[1]) {
                                    oL2 = child
                                    if (child.levels && child.levels.length) {
                                        child.levels.forEach(l3child => {
                                            if (l3child.soln_guid && l3child.soln_guid == aGuids[2]) {
                                                oL3 = l3child
                                            }
                                            if (l3child.levels && l3child.levels.length) {
                                                l3child.levels.forEach(l4child => {
                                                    if (l4child.soln_guid && l4child.soln_guid == aGuids[3]) {
                                                        oL4 = l4child
                                                    }
                                                });
                                            }


                                        })
                                    }
                                }

                            })
                        }
                    })

                    var currentL1 = solutionAreaDataModel.getProperty("/selectedLevel1Guid")
                    var currentL2 = solutionAreaDataModel.getProperty("/selectedLevel2Id")
                    if (oL1 && currentL1 != null && currentL1 != oL1.soln_guid) {
                        materials = []
                        displayTokensMaterial = []
                        displayTokensAdditionalSolution = []
                        mMaterialMap.forEach((arr, key) => {
                            arr.forEach(value => {
                                value.selected = false
                            })
                        })
                        if (mMaterialMap.get(currentL1))
                            materialTokensToBeRem.push(...mMaterialMap.get(currentL1))
                        if (mMaterialMap.get(currentL2))
                            materialTokensToBeRem.push(...mMaterialMap.get(currentL2))
                        oL1.selected = true
                        oL2.selected = true


                    }
                    //checking if the new L3,L4 selection is from a different L2 or not
                    else if (currentL2 != null && oL2 && currentL2 != oL2.soln_guid) {
                        materials = []
                        // displayTokens=[]
                        displayTokensMaterial = displayTokensMaterial.filter(each => each.triggeredBy == oL2.soln_prnt_guid)
                        displayTokensAdditionalSolution = displayTokensAdditionalSolution.filter(each => each.triggeredBy == oL2.soln_prnt_guid)
                        mMaterialMap.forEach((arr, key) => {
                            arr.forEach(value => {
                                if (value.triggeredBy != oL2.soln_prnt_guid)
                                    value.selected = false
                            })
                        })
                        if (mMaterialMap.get(currentL2))
                            materialTokensToBeRem.push(...mMaterialMap.get(currentL2))
                        oL2.selected = true
                        // solutionAreaDataModel.setProperty("/selectedLevel2Id",oL2.soln_guid)
                    }
                    if (oL1) {
                        solutionAreaDataModel.setProperty("/selectedLevel1Guid", oL1.soln_guid)
                    }
                    if (oL2) {
                        solutionAreaDataModel.setProperty("/selectedLevel2Id", oL2.soln_guid)
                    }

                    solHierarchy.forEach(function (level1Master) {
                        if (level1Master.levels.length && level1Master.levels[0].soln_guid) {
                            level1Master.levels.forEach(level2Master => {
                                if (level2Master.soln_guid != oL2.soln_guid) {
                                    level2Master.selected = false
                                    if (level2Master.levels.length && level2Master.levels[0].soln_guid) {
                                        level2Master.levels.forEach(level3Master => {
                                            level3Master.selected = false
                                            level3Master.partialSelection = false
                                            if (level3Master.levels.length && level3Master.levels[0].soln_guid) {
                                                level3Master.levels.forEach(level4Master => {
                                                    level4Master.selected = false
                                                    if (level4Master.levels.length && level4Master.levels[0].soln_guid) {
                                                        level4Master.levels.forEach(level5Master => {
                                                            level5Master.selected = false;
                                                        });
                                                    }
                                                })
                                            }


                                        })
                                    }
                                }
                            })
                        }

                    })
                    if (oSelectedRow.LevelId == 3) {
                        oSelectedRow.selected = bIsSelected
                        bIsSelected ? tokensToBeAdded.push(oSelectedRow) : tokensToBeRemoved.push(oSelectedRow)
                        oSelectedRow.partialSelection = false
                        oSelectedRow.explicitlySelected = bIsSelected
                    }
                    if (oSelectedRow.LevelId == 4) {
                        oSelectedRow.selected = bIsSelected
                        bIsSelected ? tokensToBeAdded.push(oSelectedRow) : tokensToBeRemoved.push(oSelectedRow)
                        var aL3Level = oL3 ? oL3.levels : [];
                        var isSelectedCount = aL3Level.filter(c => c.selected).length;
                        if (oL3) {
                            oL3.selected = true
                        }
                        if (isSelectedCount == 0) {
                            if (oL3 && !oL3.explicitlySelected) {
                                oL3.selected = false
                                oL3.partialSelection = false
                            }


                        } else if (isSelectedCount == aL3Level.length) {
                            oL3.selected = true
                            oL3.partialSelection = false
                        } else {
                            if (oL3) {
                                oL3.partialSelection = true
                            }
                        }
                    }
                    if (oSelectedRow.LevelId == 5) {
                        oSelectedRow.selected = bIsSelected;
                        bIsSelected ? tokensToBeAdded.push(oSelectedRow) : tokensToBeRemoved.push(oSelectedRow)
                        var aL4Level = oL4 ? oL4.levels : [];
                        var isSelectedCount = aL4Level.filter(c => c.selected).length;
                        if (oL4) {
                            oL4.selected = true;
                        }
                        if (oL3) {
                            oL3.selected = true;
                        }

                        if (isSelectedCount == 0) {
                            if (oL4) {
                                if (!oL4.explicitlySelected) {
                                    oL4.selected = false
                                    oL4.partialSelection = false
                                }
                            }

                        } else if (oL4 && (isSelectedCount == aL4Level.length)) {
                            oL4.selected = true
                            oL4.partialSelection = false
                        } else {
                            if (oL4) {
                                oL4.partialSelection = true
                            }

                        }
                        var aL3Level = oL3 ? oL3.levels : [];
                        var isSelectedCount = aL3Level.filter(c => c.selected).length;
                        if (oL3) {
                            oL3.selected = true
                        }
                        if (isSelectedCount == 0) {
                            if (oL3) {
                                if (!oL3.explicitlySelected) {
                                    oL3.selected = false
                                    oL3.partialSelection = false
                                }
                            }

                        } else if (oL3 && (isSelectedCount == aL3Level.length)) {
                            oL3.selected = true
                            oL3.partialSelection = false
                        } else {
                            if (oL3) {
                                oL3.partialSelection = true
                            }
                        }
                    }

                    tokensToBeAdded.forEach(token => {
                        token.isMaterial ? displayTokensMaterial.push(token) : displayTokensAdditionalSolution.push(token)
                    })


                    tokensToBeRemoved.forEach(obj => {
                        if (mMaterialMap.get(obj.id)) {
                            mMaterialMap.get(obj.id).forEach(child => { child.selected = false })
                            materialTokensToBeRem.push(...mMaterialMap.get(obj.id))
                        }
                    })
                    tokensToBeRemoved.push(...materialTokensToBeRem)
                    const idsToBeRemoved = new Set(tokensToBeRemoved.map(item => item.id))
                    displayTokensMaterial = displayTokensMaterial.filter(item => !idsToBeRemoved.has(item.id))
                    displayTokensAdditionalSolution = displayTokensAdditionalSolution.filter(item => !idsToBeRemoved.has(item.id))
                    // materials = materials.filter(item => !idsToBeRemoved.has(item.id))


                    solutionAreaDataModel.setProperty("/displayTokensMaterial", displayTokensMaterial)
                    solutionAreaDataModel.setProperty("/displayTokensAdditionalSolution", displayTokensAdditionalSolution)
                    solutionAreaDataModel.setProperty("/materials", materials)
                    solutionAreaDataModel.setProperty("/materialMap", mMaterialMap)
                    solutionAreaDataModel.refresh(true)

                }
            },
            onChangeSolutionAreas: function (evt) {
                //const oSolAreaMasterDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData")
                // let aSelectedSLA = this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aTokenSelectedSolutionAreas");
                this.getView().getModel("employee").setProperty(`/TempEmployee/SolutionAreas`,   this.getView().getModel("employee").getProperty("/solutionForFilter"));

                
                // let sL1guid = oSolAreaMasterDataModel.getProperty("/selectedLevel1Guid")
                // let sL2guid = oSolAreaMasterDataModel.getProperty("/selectedLevel2Id")
                // let solHierarchyMap = oSolAreaMasterDataModel.getProperty("/solHierarchyMap")
                // let oL1Data = solHierarchyMap.get(sL1guid)
                // let oL2Data = solHierarchyMap.get(sL2guid)
                // var aSelAddSol = oSolAreaMasterDataModel.getProperty("/displayTokensAdditionalSolution") ? oSolAreaMasterDataModel.getProperty("/displayTokensAdditionalSolution") : [];
                // var aSolFinalNames = [];
                // let aSolFullGuids = [];
                // let aSolFullIds = [];
                // if (aSelAddSol.length > 0) {
                //     aSelAddSol.forEach(addSol => {
                //         aSolFinalNames.push(addSol.full_sol_name);
                //         aSolFullGuids.push(addSol.full_sol_guid)
                //         aSolFullIds.push(addSol.full_sol_id);
                //     })

                // }
                // var oPayload = {}
                // if (oL2Data) {
                //     oPayload = {
                //         SelectedSolutionArea: oL1Data.soln_name + " > " + oL2Data.soln_name,
                //         soln_guid: oL2Data.soln_guid,
                //         soln_id: oL2Data.soln_id,
                //         soln_name: oL2Data.soln_name,
                //         solnFinalName: oL2Data.soln_name,
                //         prnt_soln_id: oL1Data.soln_id,
                //         soln_prnt_guid: oL1Data.soln_guid,
                //         LevelId: 2,
                //         SolAreal1Guid: oL1Data.soln_guid,
                //         SolAreal1Desc: oL1Data.soln_name,
                //         SolAreal2Guid: oL2Data.soln_guid,
                //         SolAreal2Desc: oL2Data.soln_name,
                //         AllSelectedSolutions: aSolFinalNames.length > 0 ? aSolFinalNames.join(", ") : oL2Data.full_sol_name,
                //         AllSelectedGuids: aSolFullGuids.length > 0 ? aSolFullGuids.join(" , ") : oL2Data.full_sol_guid,
                //         AllSelectedIds: aSolFullIds.length > 0 ? aSolFullIds.join(" , ") : oL2Data.full_sol_id
                //     }
                // } else if (oL1Data) {
                //     oPayload = {
                //         SelectedSolutionArea: oL1Data.soln_name,
                //         soln_guid: oL1Data.soln_guid,
                //         soln_id: oL1Data.soln_id,
                //         soln_name: oL1Data.soln_name,
                //         solnFinalName: oL1Data.soln_name,

                //         soln_prnt_guid: "00000000-0000-0000-0000-000000000000",


                //         Guid: oL1Data.soln_guid,
                //         ID: oL1Data.soln_id,
                //         Desc: oL1Data.soln_name,
                //         LevelId: 1,
                //         SolAreal1Guid: oL1Data.soln_guid,
                //         SolAreal1Desc: oL1Data.soln_name,
                //         DisplayGuid: oL1Data.soln_guid,
                //         DisplayDesc: oL1Data.soln_name,
                //         AllSelectedSolutions: oL1Data.full_sol_name,
                //         AllSelectedGuids: oL1Data.full_sol_guid,
                //         AllSelectedIds: oL1Data.full_sol_id

                //     };
                // }


                // aSelectedSLA = []
                // if (oL2Data || oL1Data) {
                //     aSelectedSLA.push(oPayload)
                // }
                // let aAddSolutions=[]    
                // let aMaterials=[]
                // oSolAreaMasterDataModel.setProperty("/selectedLevel2Id", null)
                // oSolAreaMasterDataModel.setProperty("/selectedLevel1Guid", null)
                // let displayTokensMaterial = oSolAreaMasterDataModel.getProperty("/displayTokensMaterial")
                // let displayTokensAdditionalSolution = oSolAreaMasterDataModel.getProperty("/displayTokensAdditionalSolution")
                // this.getView().getModel("employee").setProperty(`/TempEmployee/SolutionAreas`, aSelectedSLA);
                // this.getView().getModel("employee").setProperty(`/TempEmployee/AdditionalSolutions`, displayTokensAdditionalSolution);
                // this.getView().getModel("employee").setProperty(`/TempEmployee/Materials`, displayTokensMaterial);

                // let oSelectParams = {
                //     "bIndustry": false,
                //     "minSelect": this.getView().getModel("employee").getProperty(`/minSelect`),
                //     "maxSelect": this.getView().getModel("employee").getProperty(`/maxSelect`),
                // };

                // if (!aSelectedSLA.length) {
                //     this.onDeleteSLAToken();
                // }


                // this.oSLASearchContext = false;
                // this.oSearchAddSlnContext = false
                const that = this;
                //   this.solutionHierarchyDialogForward.close()
                this.solutionHierarchyDialogForward.then(function (oDialog) {
                    oDialog.destroy();
                    // models.getSolutionAreaMasterData(that)
                    that.solutionHierarchyDialogForward = false;
                });
                let oSolutionAreasObj = this.getView().getModel("employee").getData();
                this.getView().getModel("variant").setProperty("/solutionArea", oSolutionAreasObj.TempEmployee.SolutionAreas);
                this.getView().getModel("variant").refresh();
            },
            //called when new solution hierarchy dialog is closed
            closeSolutionHierarchy: function () {
                const oSolAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData")
                // let solHierarchy = oSolAreaDataModel.getProperty("/solHierarchy");
                // let solHierarchyMap = oSolAreaDataModel.getProperty("/solHierarchyMap");
                // let mMaterialMap = oSolAreaDataModel.getProperty("/materialMap") ? oSolAreaDataModel.getProperty("/materialMap") : [];
                // solHierarchy.forEach(item => {
                //     solHierarchyMap.get(item.soln_guid).levels = []
                // })
                // mMaterialMap.forEach((arr, key) => {
                //     arr.forEach(value => {
                //         value.selected = false
                //     })
                // })

                // oSolAreaDataModel.setProperty("/solHierarchyMap", solHierarchyMap)
                // oSolAreaDataModel.setProperty("/selectedLevel2Id", null)
                // oSolAreaDataModel.setProperty("/selectedLevel1Guid", null)
                // oSolAreaDataModel.setProperty("/showDisplayMaterials", false)
                // oSolAreaDataModel.setProperty("/materials", [])
                // oSolAreaDataModel.setProperty("/displayTokensMaterial", [])
                // oSolAreaDataModel.setProperty("/displayTokensAdditionalSolution", [])
                // oSolAreaDataModel.refresh(true)
                // const solutionTree = this.byId("idSolutionTree");
                // solutionTree.removeSelections();
                // solutionTree.collapseAll();
                // this.solutionHierarchyDialogForward.close()
                  this.getView().getModel("employee").setProperty("/solutionForFilter",  this.tempSelectedSolution)
                this.getView().getModel("employee").setProperty("/TempEmployee/SolutionAreas",  this.tempSelectedSolution)
                let aSolutionMasterData = this.getOwnerComponent().getModel("SolutionAreaMasterData").getData();
                 const that = this;
                aSolutionMasterData.solHierarchy.forEach(function (item) {
                    let aFilteredSln =  that.tempSelectedSolution.filter(val => val.soln_guid === item.soln_guid)
                    if (aFilteredSln.length) {
                        item.selected = true;
                    }else{
                        item.selected = false;
                    }
                })
              
                this.getOwnerComponent().getModel("SolutionAreaMasterData").refresh();
                this.solutionHierarchyDialogForward.then(function (oDialog) {
                   // models.getSolutionAreaMasterData(that)
                    oDialog.destroy();
                    that.solutionHierarchyDialogForward = false;

                });
            },
            /*Token updated delete Solution Area*/
            onDeleteSLAToken: function (oEvent) {
                var deletedObj=oEvent.getParameter("removedTokens")[0].getBindingContext("employee").getObject()
                this.onDeleteDisplayTokens(deletedObj,true)
                // const oModel = this.getView().getModel("employee");
                // oModel.setProperty(`/TempEmployee/SolutionAreas`, []);
                // oModel.setProperty(`/TempEmployee/AdditionalSolutions`, []);
                // this.oSLASearchContext = false;
                // this.oSearchAddSlnContext = false
                // let oSelectParams = {
                //     "bIndustry": false,
                //     "minSelect": oModel.getProperty(`/minSelect`),
                //     "maxSelect": oModel.getProperty(`/maxSelect`),
                // }




            },
            /*Open Business Area Industry Fragment*/
            onOpenBAIndustryValueHelpDialog: function (oEvent) {
                const that = this;
                if (!this.pBAIndustryValueHelpDialog) {
                    this.pBAIndustryValueHelpDialog = this.loadFragment({
                        name: "com.dealsupport.melodyrequest.fragments.IndustryFilter"
                    });
                    this.getView().getModel("employee").refresh();
                    this._callBusinessAreaIndustryMasterData();
                } else {
                    const oModel = this.getView().getModel("employee");
                    if (oModel.getData().TempEmployee.BAIndustriesList) {
                        if (oModel.getData().TempEmployee.BAIndustriesList.length) {
                            oModel.setProperty(`/TempEmployee/BAIndustriesList`, oModel.getData().TempEmployee.BAIndustriesList);
                        }
                    }
                }
                this.pBAIndustryValueHelpDialog.then(function (oDialog) {
                    that.getView().setModel(new sap.ui.model.json.JSONModel(), "masterDataModel");
                    const oMasterDataModel = that.getView().getModel("masterDataModel");
                    oMasterDataModel.setData(that.getView().getModel("employee").getData());
                    that.getView().getModel("masterDataModel").refresh();
                    that.filterBAIndustries();
                    oDialog.open();

                });
            },
            _callBusinessAreaIndustryMasterData: function () {
                const oModel = this.getView().getModel("employee");
                const oTempEmployee = oModel.getProperty("/TempEmployee");
                var that = this;
                const data = appView.getView().getModel("baIndMasterData").getData();

                if (data && data.d && data.d.results) {
                    const aBAIndustry = data.d.results;
                    oTempEmployee.BAIndustriesList = [];
                    aBAIndustry.map((element, index, array) => {
                        oTempEmployee.BAIndustriesList.push({
                            Guid: element.BaIndGuid,
                            ID: element.BaIndId,
                            Desc: element.BaIndDesc,
                            ClusterGuid: element.IndClstrGuid,
                            ClusterDesc: element.IndClstrDesc,
                            IsDefault: (element.DefaultSel && element.DefaultSel === "X") ? true : false,
                            IsNonFocused: (element.DisplayGroup && element.DisplayGroup === "2") ? true : false,
                            IsPrimary: false,
                            IsEnabled: (element.DisplayGroup !== "4"),
                            IsSelected: false,
                            BaIndTechID: element.BaIndTechId,
                            BaIndId: element.BaIndId
                        });
                    });
                }
                oTempEmployee.BAIndustriesList.sort((i, j) => i.ClusterDesc.localeCompare(j.ClusterDesc));
                oTempEmployee.BAIndustriesList.unshift(oTempEmployee.BAIndustriesList.splice(oTempEmployee.BAIndustriesList.findIndex(item => item.ID === "0025"), 1)[0]);
                oModel.refresh(true);
                that.filterBAIndustries();
            },
            /*Filter business area industries*/
            filterBAIndustries: function () {
                const oModel = this.getView().getModel("employee");
                const oTempEmployee = oModel.getProperty("/TempEmployee");

                let aBAIndustries = [];
                aBAIndustries = JSON.parse(JSON.stringify(oTempEmployee.BAIndustriesList));

                let aEmployeeBAIndustries = JSON.parse(JSON.stringify(oModel.getProperty("/TempEmployee/BAIndustries")));
                oModel.setProperty("/NonIndustryFocused", {
                    Guid: "",
                    IsSelected: false,
                    IsVisible: false
                });
                aBAIndustries.map(function (element, index, array) {
                    const oEmployeeBAIndustry = aEmployeeBAIndustries.find(item => item.Guid === element.Guid);
                    if (oEmployeeBAIndustry) {
                        element.IsSelected = true;
                        element.IsPrimary = false;
                        oEmployeeBAIndustry.ClusterGuid = element.ClusterGuid;
                        oEmployeeBAIndustry.ClusterDesc = element.ClusterDesc;
                        oEmployeeBAIndustry.BaIndTechID = element.BaIndTechID;
                        oEmployeeBAIndustry.BaIndId = element.BaIndId;
                    } else {
                        element.IsSelected = false;
                        element.IsPrimary = false;
                    }
                    if (element.IsNonFocused) {
                        oModel.setProperty("/NonIndustryFocused", {
                            Guid: element.Guid,
                            IsSelected: false,
                            IsVisible: true
                        });
                        if (oEmployeeBAIndustry && oEmployeeBAIndustry.Guid === element.Guid) {
                            aEmployeeBAIndustries = [{
                                Guid: element.Guid,
                                Desc: element.Desc,
                                IsPrimary: false,
                                IsNonFocused: true,
                                ID: element.ID
                            }];
                            oModel.setProperty("/NonIndustryFocused", {
                                Guid: element.Guid,
                                IsSelected: true,
                                IsVisible: true,
                                ID: element.ID
                            });
                        }
                    }
                });
                let aFilteredEmployeeBAIndustries = JSON.parse(JSON.stringify(aEmployeeBAIndustries));
                for (let i = 0; i < aEmployeeBAIndustries.length; i++) {
                    const iIndex = aBAIndustries.findIndex(item => item.Guid === aEmployeeBAIndustries[i].Guid);
                    if (iIndex === -1) {
                        aFilteredEmployeeBAIndustries = aFilteredEmployeeBAIndustries.filter(item => item.Guid !== aEmployeeBAIndustries[i].Guid);
                    }
                }
                oModel.setProperty("/TempEmployee/BAIndustries", aFilteredEmployeeBAIndustries);
                oModel.setProperty("/TempEmployee/TempBAIndustries", JSON.parse(JSON.stringify(oTempEmployee.BAIndustries)));
                oModel.setProperty("/BAIndustries", aBAIndustries);
                oModel.refresh(true);
            },
            /*Search event for business area industies*/
            onSearchBAIndustry: function (oEvent) {
                let sQuery = "";
                if (oEvent) {
                    sQuery = oEvent.getSource().getValue();
                }
                let allFilter = [];
                if (sQuery && sQuery.length > 0) {
                    const oFilter1 = new sap.ui.model.Filter("Desc", sap.ui.model.FilterOperator.Contains, sQuery);
                    const oFilter2 = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.Contains, sQuery);
                    const oFilter3 = new sap.ui.model.Filter("ClusterDesc", sap.ui.model.FilterOperator.Contains, sQuery);
                    allFilter = new sap.ui.model.Filter([oFilter1, oFilter2, oFilter3], false);
                }
                this.fnFilterNonFocusedTableData(sQuery, "baIndustryFiltertableId", allFilter);
            },
            fnFilterNonFocusedTableData: function (sQuery, tableId, allFilter) {
                const oNonFocusedFilter = new sap.ui.model.Filter("IsNonFocused", sap.ui.model.FilterOperator.EQ, false);
                const aFilters = new sap.ui.model.Filter([allFilter, oNonFocusedFilter], true);
                this.getView().byId(tableId).getBinding().filter(aFilters);
            },
            /*Select event for business area industries*/
            onSelectBAIndustry: function (oEvent) {
                const oSource = oEvent.getSource();
                const oBinding = oSource.getBindingInfo("selected").binding;
                const oContext = oBinding.getContext();
                const oModel = oContext.getModel();
                const oBAIndustry = oModel.getProperty(oContext.getPath());
                const bSelected = oEvent.getParameter("selected");
                const aBAIndustries = oModel.getProperty("/BAIndustries");
                let aEmployeeBAIndustries = oModel.getProperty("/TempEmployee/TempBAIndustries");
                const iIndex = aEmployeeBAIndustries.findIndex(item => item.Guid === oBAIndustry.Guid);
                //aEmployeeBAIndustries.length = 0; 

                oBAIndustry.IsSelected = bSelected
                oEvent.getSource().getBindingContext("masterDataModel").getObject().IsSelected = bSelected
                this.getView().getModel("masterDataModel").refresh()
                if (bSelected) {
                    aEmployeeBAIndustries.push({
                        Guid: oBAIndustry.Guid,
                        Desc: oBAIndustry.Desc,
                        ClusterGuid: oBAIndustry.ClusterGuid,
                        ClusterDesc: oBAIndustry.ClusterDesc,
                        IsPrimary: true,
                        IsSelected: true,
                        BaIndTechID: oBAIndustry.BaIndTechID,
                        BaIndId: oBAIndustry.BaIndId
                    });
                } else {
                    aEmployeeBAIndustries = aEmployeeBAIndustries.reduce((acc, item) => {
                        if (item.Guid !== oBAIndustry.Guid) {
                            acc.push(item);
                        }
                        return acc;
                    }, []);
                    oModel.setProperty("/TempEmployee/TempBAIndustries", aEmployeeBAIndustries);
                }

                oModel.refresh(true);

            },
            /*Update business area industries*/
            onChangeBAIndustries: function (oEvent) {
                const oModel = this.getView().getModel("employee");
                const aEmployeeBAIndustries = oModel.getProperty("/TempEmployee/TempBAIndustries");
                oModel.setProperty("/TempEmployee/BAIndustries", JSON.parse(JSON.stringify(aEmployeeBAIndustries)));
                this.getView().getModel("variant").setProperty("/IndData", this.getView().getModel("employee").getData().TempEmployee.BAIndustries);
                this.getView().getModel("variant").refresh();
                this.onCloseBAIndustryValueHelpDialog();
            },
            /*Close business area industries fragment*/
            onCloseBAIndustryValueHelpDialog: function () {
                const oModel = this.getView().getModel("masterDataModel");
                const aEmployeeBAIndustries = oModel.getProperty("/TempEmployee/BAIndustries");
                const oEmployeeModel = this.getView().getModel("employee");
                oEmployeeModel.setProperty(`/TempEmployee/TempBAIndustries`, JSON.parse(JSON.stringify(aEmployeeBAIndustries)));
                this.getView().getModel("employee").setProperty("/sSearchBoxText", "");
                var that = this;
                this.pBAIndustryValueHelpDialog.then(function (oDialog) {
                    that.onSearchBAIndustry();
                    oDialog.close();

                });

            },
            /*Token updated delete Business Area Industry*/
            onDeleteBAIndToken: function (oEvent) {
                const oModel = this.getView().getModel("employee");
                const oTempEmployee = oModel.getProperty("/TempEmployee");
                const oParameters = oEvent.getParameters();
                if (oParameters.type === "removed") {
                    const aTokens = oParameters.removedTokens;
                    for (let i = 0; i < aTokens.length; i++) {
                        const iIndex = oTempEmployee.BAIndustries.findIndex(item => item.Guid === aTokens[i].getKey());
                        if (iIndex !== -1) {
                            oTempEmployee.BAIndustries.splice(iIndex, 1);
                            oTempEmployee.TempBAIndustries = oTempEmployee.BAIndustries;
                            oModel.refresh(true);
                        }
                    }
                }
            },
            onStartDateChange: function () {
                const oStartDP = this.byId("dpCreateDate");
                const oEndDP = this.byId("dpEndDate");

                const dStart = oStartDP.getDateValue();
                   this.byId("dpCreateDate").addStyleClass("disabledInput");
                this.byId("dpEndDate").addStyleClass("disabledInput");
                if (dStart) {
                    // Set the minimum selectable date for End Date
                    oEndDP.setMinDate(dStart);
                
                } else {
                    // If start date is cleared → reset min date
                    oEndDP.setMinDate(null);
                }
                const dp = this.byId("dpCreateDate");

                // wait until DOM is ready
                setTimeout(() => {
                    const $inner = dp.$().find("input");

                    if ($inner.length) {
                        $inner.attr("readonly", true);
                    }
                });
                 this.getView().byId("idClearStartDate").setVisible(true);
            },
            onEndDateChange: function () {
                let oEndDate =   this.byId("dpEndDate");
                this.byId("dpEndDate").addStyleClass("disabledInput");
                this.byId("dpCreateDate").addStyleClass("disabledInput");
                //disable date input field type
                $("#" + this.byId("dpCreateDate").sId + "-inner").prop("readonly", true);
                $("#" + this.byId("dpEndDate").sId + "-inner").prop("readonly", true);
                  const dp = this.byId("dpCreateDate");

                // wait until DOM is ready
                setTimeout(() => {
                    const $inner = oEndDate.$().find("input");

                    if ($inner.length) {
                        $inner.attr("readonly", true);
                    }
                });
                 this.getView().byId("idClearEndDate").setVisible(true);
            },
            onSelectDefaultVariant:function(oEvent){
                oEvent.getSource().getBindingContext("mroDataVariant").getObject().IsDefault = "X";
                oEvent.getSource().getBindingContext("mroDataVariant").getObject().Favourite = "X"
                this.getView().getModel("mroDataVariant").refresh();
                
            },
            onSelectSolutionWorklist: function (oEvent) {
                let selectedObj = oEvent.getSource().getBindingContext("SolutionAreaMasterData").getObject();
                let solutionForFilter = this.getView().getModel("employee").getProperty("/solutionForFilter");
                const oSolutionAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData");
                const aSolnModelMasterData = oSolutionAreaDataModel.getProperty("/solHierarchy");
                if(selectedObj.LevelId === 2){
                    let sParentGuid = selectedObj.soln_prnt_guid;
                    aSolnModelMasterData.forEach(function(item){
                        if(item.soln_guid === sParentGuid){
                            item.selected = solutionForFilter.filter(val=>val.soln_guid === item.soln_guid).length ? true:!!item.levels.filter(item=>item.selected).length;
                            item.partialSelection = solutionForFilter.filter(val=>val.soln_guid === item.soln_guid).length ? false:true;
                        }
                    })
                }


                if (oEvent.getSource().getSelected()) {
                    if (solutionForFilter) {
                        solutionForFilter.push(selectedObj)
                        this.getView().getModel("employee").setProperty("/solutionForFilter", solutionForFilter)
                    } else {
                        this.getView().getModel("employee").setProperty("/solutionForFilter", [selectedObj])
                    }
                } else {
                    solutionForFilter = solutionForFilter.filter(item => item.soln_guid !== selectedObj.soln_guid)
                    this.getView().getModel("employee").setProperty("/solutionForFilter", solutionForFilter)
                }
                this.getView().getModel("employee").refresh(true)

            },
            onDeleteDisplayTokens:function(oEvent,bFnCallFlag){   
                if(!bFnCallFlag){
                     var deletedToken = oEvent.getParameter("removedTokens")[0];
            		var deletedObj = deletedToken.getBindingContext("employee").getObject();
                    const oSolutionAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData");
                    const sParentGuid = deletedToken.getBindingContext("employee").getObject().soln_prnt_guid;
                    const sSelectedGuid = deletedToken.getBindingContext("employee").getObject().soln_guid;
                     const sSelectedLevelId = deletedToken.getBindingContext("employee").getObject().LevelId;
                    const slFilter = this.getView().getModel("employee").getProperty("/solutionForFilter");
                    oSolutionAreaDataModel.getProperty("/solHierarchy").forEach(function(item){
                        if(sParentGuid === item.soln_guid && sSelectedLevelId === 2){
                              let aSlnFilter = slFilter.filter(sln=>(sln.soln_guid !==sSelectedGuid && sln.soln_prnt_guid === sParentGuid));
                            item.selected = !!aSlnFilter.length;
                            item.partialSelection = item.selected;
                        }
                    });

                }else{
                    var deletedObj=oEvent
                }
               
			const oSolutionAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData");
                var solHierarchy=oSolutionAreaDataModel.getProperty("/solHierarchy")
                var solutionForFilter=  this.getView().getModel("employee").getProperty("/solutionForFilter")
                solHierarchy.forEach(obj=>{
                    console.log(obj)
                    if(obj.full_sol_id === deletedObj.full_sol_id){                    
                        obj.selected=false;
                        
                    }
                    if(obj.levels.length && obj.levels[0].soln_guid){
                        obj.levels.forEach(child=>{
                            if(child.full_sol_id === deletedObj.full_sol_id){
                                child.selected=false
                                
                                
                            }
                        })
                    }
                })
                solutionForFilter=solutionForFilter.filter(item=>item.soln_guid!==deletedObj.soln_guid)
                oSolutionAreaDataModel.setProperty("/solHierarchy",solHierarchy)
                this.getView().getModel("employee").setProperty("/solutionForFilter",solutionForFilter)
                this.getView().getModel("employee").setProperty("/TempEmployee/SolutionAreas",solutionForFilter)
                 this.getView().getModel("variant").setProperty("/solutionArea", solutionForFilter);
                this.getView().getModel("variant").refresh();
                oSolutionAreaDataModel.refresh(true)
            }






        });
    });
