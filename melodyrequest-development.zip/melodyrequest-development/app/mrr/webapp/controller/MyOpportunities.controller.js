sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "com/dealsupport/melodyrequest/model/models",
  "com/dealsupport/melodyrequest/model/formatter"
],
  /**
   * @param {typeof sap.ui.core.mvc.Controller} Controller
   */
  function (Controller, models, formatter) {
    "use strict";

    return Controller.extend("com.dealsupport.melodyrequest.controller.MyOpportunities", {

      formatter: formatter,

      onInit: function () {
        this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
        this.OREModel = this.getOwnerComponent().getModel("OREModel");
        this.OREModel.setProperty("/isBusy", false);
      },

      fnFetchOREData: function () {
        var that = this;
        var sUserId = this.OREModel.getProperty("/Id");
        if (sUserId) {
          this.OREModel.setProperty("/isBusy", true);
          this.OREModel.setProperty("/Id", sUserId);
          this.getView().byId("SimpleForm").setBusy(true);
          models.getfnFetchOREData(this, sUserId);
        }
      },
      fnFetchNewOREData: function () {
        var that = this;
        var sUserId = this.OREModel.getProperty("/Id");
        if (sUserId) {
          this.OREModel.setProperty("/isBusy", true);
          this.OREModel.setProperty("/data", {});
          this.OREModel.setProperty("/Id", sUserId);
          this.getView().byId("SimpleForm").setBusy(true);
          models.getfnFetchNewOREData(this, sUserId);
        }
      }
    });
  });
