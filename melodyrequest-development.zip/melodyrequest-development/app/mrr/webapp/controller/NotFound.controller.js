sap.ui.define([
    "sap/ui/core/mvc/Controller"
 ], function (Controller) {
    "use strict";
    return Controller.extend("com.dealsupport.melodyrequest.controller.NotFound", {
       onInit: function () {
         this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
         sap.ui.core.BusyIndicator.hide();
       }
    });
 });