var appView;
var pendingRequests;
var searchFlag;
sap.ui.define(
	[
		"sap/m/library",
		"sap/ui/core/mvc/Controller",
		"com/dealsupport/melodyrequest/model/models",
		'sap/ui/core/Fragment',
		'sap/ui/model/json/JSONModel',
		'sap/m/Token',
		"sap/f/library",
		"sap/ui/core/mvc/XMLView",
		"com/dealsupport/melodyrequest/model/formatter",
		"com/dealsupport/melodyrequest/control/Common",
		"sap/ui/core/format/DateFormat",
		"com/dealsupport/melodyrequest/control/ErrorHandle",
		"sap/m/MessageBox",
		'sap/ui/model/Filter',
		'sap/ui/model/FilterOperator',
		"sap/base/security/sanitizeHTML"
	],
	function (mobileLibrary, BaseController, models, Fragment, JSONModel, Token, fioriLibrary, XMLView, formatter, CommonJS,DateFormat,ErrorHandle,MessageBox,Filter,FilterOperator,sanitizeHTML) {
		"use strict";
		let URLHelper = mobileLibrary.URLHelper;
		let LayoutType = fioriLibrary.LayoutType;
		return BaseController.extend("com.dealsupport.melodyrequest.controller.App", {
			formatter: formatter,
			common:CommonJS,
			onInit: function () {
				this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
				this.loggUserId = this.getOwnerComponent().getModel("userDetails").getProperty("/user_name").toUpperCase();
				appView = this;
				this.sInstanceID = false;
				//Get app constants model which contains base Urls and settings
				let oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
				this.oFormatToDisplay = DateFormat.getDateInstance({ // this format is used to display selected dates in calendar
					pattern : "dd MMM yyyy"
				});
				let sDownTimeFlag = oAppConstantsModel.getProperty("/DownTime/0/Operational_Status");
				this._setSelectedMenuKey();
				this._InitializeBusyIndicator();
				oAppConstantsModel.setProperty("/AdminRole", roleFlag);
				if (!sDownTimeFlag) {
					if (roleFlag == false) {
						this.getView().byId("idRoleManagement").setVisible(false);
					} else {
						this.getView().byId("idRoleManagement").setVisible(false);
					}
					this.bus = this.getOwnerComponent().getEventBus();
					this.bus.subscribe("flexible", "setListPage", this.setListPage, this);
					this.bus.subscribe("flexible", "setDetailPage", this.setDetailPage, this);
					appView.listView = false;
					//set pfc data in initial load
					const profitCenterSorgModel = new sap.ui.model.json.JSONModel();
					this.getView().setModel(profitCenterSorgModel, "selectedProfitCenter");
					const oTerritoryMasterModel = new sap.ui.model.json.JSONModel();
					this.getView().setModel(oTerritoryMasterModel, "territoriesMaster");
					const oCrossCvgModel = new sap.ui.model.json.JSONModel();
					this.getView().setModel(oCrossCvgModel, "crossCvgMasterData");
					const oBALobModel = new sap.ui.model.json.JSONModel();
					this.getView().setModel(oBALobModel, "baLoBMasterData");
					const oBAIndModel = new sap.ui.model.json.JSONModel();
					this.getView().setModel(oBAIndModel, "baIndMasterData");
					const oUserDataModel = new sap.ui.model.json.JSONModel({});
					this.getView().setModel(oUserDataModel, "userDataModel");
					const oSubsEmployeeModel = new sap.ui.model.json.JSONModel();
					this.getView().setModel(oSubsEmployeeModel, "subsEmployeeService");
					this.getView().setModel(new sap.ui.model.json.JSONModel(), "myOppDialogModel");
					//call BA Industry
					models.getResourceProfileMasterData("YC_OR_M_BA_INDUSTRY", appView, "businessAreaIndustryPrimary", true);
					
				} else {
					//down time enable
					this.getView().byId("idRoleManagement").setVisible(false);
					this.getOwnerComponent().getRouter().navTo("NotFound");
				}
				let sLoggedInUser = this.getOwnerComponent().getModel("userDetails").getProperty("/email");
				const sSortQqueryPrams = `&$orderby=DTLastActivity_tdate desc,DTLastActivity_ttime desc`;
				const sCountQueryParams =
						`/wf/V_WfInstance_Inbox?$count=true&$filter=(currentStateID eq 'WSUBMN' or currentStateID eq 'WRESAP' or currentStateID eq 'WIOAPP' or currentStateID eq 'REQSUB' or currentStateID eq 'REESUB' or currentStateID eq 'WMNAPP') and contains(CurrentProcessorEmail,'${sLoggedInUser}')`;
				const sFinalCountQueryParams = `${sCountQueryParams}${sSortQqueryPrams}`;
				if (this.getOwnerComponent().getRouter()["oHashChanger"]["hash"].includes("Worklist")) {
					models.getInboxWfInstanceFilterLists(this.fnSuccessCountCallback, this.fnErrorFilterCallback, this, sFinalCountQueryParams);
				} 
				if(!this.getOwnerComponent().getRouter()["oHashChanger"]["hash"] ){
					this.getOwnerComponent().getRouter().navTo("MyInbox");
				}
			},
			fnSuccessCountCallback: function (oResult, self) {
				//set count for tabs
				oResult.count = oResult["@odata.count"];
				let oModel = new sap.ui.model.json.JSONModel();
				let oCount = {}
				oCount.pendingReqCount = self.count;
				oCount.MyReqCount = oResult.count;
				self.getOwnerComponent().getModel("appConstants").setProperty("/openTaskCount", oCount.MyReqCount);
				self.getOwnerComponent().getModel("appConstants").setProperty("/pendingReqCount", oCount.MyReqCount);
			},
			_setSelectedMenuKey: function () {
				//set header selection
				let oAppHeader = this.byId("idMainHeader");
				let oHashChanger = this.getOwnerComponent().getRouter().oHashChanger.getHash();
				this._setMyInboxContent();
				switch (true) {
					case oHashChanger.includes("HomePage"):
						this._setMyInboxContent("MyInbox");
						return oAppHeader.setSelectedKey("MyInbox");
						break;
					case oHashChanger.includes("NotFound"):
						return oAppHeader.setSelectedKey("NotFound");
						break;
					case oHashChanger.includes("CreateReq"):
						return oAppHeader.setSelectedKey("CreateReq");
						break;
					case oHashChanger.includes("ReqArea"):
						return oAppHeader.setSelectedKey("ReqArea");
						break;
					case oHashChanger.includes("Detail"):
						return oAppHeader.setSelectedKey("ReqArea");
						break;
					case oHashChanger.includes("CreateReqList"):
						return oAppHeader.setSelectedKey("CreateReqList");
						break;
					case oHashChanger.includes("Worklist"):
						return oAppHeader.setSelectedKey("Worklist");
						break;
					case oHashChanger.includes("WfInstance"):
						return oAppHeader.setSelectedKey("Worklist");
						break;
					case oHashChanger.includes("MyOpportunities"):
						return oAppHeader.setSelectedKey("MyOpportunities");
						break;
					case oHashChanger.includes("ManagerReqView"):
						return oAppHeader.setSelectedKey("Worklist");
						break;
					case oHashChanger.includes("SubmitReqView"):
						return oAppHeader.setSelectedKey("Worklist");
						break;
					case oHashChanger.includes("IOOwnerReqView"):
						return oAppHeader.setSelectedKey("Worklist");
						break;
					default:
						this._setMyInboxContent("MyInbox");
						return oAppHeader.setSelectedKey("MyInbox");
						break;
				}
			},
			_setMyInboxContent:function(userSelected){
				if(userSelected === "MyInbox"){
					this.getView().byId("mainContents").setVisible(false);
					this.getView().byId("idSplitVbox").setVisible(true);
				}else{
					this.getView().byId("mainContents").setVisible(true);
					this.getView().byId("idSplitVbox").setVisible(false);
				}
			},
			onSideNavButtonPress: function () {
				let oSideNavigation = this.byId("sideNavigation");
				let bExpanded = oSideNavigation.getExpanded();
				oSideNavigation.setExpanded(!bExpanded);
			},
			onItemSelect: function (oEvent) {
				let userSelected = oEvent.getParameter("item").getKey();
				if(userSelected === "CreateReq"){
					this.onOpenCreateReqDialog();
				}else{
					this.getOwnerComponent().getRouter().navTo(userSelected);
				}
				
			},
			onSelectEmail: function () {
				let sUrl = window.location.href;
				URLHelper.triggerEmail(false, "Link to: User Role Management", sUrl, false, false);
			},
			onSelectSupport: function () {
				let oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
				let sUrl = oAppConstantsModel.getProperty("/supporturl/0/Value")
				URLHelper.redirect(sUrl, "_blank");
			},

			onSelectSharePoint: function () {
				let oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
				let sUrl = oAppConstantsModel.getProperty("/SharePointURL/0/Value")
				URLHelper.redirect(sUrl, "_blank");
			},

			fnSuccessUrl: function (data, self) {
				let sUrl = data.value[0].Value;
				URLHelper.redirect(sUrl, true);
			},

			fnErrorUrl: function (data, self) {

			},
			onSearchResourceManagers: function () {
				sap.ui.core.BusyIndicator.show(0);
				appView.detailViewScreen.onSearchResourceManagers(appView.detailViewScreen);

			},
			//open error popover fragment
			_onOpenErrorPopOver: function () {
				if (!appView.pErrorPopOver) {
					appView.pErrorPopOver = appView.loadFragment({
						name: "com.dealsupport.melodyrequest.fragments.ErrorNotification"
					});
				}
				appView.pErrorPopOver.then(function (oDialog) {
					oDialog.openBy(appView.getView().byId("idNotificationBadgedButton"));
					return;
				});
			},
			_onClosePopOverList: function () {
				this._onClosePopOver();
				const oErrorModel = appView.getView().getModel("errorMsgModel");
				appView.getView().byId("idNotificationBadgedButton").setVisible(false);
				oErrorModel.setProperty("/errorInformation", [])
				appView.getView().byId("idNotificationBadgedButton").setVisible(false);
				if (appView.pErrorPopOver) {
					appView.pErrorPopOver.then(function (oDialog) {
						oDialog.destroy();
						delete appView.pErrorPopOver;
					});
				}
			},
			_onClosePopOver: function () {
				if (appView.pErrorPopOver) {
					appView.pErrorPopOver.then(function (oDialog) {
						oDialog.close();
					});
				}
			},

			//Create Request Dialog
			onOpenCreateReqDialog: function (evt, oBindingContext, isHarmonyRouting) {
				appView.isDetailPageOpened=false
				appView.oRouting = false;
				this.oUpdatedBindingContext = oBindingContext;
				let oView = appView.getView();
				let that = appView;
				sap.ui.core.BusyIndicator.show(0);
				let sLoggedInUserID = appView.getOwnerComponent().getModel("userDetails").getProperty("/user_name");
				//set footer model for create request
				const oFooterModel = new sap.ui.model.json.JSONModel();
				const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				const sI18nError = i18nModel.getText("Error");
				const oFooterData = {
					"footerButtons":{
						"createReqButtonVisible":false,
						"searchResourceButtonVisible":false,
						"createReqButtonEnabled":false,
						"searchResourceButtonEnabled":false,
						"errorBtnVisible":false,
						"errorBtnType":"Negative",
						"errorBtnIcon":"sap-icon://error",
						"errorBtnText":sI18nError

					}
				}
				oFooterModel.setData(oFooterData);
				this.getView().setModel(oFooterModel, "createReqFooterModel");
				const oErrorModel = new sap.ui.model.json.JSONModel();
				const oErrorData = {
					"errorInformation":[]
				}
				oErrorModel.setData(oErrorData);
				this.getView().setModel(oErrorModel, "errorMsgModel");
				if (!appView.getView().getModel("publicSalesOrgModel")) {
					setTimeout(function () {
						//Get sales org details
						models.getPublicSalesOrg(appView, appView.fnSuccessPublicSalesOrg);
						that._openCreateReqDialog(that);

					});
				} else {
					this._openCreateReqDialog(this);
				}

			},
			_onDestroyAllResourcePopOvers:function(){
				if (appView.detailViewScreen) {
					if (appView.listView._pValueHelpDialog) {
						appView.listView._pValueHelpDialog.then(function (oDialog) {
							appView.listView._pValueHelpDialog = false;
							oDialog.destroy();

						});
					}
					if (appView.listView._pAccountValueHelpDialog) {
						appView.listView._pAccountValueHelpDialog.then(function (oDialog) {
							appView.listView._pAccountValueHelpDialog = false;
							oDialog.destroy();

						});
					}
					if (appView.detailViewScreen.pBAIndustryValueHelpDialog) {
						appView.detailViewScreen.pBAIndustryValueHelpDialog.then(function (oDialog) {
							appView.detailViewScreen.pBAIndustryValueHelpDialog = false;
							oDialog.destroy();

						});
					}
					if (appView.detailViewScreen.pBALoBValueHelpDialog) {
						appView.detailViewScreen.pBALoBValueHelpDialog.then(function (oDialog) {
							appView.detailViewScreen.pBALoBValueHelpDialog = false;
							oDialog.destroy();

						});
					}
					if (appView.detailViewScreen.pCrossCvgValueHelpDialog) {
						appView.detailViewScreen.pCrossCvgValueHelpDialog.then(function (oDialog) {
							appView.detailViewScreen.pCrossCvgValueHelpDialog = false;
							oDialog.destroy();

						});
					}
					if (appView.detailViewScreen.pBASegDialog) {
						appView.detailViewScreen.pBASegDialog.then(function (oDialog) {
							appView.detailViewScreen.pBASegDialog = false;
							oDialog.destroy();

						});
					}
					if (appView.detailViewScreen.pHubValueHelpDialog) {
						appView.detailViewScreen.pHubValueHelpDialog.then(function (oDialog) {
							appView.detailViewScreen.pHubValueHelpDialog = false;
							oDialog.destroy();

						});
					}
				}
			},
			_getSalesOrgName: function (sSalesOrgID) {
				//Get sales org details
				let aSalesOrg = this.getView().getModel("publicSalesOrgModel").getData().value;
				return aSalesOrg.filter((org) => org.Sales_org_ID === sSalesOrgID)[0].Sales_org_name;
			},
			fnSuccessPublicReqAreaCallback: function (oData, self) {
				self.bus.publish("flexible", "setDetailPage", oData);
			},
			onCancelCreateReq: function () {
				appView.listView._onResetModels();
				this.oCreateDialog.close();
				this._setSelectedMenuKey();
			},
			fnSuccessPublicSalesOrg: function (oData, self) {
				const oPublicReqAreaModel = new sap.ui.model.json.JSONModel();
				const oDataArr = oData;
				oPublicReqAreaModel.setData(oData);
				self.getView().setModel(oPublicReqAreaModel, "publicSalesOrgModel");
				// set Model to Remove duplicacy for Select Sales Org for Account
				const uniqueEntries = {};
				oData.value.forEach(function (entry) {
					uniqueEntries[entry.Parent_SorgID] = entry;
				});
				const uniqueValueData = Object.values(uniqueEntries);
				const oUniqueValueModel = new sap.ui.model.json.JSONModel();
				oUniqueValueModel.setData(uniqueValueData);
				self.getView().setModel(oUniqueValueModel, "publicSalesOrg");
				// Ends here
			},
		fnSuccessEmployeePartnerCallback: function (oData, self) {
				//Get Partner details
				self.sPartnerID =  oData.d.results[0] ? oData.d.results[0].PARTNER:"";
				self.sFinalQueryParams =
					`$filter=DISP_AUTH eq true and SALES_TEAM_MEMBER eq '${self.sPartnerID}' and (STATUS eq 'E0001' or STATUS eq 'E0007' or STATUS eq 'E0003') and (FORECAST eq '1' or FORECAST eq '4' or FORECAST eq '2' or FORECAST eq '3')& search-focus=ACCOUNT&search=`
				//Call opportunity service based on the partner
				sap.ui.core.BusyIndicator.show();
				setTimeout(function() {
					if (self.sPartnerID) {
						models.getMyOpportunities(self, self.sFinalQueryParams, self.fnSuccessOpportunitiesCallback, true);
					} else {
						//open create req fragment
						self._openCreateReqDialog(self);
					}
			},1000);
			},
			fnSuccessOpportunitiesCallback: function (oData, self) {
				//Get opportunity details and set myOppDialogModel
				const oMyOppModel = new sap.ui.model.json.JSONModel();
				oMyOppModel.setData(oData.d);
				self.getView().setModel(oMyOppModel, "myOppDialogModel");
				self.getView().getModel("myOppDialogModel").refresh();
				if(!self.bOppSearch){
					self._openCreateReqDialog(self);
				}
			},
			_openCreateReqDialog:function(self){
				let oBindingContext = self.oUpdatedBindingContext;
				if (!appView._pCreateReqialog){
					appView._pCreateReqialog = Fragment.load({
					id: self.getView().getId(),
					name: "com.dealsupport.melodyrequest.fragments.CreateReqDialog",
					controller: appView
				}).then(function (oCreateDialog) {
					self.oCreateDialog = oCreateDialog;
					self.getView().addDependent(oCreateDialog);
					return oCreateDialog;
				});
				}

				self._pCreateReqialog.then(function (oCreateDialog) {
					let oDefault;
					appView.prevSelectedOppDetails = false;
					appView.oFinalData = {};
					// Git #181  start
					// create object to store default profitcenter
					appView.oFinalData.oppDefaultSalesOrg = { "TempProfitCenter": { "Territories": [] }, "filteredProfitCenter": [] };
					// Git #181  end
					self.oFlexibleColumnLayout = sap.ui.getCore().byId("fcl");
					self.bus.publish("flexible", "setListPage");
					if (!oBindingContext) {
						//Direct request
						//oCreateDialog.getBeginButton().setEnabled(false);
						appView.getView().getModel("createReqFooterModel").setProperty("/footerButtons/createReqButtonEnabled", false);
						appView.getView().getModel("createReqFooterModel").refresh();
						if (appView.listView) {
							//if no routing from harmony reset the create req details
							appView.listView.byId("idOppContainer").setVisible(true);
							appView.listView.byId("idAccountContainer").setVisible(false);
							appView.listView.byId("multiInputNewOpp").removeStyleClass("customLibInputOppSelectStyle");
							appView.listView.byId("multiInputNewOpp").addStyleClass("customLibInputOppStyle");
							//set Model for opportunity and account info
							appView.listView.getView().setModel(new sap.ui.model.json.JSONModel([]), "oppAccInfoModel");
							appView.listView.getView().getModel("oppAccInfoModel").refresh();
							//set default selected opp
							appView.listView.byId("idCreateSegContainer").setSelectedKey("opp")
							//reset all the inputs
							appView.listView.byId("multiInputNewOpp").setOpportunityId("");
							appView.listView.byId("multiInputAccount").setTokens([]);

							appView.listView.getView().byId("multiInputAccount").setWidth("99%");
							appView.oCreateDialog.setContentHeight("350px");
					appView.oCreateDialog.setContentWidth("800px");
					appView.getOwnerComponent().getModel("appConstants").setProperty("/oppAccConatinerVisible",false);
					// oDefault = appView.getOwnerComponent().getModel("mrrAppEngModel").getProperty("/aActiveEngagements").find(e => e.is_default === 'X');
					oDefault = appView.getOwnerComponent().getModel("mrrAppEngModel").getProperty("/engagementList").find(e => e.is_default === 'X');
					appView.getOwnerComponent().getModel("appConstants").refresh();
					
			

						}
					} else {
						//PreSelect the opportunity, Req from other App (Harmony)
						appView.oFinalData = {};
						appView.oFinalData.accountName = oBindingContext.ACCOUNT_NAME ? oBindingContext.ACCOUNT_NAME.trim(): oBindingContext.ACCOUNT_NAME;
						appView.oFinalData.accountId = oBindingContext.ACCOUNT;
						appView.oFinalData.opportunityId = oBindingContext.OPPT_ID;
						appView.oFinalData.OrgID = oBindingContext.SALES_ORG_SHORT;
						appView.oFinalData.oppOrgId =   oBindingContext.SALES_ORG_SHORT;
						appView.oFinalData.OrgType = "SORG";
						appView.oFinalData.RequestType = "Opportunity";
						appView.oFinalData.Opp_Desc = oBindingContext.DESCRIPTION;
						if(oBindingContext.ENGAGE_TYPE)
							appView.getOwnerComponent().getModel("mrrAppEngModel").setProperty("/engagementSelectedKey",oBindingContext.ENGAGE_TYPE)
						appView.oFinalData.SalesOrg = appView._getSalesOrgName(appView.oFinalData.OrgID);
						appView.oRouting = true;
						if (appView.oRouting) {
							//Get and set opportunity details from harmony
							appView.listView.fnGetSelectedOppoDetails(false, true)
							// oDefault = appView.getOwnerComponent().getModel("mrrAppEngModel").getProperty("/aActiveEngagements").find(e.eng_Desc === EngType);
							//appView.oRouting = false;
						}
					}
					if (oDefault) {
						appView.getOwnerComponent().getModel("mrrAppEngModel").setProperty("/engagementSelectedKey", oDefault.eng_type_ID);
						appView.oFinalData.EngagementType = oDefault.eng_type_ID;
						appView.getOwnerComponent().getModel("mrrAppEngModel").refresh();
					}
					if(appView.detailViewScreen){
						appView._onDestroyAllResourcePopOvers();
					}
					oCreateDialog.open();
					// Check if the binding context exists
					appView.getView().setBusy(false);
					if(oBindingContext && appView.getOwnerComponent().getModel("appConstants").getProperty("/RoutingBusyDialog/0/Operational_Status")){
						appView.onOpenRouteBusyDialog();
					}
					sap.ui.core.BusyIndicator.hide();
				});
			},
			setAccountModel: function (self) {
				//Initiate account model
				let aMyOpportunities = self.getView().getModel("myOppDialogModel").getData().results;
				let aAccount = [];
				aMyOpportunities.forEach(function (opp) {
					if (self.formatter.formatCreateRequestBtn(opp.DISP_AUTH, opp.IS_LEAN, opp.SALES_ORG_SHORT, self)) {
						aAccount.push({
							"ACCOUNT": opp.ACCOUNT,
							"ACCOUNT_NAME": opp.ACCOUNT_NAME
						});
					}
				});
				const oMyAccountModel = new sap.ui.model.json.JSONModel();
				oMyAccountModel.setData(aAccount);
				self.getView().setModel(oMyAccountModel, "myAccountModel");

			},
			
			setListPage: function () {
				//set createReqList Page
				this.oCreateDialog.getContent()[0].setLayout(LayoutType.OneColumn).setLayout(LayoutType.OneColumn);
				if(appView.listView){
					//set model for html text
					let sHtmlOppOrOppText = this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/Opp_Title/0/fieldDesc");
					let oModelInfoText = new JSONModel({
						HTML : sHtmlOppOrOppText
					});
					appView.listView.getView().setModel(oModelInfoText,"infoHTMText");
					let sHtmlOppOrAccText = this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/Acc_Title/0/fieldDesc")
					let oModelInfoAccText = new JSONModel({
						HTML : sHtmlOppOrAccText
					});
					appView.listView.getView().setModel(oModelInfoAccText,"infoAccHTMText");
					// appView.listView._onResetModels();
					if(appView.oRouting){
						//Get and Set opportunity details from harmony
						appView.listView.fnGetSelectedOppoDetails(false, true)
						appView.oRouting = false;
					}
				}

			},

			// Lazy loader for the mid page - only on demand (when the user clicks)
			setDetailPage: function (s, e, oContext) {
				let that = this;
				let bIsGroupSelectable=false;				
				appView.bIsSelectOppVal = false;			
				appView.isDetailPageOpened = true;						
				this._loadView({
					id: "midView",
					viewName: "com.dealsupport.melodyrequest.view.CreateReqDetail"
				}).then(function (detailView) {
					appView.listView.getView().byId("multiInputAccount").setWidth("100%");
					appView.oCreateDialog.setContentHeight("700px");
					appView.oCreateDialog.setContentWidth("1300px");
					appView.getOwnerComponent().getModel("appConstants").setProperty("/oppAccConatinerVisible",true);
					appView.getOwnerComponent().getModel("appConstants").refresh();
					appView.detailViewScreen.iModiFiedIndex = false;
					appView.listView.getView().getModel("oppAccInfoModel").setData(appView.oFinalData);
					appView.listView.getView().getModel("oppAccInfoModel").refresh();
					if(appView.listView.getView().getModel("selectedProfitCenter").getData() && !appView.listView.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories").length ){					
						appView.listView.getView().getModel("selectedProfitCenter").setProperty("/selectedPfc","");
						appView.listView.getView().getModel("selectedProfitCenter").refresh();
					}
					if(!appView.listView.getView().getModel("selectedProfitCenter").getData()){						
						appView.listView.getView().getModel("selectedProfitCenter").setData({
							 "TempProfitCenter": { "Territories": [] }, "filteredProfitCenter": [],selectedPfc:""
						})
					}
					appView.detailViewScreen.getView().setModel(new JSONModel(appView.listView.getView().getModel("selectedProfitCenter").getData()),"selectedProfitCenter");
					if (oContext && !appView.oFinalData.isResourceProfile) {
						appView.detailViewScreen.getView().getModel("selectedProfitCenter").refresh();
						appView.detailViewScreen.getView().byId("idResourceProfileContainer").setVisible(false);
						appView.detailViewScreen.getView().byId("idResIntro").setVisible(false);
						appView.detailViewScreen.getView().byId("idResProfitCenter").setVisible(false);
						appView.detailViewScreen.getView().byId("idReqAreaContainer").setVisible(true);
						sap.ui.core.BusyIndicator.hide();
						that._setRequestAreas(detailView, oContext);
					}else{
						
						appView.detailViewScreen.getView().byId("idResourceProfileContainer").setVisible(true);
						appView.detailViewScreen.getView().byId("idResIntro").setVisible(true);
						appView.detailViewScreen.getView().byId("idResProfitCenter").setVisible(true);
						appView.detailViewScreen.getView().byId("idReqAreaContainer").setVisible(false);
						if (appView.listView.sStatus === "initialLoad") {
							//Set Resource profile model
							appView.detailViewScreen.getView().setModel(new sap.ui.model.json.JSONModel({
								Roles: [],
								SelectedRoles: []
							}), "roles");
									const oResourceSearchObj = CommonJS._setNewResourceProfileObj(appView);
									appView.detailViewScreen.getView().setModel(new sap.ui.model.json.JSONModel({
								"isFilter":false,
								searchItems: [
									oResourceSearchObj
								]
							}), "employee");
							if(appView.oFinalData.OrgID){
								const sSalesOrgVal = appView.oFinalData.OrgID;
							const sSalesOrgNumber = Number(sSalesOrgVal.replace('SORG-', '')).toString();
							if(appView.detailViewScreen.getView().getModel("employee")){
								appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/TempProfitCenter",appView.listView.getView().getModel("selectedProfitCenter").getData()
								.TempProfitCenter);
								appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/selectedPfc",appView.listView.getView().getModel("selectedProfitCenter").getData()
								.TempProfitCenter.Territories[0]);
							}
							
							}
							if (appView.detailViewScreen.getView().getModel("employee").getProperty("/searchItems/0/selectedPfc")) {
								//set profit center text
								appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/isPfcSelected", true);
							} else {
								appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/isPfcSelected", false);
							}
							if(appView.listView.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories").length){
								bIsGroupSelectable=appView.listView.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories")[0].GrpSelectable=='X'?true:false
							}

							//set resprofile field level config
							let bEngagementType=appView.getOwnerComponent().getModel("mrrAppEngModel").getData().engagementSelectedKey=='0001'?true:false
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/BAIndustryMandatory",false);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/BAIndustrySelectable",bEngagementType);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/GrpSelectable",bEngagementType && bIsGroupSelectable);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/SolnAreaMandatory",false);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/SolnAreaSelectable",bEngagementType);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/minSelect",0);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/maxSelect",2);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/solnAreaEnable",true);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/industryEnable",true);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/solnIndRequired",false);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/fieldSelectionMidInfoIcon",false);
							appView.detailViewScreen.getView().getModel("employee").setProperty
							("/searchItems/0/midSectionDesc", appView.getOwnerComponent().
							getModel("mrrAppConfigModel").getProperty("/SolnInd_SelectionText/0/fieldDesc"));
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/legacyValidation",false);

							appView.detailViewScreen.getView().getModel("employee").setProperty("/TempEmployee/ManagerLevel", appView.getOwnerComponent().getModel("managerLevelMasterData").getData());
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/searchTitle", "Search 1");
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/isBALobRequired", true);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/isCrossCoverageRequired", true);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/isBAIndustryRequired", true);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/selAtleaseoneValueVisibility", true);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/isSolnAreaRequired", true);
							appView.detailViewScreen.loadRoleTypeData("ROLETYPE", appView.getView().getModel("roleMasterData").getData());
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/TempEmployee/ManagerLevel", appView.getView().getModel("managerLevelMasterData").getData());
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/LobIsRequired", true);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/searchFieldsText", "[]");
							appView.listView.sStatus = "onChangeOppOrAccount";
							appView.detailViewScreen._callBusinessAreaIndustryMasterData(0);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/selectedCrossCoverage", "");
							if(!appView.detailViewScreen.getView().getModel("employee").getProperty("/searchItems/isExpanded")){
								appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/isExpanded", true);
							}
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/TempEmployee/selectedBALob", "");
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/TempEmployee/selectedBAIndustry", "");
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/TempEmployee/SelectedGroup", []);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/TempEmployee/TempGroup", []);
							if(appView.getOwnerComponent().getModel("grpHierarchyForFilter"))
								appView.getOwnerComponent().getModel("grpHierarchyForFilter").setProperty("/selectedGrpID","")
							//MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
							//set selected solution area
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/TempEmployee/SolutionAreas",[]);
							//MR: [GRP02-03] GTM25 Resource Profile alignment #84 end
							//selected profit center
							let oProfitCenterResetObj = { "Territories": [] };
							appView.detailViewScreen._setSearchFieldText(0);
							//appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/TempProfitCenter",oProfitCenterResetObj);
						} else if (appView.listView.sStatus === "changePFC" || appView.listView.sStatus === "onChangeOppOrAccount") {
								if(!appView.detailViewScreen.getView().getModel("employee")){
									const oResourceSearchObj = CommonJS._setNewResourceProfileObj(appView);
									appView.detailViewScreen.getView().setModel(new sap.ui.model.json.JSONModel({
								"isFilter":false,
								searchItems: [
									oResourceSearchObj
								]
							}), "employee");
							}
							
							if (appView.oFinalData.OrgID) {
								const sSalesOrgVal = appView.oFinalData.OrgID;
								const sSalesOrgNumber = Number(sSalesOrgVal.replace('SORG-', '')).toString();
								 if(appView.detailViewScreen.getView().getModel("employee")){
									appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/TempProfitCenter",appView.listView.getView().getModel("selectedProfitCenter").getData()
									.TempProfitCenter);
									appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/selectedPfc",appView.listView.getView().getModel("selectedProfitCenter").getData()
									.TempProfitCenter.Territories[0]);
								}
								
							}


							if (appView.detailViewScreen.getView().getModel("employee").getProperty("/searchItems/0/selectedPfc")) {
								//set profit center text
								appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/isPfcSelected", true);
							} else {
								appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/isPfcSelected", false);
							}
							//set resprofile field level config
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/BAIndustryMandatory", false);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/BAIndustrySelectable", true);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/SolnAreaMandatory", false);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/SolnAreaSelectable", true);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/minSelect",0);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/maxSelect",2);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/solnAreaEnable",true);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/industryEnable",true);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/solnIndRequired",false);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/fieldSelectionMidInfoIcon",false);
							appView.detailViewScreen.getView().getModel("employee").setProperty
							("/searchItems/0/midSectionDesc", appView.getOwnerComponent().
							getModel("mrrAppConfigModel").getProperty("/SolnInd_SelectionText/0/fieldDesc"));
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/legacyValidation",false);

							appView.detailViewScreen.loadRoleTypeData("ROLETYPE", appView.getView().getModel("roleMasterData").getData());
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/TempEmployee/ManagerLevel", appView.getView().getModel("managerLevelMasterData").getData());
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/searchTitle", "Search 1");
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/isBALobRequired", true);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/isSolnAreaRequired", true);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/isCrossCoverageRequired", true);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/isBAIndustryRequired", true);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/selAtleaseoneValueVisibility", true);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/LobIsRequired", true);
							let oModel = appView.detailViewScreen.getView().getModel("employee");
							oModel.setProperty("/searchItems/0/SelectedRoleKey", "");
							oModel.setProperty("/searchItems/0/SelectedRoleAreasKey", "");
							oModel.setProperty("/searchItems/0/TempEmployee/Roles", []);
							if(!oModel.getProperty("/searchItems/0/isExpanded")){
								oModel.setProperty("/searchItems/0/isExpanded", true);
							}
							
							oModel.setProperty("/searchItems/0/TempEmployee/TempRoleAreas", []);
							oModel.setProperty("/searchItems/0/TempEmployee/TempBAIndustries", []);
							oModel.setProperty("/searchItems/0/TempEmployee/SelectedHubs", []);
							oModel.setProperty("/searchItems/0/TempEmployee/TempBALoBs", []);
							oModel.setProperty("/searchItems/0/TempEmployee/TempCrossCvg", []);
							appView.detailViewScreen.getView().getModel("employee").setProperty("/searchItems/0/LobIsRequired", true);
							oModel.setProperty("/searchItems/0/TempEmployee/RoleAreas", []);
							oModel.setProperty("/searchItems/0/TempEmployee/BAIndustries", []);
							oModel.setProperty("/searchItems/0/TempEmployee/CrossCvg", []);
							oModel.setProperty("/searchItems/0/TempEmployee/BALoBs", [])
							oModel.setProperty("/searchItems/0/searchFieldsText", "[]");
							oModel.setProperty("/searchItems/0/selectedCrossCoverage", "");
							oModel.setProperty("/searchItems/0/TempEmployee/selectedBALob", "");
							appView.detailViewScreen._callBusinessAreaIndustryMasterData(0);
							oModel.setProperty("/searchItems/0/TempEmployee/selectedBAIndustry", "");
							//MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
							//set selected Solution Area
							oModel.setProperty("/searchItems/0/TempEmployee/selectedSolutionArea", []);
							oModel.setProperty("/searchItems/0/TempEmployee/SolutionAreas",[]);
							//selected profit center
							let oProfitCenterResetObj = { "Territories": [] };
							//oModel.setProperty("/searchItems/0/TempProfitCenter",oProfitCenterResetObj);
							//MR: [GRP02-03] GTM25 Resource Profile alignment #84 end
							oModel.refresh();
							appView.detailViewScreen._setSearchFieldText(0);
						}
					}
					detailView.oSLASearchContext = false;
					that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/results",[]);
					that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",[]);
					that.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
					that.oCreateDialog.getContent()[0].addMidColumnPage(detailView);
					that.oCreateDialog.getContent()[0].setLayout(LayoutType.TwoColumnsMidExpanded);
					if(appView.detailViewScreen){
						var vboxItems=appView.detailViewScreen.byId("idResourceProfileContainer").getItems()
						if(vboxItems){
							vboxItems.forEach(obj=>{
								if(!obj.getProperty("expanded")){
									obj.setExpanded(true)
								}
							})
						}

					}
					sap.ui.core.BusyIndicator.hide();
				}.bind(this));
			
			},
			_setRequestAreas: function (self, oContext) {
				//set request area based on sales org
				self.aSelectedReqAreas = [];
				this.detailView = self;
				const aResult = oContext.value;
				const aReqAreaTree = [];
				let oReqAreaObj = {};
				for (let i = 0; i < aResult.length; i++) {
					//pushing parent text into an array
					oReqAreaObj.text = aResult[i].Ra1;
					oReqAreaObj.enabled = !(aResult[i].Ra2 !== null);
					oReqAreaObj.isLeafNode = !(aResult[i].Ra2 !== null);
					if (oReqAreaObj.enabled && oReqAreaObj.isLeafNode) {
						oReqAreaObj.PresalesRequestArea = aResult[i].Ra1;
						oReqAreaObj.PresalesRequestAreaPath = aResult[i].Request_Area;
						oReqAreaObj.GUID = aResult[i].GUID;
					}
					oReqAreaObj.nodes = [];
					aReqAreaTree.push(oReqAreaObj);
					oReqAreaObj = {};
					for (let j = 0; j < aReqAreaTree.length; j++) {
						for (let k = j + 1; k < aReqAreaTree.length; k++) {
							//removing duplicate element from array
							if (aReqAreaTree[j].text === aReqAreaTree[k].text) {
								aReqAreaTree.pop();
							}
						}
					}
				}
				for (let m = 0; m < aReqAreaTree.length; m++) {
					for (let n = 0; n < aResult.length; n++) {
						//pushing child1 (Ra1) data into array
						if (aReqAreaTree[m].text === aResult[n].Ra1) {
							oReqAreaObj.text = aResult[n].Ra2;
							oReqAreaObj.enabled = !(aResult[n].Ra3 !== null);
							oReqAreaObj.isLeafNode = !(aResult[n].Ra3 !== null);
							if (oReqAreaObj.enabled && oReqAreaObj.isLeafNode) {
								oReqAreaObj.PresalesRequestArea = aResult[n].Ra1 + "-" + aResult[n].Ra2;
								oReqAreaObj.PresalesRequestAreaPath = aResult[n].Request_Area;
								oReqAreaObj.GUID = aResult[n].GUID;
							}
							oReqAreaObj.nodes = [];
							aReqAreaTree[m].nodes.push(oReqAreaObj);
							oReqAreaObj = {};
							for (let j = 0; j < aReqAreaTree[m].nodes.length; j++) {
								for (let k = j + 1; k < aReqAreaTree[m].nodes.length; k++) {
									//removing duplicate element
									if (aReqAreaTree[m].nodes[j].text === aReqAreaTree[m].nodes[k].text) {
										aReqAreaTree[m].nodes.pop();
									}
								}
								for (let s = 0; s < aResult.length; s++) {
									//pushing child2 (ReqArea3) data into array
									if (aReqAreaTree[m].nodes[j].text === aResult[s].Ra2 && aReqAreaTree[m].text === aResult[s].Ra1) {
										oReqAreaObj.text = aResult[s].Ra3;
										oReqAreaObj.enabled = !(aResult[s].Ra4 !== null);
										oReqAreaObj.isLeafNode = !(aResult[s].Ra4 !== null);
										if (oReqAreaObj.enabled && oReqAreaObj.isLeafNode) {
											oReqAreaObj.PresalesRequestArea = aResult[s].Ra2 + "-" + aResult[s].Ra3;
											oReqAreaObj.PresalesRequestAreaPath = aResult[s].Request_Area;
											oReqAreaObj.GUID = aResult[s].GUID;
										}
										oReqAreaObj.nodes = [];
										aReqAreaTree[m].nodes[j].nodes.push(oReqAreaObj);
										oReqAreaObj = {};
										for (let i = 0; i < aReqAreaTree[m].nodes[j].nodes.length; i++) {
											for (let p = i + 1; p < aReqAreaTree[m].nodes[j].nodes.length; p++) {
												//removing duplicate element
												if (aReqAreaTree[m].nodes[j].nodes[i].text === aReqAreaTree[m].nodes[j].nodes[p].text) {
													aReqAreaTree[m].nodes[j].nodes.pop();
												}
											}
											//pushing child3(ReqArea4) data into array
											if (aResult[s].Ra4 !== null && aResult[s].Ra3 === aReqAreaTree[m].nodes[j].nodes[i].text && aReqAreaTree[m].nodes[j].text ===
												aResult[s].Ra2) {
												oReqAreaObj.text = aResult[s].Ra4;
												oReqAreaObj.enabled = true;
												oReqAreaObj.isLeafNode = true;
												oReqAreaObj.PresalesRequestArea = aResult[s].Ra3 + "-" + aResult[s].Ra4;
												oReqAreaObj.PresalesRequestAreaPath = aResult[s].Request_Area;
												oReqAreaObj.GUID = aResult[s].GUID;
												oReqAreaObj.nodes = [];
												aReqAreaTree[m].nodes[j].nodes[i].nodes.push(oReqAreaObj);
												oReqAreaObj = {};
												for (let b = 0; b < aReqAreaTree[m].nodes[j].nodes[i].nodes.length; b++) {
													for (let c = b + 1; c < aReqAreaTree[m].nodes[j].nodes[i].nodes.length; c++) {
														if (aReqAreaTree[m].nodes[j].nodes[i].nodes[b].text === aReqAreaTree[m].nodes[j].nodes[i].nodes[c].text) {
															aReqAreaTree[m].nodes[j].nodes[i].nodes.pop();
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
				const aModel = {};
				aModel.data = aReqAreaTree;
				self.setModel(new JSONModel(aModel), "myPresaleModel");
				//hide selection of parent nodes and keep it only for leaf nodes
				let that = self;
				const oTree = self.byId("idTree");
				oTree.bindAggregation("items", "myPresaleModel>/data", function (sId, oContext) {
					const oLeafChild = oContext.getProperty("isLeafNode");
					that.bSelCheckbox = false;
					if (oLeafChild && oLeafChild !== " " && that.aSelectedReqAreas.length) {
						const sChildSelGUID = oContext.getProperty("GUID");
						that.aSelectedReqAreas.forEach(function (obj) {
							if (obj.GUID === sChildSelGUID) {
								that.bSelCheckbox = true;
							}
						});
					}

					const oControl =
						(oLeafChild && oLeafChild !== " ") ? new sap.m.CustomTreeItem(sId, {
							content: new sap.m.CheckBox({
								text: "{myPresaleModel>text}",
								selected: that.bSelCheckbox,
								select: appView.onItemSelected.bind(appView)
							})
						}) :
							new sap.m.CustomTreeItem(sId, {
								content: new sap.m.Title({
									text: "{myPresaleModel>text}"
								})
							});
					return oControl;
				});
			},

			// Lazy loader for the end page - only on demand (when the user clicks)
			setDetailDetailPage: function () {
				this._loadView({
					id: "endView",
					viewName: "sap.f.sample.FlexibleColumnLayoutLandmarkInfoArrow.view.DetailDetail"
				}).then(function (detailDetailView) {
					appView.oFlexibleColumnLayout.addEndColumnPage(detailDetailView);
					appView.oFlexibleColumnLayout.setLayout(LayoutType.ThreeColumnsEndExpanded);
				}.bind(this));
			},

			// Helper function to manage the lazy loading of views
			_loadView: function (options) {
				let mViews = this._mViews = this._mViews || Object.create(null);
				if (!mViews[options.id]) {
					mViews[options.id] = this.getOwnerComponent().runAsOwner(function () {
						return XMLView.create(options);
					});
				}
				return mViews[options.id];
			},
			//Request area selection
			onItemSelected: function (oEvent) {
				const sPath = oEvent.getSource().getBindingContext("myPresaleModel").sPath;
				const oTemplateDetail = this.detailView.getModel("myPresaleModel").getProperty(sPath);
				if (oEvent.getParameter("selected")) {
					appView.getView().getModel("createReqFooterModel").setProperty("/footerButtons/createReqButtonEnabled", true);
					appView.getView().getModel("createReqFooterModel").refresh();
					const oSelectedReqArea = {
						"GUID": oTemplateDetail.GUID,
						"requestArea": oTemplateDetail.PresalesRequestArea,
						"requestAreaPath": oTemplateDetail.PresalesRequestAreaPath
					};
					this.detailView.aSelectedReqAreas.push(oSelectedReqArea);
				} else {
					this.detailView.aSelectedReqAreas = this.detailView.aSelectedReqAreas.filter(function (obj) {
						return obj.GUID !== oTemplateDetail.GUID;
					});
				}
				if (!this.detailView.aSelectedReqAreas.length) {
					appView.getView().getModel("createReqFooterModel").setProperty("/footerButtons/createReqButtonEnabled", false);
					appView.getView().getModel("createReqFooterModel").refresh();
				}
			},
			onCreateRequest: function () {
				sap.ui.core.BusyIndicator.show(0);
				this.getView().setBusy(true);
				if (!appView.oFinalData.isResourceProfile) {
					appView.aSelectedReqAreas = this.detailView.aSelectedReqAreas;
				} else {
					if (appView.oFinalData.aReqAreas.length > 1) {
						appView.oFinalData.aReqAreas = appView.oFinalData.aReqAreas.sort((a, b) => {
							const numA = parseInt(a.requestArea.match(/\d+/)[0], 10);
							const numB = parseInt(b.requestArea.match(/\d+/)[0], 10);
							return numA - numB;
						});
					}
				appView.oFinalData.isRoleAreaSelection = true;
				}
				if(appView.oFinalData.RequestType === "Opportunity"){
					//request type 'Opportunity' update opportunity details
					let oppData = this.getView().getModel("myOppDialogModel").getData();
					if (oppData) {
						//Set request 'opportunity' payalod
						appView.oFinalData.NewOppDetails = {
							STATUS: oppData.STATUS,
							CURR_PHASE: oppData.CURR_PHASE,
							STATUS_DESC: formatter.getOppState(oppData.STATUS),
							CURR_PHASE_DESC: formatter.getCurrentPhase(oppData.CURR_PHASE),
							CLOSE_DATE:formatter._setDateFormat(oppData.EXPECT_END),
							Opp_Sales_Office:appView.oFinalData.salesOfficeText,
							Opp_Partner:appView.oFinalData.oppPartnerName,
							Opp_SalesGroupName:	appView.oFinalData.salesGroup,
							Opp_InternalOrder:appView.oFinalData.internalOrder,
							Opp_SalesOrg_Name:appView.oFinalData.SalesOrg,
							Executive_Summary:appView.oFinalData.executiveSummary,
							DealInfo: ""
						};
					}
					}else{
						//request type 'Account'
						appView.oFinalData.NewOppDetails = {
							STATUS:"",
							CURR_PHASE: "",
							STATUS_DESC: "",
							CURR_PHASE_DESC: "",
							CLOSE_DATE:"",
							Opp_Sales_Office:"",
							Opp_Partner:"",
							Opp_SalesGroupName:	"",
							Opp_InternalOrder:"",
							Opp_SalesOrg_Name:"",
							DealInfo:""
						};
					}

				this._getConstants();
				this.onCallCreateRequest();
				appView.listView._onResetModels();
				sap.ui.core.BusyIndicator.hide();
			},
			_getConstants: function () {
				//get rule-service information
				let oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
				const oPayload = {
					"RuleServiceId": oAppConstantsModel.getProperty("/RuleServiceId/0/Value"),
					"RuleServiceRevision": oAppConstantsModel.getProperty("/RuleServiceRevision/0/Value"),
					"Vocabulary": [{
						"SourceSystemDetails": {
							"SystemID": oAppConstantsModel.getProperty("/SystemId/0/Value")
						}
					}]
				}
				models.callBusinessRulesSrv(oPayload, this, this, this.successBusinessRulesSrvCallBack);
			},
			successBusinessRulesSrvCallBack: function (oResult, self) {
				if (oResult.Result.length === 0) {
					//const sErrorText = CommonJS.getLocalTextByi18nValue("BUSINESS_RULES_RESULT_ERROR");
					//MessageBox.error(sErrorText);
				} else {
					self.urlToMyInbox = oResult.Result[0].TargetSystemDetails.MyInbox;
					self.urlToHarmony = oResult.Result[0].TargetSystemDetails.Harmony;
					self.urlToAccount = oResult.Result[0].TargetSystemDetails.Account;
					self.workflowDefinitionID = oResult.Result[0].TargetSystemDetails.DefinitionId;
					self.getOwnerComponent().getModel("appConstants").setProperty("/MelodyDashboard" , oResult.Result[0].TargetSystemDetails.MelodyDashboard);
				}
				// self._getRequestHistoryDetails(self.oController.aOpportunityWFIds);
			},
			onCallCreateRequest: function () {
				this.oCreateDialog.close();
				//trigger wf Request
				let oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
				if(!appView.oFinalData.isResourceProfile){
					this.aSelectedReqAreas = this.detailView.aSelectedReqAreas
				}
				appView.oFinalData.systemId = oAppConstantsModel.getProperty("/SystemId/0/Value")
				appView.oFinalData.requesterDetails = {
					email: this.getOwnerComponent().getModel("userDetails").getProperty("/email").toLowerCase(),
					fullName: this.getOwnerComponent().getModel("userDetails").getProperty("/name"),
					id: this.getOwnerComponent().getModel("userDetails").getProperty("/user_name").toUpperCase()
				};
				const sHarmonyURL = this.urlToHarmony+appView.oFinalData.opportunityId;
				if(!appView.oFinalData.isResourceProfile){	
					appView.oFinalData.OrgType = "SORG";	
					const aPublicSalesOrg = this.getView().getModel("publicSalesOrgModel").getData().value;
					if(appView.oFinalData.OrgType !== "PC"){
						if(appView.oFinalData.isNoMP){
							appView.oFinalData.ParentOrgID = appView.oFinalData.OrgID;
						}else{
							const oParentSalesOrg = aPublicSalesOrg.find(function (entry) {
							return entry.Sales_org_ID === appView.oFinalData.OrgID;
						});
						appView.oFinalData.ParentOrgID = oParentSalesOrg.Parent_SorgID;
						}
					}
					appView.oFinalData.aReqAreas = this.aSelectedReqAreas;
					appView.oFinalData.extSystemsUrls = {
						harmony: sHarmonyURL,
						myInbox: this.urlToMyInbox,
						AccountURL: `${this.urlToAccount}${appView.oFinalData.accountId}`,
						MRRUrl: this.getOwnerComponent().getModel("appConstants").getData().MRRUrl[0].Value,
						MRRInboxURL: this.getOwnerComponent().getModel("appConstants").getData().EmailUrl[0].Value,
						MelodyDashboard: this.getOwnerComponent().getModel("appConstants").getData().MelodyDashboard,
						EmailWorklistURL: this.getOwnerComponent().getModel("appConstants").getData().EmailWorklistURL[0].Value
					};
				}else{
					appView.oFinalData.OrgID = appView.oFinalData.selectedProfitCenter[0].SelectedGuid;
					appView.oFinalData.OrgType = "PC"
					appView.oFinalData.extSystemsUrls = {
						harmony: sHarmonyURL,
						myInbox: this.urlToMyInbox,
						AccountURL: `${this.urlToAccount}${appView.oFinalData.accountId}`,
						MRRUrl: this.getOwnerComponent().getModel("appConstants").getData().MRRUrl[0].Value,
						MRRInboxURL: this.getOwnerComponent().getModel("appConstants").getData().EmailUrl[0].Value,
						MelodyDashboard: this.getOwnerComponent().getModel("appConstants").getData().MelodyDashboard,
						EmailWorklistURL: this.getOwnerComponent().getModel("appConstants").getData().EmailWorklistURL[0].Value
					};
				}

				this._createCPWorkflowRequest();
			},
			_createCPWorkflowRequest: function () {
				appView.oFinalData.EngagementType=this.getOwnerComponent().getModel("mrrAppEngModel").getData().engagementSelectedKey				
				let oPayload = {
					"definitionId": this.workflowDefinitionID,
					"context": appView.oFinalData
				};

				models.callWorkflowSrv(oPayload, this, this, this._onSuccessCreateWFInstance);
			},
			_onSuccessCreateWFInstance: function (result, self) {
				appView.sInstanceID = result.id;
				self.getView().setBusy(false);
				const oRouter = self.getOwnerComponent().getRouter();
				if (self.getOwnerComponent().getRouter()["oHashChanger"].hash.includes("MyInbox")) {
					if (oHomePageView) {
						oHomePageView._onObjectMatched();
					}
				}else if(self.getOwnerComponent().getRouter()["oHashChanger"].hash === ""){
					appView.getOwnerComponent().getRouter().oHashChanger.setHash("MyInbox");
					oHomePageView._onObjectMatched();
				}else{
					oRouter.navTo("MyInbox");
				}

				self.oCreateDialog.close();

			},
			currentAvatarDisplay: function (userId) {
				return this.getOwnerComponent().getModel("appConstants").getProperty("/userImg/0/Value") + userId;
			},
			onAvatarPressed: function (oEvent) {
				sap.ui.core.BusyIndicator.show(0);
				let oView = this.getView(),
					oSourceControl = oEvent.getSource();
				if (!this._pUserPopover) {
					this._pUserPopover = Fragment.load({
						id: oView.getId(),
						name: "com.dealsupport.melodyrequest.fragments.UserInfoCard",
					}).then(function (oUserPopover) {
						oView.addDependent(oUserPopover);
						return oUserPopover;
					});
				}

				this._pUserPopover.then(function (oPopover) {
					oPopover.openBy(oSourceControl);
				});
				sap.ui.core.BusyIndicator.hide();
			},
			onPressEmpEmail: function (oEvent) {
				const sUrl = oEvent.getSource().getProperty("text");
				URLHelper.triggerEmail(sUrl, "Info Request - MRR", false, false, false, true);
			},
			_InitializeBusyIndicator:function(){
				if (!appView.pBusyIndicator) {
					appView.pBusyIndicator = appView.loadFragment({
						name: "com.dealsupport.melodyrequest.fragments.BusyDialog"
					});
				}

			},
			onOpenBusyDialog: function () {
				var oDialog = appView.byId("BusyDialog");
				oDialog.open();
			},
			onCloseBusyDialog: function () {
				var oDialog = appView.byId("BusyDialog");
				oDialog.close()
			},
			//open approver notification popover 
			_onOpenApproverNotificationPopOver: function () {
				if (!appView.pNotificationPopOver) {
					appView.pNotificationPopOver = appView.loadFragment({
						name: "com.dealsupport.melodyrequest.fragments.ApproverNotification"
					});
				}
				appView.pNotificationPopOver.then(function (oDialog) {
					oDialog.openBy(appView.byId("idOnSearchResourcesButton"));
				});
			},
			onProceedForParentPFCSearch:function(){
				appView.listView._onSelecteParentPFCNode(appView.listView);
				appView.detailViewScreen.onSearchResourceManagers(appView.detailViewScreen);
			},
			onDeclineParentSearch:function(){
				if(appView.getView().getModel("createReqFooterModel").getProperty("/isResourceAdmin")){
					const sVal = appView.getView().getModel("createReqFooterModel").getProperty("/approverId");
					appView.detailViewScreen.openResProfileDialog(appView.detailViewScreen, sVal);
				}else{

				}

			},
			onSelectSettings: function(oEvent){
				const oevt = oEvent.getSource();
				let oView = this.getView();
				if (!this._pActionSheetFragment) {
					this._pActionSheetFragment = Fragment.load({
						id: oView.getId(),
						name: "com.dealsupport.melodyrequest.fragments.SettingsAction",
						controller: this
					}).then(function (oActionSheet) {
						oView.addDependent(oActionSheet);
						return oActionSheet;
					});
				}
				this._pActionSheetFragment.then(function (oActionSheet) {
					oActionSheet.openBy(oevt);
				});
			},
			onClickReqAreaSettings: function(){
				appView.onOpenBusyDialog();
				var oView = this.getView();
				var oDialog = this.byId("userRoleDialog");
	
				if (!oDialog) {
					Fragment.load({
						id: oView.getId(),
						name: "com.dealsupport.melodyrequest.fragments.RequestAreaFragment",
						controller: this
					}).then(function (oFragment) {
						oView.addDependent(oFragment);
						oFragment.open();
					});
				} else {
					oDialog.open();
				}
				appView.onCloseBusyDialog()
			},
	
			onCancelReqArea: function () {
				// Handle cancel button press
				var oDialog = this.byId("userRoleDialog");
				if (oDialog) {
					oDialog.close();
				}
				
			},
			//open task message dialog when the task has been processed
			onOpenTaskProcessedMsgDialog:function(bOldRequest){
				let that = this;
				let oView = appView.getView();
				const wfInstanceModel = that.getOwnerComponent().getModel("wfInstanceModel"),
				i18nModel = that.getOwnerComponent().getModel("i18n").getResourceBundle();
				if(wfInstanceModel.getData()){
				if (!appView._pTaskNotificationDialog) {
					appView._pTaskNotificationDialog = Fragment.load({
						id: oView.getId(),
						name: "com.dealsupport.melodyrequest.fragments.taskCompleteMsg",
						controller: appView
					}).then(function (oTaskNotifyDialog) {
						appView.oTaskNotifyDialog = oTaskNotifyDialog;
						oView.addDependent(oTaskNotifyDialog);
						return oTaskNotifyDialog;
					});
				}
			    //open task message dialog / old request prompt
					this._pTaskNotificationDialog.then(function (oTaskNotifyDialog) {
						//get task details from WF_inbox service
						const sReqApproverName = wfInstanceModel.getProperty("/LastActionTaken_UserName"),
							sDTLastActivity_tdate = wfInstanceModel.getProperty("/DTLastActivity_tdate"),
							sDTLastActivity_ttime = wfInstanceModel.getProperty("/DTLastActivity_ttime"),
							sRefrenceID = wfInstanceModel.getProperty("/RefrenceID"),
							sAccountName = wfInstanceModel.getProperty("/Account_name"),
							sAccountID = wfInstanceModel.getProperty("/Account_ID"),
							sOpportunityDesc = wfInstanceModel.getProperty("/OpportunityDesc"),
							sOpportunityID = wfInstanceModel.getProperty("/OpportunityID"),
							sCurrentState = wfInstanceModel.getProperty("/CurrentState"),
							sOppUrl = wfInstanceModel.getProperty("/ExtSystemsUrl"),
							sInstanceID = wfInstanceModel.getProperty("/InstanceID"),
							sOppStyle = !sOpportunityDesc ? `style="display:none"` : `style="display:visible"`,
							sReportUrl = that.getOwnerComponent().getModel("appConstants").getProperty("/ReportLink/0/Value"),
							sReportText =  that.getOwnerComponent().getModel("appConstants").getProperty("/ReportLinkText/0/Value"),
							sTaskUrlFullDesc = that.getOwnerComponent().getModel("appConstants").getProperty("/taskNotFoundUrlDesc/0/Value"),
							sTaskUrlFullDescStyle = !that.getOwnerComponent().getModel("appConstants").getProperty("/taskNotFoundUrlDesc/0/Operational_Status") ? `style="display:none"` : `style="display:visible"`,
							sUrlStyle = !that.getOwnerComponent().getModel("appConstants").getProperty("/ReportLinkText/0/Operational_Status") ? `style="display:none"` : `style="display:visible"`,
							// sTaskDetails = `<h5>${i18nModel.getText("taskMsgMelodyReq")} ${sRefrenceID}</h5>
							sTaskDetails = `
			<ul>
			<li>${i18nModel.getText("taskMsgAccountNameID")}: ${sAccountName} ${sAccountID}</li>
			<li ${sOppStyle}>${i18nModel.getText("taskMsgOppDesc")}: ${sOpportunityDesc}</li>
			<li ${sOppStyle}>${i18nModel.getText("taskMsgOppID")}: <a href=${sOppUrl}>${sOpportunityID}</a></li>
			<li>${i18nModel.getText("taskMsgReqStatus")}: <strong>${sCurrentState}</strong></li>
			</ul>`,
			sTaskDesc = that.getOwnerComponent().getModel("appConstants").getProperty("/legacyTaskMsg/0/Value"),
			sTaskUrlText = that.getOwnerComponent().getModel("appConstants").getProperty("/legacyTaskUrlText/0/Value"),
			sTaskLegacyMsg = sanitizeHTML(`${sTaskDesc}<a style="display:visible" href="${that.getOwnerComponent().getModel("appConstants").getProperty("/oldAppUrl/0/Value")}/HomePage/${that.getOwnerComponent().getModel("appConstants").getProperty("/routePath")}/${sInstanceID}" target="_blank" class="sapMLnk">${sTaskUrlText}</a></p>`),
			// sHtmlMsg = !bOldRequest ? `<div><p></p><p>${i18nModel.getText("taskAlreadyActionedBy")} ${sReqApproverName} ${i18nModel.getText("on")} ${sDTLastActivity_tdate} ${sDTLastActivity_ttime} CET</p>
			// <p ${sTaskUrlFullDescStyle}>${sTaskUrlFullDesc} <a ${sUrlStyle} href="${sReportUrl}">${sReportText}</a></p>
			// ${sTaskDetails}
			// </div>`:`${sTaskLegacyMsg}${sTaskDetails}
			// </div>`
			sHtmlMsg = !bOldRequest ? `<div><p></p><p>${i18nModel.getText("unauthorizedTaskMsg")}  <strong>${i18nModel.getText("taskMsgMelodyReq")} ${sRefrenceID}</strong></p>
			
			${sTaskDetails}
			</div>`:`<div> ${sTaskLegacyMsg}${sTaskDetails}
			</div>`
						let oTaskProcessedModel = new JSONModel({
							HTML: sHtmlMsg,
							bIsOldReq:bOldRequest
						});
						models._getGetWfContextDetails(that, sInstanceID, that.fnSuccessGetContextDetails);
						that.getView().setModel(oTaskProcessedModel, "taskProcessedModel");
						oTaskNotifyDialog.open();
					});
				} else {
					const sResponsivePaddingClasses = "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer";
					MessageBox.error(i18nModel.getText("taskMsgDeletedMsg"), {
						title:i18nModel.getText("inValidTask"),
						contentWidth: "100px",
						actions: [MessageBox.Action.OK],
						styleClass: sResponsivePaddingClasses,
						dependentOn: that.getView(),
						onClose: function (oAction) {
							if (oAction === MessageBox.Action.OK) {
							that.onCloseTaskMsgDialog(that);
							}
						}
					});

				}
			},
			//close task message dialog
			onCloseTaskMsgDialog: function (evt) {
				if(this.byId("idMainHeader").getSelectedKey() !== 'Worklist'){
					//Refresh the open tasks
				const oReqMasterPageView = this.getOwnerComponent().getModel("appConstants").getProperty("/ReqMasterPage"),
					aMasterList = oReqMasterPageView.byId("id-list-pendingRequests").getItems(),
					oInitialList = aMasterList.length ? aMasterList[0]:false;
				sap.ui.core.BusyIndicator.show();
				if(oInitialList){
					//Open tasks  => select first open task and loas the details
					oReqMasterPageView.byId("id-list-pendingRequests").setSelectedItem(aMasterList[0]);
					oReqMasterPageView.byId("id-list-pendingRequests").fireSelectionChange();
				}else{
					//no open task
					sap.ui.core.BusyIndicator.hide();
				}
			}else{
				//Refresh the worklist page
				this.getOwnerComponent().getRouter().navTo("Worklist");
			}
				if(this.oTaskNotifyDialog){
					this.oTaskNotifyDialog.close();
				}	
			},
			 /**Git 277
         * fetch context of the request to display action history of old requests
         * @param {object} result - context response
         * @param {object} that -The context of the calling contollrer object, typically the controller.
         */
			fnSuccessGetContextDetails: function (result, that) {
				
				sap.ui.core.BusyIndicator.hide();
				result.EngagementType = result.EngagementType ? result.EngagementType : '0001'
				if (result.EngagementType === '0002')
					result.requestDetails.c2c_DealText = result.requestDetails.c2c_Deal ? "Yes" : "No"
				const oContextModel = new sap.ui.model.json.JSONModel(result);
				that.getView().setModel(oContextModel);
				that.getView().getModel().getProperty("/approvalHistory").reverse();
				var currentStateID = that.getOwnerComponent().getModel("wfInstanceModel").getData().currentStateID
				// if (!(currentStateID === 'REQSUB' || currentStateID === 'REQTER' || currentStateID === 'REQCRT')) {
					CommonJS._setActionHistoryModel(that);
					//that.handleSCBtnPress()
				// } else {
				
				// }
			
				setTimeout(function () {
					that.getView().setBusy(false);
				}, 1000, this);
				sap.ui.core.BusyIndicator.hide();
				that.getView().setBusy(false);

			},
			_getBaseSubstituteUrl:function(){
				return this._getRuntimeBaseURL() + "/cap";
			},
			onChangeSubstInput:function(oEvent){
			let sInputVal = oEvent.getParameter("value") ? oEvent.getParameter("value").toUpperCase():oEvent.getParameter("selectedItem").getText();
			this.getView().getModel("userIdModel").setProperty("/userID",sInputVal.trim());
				if(sInputVal.length >= 3){
					//call the ore employee service=> get active ore record and melody request flag is true
					models._CallSubsEmployeeService(this.fnSuccessEmpCallback,sInputVal,this);
					const oSubsModelContext = oEvent.getSource().getModel("subsEmployeeService").getData(),
					sUserId = this.getView().getModel("userIdModel").getProperty("/userID"),
					oSelectedContext = oSubsModelContext.filter(subs=>subs.Id === sUserId);
					if(oSelectedContext.length){
						//validation on the substitute inputs
						let sUserName = oSelectedContext[0].lastName ?`${oSelectedContext[0].firstName} ${oSelectedContext[0].lastName}`:oSelectedContext.firstName
						this.getView().getModel("userIdModel").setProperty("/SubstituteID",oSelectedContext[0].ID);
						this.getView().getModel("userIdModel").setProperty("/SubstituteEmail",oSelectedContext[0].email);
						this.getView().getModel("userIdModel").setProperty("/SubstituteName",sUserName);
						this.getView().getModel("userIdModel").setProperty("/substValueState", "None");
						this.getView().getModel("userIdModel").setProperty("/saveSubstEnable", true);
						this._onValidateUser();
					}else{
						//validation on the substitute inputs
						let sUserValidationText = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("inValidUser");
						this._setUserErrorValueState(sUserValidationText);
						this.getView().getModel("userIdModel").setProperty("/saveSubstEnable", false);
					}
					
				}else{
					//validation on the substitute inputs
					this.getView().getModel("subsEmployeeService").setData([]);
					this.getView().getModel("subsEmployeeService").refresh();
					let sUserValidationText = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("inValidUser");
					this._setUserErrorValueState(sUserValidationText);
					this._onValidateUser();
					this.getView().getModel("userIdModel").setProperty("/saveSubstEnable", false);
				}
				this.getView().getModel("userIdModel").refresh();
			},
			_setUserErrorValueState:function(sValueStateText){
				//set substitute inputs value state
				this.getView().getModel("userIdModel").setProperty("/substValueState", "Error");
				this.getView().getModel("userIdModel").setProperty("/substMessageStripVisible", false);
				this.getView().getModel("userIdModel").setProperty("/substValueStateText", sValueStateText);
				this.getView().getModel("userIdModel").setProperty("/saveSubstEnable", false);
			},
			fnSuccessEmpCallback:function(data,oController){
				//success call for ore employee service
				let sUserId = oController.getOwnerComponent().getModel("userDetails").getData().user_name,
					aFinalUser = data.d.results.filter(item=> item.Id !== sUserId );
				oController.getView().getModel("subsEmployeeService").setData(aFinalUser);
				oController.getView().getModel("subsEmployeeService").refresh();
			},
			onClickDelegateSettings: function(){
				//open substitute-processor dialog
				appView.onOpenBusyDialog();
				var oView = this.getView();
				var oDialog = this.byId("idDelegateDialog");
				const that = this;
				this.getView().getModel("userDataModel").setProperty("/bTextDisplay", true);
				if (!oDialog) {
					Fragment.load({
						id: oView.getId(),
						name: "com.dealsupport.melodyrequest.fragments.Delegate",
						controller: this
					}).then(function (oFragment) {
						//reset substitute inputs
						that.resetDataWhenUserSearchIsOff();
						oView.addDependent(oFragment);
												oFragment.open();
					});
				} else {
					that.resetDataWhenUserSearchIsOff();
					oDialog.open();
				}
				let sUserId = this.getOwnerComponent().getModel("userDetails").getData().user_name,
					sUrlParams = {
						$filter: `ManagerId eq '${sUserId}' and Active eq true`,
					}
					//call ore employee service
				this._getSubstituteData(sUrlParams);	
				appView.onCloseBusyDialog();
			},
			_getWorkflowRuntimeBaseURL: function () {
				return this._getRuntimeBaseURL() + "/workflowruntime/";
			},
			_getRuntimeBaseURL: function () {
				const appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
				const appPath = appId.replaceAll(".", "/");
				const appModulePath = sap.ui.require.toUrl(appPath);
				return appModulePath;
			},
			onDeleteSubstitute:function(oEvent){
				//delete substitute record
				const oSelectedContext = oEvent.getSource().getBindingContext("delegateModel").getObject(),
					sBaseUrl = this._getBaseSubstituteUrl(),
					that = this;
					this._deleteSubstituteData(oSelectedContext);
			},
			onChangeRange : function(oEvent) {
				//date range change
				let that = this,
					oFormat = DateFormat.getDateInstance({
				pattern : "yyyyMMdd"
			}),
				oSelectedDates = oEvent.getSource().getSelectedDates(),
				oCalendar = this.getView().byId("selectionCalendar"),
				dFromDateRaw = ( oSelectedDates[0].getStartDate() ),
				oSelectDatesPage = this.getView().byId("date_selection"),
				dCurrentRaw =  new Date(),
				dCurrent = oFormat.format( ( dCurrentRaw ) ),
				dFromDate = oFormat.format( dFromDateRaw ),
				dFromDateToDisplay = that.oFormatToDisplay.format( dFromDateRaw ),
				dToDateRaw = ( oSelectedDates[0].getEndDate() ),
				dToDate = null,
				i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();

			// if to date and from date, both are selected
			if (dToDateRaw != null) { // eslint-disable-line eqeqeq
				dToDate = oFormat.format( dToDateRaw );
				var dToDateToDisplay = that.oFormatToDisplay.format( dToDateRaw );
				if ( dFromDate < dCurrent || dToDate < dCurrent ) { // if selected dates are not valid
					oCalendar.removeAllSelectedDates(); // unselect all dates
					dFromDate = dCurrent; // set current date to from date
					dToDate = null; // set to date as null
					this.getView().getModel("userDataModel").setProperty("/period",i18nModel.getText("substn.dateSelection.from") + " "  + "" ); // donot show any date selected under substitution period
					return; // donot process further
				};
				// display start date and end date under substitution period
				this.getView().getModel("userDataModel").setProperty("/period", i18nModel.getText("substn.dateSelection.from")+ " "  + dFromDateToDisplay + " " + i18nModel.getText("substn.dateSelection.to")+ " "  + dToDateToDisplay);

			}
			// if only from date is selected
			else if (dFromDate < dCurrent ) { // if from date is invalid
				dFromDate = dCurrent; // set current date as from date
				oCalendar.removeAllSelectedDates(); // unselect all selected dates
			}
			else { // if from date is valid
				this.getView().getModel("userDataModel").setProperty("/period", i18nModel.getText("substn.dateSelection.from")+ " "  + dFromDateToDisplay + ""); //display fromdate under substitution period
			}
			oSelectedDates = { startDate: dFromDate, endDate: dToDate };
			let sFromDate;
			let sToDate;

			if (oSelectedDates) {
				sFromDate = new Date(dFromDate.replace(/(\d{4})(\d{2})(\d{2})/g, '$1-$2-$3'))
				.toISOString().split('T')[0];
				sToDate = dToDate ? new Date(dToDate.replace(/(\d{4})(\d{2})(\d{2})/g, '$1-$2-$3')).toISOString().split('T')[0] : dToDate;
			}
			else {
				sFromDate = new Date().toISOString().split('T')[0];
			}

			let endDateInputValue = sToDate;
			let startDateInputValue = sFromDate;

			if (endDateInputValue) {
					oSelectedDates.endDate  =endDateInputValue;
			}
			else {
					oSelectedDates.endDate= startDateInputValue;
			}
			
			if (startDateInputValue) {
					oSelectedDates.startDate =startDateInputValue;
			}
			this.getView().getModel("userDataModel").setProperty("/selectedDates", oSelectedDates); 
			this._onValidateUser();
			},
		resetDataWhenUserSearchIsOff: function() {
			//reset substitute inputs
			let oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
				oAppConstantsModel.setProperty("/delegateSearchValue", "");
				oAppConstantsModel.setProperty("/setNoDataDelegate", false);
				oAppConstantsModel.refresh();
				const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				let noDataText = i18nModel.getText("noDataSubst");
				this._setDefaultIlluStartionMsg(noDataText);
			if (!this.userIdModel) {
				this.userIdModel = new JSONModel();
				this.getView().setModel(this.userIdModel, "userIdModel");
			}
			const oSelectedDates = {
				startDate: new Date().toISOString().split('T')[0],
				endDate: new Date().toISOString().split('T')[0]
				};
			
			this.getView().getModel("userIdModel").setProperty("/userID", "");
			this.getView().getModel("userIdModel").setProperty("/saveSubstEnable", false);
			this.getView().getModel("userIdModel").setProperty("/substValueState", "None");
			this.getView().getModel("userIdModel").setProperty("/substValueStateText", "");
			this.getView().getModel("userIdModel").setProperty("/selectedSubTab", "mysubs");
			this.getView().byId("idDelegateTab").setSelectedKey("mysubs");
			this.getView().getModel("userIdModel").setProperty("/substMessageStripVisible", false);
			let oCalendar = this.getView().byId("selectionCalendar");
			oCalendar.removeAllSelectedDates();
			this.getView().getModel("userDataModel").setData({});
			this.getView().getModel("userDataModel").setProperty("/profileParameters", "" );
			this.getView().getModel("userDataModel").setProperty("/period", i18nModel.getText("substn.create.default_date") );
			this.getView().getModel("userDataModel").setProperty("/selectedDates", oSelectedDates); 
			oCalendar.focusDate( new Date() ); // reset the calender's focus date
		},
		_onValidateUser:function(){
			//validate employee
			let oSelectedDates =  this.getView().getModel("userDataModel").getProperty("/selectedDates"),
				sSubstUser =  this.getView().getModel("userIdModel").getProperty("/userID"),
				oDelegateModelData = this.getView().getModel("delegateModel").getData(),
				bUserValidation = false;
			if(oDelegateModelData.length){
				oDelegateModelData.forEach(function(user){
					if(sSubstUser === user.SubstituteID){
						bUserValidation = true;
					}
				});
			}
			if(this.getView().getModel("userIdModel").getProperty("/substValueState") ==="None" && sSubstUser){
				this.getView().getModel("userIdModel").setProperty("/saveSubstEnable", true);
			}else{
				this.getView().getModel("userIdModel").setProperty("/saveSubstEnable", false);
			}
		},
		onCloseSubsDialog:function(){
			var oDialog = this.byId("idDelegateDialog");
			if (oDialog) {
				oDialog.close();
			}
		},
		handleCreateSubstitutionPopOverSave : function() {
			//update substitute payload oEntry
			let oEntry = {
				"active": true,
				"manager_id" :this.getOwnerComponent().getModel("userDetails").getData().user_name
			},
			oSubsUserModel = this.getView().getModel("userIdModel");
			oEntry.substitute_id = oSubsUserModel.getProperty("/userID");
			let oDatesSelected = this.getView().getModel("userDataModel").getProperty("/selectedDates");
		

			if (oDatesSelected) {
				oEntry.valid_from =new Date(oDatesSelected.startDate).toISOString();
				oEntry.valid_to =new Date( oDatesSelected.endDate).toISOString();
			}
			else {
				oEntry.valid_from = new Date().toISOString();
				oEntry.valid_to = new Date().toISOString();
			}
			
			this._postSubstituteData(oEntry);
		},
			onCancelReqArea: function () {
				// Handle cancel button press
				var oDialog = this.byId("userRoleDialog");
				if (oDialog) {
					oDialog.close();
				}
				
			},
			_deleteSubstituteData: async function (oEntry) {
				//delete substitute record
				try {
					const oIntLSModel = models.systemLSUserDetailsDataModel(this, true),
						that = this;
					sap.ui.core.BusyIndicator.show();
					let oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
					oAppConstantsModel.setProperty("/setNoDataDelegate", true);
					oAppConstantsModel.refresh();
			
					const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
					let noDataText = i18nModel.getText("noDataSubst");
					this._setDefaultIlluStartionMsg(noDataText);
					let sDeleteUrl = `(guid=guid'${oEntry.GUID}',manager_id='${oEntry.ManagerId}',substitute_id='${oEntry.SubstituteId}')`;
			
					await models._callDeleteOdata(oIntLSModel, `/YC_MR_T_SUBSSet${sDeleteUrl}`);
			
					let sUrlParams = {
						$filter: `ManagerId eq '${oEntry.ManagerId}' and Active eq true`,
					};
					await that._getSubstituteData(sUrlParams); 
					sap.ui.core.BusyIndicator.hide();
			
				} catch (oError) {
					sap.ui.core.BusyIndicator.hide();
					ErrorHandle.setErrorMessage(oError, this);
				}
			},
			_postSubstituteData: async function (oEntry) {
				//add substitute
				try {
					const oIntLSModel = models.systemLSUserDetailsDataModel(this, true);
					sap.ui.core.BusyIndicator.show();
			
					await models._callPOSTOdata(oIntLSModel, `/YC_MR_T_SUBSSet`, oEntry);
			
					let sUrlParams = {
						$filter: `ManagerId eq '${oEntry.manager_id}' and Active eq true`,
					};
					await this._getSubstituteData(sUrlParams);
					sap.ui.core.BusyIndicator.hide();
				} catch (oError) {
					sap.ui.core.BusyIndicator.hide();
					// ErrorHandle.setErrorMessage(oError, this);
				}
			},
			_getSubstituteData: function (sUrlParams) {
				//oData get call for substitute
				const oIntLSModel = models.systemResourcesDataModel(this),
					that = this,
					oBusyDialog = new sap.m.BusyDialog();
					if(that.getView().byId("idDelegateTab") && that.getView().byId("idDelegateTab").getSelectedKey() === "subsFor" && !sUrlParams.$filter.includes("SubstituteId")){
						that.getView().byId("idDelegateTab").setSelectedKey("mysubs");
					}
					oBusyDialog.open(0)
					//   this.byId("idDelegateDialog").getContent()[0].getContent()[0].getMainContent()[0].getContent()[0].setBusy(true);
					
				models._callGETOdata(oIntLSModel, `/YC_MR_T_SUBSTITUTE`,sUrlParams).
					then(function (data) {
						let oDelegateModel = new sap.ui.model.json.JSONModel(data.results);
						that.getView().setModel(oDelegateModel, "delegateModel");
						that.getView().getModel("delegateModel").refresh();
						let oAppConstantsModel = that.getOwnerComponent().getModel("appConstants");
						if(!that.getView().getModel("userIdModel")){
							that.getView().setModel( new JSONModel(), "userIdModel");
							that.getView().getModel("userIdModel").setProperty("/substMessageStripVisible", false);
						}
						oAppConstantsModel.setProperty("/delegateSearchValue", "");
						oAppConstantsModel.setProperty("/setNoDataDelegate", true);
						if(!data.results.length){
							oAppConstantsModel.setProperty("/showSeparators", "None");
						}else{
							oAppConstantsModel.setProperty("/showSeparators", "All");
						}
						oAppConstantsModel.refresh();
						oBusyDialog.close();
					})
					.catch(function (oError) {
						sap.ui.core.BusyIndicator.hide();
						oBusyDialog.close();
						let oAppConstantsModel = that.getOwnerComponent().getModel("appConstants");
						oAppConstantsModel.setProperty("/setNoDataDelegate", true);
						oAppConstantsModel.setProperty("/showSeparators", "None");
						oAppConstantsModel.refresh();
						ErrorHandle.setErrorMessage(oError, that);
					});
				
			},
			onSelectDelegateTab: function (oEvent) {
				//substitute tab selection
				const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				let oAppConstantsModel = this.getOwnerComponent().getModel("appConstants"),
				noDataText = (oEvent.getParameter("selectedKey") === 'subsFor') ? i18nModel.getText("noDataSubstFor") : i18nModel.getText("noDataSubst");
				oAppConstantsModel.setProperty("/setNoDataDelegate", false);
				oAppConstantsModel.setProperty("/delegateSearchValue", "");
				oAppConstantsModel.refresh();
				oAppConstantsModel.refresh();
				this.getView().getModel("delegateModel").setData();
				let sUserId = this.getOwnerComponent().getModel("userDetails").getData().user_name,
					sUrlParams = (oEvent.getParameter("selectedKey") === 'subsFor') ?
						{
							$filter: `SubstituteId eq '${sUserId}' and Active eq true`,
						} :
						{
							$filter: `ManagerId eq '${sUserId}'and Active eq true`,
						}
				
						this._setDefaultIlluStartionMsg(noDataText);
				this._getSubstituteData(sUrlParams)
			},
			handleDelegateSubsSearch: function onSearchTerritory(oEvent) {
				//substitute search
				const sVal = oEvent.getParameter("newValue") ? oEvent.getParameter("newValue"):oEvent.getParameter("query"),
					  sFinalVal = sVal ? sVal.toLowerCase():'';
				let oFilter;
				if (sFinalVal) {
					oFilter = new Filter([
						new Filter("SubstituteName", FilterOperator.Contains, sFinalVal),
						new Filter("SubstituteId", FilterOperator.Contains, sFinalVal)
					], false);
				} else {
					oFilter = []
				}
				oEvent.getSource().getParent().getParent().getBinding("items").filter([oFilter]);
				const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				this._updateControlBinding(oEvent,i18nModel.getText("noDataSubst"),i18nModel.getText("noSearchSubst"))
				
			},
			_setDefaultIlluStartionMsg:function(noDataText){
				//set No Data message
				let oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
				oAppConstantsModel.setProperty("/illuStrationType", "sapIllus-EmptyPlanningCalendar");
				oAppConstantsModel.setProperty("/illuStrationTitle", noDataText);
				oAppConstantsModel.setProperty("/illuStrationDescription", false);
			},
			_updateControlBinding:function(oEvent,noDataText,noSearchText){
				let oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
				if(!oEvent.getSource().getParent().getParent().getItems().length && this.getView().getModel("delegateModel").getData().length){
					oAppConstantsModel.setProperty("/showSeparators", "None");
					oAppConstantsModel.setProperty("/illuStrationType", "sapIllus-NoSearchResults");
					oAppConstantsModel.setProperty("/illuStrationTitle",noSearchText);
					oAppConstantsModel.setProperty("/illuStrationDescription",true);
				}else{
					this.getView().getModel("delegateModel").getData().length ? 
					oAppConstantsModel.setProperty("/showSeparators", "All"):oAppConstantsModel.setProperty("/showSeparators", "None");
					oAppConstantsModel.setProperty("/illuStrationType", "sapIllus-EmptyPlanningCalendar");
					oAppConstantsModel.setProperty("/illuStrationTitle", noDataText);
					oAppConstantsModel.setProperty("/illuStrationDescription",false);
				}
				oAppConstantsModel.refresh();

			},
			handleDelegateSubsForSearch: function(oEvent) {
				//substitute changes
				let sValue = oEvent.getParameter("newValue") ? oEvent.getParameter("newValue").toLowerCase():oEvent.getParameter("newValue");
				let oFilter;
				if (sValue) {
					oFilter = new Filter([
						new Filter("ManagerName", FilterOperator.Contains, sValue),
						new Filter("ManagerId", FilterOperator.Contains, sValue)
					], false);
				} else {
					oFilter = []
				}
				oEvent.getSource().getParent().getParent().getBinding("items").filter([oFilter]);
				const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				this._updateControlBinding(oEvent,i18nModel.getText("noDataSubstFor"),i18nModel.getText("noSearchSubstFor"))
				
			},
			onOpenRouteBusyDialog: function () {
				// load BusyDialog fragment asynchronously
				if (!this._pBusyDialog) {
					this._pBusyDialog = Fragment.load({
						name:"com.dealsupport.melodyrequest.fragments.RoutingBusyDialog",
						controller: this
					}).then(function (oBusyDialog) {
						this.getView().addDependent(oBusyDialog);
						return oBusyDialog;
					}.bind(this));
				}
	
				this._pBusyDialog.then(function(oBusyDialog) {
					oBusyDialog.open();
				}.bind(this));
			},
			onRouteBusyDialogClosed: function (oEvent) {
				if(this._pBusyDialog){
					this._pBusyDialog.then(function(oBusyDialog) {
						oBusyDialog.close();
					});
				}
			},
		});
	}
);
