sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/ui/core/format/DateFormat",
    "sap/ui/core/Fragment",
    "sap/ui/core/syncStyleClass",
    "sap/m/Text",
    "sap/m/TextArea",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "com/dealsupport/melodyrequest/model/formatter",
    "sap/m/Dialog",
    "sap/m/Button",
    "sap/m/MessageBox",
    "com/dealsupport/melodyrequest/model/models",
    "com/dealsupport/melodyrequest/control/ErrorHandle",
    "com/dealsupport/melodyrequest/model/users",
    "com/dealsupport/melodyrequest/control/Common",
    "sap/ui/model/odata/v2/ODataModel",
    "sap/m/library",
    "com/melody/lib/controls/RapidRegistration/RapidRegistration",
    "com/melody/lib/service/ActivityService",
    "sap/base/security/sanitizeHTML",
    "com/melody/lib/service/OpportunityService",
     "sap/ui/comp/personalization/Controller",
], function (Controller, JSONModel, MessageToast, DateFormat, Fragment, syncStyleClass, Text, TextArea,
    Filter, FilterOperator, formatter, Dialog, Button, MessageBox, Models, ErrorHandle,users,CommonJS,ODataModel,library,RapidRegistrationLibrary,ActivityService,sanitizeHTML,OpportunityService,TablePersoController){
    let workflowInstanceId,
        token;
    "use strict";

    return Controller.extend("com.dealsupport.melodyrequest.controller.ManagerDetailPage", {

        formatter: formatter,
        common:CommonJS,
        onInit: function () {
            this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
            this.bInitialLoad = true;
            this.getOwnerComponent().getModel("appConstants").setProperty("/isAfterWfAction", false);
            if (this.getOwnerComponent().getRouter().getRoute("ManagerDetailPage")) {
                this.getOwnerComponent().getRouter().getRoute("ManagerDetailPage").attachPatternMatched(this._onObjectMatched, this);
            }
            if (this.getOwnerComponent().getRouter().getRoute("ManagerReqView")) {
                this.getOwnerComponent().getRouter().getRoute("ManagerReqView").attachPatternMatched(this._onObjectMatched, this);
            }
            const oCrossCvgModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oCrossCvgModel, "crossCvgMasterData");
            const oBALobModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oBALobModel, "baLoBMasterData");
            const oBAIndModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oBAIndModel, "baIndMasterData");
            //set model for  salesOrg Map for legacy or old requests to map with sales org profit center
            let opcmodel = new sap.ui.model.json.JSONModel( this.getOwnerComponent().getModel("PCSalesOrgMasterData").getData());
            this.getView().setModel(opcmodel, "PCSalesOrgMaster");
            const oTerritoryMasterModel = new sap.ui.model.json.JSONModel([]);
            this.getView().setModel(oTerritoryMasterModel, "territoriesMaster");

        },
        navToReqView:function(){
            this.getOwnerComponent().getRouter().navTo("Worklist");
        },
        addNavButtoninWF: function(){
            var oExpTitleText = this.getView().byId("idExpMTitleHeading");
            var oSnapTitleText = this.getView().byId("idSnapMTitleHeading");
            var oHBoxExp = this.getView().byId("hboxExpMTitle");
            var oHBoxSnap = this.getView().byId("hboxSnapMTitle");
            if (this.oButtonExp) {
                oHBoxExp.removeItem(this.oButtonExp);
                this.oButtonExp.destroy();
                this.oButtonExp = null;
            }

            if (this.oButtonSnap) {
                oHBoxSnap.removeItem(this.oButtonSnap);
                this.oButtonSnap.destroy();
                this.oButtonSnap = null;
            }

            if (this.getOwnerComponent().getModel("appConstants").getProperty("/isReqView")) {
                if (!this.oButtonExp) {
                var oButtonExp = new sap.m.Button({
                    type:"Back",
                    visible: true,
                    press: this.navToReqView.bind(this)
                }).addStyleClass("customBackBtnClassReqView");

                var oButtonSnap = new sap.m.Button({
                    type:"Back",
                    visible: true,
                    press: this.navToReqView.bind(this)
                }).addStyleClass("customBackBtnClassReqView");

                
                oHBoxExp.insertItem(oButtonExp, 0);
                oHBoxSnap.insertItem(oButtonSnap, 0);
            }
                oExpTitleText.addStyleClass("sapUiTinyMarginTop");
                oSnapTitleText.addStyleClass("sapUiTinyMarginTop");
                this.getView().byId("idMngrHeaderCnt").addStyleClass("customStyleHeaderCntClass");
                this.getView().byId("idMngrDynamicHeader").addStyleClass("customStyleObjTitleClass");
            
                this.oButtonExp = oButtonExp;
                this.oButtonSnap = oButtonSnap;
            } else {
                
                oExpTitleText.removeStyleClass("sapUiTinyMarginTop");
                oSnapTitleText.removeStyleClass("sapUiTinyMarginTop");
                this.getView().byId("idMngrHeaderCnt").removeStyleClass("customStyleHeaderCntClass");
                this.getView().byId("idMngrDynamicHeader").removeStyleClass("customStyleObjTitleClass");
            }

        },
        //refresh the task
        onRefreshDetailPage:function(){
            this._onObjectMatched(this._oRouteObj);

        },
        fnCurrentStateSuccessCallback: function (oResult, self) {
            //initiate current state model
            self.getOwnerComponent().getModel("currentStateModel").setData(oResult);
            sap.ui.core.BusyIndicator.hide();
        },
        fnCurrentStateErrorCallback: function (oError, self) {
            MessageBox.error(oError.responseText, {
                contentWidth: "600px"
            });
            sap.ui.core.BusyIndicator.hide();
        },
        _onObjectMatched: function (evt) {
             this.activityPostResData = [];
            this.getView().byId("managerPageDynamicSideContent").setVisible(true);
            this.getView().byId("idManagerPage").setShowHeader(false);
            this.getOwnerComponent().getModel("appConstants").setProperty("/isOldVersionReq", false);
            this.getOwnerComponent().getModel("appConstants").setProperty("/oControllerScp", this);
            this.getOwnerComponent().getModel("appConstants").refresh();
            this._oRouteObj = evt;
            this.getView().setVisible(true);
            this.getOwnerComponent().getModel("appConstants").setProperty("/routePath","ManagerDetailPage");
            this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",[])
            this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/results",[])
            this.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
            this.oSLASearchContext = false;
            this.oSearchAddSlnContext = false;
            this.bSendBackToProcessor=false     //flag to check whether send back to processor was pressed or not- GIT #144
            if(evt.getParameter("name") === "ManagerReqView"){
                this.getOwnerComponent().getModel("appConstants").setProperty("/isReqView",true)
            }else{
                this.getOwnerComponent().getModel("appConstants").setProperty("/isReqView",false);
            }
            this.addNavButtoninWF();
            //Set Busy indicator for Req Info,Deal, comment and Linked sub req section
            this.getView().byId("idReqInfoSect").setBusy(true);
            this.getView().byId("idDealInfoTabBar").setBusy(true);
            this.getView().byId("idCommentsSec").setBusy(true);
            this.getView().byId("idSubTaskSec").setBusy(true);
            //this.getView().setBusy(true);
            this.sUserTaskId = false;
            this.aWfLogs = false;
            this.sRootInstanceId = evt.getParameter("arguments").ID;
            this.getOwnerComponent().getModel("appConstants").setProperty("/urlInstanceID", this.sRootInstanceId)
            this.i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            const sInstanceID = evt.getParameter("arguments").ID;
            if(this.bInitialLoad || evt.getParameter("name") === "ManagerReqView" ||  this.getOwnerComponent().getModel("appConstants").getProperty("/isAfterWfAction")){
                Models.getMyInboxInstanceDetails(this.fnSuccessCallback, this.fnErrorCallback, this, sInstanceID);
            }
            const sLoggedInUser = this.getOwnerComponent().getModel("userDetails").getProperty("/email");
            const oContextObject =  this.getOwnerComponent().getModel("wfInstanceModel").getData();
            const isCurrentProcesser = oContextObject ? formatter.formatUrl(oContextObject.CurrentProcessorEmail, sLoggedInUser, oContextObject.TechnicalState, oContextObject.currentStateID):false;
            if (isCurrentProcesser) {
                this.getView().byId("idManagerDetailMsg").setVisible(false);
                this.getView().byId("managerPageDynamicSideContent").setVisible(true);
                let sTaskDetails =  this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("taskDetailsText");
                CommonJS._OpenBusyIndicator(this,sTaskDetails);
                this.getView().byId("idManagerPage").setShowFooter(true);
                this.onLoadManagerRequest();
                //hide Action history content
                // const oDynamicSideView = this.getView().byId("managerPageDynamicSideContent");
                // oDynamicSideView.setShowSideContent(false);
                // //show action history
                // this.getView().byId("openSideContentBtnManagerPage").setVisible(true);
            } else {
                //task has been processed
                // this.getView().byId("managerPageDynamicSideContent").setVisible(false);
                this.getView().byId("managerPageDynamicSideContent").setVisible(false);
                this.getView().byId("idManagerPage").setShowFooter(false);
                //open task notification message
                sap.ui.core.BusyIndicator.hide();
                 CommonJS._closeBusyIndicator(this);
                this.getView().setBusy(false);
                appView.onOpenTaskProcessedMsgDialog();
                this.getView().setBusy(false);
            }
            this.bInitialLoad = false;
            this.getOwnerComponent().getModel("appConstants").setProperty("/isAfterWfAction",false);   
           
        },
        fnSuccessCallback: function (oResponse, self) {
            self.getOwnerComponent().getModel("wfInstanceModel").setData(oResponse.value[0]);
            self.getOwnerComponent().getModel("wfInstanceModel").refresh();
            sap.ui.core.BusyIndicator.hide();
        },
        fnErrorCallback: function (oError, self) {
            MessageBox.error(oError.responseText, {
                contentWidth: "600px"
            });
            sap.ui.core.BusyIndicator.hide();
        },
        getMessage: function (pMessage, aParametrs) {
            // read msg from i18n model
            var sMsg = "";
            let oMdlI18n = this.getOwnerComponent().getModel("i18n");
            if (oMdlI18n) {
                this._oBundle = oMdlI18n.getResourceBundle();
            } else {
                this._oBundle = null;
                return sMsg;
            }

            if (aParametrs && aParametrs.length) {
                sMsg = this._oBundle.getText(pMessage, aParametrs);
            } else {
                sMsg = this._oBundle.getText(pMessage);
            }

            return sMsg;
        },
        onLoadManagerRequest: function () {
             Models._getWfExecutionLogs(this, this.sRootInstanceId, this.fnSuccessGetExecutionLogs);
          
        },
        fnSuccessGetExecutionLogs: function (result, self) {
            //Get Wf execution logs to track task history
            sap.ui.core.BusyIndicator.hide();
            // self.getView().setBusy(false);
            if (result[result.length - 1].subflow) {
                for (let i = 0; i < result.length; i++) {
                    if (result[i].subflow) {
                        if (result[i].subflow.workflowInstanceId) {
                            setTimeout(function () {
                            Models._getWfExecutionLogs(self, result[i].subflow.workflowInstanceId, self.fnSuccessGetSubFlowExecutionLogs);
                        }.bind(self), 1000);
                        }
                    }
                }
            } else {
                self.sUserTaskId = result[result.length - 1].taskId;
                if (self.sUserTaskId) {
                    self.getView().byId("idManagerDetailMsg").setVisible(false);
                    self.getView().byId("managerPageDynamicSideContent").setVisible(true);
                    self.getView().byId("idManagerPage").setShowFooter(true);
                    Models._getWfTaskContextDetails(self, self.sUserTaskId, self.fnSuccessGetContextDetails);
                } else {
                    self.getView().byId("idManagerDetailMsg").setVisible(true);
                    self.getView().byId("managerPageDynamicSideContent").setVisible(false);
                    self.getView().byId("idManagerPage").setShowFooter(false);
                    self.getView().setBusy(false);
                    sap.ui.core.BusyIndicator.hide();
                      CommonJS._closeBusyIndicator(self);
                    const i18nModel = self.getOwnerComponent().getModel("i18n").getResourceBundle();
                    if(result[result.length-1].type.includes("FAILED")){
                        self.getView().byId("idManagerDetailMsg").setTitle(i18nModel.getText("taskFailed"));
                        self.getView().byId("idManagerDetailMsg").setDescription(i18nModel.getText("taskFailedDesc"));
                        self.getView().byId("idBtnDetRefresh").setVisible(false);
                        self.getView().byId("idManagerDetailMsg").setIllustrationType("sapIllus-ErrorScreen");
                        if (self.getOwnerComponent().getModel("appConstants").getProperty("/isReqView")) {
                            //execute on Request view
                            self.getView().byId("idManagerPage").setShowHeader(true);
                        } else {
                            //execute on Open task view
                            self.getView().byId("idManagerPage").setShowHeader(false);
                        }
                       
                    }else{
                        self.getView().byId("idBtnDetRefresh").setVisible(true);
                        self.getView().byId("idManagerDetailMsg").setTitle(i18nModel.getText("taskRefresh"));
                        self.getView().byId("idManagerDetailMsg").setDescription(i18nModel.getText("taskRefreshDesc"));
                        self.getView().byId("idManagerDetailMsg").setIllustrationType("sapIllus-ReloadScreen");
                        if (self.getOwnerComponent().getModel("appConstants").getProperty("/isReqView")) {
                            //execute on Request view
                            self.getView().byId("idManagerPage").setShowHeader(true);
                        } else {
                             //execute on Open task view
                            self.getView().byId("idManagerPage").setShowHeader(false);
                        }
                    }

                }
              

            }
        },
        //Get Subflow execution logs
        fnSuccessGetSubFlowExecutionLogs: function (result, self) {
            if (result[result.length - 1].recipientUsers) {
                const sLoggedInUserId = self.getOwnerComponent().getModel("userDetails").getProperty("/user_name").toUpperCase();
                const aRecipentUser = result[result.length - 1].recipientUsers.filter((user) => user.toUpperCase() === sLoggedInUserId);
                if (aRecipentUser.length) {
                    self.sUserTaskId = result[result.length - 1].taskId;
                    if (self.sUserTaskId) {
                        self.getView().byId("idManagerDetailMsg").setVisible(false);
                        self.getView().byId("managerPageDynamicSideContent").setVisible(true);
                        self.getView().byId("idManagerPage").setShowFooter(true);
                        Models._getWfTaskContextDetails(self, self.sUserTaskId, self.fnSuccessGetContextDetails);
                    } else {
                         CommonJS._closeBusyIndicator(self);
                        self.getView().byId("idManagerDetailMsg").setVisible(true);
                        self.getView().byId("managerPageDynamicSideContent").setVisible(false);
                        self.getView().byId("idManagerPage").setShowFooter(false);
                        self.getView().setBusy(false);
                        sap.ui.core.BusyIndicator.hide();
                        const i18nModel = self.getOwnerComponent().getModel("i18n").getResourceBundle();
                        if(result[result.length-1].type.includes("FAILED")){
                            self.getView().byId("idManagerDetailMsg").setTitle(i18nModel.getText("taskFailed"));
                            self.getView().byId("idManagerDetailMsg").setDescription(i18nModel.getText("taskFailedDesc"));
                            self.getView().byId("idBtnDetRefresh").setVisible(false);
                        }else{
                            self.getView().byId("idBtnDetRefresh").setVisible(true);
                            self.getView().byId("idManagerDetailMsg").setTitle(i18nModel.getText("taskRefresh"));
                            self.getView().byId("idManagerDetailMsg").setDescription(i18nModel.getText("taskRefreshDesc"));
                        }
                    }
                }
            }
        },
        fnSuccessGetWfTaskDetails: function (result, that) {
            //initaite task-history model
            const taskInstanceModel = new JSONModel(result);
            taskInstanceModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
            that.getView().setModel(taskInstanceModel, "taskInstanceModel");
            Models._getWfTaskContextDetails(that, that.sUserTaskId, that.fnSuccessGetContextDetails);
        },
        fnSuccessGetContextDetails: function (result, that) {
            that.getView().byId("idSaveandSubmitBtn").setEnabled(true);
            sap.ui.core.BusyIndicator.hide();
            result.EngagementType = result.EngagementType ? result.EngagementType : '0001'
            if(result.EngagementType==='0002')
                result.requestDetails.c2c_DealText=result.requestDetails.c2c_Deal?"Yes":"No"            
            const oContextModel = new JSONModel(result);
            that.getView().setModel(oContextModel);
            //  that.getContentDensityClass();
            //add OrgId,OrgType,RequestType for older tasks
            if (typeof (oContextModel.getData()["SalesOrgID"]) === "string") {
                oContextModel.getData()["OrgID"] = oContextModel.getData()["SalesOrgID"];
                oContextModel.getData()["OrgType"] = "SORG";
                oContextModel.getData()["RequestType"] = "Opportunity"
            }
            // document service interaction
            if (!oContextModel.getProperty("/currentStepID") && oContextModel.getProperty("/currentStepName") === "Presales Manager Approval") {
                oContextModel.setProperty("/currentStepID", "MANAPP")
            }
            // document service interaction
            that.oAttachmentsModel = new JSONModel();
            that.oAttachmentsModel.downloadEnabled = false;
            that.getView().setModel(that.oAttachmentsModel, "attachmentsModel");
           // that.loadAttachments(that);

            // let oModel = this.getView().getModel();
            that._fetchFormConfigData(that);  
            that._fetchFormActions(that);     

            oContextModel.setProperty("/namesOfPartiesVisible", false);
            const aInvolvedPartiesKeys = oContextModel.getProperty("/requestDetails/involvedPartiesKeys");
            if (aInvolvedPartiesKeys && aInvolvedPartiesKeys.length > 0) {
                if (aInvolvedPartiesKeys.includes("1") || aInvolvedPartiesKeys.includes("2") || aInvolvedPartiesKeys.includes("3")) { // if SAP Partner, SAP Consulting or Customer Advisory is selected
                    oContextModel.setProperty("/namesOfPartiesVisible", true);
                }
            }
            //i18n model
            that.i18nModel = that.getOwnerComponent().getModel("i18n").getResourceBundle();

           // Git 132 (Form template changes + add new opp fields)
            if(!that.getView().getModel().getProperty("/NewOppDetails/Opp_SalesOrg_Name") && that.getView().getModel().getProperty("/RequestType") === 'Opportunity'){
               //update new opp details for request created before the git 132 changes
                const oUrlParams = {
                    $expand: 'Notes,PartiesInvolved,DQReview,Attributes,CloseplanActivities,DocFlow,Attachments,Items,Pricing,RevenueSplitPlanH,RevenueSplitPlanI,SalesTeamWF,CustomerIncentive,S2SActivities,S2SActivities/PartiesInvolved,S2SActivities/Goals,RenewalExecution,OppHandover'
                };
                Models._getMyOpportunityDetails(that, that.getView().getModel().getProperty("/opportunityId"), oUrlParams, CommonJS.parseGetOppDataResponse);
            }else{
                //update deal info
                CommonJS.parseGetOppDataResponse(oContextModel.getProperty("/CPICalls/getDataFromCRM/Response/d/"),that);
            }
            that.getView().byId("idReqInfoSect").setBusy(false);
            that.getView().byId("idDealInfoTabBar").setBusy(false);
            // that._fetchFormActions(that);
            const sInstanceID = that.getOwnerComponent().getModel("wfInstanceModel").getProperty("/InstanceID");
            Models._getUserComments(that,sInstanceID,"GET")
             //call task service to filter sub-tasks
            Models.getSubTaskInstanceDetails(that);
            // that.configureView(oContextModel.getProperty("/currentStepName"));
            const oControlAssignmentTab = that.getView().byId("idAssignmentsSection");
            oControlAssignmentTab.setVisible(false);
            const oDefaultSection = that.getView().byId("idObjPageLayout").getSections()[0];
            that.getView().byId("idObjPageLayout").setSelectedSection(oDefaultSection);
            const oWFRoutingModel = new JSONModel(that._getWFRoutingBaseURL());
            that.getView().setModel(oWFRoutingModel, "WFRoutingAPIData");
            //Change Request to IO Staffing Working for EMEA #93 start
            //get skip io workflow task flag
            const oWFRoutingModelSkipIO = new JSONModel(that._getWFRoutingSkipIOBaseURL());
            that.getView().setModel(oWFRoutingModelSkipIO, "WFRoutingSkipIOAPIData");
            //Change Request to IO Staffing Working for EMEA #93 end
            const oIoOwnerModel = new JSONModel([]);
            that.getView().setModel(oIoOwnerModel, "ioOwnerISPModel");
            const oIoOwnerDetailsModel = new JSONModel([]);
            that.getView().setModel(oIoOwnerDetailsModel, "ioOwnerDetails");

            if (that.getView().getModel().getData().isResourceProfile) {
                that.getResProfileDetails();
                    CommonJS.setHeaderDetails(that);
            }
            //Git 132 (Form template/standardization ) - Set header fields
        
            //Call profitcenter master data --Git 181 Start
            // if(that.getOwnerComponent().getModel("territoriesPFCMaster").getData().length){
            //     Models._setSalesOrgProfitCenter(that,true)
            // }else{
            //     CommonJS._callProfitCenterMasterData(that,false,true);
            // }
            if (that.getOwnerComponent().getModel("mrrAppEngModel").getProperty("/TerritoryMasterDataEngType") !== result.EngagementType) {
                CommonJS._callProfitCenterMasterData(that,false,true,result.EngagementType);
            }else{
                Models._setSalesOrgProfitCenter(that,true)
            }
            //--Git 181 End
            //Git 132 (Form template/standardization ) - Get user comments
            that.getOwnerComponent().getModel("wfInstanceModel").setProperty("/bIsUserCommentInput",true);
            that.getOwnerComponent().getModel("wfInstanceModel").refresh();	

            /* Start of Code for CurrentTask Instance ID Update  */
           that.updateCurrentInstance();
            /* End of Code for CurrentTask Instance ID Update  */

            /*initialize assignments */
            that._initializeAssignments();
         
                CommonJS.getResFieldDetails(that);
          

            //setAttachment url visibility
            if (that.getView().getModel().getProperty("/requestDetails/attachmentUrls")) {
                const bAttachmentUrl = that.getView().getModel().getProperty("/requestDetails/attachmentUrls").length ? true : false;
                that.getView().getModel().setProperty("/isAttachmentUrl", bAttachmentUrl);
                if(bAttachmentUrl){
                    const aFinalAttachmentUrl = that.getView().getModel().getProperty("/requestDetails/attachmentUrls");
                    let bAttachmentFinalUrl = true;
                    aFinalAttachmentUrl.forEach(function(item,iIndex){
                        if(!item.url && !item.urlName){
                             bAttachmentFinalUrl = false;
                        }
                    });
                    that.getView().getModel().setProperty("/isAttachmentUrl", bAttachmentFinalUrl);
                }
                
            }
            that.getView().getModel().getData().isResourceProfile = (that.getView().getModel().getData().isResourceProfile) ? true : false;
            /* Set footer model for resource profile screen*/
            const i18nModel = that.getOwnerComponent().getModel("i18n").getResourceBundle();
            const sI18nError = i18nModel.getText("Error");
            const oProfileViewModel = new sap.ui.model.json.JSONModel();
            const oProfileView = {
                "footerButtons": {
                    "forwardReqButtonVisible": false,
                    "searchResourceButtonVisible": false,
                    "forwardReqButtonEnabled": false,
                    "searchResourceButtonEnabled": false,
                    "errorBtnVisible": false,
                    "errorBtnType": "Negative",
                    "errorBtnIcon": "sap-icon://error",
                    "errorBtnText": sI18nError
                }
            }
            oProfileViewModel.setData(oProfileView);
            that.getView().setModel(oProfileViewModel, "profileViewParameters");
            const oErrorModel = new sap.ui.model.json.JSONModel();
            const oErrorData = {
                "errorInformation": []
            }
            oErrorModel.setData(oErrorData);
            that.getView().setModel(oErrorModel, "errorMsgModel");


            //set pfc data in initial load
            const profitCenterSorgModel = new sap.ui.model.json.JSONModel();
            that.getView().setModel(profitCenterSorgModel, "selectedProfitCenter");

            let sorgIDPc;
            if (that.getView().getModel().getProperty("/OrgType") === "PC") {
                that.getView().getModel("PCSalesOrgMaster").getData().find(function (item) {
                    if (item.ProfitCenterGuid === that.getView().getModel().getProperty("/OrgID")) {
                        sorgIDPc = item.SOrg;
                    }
                });
            }
            that.getView().getModel().getProperty("/approvalHistory").reverse();
            that.getView().getModel().refresh();
            var currentStateID = that.getOwnerComponent().getModel("wfInstanceModel").getData().currentStateID
            if (!(currentStateID === 'REQSUB' || currentStateID === 'REQTER' || currentStateID === 'REQCRT')) {
                that.handleSCBtnPress()
            } else {
                that.handleSideContentHide()
            }
            if(sorgIDPc === "NOMP"){
                sorgIDPc = that.getView().getModel().getProperty("/OrgID")
            }
            
					setTimeout(function() {
						   that.getView().setBusy(false);
					}, 1000, this);
        //    that.handleSideContentHide();
           //set messagestrip for IO 
           const sStaffingMsg = that.getOwnerComponent().getModel("appConstants").getProperty("/ManualStaffing/0/Value");
           const sStaffingMsgUrl =  that.getOwnerComponent().getModel("appConstants").getProperty("/ManualStaffingURL/0/Value");
           const sStaffingMsgUrlText = that.getOwnerComponent().getModel("appConstants").getProperty("/ManualStaffingHyperlinkText/0/Value");
           const bStaffingUrlVisible = that.getOwnerComponent().getModel("appConstants").getProperty("/ManualStaffingHyperlinkText/0/Operational_Status");
           let sFinalStaffingMsg;
           if(sStaffingMsg.includes(sStaffingMsgUrlText) && bStaffingUrlVisible){
                //message with link
            const aSplitMsg = sStaffingMsg.split(sStaffingMsgUrlText)
             sFinalStaffingMsg = aSplitMsg[1] ? sanitizeHTML(`${aSplitMsg[0]} <a target="_blank" href="${sStaffingMsgUrl}">${sStaffingMsgUrlText}</a>${aSplitMsg[1]}`): 
             sanitizeHTML(`${aSplitMsg[0]} <a target="_blank" href="${sStaffingMsgUrl}">`)
           }else{
                //message without link
                sFinalStaffingMsg = sStaffingMsg;
            }
           //set staffing message model
           that.getView().setModel(new JSONModel({
            "staffingMsg":sFinalStaffingMsg
        }),"ioWorkFlowMessageModel");
            const sRequestType = that.getView().getModel().getProperty("/RequestType");
            that.getView().setModel(new JSONModel, "internalOrderModel");
             CommonJS._closeBusyIndicator(that);
             if (sRequestType === "Opportunity") {
               const oOppId = that.getView().getModel().getProperty("/opportunityId");
                /*Call opportunity service to update internal order start
                 @param {object} that - controller scope
                 @param {oOppId} string - opportunity number
                 */
                Models.getMyOpportunitiesIO(that, oOppId, "ioFetch");
             }
        sap.ui.core.BusyIndicator.hide();
        that.getView().setBusy(false);
            that.getView().getModel().setProperty("/bActionHistoryOpen", true);
            that.getView().getModel().refresh();
    
            let oModelData = that.getView().getModel().getData();
            let oAccountOwnerDetails = {accOwnerDetails:oModelData["accOwnerDetails"]};
            let oOppOwnerDetails = {oppOwnerDetails: oModelData["oppOwnerDetails"]};
            let aEmpIds = [
                oAccountOwnerDetails?.accOwnerDetails?.id,
                oOppOwnerDetails?.oppOwnerDetails?.id
            ].filter(Boolean);
            //Check opp/account owner details
            CommonJS.checkUserActive(that, aEmpIds, oAccountOwnerDetails, oOppOwnerDetails);
        },
       
        fetchResources: function (url, self, isCA, iStartIndex, iChunkSize, sSearchValue) {
            let sUrl;
            const that = this;
            if(sSearchValue){
                sUrl = url;
            }else{
                sUrl = url +  "&$top=" + iStartIndex + "&$skip=" + iChunkSize; 
            }
            //expand substitute query only applicable for named contact service
            let sFinalUrl = isCA ? sUrl + "&$expand=to_nmdsubstitute" :sUrl;
            $.ajax({
                url: sFinalUrl,
                dataType: 'json',
                async: false,
                method: "GET",
                success: function (data) {
                    const filteredData = data.d.results;
                    const sNo = self.i18nModel.getText("matchNo");
                    const sYes = self.i18nModel.getText("matchYes");                
                    const oResourcesModel = filteredData.map(item => ({
                        match: sNo,
                        SolId:item.SolId,
                        fullName: item.EmpName,
                        email: item.EmailId,
                        userId: item.Id || item.ResourceId,
                        partnerId: "",
                        address: "",
                        country: "",
                        ManagerId: item.ManagerId,
                        TrpcDesc: item.TrpcDesc,
                        RoleDesc: item.RoleDesc,
                        RoleAreaDesc: item.RoleAreaDesc,
                        BasegDesc: item.BasegDesc,
                        GroupL1: item.GroupL1,
                        GroupL2: item.GroupL2,
                        GroupL3: item.GroupL3,
                        MgrL1NameId: `${item.ManagerName} - ${item.ManagerId}`,
                        BaIndDesc: item.BaIndDesc,
                        SolAreaDesc: item.SolDesc,
                        IacDesc: item.IacDesc,
                        CrossCvrgDesc: item.CrossCvrgDesc,
                        ManagerLevel: item.ManagerLevel,
                        Trtrypc:item.Trtrypc,
                        ManagerId:item.ManagerId,
                        RoleGuid:item.RoleGuid,
                        SolL1Guid:item.SolL1Guid,
                        SolL2Guid:item.SolL2Guid,
                        SolL3Guid:item.SolL3Guid,
                        SolL4Guid:item.SolL4Guid,
                        SolL5Guid:item.SolL5Guid,
                        selected: false,
                        enabled: true,
                        btnEnabled: true,
                        HubDesc: item.HubDesc,
                        SolnHierarchy:item.SolnHierarchy,
                        GroupClusterDesc:item.GrpHierarchy,
						GroupCluster:item.GroupCluster,
						Groupl1Guid:item.Groupl1Guid,
						Groupl2Guid:item.Groupl2Guid,
						GroupL2:item.GroupL2,
						Groupl3Guid:item.Groupl3Guid,
						Groupl4Guid:item.Groupl4Guid,
						GroupL4:item.GroupL4,
						Groupl5Guid:item.Groupl5Guid,
                        GroupFullDesc: that.setGrpData({
                            GroupClstrGuid: item.GroupCluster,
                            GrpClstrDesc: that.getGroupClusterText(item.GroupCluster),
                            Groupl1Guid: item.Groupl1Guid,
                            GrpL1Desc: item.GroupL1,
                            Groupl2Guid: item.Groupl2Guid,
                            GrpL2Desc: item.GroupL2,
                            Groupl3Guid: item.Groupl3Guid,
                            GrpL3Desc: item.GroupL3,
                            Groupl4Guid: item.Groupl4Guid,
                            GrpL4Desc: item.GroupL4,
                            Groupl5Guid: item.Groupl5Guid,
                            GrpL5Desc: item.GroupL5
                        }),
                        resourceManagerDetails:{
                        EMAIL:item.ManagerEmail,
                        ID:item.ManagerId,
                        NAME:item.ManagerName,
                        ROLE:item.Manager_CrmRoleId},
                        to_nmdsubstitute:item.to_nmdsubstitute ? item.to_nmdsubstitute:[],
                        Emp_CrmRoleId:item.Emp_CrmRoleId ? item.Emp_CrmRoleId:[],
                    }));
        
                    const oResourceSelectionData = that.getView().getModel("ResProfileModel").getData();
                    
                    let aMatchResources = oResourcesModel.filter(user => {
                        let sQueryParams = oResourceSelectionData
                            .filter(selection => selection.queryParams !== "HubDesc")
                            .map(selection => {
                                let queryVal = selection.queryParams === "TrpcDesc"
                                    ? `${that.getView().getModel().getData().selectedProfitCenter[0].Desc}-${that.getView().getModel().getData().selectedProfitCenter[0].TrpcId}`
                                    : selection.Desc;
                                
                                return queryVal.split(",").map(q => `user.${selection.queryParams}.includes("${q}")`).join(" || ");
                            })
                            .join(" && ");
                        
                        return eval(`(${sQueryParams}) && (user.ManagerLevel === "non-managerial")`);
                    });
                    
                    const aHubs = oResourceSelectionData.filter(selection => selection.queryParams === "HubDesc");
                    
                    if (aHubs.length) {
                        const sHubList = aHubs[0].Desc.split(",");
                        aMatchResources.forEach(resource => {
                            const sResourceHubs = resource.HubDesc.split(";");
                            resource.match = sResourceHubs.some(hub => sHubList.includes(hub)) ? sYes : sNo;
                        });
                    } else {
                        aMatchResources.forEach(item => item.match = sYes);
                    }
                    
                    const uniqueFinalResources = [
    ...new Map([...aMatchResources, ...oResourcesModel].map(item => [item.userId, item])).values()
];

var oModel = that.getView().getModel(isCA ? "resourcesCAModel" : "resourcesOREModel");
var aExistingData = oModel && oModel.getData().length ? oModel.getData() : [];

let uniqueUpdatedData = sSearchValue ? uniqueFinalResources : aExistingData.concat(uniqueFinalResources);

const aUpdatedData = [...new Map(uniqueUpdatedData.map(item => [item.userId, item])).values()];
aUpdatedData.sort((a, b) => (b.match === "Yes") - (a.match === "Yes"));
self.oContextAssignmentObj
    ? (self.oContextAssignmentObj.selectedNominees = self.oContextAssignmentObj.selectedNominees ? self.oContextAssignmentObj.selectedNominees : [])
    : (self.oContextAssignmentObj = { selectedNominees: [] });
self.oContextAssignmentObj
    ? (self.oContextAssignmentObj.PreviousSelectedNominees = self.oContextAssignmentObj.PreviousSelectedNominees ? self.oContextAssignmentObj.PreviousSelectedNominees : [])
    : (self.oContextAssignmentObj = { PreviousSelectedNominees: [] });

if (sSearchValue) {
    const availableResources = self.oContextAssignmentObj.selectedNominees;
    const availablePrevResources = self.oContextAssignmentObj.PreviousSelectedNominees;
const aResourceData = oModel.getData().availableResources ?  oModel.getData().availableResources : oModel.getData();
if(aResourceData){
    aUpdatedData.forEach(updatedItem => {
        const matchedResource = aResourceData.find(resource => resource.userId === updatedItem.userId && resource.selected === true);
        if (matchedResource) {
            updatedItem.selected = true;
            updatedItem.enabled = matchedResource.enabled;
            updatedItem.btnEnabled = matchedResource.btnEnabled;
        }
    });
        }
        if(availableResources){
        aUpdatedData.forEach(updatedItem => {
        const matchedResource = availableResources.find(resource => resource.userId === updatedItem.userId );
        if (matchedResource) {
            updatedItem.selected = true;
            updatedItem.enabled = false;
            updatedItem.btnEnabled = false;
        }
    });
        }
        if(availablePrevResources){
          aUpdatedData.forEach(updatedItem => {
        const matchedResource = availablePrevResources.find(resource => resource.userId === updatedItem.userId && resource.selected === true);
        if (matchedResource) {
            updatedItem.selected = true;
            updatedItem.enabled = matchedResource.enabled;
            updatedItem.btnEnabled = matchedResource.btnEnabled;
        }
    });
        }
    const sSelectedKey = that.getView().getModel("employee").getProperty("/filter/selectedTab");
    const oView = that.getView();

    const modelMap = {
        directReports: { model: "resourceModel", property: "/resourceHeaderCount" },
        customerAdvisory: { model: "CAModel", property: "/customerHeaderCount" }
    };

    if (modelMap[sSelectedKey]) {
        oView.getModel(modelMap[sSelectedKey].model).setProperty(modelMap[sSelectedKey].property, uniqueFinalResources.length);
    }
     let aPrevSelectionModel = isCA ? self.getView().getModel("resourcesCAModel").getData().filter(item => item.selected === true) : self.getView().getModel("resourcesOREModel").getData().filter(item => item.selected === true);
    let aPrevSelected = aPrevSelectionModel.length ? aPrevSelectionModel.filter(element => aUpdatedData.some(item => item.userId === element.userId)) : [];
    if(aPrevSelected.length){
          aUpdatedData.forEach(updatedItem => {
        const matchedResource = aPrevSelected.find(resource => resource.userId === updatedItem.userId && resource.selected === true);
        if (matchedResource) {
            updatedItem.selected = true;
            updatedItem.enabled = matchedResource.enabled;
            updatedItem.btnEnabled = matchedResource.btnEnabled;
        }
    });
        }
    that.getView().setModel(new JSONModel(aUpdatedData), isCA ? "searchResourcesCAModel" : "searchResourcesOREModel");
    that.getView().getModel( isCA ? "searchResourcesCAModel" : "searchResourcesOREModel").refresh();
}else{
    if(self.oContextAssignmentObj.selectedNominees){
        aUpdatedData.forEach(updatedItem => {
    let matchedResource = self.oContextAssignmentObj.selectedNominees.find(resource => resource.userId === updatedItem.userId && resource.selected === true);
    if (matchedResource) {
        updatedItem.selected = true;
        updatedItem.enabled = true;
    } else {
        updatedItem.selected = false;
    }
});
    }

   
    that.getView().setModel(new JSONModel(aUpdatedData), isCA ? "resourcesCAModel" : "resourcesOREModel");
    let oTable = that.byId("EmpDetailsTableID");   // or Table ID
    let oBinding = oTable.getBinding("rows");
    oBinding.filter([]);
    if (!isCA && that.aFilters) {
        const oSelectedFilter = that.getView().getModel("employee").getProperty("/filter");
        let sSearchQuery = that.getView().getModel("employee").getProperty("/searchEmployee");
        if (oSelectedFilter.ManagerId?.SelectedKeys?.length) {
            that.aFilters.push(that.getPropertyFilters("ManagerId", oSelectedFilter.ManagerId.SelectedKeys));
        }
        if (sSearchQuery) {
            that.aFilters.push(new sap.ui.model.Filter({
                filters: [
                    new sap.ui.model.Filter("userId", sap.ui.model.FilterOperator.Contains, sSearchQuery),
                    new sap.ui.model.Filter("fullName", sap.ui.model.FilterOperator.Contains, sSearchQuery)
                ],
                and: false // OR condition
            }));
        }
        oBinding.filter(that.aFilters);

    }
}

                },
                error: function (error) {
                    ErrorHandle.setErrorMessage(error, self);
                }
            });
        },
        
       getCAResources: function (url, self, sSearchValue) {
    let oModel = this.getView().getModel("CAModel");
    let currentPage = oModel.getProperty("/currentCAPage") || 1;
    let itemsPerPage = 500;
    let totalCount = oModel.getProperty("/customerHeaderCount");

    let adjustedCount = Math.ceil(totalCount / itemsPerPage) * itemsPerPage;
    let skip = (currentPage - 1) * itemsPerPage;

    if(skip <= adjustedCount || !adjustedCount){
        this.fetchResources(url, self, true, itemsPerPage, skip, sSearchValue);
        currentPage++;
        oModel.setProperty("/currentCAPage", currentPage);
        skip = (currentPage - 1) * itemsPerPage;
    } 

    oModel.refresh();
},

        
getResources: function (url, self, sSearchValue) {
    let oModel = this.getView().getModel("resourceModel");

    let itemsPerPage = 500;
    let totalCount = oModel.getProperty("/resourceHeaderCount"); 
    let adjustedCount = Math.ceil(totalCount / itemsPerPage) * itemsPerPage; 

    let currentPage = oModel.getProperty("/currentPage") || 1;
    let skip = (currentPage - 1) * itemsPerPage;

    if(skip <= adjustedCount || !adjustedCount){
        this.fetchResources(url, self, false, itemsPerPage, skip, sSearchValue);
        currentPage++;
        oModel.setProperty("/currentPage", currentPage);
        skip = (currentPage - 1) * itemsPerPage;
    } 

    oModel.refresh();
},
onLiveOREChange: function(oEvent){
    let sValue = oEvent.getParameter("newValue");
    this.getView().byId("customerAdvisoryID").setBusy(true);
    this.getView().byId("EmpDetailsTableID").setBusy(true);
  let isLiveSearch = true;
  let that = this;
  if (!sValue) {
  
const sSelectedKey =  this.getView().getModel("employee").getProperty("/filter/selectedTab");

  switch (sSelectedKey) {
      case "directReports":
          
      this._updateCount( "resourceModel", "/resourceHeaderCount", "/resourceCount");
          this.getView().getModel("resourceModel").refresh(true);
          break;
      case "customerAdvisory":
          this._updateCount("CAModel", "/customerHeaderCount", "/customerCount");
          this.getView().getModel("CAModel").refresh(true);
          break;
      default:
          break;
  }
  that.onORESearchResources(oEvent, isLiveSearch);
  that.getView().byId("customerAdvisoryID").setBusy(false);
  that.getView().byId("EmpDetailsTableID").setBusy(false);
  }else {
       setTimeout(function() {
           if (sValue.length > 2){
                that.onORESearchResources(oEvent, isLiveSearch);
           }
     
            that.getView().byId("customerAdvisoryID").setBusy(false);
            that.getView().byId("EmpDetailsTableID").setBusy(false);
       },1000);
  }
},
onHighlightOreResourcess: function (oEvent) {
    let oTable = oEvent.getSource();
    let iFirstVisibleRow = oEvent.getParameter("firstVisibleRow");
    let iVisibleRowCount = oTable.getVisibleRowCount();
    let iTotalRows = oTable.getBinding("rows").getLength();
    if (iFirstVisibleRow + iVisibleRowCount >= iTotalRows) {
        if (this.getView().getModel("employee").getProperty("/filter/selectedTab") === "directReports") {
            const emailToFind = this.getOwnerComponent().getModel("userDetails").getProperty("/email");
            let usersArray = this.getView().getModel().getData().approverDetails;
            let userId;

            for (let i = 0; i < usersArray.length; i++) {
                if (usersArray[i].email === emailToFind) {
                    userId = usersArray[i].userId;
                    break; 
                }
            }

            const workflowBaseurl = this._getOREResourcesBaseURL();
            let filterResources = `?$filter=ManagerId eq '${userId}' and MelodyRequest eq 'X'&$orderby=CapEmpNme asc`;
            let sUrl = workflowBaseurl + filterResources;
            this.getResources(sUrl, this);
            this._updateAvailableResources();

        } else {
            const oAssignmentData = this.getView().getModel("assignmentsModel").getData().assignments;
            const oSelectedCustomers = oAssignmentData.flatMap(a => a.selectedNominees);
            const ApproversOREUrl = this._getOREApproversBaseURL();
            const OREFilterUrl = "?$filter=(MelodyRequest eq 'X')&$orderby=CapEmpNme asc";
            const serviceUrlORE = ApproversOREUrl + OREFilterUrl;
            this._updateAvailableCustomers();
        }
    }
},
        
        loadMoreData: function () {
            let oModel = this.getView().getModel("resourceModel");
            let iCurrentLength = oModel.getProperty("/availableResources").length;
            let iNextStartIndex = iCurrentLength;
        
           this.getResources(iNextStartIndex, 500); 
        },
        _setRequestAreas: function (self, oContext) {
            //code snippet to tranform flat structure to required tree structure of request areas
            self.aSelectedReqAreas = [];
            this.detailView = self;
            const aResult = oContext.value;
            const aModel = {};
            aModel.data = this._setReqAreasTree(aResult);
            self.setModel(new JSONModel(aModel), "myPresaleModel");
            //hide selection of parent nodes and keep it only for leaf nodes
            var that = self;
            const oTree = self.byId("idTree");
            oTree.bindAggregation("items", "myPresaleModel>/data", function (sId, oContext) {
                const oLeafChild = oContext.getProperty("isLeafNode");
                that.bSelCheckbox = false;
                if (oLeafChild && oLeafChild !== " " && that.aSelectedReqAreas.length) {
                    const sChildSelGUID = oContext.getProperty("GUID");
                    that.aSelectedReqAreas.forEach(function (obj) {
                        if (obj.GUID === sChildSelGUID) {
                            that.bSelCheckbox = true;
                        }
                    });
                }

                const oControl =
                    (oLeafChild && oLeafChild !== " ") ? new sap.m.CustomTreeItem(sId, {
                        content: new sap.m.RadioButton({
                            text: "{myPresaleModel>text}",
                            selected: that.bSelCheckbox,
                            select: that.onItemSelected.bind(that)
                        })
                    }) :
                        new sap.m.CustomTreeItem(sId, {
                            content: new sap.m.Title({
                                text: "{myPresaleModel>text}"
                            })
                        });
                return oControl;
            });
        },
        //Request area selection
        onItemSelected: function (oEvent) {
            const sPath = oEvent.getSource().getBindingContext("myPresaleModel").sPath;
            const oTemplateDetail = this.detailView.getModel("myPresaleModel").getProperty(sPath);
            if (oEvent.getParameter("selected")) {
                //this.oCreateDialog.getBeginButton().setEnabled(true);
                this.getView().getModel("profileViewParameters").setProperty("/footerButtons/createReqButtonEnabled", true);
                this.getView().getModel("profileViewParameters").refresh();
                const oSelectedReqArea = {
                    "GUID": oTemplateDetail.GUID,
                    "requestArea": oTemplateDetail.PresalesRequestArea,
                    "requestAreaPath": oTemplateDetail.PresalesRequestAreaPath
                };
                this.detailView.aSelectedReqAreas.push(oSelectedReqArea);
            } else {
                this.detailView.aSelectedReqAreas = this.detailView.aSelectedReqAreas.filter(function (obj) {
                    return obj.GUID !== oTemplateDetail.GUID;
                });
            }
            if (!this.detailView.aSelectedReqAreas.length) {
                //this.oCreateDialog.getBeginButton().setEnabled(false);
                this.getView().getModel("profileViewParameters").setProperty("/footerButtons/createReqButtonEnabled", false);
                this.getView().getModel("profileViewParameters").refresh();
            }
            const bBtnEnable = (this.detailView.aSelectedReqAreas.length > 0);
            //	this.dialog.getButtons()[0].setEnabled(bBtnEnable);
        },
        // Helper function to manage the lazy loading of views
        _loadView: function (options) {
            let mViews = this._mViews = this._mViews || Object.create(null);
            if (!mViews[options.id]) {
                mViews[options.id] = this.getOwnerComponent().runAsOwner(function () {
                    return XMLView.create(options);
                });
            }
            return mViews[options.id];
        },

        onSelectInternalOrder: function (oEvent) {
            const iInternalOrder = oEvent.getSource().getBindingContext("assignmentsModel").getObject().internalOrder;
            //Call the tasklevelSet 
            Models._getTaskLevelSet(this, iInternalOrder);
            //call io owner service
            // Models._getIoOwnerData(this,iInternalOrder);
            Models._getIOOwnerDetails(this, iInternalOrder);
        },
        _fetchFormActions: function (self) {
            const sOrgID = 'ParentOrgID' in self.getView().getModel().getData() ? self.getView().getModel().getProperty("/ParentOrgID") : self.getView().getModel().getProperty(
                "/OrgID");
            const sOrgType = self.getView().getModel().getProperty("/OrgType");
            const sCurrentStepName = self.getView().getModel().getProperty("/currentStepID");
            const sUserTask = (sCurrentStepName === "MANAPP") ? "Manager" : "Resource";
            const sFormatOrgID = self._getOrgIDnumber(sOrgID, sOrgType);
            var sEngagementType=self.getView().getModel().getData().EngagementType
            const sUrl = self._getRuntimeBaseURL() +
                `/cap/req-area-api-/Action?$filter=eng_Type_ID eq '${sEngagementType}' and (orgID eq '${sFormatOrgID}' and orgType eq '${sOrgType}') and (UserTask eq '${sUserTask}')`;
            $.ajax({
                contentType: "application/json",
                url: sUrl,
                async: true,
                type: "GET",
                success: function (oData) {
                    const aFormActionsValues = oData.value;
                    const oFormValue = aFormActionsValues.reduce(function (formVal, val) {
                        (formVal[val.Action_ID] = formVal[val.Action_ID] || []).push(val);
                        return formVal;
                    }, {})
                    const oFormActionsConfigModel = new JSONModel(oFormValue);
                    self.getView().setModel(oFormActionsConfigModel, "formActionsConfigModel");
                    self._setFooterButtonDefaultVisibility();

                },
                error: function (oError) {

                }
            });
        },
        _getOrgIDnumber: function (sOrgID, sOrgType) {
            if (sOrgType === "SORG") {
                return Number(sOrgID.replace('SORG-', '')).toString();
            } else {
                return sOrgID;
            }
        },
        //set form configurable model
        _fetchFormConfigData: function (self) {
            const sOrgID = 'ParentOrgID' in self.getView().getModel().getData() ? self.getView().getModel().getProperty("/ParentOrgID") : self.getView().getModel().getProperty(
                "/OrgID");
            const sOrgType = self.getView().getModel().getProperty("/OrgType");
            const sFormatOrgID = self._getOrgIDnumber(sOrgID, sOrgType);
            var sEngagementType=self.getView().getModel().getData().EngagementType
            const sUrl = self._getRuntimeBaseURL() +
                `/cap/req-area-api-/Form_Tab?$expand=Fields&&$filter=orgID eq '${sFormatOrgID}' and orgType eq '${sOrgType}' and eng_Type_ID eq '${sEngagementType}'`;

            $.ajax({
                contentType: "application/json",
                url: sUrl,
                async: true,
                type: "GET",
                success: function (oData) {
                    let aDataNew = [];

                    for (let i = 0; i < oData.value.length; i++) {
                        if (!aDataNew[oData.value[i].ID]) {
                            aDataNew[oData.value[i].ID] = [];
                        }
                        aDataNew[oData.value[i].ID] = oData.value[i];
                        let aDataNewFields = [];
                        for (let j = 0; j < oData.value[i].Fields.length; j++) {

                            if (!aDataNew[oData.value[i].Fields[j].ID]) {
                                aDataNewFields[oData.value[i].Fields[j].ID] = [];
                            }
                            aDataNewFields[oData.value[i].Fields[j].ID] = oData.value[i].Fields[j];
                            // aDataNew[oConfigData.value[i].ID].Fields = aDataNewFields[oConfigData.value[i].Fields[j].ID
                        }
                        aDataNew[oData.value[i].ID].Fields = aDataNewFields;
                    }
                    const oFormConfigModel = new JSONModel(aDataNew);
                    self.getView().setModel(oFormConfigModel, "formConfigModel");
                },
                error: function (oError) {

                }
            });
        },
        formatTimeInvestmentVisibility: function (sVal, bExpectedTimeInvestment) {
            if (sVal === "X" && bExpectedTimeInvestment) {
                return true;
            } else {
                return false;
            }
        },
        parseGetOppDataResponse: function (data) {
            if (data) {
                const oDealInfo = {
                    accName: data.ACCOUNT_NAME,
                    oppName: data.DESCRIPTION,
                    decision: data.DECISION,
                    reviewerName: data.DQReview.REVIEWER1_NAME,
                    forecast: data.FORECAST,
                    onPremRevenue: data.LICENSE_REVENUE,
                    cloudRevenue: data.CLOUD_REVENUE,
                    currency: data.CURRENCY,
                    CURR_PHASE: data.CURR_PHASE,
                    STATUS: data.STATUS,
                    TCV: data.Items.results.length ? data.Items.results[0].TOTAL_TCV : ""
                };
                

                //set dates
                const jsonClosingDate = data.EXPECT_END,
                    closingDateFull = jsonClosingDate ? new Date(parseInt(jsonClosingDate.substr(6))) : null;
                oDealInfo.closingDate = closingDateFull;

                const jsonReviewDate = data.DQReview.REVIEW_DATE1,
                    reviewDateFull = jsonReviewDate ? new Date(parseInt(jsonReviewDate.substr(6))) : null;
                oDealInfo.reviewDate = reviewDateFull;

                //process Notes
                const aNotes = data.Notes.results;
                for (let i = 0; i < aNotes.length; i++) {
                    switch (aNotes[i].TDID) {
                        case "ZD01":
                            oDealInfo.compelEventText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD02":
                            oDealInfo.fundingText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD03":
                            oDealInfo.custStakeText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD04":
                            oDealInfo.custChallengesText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD05":
                            oDealInfo.custBusDriversText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD06":
                            oDealInfo.solutionText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD07":
                            oDealInfo.competitorsText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD08":
                            oDealInfo.partnersText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD10":
                            oDealInfo.execSummary = aNotes[i].CONC_LINES;
                            break;
                        default:
                    }
                }

                //process Attributes
                const aAttributes = data.Attributes.results;
                for (let i = 0; i < aAttributes.length; i++) {
                    switch (aAttributes[i].ATTR_CODE) {
                        case "AS0103":
                            oDealInfo.compelEventQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0104":
                            oDealInfo.fundingQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0105":
                            oDealInfo.custStakeQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0106":
                            oDealInfo.custChallengesQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0107":
                            oDealInfo.custBusDriversQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0108":
                            oDealInfo.solutionQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0109":
                            oDealInfo.competitorsQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0110":
                            oDealInfo.partnersQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0132":
                            oDealInfo.decision = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0133":
                            oDealInfo.reviewerName = aAttributes[i].ATTR_DESCR;
                            break;
                        case "AS0134":
                            oDealInfo.reviewDate = new Date(aAttributes[i].ATTR_VALUE.slice(0, 4) + "-" + aAttributes[i].ATTR_VALUE.slice(4, 6) + "-" +
                                aAttributes[i].ATTR_VALUE.slice(-2));
                            break;
                        default:
                    }
                }

                oDealInfo.attributes = aAttributes;
                 //Git 132 (Form template/standardization )
                 //set close date and latest review date
                const options = {
                    year: 'numeric',
                    month: 'long', // 'long' for full month name (e.g., "July"), 'short' for abbreviated (e.g., "Jul")
                    day: 'numeric'
                  };
                const sLatestRevieweDateLabel = this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/HarmonyLatestReviewDate/0/fieldDesc"),
                      sReviewerLabel = this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/Reviewer/0/fieldDesc");
                oDealInfo.latesReviewDateField = oDealInfo.reviewDate ? `${sLatestRevieweDateLabel}: ${oDealInfo.reviewDate.toLocaleDateString('en-US', options)}`:"";
                oDealInfo.reviewerField = oDealInfo.reviewerName ? `${sReviewerLabel}: ${oDealInfo.reviewerName}`:"";

                this.getView().getModel().setProperty("/dealInfo", oDealInfo);
                this.getView().getModel().refresh();
            }
        },
        _forwardActionDialog: function (oEvent, processContext, taskId, sDecision, oPresalesData) {
            const oevt = oEvent.getSource();
            let oView = this.getView();
            if (!this._pActionSheetFragment) {
                this._pActionSheetFragment = Fragment.load({
                    id: oView.getId(),
                    name: "com.dealsupport.melodyrequest.fragments.managerPage.ForwardActionSheetFragment",
                    controller: this
                }).then(function (oActionSheet) {
                    oView.addDependent(oActionSheet);
                    return oActionSheet;
                });
            }
            this._pActionSheetFragment.then(function (oActionSheet) {
                oActionSheet.openBy(oevt);
            });
        },
        /* GIT #142
            Forward->named contact
            called when "Named contact selection" is pressed
        */
    onNamedContactsPress: function () {
            const oModel = this.getView().getModel();

            oModel.setProperty("/comments", "");
            this.getView().getModel("profileViewParameters").setProperty("/footerButtons/errorBtnVisible", false);
            this.getView().setModel(new sap.ui.model.json.JSONModel({ ApproverDetails: [] }), "selectedOREModel");
            //dialog box of named contact forward request action - GIT #142
            let oMultiInputForward = new sap.m.MultiInput({
                placeholder: this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/SelectProcessor/0/fieldDesc"),
                valueHelpOnly: true,
                valueHelpRequest: this.onValueHelpRequestForward.bind(this),
                tokenUpdate: this.onDeleteNamedContactToken.bind(this)
                
            })
            //GIT 270- prepopulate the processor names for named contact forward multi input
            const allApprovers=this.getView().getModel().getData().aResourceProfileApprovers.ApproverDetails
            const aApprovers=this.getView().getModel().getData().aResourceProfileApprovers.aApprovers
            const aSubstitues=this.getView().getModel().getData().aResourceProfileApprovers.SubstituteApproverDetails
            var deepCopyApprovers=jQuery.extend(true,[],allApprovers)
            var deepCopyApproversPrimary=jQuery.extend(true,[],aApprovers)
            this.getView().getModel("selectedOREModel").setProperty("/ApproverDetailsExisting",JSON.parse(JSON.stringify(allApprovers)))
            this.getView().getModel("selectedOREModel").setProperty("/aApproversExisting",JSON.parse(JSON.stringify(deepCopyApproversPrimary)))
            this.getView().getModel("selectedOREModel").setProperty("/aSubstituesExisting",JSON.parse(JSON.stringify(aSubstitues)))
            this.getView().getModel("selectedOREModel").setProperty("/ApproverDetails",JSON.parse(JSON.stringify(allApprovers)))
            let oTokenTemplate = new sap.m.Token({
                key: "{selectedOREModel>ID}",
                text: "{selectedOREModel>fullName}"
            })
            oMultiInputForward.bindAggregation("tokens", {
                path: "selectedOREModel>/ApproverDetails",
                template: oTokenTemplate
            })

            let oVBox = new sap.m.VBox({
                items: [
                    new sap.m.Text("idForwardComments", {
                        text: this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/ForwardMsg/0/fieldDesc"),
                        wrapping: true

                    }),
                    oMultiInputForward,
                    new TextArea("submissionNote", {
                        width: "100%",
                        value: '{/comments}',                        
                        placeholder: this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/ForwardCommentPlaceholder/0/fieldDesc") + "\n" + this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/ForwardCommentMsg/0/fieldDesc"),
                        maxLength:5000

                    }),
                ]
            })
            let that = this;
            this.oSubmitDialog = new Dialog({
                type: library.DialogType.Message,
                customHeader: new sap.m.Bar({
                    contentLeft: [
                        new sap.m.Title({
                            text: this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/ForwardNamedContactTitle/0/fieldDesc"),
                        })
                    ],
                    contentRight: [
                        //Git 314 Add advanced search link
                        new sap.m.Link({
                            text:  this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("advancedSearch"),
                            emphasized:true,
                            press: function(){
                                const currentSelectedList = that.getView().getModel("selectedOREModel").getProperty("/ApproverDetails");
                                let deepCopyCurrentSelectedList = jQuery.extend(true, [], currentSelectedList)
                                that.getView().getModel("selectedOREModel").setProperty("/CurrentSelectedApproverList", deepCopyCurrentSelectedList);
                                let allApprovers = that.getView().getModel().getData().aResourceProfileApprovers.ApproverDetails
                                let aApprovers = that.getView().getModel().getData().aResourceProfileApprovers.aApprovers
                                let aSubstitues = that.getView().getModel().getData().aResourceProfileApprovers.SubstituteApproverDetails
                                that.getView().getModel("selectedOREModel").setProperty("/ApproverDetailsBeforeList", JSON.parse(JSON.stringify(allApprovers)))
                                that.getView().getModel("selectedOREModel").setProperty("/aApproversBeforeList", JSON.parse(JSON.stringify(aApprovers)))
                                that.getView().getModel("selectedOREModel").setProperty("/aSubstituesBeforeList", JSON.parse(JSON.stringify(aSubstitues)))
                                //open reusable ore record search dialog
                                that._onOpenOREResourceDialog();
                            }
                        }).addStyleClass("styleAdvancedSearch")
                    ]
                }),
                contentWidth: "450px",
                content: [
                    oVBox



                ],
                beginButton: new Button("idBtnForwardRequestOk", {
                    type: library.ButtonType.Emphasized,
                    text: this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/SaveSubmit/0/fieldDesc"),                    
                    enabled: false,
                    press: function () {
                        this.onForwardRequestOkPress()
                    }.bind(this)
                }),
                endButton: new Button({
                    text: this.i18nModel.getText("cancel"),
                    press: function () {
                        var dcAllApprovers=this.getView().getModel("selectedOREModel").getProperty("/ApproverDetailsExisting")
                        var dcPrimaryApprovers=this.getView().getModel("selectedOREModel").getProperty("/aApproversExisting")
                        var dcSubApprovers=this.getView().getModel("selectedOREModel").getProperty("/aSubstituesExisting")
                        this.getView().getModel().setProperty("/aResourceProfileApprovers/ApproverDetails",dcAllApprovers)
                        this.getView().getModel().setProperty("/aResourceProfileApprovers/aApprovers",dcPrimaryApprovers)
                        this.getView().getModel().setProperty("/aResourceProfileApprovers/SubstituteApproverDetails",dcSubApprovers)
                        this.oSubmitDialog.close();
                        this.oSubmitDialog.destroy();
                    }.bind(this)
                })
            });
            //to get access to the controller's model
            this.getView().addDependent(this.oSubmitDialog);
            // }
            // toggle compact style
            syncStyleClass("sapUiSizeCompact", this.getView(), this.oSubmitDialog);

            this.oSubmitDialog.open();


        },
        /**
         * Git #270 named contact forward UX change
         * function called tokens are deleted from multi input of edit processor popup
         * @param {object} oEvent - token update event object         
         */
        onDeleteNamedContactToken: function (oEvent) {            
            const oModel = this.getView().getModel("selectedOREModel");
            const oApproversORE = oModel.getProperty("/ApproverDetails");
            const oParameters = oEvent.getParameters();
            // var substituesOfDelToken=[]
            if (oParameters.type === "removed") {
                const aTokens = oParameters.removedTokens;
                for (let i = 0; i < aTokens.length; i++) {
                    const iIndex = oApproversORE.findIndex(item => item.ID === aTokens[i].getKey());
                    if (iIndex !== -1) {
                        // if(oApproversORE[iIndex].to_substitute?.results?.length>0){
                        //     substituesOfDelToken.push(...oApproversORE[iIndex].to_substitute?.results)
                        // }
                        oApproversORE.splice(iIndex, 1);
                        oModel.refresh(true);
                    }
                }
                // substituesOfDelToken.forEach(obj=>{
                //     var subIndex = oApproversORE.findIndex(item => item.ID === obj.SubstituteId);
                //     if(subIndex!==-1){
                //         oApproversORE.splice(subIndex, 1);
                //         oModel.refresh(true);
                //     }
                // })
            }
            if (!oApproversORE.length) {
                if( this.byId("idMultiInputORE"))
                    this.byId("idMultiInputORE").setVisible(false);
                if(this.byId("idForwardNamedContact"))
                    this.byId("idForwardNamedContact").setEnabled(false); 
            } else {
                if( this.byId("idMultiInputORE"))
                    this.byId("idMultiInputORE").setVisible(true);
                if(this.byId("idForwardNamedContact"))
                    this.byId("idForwardNamedContact").setEnabled(true); 
            }
            //setting the visibility of forward request btn- GIT #142
            let bForwardBtnVisibility = oApproversORE.length > 0
            sap.ui.getCore().byId("idBtnForwardRequestOk").setEnabled(bForwardBtnVisibility)
            const oList = this.byId("idListORE");
            if(oList){
                const aItems = oList.getItems();
                for (let i = 0; i < aItems.length; i++) {
                    const oContext = aItems[i].getBindingContext("resourceModelORE").getObject();
                    const aFilterObj = oApproversORE.filter((approvers) => approvers.ID === oContext.ID);
                    if (aFilterObj.length) {
                        aItems[i].setSelected(true);
                    } else {
                        aItems[i].setSelected(false);
                    }
                }
            } 
            this.onConfirmNamedContact()

        },
        /*
                    GIT #142 - Forward -> Named contact
                    forward to named contact->select processor multi inupt value help handler 
                */
        onValueHelpRequestForward: function (oEvent) {
            let oView = this.getView();
            let that = this;
            const currentSelectedList = this.getView().getModel("selectedOREModel").getProperty("/ApproverDetails");
            let deepCopyCurrentSelectedList = jQuery.extend(true, [], currentSelectedList)
            this.getView().getModel("selectedOREModel").setProperty("/CurrentSelectedApproverList", deepCopyCurrentSelectedList);
            this.getView().getModel("profileViewParameters").setProperty("/footerButtons/errorBtnVisible", false);
            let allApprovers=this.getView().getModel().getData().aResourceProfileApprovers.ApproverDetails
            let aApprovers=this.getView().getModel().getData().aResourceProfileApprovers.aApprovers
            let aSubstitues=this.getView().getModel().getData().aResourceProfileApprovers.SubstituteApproverDetails            
            this.getView().getModel("selectedOREModel").setProperty("/ApproverDetailsBeforeList",JSON.parse(JSON.stringify(allApprovers)))
            this.getView().getModel("selectedOREModel").setProperty("/aApproversBeforeList",JSON.parse(JSON.stringify(aApprovers)))
            this.getView().getModel("selectedOREModel").setProperty("/aSubstituesBeforeList",JSON.parse(JSON.stringify(aSubstitues)))
            // this.getView().setModel(new sap.ui.model.json.JSONModel({ ApproverDetails: [] }), "selectedOREModel");

            if (!this._pNamedContactListPopover) {
                this._pNamedContactListPopover = Fragment.load({
                    id: oView.getId(),
                    name: "com.dealsupport.melodyrequest.fragments.managerPage.NamedContactsListFragment",
                    controller: this
                }).then(function (oNamedContactDialog) {
                    that.oNamedContactDialog = oNamedContactDialog;
                    oView.addDependent(oNamedContactDialog);
                    return oNamedContactDialog;
                }).catch(function (error) {
                });
            }

            this._pNamedContactListPopover.then(function (oNamedContactDialog) {
                that.getView().byId("idForwardNamedContact").setEnabled(false);
                oNamedContactDialog.addStyleClass(that.getOwnerComponent().getContentDensityClass());

                oNamedContactDialog.openBy(oEvent.getSource());
                sap.ui.core.BusyIndicator.show(0);
                that.byId("idMultiInputORE").setVisible(false);
                // that.getView().setModel(new sap.ui.model.json.JSONModel(), "selectedOREModel");

                that.currentPageORE = 0;
                that.itemsPerPage = 500;
                that.isFetchingData = false;

                const ApproversOREUrl = that._getOREApproversBaseURL();
                const OREFilterUrl = "?$filter=(MelodyRequest eq 'X')&$orderby=CapEmpNme asc";
                const serviceUrlORE = ApproversOREUrl + OREFilterUrl;

                that.loadData(serviceUrlORE, that.itemsPerPage, 0);

                let oScrollContainer = that.getView().byId("idListORE").getParent();
                /*
                    GIT #142 - Forward->Named Contact 
                    Visibility of search field,multi input and selected names inside named contact list getting set
                */

                let oMultiInput = that.byId("idMultiInputORE");
                const bHasSelection = that.getView().getModel("selectedOREModel").getProperty("/ApproverDetails").length > 0;
                that.getView().byId("idForwardNamedContact").setEnabled(bHasSelection);
                oMultiInput.setVisible(bHasSelection);

                let contactList = that.getView().getModel("selectedOREModel").getProperty("/ApproverDetails")
                const oList = that.getView().byId("idListORE");
                const aItems = oList.getItems();
                for (let i = 0; i < aItems.length; i++) {
                    const oContext = aItems[i].getBindingContext("resourceModelORE").getObject();
                    const aFilterObj = contactList.filter((approvers) => approvers.ID === oContext.ID);
                    if (aFilterObj.length) {
                        aItems[i].setSelected(true);
                    } else {
                        aItems[i].setSelected(false);
                    }
                }
                let oSearchORE = that.byId("idSearchORE");
                if (oSearchORE) oSearchORE.setValue("");

                if (oScrollContainer) {
                    oScrollContainer.attachBrowserEvent("scroll", function () {
                        let domRef = oScrollContainer.getDomRef();
                        if (!that.isFetchingData && domRef.scrollTop + domRef.clientHeight >= domRef.scrollHeight - 10) {
                            that.isFetchingData = true;
                            that.loadMoreData(serviceUrlORE);
                        }
                    });
                }
            });
        },
        /* 
            GIT #142 Forward->Named Contact
            method called when named contacts are selected and ok btn is pressed
        */
        onForwardRequestOkPress: function () {
            this.getView().setModel(new sap.ui.model.json.JSONModel({ ApproverDetails: [] }), "selectedOREModel");
            this.getView().setModel(new sap.ui.model.json.JSONModel({ ApproverDetails: [] }), "resourceModelORE");
            this.onForwardRequest("namedContact")
            this.oSubmitDialog.close();
            this.oSubmitDialog.destroy();
        },

loadData: function (url, top, skip) {
    var that = this;
    that.getNamedContactsData(url, top, skip)
        .then(function (data) {
            let oResourceModel = that.getView().getModel("resourceModelORE");
            let aExistingData = oResourceModel ? oResourceModel.getData().ApproverDetails || [] : [];

            const valueORE = data.d.results;
            const approverDetails = valueORE.map(function (obj) {
                return {
                    fullName: obj.EmpName,
                    ID: obj.Id,
                    email: obj.EmailId,
                    to_substitute:obj.to_nmdsubstitute,
                    ROLE:obj.Emp_CrmRoleId
                };
            });

            const uniqueData = [...aExistingData, ...approverDetails].reduce((acc, obj) => {
                if (!acc.some(item => item.ID === obj.ID)) {
                    acc.push(obj);
                }
                return acc;
            }, []);

            if (!oResourceModel) {
                oResourceModel = new sap.ui.model.json.JSONModel();
                that.getView().setModel(oResourceModel, "resourceModelORE");
            }

            oResourceModel.setData({
                ApproverDetails: uniqueData
            });

            that.currentPageORE++;
            that.isFetchingData = false;
        })
        .catch(function (error) {
            that.isFetchingData = false;
        });
},

loadMoreData: function (url) {
    let skip = this.currentPageORE * this.itemsPerPage;
    this.loadData(url, this.itemsPerPage, skip);
},

getNamedContactsData: function (url, top, skip) {
    return new Promise(function (resolve, reject) {
        $.ajax({
            url: `${url}&$top=${top}&$skip=${skip}&$expand=to_nmdsubstitute`,
            dataType: 'json',
            method: "GET",
            success: function (data) {
                resolve(data);
                sap.ui.core.BusyIndicator.hide();
            },
            error: function (error) {
                reject(error);
            }
        });
    });
},

        loadInitialContent: function () {
            let oSegmentedButton = this.getView().byId("segmentedButton");
            oSegmentedButton.fireSelectionChange({
                selectedItem: oSegmentedButton.getItems()[0]
            });
        },
        //triggered when cancel button of named contact list (forward request) is pressed-GIT #142
        onCloseNamedContact: function () {
            const that = this;
            this._pNamedContactListPopover.then(function (oDialog) {
                //resetting the previously select names after cancel btn of named list is pressed
                that._setEditProcessorData();
                oDialog.close();
            });
        },
                /**
        *Git 313
        * set processor data for forward
        * set processor Data
        * @function _setEditProcessorData
        */
        _setEditProcessorData: function(){
            this.getView().getModel("selectedOREModel").setProperty("/ApproverDetails", []);
            let aCurrentSelectedList = this.getView().getModel("selectedOREModel").getProperty("/CurrentSelectedApproverList");
            this.getView().getModel("selectedOREModel").setProperty("/ApproverDetails", aCurrentSelectedList);
            let dcAllApprovers = this.getView().getModel("selectedOREModel").getProperty("/ApproverDetailsBeforeList");
            let dcPrimaryApprovers = this.getView().getModel("selectedOREModel").getProperty("/aApproversBeforeList");
            let dcSubApprovers = this.getView().getModel("selectedOREModel").getProperty("/aSubstituesBeforeList");
            this.getView().getModel().setProperty("/aResourceProfileApprovers/ApproverDetails", dcAllApprovers);
            this.getView().getModel().setProperty("/aResourceProfileApprovers/aApprovers", dcPrimaryApprovers);
            this.getView().getModel().setProperty("/aResourceProfileApprovers/SubstituteApproverDetails", dcSubApprovers);
        },
        onConfirmNamedContact: function () {
            let aSelectedItems = JSON.parse(JSON.stringify(this.getView().getModel("selectedOREModel").getProperty("/ApproverDetails")));
            //substitute check and update substitute details
            let aSelItemsFromList=aSelectedItems.filter(item=> item.to_substitute)
            let subFromContext=this.getView().getModel().getProperty("/aResourceProfileApprovers/SubstituteApproverDetails")
            let aProcessorListFromCreateReq=aSelectedItems.filter(item=> !item.to_substitute)
            var subFromCreateReq=[]
            aProcessorListFromCreateReq.forEach(obj=>{
                const iIndex = subFromContext.findIndex(item => item.ID === obj.ID);
                    if (iIndex !== -1) {
                        subFromCreateReq.push(subFromContext[iIndex])
                    }
            })
            // let aSubstituteFinalApprover = CommonJS._getSubstituteDetails(aSelectedItems, false, true);
            let aSubstituteFinalApprover = CommonJS._getSubstituteDetails(aSelItemsFromList, false, true);
            aSubstituteFinalApprover.push(...subFromCreateReq)
            let uniqueSubs = Array.from(new Map(aSubstituteFinalApprover.map(aSubstituteFinalApprover => [aSubstituteFinalApprover.ID, aSubstituteFinalApprover])).values());
            let aFinalApprovers = aSubstituteFinalApprover.length ? aSelectedItems.concat(aSubstituteFinalApprover) : aSelectedItems;
            const uniqueApprovers = [...new Map(aFinalApprovers.map(item => [item.ID, item])).values()];
            let aPrimaryApp= aSelectedItems.filter(obj=> !uniqueSubs.some(obj2=>obj2.ID === obj.ID))
            let aUniqueListApprovers = [...new Map(aPrimaryApp.map(item => [item.ID, item])).values()];
            this.getView().getModel().getData().aResourceProfileApprovers.ApproverDetails = uniqueApprovers;
            this.getView().getModel().setProperty("/aResourceProfileApprovers/SubstituteApproverDetails", uniqueSubs);
            // var aApprovers=aSelItemsFromList.concat(this.getView().getModel().getProperty("/aResourceProfileApprovers/aApprovers"))
            // var uniqueaApprovers=[...new Map(aApprovers.map(item => [item.ID, item])).values()];
            this.getView().getModel().setProperty("/aResourceProfileApprovers/aApprovers", aUniqueListApprovers);
            //setting the visibility of forward request btn- GIT #142
            const that = this;
            var bForwardBtnVisibility = aSelectedItems.length > 0
            sap.ui.getCore().byId("idBtnForwardRequestOk").setEnabled(bForwardBtnVisibility)
            if(this._pNamedContactListPopover){
                this._pNamedContactListPopover.then(function (oDialog) {                                        
                    oDialog.close();
                });
            }
            if (this.pORESelectDialog) {
                this.pORESelectDialog.then(function (oDialog) {
                    oDialog.close();
                });
            }


        },
        onSegmentedButtonSelect: function (oEvent) {
         sap.ui.core.BusyIndicator.show(0);
            let sSelectedKey;
            var that = this;
            if (oEvent.getParameters().item && oEvent.getParameters().item.getProperty("key")) {
                sSelectedKey = oEvent.getParameters().item.getProperty("key");
            } else if (oEvent.getParameters().selectedItem && oEvent.getParameters().selectedItem.getProperty("key")) {
                sSelectedKey = oEvent.getParameters().selectedItem.getProperty("key");
            }
            this.getView().byId("idForwardNamedContact").setEnabled(false);
            this.byId("idMultiInputBs").setVisible(false);
            this.byId("idMultiInputORE").setVisible(false);
            const oListContainerResources = this.getView().byId("listContainerResources");
            const oListContainerORE = this.getView().byId("listContainerORE");
            const getBSurl = this._getApproversBaseURL(this);
            const sProfitcenter = "";
            const bSFilterurl = "?$filter=(TableTypeId%20eq%20%270002%27) and (RecordStatus eq '01')";
            const serviceUrlBS = getBSurl + bSFilterurl;
            const ApproversOREUrl = this._getOREApproversBaseURL(this);
            const OREFilterurl = "?$filter=(MelodyRequest eq 'X')";
            const serviceUrlORE = ApproversOREUrl + OREFilterurl;
            let currentPageBS = 1;
            let currentPageORE = 1;
            let itemsPerPage = 500;

            let listContainerBS = this.getView().byId("listContainerResources");
            let listContainerORE = this.getView().byId("listContainerORE");

            listContainerBS.attachBrowserEvent("scroll", function () {
                if (listContainerBS.getDomRef().scrollHeight - listContainerBS.getDomRef().clientHeight === listContainerBS.getDomRef().scrollTop) {
                    loadNextPage("resources");
                }
            });

            listContainerORE.attachBrowserEvent("scroll", function () {
                if (listContainerORE.getDomRef().scrollHeight - listContainerORE.getDomRef().clientHeight === listContainerORE.getDomRef().scrollTop) {
                    loadNextPage("ore");
                }
            });

            function loadNextPage(selectedKey) {
                const skip = (selectedKey === "resources") ? currentPageBS * itemsPerPage : currentPageORE * itemsPerPage;
                const serviceUrl = (selectedKey === "resources") ? serviceUrlBS : serviceUrlORE;
                loadData(serviceUrl, itemsPerPage, skip, selectedKey);
            }

            if (sSelectedKey === "resources") {
                oListContainerResources.setVisible(true);
                oListContainerORE.setVisible(false);

                loadData(serviceUrlBS, itemsPerPage, 0, "resources");
            } else if (sSelectedKey === "ore") {
                oListContainerResources.setVisible(false);
                oListContainerORE.setVisible(true);

                loadData(serviceUrlORE, itemsPerPage, 0, "ore");
            }

            function loadData(url, top, skip, selectedKey) {
                // Call the function that retrieves the named contacts data from the specified URL with pagination parameters.
                // The parameters 'top' and 'skip' control the number of records to fetch and the starting point for the fetch respectively.
                that.getNamedContactsData(url, top, skip)
                    .then(function (data) {
                        const approverArray = [];
                        const oResourceModel = new sap.ui.model.json.JSONModel();

                        if (selectedKey == "resources") {
                            const value = data.d.results;
                            const aFinalApprovers = [];
                            value.forEach(function (obj) {
                                if (obj.UserTypeId == "0001") {
                                    aFinalApprovers.push(obj);
                                }
                            });


                            const approverInfo = users.getProcessorsUserInfo(aFinalApprovers, that, true);
                            //remove duplicates and update profitcenter
                            const uniqueBSResources = approverInfo.reduce((approver, user) => {
                                if (!approver.find(u => u.ID === user.ID)) {
                                    const aFilteredUserId = approverInfo.filter((resource) => resource.ID === user.ID);
                                    aFilteredUserId.map(resource => resource.ProfitCenterDetails.formattedDesc).join(",")
                                    approver.push(user);
                                }
                                return approver
                            }, []);
                            oResourceModel.setData({
                                ApproverDetails: uniqueBSResources
                            });
                            that.getView().setModel(oResourceModel, "resourceModelBS");
                            currentPageBS++;
                        } else if (selectedKey == "ore") {

                            const valueore = data.d.results;

                            const approverDetails = valueore.map(function (obj) {
                                return {
                                    fullName: obj.EmpName,
                                    ID: obj.Id,
                                    email: obj.EmailId
                                };
                            });
                            const uniqueData = approverDetails.reduce((acc, obj) => {
                                if (!acc.some(item => item.ID === obj.ID)) {
                                  acc.push(obj);
                                }
                                return acc;
                              }, []);
                            oResourceModel.setData({
                                ApproverDetails: uniqueData
                            });
                            that.getView().setModel(oResourceModel, "resourceModelORE");

                            currentPageORE++;
                        }

                    }.bind(this))
                    .catch(function (error) {
                        Models._setErrorMsgPopOver(that, "namedContacts", error, false, "namedContact");
                    });
            }
        },
        _setSelectedNamedContactModel: function (oList) {
            const aSelectedManager = [];

            oList.forEach(function (manager) {
                aSelectedManager.push(manager.getObject())
            });
            return aSelectedManager

        },
         onSelectNamedApprovers: function (oEvent) {
        const aManagerModel = new JSONModel();
        
        let oList, oMultiInput, sModelName;
    
            oList = this.byId("idListORE");
            oMultiInput = this.byId("idMultiInputORE");
            sModelName = "resourceModelORE";
      
    
        const aSelectedContext = oList.getSelectedContexts(sModelName);
        const aSelectedManager = this._setSelectedNamedContactModel(aSelectedContext);
    
        const oSelectedModel = this.getView().getModel("selectedOREModel");
                if(oEvent.getParameter("listItem").getProperty("selected")){
                     oSelectedModel.getProperty("/ApproverDetails").push(oEvent.getParameter("listItem").getBindingContext("resourceModelORE").getObject());
                }else{
                    let sUserId = oEvent.getParameter("listItem").getProperty("number");
                    let aFinalUsers = oSelectedModel.getProperty("/ApproverDetails").length ? oSelectedModel.getProperty("/ApproverDetails").filter(item => item.ID !== sUserId) : [];
                    aFinalUsers.length ? oSelectedModel.setProperty("/ApproverDetails" , aFinalUsers) : oSelectedModel.setProperty("/ApproverDetails" , []);
                }
       
                
        oSelectedModel.refresh();
    
        const bHasSelection = oSelectedModel.getProperty("/ApproverDetails").length  > 0;
        this.getView().byId("idForwardNamedContact").setEnabled(bHasSelection);
        oMultiInput.setVisible(bHasSelection);
            },
        onDeleteBSToken: function (oEvent) {
            const oModel = this.getView().getModel("selectedBSModel");
            const oApproversBS = oModel.getProperty("/ApproverDetails");
            const oParameters = oEvent.getParameters();
            if (oParameters.type === "removed") {
                const aTokens = oParameters.removedTokens;
                for (let i = 0; i < aTokens.length; i++) {
                    const iIndex = oApproversBS.findIndex(item => item.ID === aTokens[i].getKey());
                    if (iIndex !== -1) {
                        oApproversBS.splice(iIndex, 1);
                        oModel.refresh(true);
                    }
                }
            }
            if (!oApproversBS.length) {
                this.byId("idMultiInputBs").setVisible(false);
                this.getView().byId("idForwardNamedContact").setEnabled(false);
            } else {
                this.byId("idMultiInputBs").setVisible(true);
                this.getView().byId("idForwardNamedContact").setEnabled(true);
            }
            const oList = this.byId("idListBS");
            const aItems = oList.getItems();
            for (let i = 0; i < aItems.length; i++) {
                const oContext = aItems[i].getBindingContext("resourceModelBS").getObject();
                const aFilterObj = oApproversBS.filter((approvers) => approvers.ID === oContext.ID && approvers.ProfitCenterDetails.TrpcGuid === oContext.ProfitCenterDetails.TrpcGuid);
                if (aFilterObj.length) {
                    aItems[i].setSelected(true);
                } else {
                    aItems[i].setSelected(false);
                }
            }
        },
        onDeleteOREToken: function (oEvent) {
            const oModel = this.getView().getModel("selectedOREModel");
            const oApproversORE = oModel.getProperty("/ApproverDetails");
            const oParameters = oEvent.getParameters();            
            if (oParameters.type === "removed") {
                const aTokens = oParameters.removedTokens;
                for (let i = 0; i < aTokens.length; i++) {
                    const iIndex = oApproversORE.findIndex(item => item.ID === aTokens[i].getKey());
                    if (iIndex !== -1) {                                                
                        oApproversORE.splice(iIndex, 1);
                        oModel.refresh(true);
                    }
                }                
            }
            if (!oApproversORE.length) {
                if( this.byId("idMultiInputORE"))
                    this.byId("idMultiInputORE").setVisible(false);
                if(this.byId("idForwardNamedContact"))
                    this.byId("idForwardNamedContact").setEnabled(false); 
            } else {
                if( this.byId("idMultiInputORE"))
                    this.byId("idMultiInputORE").setVisible(true);
                if(this.byId("idForwardNamedContact"))
                    this.byId("idForwardNamedContact").setEnabled(true); 
            }
            //setting the visibility of forward request btn- GIT #142
            let bForwardBtnVisibility = oApproversORE.length > 0
            sap.ui.getCore().byId("idBtnForwardRequestOk").setEnabled(bForwardBtnVisibility)
            const oList = this.byId("idListORE");
            if(oList){
                const aItems = oList.getItems();
                for (let i = 0; i < aItems.length; i++) {
                    const oContext = aItems[i].getBindingContext("resourceModelORE").getObject();
                    const aFilterObj = oApproversORE.filter((approvers) => approvers.ID === oContext.ID);
                    if (aFilterObj.length) {
                        aItems[i].setSelected(true);
                    } else {
                        aItems[i].setSelected(false);
                    }
                }
            }            
        },
        onSearchBS: function (oEvent) {
            const sSearchValue = oEvent.getParameter("query").toLowerCase();
            const oList = this.getView().byId("idListBS");
            let aFilters = [];
            const oUserIdFilter = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.Contains, sSearchValue);
            aFilters.push(oUserIdFilter);
            const oEmailFilter = new sap.ui.model.Filter("email", sap.ui.model.FilterOperator.Contains, sSearchValue);
            aFilters.push(oEmailFilter);
            const oPFCFilter = new sap.ui.model.Filter("ProfitCenterDetails/formattedDesc", sap.ui.model.FilterOperator.Contains, sSearchValue);
            aFilters.push(oPFCFilter);

            const oCombinedFilter = new sap.ui.model.Filter(aFilters, false);

            oList.getBinding("items").filter(oCombinedFilter);
            oList.removeSelections();
            for (let i = 0; i < oList.getItems().length; i++) {
                const oContext = oList.getItems()[i].getBindingContext("resourceModelBS").getObject();
                const selectedBSModelData = this.getView().getModel("selectedBSModel").getData();
                const approverDetails = selectedBSModelData?.ApproverDetails || [];

                const aFilterObj = approverDetails.filter((approvers) => approvers.ID === oContext.ID);
                if (aFilterObj.length) {
                    oList.getItems()[i].setSelected(true);
                }
            }
        },
        onSearchORE: function (oEvent, isLiveSearch) {
            this.currentPageORE = 0;
            let sSearchValue;
            if(!isLiveSearch){
                sSearchValue = oEvent.getParameter("query");
            }else{
                sSearchValue = oEvent.getParameter("newValue");
            }
           
    const oList = this.getView().byId("idListORE");
    const that = this;
    const ApproversOREUrl = that._getOREApproversBaseURL();
    let filterORE;
let serviceUrlORE;
    if (sSearchValue) {
        filterORE = "&$filter=(MelodyRequest eq 'X')&$orderby=CapEmpNme asc";
        serviceUrlORE = ApproversOREUrl + "?search=" + sSearchValue + filterORE;
    }else{
        filterORE = "?$filter=(MelodyRequest eq 'X')&$orderby=CapEmpNme asc";
         serviceUrlORE = ApproversOREUrl + filterORE;
    }
    sap.ui.core.BusyIndicator.show(0);
    that.getNamedContactsData(serviceUrlORE, that.itemsPerPage, 0)
        .then(function (data) {
            sap.ui.core.BusyIndicator.hide();
            const valueORE = data.d.results;
            const approverDetails = valueORE.map(function (obj) {
                return {
                    fullName: obj.EmpName,
                    ID: obj.Id,
                    email: obj.EmailId,
                    to_substitute:obj.to_nmdsubstitute
                };
            });
            let oResourceModel = that.getView().getModel("resourceModelORE");
            if (!oResourceModel) {
                oResourceModel = new sap.ui.model.json.JSONModel();
                that.getView().setModel(oResourceModel, "resourceModelORE");
            }
            oResourceModel.setData({ ApproverDetails: approverDetails });
            oList.removeSelections();
            const oSelectedModel = that.getView().getModel("selectedOREModel").getData();
            const selectedApprovers = oSelectedModel?.ApproverDetails || [];

            oList.getItems().forEach((oItem) => {
                const oContext = oItem.getBindingContext("resourceModelORE").getObject();
                if (selectedApprovers.some(approver => approver.ID === oContext.ID)) {
                    oItem.setSelected(true);
                }
            });

        })
        .catch(function (error) {
            sap.ui.core.BusyIndicator.hide();
        });
        },
        onLiveORENamedChange:function(oEvent){
            var sValue = oEvent.getParameter("newValue");
    if (!sValue) {
             this.onSearchORE(oEvent);
    }else if (sValue.length > 5){
        this.onSearchORE(oEvent, true);
    }
        },
        currentAvatarDisplay: function (userId) {
            return this.getOwnerComponent().getModel("appConstants").getProperty("/userImg/0/Value") + userId;
        },
        _getOREFilterUrl: function () {
            const filterValues = {
                "Manager_Level": "non-managerial",
                "Role_GUID": this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RoleId,
                "RoleArea_P_GUID": this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.RoleArea_P_GUID.ID
            };
            const cross_CVRG_P_GUIDArray = this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.cross_CVRG_P_GUIDArray;

            const crossBAGuid = this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.BASegments;
            const baIndustriesGuid = this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.BAIndustries;
            const baLobs = this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.BALoBs;
            const hubs = this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.TempSelectedHubs;
            const baIndustries_GUIDs = baIndustriesGuid.map(item => item.BaIndId);
            const filterCondition1 = baIndustries_GUIDs.length ?
                `(${baIndustries_GUIDs.map(guid => `BaIndId eq '${guid}'`).join(' or ')})` : "";

            const baLobs_GUIDs = baLobs.map(item => item.ID);
            const filterCondition2 = baLobs_GUIDs.length ? `(${baLobs_GUIDs.map(guid => `BaLobId eq '${guid}'`).join(' or ')})` : "";
            const cross_CVRG_P_GUIDs = cross_CVRG_P_GUIDArray.map(item => item.ID);
            const filterCondition3 = cross_CVRG_P_GUIDs.length ? `(${cross_CVRG_P_GUIDs.map(guid => `CrossCvrgId eq '${guid}'`).join(' or ')})` : "";
            const crossBAGuidGuids = crossBAGuid.map(item => item.ID);
            const filterCondition4 = crossBAGuidGuids.length ? `(${crossBAGuidGuids.map(guid => `BaSegId eq '${guid}'`).join(' or ')})` : "";
            // const hubGuids = hubs.map(item => item.ID);
            // const filterCondition5 = hubGuids.length ? `(${hubGuids.map(guid => `HubIndId eq '${guid}'`).join(' or ')})` : "";

            let finalFilterString = `$filter=(RoleId eq '${filterValues.Role_GUID}') and (RoleAreaId eq '${filterValues.RoleArea_P_GUID}')`;

            const filterConditions = [filterCondition1, filterCondition2, filterCondition3, filterCondition4];
            const nonEmptyFilters = filterConditions.filter(condition => condition !== '');

            if (nonEmptyFilters.length > 0) {
                finalFilterString += ' and ';
                finalFilterString += nonEmptyFilters.join(' and ');
            }
            return finalFilterString;
        },
        bSFilterurl: function (ApproversBaseUrl, sProfitcenter, tableTypeId) {
            const filterValues = {
                "ProfitCenterGUID": sProfitcenter,
                "TableTypeID": tableTypeId,
                "Manager_Level": "non-managerial",
                "Role_GUID": this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.Guid,
                "RoleArea_P_GUID": this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.RoleArea_P_GUID.Guid
            };
            const cross_CVRG_P_GUIDArray = this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.cross_CVRG_P_GUIDArray;

            const crossBAGuid = this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.BASegments;
            const baIndustriesGuid = this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.BAIndustries;
            const baLobs = this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.BALoBs;

            const baIndustries_GUIDs = baIndustriesGuid.map(item => item.Guid);
            const filterCondition1 = baIndustries_GUIDs.length ? baIndustries_GUIDs.map(guid => ` and (BA_Industry_P_GUID eq ${guid})`).join(' or ') : "";

            // const filterCondition1 = baIndustries_GUIDs.map(guid => `BA_Industry_P_GUID eq ${guid}`).join(' or '); // Extract GUIDs from the first array
            const baLobs_GUIDs = baLobs.map(item => item.Guid);
            // const filterCondition2 = baLobs_GUIDs.map(guid => `BA_Lob_P_GUID eq ${guid}`).join(' or ');
            const filterCondition2 = baLobs_GUIDs.length ? baLobs_GUIDs.map(guid => ` and (BA_Lob_P_GUID eq ${guid})`).join(' or ') : "";
            const cross_CVRG_P_GUIDs = cross_CVRG_P_GUIDArray.map(item => item.Guid);
            // const filterCondition3 = cross_CVRG_P_GUIDs.map(guid => `Cross_CVRG_P_GUID eq ${guid}`).join(' or ');
            const filterCondition3 = cross_CVRG_P_GUIDs.length ? cross_CVRG_P_GUIDs.map(guid => ` and (Cross_CVRG_P_GUID eq ${guid})`).join(' or ') : "";
            const crossBAGuidGuids = crossBAGuid.map(item => item.Guid);
            // const filterCondition4 = crossBAGuidGuids.map(guid => `BA_Seg_GUID eq ${guid}`).join(' or ');
            const filterCondition4 = crossBAGuidGuids.length ? crossBAGuidGuids.map(guid => ` and (BA_Seg_GUID eq ${guid})`).join(' or ') : "";
            const finalFilterString = `$filter=(ProfitCenterGUID eq ${filterValues.ProfitCenterGUID}) and (TableTypeID eq '${filterValues.TableTypeID}') and (Manager_Level eq 'non-managerial') and (Role_GUID eq ${filterValues.Role_GUID}) and (RoleArea_P_GUID eq ${filterValues.RoleArea_P_GUID})${filterCondition1}${filterCondition2}${filterCondition3}${filterCondition4}`;

            return finalFilterString;
        },
       
        _getLoggedInUserAssignmentObj: function (self) {
            //filter loggedin user assignment details 
            const sCurrentUser = this.getOwnerComponent().getModel("userDetails").getProperty("/email");
            const aNominatedResources = self.getView().getModel().getProperty("/NominatedResources");
            let oResource;
            oResource = aNominatedResources.filter(nom => nom.email === sCurrentUser)[0];
            return oResource;
        },
        //Change Request to IO Staffing Working for EMEA #93 start
        //check the exception
        fnExceptionCallback: function (data, self, oAssignmentContext) {
            //check part of exception table
            if (data.value.length) {
                self.isPartOfException = true;
            } else {
                self.isPartOfException = false;
            }
           
            if ( !self.isPartOfException) {
                //no exception
                oAssignmentContext.isStaffing = self.isPartOfException;
            } else {   
                //exception 
                oAssignmentContext.isStaffing = true;
                self.oContextAssignmentObj.isStaffingFields = true;
                oAssignmentContext.isAutoStaffingCompanyCode = true;
                self.oContextAssignmentObj.staffingPurposeVisible = true;
                self.oContextAssignmentObj.expectedTimeInvstementVisible = false;
                self.oContextAssignmentObj.ioOwnerFieldVisible = self.oContextAssignmentObj.isOppOwnerActive;
                self.oContextAssignmentObj.ioOwnerTextFieldVisible = true;
                self.oContextAssignmentObj.staffingDateRangeVisible = true;
                self.oContextAssignmentObj.maxNoOfDaysToBookIOVisible = true;
                self.oContextAssignmentObj.taskLevelVisible = true;
                self.oContextAssignmentObj.staffingMsgVisible = true;
            }
            self._setStaffingMsg(self.oContextAssignmentObj.selectedNominees,self.oContextAssignmentObj);
        },
        //Change Request to IO Staffing Working for EMEA #93 end
        fnExceptionSuccessCallback: function (data, self, oAssignmentContext) {
            //check part of exception table
            if (data.value.length) {
                self.isPartOfException = true;
            } else {
                self.isPartOfException = false;
            }
            if (!oAssignmentContext) {
                //resource approval
                oAssignmentContext = self._getLoggedInUserAssignmentObj(self);
                oAssignmentContext.isPartOfException = self.isPartOfException;
                oAssignmentContext.isAutoStaffingCompanyCode = self.isAutoStaffingCompanyCode;
            } else {
                oAssignmentContext.isPartOfException = self.isPartOfException;
            }
             //Change Request to IO Staffing Working for EMEA #93 start
            let bSkipIOFlag = self.getView().getModel("WFRoutingSkipIOAPIData").getProperty("/value/0/operationalStatus");
            if (self.getView().getModel().getData().currentStepID !== "RESAPP") {
                if (oAssignmentContext && !self.isPartOfException && bSkipIOFlag) {
                    //no exception and skip io  not enabled
                    oAssignmentContext.isStaffing = false;
                    self._setStaffingMsg(self.oContextAssignmentObj.selectedNominees, self.oContextAssignmentObj);
                } else {
                    oAssignmentContext.isStaffing = true;
                    self.oContextAssignmentObj.isStaffingFields = true;
                    if (self.isPartOfException && bSkipIOFlag) {
                        oAssignmentContext.isAutoStaffingCompanyCode = true;
                    } else {
                        oAssignmentContext.isAutoStaffingCompanyCode = false
                    }
                    self.oContextAssignmentObj.staffingPurposeVisible = true;
                    self.oContextAssignmentObj.expectedTimeInvstementVisible = false;
                    self.oContextAssignmentObj.ioOwnerFieldVisible = self.oContextAssignmentObj.isOppOwnerActive;
                    self.oContextAssignmentObj.ioOwnerTextFieldVisible = true;
                    self.oContextAssignmentObj.staffingDateRangeVisible = true;
                    self.oContextAssignmentObj.maxNoOfDaysToBookIOVisible = true;
                    self.oContextAssignmentObj.taskLevelVisible = true;
                    self.oContextAssignmentObj.staffingMsgVisible = false;
                }
                self._setStaffingMsg(self.oContextAssignmentObj.selectedNominees, self.oContextAssignmentObj);
            }
            //Change Request to IO Staffing Working for EMEA #93 end
            //Check staffing criteria 
            if (oAssignmentContext.isPartOfException || oAssignmentContext.isAutoStaffingCompanyCode) {
                const sUserId = oAssignmentContext.userId;
                //Call userSearchHelps to fetch the perner number for staffing
                Models._callUserSearchHelps(sUserId, self, self.fnSuccessUserSearchHelpsCallBack, self.fnErrorUserSearchHelpsCallBack, oAssignmentContext);
            } else {
                //Proceed wf trigger
                self._onFinalSubmitWf(self);
            }
        },
        //Proceed wf trigger
        _onFinalSubmitWf: function (self) {
            const sInstanceID = self.sUserTaskId;
            const sStep = self.getView().getModel().getProperty("/currentStepID");
            const processContext = self.getView().getModel().getData();
            self.bSendBackToProcessor=false
            self._openSubmitDialog(
                processContext,
                sInstanceID,
                "Approve",
                sStep
            );
        },
        fnSuccessUserSearchHelpsCallBack: function (data, self, oAssignmentContext) {
            const sStep = self.getView().getModel().getProperty("/currentStepID");
            const sMsg =  self.i18nModel.getText("pernerServiceNoErrorMsg");
            if (data) {
                if (data.d.results.length) {
                    if (data.d.results[0].Pernr) {
                        //fetch perner number
                        oAssignmentContext.Pernr = data.d.results[0].Pernr;
                        if (sStep !== "MANAPP") {
                            //config staffing payload
                            self._formStaffingPayload(self, oAssignmentContext);
                        }
                    }
                }
                else {
                    
                    if (sStep !== "MANAPP") {
                        //Proceed wf trigger
                        self._onProceedForWfService(self, sMsg);
                    }
                }

            } else {
                
                if (sStep !== "MANAPP") {
                    //Proceed wf trigger
                    self._onProceedForWfService(self, sMsg);
                }
            }

        },
        fnErrorUserSearchHelpsCallBack: function (oError, oController) {
            //set generic error message
            ErrorHandle.setErrorMessage(oError, oController);
        },
        //set payload for staffing POST operation
        _setStaffingPayload: function (oNominatedResources) {
            const oStaffingPayload = {
                "Actexp": oNominatedResources.staffingPurposeKey ? oNominatedResources.staffingPurposeKey : "",
                "ActexpStr": oNominatedResources.staffingPurpose ? oNominatedResources.staffingPurpose : "",
                "Action": "2",
                "Begda": oNominatedResources.dateValue ? this.formatDateToMilliSeconds(oNominatedResources.dateValue) : "00000000",
                "BegdaStr": oNominatedResources.dateValue ? this.getDateString(new Date(oNominatedResources.dateValue)) : "00000000",
                "Bukrs": oNominatedResources.sCompanyCode ? oNominatedResources.sCompanyCode : "",
                "CostObjType": "IO",
                "Endda": oNominatedResources.secondDateValue ? this.formatDateToMilliSeconds(oNominatedResources.secondDateValue) : "00000000",
                "EnddaStr": oNominatedResources.secondDateValue ? this.getDateString(new Date(oNominatedResources.secondDateValue)) : "00000000",
                "EntryId": "O",
                "LogSystem": "CRM_MTR",
                "Name": oNominatedResources.fullName,
                "Snote": "",
                "Objnr": "",
                "Pernr": "00000000",
                "PernrStr": oNominatedResources.Pernr,
                "Posnr": "",
                "ReadOnly": false,
                "TaskLevel": oNominatedResources.staffingPurposeKey !== "E" ? oNominatedResources.taskLevelKey : "NONE",
                "Tasktype": "",
                "TasktypeStr": "",
                "Trtkl": "",
                "UserType": "",
                "Vbeln": oNominatedResources.internalOrder ? oNominatedResources.internalOrder.toString() : "",
                "Zexpdays": oNominatedResources.maxNoOfDaysToBookIO ? oNominatedResources.maxNoOfDaysToBookIO.toString() : "",
            }
            return oStaffingPayload;
        },
        formatDateToMilliSeconds: function (dateVal) {
            //convert date in to milli seconds
            const iDate = Date.parse(new Date(dateVal));
            return `\/Date(${iDate})\/`;
        },
        getDateString: function (date) {
            //convert date in to string
            const year = date.getFullYear();
            const month = date.getMonth() + 1;
            let month_append;
            let dat_append;
            if (month < 10) {
                month_append = "0";
            } else {
                month_append = "";
            }
            const dat = date.getDate();
            if (dat < 10) {
                dat_append = "0";
            } else {
                dat_append = "";
            }
            return (year + "" + month_append + "" + month + "" + dat_append + "" + dat);
        },
        _formStaffingPayload: function (self, oNominatedResources, bSkipResources) {
            //Finalize staffing payload
            let oFinalPayload = [];
            if (bSkipResources) {
                //skip resources ---> Presales Manager direct approve
                oNominatedResources.forEach(function (nominatedResource) {
                    oFinalPayload.push(self._setStaffingPayload(nominatedResource));
                })
            } else {
                //Resource approval
                oFinalPayload.push(self._setStaffingPayload(oNominatedResources));
            }
            sap.ui.core.BusyIndicator.show(0);
            //POST staffing
            Models._postStaffingDetails(oFinalPayload, self, self.fnSuccessPostStaffing, self.fnErrorPostStaffing)
        },
        fnSuccessPostStaffing: function (response, self) {
            sap.ui.core.BusyIndicator.hide();
            const bSkipResources = self.getView().getModel().getProperty("/Skip_Resource_Approver");
            if (bSkipResources) {
                try {
                    //error handling
                    if (JSON.parse(response.headers["sap-message"]).severity === "error") {
                        const sMsg = `${JSON.parse(response.headers["sap-message"]).message}.${self.i18nModel.getText("staffingGenericError")}?`
                        self._onProceedForWfService(self, sMsg);
                    } else {
                        //success message
                        self._showStaffingSuccessMessage(self.i18nModel.getText("staffingSuccessMsg"));
                        //proceed wf trigger
                        self.onApprove();
                    }
                } catch (err) {
                    self._showStaffingSuccessMessage(self.i18nModel.getText("staffingSuccessMsg"));
                    //proceed wf trigger
                    self.onApprove();
                }
            } else {
                try {
                    if (JSON.parse(response.headers["sap-message"]).severity === "error") {
                        const sMsg = `${JSON.parse(response.headers["sap-message"]).message}.${self.i18nModel.getText("staffingGenericError")}?`
                        //proceed wf trigger
                        self._onProceedForWfService(self, sMsg);
                    } else {
                        //proceed wf trigger
                        self._onFinalSubmitWf(self);
                    }
                } catch (err) {
                    //proceed wf trigger
                    self._onFinalSubmitWf(self);
                }
            }
        },
        _showStaffingSuccessMessage: function (sMsg) {
            //staffing POST success message
            MessageBox.show(
                sMsg, {
                icon: MessageBox.Icon.SUCCESS,
                title: "Success"
            });
        },
        _onProceedForWfService: function (self, sMsg) {
            //show warning message to continue wf -> trigger when staffing service fails
            const bSkipResources = self.getView().getModel().getProperty("/Skip_Resource_Approver");
            const sBtnText = self.getView().getModel("formActionsConfigModel").getData().idproceed[0].Label;
            MessageBox.show(
                sMsg, {
                icon: MessageBox.Icon.WARNING,
                title: "Warning",
                actions: [sBtnText, MessageBox.Action.CANCEL],
                emphasizedAction: sBtnText,
                onClose: function (oAction) {
                    if (oAction === sBtnText) {
                        if (bSkipResources) {
                            self.onApprove();
                        } else {
                            self._onFinalSubmitWf(self);
                        }
                    }
                }
            }
            );

            document.querySelectorAll(".sapMMessageBox").forEach(box => {
                box.style.width = "500px";
            });

        },
        fnErrorPostStaffing: function (response, self) {
            //staffing POST error message
            sap.ui.core.BusyIndicator.hide();
            const sMsg = self.i18nModel.getText("staffingErrorCallBackText");
            self._onProceedForWfService(self, sMsg);
        },
        fnExceptionErrorCallback: function (oError, self, token) {
            //exception error call back
            try {
                if (oError.responseJSON.error.message.value.includes("Record does not exists")) {
                    if (token) {
                        token.isPartOfException = false;
                    }
                }
            } catch (err) {
                //set generic error message
                ErrorHandle.setErrorMessage(oError, self);
            };
        },
        /**
        * RESOURCE ASSIGNMENT
        */
        _createResourceAssignmentDialog: function (processContext, taskId, sDecision) {
            const oThisController = this;
            if (!this._oResourceAssignmentDialog) {
                Fragment.load({
                    name: "com.dealsupport.melodyrequest.fragments.managerPage.ResourceAssignmentDialog",
                    controller: this
                }).then(function (oDialog) {
                    oDialog.addStyleClass(that.getOwnerComponent().getContentDensityClass());
                    this._oResourceAssignmentDialog = oDialog;
                    this._oResourceAssignmentDialog.setModel(this.getView().getModel());
                    this.getView().addDependent(this._oResourceAssignmentDialog);
                    this._configResourceAssignmentDialog();
                    this._oResourceAssignmentDialog.open();
                    this._oResourceAssignmentDialog.attachConfirm(function (oEvent) {
                        const aContexts = oEvent.getParameter("selectedContexts");
                        if (aContexts && aContexts.length) {
                            const oPresalesData = aContexts.map(function (oContext) { return oContext.getObject(); })
                            oThisController._createRoleSelectDialog(processContext, taskId, sDecision, oPresalesData);

                        }
                    })
                }.bind(this));
            } else {
                this._configResourceAssignmentDialog();
                this._oResourceAssignmentDialog.open();
            }
        },
        _createRequestDialog: function (oEvent, processContext, taskId, sDecision, oPresalesData) {
            sap.ui.core.BusyIndicator.show(0);
            oThisController._forwardActionDialog(oEvent, processContext, taskId, sDecision, oPresalesData);
            sap.ui.core.BusyIndicator.hide();
        },


        _createRoleSelectDialog: function (processContext, taskId, sDecision, oPresalesData) {
            const oThisController = this;

            if (!this._oRoleSelectDialog) {
                Fragment.load({
                    name: "com.dealsupport.melodyrequest.fragments.managerPage.RoleSelectDialog",
                    controller: this
                }).then(function (oDialog) {
                    oDialog.addStyleClass(that.getOwnerComponent().getContentDensityClass());
                    this._oRoleSelectDialog = oDialog;
                    this._oRoleSelectDialog.setModel(this.getView().getModel());
                    this.getView().addDependent(this._oRoleSelectDialog);
                    this._configRoleSelectDialog();
                    this._oRoleSelectDialog.open();
                    this._oRoleSelectDialog.attachConfirm(function (oEvent) {
                        let aContexts = oEvent.getParameter("selectedContexts");
                        if (aContexts && aContexts.length) {
                            const oRoleData = aContexts.map(function (oContext) { return oContext.getObject(); })
                            oThisController._confirmResourceAssignment(processContext, taskId, sDecision, oPresalesData, oRoleData);
                        }
                    })
                }.bind(this));
            } else {
                this._configRoleSelectDialog();
                this._oRoleSelectDialog.open();
            }
        },
        _confirmResourceAssignment: function (processContext, taskId, sDecision, oPresalesData, oRoleData) {
            let oThisController = this,
                oModel = this.getView().getModel(),
                sResourcesFullNames = oPresalesData[0].fullName;
            for (let i = 1; i < oPresalesData.length; i++) {
                sResourcesFullNames += ", " + oPresalesData[i].fullName;
            }
            oThisController.getView().getModel().setProperty("/assignedPresales", oPresalesData);
            const oAssignedRoleData = {
                name: this.getMessage(oRoleData[0].text),
                id: oRoleData[0].key
            }
            oThisController.getView().getModel().setProperty("/assignedRoleData", oAssignedRoleData);
            oThisController.bSendBackToProcessor=false
            oThisController._openSubmitDialog(processContext, taskId, sDecision, oModel.getProperty("/currentStepID"), sResourcesFullNames, oRoleData);
        },
        _configRequestDialog: function () {
            var that = this;
            const oTree = this.getView().byId("idTree");
            oTree.bindAggregation("items", "myPresaleModel>/data", function (sId, oContext) {
                const oLeafChild = oContext.getProperty("isLeafNode");
                const oControl =
                    (oLeafChild === true && oLeafChild !== " ") ? new sap.m.CustomTreeItem(sId, {
                        content: new sap.m.RadioButton({
                            text: "{myPresaleModel>text}",
                            select: that.onTreeItemSelected.bind(that)
                        })
                    }) :
                        new sap.m.CustomTreeItem(sId, {
                            content: new sap.m.Title({
                                text: "{myPresaleModel>text}"
                            })
                        });
                return oControl;
            });
        },
        _setReqAreasTree: function (aResult) {
            const aReqAreaTree = [];
            let oReqAreaObj = {};
            for (let i = 0; i < aResult.length; i++) {
                //pushing parent text into an array
                oReqAreaObj.text = aResult[i].Ra1;
                oReqAreaObj.enabled = !(aResult[i].Ra2 !== null);
                oReqAreaObj.isLeafNode = !(aResult[i].Ra2 !== null);
                if (oReqAreaObj.enabled && oReqAreaObj.isLeafNode) {
                    oReqAreaObj.PresalesRequestArea = aResult[i].Ra1;
                    oReqAreaObj.PresalesRequestAreaPath = aResult[i].Request_Area;
                    oReqAreaObj.GUID = aResult[i].GUID;
                }
                oReqAreaObj.nodes = [];
                aReqAreaTree.push(oReqAreaObj);
                oReqAreaObj = {};
                for (let j = 0; j < aReqAreaTree.length; j++) {
                    for (let k = j + 1; k < aReqAreaTree.length; k++) {
                        //removing duplicate element from array
                        if (aReqAreaTree[j].text === aReqAreaTree[k].text) {
                            aReqAreaTree.pop();
                        }
                    }
                }
            }
            for (let m = 0; m < aReqAreaTree.length; m++) {
                for (let n = 0; n < aResult.length; n++) {
                    //pushing child1 (Ra1) data into array
                    if (aReqAreaTree[m].text === aResult[n].Ra1) {
                        oReqAreaObj.text = aResult[n].Ra2;
                        oReqAreaObj.enabled = !(aResult[n].Ra3 !== null);
                        oReqAreaObj.isLeafNode = !(aResult[n].Ra3 !== null);
                        if (oReqAreaObj.enabled && oReqAreaObj.isLeafNode) {
                            oReqAreaObj.PresalesRequestArea = aResult[n].Ra1 + "-" + aResult[n].Ra2;
                            oReqAreaObj.PresalesRequestAreaPath = aResult[n].Request_Area;
                            oReqAreaObj.GUID = aResult[n].GUID;
                        }
                        oReqAreaObj.nodes = [];
                        aReqAreaTree[m].nodes.push(oReqAreaObj);
                        oReqAreaObj = {};
                        for (let j = 0; j < aReqAreaTree[m].nodes.length; j++) {
                            for (let k = j + 1; k < aReqAreaTree[m].nodes.length; k++) {
                                //removing duplicate element
                                if (aReqAreaTree[m].nodes[j].text === aReqAreaTree[m].nodes[k].text) {
                                    aReqAreaTree[m].nodes.pop();
                                }
                            }
                            for (let s = 0; s < aResult.length; s++) {
                                //pushing child2 (ReqArea3) data into array
                                if (aReqAreaTree[m].nodes[j].text === aResult[s].Ra2 && aReqAreaTree[m].text === aResult[s].Ra1) {
                                    oReqAreaObj.text = aResult[s].Ra3;
                                    oReqAreaObj.enabled = !(aResult[s].Ra4 !== null);
                                    oReqAreaObj.isLeafNode = !(aResult[s].Ra4 !== null);
                                    if (oReqAreaObj.enabled && oReqAreaObj.isLeafNode) {
                                        oReqAreaObj.PresalesRequestArea = aResult[s].Ra2 + "-" + aResult[s].Ra3;
                                        oReqAreaObj.PresalesRequestAreaPath = aResult[s].Request_Area;
                                        oReqAreaObj.GUID = aResult[s].GUID;
                                    }
                                    oReqAreaObj.nodes = [];
                                    aReqAreaTree[m].nodes[j].nodes.push(oReqAreaObj);
                                    oReqAreaObj = {};
                                    for (let i = 0; i < aReqAreaTree[m].nodes[j].nodes.length; i++) {
                                        for (let p = i + 1; p < aReqAreaTree[m].nodes[j].nodes.length; p++) {
                                            //removing duplicate element
                                            if (aReqAreaTree[m].nodes[j].nodes[i].text === aReqAreaTree[m].nodes[j].nodes[p].text) {
                                                aReqAreaTree[m].nodes[j].nodes.pop();
                                            }
                                        }
                                        //pushing child3(ReqArea4) data into array
                                        if (aResult[s].Ra4 !== null && aResult[s].Ra3 === aReqAreaTree[m].nodes[j].nodes[i].text && aReqAreaTree[m].nodes[j].text === aResult[s].Ra2) {
                                            oReqAreaObj.text = aResult[s].Ra4;
                                            oReqAreaObj.enabled = true;
                                            oReqAreaObj.isLeafNode = true;
                                            oReqAreaObj.PresalesRequestArea = aResult[s].Ra3 + "-" + aResult[s].Ra4;
                                            oReqAreaObj.PresalesRequestAreaPath = aResult[s].Request_Area;
                                            oReqAreaObj.GUID = aResult[s].GUID;
                                            oReqAreaObj.nodes = [];
                                            aReqAreaTree[m].nodes[j].nodes[i].nodes.push(oReqAreaObj);
                                            oReqAreaObj = {};
                                            for (let b = 0; b < aReqAreaTree[m].nodes[j].nodes[i].nodes.length; b++) {
                                                for (let c = b + 1; c < aReqAreaTree[m].nodes[j].nodes[i].nodes.length; c++) {
                                                    if (aReqAreaTree[m].nodes[j].nodes[i].nodes[b].text === aReqAreaTree[m].nodes[j].nodes[i].nodes[c].text) {
                                                        aReqAreaTree[m].nodes[j].nodes[i].nodes.pop();
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return aReqAreaTree;

        },
        onTreeItemSelected: function (oEvent) {
            const sPath = oEvent.getSource().getBindingContext("myPresaleModel").sPath;
            this.selectedArea = this.getView().getModel("myPresaleModel").getProperty(sPath);
            this.getView().getModel("profileViewParameters").setProperty("/footerButtons/forwardReqButtonEnabled", true);
        },
        _configResourceAssignmentDialog: function () {
            // Set growing property
            this._oResourceAssignmentDialog.setGrowing(true);
            // Set style classes
            const sResponsiveStyleClasses = "sapUiResponsivePadding--header sapUiResponsivePadding--subHeader sapUiResponsivePadding--content sapUiResponsivePadding--footer";
            this._oResourceAssignmentDialog.toggleStyleClass(sResponsiveStyleClasses, true);
            // clear the old search filter
            this._oResourceAssignmentDialog.getBinding("items").filter([]);
            // toggle compact style
            syncStyleClass("sapUiSizeCompact", this.getView(), this._oResourceAssignmentDialog);
        },
        _configRoleSelectDialog: function () {
            // Set growing property
            this._oRoleSelectDialog.setGrowing(true);
            // Set style classes
            const sResponsiveStyleClasses = "sapUiResponsivePadding--header sapUiResponsivePadding--subHeader sapUiResponsivePadding--content sapUiResponsivePadding--footer";
            this._oRoleSelectDialog.toggleStyleClass(sResponsiveStyleClasses, true);
            // clear the old search filter
            this._oRoleSelectDialog.getBinding("items").filter([]);
            // toggle compact style
            syncStyleClass("sapUiSizeCompact", this.getView(), this._oRoleSelectDialog);
        },
        onCreateRequest: function (oEvent) {
            this._oRequestDialog.close();
            this._oRequestDialog.complete();
        },
        onRequestDialogCancel: function (oEvent) {
            this._oRequestDialog.close();
        },
        onPresalesSearch: function (oEvent) {
            const sSearchQuery = oEvent.getParameter("value");
            const aFilters = [];
            aFilters.push(new Filter({
                filters: [
                    new Filter({
                        path: "fullName",
                        operator: FilterOperator.Contains,
                        value1: sSearchQuery
                    }),
                    new Filter({
                        path: "email",
                        operator: FilterOperator.Contains,
                        value1: sSearchQuery
                    })
                ],
                and: false
            }));
            const oFilter = new Filter({
                filters: aFilters,
                and: true
            });
            const oBinding = oEvent.getParameter("itemsBinding");
            oBinding.filter(oFilter);
        },
        onIOOwnerSearch: function (oEvent) {
            const sSearchQuery = oEvent.getParameter("value");
            const oList = oEvent.getSource()._dialog.getContent()[1];
            oList.setBusy(true);
            Models._callEmployeeService(sSearchQuery, 100, 0, this, oList);
        },
        onPresalesRolesSearch: function (oEvent) {
            const sSearchQuery = oEvent.getParameter("value");
            const aFilters = [];

            aFilters.push(new Filter({
                filters: [
                    new Filter({
                        path: "text",
                        operator: FilterOperator.Contains,
                        value1: sSearchQuery
                    })
                ],
                and: false
            }));
            const oFilter = new Filter({
                filters: aFilters,
                and: true
            });
            const oBinding = oEvent.getParameter("itemsBinding");
            oBinding.filter(oFilter);
        },
        onPresalesRolesDialogClose: function (oEvent) {
            oEvent.getSource().getBinding("items").filter([]);
        },
        _openSubmitDialog: function (processContext, taskId, sDecision, sStep, sResourcesFullNames, oRoleData) {

            const oModel = this.getView().getModel();
            let sNewDecision = this._setDecision(sDecision);
            oModel.setProperty("/comments", "");
            oModel.refresh()
            let oRejectCodes = this.getView().getModel("RejectionCodeAPIData");
            if (sStep !== "MANAPP") {



                //dialog box for send back to processor - GIT #144
                if (this.bSendBackToProcessor) {
                    this.oSubmitDialog = new Dialog({
                        type: library.DialogType.Message,
                        title: this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/SendBacktoProcessorTitle/0/fieldDesc"),
                        content: [
                            new Text({
                                text: this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/SendBacktoProcessorMsg/0/fieldDesc"),
                                wrapping: true

                            }),


                            new TextArea("submissionNoteReject", {
                                width: "100%",
                                placeholder: this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/ResourceCommentPlaceholder/0/fieldDesc") + "\n" + this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/ResourceCommentMsg/0/fieldDesc"),
                                visible: sDecision === "Reject" ? true : false,
                                maxLength:5000,
                                liveChange: function (oEvent) {
                                    oEvent.getParameter("value").length > 0 ? this.oSubmitDialog.getBeginButton().setEnabled(true) : this.oSubmitDialog.getBeginButton().setEnabled(false)
                                }.bind(this)
                            })
                        ],
                        beginButton: new Button({
                            type: library.ButtonType.Emphasized,
                            text: this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/SendBacktoProcessorTitle/0/fieldDesc"),
                            enabled: false,
                            press: function () {
                                this._validateInput(this.getView().getModel().getData(), taskId, sDecision);
                            }.bind(this)
                        }),
                        endButton: new Button({
                            text: this.getMessage("CANCEL"),
                            press: function () {
                                this.oSubmitDialog.close();
                                this.oSubmitDialog.destroy();
                            }.bind(this)
                        })
                    });
                } else {
                    //Combo box for request request pop up - GIT #139
                    let oComboBox = new sap.m.ComboBox("idRejectionSelect", {
                        width: "100%",
                        placeholder: this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/ProcessorRejectReason/0/fieldDesc"),
                        valueState: "Error",
                        showValueStateMessage: false,
                        change: function (oEvent) {
                            oEvent.getSource().setValueState("None")
                            this.oSubmitDialog.getBeginButton().setEnabled(true);
                        }.bind(this),
                        items: {
                            path: "/value",
                            template: new sap.ui.core.Item({
                                key: "{RejID}",
                                text: "{Rejection_Reason}"
                            })
                        },
                        visible: sDecision === "Reject" ? true : false
                    })
                    //combo box input disabled- GIT #139
                    oComboBox.addEventDelegate({
                        onAfterRendering: function () {
                            var $input = oComboBox.$().find("input")
                            if ($input.length) {
                                $input.attr("readonly", true)
                            }
                        }
                    }, oComboBox)

                    this.oSubmitDialog = new Dialog({
                        type: library.DialogType.Message,
                        title: sStep === "MANAPP" ? sDecision === "Approve" ? this.getMessage("CONFIRM_APPROVE_AND_ASSIGN") : sDecision === "Send Back to Requestor" ? this.getMessage("ENTER_COMMENT") : this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/ProcessorRejectRequestTitle/0/fieldDesc") :
                            sDecision === "Approve" ? sNewDecision == "Acknowledge" ? this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/AcknowledgeRequestTitle/0/fieldDesc") : this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/AcceptRequestTitle/0/fieldDesc") : sDecision === "Send Back to Requestor" ? this.getMessage("ENTER_COMMENT") : this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/ProcessorRejectRequestTitle/0/fieldDesc"),
                        content: [
                            new Text({
                                text: sStep === "MANAPP" ?
                                sDecision === "Approve" ? this.getMessage("APPROVE_AND_ASSIGN_CONFIRM") + ' ' + sResourcesFullNames + ' ' + this.getMessage("IN_ROLE") + ' ' + this.getMessage(oRoleData[0].text) + '?' : sDecision === "Send Back to Requestor" ? this.getMessage("PROVIDE_REASON_FOR_DECISION") + ' "' + sNewDecision + '".' : this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/ProcessorRejectRequestMessage/0/fieldDesc") :
                                sDecision === "Approve" ? sNewDecision=="Acknowledge"?this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/AcknowledgeRequestMessage/0/fieldDesc"):this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/AcceptRequestMsg/0/fieldDesc") : sDecision === "Send Back to Requestor" ? this.getMessage("PROVIDE_REASON_FOR_DECISION") + ' "' + sNewDecision + '".' : this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/ProcessorRejectRequestMessage/0/fieldDesc"),

                                wrapping: true

                            }),

                            oComboBox,
                            new TextArea("submissionNote", {
                                width: "100%",
                                value: '{/comments}',
                                placeholder: sDecision === "Approve" && sStep === "MANAPP" ? this.getMessage("ASSIGN_RESOURCE_PLACEHOLDER") : sDecision === "Send Back to Requestor" ? this.getMessage("ENTER_TEXT_REQ") : this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/ResourceCommentPlaceholder/0/fieldDesc") + "\n" + this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/ResourceCommentMsg/0/fieldDesc"),
                                valueState: '{/commentsState}',
                                valueStateText: '{/commentsStateText}',
                                visible: sDecision === "Reject" ? false : true,
                                maxLength:5000,
                                liveChange: function (oEvent) {
                                    const sComment = oEvent.getParameter("value");
                                    this.oSubmitDialog.getBeginButton().setEnabled(sComment.length > 0);
                                    if (sComment.length > 0) {
                                        oModel.setProperty("/commentsState", "None");
                                        oModel.setProperty("/comments", sComment);
                                    }
                                }.bind(this)
                            }),
                            new TextArea("submissionNoteReject", {
                                width: "100%",
                                placeholder: this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/ProcessorRejectCommentPlaceholder/0/fieldDesc") + "\n" + this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/ProcessorRejectCommentMsg/0/fieldDesc"),
                                visible: sDecision === "Reject" ? true : false,
                                maxLength:5000
                            })
                        ],
                        beginButton: new Button({
                            type: library.ButtonType.Emphasized,
                            text: sDecision == "Reject" ? this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/ProcessorRejectButtonText/0/fieldDesc") : sDecision == "Approve" ?sNewDecision=="Acknowledge"? this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/AcknowledgeRequestButtonText/0/fieldDesc"): this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/AcceptRequestButtonText/0/fieldDesc"): this.getMessage("OK"),
                            enabled: sDecision == "Approve" ? true : false,
                            press: function () {
                                this._validateInput(this.getView().getModel().getData(), taskId, sDecision);
                            }.bind(this)
                        }),
                        endButton: new Button({
                            text: this.getMessage("CANCEL"),
                            press: function () {
                                this.oSubmitDialog.close();
                                this.oSubmitDialog.destroy();
                            }.bind(this)
                        })
                    });
                }
                //to get access to the controller's model
                this.getView().addDependent(this.oSubmitDialog);
                // }
                // toggle compact style
                syncStyleClass("sapUiSizeCompact", this.getView(), this.oSubmitDialog);
                this.oSubmitDialog.setModel(oRejectCodes);
                this.oSubmitDialog.open();
            }
        },
        _validateInput: function (processContext, taskId, sDecision) {
            let oModel = this.getView().getModel(),
                errorExist = false,
                sComment = oModel.getProperty("/comments");

            if (sDecision != "Reject") {
                if (sComment && sComment.trim() && sComment !== "" && sComment !== "undefined" && sComment !==
                    "null") {
                    oModel.setProperty("/commentsState", "None");
                } else {
                    if(sDecision!="Approve")
                        errorExist = true;
                    oModel.setProperty("/commentsStateText", this.getMessage("PROVIDE_COMMENT"));
                    oModel.setProperty("/commentsState", "Error");
                }
            } else if (sDecision == "Reject") {
                if(! this.bSendBackToProcessor){
                    processContext.rejectReason = sap.ui.getCore().byId("idRejectionSelect").getSelectedItem().getText();
                    processContext.rejectReasonID = sap.ui.getCore().byId("idRejectionSelect").getSelectedItem().getKey()
                }
                processContext.comments = sap.ui.getCore().byId("submissionNoteReject").getValue();

            }
            if (errorExist) {
                const sGenericErrorText = this.getMessage("FIELD_VALIDATION_ERROR_GENERIC");
                MessageToast.show(sGenericErrorText)
                this.getView().setBusy(false);
                return;
            } else {
                this.oSubmitDialog.close();
                this.oSubmitDialog.destroy();
                if (processContext.ResReject !== true) {
                    // this._fnRegisterActivity(this,processContext, taskId, sDecision);
                    const oAssignmentsData = this.getView().getModel("assignmentsModel").getProperty("/assignments"),
                        bIsNoActivityRegister = oAssignmentsData.every(val => !val.enableActivityRegister);
                    // if (bIsNoActivityRegister) {
                    //     this._onOpenActivityBusyDialog(this, processContext, taskId, sDecision,true);
                    // } else {
                    //     if(sDecision == "Approve"){
                    //         this._onOpenActivityBusyDialog(this, processContext, taskId, sDecision);
                    //     }else{
                    //         this._triggerComplete(processContext, taskId, sDecision);
                    //     }
                     
                    // }
                     if(sDecision == "Approve"){
                            this._onOpenActivityBusyDialog(this, processContext, taskId, sDecision,bIsNoActivityRegister);
                        }else{
                            this._triggerComplete(processContext, taskId, sDecision);
                        }
                    //this._triggerComplete(processContext, taskId, sDecision);
                } else {
                    if (processContext.rejectReasonID) {
                        var oRejectReason = {
                            "rejReason": processContext.rejectReason,
                            "rejComments": processContext.comments,
                            "rejectReasonID": processContext.rejectReasonID
                        }

                    } else {
                        var oRejectReason = {
                            "rejReason": processContext.rejectReason,
                            "rejComments": processContext.comments
                        }
                    }
                    
                    const oFinalPayload = this._fnConfigAssignmentsPayload(this);
                    const oAssignments = oFinalPayload.Assignment;
                    this._triggerComplete(oAssignments, taskId, sDecision, oRejectReason);
                }
            }
        },
        // This method is called when the confirm button is click by the end user
         _triggerComplete: function (processContext, taskId, sDecision, managerRejectReason, isResourceProfile, sSelection) {
            const oThisController = this;
            const cFLPUserInfo = this.getOwnerComponent().getModel("userDetails");
            const workflowBaseurl = this._getWorkflowRuntimeBaseURL();
            oThisController.getView().getModel().getProperty("/actRegDialog")?  sap.ui.core.BusyIndicator.hide(): sap.ui.core.BusyIndicator.show();
            //get substituteDetails
            let aSubstDetails = oThisController.getView().getModel().getProperty("/substituteApproverDetails");
            let aFilteredSubstitute = aSubstDetails ? aSubstDetails.filter(subs => subs.userId === cFLPUserInfo.getProperty("/user_name")):[];
            if(  this.oActBusyDialog){
                 this.oActBusyDialog.removeAllButtons();
            }
            $.ajax({
                // Call workflow API to get the xsrf token
                url: workflowBaseurl + "rest/v1/xsrf-token",
                method: "GET",
                headers: {
                    "X-CSRF-Token": "Fetch"
                },
                success: function (result, xhr, data) {
                    // After retrieving the xsrf token successfully
                    const token = data.getResponseHeader("X-CSRF-Token");
                    let userId = null;
                    if (oThisController.getView().getModel().getProperty("/currentStepID") === "MANAPP") {
                        if (!oThisController.getView().getModel().getData().isResourceProfile) {
                            let usersArray = oThisController.getView().getModel().getData().approverDetails;
                            let emailToFind = cFLPUserInfo.getProperty("/email")
                            for (let i = 0; i < usersArray.length; i++) {
                                if (usersArray[i].email === emailToFind) {
                                    userId = usersArray[i].userId;
                                    break;
                                }
                            }
                        } else {
                            let usersArray = oThisController.getView().getModel().getData().aResourceProfileApprovers.ApproverDetails;
                            let emailToFind = cFLPUserInfo.getProperty("/email")
                            for (let i = 0; i < usersArray.length; i++) {
                                if (usersArray[i].email === emailToFind) {
                                    userId = usersArray[i].ID;
                                    break;
                                }
                            }
                        }
                    }
                    else {
                        let usersArray = oThisController.getView().getModel().getData().NominatedResources;
                        let emailToFind = cFLPUserInfo.getProperty("/email")
                        for (let i = 0; i < usersArray.length; i++) {
                            if (usersArray[i].email === emailToFind) {
                                userId = usersArray[i].userId;
                                break;
                            }
                        }
                    }
                    // form the context that will be updated
                    const oBasicData = {
                        context: {
                            "decision": sDecision,
                            "currentProcessor": {
                                "email": cFLPUserInfo.getProperty("/email"),
                                "fullName": cFLPUserInfo.getProperty("/name"),
                                "id": cFLPUserInfo.getProperty("/user_name")
                            }
                        },
                        "status": "COMPLETED"
                    };
                    if(oThisController.getView().getModel().getProperty("/accOwnerDetails")?.id){
                        //update account owner payload
                        oBasicData.context.accOwnerDetails = oThisController.getView().getModel().getProperty("/accOwnerDetails")
                    }
                    if(oThisController.getView().getModel().getProperty("/oppOwnerDetails")?.id){
                        //update opportunity owner payload
                        oBasicData.context.oppOwnerDetails = oThisController.getView().getModel().getProperty("/oppOwnerDetails")
                    }
                    if (!oThisController.getView().getModel().getProperty("/parentInstanceID")) {
                        oBasicData.context.parentInstanceID = oThisController.getOwnerComponent().getModel("wfInstanceModel").getData().ParentInstanceID;
                    }
                    switch (sDecision) {
                        case "Approve":
                            oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idapprove[0].ID;
                            //GIT - 308 Complete actions confirmation msgs
                            if(oThisController.getView().getModel("formActionsConfigModel").getData().idapprove[0].UserTask === 'Manager'){
                                oThisController.sSuccessMsg = oThisController.getView().getModel("formActionsConfigModel").getData().idapprove[0].Action_Message;
                            }else{
                                oThisController.sSuccessMsg = oThisController.i18nModel.getText("approvedMsg");
                            }
                            break;
                        case "Forward":
                            oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idforward[0].ID;
                            if(sSelection === true){
                                oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idresprofilesel[0].ID; 
                                //GIT - 308 Complete actions confirmation msgs
                                oThisController.sSuccessMsg = oThisController.getView().getModel("formActionsConfigModel").getData().idresprofilesel[0].Action_Message; 
                                oBasicData.context.ForwardAction = "Edit Profile"
                            }else if(sSelection == "namedContact"){
                                oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idnamedcontsel[0].ID; 
                                //GIT - 308 Complete actions confirmation msgs
                                oThisController.sSuccessMsg = oThisController.getView().getModel("formActionsConfigModel").getData().idnamedcontsel[0].Action_Message; 
                                oBasicData.context.ForwardAction = "Edit Processor"
                             }                            
                            break;
                        case "Reject":
                            oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idreject[0].ID;
                            oThisController.sSuccessMsg = oThisController.i18nModel.getText("rejectedMsg");
                            break;
                        case "Send Back to Requestor":
                            oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idrework[0].ID;
                            //GIT - 308 Complete actions confirmation msgs
                            oThisController.sSuccessMsg = oThisController.getView().getModel("formActionsConfigModel").getData().idrework[0].Action_Message;                            
                            break;
                        default:
                            oBasicData.context.decision_ID = ""
                            oThisController.sSuccessMsg = oThisController.i18nModel.getText("requestSubmitted");
                            break;
                    }
                    if(sDecision === "Reject" && oThisController.getView().getModel().getProperty("/currentStepID") !== "MANAPP"){
                        oThisController.sSuccessMsg = oThisController.i18nModel.getText("closeMsg");
                    }
                    if (sDecision == "Forward" && processContext.isResourceProfile) {
                        oBasicData.context.isRoleAreaSelection = true;
                        oBasicData.context.oldReqArea = processContext.selectedProfitCenter[0].Desc;
                        oBasicData.context.searchFieldsText = oThisController.getView().getModel("resourceModel").getData()[0] ? oThisController.getView().getModel("resourceModel").getData()[0].sSearchText : oThisController.getView().getModel("resourceModel").getData().searchFieldsText;
                    }
                    if (oThisController.getView().getModel().getProperty("/currentStepID") === "MANAPP") {
                        oBasicData.context.ManagerUserTaskID = oThisController.sUserTaskId;
                        if (processContext.Assignment  && sDecision !== "Reject") {
                            oBasicData.context.Assignment = processContext.Assignment;
                        } else {
                            if (sDecision !== "Send Back to Requestor" && sDecision !== "Forward"  && sDecision !== "Reject") {
                                oBasicData.context.Assignment = processContext;
                            }
                        }
                    } else {
                        oBasicData.context.ResourcesUserTaskID = oThisController.sUserTaskId;
                        const sReqType = processContext.RequestType;
                        const sCurrentUser = oThisController.getOwnerComponent().getModel("userDetails").getData().email;
                        let bIsIOStaffing;
                        processContext.NominatedResources.forEach(function (nom) {
                            if (sCurrentUser === nom.email) {
                                bIsIOStaffing = nom.isIOStaffing
                            }
                        });
                        if (sDecision === "Approve" && sReqType === "Opportunity" && bIsIOStaffing) {
                            //submit(update) updated fields for staffing
                            oBasicData.context.NominatedResources = processContext.NominatedResources;
                        }
                        if (sDecision === "Approve") {
                            if (processContext.AllAssignmentDetails && processContext.AllAssignmentDetails.length) {
                                oBasicData.context.AllAssignmentDetails = processContext.AllAssignmentDetails;
                            }
                        }
                    }
                    if (processContext.comments || oThisController.getView().getModel().getProperty("/comments")){
                        //update action comments
                        oBasicData.context.comments = processContext.comments ? processContext.comments:oThisController.getView().getModel().getProperty("/comments");
                    }


                    if (sDecision === "Forward" && oThisController.selectedArea && !isResourceProfile && sSelection !== "namedContact") {
                        oBasicData.context.requestAreaPath = oThisController.selectedArea.PresalesRequestAreaPath;
                        oBasicData.context.requestArea = oThisController.selectedArea.PresalesRequestArea;
                        oBasicData.context.forwardGUID = oThisController.selectedArea.GUID;
                        oBasicData.context.isResourceProfile = false;
                        oBasicData.context.OrgType = "SORG";
                        let sorgID;
                        let oTempEmployeeGUID = oThisController.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories/0/SelectedGuid");
                        oThisController.getView().getModel("PCSalesOrgMaster").getData().find(function (item) {
                            if (item.ProfitCenterGuid === oTempEmployeeGUID) {
                                sorgID = item.SOrg;
                            }
                        });
                        if(oTempEmployeeGUID){
                            //update orgId when processor forward from resource profile to Req Area
                            oBasicData.context.OrgID = "SORG-" + ('0000' + sorgID).slice(-4);
                        }
                        if (sorgID === "NOMP") {
                            sorgID = oTempEmployeeGUID;
                            oBasicData.context.OrgID = sorgID;
                            oBasicData.context.isNoMP = true;
                            oBasicData.context.OrgType = "PC";
                        }
                        oThisController.onCloseForwardReqDialog();
                    } else if (sDecision === "Forward" && isResourceProfile && sSelection !== "namedContact") {
                        oThisController["aResourceProfileApprovers"]["ResourceProfileDetails"]["SolutionAreas"] =
                            oThisController["aResourceProfileApprovers"]["ResourceProfileDetails"]["SolutionAreas"] ? oThisController["aResourceProfileApprovers"]["ResourceProfileDetails"]["SolutionAreas"] : [];
                        oBasicData.context.aResourceProfileApprovers = oThisController.aResourceProfileApprovers;
                        oBasicData.context.OrgID  = oThisController.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories/0/SelectedGuid");
                        oBasicData.context.isResourceProfile = true;
                        oBasicData.context.selectedProfitCenter = oThisController.selectedProfitCenter;
                        oThisController.onCloseForwardReqDialog();
                    } else if (sSelection === "namedContact") {
                        oBasicData.context.aResourceProfileApprovers = oThisController.getView().getModel().getData().aResourceProfileApprovers;
                    }

                    if (sDecision === "Reject") {
                        if (managerRejectReason) {
                            oBasicData.context.rejectReason = managerRejectReason.rejReason;
                            oBasicData.context.comments = managerRejectReason.rejComments;
                            if(managerRejectReason.rejectReasonID)
                                oBasicData.context.rejectReasonID = managerRejectReason.rejectReasonID;
                        } else {
                            if(! oThisController.bSendBackToProcessor){
                                oBasicData.context.rejectReason = processContext.rejectReason;
                                oBasicData.context.rejectReasonID = processContext.rejectReasonID;
                            } 
                        }
                    }
                    if(oThisController.getView().getModel().getProperty("/currentStepID") !== "MANAPP" && sDecision === "Reject"){
                        oBasicData.context.ResSendBackDecision = oThisController.getView().getModel("formActionsConfigModel").getData().idreject[0].Label;
                    }
                    //update orgid,orgtype and requesttype for older entries
                    if (typeof (oThisController.getView().getModel().getData()["SalesOrgID"]) === "string") {
                        oBasicData.context["OrgID"] = oThisController.getView().getModel().getData()["SalesOrgID"];
                        oBasicData.context["OrgType"] = "SORG";
                        oBasicData.context["RequestType"] = "Opportunity"

                        if (sDecision === "Forward") {
                            //update areapath call
                            const OrgID_Num = oThisController._getOrgIDnumber(oBasicData.context.OrgID, oBasicData.context.OrgType);
                            const aAreaPathCallRequests = [{
                                id: "1",
                                method: "GET",
                                url: "/Resources(GUID=" + processContext.GUID + ",IsActiveEntity=true)",
                                headers: { "content-type": "application/json;IEEE754Compatible=true" }
                            },
                            // To fetch Email template details
                            {
                                id: "2",
                                method: "GET",
                                url: "/Email_Body?$filter=orgID eq '" + OrgID_Num + "' and orgType eq '" + oBasicData.context.OrgType + "'",
                                headers: { "content-type": "application/json;IEEE754Compatible=true" }
                            },
                            // End of code for Melody Resource Request Tool Sprint 1
                            // to fetch Email Delegates Details
                            {
                                id: "3",
                                method: "GET",
                                url: "/Email_Delegates?$filter=orgID eq '" + oBasicData.context.OrgID + "'",
                                headers: { "content-type": "application/json;IEEE754Compatible=true" }
                            },
                            // to check routing flags 
                            {
                                id: "4",
                                method: "GET",
                                url: "/WF_Routing?$filter=eng_Type_ID eq '"+processContext.EngagementType+"' and orgID eq '" + oBasicData.context.OrgID + "'",
                                headers: { "content-type": "application/json;IEEE754Compatible=true" }
                            }];
                            oBasicData.context.areaPathCall = {
                                "Request": {
                                    "requests": aAreaPathCallRequests
                                }
                            };
                        }
                    }
                    //update refrence id for older request
                    if (typeof oThisController.getView().getModel().getData().RequestID !== "object") {
                        if( oThisController.getView().getModel().getProperty("/updatedRefId")){
                            oBasicData.context.RequestID = {
                                "value": oThisController.getView().getModel().getProperty("/updatedRefId")
                            }
                        }
                    }
                    //substitute check
                    if (aFilteredSubstitute.length) {
                        oBasicData.context.isSubstitute = true;
                    }else{
                        oBasicData.context.isSubstitute = false;
                    }
                    $.ajax({
                        // Call workflow API to complete the task
                        url: workflowBaseurl + "rest/v1/task-instances/" + taskId,
                        method: "PATCH",
                        contentType: "application/json",
                        // pass the updated context to the API
                        data: JSON.stringify(oBasicData),
                        headers: {
                            // pass the xsrf token retrieved earlier
                            "X-CSRF-Token": token
                        },
                        // refreshTask needs to be called on successful completion
                        success: function (result, xhr, data) {
                                sap.ui.core.BusyIndicator.show();
                                oThisController.getView().byId("idSaveandSubmitBtn").setEnabled(false);
                                if (oThisController.oActBusyDialog) {
                                const oBusyModelData = oThisController.getView().getModel("actiVityBusyData");
                                oBusyModelData.setProperty("/submitStatusIcon", "sap-icon://sys-enter-2");
                                oBusyModelData.setProperty("/submitBusyVisible", false);
                                oBusyModelData.setProperty("/submitStatus", "Success");
                                oBusyModelData.refresh();
                                if (oThisController.getView().getModel().getProperty("/actRegDialog")) {
                                    //trigger after the activity registration and resource assignment
                                    oThisController.getView().getModel().setProperty("/actRegDialog/RESText", oThisController.getOwnerComponent().getModel("i18n").getResourceBundle().getText("activityRegComplete"));
                                    oThisController.getView().getModel().setProperty("/actRegDialog/RESColorScheme", 8);
                                    oThisController.getView().getModel().setProperty("/actRegDialog/RESIcon", "sap-icon://status-completed");
                                }
                                oThisController.oActBusyDialog.close();
                            }
                            // oThisController._refreshTask();
                            MessageToast.show(oThisController.sSuccessMsg, {
                                duration: 6000
                            });
                        if(oThisController.getOwnerComponent().getModel("appConstants").getProperty("/isReqView")){
                            sap.ui.core.BusyIndicator.hide();
                            oThisController.navToReqView();
                        }else{
                            oThisController.getOwnerComponent().getModel("appConstants").setProperty("/isAfterWfAction",true);
                            setTimeout(function () {
                            CommonJS._refreshTask(oThisController);
                            }, 1000)
                        }
                        oThisController.getView().setBusy(false);

                        }

                    });
                }
            });

        },
        onItemSearchInHierarchy: function (oEvent) {
            const sQUery = oEvent.getParameter("newValue").trim();
            let oPresaleTable = {};
            oPresaleTable = this.getView().byId("idTree");
            const oPresaleTextFilter = new Filter("text", FilterOperator.Contains, sQUery);
            const oPresaleFilter = new Filter({
                filters: [oPresaleTextFilter],
                and: false
            });
            oPresaleTable.getBinding("items").filter(oPresaleFilter);
        },
        // Request Inbox to refresh the control once the task is completed
        _refreshTask: function () {
            const taskId = this.getComponentData().startupParameters.taskModel.getData().InstanceID;
            this.getComponentData().startupParameters.inboxAPI.updateTask("NA", taskId);
            
        },
        /**
        * DOCUMENT SERVICE INTEGRATION
        */
        loadAttachments: function (that) {
            // get workflow ID
            const taskInstanceModel = that.getView().getModel("taskInstanceModel");
            workflowInstanceId = taskInstanceModel.getData().workflowInstanceId;
            that.workflowFileUploadId = that.getView().getModel().getProperty("/workflowFileUploadId") ? that.getView().getModel().getProperty("/workflowFileUploadId") : workflowInstanceId;
            that.sDocServiceUrl= that._getDocServiceRuntimeBaseURL();
            const sUrl = that.sDocServiceUrl + "/WorkflowManagement/HarmonyPresalesRequests/" + that.workflowFileUploadId + "/?succinct=true";
            const oSettings = {
                "url": sUrl,
                "method": "GET",
                // "async": false
            };
            const oThisController = that;

            $.ajax(oSettings)
                .done(function (results) {
                    if(!oThisController.getView().getModel().getProperty("/attachmentUrls")){
                        const aUploadedUrlObj = results.objects;
                        if (aUploadedUrlObj.length) {
                            oThisController.getView().getModel().setProperty("/attachmentUrls", []);
                            aUploadedUrlObj.forEach(function (obj) {
                                // //form uploaded attachment url
                                // const objectId = obj.object.succinctProperties["cmis:objectId"];
                                // const sFileName = obj.object.succinctProperties["cmis:name"];
                                // //change required
                                // const sRootUrl = "https://sapit-presales-test.cockpit.workflowmanagement.cfapps.eu10.hana.ondemand.com";
                                // const sQuery = `?objectId=${objectId}&cmisselector=content`;
                                // const oUrl = {
                                //     "urlName": sFileName,
                                //     "url": `${sRootUrl}${oThisController.sDocServiceUrl}/WorkflowManagement/HarmonyPresalesRequests/${oThisController.workflowFileUploadId}${sQuery}`,
                                //     "urlDelete": true,
                                //     "urlNameValueState": "None",
                                //     "urlValueStateText": "",
                                //     "urlValueState": "None"
                                // }
                                // oThisController.getView().getModel().getProperty("/attachmentUrls").push(oUrl);
                                // oThisController.getView().getModel().setProperty("/isAttachmentUrl", true);
                
                            });
                        }
                    }
                    oThisController.getView().getModel().refresh()
                    oThisController._mapAttachmentsModel(results);
                })
                .fail(function (err) {
                    if (err !== undefined) {
                        // const oErrorResponse = $.parseJSON(err.responseText);
                        // MessageToast.show(oErrorResponse.message, {
                        //     duration: 6000
                        // });
                    } else {
                       // MessageToast.show("Unknown error!");
                    }
                });
        },

        // assign data to attachments model
        _mapAttachmentsModel: function (data) {
            data.downloadEnabled = data && data.objects && data.objects.length > 0;
            this.oAttachmentsModel.setData(data);
            this.oAttachmentsModel.refresh();
            this.getView().setBusy(false);
        },

        onDownloadAll: function (oEvent) {
            let uploadCollection = this.byId("UploadCollection");
            for (let i = 0; i < uploadCollection.getItems().length; i++) {
                uploadCollection.downloadItem(uploadCollection.getItems()[i], true);
            }
        },
        // formatting functions
        formatTimestampToDate: function (timestamp) {
            const oFormat = DateFormat.getDateTimeInstance();
            return oFormat.format(new Date(timestamp));
        },
        formatFileLength: function (fileSizeInBytes) {
            let i = -1;
            let byteUnits = [' kB', ' MB', ' GB', ' TB', 'PB', 'EB', 'ZB', 'YB'];
            do {
                fileSizeInBytes = fileSizeInBytes / 1024;
                i++;
            } while (fileSizeInBytes > 1024);
            return Math.max(fileSizeInBytes, 0.1).toFixed(1) + byteUnits[i];
        },
        formatDownloadUrl: function (objectId) {
            const docServieBaseUrl = this._getDocServiceRuntimeBaseURL();
            return docServieBaseUrl + "/WorkflowManagement/HarmonyPresalesRequests/"
                + workflowInstanceId + "?objectId=" + objectId + "&cmisselector=content";
        },
        _getWorkflowRuntimeBaseURL: function () {
            return this._getRuntimeBaseURL() + "/workflowruntime/";
        },
        _getDocServiceRuntimeBaseURL: function () {
            return this._getRuntimeBaseURL() + "/docservice";
        },
        _getRequestAreaBaseURL: function (sorgIDPc) {
            let sOrgID = 'ParentOrgID' in this.getView().getModel().getData() ? this.getView().getModel().getProperty("/ParentOrgID") : this.getView().getModel().getProperty("/OrgID");
            if (this.getView().getModel().getProperty("/OrgType") === 'SORG') {
                sOrgID = Number(sOrgID.replace('SORG-', '')).toString();
            }
            let sFinalOrgId;
            if (sorgIDPc) {
                sFinalOrgId = sorgIDPc
            } else {
                sFinalOrgId = sOrgID
            }
            return this._getRuntimeBaseURL() + "/cap/req-area-api-/Public_ReqArea?$filter=orgID eq '" + sFinalOrgId + "'";
        },
        _getConstantsBaseURL: function () {
            return this._getRuntimeBaseURL() + "/cap/req-area-api-/Parameter";
        },
        _getWFRoutingBaseURL: function () {
            let sOrgID = 'ParentOrgID' in this.getView().getModel().getData() ? this.getView().getModel().getData().ParentOrgID : this.getView().getModel().getData().OrgID;
            var sEngagementType=this.getView().getModel().getData().EngagementType
            if (this.getView().getModel().getProperty("/OrgType") === 'SORG') {
                sOrgID = Number(sOrgID.replace('SORG-', '')).toString();
            }
            return this._getRuntimeBaseURL() + "/cap/resources/WF_Routing?$filter=eng_Type_ID eq '"+sEngagementType+"' and orgID eq '" + sOrgID + "' and routing eq 'AUTO_STAFFING_ENABLE' and operationalStatus eq 'X'";
        },
         //Change Request to IO Staffing Working for EMEA #93 start
         //base url for skipIo service
        _getWFRoutingSkipIOBaseURL: function () {
            let sOrgID = 'ParentOrgID' in this.getView().getModel().getData() ? this.getView().getModel().getData().ParentOrgID : this.getView().getModel().getData().OrgID;
            var sEngagementType=this.getView().getModel().getData().EngagementType
            if (this.getView().getModel().getProperty("/OrgType") === 'SORG') {
                sOrgID = Number(sOrgID.replace('SORG-', '')).toString();
            }
            return this._getRuntimeBaseURL() + "/cap/resources/WF_Routing?$filter=eng_Type_ID eq '"+sEngagementType+"' and orgID eq '" + sOrgID + "' and routing eq 'SKIP_IO_OWNER_WF' and operationalStatus eq 'X'";
        },
         //Change Request to IO Staffing Working for EMEA #93 end
        _getRejectionCodeBaseURL: function () {
            const sManagerORresource = this.getView().getModel().getProperty("/currentStepID") === "MANAPP" ? "4" : "5";
            let sOrgID = 'ParentOrgID' in this.getView().getModel().getData() ? this.getView().getModel().getProperty("/ParentOrgID") : this.getView().getModel().getProperty("/OrgID");
            if (this.getView().getModel().getProperty("/OrgType") === 'SORG') {
                sOrgID = Number(sOrgID.replace('SORG-', '')).toString();
            }
            return this._getRuntimeBaseURL() + "/cap/req-area-api-/Rejection_Codes?$filter=OrgID eq '" + sOrgID + "' and UserTask_ID eq '" + sManagerORresource + "'&$orderby=Rejection_Reason asc";
        },
        /*Start of code for Multiple resources */
        _initializeAssignments: function () {
            //initialize assignments model
            let oAssignments = {
                "assignments": []
            };
            const oModel = new JSONModel(oAssignments);
            this.getView().setModel(oModel, "assignmentsModel");
            var that = this;
            //initialize roles model
            //initialize resource model
            const oResourceModel = new JSONModel(this.getView().getModel().getData());
            const oCAModel = new JSONModel(this.getView().getModel().getData());
            this.getView().setModel(oCAModel, "CAModel");
            this.getView().setModel(oResourceModel, "resourceModel");
            if (this.getView().getModel("resourceModel").getData().RequestType == "Account") {
                this.getView().byId("idDealInfoTabBar").setVisible(false);
            } else {
                this.getView().byId("idDealInfoTabBar").setVisible(true);
            }
            const oBaseModel = this.getView().getModel();
              let aActivityFormLayout = [];
            if (this.getView().getModel().getProperty("/currentStepID") === "RESAPP") {
                 //Git 132 (Form template/standardization ) start
                //set resource assignment field for resource task
                const oContextAssignments = oBaseModel.getProperty("/AllAssignmentDetails") ? oBaseModel.getProperty("/AllAssignmentDetails") :
                    [{
                        "comments": oBaseModel.getProperty("/assignmentComments"),
                        "NominatedResources": oBaseModel.getProperty("/NominatedResources")
                    }];
                    //set assignment details
                     oBaseModel.setProperty("/AllAssignmentDetails",oContextAssignments)
                    oAssignments.assignments = CommonJS._setResourceAssignment(oContextAssignments,that);
                //Git 132 (Form template/standardization ) end
                const sLoggedInUserId = this.getOwnerComponent().getModel("userDetails").getProperty("/user_name");
                if (oAssignments.assignments.length) {
                    oAssignments.assignments = oAssignments.assignments.filter(innerArr => {
                        return innerArr.selectedNominees.some(element => element.userId === sLoggedInUserId); // Use .some() to check if any element in innerArr meets the condition
                    });
                }
                //Call activity temp data service to get activity details from Processor task
                Models._callActivityTempDataService(this, false, "GET");
                const aAssignmentData = this.getView().getModel("assignmentsModel").getData().assignments,
                    aActivities = this.getView().getModel("activityTempModel").getData().value;
                    aActivities.sort((a, b) => a.ActivityTypeDescription.localeCompare(b.ActivityTypeDescription));
                if (aActivities.length) {
                    for (let i = 0; i < aAssignmentData.length; i++) {
                        if (aAssignmentData[i].enableActivityRegister) {
                            let aContextActivity = aActivities.filter(item => item.AssignmentID.toString() === aAssignmentData[i].AssignmentID.toString()),
                                aUpdatedActivities = [];
                            let aActivityList =  aAssignmentData[i].activityLists &&  aAssignmentData[i].activityLists.length ? aAssignmentData[i].activityLists:[];
                            //set the obj for activity
                            aContextActivity.forEach(function (item,iIndex) {
                              const oUpdatedActivity = {
                                    "activityPaylod": item,
                                    "assignmentID": item.AssignmentID,
                                    "activity_GUID": item.ActivityGuid,
                                    "instanceID": item.Instance_Guid,
                                    "ActivityTypeInfo":aActivityList.length && aActivityList.filter(act=>act.ActivityDesc === item.ActivityTypeDescription).length ?  aActivityList.filter(act=>act.ActivityDesc === item.ActivityTypeDescription)[0].ActivityTypeInfo :"",
                                    "resourceList": aAssignmentData[i].resourceList,
                                }
                                //set visibility for activity fields
                                oUpdatedActivity.to_ALandVisible = oUpdatedActivity.activityPaylod.to_ALand && oUpdatedActivity.activityPaylod.to_ALand.length ? true : false;
                                oUpdatedActivity.to_AAddOppVisible = oUpdatedActivity.activityPaylod.to_AAddOpp && oUpdatedActivity.activityPaylod.to_AAddOpp.length ? true : false;
                                oUpdatedActivity.to_AInitiativeVisible = oUpdatedActivity.activityPaylod.to_AInitiative && oUpdatedActivity.activityPaylod.to_AInitiative.length ? true : false;
                                oUpdatedActivity.to_AFilesVisible = oUpdatedActivity.activityPaylod.to_AFiles && oUpdatedActivity.activityPaylod.to_AFiles.length ? true : false,
                                oUpdatedActivity.to_ATaxonomyVisible = oUpdatedActivity.activityPaylod.to_ATaxonomy && oUpdatedActivity.activityPaylod.to_ATaxonomy.length ? true : false,
                                oUpdatedActivity.to_AMaterialVisible = oUpdatedActivity.activityPaylod.to_AMaterial && oUpdatedActivity.activityPaylod.to_AMaterial.length ? true : false;
                                oUpdatedActivity.bIsExpanded = (iIndex === 0) ? true:false;
                                aUpdatedActivities.push(oUpdatedActivity);
                                if(oUpdatedActivity.activityPaylod.ChildFrmLayoutId){
                                    //push activity display form layout
                                    aActivityFormLayout.push(oUpdatedActivity.activityPaylod.ChildFrmLayoutId);
                                }
                                const aSolns = JSON.parse(JSON.stringify(oUpdatedActivity.activityPaylod.to_ATaxonomy));
                                //format solutions
                                aSolns.forEach(function(item){
                                    switch ( item.L5Desc || item.L4Desc || item.L3Desc || item.L2Desc ) {
                                        case item.L5Desc:
                                            item.SolutionDesc = item.L5Desc
                                            break;
                                        case item.L4Desc:
                                            item.SolutionDesc = item.L4Desc
                                            break;
                                        case item.L3Desc:
                                            item.SolutionDesc = item.L3Desc
                                            break;
                                        case item.L2Desc:
                                            item.SolutionDesc = item.L2Desc
                                            break;
                                        default:
                                        item.SolutionDesc = ""
                                    }
                                })
                                const aMateriaData =    JSON.parse(JSON.stringify(oUpdatedActivity.activityPaylod.to_AMaterial));
                                //map all the materials
                                aMateriaData.forEach(item => {
                                    item.SolutionDesc = item.MatDesc;
                                });
                                //join solutionarea and material description
                                oUpdatedActivity.solnMaterialData = aSolns.concat(aMateriaData);

                                //processor list
                                const aActTeamMember = oUpdatedActivity.activityPaylod.to_ATeam,
                                    aProcessorList = aActTeamMember.map(({
                                        NAME: fullName,
                                        EMAIL: email,
                                        ...rest
                                    }) => ({
                                        fullName, email,
                                        ...rest
                                    }));

                                aProcessorList.length ? aProcessorList[0].bIsTitle = true : false;
                                //sort processor list
                                CommonJS._empSort(aProcessorList, "fullName");
                                let aProcessorShortList = [],
                                    aProcessorMoreList = [],
                                    sMoreProcessorText;
                                if (aProcessorList.length > 2) {
                                    const iProcessorMoreCount = (aProcessorList.length - 2).toString(),
                                        si18nMoreText = that.getOwnerComponent().getModel("i18n").getResourceBundle().getText("more");
                                    sMoreProcessorText = `(${iProcessorMoreCount} ${si18nMoreText})`;
                                    aProcessorShortList = aProcessorList.slice(0, 2); // visible approver list ( max 2 processors)
                                    aProcessorMoreList = aProcessorList.slice(2);// array point to link to show more processors	
                                } else {
                                    aProcessorShortList = aProcessorList;
                                }
                                //set object for request header model
                                oUpdatedActivity.actTeamList = {
                                    processorShortList: aProcessorShortList,
                                    processorMoreList: aProcessorMoreList,
                                    moreProcessorText: sMoreProcessorText,
                                    processorDisplayList: sMoreProcessorText ? aProcessorShortList.concat([{
                                        ID: "idMoreText",
                                        fullName: sMoreProcessorText
                                    }]) : aProcessorShortList
                                }
                                oUpdatedActivity.actTeamList.currentScope = that;
                            });

                            aAssignmentData[i].activities = aUpdatedActivities;
                        }
                    }
                }
            } 
            this.getView().getModel("assignmentsModel").refresh(true);
              if (aActivityFormLayout.length) {
                // Build filter array
                let aFilters = aActivityFormLayout.map(function (sValue) {
                    return new sap.ui.model.Filter("FormLayoutID", sap.ui.model.FilterOperator.EQ, sValue);
                });
                //call layout service for the activity form configuration
                 this.fnGetLayoutData(aFilters,this,true);
            }
        },
          /**
         * Git #230 Activity integration start
         * Set End date as Start date + 6Days
         * @param {number} days - days after start date => 6
         * @function _getDateAfterXdays
         */
        _getDateAfterXdays: function (days) {
            function addDays(date, days) {
                const newDate = new Date(date);
                newDate.setDate(date.getDate() + days);
                return newDate;
            }

            // Get the current date
            const todayDate = new Date();
            // Function call to add days
            return addDays(todayDate, days);
        },
        _fetchRoleDetails: function () {
            return this._getRuntimeBaseURL() + "/cap/req-area-api-/Presales_role";
        },
        //IO staffing switch event trigger
        onIOstaffingToggle: function (oBindingContextObj) {
            //reset assignment fields
            oBindingContextObj.staffingDateRange = "";
            oBindingContextObj.staffingPurpose = "";
            oBindingContextObj.maxNoOfDaysToBookIO = "";
            oBindingContextObj.selectedInternalOrder = "";
            this._setSelectedIOowner(oBindingContextObj);
            oBindingContextObj.staffingPurposeKey = "Sel";

            oBindingContextObj.taskLevelVal = "NONE-None";

            oBindingContextObj.selectedRole = "";
            oBindingContextObj.selectedInternalOrder = "";
            oBindingContextObj.selectedNominees = [];

            oBindingContextObj.staffingPurposeVisible = false;
            oBindingContextObj.ioOwnerFieldVisible = false;
            oBindingContextObj.ioOwnerTextFieldVisible = false;
            oBindingContextObj.staffingDateRangeVisible = false;
            oBindingContextObj.maxNoOfDaysToBookIOVisible = false;
            oBindingContextObj.taskLevelVisible = false;
            oBindingContextObj.taskLevelEnable = false;
            oBindingContextObj.resourceValueState = "None";
            oBindingContextObj.staffingPurposeValueState = "None";
            oBindingContextObj.dateRangeValueState = "None";
            oBindingContextObj.daysToBooksValueState = "None"
            oBindingContextObj.internalOrderSelectValueState = "None";
            oBindingContextObj.ioOwnerValueState = "None";
            oBindingContextObj.roleValueState = "None";
            oBindingContextObj.isIOStaffing = true,
            oBindingContextObj.staffingPurposeKey = "A";
            oBindingContextObj.taskLevelKey = "NONE";
            oBindingContextObj.staffingPurpose = "Activities";
            oBindingContextObj.expectedTimeInvstementVisible = false;

         
            // //Staffing ON
            oBindingContextObj.internalOrderFormVisible = true;
            this.getView().getModel("assignmentsModel").refresh();
        },
        //add new assignment
        onAddNewAssignment: function () {
            const oModelData = this.getView().getModel("assignmentsModel").getData().assignments;
            let allNominees = oModelData.flatMap(obj => obj.selectedNominees);

 let uniqueNominees = Array.from(
    new Map(allNominees.map(item => [item.userId, item])).values()
);
            const oInternalOrderModel = this.getView().getModel("internalOrderModel");
            const oAssignments = {
                "minDate": new Date(),
                "isIOStaffing": false,
                "selectedRole": "",
                "selectedInternalOrder": "",
                "roleValueState": "None",
                "roleValueStateText": `${this.i18nModel.getText("roleValueStateText")}`,
                "resourceValueState": "None",
                "resourceValueStateText": this.getView().getModel().getProperty("/Skip_Resource_Approver") ? `${this.i18nModel.getText("selectResource")}` : `${this.i18nModel.getText("selectResourceNominee")}`,
                "selectedNominees": [],
                "selectedTimeInvestment": 0,
                "selectedIOOwner": [],
                "staffingPurpose": "",
                "staffingPurposeVisible": false,
                "expectedTimeInvstementVisible": true,
                "staffingPurposeValueState": "None",
                "staffingPurposeValueStateText": `${this.i18nModel.getText("staffingPurposeValueStateText")}`,
                "staffingDateRange": "",
                "staffingDateRangeVisible": false,
                "dateRangeValueStateText": `${this.i18nModel.getText("dateRangeValueStateText")}`,
                "dateRangeValueState": "None",
                "maxNoOfDaysToBookIO": "",
                "maxNoOfDaysToBookIOVisible": false,
                "daysToBooksValueStateText": `${this.i18nModel.getText("dateRangeValueStateText")}`,
                "daysToBooksValueState": "None",
                "internalOrder": oInternalOrderModel.getData().length > 1 ? oInternalOrderModel.getData()[0] : this.getView().getModel().getProperty("/internalOrder"),
                "internalOrderSelectValueState": "None",
                "internalOrderSelectValueStateText": `${this.i18nModel.getText("internalOrderSelectValueStateText")}`,
                "internalOrderFormVisible": false,
                "ioOwnerValueState": "None",
                "resCommentValueState":"None",
                "ioOwnerFieldVisible": false,
                "ioOwnerTextFieldVisible": false,
                "ioOwnerValueStateText": `${this.i18nModel.getText("ioOwnerValueStateText")}`,
                "staffingPurposeVal": "",
                "taskLevelKey": "",
                "taskLevelVal": "",
                "taskLevelVisible": false,
                "taskLevelValueStateText": `${this.i18nModel.getText("taskLevelValueStateText")}`,
                "taskLevelValueState": "None",
                "comments":"",
                "taskLevelEnable": true,
                //Change Request to IO Staffing Working for EMEA #93 start ---> staffing warning message properties
                "staffingMsg":this.getOwnerComponent().getModel("appConstants").getProperty("/ManualStaffing/0/Value"),
                "staffingMsgVisible":false,
                "staffingMsgUrl":this.getOwnerComponent().getModel("appConstants").getProperty("/ManualStaffingURL/0/Value"),
                "StaffingMsgUrlText":this.getOwnerComponent().getModel("appConstants").getProperty("/ManualStaffingHyperlinkText/0/Value"),
                "staffingUrlVisible":this.getOwnerComponent().getModel("appConstants").getProperty("/ManualStaffingHyperlinkText/0/Operational_Status"),
                "PreviousSelectedNominees": uniqueNominees,
                 //Change Request to IO Staffing Working for EMEA #93 end
                 "activities": [{
                        "selectedActivity": "",
                        "activityPaylod": {},
                        "actValueState":"None",
                        "enableRegEdit":false,
                        "activityDelete":false,
                    }
                    ],
                    "actvityVisible": false,
                    "RoleFieldVisible":false

            }
            oModelData.push(oAssignments);
            for (let i = 0; i < oModelData.length; i++) {
                oModelData[i].AssignmentID = i + 1;
            }
            if (oModelData.length === 1) {
                oAssignments.assignmentDelete = false;
            } else {
                oModelData.forEach(function (val) {
                    val.assignmentDelete = true;
                });
            }
            //set IO owner
            this._setSelectedIOowner(oAssignments);
            this.getView().getModel("assignmentsModel").refresh();
            if (this.getView().getModel().getProperty("/RequestType") === "Opportunity" && this.getView().getModel("WFRoutingAPIData").getProperty("/value/0/operationalStatus") && this.getView().getModel("internalOrderModel").getData().length) {
                this.onIOstaffingToggle(oAssignments);
            }
              const oAppConfigModel = this.getOwnerComponent().getModel("mrrAppConfigModel").getData();
                oAppConfigModel.ActivityType_InfoBubble = [{
                    "fieldDesc": ""
                }];
                this.getOwnerComponent().getModel("mrrAppConfigModel").refresh();
        },
        _setSelectedIOowner: function (oAssignments) {
            const ioOwnerModel = this.getView().getModel("ioOwnerDetails");
            //set opportunity owner as IO owner
            let iOownerDetails;
            if (ioOwnerModel.getData().length) {
                iOownerDetails = {
                    "IOOwnerName": `${ioOwnerModel.getProperty("/0/firstName")} ${ioOwnerModel.getProperty("/0/lastName")}`,
                    "IOOwnerEmail": ioOwnerModel.getProperty("/0/email"),
                    "IOOwnerUserId": ioOwnerModel.getProperty("/0/ID")
                }
            } else {
                const oModel = this.getView().getModel();
                //set opportunity owner as IO owner
                iOownerDetails = {
                    "IOOwnerName": oModel.getProperty("/oppOwnerDetails").fullName,
                    "IOOwnerEmail": oModel.getProperty("/oppOwnerDetails").email,
                    "IOOwnerUserId": oModel.getProperty("/oppOwnerDetails").id
                }
            }
            oAssignments.isOppOwnerActive = true;
            //Enable forward functionality
            oAssignments.isForward = true;
            //Final selected IO Owner context
            oAssignments.selectedIOOwner = [{ "IOOwnerDetails": iOownerDetails }];
        },
        /**
      *Git 313
      * open profit center filter dialog
      * set profit center master data
      * @function onOpenFilterProfitCenterFilterDialog
      */
        onOpenFilterProfitCenterFilterDialog: function () {
            let that = this;
            if (!this.pProfitCenterValueHelpDialog) {
                this.pProfitCenterValueHelpDialog = this.loadFragment({
                    name: "com.dealsupport.melodyrequest.fragments.filter.profitCenterMasterData"
                });
            }
            this.pProfitCenterValueHelpDialog.then(function (oDialog) {
                that.getView().getModel("employee").setProperty("/sSearchBoxText", "");
                let aSelectedProfitCenter = that.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories");
                that.getView().getModel("selectedProfitCenter").setProperty("/TempProfitCenter/TempTreeTerritories", aSelectedProfitCenter);
                that.getView().getModel("selectedProfitCenter").refresh();
                that.getView().setModel(new sap.ui.model.json.JSONModel(), "masterDataModel");
                const oMasterDataModel = that.getView().getModel("masterDataModel");
                oMasterDataModel.setProperty("/TempProfitCenter", JSON.parse(JSON.stringify(that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter)));
                that.getView().getModel("masterDataModel").refresh();
                that.filterTerritories();
                aSelectedProfitCenter && aSelectedProfitCenter.length ?
                    that.getView().getModel("employee").setProperty("/filter/dialogselProfitCenterVisible", true) : that.getView().getModel("employee").setProperty("/filter/dialogselProfitCenterVisible", false);
                oDialog.open();
            });
        },
        //Open Nominee dialog (nominee user name and mail info)
        onNomineeSelectDialogOpen: function (evt) {
            this.oContextAssignmentObj = evt.getSource().getBindingContext("assignmentsModel").getObject();
            this.oNomineeValueHelpControl = evt.getSource();
            const that = this
            const oResourceModel = this.getView().getModel("resourceModel");
            if (!oResourceModel.getData().availableResources) {
                oResourceModel.getData().availableResources = this.getView().getModel().getData().availableResources;
            }
            oResourceModel.refresh(true);

            if (this.getView().getModel().getData().isResourceProfile) {
                this._onOpenOREResourceDialog(evt);
            } else {
                if (!this.pNomineeSelectDialog) {
                    this.pNomineeSelectDialog = this.loadFragment({
                        name: "com.dealsupport.melodyrequest.fragments.managerPage.nomineeSelectDialog"
                    });
                }

                this.pNomineeSelectDialog.then(function (oNomineeSelectDialog) {
                    oNomineeSelectDialog.addStyleClass(that.getOwnerComponent().getContentDensityClass());
                    if (this._bNomineeSelectInitialized) {
                        oNomineeSelectDialog.open();
                        return;
                    }

                    oNomineeSelectDialog.open();
                    const oAssignmentData = this.getView().getModel("assignmentsModel").getData().assignments;
                    const oSelectedResources = [];
                    oAssignmentData.forEach(function (assignment) {
                        assignment.selectedNominees.forEach(function (nominee) {
                            oSelectedResources.push(nominee);
                        });
                    });
                    const oStandardList = oNomineeSelectDialog.getItems();
                    oStandardList.forEach(function (oControl) {
                        oControl.setBlocked(false);
                    });
                    let aAvailableResources = oResourceModel.getProperty("/availableResources");
                    aAvailableResources.forEach(function (resource) {
                        resource.selected = false;
                    });

                    oAssignmentData.forEach(function (assignment) {
                        assignment.selectedNominees.forEach(function (nominee) {
                            aAvailableResources.forEach(function (resource) {
                                if (resource.fullName === nominee.fullName && resource.email === nominee.email) {
                                    resource.selected = true;
                                }
                            });
                        });
                    });

                    oSelectedResources.forEach(function (resource) {
                        oStandardList.forEach(function (oListItem) {
                            const oBindingContextObj = oListItem.getBindingContext("resourceModel").getObject();
                            if (resource.fullName === oBindingContextObj.fullName &&
                                resource.email === oBindingContextObj.email) {
                                oListItem.setBlocked(true);
                                resource.selected = false;
                            }
                        });
                    });
                    this.oContextAssignmentObj.selectedNominees.forEach(function (resource) {
                        oStandardList.forEach(function (oListItem) {
                            const oBindingContextObj = oListItem.getBindingContext("resourceModel").getObject();
                            if (resource.fullName === oBindingContextObj.fullName &&
                                resource.email === oBindingContextObj.email) {
                                oListItem.setBlocked(false);
                                resource.selected = true;
                            }
                        });
                    });

                    CommonJS._empSort(aAvailableResources,"fullName");
                    oResourceModel.setProperty("/availableResources", aAvailableResources);
                }.bind(this));
            }
        },
        //open IO Owner select dialog
        onIOOwnerDialogOpen: function (evt) {
            this.oContextAssignmentIOOwnerObj = evt.getSource().getBindingContext("assignmentsModel").getObject();
            const oIoOwnerData = new JSONModel([]);
            this.getView().setModel(oIoOwnerData, "ioOwnerModel");

            if (!this.pIOOwnerSelectDialog) {
                this.pIOOwnerSelectDialog = this.loadFragment({
                    name: "com.dealsupport.melodyrequest.fragments.managerPage.IOOwneSelectDialog"
                });
            }
            this.pIOOwnerSelectDialog.then(function (oIOOwnerSelectDialog) {
                oIOOwnerSelectDialog._searchField.setPlaceholder("Search IO Owner");
                if (this._bNomineeSelectInitialized) {
                    oIOOwnerSelectDialog.open();
                    return;
                }
                oIOOwnerSelectDialog.open();
            }.bind(this));

        },
        //resource select event
        onSelectResource: function (evt) {
            this.oNomineeValueHelpControl.setBusy(true);
            let aToken = evt.getParameter("selectedContexts").map(function (oContext) {
                return oContext.getObject();
            })
            this._onSelectResources(aToken);
        },
        onSelectIOOwner: function (evt) {
            const oAssignmentsModel = this.getView().getModel("assignmentsModel");
            let aToken = evt.getParameter("selectedContexts").map(function (oContext) {
                oContext.getObject().IOOwnerDetails = {
                    "IOOwnerName": `${oContext.getObject().firstName} ${oContext.getObject().lastName}`,
                    "IOOwnerEmail": oContext.getObject().email,
                    "IOOwnerUserId": oContext.getObject().ID,
                }
                return oContext.getObject();
            })

            this.oContextAssignmentIOOwnerObj.selectedIOOwner = aToken;
            this.getView().getModel("assignmentsModel").refresh();

            this._fnIOOwnerValidation(aToken, this.oContextAssignmentIOOwnerObj);
            oAssignmentsModel.refresh(true);
        },
        fnSuccessISPCall: function (response, self) {
            let isAutoStaffing = response.d.Zflag;
            const sMessage = response.d.Zmsg
            if (sMessage === "Record exists in ZSOL_CC") {
                self.isAutoStaffing = true;
            }
            self.isAutoStaffing = isAutoStaffing;
        },
        //resouce select validation
        _fnIOOwnerValidation: function (aToken, oContextAssignment) {
            if (aToken.length) {
                oContextAssignment.ioOwnerValueState = "None";
            } else {
                oContextAssignment.ioOwnerValueState = "Error";
            }
            this.getView().getModel("assignmentsModel").refresh();

        },
        onPresalesDialogClose: function (oEvent) {
            oEvent.getSource().getBinding("items").filter([]);
            const aResources = this.getView().getModel("resourceModel").getData().availableResources;
            aResources.forEach(function (resource) {
                resource.selected = false;
            });

        },

        //resouce select validation
        _fnResourceValidation: function (aToken, oContextAssignment) {
            if (aToken.length) {
                oContextAssignment.resourceValueState = "None";
            } else {
                oContextAssignment.resourceValueState = "Error";
            }
            this.getView().getModel("assignmentsModel").refresh();
            if (this.getView().getModel().getData().ResReject !== true) {
                // this._onValidateAssignment();
            }
        },
        //remove resource token event
        onResourceUpdate: function (evt) {
            const aRemovedToken = evt.getParameter("removedTokens");
            const oAssignments = evt.getSource().getBindingContext("assignmentsModel").getObject();
            let oRemovedObj;
            if (aRemovedToken.length) {
                oRemovedObj = {
                    "fullName": aRemovedToken[0].getText(),
                    "email": aRemovedToken[0].getKey(),
                    "selected": false
                }
                evt.getSource().getBindingContext("assignmentsModel").getObject().activities = [];
                evt.getSource().getBindingContext("assignmentsModel").getObject().actvityVisible = false;
                evt.getSource().getBindingContext("assignmentsModel").getObject().RoleFieldVisible = false;
                evt.getSource().getModel("assignmentsModel").refresh();
            }
            //update selection for resource selection
            const aSelectedNominee = oAssignments.selectedNominees;
            aSelectedNominee.forEach(function (nom, index, object) {
                if (nom.fullName === oRemovedObj.fullName && nom.email === oRemovedObj.email) {
                    aSelectedNominee.splice(index, 1);
                    return;
                }
            });
            if (oAssignments.isIOStaffing) {
                this._checkResourceAutoStaffing(aSelectedNominee, oAssignments);
            }
            this._fnResourceValidation(aSelectedNominee, oAssignments);
        },
        _checkResourceAutoStaffing: function (aSelectedNominee, oAssignments) {
            //check autostaffing based on resource updates
            let bIsAutoStaffing = aSelectedNominee.every(val => val.isAutoStaffing === true);
            //Change Request to IO Staffing Working for EMEA #93 start
            //check company code eq to sales org for all the resources and auto staffing
            let bCompanySalesOrgNoMatch = aSelectedNominee.every(val => !val.isStaffing);
            let bSkipIOFlag = this.getView().getModel("WFRoutingSkipIOAPIData").getProperty("/value/0/operationalStatus");
            if ((bSkipIOFlag && !bIsAutoStaffing && !bCompanySalesOrgNoMatch) || (!bSkipIOFlag &&!bIsAutoStaffing )) {
                //company code not eq to salesOrg for all the resources
                //not autostaffed - show staffing fields
                oAssignments.staffingPurposeVisible = true;
                oAssignments.ioOwnerFieldVisible = oAssignments.isOppOwnerActive;
                oAssignments.ioOwnerTextFieldVisible = true;
                oAssignments.staffingDateRangeVisible = true;
                oAssignments.maxNoOfDaysToBookIOVisible = true;
                oAssignments.taskLevelVisible = true;
                oAssignments.expectedTimeInvstementVisible = false;
                oAssignments.staffingMsgVisible = false;
            } else{
                 //company code eq to salesOrg for atleast one resource
                //auto staffed - hide staffing fields
                oAssignments.staffingPurposeVisible = false;
                oAssignments.ioOwnerFieldVisible = false;
                oAssignments.ioOwnerTextFieldVisible = false;
                oAssignments.staffingDateRangeVisible = false;
                oAssignments.maxNoOfDaysToBookIOVisible = false;
                oAssignments.taskLevelVisible = false;
                oAssignments.expectedTimeInvstementVisible = true;
                if(!bIsAutoStaffing && aSelectedNominee.length){
                    //set warning message
                    this._setStaffingMsg(aSelectedNominee,oAssignments);
                }
             
            }

            if (!aSelectedNominee.length) {
                oAssignments.expectedTimeInvstementVisible = false;
                oAssignments.staffingMsgVisible = false;
            }

            this.getView().getModel("assignmentsModel").refresh(true);
        },
        onIOOwnerUpdate: function (evt) {
            const oAssignments = evt.getSource().getBindingContext("assignmentsModel").getObject();
            //update selection for resource selection
            const aSelectedIOOwner = [];
            this._fnIOOwnerValidation(aSelectedIOOwner, oAssignments);
        },
        onApprove: function () {
            //final approve action
            const oFinalPayload = this._fnConfigAssignmentsPayload();
            const oModel = this.getView().getModel();
            oModel.refresh(true);
            this.oAssignments = oFinalPayload.Assignment;
             const oAssignmentsData = this.getView().getModel("assignmentsModel").getProperty("/assignments"),
                    bIsNoActivityRegister = oAssignmentsData.every(val => !val.enableActivityRegister);
            if (this.getView().getModel().getProperty("/Skip_Resource_Approver")) {
                // if (bIsNoActivityRegister) {
                //     //If activity register disable based on activity type..then directly submit the request
                //     // this._triggerComplete(this.oAssignments, this.sUserTaskId,
                //     //     "Approve");
                //       this._onOpenActivityBusyDialog(this, this.oAssignments, this.sUserTaskId, "Approve",true);
                // } else {
                //     //Register activity then submit the request
                //     this._onOpenActivityBusyDialog(this, this.oAssignments, this.sUserTaskId, "Approve");
                // }
                  this._onOpenActivityBusyDialog(this, this.oAssignments, this.sUserTaskId, "Approve",bIsNoActivityRegister);

            } else {
                //if skip resource disable then strore activity in activity temp table
                // this._fnStoreActivityTemp(this);
                if (bIsNoActivityRegister) {
                    //If activity register disable based on activity type..then directly submit the request
                    this._triggerComplete(this.oAssignments, this.sUserTaskId,
                        "Approve");
                }else{
                      this._fnMapActivityPayload(this);
                }
              
            }
        },
        _fnConfigAssignmentsPayload: function () {
            //set payload for context
            const oAssignmentsModel = this.getView().getModel("assignmentsModel");
            const aAssignmentsData = oAssignmentsModel.getData().assignments;
            const aAssignmentPayload = [];
         
            aAssignmentsData.forEach(function (assignment, index) {
                let sAssignmentId = index + 1;
                let oAssignmentPayloadObj = {};
                let aFinalNominee = [];
                let aNominee = assignment.selectedNominees;
                aNominee.forEach(function (nom) {
                    delete nom.selected;
                    nom.isIOStaffing = assignment.isIOStaffing;
                    nom.staffingPurpose = assignment.staffingPurpose;
                    nom.staffingPurposeKey = assignment.staffingPurposeKey;
                    nom.AssignmentID =sAssignmentId;
                    nom.taskLevelKey = assignment.taskLevelKey;
                    nom.taskLevelEnable = assignment.taskLevelEnable;
                    nom.taskLevelVal = assignment.taskLevelVal;
                    nom.staffingDateRange = assignment.staffingDateRange;
                    nom.dateValue = assignment.dateValue;
                    nom.secondDateValue = assignment.secondDateValue;
                    nom.maxNoOfDaysToBookIO = assignment.maxNoOfDaysToBookIO;
                    nom.isForward = assignment.isForward;
                    nom.internalOrder = assignment.internalOrder ? assignment.internalOrder : assignment.selectedInternalOrder;

                    if (assignment.selectedIOOwner) {
                        nom.ioOwnerDetails = assignment.selectedIOOwner.length ? assignment.selectedIOOwner[0].IOOwnerDetails : "";
                    }

                    aFinalNominee.push(nom)

                });
                const selectedTimeInvestment = (assignment.selectedTimeInvestment === 0) ? "" :
                    assignment.selectedTimeInvestment;
                oAssignmentPayloadObj.TimeInvestment = selectedTimeInvestment.toString();
                oAssignmentPayloadObj.AssignmentID = sAssignmentId.toString();
                oAssignmentPayloadObj.NominatedResources = aNominee;
                oAssignmentPayloadObj.isIOStaffing = assignment.isIOStaffing;
                oAssignmentPayloadObj.internalOrderFormVisible = assignment.internalOrderFormVisible;
                oAssignmentPayloadObj.ioOwnerFieldVisible = assignment.ioOwnerFieldVisible;
                oAssignmentPayloadObj.ioOwnerTextFieldVisible = assignment.ioOwnerTextFieldVisible;
                oAssignmentPayloadObj.staffingPurposeVisible = assignment.staffingPurposeVisible;
                oAssignmentPayloadObj.expectedTimeInvstementVisible = assignment.expectedTimeInvstementVisible;
                oAssignmentPayloadObj.taskLevelVisible = assignment.taskLevelVisible;
                oAssignmentPayloadObj.staffingDateRangeVisible = assignment.staffingDateRangeVisible;
                oAssignmentPayloadObj.maxNoOfDaysToBookIOVisible = assignment.maxNoOfDaysToBookIOVisible;
                oAssignmentPayloadObj.taskLevelEnable = assignment.taskLevelEnable;
                if (assignment.enableActivityRegister) {
                      assignment.activities = assignment.activities.filter(item=>Object.values(item.activityPaylod).length > 3)
                     assignment.enableActivityRegister =  assignment.activities.length ? true:false;
                    //set activity assignment
                    oAssignmentPayloadObj.activityLists = assignment.activities.map(activity => ({
                        ActivityGuid: activity.activityPaylod.ActivityGuid,
                        ActivityTypeInfo:activity.ActivityTypeInfo,
                        assignmentID: sAssignmentId.toString(),
                        ActivityDesc: activity.activityPaylod.ActivityTypeDescription,
                        ActivityID:""
                    }));
                } else {
                    oAssignmentPayloadObj.activityLists = [];
                }
                oAssignmentPayloadObj.enableActivityRegister = assignment.enableActivityRegister;
                if(oAssignmentPayloadObj.NominatedResources && oAssignmentPayloadObj.NominatedResources.length){
                    //update activity lists for very old requests
                    oAssignmentPayloadObj.NominatedResources[0].activityLists =  oAssignmentPayloadObj.activityLists;
                    oAssignmentPayloadObj.NominatedResources[0].enableActivityRegister = assignment.enableActivityRegister;
                }
 
                //set assignment comment
                oAssignmentPayloadObj.comments = assignment.comments ? assignment.comments.trim():"";
                //Change Request to IO Staffing Working for EMEA #93 start
                //set staffing msg payload
                oAssignmentPayloadObj.staffingMsgVisible =   oAssignmentPayloadObj.staffingMsgVisible ?   oAssignmentPayloadObj.staffingMsgVisible:false;
               // //Change Request to IO Staffing Working for EMEA #93 end
                oAssignmentPayloadObj.NominatedResources = aNominee;
                aAssignmentPayload.push(oAssignmentPayloadObj);

            });
            const oFinalPayload = {
                "Assignment": aAssignmentPayload
            };
            return oFinalPayload;
        },
        //delete assignment
        onDeleteAssignment: function (evt) {
            const oAssignmentObj = evt.getSource().getBindingContext("assignmentsModel").getObject();
            const oAssignmentsModel = this.getView().getModel("assignmentsModel");
            const filteredArray = oAssignmentsModel.getData().assignments.filter(e => e !== oAssignmentObj);
            if (filteredArray.length === 1) {
                filteredArray[0].assignmentDelete = false;
            } else {
                filteredArray.forEach(function (val) {
                    val.assignmentDelete = true;
                });
            }
            filteredArray.forEach(function (assignments, i) {
                assignments.AssignmentID = i + 1;
            })
            oAssignmentsModel.setProperty("/assignments", filteredArray);
            oAssignmentsModel.refresh(true);
        },
        //role selection change event
        onSelectRole: function (evt) {
            const sSelectedKey = evt.getParameter("value");
            const oAssignmentsModel = this.getView().getModel("assignmentsModel");
            const oSelectedObj = evt.getSource().getBindingContext("assignmentsModel").getObject();
            if (sSelectedKey) {
                oSelectedObj.roleValueState = "None";
            } else {
                oSelectedObj.roleValueState = "Error";
            }
            oAssignmentsModel.refresh(true);
            if (this.getView().getModel().getData().ResReject !== true) {
                //this._onValidateAssignment();
            }

        },
        //Task level change event
        onSelectTaskLevel: function (evt) {
            const sSelectedKey = evt.getParameter("selectedItem").getKey();
            const oAssignmentsModel = this.getView().getModel("assignmentsModel");
            const sSelectedText = evt.getParameter("selectedItem").getText();
            const oSelectedObj = evt.getParameter("selectedItem").getBindingContext("assignmentsModel").getObject();
            if (sSelectedKey !== "Sel") {
                oSelectedObj.taskLevelValueState = "None";
                oSelectedObj.taskLevelVal = sSelectedText;
                oSelectedObj.taskLevelKey = sSelectedKey
            } else {
                oSelectedObj.taskLevelValueState = "Error";

            }
            oAssignmentsModel.refresh(true);

        },
        //Staffing purpose change event
        onSelectStaffingPurpose: function (evt) {
            const sSelectedKey = evt.getParameter("selectedItem").getKey();
            const sSelectedText = evt.getParameter("selectedItem").getText();
            const oAssignmentsModel = this.getView().getModel("assignmentsModel");
            const oSelectedObj = evt.getParameter("selectedItem").getBindingContext("assignmentsModel").getObject();
            oSelectedObj.taskLevelEnable = true;
            oSelectedObj.taskLevelKey = "NONE";
            if (sSelectedKey !== "Sel") {
                oSelectedObj.staffingPurposeValueState = "None";
                oSelectedObj.taskLevelVisible = true;
                oSelectedObj.taskLevelEnable = sSelectedKey === "E" ? false : true;
                oSelectedObj.taskLevelVal = sSelectedKey === "E" ? "" : "NONE-None";
                oSelectedObj.taskLevelValueState = "None";
                oSelectedObj.staffingPurpose = sSelectedText;
                oSelectedObj.staffingPurposeKey = sSelectedKey;
            } else {
                oSelectedObj.staffingPurposeValueState = "Error";
                if (sSelectedKey === "Sel") {
                    oSelectedObj.taskLevelEnable = false;
                }
            }
            oAssignmentsModel.refresh(true);

        },
        //Date selection change event
        onStaffingDateRangeChange: function (evt) {
            const sDateVal = evt.getParameter("value");
            const oAssignmentsModel = this.getView().getModel("assignmentsModel");
            const oSelectedObj = evt.getSource().getBindingContext("assignmentsModel").getObject();
            if (sDateVal) {
                oSelectedObj.dateRangeValueState = "None";
            } else {
                oSelectedObj.dateRangeValueState = "Error";
            }
            oAssignmentsModel.refresh(true);

        },
        fetchPreSalesRoleData: function (self) {
            if (!self.getOwnerComponent().getModel("rolesModel").getData().value.length) {
                const sUrl = self._getRuntimeBaseURL() + "/cap/req-area-api-/Presales_role";
                $.ajax({
                    contentType: "application/json",
                    url: sUrl,
                    async: false,
                    type: "GET",
                    success: function (oData) {
                        let oRolesModel = new JSONModel(oData);
                        const sSalesOrg = 'ParentOrgID' in self.getView().getModel().getData() ? self.getView().getModel().getProperty("/ParentOrgID") : self.getView().getModel().getProperty("/OrgID");
                        const sOrgType = self.getView().getModel().getProperty("/OrgType");
                        const sFormatOrgID = self._getOrgIDnumber(sSalesOrg, sOrgType);
                        const result = oData.value.reduce(function (r, a) {
                            r[a.orgID] = r[a.orgID] || [];
                            r[a.orgID].push(a);
                            return r;
                        }, Object.create(null));
                        oRolesModel = result[sFormatOrgID];
                        oData.value = [];
                        oData.value = oRolesModel;
                        // const oRoleModelData = new JSONModel(oData);
                        // self.getView().setModel(oRoleModelData, "rolesModel");
                        self.getOwnerComponent().getModel("rolesModel").setData(oData);

                    },
                    error: function (oError) {

                    }
                });
            }
        },

        _onValidateAssignment: function () {
            //validate assignment fields
            let bAssignmentMandtValidation;
            let bAssignmentValidation;
            let bCommentValidation;
            const oAssignmentsModel = this.getView().getModel("assignmentsModel");
            const oAssignmentsData = oAssignmentsModel.getData().assignments;
            const oInternalOrderModel = this.getView().getModel("internalOrderModel").getData();
            const sReqType = this.getView().getModel().getProperty("/RequestType");
            let that = this;
            let aInvalidActivities = [];
            let bActivityValidation;
            var invActs=[]
            //validation for approve
            if (oAssignmentsData.length) {
                oAssignmentsData.forEach(function (assignment) {
                    assignment.roleValueState = assignment.selectedRole === "" ? "Error" : "None";
                    if (oInternalOrderModel.length > 1) {
                        assignment.internalOrderSelectValueState = assignment.selectedRole === "" ? "Error" : "None";
                    }
                    assignment.resourceValueState = !assignment.selectedNominees.length ? "Error" : "None";
                    let bIsAutoStaffingCompanyCode = assignment.selectedNominees.every(val => val.isAutoStaffingCompanyCode === true);
                    let bNoException = assignment.selectedNominees.every(val => val.isPartOfException === false);
                    let bSkipIOFlag = that.getView().getModel("WFRoutingSkipIOAPIData").getProperty("/value/0/operationalStatus");
                    if (assignment.isIOStaffing && sReqType === "Opportunity" && (bIsAutoStaffingCompanyCode || !bSkipIOFlag || !bNoException ) && assignment.staffingDateRangeVisible) {
                        let bIsAutoStaffing = assignment.selectedNominees.every(val => val.isAutoStaffing === true);
                        if (!bIsAutoStaffing) {
                            assignment.staffingPurposeValueState = assignment.staffingPurposeKey === "Sel" ? "Error" : "None";
                            assignment.dateRangeValueState = !assignment.staffingDateRange ? "Error" : "None";
                            assignment.daysToBooksValueState = !assignment.maxNoOfDaysToBookIO ? "Error" : "None";
                            if (assignment.staffingPurposeKey === "E") {
                                assignment.taskLevelValueState = "None"
                            } else {
                                assignment.taskLevelValueState = assignment.taskLevelKey === "Sel" ? "Error" : "None";
                            }
                        }
                        assignment.internalOrderSelectValueState = !assignment.internalOrderSelectValueState ? "Error" : "None";
                        assignment.ioOwnerValueState = !assignment.selectedIOOwner.length ? "Error" : "None";
                        if (!assignment.selectedNominees.length || (!bIsAutoStaffing && !assignment.staffingPurpose) || (!bIsAutoStaffing && !assignment.staffingDateRange)
                            || (!bIsAutoStaffing && !assignment.maxNoOfDaysToBookIO) || !assignment.selectedIOOwner.length ||
                            (!bIsAutoStaffing && assignment.staffingPurposeKey === "Sel") || assignment.taskLevelValueState === "Error") {
                            bAssignmentMandtValidation = true;
                            bAssignmentValidation = true;
                        }
                    } else {
                        if (!assignment.selectedNominees.length) {
                            bAssignmentMandtValidation = true;
                            bAssignmentValidation = true;
                        }
                    }
                    if (assignment.enableActivityRegister && assignment.activities) {
                        let bActValidation = assignment.activities.filter(item => item.actValueState === "Error").length ? true : false;
                        invActs=assignment.activities.filter(item => item.actValueState === "Error")
                        if (bActValidation) {
                            //check activity validation for each assignment
                            aInvalidActivities.push(bActValidation)
                        }
                        bActivityValidation = aInvalidActivities.length ? true:false;
                        //set activity assignments 
                        assignment.activities.forEach(function(actItems){
                            //  if(!actItems.activityPaylod.ActivityTypeDescription){
                            //     actItems.actValueState = "Error";
                            //     bAssignmentValidation = true;
                            //     bAssignmentMandtValidation = true;
                            //     actItems.actValueStateText = this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/activityRequiredField/0/fieldDesc");
                            //  }else{
                                actItems.actValueState = actItems.actValueState;
                                actItems.actValueStateText = actItems.actValueStateText
                            // }
                         })
                    } else {
                        bActivityValidation = aInvalidActivities.length ? true:false;
                        bAssignmentValidation = bAssignmentValidation;
                        bAssignmentMandtValidation = bAssignmentMandtValidation;
                    }
                });
                if(oAssignmentsData.filter(assignment=> assignment.resCommentValueState === "Error").length){
                   //validation on comment => Restrict the max length to 5000
                    bCommentValidation = true;

                }
            }
            let sCommentValidationMsg = this.getOwnerComponent().getModel("appConstants").getProperty("/commentValidationMsg/0/Value");
            if (bAssignmentMandtValidation === true) {
                const si18nAssignmentErrMsg = !bCommentValidation ? this.i18nModel.getText("assignmentValidationMsg"):
                `${this.i18nModel.getText("assignmentValidationMsg")} ${this.i18nModel.getText("and")} ${sCommentValidationMsg}`
                MessageBox.error(si18nAssignmentErrMsg, {
                    actions: [MessageBox.Action.OK],
                    emphasizedAction: MessageBox.Action.OK
                });
            } else if(bCommentValidation){
                //popup comment validation message
                MessageBox.error(sCommentValidationMsg, {
                    actions: [MessageBox.Action.OK],
                    emphasizedAction: MessageBox.Action.OK
                });

            }else if(bActivityValidation){
                  MessageBox.error(invActs[0].actValueStateText, {
                    actions: [MessageBox.Action.OK],
                    emphasizedAction: MessageBox.Action.OK
                });
            } else if (bAssignmentMandtValidation !== true && bAssignmentValidation !== true && !bActivityValidation) {
                const bSkipResources = this.getView().getModel().getProperty("/Skip_Resource_Approver");
                if (bSkipResources) {
                    //Skip resource approver-->Direct Manger approve
                    let aStaffingData = [];
                    oAssignmentsData.forEach(function (assignment) {
                        const aNominatedResource = assignment.selectedNominees[0];
                        if (!aNominatedResource.isAutoStaffing) {
                            if (aNominatedResource.isAutoStaffingCompanyCode || aNominatedResource.isPartOfException) {
                                aNominatedResource.dateValue = assignment.dateValue;
                                aNominatedResource.secondDateValue = assignment.secondDateValue;
                                aNominatedResource.taskLevelKey = assignment.taskLevelKey;
                                aNominatedResource.taskLevelVal = assignment.taskLevelVal;
                                aNominatedResource.internalOrder = assignment.internalOrder;
                                aNominatedResource.maxNoOfDaysToBookIO = assignment.maxNoOfDaysToBookIO;
                                aNominatedResource.isForward = assignment.isForward;
                                aNominatedResource.staffingPurpose = assignment.staffingPurpose;
                                aNominatedResource.staffingPurposeKey = assignment.staffingPurposeKey;
                                aStaffingData.push(aNominatedResource);
                            }
                        }

                    });
                    if (aStaffingData.length) {
                        //prepare staffing payload
                        this._formStaffingPayload(this, aStaffingData, bSkipResources)
                    } else {
                        //proceed wf trigger
                        this.onApprove();
                    }
                } else {
                    //proceed wf trigger
                    this.onApprove();
                }
            }
            oAssignmentsModel.refresh(true);
        },
        onChangeCommentsLengthValidation:function(evt){
            //live change on comment input value and check the validation
            const oBindingContext = evt.getSource().getBindingContext("assignmentsModel").getObject();
            oBindingContext.comments = evt.getParameter("value");
            if(evt.getParameter("value").length > 5000){
                oBindingContext.resCommentValueState = "Error";
            }else{
                oBindingContext.resCommentValueState = "None";
            }
        },
        //format IO staffing switch visibility
        formatIOStaffingToggle: function (sRequestType, oOpportunityResponse, sOperationalStatus) {
            if (sOperationalStatus && sRequestType === "Opportunity" && oOpportunityResponse.length) {
                return true;
            } else {
                return false;
            }
        },
        //format Internal order text control visibility if one internal order
        formatIODisplayMessage: function (oOpportunityResponse, sRequestType, bOPerationalFlag) {
            if (sRequestType === "Opportunity" && bOPerationalFlag && !oOpportunityResponse.length) {
                this.getView().byId("idAssignmntPanel").addStyleClass("customMessageStripPanel");
                return true;
            } else {
                this.getView().byId("idAssignmntPanel").removeStyleClass("customMessageStripPanel");
                return false;
            }
        },
        //format Internal order select control visibility if two or more internal order
        formatFormInternalOrderSelectVisibility: function (aInternalOrder, isStaffingVisible, sReqType) {
            if (sReqType === "Opportunity" && isStaffingVisible && aInternalOrder.length > 1) {
                return true;
            } else {
                return false;
            }
        },
        formatFormInternalOrderDisplayVisibility: function (aInternalOrder, isStaffingVisible, sReqType) {
            if (sReqType === "Opportunity" && isStaffingVisible && aInternalOrder.length === 1) {
                return true;
            } else {
                return false;
            }
        },
        /* Start of Code for CurrentTask Instance ID Update  */
        updateCurrentInstance: function () {
            const WfExt_data = {};
	var URL = this._getRuntimeBaseURL() + "/cap/wf/WfInstance";
	var oModelData = this.getView().getModel().getData();
	const oContextModelData = this.getView().getModel();
    let that = this;
	WfExt_data.instance_GUID = oContextModelData.getProperty("/WfID_PresalesRequestApproval");
	WfExt_data.parentInstance_GUID = oContextModelData.getProperty("/parentInstanceID");
    if(!WfExt_data.parentInstance_GUID){
        WfExt_data.parentInstance_GUID = this.getOwnerComponent().getModel("wfInstanceModel").getData().ParentInstanceID;
     }
	WfExt_data.currentTaskInstanceID = this.sUserTaskId;;
	WfExt_data.currentTaskURL = window.location.href;
	const instGuid = `(instance_GUID='${WfExt_data.instance_GUID}',parentInstance_GUID='${WfExt_data.parentInstance_GUID}')`;
	// WfExt_data.CurrentTaskURL = window.location.href; 
	$.ajax({
	url: URL+ `?&$filter=instance_GUID eq ''`,
	type: "GET",
	async: true,
	beforeSend: function (xhr) {
		xhr.setRequestHeader("X-CSRF-Token", "Fetch");
	},
	complete: function (xhr) {
		token = xhr.getResponseHeader("X-CSRF-Token"); const oSettings = {
			"url": URL + instGuid,
			"method": "PATCH",
			"async": false,
			"data": JSON.stringify(WfExt_data),
			"headers": {
				'X-CSRF-Token': token
			},
			"contentType": "application/json",
		};
		$.ajax(oSettings)
			.done(function (results) { 
                if(typeof that.getView().getModel().getData().RequestID !== "object" && typeof results === "object"){
                    if(results.refID){
                        oContextModelData.setProperty("/updatedRefId" ,results.refID);
                    }
                }
            })
			.fail(function (err) {
				MessageBox.error("Current user Instance ID update failed!");
			});
	}
	});
        },
        /* End of Code for CurrentTask Instance ID Update  */

        formatAssignmentOppDisplay: function (sRequestType) {
            if (sRequestType == "Opportunity") {
                return true;
            } else {
                return false;
            }
        },
        formatAssignmentAccDisplay: function (sRequestType) {
            if (sRequestType == "Account") {
                return true;
            } else {
                return false;
            }
        },
        _getServiceUrl: function (ApproversBaseUrl, sProfitcenter, tableTypeId, isSubsFlag ) {
            const filterValues = {
				"TableTypeID": tableTypeId,
				"Manager_Level": "non-managerial",
                "aRoles":this.getView().getModel("employee").getProperty(`/TempEmployee/TempRoles`).RolesData,
                "aSubsRoles":this.getView().getModel("employee").getProperty(`/TempEmployee/TempRoles`).aSubstituteRoleRoleArea,
			};
			const sManagerLevel = `(ManagerLevel eq 'non-managerial')`;
			const baIndustriesGuid = this.getView().getModel("employee").getData().TempEmployee.BAIndustries;
			const baIndustries_GUIDs = baIndustriesGuid.map(item => item.BaIndId);
			const filterCondition1 = baIndustries_GUIDs.length ? `(${baIndustries_GUIDs.map(BaIndId => `(BaIndId eq '${BaIndId}')`).join(' or ')})` :
				`(BaIndId eq '')`;
            const aSolAreas = this.getView().getModel("employee").getData().TempEmployee.SolutionAreas;
            const aSolAreas_GUIDs = aSolAreas ? aSolAreas.map(item => item.soln_id) : [];
            const parentSolIds = aSolAreas ? aSolAreas.map(item => item.prnt_soln_id) : [];
            //set Role payload
			const aFinaRole = isSubsFlag ? filterValues.aSubsRoles:filterValues.aRoles;
			this.getView().getModel("employee").setProperty("/aFinalRolePaylod",aFinaRole);
            let filterConditionSolAreas = "";
            let filterParts = [];
            aSolAreas_GUIDs.forEach((soln_id, index) => {
                const relatedArea = aSolAreas[index];
                const parentSolId = parentSolIds[index]; 
                if (relatedArea?.soln_prnt_guid === "00000000-0000-0000-0000-000000000000") {
                  filterParts.push(`(SolAreaL1Id eq '${soln_id}' and SolAreaL2Id eq '')`);
                } else {
                  filterParts.push(`(SolAreaL2Id eq '${soln_id}' and SolAreaL1Id eq '${parentSolId}')`);
                }
              });
            filterConditionSolAreas = filterParts.length
                ? `(${filterParts.join(' or ')})`
                : `(SolAreaL1Id eq '' and SolAreaL2Id eq '')`;
			//multiple profit center
			const aSelectedProfitCenter = JSON.parse(JSON.stringify(this.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories));
            for (let i = 0; i < aSelectedProfitCenter.length; i++) {
				if (!aSelectedProfitCenter[i].isCheckBox || !aSelectedProfitCenter[i].isResourceProfile) {
					aSelectedProfitCenter.splice(i, 1)
				}
			}
			const aFinalPfc = aSelectedProfitCenter.filter((obj1, i, arr) => 
				arr.findIndex(obj2 => (obj2.SelectedGuid === obj1.SelectedGuid)) === i
			  );
            const aSelectedPfcGuids = aFinalPfc.map(item => item.TrpcId);
			const filterCondition5 = aSelectedPfcGuids.length ? `(${aSelectedPfcGuids.map(SelectedGuid => `(TrpcId eq '${SelectedGuid}')`).join(' or ')})` : `(TrpcId  eq '')`;
            //role data
			const aRoleIds = isSubsFlag ? filterValues.aSubsRoles.map(item => item.RoleID):filterValues.aRoles.map(item => item.RoleID);
			const aUniqueRoleIds = aRoleIds.filter((item, index) => aRoleIds.indexOf(item) === index);
			const filterConditionForRoles = aUniqueRoleIds.length ? `(${aUniqueRoleIds.map(roleId => `RoleId eq '${roleId}'`).join(' or ')})` :
				`(RoleId eq '')`;
            //filter condition for Role Areas
			const aRoleAreaIds = isSubsFlag ? filterValues.aSubsRoles.map(item => item.RoleAreaID) : filterValues.aRoles.map(item => item.RoleAreaID);
			const aUniqueRoleAreaIds = aRoleAreaIds.filter((item, index) => aRoleAreaIds.indexOf(item) === index);
			const filterConditionForRoleArea = aUniqueRoleAreaIds.length ? `(${aUniqueRoleAreaIds.map(roleAreaId => `RoleAreaId eq '${roleAreaId}'`).join(' or ')})` :
				`(RoleAreaId eq '')`;
			let finalFilterString =
				`$filter=${sManagerLevel} and (TableTypeId eq '${filterValues.TableTypeID}') and 
							${filterConditionForRoles}  and ${filterConditionForRoleArea} and (RecordStatus eq '01')`;

                            let aIACID = this.getView().getModel("IACRoleAreaModel").getData() ? this.getView().getModel("IACRoleAreaModel").getData()[0].IacId : "";
                            let filterConditionIAC = `(IacValue eq '${aIACID}')`;
            const filterConditions = [filterCondition5];
			if(this.getView().getModel("employee").getProperty(`/BAIndustrySelectable`)){
				//push only if industry field is selectable/visible
                filterConditions.push(filterCondition1);
			}
			if(this.getView().getModel("employee").getProperty(`/SolnAreaSelectable`)){
				//push only if solution area is selectable/visible
                filterConditions.push(filterConditionSolAreas);
			}
			if(this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/Operational_Status") && !this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/isIACQueryRemove") && (this.getView().getModel().getData().EngagementType!=='0002')){
				filterConditions.push(filterConditionIAC)
			}
            if(this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/Operational_Status") && !this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/isIACQueryRemove") && (this.getView().getModel().getData().EngagementType!=='0002')){
				filterConditions.push(filterConditionIAC)
			}
			const nonEmptyFilters = filterConditions.filter(condition => condition !== '');
 
			if (nonEmptyFilters.length > 0) {
				finalFilterString += ' and ';
				finalFilterString += nonEmptyFilters.join(' and ');
			}
			return `${finalFilterString}&$expand=to_substitute`;
        },

        _getServiceBSUrl: function (ApproversBaseUrl, sProfitcenter, tableTypeId,isSubsFlag) {
            const filterValues = {
                "ProfitCenterGUID": sProfitcenter,
                "TableTypeID": tableTypeId,
                "Manager_Level": "non-managerial",
                "aRoles":this.getView().getModel("employee").getProperty(`/TempEmployee/TempRoles`).RolesData,
                "aSubsRoles":this.getView().getModel("employee").getProperty(`/TempEmployee/TempRoles`).aSubstituteRoleRoleArea
            };
            const sManagerLevel = `((ManagerLevel eq 'non-managerial') or (ManagerLevel eq '*'))`;
            const baIndustriesGuid = this.getView().getModel("employee").getData().TempEmployee.BAIndustries;
            const baIndustries_GUIDs = baIndustriesGuid.map(item => item.BaIndId);
            let filterCondition1 = baIndustries_GUIDs.length ? `(${baIndustries_GUIDs.map(BaIndId => `(BaIndId eq '${BaIndId}')`).join(' or ')} or (BaIndId eq '*'))` :
                "(BaIndId eq '')";
            let aSolAreas = this.getView().getModel("employee").getData().TempEmployee.SolutionAreas;
            let filterConditionSolAreas = "";
            if (aSolAreas.length) {
                const filterParts = aSolAreas.map(item => {
                    if (item.soln_prnt_guid === "00000000-0000-0000-0000-000000000000") {
                        return `(SolAreaL1Id eq '${item.soln_id}' or SolAreaL1Id eq '*') and (SolAreaL2Id eq '')`
                    } else {
                        return `(SolAreaL2Id eq '${item.soln_id}' or SolAreaL2Id eq '*') and (SolAreaL1Id eq '${item.prnt_soln_id}' or SolAreaL1Id eq '*')`
                    }
                });
                filterConditionSolAreas = filterParts.join();
			}else{
                filterConditionSolAreas = "(SolAreaL2Id eq '' ) and (SolAreaL1Id eq '')";
            }

            //multiple profit center
            const aSelectedProfitCenter = JSON.parse(JSON.stringify(this.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories));
            for (let i = 0; i < aSelectedProfitCenter.length; i++) {
                if (!aSelectedProfitCenter[i].isCheckBox || !aSelectedProfitCenter[i].isResourceProfile) {
                    aSelectedProfitCenter.splice(i, 1)
                }
            }
            const aFinalPfc = aSelectedProfitCenter.filter((obj1, i, arr) =>
                arr.findIndex(obj2 => (obj2.SelectedGuid === obj1.SelectedGuid)) === i
            );
            const aSelectedPfcGuids = aFinalPfc.map(item => item.TrpcId);
            //filter condition for Roles
			const aRoleIds = isSubsFlag ? filterValues.aSubsRoles.map(item => item.RoleID):filterValues.aRoles.map(item => item.RoleID);
            const aUniqueRoleIds = aRoleIds.filter((item, index) => aRoleIds.indexOf(item) === index);
            //Filter condition for Roles if any role is selected
            let oSelectedSubRole = this.getView().getModel("employee").getProperty(`/TempEmployee/TempRoles/SelectedSubRole`);
            let filterConditionForRoles;
            let bIsSubRoleSelected = false;
            if (oSelectedSubRole && Object.keys(oSelectedSubRole).length && oSelectedSubRole['active'] && this.getView().getModel("subRole").getData().filter(item=>item.RoleID==oSelectedSubRole.RoleID).length) {
                filterConditionForRoles = `RoleId eq '${oSelectedSubRole.RoleID}'`;
                bIsSubRoleSelected = true;
            } else {
                filterConditionForRoles = aUniqueRoleIds.length ? `(${aUniqueRoleIds.map(roleId => `RoleId eq '${roleId}'`).join(' or ')})` :
                    `(RoleId eq '*')`;

            }
            //filter condition for Role Areas
            const aRoleAreaIds = isSubsFlag ? filterValues.aSubsRoles.map(item => item.RoleAreaID) : filterValues.aRoles.map(item => item.RoleAreaID);
            const aUniqueRoleAreaIds = aRoleAreaIds.filter((item, index) => aRoleAreaIds.indexOf(item) === index);
            const filterConditionForRoleArea = aUniqueRoleAreaIds.length ? `(${aUniqueRoleAreaIds.map(roleAreaId => `RoleAreaId eq '${roleAreaId}'`).join(' or ')})` :
                `(RoleAreaId eq '*')`;
            //set Role payload
            const aFinaRole = isSubsFlag ? filterValues.aSubsRoles : bIsSubRoleSelected ? [oSelectedSubRole] : filterValues.aRoles;
            this.getView().getModel("employee").setProperty("/aFinalRolePaylod", aFinaRole);
            const filterCondition5 = aSelectedPfcGuids.length ? `(${aSelectedPfcGuids.map(SelectedGuid => `(TrpcId eq '${SelectedGuid}')`).join(' or ')})` : "";
            let finalFilterString =
                `$filter=${sManagerLevel} and (TableTypeId eq '${filterValues.TableTypeID}') and
                (${filterConditionForRoles} or (RoleId eq '*')) and (${filterConditionForRoleArea} or (RoleAreaId eq '*')) and (RecordStatus eq '01')`;
            let aIACID = this.getView().getModel("IACRoleAreaModel").getData() ? this.getView().getModel("IACRoleAreaModel").getData()[0].IacId : "";
            let filterConditionIAC = `(IacValue eq '${aIACID}' or IacValue eq '*')`;


                const filterConditions = [filterCondition5,filterCondition1,filterConditionSolAreas];

                if(this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/Operational_Status") && !this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/isIACQueryRemove") && (this.getView().getModel().getData().EngagementType!=='0002')){
                filterConditions.push(filterConditionIAC)
            }
            const nonEmptyFilters = filterConditions.filter(condition => condition !== '');

            if (nonEmptyFilters.length > 0) {
                finalFilterString += ' and ';
                finalFilterString += nonEmptyFilters.join(' and ');
            }
            let sEngagementType=this.getView().getModel().getData().EngagementType
            finalFilterString += ` and (EngTypeId eq '${sEngagementType}')`
            if(sProfitcenter[0].GrpSelectable === 'X'){
				let aSelGroup=this.getView().getModel("employee").getData().TempEmployee?.SelectedGroup;
				if(aSelGroup?.length){
					finalFilterString+= ` and (GroupValue eq '${aSelGroup[0].GroupID}' or GroupValue eq '*')`
				}else{
					finalFilterString+= ` and (GroupValue eq '')`
				}
			}
            return `${finalFilterString}&$expand=to_substitute`;
        },
        /*RESOURCE PROFILE SCREEN*/
        /*Reset resource profile Models*/
        _resetResourceProfile: function () {
            const oModel = this.getView().getModel("employee");
            const subRoleModel=this.getView().getModel("subRole");
            if (this.getView().getModel().getData().EngagementType !== '0002'){
                oModel.setProperty("/SelectedRoleKey", "");
                oModel.setProperty("/SelectedRoleAreasKey", "");
                oModel.setProperty("/SelectedSubRoleKey", "");
                oModel.setProperty("/TempEmployee/Roles", []);
                oModel.setProperty("/TempEmployee/TempRoles", {});
                oModel.setProperty("/TempEmployee/RoleAreas", []);
                oModel.setProperty("/TempEmployee/SelectedGroup", []);
                oModel.setProperty("/TempEmployee/TempGroup", []);
                subRoleModel.setData([]);
                subRoleModel.refresh();
            }
            oModel.setProperty("/TempEmployee/BAIndustries", []);
            oModel.setProperty("/TempEmployee/BALoBs", []);
            oModel.setProperty("/TempEmployee/CrossCvg", []);
            oModel.setProperty("/TempEmployee/BASegments", []);
            oModel.setProperty("/TempEmployee/SelectedHubs", []);
            oModel.setProperty("/TempEmployee/selectedBALob", "");
            oModel.setProperty("/TempEmployee/selectedCrossCoverage", "");
            oModel.setProperty("/TempEmployee/selectedBAIndustry", "");
            oModel.setProperty("/TempEmployee/TempBALoBs",[]);
            oModel.setProperty("/TempEmployee/TempBAIndustries", []);
            oModel.setProperty("/TempEmployee/TempCrossCvg", []);
            oModel.setProperty("/TempEmployee/SolutionAreas", []);            
            oModel.refresh();
            oModel.setProperty("/sSearchBoxText", "");
        },
        /*Event trigger for Resource Profile selection*/
     onResourceProfileSelectionPress: function (isReqArea) {
            const oView = this.getView();
            var that = this;
            const oModel = this.getView().getModel();
            const sSalesOrg = oModel.getProperty("/OrgID");
            const sSalesOrgNumber = Number(sSalesOrg.replace('SORG-', '')).toString();
            const sOrgType = that.getView().getModel().getProperty("/OrgType");
            const sOrgID = that.getView().getModel().getProperty("/OrgID");
            const isResourceProfile = oModel.getProperty("/isResourceProfile");
            //set Button model for forward request
            const oProfileViewModel = new sap.ui.model.json.JSONModel();
            const oProfileView = {
                "footerButtons": {
                    "forwardReqButtonVisible": false,
                    "searchResourceButtonVisible": false,
                    "forwardReqButtonEnabled": false,
                    "searchResourceButtonEnabled": false,
                    "errorBtnVisible": false
                },
                "isProfitCenterTextVisible": false,
                "isProfitCenterInputVisible": false,
                "isReqAreaContainerVisible": !isResourceProfile,
                "isResProfileConatiner": isResourceProfile
            }
            oProfileViewModel.setData(oProfileView);
            this.getView().setModel(oProfileViewModel, "profileViewParameters");
            const oErrorModel = new sap.ui.model.json.JSONModel();
            const oErrorData = {
                "errorInformation": []
            }
            oErrorModel.setData(oErrorData);
            this.getView().setModel(oErrorModel, "errorMsgModel");
            /*Open fragment for Resource Profile selection*/
            that.oSLASearchContext = false
            that.oSearchAddSlnContext = false
            if (!this._pForwardReqialog) {
                this._pForwardReqialog = Fragment.load({
                    id: oView.getId(),
                    name: "com.dealsupport.melodyrequest.fragments.managerPage.ForwardReqDialog",
                    controller: this
                }).then(function (oForwardDialog) {
                    oForwardDialog.addStyleClass(that.getOwnerComponent().getContentDensityClass());
                    if (isReqArea === true) {
                        const aResult = that.getView().getModel("RequestAreaAPIData").getData().value;
                        const aModel = {};
                        aModel.data = that._setReqAreasTree(aResult);
                        const oUpdatedReqArea = new JSONModel();
                        oUpdatedReqArea.setData(aModel);
                        that.getView().setModel(oUpdatedReqArea, "myPresaleModel");
                        that._configRequestDialog()
                    }
                    that.oForwardDialog = oForwardDialog;
                    oView.addDependent(oForwardDialog);
                    return oForwardDialog;
                });
            }

            this._pForwardReqialog.then(function (oForwardDialog) {

                that._onDestroyAllResourcePopOvers();
                if (!isResourceProfile) {
                    /*Request Area selection screen*/
                    that.getView().byId("idPFCField").setVisible(false);
                    that.getView().getModel("profileViewParameters").setProperty
                        ("/footerButtons/searchResourceButtonVisible", false);
                    that.getView().getModel("profileViewParameters").setProperty
                        ("/footerButtons/forwardReqButtonVisible", true);
                    that.getView().getModel("profileViewParameters").refresh();
                    that._configRequestDialog();
                } else {
                    /*Resource Profile selection screen*/
                    that.aNonSelectableParentNode = false;
                    that.getView().byId("idMultiInputPFC").getAggregation("tokenizer").setEditable(false);
                    that.aSelectedParentNode = false;
                    if (that.getView().getModel("selectedProfitCenter")) {
                        that.getView().getModel("selectedProfitCenter").setProperty("/TempProfitCenter/Territories", []);
                        that.getView().getModel("selectedProfitCenter").setProperty("/TempProfitCenter/filteredProfitCenter", []);
                        that.getView().getModel("selectedProfitCenter").refresh(true);
                    }
                    //parent selection

                    Models.getManagerPageFilteredSalesOrgProfitCenter(that, sOrgID, sOrgType);
                    that.loadTreeTerritories("treeTerritories", that.getView().getModel("territoriesMaster").getData(), true);
   that.setTerritoryHierarchySelection(false, false, false,true,true);
                    let nodeUpdate = function nodeUpdate(newValue, that) {
                        for (const child of newValue.nodes) {
                            if (child.isCheckBox && child.isResourceProfile) {
                                child.IsSelected = true;
                                let oSelectedProfitCenter = Models._setProfitCenterObj(child);
                                that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories.push(
                                    oSelectedProfitCenter);
                                that.getView().getModel("selectedProfitCenter").refresh(true);
                            }
                            nodeUpdate(child, that);
                        }
                    }
                    if (that.aSelectedParentNode && that.aSelectedParentNode.isResourceProfile && that.aSelectedParentNode.isChildNodeEnable) {
                        //select child nodes if LAC and isResourceProfile true
                        nodeUpdate(that.aSelectedParentNode, that);
                    }
                    that.getView().getModel("selectedProfitCenter").refresh(true);
                    that.getView().getModel("treeTerritories").refresh(true);
                    that.getView().getModel("crossCvgMasterData").setData(appView.getView().getModel("crossCvgMasterData").getData());
                    that.getView().getModel("baLoBMasterData").setData(appView.getView().getModel("baLoBMasterData").getData());
                    that.getView().getModel("baIndMasterData").setData(appView.getView().getModel("baIndMasterData").getData());

                    that.getView().setModel(new sap.ui.model.json.JSONModel({
                        Roles: [],
                        SelectedRoles: []
                    }), "roles");
                    var bEngType = that.getView().getModel().getData().EngagementType == '0002' ? false : true;
                    let bGrpSelectable = that.getView().getModel("selectedProfitCenter")?.getData()?.TempProfitCenter?.Territories?.[0]?.GrpSelectable == 'X' ? true : false;
                    that.getView().setModel(new sap.ui.model.json.JSONModel({
                        TempEmployee: {
                            "Roles": [],
                            "TempRoleAreas": [],
                            "TempBAIndustries": [],
                            "TempSelectedHubs": [],
                            "SelectedHubs": [],
                            "TempBALoBs": [],
                            "TempCrossCvg": [],
                            "BASegmentsBusy": false,
                            "BALoBBusy": false,
                            "CrossCvgBusy": false,
                            "hubLoBBusy": false,
                            "BAIndBusy": false,
                            "TempBASegments": [],
                            "RoleAreas": [],
                            "BAIndustries": [],
                            "BASegments": [],
                            "CrossCvg": [],
                            "BALoBs": [],
                            "ManagerLevel": [
                            ]
                        },
                        "RoleAreas": [],
                        "BAIndustries": [],
                        "sSearchBoxText": "",
                        "BASegments": [],
                        "CrossCvg": [],
                        "BALoBs": [],
                        "SelectedRoleAreas": [],
                        "Hubs": [],
                        "Rules": {
                            "HubIndustry": [],
                            "HubLoB": [],
                            "HubRole": []
                        },
                        "BAIndustryMandatory": false,
                        "BAIndustrySelectable": bEngType,
                        "SolnAreaMandatory": false,
                        "SolnAreaSelectable": bEngType,
                        "SubRoleSelectable": bEngType,
                        "GrpSelectable":bGrpSelectable,                        
                        "minSelect": 0,
                        "maxSelect": 2,
                        "solnAreaEnable": true,
                        "industryEnable": true,
                        "solnIndRequired": false,
                        "midSectionDesc": appView.getOwnerComponent().
                            getModel("mrrAppConfigModel").getProperty("/SolnInd_SelectionText/0/fieldDesc"),
                        "legacyValidation": false,
                        "fieldSelectionMidInfoIcon": false,
                        "isFilter":false
                    }), "employee");
                    that._callBusinessAreaIndustryMasterData();
                    oModel.setProperty("/TempEmployee/selectedBAIndustry", "");
                    that.loadRoleTypeData("ROLETYPE", that.getOwnerComponent().getModel("roleMasterData").getData());
                    that.getView().getModel("employee").setProperty("/TempEmployee/ManagerLevel", that.getOwnerComponent().getModel("managerLevelMasterData").getData());
                    that.getView().byId("idPFCField").setVisible(true);
                    that.getView().getModel("profileViewParameters").setProperty
                        ("/footerButtons/searchResourceButtonVisible", true);
                    that.getView().getModel("profileViewParameters").setProperty
                        ("/footerButtons/forwardReqButtonVisible", false);
                    that.getView().getModel("profileViewParameters").refresh();
                    //get salesOrg-profitCenter smapping

                    const sFilterParams = sOrgType !== "PC" ? `SOrg eq '${sSalesOrgNumber}' and isPC_Viewable eq 'X'` :
                        `ProfitCenterGuid eq  ${sOrgID} and isPC_Viewable eq 'X'`;
                    var oView = that.getView();
                    const oEmployeeModel = oView.getModel("employee");
                    const oDataModel = oView.getModel().getData();
                    const oProfileDetails = oDataModel.aResourceProfileApprovers.ResourceProfileDetails;

                    const oProfileDetailsCopy = JSON.parse(JSON.stringify(oProfileDetails));

                    oEmployeeModel.setProperty("/TempEmployee/BASegments", oProfileDetailsCopy.BASegments);
                    oEmployeeModel.setProperty("/TempEmployee/CrossCvg", oProfileDetailsCopy.cross_CVRG_P_GUIDArray);
                    oEmployeeModel.setProperty("/TempEmployee/BALoBs", oProfileDetailsCopy.BALoBs);
                    oEmployeeModel.setProperty("/TempEmployee/SelectedHubs", oProfileDetailsCopy.Hubs);
                    oEmployeeModel.setProperty("/TempEmployee/BAIndustries", oProfileDetailsCopy.BAIndustries);
                    oEmployeeModel.setProperty("/TempEmployee/TempBALoBs", oProfileDetailsCopy.BALoBs);
                    oEmployeeModel.setProperty("/TempEmployee/TempBAIndustries", oProfileDetailsCopy.BAIndustries);
                    oEmployeeModel.setProperty("/TempEmployee/SelectedGroup", oProfileDetailsCopy?.SelectedGroup ? oProfileDetailsCopy.SelectedGroup : []);
                    oEmployeeModel.setProperty("/TempEmployee/TempGroup", oProfileDetailsCopy?.SelectedGroup ? oProfileDetailsCopy.SelectedGroup : []);
                    that.getOwnerComponent().getModel("grpHierarchyForFilter").setProperty("/selectedGrpID",oProfileDetailsCopy?.SelectedGroup?.length ? oProfileDetailsCopy.SelectedGroup[0].GroupID : "")
                    oProfileDetailsCopy?.SelectedGroup?.[0]?.id ? oEmployeeModel.setProperty("/GrpPanelExpanded",true):false;
                    if(oProfileDetailsCopy.BAIndustries.length > 1){
                        oEmployeeModel.setProperty("/TempEmployee/TempBAIndustries", []);
                    }else{
                        oEmployeeModel.setProperty("/TempEmployee/TempBAIndustries", oProfileDetailsCopy.BAIndustries);
                    }
                    oEmployeeModel.setProperty("/TempEmployee/TempCrossCvg", oProfileDetailsCopy.cross_CVRG_P_GUIDArray);
                    //MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
                    if(!oProfileDetailsCopy.SolutionAreas.length){
                        oEmployeeModel.setProperty("/TempEmployee/SolutionAreas", []);
                        that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",[]);
                        that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aTokenSelectedSolutionAreas",[]);
                    }else{
                        oEmployeeModel.setProperty("/TempEmployee/SolutionAreas", oProfileDetailsCopy.SolutionAreas);
                        that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",oProfileDetailsCopy.SolutionAreas);
                        that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aTokenSelectedSolutionAreas",oProfileDetailsCopy.SolutionAreas);
                    }
                    if(typeof oProfileDetailsCopy.AdditionalSolutions !== "object"){
                        oProfileDetailsCopy.AdditionalSolutions = [];
                    }
                    if(!oProfileDetailsCopy.AdditionalSolutions.length){
                        oEmployeeModel.setProperty("/TempEmployee/AdditionalSolutions", []);
                    }else{
                        oEmployeeModel.setProperty("/TempEmployee/AdditionalSolutions", oProfileDetailsCopy.AdditionalSolutions);
                    }
                    //set selected solution area
                    //MR: [GRP02-03] GTM25 Resource Profile alignment #84 end

                    const oRoleGuid = oProfileDetailsCopy.Role_GUID.RoleGuid;
                    const oRoleTypeGuid = oProfileDetailsCopy.Role_GUID.RoleTypeGuid;
                    const sSelectedSubRoleID = oProfileDetailsCopy.Role_GUID?.SelectedSubRole?.RoleID && oProfileDetailsCopy.Role_GUID?.SelectedSubRole?.active ? oProfileDetailsCopy.Role_GUID.SelectedSubRole.RoleID : "";
                    const aRole = [oRoleGuid, oRoleTypeGuid];

                    //MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
                    //pre select role area for new requests
                    that.getView().getModel().getProperty("/isRoleAreaSelection") ? oEmployeeModel.setProperty("/SelectedRoleKey", aRole) : oEmployeeModel.setProperty("/SelectedRoleKey", "");
                    //MR: [GRP02-03] GTM25 Resource Profile alignment #84 end                                      
                    //GIT 342- populate the role combobox according to the selected role area
                    // that.getView().setModel(new sap.ui.model.json.JSONModel(), "subRole");
                    // const oSubRoleModel = that.getView().getModel("subRole");
                    // const primaryRoleIDSet = new Set(oProfileDetailsCopy.Role_GUID.RolesData.map(item => item.RoleID));
                    // const filteredSubstitueRoles = oProfileDetailsCopy.Role_GUID.aSubstituteRoleRoleArea.filter(item => !primaryRoleIDSet.has(item.RoleID));
                    // oSubRoleModel.setData([...oProfileDetailsCopy.Role_GUID.RolesData, ...filteredSubstitueRoles]);
                    const oRoleAreaGuid = oProfileDetailsCopy.Role_GUID.RoleAreaGuid;
                    const oRoleAreaId = oProfileDetailsCopy.Role_GUID.RoleAreaID;
                    const aRoleAreaId = [oRoleAreaId];
                    //MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
                    //pre select role area for new requests
                    that.getView().getModel().getProperty("/isRoleAreaSelection") ? oEmployeeModel.setProperty("/SelectedRoleAreasKey", aRoleAreaId) : oEmployeeModel.setProperty("/SelectedRoleAreasKey", "");
                    that.getView().getModel().getProperty("/isRoleAreaSelection") ? oEmployeeModel.setProperty("/SelectedSubRoleKey", sSelectedSubRoleID) : oEmployeeModel.setProperty("/SelectedSubRoleKey", "");
                    if (!that.getView().getModel().getProperty("/isRoleAreaSelection")) {
                        that.getView().getModel("profileViewParameters").setProperty
                            ("/footerButtons/searchResourceButtonEnabled", false);
                    } else {
                        that.getView().getModel("profileViewParameters").setProperty
                            ("/footerButtons/searchResourceButtonEnabled", true);
                    }
                    that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas", [])
                    that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/results", [])
                    that.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
                    //MR: [GRP02-03] GTM25 Resource Profile alignment #84 end
                    oEmployeeModel.setProperty("/aRoleAreas", [oProfileDetailsCopy.RoleArea_P_GUID]);
                    const sSelectedBAInd = oProfileDetailsCopy.BAIndustries.length ? oProfileDetailsCopy.BAIndustries[0].Guid : "";
                    oEmployeeModel.setProperty("/TempEmployee/selectedBAIndustry", sSelectedBAInd);
                    that.getView().getModel("selectedProfitCenter").setProperty("/selectedPfc", that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories[0]);
                    that.getView().getModel().getProperty("/isRoleAreaSelection") ? oEmployeeModel.setProperty("/TempEmployee/TempRoleAreas", oEmployeeModel.getProperty("/aRoleAreas")) : [];
                }

                oForwardDialog.open();

            });

            sap.ui.core.BusyIndicator.hide();
            if (that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter) {
                that.getView().getModel("selectedProfitCenter").setProperty("/selectedPfc", that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories[0]);
            }
            that.getView().getModel("selectedProfitCenter").refresh(true);
        },
        _setResValidation: function (oContextObj) {
            //set field config based on role area
            this.getView().getModel("employee").setProperty(`/BAIndustryMandatory`, oContextObj.BAIndustryMandatory);
            this.getView().getModel("employee").setProperty(`/BAIndustrySelectable`, oContextObj.BAIndustrySelectable);
            this.getView().getModel("employee").setProperty(`/SolnAreaMandatory`, oContextObj.SolnAreaMandatory);
            this.getView().getModel("employee").setProperty(`/SolnAreaSelectable`, oContextObj.SolnAreaSelectable);
            this.getView().getModel("employee").setProperty(`/minSelect`,oContextObj.minSelect);
            this.getView().getModel("employee").setProperty(`/maxSelect`,oContextObj.maxSelect);
            if (oContextObj.RoleAreaID === "0006" || oContextObj.RoleAreaID === "0003") {
                this.getView().getModel("employee").setProperty(`/fieldSelectionMidInfoIcon`, true);
            } else {
                this.getView().getModel("employee").setProperty(`/fieldSelectionMidInfoIcon`, false);
            }
            if(oContextObj.RoleAreaID === "0005"){
                //for industry advisory
                this.getView().getModel("employee").setProperty(`/midSectionDesc`,
                    appView.getOwnerComponent().
                        getModel("mrrAppConfigModel").getProperty("/Ind_SelectionText/0/fieldDesc")
                );
            }else{
                this.getView().getModel("employee").setProperty(`/midSectionDesc`,
                    appView.getOwnerComponent().
                        getModel("mrrAppConfigModel").getProperty("/SolnInd_SelectionText/0/fieldDesc")
                );
            }
            if(this.getView().getModel("employee").getProperty(`/minSelect`) === 0){
				this.getView().getModel("employee").setProperty(`/solnIndRequired`, false);
			}else{
				this.getView().getModel("employee").setProperty(`/solnIndRequired`, true);
			}
            this.getView().getModel("employee").refresh();
        },
        _onDestroyAllResourcePopOvers: function () {
            var that = this;
            if (this.pBAIndustryValueHelpDialog) {
                this.pBAIndustryValueHelpDialog.then(function (oDialog) {
                    that.pBAIndustryValueHelpDialog = false;
                    oDialog.destroy();

                });
            }
            if (this.pBALoBValueHelpDialog) {
                this.pBALoBValueHelpDialog.then(function (oDialog) {
                    that.pBALoBValueHelpDialog = false;
                    oDialog.destroy();

                });
            }
            if (this.pCrossCvgValueHelpDialog) {
                this.pCrossCvgValueHelpDialog.then(function (oDialog) {
                    that.pCrossCvgValueHelpDialog = false;
                    oDialog.destroy();

                });
            }
            if (this.pBASegDialog) {
                this.pBASegDialog.then(function (oDialog) {
                    that.pBASegDialog = false;
                    oDialog.destroy();

                });
            }
            if (this.pHubValueHelpDialog) {
                this.pHubValueHelpDialog.then(function (oDialog) {
                    that.pHubValueHelpDialog = false;
                    oDialog.destroy();

                });
            }  
        },
        /*Open profit center view selection fragment*/
        onOpenTerritoryValueHelpDialog: function (oEvent) {
            var that = this;
            const oModel = this.getView().getModel("selectedProfitCenter");
            this.bSelectPfc = false;
            if(  that.getView().byId("territoriesTableId")){
                    that.getView().byId("territoriesTableId").getExtension()[0].getContent()[0].setValue();
            }
        
            if (!this.pTerritoryValueHelpDialog) {
                this.pTerritoryValueHelpDialog = this.loadFragment({
                    name: "com.dealsupport.melodyrequest.fragments.managerPage.TerritoryValueHelpDialog"
                });
            }

            this.pTerritoryValueHelpDialog.then(function (oDialog) {
                //oModel.setProperty("/TempEmployee/TempMuRegionFlg", true);
                
                that.filterTerritories();
                oModel.refresh(true);
                oDialog.openBy(oEvent.getSource());
            });
        },
        /*Filter and set profit center master data*/
        filterTerritories: function (initLoad, isRegionMUChange) {
            const oModel = this.getView().getModel("selectedProfitCenter");
            const oTerritoryModel = this.getView().getModel("territoriesMaster");
            const aTerritories = oTerritoryModel.getData();
            const oTempEmployee = oModel.getProperty("/TempProfitCenter");
            let aEmployeeTerritories = oTempEmployee.Territories;
            oTempEmployee.TempTreeTerritories = oTempEmployee.Territories;

			//remove parent node if checkbox selection or isResourceProfile false;

			const aSelectedPfc = oModel.getData().TempProfitCenter.Territories;
			let isResourceProfileFound = aSelectedPfc.some(function (resource) {
				return resource.isResourceProfile;
			});
			if (aSelectedPfc.length > 1) {
				for (let i = 0; i < aSelectedPfc.length; i++) {
					if (!aSelectedPfc[i].isCheckBox || !aSelectedPfc[i].isResourceProfile&& isResourceProfileFound) {
						aSelectedPfc.splice(i, 1)
					}
				}
			}
            if (isRegionMUChange) {
                aEmployeeTerritories = oTempEmployee.TempTreeTerritories;
            }

            let aTempTerritory = [];
            let bSelected = oModel.getProperty("/TempEmployee/TempMuRegionFlg");
            let aFilteredTerritories = aTerritories;

            if (bSelected) {
                aFilteredTerritories = aTerritories.filter(function (item) {
                    return item.MuBelow === "";
                });
            }
            this.loadTreeTerritories("treeTerritories", aFilteredTerritories);
            oModel.refresh(true);
            this.setTerritoryHierarchySelection(false, true);
        },
        /*Select event for profit center view selection*/
        onSelectTerritory: function (oEvent) {
            this.bSelectPfc = true;
            this.selectIfTerritoryExists(this.getView().getModel("treeTerritories").getData().territories, [], 0, true);
            const oModel = this.getView().getModel("selectedProfitCenter");
            const oSource = oEvent.getSource();
            let bSelected = oEvent.getParameter("selected");
            let sSelectedDesc = oSource.data("displaydesc");
            const oBindingContext = oSource.getBindingContext("treeTerritories");
            const oTerritoryModel = oBindingContext.getModel();
            const sPath = oBindingContext.getPath();
            const oTerritory = oTerritoryModel.getProperty(sPath);
            oTerritory.IsSelected = true;
            this.oSelectedPFCNode = oTerritory.nodes;
            oTerritory.nodes = this.selectIfTerritoryExists(oTerritory.nodes, [], 0, false);
            const oTempEmployee = oModel.getProperty("/TempProfitCenter");
            let aEmployeeTerritories = oTempEmployee.TempTreeTerritories;
            aEmployeeTerritories = aEmployeeTerritories.filter(function (item) {
                return !item.Desc.includes(sSelectedDesc);
            });
            let iIndex = aEmployeeTerritories.findIndex(function (item) {
                return item.Desc.toUpperCase().trim() === oTerritory.displaydesc.toUpperCase().trim();
            });

            if (iIndex !== -1 && !bSelected) {
                aEmployeeTerritories.splice(iIndex, 1);
                oTerritory.IsPrimary = false;
            } else if (iIndex === -1 && bSelected) {
                if (aEmployeeTerritories.length === 0) {
                    oTerritory.IsPrimary = true;
                } else if (aEmployeeTerritories.length === 1 && aEmployeeTerritories[0].IsPrimary) {
                    aEmployeeTerritories[0].IsPrimary = false;
                }
                aEmployeeTerritories = [];
                const oProfitCenter = Models._setProfitCenterObj(oTerritory);
                aEmployeeTerritories.push(oProfitCenter);
            } else {
                if (iIndex !== -1) {
                    aEmployeeTerritories.splice(iIndex, 1);
                }
            }
            let bIsFilter = this.getView().getModel("employee").getProperty("/isFilter")
            if (bIsFilter) {
                //select profitcenter from ore filter masterdata
                let aProfitCenters = oModel.getProperty("/TempProfitCenter/TempTreeTerritories");
                if (bSelected) {
                    if (aEmployeeTerritories.length) {
                        aProfitCenters.push(aEmployeeTerritories[0]);
                    }
                } else {
                    oTerritory.IsSelected = false;
                    aProfitCenters = aProfitCenters.length ? aProfitCenters.filter(function (item) {
                        return item.guid !== oTerritory.guid;
                    }) : [];
                }
                oModel.setProperty("/TempProfitCenter/TempTreeTerritories", aProfitCenters);
                this.getView().getModel("masterDataModel").setProperty("/TempProfitCenter/TempTreeTerritories", aProfitCenters);
                this.getView().getModel("masterDataModel").refresh(true);
                oModel.getProperty("/TempProfitCenter/TempTreeTerritories") && oModel.getProperty("/TempProfitCenter/TempTreeTerritories").length ?
                    this.getView().getModel("employee").setProperty("/filter/dialogselProfitCenterVisible", true) : this.getView().getModel("employee").setProperty("/filter/dialogselProfitCenterVisible", false);
                oModel.refresh(true);
                } else {
                oModel.setProperty("/TempProfitCenter/TempTreeTerritories", aEmployeeTerritories);
            }
            oModel.refresh(true);
            oTerritoryModel.refresh(true);
            this.setTerritoryHierarchySelection(false,false,oBindingContext);
        },
           /**
      *Git 313
      * Close profit center dialog
      * @function onCloseTerritoryValueHelpDialog
      */
        onCloseTerritoryValueHelpDialog: function () {
            let bIsFilter = this.getView().getModel("employee").getProperty("/isFilter");
            let that = this;
            if (!bIsFilter) {
                this.pTerritoryValueHelpDialog.then(function (oDialog) {
                    oDialog.close();
                    //set resource profile data for forward
                });
                this._setResourceProfileData(that);
            } else {
                //for profit center filter
                this.pProfitCenterValueHelpDialog.then(function (oDialog) {
                    oDialog.close();
                });
            }
        },
        _setResourceProfileData: function (self) {
            const isResourceProfile = self.getView().getModel("selectedProfitCenter").
                getProperty("/TempProfitCenter/Territories/0/isResourceProfile");
            if (isResourceProfile) {
                /*Resource Profile selection screen*/
                self.getView().getModel("profileViewParameters").setProperty
                    ("/footerButtons/searchResourceButtonVisible", true);
                self.getView().getModel("profileViewParameters").setProperty
                    ("/isResProfileConatiner", true);
                self.getView().getModel("profileViewParameters").setProperty
                    ("/footerButtons/forwardReqButtonVisible", false);
                self.getView().getModel("profileViewParameters").setProperty
                    ("/isReqAreaContainerVisible", false);
                self.getView().getModel("profileViewParameters").setProperty
                    ("/footerButtons/forwardReqButtonEnabled", false);
                self.getView().getModel("profileViewParameters").setProperty
                    ("/footerButtons/searchResourceButtonEnabled", true);
            } else {
                /*Request Area selection screen*/
                self.getView().getModel("profileViewParameters").setProperty
                    ("/footerButtons/searchResourceButtonVisible", false);
                self.getView().getModel("profileViewParameters").setProperty
                    ("/isResProfileConatiner", false);
                self.getView().getModel("profileViewParameters").setProperty
                    ("/footerButtons/forwardReqButtonVisible", true);
                self.getView().getModel("profileViewParameters").setProperty
                    ("/isReqAreaContainerVisible", true);
                self.getView().getModel("profileViewParameters").setProperty
                    ("/footerButtons/forwardReqButtonEnabled", false);
                self.getView().getModel("profileViewParameters").setProperty
                    ("/footerButtons/searchResourceButtonEnabled", false);

                let sorgID;
                self.getView().getModel("PCSalesOrgMaster").getData().find(function (item) {
                    if (item.ProfitCenterGuid === self.getView().getModel("selectedProfitCenter").
                        getProperty("/TempProfitCenter/Territories/0/guid")) {
                        sorgID = item.SOrg;
                    }
                });
                //filter selected profit center
                self.getView().getModel("territoriesMaster").getData().find(function (item) {
                    if (item.TrpcGuid === self.getView().getModel("selectedProfitCenter").
                        getProperty("/TempProfitCenter/Territories/0/guid")) {
                        self.isResourceProfile = item.isResourceProfile;
                    }
                });
                if(sorgID === "NOMP"){
                    sorgID = self.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories/0/guid");
                }
                Models.getPublicReqArea(this, sorgID);

            }
            this.getView().getModel("profileViewParameters").refresh()

        },
        dialogAfterclose: function (oEvent) {//function called after Dialog is closed
            this._oDialog.destroy();//destroy only the content inside the Dialog
        },
        setTerritoryHierarchySelection: function(initLoad,forceReset,oBindingContext,bParanetNodeSelection,initialSelection) {
			const oModel = this.getView().getModel("selectedProfitCenter");
			const oTempEmployee = oModel.getProperty("/TempProfitCenter");
			const aTempTreeTerritories = bParanetNodeSelection ?   oTempEmployee.Territories:oTempEmployee.TempTreeTerritories;
			const oTerritoryHierarchyModel = this.getView().getModel("treeTerritories");
			let that = this;
			let aTerritoryHierarchies = oTerritoryHierarchyModel.getData();
			aTerritoryHierarchies = aTerritoryHierarchies.territories;
			aTerritoryHierarchies = this.selectIfTerritoryExists(aTerritoryHierarchies, [], 0, forceReset,bParanetNodeSelection,initialSelection);
			let aTerritory = [];
			for (let i = 0; i < aTempTreeTerritories.length; i++) {
			  let aDesc = aTempTreeTerritories[i].SelectedDesc.split(">");
	  
			  if (initLoad) {
				let territory = {};
				territory.Desc = aTempTreeTerritories[i].Desc;
				territory.Guid = aTempTreeTerritories[i].Guid;
				territory.IsPrimary = aTempTreeTerritories[i].IsPrimary;
				territory.TrpcId = aTempTreeTerritories[i].TrpcId;
	  
				for (let j = 1; j <= 5; j++) {
				  territory["TrpcL" + j + "Desc"] = aTempTreeTerritories[i]["TrpcL" + j + "Desc"];
				}
	  
				let oTerritory =  Models._setProfitCenterObj(oTerritory);
				aTerritory.push(oTerritory);
			  }
	  
			  aTerritoryHierarchies = this.selectIfTerritoryExists(aTerritoryHierarchies, aDesc, 0,false,bParanetNodeSelection,initialSelection);
			}
	  
			if (initLoad) {
			  oTempEmployee.Territories = aTerritory;
			  oModel.setProperty("/TempEmployee/TRPCPGUIDValueState", "None");
			}
	  
			oModel.refresh(true);
			if(oBindingContext){
			let root = oBindingContext.getObject();
			let nodeUpdate = function nodeUpdate(newValue,that) {
				for (const child of newValue.nodes) {
					if(child.isCheckBox && child.isResourceProfile){
						child.IsSelected = true;
						let oSelectedProfitCenter = Models._setProfitCenterObj(child);
						that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.TempTreeTerritories.push(
							oSelectedProfitCenter);
						that.getView().getModel("selectedProfitCenter").refresh(true);
					}
					nodeUpdate(child,that);
				}
			}
			if(root.isResourceProfile && root.isChildNodeEnable){
				//select child nodes if isResourceProfile true for parent node
				nodeUpdate(root,that);
			}
		}
			oTerritoryHierarchyModel.refresh(true);
		  },
		  /*Check if profit center exist or not*/
		  selectIfTerritoryExists: function(Territory, desc, index, forceReset,bParentNodeSelection,initialSelection) {
			if (!Territory || Territory.length === 0) {
			  return [];
			}
			const that = this;
			const oModel = this.getView().getModel("selectedProfitCenter");
			const oTempEmployee = oModel.getProperty("/TempProfitCenter");
			const aTempTreeTerritories = oTempEmployee.TempTreeTerritories;
			let oPrimaryTerritory;
			if(!bParentNodeSelection){
		     oPrimaryTerritory = aTempTreeTerritories.find(function (item) {
			  return item.IsPrimary;
			});
	  
		}
			for (let j = 0; j < Territory.length; j++) {
			  let territory = Territory[j];
			  if (!forceReset) {
				if (territory.desc.toUpperCase().trim() === (desc && desc[index] && desc[index].toUpperCase().trim())) {
					if(bParentNodeSelection && !initialSelection){
						if(desc.length-2 === index){
							territory.IsSelected = true;
							let oSelectedProfitCenter = Models._setProfitCenterObj(territory);
							that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories = [oSelectedProfitCenter];
							that.aSelectedParentNode = territory;
					  }
					} else if (desc.length - 1 === index && !bParentNodeSelection) {
						that.aSelectedParentNode = territory;
						territory.IsSelected = true;
					}
			
	  
				  if (territory.desc.toUpperCase().trim() === desc[desc.length - 1].toUpperCase().trim()) {
					if(initialSelection){
						this.aSelectedParentNode = territory;
					}
					territory.IsEnabled = true;
				  } else {
					territory.IsEnabled = false;
				  }
				if(!bParentNodeSelection){
				  if (territory.IsSelected && aTempTreeTerritories.length === 1 && aTempTreeTerritories[0].Desc.toUpperCase().trim() === territory.desc.toUpperCase().trim()) {
					territory.IsPrimary = aTempTreeTerritories[0].IsPrimary;
				  } else if (oPrimaryTerritory && oPrimaryTerritory.Desc.toUpperCase().trim() === territory.desc.toUpperCase().trim()) {
					territory.IsPrimary = true;
				  } else {
					territory.IsPrimary = false;
				  }
				}
	  
				  if (territory.nodes && territory.nodes.length > 0) {
					territory.nodes = this.selectIfTerritoryExists(territory.nodes, desc, index + 1,false,bParentNodeSelection,initialSelection);
				  }
				}
			  } else {
				territory.IsSelected = false;
				territory.IsPrimary = false;
				territory.nodes = this.selectIfTerritoryExists(territory.nodes, desc, index + 1, true,bParentNodeSelection,initialSelection);
			  }
	  
			  Territory[j] = territory;
			}
	  
			return Territory;
        },
    onChangeTerritories: function onChangeTerritories(oEvent) {
   if( this.bSelectPfc){
                this.aNonSelectableParentNode = false;
                const oModel = this.getView().getModel("selectedProfitCenter");
                const oTempEmployee = oModel.getProperty("/TempProfitCenter");
                let aTerritory = [];
                const aEmployeeTerritories = oTempEmployee.TempTreeTerritories;
                const iPrimaryIndex = aEmployeeTerritories.findIndex(function (item) {
                    return item.IsPrimary;
                });

                for (let i = 0; i < aEmployeeTerritories.length; i++) {
                    let territory = {};
                    territory.Desc = aEmployeeTerritories[i].Desc;
                    territory.guid = aEmployeeTerritories[i].guid;
                    territory.IsPrimary = aEmployeeTerritories[i].IsPrimary;
                    territory.id = aEmployeeTerritories[i].TrpcId;
                    territory.TrpcDesc = aEmployeeTerritories[i].Desc;
                    territory.isResourceProfile = aEmployeeTerritories[i].isResourceProfile;
                    territory.isCheckBox = aEmployeeTerritories[i].isCheckBox;
                    territory.isChildNodeEnable = aEmployeeTerritories[i].isChildNodeEnable;
                    territory.isParentNodeEnable = aEmployeeTerritories[i].isParentNodeEnable;
                    territory.GrpSelectable =aEmployeeTerritories[i].GrpSelectable;
                    territory.ParentGroupSelectable =aEmployeeTerritories[i].ParentGroupSelectable;

                    for (let j = 1; j <= 5; j++) {
                        territory["TrpcL" + j + "Desc"] = aEmployeeTerritories[i]["TrpcL" + j + "Desc"];
                    }

     const oTerritory =  Models._setProfitCenterObj(territory);
                    aTerritory.push(oTerritory);
                }

                oTempEmployee.Territories = aTerritory;
                let bIsFilter = this.getView().getModel("employee").getProperty("/isFilter");
                this.onCloseTerritoryValueHelpDialog();
                oModel.refresh(true);
                if (!bIsFilter) {
                    this._resetResourceProfile();
                    this.getView().getModel("selectedProfitCenter").setProperty("/selectedPfc", this.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories[0]);
                    appView.onCloseBusyDialog();
                } else {
                    //Git 314 => set profit center filter selection
                    this.getView().getModel("selectedProfitCenter").setProperty("/TempProfitCenter/TempTreeTerritories", this.getView().getModel("masterDataModel").getProperty("/TempProfitCenter/TempTreeTerritories"));
                    this.getView().getModel("selectedProfitCenter").refresh();
                    this.getFilterSummaryText();
                }
            } else {
                appView.onCloseBusyDialog();
                this.onCloseTerritoryValueHelpDialog();
            }
            var bEngType = this.getView().getModel().getData().EngagementType === '0002' ? false : true
        if(bEngType)
                this.getView().getModel("employee").setProperty(`/TempEmployee/TempRoles`, "");
        this.getView().getModel("employee").setProperty(`/fieldSelectionMidInfoIcon`,false);
        this.getView().getModel("employee").setProperty(`/BAIndustrySelectable`,bEngType);
        this.getView().getModel("employee").setProperty(`/SolnAreaMandatory`,false);
        this.getView().getModel("employee").setProperty(`/BAIndustryMandatory`,false);
        this.getView().getModel("employee").setProperty(`/SolnAreaSelectable`,bEngType);
        this.getView().getModel("employee").setProperty(`/SubRoleSelectable`, bEngType);
        this.getView().getModel("employee").setProperty(`/GrpSelectable`, this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter")?.Territories[0]?.GrpSelectable == 'X' ? true : false);        
        this.getView().getModel("employee").setProperty(`/minSelect`,0);
        this.getView().getModel("employee").setProperty(`/maxSelect`,2);
        this.getView().getModel("employee").setProperty(`/solnAreaEnable`,true);
        this.getView().getModel("employee").setProperty(`/industryEnable`,true);
        this.getView().getModel("employee").setProperty(`/solnIndRequired`,false);
        this.getView().getModel("employee").setProperty(`/GrpPanelExpanded`,false);
        this.getView().getModel("employee").setProperty(`/midSectionDesc`,this.getOwnerComponent().
                getModel("mrrAppConfigModel").getProperty("/SolnInd_SelectionText/0/fieldDesc"));
        this.getView().getModel("employee").setProperty(`/fieldSelectionMidInfoIcon`,false);
            this.oSearchAddSlnContext = [];
            this.oSLASearchContext = [];
            this._onEnableSearchResources();
        },
        getInstance: function getInstance() {
            if (!instance) {
                // create new instance of Application Object
                instance = new Application();
            }

            return instance;
        },
      loadTreeTerritories: function(type, results,bParentNodeSelection) {
   let aTerritories = []; 
   let aSlectedProfitCenter = this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories") ? this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories"):[];

   let _loop = function _loop(i) {
    if(results[i].isFiltered){
    let oCluster = aTerritories.find(function (item) {
     return item.TrpcL1Desc === results[i].TGlobal;
    });

    if (!oCluster && results[i].TGlobal && results[i].TGlobal !== "") {
     let oPCCluster = results.find(function (item) {
      return item.TrpcDesc.toUpperCase().trim() === results[i].TGlobal.toUpperCase().trim();
     });
     oCluster = {
      guid: oPCCluster.TrpcGuid,
      id: oPCCluster.TrpcId,
      isResourceProfile:oPCCluster.isResourceProfile,
      desc: results[i].TGlobal,
      TrpcDesc: oPCCluster.TrpcDesc,
      Name: oPCCluster.Name,
      displaydesc: results[i].TGlobal,
      IsPrimary: false,
      IsEnabled: false,
      IsSelected: false,
      bPrimaryRole: results[i].bPrimaryRole,
      bSelectedRole: results[i].bSelectedRole,
      isRadioBtVisible: results[i].isRadioBtVisible,
      isPrimary: results[i].isPrimary,
      nodes: [],
      LevelId: "0001",
      TrpcL1Desc: results[i].TGlobal,
      isCheckBox: oPCCluster.isCheckBox,
                        isParentNodeEnable: oPCCluster.isParentNodeEnable,
                        isChildNodeEnable: oPCCluster.isChildNodeEnable,
                        GrpSelectable: oPCCluster.GRP_Selectable,
                        ParentGroupSelectable: ""
     };
     if(aSlectedProfitCenter.length && aSlectedProfitCenter.SelectedGuid === results[i].TrpcGuid){
      oCluster.IsSelected = true;
     }
     aTerritories.push(oCluster);
     aTerritories.sort(function (a, b) {
      return a.desc.localeCompare(b.desc);
     });
    }

    if (oCluster) {
     let aL1 = oCluster.nodes;
     let oL1 = aL1.find(function (item) {
      return item.TrpcL2Desc === results[i].Region;
     });

     if (!oL1 && results[i].Region && results[i].Region !== "") {
      // const oPCL1 = results.find(item => item.Name.includes(results[i].Region));
      let oPCL1 = results.find(function (item) {
       return item.TrpcDesc.toUpperCase().trim() === results[i].Region.toUpperCase().trim();
      });
      oL1 = {
       guid: oPCL1.TrpcGuid,
       id: oPCL1.TrpcId,
       desc: results[i].Region,
       TrpcDesc: oPCL1.TrpcDesc,
       isResourceProfile:oPCL1.isResourceProfile,
       isCheckBox: oPCL1.isCheckBox,
                            isParentNodeEnable: oPCL1.isParentNodeEnable,
                            isChildNodeEnable: oPCL1.isChildNodeEnable,
       Name: oPCL1.Name,
       displaydesc: results[i].TGlobal + " > " + results[i].Region,
       IsPrimary: false,
       IsEnabled: false,
       IsSelected: false,
       bPrimaryRole: results[i].bPrimaryRole,
       bSelectedRole: results[i].bSelectedRole,
       isRadioBtVisible: results[i].isRadioBtVisible,
       isPrimary: results[i].isPrimary,
       nodes: [],
       LevelId: "0002",
       TrpcL1Desc: results[i].TGlobal,
       TrpcL2Desc: results[i].Region,
                            GrpSelectable: oPCL1.GRP_Selectable,
                            ParentGroupSelectable: oCluster.GrpSelectable
      };
      if(aSlectedProfitCenter.length && aSlectedProfitCenter.SelectedGuid === results[i].TrpcGuid){
       oL1.IsSelected = true;
      }
      aL1.push(oL1);
      aL1.sort(function (a, b) {
       return a.desc.localeCompare(b.desc);
      });
     }

     if (oL1) {
      let aL2 = oL1.nodes;
      let oL2 = aL2.find(function (item) {
       return item.TrpcL3Desc === results[i].Mu;
      });

      if (!oL2 && results[i].Mu && results[i].Mu !== "") {
       let oPCL2 = results.find(function (item) {
        return item.TrpcDesc.toUpperCase().trim() === results[i].Mu.toUpperCase().trim();
       });

       if (!oPCL2) {
        oPCL2 = results[i];
       }

       oL2 = {
        guid: oPCL2.TrpcGuid,
        id: oPCL2.TrpcId,
        isResourceProfile:oPCL2.isResourceProfile,
        isCheckBox: oPCL2.isCheckBox,
                                isParentNodeEnable: oPCL2.isParentNodeEnable,
                                isChildNodeEnable: oPCL2.isChildNodeEnable,
        desc: results[i].Mu,
        TrpcDesc: oPCL2.TrpcDesc,
        Name: oPCL2.Name,
        displaydesc: results[i].TGlobal + " > " + results[i].Region + " > " + results[i].Mu,
        IsPrimary: false,
        IsEnabled: false,
        IsSelected: false,
        bPrimaryRole: results[i].bPrimaryRole,
        bSelectedRole: results[i].bSelectedRole,
        isRadioBtVisible: results[i].isRadioBtVisible,
        isPrimary: results[i].isPrimary,
        nodes: [],
        LevelId: "0003",
        TrpcL1Desc: results[i].TGlobal,
        TrpcL2Desc: results[i].Region,
        TrpcL3Desc: results[i].Mu,
                                GrpSelectable: oPCL2.GRP_Selectable,
                                ParentGroupSelectable: oL1.GrpSelectable
       };
       if(aSlectedProfitCenter.length && aSlectedProfitCenter.SelectedGuid === results[i].TrpcGuid){
        oL2.IsSelected = true
       };
       aL2.push(oL2);
       aL2.sort(function (a, b) {
        return a.desc.localeCompare(b.desc);
       });
      }

      if (oL2) {
       let aL3 = oL2.nodes;
       let oL3 = aL3.find(function (item) {
        return item.TrpcL4Desc === results[i].MuBelow;
       });

       if (!oL3 && results[i].MuBelow && results[i].MuBelow !== "") {
        // const oPCL3 = results.find(item => item.Name.includes(results[i].MuBelow));
        let oPCL3 = results.find(function (item) {
         return item.TrpcDesc.toUpperCase().trim() === results[i].MuBelow.toUpperCase().trim();
        });

        if (!oPCL3) {
         oPCL3 = results[i];
        }

        oL3 = {
         guid: oPCL3.TrpcGuid,
         id: oPCL3.TrpcId,
         isResourceProfile:oPCL3.isResourceProfile,
         isCheckBox: oPCL3.isCheckBox,
                                    isParentNodeEnable: oPCL3.isParentNodeEnable,
                                    isChildNodeEnable: oPCL3.isChildNodeEnable,
         desc: results[i].MuBelow,
         TrpcDesc: oPCL3.TrpcDesc,
         Name: oPCL3.Name,
         displaydesc: results[i].TGlobal + " > " + results[i].Region + " > " + results[i].Mu + " > " + results[i].MuBelow,
         IsPrimary: false,
         IsEnabled: false,
         IsSelected: false,
         bPrimaryRole: results[i].bPrimaryRole,
         bSelectedRole: results[i].bSelectedRole,
         isRadioBtVisible: results[i].isRadioBtVisible,
         isPrimary: results[i].isPrimary,
         TrpcL1Desc: results[i].TGlobal,
         TrpcL2Desc: results[i].Region,
         TrpcL3Desc: results[i].Mu,
         TrpcL4Desc: results[i].MuBelow,
         nodes: [],
         LevelId: "0004",
                                    GrpSelectable: oPCL3.GRP_Selectable,
                                    ParentGroupSelectable: oL2.GrpSelectable
        };
        if(aSlectedProfitCenter.length && aSlectedProfitCenter.SelectedGuid === results[i].TrpcGuid){
         oL3.IsSelected = true;
        }
        aL3.push(oL3);
        aL3.sort(function (a, b) {
         return a.desc.localeCompare(b.desc);
        });
       }
      }
     }
    }
    }
   };
   
   for (let i = 0; i < results.length; i++) {
    _loop(i);
   }
   const oTreeTerritoriesModel = new sap.ui.model.json.JSONModel({
    type: type,
    territories: aTerritories,
    leadTerritories: aTerritories
   });
            var oModel = oTreeTerritoriesModel;
    var oData = oModel.getData();

    function updateNodes(nodes) {
        nodes.forEach(function (node) {
            node.isMargin = (!node.nodes || node.nodes.length === 0);

            if (node.nodes && node.nodes.length > 0) {
                updateNodes(node.nodes); 
            }
        });
    }
    if (oData.territories && oData.territories.length > 0) {
        updateNodes(oData.territories); 
    }

    oModel.setData(oData);
   this.getView().setModel(oTreeTerritoriesModel, "treeTerritories");
  },
        /*Search event for profit center view selection*/
        onSearchTerritory: function onSearchTerritory(oEvent) {
            const query = oEvent.getSource().getValue().trim();
            const TableId = oEvent.getSource().getParent().getParent();
            TableId.getBinding("rows").filter(query ? new Filter({
                path: "desc",
                operator: "Contains",
                value1: query
            }) : null);
            TableId.expandToLevel(query ? 99 : 0);
        },
        /*Open Business Area Industry Fragment*/
        onOpenBAIndustryValueHelpDialog: function (oEvent) {
            const that = this;
            const bIsFilter = this.getView().getModel("employee").getProperty("/isFilter");
            let sFragmentName = bIsFilter ? "com.dealsupport.melodyrequest.fragments.filter.industryFilter" :
                "com.dealsupport.melodyrequest.fragments.resourceProfile.BAIndustryValueHelpDialog"
            if (!this.pBAIndustryValueHelpDialog) {
                this.pBAIndustryValueHelpDialog = this.loadFragment({
                    name: sFragmentName
                });
                this.getView().getModel("employee").refresh();
                this._callBusinessAreaIndustryMasterData();
            } else {
                const oModel = this.getView().getModel("employee");
                if(bIsFilter){
                    that._callBusinessAreaIndustryMasterData();
                }
                if (oModel.getData().TempEmployee.BAIndustriesList) {
                    if (oModel.getData().TempEmployee.BAIndustriesList.length) {
                        oModel.setProperty(`/TempEmployee/BAIndustriesList`, oModel.getData().TempEmployee.BAIndustriesList);
                    }
                }
            }
            this.pBAIndustryValueHelpDialog.then(function (oDialog) {
                   that.getView().getModel("employee").setProperty("/sSearchBoxText", "");
                if (bIsFilter) {
                    //Git 313 filter dialog
                    let aIndData = that.getView().getModel("employee").getProperty("/TempEmployee/TempBAIndustries");
                    aIndData.length ? that.getView().getModel("employee").setProperty("/filter/dialogselIndVisible", true) :
                        that.getView().getModel("employee").setProperty("/filter/dialogselIndVisible", false);
                    let bSelected = aIndData && aIndData.length && aIndData[0].IsNonFocused ? true:false;
                    that.onChangeNonIndustryFocused(bSelected);
                    that.getView().getModel("employee").refresh();
                }
                that.getView().setModel(new sap.ui.model.json.JSONModel(), "masterDataModel");
                const oMasterDataModel = that.getView().getModel("masterDataModel");
                oMasterDataModel.setData(that.getView().getModel("employee").getData());
                that.getView().getModel("masterDataModel").refresh();
                that.filterBAIndustries();
                 that.getView().getModel("employee").getProperty("/isFilter") ? false : oDialog.setPlacement("Right");
                bIsFilter ? oDialog.open() : oDialog.openBy(oEvent.getSource());

            });
        },
      	//MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
		/*Open Solution Area  Fragment*/
		onOpenSLAPopOver: function (oEvent) {
            this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/results",[]);
			const that = this,
				 aSLAMasterData =   this.getOwnerComponent().getModel("SLAMasterDataL1").getData().results;
				 that.getView().setModel(new sap.ui.model.json.JSONModel(), "masterDataModel");
				const oMasterDataModel = that.getView().getModel("masterDataModel");
				if(this.oSLASearchContext){
					this.getView().getModel("employee").setProperty(`/TempEmployee/SolutionAreas`,this.oSLASearchContext)
				}
			if (this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`)) {
				this.oSLASearchContext = JSON.parse(JSON.stringify(this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`)));
			}
				oMasterDataModel.setData(that.getView().getModel("employee"));
				oMasterDataModel.refresh();
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",[]);
			if (!this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas/0`)) {
				//set defualy solution area L1
				//this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/selectedSolAreaL1",aSLAMasterData[0].SolGuid);
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",aSLAMasterData);
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA",false)
			}else if(this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas/0`)){
				//set selected solution area L1
				this.oContextSolutionArea = this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas/0`);
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/selectedSolAreaL1",
				this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas/0/soln_prnt_guid`));
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`));
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA",true)
			}
			this.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
			this.getView().getModel("employee").setProperty(`/TempEmployee/slaBusy`,true);
			if (!this.pSLAValueHelpDialog) {
				this.pSLAValueHelpDialog = this.loadFragment({
					name: "com.dealsupport.melodyrequest.fragments.resourceProfile.SolutionArea"
				});
			}
			this.pSLAValueHelpDialog.then(function (oDialog) {
				that.onAfterOpenSLAPopover();
				oDialog.setPlacement("Right");
				oDialog.openBy(oEvent.getSource());
				that.getView().getModel("employee").setProperty(`/TempEmployee/slaBusy`, false);
				if(that.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`)){
					that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",that.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`));
				}
				
				that.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
				that._OnUpdateSlaSelection();
                that.byId("idSolutionTreeOnCreate").getHeaderToolbar().getContent()[0].setValue("")
				that.onSearchSolutionArea(false)
			});
			this.getView().getModel("employee").refresh();
		},
		//MR: [GRP02-03] GTM25 Resource Profile alignment #84 end
        _callBusinessAreaIndustryMasterData: function () {
            const oModel = this.getView().getModel("employee");
            const oTempEmployee = oModel.getProperty("/TempEmployee");
            var that = this;
            const data = appView.getView().getModel("baIndMasterData").getData();

			if (data && data.d && data.d.results) {
				const aBAIndustry = data.d.results;
				oTempEmployee.BAIndustriesList = [];
				aBAIndustry.map((element, index, array) => {
					oTempEmployee.BAIndustriesList.push({
						Guid: element.BaIndGuid,
						ID: element.BaIndId,
						Desc: element.BaIndDesc,
						ClusterGuid: element.IndClstrGuid,
						ClusterDesc: element.IndClstrDesc,
						IsDefault: (element.DefaultSel && element.DefaultSel === "X") ? true : false,
						IsNonFocused: (element.DisplayGroup && element.DisplayGroup === "2") ? true : false,
						IsPrimary: false,
						IsEnabled: (element.DisplayGroup !== "4"),
						IsSelected: false,
						BaIndTechID: element.BaIndTechId,
						BaIndId: element.BaIndId
					});
				});
			}
			oTempEmployee.BAIndustriesList.sort((i, j) => i.ClusterDesc.localeCompare(j.ClusterDesc));
			oTempEmployee.BAIndustriesList.unshift(oTempEmployee.BAIndustriesList.splice(oTempEmployee.BAIndustriesList.findIndex(item => item.ID === "0025"), 1)[0]);
			oModel.refresh(true);
			that.filterBAIndustries();
        },

        /*Filter business area industries*/
        filterBAIndustries: function () {
            const oModel = this.getView().getModel("employee");
            const oTempEmployee = oModel.getProperty("/TempEmployee");
            oTempEmployee.BAIndustriesList  = oTempEmployee.BAIndustriesList ? oTempEmployee.BAIndustriesList:[];

            let aBAIndustries = [];
            aBAIndustries = JSON.parse(JSON.stringify(oTempEmployee.BAIndustriesList));

            let aEmployeeBAIndustries = JSON.parse(JSON.stringify(oModel.getProperty("/TempEmployee/BAIndustries")));
            oModel.setProperty("/NonIndustryFocused", {
                Guid: "",
                IsSelected: false,
                IsVisible: false
            });
            aBAIndustries.map(function (element, index, array) {
                const oEmployeeBAIndustry = aEmployeeBAIndustries.find(item => item.Guid === element.Guid);
                if (oEmployeeBAIndustry) {
                    element.IsSelected = true;
                    element.IsPrimary = false;
                    oEmployeeBAIndustry.ClusterGuid = element.ClusterGuid;
                    oEmployeeBAIndustry.ClusterDesc = element.ClusterDesc;
                    oEmployeeBAIndustry.BaIndTechID = element.BaIndTechID;
                    oEmployeeBAIndustry.BaIndId = element.BaIndId;
                } else {
                    element.IsSelected = false;
                    element.IsPrimary = false;
                }
                if (element.IsNonFocused) {
                    oModel.setProperty("/NonIndustryFocused", {
                        Guid: element.Guid,
                        IsSelected: false,
                        IsVisible: true
                    });
                    if (oEmployeeBAIndustry && oEmployeeBAIndustry.Guid === element.Guid) {
                        aEmployeeBAIndustries = [{
                            Guid: element.Guid,
                            Desc: element.Desc,
                            IsPrimary: false,
                            IsNonFocused: true,
                            ID: element.ID
                        }];
                        oModel.setProperty("/NonIndustryFocused", {
                            Guid: element.Guid,
                            IsSelected: true,
                            IsVisible: true,
                            ID: element.ID
                        });
                    }
                }
            });
            let aFilteredEmployeeBAIndustries = JSON.parse(JSON.stringify(aEmployeeBAIndustries));
            for (let i = 0; i < aEmployeeBAIndustries.length; i++) {
                const iIndex = aBAIndustries.findIndex(item => item.Guid === aEmployeeBAIndustries[i].Guid);
                if (iIndex === -1) {
                    aFilteredEmployeeBAIndustries = aFilteredEmployeeBAIndustries.filter(item => item.Guid !== aEmployeeBAIndustries[i].Guid);
                }
            }
            oModel.setProperty("/TempEmployee/BAIndustries", aFilteredEmployeeBAIndustries);
            oModel.setProperty("/TempEmployee/TempBAIndustries", JSON.parse(JSON.stringify(oTempEmployee.BAIndustries)));
            oModel.setProperty("/BAIndustries", aBAIndustries);
            oModel.refresh(true);
        },
        /*Load Role type master data*/
      loadRoleTypeData: function (type, results) {
            // MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
            // get IAC (Internal Account Classification) and Role, Role Area mapping #git84
            this.oSLASearchContext = false;
            this.oSearchAddSlnContext = false;
            this.getView().setModel(new sap.ui.model.json.JSONModel([]), "IACRoleAreaModel");
            sap.ui.core.BusyIndicator.show();
            this.getOwnerComponent().getModel("appConstants").setProperty("/IAC_ENABLE/0/isIACQueryRemove", false);
            const isIACEnabled = this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/Operational_Status");
            const sSelectedRoleAreaId = this.getView().getModel().getProperty("/aResourceProfileApprovers/ResourceProfileDetails/RoleArea_P_GUID/ID");
            const oSelectedSubRole = this.getView().getModel().getProperty("/aResourceProfileApprovers/ResourceProfileDetails/Role_GUID/SelectedSubRole");
            const ointicSystemModel = Models.systeminticDataModel(this);
            const oResourcesSystemModel = Models.systemResourcesDataModel(this);
            const oEmployeeModel  = this.getView().getModel("employee");
            const that = this;
       
            const handleError = function (oError) {
                sap.ui.core.BusyIndicator.hide();
                ErrorHandle.setErrorMessage(oError, that);
            };
       
            const processRoleAreaData = function (data) {
                sap.ui.core.BusyIndicator.hide();
                that.getView().getModel("IACRoleAreaModel").setData(data.results);
       
                const i18nModel = that.getOwnerComponent().getModel("i18n").getResourceBundle();
                const aIACRoleArea = that.getView().getModel("IACRoleAreaModel").getData();
                var sEngType = that.getView().getModel().getData().EngagementType
                if (!aIACRoleArea.length && isIACEnabled) {
                    let sUrlParams = {
                        $filter: `EngTypeId eq '${sEngType}' and IacDesc eq 'Non-IAC Focused' and RequestType eq '${that.getView().getModel().getProperty("/RequestType")}'`,
                        $expand: 'to_rolemap,to_subrolemap'
                    };
                    that.getOwnerComponent().getModel("appConstants").setProperty("/IAC_ENABLE/0/isIACQueryRemove", true);
                Models._callGETOdata(oResourcesSystemModel, "/YC_MR_M_IAC_ACV_RAMAP", sUrlParams)
                    .then(processRoleAreaData)
                    .catch(handleError);
                return;
                }
                const aFilteredRoleRoleArea = [];
       
                aIACRoleArea.forEach(function (item) {
                    let aIACRoleAreaList = item.to_rolemap.results;
                    let aIACRoleAreaSubList = item.to_subrolemap.results;
                    let aRolesData = [];
                    let aSubst = [];
                    aIACRoleAreaSubList.forEach(function (sub) {
                        let oSubst = {
                            "RoleID": sub.RoleSubstitute_ID,
                            "RoleAreaID": sub.RoleAreaSubstitute_ID,
                            "RoleDesc": sub.RoleSubstitute_Desc
                        }
                        aSubst.push(oSubst);
                    });
                    item.aSubstituteRoleRoleArea = aSubst;
                    aIACRoleAreaList.forEach(function (rolesData) {
                        let oRolesList = {
                            "RoleID": rolesData.Role_ID,
                            "RoleDesc": rolesData.Role_Desc,
                            "RoleAreaID": item.RoleAreaId
                        }
                        aRolesData.push(oRolesList);
                    });
                    item.RolesData = aRolesData;
                });
                aIACRoleArea.forEach(function (data) {
                   let aRoleMasterWithoutDuplicates = {
                        "RoleID": data.to_rolemap.results[0].Role_ID,
                        "RoleDesc": data.to_rolemap.results[0].Role_Desc,
                        "RolesData": data.RolesData,
                        "RoleAreaID": data.RoleAreaId,
                        "RoleAreaDesc": data.RoleAreaDesc,
                        "minSelect": Number(data.MinSelect),
                        "maxSelect": Number(data.MaxSelect),
                       "SolnAreaMandatory": data.SolnAreaMandatory,
                       "SolnAreaSelectable": data.SolnAreaSelectable == 'X' ? true : false,
                       "BAIndustryMandatory": data.BAIndustryMandatory,
                       "BAIndustrySelectable": data.BAIndustrySelectable == 'X' ? true : false,
                       "SubRoleSelectable": sEngType == '0002' ? false : true,
                        "aSubstituteRoleRoleArea": data.aSubstituteRoleRoleArea,
                        // "SelectedRoleDesc": data.RolesData.map(obj=>{return obj.RoleDesc}).join(", "),
                        "RoleAreas": [
                            {
                                "ID": data.RoleAreaId,
                                "Desc": data.RoleAreaDesc,
                                "RoleDesc": data.to_rolemap.results[0].Role_Desc
                            }
                        ],
                        "ID": data.to_rolemap.results[0].Role_ID,
                        "Desc": data.to_rolemap.results[0].Role_Desc
                    }
                   // aRoleMasterWithoutDuplicates.subStituteRoleRoleArea = aSubstituteRoleRoleArea;
                    //preselected RoleArea details
                    if (data.RoleAreaId === sSelectedRoleAreaId) {
                        oEmployeeModel.setProperty("/TempEmployee/TempRoleAreas", aRoleMasterWithoutDuplicates.RoleAreas);
                        oEmployeeModel.setProperty("/TempEmployee/TempRoles", aRoleMasterWithoutDuplicates);
                        oSelectedSubRole && Object.keys(oSelectedSubRole).length && oSelectedSubRole['active'] ? oEmployeeModel.setProperty("/TempEmployee/TempRoles/SelectedSubRole", oSelectedSubRole) : oEmployeeModel.setProperty("/TempEmployee/TempRoles/SelectedSubRole", { "active": false });
                        oEmployeeModel.setProperty("/TempEmployee/RoleAreas", aRoleMasterWithoutDuplicates.RoleAreas);
                        oEmployeeModel.setProperty("/TempEmployee/Roles", [aRoleMasterWithoutDuplicates]);
                        that._setResValidation(aRoleMasterWithoutDuplicates);
                        let oSelectParams = {
                            "minSelect": that.getView().getModel("employee").getProperty(`/minSelect`),
                            "maxSelect": that.getView().getModel("employee").getProperty(`/maxSelect`),
                        }
                        
                        if(that.getView().getModel("employee").getProperty(`/maxSelect`) === 1 && that.getView().getModel("employee").getProperty("/TempEmployee/BAIndustries").length &&  that.getView().getModel("employee").getProperty("/TempEmployee/SolutionAreas").length){
                            that.getView().getModel("employee").setProperty("/TempEmployee/SolutionAreas",[]);
                             that.getView().getModel("employee").setProperty("/TempEmployee/AdditionalSolutions",[]);
                            that.getView().getModel("employee").setProperty("/TempEmployee/TempBAIndustries", []);
                            that.getView().getModel("employee").setProperty("/TempEmployee/BAIndustries", []);
                        }else if( that.getView().getModel("employee").getProperty(`/maxSelect`) === 1 &&  that.getView().getModel("employee").getProperty("/TempEmployee/BAIndustries").length && !that.getView().getModel("employee").getProperty("/TempEmployee/SolutionAreas").length){
                            oSelectParams.bIndustry = true;
                            that._onManageIndSolSelection(oSelectParams); 
                        } else if( that.getView().getModel("employee").getProperty(`/maxSelect`) === 1 && !that.getView().getModel("employee").getProperty("/TempEmployee/BAIndustries").length &&  that.getView().getModel("employee").getProperty("/TempEmployee/SolutionAreas").length){
                            oSelectParams.bIndustry = false;
                            that._onManageIndSolSelection(oSelectParams);
                        }else{
                            that.getView().getModel("employee").setProperty(`/solnAreaEnable`,true);
                            that.getView().getModel("employee").setProperty(`/industryEnable`,true);
                        }
                        that._setSearchFieldText();  
                        that._onEnableSearchResources(oSelectParams);
                    }else{
                        oEmployeeModel.setProperty("/SelectedRoleKey", "");
                        that.getView().getModel().setProperty("/isRoleAreaSelection",true)
                    }
                    aFilteredRoleRoleArea.push(aRoleMasterWithoutDuplicates);
                });
       
                ["roleMasterWithoutDuplicate", "roleMaster", "roleAreas"].forEach(function (key) {
                    that.fnMasterDataSuccess(key, aFilteredRoleRoleArea);
                });
       
                // if (!that.getOwnerComponent().getModel("SolutionAreaMasterData").getData().solHierarchy.length) {
                    Models.getSolutionAreaMasterData(that)
                // }
            };
       
            const fetchRoleAreaMapping = function (IAC) {
                let sUrlParams;
                var sEngagementType = that.getView().getModel().getData().EngagementType
                if (isIACEnabled && IAC) {
                    sUrlParams = {
                        $filter: `EngTypeId eq '${sEngagementType}' and IacDesc eq '${IAC}' and RequestType eq '${that.getView().getModel().getProperty("/RequestType")}'`,
                        $expand: 'to_rolemap,to_subrolemap'
                    };
                } else {
                    sUrlParams = {
                        $filter: `EngTypeId eq '${sEngagementType}' and IacDesc eq 'Non-IAC Focused' and RequestType eq '${that.getView().getModel().getProperty("/RequestType")}'`,
                        $expand: 'to_rolemap,to_subrolemap'
                    };
                    that.getOwnerComponent().getModel("appConstants").setProperty("/IAC_ENABLE/0/isIACQueryRemove", true);
                }
                Models._callGETOdata(oResourcesSystemModel, "/YC_MR_M_IAC_ACV_RAMAP", sUrlParams)
                .then(processRoleAreaData)
                .catch(handleError);          
            };
       
            const accountDesc = this.getView().getModel().getProperty("/aResourceProfileApprovers/IAC/0/IAC_Desc");
       
            if (isIACEnabled && (!accountDesc || accountDesc === "Non-IAC Focused")) {
                Models._callGETOdata(ointicSystemModel, `/BusinessPartnerAttribSet('${this.getView().getModel().getProperty("/accountId")}')`)
                    .then(function (data) {
                        const IAC = data.TG_ACCOUNT_DESC ? data.TG_ACCOUNT_DESC.trim() : "";
                        fetchRoleAreaMapping(IAC);
                    })
                    .catch(handleError);
            } else {
                that.getOwnerComponent().getModel("appConstants").setProperty("/IAC_ENABLE/0/isIACQueryRemove", true);
                const defaultIAC = accountDesc;
                fetchRoleAreaMapping(defaultIAC);
            }
            // MR: [GRP02-03] GTM25 Resource Profile alignment #84 end
        },
        fnMasterDataSuccess: function (sModelName, aResults) {
            this.getView().setModel(new sap.ui.model.json.JSONModel(), sModelName);
            const oModel = this.getView().getModel(sModelName);
            oModel.setData(aResults);  
            if (sModelName == "roleAreas") {
                let aUpdatedRolesData = aResults.filter(item => item.RoleAreaID == this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RoleAreaID);
                this.getView().setModel(new sap.ui.model.json.JSONModel(), "subRole");
                const oSubRoleModel = this.getView().getModel("subRole");
                const primaryRoleIDSet = new Set(aUpdatedRolesData[0].RolesData.map(item => item.RoleID));
                const filteredSubstitueRoles = aUpdatedRolesData[0].aSubstituteRoleRoleArea.filter(item => !primaryRoleIDSet.has(item.RoleID));
                oSubRoleModel.setData([...aUpdatedRolesData[0].RolesData, ...filteredSubstitueRoles]);

            }          
        },
        /*Search event for business area industies*/
        onSearchBAIndustry: function (oEvent) {
            let sQuery = "";
            if (oEvent) {
                sQuery = oEvent.getSource().getValue();
            }
            let allFilter = [];
            if (sQuery && sQuery.length > 0) {
                const oFilter1 = new sap.ui.model.Filter("Desc", sap.ui.model.FilterOperator.Contains, sQuery);
                const oFilter2 = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.Contains, sQuery);
                const oFilter3 = new sap.ui.model.Filter("ClusterDesc", sap.ui.model.FilterOperator.Contains, sQuery);
                allFilter = new sap.ui.model.Filter([oFilter1, oFilter2, oFilter3], false);
            }
            this.fnFilterNonFocusedTableData(sQuery, "baIndustrytableId", allFilter);
        },
        /*Select event for business area industries*/
        onSelectBAIndustry: function (oEvent) {
            const oSource = oEvent.getSource();
            const oBinding = oSource.getBindingInfo("selected").binding;
            const oContext = oBinding.getContext();
            const oModel = oContext.getModel();
            const oBAIndustry = oModel.getProperty(oContext.getPath());
            const bSelected = oEvent.getParameter("selected");
            const aBAIndustries = oModel.getProperty("/BAIndustries");
            let aEmployeeBAIndustries = oModel.getProperty("/TempEmployee/TempBAIndustries");
            const iIndex = aEmployeeBAIndustries.findIndex(item => item.Guid === oBAIndustry.Guid);
            const oEmpModel = this.getView().getModel("employee");
            const bIsFilter = oEmpModel.getProperty("/isFilter");
            if (!bIsFilter) {
                aBAIndustries.forEach(item => item.IsSelected = false);
                aEmployeeBAIndustries.length = 0;
                oBAIndustry.IsSelected = true;
            }
            if (bSelected) {
                aEmployeeBAIndustries.push({
                    Guid: oBAIndustry.Guid,
                    Desc: oBAIndustry.Desc,
                    ClusterGuid: oBAIndustry.ClusterGuid,
                    ClusterDesc: oBAIndustry.ClusterDesc,
                    IsPrimary: true,
                    BaIndTechID: oBAIndustry.BaIndTechID,
                    BaIndId: oBAIndustry.BaIndId,
                    IsSelected: true
                });
                aEmployeeBAIndustries = aEmployeeBAIndustries.filter((obj, index, self) =>
                    index === self.findIndex(o => o.Guid === obj.Guid)
                );
            } else if (!oEvent.getSource().getGroupName) {
                aBAIndustries.forEach(function (item) {
                    if (item.Guid !== oBAIndustry.Guid) {
                       item.IsSelected = item.IsSelected
                    }else{
                         item.IsSelected = false;
                    }
                });
                aEmployeeBAIndustries = aEmployeeBAIndustries.length ? aEmployeeBAIndustries.filter(function (item) {
                    return item.Guid !== oBAIndustry.Guid;
                }) : [];
            }
            if (bIsFilter) {
                oModel.setProperty("/TempEmployee/TempBAIndustries",aEmployeeBAIndustries);
                let aIndData = this.getView().getModel("masterDataModel").getProperty("/TempEmployee/TempBAIndustries");
                aIndData.length ? this.getView().getModel("employee").setProperty("/filter/dialogselIndVisible", true) :
                    this.getView().getModel("employee").setProperty("/filter/dialogselIndVisible", false)

            }
            oModel.refresh(true);

        },
        /*Select All Business area industy*/
        onSelectAllBAIndustry: function (oEvent) {
            const oModel = this.getView().getModel("employee");
            const bSelected = oEvent.getParameter("selected");
            let aBAIndustries = oModel.getProperty("/BAIndustries");
            let aEmployeeBAIndustries = [];
            aBAIndustries.map(function (item) {
                item.IsSelected = bSelected;
                item.IsPrimary = (bSelected === true && item.IsPrimary === true) ? true : false;
                if (bSelected && item.IsNonFocused === false) {
                    aEmployeeBAIndustries.push({
                        Guid: item.Guid,
                        Desc: item.Desc,
                        ClusterGuid: item.ClusterGuid,
                        ClusterDesc: item.ClusterDesc,
                        IsPrimary: false,
                        BaIndTechID: item.BaIndTechID,
                        BaIndId: item.BaIndId
                    });
                }
            });
            oModel.setProperty("/TempEmployee/TempBAIndustries", aEmployeeBAIndustries);
            oModel.refresh(true);
        },
        /*Update business area industries*/
        onChangeBAIndustries: function (oEvent) {
            const oModel = this.getView().getModel("employee");
            const aEmployeeBAIndustries = oModel.getProperty("/TempEmployee/TempBAIndustries");
            oModel.setProperty("/TempEmployee/BAIndustries", JSON.parse(JSON.stringify(aEmployeeBAIndustries)));
            this.onCloseBAIndustryValueHelpDialog();
            let oSelectParams = {
				"bIndustry":true,
				"minSelect":oModel.getProperty(`/minSelect`),
				"maxSelect":oModel.getProperty(`/maxSelect`),
			}
			this._onManageIndSolSelection(oSelectParams);
            this._onEnableSearchResources(oSelectParams);
            this._setSearchFieldText();
        },
        	//manage selection for industry and solution area
		_onManageIndSolSelection:function(oSelectParams,bDelete){
			let oModel =  this.getView().getModel("employee");
			if(oSelectParams["maxSelect"] === 1 && !bDelete){
				oSelectParams["bIndustry"] ? oModel.setProperty(`/solnAreaEnable`,false) : 
				oModel.setProperty(`/industryEnable`,false);
			}else if(oSelectParams["maxSelect"] === 2 || bDelete){
				oModel.setProperty(`/solnAreaEnable`,true);
				oModel.setProperty(`/industryEnable`,true);
			}
			if (oModel.getProperty(`/industryEnable`) && oSelectParams["maxSelect"] === 1 && !bDelete) {
				oModel.setProperty(`/TempEmployee/SolutionAreas`, [])
			} else if (oSelectParams["maxSelect"] === 1 && bDelete) {
				oModel.setProperty(`/TempEmployee/BAIndustries`, []);
				this.getView().getModel("employee").setProperty(`/TempEmployee/TempBAIndustries`, []);
			}
			oModel.refresh();
		},
        /*Close business area industries fragment*/
        onCloseBAIndustryValueHelpDialog: function () {
            const oModel = this.getView().getModel("masterDataModel");
			const aEmployeeBAIndustries = oModel.getProperty("/TempEmployee/BAIndustries");
			const oEmployeeModel = this.getView().getModel("employee");
			oEmployeeModel.setProperty(`/TempEmployee/TempBAIndustries`, JSON.parse(JSON.stringify(aEmployeeBAIndustries)));
            this.getView().getModel("employee").setProperty("/sSearchBoxText", "");
            var that = this;
            this.pBAIndustryValueHelpDialog.then(function (oDialog) {
                that.onSearchBAIndustry();
                oDialog.close();

            });
        },
         /*Change selection to NonIndustyFoused*/
        onChangeNonIndustryFocused: function (oEvent) {
            const oModel = this.getView().getModel("employee");
            const bSelected = typeof oEvent === 'object'  ? oEvent.getParameter("state"):oEvent;
            const aBAIndustries = oModel.getProperty("/BAIndustries");
            let oMasterDataModel = this.getView().getModel("masterDataModel");
            let oNonIndustryFocused;
            aBAIndustries.map(function (element, index, array) {
                if (bSelected && element.IsNonFocused) {
                    element.IsSelected = true;
                    element.IsPrimary = true;
                    oNonIndustryFocused = element;
                } else {
                    element.IsSelected = false;
                    element.IsPrimary = false;
                }
            });

            if (bSelected && oNonIndustryFocused) {
                oModel.setProperty("/TempEmployee/TempBAIndustries", [{
                    Guid: oNonIndustryFocused.Guid,
                    Desc: oNonIndustryFocused.Desc,
                    IsPrimary: false,
                    IsNonFocused: true,
                    BaIndTechID: oNonIndustryFocused.ID,
                    BaIndId: oNonIndustryFocused.ID
                }]);
                if (oMasterDataModel) {
                    oMasterDataModel.setProperty("/TempEmployee/TempBAIndustries", [{
                        Guid: oNonIndustryFocused.Guid,
                        Desc: oNonIndustryFocused.Desc,
                        IsPrimary: false,
                        IsNonFocused: true,
                        BaIndTechID: oNonIndustryFocused.ID,
                        BaIndId: oNonIndustryFocused.ID
                    }]);
                }

                oModel.setProperty("/NonIndustryFocused", {
                    Guid: oNonIndustryFocused.Guid,
                    IsSelected: true,
                    IsVisible: true
                });
            } else {
                if (typeof oEvent === 'object') {
                    oModel.setProperty("/TempEmployee/TempBAIndustries", []);
                    if (oMasterDataModel) {
                        oMasterDataModel.setProperty("/TempEmployee/TempBAIndustries", []);
                    }
                }

                oModel.setProperty("/NonIndustryFocused", {
                    Guid: "",
                    IsSelected: false,
                    IsVisible: true
                });
            }
            if (typeof oEvent === 'object') {
                bSelected ? oModel.setProperty("/filter/dialogselIndVisible", true) : oModel.setProperty("/filter/dialogselIndVisible", false);
            }
            oModel.refresh(true);
            if( this.getView().getModel("masterDataModel")){
              this.getView().getModel("masterDataModel").refresh(true);
            }
        },
        /*Reset profit center master data model*/
        onResetProfitCenterSelection: function () {
            this.selectIfTerritoryExists(this.getView().getModel("treeTerritories").getData().territories, [], 0, true);
          this.getView().getModel("treeTerritories").refresh();
			this.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.TempTreeTerritories = [];
			this.getView().getModel("selectedProfitCenter").refresh();
        },
        fnFilterNonFocusedTableData: function (sQuery, tableId, allFilter) {
            const oNonFocusedFilter = new sap.ui.model.Filter("IsNonFocused", sap.ui.model.FilterOperator.EQ, false);
            const aFilters = new sap.ui.model.Filter([allFilter, oNonFocusedFilter], true);
            this.getView().byId(tableId).getBinding().filter(aFilters);
        },
        /*Enable Search Resources button*/
        _onEnableSearchResources: function (oSelectedParams) {
            const oModel = this.getView().getModel("employee");
            const oTempEmployee = oModel.getProperty("/TempEmployee");
            const oSearchItem = oModel.getData();
            let sSelectedPfc = this.getView().getModel("selectedProfitCenter")? this.getView().getModel("selectedProfitCenter").getData().selectedPfc:"";
            if(this.getView().getModel().getData().EngagementType=='0002' && sSelectedPfc && oSearchItem.SelectedRoleAreasKey!=""){
				oModel.setProperty(`/isValidation`, true);
			}else{
            if ((sSelectedPfc && oTempEmployee["TempRoles"] && oTempEmployee.TempRoles.RoleAreaID && (!oSearchItem.SolnAreaMandatory || !oSearchItem.SolnAreaSelectable) &&
                (!oSearchItem.BAIndustryMandatory || !oSearchItem.BAIndustryMandatory)) || (sSelectedPfc && oTempEmployee["TempRoles"] && oTempEmployee.TempRoles.RoleAreaID && (oSearchItem.SolnAreaMandatory && oTempEmployee.SolutionAreas.length) &&
                    (oSearchItem.BAIndustryMandatory && oTempEmployee.BAIndustries.length)) ||
                (sSelectedPfc && oTempEmployee["TempRoles"] && oTempEmployee.TempRoles.RoleAreaID && oTempEmployee.TempRoles.RoleAreaID && (!oSearchItem.SolnAreaMandatory || !oSearchItem.SolnAreaSelectable) &&
                    (oSearchItem.BAIndustryMandatory && oTempEmployee.BAIndustries.length)) ||
                (sSelectedPfc && oTempEmployee["TempRoles"] && oTempEmployee.TempRoles.RoleAreaID && (oSearchItem.SolnAreaMandatory && oTempEmployee.SolutionAreas.length) && (!oSearchItem.BAIndustryMandatory || !oSearchItem.BAIndustryMandatory))) {
                //if industry and solution area optional or non selectable enable create draft
                oModel.setProperty(`/isValidation`, true);
            } else {
                oModel.setProperty(`/isValidation`, false);
            }
            if(!oSelectedParams && oModel.getProperty(`/isValidation`) && this.getView().getModel("employee").getProperty(`/minSelect`) !== 0){
				oModel.setProperty(`/isValidation`, false);
			}
			if((oSelectedParams && oModel.getProperty(`/isValidation`) && oSelectedParams["minSelect"] == 1 && (!oTempEmployee.BAIndustries.length && !oTempEmployee.SolutionAreas.length)) || (oSelectedParams && oModel.getProperty(`/isValidation`) && oSelectedParams["minSelect"] == 2 && (!oTempEmployee.BAIndustries.length || !oTempEmployee.SolutionAreas.length))){
				oModel.setProperty(`/isValidation`, false);
			}
        }
            this.getView().getModel("profileViewParameters").setProperty
            ("/footerButtons/searchResourceButtonEnabled", oModel.getProperty(`/isValidation`));
        },
        /*Select event for Roles*/
        onRoleChange: function (oEvent) {
            const oSource = oEvent.getSource();
            const oModel = this.getView().getModel("employee");
            const oSelectectedItem = oSource.getSelectedItem();
            const oTempEmployee = oModel.getProperty("/TempEmployee");
            const oSubRoleModel = this.getView().getModel("subRole");
            let tempRoleArea = [];
            if (oSelectectedItem) {
                const oContext = oSelectectedItem.getBindingContext("roleAreas");
                const oRoleModel = oContext.getModel();
                const oRole = oRoleModel.getProperty(oContext.getPath());
                const oContextObj = oContext.getObject();
                //set field config based on role area
                this._setResValidation(oContextObj);
                oTempEmployee.Roles.push(oRole)
                tempRoleArea.push(...oRole.RoleAreas);
                this.getView().getModel("employee").setProperty("/TempEmployee/TempRoles", oRole)
                //GIT 342 - Populate the role drop down values based on selected role area
                this.getView().getModel("employee").setProperty("/TempEmployee/TempRoles/SelectedSubRole", {"active":false})
                const primaryRoleIDSet = new Set(oContextObj.RolesData.map(item => item.RoleID));
                const filteredSubstitueRoles = oContextObj.aSubstituteRoleRoleArea.filter(item => !primaryRoleIDSet.has(item.RoleID));
                oSubRoleModel.setData([...oContextObj.RolesData, ...filteredSubstitueRoles]);
                // oSubRoleModel.setData(oContextObj.RolesData); 
                oSubRoleModel.refresh(true);
                this.getView().getModel("employee").setProperty("/SelectedSubRoleKey", "");

            } else {
                var bEngType = this.getView().getModel().getData().EngagementType == '0002' ? false : true
                this.getView().getModel("employee").setProperty(`/BAIndustryMandatory`, false);
                this.getView().getModel("employee").setProperty(`/BAIndustrySelectable`, bEngType);
                this.getView().getModel("employee").setProperty(`/SolnAreaSelectable`, bEngType);
                this.getView().getModel("employee").setProperty(`/SubRoleSelectable`, bEngType);
                this.getView().getModel("employee").setProperty(`/fieldSelectionMidInfoIcon`, false);
                this.getView().getModel("employee").setProperty(`/minSelect`, 0);
                this.getView().getModel("employee").setProperty(`/maxSelect`, 2);
                this.getView().getModel("employee").setProperty(`/midSectionDesc`, appView.getOwnerComponent().
                    getModel("mrrAppConfigModel").getProperty("/SolnInd_SelectionText/0/fieldDesc"));
                this.getView().getModel("employee").setProperty(`/TempEmployee/TempRoles`, []);
                this.getView().getModel("employee").setProperty(`/solnIndRequired`, false);
                oSubRoleModel.setData([]);
                oSubRoleModel.refresh(true);
                this.getView().getModel("employee").setProperty("/SelectedSubRoleKey", "");

            }
            this.getView().getModel("employee").setProperty(`/TempEmployee/BAIndustries`, []);
            this.getView().getModel("employee").setProperty(`/TempEmployee/SolutionAreas`, []);
            this.getView().getModel("employee").setProperty(`/TempEmployee/AdditionalSolutions`, []);
            this.oSearchAddSlnContext = [];
            this.oSLASearchContext = [];
            this.getView().getModel("employee").setProperty(`/TempEmployee/Materials`, []);
            this.getView().getModel("employee").setProperty(`/TempEmployee/TempBAIndustries`, []);
            this.getView().getModel("employee").setProperty(`/TempEmployee/SolutionAreas`, []);
            this.getView().getModel("employee").setProperty(`/solnAreaEnable`, true);
            this.getView().getModel("employee").setProperty(`/industryEnable`, true);
            let aNewRoleArea = [];
            let map = new Map();
            for (let item of tempRoleArea) { //Removing dupliated from aray..
                if (!map.has(item.Guid)) {
                    map.set(item.Guid, true);
                    aNewRoleArea.push(item);
                }
            }
            oModel.setProperty("/SelectedRoleAreasKey", "");
            if (aNewRoleArea && aNewRoleArea.length === 1) {
                oTempEmployee.RoleAreas.push(aNewRoleArea[0]);
                oModel.setProperty("/SelectedRoleAreasKey", aNewRoleArea[0].ID);
            }
            oModel.setProperty("/aRoleAreas", aNewRoleArea);
            oModel.refresh(true);
            this.getView().getModel("employee").setProperty("/TempEmployee/TempRoleAreas", aNewRoleArea);
            this._setSearchFieldText();
            this._onEnableSearchResources();
        },
        /*Select event for Role area*/
        onRoleAreaChange: function (oEvent) {
            const oSource = oEvent.getSource();
            const oModel = this.getView().getModel("employee");
            const oSelectectedItem = oSource.getSelectedItem();
            const oTempEmployee = oModel.getProperty("/TempEmployee");
            let tempRoleArea = [];
            if (oSelectectedItem) {
                const oContext = oSelectectedItem.getBindingContext("employee");
                const oRoleAreaModel = oContext.getModel();
                const oRoleArea = oRoleAreaModel.getProperty(oContext.getPath());
                oTempEmployee.RoleAreas.push(oRoleArea)
                this.getView().getModel("employee").setProperty("/TempEmployee/TempRoleAreas", [oRoleArea])
            }
            oModel.refresh(true);
            this._onEnableSearchResources();
        },
        /*Forward the Request to submit the updated context*/
        onForwardRequest: function (sSelection) {
            const oProcessContext = this.getView().getModel().getData();
            const taskId = this.sUserTaskId;;
            this._triggerComplete(oProcessContext, taskId, "Forward", false, this.isResourceProfile, sSelection);
        },
        /*Token updated delete Business Area Industry*/
        onDeleteBAIndToken: function (oEvent) {
            const oModel = this.getView().getModel("employee");
            const oTempEmployee = oModel.getProperty("/TempEmployee");
            const bIsFilter = oModel.getProperty("/isFilter");
            const oParameters = oEvent.getParameters();
            if (oParameters.type === "removed") {
                const aTokens = oParameters.removedTokens;
                for (let i = 0; i < aTokens.length; i++) {
                    const iIndex = oTempEmployee.BAIndustries.findIndex(item => item.Guid === aTokens[i].getKey());
                    if (iIndex !== -1) {
                        oTempEmployee.BAIndustries.splice(iIndex, 1);
                        oTempEmployee.TempBAIndustries = oTempEmployee.BAIndustries;
                        oModel.refresh(true);
                    }
                }
            }
            let oSelectParams = {
				"bIndustry":true,
				"minSelect":oModel.getProperty(`/minSelect`),
				"maxSelect":oModel.getProperty(`/maxSelect`),
			}
            if (!bIsFilter) {
                this._onManageIndSolSelection(oSelectParams, true)
                this._setSearchFieldText();
                this._onEnableSearchResources(oSelectParams);
            }else{
                this.getFilterSummaryText();
            }
        },
        /*Set ORE Service Url for search managers*/
        _getOREServiceUrl: function (ApproversOREUrl, sProfitcenter, sSearchOre, isSubsFlag) {
            const sProfitCenterId = this.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories.length ? this.getView().getModel("selectedProfitCenter").getData().
                TempProfitCenter.Territories[0].TrpcId : this.getView().getModel("selectedProfitCenter").getData().
                    filteredProfitCenter[0].TrpcId;

            const filterValues = {
                "ProfitCenterGUID": sProfitCenterId,
                "Manager_Level": "non-managerial",
                "aRoles": this.getView().getModel("employee").getProperty(`/TempEmployee/TempRoles`).RolesData,
                "aSubsRoles": this.getView().getModel("employee").getProperty(`/TempEmployee/TempRoles`).aSubstituteRoleRoleArea
            };
            const baIndustriesGuid = this.getView().getModel("employee").getData().TempEmployee.BAIndustries;
            const generateFilterConditions = (propertyName, values) => {
                return values.length ? `${values.map(guid => `${propertyName} eq '${guid}'`).join(' or ')}` : "";
            };
            //multiple profit center
            const aSelectedProfitCenter = JSON.parse(JSON.stringify(this.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories));
            for (let i = 0; i < aSelectedProfitCenter.length; i++) {
                if (!aSelectedProfitCenter[i].isCheckBox || !aSelectedProfitCenter[i].isResourceProfile) {
                    aSelectedProfitCenter.splice(i, 1)
                }
            }
            const aFinalPfc = aSelectedProfitCenter.filter((obj1, i, arr) =>
                arr.findIndex(obj2 => (obj2.SelectedGuid === obj1.SelectedGuid)) === i
            );
            //filter condition for Roles
            const aRoleIds = isSubsFlag ? filterValues.aSubsRoles.map(item => item.RoleID) : filterValues.aRoles.map(item => item.RoleID);
            const aUniqueRoleIds = aRoleIds.filter((item, index) => aRoleIds.indexOf(item) === index);
            //GIT -342 creating role filter query if any role is explicitly selected
            let oSelectedSubRole = this.getView().getModel("employee").getProperty(`/TempEmployee/TempRoles/SelectedSubRole`)
            let filterConditionForRoles;
            let bIsSubRoleSelected = false;
            if (oSelectedSubRole && Object.keys(oSelectedSubRole).length && oSelectedSubRole['active'] && this.getView().getModel("subRole").getData().filter(item=>item.RoleID==oSelectedSubRole.RoleID).length) {
                filterConditionForRoles = `RoleId eq '${oSelectedSubRole.RoleID}'`;
                bIsSubRoleSelected = true;
            } else {
                filterConditionForRoles = aUniqueRoleIds.length ? `(${aUniqueRoleIds.map(roleId => `RoleId eq '${roleId}'`).join(' or ')})` :
                    `(RoleId eq '')`;
            }
            //filter condition for Role Areas
            const aRoleAreaIds = isSubsFlag ? filterValues.aSubsRoles.map(item => item.RoleAreaID) : filterValues.aRoles.map(item => item.RoleAreaID);
            const aUniqueRoleAreaIds = aRoleAreaIds.filter((item, index) => aRoleAreaIds.indexOf(item) === index);
            const filterConditionForRoleArea = aUniqueRoleAreaIds.length ? `(${aUniqueRoleAreaIds.map(roleAreaId => `RoleAreaId eq '${roleAreaId}'`).join(' or ')})` :
                `(RoleAreaId eq '')`;
            let finalFilterString = `$filter=${filterConditionForRoles} and ${filterConditionForRoleArea} and (MelodyRequest eq 'X')` + sSearchOre;
            if (aFinalPfc.length) {
                const multiple_pfc_GUIDs = aFinalPfc.map(item => item.TrpcId);
                const filterCondition10 = generateFilterConditions('Trtrypc', multiple_pfc_GUIDs);
                const filterCondition11 = generateFilterConditions('SecTrtrypc', multiple_pfc_GUIDs);
                finalFilterString += ` and (${filterCondition10} or ${filterCondition11})`;
            }
            if (baIndustriesGuid.length && this.getView().getModel("employee").getProperty(`/BAIndustrySelectable`)) {
                const baIndustries_GUIDs = baIndustriesGuid.map(item => item.BaIndId);
                const filterCondition1 = generateFilterConditions('BaIndId', baIndustries_GUIDs);
                const filterCondition6 = generateFilterConditions('SecBaIndId', baIndustries_GUIDs);
                finalFilterString += ` and (${filterCondition1} or ${filterCondition6})`;
            }
            //set Role payload
            const aFinaRole = isSubsFlag ? filterValues.aSubsRoles : bIsSubRoleSelected ? [oSelectedSubRole] : filterValues.aRoles;
            this.getView().getModel("employee").setProperty("/aFinalRolePaylod", aFinaRole);
            const aSolAreas = this.getView().getModel("employee").getData().TempEmployee.SolutionAreas;
            let filterConditionSolAreas = "";
            if (aSolAreas.length && this.getView().getModel("employee").getProperty(`/SolnAreaSelectable`)) {
                const aSolAreas_GUIDs = aSolAreas ? aSolAreas.map(item => item.soln_id) : [];
                const parentSolIds = aSolAreas ? aSolAreas.map(item => item.prnt_soln_id) : [];
                let filterConditionSolAreas = "";
                let filterParts = [];

                aSolAreas_GUIDs.forEach((soln_id, index) => {
                    const relatedArea = aSolAreas[index];
                    const parentSolId = parentSolIds[index];
                    if (relatedArea?.soln_prnt_guid === "00000000-0000-0000-0000-000000000000") {
                        filterParts.push(`(SolL1Id eq '${soln_id}') or (SecSolL1Id eq '${soln_id}')`);
                    } else {
                        filterParts.push(`(SolL2Id eq '${soln_id}' or SecSolL2Id eq '${soln_id}') and (SolL1Id eq '${parentSolId}' or SecSolL1Id eq '${parentSolId}')`);
                    }
                });
                filterConditionSolAreas = filterParts.length
                    ? `(${filterParts.join(' or ')})` : ``;
                finalFilterString += ` and ${filterConditionSolAreas}`;
            }
            let aIACID = this.getView().getModel("IACRoleAreaModel").getData() ? this.getView().getModel("IACRoleAreaModel").getData()[0].IacId : "";
            if (this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/Operational_Status") && !this.getOwnerComponent().getModel("appConstants").getProperty("/IAC_ENABLE/0/isIACQueryRemove") && (this.getView().getModel().getData().EngagementType !== '0002')) {
                finalFilterString += ` and (IacId eq '${aIACID}' or SecIacId eq '${aIACID}')`;
            }
            if (sProfitcenter[0].GrpSelectable === 'X') {
                let aSelGroup = this.getView().getModel("employee").getData().TempEmployee?.SelectedGroup;
                if (aSelGroup?.length) {
                    finalFilterString += ` and (GroupL${aSelGroup[0].LevelId}_ID eq '${aSelGroup[0].GroupID}' )`
                }
            }
            finalFilterString += "&$select=Id,EmpName,EmailId,ManagerLevel,ManagerId,ManagerName,ManagerEmail,to_substitute";
            return `${finalFilterString}&$expand=to_substitute`;

        },
        /*Trigger ORE or BS Service for search managers*/
     onSearchResourceManagers: function () {
            let that = this;
            sap.ui.core.BusyIndicator.show();
            setTimeout(function() {
            const ApproversBaseUrl = that._getApproversBaseURL(that);
            const ApproversOREUrl = that._getOREApproversBaseURL(true);
 
            let sProfitcenter = that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories.length ? that.getView().getModel("selectedProfitCenter").getData().
                TempProfitCenter.Territories : that.getView().getModel("selectedProfitCenter").getData().
                filteredProfitCenter;
            const oResourceModel = new sap.ui.model.json.JSONModel();
            sap.ui.core.BusyIndicator.show();
            that.getView().setModel(oResourceModel, "resourceModel");
            that.getView().getModel("resourceModel").setData([]);
            const serviceUrlFS = that._getServiceUrl(ApproversBaseUrl, sProfitcenter, "0001");
            const serviceUrlBS = that._getServiceBSUrl(ApproversBaseUrl, sProfitcenter, "0002");
            const serviceUrlExactFS = that._getServiceBSUrl(ApproversBaseUrl, sProfitcenter, "0001")
            const sSearchOre = " and (ManagerLevel eq 'non-managerial')";
            let roleAreaSubs = that.getView().getModel("employee").getProperty(`/TempEmployee/TempRoles/subStituteRoleRoleArea`);
            const serviceUrlOREApp = that._getOREServiceUrl(ApproversOREUrl, sProfitcenter, sSearchOre);
            const serviceUrlORERes = that._getOREServiceUrl(ApproversOREUrl, sProfitcenter, "");
            const sPrimaryRoleArea = that.getView().getModel("employee").getProperty(`/TempEmployee/TempRoles/RoleAreaID`);
   const sPrimaryRoleId = that.getView().getModel("employee").getProperty(`/TempEmployee/TempRoles/ID`);
                //multipleRoles
                let aRolesData = that.getView().getModel("employee").getProperty("/TempEmployee/TempRoles/RolesData");
                let aSubstRoleData = that.getView().getModel("employee").getProperty("/TempEmployee/TempRoles/aSubstituteRoleRoleArea");
                let oSelectedSubRole = that.getView().getModel("employee").getProperty("/TempEmployee/TempRoles/SelectedSubRole");
                let RoleSubstiTute;
                let bIsSubRoleSelected = (oSelectedSubRole && Object.keys(oSelectedSubRole).length) && oSelectedSubRole['active'] ? true : false;
                //role data
                const aRoleData = aRolesData.map(item => item.RoleID);
                const aUniqueRoleIds = aRoleData.filter((item, index) => aRoleData.indexOf(item) === index);
                const filterConditionForRoles = aUniqueRoleIds.length ? `(${aUniqueRoleIds.map(roleId => `RoleId eq '${roleId}'`).join(' or ')})` :
                    `(RoleId eq '')`;
                const aRoleDataSubs = aSubstRoleData.map(item => item.RoleID);
                const aUniqueRoleIdsSubs = aRoleDataSubs.filter((item, index) => aRoleDataSubs.indexOf(item) === index);
                const filterConditionForRolesSubs = aUniqueRoleIdsSubs.length ? `(${aUniqueRoleIdsSubs.map(roleId => `RoleId eq '${roleId}'`).join(' or ')})` :
                    `(RoleId eq '')`;

                if (filterConditionForRoles !== filterConditionForRolesSubs && !bIsSubRoleSelected) {
                    RoleSubstiTute = true;
                }
            let data;
            function fetchData(url) {
                return new Promise((resolve, reject) => {
                    $.ajax({
                        url: url,
                        dataType: 'json',
                        method: "GET",
                        success: function (data) {
                            resolve(data);
                        },
                        error: function (error) {
                            reject(error);
                        }
                    });
                });
            }
 
            function handleData(data, sVal) {
                let approverArray = data.filter(obj => obj.UserTypeId === "0001");

                const appInfoUniqueArray = Array.from(
                    new Set(approverArray.map(obj => JSON.stringify({
                        email: obj.Email,
                        ID: obj.UserId,
                        fullName: obj.EmpFullName,
                            roleId: obj.CrmRoleId,
                            roleDesc: obj.CrmRoleDesc
                    })))
                ).map(JSON.parse);
                    that.setResourcesModel(data, that, sVal, appInfoUniqueArray);
            }
            function handleOREData(oOREappData, sVal) {
                const uniqueManagers = oOREappData.reduce((acc, obj) => {
                    if (!acc.some(o => o.ID === obj.ManagerId)) {
                        acc.push({
                            email: obj.ManagerEmail,
                            ID: obj.ManagerId,
                            fullName: obj.ManagerName,
                                roleId: obj.Manager_CrmRoleId,
                                roleDesc: obj.Manager_CrmRoleDesc
                        });
                    }
                    return acc;
                }, []);
                    that.setResourcesOREModel(oOREappData, that, sVal, uniqueManagers);
            }
            //MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
            //get IAC (Internal Account Classification) and Role,Role Area mapping #git84
            fetchData(`${ApproversBaseUrl}?${serviceUrlExactFS}`)
                .then((data) => {
                    if (data.d.results.length) {
      handleData.call(that, data.d.results, "0001");
                        return Promise.resolve();
                    }
                    throw new Error("No data found in first fetch");
                })
                .catch(() => {
                    return fetchData(`${ApproversOREUrl}?${serviceUrlOREApp}`)
                        .then((data) => {
                            if (data.d?.results?.length) {
                                handleOREData.call(that, data.d.results, 20);
                                return Promise.resolve();
                            }
                            throw new Error("No data found in third fetch");
                        });
                })
                .catch(async () => {
                    if (RoleSubstiTute) {
                        const serviceUrlSubsNotExactFS = that._getServiceBSUrl(ApproversBaseUrl, sProfitcenter, "0001", true);
                        const retryFSData = await fetchData(`${ApproversBaseUrl}?${serviceUrlSubsNotExactFS}`);
                        if (retryFSData.d.results.length) {
                            handleData.call(that, retryFSData.d.results, "0001");
                            return Promise.resolve();
                        }
                    }
                    throw new Error("No data found in retry fetch");
                })
                .catch(async () => {
                    if (RoleSubstiTute) {
                        const serviceUrlSubsORE = that._getOREServiceUrl(ApproversOREUrl, sProfitcenter, sSearchOre, true);
                        const retryOREData = await fetchData(`${ApproversOREUrl}?${serviceUrlSubsORE}`);
                        if (retryOREData.d?.results?.length) {
                            handleOREData.call(that, retryOREData.d.results, 20);
                            return Promise.resolve();
                        }
                    }
                    throw new Error("No data found in retry ORE fetch");
                })
                .catch(() => {
                    return fetchData(`${ApproversBaseUrl}?${serviceUrlBS}`)
                        .then((data) => {
                            if (data) {
        handleData.call(that, data.d.results, "0002");
                                return Promise.resolve();
                            }
                            throw new Error("No data found in fallback fetch");
                        });
                })
                .catch((error) => {
                    that.errorMessageDailog(error);
                });
            //MR: [GRP02-03] GTM25 Resource Profile alignment #84 end
            }, 1000);
        },
          /**
         * Set Resource Model for FS and BS
         * 001 => FS, 002=BS and ORE=> ORE service key
         * @param {object} data -response from service
		 * @param {object} self -Controller context
		 * @param {string} sVal -Front Stop (001), Back stop(BS) (002)
		 * @param {object} aApproversArray -Approvers list
		 * @param {number} i -iteration of resource approvers
         */
      setResourcesModel: function (data, self, sVal,aApproversArray) {
            //data => Resource cordinator or administration
   //set the properties
            data = data.map(obj => {
                return { ...obj, isManagerDet:true , serviceId:sVal };
            });
            let aSubstituteFinalApprover = CommonJS._getSubstituteDetails(data);
            let approverArray = [];
            let value = data;
           for (let i = 0; i < value.length; i++) {
    let obj = value[i];
    switch (obj.UserTypeId) {
     case "0001":
      approverArray.push(obj);
      break; 
     default:
      break;
    }
   }
           const appinfo = approverArray.map(function (obj) {
    return {
     email: obj.Email,
     ID: obj.UserId,
     fullName: obj.EmpFullName,
     roleId:obj.CrmRoleId,
                    roleDesc:obj.CrmRoleDesc,
     isDelegates:!obj.isManagerDet,
     serviceId:obj.serviceId
    };
   });

            //remove duplicates based on ID
   //if duplicates exist one in manager and other in substitute then update only manager record
            const appInfoUniqueArray = Object.values(
    appinfo.reduce((acc, item) => ({
     ...acc,
     [item.ID]: acc[item.ID]?.isDelegates === false
      ? acc[item.ID]
      : item
    }), {})
   );
            const sSearchType = sVal === "0002" ?   "resource": "FS";
            self.getView().getModel("resourceModel").getData().push({
    searchType:sSearchType,
    isResourceFound:false,
    sNotificationMsg:self._setNotificationMsg(sVal),
    iCount:appInfoUniqueArray.length,
    sSearchText:self.getView().getModel("employee").getProperty(`/searchFieldsText`),
    ApproverDetails:appInfoUniqueArray,
                aApprovers: aApproversArray,
                bIsGroupSelected: this.getView().getModel("employee").getData().TempEmployee?.SelectedGroup?.length > 0 ? true : false
   });
            self.getView().getModel("resourceModel").refresh(true);
            self.isResourceProfile = true;
            const employeeData = self.getView().getModel("employee").getData().TempEmployee;
            self.getView().getModel("employee").setProperty("/TempEmployee/TempRoles/SelectedRoleDesc",self.getView().getModel("employee").getProperty("/aFinalRolePaylod").map(obj => { return obj.RoleDesc }).join(", "));
            //Set Payload for Resource profile details
            const ResourceProfileDetails = {
                Role_GUID: self.getView().getModel("employee").getProperty("/TempEmployee/TempRoles"),
                RoleArea_P_GUID: self.getView().getModel("employee").getProperty("/TempEmployee/TempRoleAreas")[0],
                BAIndustries: employeeData.BAIndustries,
                SolutionAreas:employeeData.SolutionAreas,
                Materials:employeeData.Materials,
                AdditionalSolutions:employeeData.AdditionalSolutions,
                SelectedRole:self.getView().getModel("employee").getProperty("/aFinalRolePaylod"),
                SelectedGroup:employeeData?.SelectedGroup?employeeData.SelectedGroup:[]
            };
            if(!self.getView().getModel("employee").getProperty(`/BAIndustrySelectable`)){
    //reset industry
                ResourceProfileDetails.BAIndustries = [];
   }

   if(!self.getView().getModel("employee").getProperty(`/SolnAreaSelectable`)){
    //reset solution area
                ResourceProfileDetails.SolutionAreas = [];
   }
            //MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
            //get IAC (Internal Account Classification) and Role,Role Area mapping #git84
            const oSelectRoleAreaID = self.getView().getModel("employee").getProperty("/TempEmployee/TempRoleAreas")[0].ID;
            const oSelectedIACRoleArea = self.getView().getModel("IACRoleAreaModel").getData().find(item => item.RoleAreaId === oSelectRoleAreaID);
            let uniqueSubs = Array.from(new Map(aSubstituteFinalApprover.map(aSubstituteFinalApprover => [aSubstituteFinalApprover.ID, aSubstituteFinalApprover])).values());
   uniqueSubs = uniqueSubs ? uniqueSubs.filter(item => !aApproversArray.some(aItem => aItem.ID === item.ID)) : [];
            const aResourceProfileApprovers = {
                aApprovers: aApproversArray,
                ApproverDetails: appInfoUniqueArray,
                ResourceProfileDetails: ResourceProfileDetails,
                //update substitute array to the context
    SubstituteApproverDetails:uniqueSubs,
                IAC: [{
                    "IAC_Desc": oSelectedIACRoleArea.IacDesc,
                    "IAC_ID": oSelectedIACRoleArea.IacId,
                    "IAC_RoleMap_GUID": oSelectedIACRoleArea.IacMapGuid
                }]
            };
            //MR: [GRP02-03] GTM25 Resource Profile alignment #84 end

            self.aResourceProfileApprovers = aResourceProfileApprovers;
            self.aReqAreas = [];
            self.openResProfileDialog(self, sVal);

        },
        //GIT: 720 - update to show standardized message for FS,BS and ORE resource profile search
        _setNotificationMsg: function () {
			const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			return i18nModel.getText("commonResMessDescFSBSORE");
		},
        /*Open Resource profile managers popover*/
        openResProfileDialog: function (self, sVal,bShowResourceModel,isOpenCreateReqFragment) {
            const aResource = [];
			const aResourceData = this.getView().getModel("resourceModel").getData();
            const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            const notifyDesc = i18nModel.getText("notificationMess");
            const savenNext = i18nModel.getText("saveAndNext");
            const backtext = i18nModel.getText("back");
            var that = this;
            let resourceMessDesc;
            const aResourceModelData = this.getView().getModel("resourceModel").getData();
            if (!isOpenCreateReqFragment) {
                this.selectedProfitCenter = this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories");
                if (sVal === "0001") {
                    resourceMessDesc = i18nModel.getText("resMessDescFS");
                } else if (sVal === 20) {
                    resourceMessDesc = i18nModel.getText("resMessDescORE");
                } else if (sVal === "0002") {
                    resourceMessDesc = i18nModel.getText("resMessDescBS");
                }
                this.getView().getModel("employee").setProperty("/isResource", false);
                let bApproverNotFound = aResourceData.some(function (resource) {
                    return !resource.ApproverDetails.length
                });
                if (!bApproverNotFound) {
                    aResourceData.forEach(function (resource) {
                        if (resource.searchType === "resource") {
                            that.getView().getModel("employee").setProperty("/isResource", "resourceAdmin");
                        }
                    });
                } else {
                    aResourceData.forEach(function (resource) {
                        if (!resource.ApproverDetails.length) {
                            that.getView().getModel("employee").setProperty("/isResource", "notFound");
                            aResource.push(resource);
                            that.getView().getModel("employee").setProperty("/resourceContext", aResource);
                        }
                    });
				}
            }
            this.getView().getModel("employee").refresh();

            if(!isOpenCreateReqFragment && !this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories/0/isParentNodeEnable") && this.getView().getModel("employee").getProperty("/isResource") === "notFound"){
                this._onOpenApproverNotificationPopOver(true);
                sap.ui.core.BusyIndicator.hide();
            }else if (!isOpenCreateReqFragment && this.getView().getModel("employee").getProperty("/isResource") && !bShowResourceModel && this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories/0/isParentNodeEnable")) {
                this._onOpenApproverNotificationPopOver();
            }else{

                const fragment = new sap.ui.xmlfragment(
                    "com.dealsupport.melodyrequest.fragments.managerPage.resourceProfileForward",                    
                    this
                );
                const contentVBox = new sap.m.VBox({
                    items: [
                        new sap.m.Text({ text: that.getView().getModel("resourceModel").getData()[0].sNotificationMsg }).addStyleClass("sapUiSmallMargin"),
                        fragment
                    ]
                });
                const oCustomHeader = new sap.m.OverflowToolbar({
                    content: [
                        new sap.m.Title({
                            text: notifyDesc
                        }),
                        new sap.m.ToolbarSpacer({

                        }),
                        new sap.m.Button({
                            icon: "sap-icon://decline",
                            press: function (evt) {
                                that.popover.destroy();
                            }
                        })
                    ]
                });
                this.popover = new sap.m.ResponsivePopover({
                    title: notifyDesc,
                    contentWidth: "400px",
                    modal: true,
                    content: contentVBox,
                    customHeader: oCustomHeader,
                    placement: sap.m.PlacementType.Top,
                    beginButton: new sap.m.Button({
                        text: i18nModel.getText("forwardReq"),
                        type: "Emphasized",
                        press: function () {
                            that.onForwardRequest(true);
                            that.popover.close();
                        }
                    }),
                    endButton: new sap.m.Button({
                        text: backtext,
                        press: function () {
                            that.popover.close();
                        }
                    }),
                    afterClose: function () {
                        that.popover.destroy();
                    }
                });
                that.popover.addStyleClass("customPopover");
                this.getView().addDependent(that.popover);
                that.popover.openBy(this.byId("idOnSearchResourcesButton"));
    
            }

            sap.ui.core.BusyIndicator.hide();
        },
   _onOpenApproverNotificationPopOver: function (isHigherNodeNonSelectable){
   const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
   this.noSearchResult = false;
   this.bHigherNodeNotFound = false;
            const that = this;
   sap.ui.core.Fragment.load({
    name: "com.dealsupport.melodyrequest.fragments.ApproverNotification",
    controller: this
   }).then(function (oFragment) {
    const contentVBox = new sap.m.VBox({
     items: [
      oFragment
     ]
    });
                this.getView().getModel("resourceModel").getData().forEach(obj=>{
     if(obj.bIsGroupSelected && that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories[0]?.ParentGroupSelectable!='X'){
      isHigherNodeNonSelectable=true;
     }
    })
    if (!isHigherNodeNonSelectable) {
     if (that.aNonSelectableParentNode) {
                         that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories.unshift(that.aNonSelectableParentNode)
     }
     
     //parent node => check lower node selection false and isChecBox is false or is legacy
     const oProfitCenterMasterData = that.getView().getModel("treeTerritories").getData().territories;
     this.nodeParentCheck = false;
     this.higherNodeProfitCenter = false;
     this.higherNodeItreation = false;
     this.bHigherNodeNotFound = false;
     let nodeParentCheck = function nodeUpdate(newValue, that,isItreation) {
      let oPFCMasterData = that.getView().getModel("treeTerritories").getData().territories;
      let aSelectedPFC =  isItreation ? that.higherNodeProfitCenter : that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories[0];
      let aNodeDes = aSelectedPFC.SelectedDesc.split(">");
      aNodeDes.pop();
      let sDescription = aNodeDes.join(">");
      if(!sDescription){
       that.higherNodeItreation = false;
       that.bHigherNodeNotFound = true;
      }
      else if(oPFCMasterData[0].displaydesc === sDescription.trim()){
       if (!oPFCMasterData[0].isChildNodeEnable && (!oPFCMasterData[0].isCheckBox || !oPFCMasterData[0].isResourceProfile)) {
        that.higherNodeItreation = false;
        that.bHigherNodeNotFound = true;

       }
      }else{
      for (const child of newValue.nodes) {
       if (sDescription.trim() == child.displaydesc && !child.isChildNodeEnable && (!child.isCheckBox || !child.isResourceProfile)) {
        child.IsSelected = true;
        that.nodeParentCheck = true;
        let oSelectedProfitCenter = Models._setProfitCenterObj(child);
        that.higherNodeProfitCenter = oSelectedProfitCenter;
        that.higherNodeItreation = true;

       } else if (sDescription.trim() == child.displaydesc) {
        that.higherNodeItreation = false;
       }
       if(!that.nodeParentCheck){
        nodeUpdate(child, that);
       }
       
      }
     }
      
     }
     nodeParentCheck(oProfitCenterMasterData[0], this);
     if(this.higherNodeItreation){
      nodeParentCheck(oProfitCenterMasterData[0], this,true);
     }

     if(!this.bHigherNodeNotFound){
      const aSelectedPFC = this.higherNodeProfitCenter ? this.higherNodeProfitCenter : this.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories[0];
      const sDesc = aSelectedPFC.SelectedDesc;
      const aNodeDesc = sDesc.split(">");
      aNodeDesc.pop();
      const sParentNode = aNodeDesc.join(">");
                        let sNotificationMsg;
                        if(this.getView().getModel("resourceModel").getData()[0].ApproverDetails.length){
                             sNotificationMsg = `<p>${i18nModel.getText("approverNotification")} <strong>${sParentNode}</strong> ${i18nModel.getText("allSearch")}</p>`;
                        }else{
                             sNotificationMsg = `<p>${i18nModel.getText("approverNotificationNoRes")} <strong>${sParentNode}</strong> ${i18nModel.getText("allSearch")}</p>`;
                        }
      
      let oFormattedText = new sap.m.FormattedText({
       htmlText: sNotificationMsg
      });
      oFragment.removeAllItems()
      oFragment.insertItem(oFormattedText);

     }else if(this.getView().getModel("employee").getProperty("/isResource") === "notFound"){
      this._onOpenApproverNotificationPopOver(true);
     }else{
      this.openResProfileDialog(false,false,false,true);
     }
    } else {
     let sResource = this.getView().getModel("employee").getProperty("/isResource")
     let aResourceContext = this.getView().getModel("employee").getProperty("/resourceContext");
     let aSearchMsg = [];
      aResourceContext.forEach(function (context) {
       aSearchMsg.push(
        `Search ${context.sSearchText}`
       );
      });
      let sNotificationMsg = `<p>${i18nModel.getText("processorNotFoundIn")} <strong>${aSearchMsg.join(" , ")}</strong> ${i18nModel.getText("modifyOrDeleteMsForWard")}</p>`

      let oFormattedText = new sap.m.FormattedText({
       htmlText: sNotificationMsg
      });
      oFragment.removeAllItems()
      oFragment.insertItem(oFormattedText);
     }

    if(!this.bHigherNodeNotFound){
    const that = this;
                if(this.oNotificationPopover){
                    this.oNotificationPopover.close();
                }
    this.oNotificationPopover = new sap.m.ResponsivePopover({
     title: "Notification(1)",
     contentWidth: "500px",
     verticalScrolling:false,
     modal: true,
     content: oFragment,
     placement: sap.m.PlacementType.Top,
     beginButton: new sap.m.Button({
      text: "Yes",
      visible:isHigherNodeNonSelectable ? false:true,
      press: function () {
      if(!that.noSearchResult){
       if(that.higherNodeProfitCenter){
        that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories = [that.higherNodeProfitCenter]
        that.getView().getModel("selectedProfitCenter").refresh(true);
       }
       if(that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.TempTreeTerritories){
        that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.TempTreeTerritories.length = 1;
       }
       if(that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories){
        that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories.length = 1;
       }
      
       that.loadTreeTerritories("treeTerritories",that.getView().getModel("territoriesMaster").getData(),true);
       that.setTerritoryHierarchySelection(false, false, false, true);
                            var bGrpSelect=that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories[0]?.GrpSelectable=='X'?true:false;
       that.getView().getModel("employee").getData().GrpSelectable=bGrpSelect;
       that.getView().getModel("employee").refresh(true);
       let nodeUpdate = function nodeUpdate(newValue, that) {
        for (const child of newValue.nodes) {
         if (child.isCheckBox && child.isResourceProfile) {
          child.IsSelected = true;
          let oSelectedProfitCenter = Models._setProfitCenterObj(child);
          that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories.push(
           oSelectedProfitCenter);
          that.getView().getModel("selectedProfitCenter").refresh(true);
         }
         nodeUpdate(child, that);
        }
        that.getView().getModel("selectedProfitCenter").refresh(true);
        that.getView().getModel("treeTerritories").refresh(true);
       }
       that.oNotificationPopover.destroy();
       if (that.aSelectedParentNode) {
        let oSelectedPFCDesc = Models._setProfitCenterObj(that.aSelectedParentNode);
        that.getView().getModel("selectedProfitCenter").setProperty("/selectedPfc",oSelectedPFCDesc);
        if(that.aSelectedParentNode.isChildNodeEnable){
         nodeUpdate(that.aSelectedParentNode, that);
        }
        that.getView().getModel("selectedProfitCenter").refresh(true);
        that.getView().getModel("treeTerritories").refresh(true);
        that.onSearchResourceManagers(that);
        const aSelectedTerritories = that.getView().getModel("selectedProfitCenter").getData().TempProfitCenter.Territories;
        for (let i = 0; i < aSelectedTerritories.length; i++) {
         if (!aSelectedTerritories[i].isCheckBox || !aSelectedTerritories[i].isResourceProfile) {
          that.aNonSelectableParentNode =aSelectedTerritories[0]; 
          aSelectedTerritories.splice(i, 1)
         }
        }
        that.getView().getModel("selectedProfitCenter").refresh();
       }
      else {
       let sResource = that.getView().getModel("employee").getProperty("/isResource");
       if (sResource !== "notFound") {
        let oFormattedText = new sap.m.FormattedText({
           htmlText: i18nModel.getText("noResourcesNotification")
          });
          that.noSearchResult = true;
          that.oNotificationPopover._getPopup().getContent().getContent()[0].removeAllItems();
          that.oNotificationPopover._getPopup().getContent().getContent()[0].insertItem(oFormattedText);
          that.oNotificationPopover.getBeginButton().setVisible(true);
         } else {
          let sNotificationMsg = `<p>${i18nModel.getText("processorNotFoundIn")} <strong>${aSearchMsg.join(" , ")}</strong> ${i18nModel.getText("modifyOrDeleteMsForWard")}</p>`
          let oFormattedText = new sap.m.FormattedText({
           htmlText: sNotificationMsg
          });
          that.oNotificationPopover._getPopup().getContent().getContent()[0].removeAllItems();
          that.oNotificationPopover._getPopup().getContent().getContent()[0].insertItem(oFormattedText);
          that.oNotificationPopover.getEndButton().setText("OK")
          that.oNotificationPopover.getBeginButton().setVisible(false);
         }

        }
       } else {
        that.oNotificationPopover.destroy();
       }
      }
     }),
     endButton: new sap.m.Button({
      text: isHigherNodeNonSelectable ? "OK":"No",
      press: function (oEvent) {
       if (oEvent.getSource().getText() !== "OK") {
        let sResource = that.getView().getModel("employee").getProperty("/isResource")
        let aResourceContext = that.getView().getModel("employee").getProperty("/resourceContext");
        let aSearchMsg = [];
       if (sResource === "notFound") {
        aResourceContext.forEach(function (context) {
         aSearchMsg.push(
                                        `Search ${context.sSearchText}`
         );
        });
        let sNotificationMsg = `<p>${i18nModel.getText("processorNotFoundIn")} <strong>${aSearchMsg.join(" , ")}</strong> ${i18nModel.getText("modifyOrDeleteMsForWard")}</p>`
    
        let oFormattedText = new sap.m.FormattedText({
         htmlText: sNotificationMsg
        });
        that.oNotificationPopover._getPopup().getContent().getContent()[0].removeAllItems();
        that.oNotificationPopover._getPopup().getContent().getContent()[0].insertItem(oFormattedText);
        that.oNotificationPopover.getEndButton().setText("OK")
        that.oNotificationPopover.getBeginButton().setVisible(false);
       } else {
        const sVal = that.getView().getModel("employee").getProperty("/approverId");
                                that.openResProfileDialog(that, sVal,true);
        that.oNotificationPopover.destroy();
        }
        that.getView().getModel("employee").refresh()
       } else {
        that.isNotificationPopOverClose = true;
        that.oNotificationPopover.destroy();
       }
      }
      
     }),
     afterClose: function () {
     }
    });
    this.getView().addDependent(this.oNotificationPopover);
    this.oNotificationPopover.openBy(that.byId("idOnSearchResourcesButton"));
    sap.ui.core.BusyIndicator.hide();
   }
   }.bind(this));
   
  },
         /**
         * Set ORE Resource
         * @param {object} appdata -response from service
		 * @param {object} self -Controller context
		 * @param {string} sVal - ORE Key
		 * @param {object} aApproversArray -Approvers list
		 * @param {number} i -iteration of resource approvers
         */
     setResourcesOREModel: function (appdata, self, sVal,aApproversArray) {
             //data => Managers
   //set the properties
            appdata = appdata.map(obj => {
                return { ...obj, isManagerDet:true,serviceId:"ORE" };
            })
            let aSubstituteFinalApprover = CommonJS._getSubstituteDetails(appdata,true);
            let approverArray = [];
            let appValue = appdata;
            for (let i = 0; i < appValue.length; i++) {
                let obj = appValue[i];
                approverArray.push(obj.Id);
            }
            const appinfoORE = appValue.map(function (obj) {
                return {
                    email: obj.ManagerEmail,
     ID: obj.ManagerId,
     fullName: obj.ManagerName,
     roleId:obj.Manager_CrmRoleId,
                    roleDesc:obj.Manager_CrmRoleDesc,
     isDelegates:!obj.isManagerDet,
     serviceId:obj.serviceId
                };
            });
            //remove duplicates based on ID
   //if duplicates exist one in manager and other in substitute then update only manager record
           const uniqueManagers =  Object.values(
    appinfoORE.reduce((acc, item) => ({
     ...acc,
     [item.ID]: acc[item.ID]?.isDelegates === false
      ? acc[item.ID]
      : item
    }), {})
   );
            this.getView().getModel("resourceModel").getData().push({
    isResourceFound:true,
    searchType:"ore",
    sNotificationMsg:this._setNotificationMsg(sVal),
    iCount:uniqueManagers.length,
    sSearchText:this.getView().getModel("employee").getProperty(`/searchFieldsText`),   
    ApproverDetails:uniqueManagers,
                aApprovers:aApproversArray,
                bIsGroupSelected: this.getView().getModel("employee").getData().TempEmployee?.SelectedGroup?.length > 0 ? true : false
   });
   this.getView().getModel("resourceModel").refresh(true);
            this.isResourceProfile = true;
            const employeeData = this.getView().getModel("employee").getData().TempEmployee;
            this.getView().getModel("employee").setProperty("/TempEmployee/TempRoles/SelectedRoleDesc",this.getView().getModel("employee").getProperty("/aFinalRolePaylod").map(obj => { return obj.RoleDesc }).join(", "));
            //Set Payload for Resource profile details
             const ResourceProfileDetails = {
                Role_GUID: this.getView().getModel("employee").getProperty("/TempEmployee/TempRoles"),
                RoleArea_P_GUID: this.getView().getModel("employee").getProperty("/TempEmployee/TempRoleAreas")[0],
                BAIndustries: employeeData.BAIndustries,
                SolutionAreas:employeeData.SolutionAreas,
                AdditionalSolutions:employeeData.AdditionalSolutions,    
    Materials:employeeData.Materials,
                SelectedRole:this.getView().getModel("employee").getProperty("/aFinalRolePaylod"),
                SelectedGroup: employeeData?.SelectedGroup ? employeeData.SelectedGroup:[]
            };
            if(!this.getView().getModel("employee").getProperty(`/BAIndustrySelectable`)){
    //reset industry
                ResourceProfileDetails.BAIndustries = [];
   }

   if(!this.getView().getModel("employee").getProperty(`/SolnAreaSelectable`)){
    //reset solution area
                ResourceProfileDetails.SolutionAreas = [];
   }

           //MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
            //get IAC (Internal Account Classification) and Role,Role Area mapping #git84
            const oSelectRoleAreaID = self.getView().getModel("employee").getProperty("/TempEmployee/TempRoleAreas")[0].ID;
            const oSelectedIACRoleArea = self.getView().getModel("IACRoleAreaModel").getData().find(item => item.RoleAreaId === oSelectRoleAreaID);
            let uniqueSubs = Array.from(new Map(aSubstituteFinalApprover.map(aSubstituteFinalApprover => [aSubstituteFinalApprover.ID, aSubstituteFinalApprover])).values());
   uniqueSubs = uniqueSubs ? uniqueSubs.filter(item => !aApproversArray.some(aItem => aItem.ID === item.ID)) : [];
            const aResourceProfileApprovers = {
                aApprovers:aApproversArray,
                ApproverDetails: uniqueManagers,
                //update substitute array to the context
    SubstituteApproverDetails:uniqueSubs,
                ResourceProfileDetails: ResourceProfileDetails,
                IAC: [{
                    "IAC_Desc": oSelectedIACRoleArea.IacDesc,
                    "IAC_ID": oSelectedIACRoleArea.IacId,
                    "IAC_RoleMap_GUID": oSelectedIACRoleArea.IacMapGuid
                }]
            };
            //MR: [GRP02-03] GTM25 Resource Profile alignment #84 end
            this.aResourceProfileApprovers = aResourceProfileApprovers;
            this.aReqAreas = [];
            this.isResourceProfile = true;
            this.openResProfileDialog(this, sVal);
        },
        onPressEmpEmail: function (oEvent) {
            const sUrl = oEvent.getSource().getProperty("text");
            URLHelper.triggerEmail(sUrl, "Info Request - MRR", false, false, false, true);
        },
        _getApproversBaseURL: function (self) {
           return Models._getLSRuntimeBaseURL(self) + "/sap/opu/odata/sap/YROSTER_SRV;v=0002/YC_DS_T_RESOURCE_PROFILE";
        },
        _getOREApproversBaseURL: function (bForwardRes) {
            if(!bForwardRes){
                return this._getRuntimeBaseURL() + "/int_pc/sap/opu/odata/sap/YROSTER_SRV;v=0002/YC_DS_T_NAMED_CONTACT";
            }else{
                return this._getRuntimeBaseURL() + "/int_pc/sap/opu/odata/sap/YROSTER_SRV;v=0002/YC_DS_T_PRSONPRO"
            }
         
        },
        _getOREResourcesBaseURL: function () {
            return this._getRuntimeBaseURL() + "/int_pc/sap/opu/odata/sap/YROSTER_SRV;v=0002/YC_DS_T_DIRECT_REPORTEES"
        },
        _getRuntimeBaseURL: function () {
            const appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
            const appPath = appId.replaceAll(".", "/");
            const appModulePath = sap.ui.require.toUrl(appPath);
            return appModulePath;
        },
        /*Set Error dialog*/
        errorMessageDailog: function (error) {
            let oErrorData = data ? data : error;
            Models._setErrorMsgPopOver(this, "searchResourcesManager", oErrorData);
            sap.ui.core.BusyIndicator.hide();

        },
        /*Close Forward Request Dialog*/
        onCloseForwardReqDialog: function (evt) {
            this._pForwardReqialog.then(function (oDialog) {
                oDialog.close();
            });
        },
        /*Cancel Forward Request*/
        onCancelResForward: function () {
            this.onCloseForwardReqDialog()
        },
        /*Open Resource profile manager popover*/
        onClickResourceProfileDialog: function (oEvent) {
            if (!this._resourceProfilePopover) {
                this._resourceProfilePopover = sap.ui.xmlfragment("com.dealsupport.melodyrequest.fragments.managerPage.ResourceProfileSearchPopover", this);
                this.getView().addDependent(this._resourceProfilePopover);
            }
            this.getResProfileDetails();
            CommonJS.getResFieldDetails(this);
            this._resourceProfilePopover.openBy(oEvent.getSource());
        },
        /*Set Resource profile Details PopOver*/
        getResProfileDetails: function () {
            const aResProfile =this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails;
            let sSolutionAreaDesc;
            const descStringBAindustry = aResProfile.BAIndustries.map(function (obj) {
                return obj.Desc;
            }).join(',');
            if (aResProfile.SolutionAreas) {
                if (aResProfile.SolutionAreas.length) {
                     sSolutionAreaDesc = aResProfile.SolutionAreas.map(function (obj) {
                        return obj.soln_name;
                    }).join(',');
                }
            }else{
                sSolutionAreaDesc = "";
            }
            const descPC = this.getView().getModel().getData().selectedProfitCenter[0].SelectedDesc;
            let listItems = [];
            const sProfitCenterI18n = this.i18nModel.getText("profitCenter");
            const sSLAi18n = this.i18nModel.getText("solutionArea");
            const sRoleAreaI18n = this.i18nModel.getText("roleAreaPrimary");
            const sRoleI18n = this.i18nModel.getText("rolePrimary");
            const sBAIi18n = this.i18nModel.getText("businessAreaIndustryPrimary");
             const aSelectedPFC = this.getView().getModel().getData().selectedProfitCenter;
        const trpDesc = `${aSelectedPFC[0].desc}-${aSelectedPFC[0].TrpcId}`;
            let data = [
               { Name: sProfitCenterI18n, Desc: descPC, trpDesc: trpDesc, queryParams: "TrpcDesc" },
                { Name: sRoleAreaI18n, Desc: aResProfile.Role_GUID.RoleAreaDesc, trpDesc: "", queryParams: "RoleDesc" },
                { Name: sBAIi18n, Desc: descStringBAindustry, trpDesc: "", queryParams: "BaIndDesc" },
                { Name: sSLAi18n, Desc: sSolutionAreaDesc, trpDesc: "", queryParams: "SolAreaDesc"  }
            ];
            if(this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.SelectedRole){
                let sRoleDesc; 
                if (this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RolesData.length > 1) {
                      sRoleDesc = this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RolesData.map(function (obj) {
                        return obj.RoleDesc;
                    }).join(',');
                }else{
                    sRoleDesc = this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.Desc
                }
                 data = [
               { Name: sProfitCenterI18n, Desc: descPC, trpDesc: trpDesc, queryParams: "TrpcDesc" },
                { Name: sRoleAreaI18n, Desc: aResProfile.Role_GUID.RoleAreaDesc, trpDesc: "", queryParams: "RoleAreaDesc" },
                { Name: sRoleI18n, Desc: sRoleDesc, trpDesc: "", queryParams: "RoleDesc" },
                { Name: sBAIi18n, Desc: descStringBAindustry, trpDesc: "", queryParams: "BaIndDesc" },
                { Name: sSLAi18n, Desc: sSolutionAreaDesc, trpDesc: "", queryParams: "SolAreaDesc"  }
            ];
            }
            data.forEach(function (item) {
                if (item.Desc) {
                    let listItem = {
                        Name: item.Name,
                        Desc: item.Desc,
                        queryParams: item.queryParams
                    };
                    listItems.push(listItem);
                }
            });
            let oModelResPr = new sap.ui.model.json.JSONModel();
            oModelResPr.setData(
                listItems
            );

            this.getView().setModel(oModelResPr, "ResProfileModel");
        },
        /*Open Error Popover for Named Contacts*/
        _onOpenErrorPopOverNamedContact: function () {
            this._onOpenErrorPopOver("namedContact");

        },
        _onOpenErrorPopOver: function (sNamedContact) {
            var that = this;
            if (!this.pErrorPopOver) {
                that.pErrorPopOver = that.loadFragment({
                    name: "com.dealsupport.melodyrequest.fragments.ErrorNotification"
                });
            }
            that.pErrorPopOver.then(function (oDialog) {
                if (sNamedContact === "namedContact") {
                    oDialog.openBy(that.getView().byId("idNotificationNamedContactBadgedButton"));
                } else {
                    oDialog.openBy(that.getView().byId("idNotificationBadgedButton"));
                }

            });
        },
        /*Close Error Popover*/
        _onClosePopOverList: function () {
            this._onClosePopOver();
            const oErrorModel = this.getView().getModel("errorMsgModel");
            this.getView().byId("idNotificationBadgedButton").setVisible(false);
            oErrorModel.setProperty("/errorInformation", [])
            this.getView().byId("idNotificationBadgedButton").setVisible(false);
        },
        _onClosePopOver: function () {
            var that = this;
            if (this.pErrorPopOver) {
                this.pErrorPopOver.then(function (oDialog) {
                    oDialog.destroy();
                    delete that.pErrorPopOver;
                });
            }
        },

        _getOREResourceServiceUrl: function (ApproversOREUrl) {
            const oModel = this.getView().getModel();
            const sProfitCenterId = oModel.getProperty("/selectedProfitCenter/0/TrpcId");

            const filterValues = {
                "ProfitCenterGUID": sProfitCenterId,
                "Manager_Level": "non-managerial",
                "Role_GUID": oModel.getProperty("/aResourceProfileApprovers/ResourceProfileDetails/Role_GUID/ID"),
                "RoleArea_P_GUID": oModel.getProperty("/aResourceProfileApprovers/ResourceProfileDetails/RoleArea_P_GUID/ID")
            };
            const cross_CVRG_P_GUIDArray = oModel.getProperty("/aResourceProfileApprovers/ResourceProfileDetails/cross_CVRG_P_GUIDArray");
            const crossBAGuid = oModel.getProperty("/aResourceProfileApprovers/ResourceProfileDetails/BASegments");
            const baIndustriesGuid = oModel.getProperty("/aResourceProfileApprovers/ResourceProfileDetails/BAIndustries");
            const baLobs = oModel.getProperty("/aResourceProfileApprovers/ResourceProfileDetails/BALoBs");
            const hubs = oModel.getProperty("/aResourceProfileApprovers/ResourceProfileDetails/Hubs");
            const sSearchOre = " and (ManagerLevel eq 'non-managerial')";
            const generateFilterConditions = (propertyName, values) => {
                return values.length ? `${values.map(guid => `${propertyName} eq '${guid}'`).join(' or ')}` : "";
            };
            let finalFilterString = `$filter=(Trtrypc eq '${filterValues.ProfitCenterGUID}' or SecTrtrypc eq '${filterValues.ProfitCenterGUID}') and (RoleId eq '${filterValues.Role_GUID}' or SecRoleId eq '${filterValues.Role_GUID}') and (RoleAreaId eq '${filterValues.RoleArea_P_GUID}' or SecRoleAreaId eq '${filterValues.RoleArea_P_GUID}')+${sSearchOre}`;
            if (cross_CVRG_P_GUIDArray.length) {
                const cross_CVRG_P_GUIDs = cross_CVRG_P_GUIDArray.map(item => item.ID);
                const filterCondition3 = generateFilterConditions('CrossCvrgId', cross_CVRG_P_GUIDs);
                const filterCondition8 = generateFilterConditions('SecCrossCvrgId', cross_CVRG_P_GUIDs);
                finalFilterString += ` and (${filterCondition3} or ${filterCondition8})`;
            }
            if (crossBAGuid.length) {
                const crossBAGuidGuids = crossBAGuid.map(item => item.ID);
                const filterCondition4 = generateFilterConditions('BaSegId', crossBAGuidGuids);
                const filterCondition9 = generateFilterConditions('SecBaSegId', crossBAGuidGuids);
                finalFilterString += ` and (${filterCondition4} or ${filterCondition9})`;
            }
            if (baIndustriesGuid.length) {
                const baIndustries_GUIDs = baIndustriesGuid.map(item => item.BaIndTechID);
                const filterCondition1 = generateFilterConditions('BaIndId', baIndustries_GUIDs);
                const filterCondition6 = generateFilterConditions('SecBaIndId', baIndustries_GUIDs);
                finalFilterString += ` and (${filterCondition1} or ${filterCondition6})`;
            }
            if (baLobs.length) {
                const baLobs_GUIDs = baLobs.map(item => item.ID);
                const filterCondition2 = generateFilterConditions('BaLobId', baLobs_GUIDs);
                const filterCondition7 = generateFilterConditions('SecBaLobId', baLobs_GUIDs);
                finalFilterString += ` and (${filterCondition2} or ${filterCondition7})`;
            }
            if (hubs.length) {
                let filterConditions = [];
                let filterConditions21 = [];
                let filterConditions31 = [];
                let filterConditions41 = [];

                for (let i = 0; i < hubs.length; i++) {
                    const hubGuid = hubs[i].ID;
                    if (hubs[i].Type === "INDUSTRY") {
                        filterConditions21.push(generateFilterConditions('HubIndId', [hubGuid]));
                        filterConditions21.push(generateFilterConditions('SecHubIndId', [hubGuid]));
                    } else if (hubs[i].Type === "LOB") {
                        filterConditions31.push(generateFilterConditions('HubLobId', [hubGuid]));
                        filterConditions31.push(generateFilterConditions('SecHubLobId', [hubGuid]));
                    } else if (hubs[i].Type === "ROLE") {
                        filterConditions41.push(generateFilterConditions('HubRoleId', [hubGuid]));
                        filterConditions41.push(generateFilterConditions('SecHubRoleId', [hubGuid]));
                    }
                }

                filterConditions21 = filterConditions21.filter(condition => condition);
                filterConditions31 = filterConditions31.filter(condition => condition);
                filterConditions41 = filterConditions41.filter(condition => condition);
                if (filterConditions21.length) {
                    finalFilterString += ` and (${filterConditions21.join(' or ')})`;
                }
                if (filterConditions31.length) {
                    finalFilterString += ` and (${filterConditions31.join(' or ')})`;
                }
                if (filterConditions41.length) {
                    finalFilterString += ` and (${filterConditions41.join(' or ')})`;
                }
            }
            //	finalFilterString += "&$select=Id,EmpName,EmailId,ManagerLevel";
            return finalFilterString;
        },
        _callOREResourceService: function () {
            if (this.getView().getModel().getData().isResourceProfile && this.getView().getModel().getData().currentStepID ===
                "MANAPP") {
                const oRole = this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.Role_GUID;
                const oRoleArea = this.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails.RoleArea_P_GUID;
                const usersArray = this.getView().getModel().getData().aResourceProfileApprovers.ApproverDetails;
                const emailToFind = this.getOwnerComponent().getModel("userDetails").getProperty("/email");
                let userId;
                for (let i = 0; i < usersArray.length; i++) {
                    if (usersArray[i].email === emailToFind) {
                        userId = usersArray[i].ID;
                    }
                }
                // Retrieve the base URL for the ORE resources service
                const workflowBaseurl = this._getOREResourcesBaseURL();
                let filterResources = `?$filter=ManagerId eq '${userId}' and MelodyRequest eq 'X'&$orderby=CapEmpNme asc`
                let sUrl = workflowBaseurl + filterResources;
                this.getResources(sUrl, this);

            }
            const oResourceModel = this.getView().getModel("resourceModel");
            if (this.getView().getModel().getData().isResourceProfile && this.getView().getModel().getData().currentStepID === "MANAPP") {
                oResourceModel.getData().availableResources = this.getView().getModel("resourcesOREModel").getData();
                oResourceModel.getData().resourceHeaderCount = this.getView().getModel("resourcesOREModel").getData().length;
                oResourceModel.getData().Skip_Resource_Approver = this.getView().getModel().getProperty("/Skip_Resource_Approver");
            }
            oResourceModel.refresh();
            const aResources = this.getView().getModel("resourceModel").getData().availableResources;
            const aSelectedNominees = this.oContextAssignmentObj.PreviousSelectedNominees;
            aResources.forEach(function (resource) {
                for (let i = 0; i < aSelectedNominees.length; i++) {
                    if (resource.fullName === aSelectedNominees[i].fullName &&
                        resource.email === aSelectedNominees[i].email) {
                        resource.selected = true;
                        return true;
                    }
                }
            });
        },
        _setOreFilterModel: function (sTab) {
            let oMainModel = this.getView().getModel();
            let sSelectedTab = sTab || (oMainModel.getProperty("/bIsAdvancedSearch") ? 'customerAdvisory' : 'directReports');
              this.aFilters = [];
            this.getView().setModel(new sap.ui.model.json.JSONModel({
                "TempEmployee": {
                    "TempBAIndustries": [],
                    "BAIndustries": []
                },
                 "searchEmployee": "",
                "filter": {
                    "selectedTab": sSelectedTab,
                    "valueState":"None",
                    "searchEmployee": "",
                    "mangagerFilterEnable":sSelectedTab === 'customerAdvisory' ? true : false,
                    "NonSolutionAreaFocused": false,
                    "clearInputManagerFilter":"",
                    "clearInputRoleFilter":"",
                    "TempEmployee": {
                        "SolutionAreas": [],
                        "TempSolutionArea": []
                    },
                    "ManagerId": {
                        "SelectedKeys": []
                    },
                    "RolePrimary": {
                        "SelectedKeys": []
                    },
                    "ProfitCenter": {
                        "SelectedKeys": []
                    },
                    "Group": {
                        "SelectedKeys": []
                    },
                    "TempGroupFilters": [],
                    "SolutionArea": {
                        "SelectedKeys": []
                    },
                    "Industry": {
                        "SelectedKeys": []
                    },
                },
                "BAIndustries": [],
                "sSearchBoxText": "",
                "isFilter": true,
            }), "employee");
            
            this.getView().setModel(new sap.ui.model.json.JSONModel({
                "TempProfitCenter": {
                    "Territories": [],
                    "TempTreeTerritories": []
                },
                "filteredProfitCenter": [],
                "selectedPfc": ""
            }), "selectedProfitCenter");


        },
        _onOpenOREResourceDialog: function (oEvent) {
            let that = this;
            let oMainModel = that.getView().getModel();
            !oEvent ? oMainModel.setProperty("/bIsAdvancedSearch", true) : oMainModel.setProperty("/bIsAdvancedSearch", false);
            oMainModel.refresh();
            this._setOreFilterModel();
            this.getView().getModel().setProperty("/sortColumns", this.sortColumns());
              this.getView().getModel().refresh(true);
            this._oTPC_1 = false;
            this._onDestroyAllResourcePopOvers();
            that.aFilters = [];
            if (!this.pORESelectDialog) {
                this.pORESelectDialog = this.loadFragment({
                    name: "com.dealsupport.melodyrequest.fragments.managerPage.ResourcesPFC"
                });
            }
            if (oEvent) {
                const oModelData = this.getView().getModel("assignmentsModel").getData().assignments;
                let allNominees = oModelData.flatMap(obj => obj.selectedNominees);

                let uniqueNominees = Array.from(
                    new Map(allNominees.map(item => [item.userId, item])).values()
                );
                this.oContextAssignmentObj.PreviousSelectedNominees = uniqueNominees;
                this.getView().getModel("assignmentsModel").refresh();
            }
            this.getFilterSummaryText();
            if (oEvent) {
                this.getView().setModel(new sap.ui.model.json.JSONModel({ ApproverDetails: [] }), "selectedOREModel");
            }

            that.pORESelectDialog.then(function (oORESelectDialog) {
                let oDirectReportTable = this.byId("EmpDetailsTableID");
                let aCols = oDirectReportTable.getColumns();
                if (!this.getView().getModel("colModel")) {
                    let aColsData = aCols.map(function (col) {
                        return {
                            id: col.getId(),
                            text: col.getMultiLabels().length ? col.getMultiLabels()[0].getText() : col.getLabel().getText(),
                            visible: col.getVisible()
                        };
                    });
                    aColsData = aColsData.filter(item => item.text);
                    this.aDefaultColumns = JSON.parse(JSON.stringify(aColsData));
                    let oColsModel = new sap.ui.model.json.JSONModel({ columns: aColsData });
                    this.getView().setModel(oColsModel, "colModel");
                }
                if (!that.getView().getModel("resourcesCAModel")) {
                    that.getView().setModel(new JSONModel([]), "resourcesCAModel");
                }
                if (!that.getView().getModel("resourcesOREModel")) {
                    that.getView().setModel(new JSONModel([]), "resourcesOREModel");
                }
                that.aSelectionResArray = [];
                sap.ui.core.BusyIndicator.show();
                oORESelectDialog.addStyleClass(that.getOwnerComponent().getContentDensityClass());
                that.getView().getModel("resourceModel").setProperty("/resourceHeaderCount", 0);
                that.getView().getModel("resourceModel").setProperty("/availableResources", []);
                that.getView().getModel("resourceModel").refresh()
                if (that.getView().getModel("CAModel")) {
                    that.getView().getModel("CAModel").setProperty("/customerHeaderCount", 0);
                }
                oORESelectDialog.open();

                that._resetSearchField();
                if(this.getView().getModel("CAModel")){
                    this.getView().getModel("CAModel").setData([]);
                }
                if (this.getView().getModel("resourcesCAModel")) {
                    this.getView().getModel("resourcesCAModel").setData([]);
                }
                if (this.getView().getModel("searchResourcesCAModel")) {
                    this.getView().getModel("searchResourcesCAModel").setData([]);
                }
                if (this.getView().getModel("resourceModel")) {
                    this.getView().getModel("resourceModel").setData([]);
                }
                if (this.getView().getModel("resourcesOREModel")) {
                    this.getView().getModel("resourcesOREModel").setData([]);
                }
                if (this.getView().getModel("searchResourcesOREModel")) {
                    this.getView().getModel("searchResourcesOREModel").setData([]);
                }

                // if(!this.oContextAssignmentObj.selectedNominees){
                that.onTabSelect();
                that.loadTreeTerritories("treeTerritories", that.getView().getModel("territoriesMaster").getData());

                // }

            }.bind(this));
        },
_resetSearchField: function () {
    this.getView().byId("idOreSearchField").setValue("");
    this.getView().byId("idCustomerAdvisoryField").setValue("");
},

_attachTableEvents: function () {
    const that = this;
    const oTable = this.getView().byId("EmpDetailsTableID");
    oTable.getBinding("rows").attachChange(function (oEvent) {
        that._updateCount( "resourceModel", "/resourceHeaderCount", "/resourceCount");
    });

    const oCustomerTable = this.getView().byId("customerAdvisoryID");
    oCustomerTable.getBinding("rows").attachChange(function (oEvent) {
        that._updateCount("CAModel", "/customerHeaderCount", "/customerCount");
    });
},

_updateCount: function (modelName, headerProp, countProp) {
    let oModel = this.getView().getModel("employee");
    let iCount = 0;
    let that = this;

    if (modelName === "resourceModel") {
        const usersArray = this.getView().getModel().getData().aResourceProfileApprovers.ApproverDetails;
        const emailToFind = this.getOwnerComponent().getModel("userDetails").getProperty("/email");

        const user = usersArray.find(user => user.email === emailToFind);
        const userId = user ? user.ID : null;

        if (userId) {
            const workflowBaseurl = this._getOREResourcesBaseURL();
            const sUrl =  oModel.getProperty("/filter/filterQuery") ? `${workflowBaseurl}/$count${oModel.getProperty("/filter/filterQuery")}`:
            `${workflowBaseurl}/$count?$filter=ManagerId eq '${userId}' and MelodyRequest eq 'X'&$orderby=CapEmpNme asc`;

            iCount = this.getResourcesCount(sUrl, this,"resourceModel"); 
            that.getView().getModel("resourceModel").setProperty(headerProp, iCount, null, true);
    that.getView().getModel("resourceModel").setProperty(countProp, iCount, null, true);
        }
    } else {
        const ApproversOREUrl = this._getOREApproversBaseURL();
        const OREFilterUrl = oModel.getProperty("/filter/filterQuery") ? `/$count${oModel.getProperty("/filter/filterQuery")}`:"/$count?$filter=(MelodyRequest eq 'X')&$orderby=CapEmpNme asc";
        const serviceUrlORE = ApproversOREUrl + OREFilterUrl;

        iCount = this.getResourcesCount(serviceUrlORE, this,"CAModel");
        that.getView().getModel("CAModel").setProperty(headerProp, iCount, null, true);
    that.getView().getModel("CAModel").setProperty(countProp, iCount, null, true);
    }
},

getResourcesCount: function (url, self,sModelName) {
    let result = 0;
    $.ajax({
        url: url,
        async: false, 
        dataType: 'json',
        method: "GET",
        success: function (data) {
            result = data; 
            let iTotalLength = data ? data : 0;
            let oModel = self.getView().getModel(sModelName);
            let iAvailableResourceLength = oModel.getProperty("/availableResources") ? oModel.getProperty("/availableResources").length : 0;
            let iTotalResLength = `${iAvailableResourceLength}/${iTotalLength}`;
            let oTable = self.byId("EmpDetailsTableID");   // or Table ID
            let oBinding = oTable.getBinding("rows");
            iTotalResLength = sModelName === "resourceModel" ? `${oBinding.getLength()}/${oBinding.getLength()}` : iTotalResLength;
            oModel.setProperty("/iTotalResLength", iTotalResLength);
        },
        error: function (error) {
            ErrorHandle.setErrorMessage(error, self);
        }
    });
    return result; 
},

_updateAvailableResources: function (sSearchValue) {
    const oView = this.getView();
    const oAssignmentModel = oView.getModel("assignmentsModel");
    const oResourceModel = oView.getModel("resourceModel");
    const oUserModel = this.getOwnerComponent().getModel("userDetails");
    const oMainModel = oView.getModel();
const oResouceCAModelData = this.getView().getModel("resourcesCAModel") ? this.getView().getModel("resourcesCAModel").getData().filter(item => item.selected === true) : [];
    const oResouceOREModelData = this.getView().getModel("resourcesOREModel") ? this.getView().getModel("resourcesOREModel").getData().filter(item => item.selected === true) : [];
    let oSelectedCustomers = oResouceCAModelData;
      oSelectedCustomers = oSelectedCustomers.concat(oResouceOREModelData);
    
    const oAssignmentData = oAssignmentModel.getProperty("/assignments") || [];
    let oSelectedResources = oAssignmentData.flatMap(a => a.selectedNominees);
oSelectedResources = oSelectedResources.concat(oSelectedCustomers);
    const isResourceProfile = oMainModel.getProperty("/isResourceProfile");
    const currentStepID = oMainModel.getProperty("/currentStepID");
const workflowBaseurl = this._getOREResourcesBaseURL();
    if (isResourceProfile && currentStepID === "MANAPP") {
        const oProfileDetails = oMainModel.getProperty("/aResourceProfileApprovers/ResourceProfileDetails");
        const usersArray = oMainModel.getProperty("/aResourceProfileApprovers/ApproverDetails");
        const emailToFind = oUserModel.getProperty("/email");
        let oModel = this.getView().getModel("employee");
let sUrl;
       let filterResources ;
        
        if (oProfileDetails && usersArray && emailToFind) {
            const user = usersArray.find(user => user.email === emailToFind);
            if (user) {
                
                if(sSearchValue){
                    filterResources = `&$filter=ManagerId eq '${user.ID}' and MelodyRequest eq 'X'&$orderby=CapEmpNme asc`
                     sUrl = oModel.getProperty("/filter/filterQuery")  ?  workflowBaseurl + oModel.getProperty("/filter/filterQuery") : workflowBaseurl + "?search=" + sSearchValue + filterResources;
                    this.getResources(sUrl, this , sSearchValue);
                }else{
                    filterResources = `?$filter=ManagerId eq '${user.ID}' and MelodyRequest eq 'X'&$orderby=CapEmpNme asc`
                    sUrl = oModel.getProperty("/filter/filterQuery")  ? workflowBaseurl + oModel.getProperty("/filter/filterQuery") : workflowBaseurl + filterResources;
                    this.getResources(sUrl, this);
                }
            }
        }

       const oResourcesOREModel = sSearchValue ? oView.getModel("searchResourcesOREModel") : oView.getModel("resourcesOREModel");
        if (oResourcesOREModel) {
            const oResourcesData = oResourcesOREModel.getData();
            oResourceModel.setProperty("/availableResources", oResourcesData);
            oResourceModel.setProperty("/Skip_Resource_Approver", oMainModel.getProperty("/Skip_Resource_Approver"));
        }
    }

    oResourceModel.refresh();

    const aResources = oResourceModel.getProperty("/availableResources") || [];
    let aSelectedNominees = this.oContextAssignmentObj?.selectedNominees || [];
oSelectedResources = oSelectedResources.concat(aResources);
    aSelectedNominees = aSelectedNominees.concat(oSelectedResources);
    oResourceModel.refresh();
    let iAvailableResourceLength = oResourceModel.getProperty("/availableResources") ? oResourceModel.getProperty("/availableResources").length : 0;
    let iTotalResLength = `${iAvailableResourceLength}/${oResourceModel.getProperty("/resourceHeaderCount")}`;
    oResourceModel.setProperty("/loadedData", iAvailableResourceLength);
    oResourceModel.setProperty("/iTotalResLength",iTotalResLength);
    oAssignmentModel.refresh();
     const oModelData = this.getView().getModel("assignmentsModel").getData().assignments;
            let allNominees = oModelData.flatMap(obj => obj.selectedNominees);

 
    // let oSelectedNominees = uniqueNominees.length ? uniqueNominees : this.oContextAssignmentObj.selectedNominees;
    let oSelectedNominees = aSelectedNominees.length ? aSelectedNominees.filter(item => item.selected === true) : [];
    // //skip resource
    if (aResources.length) {
        this._updateSkipResSelectBtn(aResources);
    }
   oSelectedNominees.forEach(prevNominee => {
    let found =  this.oContextAssignmentObj.PreviousSelectedNominees && this.oContextAssignmentObj.PreviousSelectedNominees.length ? this.oContextAssignmentObj.PreviousSelectedNominees.find(uniqueObj => uniqueObj.userId === prevNominee.userId):false;
    if (found) {
        found.enabled = false;
        found.btnEnabled = false;
    }
    if(this.oContextAssignmentObj.selectedNominees.filter(item=> item.userId === prevNominee.userId).length){
        found.enabled = true;
        found.btnEnabled = true;
    }
});
    let uniqueNominees = Array.from(
    new Map(oSelectedNominees.map(item => [item.userId, item])).values()
);
           if (uniqueNominees.length) {
    aResources.forEach(function (resource) {
        for (let i = 0; i < uniqueNominees.length; i++) {
            if (resource.fullName === uniqueNominees[i].fullName &&
                resource.email === uniqueNominees[i].email) {
                
                resource.selected = true;
                resource.enabled = uniqueNominees[i].enabled;
                resource.btnEnabled = uniqueNominees[i].btnEnabled;
                return; 
            }
        }
    });
}
let that = this;
if(that.aSelectionResArray.length && aResources.length){
    aResources.forEach(function (resource) {
        for (let i = 0; i < that.aSelectionResArray.length; i++) {
            if (resource.fullName === that.aSelectionResArray[i].fullName &&
                resource.email === that.aSelectionResArray[i].email) {
                resource.selected = that.aSelectionResArray[i].tempSelect;
            }
        }
    });
}
oResourceModel.refresh();
    
},
        _updateSkipResSelectBtn: function (aResources) {
            let that = this
            let aPrevSelect = [];
            this.oContextAssignmentObj.selectedNominees.forEach(function (seleRes) {
                if (seleRes) {
                    let prevEmpObj = that.oContextAssignmentObj.PreviousSelectedNominees.filter(item => item.userId !== seleRes.userId);
                    aPrevSelect = aPrevSelect.concat(prevEmpObj);
                    return;
                }
            });
            aResources.forEach(function (skipRes) {
                if (aPrevSelect.length && aPrevSelect.filter(item => item.userId === skipRes.userId).length) {
                    skipRes.enabled = false;
                    skipRes.btnEnabled = false;
                } else if (!aPrevSelect.length && that.oContextAssignmentObj.PreviousSelectedNominees.length
                    && that.oContextAssignmentObj.PreviousSelectedNominees.filter(item => item.userId === skipRes.userId).length) {
                    skipRes.enabled = false;
                    skipRes.btnEnabled = false;
                }else{
                    skipRes.enabled = true;
                    skipRes.btnEnabled = true;
                }
            });
        
        },

_updateAvailableCustomers: function (sSearchValue) {
    let bIsAdvancedSearch = this.getView().getModel().getProperty("/bIsAdvancedSearch");
    const oView = this.getView();
    let oAssignmentData;
    let oSelectedNominees;
    let oSelectedCustomers = [];
    if(!bIsAdvancedSearch){
        oAssignmentData = oView.getModel("assignmentsModel").getData().assignments;
        oSelectedNominees = oAssignmentData.flatMap(a => a.selectedNominees);
        const oResouceCAModelData = this.getView().getModel("resourcesCAModel") ? this.getView().getModel("resourcesCAModel").getData().filter(item => item.selected === true) : [];
        const oResouceOREModelData = this.getView().getModel("resourcesOREModel") ? this.getView().getModel("resourcesOREModel").getData().filter(item => item.selected === true) : [];
        let oSelectedCustomers = oSelectedNominees.concat(oResouceCAModelData);
        oSelectedCustomers = oSelectedCustomers.concat(oResouceOREModelData);
        oSelectedCustomers = oSelectedCustomers.concat(oSelectedNominees);
        oSelectedCustomers = oSelectedCustomers.concat(this.oContextAssignmentObj.selectedNominees);
    } 
    const ApproversOREUrl = this._getOREApproversBaseURL();
     let oModel = this.getView().getModel("employee");
    const serviceUrlORE = oModel.getProperty("/filter/filterQuery") ? `${ApproversOREUrl}${oModel.getProperty("/filter/filterQuery")}`
        : `${ApproversOREUrl}?$filter=(MelodyRequest eq 'X')&$orderby=CapEmpNme asc`;
    this.getCAResources(serviceUrlORE, this, sSearchValue);
    const oCAModel = oView.getModel("CAModel");
    const oResourcesCAModelData = sSearchValue ? oView.getModel("searchResourcesCAModel").getData() : oView.getModel("resourcesCAModel").getData();
    oCAModel.setProperty("/availableResources", oResourcesCAModelData);
    if (this.getView().getModel().getProperty("/bIsAdvancedSearch")) {
        // for advanced search
        this._setSelectedProcessor();
    }

    oCAModel.getData().resourceHeaderCount = oView.getModel("resourcesOREModel").getData().length;
    oCAModel.getData().Skip_Resource_Approver = oView.getModel().getProperty("/Skip_Resource_Approver");
    let iAvailableResourceLength = oCAModel.getProperty("/availableResources") ? oCAModel.getProperty("/availableResources").length : 0;
    let iTotalResLength = `${iAvailableResourceLength}/${oCAModel.getProperty("/customerHeaderCount")}`;
    oCAModel.setProperty("/loadedData",iAvailableResourceLength);
    oCAModel.setProperty("/iTotalResLength",iTotalResLength);


    const oCustomerList = oCAModel.getProperty("/availableResources");
 let aSelectedNominees = oSelectedCustomers.length && !bIsAdvancedSearch ? oSelectedCustomers.filter(item => item.selected === true) : [];
  if (oCustomerList.length) {
    this._updateSkipResSelectBtn(oCustomerList);
}
 let uniqueNominees = Array.from(
    new Map(aSelectedNominees.map(item => [item.userId, item])).values()
);
   uniqueNominees.forEach(prevNominee => {
    let found = this.oContextAssignmentObj.PreviousSelectedNominees.find(uniqueObj => uniqueObj.userId === prevNominee.userId);
    if (found) {
        found.enabled = false;
        found.btnEnabled = false;
    }
    if(this.oContextAssignmentObj.selectedNominees.filter(item=> item.userId === prevNominee.userId).length){
        prevNominee.enabled = true;
        prevNominee.btnEnabled = true;
    }
});
    if (uniqueNominees.length) {
    oCustomerList.forEach(function (resource) {
        for (let i = 0; i < uniqueNominees.length; i++) {
            if (resource.fullName === uniqueNominees[i].fullName &&
                resource.email === uniqueNominees[i].email) {
                
                resource.selected = true;
                resource.enabled = uniqueNominees[i].enabled;
                resource.btnEnabled = uniqueNominees[i].btnEnabled;
                return; 
            }
        }
    });
}
let that = this;
if(that.aSelectionResArray.length && oCustomerList.length){
    oCustomerList.forEach(function (resource) {
        for (let i = 0; i < that.aSelectionResArray.length; i++) {
            if (resource.fullName === that.aSelectionResArray[i].fullName &&
                resource.email === that.aSelectionResArray[i].email) {
                resource.selected = that.aSelectionResArray[i].tempSelect;
            }
        }
    });
}
    oCAModel.refresh();
},

onTabSelect: function (oEvent) {
    sap.ui.core.BusyIndicator.show(0);
    const sSelectedKey = this.getView().getModel("employee").getProperty("/filter/selectedTab");
    this.getView().byId("EmpDetailsTableID").setFirstVisibleRow(0);
    this.getView().byId("customerAdvisoryID").setFirstVisibleRow(0);
    
    let that = this;
    const oView = this.getView();
    this._resetSearchField();
    const toggleVisibility = (showDirectReports) => {
        oView.byId("EmpDetailsTableID").setVisible(showDirectReports);
        oView.byId("idCustomerAdvisoryBox").setVisible(!showDirectReports);
    };

    const resetModel = (modelName, currentPageProp, updateFn, headerCountProp, countProp , that) => {
        const oModel = oView.getModel(modelName);
        if (oModel.getProperty(currentPageProp)) {
            oModel.setProperty(currentPageProp, 0);
        }
        updateFn.call(that);
        that._updateCount(modelName, headerCountProp, countProp);
        oModel.refresh(true);
    };

    switch (sSelectedKey) {
        case "directReports":
             sap.ui.core.BusyIndicator.show();
            setTimeout(function() {
						   
            toggleVisibility(true);
            resetModel("resourceModel", "/currentPage", that._updateAvailableResources, "/resourceHeaderCount", "/resourceCount", that);
               
                  sap.ui.core.BusyIndicator.hide();
             },1000);
            break;

        case "customerAdvisory":
             sap.ui.core.BusyIndicator.show();
            setTimeout(function() {
			 toggleVisibility(false);
            
            resetModel("CAModel", "/currentCAPage", that._updateAvailableCustomers, "/customerHeaderCount", "/customerCount" , that);
               
                sap.ui.core.BusyIndicator.hide();
                },1000);
            
            
            break;

        default:
            break;
    }

    oView.getModel("resourceModel").refresh(true);
    oView.getModel("CAModel").refresh(true);
},

onSelectOREResources: function (evt) {
    sap.ui.core.BusyIndicator.show();

    let oResourceModelData = this.getView().getModel("resourceModel").getProperty("/availableResources");
    let oResourceCAModelData = this.getView().getModel("CAModel") && this.getView().getModel("CAModel").getData().length ? this.getView().getModel("CAModel").getProperty("/availableResources") : [];
    let aResourcesOREModel = this.getView().getModel("resourcesOREModel") ? this.getView().getModel("resourcesOREModel").getData() : [];
    let aResourcesCAOREModel = this.getView().getModel("resourcesCAModel") && this.getView().getModel("resourcesCAModel").getData().length ? this.getView().getModel("resourcesCAModel").getData() : [];
    let aSearchResourceModel = this.getView().getModel("searchResourcesOREModel") && this.getView().getModel("searchResourcesOREModel").getData().length ? this.getView().getModel("searchResourcesOREModel").getData() : [];
    let aSearchCAModel = this.getView().getModel("searchResourcesCAModel") && this.getView().getModel("searchResourcesCAModel").getData().length ? this.getView().getModel("searchResourcesCAModel").getData() : [];
    let that = this;
     let aDeletedResources = [];
    if (this.oContextAssignmentObj.selectedNominees.length && this.aSelectionResArray.length) {
        aDeletedResources = [];
        for(let i=0;i<that.oContextAssignmentObj.selectedNominees.length;i++){
            // Filter the array of selected resources (aSelectionResArray) to find any user that matches the userId 
            // of the current nominee being processed (oContextAssignmentObj.selectedNominees[i]).
            // The result is stored in the variable bUser.
            let bUser = that.aSelectionResArray.filter(item => that.oContextAssignmentObj.selectedNominees[i].userId === item.userId);
                if (bUser.length && !bUser[0].tempSelect) {
                    aDeletedResources.push(that.oContextAssignmentObj.selectedNominees.filter(item=> item.userId === bUser[0].userId)[0])
                }
        }
        const aDeletedArray = new Set(aDeletedResources.map((el) => el.userId));
        // This ensures that each user ID is only stored once, eliminating duplicates.
        that.oContextAssignmentObj.selectedNominees = that.oContextAssignmentObj.selectedNominees.filter((el) => !aDeletedArray.has(el.userId));
    }
    this.getView().getModel("assignmentsModel").refresh();
var combinedResources = this.oContextAssignmentObj.selectedNominees.concat(oResourceModelData);
combinedResources = combinedResources.concat(aResourcesOREModel);
    combinedResources = combinedResources.concat(oResourceCAModelData);
    combinedResources = combinedResources.concat(aResourcesCAOREModel);
    combinedResources = combinedResources.concat(aSearchResourceModel);
    combinedResources = combinedResources.concat(aSearchCAModel);

    if(aDeletedResources.length && combinedResources.length){   
        combinedResources.forEach(function(cmbRes){
            if(aDeletedResources.filter(item=> item.userId === cmbRes.userId).length){
                cmbRes.selected = false;
            }
        });
    }

   let aFinalCombinedResources = combinedResources.filter(user => user.selected === true && user.enabled === true);
    let uniqueUsers = aFinalCombinedResources.filter(
    (resource, index, self) =>
        index === self.findIndex((r) => r.userId === resource.userId)
);
let aAssignments =  this.getView().getModel("assignmentsModel").getData().assignments,
aAssignmentsNomArray = [];
aAssignments.forEach(item=>item.selectedNominees.length ? aAssignmentsNomArray.push(true):false);
let aToken = aAssignmentsNomArray.length > 1 && this.oContextAssignmentObj.PreviousSelectedNominees && this.oContextAssignmentObj.PreviousSelectedNominees.length ? uniqueUsers.filter(element => this.oContextAssignmentObj.PreviousSelectedNominees.some(item => item.userId != element.userId)) : uniqueUsers;
    aToken.forEach(item => item.tempSelect = true);
    setTimeout(function() {
        that._onSelectResources(aToken);
       
    },1000);
    this.onCloseOREResource();
},
        onCloseOREResource: function (oEvent) {
            // if(oEvent && !this.getView().getModel().getProperty("/Skip_Resource_Approver")) {
            //     this.oContextAssignmentObj.selectedNominees = this.oContextAssignmentObj.selectedNominees ? this.oContextAssignmentObj.selectedNominees.filter(item => item.tempSelection === false) : [];
            // }
            this.getView().getModel("assignmentsModel").refresh();
            let that = this;
            if (this.pORESelectDialog) {
                this.pORESelectDialog.then(function (oDialog) {
                    if (that.getView().getModel().getProperty("/bIsAdvancedSearch")) {
                        that._setEditProcessorData();
                    }
                    oDialog.close();
                });
            }
        },
        onORESearchResources: function (oEvent, isLiveSearch) {
            const isDirectReports = this.getView().getModel("employee").getProperty("/filter/selectedTab") === "directReports";
            const sModelName = isDirectReports ? "resourceModel" : "CAModel";
            const aModelName = isDirectReports ? "resourcesOREModel" : "resourcesCAModel";
            this.getView().byId("customerAdvisoryID").setBusy(true);
        
            const sSearchValue = isLiveSearch 
                ? oEvent.getParameter("newValue") 
                : oEvent.getParameter("query");
        
            const oModel = this.getView().getModel(sModelName);
            oModel.setProperty(isDirectReports ? "/currentPage" : "/currentCAPage", 1);
        
            
                const oResourcesOREModel = this.getView().getModel(aModelName);
                const oResourceModel = this.getView().getModel(sModelName);
                const availableResources = oResourceModel.getProperty("/availableResources") || [];
        
                let aUpdatedData = oResourcesOREModel.getData() || [];
        
                aUpdatedData.forEach(updatedItem => {
                    const matchedResource = availableResources.find(resource => 
                        resource.userId === updatedItem.userId && resource.selected
                    );
                    if (matchedResource) updatedItem.selected = true;
                });
        
                availableResources.forEach(resource => {
                    if (!aUpdatedData.some(item => item.userId === resource.userId)) {
                        aUpdatedData.push(resource);
                    }
                });
        
                aUpdatedData = [...new Map(aUpdatedData.map(item => [item.userId, item])).values()];
        
                aUpdatedData.sort((a, b) => (b.selected === true) - (a.selected === true));
        
                oResourcesOREModel.setData(aUpdatedData);
        
                if (oResourcesOREModel) {
                    oResourceModel.setProperty("/availableResources", aUpdatedData);
                    oResourceModel.setProperty(
                        "/Skip_Resource_Approver",
                        this.getView().getModel().getProperty("/Skip_Resource_Approver")
                    );
                }
        
                oResourceModel.refresh();
            if(sSearchValue) {
                isDirectReports
                    ? this._updateAvailableResources(sSearchValue)
                    : this._updateAvailableCustomers(sSearchValue);
            }
             this.getView().byId("customerAdvisoryID").setBusy(false);
        },
        
        
        _onSelectResources: async function (aToken) {
            const bSkipResources = this.getView().getModel().getProperty("/Skip_Resource_Approver");
            const oAssignmentsModel = this.getView().getModel("assignmentsModel");
            var bIsManRoleIDPresent = true
            aToken.forEach(obj => {
                if (!obj.resourceManagerDetails.ROLE) {
                    bIsManRoleIDPresent = false
                }
            })
            if (!bIsManRoleIDPresent) {
                const aResManagerIDs = aToken.map(app => app.resourceManagerDetails.ID);
                const sFilterCondition = `(${aResManagerIDs.map(userId => `(Id eq '${userId}')`).join(' or ')})`;
                var currController = this
                sUrlParams = {
                    $filter: sFilterCondition,
                }
                //oData get call for role
                const oIntLSModel = Models.systemLSUserDetailsDataModel(this, this)

                try {
                    var data = await Models._callGETOdata(oIntLSModel, `/YC_DS_T_NAMED_CONTACT`, sUrlParams)
                    if (data.results.length) {
                        var namedContactDataMap = new Map()
                        data.results.forEach(namedContactData => {
                            namedContactDataMap.set(namedContactData.Id, {
                                EMAIL: namedContactData.EmailId,
                                ID: namedContactData.Id,
                                NAME: namedContactData.EmpName,
                                ROLE: namedContactData.Emp_CrmRoleId
                            })
                        })
                        aToken.forEach(token => {
                            token.resourceManagerDetails = namedContactDataMap.get(token.resourceManagerDetails.ID)
                        })


                    }
                } catch (err) {
                    ErrorHandle.setErrorMessage(err, currController);

                }
            }
            this.oContextAssignmentObj.selectedNominees = aToken;
            //call ORE service to fetch role,roleArea, manager level etc
            for(let i=0; i<aToken.length;i++){
                const sResourceId = aToken[i].userId;
                const workflowBaseurl = this._getOREResourcesBaseURL();
                const that = this;
                const sUrl = workflowBaseurl + `?$filter=ManagerId eq '${sResourceId}' and ManagerLevel eq 'non-managerial' and MelodyRequest eq 'X' and ( not(RoleId eq '0001') or not(RoleId eq '0016') )&$select=ResourceId,ManagerLevel,RoleId,RoleAreaId,BaLobDesc,CrossCvrgDesc,BaIndDesc,BaId&$orderby=CapEmpNme asc`;

                $.ajax({
                    url: sUrl,
                    dataType: 'json',
                    async: false,
                    method: "GET",
                    success: function (data) {
                        const oData = data.d.results,
                            aResourceData = oData.filter((resource) => resource.ResourceId === aToken[i].userId),
                            sRoleId = aResourceData.length ? aResourceData[0].RoleId : "",
                            sRoleAreaId = aResourceData.length ? aResourceData[0].RoleAreaId : "",
                            sManagerLevel = aResourceData.length ? aResourceData[0].ManagerLevel : "";
                            // aToken[i].sResEngagementType = (sRoleId === "0023") ? "0002" : "0001";
                        let sBAId = "*";
                        if (aResourceData.length) {
                            sBAId = aResourceData[0].BaId ? aResourceData[0].BaId : "*";
                        };
                             let sFilterUrl = `$filter=(role_ID eq '${sRoleId}' and role_Area_ID eq '${sRoleAreaId}' and manager_level eq '${sManagerLevel}' and (BA_ID eq '${sBAId}' or BA_ID eq '*'))&$orderby=BA_ID desc&$top=1`;
                             let sFinalUrl = that._getRuntimeBaseURL() + `/cap/req-area-api-/Presales_role?${sFilterUrl}`;
                             if(aResourceData.length){
                                aToken[i].oREData = false;
                                $.ajax({
                                    contentType: "application/json",
                                    url: sFinalUrl,
                                    async: false,
                                    type: "GET",
                                    success: function (response) {
                                        if(response.value.length){
                                            aToken[i].oREData = true;
                                            aToken[i].assignedRoleData = {
                                                name: response.value[0].CRM_Role_Desc,
                                                id: response.value[0].CRM_Role_ID
                                            }
                                        }else{
                                            aToken[i].oREData = false;
                                        }
                                    },
                                    error: function (oError) {
                                        ErrorHandle.setErrorMessage(oError, that);
                                    }
                                });
                             }else{
                                aToken[i].oREData = false;
                             }
                    },
                    error: function (error) {
                        ErrorHandle.setErrorMessage(error, that);
                    }
                });  
            }
            const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            const aNotOREData = aToken.filter((res) => !res.oREData);
            if(aNotOREData.length){
                //Resource not maintained in ORE - resource should not add trigger validation
                this.sSelectedRes = "";
                let aValidatedRes = [];
                let that = this;
                aToken.forEach(function(nom){
                    if(!nom.oREData){
                        let sUserName = nom.fullName;
                        let sUserId = nom.userId ?  nom.userId:"";
                        let sUser = `- ${sUserName} (${sUserId})`;
                        that.sSelectedRes = that.sSelectedRes + "\n" +sUser
                    }else{
                        aValidatedRes.push(nom);
                    }
                });
                const sOreResourceValidationStartMsg = i18nModel.getText("oreResourceValidationStart");
                MessageBox.warning(`${sOreResourceValidationStartMsg} \n${this.sSelectedRes}`);
                this.oContextAssignmentObj.selectedNominees = aValidatedRes;
            }else{
                this.oContextAssignmentObj.selectedNominees = aToken;
            }

            if (this.getView().getModel().getProperty("/RequestType") === "Opportunity") {
                const sFinalOrgID = this.getView().getModel().getProperty("/oppOrgId") ?  this.getView().getModel().getProperty("/oppOrgId"):this.getView().getModel().getProperty("/OrgID");
                const sSalesOrg = sFinalOrgID.replace('SORG-', '');
                var that = this;
                this.oContextAssignmentObj.selectedNominees.forEach(function (token, iIndex) {
                    let sUserId = token.userId.toUpperCase();
                    if (that.oContextAssignmentObj.isIOStaffing) {
                        Models._CallautoStaffingAPI(sUserId, 100, 0, that, sSalesOrg, token);
                        //	token.isAutoStaffing = false;
                        if (!token.isAutoStaffing) {
                            //Change Request to IO Staffing Working for EMEA #93 start
                            //check company code eq to sales org for the resource and auto staffing
                            let bSkipIOFlag = that.getView().getModel("WFRoutingSkipIOAPIData").getProperty("/value/0/operationalStatus");
                            if (token.sCompanyCode === sSalesOrg || !bSkipIOFlag) {
                                //company code  eq to sales org --> show staffing fields
                                that.oContextAssignmentObj.isStaffingFields = true;
                                token.isAutoStaffingCompanyCode = token.sCompanyCode === sSalesOrg ? true : false;
                                token.isStaffing = true;
                                that.oContextAssignmentObj.staffingPurposeVisible = true;
                                that.oContextAssignmentObj.expectedTimeInvstementVisible = false;
                                that.oContextAssignmentObj.ioOwnerFieldVisible = that.oContextAssignmentObj.isOppOwnerActive;
                                that.oContextAssignmentObj.ioOwnerTextFieldVisible = true;
                                that.oContextAssignmentObj.staffingDateRangeVisible = true;
                                that.oContextAssignmentObj.maxNoOfDaysToBookIOVisible = true;
                                that.oContextAssignmentObj.taskLevelVisible = true;
                            }else if(!bSkipResources){
                                //company code not eq to sales org --> hide staffing fields --> no IO trigger for staffing
                                token.isAutoStaffingCompanyCode = false;
                                token.isStaffing = false;
                                Models._callExceptionTable(token.sCompanyCode, token.sCostCenter,that.getView().getModel().getData().EngagementType, sSalesOrg, sUserId, that, that.fnExceptionCallback, that.fnExceptionErrorCallback, token);
                            }
                              //Change Request to IO Staffing Working for EMEA #93 end
                            if (bSkipResources) {
                                //skip resources ---> Presales Manager Approval task to completes the wf
                                if (token.sCompanyCode === sSalesOrg) {
                                    //company code of the resources matches sales org of the opportunity
                                    token.isAutoStaffingCompanyCode = true;
                                    token.isStaffing = true;
                                    //Call userSearchHelps to fetch the perner number for staffing
                                    Models._callUserSearchHelps(token.userId, that, that.fnSuccessUserSearchHelpsCallBack, that.fnErrorUserSearchHelpsCallBack, token);
                                } else {
                                    //check exception table maintained
                                    token.isStaffing = false;
                                    token.isAutoStaffingCompanyCode = false;
                                    Models._callExceptionTable(token.sCompanyCode, token.sCostCenter,that.getView().getModel().getData().EngagementType ,sSalesOrg, sUserId, that, that.fnExceptionSuccessCallback, that.fnExceptionErrorCallback, token);
                                }
                            }
                            
                        } else {
                            that.oContextAssignmentObj.expectedTimeInvstementVisible = true;
                        }
                    }

                });
            }
            this.getView().getModel("assignmentsModel").refresh();
            this._fnResourceValidation(this.oContextAssignmentObj.selectedNominees, this.oContextAssignmentObj);
            this.oContextAssignmentObj.activities = [{
                "selectedActivity": "",
                "activityPaylod": {},
                "actValueState": "None",
                "enableRegEdit": false,
                "activityDelete": false,
            }
            ];
            this.oContextAssignmentObj.RoleFieldVisible = true;
            if (this.getView().getModel().getProperty("/solutionAreaPayload") && !this.getView().getModel().getProperty("/solutionAreaPayload").length && this.oContextAssignmentObj.selectedNominees.length && this.oContextAssignmentObj.selectedNominees[0].SolId) {
                let aResSolnId = new Array(this.oContextAssignmentObj.selectedNominees[0].SolId);
                this._getSolnAreaFullHiearchy(aResSolnId, oAssignmentsModel)
            } else {
                this._callActivityTypeMasterData(this.oContextAssignmentObj);
                oAssignmentsModel.refresh(true);
                this.oNomineeValueHelpControl.setBusy(false);
                sap.ui.core.BusyIndicator.hide();
            }
          
          

        },
        _setStaffingMsg:function(aSelectedResource,oAssignments){
            let bSkipIOFlag = this.getView().getModel("WFRoutingSkipIOAPIData").getProperty("/value/0/operationalStatus");
            const bSkipResources = this.getView().getModel().getProperty("/Skip_Resource_Approver"),
                  aFilteredResources = aSelectedResource.filter(res => !res.isStaffing);
            if (aFilteredResources.length && bSkipIOFlag) {
                const aSelectedNom = aFilteredResources.map(nom => nom.fullName),
                    sNomNames = aSelectedNom.toString(),
                    sI18nStartMsg = this.i18nModel.getText("staffingMsgStart"),
                    sI18nEndMsg = this.i18nModel.getText("staffingMsgEnd");
                // oAssignments.staffingMsg = bSkipResources ? `${sI18nStartMsg} (${sNomNames}) ${sI18nEndMsg}` : `${sI18nStartMsg}(s)(${sNomNames}) ${sI18nEndMsg}`;
                if(this.getOwnerComponent().getModel("appConstants").getProperty("/ManualStaffing/0/Operational_Status")){
                    oAssignments.staffingMsgVisible = true;
                }
               
            }else{
                 oAssignments.staffingMsgVisible = false;
            }
             this.getView().getModel("assignmentsModel").refresh();
        },
        onSelectSkipResource: function (evt) {
            sap.ui.core.BusyIndicator.show();
            let that = this;
        
            const sSelectedKey = this.getView().getModel("employee").getProperty("/filter/selectedTab");
            const oSource = evt.getSource();
            let aToken = [];
        
            if (sSelectedKey === "directReports" || sSelectedKey === "customerAdvisory") {
                const sModelName = sSelectedKey === "directReports" ? "resourceModel" : "CAModel";
                aToken = [oSource.getBindingContext(sModelName).getObject()];
            }
        this.oContextAssignmentObj.PreviousSelectedNominees = aToken;
           
        setTimeout(function() {
            that._onSelectResources(aToken);
           
        },1000);
            this.onCloseOREResource();
        },
        
        onHighlightOreResources: function (evt) {
            const aTableRows = this.byId("EmpDetailsTableID").getRows();
            let that = this;
            for (let i = 0; i < aTableRows.length; i++) {
                if (aTableRows[i].getBindingContext("resourceModel").getObject().selected) {
                    that.byId("EmpDetailsTableID").getRows()[i]._setSelected(true);
                } else {
                    that.byId("EmpDetailsTableID").getRows()[i]._setSelected(false);
                }
            }
        },
        onSelectORECheckBox: function (evt) {
            evt.getSource().getParent()._setSelected(evt.getParameter("selected"));
           // evt.getSource().getParent().getBindingContext("resourceModel").getObject().tempSelection = true;
            if(!evt.getParameter("selected")){
                evt.getSource().getParent().getBindingContext("resourceModel").getObject().tempSelection = true;
                evt.getSource().getParent().getBindingContext("resourceModel").getObject().tempSelect = false; 
               // this.oContextAssignmentObj.selectedNominees.length ? this.oContextAssignmentObj.selectedNominees.filter(item => item.userId !== evt.getSource().getParent().getBindingContext("resourceModel").getObject().userId) : [];
            }else{
                evt.getSource().getParent().getBindingContext("resourceModel").getObject().tempSelection = false;
                evt.getSource().getParent().getBindingContext("resourceModel").getObject().tempSelect = true;
              //  this.oContextAssignmentObj.selectedNominees.push(evt.getSource().getParent().getBindingContext("resourceModel").getObject());
           }
           let bTempSelect
          if( this.aSelectionResArray.length){
            this.aSelectionResArray.forEach(function(res){
                if(res.userId === evt.getSource().getParent().getBindingContext("resourceModel").getObject().userId ){
                    res.tempSelect = evt.getSource().getParent().getBindingContext("resourceModel").getObject().tempSelect;
                }else{
                    bTempSelect = true;
                }
            });
          }else{
            bTempSelect = true;
          }
          if(bTempSelect){
            this.aSelectionResArray.push(evt.getSource().getParent().getBindingContext("resourceModel").getObject());
          }
        },
        onSelectCACheckBox: function (evt) {
            evt.getSource().getParent()._setSelected(evt.getParameter("selected"));
          //  evt.getSource().getParent().getBindingContext("CAModel").getObject().tempSelection = true;
            if(!evt.getParameter("selected")){
                evt.getSource().getParent().getBindingContext("CAModel").getObject().tempSelection = true;
                evt.getSource().getParent().getBindingContext("CAModel").getObject().tempSelect = false;
                //this.oContextAssignmentObj.selectedNominees.length ? this.oContextAssignmentObj.selectedNominees.filter(item => item.userId !== evt.getSource().getParent().getBindingContext("CAModel").getObject().userId) : [];
           }else{
                evt.getSource().getParent().getBindingContext("CAModel").getObject().tempSelection = false;
                evt.getSource().getParent().getBindingContext("CAModel").getObject().tempSelect = true;
                //  this.oContextAssignmentObj.selectedNominees.push(evt.getSource().getParent().getBindingContext("CAModel").getObject());
           }
            let bTempSelect
          if( this.aSelectionResArray.length){
            this.aSelectionResArray.forEach(function(res){
                if(res.userId === evt.getSource().getParent().getBindingContext("CAModel").getObject().userId ){
                    res.tempSelect = evt.getSource().getParent().getBindingContext("CAModel").getObject().tempSelect;
                }else{
                    bTempSelect = true;
                }
            });
          }else{
            bTempSelect = true;
          }
          if(bTempSelect){
            this.aSelectionResArray.push(evt.getSource().getParent().getBindingContext("CAModel").getObject());
          }
        },
        _setFooterButtonDefaultVisibility: function () {
            const oFormActionsModel = this.getView().getModel("formActionsConfigModel");
            //Git 220 -- enable all manager actions
            this.getView().byId("idManagerRejectBtn").setVisible(!!(oFormActionsModel.getProperty("/idreject/0/Visibility")));
            this.getView().byId("idManagerApproveBtn").setVisible(!!(oFormActionsModel.getProperty("/idapprove/0/Visibility")));
            this.getView().byId("idManagerSbr").setVisible(!!(oFormActionsModel.getProperty("/idrework/0/Visibility")));
            // this.getView().byId("idManagerForward").setVisible(!!(oFormActionsModel.getProperty("/idforward/0/Visibility")));
            //GIT 270,290- set the visibility of edit profile and edit processor links
            this.getView().byId("idPanelEditProcessor").setVisible(!!(oFormActionsModel.getProperty("/idforward/0/Visibility")));
            this.getView().byId("idPanelEditProfile").setVisible(!!(oFormActionsModel.getProperty("/idforward/0/Visibility")));
            this.getView().byId("idSaveandSubmitBtn").setVisible(false);
            this.getView().byId("idCancelAssignmentBtn").setVisible(false);
        },
        onManagerProceedToApprove: function () {
            const model = this.getView().getModel();
            model.refresh(true);
            const sStep = this.getView().getModel().getProperty("/currentStepID");
            const oThisController = this;
            if (sStep === "MANAPP") {
               //Call opportunity service to update internal order end
                let sInternalOrder1 = this.getView().getModel().getProperty("/INTERNAL_ORDER1");
                let sInternalOrder2 = this.getView().getModel().getProperty("/INTERNAL_ORDER2");
                let aInternalOrder = [
                    sInternalOrder1 ? sInternalOrder1 : "",
                    sInternalOrder2 ? sInternalOrder2 : ""
                ].filter(io => io)
                this.getView().getModel("internalOrderModel").setData(aInternalOrder);
                if (aInternalOrder.length) {
                    const sStep = this.getView().getModel().getProperty("/currentStepID");
                    this.getView().getModel().setProperty("/internalOrder", aInternalOrder[0]);
                    if (sStep === "MANAPP") {
                        //set staffing purpose model(activities)
                        if (!(this.getView().getModel("ddlbModelActexp")&& this.getView().getModel("ddlbModelActexp").getData() && this.getView().getModel("ddlbModelActexp").getData().results.length)) {
                            Models._getActExpData(this);
                        }
                        //call service for IO Owner
                        // Models.getIoOwnerData(this, aInternalOrder[0]);
                        //call tasklevel master data
                        Models._getTaskLevelSet(this, aInternalOrder[0]);
                        //get IOOwner details
                        Models._getIOOwnerDetails(this, aInternalOrder[0]);
                    }
                }
                // Git 220 Implementation for the save and submit action for Assignment
                   //set Activity team(Manager or Subst manager) details
                if (this.getView().getModel().getProperty("/currentStepID") === "MANAPP") {
                    this._setActTeamValue();
                    this.setSolutionArea();
                }
                oThisController.getView().byId("idManagerApproveBtn").setVisible(false);
                oThisController.getView().byId("idManagerRejectBtn").setVisible(false);
                oThisController.getView().byId("idManagerSbr").setVisible(false);
                // oThisController.getView().byId("idManagerForward").setVisible(false);
                //GIT 270,290- set the visibility of edit profile and edit processor links
                oThisController.getView().byId("idPanelEditProcessor").setVisible(false);
                oThisController.getView().byId("idPanelEditProfile").setVisible(false);
                oThisController.getView().byId("idSaveandSubmitBtn").setVisible(true);
                oThisController.getView().byId("idCancelAssignmentBtn").setVisible(true);
                const oControlAssignmentTab = oThisController.getView().byId("idAssignmentsSection");
                oThisController.onAddNewAssignment();
                oControlAssignmentTab.setVisible(true);
                 const oAssignmentsection = oThisController.getView().byId("idObjPageLayout").getSections()[1];
                oThisController.getView().byId("idObjPageLayout").setSelectedSection(oAssignmentsection);
            } else {
                //resource approval
                const sReqType = oThisController.getView().getModel().getProperty("/RequestType");
                const bIsIOStaffing = oThisController._getLoggedInUserAssignmentObj(oThisController).isIOStaffing;
                const isAutoStaffing = oThisController._getLoggedInUserAssignmentObj(oThisController).isAutoStaffing;
                const sUserId = oThisController._getLoggedInUserAssignmentObj(oThisController).userId;
                const sCompanyCode = oThisController._getLoggedInUserAssignmentObj(oThisController).sCompanyCode;
                const sCostCenter = oThisController._getLoggedInUserAssignmentObj(oThisController).sCostCenter;
                // const sResEngagementType = oThisController._getLoggedInUserAssignmentObj(oThisController).sResEngagementType;
                //Check the staffing
                if (sReqType === "Opportunity" && bIsIOStaffing) {
                    //check !isAutoStaffing--> not staffed
                    if (!isAutoStaffing) {
                        const sFinalOrgID = oThisController.getView().getModel().getProperty("/oppOrgId") ?  oThisController.getView().getModel().getProperty("/oppOrgId"):oThisController.getView().getModel().getProperty("/OrgID");
                        const sSalesOrg = sFinalOrgID.replace('SORG-', '');
                        if (sCompanyCode === sSalesOrg) {
                            //company code of the resources matches sales org of the opportunity
                            oThisController.isAutoStaffingCompanyCode = true;
                            let oAssignment = oThisController._getLoggedInUserAssignmentObj(oThisController);
                            oAssignment.isAutoStaffingCompanyCode = true;
                            //Call userSearchHelps to fetch the perner number for staffing
                            Models._callUserSearchHelps(sUserId, oThisController, oThisController.fnSuccessUserSearchHelpsCallBack, oThisController.fnErrorUserSearchHelpsCallBack,
                                oAssignment);
                        } else {
                            oThisController.isAutoStaffingCompanyCode = false;
                            //check exception table maintained
                            Models._callExceptionTable(sCompanyCode, sCostCenter,oThisController.getView().getModel().getData().EngagementType, sSalesOrg, sUserId, oThisController, oThisController.fnExceptionSuccessCallback,
                                    oThisController.fnExceptionErrorCallback, false);
                        }
                    } else {
                        //Proceed wf trigger
                        oThisController._onFinalSubmitWf(oThisController);
                    }
                } else {
                    //IO Staffing false --> Proceed wf trigger
                    oThisController._onFinalSubmitWf(oThisController);
                }
            }
        },
        onCancelAssignment: function () {
            const oAssignmentsReset = {
                "assignments": []
            }
            this.getView().getModel("assignmentsModel").setData(oAssignmentsReset);
            this.getView().getModel("assignmentsModel").refresh(true);
            this.getView().byId("idAssignmentsSection").setVisible(false);
            const oReqDetSection = this.getView().byId("idObjPageLayout").getSections()[0];
            this.getView().byId("idObjPageLayout").setSelectedSection(oReqDetSection);
            this._setFooterButtonDefaultVisibility();

        },
        onSendBackToRequester: function () {
            this.bSendBackToProcessor=false
            this._finalDecision("Send Back to Requestor");
        },
        onRejectReq: function () {
            /*flag to check whether send back to processor was pressed or reject requested
                Git #144
            */
            if (!this.getView().getModel("RejectionCodeAPIData")) {
                const oRejectionCodeModel = new JSONModel(this._getRejectionCodeBaseURL());
                this.getView().setModel(oRejectionCodeModel, "RejectionCodeAPIData");
            }
            const oModel = this.getView().getModel();
            oModel.refresh(true);
            const processContext = oModel.getData();
            if (processContext.currentStepID == "RESAPP") {
                this.bSendBackToProcessor = true
            } else {
                this.bSendBackToProcessor = false
            }
            this._finalDecision("Reject");

        },
        _finalDecision: function (sDecision) {
            const oModel = this.getView().getModel();
            oModel.refresh(true);
            const processContext = oModel.getData();
            const sStep = processContext.currentStepName;
            
            // Call a local method to perform further action
            this._openSubmitDialog(
                processContext,
                this.sUserTaskId,
                sDecision,
                sStep
            );
        },
        onManagerForwardRequest:function(oEvent){
            const oModel = this.getView().getModel();
            const processContext = oModel.getData();
            const sStep = processContext.currentStepName;
            if (oModel.getData().isResourceProfile) {
                this._forwardActionDialog(
                    oEvent,
                    processContext,
                    this.sUserTaskId,
                    "Forward",
                    sStep
                );
            } else {
                this.onResourceProfileSelectionPress(true)
            }
        },
        handleSCBtnPress: function () {
            const oDynamicSideView = this.getView().byId("managerPageDynamicSideContent");
            const oOPSideContentBtn = this.getView().byId("openSideContentBtnManagerPage");
            this.getView().getModel().setProperty("/bActionHistoryOpen",true);
            this.getView().getModel().refresh();
          	//GIT 277- common function to fetch the action history
            CommonJS._setActionHistoryModel(this, oDynamicSideView, oOPSideContentBtn);
        },
        QuickViewCard: function (oModel, oevt, self, sName) {
            let oButton = oevt.getSource();
            self.getView().setModel(oModel, "EmpDetails");
            let EmployeeDetails = this.getView().getModel("EmpDetails");
            users._contactslistFragment(EmployeeDetails, oevt, self, sName).openBy(oButton);
            sap.ui.core.BusyIndicator.hide();
        },
        handleSideContentHide: function () {
            sap.ui.core.BusyIndicator.show(0);
            const oDynamicSideView = this.getView().byId("managerPageDynamicSideContent");
            const sCurrentBreakpoint = oDynamicSideView.getCurrentBreakpoint();
            const oOPSideContentBtn = this.getView().byId("openSideContentBtnManagerPage");
            if (sCurrentBreakpoint === "S") {
                oDynamicSideView.toggle();
            } else {
                oDynamicSideView.setShowSideContent(false);
                sap.ui.core.BusyIndicator.hide();
            }
            oOPSideContentBtn.setVisible(true);
            this.getView().getModel().setProperty("/bActionHistoryOpen",false);
            this.getView().getModel().refresh();
            setTimeout(function () {
                this.byId("openSideContentBtnManagerPage").focus();
            }.bind(this));
            sap.ui.core.BusyIndicator.hide();
        },        
        onBAIndChange:function(oEvent){
            let oModel;
			if (oEvent.getParameter("selectedItem")) {
                oModel = oEvent.getParameter("selectedItem").getBindingContext("employee").oModel;
				const oBAIndustry = oEvent.getParameter("selectedItem").getBindingContext("employee").getObject();
				const aEmployeeBAIndustries = [];
				aEmployeeBAIndustries.push({
					Guid: oBAIndustry.Guid,
					Desc: oBAIndustry.Desc,
					ClusterGuid: oBAIndustry.ClusterGuid,
					ClusterDesc: oBAIndustry.ClusterDesc,
					IsPrimary: oBAIndustry.IsPrimary,
					BaIndTechID: oBAIndustry.BaIndTechID,
					BaIndId: oBAIndustry.BaIndId
				});
				this.getView().getModel("employee").setProperty(`/TempEmployee/TempBAIndustries`, aEmployeeBAIndustries);
				this.getView().getModel("employee").setProperty(`/TempEmployee/BAIndustries`, aEmployeeBAIndustries);
				this.getView().getModel("employee").refresh(true);
			} else {
				this.getView().getModel("employee").setProperty(`/TempEmployee/TempBAIndustries`, []);
				this.getView().getModel("employee").setProperty(`/TempEmployee/BAIndustries`, []);
                oModel = this.getView().getModel("employee");
			}
			 this._setSearchFieldText();
			 this._onEnableSearchResources();
		},
        _setSearchFieldText:function(){
			const aSearchItem= this.getView().getModel("employee").getProperty(`/TempEmployee`);
			const aSearchParams = [];
			const aSolArea = [];
			const aBAInd = [];
		    if(aSearchItem.SolutionAreas && aSearchItem.SolutionAreas.length){
				aSearchItem.SolutionAreas.forEach(function(sol){
					aSolArea.push(sol.soln_name);
				})
			}
			if( aSearchItem.TempBAIndustries.length){
				aSearchItem.TempBAIndustries.forEach(function(Ind){
					aBAInd.push(Ind.Desc);
				})
			}
            aSearchItem.TempRoleAreas.length ? aSearchParams.push(aSearchItem.TempRoleAreas[0].Desc) :false;
			aSearchItem.SolutionAreas && aSearchItem.SolutionAreas.length ? aSearchParams.push(aSolArea.join()) :false;
			aSearchItem.TempBAIndustries.length ? aSearchParams.push(aBAInd.join()) :false;
			this.getView().getModel("employee").getProperty("/GrpSelectable") && aSearchItem?.SelectedGroup?.length ? aSearchParams.push(aSearchItem.SelectedGroup[0].GroupDesc) :false;
			// aSearchItem.TempBALoBs.length ? aSearchParams.push(aSearchItem.TempBALoBs[0].Desc) :false;
			// aSearchItem.TempCrossCvg.length ? aSearchParams.push(aSearchItem.TempCrossCvg[0].Desc) :false;
			const sSearchText = aSearchParams.join(" | ");
			this.getView().getModel("employee").setProperty(`/searchFieldsText`,`[${sSearchText}]`);
			this.getView().getModel("employee").refresh(true);

		},
        _setDecision:function(sDecision){
            let sDecisionText;
            switch(sDecision) {
                case "Approve":
                    sDecisionText = this.getView().getModel("formActionsConfigModel").getData().idapprove[0].Label;
                  break;
                case "Forward":
                    sDecisionText = this.getView().getModel("formActionsConfigModel").getData().idforward[0].Label;
                  break;
                case "Reject":
                    sDecisionText = this.getView().getModel("formActionsConfigModel").getData().idreject[0].Label;
                  break;
                case "Send Back to Requestor":
                    sDecisionText= this.getView().getModel("formActionsConfigModel").getData().idrework[0].Label;
                  break;
                default:
                    sDecisionText= ""
                  break;
              }
              return sDecisionText;
        },
        onAfterOpenPopover: function () {
            let oTreeTable = this.byId("territoriesTableId");
           
            let oBinding = oTreeTable.getBinding("rows");
       
            if (oBinding.getLength() > 0) {
                oTreeTable.expand(0);
            }
        },
      //MR: [GRP02-03] GTM25 Resource Profile alignment #84 start
		//Select Solution Area (L1)
		fnHandleLevel1Change:function(oEvent){
            const oSelectedSLA1Context = oEvent.getParameter("selectedItem").getBindingContext("SLAMasterDataL1").getObject();
            this.getOwnerComponent().getModel("SLAMasterDataLevels").setProperty("/isGridLayBusy",true);
            this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",[]);
            this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA",false);
            this.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
            Models._getSLALevels(this,oSelectedSLA1Context);
  
          },
          onSelectSLA:function(oEvent){
              const oBindingContextSLA = oEvent.getSource().getBindingContext("SLAMasterDataLevels").getObject();
              //format selected solution area based on hierachy levels
              oBindingContextSLA.SelectedSolutionArea = !oBindingContextSLA.SolAreal2Desc ? `${oBindingContextSLA.SolAreal1Desc}` : 
			 `${oBindingContextSLA.SolAreal1Desc} > ${oBindingContextSLA.SolAreal2Desc}`;
              this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas" , "");
			  let aSelectedSLA = !this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aSelectedSolutionAreas") ? [] : this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aSelectedSolutionAreas");
              if (oEvent.getParameter("selected")) {
                  aSelectedSLA.push(oBindingContextSLA);
                  this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA", true);
              } else if (aSelectedSLA.length) {
                  aSelectedSLA = aSelectedSLA.filter(item => item.soln_guid !== oBindingContextSLA.soln_guid);
                  this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA", true);
              }else{
                  this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA", false);
              }
                  let aSLALevel2 = this.getOwnerComponent().getModel("SLAMasterDataLevels").getData();
                  aSLALevel2.results.forEach(function (data) {
                      if (data.soln_guid === oBindingContextSLA.soln_guid) {
                          data.IsSelected = true;
                          data.isPartiallySelected = false;
                      } else {
                          data.IsSelected = false;
                      }
                  });
                  const removeDuplicateSLAObjects = aSelectedSLA.filter((value, index) => {
                      const _value = JSON.stringify(value);
                      return index === aSelectedSLA.findIndex(obj => {
                        return JSON.stringify(obj) === _value;
                      });
                    });
              
                    this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",removeDuplicateSLAObjects);
                    this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aTokenSelectedSolutionAreas",removeDuplicateSLAObjects);
                  this.getOwnerComponent().getModel("SLAMasterDataLevels").refresh(true);
                  this.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
                  this._OnUpdateSlaSelection();
              
          },
        onChangeSolutionAreas: function (evt) {
            let aSelectedSLA = this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aTokenSelectedSolutionAreas");
            this.getView().getModel("employee").setProperty(`/TempEmployee/SolutionAreas`, aSelectedSLA);

            const oSolAreaMasterDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData")
            let sL1guid = oSolAreaMasterDataModel.getProperty("/selectedLevel1Guid")
            let sL2guid = oSolAreaMasterDataModel.getProperty("/selectedLevel2Id")
            let solHierarchyMap = oSolAreaMasterDataModel.getProperty("/solHierarchyMap")
            let oL1Data = solHierarchyMap.get(sL1guid)
            let oL2Data = solHierarchyMap.get(sL2guid)
            var aSelAddSol = oSolAreaMasterDataModel.getProperty("/displayTokensAdditionalSolution") ?  oSolAreaMasterDataModel.getProperty("/displayTokensAdditionalSolution"):[];
            var aSolFinalNames = [];
            let aSolFullGuids = [];
            let aSolFullIds = [];
            if (aSelAddSol.length > 0) {
                aSelAddSol.forEach(addSol => {
                    aSolFinalNames.push(addSol.full_sol_name);
                    aSolFullGuids.push(addSol.full_sol_guid)
                    aSolFullIds.push(addSol.full_sol_id);
                })

            }
            var oPayload = {}
            if (oL2Data) {
                oPayload = {
                    SelectedSolutionArea: oL1Data.soln_name + " > " + oL2Data.soln_name,
                    soln_guid: oL2Data.soln_guid,
                    soln_id: oL2Data.soln_id,
                    soln_name: oL2Data.soln_name,
                    solnFinalName: oL2Data.soln_name,
                    prnt_soln_id: oL1Data.soln_id,
                    soln_prnt_guid: oL1Data.soln_guid,
                    LevelId: 2,
                    SolAreal1Guid: oL1Data.soln_guid,
                    SolAreal1Desc: oL1Data.soln_name,
                    SolAreal2Guid: oL2Data.soln_guid,
                    SolAreal2Desc: oL2Data.soln_name,
                    AllSelectedSolutions: aSolFinalNames.length > 0 ? aSolFinalNames.join(", ") : oL2Data.full_sol_name,
                    AllSelectedGuids:aSolFullGuids.length>0  ? aSolFullGuids.join(" , ") : oL2Data.full_sol_guid,
                    AllSelectedIds:aSolFullIds.length>0  ? aSolFullIds.join(" , ") : oL2Data.full_sol_id
                }
            } else if(oL1Data) {
                oPayload = {
                    SelectedSolutionArea: oL1Data.soln_name,
                    soln_guid: oL1Data.soln_guid,
                    soln_id: oL1Data.soln_id,
                    soln_name: oL1Data.soln_name,
                    solnFinalName: oL1Data.soln_name,

                    soln_prnt_guid: "00000000-0000-0000-0000-000000000000",


                    Guid: oL1Data.soln_guid,
                    ID: oL1Data.soln_id,
                    Desc: oL1Data.soln_name,
                    LevelId: 1,
                    SolAreal1Guid: oL1Data.soln_guid,
                    SolAreal1Desc: oL1Data.soln_name,
                    DisplayGuid: oL1Data.soln_guid,
                    DisplayDesc: oL1Data.soln_name,
                    AllSelectedSolutions: oL1Data.full_sol_name,
                    AllSelectedGuids:oL1Data.full_sol_guid,
                    AllSelectedIds:oL1Data.full_sol_id

                };
            }


            aSelectedSLA = []
			if (oL2Data || oL1Data) {
				aSelectedSLA.push(oPayload)
			}
            // let aAddSolutions=[]    
            // let aMaterials=[]
            oSolAreaMasterDataModel.setProperty("/selectedLevel2Id", null)
            oSolAreaMasterDataModel.setProperty("/selectedLevel1Guid", null)
            let displayTokensMaterial = oSolAreaMasterDataModel.getProperty("/displayTokensMaterial")
            let displayTokensAdditionalSolution = oSolAreaMasterDataModel.getProperty("/displayTokensAdditionalSolution")
            this.getView().getModel("employee").setProperty(`/TempEmployee/SolutionAreas`, aSelectedSLA);
            this.getView().getModel("employee").setProperty(`/TempEmployee/AdditionalSolutions`, displayTokensAdditionalSolution);
            this.getView().getModel("employee").setProperty(`/TempEmployee/Materials`, displayTokensMaterial);

            let oSelectParams = {
                "bIndustry": false,
                "minSelect": this.getView().getModel("employee").getProperty(`/minSelect`),
                "maxSelect": this.getView().getModel("employee").getProperty(`/maxSelect`),
            };
            this._onManageIndSolSelection(oSelectParams);
            if(!aSelectedSLA.length){
                this.onDeleteSLAToken();
            }
            this._setSearchFieldText();
            this._onEnableSearchResources(oSelectParams);
            this.oSLASearchContext = false;
            this.oSearchAddSlnContext = false
            const that = this;
            //   this.solutionHierarchyDialogForward.close()
            this.solutionHierarchyDialogForward.then(function (oDialog) {
                oDialog.destroy();
                 Models.getSolutionAreaMasterData(that)
                that.solutionHierarchyDialogForward = false;
            });
        },
          onCloseSolutionArea: function () {
            const that = this;
            this.pSLAValueHelpDialog.then(function (oDialog) {
                oDialog.destroy();
                that.pSLAValueHelpDialog = false;
                that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",that.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`));
                that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aTokenSelectedSolutionAreas",that.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`));
               that.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
            });
          },
          /*Token updated delete Solution Area*/
          onDeleteSLAToken: function (oEvent) {
             const oModel = this.getView().getModel("employee");
              oModel.setProperty(`/TempEmployee/SolutionAreas`, []);
              oModel.setProperty(`/TempEmployee/AdditionalSolutions`, []);
              this.oSLASearchContext = false;
               this.oSearchAddSlnContext = false
              let oSelectParams = {
				"bIndustry":false,
				"minSelect":oModel.getProperty(`/minSelect`),
				"maxSelect":oModel.getProperty(`/maxSelect`),
			}
			
			this._onManageIndSolSelection(oSelectParams,true)
              this._setSearchFieldText();
              this._onEnableSearchResources(oSelectParams);
          },
        _OnUpdateSlaSelection: function () {
            let aSLALevel2 = this.getOwnerComponent().getModel("SLAMasterDataLevels").getData();
            let that = this;
            let aSelectedSLA = this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aSelectedSolutionAreas");
            aSLALevel2.results.forEach(function (data) {
                data.isSelected = false;
                data.isPartiallySelected = false;
                if (data.is_ChildLoaded && data.to_Child.length) {
                    data.to_Child.forEach(function (child) {
                        child.isSelected = false;
                        child.isPartiallySelected = false;
                        child.solnFinalName = child.SolAreal2Desc;
                    });
                }
            });
            if (aSelectedSLA.length) {
                aSelectedSLA.forEach(function (oContextSolutionArea) {
                    aSLALevel2.results.forEach(function (data) {
                        //data.isSelected = false;
                        that.oParentData = data;
                        if (oContextSolutionArea.soln_guid === data.soln_guid) {
                            data.isSelected = true;
                            data.isPartiallySelected = false;
                        }
                        if (data.is_ChildLoaded && data.to_Child.length) {
                            data.to_Child.forEach(function (child) {
                                //child.isSelected = false;
                                if (oContextSolutionArea.soln_guid === child.soln_guid) {
                                    child.isSelected = true;
                                    child.isPartiallySelected = false;
                                }
                                if (child.isSelected && !that.oParentData.isSelected && !that.oParentData.isPartiallySelected) {
                                    //	oContextSolutionArea.isSelected = true;
                                    that.oParentData.isSelected = true;
                                    that.oParentData.isPartiallySelected = true;
                                }
                            });
                        }else if(!data.is_ChildLoaded && oContextSolutionArea.soln_prnt_guid === that.oParentData.soln_guid ){
                            let aFilteredSelectedSLA = aSelectedSLA.filter(item=> item.soln_guid === that.oParentData.soln_guid);
                            if(!aFilteredSelectedSLA.length){
                                that.oParentData.isSelected = true;
                                that.oParentData.isPartiallySelected = true;
                                that.getOwnerComponent().getModel("SLAMasterDataL1").getData().aSelectedSolutionAreas.push(that.oParentData);
                            }
                        }
                    });
                })
                this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA", true);
            } else {
                this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA", false);
            }

            this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas", aSelectedSLA)
            this.getOwnerComponent().getModel("SLAMasterDataLevels").refresh();
            if(this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aSelectedSolutionAreas").length > 1){
				let filteredData = this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aTokenSelectedSolutionAreas").filter(item => item.to_Child.length === 0)
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aTokenSelectedSolutionAreas" , filteredData);
			}
            this.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
            this.getOwnerComponent().getModel("SLAMasterDataLevels").refresh();
        },
          //delete solution area master data selection
          fnDeleteSolMatTokens:function(oEvent){
              const oContext = oEvent.getParameter("removedTokens")[0].getBindingContext("SLAMasterDataL1").getObject();
              //this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",[]);
              if(!this.getOwnerComponent().getModel("SLAMasterDataL1").getProperty("/aSelectedSolutionAreas").length){
                  this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA",false);
              }else{
                  this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA",true);
              }
           this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas" , "");
			this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aTokenSelectedSolutionAreas" , "");
              this.getOwnerComponent().getModel("SLAMasterDataLevels").refresh();
              this.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
              this._OnUpdateSlaSelection();
          },
          onAfterOpenSLAPopover: function () {
              const oTree = this.byId("idSolutionTreeOnCreate");
              let aSelectedItems = oTree.getItems();
              let aSelectedIndices = [];
              for (var i = 0; i < aSelectedItems.length; i++) {
                  aSelectedIndices.push(oTree.indexOfItem(aSelectedItems[i]));
              }
              oTree.collapse(aSelectedIndices);
          },
          systemLSDataModel: function (self) {
            //set oData model for ISP
            const componentName = this.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
            const componentPath = sap.ui.require.toUrl(componentName);
            // call ymr_srv service for solution areas
            const oDataModel = new ODataModel({
                serviceUrl: `${componentPath}/int_pc/sap/opu/odata/sap/ymr_srv`
            });
            return oDataModel;
 
        },
        //event to load support url
        onSupportlinkpress: function () {
            const sSupportUrl = this.getOwnerComponent().getModel("appConstants").getProperty("/supporturl/0/Value");
            sap.m.URLHelper.redirect(sSupportUrl, true);
        },
        //filter soution area based on solution name
        onSearchSolutionArea: function (oEvent) {
			const query = oEvent ? oEvent.getSource().getValue().trim():"";
			const oTree = this.byId("idSolutionTreeOnCreate");
			oTree.getBinding("items").filter(
				query
					? new sap.ui.model.Filter({
						path: "soln_name",
						operator: sap.ui.model.FilterOperator.Contains,
						value1: query,
					})
					: null
			);
			oTree.expandToLevel(query ? 99 : 0);
		    if(!query){
				oTree.collapseAll();
			}
        },
        onShowActivityInfo: function (evt) {
            const oAppConfigModel = this.getOwnerComponent().getModel("mrrAppConfigModel").getData();
            if (evt.getSource().getBindingContext("assignmentsModel").getObject().ActivityTypeInfo) {
                oAppConfigModel.ActivityType_InfoBubble = [{
                    "fieldDesc": evt.getSource().getBindingContext("assignmentsModel").getObject().ActivityTypeInfo
                }];
                CommonJS._onShowInfoMessage(evt, this);
            }

        },
        	//show info/hint message
		onShowInfoMessage:function(evt){
            if(evt.getSource().getCustomData()[0].getKey().includes('Role_InfoBubble')){
                if(this.getView().getModel().getData().EngagementType=='0002'){
                    evt.getSource().getCustomData()[0].setKey("Role_InfoBubbleFBS")
                }else{
                    evt.getSource().getCustomData()[0].setKey("Role_InfoBubble")
                }
            }
			CommonJS._onShowInfoMessage(evt,this);
		},
        /**
           * event trigger for old request opp routing
           *
           * @param {Object} evt -event object
           */
        handleUrlRouting:function(evt){
           Models._handleUrlRouting(evt);
        },
         /**Git 132 (Form template changes + add new opp fields)
         *press event to show more processor list
         * @param {object} oEvent -The current control(link) event
         */
		onPressUserList: function (oEvent) {
			const oView = this.getView(),
				  that = this;
			if (!this._pMoreUerListPopOver) {
				//load userList more fragment
				this._pMoreUerListPopOver = Fragment.load({
					id: oView.getId(),
					name: "com.dealsupport.melodyrequest.fragments.userListMore",
					controller: this
				}).then(function (oMoreUerListDialog) {
					that._moreUserListDialog = oMoreUerListDialog;
					oView.addDependent(oMoreUerListDialog);
					return oMoreUerListDialog;
				});
			}

			this._pMoreUerListPopOver.then(function (oMoreUerListDialog) {
                    oMoreUerListDialog.openBy(oEvent.getSource());
			});

		},
		 /**Git 132 (Form template changes + add new opp fields)
         *press event to close processor popover list
         */
		onCloseMoreLisPopOver:function(){
			if(this._moreUserListDialog){
				this._moreUserListDialog.close();
			}
		},
            /**
         * Git #230 Activity integration start
         * Open Rapid registartion dialog from melody library
         * @param {object}  oEvent - control(button) context.
         * @function fnOpenRapidRegDialog
         */
        fnOpenRapidRegDialog: function (oEvent) {
               sap.ui.core.BusyIndicator.show()
            const oSource = oEvent.getSource();
            const oWeekDates = {
                "dFirstdate": new Date(),
                "dLastdate": new Date()
            };
            this.oContextAssignmentObj = this._getParentContext(oEvent);
            let oActivityContext = oEvent.getSource().getBindingContext("assignmentsModel").getObject();
            this.getView().getModel("appConstants").setProperty("/oContextAct", oEvent.getSource())
            oEvent.getSource().getBindingContext("assignmentsModel").getObject().activityPaylod = this._setActivityPaylod(oActivityContext);
            oEvent.getSource().getBindingContext("assignmentsModel").getObject().activityPaylod["DryRunDate"] = oEvent.getSource().getBindingContext("assignmentsModel").getObject().activityPaylod["DryRunDate"] ? new Date(oEvent.getSource().getBindingContext("assignmentsModel").getObject().activityPaylod["DryRunDate"]) : null;
            this.getView().getModel("matrixModel").setProperty("/activityRegistration", oEvent.getSource().getBindingContext("assignmentsModel").getObject().activityPaylod);
            this.getView().getModel("matrixModel").setProperty("/ActvtId", "");
            this.getView().getModel("matrixModel").refresh();
            RapidRegistrationLibrary.prototype.fnOpenRapidRegDialog(oEvent, oWeekDates);
            setTimeout(function () {
                const oDialog = sap.m.InstanceManager.getOpenDialogs()[0],
                    that = RapidRegistrationLibrary.prototype.oDialogController;
 
               
                oDialog.getModel("RapidRegUIModel").refresh();
                //set footer button
 
                const oToolbar = oDialog.getContent()[1],
                    oConfirmBtn = new sap.m.Button({
                        text: "OK",
                        type: "Emphasized",
                        press: function () {
                            const madatoryFiledCount = that.fnValidateMandatoryFields();
                            if (!madatoryFiledCount) {
                                let RapidRegDataModel = that.RapidRegDataModel;
                                let ActivityData = RapidRegDataModel.getData();
                                let ActivityGuid = ActivityData["ActivityGuid"];
 
                                let aFiles = [];
                                if (ActivityData["to_AFiles"] && ActivityData["to_AFiles"].length) {
                                    ActivityData["to_AFiles"].filter((oFile) => {
                                        delete oFile.UrlState;
                                        delete oFile.FileNameState;
                                        delete oFile.IsAddBtnVisible;
                                        delete oFile.IsDelBtnVisible;
                                        oFile.ActivityGuid = ActivityGuid;
                                    });
                                    aFiles = ActivityData["to_AFiles"];
                                }
 
                                let aInitiatives = [];
                                if (ActivityData["to_AInitiative"] && ActivityData["to_AInitiative"].length) {
                                    ActivityData["to_AInitiative"].filter((item) => {
                                        aInitiatives.push({ "ActivityGuid": ActivityGuid, "InitiativeId": item.InitiativeId, "InitiativeName": item.InitiativeName });
                                    });
                                }
                                that.RapidRegDialog.getModel("appConstants").getData().oContextAct.getBindingContext("assignmentsModel").getObject()["aInitiatives"] = ActivityData["to_AInitiative"];
 
                                var aTaxonomy = ActivityData.to_ATaxonomy;
                                aTaxonomy.filter(function (item) {
                                    item.ActivityGuid = ActivityGuid;
                                    delete item.LevelId;
                                    delete item.LevelDesc;
                                });
 
                                var aMaterial = ActivityData.to_AMaterial;
                                aMaterial.filter(function (item) {
                                    item.ActivityGuid = ActivityGuid;
                                    delete item.LevelId;
                                    delete item.LevelDesc;
                                });
 
                                var aAddOpp = [];
                                var aAddOppSelections = ActivityData.to_AAddOpp;
                                if (aAddOppSelections.length) {
                                    aAddOppSelections.filter(function (object) {
                                        var opptObj = {
                                            "OpportunityNo": object.OpportunityNo,
                                            "ActivityGuid": ActivityGuid
                                        };
                                        aAddOpp.push(opptObj);
                                    });
                                }
                                let aLandcsapes = [];
                                if (ActivityData["to_ALand"] && ActivityData["to_ALand"].length) {
                                    ActivityData["to_ALand"].filter((item) => {
                                        delete item.SelectionCat;
                                        delete item.prevSelected;
                                        delete item.selected;
                                        delete item.__metadata;
                                        item.ActivityGuid = ActivityGuid;
                                    });
                                    aLandcsapes = ActivityData["to_ALand"];
                                }
 
                                let aTeam = [];
                                if (ActivityData["to_ATeam"] && ActivityData["to_ATeam"].length) {
                                    ActivityData["to_ATeam"].filter((item) => {
                                        const oUser = {
                                            "EMAIL": item.EMAIL,
                                            "ID": item.ID,
                                            "NAME": item.NAME,
                                            "ROLE": item.ROLE
                                        };
                                        aTeam.push(oUser);
                                    });
                                }
 
                                let oData = $.extend(true, {}, ActivityData);
                                oData["EndDate"] = oData["EndDate"].toISOString();
                                oData["StartDate"] = oData["StartDate"].toISOString();
                                oData["DryRunDate"] = oData["DryRunDate"] ? (oData["DryRunDate"].toJSON().split(".")[0] + "Z") : null;
                                oData["StatusChangedAt"] = oData["StatusChangedAt"] ? (oData["StatusChangedAt"].toJSON().split(".")[0] + "Z") : null;
                                oData["to_AInitiative"] = aInitiatives;
                                oData["to_AFiles"] = aFiles;
                                oData["to_AAddOpp"] = aAddOpp;
                                oData["to_ALand"] = aLandcsapes;
                                oData["to_ATeam"] = aTeam;
                                oData["IsMelodyRequest"]=true;
                                oData["assignmentID"] =  that.RapidRegDataModel.getData().assignmentID;
                                let aSlnDisplayTokens = that.oSolutionsModel.getData().DisplayTokens && that.oSolutionsModel.getData().DisplayTokens.length ? that.oSolutionsModel.getData().DisplayTokens : [];
                                oData["displayTempSlnTokens"] = aSlnDisplayTokens;
                                // that.RapidRegDialog.getModel().setProperty("/solutionAreaPayload",solutionAreaPayload);
                                 that.RapidRegDialog.getModel().refresh();
                                that.RapidRegDialog.getModel("appConstants").getData().oContextAct.getBindingContext("assignmentsModel").getObject()["activityPaylod"] = oData;
                               
                                if(oData["to_ALand"] && oData["to_ALand"].length){
                                   // that.RapidRegDialog.getModel("appConstants").setProperty("/landScapesMasterData",that.RapidRegUIModel.getProperty("/landscape"));
                               
                                }
                                that.fnCloseRapidRegDialog();
                                // VAT Team
                                // this.fnRegisterActivity(oData);
                            } else {
                                if (madatoryFiledCount === 1 && that.RapidRegUIModel.getProperty("/LandscapeValueState") === "Error") {
                                    MessageToast.show("Please Select the Checkbox or Landscapes to proceed");
                                } else {
                                    MessageToast.show("Please fill all mandatory fields.");
                                }
                            }
                        }
                    });
                let oUpdateActivityPayload = that.RapidRegDialog.getModel("appConstants").getData().oContextAct.getBindingContext("assignmentsModel").getObject()["activityPaylod"];
                that.RapidRegDataModel.setProperty("/OpportunityNumber", that.RapidRegDialog.getModel("appConstants").getData().oContextAct.getModel().getProperty("/opportunityId"))
               let oResponse = {
                    "Items":{
                        "results":  that.RapidRegDialog.getModel("appConstants").getData().oContextAct.getModel().getProperty("/OPP_SOLN_AREA") ?  that.RapidRegDialog.getModel("appConstants").getData().oContextAct.getModel().getProperty("/OPP_SOLN_AREA") :[]
                    }
                }
                that.fnFormOpportunityMaterials(oResponse);
                that.RapidRegDataModel.setProperty("/Region", oUpdateActivityPayload["Region"]);
                that.RapidRegDataModel.setProperty("/SubRegion", oUpdateActivityPayload["SubRegion"]);
                that.RapidRegDataModel.setProperty("/CvjPhaseId", oUpdateActivityPayload["CvjPhaseId"])
                if(oUpdateActivityPayload["RiskAssessId"]){
                      that.RapidRegDataModel.setProperty("/RiskAssessId", oUpdateActivityPayload["RiskAssessId"])
                }else{
                    delete that.RapidRegDataModel.getData().RiskAssessId;
                }
                that.RapidRegDataModel.refresh();
                oToolbar.insertContent(oConfirmBtn, 2);
             
                let aFinalSelectedSln = this.getView().getModel().getProperty("/solutionAreaPayload") ? this.getView().getModel().getProperty("/solutionAreaPayload") : [];
                if (this.getView().getModel("matrixModel").getProperty("/activityRegistration/displayTempSlnTokens") &&
                    this.getView().getModel("matrixModel").getProperty("/activityRegistration/displayTempSlnTokens").length) {
                    aFinalSelectedSln = this.getView().getModel("matrixModel").getProperty("/activityRegistration/displayTempSlnTokens")
                }
               
                let aLandscapes = this.getView().getModel("matrixModel").getProperty("/activityRegistration/to_ALand") ? this.getView().getModel("matrixModel").getProperty("/activityRegistration/to_ALand") : [];
               
                let aFinalSlData = JSON.parse(JSON.stringify(aFinalSelectedSln));
                if(aFinalSlData.length === 1 && !aFinalSlData[0].L4Id){
                    //If solutionarea is till L3 then remove prepopulation
                    aFinalSlData = [];
                }
                    aFinalSlData.length ? that.oSolutionsModel.setProperty("/Level2Key", aFinalSlData[0].L2Id):"";
                const aLevelHierachy =   that.oSolutionsModel.getProperty("/LevelsHierarchy"),
                      sLevel2Key =  that.oSolutionsModel.getProperty("/Level2Key"),
                      aLevel2Selected = aLevelHierachy.filter(item=>item.LevelId === sLevel2Key)[0];
                      aLevel2Selected.isParent = true;
                aFinalSlData.unshift(aLevel2Selected);
                 that.oSolutionsModel.setProperty("/to_ATaxonomy", aFinalSlData)
                let displayTokens = that.fnGetDisplayTokens(aFinalSlData);
 
                //set solution model for rapid reg dialog
                //that.oSolutionsModel.setProperty("/OppSolTempArr",displayTokens);   
                that.oSolutionsModel.setProperty("/SolTokens", displayTokens);
                that.oSolutionsModel.setProperty("/DisplayTokens", displayTokens);
                that.oSolutionsModel.setProperty("/oSolTempArr", displayTokens);
                const aAllParentIds = [];
                displayTokens.forEach(function(sln){
                    aAllParentIds.push(sln.L5Id);
                    aAllParentIds.push(sln.L4Id);
                    aAllParentIds.push(sln.L3Id);
                    aAllParentIds.push(sln.L2Id);
 
                });
                const uniqueSlnParentIds =  [...new Set(aAllParentIds)].filter(item=>item)
                function modifyTree(tree, condition, newProperty) {
                    tree.forEach(node => {
                        // Check condition (e.g.,node.LevelId === solns ) and update property value as true
                        if (condition(node)) {
                            node.isSelected = newProperty;
                        }
 
                        // If the node has children, recursively call the function
                        if (node.Levels && node.Levels.length > 0) {
                            modifyTree(node.Levels, condition, newProperty);
                        }
                    });
                }  
                uniqueSlnParentIds.forEach(function(solns){
                       modifyTree(aLevelHierachy, (node) => node.LevelId === solns, true);
                });
                that.oSolutionsModel.refresh();
                that.RapidRegDataModel.setProperty("/to_ATeam", JSON.parse(JSON.stringify(this.getView().getModel("matrixModel").getProperty("/activityRegistration/to_ATeam"))));
                that.RapidRegDataModel.setProperty("/to_ALand",  JSON.parse(JSON.stringify(aLandscapes)));
               
                const sRegDryRun = this.getView().getModel("matrixModel").getProperty("/activityRegistration/DryRunDate");
                that.RapidRegDataModel.setProperty("/DryRunDate", sRegDryRun)
                const aInitivativesFinal = that.RapidRegDialog.getModel("appConstants").getData().oContextAct.getBindingContext("assignmentsModel").getObject()["aInitiatives"] ? that.RapidRegDialog.getModel("appConstants").getData().oContextAct.getBindingContext("assignmentsModel").getObject()["aInitiatives"] : [];
                that.RapidRegDataModel.setProperty("/to_AInitiative",  JSON.parse(JSON.stringify(aInitivativesFinal)))
                const aRegSol = this.getView().getModel("matrixModel").getProperty("/activityRegistration/to_ASol") ? this.getView().getModel("matrixModel").getProperty("/activityRegistration/to_ASol"):[];
                that.RapidRegDataModel.setProperty("/to_ASol", JSON.parse(JSON.stringify(aRegSol)))
                const sRegMat = this.getView().getModel("matrixModel").getProperty("/activityRegistration/to_AMaterial") ? this.getView().getModel("matrixModel").getProperty("/activityRegistration/to_AMaterial"):[];
                that.RapidRegDataModel.setProperty("/to_AMaterial", JSON.parse(JSON.stringify(sRegMat)));
                const sRegTaxonomy = this.getView().getModel("matrixModel").getProperty("/activityRegistration/to_ATaxonomy") ? this.getView().getModel("matrixModel").getProperty("/activityRegistration/to_ATaxonomy"):[];
                if(aFinalSlData.length){
                    that.RapidRegDataModel.setProperty("/to_ATaxonomy", JSON.parse(JSON.stringify(sRegTaxonomy)));
                }else{
                      that.RapidRegDataModel.setProperty("/to_ATaxonomy", []);
                }
             
                //that.RapidRegDataModel.setProperty("/ActivityGuid", this.getView().getModel("matrixModel").getProperty("/activityRegistration/ActivityGuid"));
                const oStartDate = this.getView().getModel("matrixModel").getProperty("/activityRegistration/StartDate") ? new Date(this.getView().getModel("matrixModel").getProperty("/activityRegistration/StartDate")) : new Date();
                const oEndDate = this.getView().getModel("matrixModel").getProperty("/activityRegistration/EndDate") ? new Date(this.getView().getModel("matrixModel").getProperty("/activityRegistration/EndDate")) : new Date();
                const oDemoDate = this.getView().getModel("matrixModel").getProperty("/activityRegistration/DryRunDate") ? new Date(this.getView().getModel("matrixModel").getProperty("/activityRegistration/DryRunDate")) : null;
                that.RapidRegDataModel.setProperty("/StartDate", oStartDate);
                that.RapidRegDataModel.setProperty("/EndDate", oEndDate);
                that.RapidRegDataModel.setProperty("/DryRunDate",  oDemoDate);
                const sRegToFiles = this.getView().getModel("matrixModel").getProperty("/activityRegistration/to_AFiles") ? this.getView().getModel("matrixModel").getProperty("/activityRegistration/to_AFiles"):[];
                that.RapidRegDataModel.setProperty("/to_AFiles", JSON.parse(JSON.stringify(sRegToFiles)));
                that.RapidRegUIModel.setProperty("/to_AFiles", JSON.parse(JSON.stringify(sRegToFiles)));
                const sRegAddOpp = this.getView().getModel("matrixModel").getProperty("/activityRegistration/to_AAddOpp") ? this.getView().getModel("matrixModel").getProperty("/activityRegistration/to_AAddOpp"):[];
                that.RapidRegDataModel.setProperty("/to_AAddOpp",  JSON.parse(JSON.stringify(sRegAddOpp)));
                that.oUserModel.setProperty("/SelectedTeam", this.getView().getModel("matrixModel").getProperty("/activityRegistration/to_ATeam"));
                const aOppTeam =   this.getView().getModel().getProperty("/OPP_TEAM") ?   this.getView().getModel().getProperty("/OPP_TEAM") :[];
                const aTeam = aOppTeam.filter(user => user.USER_ID && user.EMAIL).map(user => ({
                    ROLE: user.ROLE,
                    ROLE_DESC: user.ROLE_DESCR,
                    ID: user.USER_ID,
                    NAME: user.NAME,
                    PhoneNumber: user.TELEPHONE_NUMBER,
                    MobileNumber: user.MOBILE_NUMBER,
                    EMAIL: user.EMAIL,
                    checked: false
                }));
                if(aTeam.length){
                    that.oUserModel.setProperty("/PresalesTeam", aTeam);
                }
                that.selectedTeamMap = {};
                let aTeamVal = that.oUserModel.getProperty("/SelectedTeam");
                if (aTeamVal.length) {
                    //set Teamlist tokens
                    aTeamVal.forEach(user => that.selectedTeamMap[user.ID] = user);
                }
                sap.ui.core.Fragment.byId(that.RapidRegDialogId, "idActLead").setEditable(false);
                //set selected landscapes
                that.landscapeMap = {};
 
                if (aLandscapes.length) {
                    aLandscapes.filter(function (obj, index) {
                        that.landscapeMap[obj.LandsId] = obj;
                    });
                    that.addLandscapes();
                    if (that.oLandscapeDialog) {
                        that.oLandscapeDialog.close();
                    }
 
                }
             //   oToolbar.getContent()[3].setVisible(false);
                oDialog.getModel("RapidRegUIModel").setProperty("/isRapidRegDialogBusy", false);
                oDialog.getModel("RapidRegUIModel").refresh();
                   sap.ui.core.BusyIndicator.hide()
            }.bind(this), 3000);
        },
            /**
         * Git #230 Activity integration start
         * Set Activity team(Manager or Subst manager) details
         * @function _setActTeamValue
         */
        _setActTeamValue: function () {
            const oModel = this.getView().getModel(),
                aSubstApprover = oModel.getProperty("/substituteApproverDetails"),
                oLoggedInUserId = this.getOwnerComponent().getModel("userDetails").getProperty("/user_name"),
                aAllApproverDetails = this.getView().getModel().getProperty("/aResourceProfileApprovers/ApproverDetails") ? this.getView().getModel().getProperty("/aResourceProfileApprovers/ApproverDetails") : [],
                aSubstitute = aSubstApprover.filter(user => user.userId.toUpperCase() === oLoggedInUserId.toUpperCase()),
                aCurrentApproverId = this.getOwnerComponent().getModel("userDetails").getProperty("/user_name");
            this.aCurrentApprover = aAllApproverDetails.filter(appr => appr.ID.toUpperCase() === aCurrentApproverId.toUpperCase());
            let aAllApprovers;
            if (aSubstitute.length) {
                //execute this block for the substitute processor(Manager's substitute)
                //get Substitute details
                this._getSubstituteData("SubstituteId");

            } else {
                //this._getSubstituteData("ManagerId");
                let aFinalTeam = [{
                    "EMAIL": this.getOwnerComponent().getModel("userDetails").getProperty("/email"),
                    "ID": this.getOwnerComponent().getModel("userDetails").getProperty("/user_name"),
                    "NAME": this.getOwnerComponent().getModel("userDetails").getProperty("/name"),
                    "ROLE": this.aCurrentApprover.length ? this.aCurrentApprover[0].roleId : ''
                }];
                this.getView().getModel().setProperty("/aActivityTeamManager", aFinalTeam);
                if (!aFinalTeam[0].ROLE) {
                    //if approver role not present the call below ORE service
                    this._getCRMRoleFromORE(aFinalTeam)
                }
                this.getView().getModel().refresh();
            }

        },
          /**
         * Get role of the approvers
         * @function _getCRMRoleFromORE
         * @param {object}  aApprovers - approver list.
         */
        _getCRMRoleFromORE: function (aApprovers) {
            //set filter query
            const aApproverData = aApprovers.map(app => app.ID);
            const sFilterCondition = `(${aApproverData.map(userId => `(Id eq '${userId}')`).join(' or ')})`;
            sUrlParams = {
                $filter: sFilterCondition,
            }
            //oData get call for role
            const oIntLSModel = Models.systemLSUserDetailsDataModel(this,this),
                that = this;

            Models._callGETOdata(oIntLSModel, `/YC_DS_T_NAMED_CONTACT`, sUrlParams).
                then(function (data) {
                    if (data.results.length) {
                        //set approver roles
                        const aApproverDetails = data.results.map(function (obj) {
                            return {
                                EMAIL: obj.EmailId,
                                ID: obj.Id,
                                NAME: obj.EmpName,
                                ROLE: obj.Emp_CrmRoleId
                            };
                        });
                        that.getView().getModel().setProperty("/aActivityTeamManager", aApproverDetails);
                        that.getView().getModel().refresh();
                    }
                }.bind(that))
                .catch(function (oError) {
                    ErrorHandle.setErrorMessage(oError, that);
                });
        },
          /**
         * Get role of the substitutes
         * @function _getSubstituteData
         */
         _getSubstituteData: function (fieldName) {
            let sUserId = this.getOwnerComponent().getModel("userDetails").getData().user_name,
                sUrlParams = {
                    $filter: `${fieldName} eq '${sUserId}' and Active eq true`,
                }
            //oData get call for substitute
            const oIntLSModel = Models.systemResourcesDataModel(this),
                that = this;
 
            Models._callGETOdata(oIntLSModel, `/YC_MR_T_SUBSTITUTE`, sUrlParams).
                then(function (data) {
                    let aFinalApprover = [];
                    let aAllApproverDetails = that.getView().getModel().getProperty("/aResourceProfileApprovers/ApproverDetails") ? that.getView().getModel().getProperty("/aResourceProfileApprovers/ApproverDetails") : [],
                      aCurrentApproverId = that.getOwnerComponent().getModel("userDetails").getProperty("/user_name");
                    //filter current user
                    that.aCurrentApprover = aAllApproverDetails.filter(appr => appr.ID.toUpperCase() === aCurrentApproverId.toUpperCase());
                    if (data.results.length) {
                        const aContextAllApprover = that.getView().getModel().getProperty("/approverDetails");
                        data.results.forEach(function (subsManager) {
                            //set role for substitute manager
                            if(fieldName=="SubstituteId"){                        
                            let aManger = aContextAllApprover.filter(appr => appr.userId === subsManager.ManagerId),
                                aCurrentSubsManagerContext = aAllApproverDetails.filter(appr => appr.ID.toUpperCase() === subsManager.ManagerId.toUpperCase()),
                                oManager = {
                                    "EMAIL": subsManager.ManagerEmail,
                                    "ID": subsManager.ManagerId,
                                    "NAME": subsManager.ManagerName,
                                    "ROLE": subsManager.Manager_CrmRoleId
                                }
                            aManger.length ? aFinalApprover.push(oManager) : [];
                            if(!that.aCurrentApprover[0].roleId){
                                that.aCurrentApprover[0].roleId=subsManager.CrmRoleId
                            }
                            }else{
                                aAllApproverDetails= that.getView().getModel().getProperty("/substituteApproverDetails")
                                let aManger = aAllApproverDetails.filter(appr => appr.userId === subsManager.SubstituteId),
                                aCurrentSubsManagerContext = aAllApproverDetails.filter(appr => appr.userId.toUpperCase() === subsManager.SubstituteId.toUpperCase()),
                                oManager = {
                                    "EMAIL": subsManager.SubstituteEmail,
                                    "ID": subsManager.SubstituteId,
                                    "NAME": subsManager.SubstituteName,
                                    "ROLE": subsManager.CrmRoleId
                                }
                            aManger.length ? aFinalApprover.push(oManager) : [];
                                if(!that.aCurrentApprover[0].roleId){
                                that.aCurrentApprover[0].roleId=subsManager.Manager_CrmRoleId
                            }
                            }
                        });               
                    }
                    //set final approver array
                    aFinalApprover.push({
                        "EMAIL": that.getOwnerComponent().getModel("userDetails").getProperty("/email"),
                        "ID": that.getOwnerComponent().getModel("userDetails").getProperty("/user_name"),
                        "NAME": that.getOwnerComponent().getModel("userDetails").getProperty("/name"),
                        "ROLE": that.aCurrentApprover.length ? that.aCurrentApprover[0].roleId : ''
                    });

                    
                    that.getView().getModel().setProperty("/aActivityTeamManager", aFinalApprover);
                    if (!that.aCurrentApprover.length || (that.aCurrentApprover.length && !that.aCurrentApprover.every(item => item.ROLE || item.roleId))) {
                        //if approver role not present the call below ORE service
                        that._getCRMRoleFromORE(aFinalApprover)
                    }
 
                    that.getView().getModel().refresh();
                })
                .catch(function (oError) {
                    ErrorHandle.setErrorMessage(oError, that);
                });
 
        },
         /**
         * Open activity busy dialog when activity registarting triggers
         * @function _onOpenActivityBusyDialog
         * @param {obj} that Controller scope
         * @param {obj} processContext Worklow payload
         * @param {string} taskId Workflow instance id
         * @param {string} sDecision Decision of user task (Approve)
         */
         _onOpenActivityBusyDialog: function (that,processContext, taskId, sDecision,bsIsNoActivity) {
            const oView = this.getView(),
                  i18nModel =  this.getOwnerComponent().getModel("i18n").getResourceBundle(),
                  oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
             let oBusyDialogConfig = {
                 VATLabel:oAppConstantsModel.getProperty("/VATTeamLabel/0/Value"),
                 VATTWidth: "100px",
                 VATText: i18nModel.getText("activityRegInProgress"),
                 VATColorScheme: 1,
                 VATIcon: "sap-icon://lateness",
                 ACTLabel:oAppConstantsModel.getProperty("/ACTLabel/0/Value"),
                 ACTWidth: "auto",
                 ACTText: i18nModel.getText("activityRegInNotStarted"),
                 ACTColorScheme: 10,
                 ACTIcon: "sap-icon://stop",
                 RESLabel:oAppConstantsModel.getProperty("/activityRegResAssignment/0/Value"),
                 RESWidth: "auto",
                 RESText:i18nModel.getText("activityRegInNotStarted"),
                 RESColorScheme: 10,
                 RESIcon: "sap-icon://stop",
                 VATTeamExceptionVisible:false,
                 VATVisible:false,
                 ACTRegVisible:!bsIsNoActivity,
                 VATErrorMsg:""
             };
             oView.getModel().setProperty("/actRegDialog",oBusyDialogConfig);
             oView.getModel().refresh();

            if (!this._pActBusyDialogFragment) {
                //open activity busy dialog
                this._pActBusyDialogFragment = Fragment.load({
                    id: oView.getId(),
                    name: "com.dealsupport.melodyrequest.fragments.BusyStatusActivityDialog",
                    controller: this
                }).then(function (oActBusyDialog) {
                    that.oActBusyDialog = oActBusyDialog;
                    oView.addDependent(oActBusyDialog);
                    return oActBusyDialog;
                });
            }
 
            this._pActBusyDialogFragment.then(function () {      
                that.getView().setModel(new JSONModel({}), "actiVityBusyData");
                that.oActBusyDialog.setContentWidth("400px");
                that.oActBusyDialog.removeAllButtons();
                let sReqType = that.getView().getModel().getProperty("/RequestType");
                sReqType === "Opportunity" ? that.getView().getModel().setProperty("/actRegDialog/VATVisible",true):that.getView().getModel().setProperty("/actRegDialog/VATVisible",false);
                that.getView().getModel().refresh(true);
                that.getView().setBusy(true);
                that.oActBusyDialog.open();
                setTimeout(function () {
                    that.getView().setBusy(false);
                    if (that.getView().getModel().getProperty("/RequestType") === "Opportunity") {
                        //Add current manager or resource to the VAT                    
                        that._fnAddApproverToVAT(processContext, taskId, sDecision, bsIsNoActivity);
                    } else {
                        that._callAllActivityRegServices(that, processContext, taskId, sDecision, bsIsNoActivity);
                    }
                }.bind(that), 0);

            });
        },
          /**
         * Set default activity payload
         * @function _setActivityPaylod
         * @param {obj} oActivityContext Activity payload
         */
        _setActivityPaylod: function (oActivityContext) {
            const aActivityData = oActivityContext.ActTypesData,
                sSelectedAct = oActivityContext.selectedActivityType,
                aBoundActivity = aActivityData.filter(item => item.ActvtTypeID === sSelectedAct)[0],
                oSelectedNominee = this.oContextAssignmentObj.selectedNominees[0],
                oLoggedInUserModel = this.getOwnerComponent().getModel("userDetails"),
                oBaseModel = this.getView().getModel(),
                existingData = {
                    "to_AAccnt": oBaseModel.getProperty("/RequestType") === 'Opportunity' ? [] : [{
                        "accountname": oBaseModel.getProperty("/accountName"),
                        "accountid": oBaseModel.getProperty("/accountId")
                    }],
                    "to_AOpportunity": oBaseModel.getProperty("/RequestType") === 'Opportunity' ? [
                        {
                            "accountid": oBaseModel.getProperty("/accountId"),
                            "ACCOUNT_NAME": oBaseModel.getProperty("/accountName"),
                            "OPPT_ID": oBaseModel.getProperty("/opportunityId"),
                            "mastercodeid": "",
                            "PHASE_DESC": oBaseModel.getProperty("/CURR_PHASE_DESC")
                        }
                    ] : []
                };
 
            // oActivityContext.selectedActivityType = sSelectedAct;
            //fetch Team memeber
            oActivityContext.ActivityTypeInfo = aActivityData.filter(item => item.ActvtTypeID === sSelectedAct)[0].ActivityTypeInfo;
            oActivityContext.ActivityDesc = aActivityData.filter(item => item.ActvtTypeID === sSelectedAct)[0].ActvtTypeDesc;
            const oContextActivityPayload = oActivityContext.activityPaylod;
            var aActivityTeam=jQuery.extend(true,[],this.getView().getModel().getProperty("/aActivityTeamManager"))
            this.oContextAssignmentObj.selectedNominees.forEach(obj=>{aActivityTeam.push(obj.resourceManagerDetails)})
            const aTeamMember = aActivityTeam.map(obj => {
                return { ...obj, ActivityGuid: ("ActivityGuid" in oContextActivityPayload) ? oContextActivityPayload.ActivityGuid : "" }; // Create a new object with existing properties and the new 'status'
            }).filter((obj, index, self) =>
                        index === self.findIndex((t) => t.ID === obj.ID)
                    );
            const oSlnData = this.getView().getModel().getProperty("/solutionAreaPayload");
            let aDefaultSlnArea = oSlnData && oSlnData.length ? oSlnData.map(obj => {
                return { ...obj, ActivityGuid: ("ActivityGuid" in oContextActivityPayload) ? oContextActivityPayload.ActivityGuid : "" }; // Create a new object with existing properties and the new 'status'
            }):[];

            //default activity paylod length is 3
            if (Object.keys(oContextActivityPayload).length <= 3) {
                //set asset link
                const oAppConstantsModel = this.getOwnerComponent().getModel("appConstants"),
                      aAttachmentUrl = this.getView().getModel().getProperty("/requestDetails/attachmentUrls");
                let oAssetLink;
                if (aAttachmentUrl && aAttachmentUrl.length) {
                    oAssetLink = aAttachmentUrl.map(obj => {
                        return {
                            DocumentType: "0001",
                            Status: "X",
                            Url: obj.url,
                            ProjectType: "ACTVT",
                            FileId: "",
                            FileName: obj.urlName ? obj.urlName : obj.url,
                            ActivityGuid: ("ActivityGuid" in oContextActivityPayload) ? oContextActivityPayload.ActivityGuid : "",
                        };
                    });
                } else {
                    oAssetLink = [];
                }
                oActivityContext["aInitiatives"] = [];
                const aActivityFormConfig = this.getView().getModel().getProperty("/activityFormLayout")
                if (aDefaultSlnArea?.length && !aActivityFormConfig?.Fields?.AdditionalSolutions?.Visible) {
                    aDefaultSlnArea = [];
                }
                let sOppStatus = "",
                sOppStatusId = "";
                if (oBaseModel.getProperty("/opportunityId")) {
                     sOppStatus = formatter.getOppState(oBaseModel.getProperty("/dealInfo/STATUS")) ? formatter.getOppState(oBaseModel.getProperty("/dealInfo/STATUS")) : "";
                     sOppStatusId = this.getView().getModel().getProperty("/dealInfo/STATUS") ? this.getView().getModel().getProperty("/dealInfo/STATUS") : "";
                }

                //set activity paylod
                return {
                    "ActivityGuid": ("ActivityGuid" in oContextActivityPayload) ? oContextActivityPayload.ActivityGuid : "",
                    "ActivityLead": ("userId" in oSelectedNominee) ? oSelectedNominee.userId : "",
                    "ActivityLeadName": ("fullName" in oSelectedNominee) ? oSelectedNominee.fullName : "",
                    "ActivityLeadEmailId": ("email" in oSelectedNominee) ? oSelectedNominee.email : "",
                    "ActivityTypeDescription": ("ActvtTypeDesc" in aBoundActivity) ? aBoundActivity.ActvtTypeDesc : "",
                    "ActivityTypeId": ("ActvtTypeID" in aBoundActivity) ? aBoundActivity.ActvtTypeID : "",
                    "ActvtAsstdID": ("ActvtAsstdID" in aBoundActivity) ? aBoundActivity.ActvtAsstdID : "",
                    "ChildFrmLayoutId": ("ChildFrmLayoutId" in aBoundActivity) ? aBoundActivity.ChildFrmLayoutId : "",
                    "FormLayoutId": ("FormLayoutID" in aBoundActivity) ? aBoundActivity.FormLayoutID : "",
                    "Requestor": ("user_name" in oLoggedInUserModel) ? oLoggedInUserModel.user_name : "",
                    "RequestorName": ("name" in oLoggedInUserModel) ? oLoggedInUserModel.name : "",
                    "RoleMpngID": ("RoleMpngID" in aBoundActivity) ? aBoundActivity.RoleMpngID : "",
                    "OpportunityNumber": oBaseModel.getProperty("/opportunityId") ? oBaseModel.getProperty("/opportunityId") : "",
                    "StartDate": new Date().toISOString(),
                    "CreateDate": new Date().toISOString(),
                    "EndDate": this._getDateAfterXdays(6).toISOString(),
                    "GlobalUltimateID": oBaseModel.getProperty("/accountId"),
                    "Status":"01",
                    "to_ATeam": aTeamMember,
                    "to_AFiles": oAssetLink,
                    "to_ALand": [],
                    "to_AAddOpp": [],
                    "to_AInitiative": [],
                    "to_AMaterial": [],
                    "to_AAccnt": ("to_AAccnt" in existingData && existingData.to_AAccnt.length) ? existingData
                        .to_AAccnt : [],
                    "to_AOpportunity": ("to_AOpportunity" in existingData && existingData.to_AOpportunity.length) ? existingData
                        .to_AOpportunity : [],
                    "to_ASol": ("to_ASol" in oContextActivityPayload) ? oContextActivityPayload.to_ASol : [],
                    "to_APhase": ("to_ASol" in oContextActivityPayload) ? oContextActivityPayload.to_APhase : [],
                    "to_ATaxonomy": aDefaultSlnArea,
                    "assignmentID":this.oContextAssignmentObj.AssignmentID,
                    "IsMelodyRequest":true,
                    "OppStatusDesc": sOppStatus,
                    "OppStatusId":sOppStatusId,
                    "RiskAssessId":"03"

                };
 
            } else {
 
                return oContextActivityPayload;
            }
 
        },
           /**
         * Call activity type master data
         * @function _callActivityTypeMasterData
         * @param {obj} oAssignmentContext Assignment context
         */
        _callActivityTypeMasterData: function (oAssignmentContext) {
            const oMatrixModel = new sap.ui.model.json.JSONModel();
            //store activity related data in matrix model
            this.getView().setModel(oMatrixModel, "matrixModel");
            oAssignmentContext.activityInfoVisible = false;
            this.oContextAssignmentObj.actvityVisible = true
            const sActAsstId = this.getView().getModel().getProperty("/RequestType") === "Opportunity" ? "502" : "501";
                 sResourceId = oAssignmentContext.selectedNominees[0].userId,
                 sUrlParams = {
                      	$filter: `ActivtyTypeCatznID eq '0001' and ActvtAsstdID eq '${sActAsstId}'`,
                    };     
            oLSSystemModel = Models.systemLSDataModel(this);
            Models._callGETOdata(oLSSystemModel, `/YC_MR_M_USR_ACTTYPE_LIST(P_User='${sResourceId}')/Set`,sUrlParams).then(function (oData) {
                let aResults = oData.results;
                if (aResults.length) {
                    oAssignmentContext.activities[0].ActTypesData = JSON.parse(JSON.stringify(aResults));
                    oAssignmentContext.activities[0].ActTypes = JSON.parse(JSON.stringify(aResults));
                    oAssignmentContext.enableActivityRegister = true;
                    oAssignmentContext.activities[0].enableActivityRegister = true;
                    oAssignmentContext.activities[0].ActivityTypeInfo = false;
                } else {
                    oAssignmentContext.enableActivityRegister = false;
                    oAssignmentContext.activities[0].enableActivityRegister = false;
                    oAssignmentContext.activities[0].ActivityTypeInfo = `<p>Role <strong>${oAssignmentContext.selectedNominees[0].RoleDesc}</strong > is not eligible for any activity registration</p>`;
                }
                this.getOwnerComponent().getModel("mrrAppConfigModel").refresh();
                this.getView().getModel("assignmentsModel").refresh();
            }.bind(this))

        },
           /**
         * Change event for activity type combo box
         * @function onActivityTypeChange
         * @param {object} oEvent Control event scope
         */
        onActivityTypeChange: function (oEvent) {
            oEvent.getSource().getBindingContext("assignmentsModel").getObject().activityPaylod = {};
            let oBoundedContext = oEvent.getSource().getBindingContext("assignmentsModel"),
                oSelectedActType = oBoundedContext.getObject()["selectedActivityType"],
                //get model context
                aAllAssignedActivities = this._getParentContext(oEvent).activities,
                //check activity count per assignment
                oActTypeCount = aAllAssignedActivities.reduce((acc, item) => {
                    acc[item.selectedActivityType] = (acc[item.selectedActivityType] || 0) + 1;
                    return acc;
                }, {}),
                //duplicate activity type check
                hasActTypeDuplicates = Object.values(oActTypeCount).some(count => count > 1);
            oBoundedContext.activityInfoVisible = true;
            var oValidatedComboBox = oEvent.getSource(),
                sSelectedKey = oValidatedComboBox.getSelectedKey(),
                sValue = oValidatedComboBox.getValue();

            if (!sSelectedKey) {
                if (sValue) {
                    oBoundedContext.getObject()["actValueState"] = "Error";
                    oBoundedContext.getObject()["enableRegEdit"] = false;
                    oBoundedContext.getObject()["actValueStateText"] = "Select valid value from drop down"
                    this.getView().getModel("assignmentsModel").refresh();
                    return;

                } else {
                    oBoundedContext.getObject()["actValueState"] = "None";
                    oBoundedContext.getObject()["enableRegEdit"] = false;
                    oBoundedContext.getObject()["actValueStateText"] = ""
                    this.getView().getModel("assignmentsModel").refresh();
                    return;
                }

            } else {
                oBoundedContext.getObject()["enableRegEdit"] = true;
                oBoundedContext.getObject()["actValueState"] = "None";
            }
            if (hasActTypeDuplicates && oActTypeCount[oSelectedActType] > 1) {
                //Duplicate activity type validataion
                oBoundedContext.getObject()["actValueState"] = "Error";
                oBoundedContext.getObject()["enableRegEdit"] = false;
                oBoundedContext.getObject()["actValueStateText"] =   this.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/activityAssigmentValidation/0/fieldDesc")
            } else {
                //No deplicates
                oBoundedContext.getObject()["enableRegEdit"] = true;
                oBoundedContext.getObject()["actValueState"] = "None";
                if (!hasActTypeDuplicates) {
                    aAllAssignedActivities.forEach(function (item) {
                        if (item.selectedActivityType) {
                            item.enableRegEdit = true;
                            item.actValueState = "None"

                        }
                        item.actValueState = "None";

                    });
                }
            }

            let oActivityContext = oEvent.getSource().getBindingContext("assignmentsModel").getObject();
            let oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
            CommonJS._OpenBusyIndicator(this,oAppConstantsModel.getProperty("/actTypeBusyIndicatorText/0/Value"));
            if (!("ActivityGuid" in oEvent.getSource().getBindingContext("assignmentsModel").getObject().activityPaylod)) {
                //Call to generate activity guid (Activity service)
                this._generateActivityGuid(oEvent,true);
            } else {
                //set default activity payload
                oEvent.getSource().getBindingContext("assignmentsModel").getObject().activityPaylod = this._setActivityPaylod(oActivityContext);
            const oActivityPaylod = oEvent.getSource().getBindingContext("assignmentsModel").getObject().activityPaylod;
            //get CVJ Phase value based on activity
            this.getCVJPhaseMaster(oActivityPaylod["ActivityTypeId"], oActivityPaylod["RoleMpngID"], oActivityPaylod);
            }
           
            this.getView().getModel("assignmentsModel").refresh();
              //call activity formlayout service to check mandt field
            let aSelectActivityContext = 	oBoundedContext.getObject()["ActTypesData"].filter(item => item.ActvtTypeID === oSelectedActType)[0];
            let aFilter = [new Filter("FormLayoutID", "EQ", aSelectActivityContext["ChildFrmLayoutId"])];
            this.fnGetLayoutData(aFilter,this);
            
        },
           /**
         * Git #230 Activity integration start
         * get the rapid reg layout fields config
         * @param {object}  aFilter - Passing activity type id as filter.
         * @param {object}  that - controller scope.
         * @function fnGetLayoutData
         */
        fnGetLayoutData: function (aFilter,that,bIsActivityDisplay) {
            that.bIsActivityDisplay = bIsActivityDisplay;
            function getFormLayout() {
                return new Promise((resolve) => {
                    //Call activity library service to get activity form layout
                    const response =  ActivityService.fnGetLayoutData(aFilter);
                    resolve(response);
                }).then(function (response) {
                    if(response && response.length){
                        that.getView().getModel().setProperty("/activityFormLayout",JSON.parse(response[0].FormLayoutString));
                        that.getView().getModel().refresh();
                        if(that.bIsActivityDisplay){
                            //activity display scenario
                            let oAssignmentModelData =  that.getView().getModel("assignmentsModel").getData().assignments;
                            oAssignmentModelData.forEach(function(item){
                                if(item.activities && item.activities.length){
                                    item.activities.forEach(function(obj){
                                        if("activityPaylod" in obj){
                                            const aFilteredLayout = response.filter(layout=>layout.FormLayoutID === obj.activityPaylod.ChildFrmLayoutId);
                                            if(aFilteredLayout.length){
                                                //add form layout configuration
                                                obj.SelectedLayout = JSON.parse(aFilteredLayout[0].FormLayoutString);
                                            }
                                            
                                        }
                                    });
                                }
                            })
                             that.getView().getModel("assignmentsModel").refresh();
                        }
                    }
                      CommonJS._closeBusyIndicator(that);
                   
                }.bind(that));
            }
            return getFormLayout();

        },
           /**
         * Duplicate check for activity type
         * @function _activityDuplicatesCheck
         * @param {array} aAllAssignedActivities Activity list
         */
        _activityDuplicatesCheck: function (aAllAssignedActivities) {
            const oActTypeCount = aAllAssignedActivities.reduce((acc, item) => {
                acc[item.selectedActivityType] = (acc[item.selectedActivityType] || 0) + 1;
                return acc;
            }, {});
            return Object.values(oActTypeCount).some(count => count > 1);
        },
          /**
         * Get CVJ Phase value based on activity
         * @function getCVJPhaseMaster
         * @param {number} ActivityTypeId ActivityType Id
         * @param {number} RoleMpngID Resource Role Id
         * @param {object} oActivityPaylod Activity payload
         */
        getCVJPhaseMaster: async function (ActivityTypeId, RoleMpngID, oActivityPaylod) {
            let aFilter = [];
            //set payload for CVJ Phase service
            if (ActivityTypeId) {
                aFilter.push(new Filter("Acttypeid", "EQ", ActivityTypeId));
            }
            if (RoleMpngID) {
                aFilter.push(new Filter("RoleMpngID", "EQ", RoleMpngID));
            }
            //Call getCVJPhaseMasterData from Activity service library
            let CVJPhaseMaster = await ActivityService.getCVJPhaseMasterData(aFilter) || [];
            let defaultCvjId = "";
            let defaultCvjDesc = "";
              //Set default CVJ value
            if (CVJPhaseMaster && CVJPhaseMaster.length === 1) {
                defaultCvjId = CVJPhaseMaster[0].CvjPhaseId;
            } else {
                CVJPhaseMaster.filter(function (item) {
                    if (item.DefaultCVJ === "X") {
                        defaultCvjId = item.CvjPhaseId;
                        defaultCvjDesc = item.CvjPhaseDesc;
                    }
                });
            }
            oActivityPaylod.CvjPhaseDesc = defaultCvjDesc;
            oActivityPaylod.CvjPhaseId = defaultCvjId;
        },
      /**
         * Add new activity
         * @function getCVJPhaseMaster
         * @param {object} oEvent Control (button) event context
         */
        onAddActivity: function (oEvent) {
            //Create Activity object
            const oActivity = {
                "selectedActivity": "",
                "activityPaylod": {},
                "actValueState": "None",
                "enableRegEdit": false,
                "activityDelete": true,
                "ActTypesData": oEvent.getSource().getBindingContext("assignmentsModel").getObject().activities[0].ActTypesData,
                "ActTypes": oEvent.getSource().getBindingContext("assignmentsModel").getObject().activities[0].ActTypes,
                "selectedActivityType": ""
            }
            //Set activity data
            oEvent.getSource().getBindingContext("assignmentsModel").getObject().activities[0].activityDelete = true;
            oEvent.getSource().getBindingContext("assignmentsModel").getObject().activities.push(oActivity);
            //generate activity Guid
            this._generateActivityGuid(oEvent);
            this.getView().getModel("assignmentsModel").refresh();
            const oAppConfigModel = this.getOwnerComponent().getModel("mrrAppConfigModel").getData();
            oAppConfigModel.ActivityType_InfoBubble = [{
                "fieldDesc": ""
            }];
            this.getOwnerComponent().getModel("mrrAppConfigModel").refresh();
        },
          /**
         * Generate unique activity guid (This being used for activity registration)
         * @function _generateActivityGuid
         * @param {object} oEvent Control event context
         */
        _generateActivityGuid: function (oEvent,bActivityChange) {
            function generateGuid() {
                return new Promise((resolve) => {
                    //Call activity library service to get activity guid
                    const response = ActivityService.fnInitializeNewActivity({});
                    resolve(response);
                }).then(function (response) {
                    //Set the activity guid in activity payload
                    if (!oEvent.getSource().getBindingContext("assignmentsModel").getObject().selectedActivityType) {
                        let aActivities = oEvent.getSource().getBindingContext("assignmentsModel").getObject().activities;
                        aActivities[aActivities.length - 1]["activityPaylod"]["ActivityGuid"] = response.ActivityGuid;
 
                    } else {
                        oEvent.getSource().getBindingContext("assignmentsModel").getObject()["activityPaylod"]["ActivityGuid"] = response.ActivityGuid;
                        let oActivityContext = oEvent.getSource().getBindingContext("assignmentsModel").getObject();
                        oEvent.getSource().getBindingContext("assignmentsModel").getObject()["activityPaylod"] = oEvent.getSource().getModel("appConstants").getProperty("/oControllerScp")._setActivityPaylod(oActivityContext);
                    }
                    const oActivityPaylod = oEvent.getSource().getBindingContext("assignmentsModel").getObject().activityPaylod;
                    if(bActivityChange){
                         //get CVJ Phase value based on activity
                    oEvent.getSource().getModel("appConstants").getProperty("/oControllerScp").getCVJPhaseMaster(oActivityPaylod["ActivityTypeId"], oActivityPaylod["RoleMpngID"], oActivityPaylod);
                    }
                   
                   
                    oEvent.getSource().getModel("assignmentsModel").refresh()
                      CommonJS._closeBusyIndicator(oEvent.getSource().getModel("appConstants").getProperty("/oControllerScp"));
                }.bind(oEvent));
            }
            return generateGuid(this);
 
        },
          /**
         * Call service to store activity details for temporary
         * @function _fnStoreActivityTemp
         * @param {object} self Controller scope
         */
        _fnStoreActivityTemp: function (self) {
            function fnStoreTempActivity(items) {
                return new Promise((resolve) => {
                    const oActivityPaylod = {
                        "instanceID": self.getView().getModel("wfInstanceModel").getProperty("/InstanceID"),
                        "assignmentID": items.assignmentId.toString(),
                        "activity_GUID": items.activityPaylod.ActivityGuid,
                        "activit_Payload": JSON.stringify(items.activityPaylod)
                    };
                    oResponse = Models._callActivityTempDataService(self, oActivityPaylod, "POST")
                    resolve(oResponse);
                }).then(function () {
                }.bind(self));
            }
            let aAssignmentsData = this.getView().getModel("assignmentsModel").getData().assignments,
                aAllActivities = [];

            aAssignmentsData.forEach(function (data) {
                const newProperty = 'assignmentId';
                const newValue = data.AssignmentID;
                const aFinalActivities = data.activities.map(item => {
                    return { ...item, [newProperty]: newValue }; // Using spread syntax to create a new object
                });
                aAllActivities = aAllActivities.concat(aFinalActivities)
            })
            let aOnRegActivityAllPromises = [];
            aAllActivities.forEach(function (items) {
                aOnRegActivityAllPromises.push(fnStoreTempActivity(items));
            })
            Promise.all(aOnRegActivityAllPromises)
                .then(function () {
                    self._triggerComplete(this.oAssignments, this.sUserTaskId,
                        "Approve");
                }.bind(self))
                .then(data => {
                    // 'data' will be an array of the parsed JSON data from each service call

                })
                .catch(error => {
                    // One or more promises rejected
                    console.error('Error in one of the service calls:', error);
                });


        },
         /**
         * Register activity
         * @function _fnRegisterActivity
         * @param {obj} that Controller scope
         * @param {obj} processContext Worklow payload
         * @param {string} taskId Workflow instance id
         * @param {string} sDecision Decision of user task (Approve)
         */
       _fnRegisterActivity: function (that, processContext, taskId, sDecision) {
           if (that.oActBusyDialog) {
               that.oActBusyDialog.removeAllButtons();
                that.oActBusyDialog.setContentWidth("400px");
           }
            that.getView().getModel().setProperty("/actRegDialog/VATTeamExceptionVisible",false);
            that.counter = 0;
            that.activityRegistration = true;
            that.processContext = processContext;
            let oActivityBusyText;
            let aActivityResponse = [];
            let i18nModel =  that.getOwnerComponent().getModel("i18n").getResourceBundle();
            function fnRegActivity(items) {
                return new Promise((resolve) => {
                    const oInstanceModel = that.getView().getModel("wfInstanceModel");
                    items.activityPaylod.ParentInstanceguid = oInstanceModel.getProperty("/ParentInstanceID");
                    items.activityPaylod.InstanceGuid = oInstanceModel.getProperty("/InstanceID");
                    items.activityPaylod.RefId =  oInstanceModel.getProperty("/Parent_RefrenceID") ? oInstanceModel.getProperty("/Parent_RefrenceID").toString():"";
                    items.activityPaylod.SubRefId =  oInstanceModel.getProperty("/RefrenceID") ? oInstanceModel.getProperty("/RefrenceID").toString():"";
                    items.activityPaylod.OpportunityNumber = that.getView().getModel().getProperty("/opportunityId") ? that.getView().getModel().getProperty("/opportunityId") : "";
                    //  obj.is_rec => solution area recent selection
                    items.activityPaylod.to_ATaxonomy.forEach(function (obj) {
                        delete obj.guid;
                        delete obj.Levels;
                        delete obj.LevelDesc;
                        delete obj.LevelId;
                        delete obj.isSelected;
                        obj.is_rec = "X";
                    })
                      if(!items.activityPaylod.DryRunDate || items.activityPaylod.DryRunDate  === "null"){
                            delete  items.activityPaylod.DryRunDate;
                        }
                    delete items.activityPaylod.displayTempSlnTokens;
                    delete items.activityPaylod.assignmentID;
                    delete items.activityPaylod._AAddOpp;
                    delete items.activityPaylod._AInitiative;
                    delete items.activityPaylod._ALand;
                    delete items.activityPaylod._AMaterial;
                    delete items.activityPaylod._ATeam;
                    delete items.activityPaylod._AFiles;
                    delete items.activityPaylod._ATaxonomy;
                    delete items.activityPaylod.Instance_Guid;
                    delete items.activityPaylod.AssignmentID;
                    delete items.activityPaylod.Status_Desc;
                    delete items.activityPaylod.LastChangedBy;
                    delete items.activityPaylod.IsMelodyRequest;
                   // delete items.activityPaylod.ReqMgrId;
                    delete items.activityPaylod.ActvtCntry;
                   // delete items.activityPaylod.NumberAttendees;
                    //delete items.activityPaylod.ImpactId;
                    //delete items.activityPaylod.Archived;
                    delete items.activityPaylod.RequestorEmailId;
                    const oBaseModel = that.getView().getModel();
                    items.activityPaylod.to_AAccnt =  oBaseModel.getProperty("/RequestType") !== 'Opportunity' ?[{
                        "accountname": oBaseModel.getProperty("/accountName"),
                        "accountid": oBaseModel.getProperty("/accountId")
                    }]:[];
                      items.activityPaylod.to_AOpportunity = oBaseModel.getProperty("/RequestType") === 'Opportunity' ? [
                        {
                            "accountid": oBaseModel.getProperty("/accountId"),
                            "ACCOUNT_NAME": oBaseModel.getProperty("/accountName"),
                            "OPPT_ID": oBaseModel.getProperty("/opportunityId"),
                            "mastercodeid": "",
                            "DESCRIPTION":   oBaseModel.getProperty("/Opp_Desc"),
                            "PHASE_DESC": oBaseModel.getProperty("/NewOppDetails/CURR_PHASE_DESC")
                        }
                    ] : [];
                   
           

                    if(!items.activityPaylod.external_flag){
                         delete items.activityPaylod.external_flag;
                    }
                    
                   const response = ActivityService.fnInitializeNewActivity(items.activityPaylod);
                    resolve(response);
                }).then(function (response) {
                    aActivityResponse.push(response);
                    let aAssignments = this.getView().getModel().getData().currentStepID === "RESAPP" && that.getView().getModel().getData().AllAssignmentDetails
                        && that.getView().getModel().getData().AllAssignmentDetails.length ? that.processContext.AllAssignmentDetails : that.processContext;
                    aAssignments.forEach(function (items) {
                        const aActivityList = items.activityLists ?  items.activityLists : items.NominatedResources[0].activityLists;
                        aActivityList.forEach(function (activity) {
                            if (JSON.stringify(response).includes(activity.ActivityGuid)) {
                                activity.ActivityID = response.ActivityId ? response.ActivityId.replace(/^0+/, ''):"";
                                activity.activityStartDate = response.StartDate ? response.StartDate.toISOString() : null;
                                activity.activityEndDate = response.StartDate ? response.EndDate.toISOString() : null;
                                activity.activityUrl = `${that.getOwnerComponent().getModel("appConstants").getProperty("/ActivityURL/0/Value")}${activity.ActivityID}`;
                            }
                        })
 
                    })
                    if (that.activityRegistration) {
                        that.counter++;
                        const oBusyModelData = that.getView().getModel("actiVityBusyData");
                        oActivityBusyText = `Registering activity (${that.counter}/${that.iActivityLength})`
                        oBusyModelData.setProperty("/activityBusyText", oActivityBusyText);
                        oBusyModelData.setProperty("/footerVisible", false);
                        oBusyModelData.refresh();
                    }
                }.bind(that));
            }
            let aAssignmentsData = this.getView().getModel("assignmentsModel").getData().assignments,
                aAllActivities = [];
 
            aAssignmentsData.forEach(function (data) {
                if (data.enableActivityRegister) {
                    aAllActivities = aAllActivities.concat(data.activities)
                }
            })
            let aOnRegActivityAllPromises = [];
            that.iActivityLength = aAllActivities.length;
            const oBusyModelData = that.getView().getModel("actiVityBusyData");
            oActivityBusyText = `Registering activity (1/${aAllActivities.length})`;
            oBusyModelData.setProperty("/activityBusyText", oActivityBusyText);
            oBusyModelData.setProperty("/activityStatus", "Warning");
            oBusyModelData.setProperty("/activityStatusIcon", "sap-icon://pending");
            oBusyModelData.setProperty("/footerVisible", false);
            oBusyModelData.setProperty("/submitTextVisible", false);
           if (!that.bIsVATError) {
               that.getView().getModel().setProperty("/actRegDialog/VATText", i18nModel.getText("activityRegComplete"));
               that.getView().getModel().setProperty("/actRegDialog/VATColorScheme", 8);
               that.getView().getModel().setProperty("/actRegDialog/VATIcon", "sap-icon://status-completed");
           }
            that.getView().getModel().setProperty("/actRegDialog/ACTLabel",oActivityBusyText);
            that.getView().getModel().setProperty("/actRegDialog/ACTWidth","100px");
            that.getView().getModel().setProperty("/actRegDialog/ACTText",i18nModel.getText("activityRegInProgress"));
            that.getView().getModel().setProperty("/actRegDialog/ACTColorScheme",1);
            that.getView().getModel().setProperty("/actRegDialog/ACTIcon","sap-icon://lateness");
            that.getView().getModel().refresh();
            aAllActivities.forEach(function (items) {
                aOnRegActivityAllPromises.push(fnRegActivity(items));
            })
            Promise.all(aOnRegActivityAllPromises)
                .then(function (response) {
                    const oBusyModelData = that.getView().getModel("actiVityBusyData");
                    oActivityBusyText = `Registering activity (${that.iActivityLength}/${that.iActivityLength})`;
                    oBusyModelData.setProperty("/activityBusyText", oActivityBusyText);
                    //set activity busy dialog properties
                    that.getView().getModel().setProperty("/actRegDialog/ACTLabel",oActivityBusyText);
                    that.getView().getModel().setProperty("/actRegDialog/ACTText",i18nModel.getText("activityRegComplete"));
                    that.getView().getModel().setProperty("/actRegDialog/ACTColorScheme",8);
                    that.getView().getModel().setProperty("/actRegDialog/ACTIcon","sap-icon://status-completed");
                    that.getView().getModel().setProperty("/actRegDialog/RESWidth","100px");
                    that.getView().getModel().setProperty("/actRegDialog/RESText",i18nModel.getText("activityRegInProgress"));
                    that.getView().getModel().setProperty("/actRegDialog/RESColorScheme",1);
                    that.getView().getModel().setProperty("/actRegDialog/RESIcon","sap-icon://lateness");
                    that.getView().getModel().refresh();
                    oBusyModelData.setProperty("/activityStatus", "Success");
                    oBusyModelData.setProperty("/activityBusyVisible", false);
                    oBusyModelData.setProperty("/activityStatusIcon", "sap-icon://sys-enter-2");
                    oBusyModelData.setProperty("/submitStatus", "Warning");
                    oBusyModelData.setProperty("/submitStatusIcon", "sap-icon://pending");
                    oBusyModelData.setProperty("/submitTextVisible", true);
                    oBusyModelData.setProperty("/footerVisible", false);
                    oBusyModelData.refresh();
                    let aNonVATMembers =   this.getView().getModel().getProperty("/nonVATMember");
                    let sReqType = this.getView().getModel().getProperty("/RequestType");
                    let aTeamMembers = aNonVATMembers.map(item => {
                        // Find the ntry that contains this ID in its to_ATeam
                        const entry = aActivityResponse.find(u => u.to_ATeam.results && u.to_ATeam.results.some(t => t.ID === item.ID));

                        if (!entry) return null; // skip if not found

                        // Find the specific to_ATeam object that matches
                        const teamMember = entry.to_ATeam.results ? entry.to_ATeam.results.find(t => t.ID === item.ID) : {};

                        // final payload
                        return {
                            activityId: entry.ActivityId,
                            ID: teamMember.ID || null
                        };
                    }).filter(Boolean); // remove nulls if ID not found

                    if ( sReqType === "Opportunity" && aNonVATMembers.length && that.bIsAddAVATTeam && aTeamMembers.length) {
                        that.fnSaveOppoVATTeamMembers(aTeamMembers,processContext, taskId, sDecision);
                    } else {
                        that._triggerComplete(processContext, taskId, sDecision);
                    }
 
                }.bind(that))
                .then(data => {
 
                    // 'data' will be an array of the parsed JSON data from each service call
 
                })
                .catch(error => {
                    that.activityRegistration = false;
                    const oBusyModelData = that.getView().getModel("actiVityBusyData"),
                        oActivityBusyText = `Activity registeration failed`;
                    oBusyModelData.setProperty("/activityBusyText", oActivityBusyText);
                    oBusyModelData.setProperty("/activityStatus", "Error");
                    that.getView().getModel().setProperty("/actRegDialog/ACTLabel",oActivityBusyText);
                    that.getView().getModel().setProperty("/actRegDialog/ACTText",i18nModel.getText("ACTRegFailed"));
                    that.getView().getModel().setProperty("/actRegDialog/ACTColorScheme",2);
                    that.getView().getModel().setProperty("/actRegDialog/ACTIcon","sap-icon://error");
                    that.getView().getModel().refresh();
                    oBusyModelData.setProperty("/activityBusyVisible", false);
                    oBusyModelData.setProperty("/footerVisible", true);
                    oBusyModelData.setProperty("/activityStatusIcon", "sap-icon://error");
                    oBusyModelData.refresh();
                });
        },
         /**
         * Save VAT team addes users for email notification 
         * @function fnSaveOppoVATTeamMembers
         * @param {obj} aTeamMembers VAT Team members
         * @param {obj} processContext Worklow payload
         * @param {string} taskId Workflow instance id
         * @param {string} sDecision Decision of user task (Approve)
         */
        fnSaveOppoVATTeamMembers: function (aTeamMembers,processContext, taskId, sDecision) {
            let that = this;
            let oTempArr = [];
            let sOppoOwnerId =  this.getView().getModel().getProperty("/oppOwnerDetails").id;
            let sOpportunityId = this.getView().getModel().getProperty("/opportunityId");
           
            for (let i = 0; i < aTeamMembers.length; i++) {
                    let oTempObj = {
                        "SlId": "",
                        "OppOwnerId": sOppoOwnerId,
                        "ActivityId": aTeamMembers[i]["activityId"] ?  aTeamMembers[i]["activityId"].replace(/^0+/, '') : "",
                        "OpportunityId":sOpportunityId,
                        "UserId": aTeamMembers[i]["ID"],
                        "UserAddedAt": new Date().toJSON().split(".")[0] + "Z"
                    };
                    oTempArr.push(oTempObj);
            }
            let oPayload = {
                to_team: oTempArr,
                OpportunityId: sOpportunityId
            };
            OpportunityService.getServiceToSaveOppVAT(oPayload).then((oResponse) => {
                that._triggerComplete(processContext, taskId, sDecision);
            }).catch(() => {
                that._triggerComplete(processContext, taskId, sDecision);
            });
        },
        _getNonVATTeamData: function (bsIsNoActivity) {
            let aAssignmentsData = jQuery.extend(true, [], this.getView().getModel("assignmentsModel").getData().assignments),
                aAllActivities = [],
                aSelectedResources = [];
            aAssignmentsData.forEach(function (data) {
                aSelectedResources.push(data.selectedNominees)
                if (data.enableActivityRegister) {
                    aAllActivities = aAllActivities.concat(data.activities)
                }
            });
            //set NonVAT Team ->1
            function mergeNonVATTeeam(activities) {
                const unique = new Map();

                activities.forEach(item => {
                    item.activityPaylod.to_ATeam.forEach(member => {
                        if (!unique.has(member.ID)) {
                            unique.set(member.ID, member);
                        }
                    });
                });

                return Array.from(unique.values());
            }
            let aTeamembers = !bsIsNoActivity ? mergeNonVATTeeam(aAllActivities):[],
            //if step is manager approval and skip is enable push all the resource to the VAT
                aSelectedNominee = this.getView().getModel().getProperty("/RequestType") === "Opportunity" && this.getView().getModel().getProperty("/currentStepID") === 'MANAPP' && this.getView().getModel().getProperty("/Skip_Resource_Approver")
                    ? aAssignmentsData.map(obj => {
                        return {
                            EMAIL: obj.selectedNominees[0].email,
                            ID: obj.selectedNominees[0].userId,
                            NAME: obj.selectedNominees[0].fullName,
                            ROLE: obj.selectedNominees[0].assignedRoleData.id
                        };
                    }) : [];
            aTeamembers = aTeamembers.concat(aSelectedNominee);
            aTeamembers = [...new Map(aTeamembers.map(item => [item.ID, item])).values()];
            let oOppData = this.getView().getModel().getProperty("/OPP_DATA");
            let aOppTeam = oOppData && oOppData.d && oOppData.d.PartiesInvolved.results && oOppData.d.PartiesInvolved.results ? oOppData.d.PartiesInvolved.results : [];

            const aNonVATmembers = aTeamembers.length && aOppTeam.length ? aTeamembers.filter(item1 =>
                !aOppTeam.some(item2 =>
                    item2.USER_ID === item1.ID &&
                    item2.ROLE === item1.ROLE
                )
            ) : [];
            return aNonVATmembers;
        },
          /**
         * Add team memberts to VAT team and register acyivity
         * @function _callAllActivityRegServices
         * @param {obj} processContext Worklow payload
         * @param {string} taskId Workflow instance id
         * @param {string} sDecision Decision of user task (Approve)
         */
        _callAllActivityRegServices: function (that, processContext, taskId, sDecision,bsIsNoActivity) {
            that.getView().getModel().setProperty("/nonVATMember", []);
            that.getView().getModel().refresh();
            that.bIsAddAVATTeam = false;
            that.bIsVATError = false;
            this.aUpdatedTeam = [];
            //set NonVAT Team ->1
            const aNonVATmembers =this._getNonVATTeamData(bsIsNoActivity);
            const sReqType = this.getView().getModel().getProperty("/RequestType");
            sReqType === "Opportunity" ? that.getView().getModel().setProperty("/actRegDialog/VATVisible",true): that.getView().getModel().setProperty("/actRegDialog/VATVisible", false);
            if(sReqType === "Opportunity" && aNonVATmembers.length){
                //Get NonVAT Team ->1
                that.getView().getModel().setProperty("/nonVATMember",aNonVATmembers);
                that.getView().getModel().refresh();

            //Call VAT team services ->3
            async function VATTeam(users) {
                let aNonVATmembers =  that.getView().getModel().getProperty("/nonVATMember");
                for (const id of users) {
                    //Call Business Partner - 4
                    await callBusineessPartnerService(id);
                }
            
                //Call User Search to get the crm details (Role,Role desc etc) - 5
                let aFilter = [];
                for (let i = 0; i < aNonVATmembers.length; i++) {
                     aFilter.push(new Filter("ID", "EQ", aNonVATmembers[i].USERID));
                }
                if (aFilter.length) {
                    let oParams = {
                        filters: aFilter
                    };
                    //6
                    OpportunityService.getServiceToUserSearch(oParams).then((oResponse) => {
                        let aResponse = oResponse.data.results;
                       aNonVATmembers.filter(function (NoUserObj) {
                            aResponse.filter(function (obj) {
                                if (obj.ID === NoUserObj.USERID) {
                                    NoUserObj.CRMRoleId = obj.CrmRoleId;
                                    NoUserObj.CRMRoleDesc = obj.CrmRoleDesc;
                                }
                            })
                        });
                        //Register VAT Team to harmony ->7

                        let oPartiesInvolved = [];
                        let oppData = that.getView().getModel().getProperty("/OPP_DATA")
                        let oppoData = {
                            "GUID": oppData.d.GUID,
                            "OPPT_ID": that.getView().getModel().getProperty("/opportunityId"),
                            "CHANGED_AT": oppData.d.CHANGED_AT,
                            "EXPECT_END": oppData.d.EXPECT_END

                        }
                        for (let i = 0; i < aNonVATmembers.length; i++) {
                            let obj = {
                                "ADDRESS": aNonVATmembers[i].ADDRESS,
                                "COUNTRY": aNonVATmembers[i].COUNTRY,
                                "EMAIL": aNonVATmembers[i].EMAIL,
                                "ID": aNonVATmembers[i].PARTNER,
                                "IS_EDITABLE": "",
                                "MODE": "A",
                                "MAINPARTNER": false,
                                "NAME": aNonVATmembers[i].NAME,
                                "PARTY_TYPE": "EMPLOYEE",
                                "ROLE": aNonVATmembers[i].CRMRoleId,
                                "ROLE_DESCR": aNonVATmembers[i].CRMRoleDesc,
                                "WEBSITE": ""
                            };
                            oPartiesInvolved.push(obj);
                            }
                        oppoData.PartiesInvolved = oPartiesInvolved;
                        OpportunityService.getServiceToPostOpportunityData(oppoData).then(() => {
                            that.bIsAddAVATTeam = true;
                            //Register Activity
                             that._fnRegisterActivity(that, processContext, taskId, sDecision);
                        }).catch((error) => {
                            //show VAT Exception
                            that._setVATExceptionMsg(processContext, taskId, sDecision,error);
                           
                        });

                    }).catch((error) => {
                           //show VAT Exception
                            that._setVATExceptionMsg(processContext, taskId, sDecision,error);
                    });

                }
            }
            //Call Business Partner - 4
            function callBusineessPartnerService(users) {
                let userID = users.ID,
                    urlParameters = {
                        filters: [
                            new Filter({
                                path: "TYPE",
                                operator: "EQ",
                                value1: "E"
                            })
                        ],
                        search: userID
                    }
                return new Promise((resolve, reject) => {
                    OpportunityService.getBusinessPartners(urlParameters.search, urlParameters.filters).then((oResponse) => {
                        let oData = oResponse.data.results[0];
                        if (oData) {
                            aNonVATmembers.forEach(obj => {
                                if (obj.ID === oData.USERID) {
                                    obj.NAME = oData.NAME;
                                    obj.USERID = oData.USERID;
                                    obj.PARTNER = oData.PARTNER;
                                    obj.COUNTRY = oData.COUNTRY;
                                    obj.ADDRESS = oData.ADDRESS;
                                }
                            });

                        }
                        resolve(oData);
                    }).catch((oError) => {
                         //show VAT Exception
                            that._setVATExceptionMsg(processContext, taskId, sDecision,oError);
                        reject(oError)
                    });

                });
            }

            //Call VAT services - 2
            VATTeam.call(this, aNonVATmembers, 0);
        }else{
            this._fnRegisterActivity(this, processContext, taskId, sDecision);
        }

        },
          /**
         * 
         * Add approvers to the VAT Team
         * @param {obj} processContext Worklow payload
         * @param {string} taskId Workflow instance id
         * @param {string} sDecision Decision of user task (Approve)
         * @function _fnAddApproverToVAT
         */
        _fnAddApproverToVAT: function (processContext, taskId, sDecision,bsIsNoActivity) {
            let oModel = this.getView().getModel();
            let that = this;
            const bSkip_Res = oModel.getProperty("/Skip_Resource_Approver");
            let aApprovers =  oModel.getProperty("/approverDetails") ?   oModel.getProperty("/approverDetails"):[];
            let oOppData = oModel.getProperty("/OPP_DATA");
            let aOppTeam = oOppData && oOppData.d && oOppData.d.PartiesInvolved && oOppData.d.PartiesInvolved.results ? oOppData.d.PartiesInvolved.results :[];
            const sLoggedInUserEmail = this.getOwnerComponent().getModel("userDetails").getProperty("/email");
            const sLoggedInUserId = this.getOwnerComponent().getModel("userDetails").getProperty("/user_name");
            this.getView().getModel().setProperty("/actRegDialog/VATVisible",true);
            const sStep =oModel.getProperty("/currentStepID");
            this.getView().getModel().refresh();
            const aNonVATmembers = this._getNonVATTeamData(bsIsNoActivity);
            //CPI payload
            let oApprover = {
                opportunityId: this.getView().getModel().getProperty("/opportunityId"),
                requestIntent: "UPDATE_DATA",
                assignedResourceData: {
                }
            };
            let oCurrentApprover;
            if (sStep === "MANAPP" && bSkip_Res) {
                //processor => skip resource enabled
                let aResApprover = this.getView().getModel().getProperty("/aResourceProfileApprovers/ApproverDetails") ? this.getView().getModel().getProperty("/aResourceProfileApprovers/ApproverDetails") :[];
                aApprovers = aApprovers.map(item1 => {
                    const match = aResApprover.find(item2 => item2.ID === item1.userId);
                    return { ...item1, ...match };
                });
                //update current processor details for CPI Payload
                oCurrentApprover = aApprovers.find(user => user.userId === sLoggedInUserId || user.email === sLoggedInUserEmail);
                oApprover.assignedResourceData.roleData = oCurrentApprover.roleDesc && oCurrentApprover.roleId ? {
                        id:oCurrentApprover.roleId,
                        name:oCurrentApprover.roleDesc
                }:{};
            } else {
                //resource page => Non skip resource
                oCurrentApprover = oModel.getProperty("/NominatedResources") ?  oModel.getProperty("/NominatedResources").find(assignment => assignment.userId === sLoggedInUserId || assignment.email === sLoggedInUserEmail):[];
                //update current resource details for CPI Payload
                oApprover.assignedResourceData.roleData = oCurrentApprover.assignedRoleData;
            }
            //update CPI Payload
            oApprover.userId = oCurrentApprover.userId;
            oApprover.assignedResourceData.country = oCurrentApprover.country;
            oApprover.assignedResourceData.address = oCurrentApprover.address;
            oApprover.assignedResourceData.fullName = oCurrentApprover.fullName;
            oApprover.assignedResourceData.email = oCurrentApprover.email;
            oApprover.assignedResourceData.partnerId = oCurrentApprover.partnerId;

            let bISVATmember;
            if (oApprover.assignedResourceData.roleData && oApprover.assignedResourceData.roleData.id) {
                //check current processor or resource part of the team members
                bISVATmember = aOppTeam.some(item =>
                    item.USER_ID === oApprover.userId &&
                    item.ROLE === oApprover.assignedResourceData.roleData.id
                );
            }
            if ((!bISVATmember && aNonVATmembers.length) ||(sStep !== "MANAPP" && !bISVATmember)) {
                //current processor/resource and team members  not part of the VAT Team execute this
                that.getView().getModel().setProperty("/nonVATMember", aNonVATmembers);
                that.getView().getModel().refresh();
                //if approver not in the VAT  add the approver to the VAT
                if (!oApprover.assignedResourceData.partnerId) {
                    //call business partners  if partner id not present
                  
                   let  urlParameters = {
                            filters: [
                                new Filter({
                                    path: "TYPE",
                                    operator: "EQ",
                                    value1: "E"
                                })
                            ],
                            search:  oApprover.userId
                        }
                        //business partner call
                    OpportunityService.getBusinessPartners(urlParameters.search, urlParameters.filters).then((oResponse) => {
                        let oData = oResponse.data.results[0];
                        if (oData) {
                            //update the details
                            oApprover.assignedResourceData.country = oData.COUNTRY;
                            oApprover.assignedResourceData.address = oData.ADDRESS;
                            oApprover.assignedResourceData.fullName = oData.NAME;
                            oApprover.assignedResourceData.email = oCurrentApprover.EMAIL;
                            oApprover.assignedResourceData.partnerId = oData.PARTNER
                        }
                        if (!oApprover.assignedResourceData?.roleData?.id) {
                            //if role not present call role service
                            that._callUserSearchDetailsRole(oApprover, processContext, taskId, sDecision);
                        } else {
                            //update CPI Call
                            Models._updateVATCpi(that, oApprover, processContext, taskId, sDecision);
                        }

                    }).catch((oError) => {
                        //show VAT Exception
                        that._setVATExceptionMsg(processContext, taskId, sDecision, oError);
                        reject(oError)
                    });
                } else if (!oApprover.assignedResourceData?.roleData?.id) {
                    //if role is not present  call harmony service to get the role details
                    that._callUserSearchDetailsRole(oApprover, processContext, taskId, sDecision);
                } else {
                    //Call CPI to update current processor/resource
                    Models._updateVATCpi(that,oApprover,processContext, taskId, sDecision);
                }
            } else {
                //Call Activity and teammeber POST harmony call after the CPI call
                that._callAllActivityRegServices(that, processContext, taskId, sDecision);
            }
        },
           /**
         * 
         * Call user search harmony service to get role details
         * @param {obj} oApprover VAT service payloaf
         * @param {obj} processContext Worklow payload
         * @param {string} taskId Workflow instance id
         * @param {string} sDecision Decision of user task (Approve)
         * @function _callUserSearchDetailsRole
         */
        _callUserSearchDetailsRole: function (oApprover,processContext, taskId, sDecision) {
            let that = this;
            let aFilter = [];
            aFilter.push(new Filter("ID", "EQ", oApprover.userId));
            let oParams = {
                filters: aFilter
            };
            OpportunityService.getServiceToUserSearch(oParams).then((oData) => {
                let oResponse = oData.data.results[0];
                //update VAT payload
                oApprover.assignedResourceData.roleData = {
                    "id": oResponse.CrmRoleId,
                    "name": oResponse.CrmRoleDesc,
                },
                Models._updateVATCpi(that,oApprover,processContext, taskId, sDecision);
            }).catch((error) => {
                //show VAT Exception
                that._setVATExceptionMsg(processContext, taskId, sDecision, error);
            });
        },
       
          /**
         * handle exception message for VAT Team service
         * @function _setVATExceptionMsg
         * @param {obj} processContext Worklow payload
         * @param {string} taskId Workflow instance id
         * @param {string} sDecision Decision of user task (Approve)
         * @param {object} error error call back
         */
        _setVATExceptionMsg: function (processContext, taskId, sDecision,error) {
            this.bIsVATError = true;
            this._setVATExceptionMsgContent();
            this.getView().byId("idTimelineVAT").setGrowing(true);
            this.getView().byId("idTimelineVAT").setGrowingThreshold(1);
            let oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
            if (typeof error === "object" && error !== null && error.status !== 500) {
                //Authorization message
                let sErrorText = error?.responseText ? JSON.parse(error.responseText).error["message"]["value"] : oAppConstantsModel.getProperty("/VATTeamExceptionMsg/0/Value");
                this.getView().getModel().setProperty("/actRegDialog/VATErrorMsg",sErrorText);
            } else {
                //generic exception message
                this.getView().getModel().setProperty("/actRegDialog/VATErrorMsg",oAppConstantsModel.getProperty("/VATTeamExceptionMsg/0/Value"));
            }
             this.oActBusyDialog.setContentWidth("800px");
            this.getView().getModel().setProperty("/actRegDialog/VATText", this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("VATFailed"));
            this.getView().getModel().setProperty("/actRegDialog/VATColorScheme", 2);
            this.getView().getModel().setProperty("/actRegDialog/VATIcon", "sap-icon://error");
            this._fnhandleVATTeamExcepConfirmBtns(processContext, taskId, sDecision);

        },
        /**
         * Set opportunity details for exception
         * @function _setVATExceptionMsgContent
         */
      _setVATExceptionMsgContent: function () {
            const oWfInstanceModel =  this.getOwnerComponent().getModel("wfInstanceModel"),
                i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle(),
                sAccountName = oWfInstanceModel.getProperty("/Account_name"),
                sAccountID = oWfInstanceModel.getProperty("/Account_ID"),
                sOpportunityDesc = oWfInstanceModel.getProperty("/OpportunityDesc"),
                sAccountUrl = this.getOwnerComponent().getModel("appConstants").getProperty("/HarmonyURL/0/Value"),
                sOpportunityID = oWfInstanceModel.getProperty("/OpportunityID"),
                sCurrentState = oWfInstanceModel.getProperty("/CurrentState"),
                sOppUrl = oWfInstanceModel.getProperty("/ExtSystemsUrl"),
                sOppStyle = !sOpportunityDesc ? `style="display:none"` : `style="display:visible"`,
                sTaskDetails = `
			<ul>
			<li>${i18nModel.getText("taskMsgAccountNameID")}:  <a href=${sAccountUrl}/Account/${sAccountID}> ${sAccountName} ${sAccountID}</a></li></li>
			<li ${sOppStyle}>${i18nModel.getText("taskMsgOppDesc")}: ${sOpportunityDesc}</li>
			<li ${sOppStyle}>${i18nModel.getText("taskMsgOppID")}: <a href=${sOppUrl}>${sOpportunityID}</a></li>
			<li>${i18nModel.getText("taskMsgReqStatus")}: ${sCurrentState}</li>
			</ul>`,
                sVATErrorMsg = this.getOwnerComponent().getModel("appConstants").getProperty("/harmonyErrorMsg/0/Value"),
                sHtmlMsg = `${sVATErrorMsg}${sTaskDetails}`
            let oTaskProcessedModel = new JSONModel({
                HTML: sHtmlMsg,
            });
            	this.getView().setModel(oTaskProcessedModel, "VATErrorInfoModel");

        },
          /**
         * VAT Team service exception handling
         * @function _fnhandleVATTeamExcepConfirmBtns
         * @param {obj} processContext Worklow payload
         * @param {string} taskId Workflow instance id
         * @param {string} sDecision Decision of user task (Approve)
         */
        _fnhandleVATTeamExcepConfirmBtns: function (processContext, taskId, sDecision) {
            let that = this;
            this.getView().getModel().setProperty("/actRegDialog/VATTeamExceptionVisible",true);
            this.getView().getModel().refresh();
              const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            if (this.oActBusyDialog) {
                this.oActBusyDialog.removeAllButtons();
                this.oActBusyDialog.addButton(new sap.m.Button({
                    text: that.getOwnerComponent().getModel("appConstants").getProperty("/VATExceptionConfirmBtnText/0/Value"),
                    type: "Emphasized",
                    press: function(){
                        that._fnRegisterActivity(that, processContext, taskId, sDecision)
                    }
                }));
                this.oActBusyDialog.addButton(new sap.m.Button({
                    text:i18nModel.getText("VATExceptionCancelBtnText"),
                    press: function () {
                        that.oActBusyDialog.close();
                        that.oActBusyDialog.removeAllButtons();
                    }
                }));
            }
        },
        onCloseActivityBusyDialog: function () {
            if (this.oActBusyDialog) {
                this.oActBusyDialog.close();
            }
        },
        _getParentContext: function (evt) {
            const oContextPath = evt.getSource().getBindingContext("assignmentsModel").getPath();
            const oParentPath = oContextPath.replace(/\/activities.*/, '');
            this.oContextAssignmentObj = this.getView().getModel("assignmentsModel").getProperty(oParentPath);;
            return this.getView().getModel("assignmentsModel").getProperty(oParentPath);
        },
        onDeleteActivity: function (evt) {
            const oAssignmentObj = evt.getSource().getBindingContext("assignmentsModel").getObject();
            let oParentContext = this._getParentContext(evt);
            const oActivities = oParentContext.activities;
            const filteredArray = oActivities.filter(e => e !== oAssignmentObj);
            if (filteredArray.length === 1) {
                filteredArray[0].activityDelete = false;
            } else {
                filteredArray.forEach(function (val) {
                    val.activityDelete = true;
                });
            }

            const aAllAssignedActivities = this._getParentContext(evt).activities,
                hasActTypeDuplicates = this._activityDuplicatesCheck(filteredArray);
            if (!hasActTypeDuplicates) {
                aAllAssignedActivities.forEach(function (item) {
                    if (item.selectedActivityType) {
                        item.enableRegEdit = true;
                        item.actValueState = "None"

                    }
                    item.actValueState = "None";

                });
            }
            oParentContext.activities = filteredArray;
            this.getView().getModel("assignmentsModel").refresh();

        },
        //value help request of new solution hierarchy changes
        onOpenSolutionHierarchy: async function (oEvent) {
            this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/results",[]);
			const that = this,
				 aSLAMasterData =   this.getOwnerComponent().getModel("SLAMasterDataL1").getData().results;
				 that.getView().setModel(new sap.ui.model.json.JSONModel(), "masterDataModel");
				const oMasterDataModel = that.getView().getModel("masterDataModel");
				if(this.oSLASearchContext){
					this.getView().getModel("employee").setProperty(`/TempEmployee/SolutionAreas`,this.oSLASearchContext)
				}
			if (this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`)) {
				this.oSLASearchContext = JSON.parse(JSON.stringify(this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`)));
			}
            if(this.oSearchAddSlnContext){
                this.getView().getModel("employee").setProperty(`/TempEmployee/AdditionalSolutions`,this.oSearchAddSlnContext)
            }
            if (this.getView().getModel("employee").getProperty(`/TempEmployee/AdditionalSolutions`)) {
				this.oSearchAddSlnContext = JSON.parse(JSON.stringify(this.getView().getModel("employee").getProperty(`/TempEmployee/AdditionalSolutions`)));
			}

				oMasterDataModel.setData(that.getView().getModel("employee"));
				oMasterDataModel.refresh();
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",[]);
			if (!this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas/0`)) {
				//set defualy solution area L1
				//this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/selectedSolAreaL1",aSLAMasterData[0].SolGuid);
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",aSLAMasterData);
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA",false)
			}else if(this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas/0`)){
				//set selected solution area L1
				this.oContextSolutionArea = this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas/0`);
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/selectedSolAreaL1",
				this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas/0/soln_prnt_guid`));
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",this.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`));
				this.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/isSelectedSLA",true)
			}
            that.getView().getModel("employee").setProperty(`/TempEmployee/slaBusy`, false);
				if(that.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`)){
					that.getOwnerComponent().getModel("SLAMasterDataL1").setProperty("/aSelectedSolutionAreas",that.getView().getModel("employee").getProperty(`/TempEmployee/SolutionAreas`));
				}
				
		
			this.getOwnerComponent().getModel("SLAMasterDataL1").refresh();
            this.getView().getModel("employee").refresh();
			// this.getView().getModel("employee").setProperty(`/TempEmployee/slaBusy`,true);

            let oModel=this.getOwnerComponent().getModel("SolutionAreaMasterData")
			if (!this.solutionHierarchyDialogForward) {
				this.solutionHierarchyDialogForward = this.loadFragment({
					name: "com.dealsupport.melodyrequest.fragments.resourceProfile.SolutionHierarchy",
				});	
                		
			}  
           
			// this.solutionHierarchyDialogForward.open()
			this.solutionHierarchyDialogForward.then(function (oDialog) {
                that.SADialog = oDialog;
                oModel.setProperty("/materialsContainerVisible",false);
				that.byId("idSlnTree").getContent()[0].addStyleClass("styleSlnTreeScroll");
                that.byId("idSlnFormGrid").addStyleClass("customStyleSlnSmallGrid");
				that.byId("idSlnFormGrid").removeStyleClass("customStyleSlnGrid");
				that.byId("idSlnTree").setDefaultSpan("XL12 L12 M12 S12");
				that.byId("idSlnToolbarGrid").setDefaultSpan("XL12 L12 M12 S12");
                //change by rk
                
				oDialog.setContentWidth("52%")
                oDialog.open()
                oModel.setProperty("/materials",[])
				oModel.setProperty("/displayTokensMaterial",[])
				oModel.setProperty("/displayTokensAdditionalSolution",[])	
                   let prevSelData = that.getView().getModel("employee").getProperty(`/TempEmployee`)
				let prevSelSolArea = prevSelData.SolutionAreas ? prevSelData.SolutionAreas : []
				
				var solHierarchyMap = oModel.getProperty("/solHierarchyMap")
				if (prevSelSolArea.length > 0) {
					if (prevSelSolArea[0].soln_prnt_guid == '00000000-0000-0000-0000-000000000000') {
						oModel.setProperty("/selectedLevel1Guid", prevSelSolArea[0].soln_guid)
						oModel.setProperty("/showDisplayMaterials", false)
					let mMaterialMap = oModel.getProperty("/materialMap") ? oModel.getProperty("/materialMap"):[];
					mMaterialMap.forEach((arr, key) => {
						arr.forEach(value => {
							value.selected = false
						})
					})
					oModel.setProperty("/materials", [])
					oModel.setProperty("/displayTokensMaterial", [])
					oModel.setProperty("/displayTokensAdditionalSolution", [])
						that.onChangeDisplayFullSolHierarchy(false)
						// var foundL1 = aSolnL1Data.find(item => item.soln_guid == prevSelSolArea[0].soln_guid)
						// models._loadChildren(this, foundL1, null, true)
					

					} else {
                        let aAddSlns = that.getView().getModel("employee").getProperty(`/TempEmployee/AdditionalSolutions`) ?  that.getView().getModel("employee").getProperty(`/TempEmployee/AdditionalSolutions`):[]
						oModel.setProperty("/displayTokensAdditionalSolution", aAddSlns)
						oModel.setProperty("/selectedLevel1Guid", prevSelSolArea[0].soln_prnt_guid)
						oModel.setProperty("/selectedLevel2Id", prevSelSolArea[0].soln_guid)
						oModel.setProperty("/showDisplayMaterials", true)
					let mMaterialMap = oModel.getProperty("/materialMap") ?  oModel.getProperty("/materialMap"):[];
					mMaterialMap.forEach((arr, key) => {
						arr.forEach(value => {
							value.selected = false
						})
					})
					oModel.setProperty("/materials", [])
					oModel.setProperty("/displayTokensMaterial", [])
				
						// var foundL1 = aSolnL1Data.find(item => item.soln_guid == prevSelSolArea[0].soln_prnt_guid)
						// models._loadChildren(this, foundL1, null, true,prevSelSolArea[0].soln_guid)
					let bFillSol = aAddSlns && aAddSlns.length ? true:false;
					if(bFillSol){
						that.SADialog.getContent()[0].getContent()[0].getItems()[0].getItems()[0].setState(true);
					}else{
                        that.SADialog.getContent()[0].getContent()[0].getItems()[0].getItems()[0].setState(false);
                    }
					that.onChangeDisplayFullSolHierarchy(bFillSol)
					}
					

					// if (prevSelAddSol.length > 0 || prevSelMaterial.length > 0) {
					// 	oModel.setProperty("/showDisplayMaterials", true)
					// } else {
					// 	oModel.setProperty("/showDisplayMaterials", false)
					// }
					// if(prevSelAddSol.length>0) 
					// 	models._loadChildren(this,oSelGuid,oEvent,false)
				} else {
					// oModel.setProperty("/selectedLevel1Guid", aSolnL1Data[0].SolGuid)
					oModel.setProperty("/showDisplayMaterials", false)
					let mMaterialMap = oModel.getProperty("/materialMap") ? oModel.getProperty("/materialMap"):[];
					mMaterialMap.forEach((arr, key) => {
						arr.forEach(value => {
							value.selected = false
						})
					})
					oModel.setProperty("/materials", [])
					oModel.setProperty("/displayTokensMaterial", [])
					oModel.setProperty("/displayTokensAdditionalSolution", [])
				oModel.refresh();
                }
                oModel.refresh();
                });
			
				
              
				// oModel.setProperty("/showDisplayMaterials",false)
				// let mMaterialMap=oModel.getProperty("/materialMap") ? oModel.getProperty("/materialMap") :[];
				// mMaterialMap.forEach((arr, key) => {
				// arr.forEach(value => {
				// 	value.selected = false
				// 	})
				// })
				// oModel.setProperty("/materials",[])
				// oModel.setProperty("/displayTokensMaterial",[])
				// oModel.setProperty("/displayTokensAdditionalSolution",[])	
                
             
			
			
		},
        onChangeSLAMasterSelection:function(oEvent){
			let selectedObj = oEvent.getSource().getSelectedItem().getBindingContext("SolutionAreaMasterData").getObject()
			// let sSelectedKey=oEvent.getSource().getSelectedKey()
			const oSolAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData")
			oSolAreaDataModel.setProperty("/selectedLevel2Id", null)
			oSolAreaDataModel.setProperty("/materials", [])
			oSolAreaDataModel.setProperty("/displayTokensMaterial", [])
			oSolAreaDataModel.setProperty("/displayTokensAdditionalSolution", [])
			let mMaterialMap = oSolAreaDataModel.getProperty("/materialMap") ? oSolAreaDataModel.getProperty("/materialMap"):[];
			mMaterialMap.forEach((arr, key) => {
				arr.forEach(value => {
					value.selected = false
				})
			})
			Models._loadChildren(this, selectedObj, oEvent, true)
			Models.getMaterials(this,selectedObj,true);
			const solutionTree = this.byId("idSolutionTree")
			solutionTree.removeSelections();
			solutionTree.collapseAll();
		},
		onExpandHierarchy:function(oEvent){
			const oSelGuid = oEvent.getParameter("itemContext").getObject()
            let bAddSolAreaMaterialState=this.getOwnerComponent().getModel("SolutionAreaMasterData").getProperty("/showDisplayMaterials")
            // if(!bAddSolAreaMaterialState){
            //     let index=oEvent.getParameter("itemIndex")
            //     oEvent.getSource().collapse(index)
            //     sap.m.MessageToast.show("Please enable additional solution hierarchy/materials")
            // }else{
			if(oEvent.getParameter("expanded") &&  !this.bDisableExpandAPICall)
				Models._loadChildren(this,oSelGuid,oEvent,false)                
           // }
		},
        //when L3,L4 is selected in new solution hierarchy
		onSelectSolution:function(oEvent){
        //   this.getOwnerComponent().getModel("SolutionAreaMasterData").getData().selectedLevel1Guid = "";
        //   this.getOwnerComponent().getModel("SolutionAreaMasterData").getData().selectedLevel2Id = "";
        //     this.getOwnerComponent().getModel("SolutionAreaMasterData").refresh();
			let bIsSelected=oEvent.getSource().getSelected()
			let oSelectedRow=oEvent.getSource().getBindingContext('SolutionAreaMasterData').getObject()
			let solutionAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData");
			let mSolHierarchyMap = solutionAreaDataModel.getProperty('/solHierarchyMap');
			let solHierarchy = solutionAreaDataModel.getProperty('/solHierarchy');			
			let currentSelectedL2=solutionAreaDataModel.getProperty("/selectedLevel2Id")
			this.onL3L4Select(oEvent,oSelectedRow,bIsSelected,solutionAreaDataModel)
			Models.getMaterials(this,oSelectedRow,bIsSelected);
          
			
          
		},
		//when L1,L2 radio button is selected in new solution hierarchy
        onSolAreaRadioSelect: function (oEvent) {
            const oSolAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData"),
                aAddSolns = oSolAreaDataModel.getProperty("/displayTokensAdditionalSolution") ? oSolAreaDataModel.getProperty("/displayTokensAdditionalSolution") : [],
                sSelectedLv1Id = oSolAreaDataModel.getProperty("/selectedLevel1Guid"),
                sSelectedLevel2Id = oSolAreaDataModel.getProperty("/selectedLevel2Id");
            if (aAddSolns.length) {
                let sContextSelectedId = oEvent.getSource().getBindingContext("SolutionAreaMasterData").getObject().soln_guid;
                this.prevRadioSelect = (sSelectedLevel2Id === sContextSelectedId) || (sSelectedLv1Id === sContextSelectedId) ? oEvent : this.prevRadioSelect;
                if (!((sSelectedLevel2Id === sContextSelectedId) || (sSelectedLv1Id === sContextSelectedId))) {
                    this.prevRadioSelect.getSource().setSelected(true);
                    oEvent.getSource().setSelected(false);
                    this.newRadioSelect = oEvent;
                }
                if (this.newRadioSelect) {
                  CommonJS._onOpenSolutionSelectConfimDialog(this);

                }
            } else {
                this.onSolAreaRadioSelectConfirm(oEvent)
            }


        },
		//when L1,L2 radio button is selected in new solution hierarchy
        onSolAreaRadioSelectConfirm: function (oEvent) {
               this.getOwnerComponent().getModel("SolutionAreaMasterData").refresh()	
              this.getOwnerComponent().getModel("SolutionAreaMasterData").refresh();
            if (oEvent.getParameter("selected")) {
                let selectedRadioItem = oEvent.getSource().getBindingContext("SolutionAreaMasterData").getObject()
                const oSolAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData")
                let solHierarchy = oSolAreaDataModel.getProperty("/solHierarchy")
                this.clearSASelection(solHierarchy)
                if (selectedRadioItem.LevelId==1) {
                    // let selectedObj = oEvent.getSource().getSelectedItem().getBindingContext("SolutionAreaMasterData").getObject()
                    // let sSelectedKey=oEvent.getSource().getSelectedKey()
                    
                    oSolAreaDataModel.setProperty("/selectedLevel1Guid", selectedRadioItem.soln_guid)
                    oSolAreaDataModel.setProperty("/selectedLevel2Id", null)
                    oSolAreaDataModel.setProperty("/materials", [])
                    oSolAreaDataModel.setProperty("/displayTokensMaterial", [])
                    oSolAreaDataModel.setProperty("/displayTokensAdditionalSolution", [])
                    let mMaterialMap = oSolAreaDataModel.getProperty("/materialMap") ? oSolAreaDataModel.getProperty("/materialMap"):[];
                    mMaterialMap.forEach((arr, key) => {
                        arr.forEach(value => {
                            value.selected = false
                        })
                    })
                    const solutionTree = this.byId("idSolutionTree")
                    solutionTree.removeSelections();
                    // solutionTree.collapseAll();
                    // Models._loadChildren(this, selectedRadioItem, oEvent, true)
                    Models.getMaterials(this, selectedRadioItem, true);
                } else {


                    oSolAreaDataModel.setProperty("/selectedLevel1Guid", selectedRadioItem.soln_prnt_guid)
                    // const oSolAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData");
                    let mMaterialMap = oSolAreaDataModel.getProperty("/materialMap") ? oSolAreaDataModel.getProperty("/materialMap"):[];
                    let materials = oSolAreaDataModel.getProperty("/materials")
                    let displayTokensMaterial = oSolAreaDataModel.getProperty("/displayTokensMaterial")
                    let prevSelectedL2 = oSolAreaDataModel.getProperty("/selectedLevel2Id")
                    // if(prevSelectedL2!=selectedRadioItem.soln_guid){
                    // oSolAreaDataModel.setProperty("/materials",[])
                    // oSolAreaDataModel.setProperty("/displayTokens",[])
                    // }
                    // let solHierarchy = oSolAreaDataModel.getProperty("/solHierarchy")

                    oSolAreaDataModel.setProperty("/selectedLevel2Id", selectedRadioItem.soln_guid)
                    oSolAreaDataModel.setProperty("/displayTokensMaterial", [])
                    oSolAreaDataModel.setProperty("/displayTokensAdditionalSolution", [])
                    oSolAreaDataModel.setProperty("/materials", [])
                    // if(mMaterialMap.get(prevSelectedL2))	
                    // 	mMaterialMap.get(prevSelectedL2).forEach(child=>{child.selected=false})
                    mMaterialMap.forEach((arr, key) => {
                        arr.forEach(value => {
                            // if(value.triggeredBy != selectedRadioItem.soln_prnt_guid)
                            value.selected = false
                        })
                    })
                    // materials = mMaterialMap.get(selectedRadioItem.soln_prnt_guid) ? mMaterialMap.get(selectedRadioItem.soln_prnt_guid) : []
                    // materials = []
                    // displayTokensMaterial = displayTokensMaterial.filter(each => each.triggeredBy == selectedRadioItem.soln_prnt_guid)
                    Models.getMaterials(this, selectedRadioItem, true)

                    // solHierarchy.forEach(function (level2Master) {
                    //     if (level2Master.soln_guid != selectedRadioItem.soln_guid) {
                    //         level2Master.selected = false

                    //         if (level2Master.levels.length && level2Master.levels[0].soln_guid) {
                    //             level2Master.levels.forEach(child => {
                    //                 child.selected = false
                    //                 child.partialSelection = false
                    //                 if (child.levels.length && child.levels[0].soln_guid) {
                    //                     child.levels.forEach(grandChild => {
                    //                         grandChild.selected = false

                    //                     })
                    //                 }
                    //             })
                    //         }
                    //     }
                    // })
                }
                // oSolAreaDataModel.refresh(true)
            }
        },	
       
        //function to implement selection logic of L3,L4 and filtering of selected add sol tokens
		onL3L4Select:function(oEvent,oSelectedRow,bIsSelected,solutionAreaDataModel,bIsConfirm){
			// var oContext=oEvent.getSource().getBindingContext("SolutionAreaMasterData")
			// var sPath=oContext.getPath()
			// var sParentPath=sPath.substring(0,sPath.lastIndexOf("/levels"))
			let solHierarchyMap=solutionAreaDataModel.getProperty("/solHierarchyMap")
			// var oParent=oContext.getModel().getProperty(sParentPath)
			var solHierarchy=solutionAreaDataModel.getProperty("/solHierarchy")
			var mMaterialMap=solutionAreaDataModel.getProperty("/materialMap") ? solutionAreaDataModel.getProperty("/materialMap"):[];
			var materials=solutionAreaDataModel.getProperty("/materials")
			var displayTokensMaterial=[];
			var displayTokensAdditionalSolution=solutionAreaDataModel.getProperty("/displayTokensAdditionalSolution") ? solutionAreaDataModel.getProperty("/displayTokensAdditionalSolution") : [];
			var tokensToBeAdded=[]
			var tokensToBeRemoved=[]
			var materialTokensToBeRem=[]
            let bIsDifferntL2;
            if(oEvent && !bIsConfirm && displayTokensAdditionalSolution && displayTokensAdditionalSolution.length){
                const sSelectedLevel2Id = solutionAreaDataModel.getProperty("/selectedLevel2Id"),
                      oBindingContext = oEvent.getSource().getBindingContext("SolutionAreaMasterData").getObject();
                bIsDifferntL2 = sSelectedLevel2Id && !oBindingContext.full_sol_guid.includes(sSelectedLevel2Id);
                if(bIsDifferntL2){
                    oEvent.getSource().setSelected(false);
                    CommonJS._onOpenSolutionSelectConfimDialog(this,oEvent,oSelectedRow,bIsSelected,solutionAreaDataModel);

                }
            }
            if(!bIsDifferntL2){
                	// var oParent=solHierarchyMap.get(oSelectedRow.soln_prnt_guid)
			let tempParent=solHierarchyMap.get(oSelectedRow.soln_prnt_guid)
            var aGuids=[]
            aGuids.push(oSelectedRow.soln_prnt_guid)
			while(tempParent && tempParent.LevelId!=1){
				tempParent=solHierarchyMap.get(tempParent.soln_prnt_guid)
                aGuids.push(tempParent.soln_guid)
			}
            aGuids.reverse()
           
			// var sL2Path=sParentPath
			// while(sL2Path.includes("/levels")){				
			// 	sL2Path=sL2Path.substring(0,sL2Path.lastIndexOf("/levels"))								
			// }
			// var oL2=oContext.getModel().getProperty(sL2Path)
            var oL1;
			var oL2;
            var oL3;
            let oL4;
			solHierarchy.forEach(sol=>{
				if(sol.soln_guid && sol.soln_guid==aGuids[0]){
					oL1=sol
					sol.levels.forEach(child=>{
						if(child.soln_guid && child.soln_guid==aGuids[1]){
                            oL2=child
							if(child.levels &&  child.levels.length){
                            child.levels.forEach(l3child=>{
                                if(l3child.soln_guid && l3child.soln_guid==aGuids[2]){
                                    oL3=l3child
                                }
                                if(l3child.levels && l3child.levels.length){
                                l3child.levels.forEach(l4child=>{
									if(l4child.soln_guid && l4child.soln_guid==aGuids[3]){
																		oL4=l4child
														}
								});
                            }


                            })
						}
                        }
                        
				})
				}
			})			
			// solHierarchy.forEach(sol=>{
			// 	if(sol.soln_guid==tempParent.soln_guid){
			// 		oL2=sol
			// 		sol.levels.forEach(child=>{
			// 			if(child.soln_guid==oParent.soln_guid)
			// 				oParent=child
			// 	})
			// 	}
			// })			
			// var currentL2guid=solutionAreaDataModel.getProperty("/selectedLevel2Id")
			// if(currentL2guid!=null && currentL2guid!=oL2.soln_guid){
			// 	displayTokens=[]
			// }
			var currentL1=solutionAreaDataModel.getProperty("/selectedLevel1Guid")
			var currentL2=solutionAreaDataModel.getProperty("/selectedLevel2Id")
            // oSolAreaDataModel.setProperty("/selectedLevel2Id", null)
			// oSolAreaDataModel.setProperty("/materials", [])
			// oSolAreaDataModel.setProperty("/displayTokensMaterial", [])
			// oSolAreaDataModel.setProperty("/displayTokensAdditionalSolution", [])
            //checking if the new L3,L4 selection is from a different L1 or not
            if(oL1 && currentL1!=null && currentL1!=oL1.soln_guid){
                materials=[]
                displayTokensMaterial =[]
                displayTokensAdditionalSolution = []
                mMaterialMap.forEach((arr,key)=>{
					arr.forEach(value=>{						
						value.selected = false
					})					
				})
                if(mMaterialMap.get(currentL1))
					materialTokensToBeRem.push(...mMaterialMap.get(currentL1))
                if(mMaterialMap.get(currentL2))
					materialTokensToBeRem.push(...mMaterialMap.get(currentL2))
                oL1.selected=true
                     oL2.selected=true
                // solutionAreaDataModel.setProperty("/selectedLevel1Guid",oL1.soln_guid)
                // solutionAreaDataModel.setProperty("/selectedLevel2Id",oL2.soln_guid)
                
            }
            //checking if the new L3,L4 selection is from a different L2 or not
			else if(currentL2!=null &&oL2&& currentL2!=oL2.soln_guid){
                materials=[]
				// displayTokens=[]
				displayTokensMaterial = displayTokensMaterial.filter(each => each.triggeredBy == oL2.soln_prnt_guid)
				displayTokensAdditionalSolution = displayTokensAdditionalSolution.filter(each => each.triggeredBy == oL2.soln_prnt_guid)
				mMaterialMap.forEach((arr,key)=>{
					arr.forEach(value=>{
						if(value.triggeredBy != oL2.soln_prnt_guid)
							value.selected = false
					})					
				})
				if(mMaterialMap.get(currentL2))
					materialTokensToBeRem.push(...mMaterialMap.get(currentL2))
                oL2.selected=true
                // solutionAreaDataModel.setProperty("/selectedLevel2Id",oL2.soln_guid)
			}
            if(oL1){
            solutionAreaDataModel.setProperty("/selectedLevel1Guid",oL1.soln_guid)
            }
            if(oL2){
                solutionAreaDataModel.setProperty("/selectedLevel2Id",oL2.soln_guid)
            }
         
             solHierarchy.forEach(function (level1Master) {
                // if (level1Master.soln_guid != oL1.soln_guid) {
                //     level1Master.selected = false
                    if (level1Master.levels.length && level1Master.levels[0].soln_guid) {
                        level1Master.levels.forEach(level2Master => {
                            if (level2Master.soln_guid != oL2.soln_guid) {
                            level2Master.selected = false
                            if (level2Master.levels.length && level2Master.levels[0].soln_guid) {
                                level2Master.levels.forEach(level3Master => {
                                    level3Master.selected = false
                                    level3Master.partialSelection = false
                                    if (level3Master.levels.length && level3Master.levels[0].soln_guid) {
                                        level3Master.levels.forEach(level4Master => {
                                            level4Master.selected = false
                                             if(level4Master.levels.length && level4Master.levels[0].soln_guid){
                                                level4Master.levels.forEach(level5Master => {
                                                    level5Master.selected = false;
                                                });
                                             }
                                        })
                                    }


                                })
                            }
                            }
                        })
                }
                
            })
			if(oSelectedRow.LevelId==3){
				oSelectedRow.selected=bIsSelected
				bIsSelected?tokensToBeAdded.push(oSelectedRow):tokensToBeRemoved.push(oSelectedRow)
				oSelectedRow.partialSelection=false                
                oSelectedRow.explicitlySelected=bIsSelected
				// bIsSelected?tokensToBeAdded.push(oSelectedRow):tokensToBeRemoved.push(oSelectedRow)
				// if(oSelectedRow.levels.length && oSelectedRow.levels[0].soln_guid){
				// 	oSelectedRow.levels.forEach(child=>{
				// 		tokensToBeRemoved.push(child)
				// 		child.selected=bIsSelected
				// 		child.partialSelection=false
				// 	})
				// }
			}
			if(oSelectedRow.LevelId==4){
				oSelectedRow.selected=bIsSelected
				bIsSelected ? tokensToBeAdded.push(oSelectedRow) : tokensToBeRemoved.push(oSelectedRow)
				var aL3Level= oL3 ? oL3.levels:[];
				var isSelectedCount=aL3Level.filter(c=>c.selected).length;
                if(oL3){
                    oL3.selected=true
                }
				if(isSelectedCount==0){
                    if(oL3 && !oL3.explicitlySelected){
	                oL3.selected=false
					oL3.partialSelection=false
                    }
    				
                    
				}else if(isSelectedCount==aL3Level.length){
					oL3.selected=true
					oL3.partialSelection=false
				}else{
					// if(!bIsSelected && oParent.selected==true){						
					// 	tokensToBeAdded.push(...oParent.levels)
                        
     //                }					
					// // tokensToBeRemoved.push(oParent)
					// oL3.selected=false
                    if(oL3){
					oL3.partialSelection=true
                    }
                }
			}
            if (oSelectedRow.LevelId == 5) {
                oSelectedRow.selected = bIsSelected;
                bIsSelected ? tokensToBeAdded.push(oSelectedRow) : tokensToBeRemoved.push(oSelectedRow)
                var aL4Level = oL4 ? oL4.levels:[];
                var isSelectedCount = aL4Level.filter(c => c.selected).length;
                if(oL4){
                    oL4.selected = true;
                }
                if(oL3){
                oL3.selected = true;
                }
              
                if (isSelectedCount == 0) {
                    if (oL4) {
                        if(!oL4.explicitlySelected){
                        oL4.selected = false
                        oL4.partialSelection = false
                        }
                    }

                } else if (oL4 && (isSelectedCount == aL4Level.length)) {
                    oL4.selected = true
                    oL4.partialSelection = false
                } else {
                    // if(!bIsSelected && oParent.selected==true){						
                    // 	tokensToBeAdded.push(...oParent.levels)

                    //                }					
                    // // tokensToBeRemoved.push(oParent)
                    if(oL4){
                        oL4.partialSelection = true
                    }
                 
                }
                var aL3Level =oL3  ? oL3.levels:[];
                var isSelectedCount = aL3Level.filter(c => c.selected).length;
                if(oL3){
                oL3.selected = true
                }
                if (isSelectedCount == 0) {
                     if(oL3){
                    if (!oL3.explicitlySelected){
                        oL3.selected = false
                    oL3.partialSelection = false
                    }
                }

                } else if (oL3 && (isSelectedCount == aL3Level.length)) {
                    oL3.selected = true
                    oL3.partialSelection = false
                } else {
                    // if(!bIsSelected && oParent.selected==true){						
                    // 	tokensToBeAdded.push(...oParent.levels)

                    //                }					
                    // // tokensToBeRemoved.push(oParent)
                    // oL3.selected=false
                    if(oL3){
                    oL3.partialSelection = true
                    }
                }
            }
			
			tokensToBeAdded.forEach(token => {
				token.isMaterial ? displayTokensMaterial.push(token) : displayTokensAdditionalSolution.push(token)
				// displayTokens.push(token)
				// if (mMaterialMap.get(token.id))
				// 	materials.push(...mMaterialMap.get(token.id))
			})
			
			
			tokensToBeRemoved.forEach(obj=>{
				if(mMaterialMap.get(obj.id)){
					mMaterialMap.get(obj.id).forEach(child=>{child.selected=false})
					materialTokensToBeRem.push(...mMaterialMap.get(obj.id))
				}
			})
			tokensToBeRemoved.push(...materialTokensToBeRem)
			const idsToBeRemoved = new Set(tokensToBeRemoved.map(item => item.id))
			displayTokensMaterial = displayTokensMaterial.filter(item => !idsToBeRemoved.has(item.id))
			displayTokensAdditionalSolution = displayTokensAdditionalSolution.filter(item => !idsToBeRemoved.has(item.id))
			// materials = materials.filter(item => !idsToBeRemoved.has(item.id))
			
			
			solutionAreaDataModel.setProperty("/displayTokensMaterial",displayTokensMaterial)
			solutionAreaDataModel.setProperty("/displayTokensAdditionalSolution",displayTokensAdditionalSolution)
			solutionAreaDataModel.setProperty("/materials",materials)
			solutionAreaDataModel.setProperty("/materialMap",mMaterialMap)
			solutionAreaDataModel.refresh(true)

            }
		},
        //called when new solution hierarchy dialog is closed
		closeSolutionHierarchy: function () {         
			const oSolAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData")
			let solHierarchy = oSolAreaDataModel.getProperty("/solHierarchy");
			let solHierarchyMap = oSolAreaDataModel.getProperty("/solHierarchyMap");
			let mMaterialMap = oSolAreaDataModel.getProperty("/materialMap") ?  oSolAreaDataModel.getProperty("/materialMap") :[];
			solHierarchy.forEach(item => {
				solHierarchyMap.get(item.soln_guid).levels = []
			})
			mMaterialMap.forEach((arr, key) => {
				arr.forEach(value => {					
					value.selected = false
				})
			})
			
			oSolAreaDataModel.setProperty("/solHierarchyMap",solHierarchyMap)
			oSolAreaDataModel.setProperty("/selectedLevel2Id",null)
			oSolAreaDataModel.setProperty("/selectedLevel1Guid", null)
			oSolAreaDataModel.setProperty("/showDisplayMaterials",false)
			oSolAreaDataModel.setProperty("/materials",[])
			oSolAreaDataModel.setProperty("/displayTokensMaterial",[])
			oSolAreaDataModel.setProperty("/displayTokensAdditionalSolution",[])
			oSolAreaDataModel.refresh(true)
         	const solutionTree = this.byId("idSolutionTree");
          	solutionTree.removeSelections();
          	solutionTree.collapseAll();
          	// this.solutionHierarchyDialogForward.close()
            const that=this
            this.solutionHierarchyDialogForward.then(function (oDialog) {
                   Models.getSolutionAreaMasterData(that)
                oDialog.destroy();
                that.solutionHierarchyDialogForward = false;
                
            });
        },
		//called when "show full hierarchy" checkbox is selected in new solution hierarchy
		onChangeDisplayFullSolHierarchy:function(oEvent){	
               this.getView().byId("idSolutionTree").collapseAll();
                 this.bDisableExpandAPICall = false;
			const solutionAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData");
            	 solutionAreaDataModel.setProperty("/isSolDialogBusy",true)
				   solutionAreaDataModel.refresh();
			let solHierarchy = solutionAreaDataModel.getProperty("/solHierarchy");
			let solHierarchyMap = solutionAreaDataModel.getProperty("/solHierarchyMap");
			let materialMap = solutionAreaDataModel.getProperty("/materialMap") ? solutionAreaDataModel.getProperty("/materialMap"):[];
			let displayTokensMaterial=solutionAreaDataModel.getProperty("/displayTokensMaterial");
			let  materials=solutionAreaDataModel.getProperty("/materials");
			// solutionAreaDataModel.setProperty("/displayTokensAdditionalSolution",[]);
			// solutionAreaDataModel.setProperty("/materials",[]);
			// solutionAreaDataModel.setProperty("/selectedLevel2Id",null)

			// this.clearSASelection(solHierarchy)
			if(typeof(oEvent)=='object')
				var bShowFullSolHierarchy=oEvent.getParameter("state");
			else{
				var bShowFullSolHierarchy=oEvent
			}
				  
            	let that = this;
				   	setTimeout(function() {
			if(!bShowFullSolHierarchy){
				// materials=materials.filter(function(item){
				// 	if(solHierarchyMap.get(item.triggeredBy)){
				// 		return (solHierarchyMap.get(item.triggeredBy).LevelId==3 || solHierarchyMap.get(item.triggeredBy).LevelId==4)
						
				// 	}
				// })
			
				// displayTokensMaterial=displayTokensMaterial.filter(function(item){
				// 	if(solHierarchyMap.get(item.triggeredBy)){
				// 		return (solHierarchyMap.get(item.triggeredBy).LevelId==3 || solHierarchyMap.get(item.triggeredBy).LevelId==4)
						
				// 	}
				// })
				solutionAreaDataModel.setProperty("/displayTokensAdditionalSolution",[]);
                solutionAreaDataModel.setProperty("/displayTokensMaterial",[]);
                solutionAreaDataModel.setProperty("/materialsContainerVisible",false);
				that.byId("idSlnFormGrid").addStyleClass("customStyleSlnSmallGrid");
				//that.byId("idSlnFormGrid").removeStyleClass("customStyleSlnGrid");
				that.byId("idSlnTree").setDefaultSpan("XL12 L12 M12 S12");
				that.byId("idSlnToolbarGrid").setDefaultSpan("XL12 L12 M12 S12");
				that.byId("idSlnTree").getContent()[0].addStyleClass("styleSlnTreeScroll")
				that.SADialog.setContentWidth("52%")
                if(solHierarchyMap){
                     solHierarchyMap.forEach((item,key)=>{
				
				if(item.LevelId==3){
					item.selected=false
				
					item.partialSelection=false
				}else if(item.LevelId==4){
					item.selected=false
				}else if(item.LevelId==5){
                    item.selected=false
                }
			    })
            }
                // materialMap.forEach((item,key)=>{
                //     item.forEach(mat=>{
                //         mat.selected=false
                //     })
                // })
            }else{
				//  //that.SADialog.setContentWidth("900px");
				//  that.byId("idSlnTree").getContent()[0].removeStyleClass("styleSlnTreeScroll")
				//  that.byId("idSlnTree").setDefaultSpan("XL5 L6 M6 S12");
				//  that.byId("idSlnToolbarGrid").setDefaultSpan("XL6 L6 M6 S12");
				//  solutionAreaDataModel.setProperty("/materialsContainerVisible",true);
				//  that.byId("idSlnFormGrid").removeStyleClass("customStyleSlnSmallGrid");
				//  that.byId("idSlnFormGrid").addStyleClass("customStyleSlnGrid");		 
			}
			solHierarchy.forEach(item => {	
                if(item.levels.length && item.levels[0].soln_guid){
                    item.levels.forEach(l2children=>{
                        l2children.levels = bShowFullSolHierarchy ? [{ "soln_name": "Loading..." }] 	:	[]					
                    })	
                }		
			})
			
			// that.byId("idSolutionTree").collapseAll();
             solutionAreaDataModel.setProperty("/isSolDialogBusy",false)
			     solutionAreaDataModel.refresh();
            	},1200);
			
			
		},
		clearSASelection:function(solHierarchy){		
			solHierarchy.forEach(function(obj){
				obj.selected=false
				if(obj.LevelId==3)
					obj.partialSelection=false
				if(obj.levels.length && obj.levels[0].soln_guid){
					this.clearSASelection(obj.levels)
				}
			}.bind(this))
		},		
		onDeleteDisplayTokens:function(oEvent){
			let deletedToken = oEvent.getParameter("removedTokens")[0];
			let deletedObj = deletedToken.getBindingContext("SolutionAreaMasterData").getObject();
			const oSolutionAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData");
			let propName = deletedObj.isMaterial ? '/displayTokensMaterial' : '/displayTokensAdditionalSolution'
			let displayTokens=oSolutionAreaDataModel.getProperty(propName)
			let materials = oSolutionAreaDataModel.getProperty("/materials");
			displayTokens = displayTokens.filter(each => each.id !== deletedObj.id);
			oSolutionAreaDataModel.setProperty(propName, displayTokens);
			if (deletedObj.isMaterial) {
				let material = materials.find(each => each.id === deletedObj.id);
				if(material) 
					material.selected = false;
				oSolutionAreaDataModel.setProperty("/materials", materials)
				oSolutionAreaDataModel.refresh(true)
			}
			else {
				this.onL3L4Select(null,deletedObj,false,oSolutionAreaDataModel)
                Models.getMaterials(this,deletedObj,false)
			}
		},
		onSelectMaterial:function(oEvent){
			 const oSolutionAreaDataModel = this.getOwnerComponent().getModel("SolutionAreaMasterData");
          let displayTokensMaterial = oSolutionAreaDataModel.getProperty("/displayTokensMaterial");
          const isSelected = oEvent.getSource().getSelected();
          const selectedRow = oEvent.getSource().getBindingContext('SolutionAreaMasterData').getObject();
          if (isSelected)
            displayTokensMaterial.push(selectedRow);
          else
            displayTokensMaterial = displayTokensMaterial.filter(each => each.id !== selectedRow.id)
          oSolutionAreaDataModel.setProperty("/displayTokensMaterial", displayTokensMaterial)
		  oSolutionAreaDataModel.refresh(true)
		},
        onOpenSolutionConfirmation:function(){
            let preSelectedSolAreas=this.getView().getModel("employee").getData().TempEmployee.SolutionAreas
            if(preSelectedSolAreas && preSelectedSolAreas.length>0){
                MessageBox.confirm("Opening the dialog box will clear the existing selection. Do You want to continue?",
                    {
                        title:"Confirmation",
                        actions:[sap.m.MessageBox.Action.OK,sap.m.MessageBox.Action.CANCEL],
                        onClose:function(oAction){
                            if(oAction==sap.m.MessageBox.Action.OK){
                                this.onOpenSolutionHierarchy()
                            }
                        }.bind(this)
                    }
                )                
            }else{
                this.onOpenSolutionHierarchy()                
            }
        },
          /**
         *handle busy indicator for material table
		* @function tableChangeHandler
        * @param {boolean} bBusy - update table  growing start(true) and update table finish(false) 
        */
        tableChangeHandler: function (event, bBusy=false) {
            let oSlaMasterModel = this.getOwnerComponent().getModel("SolutionAreaMasterData");
            // if (event.getParameter("reason") === "Growing") {
            //      event.getSource().setBusy(bBusy);
            // } 
        },
        onSearchSlnHierachy: function (evt) {
           CommonJS.onSearchSlnHierachy(evt,this)
        },
        setSolutionArea: function () {
            //check the request has solution area
            const aAdditionalSlnArea = this.getView().getModel().getProperty("/aResourceProfileApprovers/ResourceProfileDetails/AdditionalSolutions") ? this.getView().getModel().getProperty("/aResourceProfileApprovers/ResourceProfileDetails/AdditionalSolutions") : [],
                //if additional solution present set additional solution as activity solutions else set as primary solution
                aActivitySlnFromReq = (aAdditionalSlnArea.length) ? aAdditionalSlnArea : this.getView().getModel().getProperty("/aResourceProfileApprovers/ResourceProfileDetails/SolutionAreas"),
                aOppSolnsHarmony = this.getView().getModel().getProperty("/OPP_SOLN_AREA") ? this.getView().getModel().getProperty("/OPP_SOLN_AREA") : [];

            if (aActivitySlnFromReq && aActivitySlnFromReq.length) {
                if (!aAdditionalSlnArea.length || (aAdditionalSlnArea.length && aAdditionalSlnArea[0].full_sol_id)) {
                    let aFinalSlns = aActivitySlnFromReq.map(obj => {
                        return {
                            full_sol_id: ("full_sol_id" in obj) ? obj.full_sol_id : obj.soln_id ? obj.prnt_soln_id + " > " + obj.soln_id : obj.soln_id,
                            full_sol_name: ("full_sol_name" in obj) ? obj.full_sol_name : obj.SelectedSolutionArea,
                            full_sol_guid: ("full_sol_guid" in obj) ? obj.full_sol_guid: obj.SolAreal2Guid ? obj.soln_prnt_guid + " > " + obj.SolAreal2Guid : obj.soln_prnt_guid,
                        }; // Create a new object with existing properties and the new 'status'
                    });
                    this._setActivitySlnPaylod(aFinalSlns)
                } else if (aAdditionalSlnArea.length) {
                    let aSolnIds = aAdditionalSlnArea.map(obj => obj.soln_id);
                    this._getSolnAreaFullHiearchy(aSolnIds)

                }
            } else if (this.getView().getModel().getProperty("/RequestType") === "Opportunity" && aOppSolnsHarmony.length) {
                const sSolYear =  this.getOwnerComponent().getModel("appConstants").getProperty("/SolYear/0/Value");
                let aOppSolnIds = aOppSolnsHarmony.map(obj => "final_soln_area" in obj ? obj.final_soln_area + sSolYear : "").filter((item, index, self) => {
                    return item && self.indexOf(item) === index;
                });
                this._getSolnAreaFullHiearchy(aOppSolnIds)

            } else {
                this.getView().getModel().setProperty("/solutionAreaPayload", []);
            }
        },
        _getSolnAreaFullHiearchy: function (aSlnIds,oAssignmentModel) {
            const oLSSystemModel = Models.systemLSDataModel(this),
                that = this;
            oLSSystemModel.setUseBatch(true);
            this.aGetSln = [];
            aSlnIds.forEach(function (slnId) {
                oLSSystemModel.read(`/YC_MR_SOL_TO_ROOT(P_SolnId='${slnId}')/Set`, {
                    groupId: "slnId",
                    success: function (oData, oResponse) {
                        if (oResponse.data.results.length) {
                            that.aGetSln.push(oResponse.data.results[0]);
                            if (that.aGetSln.length === aSlnIds.length) {
                                if (that.aGetSln.length) {
                                    let aFinalSlns = that.aGetSln.map(obj => {
                                        return {
                                            full_sol_id: obj.id_path,
                                            full_sol_name: obj.soln_path,
                                            full_sol_guid:obj.path
                                        }; // Create a new object with new property
                                    });
                                    that._setActivitySlnPaylod(aFinalSlns,oAssignmentModel);
                                    that.aGetSln = [];
                                } else {
                                    that.getView().getModel().setProperty("/solutionAreaPayload", []);
                                }

                            }
                        } else {
                            that.getView().getModel().setProperty("/solutionAreaPayload", []);
                        }
                        if(oAssignmentModel){
                              that._callActivityTypeMasterData(that.oContextAssignmentObj);
                        }
                           sap.ui.core.BusyIndicator.hide();
                    },
                    error: function (oError) {
                        that.aGetSln.push(oError);
                        that.aGetSln = [];
                           sap.ui.core.BusyIndicator.hide();
                        return fnError(oError, oController)
                    }
                })
            });
         

            // Submit all in one batch
            oLSSystemModel.submitChanges();

        },
        _setActivitySlnPaylod: function (input, oAssignmentModel) {
            let aFinalActivitySln = [];
            input.map(item => {
                const idParts = item.full_sol_id.split(" > ");
                const nameParts = item.full_sol_name.split(" > ");
                const guidParts = item.full_sol_guid.split(" > ");
                if( idParts.length > 4){
                      idParts.length = 4;
                    nameParts.length = 4;
                    guidParts.length = 4;
                }
              
                const result = {
                    LevelCount: idParts.length + 1, // LevelCount is number of parts in guid + 1
                };

                // Dynamically create properties based on the level count
                for (let i = 0; i < idParts.length; i++) {
                    result[`L${i + 2}Id`] = idParts[i];
                    result[`L${i + 2}Desc`] = nameParts[i];
                    result[`guid`] = guidParts[guidParts.length-1];
                }
                aFinalActivitySln.push(result);

            });
          //  this.getView().getModel().setProperty("/solutionAreaPayload", aFinalActivitySln);
           

              const oLSSystemModel = Models.systemLSDataModel(this),
                that = this;
            oLSSystemModel.setUseBatch(true);
            this.aGetSlnGuid = [];
            aFinalActivitySln.forEach(function (item) {
                 let sUrlParams = {
                    $filter: `project_type eq 'ACTVT' and soln_guid eq (guid'${item.guid}')`,
                    $expand:"to_Child"
                };
                oLSSystemModel.read(`/YC_MR_M_SOL_HIERARCHY`,{
                    groupId: "slnGuid",
                    urlParameters:sUrlParams,
                    success: function (oData, oResponse) {
                        if (oResponse.data.results.length) {
                            that.aGetSlnGuid.push(oResponse.data.results[0]);
                            oResponse.data.results[0].to_Child
                            if (that.aGetSlnGuid.length === aFinalActivitySln.length) {
                                aFinalActivitySln.forEach(function(sln){
                                    const aFilteredGuid = that.aGetSlnGuid.filter(item=> item.soln_guid === sln.guid);
                                    if(aFilteredGuid.length){
                                        let aChild = aFilteredGuid[0].to_Child.results;
                                        sln.Levels = aChild.map(obj => {
                                            return { ...obj, LevelId: obj.soln_id,
                                                LevelDesc:obj.soln_name
                                            }; // Create a new object with existing properties and the new 'status'
                                        });
                                        sln.LevelDesc = aFilteredGuid[0].soln_name;
                                        sln.LevelId = aFilteredGuid[0].soln_id;
                                    }
                                });
                                aFinalActivitySln = aFinalActivitySln.filter((obj, index, self) =>
                                    index === self.findIndex((o) => o.guid === obj.guid)
                                );
                
                                that.getView().getModel().setProperty("/solutionAreaPayload", aFinalActivitySln);
                            }
                        } else {
                            that.getView().getModel().setProperty("/solutionAreaPayload", []);
                        }
                    },
                    error: function (oError) {
                        that.aGetSln.push(oError);
                        that.aGetSln = [];
                        return fnError(oError, oController)
                    }
                })
            });
              oLSSystemModel.submitChanges();
               if(oAssignmentModel){
                this._callActivityTypeMasterData(this.oContextAssignmentObj);
                oAssignmentModel.refresh(true);
                this.oNomineeValueHelpControl.setBusy(false);
                sap.ui.core.BusyIndicator.hide();
            }
         
        },
        //recent changes rk--
        handleDetaillOpenInfoPress: function (oEvent) {
			let sRiskId = oEvent.getSource().getBindingContext("assignmentsModel").getObject().activityPaylod.RiskAssessId;
			this.getView().setModel(new JSONModel({
					"RiskAssessId":sRiskId
			}),"default");
			if (!this.detailRiskInfoPopup) {
				this.detailRiskInfoPopup = sap.ui.xmlfragment(this.getView().getId(),
					"com.dealsupport.melodyrequest.fragments.riskInfo", this);
				this.getView().addDependent(this.detailRiskInfoPopup);
			}
			this.detailRiskInfoPopup.openBy(oEvent.getSource());
		},

		handleDetailRiskInfoOkPress: function () {
			this.detailRiskInfoPopup.close();
		},
        _setActivityTemData: function () {
            const oLSSystemModel = Models.systemLSDataModel(this),
                that = this;
            oLSSystemModel.setUseBatch(true);
            this.aGetSln = [];
            aSlnIds.forEach(function (slnId) {
                oLSSystemModel.read(`/YC_MR_SOL_TO_ROOT(P_SolnId='${slnId}')/Set`, {
                    groupId: "slnId",
                    success: function (oData, oResponse) {
                        if (oResponse.data.results.length) {
                            that.aGetSln.push(oResponse.data.results[0]);
                            if (that.aGetSln.length === aSlnIds.length) {
                                if (that.aGetSln.length) {
                                    let aFinalSlns = that.aGetSln.map(obj => {
                                        return {
                                            full_sol_id: obj.id_path,
                                            full_sol_name: obj.soln_path,
                                            full_sol_guid: obj.path
                                        }; // Create a new object with new property
                                    });
                                    that._setActivitySlnPaylod(aFinalSlns, oAssignmentModel);
                                    that.aGetSln = [];
                                } else {
                                    that.getView().getModel().setProperty("/solutionAreaPayload", []);
                                }

                            }
                        } else {
                            that.getView().getModel().setProperty("/solutionAreaPayload", []);
                        }
                    },
                    error: function (oError) {
                        that.aGetSln.push(oError);
                        that.aGetSln = [];
                        return fnError(oError, oController)
                    }
                })
            });
            // Submit all in one batch
            oLSSystemModel.submitChanges();

        },
        _fnMapActivityPayload: function (self) {
             const oInstanceModel = this.getView().getModel("wfInstanceModel");
              let aAssignmentsData = this.getView().getModel("assignmentsModel").getData().assignments,
                sOppStatus = "",
                sOppStatusId ="",
                aAllActivities = [];
               sap.ui.core.BusyIndicator.show();
                if (this.getView().getModel().getProperty("/opportunityId")) {
                     sOppStatus = formatter.getOppState(this.getView().getModel().getProperty("/dealInfo/STATUS")) ? formatter.getOppState(this.getView().getModel().getProperty("/dealInfo/STATUS")) : "";
                     sOppStatusId = this.getView().getModel().getProperty("/dealInfo/STATUS") ? this.getView().getModel().getProperty("/dealInfo/STATUS") : "";
                    }
            aAssignmentsData.forEach(function (data) {
                const newProperty = 'assignmentId';
                const newValue = data.AssignmentID;
                const aFinalActivities = data.activities.map(item => {
                    return { ...item, [newProperty]: newValue }; // Using spread syntax to create a new object
                });
                aAllActivities = aAllActivities.concat(aFinalActivities)
            })
            let aFinalActivities = aAllActivities.map(obj => {
                return obj.activityPaylod
            }).filter(item=>item.assignmentID);
           const sOppNumber = this.getView().getModel().getProperty("/opportunityId") ? this.getView().getModel().getProperty("/opportunityId") : "";
           let aFinalPayload  = aFinalActivities.map(obj => ({
                "AssignmentID":obj.assignmentID.toString(),
                "INSTANCE_GUID": oInstanceModel.getProperty("/InstanceID"),
                "ACTIVITY_GUID": ("ActivityGuid" in obj) ? obj.ActivityGuid : "",
                "ACTIVITY_LEAD": ("ActivityLead" in obj) ? obj.ActivityLead : "",
                "ACT_LEAD_MAIL_ID": ("ActivityLeadEmailId" in obj) ? obj.ActivityLeadEmailId : "",
                "Act_LEAD_NAME":("ActivityLeadName" in obj) ? obj.ActivityLeadName : "",
                "ACTTYPEID": ("ActivityTypeId" in obj) ? obj.ActivityTypeId : "",
                "ASSTD_ID": ("ActvtAsstdID" in obj) ? obj.ActvtAsstdID : "",
                "REQUESTOR":("Requestor" in obj) ? obj.Requestor : "",
                "PFCG_ROLEMPNG_ID": ("RoleMpngID" in obj) ? obj.RoleMpngID : "",
                "OPPORTUNITYNO": sOppNumber,
                "STARTAT":("StartDate" in obj) ? obj.StartDate : "",
                "CREATEDAT": ("CreateDate" in obj) ? obj.CreateDate : "",
                "ENDAT":("EndDate" in obj) ? obj.EndDate : "",
                "ACCOUNT_EXECUTIVE":("AccountExecutive" in obj) ? obj.AccountExecutive : "",
                "ACC_EXEC_MAIL_ID":("AccountExecutiveEmailId" in obj) ? obj.AccountExecutiveEmailId : "",
                "ACTIVITY_SUPPORT":("ActivitySupport" in obj) ? obj.ActivitySupport : "",
                "EXTERNAL_FLAG":("external_flag" in obj) ? obj.external_flag ? "X" :"" : "",
                "ARCHIVED":("external_flag" in obj) ? obj.Archived ? "X":"" : "",
                "METHODID":("MethodId" in obj) ? obj.MethodId : "",
                "STATUS":("Status" in obj) ? obj.Status : "",
                "ACTVT_STATUS":("ActvtStatus" in obj) ? obj.ActvtStatus : "",
                "ACTVT_NAME":("ActvtName" in obj) ? obj.ActvtName : "",
                "ACTVT_CNTRY":("CntryName" in obj) ? obj.CntryName : "",
                "IMPACT_ID":("ImpactID" in obj) ? obj.ImpactID : "",
                "DEALTYPE":("DealType" in obj) ? obj.DealType : "",
                "MEETING_INVITEES":("MeetingInvitees" in obj) ? obj.MeetingInvitees : "",
                "DESCRIPTION":("Description" in obj) ? obj.Description : "",
                "RA_ID":("RiskAssessId" in obj) ? obj.RiskAssessId : "",
                "RA_COMMENT":("RiskComment" in obj) ? obj.RiskComment : "",
                "MAIN_SOLUTION_ID":("MainSolutionId" in obj) ? obj.MainSolutionId : "",
                "GLOBAL_ULTIMATE_ID": ("GlobalUltimateID" in obj) ? obj.GlobalUltimateID : "",
                "DC_ID":("DcId" in obj) ? obj.DcId : "",
                "SURVEY_RECPT":("SurveyRecpt" in obj) ? obj.SurveyRecpt : "",
                "REQUESTED_DELIVERY":("RequestedDelivery" in obj) ? obj.RequestedDelivery : null,
                "DRY_RUN":("DryRunDate" in obj) ? obj.DryRunDate ? obj.DryRunDate :null : null,
                "DISCOVERY_COMPLT":("DiscoveryCompleted" in obj) ? obj.DiscoveryCompleted : "",
                "REGION":("ActvtRegion" in obj) ? obj.ActvtRegion : "",
                "SCP_ACCOUNT":("SCPAccount" in obj) ? obj.SCPAccount : "",
                "POTENTIAL_CLOSE_DATE":("PotentialCloseDate" in obj) ? obj.PotentialCloseDate? obj.PotentialCloseDate:null : null,
                "TARGET_VALUE":("TargetValue" in obj) ? obj.TargetValue : "",
                "REQ_MGR_ID":("RequestorManagerID" in obj) ? obj.RequestorManagerID : "",
                "TOP_DEAL_FLAG":("TopDealFlag" in obj) ? obj.TopDealFlag : "",
                "EXISTING_CLIENT":("ExistingClient" in obj) ? obj.ExistingClient : "",
                "STATUS_CHANGED_AT":("StatusChangedAt" in obj) ? obj.StatusChangedAt ? obj.StatusChangedAt:null : null,
                "LASTCHANGEDAT":("LastChangedAt" in obj) ? obj.LastChangedAt ? obj.LastChangedAt:null : null,
                "ActTeam":  ("to_ATeam" in obj) ? obj.to_ATeam.map(function (oTeamObj) {
                    return {
                        "USERID":oTeamObj.ID,
                        "ROLE": oTeamObj.ROLE,
                        "EMAIL": oTeamObj.EMAIL,
                        "NAME":  oTeamObj.NAME
                    };
                            }): [],
                "LSCAPE": ("to_ALand" in obj) ? obj.to_ALand.map(function (oLsCapeObj) {
                    return {
                        "LANDSID":oLsCapeObj.LandsId
                    };
                }) : [],
                "Initiative": ("to_AInitiative" in obj) ? obj.to_AInitiative.map(function (oInitvIdObj) {
                    return {
                         "INITIATIVE_ID": Number(oInitvIdObj.InitiativeId)
                         };
                })  : [],
                "AddOpp": ("to_AAddOpp" in obj) ? obj.to_AAddOpp.map(function (oAddOppObj) {
                    return {
                         "OPPORTUNITYNO": oAddOppObj.OpportunityNo
                    };
                }) : [],
                "Material": ("to_AMaterial" in obj) ? obj.to_AMaterial.map(function (oMatObj) {
                    return {
                         "MAT_ID": oMatObj.MatId,
                         "SOL_YEAR": oMatObj.SolYear
                    };
                }) : [],
                "Taxonomy":("to_ATaxonomy" in obj) ? obj.to_ATaxonomy.map(function (oSlnObj) {
                    return {
                        "SOLN_ID_L2": oSlnObj.L2Id ?  oSlnObj.L2Id:"",
                        "SOLN_ID_L3": oSlnObj.L3Id ?  oSlnObj.L3Id:"",
                        "SOLN_ID_L4": oSlnObj.L4Id ?  oSlnObj.L4Id:"",
                        "SOLN_ID_L5": oSlnObj.L5Id ?  oSlnObj.L5Id:"",
                        "SOLN_ID_L6": oSlnObj.L6Id ?  oSlnObj.L6Id:"",
                        "SOLN_ID_L7": oSlnObj.L7Id ?  oSlnObj.L7Id:"",
                        "SOLN_ID_L8": oSlnObj.L7Id ?  oSlnObj.L8Id:""
                    };
                })  : [],
                "ActvtExt": [
                    {
                        "CVJ_PHASE_ID":("CvjPhaseId" in obj) ? obj.CvjPhaseId :"",
                        "OPP_STATUS_ID": sOppStatusId,
                        "OPP_STATUS_DESC": sOppStatus
                    }
                ],
                "to_AFiles":("to_AFiles" in obj) ? obj.to_AFiles.map(function (oLinkObj) {
                    return {
                        "FILE_NAME": oLinkObj.FileName,
                        "URL": oLinkObj.Url,
                        "PROJECT_TYPE": oLinkObj.ProjectType
                    };
                })  : [],
                

            }));

            function fnStoreTempActivity(items) {
                return new Promise((resolve) => {
                    self.activityPostResData = Array.isArray( self.activityPostResData) && self.activityPostResData.length ? self.activityPostResData:[];
                    let aDuplicateAssignment = self.activityPostResData.filter(actvt=> (actvt.ACTTYPEID === items.ACTTYPEID)  && (actvt.AssignmentID === items.AssignmentID) && (actvt.INSTANCE_GUID === items.INSTANCE_GUID))
                    if(!aDuplicateAssignment.length){
                           oResponse = Models._callActivityTempDataService(self, items, "POST")
                    }
                  
                    resolve(oResponse);
                }).then(function () {
                }.bind(self));
            }
              let aOnRegActivityAllPromises = [];
            aFinalPayload.forEach(function (items) {
                aOnRegActivityAllPromises.push(fnStoreTempActivity(items));
            })
            Promise.all(aOnRegActivityAllPromises)
                .then(function () {
                       sap.ui.core.BusyIndicator.hide();
                   self._triggerComplete(self.oAssignments, self.sUserTaskId,
                        "Approve");
                }.bind(self))
                .then(data => {
                    // 'data' will be an array of the parsed JSON data from each service call

                })
                .catch(error => {
                    // One or more promises rejected
                    console.error('Error in one of the service calls:', error);
                });

        },    
        onDisplayActLeadInfo: function (oEvent) {
           CommonJS.onDisplayActLeadInfo(oEvent, this)
        },
        onTeamDetailPressed: function (oEvent) {
            CommonJS.onTeamDetailPressed(oEvent, this)
        },
        handleSendMailClick: function (oEvent) {
            CommonJS.handleSendMailClick(oEvent, this)
        },
        handleCallClick: function (evt) {
           CommonJS.handleCallClick(evt, this)
        },
        //Function to view list of team members in pop-up
        viewDetails: function (oEvent) {
            CommonJS.viewDetails(oEvent, this)
        },
        /**
            *@function onSubRoleChange
            *@description event handler for change event of Role Combobox #GIT 342            
            * @param {object} oEvent -Event object of handler
        */
        onSubRoleChange: function (oEvent) {
            const oSource = oEvent.getSource();
            const oModel = this.getView().getModel("employee");
            const oSelectectedItem = oSource.getSelectedItem();
            if (oSelectectedItem) {
                const oContext = oSelectectedItem.getBindingContext("subRole");
                const oSubRoleModel = oContext.getModel();
                const oRole = oSubRoleModel.getProperty(oContext.getPath());

                // oTempEmployee.Roles.push(oRole)
                // tempRoleArea.push(...oRole.RoleAreas);
                oRole.active = true;
                
                this.getView().getModel("employee").setProperty("/TempEmployee/TempRoles/SelectedSubRole", oRole);
                // this.getView().getModel("employee").setProperty("/TempEmployee/TempRoles/SelectedRoleDesc", oRole.RoleDesc)
                oModel.setProperty("/SelectedSubRoleKey", oRole.RoleID);
            } else {
                oModel.setProperty("/SelectedSubRoleKey", "");
                if (this.getView().getModel("employee").getProperty("/TempEmployee/TempRoles")) {
                    // this.getView().getModel("employee").setProperty("/TempEmployee/TempRoles/SelectedRoleDesc", this.getView().getModel("employee").getProperty("/TempEmployee/TempRoles/RolesData").map(obj=>{return obj.RoleDesc}).join(", "))
                    this.getView().getModel("employee").setProperty("/TempEmployee/TempRoles/SelectedSubRole", { "active": false });
                }
            }
            oModel.refresh(true);
        },
          /**
            *@function onManager1Change
            *@description Manager filter input live changes            
            *
        */
        onManager1Change: function () {
            this.getFilterSummaryText();
        },
       /**
            *@function onRolePrimaryChange
            *@description Role filter input live changes            
            *
        */
        onRolePrimaryChange: function () {
            this.getFilterSummaryText();
        },
         /**
            *@function onSelectGroupFilter
            *@description Select group filter event  
            * @param {object}  oEvent - Context of the checkbox      
        */
        onSelectGroupFilter: function (oEvent) {
            const oModel = this.getView().getModel("employee");
            const oSource = oEvent.getSource();
            const bSelected = oEvent.getParameter("selected");
            const sSelectedGuid = oSource.data("displayguid");

            const oBindingContext = oSource.getBindingContext("grpHierarchyForFilter");
            const oGrpLeadHierarchyTreeModel = oBindingContext.getModel();
            const sPath = oBindingContext.getPath();
            const oGroup = oGrpLeadHierarchyTreeModel.getProperty(sPath);
            oGroup.nodes = this.selectIfGroupExists(oGroup.nodes, [], 0, true);

            const oTempEmployee = oModel.getProperty("/filter");
            let aTempGroupFilters = oTempEmployee.TempGroupFilters;

            aTempGroupFilters = aTempGroupFilters.filter(item => !item.SelectedGuid.includes(
                sSelectedGuid));

            const iIndex = aTempGroupFilters.findIndex(item => item.SelectedGuid === oGroup.displayguid);

            if (bSelected) {
                if (iIndex === -1) {
                    let oGrpObj = {
                        GroupClstrGuid: oGroup.GrpClstrGuid,
                        GrpClstrDesc: oGroup.GrpClstrDesc,
                        Groupl1Guid: oGroup.GroupL1Guid,
                        GrpL1Desc: oGroup.GroupL1Desc,
                        Groupl2Guid: oGroup.GroupL2Guid,
                        GrpL2Desc: oGroup.GroupL2Desc,
                        Groupl3Guid: oGroup.GroupL3Guid,
                        GrpL3Desc: oGroup.GroupL3Desc,
                        Groupl4Guid: oGroup.GroupL4Guid,
                        GrpL4Desc: oGroup.GroupL4Desc,
                        Groupl5Guid: oGroup.GroupL5Guid,
                        GrpL5Desc: oGroup.GroupL5Desc
                    };
                   
                  
                    aTempGroupFilters.push( this.setGrpData(oGrpObj));
                }

                const guids = sSelectedGuid.split(",");
                let aSelectedGuids = JSON.parse(JSON.stringify(guids));
                aSelectedGuids.pop();
                for (let i = guids.length - 2; i >= 0; i--) {
                    let iParentIndex = aTempGroupFilters.findIndex(item => item.SelectedGuid === aSelectedGuids.join(","));
                    if (iParentIndex !== -1) {
                        aTempGroupFilters.splice(iParentIndex, 1);
                    }
                    aSelectedGuids.pop();
                }
            } else {
                if (iIndex !== -1) {
                    aTempGroupFilters.splice(iIndex, 1);
                }
            }

            oModel.setProperty("/filter/TempGroupFilters", aTempGroupFilters);
            oModel.refresh(true);
            oGrpLeadHierarchyTreeModel.refresh(true);
            this.setGroupFilterHierarchySelection();
        },
          /**
            *@function setGroupFilterHierarchySelection
            *@description Update group hierachy selection
        */
        setGroupFilterHierarchySelection: function () {
            const oModel = this.getView().getModel("employee");
            const oTempEmployee = oModel.getProperty("/filter");

            const aTempGroupFilters = oTempEmployee.TempGroupFilters;
            const oGroupLeadHierarchyModel = this.getOwnerComponent().getModel("grpHierarchyForFilter");
            let aGroupLeadHierarchies = oGroupLeadHierarchyModel.getData();

            aGroupLeadHierarchies = this.selectIfGroupExists(aGroupLeadHierarchies, [], 0, true);
            const aGroupLeads = [];
            let aFilterGroups = {
                groupL1: [],
                groupL2: [],
                groupL3: [],
                groupL4: [],
                groupL5: []
            };
            for (let i = 0; i < aTempGroupFilters.length; i++) {
                const aGuids = aTempGroupFilters[i].SelectedGuid.split(",");

                // if (initLoad) {
                let group = {};
                group.GroupClstrGuid = aTempGroupFilters[i].GroupClstrGuid;
                group.GrpClstrDesc = aTempGroupFilters[i].GrpClstrDesc;

                for (let j = 1; j <= 5; j++) {
                    group["Groupl" + j + "Guid"] = aTempGroupFilters[i]["Groupl" + j + "Guid"];
                    group["GrpL" + j + "Desc"] = aTempGroupFilters[i]["GrpL" + j + "Desc"];
                }

                const oGroup = this.setGrpData(group);
                aGroupLeads.push(oGroup);
                aFilterGroups.groupL1.push(oGroup.Groupl1Guid);
                aFilterGroups.groupL2.push(oGroup.Groupl2Guid);
                aFilterGroups.groupL3.push(oGroup.Groupl3Guid);
                aFilterGroups.groupL4.push(oGroup.Groupl4Guid);
                aFilterGroups.groupL5.push(oGroup.Groupl5Guid);
                // }

                aGroupLeadHierarchies = this.selectIfGroupExists(aGroupLeadHierarchies, aGuids, 0);

            }

           // oTempEmployee.Group.SelectedKeys = aGroupLeads;
            oTempEmployee.filterGroup = aFilterGroups;
            oTempEmployee.dialogselGroup = aGroupLeads;
            oTempEmployee.dialogselGroupVisible = !!aGroupLeads.length 

            oModel.refresh(true);
            oGroupLeadHierarchyModel.refresh(true);
            this.getFilterSummaryText();
        },
		   /**
            *@function onConfirmGroup
            *@description Final Group selection       
        */
      onConfirmGroup: function () {
            const oModel = this.getView().getModel("employee");
            if(oModel.getProperty("/isFilter")){
                const oTempEmployee = oModel.getProperty("/filter");
                const aSelectedGrps = jQuery.extend(true, [], oTempEmployee.dialogselGroup);
                this.getView().getModel("employee").setProperty("/filter/Group/SelectedKeys", JSON.parse(JSON.stringify(aSelectedGrps)));
                this.getView().getModel("employee").refresh();
                this.pFilterGrpDialog.close();
                this.getFilterSummaryText();
            } else {
                const oModel = this.getView().getModel("masterDataModel");
                const aSelectedGroup = oModel.getProperty("/TempEmployee/TempGroup");
                const oEmployeeModel = this.getView().getModel("employee");
                if (aSelectedGroup.length) {

                    oEmployeeModel.setProperty(`/TempEmployee/SelectedGroup`, JSON.parse(JSON.stringify([
                        {
                            "GroupID": aSelectedGroup[0].id ? aSelectedGroup[0].id : aSelectedGroup[0].GroupID,
                            "GroupDesc": aSelectedGroup[0].desc ? aSelectedGroup[0].desc : aSelectedGroup[0].GroupDesc,
                            "SelectedGroup": aSelectedGroup[0].desc ? aSelectedGroup[0].desc : aSelectedGroup[0].GroupDesc,
                            "SelectedGroupHierarchy": aSelectedGroup[0].display ? aSelectedGroup[0].display : aSelectedGroup[0].SelectedGroupHierarchy,
                            "LevelId": aSelectedGroup[0].LevelId,
                            "display":aSelectedGroup[0].display ? aSelectedGroup[0].display : aSelectedGroup[0].SelectedGroupHierarchy,
                            "id":aSelectedGroup[0].id
                        }])));
                    this.getOwnerComponent().getModel("grpHierarchyForFilter").setProperty("/selectedGrpID", aSelectedGroup[0].id ? aSelectedGroup[0].id : aSelectedGroup[0].GroupID)
                }
                oEmployeeModel.refresh(true);
                this._setSearchFieldText();
                const that=this;
                this._pFilterGroup.then(function (oDialog) {
                    if(oModel.getProperty("/isFilter")){
                        oDialog.close();
                    }else{
                        oDialog.destroy();
                        that._pFilterGroup=false;
                    }
                });
            }
        },
         /**
            *@function getGroupClusterText
            *@description Get group cluster text
            * @param {string}  sValue - Group id     
        */
         getGroupClusterText: function (sValue) {
			if (!sValue || sValue === "00000000-0000-0000-0000-000000000000") {
				return "";
			}
			const oGrpClusterModel = this.getOwnerComponent().getModel("grpCluster");
			const aGroupCluster = oGrpClusterModel.getData();
			sValue = aGroupCluster.find(item => item.GrpClstrGuid === sValue);
			if (sValue) {
				return sValue.GrpClstrDesc;
			}
            return
		},
         /**
            *@function setGrpData
            *@description Set Group data
            * @param {object}  oData - Group response    
        */
        setGrpData: function (oData) {
            this.GroupClstrGuid = (oData && oData.GroupClstrGuid) ? oData.GroupClstrGuid : "00000000-0000-0000-0000-000000000000";
            this.GrpClstrDesc = (oData && oData.GrpClstrDesc) ? oData.GrpClstrDesc : "";

            this.Groupl1Guid = (oData && oData.Groupl1Guid) ? oData.Groupl1Guid : "00000000-0000-0000-0000-000000000000";
            this.GrpL1Desc = (oData && oData.GrpL1Desc) ? oData.GrpL1Desc : "";

            this.Groupl2Guid = (oData && oData.Groupl2Guid) ? oData.Groupl2Guid : "00000000-0000-0000-0000-000000000000";
            this.GrpL2Desc = (oData && oData.GrpL2Desc) ? oData.GrpL2Desc : "";

            this.Groupl3Guid = (oData && oData.Groupl3Guid) ? oData.Groupl3Guid : "00000000-0000-0000-0000-000000000000";
            this.GrpL3Desc = (oData && oData.GrpL3Desc) ? oData.GrpL3Desc : "";

            this.Groupl4Guid = (oData && oData.Groupl4Guid) ? oData.Groupl4Guid : "00000000-0000-0000-0000-000000000000";
            this.GrpL4Desc = (oData && oData.GrpL4Desc) ? oData.GrpL4Desc : "";

            this.Groupl5Guid = (oData && oData.Groupl5Guid) ? oData.Groupl5Guid : "00000000-0000-0000-0000-000000000000";
            this.GrpL5Desc = (oData && oData.GrpL5Desc) ? oData.GrpL5Desc : "";

            let sSelectedGuid = "";
            let sSelectedDesc = "";
            let sGroupGuidAndDesc = "";
            if (this.GroupClstrGuid && parseInt(this.GroupClstrGuid, 10) !== 0) {
                sSelectedGuid += this.GroupClstrGuid;
                sSelectedDesc += this.GrpClstrDesc;
                sGroupGuidAndDesc += this.GroupClstrGuid + "|" + this.GrpClstrDesc;
                if (this.Groupl1Guid && parseInt(this.Groupl1Guid, 10) !== 0) {
                    sSelectedGuid += "," + this.Groupl1Guid;
                    sSelectedDesc += " > " + this.GrpL1Desc;
                    sGroupGuidAndDesc += this.Groupl1Guid + "|" + this.GrpL1Desc;

                    if (this.Groupl2Guid && parseInt(this.Groupl2Guid, 10) !== 0) {
                        sSelectedGuid += "," + this.Groupl2Guid;
                        sSelectedDesc += " > " + this.GrpL2Desc;
                        sGroupGuidAndDesc += this.Groupl2Guid + "|" + this.GrpL2Desc;

                        if (this.Groupl3Guid && parseInt(this.Groupl3Guid, 10) !== 0) {
                            sSelectedGuid += "," + this.Groupl3Guid;
                            sSelectedDesc += " > " + this.GrpL3Desc;
                            sGroupGuidAndDesc += this.Groupl3Guid + "|" + this.GrpL3Desc;

                            if (this.Groupl4Guid && parseInt(this.Groupl4Guid, 10) !== 0) {
                                sSelectedGuid += "," + this.Groupl4Guid;
                                sSelectedDesc += " > " + this.GrpL4Desc;
                                sGroupGuidAndDesc += this.Groupl4Guid + "|" + this.GrpL4Desc;

                                if (this.Groupl5Guid && parseInt(this.Groupl5Guid, 10) !== 0) {
                                    sSelectedGuid += "," + this.Groupl5Guid;
                                    sSelectedDesc += " > " + this.GrpL5Desc;
                                    sGroupGuidAndDesc += this.Groupl5Guid + "|" + this.GrpL5Desc;
                                }
                            }
                        }
                    }
                }
            }

            this.SelectedGuid = sSelectedGuid;
            this.SelectedDesc = sSelectedDesc;
            this.GroupGuidAndDesc = sGroupGuidAndDesc;
            return {
                GroupClstrGuid:this.GroupClstrGuid,
                GrpClstrDesc:this.GrpClstrDesc,
                Groupl1Guid: this.Groupl1Guid,
                GrpL1Desc: this.GrpL1Desc,
                Groupl2Guid: this.Groupl2Guid,
                GrpL2Desc: this.GrpL2Desc,
                Groupl3Guid: this.Groupl3Guid,
                GrpL3Desc: this.GrpL3Desc,
                Groupl4Guid: this.Groupl4Guid,
                GrpL4Desc: this.GrpL4Desc,
                Groupl5Guid: this.Groupl5Guid,
                GrpL5Desc: this.GrpL5Desc,
                SelectedGuid:sSelectedGuid,
                SelectedDesc:sSelectedDesc,
                GroupGuidAndDesc:sGroupGuidAndDesc
            };
        },
         /**
            *@function setSolutionData
            *@description Set Solution area data
            * @param {object}  oData - Solution area response    
        */
        setSolutionData: function (oData) {
            this.Guid = (oData && oData.Guid) ? oData.Guid : "00000000-0000-0000-0000-000000000000";
            this.Desc = (oData && oData.Desc) ? oData.Desc : "";
            this.LevelId = (oData && oData.LevelId) ? oData.LevelId : "";
            this.IsMaterial = (oData && oData.IsMaterial) ? true : false;
            this.IsPrimary = (oData && oData.IsPrimary) ? true : false;
            this.IsPrimCatalyst = (oData && oData.IsPrimCatalyst) ? true : false;
            this.IsNonFocused = (oData && oData.IsNonFocused) ? true : false;
            this.sol_year = (oData && oData.sol_year) ? oData.sol_year : "";
            this.soln_guid = (oData && oData.soln_guid) ? oData.soln_guid : "00000000-0000-0000-0000-000000000000";
            this.SolutionAreaGuid = (oData && oData.SolutionAreaGuid) ? oData.SolutionAreaGuid : "00000000-0000-0000-0000-000000000000";
            this.SolAreal1Guid = (oData && oData.SolAreal1Guid) ? oData.SolAreal1Guid : "00000000-0000-0000-0000-000000000000";
            this.SolAreal1Desc = (oData && oData.SolAreal1Desc) ? oData.SolAreal1Desc : "";

            this.SolAreal2Guid = (oData && oData.SolAreal2Guid) ? oData.SolAreal2Guid : "00000000-0000-0000-0000-000000000000";
            this.SolAreal2Desc = (oData && oData.SolAreal2Desc) ? oData.SolAreal2Desc : "";

            this.SolAreal3Guid = (oData && oData.SolAreal3Guid) ? oData.SolAreal3Guid : "00000000-0000-0000-0000-000000000000";
            this.SolAreal3Desc = (oData && oData.SolAreal3Desc) ? oData.SolAreal3Desc : "";

            this.SolAreal4Guid = (oData && oData.SolAreal4Guid) ? oData.SolAreal4Guid : "00000000-0000-0000-0000-000000000000";
            this.SolAreal4Desc = (oData && oData.SolAreal4Desc) ? oData.SolAreal4Desc : "";

            // LPR
            this.SolAreal5Guid = (oData && oData.SolAreal5Guid) ? oData.SolAreal5Guid : "00000000-0000-0000-0000-000000000000";
            this.SolAreal5Desc = (oData && oData.SolAreal5Desc) ? oData.SolAreal5Desc : "";
            // Materials
            this.SolAreal6Guid = (oData && oData.SolAreal6Guid) ? oData.SolAreal6Guid : "00000000-0000-0000-0000-000000000000";
            this.SolAreal6Desc = (oData && oData.SolAreal6Desc) ? oData.SolAreal6Desc : "";

            let sSelectedGuid = "";
            let sSelectedDesc = "";
            let sGroupGuidAndDesc = "";
            // if(this.GroupClstrGuid && parseInt(this.GroupClstrGuid, 10) !== 0) {
            // 		sSelectedGuid += this.GroupClstrGuid;
            // 		sSelectedDesc += this.GrpClstrDesc;
            // 		sGroupGuidAndDesc += this.GroupClstrGuid + "|" + this.GrpClstrDesc;
            if (this.SolAreal1Guid && parseInt(this.SolAreal1Guid, 10) !== 0) {
                sSelectedGuid += this.SolAreal1Guid;
                sSelectedDesc += this.SolAreal1Desc;
                sGroupGuidAndDesc += this.SolAreal1Guid + "|" + this.SolAreal1Desc;

                if (this.SolAreal2Guid && parseInt(this.SolAreal2Guid, 10) !== 0) {
                    sSelectedGuid += "," + this.SolAreal2Guid;
                    sSelectedDesc += " > " + this.SolAreal2Desc;
                    sGroupGuidAndDesc += this.SolAreal2Guid + "|" + this.SolAreal2Desc;

                    if (this.SolAreal3Guid && parseInt(this.SolAreal3Guid, 10) !== 0) {
                        sSelectedGuid += "," + this.SolAreal3Guid;
                        sSelectedDesc += " > " + this.SolAreal3Desc;
                        sGroupGuidAndDesc += this.SolAreal3Guid + "|" + this.SolAreal3Desc;

                        if (this.SolAreal4Guid && parseInt(this.SolAreal4Guid, 10) !== 0) {
                            sSelectedGuid += "," + this.SolAreal4Guid;
                            sSelectedDesc += " > " + this.SolAreal4Desc;
                            sGroupGuidAndDesc += this.SolAreal4Guid + "|" + this.SolAreal4Desc;

                            if (this.SolAreal5Guid && parseInt(this.SolAreal5Guid, 10) !== 0) {
                                sSelectedGuid += "," + this.SolAreal5Guid;
                                sSelectedDesc += " > " + this.SolAreal5Desc;
                                sGroupGuidAndDesc += this.SolAreal5Guid + "|" + this.SolAreal5Desc;

                                if (this.SolAreal6Guid && parseInt(this.SolAreal6Guid, 10) !== 0) {
                                    sSelectedGuid += "," + this.SolAreal6Guid;
                                    sSelectedDesc += " > " + this.SolAreal6Desc;
                                    sGroupGuidAndDesc += this.SolAreal6Guid + "|" + this.SolAreal6Desc;
                                }
                            }
                        }
                    }
                }
            }
            // }

            this.SelectedGuid = sSelectedGuid;
            this.SelectedDesc = sSelectedDesc;
            this.GroupGuidAndDesc = sGroupGuidAndDesc;
            return {
					Desc: oData.Desc,
                    SelectedDesc:sSelectedDesc,
                    SelectedGuid:sSelectedGuid,
					Guid: oData.Guid,
					LevelId: oData.LevelId,
					IsMaterial: false,
					IsPrimary: oData.IsPrimary,
					IsPrimCatalyst: oData.IsPrimCatalyst,
					IsNonFocused: oData.IsNonFocused,
					soln_guid: oData.Guid,
					SolAreal1Guid: oData.SolAreal1Guid,
					SolAreal1Desc: oData.SolAreal1Desc,
					SolAreal2Guid: oData.SolAreal2Guid,
					SolAreal2Desc: oData.SolAreal2Desc,
					SolAreal3Guid: oData.SolAreal3Guid,
					SolAreal3Desc: oData.SolAreal3Desc,
					SolAreal4Guid: oData.SolAreal4Guid,
					SolAreal4Desc: oData.SolAreal4Desc,
					SolAreal5Guid: oData.SolAreal5Guid,
					SolAreal5Desc: oData.SolAreal5Desc,
					SolAreal6Guid: oData.SolAreal6Guid, //material Id
					SolAreal6Desc: oData.SolAreal6Desc, // Material name
				}
        },
        selectIfGroupExists: function (groups, guids, index, forceReset) {
            if (!groups || groups.length === 0) {
                return [];
            }

            for (let j = 0; j < groups.length; j++) {
                const group = groups[j];
                if (!forceReset) {
                    if (group.guid === guids[index]) {
                        group.selectedLead = true;
                        if (group.nodes && group.nodes.length > 0) {
                            group.nodes = this.selectIfGroupExists(group.nodes, guids, index + 1);
                        }
                    }
                } else {
                    group.selectedLead = false;
                    group.nodes = this.selectIfGroupExists(group.nodes, guids, index + 1, true);
                }
                groups[j] = group;
            }
            return groups;
        },
        onEmpDetailsSortDialog: function () {
            if (!this._oEmpSortDialog) {
                Fragment.load({
                    name: "com.dealsupport.melodyrequest.fragments.managerPage.EmpDetailsSortingDialog",
                    controller: this
                }).then(function (oDialog) {
                    this._oEmpSortDialog = oDialog;
                    // this._oEmpSortDialog.setModel(this.getView().getModel());
                    this.getView().addDependent(this._oEmpSortDialog);
                    this._oEmpSortDialog.open();
                }.bind(this));
            } else {
                this._oEmpSortDialog.open();
            }
        },
        handleEmpDetSortConfirm: function (oEvent) {
            sap.ui.core.BusyIndicator.show();
            const oSortItem = oEvent.getParameter("sortItem");
            const sortDescending = oEvent.getParameter("sortDescending");
            const sSelectedTab = this.getView().getModel("employee").getProperty("/filter/selectedTab");
            this.SortBy = oSortItem.getKey();
            this.SortBy = (this.SortBy === "Id" || this.SortBy === "ResourceId") && sSelectedTab !== 'customerAdvisory' ? 'ResourceId' : this.SortBy;
            this.SortOrder = "asc";
            if (sortDescending) {
                this.SortOrder = "desc";
            }
            this.onSearchOreRecords();
        },
        	onOpenFilterGroup: function () {
            CommonJS.valueHelpRequestGroup(this,true);
		},
        onOpenGroupValueHelpDialog:function(oEvent){
            CommonJS.valueHelpRequestGroup(this, false, oEvent, false);
        },
        fnSelectGroupFilterCluster: function (tableModelName) {
            const oGrpClsterModel = this.getOwnerComponent().getModel(tableModelName);
            const aGrpClstData = oGrpClsterModel.getData();
            const oModel = this.getView().getModel("employee");
            const oTempEmployee = oModel.getProperty("/filter");
            let oSelectedCluster = [];
            let grpData = [];
            for (let i = 0; i < aGrpClstData.length; i++) {
                // if (aGrpClstData[i].selectedLead === true) {
                oSelectedCluster.push(aGrpClstData[i].guid);
                grpData.push(aGrpClstData[i]);
                // }
            }
            oGrpClsterModel.setData(grpData);

            oModel.refresh(true);
            const aGroupCluster = this.getOwnerComponent().getModel("grpCluster").getProperty("/");
            if (oSelectedCluster.length === aGroupCluster.length) {
                oTempEmployee.selectedGroupFilterClst = "00000000-0000-0000-0000-000000000000";
            } else if (oSelectedCluster.length === 0) {
                oTempEmployee.selectedGroupFilterClst = "00000000-0000-0000-0000-000000000000";
                //this.fnSelectionChangeClusters(tableModelName, oTempEmployee.selectedGroupFilterClst);
            } else {
                oTempEmployee.selectedGroupFilterClst = oSelectedCluster.toLocaleString();
            }
            oModel.refresh(true);

        },
        fnSelectionChangeClusters: function (tableModelName, selectedCluster) {

            const oGrpWithoutClsterModel = this.getOwnerComponent().getModel("groupWithoutCluster");
            const aGrpWithoutClst = oGrpWithoutClsterModel.getProperty("/");
            let filteredGroups = [];
            if (selectedCluster) {
                let oSelectedCluster = selectedCluster;
                const aGroupCluster = this.getOwnerComponent().getModel("grpCluster").getProperty("/");
                if (oSelectedCluster === "00000000-0000-0000-0000-000000000000") {
                    let clstArray = [];
                    for (let j = 0; j < aGroupCluster.length; j++) {
                        clstArray.push(aGroupCluster[j].GrpClstrGuid);
                    }
                    oSelectedCluster = clstArray;
                } else {
                    oSelectedCluster = Array(oSelectedCluster)
                }

                for (let i = 0; i < oSelectedCluster.length; i++) {
                    let tempFilteredGroups = aGrpWithoutClst.filter((item) => {
                        return item.cluster === oSelectedCluster[i];
                    });

                    tempFilteredGroups = JSON.parse(JSON.stringify(tempFilteredGroups));

                    const filteredCluster = aGroupCluster.filter((item) => {
                        return item.GrpClstrGuid === oSelectedCluster[i];
                    });
                    filteredGroups.push({
                        guid: oSelectedCluster[i],
                        id: filteredCluster[0].GrpClstrId,
                        desc: filteredCluster[0].GrpClstrDesc,
                        cluster: oSelectedCluster[i],
                        parent: null,
                        displayguid: filteredCluster[0].GrpClstrGuid,
                        display: filteredCluster[0].GrpClstrDesc,
                        GroupGuidAndId: filteredCluster[0].GrpClstrGuid + "|" + filteredCluster[0].GrpClstrId,
                        GroupGuidAndDesc: filteredCluster[0].GrpClstrGuid + "|" + filteredCluster[0].GrpClstrDesc,
                        editableLead: false,
                        selectedLead: false,
                        nodes: tempFilteredGroups,
                        GrpClstrGuid: filteredCluster[0].GrpClstrGuid,
                        GrpClstrDesc: filteredCluster[0].GrpClstrDesc,
                        partiallySelected: false
                    });
                }

            }
            if (filteredGroups) {
                if (['grpHierarchyTree'].includes(tableModelName)) {
                    const oLoginUserData = this.getModel("user").getData();
                    var aAvailableGroups = [];
                    if (oLoginUserData.AccessProfFlag.toUpperCase() === "AD") {
                        aAvailableGroups = filteredGroups;
                    } else {
                        filteredGroups.forEach(i => oLoginUserData.to_dataowner.forEach(d => d.GroupClstrGuid === i.guid && !aAvailableGroups.map(a => a
                            .guid).includes(d.GroupClstrGuid) && aAvailableGroups.push(i)));

                        aAvailableGroups = this.filterGroupHTree(aAvailableGroups, oLoginUserData, 1, 5);
                    }
                    this.getModel(tableModelName).setData(JSON.parse(JSON.stringify(aAvailableGroups)));
                    this.getModel(tableModelName).refresh(true);
                } else {
                    this.getModel(tableModelName).setData(JSON.parse(JSON.stringify(filteredGroups)));
                    this.getModel(tableModelName).refresh(true);
                }
            }
        },
        /*Update business area industries*/
        onConfirmIndFilter: function (oEvent) {
            const oModel = this.getView().getModel("employee");
            const aEmployeeBAIndustries = oModel.getProperty("/TempEmployee/TempBAIndustries");
            oModel.setProperty("/TempEmployee/BAIndustries", JSON.parse(JSON.stringify(aEmployeeBAIndustries)));
            this.onCloseBAIndustryValueHelpDialog();
            oModel.refresh();
            this.getFilterSummaryText();
        },
        sortColumns: function () {
            const oMrAppConfigModel = this.getOwnerComponent().getModel("mrrAppConfigModel");
            const sortColumns = [{
                key: "Id",
                text: oMrAppConfigModel.getProperty("/ClmEmployeeID/0/fieldDesc"),
                selected: false
            }, 
            {
                key: "CapEmpNme",
                text:oMrAppConfigModel.getProperty("/ClmEmployeeName/0/fieldDesc"),
                selected: true
            }, 
            {
                text: oMrAppConfigModel.getProperty("/ClmManagerNameID/0/fieldDesc"),
                key: "MgrL1NameId",
                selected: false
            }, {
                text:oMrAppConfigModel.getProperty("/ClmManagerLevel/0/fieldDesc"),
                key: "ManagerLevel",
                selected: false
            }, {
                text:oMrAppConfigModel.getProperty("/ClmProfitCenterPrimary/0/fieldDesc"),
                key: "TrpcDesc",
                selected: false
            },
            {
                text: oMrAppConfigModel.getProperty("/ClmRolePrimary/0/fieldDesc"),
                key: "RoleDesc",
                selected: false
            }, {
                text: oMrAppConfigModel.getProperty("/ClmIndustryPrimary/0/fieldDesc"),
                key: "BaIndDesc",
                selected: false
            }, {
                text: oMrAppConfigModel.getProperty("/ClmIACPrimary/0/fieldDesc"),
                key: "IacDesc",
                selected: false
            }, {
                text: oMrAppConfigModel.getProperty("/ClmSolutionAreaPrimary/0/fieldDesc"),
                key: "SolnHierarchy",
                selected: false
            },
            {
                text: oMrAppConfigModel.getProperty("/ClmGroup/0/fieldDesc"),
                key: "GrpHierarchy",
                selected: false
            }];
            return sortColumns;
        },
        onEmpPersonalizationDialog: function () {
            //open table column settings dialog
            if (!this.pSettingsalueDialog) {
                this.pSettingsValueDialog = this.loadFragment({
                    name: "com.dealsupport.melodyrequest.fragments.tableSettingDialog"
                });
            }
            this.pSettingsValueDialog.then(function (oSettingsValueDialog) {
                oSettingsValueDialog.open();
                this._settingsModelData = JSON.parse(JSON.stringify(this.getView().getModel("colModel").getData()));
                this._oSettingsValueDialog = oSettingsValueDialog;
            }.bind(this));

        },
        /**
      *
      * trigger event when table setting dialog colModel updates
      * disable check box selection for request subId and Req status
      * @function onListUpdateFinished
      */
        onListUpdateFinished: function () {
            const aItems = this._oSettingsValueDialog.getContent()[0].getItems();
            aItems.forEach(item => {
                const id = item.getBindingContext("colModel").getObject().id
                item.removeStyleClass("disableCheckbox");
                // if (id.includes("idRequestSubId") || id.includes("idCurrentState")) {
                //     item.addStyleClass("disableCheckbox");
                // }
            });
        },
        /**
   *
   * close the table setting dialog
   * @function onCancelColumns
   */
        onCancelColumns: function () {
            this._oSettingsValueDialog.close();
            this.getView().getModel("colModel").setData(this._settingsModelData);
            this.getView().getModel("colModel").refresh()
        },
        /**
   *
   * search event for table setting dialog
   * @param {oEvent} search control event
   * @function onColumnSearch
   */
        onColumnSearch: function (oEvent) {
            var sQuery = oEvent.getParameter("newValue");
            var oList = this._oSettingsValueDialog.getContent()[0];
            var oBinding = oList.getBinding("items");

            if (!sQuery) {
                oBinding.filter([]);
            } else {
                var oFilter = new Filter("text", FilterOperator.Contains, sQuery);
                oBinding.filter([oFilter]);
            }
        },
        onSearchGroupFilter: function (oEvent) {
            const query = oEvent ? oEvent.getSource().getValue().trim() : "";
            const TableId = this.byId("grpFilterHierarchyTableId");
            if (TableId) {
                TableId.getBinding("items").filter(query ? new Filter({
                    path: "desc",
                    operator: "Contains",
                    value1: query
                }) : null);
                TableId.expandToLevel(query ? 99 : 0);
            }
        },
        onDeleteIndDialogToken: function (oEvent) {
            if (oEvent.getParameter("type") === "removed") {
                let aRemovedTokens = oEvent.getParameter("removedTokens");
                let oModel = this.getView().getModel("masterDataModel");
                let aSelected = oModel.getProperty("/BAIndustries");
                let aSelectedTokens = oModel.getProperty("/TempEmployee/TempBAIndustries");
                let that = this;

                aRemovedTokens.forEach(function (oToken) {
                    let sKey = oToken.getKey();
                    let isNonFocused = oToken.getBindingContext("masterDataModel").getObject().IsNonFocused;
                    if(isNonFocused){ 
                        that.onChangeNonIndustryFocused(); 
                    }

                    aSelected.forEach(function (item) {
                        if (item.Guid === sKey) {
                            item.IsSelected = false; // update your selected flag
                        }
                    });
                      aSelectedTokens.forEach(function (item) {
                        if (item.Guid === sKey) {
                              item.IsDel = true; // update your selected flag
                        }
                    });
                });
                aSelectedTokens = aSelectedTokens.filter(item => !item.IsDel);
                oModel.setProperty("/BAIndustries", aSelected);
                oModel.setProperty("/TempEmployee/TempBAIndustries", aSelectedTokens);
                oModel.refresh();
            }

        },
        onCloseProfitCenterDialog: function () {
            this.getView().getModel("selectedProfitCenter").setProperty("/TempProfitCenter/TempTreeTerritories", this.getView().getModel("masterDataModel").getProperty("/TempProfitCenter/Territories"));
            this.getView().getModel("selectedProfitCenter").setProperty("/TempProfitCenter/Territories", this.getView().getModel("masterDataModel").getProperty("/TempProfitCenter/Territories"));
            this.getView().getModel("selectedProfitCenter").refresh();
            this.pProfitCenterValueHelpDialog.then(function (oDialog) {
                oDialog.close();

            });
        },
        onDeleteDialogProfitCenterToken: function (oEvent) {
            if (oEvent.getParameter("type") === "removed") {
                let aRemovedTokens = oEvent.getParameter("removedTokens");
                let aProfitCenterMasterData = this.getView().getModel("treeTerritories").getProperty("/territories");
                let aSelectedProfitCenter = this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/TempTreeTerritories")
                let that = this;
                aRemovedTokens.forEach(function (oToken) {
                    let deletedTokenGuid = oToken.getKey();
                    aSelectedProfitCenter.forEach(function (item) {
                        if (item.guid === deletedTokenGuid) {
                            item.IsDel = true; // update your selected flag
                        }
                    });
                    that._handleDeleteToken(aProfitCenterMasterData, deletedTokenGuid);

                });
                aSelectedProfitCenter = aSelectedProfitCenter.filter(item => !item.IsDel);
                this.getView().getModel("selectedProfitCenter").setProperty("/TempProfitCenter/TempTreeTerritories", aSelectedProfitCenter);
                this.getView().getModel("selectedProfitCenter").refresh();

                this.getView().getModel("treeTerritories").setProperty("/territories", aProfitCenterMasterData);
                this.getView().getModel("treeTerritories").setProperty("/leadTerritories", aProfitCenterMasterData);
                this.getView().getModel("treeTerritories").refresh();
            }

        },
        onDeleteProfitCenterToken: function (oEvent) {
            if (oEvent.getParameter("type") === "removed") {
                let aRemovedTokens = oEvent.getParameter("removedTokens");
                let oModel = this.getView().getModel("selectedProfitCenter");
                let aSelected = oModel.getProperty("/TempProfitCenter/TempTreeTerritories");

                aRemovedTokens.forEach(function (oToken) {
                    let sKey = oToken.getKey();

                    aSelected.forEach(function (item) {
                        if (item.SelectedGuid === sKey) {
                            item.IsDel = true; // update your selected flag
                        }
                    });
                });
                 aSelected = aSelected.filter(item => !item.IsDel);

                oModel.setProperty("/TempProfitCenter/TempTreeTerritories", aSelected);
                oModel.setProperty("/TempProfitCenter/Territories", aSelected);
                oModel.refresh();
                this.getFilterSummaryText();
            }
        },
        onDeleteGroupToken: function (oEvent) {
            if (oEvent.getParameter("type") === "removed") {
                let aRemovedTokens = oEvent.getParameter("removedTokens");
                let oModel = this.getView().getModel("employee");
                let aSelected = oModel.getProperty("/filter/Group/SelectedKeys");

                aRemovedTokens.forEach(function (oToken) {
                    let sKey = oToken.getKey();

                    aSelected.forEach(function (item) {
                        if (item.SelectedGuid === sKey) {
                            item.IsDel = true; // update your selected flag
                        }
                    });
                });
                aSelected = aSelected.filter(item => !item.IsDel);

                oModel.setProperty("/filter/Group/SelectedKeys", aSelected);
                oModel.setProperty("/filter/TempGroupFilters", aSelected);
                oModel.refresh();
                this.getFilterSummaryText();
            }

        },
      
        onDeleteDialogGroup: function (oEvent) {
            let oTempGrpFilters = this.getView().getModel("employee").getProperty("/filter/TempGroupFilters");
            if (oEvent.getParameter("type") === "removed") {
                let aRemovedTokens = oEvent.getParameter("removedTokens");
                aRemovedTokens.forEach(function (oToken) {
                    let deletedTokenGuid = oToken.getKey();
                    oTempGrpFilters.forEach(function (item) {
                        if (item.SelectedGuid === deletedTokenGuid) {
                            item.IsDel = true; // update your selected flag
                        }
                    });

                });
                oTempGrpFilters = oTempGrpFilters.filter(item => !item.IsDel);
                this.getView().getModel("employee").setProperty("/filter/TempGroupFilters", oTempGrpFilters);
                this.setGroupFilterHierarchySelection();
                this.getView().getModel("employee").refresh();
            }

        },
        _handleDeleteToken: function (nodes, tokenGuid,type) {
            let that = this;
            function removeSelectionFromSubtree(node) {
                 node.selectedLead = false;
                 node.IsSelected = false;
                if (node.nodes?.length) {
                    node.nodes.forEach(child => removeSelectionFromSubtree(child));
                }
            }
            for (const node of nodes) {
                // if token node found
                if (node.guid === tokenGuid) {
                    removeSelectionFromSubtree(node);
                    return true; // stop traversal once done
                }
                // search inside children
                if (node.nodes?.length) {
                    const found = that._handleDeleteToken(node.nodes, tokenGuid);
                    if (found) return true;
                }
            }
            return false;
        },
      oncloseGroupDialog:function(){
            const oEmployeeModel = this.getView().getModel("employee");
            if(!oEmployeeModel.getProperty("/isFilter")){
                const oModel = this.getView().getModel("masterDataModel");   
                const aSelectedGroup = oEmployeeModel.getProperty(`/TempEmployee/SelectedGroup`);
                oModel.setProperty("/TempEmployee/TempGroup",JSON.parse(JSON.stringify(aSelectedGroup)));
                this.getOwnerComponent().getModel("grpHierarchyForFilter").setProperty("/selectedGrpID", aSelectedGroup?.[0]?.id ? aSelectedGroup[0].id : "")
            }
            const that=this;
            this._pFilterGroup.then(function (oDialog) { 
                if(oEmployeeModel.getProperty("/isFilter")){
                    oDialog.close();
                }else{
                    oDialog.destroy();
                    that._pFilterGroup=false;
                }
            });
                
        },
        // SOlution area
        onOpenSolutionAreaValueHelpDialog: function () {
            const oModel = this.getView().getModel("employee");
            const aSolutionAreas = oModel.getProperty("/filter/TempEmployee/SolutionAreas");
            aSolutionAreas.length ? oModel.setProperty("/filter/dialogselSlnVisible", true) : oModel.setProperty("/filter/dialogselSlnVisible", false);
            oModel.setProperty("/NonSolutionAreapFocused", {
                Guid: "",
                IsSelected: false,
                IsVisible: true
            });
            const that = this;
            if (!this.pSolutionAreaDialog) {
                this.pSolutionAreaDialog = this.loadFragment({
                    name: "com.dealsupport.melodyrequest.fragments.filter.SolutionAreaValueHelpDialog"
                });
            }
            this.pSolutionAreaDialog.then(function (oDialog) {
                oModel.setProperty("/filter/TempEmployee/TempSolutionArea",oModel.getProperty("/filter/TempEmployee/SolutionAreas"));
                let bSelected = aSolutionAreas && aSolutionAreas.length && aSolutionAreas[0].IsNonFocused ? true:false;

                that.filterSolutionAreas();
                oDialog.open();
                that.onChangeNonSolAreaFocused(bSelected);
            });

        },
        filterSolutionAreas: function (initLoad, isRoleChanged = false) {
            const oModel = this.getView().getModel("employee");
            const oSolutionModel = this.getOwnerComponent().getModel("solutionAreaFilterMasterData");
            const aMasterSolutionArea = oSolutionModel.getProperty("/solutionareas") || [];
            const oTempEmployee = oModel.getProperty("/filter/TempEmployee");

            const that = this;
            let aSolutionAreas = $.extend(true, [], oSolutionModel.getData().solutionareas);
            let aEmployeeSolutionAreas = $.extend(true, [], oModel.getProperty("/filter/TempEmployee/SolutionAreas"));
            oModel.setProperty("/filter/NonSolutionAreaFocused", {
                Guid: "",
                IsSelected: false,
                IsVisible: false
            });
            aSolutionAreas.map(function (element) {
                const oEmployeeSolutionArea = aEmployeeSolutionAreas.find(item => item.SolAreal1Guid === element.Guid);
                if (oEmployeeSolutionArea) {
                    aEmployeeSolutionAreas.IsMaterial = false;
                    element.IsSelected = true;
                    element.IsPrimary = (oEmployeeSolutionArea.Guid === element.Guid && oEmployeeSolutionArea.IsPrimary) ? true : false;
                    element.IsEnabled = (oEmployeeSolutionArea.Guid === element.Guid) ? true : false;
                } else {
                    element.IsSelected = true;
                    element.IsPrimary = false;
                    element.IsEnabled = false;
                }
                if (aEmployeeSolutionAreas.IsNonFocused) {
                    oModel.setProperty("/filter/NonSolutionAreaFocused", {
                        Guid: element.Guid,
                        IsSelected: false,
                        IsVisible: true
                    });
                    if ((!aEmployeeSolutionAreas.length) || (aEmployeeSolutionAreas && aEmployeeSolutionAreas.Guid ===
                        element.Guid)) {

                        let oSln = that.setSolutionData({
                            Guid: element.Guid,
                            Desc: element.Desc,
                            IsPrimary: true,
                            IsNonFocused: true,
                            IsMaterial: false,
                            SolAreal1Guid: element.Guid,
                            SolAreal1Desc: element.Desc,
                        })
                        aEmployeeSolutionAreas = [oSln];
                        oModel.setProperty("/filter/NonSolutionAreaFocused", {
                            Guid: element.Guid,
                            IsSelected: true,
                            IsVisible: true
                        });
                    }
                }
                const oSolution = aMasterSolutionArea.find(item => item.Guid === element.Guid);
                if (oSolution) {
                    element.Levels = [];
                    element.Levels.push(...oSolution.Levels);
                }
            });
            oModel.setProperty("/TempEmployee/SolutionAreas", $.extend(true, [], aEmployeeSolutionAreas));
            const aSolutionArea = [];
            for (let i = 0; i < oTempEmployee.SolutionAreas.length; i++) {
                const iIndex = aSolutionAreas.findIndex(item => item.Guid === oTempEmployee.SolutionAreas[i].SolAreal1Guid);
                if (iIndex !== -1) {
                    let aSln = this.setSolutionData(oTempEmployee.SolutionAreas[i]);
                    aSolutionArea.push(aSln);
                } else if (oTempEmployee.SolutionAreas[i].IsMaterial) {
                    aSolutionArea.push(oTempEmployee.SolutionAreas[i]);
                }
            }
            oModel.setProperty("/TempEmployee/TempSolutionArea", aSolutionArea);
            if (initLoad) {
                if (isRoleChanged) {
                    oModel.setProperty("/Employee/SolutionAreas", aSolutionArea);
                    oModel.setProperty("/TempEmployee/SolutionAreas", aSolutionArea);
                }
                else {
                    if (aSolutionArea.length > 0 && aEmployeeSolutionAreas.length === aSolutionArea.length) {
                        oModel.setProperty("/Employee/SolutionAreas", aSolutionArea);
                        oModel.setProperty("/TempEmployee/SolutionAreas", aSolutionArea);
                    }
                    else {
                        oModel.setProperty("/TempEmployee/SolutionAreas", aEmployeeSolutionAreas);
                        oModel.setProperty("/Employee/SolutionAreas", aEmployeeSolutionAreas);
                        oModel.setProperty("/TempEmployee/TempSolutionArea", aEmployeeSolutionAreas);
                    }
                }
            }
            oModel.setProperty("/filter/SolutionAreas", aSolutionAreas);
            this.setSolutionHierarchySelection(initLoad);
            this.onSearchSolutions();
            oSolutionModel.refresh(true);
            oModel.refresh(true);
        },
        setSolutionHierarchySelection: function (initLoad) {
            const oModel = this.getView().getModel("employee");
            const oTempEmployee = oModel.getProperty("/filter/TempEmployee");
            let aTempSolutionAreas = oTempEmployee.TempSolutionArea;
            let aSolutionAreas = oModel.getProperty("/filter/SolutionAreas");
            const NonSolutionAreaFocused = oModel.getProperty("/filter/NonSolutionAreaFocused");
            aSolutionAreas = this.selectIfSolutionsExists(aSolutionAreas, [], 0, true);
            for (let i = 0; i < aTempSolutionAreas.length; i++) {
                let aGuid = [];
                if (NonSolutionAreaFocused && !NonSolutionAreaFocused.IsSelected && aTempSolutionAreas[i].SelectedGuid) {
                    aGuid = aTempSolutionAreas[i].SelectedGuid.split(",");
                }
                aSolutionAreas = this.selectIfSolutionsExists(aSolutionAreas, aGuid, 0);

            }
            oModel.setProperty("/filter/SolutionAreas", aSolutionAreas);
            oModel.refresh(true);
        },
        selectIfSolutionsExists: function (aSolutions, guids, index, forceReset) {
            if (!aSolutions || aSolutions.length === 0) {
                return [];
            }
            if (aSolutions[0].Guid) {
                const oModel = this.getView().getModel("employee");
                const oTempEmployee = oModel.getProperty("/filter/TempEmployee");
                const aTempSolutionArea = $.extend(true, [], oTempEmployee.TempSolutionArea);

                const oPrimarySolutionArea = aTempSolutionArea.find(item => item.IsPrimary);
                const oPrimaryCatalystSol = aTempSolutionArea.find(item => item.IsPrimCatalyst);

                for (let j = 0; j < aSolutions.length; j++) {
                    const oSolution = aSolutions[j];
                    if (!oSolution.IsNonFocused) {
                        if (oPrimaryCatalystSol) {
                            if (oSolution.IsSelectable && oSolution.IsPrimaryRequire) {

                                oSolution.IsPrimCatalystFlag = true;
                            } else {

                                oSolution.IsPrimCatalystFlag = JSON.parse(JSON.stringify(oSolution.IsPrimCatalyst));
                                oSolution.IsPrimary = (oSolution.IsPrimCatalystFlag) ? oSolution.IsPrimary : false;
                            }
                        } else {
                            oSolution.IsPrimCatalystFlag = JSON.parse(JSON.stringify(oSolution.IsPrimCatalyst));
                            oSolution.IsPrimary = (oSolution.IsPrimCatalystFlag) ? oSolution.IsPrimary : false;
                        }

                        if (!forceReset) {

                            if (oSolution.Guid.trim() === (guids && guids[index] && guids[index].trim())) {
                                const iIndex = aTempSolutionArea.findIndex(item => oSolution.Guid === item.Guid);
                                oSolution.IsSelected = true;
                                oSolution.IsEnabled = (iIndex !== -1 && oSolution.IsPrimaryFlag) ? true : false;
                                oSolution.IsPrimary = (oPrimarySolutionArea && oPrimarySolutionArea.Guid === oSolution.Guid && oSolution.IsPrimCatalystFlag) ?
                                    true : false;
                                if (iIndex !== -1 && !oSolution.IsPrimary) {
                                    aTempSolutionArea[iIndex].IsPrimary = false;
                                }
                            }
                            if (oSolution.Levels && oSolution.Levels.length > 0 && oSolution.Levels[0].Guid) {
                                oSolution.Levels = this.selectIfSolutionsExists(oSolution.Levels, guids, index + 1);
                            }
                        } else {
                            oSolution.IsSelected = false;
                            oSolution.IsPrimary = false;
                            oSolution.IsEnabled = false;
                            if (oSolution.Levels && oSolution.Levels.length > 0 && oSolution.Levels[0].Guid) {
                                oSolution.Levels = this.selectIfSolutionsExists(oSolution.Levels, guids, index + 1, true);
                            }

                        }

                    }
                    aSolutions[j] = oSolution;
                }
            }
            return aSolutions;
        },
        onSelectSolutionArea: function (oEvent) {
            const oModel = this.getView().getModel("employee");
            const oSource = oEvent.getSource();
            const bSelected = oEvent.getParameter("selected");
            const sSelectedGuid = oSource.data("DisplayGuid");

            const oBindingContext = oSource.getBindingContext("employee");
            const oGrpHierarchyTreeModel = oBindingContext.getModel();
            const sPath = oBindingContext.getPath();
            const oSolutionArea = oGrpHierarchyTreeModel.getProperty(sPath);
            oSolutionArea.Levels = this.selectIfSolutionsExists(oSolutionArea.Levels, [], 0, true);
            const oTempEmployee = oModel.getProperty("/filter/TempEmployee");
            let aEmployeeSolutionArea = oTempEmployee.TempSolutionArea || [];
            if (oEvent.getParameter("origin") === "recent") {
                aEmployeeSolutionArea = aEmployeeSolutionArea.filter(
                    item => item.SelectedGuid !== sSelectedGuid
                );
            }
            else {
                aEmployeeSolutionArea = aEmployeeSolutionArea.filter(item => !item.SelectedGuid.includes(
                    sSelectedGuid));
            }
            const iIndex = aEmployeeSolutionArea.findIndex(item => item.SelectedGuid === oSolutionArea.sSelectedGuid);

            if (iIndex !== -1 && !bSelected) {
                aEmployeeSolutionArea.splice(iIndex, 1);
                oSolutionArea.IsPrimary = false;
            } else if (iIndex === -1 && bSelected) {
                const aSolutionWIthoutMaterilas = aEmployeeSolutionArea.filter(item => !item.IsMaterial);
                if (aSolutionWIthoutMaterilas && aSolutionWIthoutMaterilas.length === 0) {
                    oSolutionArea.IsPrimary = (oSolutionArea.IsPrimaryFlag && oSolutionArea.IsPrimCatalystFlag) ? true : false;
                } else if (aSolutionWIthoutMaterilas && aSolutionWIthoutMaterilas.length === 1 && aSolutionWIthoutMaterilas[0].IsPrimary) {
                    const iIndex = aEmployeeSolutionArea.findIndex(item => item.IsPrimary);
                    if (iIndex !== -1) {
                        aEmployeeSolutionArea[iIndex].IsPrimary = false;
                    }

                }

                let aSlnArea = this.setSolutionData({
                    Desc: oSolutionArea.Desc,
                    Guid: oSolutionArea.Guid,
                    LevelId: oSolutionArea.LevelId,
                    IsMaterial: false,
                    IsPrimary: oSolutionArea.IsPrimary,
                    IsPrimCatalyst: oSolutionArea.IsPrimCatalyst,
                    IsNonFocused: oSolutionArea.IsNonFocused,
                    soln_guid: oSolutionArea.Guid,
                    SolAreal1Guid: oSolutionArea.SolAreal1Guid,
                    SolAreal1Desc: oSolutionArea.SolAreal1Desc,
                    SolAreal2Guid: oSolutionArea.SolAreal2Guid,
                    SolAreal2Desc: oSolutionArea.SolAreal2Desc,
                    SolAreal3Guid: oSolutionArea.SolAreal3Guid,
                    SolAreal3Desc: oSolutionArea.SolAreal3Desc,
                    SolAreal4Guid: oSolutionArea.SolAreal4Guid,
                    SolAreal4Desc: oSolutionArea.SolAreal4Desc,
                    SolAreal5Guid: oSolutionArea.SolAreal5Guid,
                    SolAreal5Desc: oSolutionArea.SolAreal5Desc,
                    SolAreal6Guid: oSolutionArea.SolAreal6Guid, //material Id
                    SolAreal6Desc: oSolutionArea.SolAreal6Desc, // Material name
                });

                aEmployeeSolutionArea.push(aSlnArea);
                const guids = sSelectedGuid.split(",");
                let aSelectedGuids = JSON.parse(JSON.stringify(guids));
                aSelectedGuids.pop();
                for (let i = guids.length - 2; i >= 0; i--) {
                    let iParentIndex = aEmployeeSolutionArea.findIndex(item => item.SelectedGuid === aSelectedGuids.join(","));
                    if (iParentIndex !== -1) {
                        aEmployeeSolutionArea.splice(iParentIndex, 1);
                    }
                    aSelectedGuids.pop();
                }

            } else {
                if (oSolutionArea.LevelId > 1 && !bSelected) {
                    const aSelectedNodes = sPath.split("/filter/SolutionAreas/")[1].split("/Levels/");
                    let sSelectedNodePath = "/filter/SolutionAreas/" + aSelectedNodes[0];
                    for (let i = 1; i < aSelectedNodes.length - 1; i++) {
                        sSelectedNodePath += "/Levels/" + aSelectedNodes[i];
                    }
                    const oSelectedLevelsParent = oGrpHierarchyTreeModel.getProperty(sSelectedNodePath);
                    const IParentIndex = aEmployeeSolutionArea.findIndex(item => item.SelectedGuid.includes(oSelectedLevelsParent.Guid));
                    if (IParentIndex === -1 && oSelectedLevelsParent.IsSelectableFlag) {
                        let aSln = this.setSolutionData({
                            Desc: oSelectedLevelsParent.Desc,
                            Guid: oSelectedLevelsParent.Guid,
                            LevelId: oSelectedLevelsParent.LevelId,
                            IsMaterial: false,
                            IsPrimary: false,
                            IsPrimCatalyst: oSelectedLevelsParent.IsPrimCatalyst,
                            soln_guid: oSelectedLevelsParent.Guid,
                            SolAreal1Guid: oSelectedLevelsParent.SolAreal1Guid,
                            SolAreal1Desc: oSelectedLevelsParent.SolAreal1Desc,
                            SolAreal2Guid: oSelectedLevelsParent.SolAreal2Guid,
                            SolAreal2Desc: oSelectedLevelsParent.SolAreal2Desc,
                            SolAreal3Guid: oSelectedLevelsParent.SolAreal3Guid,
                            SolAreal3Desc: oSelectedLevelsParent.SolAreal3Desc,
                            SolAreal4Guid: oSelectedLevelsParent.SolAreal4Guid,
                            SolAreal4Desc: oSelectedLevelsParent.SolAreal4Desc,
                            SolAreal5Guid: oSelectedLevelsParent.SolAreal5Guid,
                            SolAreal5Desc: oSelectedLevelsParent.SolAreal5Desc,
                            SolAreal6Guid: oSelectedLevelsParent.SolAreal6Guid, //material Id
                            SolAreal6Desc: oSelectedLevelsParent.SolAreal6Desc, // Material name
                        });
                        aEmployeeSolutionArea.push(aSln);

                    }
                }
                if (iIndex !== -1) {
                    aEmployeeSolutionArea.splice(iIndex, 1);
                }
            }

            oModel.setProperty("/filter/TempEmployee/TempSolutionArea", aEmployeeSolutionArea);
            this.setSolutionHierarchySelection();
            aEmployeeSolutionArea.length ? oModel.setProperty("/filter/dialogselSlnVisible", true) : oModel.setProperty("/filter/dialogselSlnVisible", false);
            oModel.refresh(true);
        },
        onSearchSolutions: function (oEvent) {
            let sQuery = "";
            if (oEvent) {
                sQuery = oEvent.getSource().getValue().trim();
            }
            const TableId = this.byId("idSolutionFilterTree");
            const allFilter = [];
            let oFilter2;
            if (sQuery && sQuery.length > 0) {
                const oFilter1 = new sap.ui.model.Filter("Desc", sap.ui.model.FilterOperator.Contains, sQuery);
                allFilter.push(oFilter1);
                oFilter2 = new sap.ui.model.Filter("SolnName", sap.ui.model.FilterOperator.Contains, sQuery)
            }
            const oNonFocusedFilter = new sap.ui.model.Filter("IsNonFocused", sap.ui.model.FilterOperator.EQ, false);
            allFilter.push(oNonFocusedFilter);
            const aFilters = new sap.ui.model.Filter({
                filters: allFilter,
                and: true
            });
            TableId.getBinding().filter(aFilters);
            if (sQuery) {
                TableId.expandToLevel(sQuery ? 99 : 0);
            } else {
                TableId.collapseAll();
            }

        },
        onChangeNonSolAreaFocused: function (oEvent) {
            const oModel = this.getView().getModel("employee");
            const bSelected = typeof oEvent === 'object'  ? oEvent.getParameter("state"):oEvent;
            const aSolutionAreas = oModel.getProperty("/filter/SolutionAreas");
            let oNonIndustryFocused;
            aSolutionAreas.map(function (element) {
                if (bSelected && element.IsNonFocused) {
                    element.IsSelected = true;
                    element.IsPrimary = true;
                    oNonIndustryFocused = element;
                } else if(typeof oEvent === 'object') {
                    element.IsSelected = false;
                    element.IsPrimary = false;
                }
            });
            if (bSelected && oNonIndustryFocused) {
                let oSln = this.setSolutionData({
                    Guid: oNonIndustryFocused.Guid,
                    Desc: oNonIndustryFocused.Desc,
                    IsPrimary: true,
                    IsNonFocused: true,
                    IsMaterial: false,
                    SolAreal1Guid: oNonIndustryFocused.Guid,
                    SolAreal1Desc: oNonIndustryFocused.Desc
                });
                oModel.setProperty("/filter/TempEmployee/TempSolutionArea", [oSln]);
                oModel.setProperty("/filter/NonSolutionAreaFocused", {
                    Guid: oNonIndustryFocused.Guid,
                    IsSelected: true,
                    IsVisible: true
                });
            } else {
                if (typeof oEvent === 'object') {
                    oModel.setProperty("/filter/TempEmployee/TempSolutionArea", []);
                }
                oModel.setProperty("/filter/NonSolutionAreaFocused", {
                    Guid: "",
                    IsSelected: false,
                    IsVisible: true
                });
            }
            this.setSolutionHierarchySelection(true);
            
        },
        onChangeFilterSolutionArea: function () {
            const oModel = this.getView().getModel("employee");
            const aTempSolutionAreas = oModel.getProperty("/filter/TempEmployee/TempSolutionArea");
            const aSolutionArea = [];
            for (let i = 0; i < aTempSolutionAreas.length; i++) {
                const oSolutionArea = {};
                oSolutionArea.Desc = aTempSolutionAreas[i].Desc;
                oSolutionArea.Guid = aTempSolutionAreas[i].Guid;
                oSolutionArea.LevelId = aTempSolutionAreas[i].LevelId;
                oSolutionArea.IsMaterial = aTempSolutionAreas[i].IsMaterial;
                oSolutionArea.IsPrimary = aTempSolutionAreas[i].IsPrimary;
                oSolutionArea.IsPrimCatalyst = aTempSolutionAreas[i].IsPrimCatalyst;
                oSolutionArea.IsNonFocused = aTempSolutionAreas[i].IsNonFocused;
                oSolutionArea.sol_year = aTempSolutionAreas[i].sol_year;
                oSolutionArea.soln_guid = aTempSolutionAreas[i].soln_guid;
                for (let j = 1; j <= 6; j++) {
                    oSolutionArea["SolAreal" + j + "Guid"] = aTempSolutionAreas[i]["SolAreal" + j + "Guid"];
                    oSolutionArea["SolAreal" + j + "Desc"] = aTempSolutionAreas[i]["SolAreal" + j + "Desc"];
                }
                const oSolArea = this.setSolutionData(oSolutionArea);

                aSolutionArea.push(oSolArea);
            }
            oModel.setProperty("/filter/TempEmployee/SolutionAreas", $.extend(true, [], aSolutionArea));
            this.onCloseSolutionAreaValueHelpDialog();
            this.getFilterSummaryText();
        },
        onCloseSolutionAreaValueHelpDialog: function () {
            this.pSolutionAreaDialog.then(function (oDialog) {
                this.getView().getModel("employee").setProperty("/filter/sSearchBoxText", "");
                this.getView().getModel("employee").setProperty("/filter/sMatSearchBoxText", "");
                this.onSearchSolutions(false);
                oDialog.close();
            }.bind(this));
        },
        onDeleteSolutionFilterToken: function (oEvent) {
            if (oEvent.getParameter("type") === "removed") {
                let aRemovedTokens = oEvent.getParameter("removedTokens");
                let oModel = this.getView().getModel("employee");
                let aSelected = oModel.getProperty("/filter/TempEmployee/SolutionAreas");

                aRemovedTokens.forEach(function (oToken) {
                    let sKey = oToken.getKey();

                    aSelected.forEach(function (item) {
                        if (item.Guid === sKey) {
                            item.IsDel = true; // update your selected flag
                        }
                    });
                });
                aSelected = aSelected.filter(item => !item.IsDel);

                oModel.setProperty("/filter/TempEmployee/SolutionAreas", aSelected);
                oModel.setProperty("/filter/TempEmployee/TempSolutionArea", aSelected);
                oModel.refresh();
                this.getFilterSummaryText();
            }
        },
        onDeleteDialogSlnToken: function (oEvent) {
            if (oEvent.getParameter("type") === "removed") {
                let aRemovedTokens = oEvent.getParameter("removedTokens");
                let oModel = this.getView().getModel("employee");
                let aSelected = oModel.getProperty("/filter/TempEmployee/TempSolutionArea");
                let that = this;

                aRemovedTokens.forEach(function (oToken) {
                    let sKey = oToken.getKey();
                    let isNonFocused = oToken.getBindingContext("employee").getObject().IsNonFocused
                    if(isNonFocused){
                        that.onChangeNonSolAreaFocused();
                    }

                    aSelected.forEach(function (item) {
                        if (item.Guid === sKey) {
                            item.IsDel = true; // update your selected flag
                        }
                    });
                });
                aSelected = aSelected.filter(item => !item.IsDel);
                oModel.setProperty("/filter/TempEmployee/TempSolutionArea", aSelected);
                this.setSolutionHierarchySelection();
                oModel.refresh();
            }
        },
        onSearchOreRecords: function () {
            const sSelectedKey = this.getView().getModel("employee").getProperty("/filter/selectedTab");
            this.getView().setModel(new JSONModel([]), sSelectedKey === "customerAdvisory" ? "resourcesCAModel" : "resourcesOREModel");
            let sFilterQuery = this._getFilters();
            this.getView().getModel("employee").setProperty("/filter/filterQuery", sFilterQuery);
            this.getView().getModel("employee").refresh();
            this.onTabSelect();
            this.getView().byId("EmpDetailsTableID").setFirstVisibleRow(0);
            this.getView().byId("customerAdvisoryID").setFirstVisibleRow(0);
        },
        _getFilters: function () {
            const oModel = this.getView().getModel("employee");
            const oSelectedFilter = oModel.getProperty("/filter");
            const oMainModel = this.getView().getModel();
            const oUserModel = this.getOwnerComponent().getModel("userDetails");
            const aFilters = [];
            let oFilterSlnGrps = this._getSlnGroup();
            let oFilterGrps = this._getFilterGroup();
            const sSelectedKey = this.getView().getModel("employee").getProperty("/filter/selectedTab");
            const usersArray = oMainModel.getProperty("/aResourceProfileApprovers/ApproverDetails");
            const emailToFind = oUserModel.getProperty("/email");
            const sLoggedInUserId = oUserModel.getProperty("/user_name").toUpperCase();
            const user = usersArray.find(user => user.email === emailToFind);
            let sFilters = "";
            let sDefaultFilter = sSelectedKey === "customerAdvisory" ? `MelodyRequest eq 'X'` : `ManagerId eq '${user.ID}' and MelodyRequest eq 'X'`;
            let aIndustry = oModel.getProperty("/TempEmployee/BAIndustries") ? oModel.getProperty("/TempEmployee/TempBAIndustries") : [];
            let aSelectedProfitCenter = this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories") ? this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories") : [];
            //Industry
            if (aIndustry.length > 0) {
                let oIndustryId = {
                    Desc: aIndustry.map(item => item.Desc)
                };

                aFilters.push(this.getPropertyFilters("BaIndDesc", oIndustryId.Desc));
            }
            //profit center
            if (aSelectedProfitCenter.length > 0) {
                let oProfitCenterId = {
                    Trtrypc: aSelectedProfitCenter.map(item => item.TrpcId)
                };

                aFilters.push(this.getPropertyFilters("Trtrypc", oProfitCenterId.Trtrypc));
            }
            // Manager1 IPP
            if (oSelectedFilter.ManagerId.SelectedKeys.length > 0 && sSelectedKey === 'customerAdvisory') {
                if ((sSelectedKey === "customerAdvisory") || (sSelectedKey === "directReports" && !oSelectedFilter.ManagerId.SelectedKeys.join().includes(sLoggedInUserId))) {
                aFilters.push(this.getPropertyFilters("ManagerId", oSelectedFilter.ManagerId.SelectedKeys));
                }
            }
            // role primary
            if (oSelectedFilter.RolePrimary.SelectedKeys.length > 0) {
                const aRolePrimary = [];
                oSelectedFilter.RolePrimary.SelectedKeys.map(function (element) {
                    aRolePrimary.push(element.split(",")[0]);
                });
                aFilters.push(this.getPropertyFilters("RoleGuid", aRolePrimary));
                sFilters += "RoleGuid=" + aRolePrimary.toString() + "&";
            }
            // group
            if (oFilterGrps && oFilterGrps.groupL1.length > 0 && oFilterGrps.groupL1.toString() !==
                "00000000-0000-0000-0000-000000000000") {
                aFilters.push(this.getPropertyFilters("Groupl1Guid", oFilterGrps.groupL1));
                sFilters += "Groupl1Guid=" + oFilterGrps.groupL1.toString() + "&";
            }
            if (oFilterGrps && oFilterGrps.groupL2.length > 0 && oFilterGrps.groupL2.toString() !==
                "00000000-0000-0000-0000-000000000000") {
                aFilters.push(this.getPropertyFilters("Groupl2Guid", oFilterGrps.groupL2));
                sFilters += "Groupl2Guid=" + oFilterGrps.groupL2.toString() + "&";
            }
            if (oFilterGrps && oFilterGrps.groupL3.length > 0 && oFilterGrps.groupL3.toString() !==
                "00000000-0000-0000-0000-000000000000") {
                aFilters.push(this.getPropertyFilters("Groupl3Guid", oFilterGrps.groupL3));
                sFilters += "Groupl3Guid=" + oFilterGrps.groupL3.toString() + "&";
            }
            if (oFilterGrps && oFilterGrps.groupL4.length > 0 && oFilterGrps.groupL4.toString() !==
                "00000000-0000-0000-0000-000000000000") {
                aFilters.push(this.getPropertyFilters("Groupl4Guid", oFilterGrps.groupL4));
                sFilters += "Groupl4Guid=" + oFilterGrps.groupL4.toString() + "&";
            }
            if (oFilterGrps && oFilterGrps.groupL5.length > 0 && oFilterGrps.groupL5.toString() !==
                "00000000-0000-0000-0000-000000000000") {
                aFilters.push(this.getPropertyFilters("Groupl5Guid", oFilterGrps.groupL5));
                sFilters += "Groupl5Guid=" + oFilterGrps.groupL5.toString() + "&";
            }

            // sln
            if (oFilterSlnGrps && oFilterSlnGrps.aSlnL1.length > 0 && oFilterSlnGrps.aSlnL1.toString() !==
                "00000000-0000-0000-0000-000000000000") {
                aFilters.push(this.getPropertyFilters("SolL1Guid", oFilterSlnGrps.aSlnL1));
                sFilters += "SolL1Guid=" + oFilterSlnGrps.aSlnL1.toString() + "&";
            }
            if (oFilterSlnGrps && oFilterSlnGrps.aSlnL2.length > 0 && oFilterSlnGrps.aSlnL2.toString() !==
                "00000000-0000-0000-0000-000000000000") {
                aFilters.push(this.getPropertyFilters("SolL2Guid", oFilterSlnGrps.aSlnL2));
                sFilters += "SolL2Guid=" + oFilterSlnGrps.aSlnL2.toString() + "&";
            }
            if (oFilterSlnGrps && oFilterSlnGrps.aSlnL3.length > 0 && oFilterSlnGrps.aSlnL3.toString() !==
                "00000000-0000-0000-0000-000000000000") {
                aFilters.push(this.getPropertyFilters("SolL3Guid", oFilterSlnGrps.aSlnL3));
                sFilters += "SolL3Guid=" + oFilterSlnGrps.aSlnL3.toString() + "&";
            }
            if (oFilterSlnGrps && oFilterSlnGrps.aSlnL4.length > 0 && oFilterSlnGrps.aSlnL4.toString() !==
                "00000000-0000-0000-0000-000000000000") {
                aFilters.push(this.getPropertyFilters("SolL4Guid", oFilterSlnGrps.aSlnL4));
                sFilters += "SolL4Guid=" + oFilterSlnGrps.aSlnL4.toString() + "&";
            }
            if (oFilterSlnGrps && oFilterSlnGrps.aSlnL5.length > 0 && oFilterSlnGrps.aSlnL5.toString() !==
                "00000000-0000-0000-0000-000000000000") {
                aFilters.push(this.getPropertyFilters("SolL5Guid", oFilterSlnGrps.aSlnL5));
                sFilters += "SolL5Guid=" + oFilterSlnGrps.aSlnL5.toString() + "&";
            }

            function buildODataFilter(filters) {
                function parseFilter(filter) {
                    // MultiFilter
                    if (filter.aFilters && filter.aFilters.length) {
                        const logic = filter.bAnd === false ? " or " : " or ";
                        return "(" + filter.aFilters.map(parseFilter).join(logic) + ")";
                    }
                    let field = filter.sPath;
                    let op = filter.sOperator;
                    let value = filter.oValue1;
                    if (typeof value === "string") {
                        value = `'${value}'`;
                    }
                    if (["RoleGuid", "Groupl1Guid", "Groupl2Guid", "Groupl3Guid", "Groupl4Guid", "Groupl5Guid", "SolL1Guid", "SolL2Guid", "SolL3Guid", "SolL4Guid", "SolL5Guid"].includes(field) && typeof value === "string") {
                        value = "guid" + value;
                    }
                    switch (op) {
                        case "EQ": return `${field} eq ${value}`;
                        case "NE": return `${field} ne ${value}`;
                        case "GT": return `${field} gt ${value}`;
                        case "LT": return `${field} lt ${value}`;
                        case "GE": return `${field} ge ${value}`;
                        case "LE": return `${field} le ${value}`;
                        case "Contains":
                            return `contains(${field},${value})`;
                        case "StartsWith":
                            return `startswith(${field},${value})`;
                        case "EndsWith":
                            return `endswith(${field},${value})`;
                        case "BT":
                            let value2 = typeof filter.oValue2 === "string"
                                ? `'${filter.oValue2}'`
                                : filter.oValue2;
                            return `(${field} ge ${value} and ${field} le ${value2})`;
                        default:
                            return `${field} eq ${value}`;
                    }
                }
                return filters.map(parseFilter).join(" and ");
            }
            this.aFilters = aFilters;
            sFilters = buildODataFilter(aFilters);
            this.SortOrder = this.SortOrder ? this.SortOrder : 'asc';
            this.SortBy = this.SortBy ? this.SortBy : 'CapEmpNme';
            let sSearchText = oModel.getProperty("/searchEmployee");
            this.SortBy = this.SortBy === "ResourceId" && sSelectedKey === 'customerAdvisory' ? "Id": this.SortBy;
            this.SortBy = this.SortBy === "Id" && sSelectedKey !== 'customerAdvisory' ? 'ResourceId' : this.SortBy;
       

            let sFilterQuery = sFilters ? `?$filter=${sDefaultFilter} and ${sFilters}&$orderby=${this.SortBy} ${this.SortOrder}` : `?$filter=${sDefaultFilter}&$orderby=${this.SortBy} ${this.SortOrder}`
            return sSearchText ? `${sFilterQuery}&search=${sSearchText}` : sFilterQuery;
        },
        getPropertyFilters: function (sProperty, aSelectedKeys) {
            const aFilters = [];
            for (let i = 0; i < aSelectedKeys.length; i++) {
                const oFilter = new Filter(sProperty, FilterOperator.EQ, aSelectedKeys[i]);
                aFilters.push(oFilter);
            }
            return new Filter({
                filters: aFilters,
                and: false
            });
        },
        _getSlnGroup: function () {
            let oModel = this.getView().getModel("employee");
            let aSelectedSolutionAreas = oModel.getProperty("/filter/TempEmployee/SolutionAreas") ? oModel.getProperty("/filter/TempEmployee/SolutionAreas") : [];
            let aFilterSolution = {
                aSlnL1: [],
                aSlnL2: [],
                aSlnL3: [],
                aSlnL4: [],
                aSlnL5: []
            };
            for (let i = 0; i < aSelectedSolutionAreas.length; i++) {
                aSelectedSolutionAreas[i].SolAreal1Guid && aFilterSolution.aSlnL1.push(aSelectedSolutionAreas[i].SolAreal1Guid);
                aSelectedSolutionAreas[i].SolAreal2Guid && aFilterSolution.aSlnL2.push(aSelectedSolutionAreas[i].SolAreal2Guid);
                aSelectedSolutionAreas[i].SolAreal3Guid && aFilterSolution.aSlnL3.push(aSelectedSolutionAreas[i].SolAreal3Guid);
                aSelectedSolutionAreas[i].SolAreal4Guid && aFilterSolution.aSlnL4.push(aSelectedSolutionAreas[i].SolAreal4Guid);
                aSelectedSolutionAreas[i].SolAreal5Guidh && aFilterSolution.aSlnL5.push(aSelectedSolutionAreas[i].SolAreal5Guid);
            }
            return aFilterSolution;
        },
        _getFilterGroup: function () {
            let oModel = this.getView().getModel("employee");
            let aTempGroupFilters = oModel.getProperty("/filter/Group/SelectedKeys") ?  oModel.getProperty("/filter/Group/SelectedKeys") : [];
            let aFilterGroups = {
                groupL1: [],
                groupL2: [],
                groupL3: [],
                groupL4: [],
                groupL5: []
            };
            for (let i = 0; i < aTempGroupFilters.length; i++) {
                let group = {};
                group.GroupClstrGuid = aTempGroupFilters[i].GroupClstrGuid;
                group.GrpClstrDesc = aTempGroupFilters[i].GrpClstrDesc;

                for (let j = 1; j <= 5; j++) {
                    group["Groupl" + j + "Guid"] = aTempGroupFilters[i]["Groupl" + j + "Guid"];
                    group["GrpL" + j + "Desc"] = aTempGroupFilters[i]["GrpL" + j + "Desc"];
                }
                const oGroup = this.setGrpData(group);
                aFilterGroups.groupL1.push(oGroup.Groupl1Guid);
                aFilterGroups.groupL2.push(oGroup.Groupl2Guid);
                aFilterGroups.groupL3.push(oGroup.Groupl3Guid);
                aFilterGroups.groupL4.push(oGroup.Groupl4Guid);
                aFilterGroups.groupL5.push(oGroup.Groupl5Guid);
            }
            oModel.setProperty("/filter/filterGroup",aFilterGroups);
            oModel.refresh();
            return aFilterGroups;
        },
       
        onOpenP13n: function () {
            const sSelectedKey = this.getView().getModel("employee").getProperty("/filter/selectedTab");
            sSelectedKey === 'directReports' ?   this._oTPC_1.openDialog() : this._oTPC_2.openDialog();
         
        },
        _getCurrentTable: function () {
            return this.byId("EmpDetailsTableID").getVisible() ? this.byId("EmpDetailsTableID") : this.byId("customerAdvisoryID");
        },
        onDeleteProcessorToken: function (oEvent) {
            if (oEvent.getParameter("type") === "removed") {
                let aRemovedTokens = oEvent.getParameter("removedTokens");
                let oModel = this.getView().getModel("selectedOREModel");
                 let aSelectedProcessor = oModel.getProperty("/ApproverDetails");
                aRemovedTokens.forEach(function (oToken) {
                    let sKey = oToken.getKey();

                    aSelectedProcessor.forEach(function (item) {
                        if (item.ID === sKey) {
                            item.IsDel = true; // update your selected flag
                        }
                    });
                });
                aSelectedProcessor = aSelectedProcessor.filter(item => !item.IsDel);
                oModel.setProperty("/ApproverDetails", aSelectedProcessor);
                oModel.refresh();
                this.getView().getModel("employee").setProperty("/bIsEditProcessorInput",aSelectedProcessor && aSelectedProcessor.length > 0);
                this.getView().getModel("employee").refresh();
                this._setSelectedProcessor();
            }
        },
        _setSelectedProcessor: function () {
            let oModel = this.getView().getModel("selectedOREModel");
            let aSelectedProcessor = oModel.getProperty("/ApproverDetails");
            let aProcessorData = this.getView().getModel("CAModel").getProperty("/availableResources");
            // Create ID lookup
            let aUserIds = aSelectedProcessor.map(function (item) {
                return item.ID;
            });
            // Update CAModel
            aProcessorData.forEach(function (item) {
                item.selected = aUserIds.includes(item.userId);
            });
            // Refresh model
            this.getView().getModel("CAModel").refresh();

        },
          /**
        * Select processor from advanced search
        * @param {obj} oEvent button context
        * @function onSelectProcessor
        */
        onSelectProcessor: function (oEvent) {
            let oCheckBox = oEvent.getSource();
            let bSelected = oEvent.getParameter("selected");
            let oContext = oCheckBox.getBindingContext("CAModel");
            let oData = oContext.getObject();
            let oModel =  this.getView().getModel("selectedOREModel");
            let aSelectedItems = oModel.getProperty("/ApproverDetails");
            if (bSelected) {
                // ADD
                let exists = aSelectedItems.some(item => item.ID === oData.userId);

                if (!exists) {
                    aSelectedItems.push({
                        fullName: oData.fullName,
                        ID: oData.userId,
                        email: oData.email,
                        to_substitute: oData.to_nmdsubstitute,
                        ROLE: oData.Emp_CrmRoleId
                    });
                }
            } else {
                // REMOVE
                aSelectedItems = aSelectedItems.filter(item => item.ID !== oData.userId);
            }
            oModel.setProperty("/ApproverDetails", aSelectedItems);
            oModel.refresh(true);
           //this.getView().getModel("employee").setProperty("/bIsEditProcessorInput",aSelectedItems && aSelectedItems.length > 0);
            this.getView().getModel("employee").refresh();
        },
        onResetRecords: function () {
            this._setOreFilterModel(this.getView().getModel("employee").getProperty("/filter/selectedTab"));
            this.onSearchOreRecords();
            this.getFilterSummaryText();
        },
        getFilterSummaryText: function () {
            const aFilterCriterias = this._getFilterLabel();
            const oResourceModel = this.getView().getModel("i18n").getResourceBundle();

            let sFilterSummaryText = oResourceModel.getText("filteredBy") + ": " + oResourceModel.getText("none");
            if (aFilterCriterias.length > 0) {
                sFilterSummaryText = oResourceModel.getText("filteredBy") + ": (" + aFilterCriterias.length + "):" + aFilterCriterias.join(", ");
            }
            const oModel = this.getView().getModel("employee");
            oModel.setProperty("/FilteredText", sFilterSummaryText);
        },
          /**
        * update filter by labels
        * @function _getFilterLabel
        */
        _getFilterLabel: function () {
            let oModel = this.getView().getModel("employee");
            let aSelectedProfitCenter = this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories") ? this.getView().getModel("selectedProfitCenter").getProperty("/TempProfitCenter/Territories") : [];
            let aSelectedIndustry = oModel.getProperty("/TempEmployee/BAIndustries") ? oModel.getProperty("/TempEmployee/TempBAIndustries") : [];
            let aSelectedSolutionAreas = oModel.getProperty("/filter/TempEmployee/SolutionAreas") ? oModel.getProperty("/filter/TempEmployee/SolutionAreas") : [];
            let aSelectedGrp = oModel.getProperty("/filter/Group/SelectedKeys") ?  oModel.getProperty("/filter/Group/SelectedKeys") : [];
            let aSelectedRole = oModel.getProperty("/filter/RolePrimary/SelectedKeys") ?  oModel.getProperty("/filter/RolePrimary/SelectedKeys") : [];
            let aSelectedManager = oModel.getProperty("/filter/ManagerId/SelectedKeys") ?  oModel.getProperty("/filter/ManagerId/SelectedKeys") : [];
            let oSearch = oModel.getProperty("/searchEmployee");
            let oSelectedFilter = {
                "role":{
                    "label":"Role (Primary)",
                    "selectedKeys":aSelectedRole
                },
                "mangerName": {
                    "label": "Manager L1 Name - ID",
                    "selectedKeys": aSelectedManager
                },
                "profitCenter":{
                    "label":"Profit Center",
                    "selectedKeys":aSelectedProfitCenter
                },
                "industry":{
                    "label":"Industry",
                    "selectedKeys":aSelectedIndustry
                },
                "aSelectedSolutionAreas":{
                    "label":"Solution Area",
                    "selectedKeys":aSelectedSolutionAreas
                },
                "Group":{
                    "label":"Group",
                    "selectedKeys":aSelectedGrp
                }
            }
            const aFilterCriterias = [];
            if (oSearch) {
                aFilterCriterias.push(" EmployeeID/Name")
            }
            for (var prop in oSelectedFilter) {
                if (oSelectedFilter[prop].selectedKeys && oSelectedFilter[prop].selectedKeys.length > 0) {
                    aFilterCriterias.push(oSelectedFilter[prop].label);
                }
            }
            return aFilterCriterias;
        },
        onAddProcessor:function(){
            this.onConfirmNamedContact(false);

        },
        _initializeTableSettings: function () {
                 let oTable2 = this.getView().byId("customerAdvisoryID");
            let aCols2 = oTable2.getColumns();

            let aColsData2 = aCols2.map(function (col) {
                return {
                    id: col.getId(),
                    text: col.getMultiLabels().length ? col.getMultiLabels()[0].getText() : col.getLabel().getText(),
                    visible: col.getVisible()
                };
            });
            aColsData2 = aColsData2.filter(item => item.text);
            this.aColumnList = JSON.parse(JSON.stringify(aColsData2));
            // let oColsModel2 = new sap.ui.model.json.JSONModel({ columns: aColsData });
            // this.getView().setModel(oColsModel2, "colModel2");

            if (!this._oTPC1) {
                this._oTPC1 = new TablePersoController({
                    table: this.byId("EmpDetailsTableID"),
                    componentName: "settings",
                    persoService: this._getPersoService("Table1Perso"),
                });
                // this._oTPC1.activate();
            }
            if (!this._oTPC2) {
                this._oTPC2 = new TablePersoController({
                    table: this.byId("customerAdvisoryID"),
                    componentName: "settings",
                    persoService: this._getPersoService("Table2Perso"),
                });
                // this._oTPC2.activate();
            }
            
       
        },
      
         // LocalStorage-based PersoService
        _getPersoService: function (sKey) {
            return {
                setFeatureColumnList: function (aColumnList) {
                    this.aColumnList = aColumnList;
                },
                getPersData: function () {
                    var oDeferred = new jQuery.Deferred();
                    if (!this._oBundle) {
                        this._oBundle = this.aColumnList;
                    }
                    var oBundle = this._oBundle;
                    oDeferred.resolve(oBundle);
                    return oDeferred.promise();
                },

                setPersData: function (oBundle) {
                    var oDeferred = new jQuery.Deferred();
                    this._oBundle = oBundle;
                    oDeferred.resolve();
                    return oDeferred.promise();

                },
                resetPersData: function () {
                    var oDeferred = new jQuery.Deferred();
                    var oInitialData = {
                        _persoSchemaVersion: "1.0",
                        aColumns: this.aColumnList
                    };
                    this._oBundle = oInitialData;
                    oDeferred.resolve();
                    return oDeferred.promise();
                }
            };
        },
          /**
        * Open ore resource table setting dialog
        * @function onSettingsPress
        */
          onSettingsPress: function () {
            //open table column settings dialog
            if (!this.pSettingsalueDialog) {
                this.pSettingsValueDialog = this.loadFragment({
                    name: "com.dealsupport.melodyrequest.fragments.filter.tableSettingDialog"
                });
            }
            this.pSettingsValueDialog.then(function (oSettingsValueDialog) {
                oSettingsValueDialog.open();
                this._settingsModelData = JSON.parse(JSON.stringify(this.getView().getModel("colModel").getData()));
                this._oSettingsValueDialog = oSettingsValueDialog;
            }.bind(this));
        },
            /**
        * Table setting dialog save
        * show/hide ore table columns
        * @function onApplyColumns
        */
        onApplyColumns: function () {
            let oList = this._oSettingsValueDialog.getContent()[0];
            let oBinding = oList.getBinding("items");
            oBinding.filter([]);
            var aSelected = this._oSettingsValueDialog.getContent()[0].getSelectedItems();
            let oDirectReportTable = this.byId("EmpDetailsTableID");
            let oCATable = this.byId("customerAdvisoryID");

            var oModel = this.getView().getModel("colModel");
            var aCols = oModel.getProperty("/columns");

            //for direct reportees
            aCols.forEach(function (col) {
                let sColumText = col.text;
                let aTableDRColumn = oDirectReportTable.getColumns().filter(tbl=> tbl.getMultiLabels()[0].getText() === sColumText);
                if(aTableDRColumn && aTableDRColumn.length){
                    aTableDRColumn[0].setVisible(false);
                }
                let aTableCAColumn = oCATable.getColumns().filter(tbl => tbl.getMultiLabels()[0].getText() === sColumText);
                if (aTableCAColumn && aTableCAColumn.length) {
                    aTableCAColumn[0].setVisible(false);
                }                
            });

            //for all candidates
            aSelected.forEach(function (item) {
                let sColumText = item.getBindingContext("colModel").getObject().text;
                let aTableDRColumn = oDirectReportTable.getColumns().filter(tbl=> tbl.getMultiLabels()[0].getText() === sColumText);
                if(aTableDRColumn && aTableDRColumn.length){
                    aTableDRColumn[0].setVisible(true);
                }
                let aTableCAColumn = oCATable.getColumns().filter(tbl => tbl.getMultiLabels()[0].getText() === sColumText);
                if (aTableCAColumn && aTableCAColumn.length) {
                    aTableCAColumn[0].setVisible(true);
                }       
            });

            this._oSettingsValueDialog.close();
        },
        /**
           *
           * Reset table setting selection
           * @function onToggleRefresh
           */
        onToggleRefresh: function () {
            this.getView().getModel("colModel").setProperty("/columns", this.aDefaultColumns);
            this.getView().getModel("colModel").refresh();
            this.aDefaultColumns = JSON.parse(JSON.stringify(this.getView().getModel("colModel").getProperty("/columns")));
        },
        /**
        *
        * sort table setting
        * @function onToggleSort
        */
        onToggleSort: function () {
            this._bSortDescending = !this._bSortDescending;
            var oList = this._oSettingsValueDialog.getContent()[0];
            var oBinding = oList.getBinding("items");

            // Apply sorter on "header" property
            var oSorter = new sap.ui.model.Sorter("text", this._bSortDescending);
            oBinding.sort(oSorter);

            // Also change the sort button icon to arrow up/down
            var oButton = this._oSettingsValueDialog.getCustomHeader().getContentRight()[0];
            if (this._bSortDescending) {
                oButton.setIcon("sap-icon://sort-descending");
            } else {
                oButton.setIcon("sap-icon://sort-ascending");
            }
        },
     
        /**
      
            * on select table setting column
            * @function onListSelectionChange
            */
        onListSelectionChange: function (oEvent) {
            const item = oEvent.getParameter("listItem");
            const id = item.getBindingContext("colModel").getObject().id

            if (id.includes("idOreManger") || id.includes("idOreEmpName") || id.includes("idOreEmpID") || id.includes("idOreReqMatch") || id.includes("idOreGrp")) {
                item.setSelected(true);
            }
        },
            /**
        * trigger for ore resource sort dialog list update
        * @function onListFilterUpdateFinished
        */
         onListFilterUpdateFinished: function () {
                const aItems = this._oSettingsValueDialog.getContent()[0].getItems();
                aItems.forEach(item => {
                    const id = item.getBindingContext("colModel").getObject().id
                    item.removeStyleClass("disableCheckbox");
                    if (id.includes("idOreManger") || id.includes("idOreEmpName") || id.includes("idOreEmpID") || id.includes("idOreReqMatch") || id.includes("idOreGrp")) {
                        //disable check box for manager,employee name,employee id and group 
                        item.addStyleClass("disableCheckbox");
                    }
                });
            },
                /**
        * Select Group
        * @param {obj} oEvent checkbox context
        * @function onSelectGroup
        */
        onSelectGroup: function (oEvent) {
            const oModel = this.getView().getModel("masterDataModel");
            const oSelectedGroup = oEvent.getSource().getBindingContext("grpHierarchyForFilter").getObject();
            oModel.setProperty("/TempEmployee/TempGroup", [oSelectedGroup]);
            this.getOwnerComponent().getModel("grpHierarchyForFilter").setProperty("/selectedGrpID", oSelectedGroup.id)
            oModel.refresh(true);
        },
        onDeleteGroupTokenForwardReq:function(oEvent){            						
			const oModel = this.getView().getModel("employee");
			const oTempEmployee = oModel.getProperty(`/TempEmployee`);
			const oParameters = oEvent.getParameters();
			if (oParameters.type === "removed") {
				oTempEmployee.SelectedGroup=[];
				this.getOwnerComponent().getModel("grpHierarchyForFilter").setProperty("/selectedGrpID","")
				oTempEmployee.TempGroup=[];
				this._setSearchFieldText();
				oModel.refresh(true);
			}
        },
            /**
        * Trigger after role filter input select
        * @function onRoleSelectFinished
        */
        onRoleSelectFinished:function(){
            this.getView().getModel("employee").setProperty("/filter/clearInputRoleFilter","");
        },
                 /**
        * Trigger after manager filter input select
        * @function onManagerSelectFinished
        */
        onManagerSelectFinished:function(){
            this.getView().getModel("employee").setProperty("/filter/clearInputManagerFilter","");
        },
        /**
         * trigger on click of show more action history
         * @function fnPressMoreActionHistoryList
         */
        fnPressMoreActionHistoryList: function () {
            this.getView().byId("idTimelineVAT").setForceGrowing(true);
            this.getView().byId("idTimelineVAT").setGrowingThreshold(1000);
            this.getView().byId("idTimelineVAT").setForceGrowing(false);
        },

    });
});