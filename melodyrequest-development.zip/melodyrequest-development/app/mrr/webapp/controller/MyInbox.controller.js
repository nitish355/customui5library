sap.ui.define([
	"sap/m/library",
	"sap/ui/core/mvc/Controller",
	"com/dealsupport/melodyrequest/model/models",
	"com/dealsupport/melodyrequest/model/users",
	"com/dealsupport/melodyrequest/model/formatter",
	"sap/ui/core/Fragment",
	"sap/m/MessageBox",
	'sap/ui/model/json/JSONModel',
	"sap/m/MessageToast",
	"sap/m/UploadCollectionParameter",
	"sap/ui/core/format/DateFormat",
	"sap/ui/core/library"
],
	function (mobileLibrary, Controller, models, users, formatter, Fragment, MessageBox, JSONModel, MessageToast, UploadCollectionParameter, DateFormat, library) {
		"use strict";
		var URLHelper = mobileLibrary.URLHelper;
		var workflowInstanceId,
			token,
			ValueState = library.ValueState;
		return Controller.extend("com.dealsupport.melodyrequest.controller.MyInbox", {
			formatter: formatter,
			onInit: function () {
				this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
			},
		

			});
	});