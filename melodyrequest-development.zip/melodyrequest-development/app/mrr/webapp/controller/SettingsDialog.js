sap.ui.define(['jquery.sap.global',
	'com/dealsupport/melodyrequest/controller/BaseController'
],
	function (jQuery, BaseController) {
		"use strict";

		var SettingsDialog = {
			setFeatureColumnList: function (aColumnList) {
				this.aColumnList = aColumnList;
			},
			getPersData: function () {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.aColumnList;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},

			setPersData: function (oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();

			},
			resetPersData: function () {
				var oDeferred = new jQuery.Deferred();
				var oInitialData = {
					_persoSchemaVersion: "1.0",
					aColumns: this.aColumnList
				};
				this._oBundle = oInitialData;
				oDeferred.resolve();
				return oDeferred.promise();
			}
		};

		return SettingsDialog;
	});