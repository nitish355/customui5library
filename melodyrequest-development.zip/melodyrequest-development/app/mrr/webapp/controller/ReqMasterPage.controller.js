var oHomePageView;
sap.ui.define([
	"sap/m/library",
	"sap/ui/core/mvc/Controller",
	"com/dealsupport/melodyrequest/model/models",
	"com/dealsupport/melodyrequest/model/users",
	"com/dealsupport/melodyrequest/model/formatter",
	"sap/ui/core/Fragment",
	"sap/m/MessageBox",
	'sap/ui/model/json/JSONModel',
	"sap/m/MessageToast",
	"sap/m/UploadCollectionParameter",
	"sap/ui/core/format/DateFormat",
	"sap/ui/core/library",
	"sap/m/ViewSettingsFilterItem",
	"sap/m/ViewSettingsItem",
	"sap/m/ViewSettingsCustomItem",
	"sap/m/DateRangeSelection",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
],
	function (mobileLibrary, Controller, models, users, formatter, Fragment, MessageBox, JSONModel, MessageToast, UploadCollectionParameter, DateFormat, library,ViewSettingsFilterItem,ViewSettingsItem,ViewSettingsCustomItem,DateRangeSelection,Filter,FilterOperator) {
		"use strict";
		var URLHelper = mobileLibrary.URLHelper;
		var workflowInstanceId,
			token,
			ValueState = library.ValueState;
		return Controller.extend("com.dealsupport.melodyrequest.controller.ReqMasterPage", {
			formatter: formatter,
			onInit: function () {
				this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
				oHomePageView = this;
				this.initialLoad = true;
				let oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
				let sDownTimeFlag = oAppConstantsModel.getProperty("/DownTime/0/Operational_Status");
				oAppConstantsModel.setProperty("/ReqMasterPage", this);
				let sLoggedInUser = this.getOwnerComponent().getModel("userDetails").getProperty("/email");
				this.sQueryParams =
							`/wf/V_WfInstance_Inbox?$count=true&$filter=(currentStateID eq 'WSUBMN' or currentStateID eq 'WIOAPP' or currentStateID eq 'WRESAP' or currentStateID eq 'REQSUB' or currentStateID eq 'REESUB' or currentStateID eq 'WMNAPP') and contains(CurrentProcessorEmail,'${sLoggedInUser}')`;
				if (sDownTimeFlag) {
					//enable dwontime page
					this.getOwnerComponent().getRouter().navTo("NotFound");
				} else {
					// models.getCurrentStateLists(this.fnCurrentStateSuccessCallback, this.fnCurrentStateErrorCallback, this);
					if (this.getOwnerComponent().getRouter()["oHashChanger"]["hash"].includes("/ReqDetailPage/")) {
						this.onSelectMyRequestTab();
					} else {
						// models.getPendingCurrentStateLists(this.fnCurrentPendingStateSuccessCallback, this.fnCurrentStateErrorCallback, this);
						// const acurrStateModel = this.getOwnerComponent().getModel("currentStateModel").getData().value;
						// const oFilterCurrState = acurrStateModel.filter(item => item.Technical_state === "inProcess");
						// let oFilterData = new sap.ui.model.json.JSONModel();
						// oFilterData.setData({
						// 	value: oFilterCurrState
						// });
						// this.getView().setModel(oFilterData, "pendingCurrentStateModel");
						// this._fetchAPICalls(true);
					}
					if (this.getOwnerComponent().getRouter().getRoute("MyInbox")) {
						this.getOwnerComponent().getRouter().getRoute("MyInbox").attachPatternMatched(this._onObjectMatched, this);
					}
					if (this.getOwnerComponent().getRouter()["oHashChanger"]["hash"].includes("HomePage/")) {
						this._fetchAPICalls(true);
					}
				}

			},
			_fetchAPICalls: function (bInitialLoad) {
				sap.ui.core.BusyIndicator.show(0);
				this.sSortQqueryPrams = `&$orderby=DTLastActivity_tdate desc,DTLastActivity_ttime desc`;
				let skip = 0;
				let top = 20;
				this.sFinalQueryParams = `${this.sQueryParams}${this.sSortQqueryPrams}`;
				this._alreadyLoadedCount = 20;
				//get i18n texts
				let i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				let sNoPendingRequestsText = i18nModel.getText("noPendingRequestsText");
				this.getView().byId("id-list-pendingRequests").setNoDataText(sNoPendingRequestsText);
				//call wf instance service
				let sUrlInstanceId;
				if (this.getOwnerComponent().getRouter().getRoute("ReqDetailPage")._oRouter.oHashChanger["hash"].split('/').length === 3 && this.initialLoad) {
					sUrlInstanceId = this.getOwnerComponent().getRouter().getRoute("ReqDetailPage")._oRouter.oHashChanger["hash"].split('/')[2];
					this.sFinalQueryParams = `${this.sQueryParams}${this.sSortQqueryPrams}`;
				}
				sap.ui.core.BusyIndicator.show();
					models.getInboxWfInstanceFilterLists(this.fnSuccessFilterCallback, this.fnErrorFilterCallback, this, this.sFinalQueryParams, sUrlInstanceId, skip, top);
			},
			onSelectMyRequestTab: function () {
				//select Master pag Tabs ( My Requests & My Pending Requests)
				let sLoggedInUser = this.getOwnerComponent().getModel("userDetails").getProperty("/email");
				let sLoggedInUserId = this.getOwnerComponent().getModel("userDetails").getProperty("/user_name").toUpperCase();
					this.sQueryParams =
							`/wf/V_WfInstance_Inbox?$count=true&$filter=(currentStateID eq 'WSUBMN' or currentStateID eq 'WRESAP' or currentStateID eq 'WIOAPP' or currentStateID eq 'REQSUB' or currentStateID eq 'REESUB' or currentStateID eq 'WMNAPP') and contains(CurrentProcessorEmail,'${sLoggedInUser}')`;
				
				this._fetchAPICalls();
				this._onResetFilter();
			},
					/**
			 * Git 274- Opentask filter
			 * This will trigger while routing to open task and on refresh
			 * Reset filter
			 * @function onResetFilter
			 **/
			onResetFilter: function () {
				this._onResetFilter();
				this._alreadyLoadedCount = 20;
				let sLoggedInUser = this.getOwnerComponent().getModel("userDetails").getProperty("/email");
				if (this._oSortDialog) {
					this._oSortDialog._getResetButton().firePress()
				}
				this.sQueryParams =
						`/wf/V_WfInstance_Inbox?$count=true&$filter=(currentStateID eq 'WSUBMN' or currentStateID eq 'WRESAP' or currentStateID eq 'WIOAPP' or currentStateID eq 'REQSUB' or currentStateID eq 'REESUB' or currentStateID eq 'WMNAPP') and contains(CurrentProcessorEmail,'${sLoggedInUser}')`;
				this._fetchAPICalls();

			},
			onUpdateStartedGrowingTable: function (oEvent) {
				//Pagination in the Worklist page
				let sUrlInstanceId;
				let bInstanceIdExist;
				const oList = oEvent.getSource();
				const oPendingRequestsData = this.getView().getModel("pendingReqModel").getData();
				if (oPendingRequestsData) {
					if (this.getOwnerComponent().getRouter().getRoute("ReqDetailPage")._oRouter.oHashChanger["hash"].split('/').length === 3 && this.initialLoad) {
						sUrlInstanceId = this.getOwnerComponent().getRouter().getRoute("ReqDetailPage")._oRouter.oHashChanger["hash"].split('/')[2];
						bInstanceIdExist = oPendingRequestsData.value.filter(req => req.InstanceID === sUrlInstanceId);
					}
					const iTotalLen = oPendingRequestsData.count;
					if (iTotalLen !== null && iTotalLen !== undefined && iTotalLen > 10) {
						//Setting the value for iBindingLength = oBinding.getLength() which is the total count of items.
						oList.getBindingInfo("items").binding.iLength = iTotalLen;
						if (oList.getGrowingInfo().actual === this._alreadyLoadedCount && oList.getGrowingInfo().actual <
							iTotalLen && oEvent.getParameter("reason") === "Growing") {
							pendingRequests = true;
							this._requestAndAppendMoreLists(this._alreadyLoadedCount);
						}
					}
				}
			},
				/**
			 * Git 274- Opentask filter
			 * Reset all the open task filter
			 * @function _onResetFilter
			 **/
			_onResetFilter: function () {
				//reset search value
				this.getView().byId("idOpenTaskSearch").setValue("");
				if (this._inboxFilterDialog) {
					this.getView().byId("idInfoToolOpenTask").setVisible(false)
					let aFilterItems = this._inboxFilterDialog.getFilterItems();
					aFilterItems.forEach(function (item) {
						if (item.getKey() === "RequestSubmissionDate") {
							//reset request submission date fiels
							item.getCustomControl().setDateValue(null);
							item.getCustomControl().setSecondDateValue(null)
							item.setFilterCount(0); // dynamically set count
						}
					});
					//reset all filter items
					this._inboxFilterDialog.destroyFilterItems();
					this._filterStartDate = false;
					this._filterEndDate = false;
					this._pFilterDialog = false;
				}
			},
			_onObjectMatched: function (evt) {
				try {
					if (evt.getParameter("arguments")["?query"]) {
						//set routing
						appView.harmMonyQuery = evt.getParameter("arguments")["?query"];
						let oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
						oAppConstantsModel.setProperty("/harmonyQuery",appView.harmMonyQuery);
						appView.getView().setBusy(true);
					}
				} catch (error) {

				}
				// SANITIZE
				let sLoggedInUser = this.getOwnerComponent().getModel("userDetails").getProperty("/email");
				this.sQueryParams =
						`/wf/V_WfInstance_Inbox?$count=true&$filter=(currentStateID eq 'WSUBMN' or currentStateID eq 'WRESAP' or currentStateID eq 'WIOAPP' or currentStateID eq 'REQSUB' or currentStateID eq 'REESUB' or currentStateID eq 'WMNAPP') and contains(CurrentProcessorEmail,'${sLoggedInUser}')`;
				this._fetchAPICalls(true);

				if (this._inboxFilterDialog) {
					this._onResetFilter();
				}
				if (this._oSortDialog) {
					this._oSortDialog._getResetButton().firePress()
				}
				this.aFilters = [];
				this.initialLoad = false;
				appView._setSelectedMenuKey();
			},
			fnCurrentStateSuccessCallback: function (oResult, self) {
				//initiate current state model
				self.getOwnerComponent().getModel("currentStateModel").setData(oResult);
				sap.ui.core.BusyIndicator.hide();
			},
			fnCurrentPendingStateSuccessCallback: function (oResult, self) {
				//initiate current state (Pending) model
				let oModel = new sap.ui.model.json.JSONModel();
				oModel.setData(oResult);
				self.getView().setModel(oModel, "pendingCurrentStateModel");
				sap.ui.core.BusyIndicator.hide();
			},
			fnCurrentStateErrorCallback: function (oError, self) {
				MessageBox.error(oError.responseText, {
					contentWidth: "600px"
				});
				sap.ui.core.BusyIndicator.hide();
			},
			fnSuccessCountCallback: function (oResult, self) {
				//set count for tabs
				oResult.count = oResult["@odata.count"];
				let oModel = new sap.ui.model.json.JSONModel();
				let oCount = {}
				if (self.sQueryParams.includes("EmpRequester_ID")) {
					oCount.pendingReqCount = oResult.count;
					oCount.MyReqCount = self.count;
				} else {
					oCount.pendingReqCount = self.count;
					oCount.MyReqCount = oResult.count;
				}
				oModel.setData(oCount);
				self.getOwnerComponent().setModel(oModel, "countModel");
				self.getOwnerComponent().getModel("appConstants").setProperty("/openTaskCount", oCount.pendingReqCount);
				self.getOwnerComponent().getModel("appConstants").setProperty("/pendingReqCount", oCount.pendingReqCount);
			},
			fnSuccessFilterCallback: function (oResult, self, bInitialLoad) {
				let oModel = new sap.ui.model.json.JSONModel();
				oModel.setSizeLimit(99999); 
				sap.ui.core.BusyIndicator.hide();
				let isInstanceIDMatch;
				if (!self.sSortQqueryPrams) {
					self.sSortQqueryPrams = `&$orderby=DTLastActivity_tdate desc,DTLastActivity_ttime desc`;
				}
				oResult.count = oResult["@odata.count"];
				self.count = oResult.count;
				oModel.setData(oResult);
				let sLoggedInUser = self.getOwnerComponent().getModel("userDetails").getProperty("/email");
				let sLoggedInUserId = self.getOwnerComponent().getModel("userDetails").getProperty("/user_name").toUpperCase();
				if (self.sQueryParams.includes("EmpRequester_ID")) {
					//initiate api call url for 'Pending Requests' Tab
					self.sCountQueryParams =
						`/wf/V_WfInstance_Inbox?$count=true&$filter=(currentStateID eq 'WSUBMN' or currentStateID eq 'WRESAP' or currentStateID eq 'WIOAPP' or currentStateID eq 'REQSUB' or currentStateID eq 'REESUB' or currentStateID eq 'WMNAPP') and contains(CurrentProcessorEmail,'${sLoggedInUser}')`;
				} else {
					//initiate api call url for 'My Requests' Tab
					self.sCountQueryParams = `/wf/V_WfInstance_Inbox?$count=true&$filter=EmpRequester_ID eq '${sLoggedInUserId}'`;
				}
				self.sFinalCountQueryParams = `${self.sCountQueryParams}${self.sSortQqueryPrams}`;
				let sUrlInstanceId;
				if (self.getOwnerComponent().getRouter().getRoute("ReqDetailPage")._oRouter.oHashChanger["hash"].split('/').length === 3 && self.initialLoad) {
					sUrlInstanceId = self.getOwnerComponent().getRouter().getRoute("ReqDetailPage")._oRouter.oHashChanger["hash"].split('/')[2];
				}
				self.getOwnerComponent().setModel(oModel, "pendingReqModel");
				//models.getInboxWfInstanceFilterLists(self.fnSuccessCountCallback, self.fnErrorFilterCallback, self, self.sFinalCountQueryParams);
              try{
				if (appView.sInstanceID) {
					self.sQueryParams =
						`/wf/V_WfInstance_Inbox?$count=true&$filter=(currentStateID eq 'WSUBMN' or currentStateID eq 'WRESAP' or currentStateID eq 'WIOAPP' or currentStateID eq 'REQSUB' or currentStateID eq 'REESUB' or currentStateID eq 'WMNAPP') and contains(CurrentProcessorEmail,'${sLoggedInUser}')`;
					oResult.value.forEach(function (item) {
						if (appView.sInstanceID === item.InstanceID) {
							isInstanceIDMatch = true;
						}
					});
					if (!isInstanceIDMatch) {
						self._fetchAPICalls(true);
					} else {
						if (!sUrlInstanceId) {
							self.onListItemPress(false, bInitialLoad);
						}
						if (self.getOwnerComponent().getModel("pendingReqModel").getData().value.length) {
							let sInstanceID = self.getOwnerComponent().getModel("pendingReqModel").getData().value[0].InstanceID;
							//self.setDetailPageData(sInstanceID);
						}
						sap.ui.core.BusyIndicator.hide();
					}
				} else {
					if (!sUrlInstanceId) {
						self.onListItemPress(false, bInitialLoad);
					}
					if (self.getOwnerComponent().getModel("pendingReqModel").getData().value.length) {
						let sInstanceID = self.getOwnerComponent().getModel("pendingReqModel").getData().value[0].InstanceID;
						//self.setDetailPageData(sInstanceID);
					}
					sap.ui.core.BusyIndicator.hide();
				}
			}catch(err){
				
			}

			
			},

			fnSuccessCallback: function (oResponse, self) {
				let oModel = new sap.ui.model.json.JSONModel();
				oModel.setData(oResponse.value[0]);
				self.getView().setModel(oModel, "wfInstanceModel");
				self.getView().getModel("wfInstanceModel").refresh();
				sap.ui.core.BusyIndicator.hide();
			},
			fnErrorCallback: function (oError, self) {
				MessageBox.error(oError.responseText, {
					contentWidth: "600px"
				});
				sap.ui.core.BusyIndicator.hide();
			},
			fnErrorFilterCallback: function (oError, self) {
				sap.ui.core.BusyIndicator.hide();
				if (oError.responseText) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.warning(oError.responseText, {
					});
					if (JSON.parse(oError.responseText).error.code === '403') {
						self.getView().byId("DynamicSideContent").setVisible(false);
					}
				} else {
					MessageBox.error("Something went wrong", {
					});
					self.getView().byId("DynamicSideContent").setVisible(false);
				}
			},

			handleEmailPress: function (evt) {
				URLHelper.triggerEmail(this._getVal(evt), "Info Request - MRR", false, false, false, true);
			},
			handleGuidePress: function () {
				URLHelper.redirect('https://sap.sharepoint.com/sites/113849/SitePages/MRR-User%20Guide.aspx', true);
			},
			_getVal: function (evt) {
				return evt.getSource().getProperty("text");
			},

			fnSuccessUrl: function (data, self) {
				let sUrl = data.value[2].Value;
				URLHelper.redirect(sUrl, "_blank");
			},
			fnErrorUrl: function (data, self) {

			},

			getGroup: function (oContext) {
				let sKey = oContext.getProperty("ParentInstanceID");
				let sCreationDate = oContext.getProperty("DTLastActivity_tdate");
				const sCreationTime = oContext.getProperty("DTLastActivity_ttime");
				let formattedDate = formatter.formatDate(sCreationDate, sCreationTime);
				let sOpportunityID = oContext.getProperty("OpportunityID");
				let sAccountID = oContext.getProperty("Account_ID");
				let sRequestType = oContext.getProperty("RequestType");
				let sReferenceId = oContext.getProperty("RefrenceID") ? `#${oContext.getProperty("RefrenceID")}` : sKey;
				let sTitle = this._setGroupHeaderTitle(sRequestType, sOpportunityID, sAccountID, formattedDate);
				return {
					key: sReferenceId,
					title: sTitle
				};
			},
			_setGroupHeaderTitle: function (sRequestType, sOpportunityID, sAccountID, formattedDate) {
				//set master data group header
				let sTitle;
				switch (sRequestType) {
					case 'Opportunity':
						sTitle = `${formattedDate} - Opportunity ${sOpportunityID}`;
						break;
					case 'Account':
						sTitle = `${formattedDate} - Account ${sAccountID}`;
						break;
					default:
						sTitle = `Grouping not available`;
				}
				return sTitle;
			},
			getGroupHeader: function (oGroup) {
				const sCount = oGroup.key.includes("#") ? oGroup.key:"";
				return new sap.m.GroupHeaderListItem({
					title: oGroup.title,
					upperCase: false,
					count:sCount
				});
			},
			findItemByInstanceId: function (sInstanceID) {
				let oBindingContext;
				const oList = this.getView().byId("id-list-pendingRequests");
				const aItems = oList.getItems();
				let result = [];
				if (aItems.length) {
					result = jQuery.grep(aItems, function (oItem) {
						oBindingContext = oItem.getBindingContext("pendingReqModel");
						if (oBindingContext && oBindingContext.getObject().InstanceID === sInstanceID) {
							return true;
						}

					});
				}
				return result[0] || null;
			},
			setListItem: function (oItem) {
				const oList = this.getView().byId("id-list-pendingRequests");
				oList.removeSelections();
				oItem.setSelected(true);
				oItem.focus();
				oList.setSelectedItem(oItem, true);
			},
			onListItemPress: function (oEvent, bInitialLoad) {
				//select master data list
				let oItem;
				let oContextObject;
				const oPendingModel = this.getOwnerComponent().getModel("pendingReqModel");
				if (this.getOwnerComponent().getRouter().getRoute("ReqDetailPage")._oRouter.oHashChanger["hash"].split('/').length === 3 && bInitialLoad) {
					this.urlInstanceId = this.getOwnerComponent().getRouter().getRoute("ReqDetailPage")._oRouter.oHashChanger["hash"].split('/')[2]
				} else {
					this.urlInstanceId = false;
				}
				if (oEvent) {
					oItem = oEvent.getSource();
					oContextObject = oItem.getSelectedContexts("pendingReqModel")[0].getObject()
				} else if (bInitialLoad && !this.urlInstanceId) {
					oContextObject = oPendingModel.getData().value[0];
				} else {
					if (!this.urlInstanceId) {
						oContextObject = oPendingModel.getData().value[0];
					} else {
						for (let i = 0; i < oPendingModel.getData().value.length; i++) {
							if (oPendingModel.getData().value[i].InstanceID === this.urlInstanceId) {
								oContextObject = oPendingModel.getData().value[i];
							}
						}
					}

				}
				const oRouter = this.getOwnerComponent().getRouter();
				this.urlInstanceId = false;
				const sRoute = this._setDetailPageRoute(oContextObject)
				if (oContextObject) {
					this.getOwnerComponent().getModel("wfInstanceModel").setData(oContextObject);
					this.getOwnerComponent().getModel("wfInstanceModel").refresh();
					oRouter.navTo(sRoute, {
						ID: oContextObject.InstanceID
					});
				} else {
					oRouter.navTo(sRoute);
				}
			},
			onAfterRendering :function(){
				if(this.getOwnerComponent().getModel("appConstants").getProperty("/harmonyQuery")){
					//harmony routing
					appView.onOpenCreateReqDialog("", this.getOwnerComponent().getModel("appConstants").getProperty("/harmonyQuery"), true);
					this.getOwnerComponent().getModel("appConstants").setProperty("/harmonyQuery",false)
					this.getOwnerComponent().getModel("userDetails").setProperty("/OpportunityOperationalStatus", true);
				}
			},
			_setDetailPageRoute: function (oContextObject) {
				const sLoggedInUser = this.getOwnerComponent().getModel("userDetails").getProperty("/email");
				let sFinalRoute,
					sRoutePath;
				if (oContextObject) {
					const isCurrentProcesser = formatter.formatUrl(oContextObject.CurrentProcessorEmail, sLoggedInUser, oContextObject.TechnicalState, oContextObject.currentStateID);
					if (!isCurrentProcesser && !((oContextObject.currentStateID === "REESUB" || oContextObject.currentStateID === "REQSUB") && oContextObject.CurrentProcessorEmail === sLoggedInUser)) {
						sFinalRoute = "ReqDetailPage";
						sRoutePath = "ReqDetailPage";
					} else {
						switch (oContextObject.currentStateID) {
							case "REQSUB":
								sFinalRoute = "SubmitReqDetailPage";
								sRoutePath="SubmitReq";
								break;
							case "REESUB":
								sFinalRoute = "SubmitReqDetailPage";
								sRoutePath="SubmitReq";
								break;
							case "WMNAPP":
								sFinalRoute = "ManagerDetailPage";
								sRoutePath="ManagerDetailPage";
								break;
							case "WSUBMN":
								sFinalRoute = "ManagerDetailPage";
								sRoutePath="ManagerDetailPage";
								break;
							case "WRESAP":
								sFinalRoute = "ManagerDetailPage";
								sRoutePath="ManagerDetailPage";
								break;
							case "WIOAPP":
								sFinalRoute = "IOOwnerDetailPage";
								sRoutePath="IOOwnerDetailPage";
								break;
							default:
								sFinalRoute = "ReqDetailPage";
								sRoutePath="ReqDetailPage";
								break;
						}
					}
				} else {
					sFinalRoute = "ReqDetailPage";
					sRoutePath="ReqDetailPage";
				}
				this.getOwnerComponent().getModel("appConstants").setProperty("/routePath",sRoutePath);
				this.getOwnerComponent().getModel("appConstants").refresh();
				return sFinalRoute;
			},

			onUpdateFinished: function (oEvent) {
				//file uploader update

				oEvent.oSource.rerender();
				if (this.getView().byId("id-list-pendingRequests").getGrowing()) {
					let sUrlInstanceId;
					//this.getView().byId("id-list-pendingRequests").setGrowing(true);

					//this.getView().byId("id-list-pendingRequests").setGrowingScrollToLoad(true);
					//this.onUpdateStartedGrowingTable(oEvent);
					this.initialLoad = false;
				}
				const sUrlInstanceId = this.getOwnerComponent().getRouter().getRoute("ReqDetailPage")._oRouter.oHashChanger["hash"].split('/')[2];
				const oItem = this.findItemByInstanceId(sUrlInstanceId);
				if (oItem) {
					//this.getView().byId("id-list-pendingRequests").setGrowingThreshold(20)
					this.initialLoad = false;
					const oList = this.getView().byId("id-list-pendingRequests");
					oList.removeSelections();
					oList.setSelectedItem(oItem);
					oItem.setSelected(true);
					oItem.focus();
					this.getView().byId("id-list-pendingRequests").getParent().scrollTo(oItem);
					oList.setSelectedItem(oItem, true);
					//this.getView().byId("id-list-pendingRequests").setGrowing(true);
					this.getOwnerComponent().getModel("pendingReqModel").getData().value.length;
					this._alreadyLoadedCount = this.getOwnerComponent().getModel("pendingReqModel").getData().value.length
					//this.getView().byId("id-list-pendingRequests").setGrowingScrollToLoad(true);
					this.getOwnerComponent().getModel("pendingReqModel").refresh();
					oEvent.oSource.rerender();

				}
			},

			_requestAndAppendMoreLists: function (sAlreadyLoadedTenantCount) {
				//To load more data ( pagination )
				let iSkip = parseInt(sAlreadyLoadedTenantCount, [10]);
				let iTop = 20;
				var that = this;
				let workflowBaseurl = models._getWfServiceRuntimeBaseURLRoleBased(this);
				if (!this.sSortQqueryPrams) {
					this.sSortQqueryPrams = `&$orderby=DTLastActivity_tdate desc,DTLastActivity_ttime desc`;
				}
				this.sFinalQueryParams = `${this.sQueryParams}${this.sSortQqueryPrams}`;

				jQuery.ajax({
					async: false,
					contentType: "application/json",
					url: `${workflowBaseurl}${this.sFinalQueryParams}&$skip=${iSkip}&$top=${iTop}`,
					type: "GET",
					success: function (oData) {
						that._alreadyLoadedCount = oData.value.length + iSkip;
						let oModel = that.getOwnerComponent().getModel("pendingReqModel");
						oData.count = oData["@odata.count"];
						let aWfHistoryLists = oModel.getData().value.concat(oData.value);
						oModel.setData({
							"count": oData.count,
							"value": aWfHistoryLists
						}, true);
						that._closeBusyIndicator(that);

					}.bind(this),
					error: function (oError) {
						that._closeBusyIndicator(that);
						MessageBox.error(oError.responseText, {
							contentWidth: "600px"
						});
						sap.ui.core.BusyIndicator.hide();
						return false;
					}
				});

			},
			_closeBusyIndicator: function (self) {
				let oTable = self.getView().byId("id-list-pendingRequests");
				oTable.setBusy(false);

			},
			onSearch: function (oEvent) {
				// SANITIZE
				let sLoggedInUser = this.getOwnerComponent().getModel("userDetails").getProperty("/email");
				this._alreadyLoadedCount = 20;
				let sQuery = oEvent ? oEvent.getParameter('query') : "";
					this.sQueryParams =
						`/wf/V_WfInstance_Inbox?$count=true&$filter=(currentStateID eq 'WSUBMN' or currentStateID eq 'WRESAP' or currentStateID eq 'WIOAPP' or currentStateID eq 'REQSUB' or currentStateID eq 'REESUB' or currentStateID eq 'WMNAPP') and contains(CurrentProcessorEmail,'${sLoggedInUser}')&$search=${sQuery}`;
				this._fetchAPICalls();

			},
				/**
			 * Git 274- Opentask filter
			 * Open task search
			 * @function onSearchTasks
			 * @param {object} oEvent - control scope
			 **/
			onSearchTasks: function (oEvent) {
				// Get search query
				let sQuery = oEvent.getParameter("query");
				// Get list binding
				let oList = this.getView().byId("id-list-pendingRequests");
				let oBinding = oList.getBinding("items");
				let that = this;

				//oBinding.filter([]);
					this.aFilters = this.aFilters ?  this.aFilters: [];
				if (sQuery) {
					//if value present
					// Build filter array
					if (sQuery && sQuery.length > 0) {
						let oFilterOppId = new Filter(
							"OpportunityID",
							FilterOperator.Contains,
							sQuery
						);
						let oFilterOppDesc = new Filter(
							"OpportunityDesc",
							FilterOperator.Contains,
							sQuery
						);
						let oFilterAccountDesc = new Filter(
							"Account_name",
							FilterOperator.Contains,
							sQuery
						);
						let oFilterAccountId = new Filter(
							"Account_ID",
							FilterOperator.Contains,
							sQuery
						);
						let oFilterIndustry = new Filter(
							"BA_Industry_Desc",
							FilterOperator.Contains,
							sQuery
						);
						let oFilterProfitCenter = new Filter(
							"orgName",
							FilterOperator.Contains,
							sQuery
						);
						let oFilterRoleArea = new Filter(
							"Role_Desc",
							FilterOperator.Contains,
							sQuery
						);
						let oFilterSolution = new Filter(
							"Solution_Desc",
							FilterOperator.Contains,
							sQuery
						);
						let oFilterRefId = new Filter(
							"RefrenceID",
							FilterOperator.Contains,
							sQuery
						);
						let oRequestorName = new Filter(
							"RequestorName",
							FilterOperator.Contains,
							sQuery
						);
						let oSearchGlobal = new Filter(
							"searchGlobal",
							FilterOperator.Contains,
							sQuery
						);


						// OR filter 
						this.aFilters.push(new Filter({
							filters: [oFilterOppId, oFilterOppDesc,oFilterAccountDesc,oFilterAccountId,oFilterIndustry,oFilterProfitCenter,
								oFilterRoleArea,oFilterSolution,oRequestorName,oSearchGlobal
							],
							and: false
						}));
					}

					// Apply filter to list binding
					oBinding.filter(this.aFilters);
					//set default list selection
					this._onSetDefaultSelection();
				} else if(oEvent.getParameter("refreshButtonPressed")){
					this.aFilters = [];
					this.getView().byId("idInfoToolOpenTask").setVisible(false);
					if (this._inboxFilterDialog) {
						this._inboxFilterDialog.destroyFilterItems();
						let aFilterItems = this._inboxFilterDialog.getFilterItems();
						aFilterItems.forEach(function (item) {
							if (item.getKey() === "RequestSubmissionDate") {
								//reset date filter only search
								item.getCustomControl().setDateValue(null);
								item.getCustomControl().setSecondDateValue(null)
								item.setFilterCount(0); // dynamically set count
							}
						});
						//reset open task filter
						this._inboxFilterDialog.destroyFilterItems();
						this._filterStartDate = false;
						this._filterEndDate = false;
						this._pFilterDialog = false;

					}
					//If no value reset and get the updated open taks
					if(this._oSortDialog ){
						this._oSortDialog._getResetButton().firePress()
					}
					this._alreadyLoadedCount = 20;
					//SANITIZE
					let sLoggedInUser = this.getOwnerComponent().getModel("userDetails").getProperty("/email");
					this.sQueryParams =
						`/wf/V_WfInstance_Inbox?$count=true&$filter=(currentStateID eq 'WSUBMN' or currentStateID eq 'WRESAP' or currentStateID eq 'WIOAPP' or currentStateID eq 'REQSUB' or currentStateID eq 'REESUB' or currentStateID eq 'WMNAPP') and contains(CurrentProcessorEmail,'${sLoggedInUser}')&$search=${sQuery}`;
					this._fetchAPICalls();
				}else if(!sQuery){
					this.aFilters.forEach(function (item, iIndex) {
						if (item.aFilters) {
							let bSearch = !!(item.aFilters.filter(val => val.getPath() === "searchGlobal").length)
							if (bSearch) {
								that.aFilters.splice(iIndex, 1);
							}
						}
					})
					oBinding.filter(this.aFilters);
						//set default list selection
					this._onSetDefaultSelection();

				}
			},
				/**
			 * Git 274- Opentask filter
			 * Set Open task master list default selection
			 * @function _onSetDefaultSelection
			 **/
			_onSetDefaultSelection: function () {
				let oList = this.getView().byId("id-list-pendingRequests");
				let oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
				const oRouter = this.getOwnerComponent().getRouter();
				oAppConstantsModel.setProperty("/pendingReqCount", oList.getBinding("items").getLength());
				if (oList.getItems().length) {
					oList.setSelectedItem(oList.getItems([0]), true);
					oList.getItems()[0].setSelected(true);
					let oContextObject = oList.getItems()[0].getBindingContext("pendingReqModel").getObject();
					//set detail page routing for the default selection
					let sRoute = this._setDetailPageRoute(oContextObject)
					if (oContextObject) {
						this.getOwnerComponent().getModel("wfInstanceModel").setData(oContextObject);
						this.getOwnerComponent().getModel("wfInstanceModel").refresh();
						oRouter.navTo(sRoute, {
							ID: oContextObject.InstanceID
						});
					} else {
						oRouter.navTo(sRoute);
					}
				} else {
					//route to detail page
					oRouter.navTo("ReqDetailPage");
				}
			},
				/**
			 * Git 274- Opentask filter
			 * OPEN Open task filter dialog
			 * @function onFilterMyInbox
			 **/
			onFilterMyInbox: function () {
				// create filter dialog
				let oView = this.getView();
				let that = this;
				this.getView().setModel(new sap.ui.model.json.JSONModel(), "oOpenTaskFilterModel");
				if (!this._pFilterDialog) {
					this._pFilterDialog = Fragment.load({
						id: oView.getId(),
						name: "com.dealsupport.melodyrequest.fragments.MyInboxFilter",
						controller: this
					}).then(function (oFilterDialog) {
						oFilterDialog.addStyleClass(that.getOwnerComponent().getContentDensityClass());
						oView.addDependent(oFilterDialog);
						that._inboxFilterDialog = oFilterDialog;					
						return oFilterDialog;
					});		
				}

				this._pFilterDialog.then(function (oFilterDialog) {
					if (!oFilterDialog.getFilterItems().length) {
						//set filter master data based on open task
						that._setFilterTransactionData();
						//Dynamically create open task filter dialog
						that._createMyInboxControl(oFilterDialog);
					}	
					oFilterDialog.open();
				});

			},
				/**
			 * Git 274- Opentask filter
			 * Set open task filter master data
			 * @function _setFilterTransactionData
			 **/
			_setFilterTransactionData: function () {
				//map open task filter master data
				const oOpenTaskFilter = {
					Account: this._mapFilterData("Account_name"),
					Opportunity: this._mapFilterData("OpportunityID"),
					RequestorName: this._mapFilterData("EmpRequester_Name"),
					Req_ID: this._mapFilterData("RefrenceID"),
					ReqIndustry: this._mapFilterData("BA_Industry_Desc"),
					ReqProfitCenter: this._mapFilterData("orgName"),
					ReqRole: this._mapFilterData("Role_Desc"),
					ReqSolution: this._mapFilterData("Solution_Desc")
				}
				this.getView().getModel("oOpenTaskFilterModel").setData(oOpenTaskFilter);
				this.getView().getModel("oOpenTaskFilterModel").setSizeLimit(99999);  
			},
			/**
			 * Git 274- Opentask filter
			 * map open task filter master data
			 * @param {String} sProperty - open task filter property
			 * @function _mapFilterData
			 **/
			_mapFilterData: function (sProperty) {
				const oOpenTaskModelData = this.getView().getModel("pendingReqModel").getData().value;
				let aModelDataFinal;
			if(sProperty === "Role_Desc"){
				const seen = new Set();
				aModelDataFinal = oOpenTaskModelData
					.flatMap(item => {
						if (!item.Role_Desc) return [];

						return item.Role_Desc.split(";").map(role => role);
					})
					.filter(role => {
						const key = role.trim();
						if (seen.has(key)) return false;
						seen.add(key);
						return true;
					})
					.map(role => ({
						key: role.trim(),
						text: role.trim()
					}));
			}else{
				 aModelDataFinal =  oOpenTaskModelData.map(item => {
					// Create a new object to avoid mutating the original
					return {
						key: item[sProperty] ?  item[sProperty].toString().trim():"",
						text: item[sProperty] ? item[sProperty].toString().trim():""
					};
				}).filter((obj, index, self) =>
					index === self.findIndex((o) =>o["text"] && o["text"] === obj["text"])
				);
			}
				if (sProperty === 'RefrenceID') {
					//sort ref id master data from latest to oldest (descending)
					return aModelDataFinal.sort((a, b) => Number(b.text) - Number(a.text));
				} else if (sProperty === 'OpportunityID') {
					//sort opp id master data(ascending)
					return aModelDataFinal.sort((a, b) => Number(a.text) - Number(b.text));
				} else {
					//sort other field alphabetically
					return aModelDataFinal.sort((a, b) => a.text.localeCompare(b.text))
				}
			},
				/**
			 * Git 274- Opentask filter
			 * Create open task filter list dynamically
			 * @function _createMyInboxControl
			 * @param {object} oFilterDialog - open task filter dialog scope
			 **/
			_createMyInboxControl: function (oFilterDialog) {
				let oMRConfigModel = this.getOwnerComponent().getModel("MRLabelConfigModel"),
					oOpenTaskConifg = oMRConfigModel.getData().filter(item => item.typeDesc === "OpenTaskFilter"),
					 that = this;
				oOpenTaskConifg.sort((a, b) => {
					return a.fieldID.localeCompare(b.fieldID); 
				});
				/**
				 * @function addControl
				 * add open task filter dynamically
				 * @param {string} isActive - filter field active or not (config)
				 * @param {string} fieldDesc - filter label (config)
				 * @param {string} fieldID - filter fieldId for mapping(config)
				 * @param {string} sPath - open task filter property
				 * **/
				function addControl(isActive, fieldDesc, fieldID, sPath) {
					if (isActive) {
						//create control only for active field
						let oViewSettingControl;
						if (fieldID !== "RequestSubmissionDate") {
							//create standarad view setting filter item for all field except RequestSubmission
							oViewSettingControl = new ViewSettingsFilterItem({
								text: fieldDesc,
								key: fieldID,
								items: that.getView().getModel("oOpenTaskFilterModel").getProperty(`/${sPath}`)
							});
							//bind viewsetting items
							oViewSettingControl.bindAggregation("items", {
								path: that.getView().getModel("oOpenTaskFilterModel").getProperty(`/${sPath}`),
								factory: function (sId, oContext) {
									return new ViewSettingsItem({
										key: oContext.getProperty("key"),
										text: oContext.getProperty("text")
									});
								}
							});
						} else {
							//create custom view setting item ( daterage field) for request submission
							oViewSettingControl = new ViewSettingsCustomItem({
								text: fieldDesc,
								key: fieldID,
								customControl: new DateRangeSelection({
									width: "300px",
									change:function(oEvent){
										/**
										 * @function formatDateToYYYYMMDD
										 * convert date in to mm-dd-yyy format
										 * @param {object} oDate - date object
										 * **/
										function formatDateToYYYYMMDD(oDate) {
											let yyyy = oDate.getFullYear();
											let mm = oDate.getMonth() + 1; // Months are zero-based
											let dd = oDate.getDate();

											// Pad with leading zero if needed
											if (mm < 10) { mm = "0" + mm; }
											if (dd < 10) { dd = "0" + dd; }

											return yyyy + "-" + mm + "-" + dd;
										}
										let oStartDate = oEvent.getSource().getDateValue()
   										let oEndDate = oEvent.getSource().getSecondDateValue();
										that._filterStartDate = formatDateToYYYYMMDD(oStartDate);
										that._filterEndDate =  formatDateToYYYYMMDD(oEndDate);
										// Calculate the difference in milliseconds
										let diff = oEndDate.getTime() - oStartDate.getTime();
										// Convert to days (1 day = 24*60*60*1000 ms)
										let countDays = Math.ceil(diff / (1000 * 60 * 60 * 24));
										let aFilterItems = that._inboxFilterDialog.getFilterItems();
										aFilterItems.forEach(function (item) {
											if (item.getKey() === "RequestSubmissionDate") {
												item.setFilterCount(countDays); // dynamically set count
											}
										});
									}
								}).addStyleClass("sapUiSmallMarginBegin sapUiTinyMarginBottom")
							});

						}
						oFilterDialog.addFilterItem(oViewSettingControl)
					}
				};
				/**
				 * Git 274- Opentask filter
				 * Add open task filter based on config
				 * @function oOpenTaskConifg
				 * @param {string} openTaskName - open task filter config
				 **/
				oOpenTaskConifg.forEach(function (openTaskName) {
					switch ( openTaskName["fieldID"]) {
						case "AccountName":
							addControl(openTaskName["isActive"],openTaskName["fieldDesc"],openTaskName["fieldID"],"Account");
							break;
						case "OpportunityID":
							addControl(openTaskName["isActive"],openTaskName["fieldDesc"],openTaskName["fieldID"],"Opportunity");
							break;
						case "RequestorName":
							addControl(openTaskName["isActive"],openTaskName["fieldDesc"],openTaskName["fieldID"],"RequestorName");
							break;
						case "Req_ID":
							addControl(openTaskName["isActive"],openTaskName["fieldDesc"],openTaskName["fieldID"],"Req_ID");
							break;
						case "ReqIndustry":
							addControl(openTaskName["isActive"],openTaskName["fieldDesc"],openTaskName["fieldID"],"ReqIndustry");
							break;
						case "ReqProfitCentre":
							addControl(openTaskName["isActive"],openTaskName["fieldDesc"],openTaskName["fieldID"],"ReqProfitCenter");
							break;
						case "ReqRole":
							addControl(openTaskName["isActive"],openTaskName["fieldDesc"],openTaskName["fieldID"],"ReqRole");
							break;
						case "ReqSolution":
							addControl(openTaskName["isActive"],openTaskName["fieldDesc"],openTaskName["fieldID"],"ReqSolution");
							break;
						case "RequestSubmissionDate":
							addControl(openTaskName["isActive"],openTaskName["fieldDesc"],openTaskName["fieldID"]);
							break;
						default:
							break;
					}
				});
	
			},
			/**
				 * Git 274- Opentask filter
				 * Filter open task
				 * @function handleFilterConfirm
				 * @param {object} oEvent - filter button scope
				 **/
			handleFilterConfirm: function (oEvent) {
				let oList = this.getView().byId("id-list-pendingRequests"); // your List
				let oSelectedFilterKey = oEvent.getParameters().filterCompoundKeys;
				this.getView().byId("idOpenTaskSearch").setValue("");
				//set filter object
				let aFilterData = {
				};
				oSelectedFilterKey.hasOwnProperty("AccountName") ? aFilterData.Account_name = Object.keys(oEvent.getParameters().filterCompoundKeys[
					"AccountName"
				]) : [];
				oSelectedFilterKey.hasOwnProperty("OpportunityID") ? aFilterData.OpportunityID = Object.keys(oEvent.getParameters().filterCompoundKeys[
					"OpportunityID"
				]) : [];
				oSelectedFilterKey.hasOwnProperty("ReqIndustry") ? aFilterData.BA_Industry_Desc = Object.keys(oEvent.getParameters().filterCompoundKeys[
					"ReqIndustry"
				]) : [];
				oSelectedFilterKey.hasOwnProperty("ReqProfitCentre") ? aFilterData.orgName = Object.keys(oEvent.getParameters().filterCompoundKeys[
					"ReqProfitCentre"
				]) : [];
				oSelectedFilterKey.hasOwnProperty("ReqRole") ? aFilterData.Role_Desc = Object.keys(oEvent.getParameters().filterCompoundKeys[
					"ReqRole"
				]) : [];
				oSelectedFilterKey.hasOwnProperty("ReqSolution") ? aFilterData.Solution_Desc = Object.keys(oEvent.getParameters().filterCompoundKeys[
					"ReqSolution"
				]) : [];
				oSelectedFilterKey.hasOwnProperty("Req_ID") ? aFilterData.RefrenceID = Object.keys(oEvent.getParameters().filterCompoundKeys[
					"Req_ID"
				]) : [];
				oSelectedFilterKey.hasOwnProperty("RequestorName") ? aFilterData.EmpRequester_Name = Object.keys(oEvent.getParameters().filterCompoundKeys[
					"RequestorName"
				]) : [];


				this.aFilters = [];

				// Loop through each field
				for (let key in aFilterData) {
					let aFieldValues = aFilterData[key];
					// OR filter for current field
					let aOrFilters = aFieldValues.map(function (value) {
						if(key === 'Role_Desc'){
							return new Filter(key, FilterOperator.Contains, value);
						}else{
							return new Filter(key, FilterOperator.EQ, value);
						}	
					});

					// Combine OR filters for the field
					if (aOrFilters.length > 1) {
						this.aFilters.push(new Filter({
							filters: aOrFilters,
							and: false // OR
						}));
					} else if (aOrFilters.length === 1) {
						this.aFilters.push(aOrFilters[0]);
					}
				}
				// Date range filter
				if (this._filterStartDate && this._filterEndDate) {
					// For string dates in JSONModel, compare as strings (yyyy-MM-dd format works)
					this.aFilters.push(new Filter({
						path: "DTCreation_tdate",
						operator: FilterOperator.BT,
						value1: this._filterStartDate,
						value2: this._filterEndDate
					}));
					this.aFilters.push(new Filter("CurrentStepID", FilterOperator.NE, "REQSUB"));
				}

				// Combine all fields with AND
				let oFinalFilter = new Filter({
					filters: this.aFilters,
					and: true
				});

				// Apply filter to List binding
				oList.getBinding("items").filter(oFinalFilter);
				this._onSetDefaultSelection();
				let sFinalFilterString = oEvent.getParameters().filterString;
				if (this._filterStartDate) {
					this.getView().byId("idInfoToolOpenTask").setVisible(true)
					let aFilterItems = this._inboxFilterDialog.getFilterItems(),
						sDateFilterString;
					aFilterItems.forEach(function (item) {
						if (item.getKey() === "RequestSubmissionDate") {
							sDateFilterString = `${item.getText()} (${item.getCustomControl().getValue()})`
						}
					});
					sFinalFilterString = oEvent.getParameters().filterString ? `${oEvent.getParameters().filterString}, ${sDateFilterString}` : `Filtered By: ${sDateFilterString}`;
					this.getView().byId("infoOpenTaskFilterText").setText(sFinalFilterString);
					this.getView().byId("infoOpenTaskFilterText").setTooltip(sFinalFilterString);
				}

				if (sFinalFilterString) {
					//set Filtered by string
					let sFormattedFilterString = sFinalFilterString.replace("Filtered By:", "").trim();
					let result = [];
					let current = "";
					let depth = 0;

					for (let char of sFormattedFilterString) {
						if (char === '(') depth++;
						if (char === ')') depth--;

						if (char === ',' && depth === 0) {
							result.push(current.trim());
							current = "";
						} else {
							current += char;
						}
					}
					if (current.trim()) result.push(current.trim());
					//sort filter params and show filter string
					let sFinalFormattedFilterString = `Filtered By: ${result.sort().join()}`;
					this.getView().byId("idInfoToolOpenTask").setVisible(true)
					this.getView().byId("infoOpenTaskFilterText").setText(sFinalFormattedFilterString);
					this.getView().byId("infoOpenTaskFilterText").setTooltip(sFinalFormattedFilterString);
				} else {
					this.getView().byId("idInfoToolOpenTask").setVisible(false);
				}
				// if(this._oSortDialog ){
				// 		this._oSortDialog._getResetButton().firePress()
				// 	}
			},
			/**
			 * Git 274- Opentask filter
			 * This will trigger on click of open task filter list to detail page
			 * @function onFilterDetailPageOpen
			 * @param {object} oEvent - filter list selection scope
			 **/
			onFilterDetailPageOpen:function(oEvent){
				//set No data text
				let sKey = oEvent.getParameter("parentFilterItem").getKey(),
					oAppConfigModel = this.getOwnerComponent().getModel("mrrAppConfigModel"),
					sNoDataText;
					switch (sKey) {
					case 'AccountName':
						sNoDataText = oAppConfigModel.getProperty("/accountFilterNoDataText/0/fieldDesc");
						break;
					case 'OpportunityID':
						sNoDataText =oAppConfigModel.getProperty("/oppFilterNoDataText/0/fieldDesc");
						break;
					case 'ReqIndustry':
						sNoDataText = oAppConfigModel.getProperty("/indFilterNoDataText/0/fieldDesc");
						break;
					case 'ReqProfitCentre':
						sNoDataText = oAppConfigModel.getProperty("/pfcFilterNoDataText/0/fieldDesc");
						break;
					case 'ReqRole':
						sNoDataText = oAppConfigModel.getProperty("/roleFilterNoDataText/0/fieldDesc");
						break;
					case 'ReqSolution':
						sNoDataText = oAppConfigModel.getProperty("/solFilterNoDataText/0/fieldDesc");
						break;
					case 'Req_ID':
						sNoDataText = oAppConfigModel.getProperty("/reqIdFilterNoDataText/0/fieldDesc");
						break;
					case 'RequestorName':
						sNoDataText = oAppConfigModel.getProperty("/requestorFilterNoDataText/0/fieldDesc");
						break;
					default:
						sNoDataText =oAppConfigModel.getProperty("/defaultFilterNoDataText/0/fieldDesc");
				}
				try {
					// set no data text
				    this._inboxFilterDialog._dialog.getContent()[0].getPages()[0].getContent()[1].setNoDataText(sNoDataText)
				} catch (e) {
					
				}
			},
				/**
			 * Git 274- Opentask filter
			 * Reset open task filter
			 * @function onResetSettingFilter
			 **/
			onResetSettingFilter: function () {
				let aFilterItems = this._inboxFilterDialog.getFilterItems();
				this._filterStartDate = false;
				this._filterEndDate = false;
				aFilterItems.forEach(function (item) {
					if (item.getKey() === "RequestSubmissionDate") {
						//reset req submission date field
						item.getCustomControl().setDateValue(null);
						item.getCustomControl().setSecondDateValue(null)
						item.setFilterCount(0); // dynamically set count
					}
				});
				//reset all open task filter
				//this._pFilterDialog = false;
				//this._inboxFilterDialog.destroyFilterItems();
			},
			handleFilterDialogConfirm: function (oEvent) {
				let i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				let sCurrentStateText = i18nModel.getText("currentState");
				let sSalesOrgText = i18nModel.getText("salesOrg")
				// SANITIZE
				let sLoggedInUser = this.getOwnerComponent().getModel("userDetails").getProperty("/email");
				let sLoggedInUserId = this.getOwnerComponent().getModel("userDetails").getProperty("/user_name").toUpperCase();
				let aFinalFilterParams = [];
				let urlCurrentStateParams = "CurrentState";
				let urlReqTypeParams = "RequestType";
				let urlSalesOrgParams = "orgName";
				let sOrgType = 'SORG';
				let sReqType = i18nModel.getText("requestType");
				this._alreadyLoadedCount = 20;
				this.sQueryParams = `/wf/V_WfInstance_Inbox?$count=true&$filter=EmpRequester_ID eq '${sLoggedInUserId}'`;
				let oSelectedFilterKey = oEvent.getParameters().filterCompoundKeys;
				if (oSelectedFilterKey.hasOwnProperty(sCurrentStateText)) {
					let aCurrentStateKey =
						Object
							.keys(oEvent.getParameters().filterCompoundKeys[
								"Req Status - Task - Owner Role"
							]);
				// let aCurrentStateKey = Object.keys(oEvent.getParameters().filterCompoundKeys["Request Status - Step"]);
					//Current state filter query
					for (let i = 0; i < aCurrentStateKey.length; i++) {
						if (aCurrentStateKey.length === 1) {
							urlCurrentStateParams = `${urlCurrentStateParams} eq '${aCurrentStateKey[i]}'`
						} else {
							if (i === 0) {
								urlCurrentStateParams = `${urlCurrentStateParams} eq '${aCurrentStateKey[i]}'`
							}
							if (i !== aCurrentStateKey.length - 1 && i != 0) {
								urlCurrentStateParams = `${urlCurrentStateParams} or CurrentState eq '${aCurrentStateKey[i]}'`
							} else if (i == aCurrentStateKey.length - 1) {
								urlCurrentStateParams = `${urlCurrentStateParams} or CurrentState eq '${aCurrentStateKey[i]}'`
							}
						}
					}
					aFinalFilterParams.push(`(${urlCurrentStateParams})`);
				}
				if (oSelectedFilterKey.hasOwnProperty(sSalesOrgText)) {
					let sSalesOrgKey = Object.keys(oEvent.getParameters().filterCompoundKeys["Sales Org"]);;
					//Sales Org filter query
					for (let i = 0; i < sSalesOrgKey.length; i++) {
						if (sSalesOrgKey.length === 1) {
							urlSalesOrgParams = `(${urlSalesOrgParams} eq '${sSalesOrgKey[i]}' and OrgType eq '${sOrgType}')`
						} else {
							if (i === 0) {
								urlSalesOrgParams = `(${urlSalesOrgParams} eq '${sSalesOrgKey[i]}' and OrgType eq '${sOrgType}')`
							}
							if (i !== sSalesOrgKey.length - 1 && i != 0) {
								urlSalesOrgParams = `${urlSalesOrgParams} or (orgName eq '${sSalesOrgKey[i]}' and OrgType eq '${sOrgType}')`
							} else if (i == sSalesOrgKey.length - 1) {
								urlSalesOrgParams = `${urlSalesOrgParams} or (orgName eq '${sSalesOrgKey[i]}' and OrgType eq '${sOrgType}')`
							}
						}
					}
					aFinalFilterParams.push(`(${urlSalesOrgParams})`);
				}
				if (oSelectedFilterKey.hasOwnProperty(sReqType)) {
					let aReqTypeKey = Object.keys(oEvent.getParameters().filterCompoundKeys["Request Type"]);
					//Request type filter query
					for (let i = 0; i < aReqTypeKey.length; i++) {
						if (aReqTypeKey.length === 1) {
							urlReqTypeParams = `${urlReqTypeParams} eq '${aReqTypeKey[i]}'`
						} else {
							if (i === 0) {
								urlReqTypeParams = `${urlReqTypeParams} eq '${aReqTypeKey[i]}'`
							}
							if (i !== aReqTypeKey.length - 1 && i != 0) {
								urlReqTypeParams = `${urlReqTypeParams} or RequestType eq '${aReqTypeKey[i]}'`
							} else if (i == aReqTypeKey.length - 1) {
								urlReqTypeParams = `${urlReqTypeParams} or RequestType eq '${aReqTypeKey[i]}'`
							}
						}
					}
					aFinalFilterParams.push(`(${urlReqTypeParams})`);
				}
				let sFinalFilterUrl;
				if (aFinalFilterParams.length) {
					for (let j = 0; j < aFinalFilterParams.length; j++) {
						let sFilterUrl = aFinalFilterParams[j];
						if (aFinalFilterParams.length === 1) {
							sFinalFilterUrl = sFilterUrl;
						} else {
							if (j === 0) {
								sFinalFilterUrl = sFilterUrl;
							} else {
								sFinalFilterUrl = `${sFinalFilterUrl} and ${sFilterUrl}`
							}

						}
					}
				} else {
					sFinalFilterUrl = "";
				}

				
					if (sFinalFilterUrl) {
						if (!sFinalFilterUrl.includes("CurrentState")) {
							sFinalFilterUrl =
								`${sFinalFilterUrl} and (currentStateID eq 'WSUBMN' or currentStateID eq 'WRESAP' or currentStateID eq 'WIOAPP' or currentStateID eq 'REQSUB' or currentStateID eq 'REESUB' or currentStateID eq 'WMNAPP')`
						}
					}
					this.sQueryParams = sFinalFilterUrl ?
						`/wf/V_WfInstance_Inbox?$count=true&$filter=${sFinalFilterUrl} and contains(CurrentProcessorEmail,'${sLoggedInUser}')` :
						`/wf/V_WfInstance_Inbox?$count=true&$filter=(currentStateID eq 'WSUBMN' or currentStateID eq 'WRESAP' or currentStateID eq 'WIOAPP' or currentStateID eq 'REQSUB' or currentStateID eq 'REESUB' or currentStateID eq 'WMNAPP') and contains(CurrentProcessorEmail,'${sLoggedInUser}')`
				
				this._inboxFilterDialog._navContainer.to(this._inboxFilterDialog._navContainer.getPages()[1].getId())
				this._fetchAPICalls();
			},
			handleSortButtonPressed: function () {
				let that = this;
				if (!this.pSortDialog) {
					this.pSortDialog = this.loadFragment({
						name: "com.dealsupport.melodyrequest.fragments.SortDialog"
					});
				}
				this.pSortDialog.then(function (oSortDialog) {
					oSortDialog.addStyleClass(that.getOwnerComponent().getContentDensityClass());
					that._oSortDialog = oSortDialog;
					oSortDialog.open();
				}.bind(this));
			},
				/**
			 * Git 274- Sort Open Task
			 * Sort Open task
			 * @function onSortOpenTasks
			 * @param {object} oEvent - current control scope
			 **/
			onSortOpenTasks: function (oEvent) {
				let oBinding = this.getView().byId("id-list-pendingRequests").getBinding("items"),
					mParams = oEvent.getParameters(),
					sPath = mParams.sortItem.getKey(),
				bDescending = mParams.sortDescending;
				if (sPath === "DTCreation_tdate") {
					!bDescending ?
						oBinding.sort(new sap.ui.model.Sorter("DTCreation_tdate", false, false, function (a, b) {
							return new Date(a) - new Date(b);
						})) :oBinding.sort(new sap.ui.model.Sorter("DTCreation_tdate", false, false, function (a, b) {
							return new Date(b) - new Date(a);
						}));
				} else {
					!bDescending ? oBinding.sort(new sap.ui.model.Sorter("OpportunityID", true, false, function (a, b) {
						return Number(a) - Number(b);   // numeric compare
					})) : oBinding.sort(new sap.ui.model.Sorter("OpportunityID", true, false, function (a, b) {
						return Number(b) - Number(a);
					}));
				}
				this._onSetDefaultSelection();
			},
		
			handleSortDialogConfirm: function (oEvent) {
				this._alreadyLoadedCount = 20;
				var mParams = oEvent.getParameters(),
					sPath,
					bDescending,

					sPath = mParams.sortItem.getKey();
				bDescending = mParams.sortDescending === true ? `desc` : `asc`
				if (sPath === "DTCreation_tdate") {
					this.sSortQqueryPrams = `&$orderby=${sPath} ${bDescending},DTCreation_ttime ${bDescending}`;
				} else {
					this.sSortQqueryPrams = `&$orderby=${sPath} ${bDescending}`;
				}

				this.sFinalQueryParams = `${this.sQueryParams}${this.sSortQqueryPrams}`;
				models.getInboxWfInstanceFilterLists(this.fnSuccessFilterCallback, this.fnErrorFilterCallback, this, this.sFinalQueryParams, 0, 20);
			},
			onOpenReqArePopOver: function (oEvent) {
				let oButton = oEvent.getSource(),
					sContextReqArea = oEvent.getSource().getBindingContext("pendingReqModel").getObject().RequestArea,
					aReqArea = sContextReqArea.split(","),
					oView = this.getView(),
					oModel = new sap.ui.model.json.JSONModel();
				aReqArea.shift();
				oModel.setData(aReqArea);
				this.getView().setModel(oModel, "reqAreaPopoVerModel");

				// create popover
				if (!this._pReqAreaPopover) {
					this._pReqAreaPopover = Fragment.load({
						id: oView.getId(),
						name: "com.dealsupport.melodyrequest.fragments.ReqAreaPopOver",
						controller: this
					}).then(function (oPopover) {
						oView.addDependent(oPopover);
						return oPopover;
					});
				}

				this._pReqAreaPopover.then(function (oPopover) {
					oPopover.openBy(oButton);
				});
			},
			onOpenCreateReqDialog: function () {
				appView.onOpenCreateReqDialog();
			}
		});
	});