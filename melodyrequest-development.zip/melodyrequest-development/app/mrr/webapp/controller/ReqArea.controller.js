sap.ui.define([
    "sap/m/library",
    "sap/ui/core/mvc/Controller",
    "sap/m/TablePersoController",
    "sap/m/SearchField",
    "./SettingsDialog",
    "com/dealsupport/melodyrequest/model/models",
    "com/dealsupport/melodyrequest/model/users",
    "sap/m/MessageBox",
    "sap/ui/export/library",
    "sap/ui/export/Spreadsheet",
    "com/dealsupport/melodyrequest/model/formatter",
    "com/dealsupport/melodyrequest/control/ValueHelpUserCommon",
    "com/dealsupport/melodyrequest/control/Common",
    'sap/ui/core/Fragment'
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (mobileLibrary, Controller, TablePersoController, SearchField, SettingsDialog, models, users, MessageBox,
        exportLibrary, Spreadsheet, formatter, UserCommon, Common, Fragment) {
        "use strict";
        var URLHelper = mobileLibrary.URLHelper;
        var EdmType = exportLibrary.EdmType;
        return Controller.extend("com.dealsupport.melodyrequest.controller.ReqArea", {
            formatter: formatter,
            onInit: function () {
                this.getView().addStyleClass(appView.getOwnerComponent().getContentDensityClass());
                var oAppConstantsModel = appView.getOwnerComponent().getModel("appConstants");
                var sDownTimeFlag = oAppConstantsModel.getProperty("/DownTime/0/Operational_Status");
                if (sDownTimeFlag) {
                    appView.getOwnerComponent().getRouter().navTo("NotFound");
                } else {
                this._setBasicSearchBar();
                this.initialLoad = true;
                this._onObjectMatched();
                //initialize table settings
                this._oTPC = new TablePersoController({
                    // init and activate controller for personalization 
                    table: this.getView().byId("id-ReqArea-table"),
                    componentName: "settings",
                    persoService: SettingsDialog
                });
                var oTable = this.getView().byId("id-ReqArea-table");
                //remove select all check box from table
                this._myDelegate = {
                    onAfterRendering: function () {
                        if (typeof this._getSelectAllCheckbox === "function" && this._getSelectAllCheckbox().isA("sap.m.CheckBox")) {
                            this._getSelectAllCheckbox().setVisible(false);
                        }
                    }
                };
                oTable.addEventDelegate(this._myDelegate, oTable);
            }
            },
            onSettingsPress: function (oEvent) {
                //open table column settings dialog
                this._oTPC.openDialog();
            },

            fnErrorCallback: function (oError, self) {
                MessageBox.error(oError.responseText, {
                    contentWidth: "600px"
                });
                sap.ui.core.BusyIndicator.hide();
            },
            SalesOrgDesc: function (oValue) {
                switch (oValue) {
                    case "71":
                        return ("India");
                        break;
                    case "23":
                        return ("Germany");
                        break;
                    case "2":
                        return ("Switzerland");
                        break;
                    case "3":
                        return ("Austria");
                        break;
                    case "6":
                        return ("Spain");
                        break;
                    default:
                        return oValue;
                        break;
                }
            },
            toDetailPage: function (oEvent) {
                var oItem = oEvent.getSource();
                sap.ui.core.BusyIndicator.show(0);
                var sGUID = oItem.getBindingContext("AdminResources").getProperty("GUID");
                var oView = this.getView();
				var oDialog = this.byId("userReqDetailDialog");
                appView.getView().getModel("AdminResources").getData().selectedGuid = sGUID;
                if(appView.getOwnerComponent().getModel("appConstants").getProperty("/AdminDetail")){
                    appView.getOwnerComponent().getModel("appConstants").getProperty("/AdminDetail")._onObjectMatched();
                }
				if (!oDialog) {
					Fragment.load({
						id: oView.getId(),
						name: "com.dealsupport.melodyrequest.fragments.ReqDetailFrag",
						controller: this
					}).then(function (oFragment) {
						oView.addDependent(oFragment);
						oFragment.open();
					});
				} else {
					oDialog.open();
				}
            },
            onCancelReqArea: function () {
				// Handle cancel button press
				var oDialog = this.byId("userReqDetailDialog");
				if (oDialog) {
					oDialog.close();
				}
				
			},
            onPressHIstory: function () {
                appView.getOwnerComponent().getRouter().navTo("History");
            },
            onCreate: function () {
                models.createAdminGUID(this.fnSuccessCreateCallback, this.fnErrorCreateCallback, appView);
            },
            fnSuccessCreateCallback: function (oResult, self) {
                sap.ui.core.BusyIndicator.hide();
                self.getOwnerComponent().getRouter().navTo("Detail", {
                    GUID: oResult.GUID,
                    MODE: "Create"
                });
            },
            fnErrorCreateCallback: function (oError) {
                MessageBox.error(oError.responseText, {
                    contentWidth: "600px"
                });
                sap.ui.core.BusyIndicator.hide();
            },
            onTableRowSelChange: function (oEvent) {
                var oIndeces = oEvent.getSource().getSelectedItems();
                if (oIndeces.length === 0) {
                    this.byId("idDeleteButton").setEnabled(false)
                } else {
                    this.byId("idDeleteButton").setEnabled(true)
                }
            },
            onDelete: function (oEvent) {
                var oTable = this.getView().byId("id-ReqArea-table");
                var oSelectedContexts = oTable.getSelectedContexts("AdminResources");
                var that = this;
                var aDeleteMsg = [];
                try {
                    oSelectedContexts.forEach(function (oContext) {
                        var sReqArea = oContext.getObject().RequestArea;
                        var sSalesOrgName = oContext.getObject().orgName;
                        var sDeleteMsg = `${sReqArea}(${sSalesOrgName})`
                        aDeleteMsg.push(sDeleteMsg);
                    });
                } catch (err) { };
                var sFinalDeleteMsg = aDeleteMsg.toString();
                MessageBox.show(
                    `Are you sure want to delete the configuration for ${sFinalDeleteMsg} ?`, {
                    icon: MessageBox.Icon.WARNING,
                    title: "Delete Confirmation",
                    actions: [MessageBox.Action.YES, MessageBox.Action.NO],
                    emphasizedAction: MessageBox.Action.YES,
                    onClose: function (oAction) {
                        if (oAction === MessageBox.Action.YES) {
                            for (var i = 0; i < oSelectedContexts.length; i++) {
                                var sGUID = oSelectedContexts[i].getObject().GUID
                                var sUrl =
                                    `/AdminResources(GUID=${sGUID})`
                                var isCompleteAPICalls
                                if (i + 1 === oSelectedContexts.length) {
                                    isCompleteAPICalls = true;
                                }
                                models.deleteAdminGUID(that.fnSuccessDeleteAdminGUIDDeleteCallback, that.fnErrorDeleteAdminGUIDCallback, that, sUrl, isCompleteAPICalls);
                            }

                        }

                    }
                }
                );
            },
            fnSuccessDeleteAdminGUIDDeleteCallback: function (oResponse, self, isCompleteAPICalls) {
                sap.ui.core.BusyIndicator.hide();
                if (isCompleteAPICalls) {
                    var oFilterUrlModel = self.getOwnerComponent().getModel("filterUrl");
                    oFilterUrlModel.setProperty("/adminViewFilterUrl", '/AdminResources?$count=true');
                    var sFinalUrl = oFilterUrlModel.getProperty("/adminViewFilterUrl");
                    self._onResetAllFilter();
                    self._alreadyLoadedCount = 20;
                    models.getAdminViewFilterLists(self.fnSuccessFilterCallback, self.fnErrorFilterCallback, self, sFinalUrl);
                    self.getView().byId("idDeleteButton").setEnabled(false);
                }
            },
            fnErrorDeleteAdminGUIDCallback: function (oError, self) {
                MessageBox.error(oError.responseText, {
                    contentWidth: "600px"
                });
                sap.ui.core.BusyIndicator.hide();
            },
            //valueHelp dialog for Request Area
            onRequestAreaValueHelpRequested: function (oEvent) {
                Common._onRequestAreaValueHelpRequested(oEvent, this);
            },
            handleReqAreaValueHelpSearch: function (evt) {
                Common._handleReqAreaValueHelpSearch(evt);
            },
            handleReqAreaValueHelpClose: function (evt) {
                var oMultiInputReqArea = this.getView().byId("id-Admin-filter-RequestArea");
                Common._handleReqAreaValueHelpClose(evt, oMultiInputReqArea);
            },
            //user dialog
            //resources
            onUserValueHelpRequested: function (oEvent) {
                this.oMultiInputID = oEvent.getParameter("id");
                const oMultiInput = this.getView().byId(this.oMultiInputID);
                let isUserID = true;
                let sLabel;
                const i18nModel = appView.getOwnerComponent().getModel("i18n").getResourceBundle();
                switch (true) {
                    case this.oMultiInputID.includes("id-filter-Resources"):
                        sLabel = i18nModel.getText("resources");
                        break;
                    case this.oMultiInputID.includes("id-filter-Approvers"):
                        sLabel = i18nModel.getText("approvers");
                        break;
                    case this.oMultiInputID.includes("id-filter-Substitute"):
                        sLabel = i18nModel.getText("subApprovers");
                        break;
                    default:
                        sLabel = i18nModel.getText("users");
                        break;
                }
                Common._onUserValueHelpRequested(this, oMultiInput, isUserID, sLabel);
           },
            onFilterBarUserSearch: function () {
                Common._onFilterBarUserSearch(this)
            },
            _onAddSelectedUser: function (evt, that) {
                Common.__onAddSelectedUser(evt, that)
            },
            onValueHelpUserCancelPress: function () {
                UserCommon._onValueHelpUserCancelPress(this);
            },
            onUserSearchValueChange: function (oEvent) {
                UserCommon._onUserSearchValueChange(oEvent, this._ovalueHelpUserFragment);
            },
            onValueHelpUserAfterClose: function () {
                UserCommon._onValueHelpUserAfterClose(this);
            },
            onValueHelpUserOkPress: function (oEvent) {
                var oMultiInput = this.getView().byId(this.oMultiInputID);
                Common._onValueHelpUserOkPress(oEvent, oMultiInput, this)
            },
            _onSearch: function (oEvent) {
                //free-text search call
                this._alreadyLoadedCount = 20;
                var sQuery = oEvent.getParameter('query');
                this.sQueryParams = `/AdminResources?$count=true&$search=${sQuery}`;
                this.sFinalQueryParams = `${this.sQueryParams}`;
                var oFilterUrlModel = appView.getOwnerComponent().getModel("filterUrl");
                oFilterUrlModel.setProperty("/adminViewFilterUrl", this.sFinalQueryParams);
                var sFinalUrl = oFilterUrlModel.getProperty("/adminViewFilterUrl");
                models.getAdminViewFilterLists(this.fnSuccessFilterCallback, this.fnErrorFilterCallback, this, sFinalUrl);
            },
            _setBasicSearchBar: function () {
                //initialize search toolbar
                var oFilterBar = this.getView().byId('id-ReqArea-filterbar');
                var that = this;
                var oBasicSearch = new SearchField("id-ReqArea-basic-searchfield", {
                    search: function (oEvent) {
                        that.onFilter(oEvent);
                        //Fire call to search for value
                    }
                });
                oFilterBar.setBasicSearch(oBasicSearch);
            },
            _onObjectMatched: function () {
                var sPreviousHash = sap.ui.core.routing.History.getInstance().getPreviousHash();
                var oFilterUrlModel = appView.getOwnerComponent().getModel("filterUrl");
                this.getView().byId("idDeleteButton").setEnabled(false);
                if (sPreviousHash) {
                    if (!sPreviousHash.includes('Detail')) {
                        oFilterUrlModel.setProperty("/adminViewFilterUrl", '/AdminResources?$count=true');
                        this._onResetAllFilter();
                    }
                } else {
                    oFilterUrlModel.setProperty("/adminViewFilterUrl", '/AdminResources?$count=true');
                    this._onResetAllFilter();
                }
                if (this.initialLoad) {
                    oFilterUrlModel.setProperty("/adminViewFilterUrl", '/AdminResources?$count=true');
                    this._onResetAllFilter();
                    this.initialLoad = false;
                }
                this._fnAdminViewAPICalls();
               appView._setSelectedMenuKey();
            },
            _fnAdminViewAPICalls: function () {
                this.filterApplied = false;
                sap.ui.core.BusyIndicator.show(0);
                var oFilterUrlModel = appView.getOwnerComponent().getModel("filterUrl");
                var sFinalUrl = oFilterUrlModel.getProperty("/adminViewFilterUrl");
                this.sQueryParams = sFinalUrl,
                this.sFinalQueryParams = sFinalUrl,
                this._alreadyLoadedCount = 20;
                var sUrl = "/Public_ReqArea";
                models.getPublicSalesOrg(appView, this.fnSuccessPublicSalesOrg);
                models.getReqAreaLists(this.fnReqAreaSuccessCallback, this.fnReqAreaErrorCallback, appView, sUrl);
                models.getAdminViewFilterLists(this.fnSuccessFilterCallback, this.fnErrorFilterCallback, appView, sFinalUrl);
                // this._oTPC.activate();
                this._configureEditingStatus();
            },
            fnSuccessPublicSalesOrg: function (oData, self) {
                const oPublicReqAreaModel = new sap.ui.model.json.JSONModel();
                oPublicReqAreaModel.setData(oData);
                self.getView().setModel(oPublicReqAreaModel, "publicSalesOrgModel");
            },
            fnReqAreaSuccessCallback: function (oResult, self) {
                let newArray = [];
                let uniqueObject = {};
                let aPublicSalesOrg  = self.getView().getModel("publicSalesOrgModel").getData().value;
                models.getProfitCenterList(self);
                oResult.value.forEach(function(item){
                    const sPublisSalesOrg = aPublicSalesOrg.filter((org) => org.ID === item.orgID);
                    item.orgName = sPublisSalesOrg.Sales_org_name;
                });
                for (let i in oResult.value) {
                    var objTitle = oResult.value[i]['Request_Area'];
                    uniqueObject[objTitle] = oResult.value[i];
                }
                for (var i in uniqueObject) {
                    newArray.push(uniqueObject[i]);
                }
                oResult.value = newArray;
                var oModel = new sap.ui.model.json.JSONModel();
                oModel.setData(oResult);
                self.getView().setModel(oModel, "reqAreaModel");
                oModel.refresh();
                sap.ui.core.BusyIndicator.hide();
            },
            fnReqAreaErrorCallback: function (oError) {
                MessageBox.error(oError.responseText, {
                    contentWidth: "600px"
                });
                sap.ui.core.BusyIndicator.hide();
            },
            _configureEditingStatus: function () {
                var aEditingStatus = ["All", "All (Hiding Drafts)", "Unchanged", "Own Draft"
                    , "Locked by Another User", "Unsaved Changes by Another User"];

                var oModel = new sap.ui.model.json.JSONModel();
                oModel.setData(aEditingStatus);
                this.getView().setModel(oModel, "editingStatus");
            },
            _onResetAllFilter: function () {
                var oView = this.getView();
                oView.byId("id-ReqArea-filterbar")._oBasicSearchField.setValue("");
                oView.byId("id-filter-Substitute").removeAllTokens()
                oView.byId("id-filter-Approvers").removeAllTokens();
                oView.byId("id-Admin-filter-RequestArea").removeAllTokens();
                oView.byId("id-filter-Resources").removeAllTokens();
                oView.byId("id-Admin-filter-salesOrg").setSelectedItems("");
            },
            fnSuccessCallback: function (oResult, self) {
                var oModel = new sap.ui.model.json.JSONModel();
                oResult.count = oResult.value.length;
                oModel.setData(oResult);
                self.getOwnerComponent().setModel(oModel, "AdminResources");
                sap.ui.core.BusyIndicator.hide();
                if (self._oSortDialog) {
                    self._oSortDialog.setSortDescending(true);
                    self._oSortDialog.setSelectedSortItem(
                        self._oSortDialog.getSortItems()[0].sId);
                }
            },
            fnErrorCallback: function (oError, self) {
                MessageBox.error(oError.responseText, {
                    contentWidth: "600px"
                });
                sap.ui.core.BusyIndicator.hide();
            },
            onUpdateStartedGrowingTable: function (oEvent) {
                //Pagination in the Worklist page
                var oTable = oEvent.getSource();
                var oReqAreaData = this.getView().getModel("AdminResources").getData();
                let aPublicSalesOrg  = appView.getOwnerComponent().getModel("salesOrgModel").getData().value;
                oReqAreaData.value.forEach(function(item){
                    aPublicSalesOrg.filter(function(org){
                        if(org.ID === item.orgID){
                           item.orgName = org.Desc;
                        }
                    });  
                });
                if (oReqAreaData) {
                    var iTotalLen = oReqAreaData.count;
                    if (iTotalLen !== null && iTotalLen !== undefined && iTotalLen > 20) {
                        //Setting the value for iBindingLength = oBinding.getLength() which is the total count of items.
                        oTable.getBindingInfo("items").binding.iLength = iTotalLen;
                        if (oTable.getGrowingInfo().actual === this._alreadyLoadedCount && oTable.getGrowingInfo().actual <
                            iTotalLen && oEvent.getParameter("reason") === "Growing") {
                            this._requestAndAppendMoreLists(this._alreadyLoadedCount);
                        }
                    }
                }
            },
            _getWfServiceRuntimeBaseURL: function (self) {
                return this._getRuntimeBaseURL(self) + "/adminresources";
            },
            _getRuntimeBaseURL: function (self) {
                var componentName = self.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
                var componentPath = sap.ui.require.toUrl(componentName);
                return componentPath;
            },
            _requestAndAppendMoreLists: function (sAlreadyLoadedTenantCount) {
                //To load more Features
                var iSkip = parseInt(sAlreadyLoadedTenantCount, [10]);
                var iTop = 20;
                var that = this;
                var oFilterUrlModel = appView.getOwnerComponent().getModel("filterUrl");
                var sFinalUrl = oFilterUrlModel.getProperty("/adminViewFilterUrl");
                var workflowBaseurl = models._getAdminWfServiceRuntimeBaseURL(appView);
                // this.sFinalQueryParams = `${this.sQueryParams}`;

                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    url: `${workflowBaseurl}${sFinalUrl}&$skip=${iSkip}&$top=${iTop}`,
                    type: "GET",
                    success: function (oData) {
                        that._alreadyLoadedCount = oData.value.length + iSkip;
                        var oModel = appView.getOwnerComponent().getModel("AdminResources");
                        oData.count = oData["@odata.count"];
                        var aReqAreaLists = oModel.getData().value.concat(oData.value);
                        oModel.setData({
                            "count": oData.count,
                            "value": aReqAreaLists
                        }, true);
                        that._closeBusyIndicator(that);


                    }.bind(this),
                    error: function (oError) {
                        that._closeBusyIndicator(that);
                        MessageBox.error(oError.responseText, {
                            contentWidth: "600px"
                        });
                        sap.ui.core.BusyIndicator.hide();
                        return false;
                    }
                });

            },
            _closeBusyIndicator: function (self) {
                var oTable = self.getView().byId("id-ReqArea-table");
                oTable.setBusy(false);

            },
            onFilter: function () {
                //master data filter based on multi fields
                var oView = this.getView();
                var aRequestArea = oView.byId("id-Admin-filter-RequestArea").getTokens();
                var aResources = oView.byId("id-filter-Resources").getTokens();
                var aSalesOrg = oView.byId("id-Admin-filter-salesOrg").getSelectedItems();
                var aApprovers = oView.byId("id-filter-Approvers").getTokens();
                var aSubApprovers = oView.byId("id-filter-Substitute").getTokens();
                var urlReqAreaParams = "RequestArea";
                var urlSalesOrgParams = "orgID";
                var urlResourcesParams = `contains(Resources,`
                var urlApproversParams = `contains(Approvers,`
                var urlSubApproversParams = `contains(SubstituteApprovers,`
                var aFinalFilterParams = [];
                this._alreadyLoadedCount = 20;
                var sOrgType='SORG';
                this.getView().byId("idDeleteButton").setEnabled(false);
                var sBasicSearchValue = oView.byId("id-ReqArea-filterbar").getBasicSearchValue();

                //start of Request Area Path filter query
                if (aRequestArea.length) {
                    for (var i = 0; i < aRequestArea.length; i++) {
                        var sTokenText = aRequestArea[i].getText();
                        if (aRequestArea.length === 1) {
                            urlReqAreaParams = `${urlReqAreaParams} eq '${sTokenText}'`
                        } else {
                            if (i === 0) {
                                urlReqAreaParams = `${urlReqAreaParams} eq '${sTokenText}'`
                            }
                            if (i !== aRequestArea.length - 1 && i != 0) {
                                urlReqAreaParams = `${urlReqAreaParams} or RequestArea eq '${sTokenText}'`
                            } else if (i == aRequestArea.length - 1) {
                                urlReqAreaParams = `${urlReqAreaParams} or RequestArea eq '${sTokenText}'`
                            }
                        }
                    }
                    urlReqAreaParams = urlReqAreaParams.replaceAll("&", "%26");
                    aFinalFilterParams.push(`(${urlReqAreaParams})`);
                }
                //end of Request Area Path filter query
                //start of Sales Org filter query
                if (aSalesOrg.length) {
                    for (var i = 0; i < aSalesOrg.length; i++) {
                        var sTokenText = aSalesOrg[i].getKey();
                        if (aSalesOrg.length === 1) {
                            urlSalesOrgParams = `(${urlSalesOrgParams} eq '${sTokenText}' and orgType eq '${sOrgType}')`;
                        } else {
                            if (i === 0) {
                                urlSalesOrgParams = `(${urlSalesOrgParams} eq '${sTokenText}' and orgType eq '${sOrgType}')`;
                            }
                            if (i !== aSalesOrg.length - 1 && i != 0) {
                                urlSalesOrgParams = `${urlSalesOrgParams} or (orgID eq '${sTokenText}' and orgType eq '${sOrgType}')`;
                            } else if (i == aSalesOrg.length - 1) {
                                urlSalesOrgParams = `${urlSalesOrgParams} or (orgID eq '${sTokenText}' and orgType eq '${sOrgType}')`;
                            }
                        }
                    }
                    aFinalFilterParams.push(`(${urlSalesOrgParams})`);
                }
                //end of Sales Org filter query

                //start of Resources filter query
                if (aResources.length) {
                    for (var i = 0; i < aResources.length; i++) {
                        var sTokenText = aResources[i].getText().match(/\(([^)]+)\)/)[1];
                        if (aResources.length === 1) {
                            urlResourcesParams = `${urlResourcesParams}'${sTokenText}')`

                        } else {
                            if (i === 0) {
                                urlResourcesParams = `${urlResourcesParams}'${sTokenText}')`
                            }
                            if (i !== aResources.length - 1 && i != 0) {
                                urlResourcesParams = `${urlResourcesParams} or contains(Resources,'${sTokenText}')`
                            } else if (i == aResources.length - 1) {
                                urlResourcesParams = `${urlResourcesParams} or contains(Resources,'${sTokenText}')`
                            }
                        }
                    }
                    aFinalFilterParams.push(`(${urlResourcesParams})`);
                }
                //end of Resources filter query

                //start of Approver filter query
                if (aApprovers.length) {
                    for (var i = 0; i < aApprovers.length; i++) {
                        var sTokenText = aApprovers[i].getText().match(/\(([^)]+)\)/)[1];
                        if (aApprovers.length === 1) {
                            urlApproversParams = `${urlApproversParams}'${sTokenText}')`
                        } else {
                            if (i === 0) {
                                urlApproversParams = `${urlApproversParams}'${sTokenText}')`
                            }
                            if (i !== aApprovers.length - 1 && i != 0) {
                                urlApproversParams = `${urlApproversParams} or contains(Resources,'${sTokenText}')`
                            } else if (i == aApprovers.length - 1) {
                                urlApproversParams = `${urlApproversParams} or contains(Resources,'${sTokenText}')`
                            }
                        }
                    }
                    aFinalFilterParams.push(`(${urlApproversParams})`);
                }
                //end of  Approvers filter query

                //start of Sub Approver filter query
                if (aSubApprovers.length) {
                    for (var i = 0; i < aSubApprovers.length; i++) {
                        var sTokenText = aSubApprovers[i].getText().match(/\(([^)]+)\)/)[1];
                        if (aSubApprovers.length === 1) {
                            urlSubApproversParams = `${urlSubApproversParams}'${sTokenText}')`
                        } else {
                            if (i === 0) {
                                urlSubApproversParams = `${urlSubApproversParams}'${sTokenText}')`
                            }
                            if (i !== aSubApprovers.length - 1 && i != 0) {
                                urlSubApproversParams = `${urlSubApproversParams} or contains(Resources,'${sTokenText}')`
                            } else if (i == aSubApprovers.length - 1) {
                                urlSubApproversParams = `${urlSubApproversParams} or contains(Resources,'${sTokenText}')`
                            }
                        }
                    }
                    aFinalFilterParams.push(`(${urlSubApproversParams})`);
                }
                //end of Sub Approvers filter query



                //start of filter query
                var sFinalFilterUrl;
                if (aFinalFilterParams.length) {
                    for (var j = 0; j < aFinalFilterParams.length; j++) {
                        var sFilterUrl = aFinalFilterParams[j];
                        if (aFinalFilterParams.length === 1) {
                            sFinalFilterUrl = sFilterUrl;
                        } else {
                            if (j === 0) {
                                sFinalFilterUrl = sFilterUrl;
                            } else {
                                sFinalFilterUrl = `${sFinalFilterUrl} and ${sFilterUrl}`
                            }

                        }
                    }
                } else {
                    sFinalFilterUrl = "";
                }
                this.sQueryParams = sFinalFilterUrl ? `/AdminResources?$count=true&$filter=${sFinalFilterUrl}` : `/AdminResources?$count=true`;
                if(sBasicSearchValue){
                    this.sQueryParams =  `${this.sQueryParams}&$search=${sBasicSearchValue}`;
                }

                this.sFinalQueryParams = `${this.sQueryParams}`;
                var oFilterUrlModel = appView.getOwnerComponent().getModel("filterUrl");
                oFilterUrlModel.setProperty("/adminViewFilterUrl", this.sFinalQueryParams);
                var sFinalUrl = oFilterUrlModel.getProperty("/adminViewFilterUrl");

                //end of final filter query
                //backend filter GET call
                models.getAdminViewFilterLists(this.fnSuccessFilterCallback, this.fnErrorFilterCallback, appView, sFinalUrl);
            },
            fnSuccessFilterCallback: function (oResult, self) {

                var oModel = new sap.ui.model.json.JSONModel();
                oResult.count = oResult["@odata.count"];
                let aPublicSalesOrg  = self.getOwnerComponent().getModel("salesOrgModel").getData().value;
                oResult.value.forEach(function(item){
                    aPublicSalesOrg.filter(function(org){
                        if(org.ID === item.orgID){
                           item.orgName = org.Desc;
                        }
                    });  
                });
               
                oModel.setData(oResult);
                self.getOwnerComponent().setModel(oModel, "AdminResources");
                sap.ui.core.BusyIndicator.hide();
                if (self._oSortDialog) {
                    self._oSortDialog.setSortDescending(true);
                    self._oSortDialog.setSelectedSortItem(
                        self._oSortDialog.getSortItems()[0].sId);
                }
                sap.ui.core.BusyIndicator.hide();
            },
            fnErrorFilterCallback: function (oError, self) {
                MessageBox.error(oError.responseText, {
                    contentWidth: "600px"
                });
                sap.ui.core.BusyIndicator.hide();
            },
            onExport: function () {
                //Export to Excel
                this.oExportedData = 0;
                this.exportedDataLists = [];
                this._triggerExportToExcelAPI();
            },
            _APICallForExportToExcelMoreData: function (sLoadedExportDataCount) {
                //To load more Features
                var iSkip = parseInt(sLoadedExportDataCount, [10]);
                var iTop = 1000;
                var that = this;
                var that = this;
                var workflowBaseurl = models._getAdminWfServiceRuntimeBaseURL(appView);
                this.sFinalQueryParams = `${this.sQueryParams}`;
                var oFilterUrlModel = appView.getOwnerComponent().getModel("filterUrl");
                oFilterUrlModel.setProperty("/adminViewFilterUrl", this.sFinalQueryParams);
                var sFinalUrl = oFilterUrlModel.getProperty("/adminViewFilterUrl");

                jQuery.ajax({
                    async: false,
                    contentType: "application/json",
                    url: `${workflowBaseurl}${sFinalUrl}&$skip=${iSkip}&$top=${iTop}`,
                    type: "GET",
                    success: function (oData) {
                        that.oExportedData = oData.value.length + iSkip;
                        oData.count = oData["@odata.count"];
                        if (!that.exportedDataLists) {
                            that.exportedDataLists = oData.value;
                        } else {
                            that.exportedDataLists = that.exportedDataLists.concat(oData.value);
                        }
                        if (that.exportedDataLists.length < oData.count) {
                            that._triggerExportToExcelAPI();
                        } else {
                            that._onFinalExportToExcel(that);
                        }
                    }.bind(this),
                    error: function (oError) {
                        that._closeBusyIndicator(that);
                        MessageBox.error(oError.responseText, {
                            contentWidth: "600px"
                        });
                        sap.ui.core.BusyIndicator.hide();
                        return false;
                    }
                });
            },
            _onFinalExportToExcel: function (that) {
                var aCols, oSettings, oSheet;
                aCols = that._createColumnConfig();
                for (var i = 0; i < that.exportedDataLists.length; i++) {
                    that.exportedDataLists[i].SalesOrgName = that.SalesOrgDesc(that.exportedDataLists[i].orgID);
                }
                let aPublicSalesOrg  = appView.getOwnerComponent().getModel("salesOrgModel").getData().value;
                        that.exportedDataLists.forEach(function(item){
                    aPublicSalesOrg.filter(function(org){
                        if(org.ID === item.orgID){
                           item.OrgName = org.Desc;
                        }
                    });  
                });
                oSettings = {
                    workbook: {
                        columns: aCols,
                        hierarchyLevel: "Level"
                    },
                    dataSource: that.exportedDataLists,
                    fileName: "Request_Areas.xlsx",
                    worker: false // We need to disable worker because we are using a MockServer 
                };

                oSheet = new Spreadsheet(oSettings);
                oSheet.build().finally(function () {
                    oSheet.destroy();
                });
            },
            _triggerExportToExcelAPI: function () {
                var oModelData = appView.getOwnerComponent().getModel("AdminResources").getData();
                var iTotalexportDataLength = oModelData.count;
                if (iTotalexportDataLength !== null && iTotalexportDataLength !== undefined && iTotalexportDataLength) {
                    //Setting the value for iBindingLength = oBinding.getLength() which is the total count of items.
                    if (this.oExportedData <
                        iTotalexportDataLength) {
                        this._APICallForExportToExcelMoreData(this.oExportedData);
                    }
                }
            },
            _createColumnConfig: function () {
                var aCols = [];
                for (var i = 0; i < this.exportedDataLists.length; i++) {
                    let sPCName;
                    let PCdata = this.getView().getModel("ProfitCenterListData").getData().value;
                    const sOrgName = this.exportedDataLists[i].OrgName;
                    const sOrgID = this.exportedDataLists[i].orgID;
                    if (sOrgName) {
                        sPCName = sOrgName;
                    } else {

                        function getProfitCenterDesc(orgID, values) {
                            const result = values.find(item => item.profitCenterGUID === orgID);
                            console.log(result);
                            sPCName = result ? result.profitCenterDesc : "";
                        }
                        getProfitCenterDesc(sOrgID, PCdata)
                    }
                    this.exportedDataLists[i].OrgName = sPCName;
                }
                const i18nModel = appView.getOwnerComponent().getModel("i18n").getResourceBundle();
                const salesOrgName = i18nModel.getText("salesOrgName");
                const requestArea = i18nModel.getText("requestArea");
                const resources = i18nModel.getText("resources");
                const approvers = i18nModel.getText("approvers");
                const subApprovers = i18nModel.getText("subApprovers");
                aCols.push({
                    label: salesOrgName,
                    property: "OrgName",
                    type: EdmType.String
                });

                aCols.push({
                    label: requestArea,
                    property: "RequestArea",
                    type: EdmType.String

                });

                aCols.push({
                    label: resources,
                    property: "Resources",
                    type: EdmType.String
                });

                aCols.push({
                    label: approvers,
                    property: "Approvers",
                    type: EdmType.String
                });

                aCols.push({
                    label: subApprovers,
                    property: "SubstituteApprovers",
                    type: EdmType.String
                });

                return aCols;
            },
            onExit: function () {
                this._oTPC.destroy();
                this.aSelectedUsers = [];
            },
            onResourceContactlisticon: function (oEvent) {
                sap.ui.core.BusyIndicator.show(0);
                var sName = "Resources";
                var sResources = oEvent.getSource().getBindingContext("AdminResources").getObject().Resources;
                var oValType = "ID"
                users.callEmpApi(sResources, oEvent, this, sName, oValType);

            },
            onAppContactlisticon: function (oEvent) {
                sap.ui.core.BusyIndicator.show(0);
                var sName = "Approvers";
                var sResources = oEvent.getSource().getBindingContext("AdminResources").getObject().Approvers;
                var oValType = "ID"
                users.callEmpApi(sResources, oEvent, this, sName, oValType);

            },
            onSubsAppContactlisticon: function (oEvent) {
                sap.ui.core.BusyIndicator.show(0);
                var sName = "Substitute Approvers";
                var sResources = oEvent.getSource().getBindingContext("AdminResources").getObject().SubstituteApprovers;
                var oValType = "ID"
                users.callEmpApi(sResources, oEvent, this, sName, oValType);

            },
            funcSuccess: function (oData, self) {
                var oModel = new sap.ui.model.json.JSONModel();
                oModel.setData(oResult);
                self.getOwnerComponent().setModel(oModel, "EmpData");
                this.onQuickCardOpen(EmpData);
            },
            QuickViewCard: function (oModel, oevt, self, sName) {
                var oButton = oevt.getSource();
                self.getView().setModel(oModel, "EmpDetails");
                var EmployeeDetails = this.getView().getModel("EmpDetails");
                users._contactslistFragment(EmployeeDetails, oevt, self, sName).openBy(oButton);
                sap.ui.core.BusyIndicator.hide();
            },

            onPressEmpEmail: function (oEvent) {
                var sUrl = oEvent.getSource().getProperty("text");
                URLHelper.triggerEmail(sUrl, "Info Request - MRR", false, false, false, true);
            },

            currentAvatarDisplay: function (oEvent) {
                var userId = oEvent;
                return this.getOwnerComponent().getModel("appConstants").getProperty("/userImg/0/Value") + userId;
            }
        });
    });
