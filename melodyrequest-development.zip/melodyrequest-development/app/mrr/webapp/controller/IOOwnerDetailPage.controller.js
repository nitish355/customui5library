sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/ui/core/format/DateFormat",
    "com/dealsupport/melodyrequest/model/formatter",
    "sap/m/MessageBox",
    "com/dealsupport/melodyrequest/model/models",
    "sap/m/Dialog",
    "sap/m/DialogType",
    "sap/m/Button",
    "sap/m/ButtonType",
    "sap/ui/core/syncStyleClass",
    "sap/m/TextArea",
    "sap/ui/core/Fragment",
    "com/dealsupport/melodyrequest/control/Common",
], function (BaseController, JSONModel, MessageToast, DateFormat, formatter, MessageBox, Models, Dialog, DialogType, Button, ButtonType, syncStyleClass, TextArea, Fragment, CommonJS) {
    var workflowInstanceId,
        token;
    "use strict";
    return BaseController.extend("com.dealsupport.melodyrequest.controller.IOOwnerDetailPage", {
        formatter: formatter,
        common:CommonJS,


        onInit: function () {
            this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
            this.bInitialLoad = true;
            this.getOwnerComponent().getModel("appConstants").setProperty("/isAfterWfAction",false);
            if (this.getOwnerComponent().getRouter().getRoute("IOOwnerDetailPage")) {
                this.getOwnerComponent().getRouter().getRoute("IOOwnerDetailPage").attachPatternMatched(this._onObjectMatched, this);
            }
            if (this.getOwnerComponent().getRouter().getRoute("IOOwnerReqView")) {
                this.getOwnerComponent().getRouter().getRoute("IOOwnerReqView").attachPatternMatched(this._onObjectMatched, this);
            }

        },
        navToReqView:function(){
            this.getOwnerComponent().getRouter().navTo("Worklist");
        },
        addNavButtoninWF: function(){
            var oExpTitleText = this.getView().byId("idExpIOTitleHeading");
            var oSnapTitleText = this.getView().byId("idSnapIOTitleHeading");
            var oHBoxExp = this.getView().byId("hboxExpIOTitle");
            var oHBoxSnap = this.getView().byId("hboxSnapIOTitle");
            if (this.oButtonExp) {
                oHBoxExp.removeItem(this.oButtonExp);
                this.oButtonExp.destroy();
                this.oButtonExp = null;
            }

            if (this.oButtonSnap) {
                oHBoxSnap.removeItem(this.oButtonSnap);
                this.oButtonSnap.destroy();
                this.oButtonSnap = null;
            }
            if (this.getOwnerComponent().getModel("appConstants").getProperty("/isReqView")) {
                if (!this.oButtonExp) {
                var oButtonExp = new sap.m.Button({
                      type: "Back",
                    visible: true,
                    press: this.navToReqView.bind(this)
                }).addStyleClass("customBackBtnClassReqView");

                var oButtonSnap = new sap.m.Button({
                    type: "Back",
                    visible: true,
                    press: this.navToReqView.bind(this)
                }).addStyleClass("customBackBtnClassReqView");

                
                oHBoxExp.insertItem(oButtonExp, 0);
                oHBoxSnap.insertItem(oButtonSnap, 0);
            }
                oExpTitleText.addStyleClass("sapUiTinyMarginTop");
                oSnapTitleText.addStyleClass("sapUiTinyMarginTop");

                this.getView().byId("idIOHeaderCnt").addStyleClass("customStyleHeaderCntClass");
                this.getView().byId("idIODynamicHeader").addStyleClass("customStyleObjTitleClass");

                
                this.oButtonExp = oButtonExp;
                this.oButtonSnap = oButtonSnap;
            } else {
                

                oExpTitleText.removeStyleClass("sapUiTinyMarginTop");
                oSnapTitleText.removeStyleClass("sapUiTinyMarginTop");

                this.getView().byId("idIOHeaderCnt").removeStyleClass("customStyleHeaderCntClass");
                this.getView().byId("idIODynamicHeader").removeStyleClass("customStyleObjTitleClass");
            }

        },
        fnCurrentStateSuccessCallback: function (oResult, self) {
            //initiate current state model
            self.getOwnerComponent().getModel("currentStateModel").setData(oResult);
            sap.ui.core.BusyIndicator.hide();
        },
    fnCurrentStateErrorCallback: function (oError, self) {
            MessageBox.error(oError.responseText, {
                contentWidth: "600px"
            });
            sap.ui.core.BusyIndicator.hide();
        },
        _onObjectMatched: function (evt) {
            this.getView().byId("idIOPage").setShowHeader(false);
            this.getView().byId("IOPageDynamicSideContent").setVisible(true);
            this.getOwnerComponent().getModel("appConstants").setProperty("/isOldVersionReq", false);
            this.getOwnerComponent().getModel("appConstants").refresh();
            this.getView().setVisible(true);
            this.getOwnerComponent().getModel("appConstants").setProperty("/routePath","IOOwnerDetailPage");
            if(evt.getParameter("name") === "IOOwnerReqView"){
                this.getOwnerComponent().getModel("appConstants").setProperty("/isReqView",true);
            }else{
                this.getOwnerComponent().getModel("appConstants").setProperty("/isReqView",false);
            }
            this.addNavButtoninWF();
            if (this.getView().getModel()) {
                this.getView().getModel().setData();
            }
            this.bTabSelected = false;
            this.sUserTaskId = false;
            this.aWfLogs = false;
            this.sRootInstanceId = evt.getParameter("arguments").ID;
            this.aUserTaskIds = [];
            this.getOwnerComponent().getModel("appConstants").setProperty("/urlInstanceID", this.sRootInstanceId);
            this.i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            this.getView().setBusy(true);
            const sInstanceID = evt.getParameter("arguments").ID;
            if (this.bInitialLoad || evt.getParameter("name") === "IOOwnerReqView" ||  this.getOwnerComponent().getModel("appConstants").getProperty("/isAfterWfAction")) {
                Models.getMyInboxInstanceDetails(this.fnSuccessCallback, this.fnErrorCallback, this, sInstanceID);
            }
            const sLoggedInUser = this.getOwnerComponent().getModel("userDetails").getProperty("/email");
            const oContextObject = this.getOwnerComponent().getModel("wfInstanceModel").getData();
            const isCurrentProcesser = oContextObject ? formatter.formatUrl(oContextObject.CurrentProcessorEmail, sLoggedInUser, oContextObject.TechnicalState, oContextObject.currentStateID) : false;
            if (isCurrentProcesser) {
                this.getView().byId("idIODetailMsg").setVisible(false);
                this.getView().byId("IOPageDynamicSideContent").setVisible(true);
                this.getView().byId("idIOPage").setShowFooter(true);
                this.onLoadIOOwnerRequest();
                //hide Action history content
                // const oDynamicSideView = this.getView().byId("IOPageDynamicSideContent");
                // oDynamicSideView.setShowSideContent(false);
                // //show action history
                // this.getView().byId("openSideContentBtnIOPage").setVisible(true);
            } else {
                this.getView().byId("IOPageDynamicSideContent").setVisible(false);
              appView.onOpenTaskProcessedMsgDialog();
                this.getView().setBusy(false);
            }
            this.bInitialLoad = false;
            this.getOwnerComponent().getModel("appConstants").setProperty("/isAfterWfAction",false);
        },
        fnSuccessCallback: function (oResponse, self) {
            self.getOwnerComponent().getModel("wfInstanceModel").setData(oResponse.value[0]);
            self.getOwnerComponent().getModel("wfInstanceModel").refresh();
            sap.ui.core.BusyIndicator.hide();
        },
        fnErrorCallback: function (oError, self) {
            MessageBox.error(oError.responseText, {
                contentWidth: "600px"
            });
            sap.ui.core.BusyIndicator.hide();
        },
        onLoadIOOwnerRequest: function () {
            Models._getWfExecutionLogs(this, this.sRootInstanceId, this.fnSuccessGetExecutionLogs);

        },
        fnSuccessGetExecutionLogs: function (result, self) {
            //Get Wf execution logs to track task history
            if (result[result.length - 1].subflow) {
                for (let i = 0; i < result.length; i++) {
                    if (result[i].subflow && result[i].type === "REFERENCED_SUBFLOW_STARTED") {
                        if (result[i].subflow.workflowInstanceId) {
                            Models._getWfExecutionLogs(self, result[i].subflow.workflowInstanceId, self.fnSuccessGetSubFlowExecutionLogs);
                        }
                    }
                }
            } else {
                self.sUserTaskId = result[result.length - 1].taskId;
                if (self.sUserTaskId) {
                    self.getView().byId("idIODetailMsg").setVisible(false);
                    self.getView().byId("IOPageDynamicSideContent").setVisible(true);
                    self.getView().byId("idIOPage").setShowFooter(true);
                    Models._getWfTaskDetails(self, self.sUserTaskId, self.fnSuccessGetWfTaskDetails, self.fnErrorGetWfTaskDetails);
                } else {
                    self.getView().byId("idIODetailMsg").setVisible(true);
                    self.getView().byId("IOPageDynamicSideContent").setVisible(false);
                    self.getView().byId("idIOPage").setShowFooter(false);
                    self.getView().setBusy(false);
                    const i18nModel = self.getOwnerComponent().getModel("i18n").getResourceBundle();
                    if(result[result.length-1].type.includes("FAILED")){
                        self.getView().byId("idIODetailMsg").setTitle(i18nModel.getText("taskFailed"));
                        self.getView().byId("idIODetailMsg").setDescription(i18nModel.getText("taskFailedDesc"));
                        self.getView().byId("idBtnDetIORefresh").setVisible(false);
                        if (self.getOwnerComponent().getModel("appConstants").getProperty("/isReqView")) {
                            //execute on Request view
                            self.getView().byId("idIOPage").setShowHeader(true);
                        } else {
                            //execute on open task view
                            self.getView().byId("idIOPage").setShowHeader(false);
                        }
                    }else{
                        self.getView().byId("idBtnDetIORefresh").setVisible(true);
                        self.getView().byId("idIODetailMsg").setTitle(i18nModel.getText("taskRefresh"));
                        self.getView().byId("idIODetailMsg").setDescription(i18nModel.getText("taskRefreshDesc"));
                          
                        if (self.getOwnerComponent().getModel("appConstants").getProperty("/isReqView")) {
                            //execute on Request view
                            self.getView().byId("idIOPage").setShowHeader(true);
                        } else {
                            //execute on open task view
                            self.getView().byId("idIOPage").setShowHeader(false);
                        }
                    }
                }

            }
        },
        //Get Subflow execution logs
        fnSuccessGetSubFlowExecutionLogs: function (result, self) {
            if (result[result.length - 1].recipientUsers) {
                const sLoggedInUserId = self.getOwnerComponent().getModel("userDetails").getProperty("/user_name").toUpperCase();
                const aRecipentUser = result[result.length - 1].recipientUsers.filter((user) => user.toUpperCase() === sLoggedInUserId);
                if (aRecipentUser.length) {
                    self.sUserTaskId = result[result.length - 1].taskId;
                    self.aUserTaskIds.push(self.sUserTaskId);
                    if (self.sUserTaskId) {
                        self.getView().byId("idIODetailMsg").setVisible(false);
                        self.getView().byId("IOPageDynamicSideContent").setVisible(true);
                        self.getView().byId("idIOPage").setShowFooter(true);
                        if (self.getView().getModel() && self.getView().getModel().getProperty("/UserTaskIds")) {
                            //  self.aUserTaskIds.reverse();
                            const aAssignments = [];
                            for (let i = 0; i < self.aUserTaskIds.length; i++) {
                                aAssignments.push({
                                    "title": "Assignment-" + (i + 1),
                                    "wfId": self.aUserTaskIds[i]
                                });
                            }
                            self.getView().getModel().setProperty("/UserTaskIds", aAssignments);
                            self.getView().byId("idAssignmentTabHeader").setSelectedKey(self.aUserTaskIds[0]);

                        } else {
                            Models._getWfTaskDetails(self, self.sUserTaskId, self.fnSuccessGetWfTaskDetails);
                        }
                    } else {
                        self.getView().byId("idIODetailMsg").setVisible(true);
                        self.getView().byId("IOPageDynamicSideContent").setVisible(false);
                        self.getView().byId("idIOPage").setShowFooter(false);
                        self.getView().setBusy(false);
                    }
                }
            }
        },
        fnSuccessGetWfTaskDetails: function (result, that) {
            //initaite task-history model
            const taskInstanceModel = new JSONModel(result);
            taskInstanceModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
            that.getView().setModel(taskInstanceModel, "taskInstanceModel");
            Models._getWfTaskContextDetails(that, that.sUserTaskId, that.fnSuccessGetContextDetails);
        },
        fnSuccessGetContextDetails: function (result, that) {
            result.EngagementType = result.EngagementType ? result.EngagementType : '0001'
            if(result.EngagementType==='0002')
				result.requestDetails.c2c_DealText = result.requestDetails.c2c_Deal ? "Yes" : "No"
            that.getView().setBusy(true);
            if (!that.bTabSelected) {
                const oContextModel = new JSONModel(result);
                that.getView().setModel(oContextModel);
                //add OrgId,OrgType,RequestType for older tasks
                if (typeof (oContextModel.getData()["SalesOrgID"]) === "string") {
                    oContextModel.getData()["OrgID"] = oContextModel.getData()["SalesOrgID"];
                    oContextModel.getData()["OrgType"] = "SORG";
                    oContextModel.getData()["RequestType"] = "Opportunity"
                }
                if (!oContextModel.getProperty("/currentStepID") && oContextModel.getProperty("/currentStepName") === "Presales Manager Approval") {
                    oContextModel.setProperty("/currentStepID", "MANAPP")
                }
                // document service interaction
                that.oAttachmentsModel = new JSONModel();
                that.oAttachmentsModel.downloadEnabled = false;
                that.getView().setModel(that.oAttachmentsModel, "attachmentsModel");
               // that.loadAttachments();
                oContextModel.setProperty("/namesOfPartiesVisible", false);
                let aInvolvedPartiesKeys = oContextModel.getProperty("/requestDetails/involvedPartiesKeys");
                if (aInvolvedPartiesKeys && aInvolvedPartiesKeys.length > 0) {
                    if (aInvolvedPartiesKeys.includes("1") || aInvolvedPartiesKeys.includes("2") || aInvolvedPartiesKeys.includes("3")) { // if SAP Partner, SAP Consulting or Customer Advisory is selected
                        oContextModel.setProperty("/namesOfPartiesVisible", true);
                    }
                }
                /**Git 132 (Form template changes + add new opp fields)
                 * update deal info
                  */
                CommonJS.parseGetOppDataResponse(oContextModel.getProperty("/CPICalls/getDataFromCRM/Response/d/"),that);
                that._fetchFormActions(that);
                that.i18nModel = that.getOwnerComponent().getModel("i18n").getResourceBundle();

                const oReqAreaModel = new JSONModel(that._getRequestAreaBaseURL());
                that.getView().setModel(oReqAreaModel, "RequestAreaAPIData");

                const oRejectionCodeModel = new JSONModel(that._getRejectionCodeBaseURL());
                that.getView().setModel(oRejectionCodeModel, "RejectionCodeAPIData");

                /* Start of Code for CurrentTask Instance ID Update  */
                that.updateCurrentInstance();
                /* End of Code for CurrentTask Instance ID Update  */

                that._initializeAssignments();

                that._fetchFormConfigData(that);
                const taskInstanceModel = that.getView().getModel("taskInstanceModel");
                const sSubject = taskInstanceModel.getData().subject;
               // that.getView().byId("presalesRequestIOOwnerPageHeader").setText(sSubject);
                //that.getView().byId("presalesRequestIOOwnerSnappedPageHeader").setText(sSubject);

                //fetch internal order from context
                let sInternalOrder1 = that.getView().getModel().getProperty("/INTERNAL_ORDER1");
                let sInternalOrder2 = that.getView().getModel().getProperty("/INTERNAL_ORDER2");
                let aInternalOrder = [
                    sInternalOrder1 ? sInternalOrder1 : "",
                    sInternalOrder2 ? sInternalOrder2 : ""
                ].filter(io => io);

                const oInternalOrderModel = new JSONModel(aInternalOrder);
                that.getView().setModel(oInternalOrderModel, "internalOrderModel");
                // that.aUserTaskIds.reverse();
                const aAssignments = [];
                for (let i = 0; i < that.aUserTaskIds.length; i++) {
                    aAssignments.push({
                        "title": "Assignment-" + (i + 1),
                        "wfId": that.aUserTaskIds[i]
                    });
                }
                that.getView().getModel().setProperty("/UserTaskIds", aAssignments);
                that.getView().byId("idAssignmentTabHeader").setSelectedKey(that.aUserTaskIds[0]);
                that.getView().getModel().getProperty("/approvalHistory").reverse();
                that.getView().getModel().refresh();
                that.getView().setBusy(false);
                //that.handleSideContentHide();
                var currentStateID = that.getOwnerComponent().getModel("wfInstanceModel").getData().currentStateID
                if (!(currentStateID === 'REQSUB' || currentStateID === 'REQTER' || currentStateID === 'REQCRT')) {
                    that.handleSCBtnPress()
                } else {
                    that.handleSideContentHide()
                }
            } else {
                that.getView().getModel().setProperty("/io_OwnerResource", result.io_OwnerResource)
                that._initializeAssignments();
                that.getView().getModel().refresh();
                that.getView().setBusy(false);
            }
              //Git 132 (Form template/standardization ) - Get user comments
              const sInstanceID = that.getOwnerComponent().getModel("wfInstanceModel").getProperty("/InstanceID");
                  that.getOwnerComponent().getModel("wfInstanceModel").setProperty("/bIsUserCommentInput",true);
              that.getOwnerComponent().getModel("wfInstanceModel").refresh();	
                  Models._getUserComments(that,sInstanceID,"GET")
              //setAttachment url visibility
              if (that.getView().getModel().getProperty("/requestDetails/attachmentUrls")) {
                const bAttachmentUrl = that.getView().getModel().getProperty("/requestDetails/attachmentUrls").length ? true : false;
                that.getView().getModel().setProperty("/isAttachmentUrl", bAttachmentUrl);
                if(bAttachmentUrl){
                    const aFinalAttachmentUrl = that.getView().getModel().getProperty("/requestDetails/attachmentUrls");
                    let bAttachmentFinalUrl = true;
                    aFinalAttachmentUrl.forEach(function(item,iIndex){
                        if(!item.url && !item.urlName){
                             bAttachmentFinalUrl = false;
                        }
                    });
                    that.getView().getModel().setProperty("/isAttachmentUrl", bAttachmentFinalUrl);
                }
                
            }
           //Git 132 (Form template/standardization ) - Set header fields
           
                CommonJS.setHeaderDetails(that);
                CommonJS.getResFieldDetails(that);
           
            //call task service to filter sub-tasks
            Models.getSubTaskInstanceDetails(that);
            let oModelData = that.getView().getModel().getData();
            let oAccountOwnerDetails = { accOwnerDetails: oModelData["accOwnerDetails"] };
            let oOppOwnerDetails = { oppOwnerDetails: oModelData["oppOwnerDetails"] };
            let aEmpIds = [
                oAccountOwnerDetails?.accOwnerDetails?.id,
                oOppOwnerDetails?.oppOwnerDetails?.id
            ].filter(Boolean);
            //Check account/opp owner details
            CommonJS.checkUserActive(that, aEmpIds, oAccountOwnerDetails, oOppOwnerDetails);
        },
     
        _initializeAssignments: function () {
            //initialize assignments model
            const oAssignments = {
                "assignments": [this.getView().getModel().getProperty("/io_OwnerResource")]
            };
            const oModel = new JSONModel(oAssignments);
            this.getView().setModel(oModel, "assignmentsModel");
        },
        //on Select assignment tab
        onSelectIOAssignmentTab: function (evt) {
            this.sUserTaskId = this.getView().byId("idAssignmentTabHeader").getSelectedKey();
            this.getView().setBusy(true);
            this.bTabSelected = true;
            Models._getWfTaskDetails(this, this.sUserTaskId, this.fnSuccessGetWfTaskDetails);
        },
        _fetchFormActions: function (self) {
            let oModel = self.getView().getModel().getData();
            let sOrgID;
            if (oModel.OrgType === "SORG") {
                sOrgID = 'ParentOrgID' in oModel ? self.getView().getModel().getProperty("/ParentOrgID") : this.getView().getModel().getProperty("/OrgID");
            } else {
                sOrgID = self.getView().getModel().getProperty("/OrgID");
            }
            var sEngagementType=self.getView().getModel().getData().EngagementType
            const sOrgType = self.getView().getModel().getProperty("/OrgType");
            const sUserTask = "IO_Owner";
            const sFormatOrgID = self._getOrgIDnumber(sOrgID, sOrgType);
            const sUrl = self._getRuntimeBaseURL() + `/cap/req-area-api-/Action?$filter=eng_Type_ID eq '${sEngagementType}' and (orgID eq '${sFormatOrgID}' and orgType eq '${sOrgType}') and (UserTask eq '${sUserTask}')`;
            $.ajax({
                contentType: "application/json",
                url: sUrl,
                async: false,
                type: "GET",
                success: function (oData) {
                    const aFormActionsValues = oData.value;
                    const oFormValue = aFormActionsValues.reduce(function (formVal, val) {
                        (formVal[val.Action_ID] = formVal[val.Action_ID] || []).push(val);
                        return formVal;
                    }, {})
                    const oFormActionsConfigModel = new JSONModel(oFormValue);
                    self.getView().setModel(oFormActionsConfigModel, "formActionsConfigModel");

                },
                error: function (oError) {

                }
            });
        },
        _getOrgIDnumber: function (sOrgID, sOrgType) {
            if (sOrgType === "SORG") {
                return Number(sOrgID.replace('SORG-', '')).toString();
            } else {
                return sOrgID;
            }
        },
        //set form configurable model
        _fetchFormConfigData: function (self) {
            const sOrgID = self.getView().getModel().getData().ParentOrgID ? self.getView().getModel().getProperty("/ParentOrgID") : self.getView().getModel().getProperty("/OrgID");
            const sOrgType = self.getView().getModel().getProperty("/OrgType");
            const sFormatOrgID = self._getOrgIDnumber(sOrgID, sOrgType);
             var sEngagementType=self.getView().getModel().getData().EngagementType
            const sUrl = self._getRuntimeBaseURL() + `/cap/req-area-api-/Form_Tab?$expand=Fields&&$filter=orgID eq '${sFormatOrgID}' and orgType eq '${sOrgType}' and eng_Type_ID eq '${sEngagementType}'`;

            $.ajax({
                contentType: "application/json",
                url: sUrl,
                async: false,
                type: "GET",
                success: function (oData) {
                    const aDataNew = [];

                    for (let i = 0; i < oData.value.length; i++) {
                        if (!aDataNew[oData.value[i].ID]) {
                            aDataNew[oData.value[i].ID] = [];
                        }
                        aDataNew[oData.value[i].ID] = oData.value[i];
                        const aDataNewFields = [];
                        for (let j = 0; j < oData.value[i].Fields.length; j++) {

                            if (!aDataNew[oData.value[i].Fields[j].ID]) {
                                aDataNewFields[oData.value[i].Fields[j].ID] = [];
                            }
                            aDataNewFields[oData.value[i].Fields[j].ID] = oData.value[i].Fields[j];
                            // aDataNew[oConfigData.value[i].ID].Fields = aDataNewFields[oConfigData.value[i].Fields[j].ID
                        }
                        aDataNew[oData.value[i].ID].Fields = aDataNewFields;
                    }
                    const oFormConfigModel = new JSONModel(aDataNew);
                    self.getView().setModel(oFormConfigModel, "formConfigModel");
                },
                error: function (oError) {

                }
            });
        },
        formatFormConfigVisibility: function (sVal) {
            if (sVal === "X") {
                return true;
            } else {
                return false;
            }
        },
        formatFormConfigReqAreaVisibility(sVal, sReqArea) {
            return sReqArea !== "" && sVal === "X";
        },
        formatFieldForNonRise: function (isRise, formVisibility) {
            if (formVisibility === "X") {
                let isRiseVisibility = !isRise;
                return isRiseVisibility;
            } else {
                return false;
            }
        },
        formatFieldBasedOnMultipleProperties: function (bVal, formVisibility) {
            if (formVisibility === "X") {
                return bVal;
            } else {
                return false;
            }
        },
        formatFieldSelectField: function (bVal, formVisibility, isMeetingPlanned) {
            if (formVisibility && isMeetingPlanned) {
                return bVal;
            } else {
                return false;
            }
        },
        parseGetOppDataResponse: function (data) {
            if (data) {
                const oDealInfo = {
                    accName: data.ACCOUNT_NAME,
                    oppName: data.DESCRIPTION,
                    decision: data.DECISION,
                    reviewerName: data.DQReview.REVIEWER1_NAME,
                    forecast: data.FORECAST,
                    onPremRevenue: data.LICENSE_REVENUE,
                    cloudRevenue: data.CLOUD_REVENUE,
                    currency: data.CURRENCY,
                    CURR_PHASE: data.CURR_PHASE,
                    STATUS: data.STATUS,
                    TCV: data.Items.results.length ? data.Items.results[0].TOTAL_TCV : ""
                };

                //set dates
                const jsonClosingDate = data.EXPECT_END,
                    closingDateFull = jsonClosingDate ? new Date(parseInt(jsonClosingDate.substr(6))) : null;
                oDealInfo.closingDate = closingDateFull;

                const jsonReviewDate = data.DQReview.REVIEW_DATE1,
                    reviewDateFull = jsonReviewDate ? new Date(parseInt(jsonReviewDate.substr(6))) : null;
                oDealInfo.reviewDate = reviewDateFull;

                //process Notes
                const aNotes = data.Notes.results;
                for (let i = 0; i < aNotes.length; i++) {
                    switch (aNotes[i].TDID) {
                        case "ZD01":
                            oDealInfo.compelEventText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD02":
                            oDealInfo.fundingText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD03":
                            oDealInfo.custStakeText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD04":
                            oDealInfo.custChallengesText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD05":
                            oDealInfo.custBusDriversText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD06":
                            oDealInfo.solutionText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD07":
                            oDealInfo.competitorsText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD08":
                            oDealInfo.partnersText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD10":
                            oDealInfo.execSummary = aNotes[i].CONC_LINES;
                            break;
                        default:
                    }
                }

                //process Attributes
                const aAttributes = data.Attributes.results;
                for (let i = 0; i < aAttributes.length; i++) {
                    switch (aAttributes[i].ATTR_CODE) {
                        case "AS0103":
                            oDealInfo.compelEventQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0104":
                            oDealInfo.fundingQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0105":
                            oDealInfo.custStakeQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0106":
                            oDealInfo.custChallengesQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0107":
                            oDealInfo.custBusDriversQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0108":
                            oDealInfo.solutionQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0109":
                            oDealInfo.competitorsQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0110":
                            oDealInfo.partnersQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0132":
                            oDealInfo.decision = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0133":
                            oDealInfo.reviewerName = aAttributes[i].ATTR_DESCR;
                            break;
                        case "AS0134":
                            oDealInfo.reviewDate = new Date(aAttributes[i].ATTR_VALUE.slice(0, 4) + "-" + aAttributes[i].ATTR_VALUE.slice(4, 6) + "-" + aAttributes[i].ATTR_VALUE.slice(-2));
                            break;
                        default:
                    }
                }
                oDealInfo.attributes = aAttributes;
                this.getView().getModel().setProperty("/dealInfo", oDealInfo);
                this.getView().getModel().refresh();
            }
        },
        configureView: function (sStep) {
            const that = this;
            const startupParameters = this.getComponentData().startupParameters;
            const taskInstanceModel = this.getModel("taskInstanceModel");
            const approveText = this.getMessage("APPROVE");
            const rejectText = this.getMessage("REJECT");
            const forwardText = this.getMessage("FORWARD");
            const sSubject = taskInstanceModel.getData().subject;
            const oModel = this.getView().getModel();
            const oFormActionsModelData = this.getView().getModel("formActionsConfigModel").getData();
            this.byId("presalesRequestApprovalPageHeader").setObjectTitle(sSubject);

            //add approve button

            const aApproveActionBtn = {
                sBtnTxt: approveText,
                enabled: true,
                visible: "true",
                onBtnPressed: function () {
                    that._onCallUserSearchHelps(that);
                }
            };
            // Add 'Approve' action to the task
            if (oFormActionsModelData.idapprove[0].Visibility === "X") {
                startupParameters.inboxAPI.addAction({
                    action: "approve",
                    label: oFormActionsModelData.idapprove[0].Label,
                    type: "Accept"
                },
                    // Set the onClick function
                    aApproveActionBtn.onBtnPressed);
            }

            //Send back to processor button

            const oRejectAction = {
                sBtnTxt: rejectText,
                onBtnPressed: function () {
                    that._onValidateAssignment("reject");
                }
            };
            //add reject action
            if (oFormActionsModelData.idreject[0].Visibility === "X") {
                startupParameters.inboxAPI.addAction({
                    action: "reject",
                    label: oFormActionsModelData.idreject[0].Label,
                    type: "Emphasized"
                }, oRejectAction.onBtnPressed);
            }

            //add Reject(close) button
            const oClosedRejectBtn = {
                sBtnTxt: "close",
                onBtnPressed: function () {
                    that._onValidateAssignment("Close");
                }
            };
            if (oFormActionsModelData.idclose && oFormActionsModelData.idclose[0].Visibility === "X") {
                startupParameters.inboxAPI.addAction({
                    action: "close",
                    label: oFormActionsModelData.idclose[0].Label,
                    type: "Reject"
                }, oClosedRejectBtn.onBtnPressed);
            }

        },
        _selectIOownerDialog: function (processContext, taskId, sDecision) {
            const oIoOwnerData = new JSONModel([]);
            const that = this
            this.getView().setModel(oIoOwnerData, "ioOwnerModel");
            if (!this.pIOOwnerSelectDialog) {
                this.pIOOwnerSelectDialog = this.loadFragment({
                    name: "com.sap.bpm.IOownerForm.view.IOOwneSelectDialog"
                });
            }
            this.pIOOwnerSelectDialog.then(function (oIOOwnerSelectDialog) {
                that._IoOwnerDialog = oIOOwnerSelectDialog;
                that.getView().getModel().setProperty("/forWardEnabled", false);
                that.getView().getModel().refresh(true);
                oIOOwnerSelectDialog.open();
                return;
            }.bind(this));

        },
        onIOOwnerSearch: function (oEvent) {
            const sSearchQuery = oEvent.getParameter("query");
            this.getView().getModel().setProperty("/ioOwnerListBusy", true);
            this.getView().getModel().setProperty("/ioOwnerListBusy", false);
            if (sSearchQuery) {
                Models._callEmployeeService(sSearchQuery, 100, 0, this);
            } else {
                this.getView().getModel().setProperty("/forWardEnabled", false);
                this.getView().setModel(new JSONModel([]), "ioOwnerModel");
            }
            this.getView().getModel().refresh();
        },
        onSelectIOOwner: function (evt) {
            let oSelectedContext = evt.getParameter("listItem").getBindingContext("ioOwnerModel").getObject()
            this.getView().getModel().setProperty("/forWardIoOwnerDetails", oSelectedContext);
            this.getView().getModel().setProperty("/forWardEnabled", true);
            this.getView().getModel().refresh();
        },
        handleForwardRequest: function (evt) {
            const sTaskId = this.getView().getModel("taskInstanceModel").getProperty("/id");
            const oAssignmentsModel = this.getView().getModel("assignmentsModel");
            const aAssignments = oAssignmentsModel.getData().assignments;
            const oSelectedOwnerDetails = this.getView().getModel().getProperty("/forWardIoOwnerDetails");
            const iOownerDetails = {
                "IOOwnerName": `${oSelectedOwnerDetails.firstName} ${oSelectedOwnerDetails.lastName}`,
                "IOOwnerEmail": oSelectedOwnerDetails.email,
                "IOOwnerUserId": oSelectedOwnerDetails.ID
            }
            aAssignments[0].NominatedResources[0].ioOwnerDetails = iOownerDetails;
            this._triggerComplete(aAssignments, sTaskId, "Forward")
            this._IoOwnerDialog.close();
        },
        handleCancelForward: function () {
            this._IoOwnerDialog.close();
        },
        // This method is called when the confirm button is click by the end user
        _triggerComplete: function (assignmentData, taskId, sDecision) {
            const oThisController = this;
            const cFLPUserInfo = this.getOwnerComponent().getModel("userDetails");
            const workflowBaseurl = this._getWorkflowRuntimeBaseURL();
            assignmentData[0].NominatedResources[0].Io_Decision = sDecision;
            sap.ui.core.BusyIndicator.show();

            $.ajax({
                // Call workflow API to get the xsrf token
                url: workflowBaseurl + "rest/v1/xsrf-token",
                method: "GET",
                headers: {
                    "X-CSRF-Token": "Fetch"
                },
                success: function (result, xhr, data) {

                    // After retrieving the xsrf token successfully
                    const token = data.getResponseHeader("X-CSRF-Token");

                    // form the context that will be updated
                    const oBasicData = {
                        context: {
                            "IOUserTaskID": oThisController.getView().getModel("taskInstanceModel").getProperty("/id"),
                            "decision": sDecision,
                            "io_OwnerResource": assignmentData[0],
                            "currentProcessor": {
                                "email": cFLPUserInfo.getProperty("/email"),
                                "fullName": cFLPUserInfo.getProperty("/name"),
                                "id": oThisController.getView().getModel().getData().io_OwnerIds
                            }
                        },
                        "status": "COMPLETED"
                    };
                    switch (sDecision) {
                        case "Approve":
                            oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idapprove[0].ID;
                            oThisController.sSuccessMsg = oThisController.i18nModel.getText("approvedMsg");
                            break;
                        case "Forward":
                            oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idforward[0].ID;
                            oThisController.sSuccessMsg = oThisController.i18nModel.getText("forwardedMsg");
                            break;
                        case "Reject":
                            oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idreject[0].ID;
                            oThisController.sSuccessMsg = oThisController.i18nModel.getText("closeMsg");
                            break;
                        case "Close":
                            oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idclose[0].ID;
                            oThisController.sSuccessMsg = oThisController.i18nModel.getText("rejectedMsg");
                            break;
                        case "Proceed":
                            oBasicData.context.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idproceed[0].ID;
                            oThisController.sSuccessMsg = oThisController.i18nModel.getText("approvedMsg");
                            break;
                        default:
                            oBasicData.context.decision_ID = ""
                            break;
                    }
                      //update refrence id for older request
                      if (typeof oThisController.getView().getModel().getData().RequestID !== "object") {
                        if( oThisController.getView().getModel().getProperty("/updatedRefId")){
                            oBasicData.context.RequestID = {
                                "value": oThisController.getView().getModel().getProperty("/updatedRefId")
                            }
                        }
                    }
                    if (oThisController.getView().getModel().getProperty("/accOwnerDetails")?.id) {
                        //update account owner payload
                        oBasicData.context.accOwnerDetails = oThisController.getView().getModel().getProperty("/accOwnerDetails")
                    }
                    if (oThisController.getView().getModel().getProperty("/oppOwnerDetails")?.id) {
                        //update opportunity owner payload
                        oBasicData.context.oppOwnerDetails = oThisController.getView().getModel().getProperty("/oppOwnerDetails")
                    }
                    $.ajax({
                        // Call workflow API to complete the task
                        url: workflowBaseurl + "rest/v1/task-instances/" + taskId,
                        method: "PATCH",
                        contentType: "application/json",
                        // pass the updated context to the API
                        data: JSON.stringify(oBasicData),
                        headers: {
                            // pass the xsrf token retrieved earlier
                            "X-CSRF-Token": token
                        },
                        // refreshTask needs to be called on successful completion
                        success: function (result, xhr, data) {
                            const aUserTaskIds = oThisController.getView().getModel().getProperty("/UserTaskIds");
                            const sSelectedAssignmentTab = oThisController.getView().byId("idAssignmentTabHeader").getSelectedKey();
                            if (aUserTaskIds.length > 1) {
                                for (let i = 0; i < aUserTaskIds.length; i++) {
                                    if (aUserTaskIds[i].wfId === sSelectedAssignmentTab) {
                                        aUserTaskIds.splice(i, 1);
                                    }
                                }
                                oThisController.getView().getModel().refresh();
                                oThisController.getView().byId("idAssignmentTabHeader").setSelectedKey(aUserTaskIds[0].wfId);
                                oThisController.getView().byId("idAssignmentTabHeader").fireSelect();
                            } else {
                                if(oThisController.getOwnerComponent().getModel("appConstants").getProperty("/isReqView")){
                                    oThisController.navToReqView();
                                }else{
                                    oThisController.getOwnerComponent().getModel("appConstants").setProperty("/isAfterWfAction",true);
                                    setTimeout(function () {
                                        CommonJS._refreshTask(oThisController);
                                    }, 1000)
                                }
                            }
                            oThisController.getView().setBusy(false);
                               // oThisController._refreshTask();
                            MessageToast.show(oThisController.sSuccessMsg, {
                                duration: 6000
                            });
                            sap.ui.core.BusyIndicator.hide();
                        }

                    });
                }
            });

        },

        /**
         * DOCUMENT SERVICE INTEGRATION
         */
        loadAttachments: function () {
            // get workflow ID
            const taskInstanceModel = this.getModel("taskInstanceModel");
            workflowInstanceId = taskInstanceModel.getData().workflowInstanceId;
            const workflowFileUploadId = this.getView().getModel().getProperty("/workflowFileUploadId") ? this.getView().getModel().getProperty("/workflowFileUploadId") : workflowInstanceId;
            const docServieBaseUrl = this._getDocServiceRuntimeBaseURL();
            const sUrl = docServieBaseUrl + "/WorkflowManagement/HarmonyPresalesRequests/" + workflowFileUploadId + "/?succinct=true";
            const oSettings = {
                "url": sUrl,
                "method": "GET",
                // "async": false
            };
            const oThisController = this;
            $.ajax(oSettings)
                .done(function (results) {
                    oThisController._mapAttachmentsModel(results);
                })
                .fail(function (err) {
                    if (err !== undefined) {
                        // const oErrorResponse = $.parseJSON(err.responseText);
                        // MessageToast.show(oErrorResponse.message, {
                        //     duration: 6000
                        // });
                    } else {
                        // MessageToast.show("Unknown error!");
                    }
                });
        },
        // assign data to attachments model
        _mapAttachmentsModel: function (data) {
            data.downloadEnabled = data && data.objects && data.objects.length > 0;
            this.oAttachmentsModel.setData(data);
            this.oAttachmentsModel.refresh();
            this.getView().setBusy(false);
        },

        // formatting functions
        formatTimestampToDate: function (timestamp) {
            const oFormat = DateFormat.getDateTimeInstance();
            return oFormat.format(new Date(timestamp));
        },
        formatFileLength: function (fileSizeInBytes) {
            let i = -1;
            const byteUnits = [' kB', ' MB', ' GB', ' TB', 'PB', 'EB', 'ZB', 'YB'];
            do {
                fileSizeInBytes = fileSizeInBytes / 1024;
                i++;
            } while (fileSizeInBytes > 1024);

            return Math.max(fileSizeInBytes, 0.1).toFixed(1) + byteUnits[i];
        },

        formatDownloadUrl: function (objectId) {
            const docServieBaseUrl = this._getDocServiceRuntimeBaseURL();
            return docServieBaseUrl + "/WorkflowManagement/HarmonyPresalesRequests/"
                + workflowInstanceId + "?objectId=" + objectId + "&cmisselector=content";
        },
        _getRuntimeBaseURL: function () {
            let appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
            let appPath = appId.replaceAll(".", "/");
            let appModulePath = sap.ui.require.toUrl(appPath);
            return appModulePath;
        },
        _getWorkflowRuntimeBaseURL: function () {
            return this._getRuntimeBaseURL() + "/workflowruntime/";
        },
        _getDocServiceRuntimeBaseURL: function () {
            return this._getRuntimeBaseURL() + "/docservice";
        },
        _getRequestAreaBaseURL: function () {
            let sSalesOrgID = 'ParentOrgID' in this.getView().getModel().getData() ? this.getView().getModel().getData().ParentOrgID : this.getView().getModel().getData().OrgID;
            if (this.getView().getModel().getProperty("/OrgType") === 'SORG') {
                sSalesOrgID = Number(sSalesOrgID.replace('SORG-', '')).toString();
            }
            return this._getRuntimeBaseURL() + "/cap/req-area-api-/Public_ReqArea?$filter=orgID eq '" + sSalesOrgID + "'";
        },
        _getConstantsBaseURL: function () {
            return this._getRuntimeBaseURL() + "/cap/req-area-api-/Parameter";
        },
        _getRejectionCodeBaseURL: function () {
            let sSalesOrgID = 'ParentOrgID' in this.getView().getModel().getData() ? this.getView().getModel().getData().ParentOrgID : this.getView().getModel().getData().OrgID;
            if (this.getView().getModel().getProperty("/OrgType") === 'SORG') {
                sSalesOrgID = Number(sSalesOrgID.replace('SORG-', '')).toString();
            }
            const sManagerORresource = this.getView().getModel().getProperty("/currentStepID") === "MANAPP" ? "4" : "5";
            return this._getRuntimeBaseURL() + "/cap/req-area-api-/Rejection_Codes?$filter=OrgID eq '" + sSalesOrgID + "' and UserTask_ID eq '" + sManagerORresource + "'";
        },
        _onValidateAssignment: function (sDecision) {
            let oAssignmentsModel = this.getView().getModel("assignmentsModel");
            const that = this;

            const sTaskId = this.getView().getModel("taskInstanceModel").getProperty("/id");
            const aStaffingData = [];
            oAssignmentsModel.getData().assignments.forEach(function (assignments) {
                const aNominatedResource = assignments.NominatedResources[0];
                if (sDecision === "Approve") {
                    aStaffingData.push(aNominatedResource);
                    that._formStaffingPayload(that, aStaffingData);
                }
            });
            if (sDecision === "reject" && !aStaffingData.length) {
                // that._triggerComplete(oAssignmentsModel.getData().assignments, sTaskId, "Submit");
                that._openSubmitDialog(
                    oAssignmentsModel.getData().assignments,
                    sTaskId,
                    "Reject"
                );
            }
            if (sDecision === "Close") {
                that._openSubmitDialog(
                    oAssignmentsModel.getData().assignments,
                    sTaskId,
                    "Close"
                );
            }

        },
        /* Start of Code for CurrentTask Instance ID Update  */

        updateCurrentInstance: function () {
            let WfExt_data = {};
            var URL = this._getRuntimeBaseURL() + "/cap/wf/WfInstance";
	var oModelData = this.getView().getModel().getData();
    let that = this;
	const oContextModelData = this.getView().getModel();
	WfExt_data.instance_GUID = oContextModelData.getProperty("/WfID_PresalesRequestApproval");
	WfExt_data.parentInstance_GUID = oContextModelData.getProperty("/parentInstanceID");
    if(!WfExt_data.parentInstance_GUID){
        WfExt_data.parentInstance_GUID = this.getOwnerComponent().getModel("wfInstanceModel").getData().ParentInstanceID;
     }
	WfExt_data.currentTaskInstanceID = this.getView().getModel("taskInstanceModel").getProperty("/id");
	WfExt_data.currentTaskURL = window.location.href;
	const instGuid = `(instance_GUID='${WfExt_data.instance_GUID}',parentInstance_GUID='${WfExt_data.parentInstance_GUID}')`;
             $.ajax({
                url:  URL+`?&$filter=instance_GUID eq ''`,
                type: "GET",
                async: true,
                beforeSend: function (xhr) {
                    xhr.setRequestHeader("X-CSRF-Token", "Fetch");
                },
                complete: function (xhr) {
                    token = xhr.getResponseHeader("X-CSRF-Token"); let oSettings = {
                        "url": URL + instGuid ,
                        "method": "PATCH",
                        "async": false,
                        "data": JSON.stringify(WfExt_data),
                        "headers": {
                            'X-CSRF-Token': token
                        },
                        "contentType": "application/json",
                    };
                    $.ajax(oSettings)
                        .done(function (results) { 
                            if(typeof that.getView().getModel().getData().RequestID !== "object" && typeof results === "object"){
                                if(results.refID){
                                    oContextModelData.setProperty("/updatedRefId" ,results.refID);
                                }
                            }
                        })
                        .fail(function (err) {
                            MessageBox.error("Current user Instance ID update failed!");
                        });
                }
            });
        },
        // change event for io owner decision 'Approve' or 'Reject'
        onIOOwnerProceedToApprove: function () {
            //call userSearchHelps to get perner no
            const oAssignmentsModel = this.getView().getModel("assignmentsModel");
            const oBindingContextObj = oAssignmentsModel.getData().assignments[0].NominatedResources[0];
            Models._callUserSearchHelps(oBindingContextObj.userId, this, this.fnSuccessUserSearchHelpsCallBack, this.fnErrorUserSearchHelpsCallBack, oBindingContextObj);
            oAssignmentsModel.refresh(true);
        },
        fnErrorUserSearchHelpsCallBack: function (oError, oController) {
            oController.fnErrorMessage(oError.responseText);
        },
        fnErrorMessage: function (errorText) {
            MessageBox.error(errorText, {
                contentWidth: "600px"
            });
            sap.ui.core.BusyIndicator.hide();
        },
        //staffing calll
        _formStaffingPayload: function (self, oNominatedResources) {
            let oFinalPayload = [];
            oNominatedResources.forEach(function (nominatedResource) {
                //set staffing payload
                oFinalPayload.push(self._setStaffingPayload(self, nominatedResource));
            });
            sap.ui.core.BusyIndicator.show(0);
            Models._postStaffingDetails(oFinalPayload, self, self.fnSuccessPostStaffing, self.fnErrorPostStaffing)
        },
        //convert date to milliseconds
        formatDateToMilliSeconds: function (dateVal) {
            const iDate = Date.parse(new Date(dateVal));
            return `\/Date(${iDate})\/`;
        },
        //convert date to date string
        getDateString: function (date) {
            const year = date.getFullYear();
            let month_append;
            let dat_append;
            const month = date.getMonth() + 1;
            if (month < 10) {
                month_append = "0";
            } else {
                month_append = "";
            }
            const dat = date.getDate();
            if (dat < 10) {
                dat_append = "0";
            } else {
                dat_append = "";
            }
            return (year + "" + month_append + "" + month + "" + dat_append + "" + dat);
        },
        //set staffing payload
        _setStaffingPayload: function (self, oNominatedResources) {
            const oStaffingPayload = {
                "Actexp": oNominatedResources.staffingPurposeKey ? oNominatedResources.staffingPurposeKey : "",
                "ActexpStr": oNominatedResources.staffingPurpose ? oNominatedResources.staffingPurpose : "",
                "Action": "2",
                "Begda": oNominatedResources.dateValue ? self.formatDateToMilliSeconds(oNominatedResources.dateValue) : "00000000",
                "BegdaStr": oNominatedResources.dateValue ? self.getDateString(new Date(oNominatedResources.dateValue)) : "00000000",
                "Bukrs": oNominatedResources.sCompanyCode ? oNominatedResources.sCompanyCode : "",
                "CostObjType": "IO",
                "Endda": oNominatedResources.secondDateValue ? self.formatDateToMilliSeconds(oNominatedResources.secondDateValue) : "00000000",
                "EnddaStr": oNominatedResources.secondDateValue ? self.getDateString(new Date(oNominatedResources.secondDateValue)) : "00000000",
                "EntryId": "O",
                "LogSystem": "CRM_MTR",
                "Name": oNominatedResources.fullName,
                "Snote": "",
                "Objnr": "",
                "Pernr": "00000000",
                "PernrStr": oNominatedResources.Pernr,
                "Posnr": "",
                "ReadOnly": false,
                "TaskLevel": oNominatedResources.staffingPurposeKey !== "E" ? oNominatedResources.taskLevelKey : "NONE",
                "Tasktype": "",
                "TasktypeStr": "",
                "Trtkl": "",
                "UserType": "",
                "Vbeln": oNominatedResources.internalOrder ? oNominatedResources.internalOrder.toString() : "",
                "Zexpdays": oNominatedResources.maxNoOfDaysToBookIO ? oNominatedResources.maxNoOfDaysToBookIO.toString() : ""

            }
            return oStaffingPayload;
        },
        //Sucess staffing POST call
        fnSuccessPostStaffing: function (response, self) {
            sap.ui.core.BusyIndicator.hide();
            const oAssignmentsModel = self.getView().getModel("assignmentsModel");
            const sTaskId = self.getView().getModel("taskInstanceModel").getProperty("/id");
            try {
                if (JSON.parse(response.headers["sap-message"]).severity === "error") {
                    //Show warning message to proceed for Wf triifer
                    const sMsg = `${JSON.parse(response.headers["sap-message"]).message}.${self.i18nModel.getText("staffingGenericError")}`
                    self._proceedToWfService(self, sMsg);
                } else {
                    self._showStaffingSuccessMessage(self.i18nModel.getText("staffingSuccessMsg"));
                    //proceed wf trigger
                    self._triggerComplete(oAssignmentsModel.getData().assignments, sTaskId, "Approve");
                }
            } catch (err) {
                //show success message
                self._showStaffingSuccessMessage(self.i18nModel.getText("staffingSuccessMsg"));
                //proceed wf trigger
                self._triggerComplete(oAssignmentsModel.getData().assignments, sTaskId, "Approve");
            }
        },
        //show staffing POST success message
        _showStaffingSuccessMessage: function (sMsg) {
            MessageBox.show(
                sMsg, {
                icon: MessageBox.Icon.SUCCESS,
                title: "Success"
            });

        },
        //error call back for POST staffing
        fnErrorPostStaffing: function (error, self) {
            sap.ui.core.BusyIndicator.hide();
            const sMsg = self.i18nModel.getText("staffingErrorCallBackText");
            //proceed wf trigger
            self._proceedToWfService(self, sMsg);

        },
        //proceed wf trigger
        _proceedToWfService: function (self, sMsg) {
            const oAssignmentsModel = self.getView().getModel("assignmentsModel");
            const sTaskId = self.getView().getModel("taskInstanceModel").getProperty("/id");
            //show warning message for POST staffing
            const sBtnText = self.getView().getModel("formActionsConfigModel").getData().idproceed[0].Label;
            MessageBox.show(
                sMsg, {
                icon: MessageBox.Icon.WARNING,
                title: "Warning",
                actions: [sBtnText, MessageBox.Action.CANCEL],
                emphasizedAction: sBtnText,
                onClose: function (oAction) {
                    if (oAction === sBtnText) {
                        self._triggerComplete(oAssignmentsModel.getData().assignments, sTaskId, "Proceed");
                    }
                }
            }
            );
        },
        //Success GET call for UserSearchHelps
        fnSuccessUserSearchHelpsCallBack: function (data, self, oAssignmentContext) {
            const sStep = self.getView().getModel().getProperty("/currentStepID");
            const sMsg = self.i18nModel.getText("pernerServiceNoErrorMsg");
            if (data) {
                if (data.d.results.length) {
                    if (data.d.results[0].Pernr) {
                        //add perner number to assignmentcontext
                        oAssignmentContext.Pernr = data.d.results[0].Pernr;
                        self._onValidateAssignment("Approve");
                    }
                } else {
                    self._showErrorMsg(self, sMsg);
                }

            } else {
                if (sStep !== "MANAPP") {
                    self._showErrorMsg(self, sMsg);
                }
            }
        },
        //generic error message
        _showErrorMsg: function (self, sMsg) {
            MessageBox.show(
                sMsg, {
                icon: MessageBox.Icon.WARNING,
                title: "Warning",
                actions: [MessageBox.Action.OK],
                emphasizedAction: MessageBox.Action.OK,

            }
            );
        },
        _setCommentTexts: function (sDecision) {
            let oFieldText = {};
            switch (sDecision) {
                case "Approve":
                    oFieldText.placeholder = this.i18nModel.getText("staffingApproveCommentMsg");
                    oFieldText.commentValueStateText = "";
                    break;
                case "Close":
                    oFieldText.placeholder = this.i18nModel.getText("ENTER_TEXT_OPT_IO");
                    oFieldText.commentValueStateText = this.i18nModel.getText("rejectReasonRequired");
                    break;
                default:
                    oFieldText.placeholder = this.i18nModel.getText("ENTER_COMMENT");
                    oFieldText.commentValueStateText = this.i18nModel.getText("commentValueState");
                    break;
            }
            return oFieldText;

        },
        _openSubmitDialog: function (assignments, taskId, sDecision) {
            const oModel = this.getView().getModel();
            oModel.setProperty("/IOownerComments", "");
            const that = this;
            let oFieldText = this._setCommentTexts(sDecision)
            // if (!this.oSubmitDialog) {
            assignments[0].NominatedResources[0].IOownerComments = false;
            this.oSubmitDialog = new Dialog({
                type: DialogType.Message,
                title: this.i18nModel.getText("ENTER_COMMENT"),
                content: [
                    new TextArea("submissionNote", {
                        width: "100%",
                        value: '{/IOownerComments}',
                        placeholder: oFieldText.placeholder,
                        valueState: '{/commentsState}',
                        valueStateText: oFieldText.commentValueStateText,
                        liveChange: function (oEvent) {
                            const sComment = oEvent.getParameter("value").trim();
                            this.oSubmitDialog.getBeginButton().setEnabled(sComment.length > 0);
                            assignments[0].NominatedResources[0].IOownerComments = sComment;
                            if ((sDecision === "Close" || sDecision === "Reject") && sComment.length > 0) {
                                oModel.setProperty("/commentsState", "None");
                            } else {
                                oModel.setProperty("/commentsState", "Error");
                            }
                            oModel.setProperty("/comments", sComment);
                        }.bind(this)
                    })
                ],
                beginButton: new Button({
                    type: ButtonType.Emphasized,
                    text: this.i18nModel.getText("OK"),
                    press: function () {
                        if (assignments[0].NominatedResources[0].IOownerComments) {
                            that._triggerComplete(assignments, taskId, sDecision);
                            this.oSubmitDialog.close();
                            this.oSubmitDialog.destroy();
                        } else {
                            oModel.setProperty("/commentsState", "Error");
                        }
                    }.bind(this)
                }),
                endButton: new Button({
                    text: this.i18nModel.getText("CANCEL"),
                    press: function () {
                        this.oSubmitDialog.close();
                        this.oSubmitDialog.destroy();
                    }.bind(this)
                })
            });
            //to get access to the controller's model
            this.getView().addDependent(this.oSubmitDialog);
            // }
            // toggle compact style
            syncStyleClass("sapUiSizeCompact", this.getView(), this.oSubmitDialog);
            this.oSubmitDialog.open();
        },
        onRejectIOOwner: function () {
            this._onValidateAssignment("reject");
        },
        onCloseIOTask: function () {
            this._onValidateAssignment("Close");
        },
        handleSCBtnPress: async function () {
            const oDynamicSideView = this.getView().byId("IOPageDynamicSideContent");
            const oOPSideContentBtn = this.getView().byId("openSideContentBtnIOPage");
            //GIT 277- common function to fetch the action history
            CommonJS._setActionHistoryModel(this,oDynamicSideView,oOPSideContentBtn)
        },
        handleSideContentHide: function () {
            sap.ui.core.BusyIndicator.show(0);
            const oDynamicSideView = this.getView().byId("IOPageDynamicSideContent");
            const sCurrentBreakpoint = oDynamicSideView.getCurrentBreakpoint();
            const oOPSideContentBtn = this.getView().byId("openSideContentBtnIOPage");
            if (sCurrentBreakpoint === "S") {
                oDynamicSideView.toggle();
            } else {
                oDynamicSideView.setShowSideContent(false);
                sap.ui.core.BusyIndicator.hide();
            }
            oOPSideContentBtn.setVisible(true);

            setTimeout(function () {
                this.byId("openSideContentBtnIOPage").focus();
            }.bind(this));
            sap.ui.core.BusyIndicator.hide();
        },
        formatAttachmentVisibility: function (bConfig, isAttachment) {
            if (bConfig === "X" && isAttachment) {
                return true;
            } else {
                return false;
            }
        },
        /**
           * event trigger for old request opp routing
           *
           * @param {Object} evt -event object
           */
        handleUrlRouting:function(evt){
            Models._handleUrlRouting(evt);
         },
          /**Git 132 (Form template changes + add new opp fields)
         *press event to show more processor list
         * @param {object} oEvent -The current control(link) event
         */
		onPressUserList: function (oEvent) {
			const oView = this.getView(),
				  that = this;
			if (!this._pMoreUerListPopOver) {
				//load userList more fragment
				this._pMoreUerListPopOver = Fragment.load({
					id: oView.getId(),
					name: "com.dealsupport.melodyrequest.fragments.userListMore",
					controller: this
				}).then(function (oMoreUerListDialog) {
					that._moreUserListDialog = oMoreUerListDialog;
					oView.addDependent(oMoreUerListDialog);
					return oMoreUerListDialog;
				});
			}

			this._pMoreUerListPopOver.then(function (oMoreUerListDialog) {
				 oMoreUerListDialog.openBy(oEvent.getSource());
			});

		},
		 /**Git 132 (Form template changes + add new opp fields)
         *press event to close processor popover list
         */
		onCloseMoreLisPopOver:function(){
			if(this._moreUserListDialog){
				this._moreUserListDialog.close();
			}
		}

    });
});