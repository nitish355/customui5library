sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"com/dealsupport/melodyrequest/model/models",
	"sap/ui/model/Filter",
], function (JSONModel, models, Filter) {
	"use strict";
	var globalFilterRef = {};

	return {
		_onValueHelpAcc: function (oController, oMultiInput) {
			this._ovalueHelpPartnerFragment = sap.ui.xmlfragment("com.dealsupport.melodyrequest.fragments.PartnerValueHelpDialogFilterbar", oController);
			oController.getView().addDependent(this._ovalueHelpPartnerFragment);
			this._ovalueHelpPartnerFragment.setKey("PARTNER");
			var oPartnerModel = new JSONModel();
			this.columns = new JSONModel({
				cols: [{
					label: "Name",
					template: "NAME",
				}, {
					label: "Business Partner",
					template: "PARTNER",
				}, {
					label: "Partner Type",
					template: "CH_PARTNER_TYPE",
				}, {
					label: "Country",
					template: "COUNTRY_NAME",
				}, {
					label: "Address",
					template: "ADDRESS",
				}]
			});
			this._ovalueHelpPartnerFragment.getTableAsync().then(
				function (oTable) {
					oTable.setModel(oPartnerModel);
					oTable.setModel(this.columns, "columns");
					if (oTable.bindRows) {
						oTable.bindAggregation("rows", "/");
					}
				}.bind(this)
			);
			try {
				if (oMultiInput) {
					this._ovalueHelpPartnerFragment.setTokens(oMultiInput.getTokens());
				}
			} catch (err) { };
			this._ovalueHelpPartnerFragment.open();
			return this._ovalueHelpPartnerFragment;
		},
		_onFilterBarPartnerSearch: function (that) {
			var sValue = that._ovalueHelpPartnerFragment.getFilterBar().getBasicSearchValue();
			var aSelectionSet = that._ovalueHelpPartnerFragment.getFilterBar().getFilterGroupItems();
			aSelectionSet.reduce(function (aResult, oControl) {
				if (oControl.getControl().getValue()) {
					aResult.push(
						new Filter({
							path: oControl.getControl().getName(),
							value1: oControl.getControl().getValue()
						})
					);
				}
				return aResult;
			}, []);
			models.getPartnerModelData(that, sValue);
		},
		_onValueHelpAccCancelPress: function (oController) {
			oController._ovalueHelpPartnerFragment.close();
		},

		_onValueHelpAccAfterClose: function (oController) {
			oController._ovalueHelpPartnerFragment.destroy();
		},

	};
});
