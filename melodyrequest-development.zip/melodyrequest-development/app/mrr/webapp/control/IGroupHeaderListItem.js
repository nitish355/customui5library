/*eslint-disable */
sap.ui.define([
	"sap/m/GroupHeaderListItem",
	"sap/m/Text",
	"sap/m/Link",
	"sap/m/ObjectStatus"
], function (List,Text,Link,ObjectStatus) {
	"use strict";

	/**
	 * Constructor for a new OTTOInput
	 */
	let IGroupHeaderListItem = List.extend("com.dealsupport.melodyrequest.control.IGroupHeaderListItem", {
		metadata: {
			aggregations: {

				status: {
					type: "sap.m.ObjectStatus",
					multiple: false,
					defaultClass: ObjectStatus
				},
				link: {
					type: "sap.m.Link",
					multiple: false,
					defaultClass: Link
				},
				customText:{
					type:"sap.m.Text", 
					multiple: false,
					defaultClass: Text
				}

			}
		},
		init: function () {

		},
		renderer: function (oRm, oControl) {
			oRm.openStart("tr", oControl);
			oRm.addClass("sapMLIB sapMLIB-CTX sapMLIBTypeInactive sapMLIBFocusable sapMGHLI customTrStyle");
			oRm.writeClasses();
			oRm.openEnd();

			oRm.openStart("td", oControl);
			oRm.addClass("sapMListTblHighlightCell");
			oRm.openEnd();
			oRm.close('td');


			oRm.openStart("td", oControl);
			oRm.addClass("sapMGHLICell sapMTblCellFocusable");
			oRm.writeClasses();
			oRm.openEnd();
			oRm.openStart("div", oControl);
			oRm.addClass("sapMLIBContent customStyleDiv");
			oRm.writeClasses();
			oRm.openEnd();
			oRm.openStart('span', oControl);
			oRm.addClass("sapMGHLITitle");
			oRm.writeClasses();
			oRm.openEnd();
			oRm.write(oControl.getTitle());
			oRm.write("&nbsp");
			oRm.renderControl(oControl.getLink());
			oRm.write("&nbsp");
			oRm.renderControl(oControl.getCustomText());
			oRm.write("&nbsp");
			oRm.renderControl(oControl.getStatus());
			oRm.close('span');
			oRm.close('div');
			oRm.openStart("div", oControl);
			oRm.addClass("sapMTblItemNav");
			oRm.writeClasses();
			oRm.openEnd();
			oRm.close('div');
			oRm.openStart("div", oControl);
			oRm.addClass("sapMTblItemNav");
			oRm.writeClasses();
			oRm.openEnd();
			oRm.close('div');
			oRm.openStart("div", oControl);
			oRm.addClass("sapMTblItemNav");
			oRm.writeClasses();
			oRm.openEnd();
			oRm.close('div');
			oRm.openStart("div", oControl);
			oRm.addClass("sapMTblItemNav");
			oRm.writeClasses();
			oRm.openEnd();
			oRm.close('div');
			oRm.openStart("div", oControl);
			oRm.addClass("sapMTblItemNav");
			oRm.writeClasses();
			oRm.openEnd();
			oRm.close('div');
			oRm.openStart("div", oControl);
			oRm.addClass("sapMTblItemNav");
			oRm.writeClasses();
			oRm.openEnd();
			oRm.close('div');
			oRm.openStart("div", oControl);
			oRm.addClass("sapMTblItemNav");
			oRm.writeClasses();
			oRm.openEnd();
			oRm.close('div');
			oRm.openStart("div", oControl);
			oRm.addClass("sapMTblItemNav");
			oRm.writeClasses();
			oRm.openEnd();
			oRm.close('div');
			oRm.close('td');
			oRm.openStart("td", oControl);
			oRm.addClass("sapMListTblNavCol");
			oRm.openEnd();
			oRm.close('td');
			oRm.openStart("td", oControl);
			oRm.addClass("sapMListTblNavigatedCell");
			oRm.openEnd();
			oRm.close('td');
			oRm.close('tr');
		},
		onAfterRendering: function () {
			if (sap.ui.core.Control.prototype.onAfterRendering) {
				sap.ui.core.Control.prototype.onAfterRendering.apply(this, arguments);
			}
		}

	});

	return IGroupHeaderListItem;

});