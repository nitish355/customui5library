sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "sap/ui/Device",
    "sap/m/MessageBox"
], function (JSONModel , Device , MessageBox) {
    "use strict";

    return {

       //Handling Error Messages
       setErrorMessage: function(oError, self,isDialog,bIsOppServiceFails){
        sap.ui.core.BusyIndicator.hide();
        let i18nModel = self.getOwnerComponent().getModel("i18n").getResourceBundle();
        let sErrorMess = !bIsOppServiceFails ? i18nModel.getText("Somethingwentwrong"):self.getOwnerComponent().getModel("appConstants").getProperty("/ServiceDown/0/Value");
        let sMsgText = oError.responseText && !bIsOppServiceFails ? oError.responseText : sErrorMess;
        if (!isDialog) {
            MessageBox.error(sMsgText, {
            });
        }
        else {
            return sMsgText;
        }
         // Check if the busy dialog is currently initialized and available
         if(appView._pBusyDialog){
            appView.getView().setBusy(false);
            appView.onRouteBusyDialogClosed();
        }
    }       
    };
});
