sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"com/dealsupport/melodyrequest/model/users",
	"sap/ui/model/Filter",
], function (JSONModel, Users, Filter) {
	"use strict";
	var globalFilterRef = {};

	return {
		_onValueHelpUser: function (oController, oMultiInput, isUserID,sLabel) {
			appView._ovalueHelpUserFragment = sap.ui.xmlfragment("com.dealsupport.melodyrequest.fragments.ValueHelpUser", oController);
			appView._ovalueHelpUserFragment.addStyleClass(appView.getOwnerComponent().getContentDensityClass());
			oController.getView().addDependent(appView._ovalueHelpUserFragment);
			if (isUserID) {
				appView._ovalueHelpUserFragment.setKey("ID");
				appView._ovalueHelpUserFragment.setDescriptionKey("fullName");
			} else {
				appView._ovalueHelpUserFragment.setKey("email");
				appView._ovalueHelpUserFragment.setDescriptionKey("fullName");
			}
             //Pass ID for Resource Filter
			if(oController.oMultiInputID.includes("id-filter-resource")){
				appView._ovalueHelpUserFragment.setKey("ID");
			}

			var oUsermodel = new JSONModel();
			appView.columns = new JSONModel({
				cols: [{
					label: "First Name",
					template: "firstName",
				}, {
					label: "Last Name",
					template: "lastName",
				}, {
					label: "EMail",
					template: "email",
				}, {
					label: "User ID",
					template: "ID",
				},],
			});
			var that = oController;
			appView._ovalueHelpUserFragment.getTableAsync().then(
				function (oTable) {
					var sHeaderText = appView._ovalueHelpUserFragment.getContent()[0].getItems()[1].getItems()[1].getContent()[0].getHeaderText();
					appView._ovalueHelpUserFragment.setTitle(sLabel);
					appView._ovalueHelpUserFragment.getFilterBar().setShowGoOnFB(false);
					let i18nModel = appView.getOwnerComponent().getModel("i18n").getResourceBundle();
					let sPlaceHolder = i18nModel.getText("userSearchPlaceHolder");
					appView._ovalueHelpUserFragment.getFilterBar()._oBasicSearchField.setPlaceholder(sPlaceHolder);
					if (sHeaderText === "No items selected") {
						appView._ovalueHelpUserFragment.getButtons()[0].setEnabled(false);
					} else {
						appView._ovalueHelpUserFragment.getButtons()[0].setEnabled(true);
					}
					oTable.setModel(oUsermodel);
					oTable.setModel(appView.columns, "columns");
					if (oTable.bindRows) {
						oTable.bindAggregation("rows", "/");
					}
					oTable.getExtension()[0].getContent()[0].setVisible(true);
					//appView._ovalueHelpUserFragment.update();
				}.bind(this)
			);
			try {
				if (oMultiInput) {
					appView._ovalueHelpUserFragment.setTokens(oMultiInput.getTokens());
				}
			} catch (err) { };
			appView._ovalueHelpUserFragment.open();
			//appView._ovalueHelpUserFragment.getTable().attachRowSelectionChange(appView.liveTableSelection);
			if (appView._ovalueHelpUserFragment.getFilterBar() && appView._ovalueHelpUserFragment.getFilterBar().getContent() &&
				appView._ovalueHelpUserFragment.getFilterBar().getContent()[0] && appView._ovalueHelpUserFragment.getFilterBar().getContent()[0].getContent()
			) {
				appView.content = appView._ovalueHelpUserFragment.getFilterBar().getContent()[0].getContent();
				for (var k = 0; k < appView.content.length; k++) {
					if (appView.content[k].getId() && appView.content[k].getId() === "userSearchFB_id-btnGo") {
						appView.content[k].setVisible(true);
					}
				}
			}
			return appView._ovalueHelpUserFragment;
		},
		liveTableSelection: function (self) {
			// var oDialog = self.getSource().getParent().getParent().getParent();
			// var sHeaderText = oDialog.getContent()[0].getItems()[1].getItems()[1].getContent()[0].getHeaderText();
			// if (sHeaderText === "No items selected") {
			// 	oDialog.getButtons()[0].setEnabled(false);
			// } else {
			// 	oDialog.getButtons()[0].setEnabled(true);
			// }
		},
		_onFilterBarUserSearch: function (that) {
			const sSearch  =  that._ovalueHelpUserFragment.getFilterBar().getBasicSearchValue();
			//Call to employeeSerach
			if (sSearch.length >= 3) {
				let _top = 100,
					_skip = 0;
				Users.callUserApi(sSearch, _top, _skip, that);
			}else{
                const i18nModel = appView.getOwnerComponent().getModel("i18n").getResourceBundle();
                const sValidationMsg = i18nModel.getText("searchValidationMsg");
				if(!sSearch){
					that._ovalueHelpUserFragment.getTable().getModel().setData([])
					that._ovalueHelpUserFragment.getTable().getModel().refresh()

				}else{
					sap.m.MessageToast.show(sValidationMsg);
				}
				
            }
		},

		_onUserSearchValueChange: function (oEvent, oFragment) {
			/*Update global filter reference with new value*/
			globalFilterRef[oEvent.getParameter("id")] = oEvent.getParameter("newValue");
			if (oEvent.getParameter("newValue") !== "") {
				/*new value is entered so enable the GO button*/
				appView.setGoBtnDisplay(oFragment, true);
			} else {
				/*new value is empty but should check if other input filters are available*/
				var filterIdArr = ["usersearch_firstNameID", "usersearch_lastNameID", "usersearch_userID", "usersearch_sapNameID"];
				var filterFlag = false;
				for (var index = 0; index < filterIdArr.length; index++) {
					if (globalFilterRef[filterIdArr[index]] && globalFilterRef[filterIdArr[index]] !== "") {
						/*filter value available*/
						filterFlag = true;
						break;
					}
				}
				if (!filterFlag) {
					/*no other filter values are available so disable the Go button*/
					appView.setGoBtnDisplay(oFragment, false);
				}
			}
		},

		setGoBtnDisplay: function (oFragment, _eValue) {
			if (oFragment.getFilterBar() && oFragment.getFilterBar().getContent() && oFragment.getFilterBar().getContent()[0] &&
				oFragment.getFilterBar().getContent()[0].getContent()) {
				appView.content = oFragment.getFilterBar().getContent()[0].getContent();
				for (var k = 0; k < appView.content.length; k++) {
					if (appView.content[k].getId() && appView.content[k].getId() === "userSearchFB_id-btnGo") {
						appView.content[k].setEnabled(_eValue);
						appView.content[k].setVisible(true);
					}
				}
			}
		},

		_onValueHelpUserCancelPress: function (oController) {
			oController._ovalueHelpUserFragment.close();
		},

		_onValueHelpUserAfterClose: function (oController) {
			oController._ovalueHelpUserFragment.destroy();
		},

	};
});
