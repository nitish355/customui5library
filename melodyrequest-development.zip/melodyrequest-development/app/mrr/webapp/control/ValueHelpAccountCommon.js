sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"com/dealsupport/melodyrequest/model/models",
	"sap/ui/model/Filter",
], function (JSONModel, models, Filter) {
	"use strict";
	var globalFilterRef = {};

	return {
		_onValueHelpAcc: function (oController, oMultiInput) {
			this._ovalueHelpAccFragment = sap.ui.xmlfragment("com.dealsupport.melodyrequest.fragments.AccountValueHelpDialogFilterbar", oController);
			oController.getView().addDependent(this._ovalueHelpAccFragment);
			this._ovalueHelpAccFragment.setKey("PARTNER");
			var oAccountModel = new JSONModel();
			this.columns = new JSONModel({
				cols: [{
                    label: "Name",
                    template: "NAME",
                }, {
                    label: "Business Partner",
                    template: "PARTNER",
                }, {
                    label: "User",
                    template: "USERID",
                }, {
                    label: "Address",
                    template: "ADDRESS",
                }]
			});
			this._ovalueHelpAccFragment.getTableAsync().then(
				function (oTable) {
					oTable.setModel(oAccountModel);
					oTable.setModel(this.columns, "columns");
					if (oTable.bindRows) {
						oTable.bindAggregation("rows", "/");
					}
				}.bind(this)
			);
			try {
				if (oMultiInput) {
					this._ovalueHelpAccFragment.setTokens(oMultiInput.getTokens());
				}
			} catch (err) { };
			this._ovalueHelpAccFragment.open();
			return this._ovalueHelpAccFragment;
		},
		_onFilterBarAccountSearch: function (that) {
			var sValue = that._ovalueHelpAccFragment.getFilterBar().getBasicSearchValue();
			var aSelectionSet = that._ovalueHelpAccFragment.getFilterBar().getFilterGroupItems();
			aSelectionSet.reduce(function (aResult, oControl) {
				if (oControl.getControl().getValue()) {
					aResult.push(
						new Filter({
							path: oControl.getControl().getName(),
							value1: oControl.getControl().getValue()
						})
					);
				}
				return aResult;
			}, []);
		
			models.getAccountModelData(that , sValue );
		},
		_onValueHelpAccCancelPress: function (oController) {
			oController._ovalueHelpAccFragment.close();
		},

		_onValueHelpAccAfterClose: function (oController) {
			oController._ovalueHelpAccFragment.destroy();
		},

	};
});
