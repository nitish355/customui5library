sap.ui.define([

    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/Token",
    "com/dealsupport/melodyrequest/control/ValueHelpUserCommon",
    "com/dealsupport/melodyrequest/model/enterKey",
    "com/dealsupport/melodyrequest/control/ValueHelpAccountCommon",
    "com/dealsupport/melodyrequest/control/ValueHelpPartnerCommon",
    "com/dealsupport/melodyrequest/model/users",
    "sap/ui/model/json/JSONModel",
    "com/dealsupport/melodyrequest/model/models",
    "com/dealsupport/melodyrequest/model/formatter",
    "sap/m/library",
    "sap/m/Button",
    "com/dealsupport/melodyrequest/control/ErrorHandle",
    "sap/ui/core/Fragment",
], function (Filter, FilterOperator, Token, UserCommon, EnterKey, UserAccCommon, UserPartnerCommon, Users, JSONModel,models,formatter,library,Button,ErrorHandle,Fragment) {
    "use strict";

    return {
        //valueHelp dialog for Request Area
        _onRequestAreaValueHelpRequested: function (oEvent, oController, isSingleSelect) {
            var sInputValue = oEvent.getSource().getValue();
            if (!oController.pReqAreaValueDialog) {
                oController.pReqAreaValueDialog = oController.loadFragment({
                    name: "com.dealsupport.melodyrequest.fragments.ReqAreaValueHelpDialogFilterbar"
                });
            }
            oController.pReqAreaValueDialog.then(function (oReqAreaValueDialog) {
                oReqAreaValueDialog.addStyleClass(appView.getOwnerComponent().getContentDensityClass());
                // create a filter for the binding
                oReqAreaValueDialog.getBinding("items").filter([new Filter(
                    "Request_Area",
                    FilterOperator.Contains,
                    sInputValue
                )]);
                // open value help dialog filtered by the input value
                oReqAreaValueDialog.open(sInputValue);
                if (isSingleSelect) {
                    oReqAreaValueDialog.getAggregation("_dialog").getContent()[1].setMode("SingleSelectLeft")
                } else {
                    oReqAreaValueDialog.getAggregation("_dialog").getContent()[1].setMode("MultiSelect")
                }
            }.bind(oController));
        },
        _handleReqAreaValueHelpSearch: function (evt) {
            var sValue = evt.getParameter("value");
            var oFilter = new Filter(
                "Request_Area",
                FilterOperator.Contains,
                sValue
            );
            evt.getSource().getBinding("items").filter([oFilter]);
        },
        _handleReqAreaValueHelpClose: function (evt, oMultiInput, isSingleSelect) {
            const selectedContexts = evt.getParameters().selectedContexts;
            const selectedItems = [];
            selectedContexts.forEach(context => {
                const selectedItem = context.getObject();
                selectedItems.push(selectedItem);
            });
            evt.getParameters().selectedItems = selectedItems;
            const aSelectedItems = evt.getParameter("selectedItems");
            if (!isSingleSelect) {
                const oMultiInputTokens = oMultiInput.getTokens();
                if (aSelectedItems && aSelectedItems.length > 0) {
                    aSelectedItems.forEach(function (oItem) {
                        const bIsDuplicateToken = oMultiInputTokens.filter((oMultiInputToken) => {
                            if (oMultiInputToken.getText() === oItem.Request_Area) {
                                return true;
                            }
                        });
                        if (!bIsDuplicateToken.length) {
                            oMultiInput.addToken(new Token({
                                text: oItem.Request_Area
                            }));
                        }
                    });
                }
            } else {
                const oSelectedItem = aSelectedItems[0].Request_Area;
                oMultiInput.setValue(oSelectedItem);
            }
        },
        //user dialog
        _onUserValueHelpRequested: function (oController, oMultiInput, isUserID, sLabel) {
            oController._ovalueHelpUserFragment = UserCommon._onValueHelpUser(oController, oMultiInput, isUserID, sLabel);
            oController._ovalueHelpUserFragment.setRangeKeyFields([{
                label: "User",
                key: "ID",
                type: "string",
            }]);
            oController.aSelectedUsers = [];
            var oFilterGroupItems = oController._ovalueHelpUserFragment.getFilterBar().getFilterGroupItems();
            var that = oController;
            const _oBasicSearchField = new sap.m.SearchField();
            oController._ovalueHelpUserFragment.getFilterBar().setBasicSearch(_oBasicSearchField);
            // Trigger filter bar search when the basic search is fired
            _oBasicSearchField.attachSearch(function () {
                oController._ovalueHelpUserFragment.getFilterBar().search();
            });
            oFilterGroupItems.forEach(function (item) {
                EnterKey._enterPressKeyBind(that, item.getControl(), that.onFilterBarUserSearch, false);
            });
        },
        _onAccValueHelpRequested: function (oController, oMultiInput) {
            oController._ovalueHelpAccFragment = UserAccCommon._onValueHelpAcc(oController, oMultiInput);
        },
        _onPartnerValueHelpRequested: function (oController, oMultiInput) {
            oController._ovalueHelpPartnerFragment = UserPartnerCommon._onValueHelpAcc(oController, oMultiInput);
        },
        _onFilterBarUserSearch: function (oController) {
            UserCommon._onFilterBarUserSearch(oController);
            var that = oController;
            oController._ovalueHelpUserFragment.getTable().attachRowSelectionChange(function (evt) {
                that._onAddSelectedUser(evt, that);
            });
        },
        __onAddSelectedUser: function (evt, oController) {
            var oSearchUserModel = evt.getSource().getModel().getData();
            if (evt.getParameter("selectAll") === true) {
                oSearchUserModel.forEach(function (items) {
                    oController.aSelectedUsers.push(items);
                });
            } else {
                try {
                    var oSelectedUserObj = evt.getSource().getModel().getProperty(evt.getParameter("rowContext").getPath());
                    oController.aSelectedUsers.push(oSelectedUserObj);
                } catch (err) { };
            }
        },
        _onValueHelpUserOkPress: function (oEvent, oMultiInput, oController) {
            var aTokens = oEvent.getParameter("tokens");
            /* to display tokens in table: multi-input field */
             switch (true) {
                case oMultiInput.getId().includes("id-filter-requester"):
                    oController.getView().getModel("variant").setProperty("/reqNameId",[]);
                    oController.getView().getModel("variant").refresh();
                    break;
                case oMultiInput.getId().includes("id-filter-currentProcessor"):
                     oController.getView().getModel("variant").setProperty("/taskOwnerName",[]);
                    oController.getView().getModel("variant").refresh();
                    break;
                case oMultiInput.getId().includes("id-filter-resource"):
                    oController.getView().getModel("variant").setProperty("/resourceNameId",[]);
                    oController.getView().getModel("variant").refresh();
                    break;
                case oMultiInput.getId().includes("id-filter-processor"):
                    oController.getView().getModel("variant").setProperty("/processorNameId",[]);
                    oController.getView().getModel("variant").refresh();
                    break;
                default:
                    break;
            }

            var userstr = '{"userTokens":[]}';
            var tokensObj = JSON.parse(userstr);
            oMultiInput.removeAllTokens();
            oMultiInput.addToken();
            let aFilterTokens = function getSelectedTokens(Tokens) {
                return Tokens.map(item => {
                    // Create a new object to avoid mutating the original
                    return {
                        key: item.getKey(),
                        value: item.getText()
                    };
                });
            },
            bIsFilterSelect;
            switch (true) {
                case oMultiInput.getId().includes("id-filter-requester"):
                     oController.getView().getModel("variant").setProperty("/reqNameId",[]);
                    let aRequestorNameKeyValue = aFilterTokens(aTokens);
                    oMultiInput.removeAllTokens();
                    oController.getView().getModel("variant").setProperty("/reqNameId", aRequestorNameKeyValue);
                    oController.getView().getModel("variant").refresh();
                    bIsFilterSelect = true;
                    break;
                case oMultiInput.getId().includes("id-filter-currentProcessor"):
                    let aTaskOwnerNameKeyValue = aFilterTokens(aTokens);
                    oController.getView().getModel("variant").setProperty("/taskOwnerName", aTaskOwnerNameKeyValue);
                    oController.getView().getModel("variant").refresh();
                    bIsFilterSelect = true;
                    break;
                case oMultiInput.getId().includes("id-filter-resource"):
                    let aResourceNameKeyValue = aFilterTokens(aTokens);
                    oController.getView().getModel("variant").setProperty("/resourceNameId", aResourceNameKeyValue);
                    oController.getView().getModel("variant").refresh();
                    bIsFilterSelect = true;
                    break;
                case oMultiInput.getId().includes("id-filter-processor"):
                    let aProcessorNameKeyValue = aFilterTokens(aTokens);
                    oController.getView().getModel("variant").setProperty("/processorNameId", aProcessorNameKeyValue);
                    oController.getView().getModel("variant").refresh();
                    bIsFilterSelect = true;
                    break;
                default:
                    bIsFilterSelect = false;
                    break;
            }

            
         
        
                for (var i = 0; i < aTokens.length; i++) {
                    tokensObj.userTokens.push({
                        key: aTokens[i].getKey(),
                        name: aTokens[i].getText()
                    });
                    if (!bIsFilterSelect) {
                        oMultiInput.addToken(new Token({
                            key: aTokens[i].getKey(),
                            text: aTokens[i].getText()
                        }));
                    }
              
            }
            oController._ovalueHelpUserFragment.close();
        },
        _onValueHelpAccOkPress: function (oEvent, oMultiInput, oController) {
            var aTokens = oEvent.getParameter("tokens");
            /* to display tokens in table: multi-input field */
            var userstr = '{"userTokens":[]}';
            var tokensObj = JSON.parse(userstr);
            oMultiInput.removeAllTokens();
            oMultiInput.addToken();
            for (var i = 0; i < aTokens.length; i++) {
                tokensObj.userTokens.push({
                    key: aTokens[i].getKey(),
                    name: aTokens[i].getText()
                });
                oMultiInput.addToken(new Token({
                    key: aTokens[i].getKey(),
                    text: aTokens[i].getText()
                }));
            }
            oController._ovalueHelpAccFragment.close();
        },
        _onValueHelpPartnerOkPress: function (oEvent, oMultiInput, oController) {
            var aTokens = oEvent.getParameter("tokens");
            /* to display tokens in table: multi-input field */
            var userstr = '{"userTokens":[]}';
            var tokensObj = JSON.parse(userstr);
            oMultiInput.removeAllTokens();
            oMultiInput.addToken();
            for (var i = 0; i < aTokens.length; i++) {
                tokensObj.userTokens.push({
                    key: aTokens[i].getKey(),
                    name: aTokens[i].getText()
                });
                oMultiInput.addToken(new Token({
                    key: aTokens[i].getKey(),
                    text: aTokens[i].getText()
                }));
            }
            oController._ovalueHelpPartnerFragment.close();
        },
        _setNewResourceProfileObj: function (self) {
            return {
                "isValidation": false,
                "isExpanded": true,
                "BAIndustryMandatory":false,
                "BAIndustrySelectable":self.getOwnerComponent().getModel("mrrAppEngModel").getData().engagementSelectedKey=='0001'?true:false,
                "SolnAreaMandatory":false,
                "SolnAreaSelectable":self.getOwnerComponent().getModel("mrrAppEngModel").getData().engagementSelectedKey=='0001'?true:false,
                "isFilter":false,                
                "minSelect":0,
                "maxSelect":2,
                "solnAreaEnable":true,
                "industryEnable":true,
                "solnIndRequired":false,
                "midSectionDesc":appView.getOwnerComponent().
                getModel("mrrAppConfigModel").getProperty("/SolnInd_SelectionText/0/fieldDesc"),
                "legacyValidation":false,
                "fieldSelectionMidInfoIcon":false,
                TempEmployee: {
                    "Roles": [],
                    "TempRoleAreas": [],
                    "TempBAIndustries": [],
                    "SelectedHubs": [],
                    "TempBALoBs": [],
                    "TempCrossCvg": [],
                    "TempBASegments": [],
                    "BASegmentsBusy": false,
                    "BALoBBusy": false,
                    "CrossCvgBusy": false,
                    "hubLoBBusy": false,
                    "BAIndBusy": false,
                    "RoleAreas": [],
                    "BAIndustries": [],
                    "BASegments": [],
                    "CrossCvg": [],
                    "BALoBs": [],
                    "ManagerLevel": [
                    ]
                },
                "RoleAreas": [],
                "BAIndustries": [],
                "sSearchBoxText": "",
                "BASegments": [],
                "CrossCvg": [],
                "BALoBs": [],
                "SelectedRoleAreas": [],
                "Hubs": [],
                "Rules": {
                    "HubIndustry": [],
                    "HubLoB": [],
                    "HubRole": []
                }
            }
        },
        _refreshTask: function (that) {
            const oAppConstantsModel = that.getOwnerComponent().getModel("appConstants"),
                oContextModel = that.getOwnerComponent().getModel("wfInstanceModel"),
                sContextInstanceId = oContextModel.getProperty("/InstanceID"),
                oMasterView = oAppConstantsModel.getProperty("/ReqMasterPage"),
                oMasterList = oMasterView.getView().byId("id-list-pendingRequests").getItems(),
                oRouter = that.getOwnerComponent().getRouter();

            oMasterView.getOwnerComponent().getModel("pendingReqModel").getData().value.filter((oItem, iIndex) => {
                if (oItem.InstanceID === sContextInstanceId) {
                    oMasterView.getOwnerComponent().getModel("pendingReqModel").getData().value.splice(iIndex, 1);
                    oMasterView.getOwnerComponent().getModel("pendingReqModel").refresh(true);
                }
            });
            oMasterView.getView().byId("id-list-pendingRequests").removeSelections();
            if (oMasterList.length > 1) {
                oMasterView.getView().byId("id-list-pendingRequests").setSelectedItem(oMasterList[0]);
                oMasterList[0].setSelected(true);
                oMasterList[0].focus();
                oMasterView.getView().byId("id-list-pendingRequests").getParent().scrollTo(oMasterList[0]);
                const sRoute = oMasterView._setDetailPageRoute(oMasterList[0].getBindingContext("pendingReqModel").getObject());
                oRouter.navTo(sRoute, {
                    ID: oMasterList[0].getBindingContext("pendingReqModel").getObject().InstanceID
                });
                oAppConstantsModel.setProperty("/pendingReqCount",oAppConstantsModel.getProperty("/pendingReqCount")-1);
                oAppConstantsModel.refresh();
                return;
            } else {
                oRouter.navTo("ReqDetailPage", {
                    ID: ""
                });
                oAppConstantsModel.setProperty("/pendingReqCount",0);
                oAppConstantsModel.refresh();
            }
            sap.ui.core.BusyIndicator.hide();

        },
        _getSubstituteDetails:function(data,isOre,isNamedContact){
			//get all the substitutes
			let aSubstArray = [];
			data.forEach(function (item) {
				if (item.to_substitute.results.length) {
					aSubstArray.push(...item.to_substitute.results);
				}
			});
			const now = new Date();
			const currentDate = now.toISOString().split('T')[0];
			const aSubstituteFinalApprover = [];
			aSubstArray.forEach(function(subs){
                subs.UserTypeId = "0001";
                if (!isNamedContact) {
                    if (isOre) {
                        subs.ManagerEmail = subs.SubstituteEmail;
                        subs.ManagerName = subs.SubstituteName;
                        subs.ManagerId = subs.SubstituteId;
                    } else {
                        subs.Email = subs.SubstituteEmail;
                        subs.EmpFullName = subs.SubstituteName;
                        subs.UserId = subs.SubstituteId;
                    }
                }
				let sFormattedStartDate = subs.ValidFrom.substring( subs.ValidFrom.indexOf('(')+1, subs.ValidFrom.lastIndexOf(')')),
					iFinalStartDate = Number(sFormattedStartDate.split("+")[0]),
					dateFrom = new Date(iFinalStartDate).toISOString().split('T')[0],
					sFormattedEndDate = subs.ValidTo.substring( subs.ValidFrom.indexOf('(')+1, subs.ValidFrom.lastIndexOf(')')),
					iFinalEndDate = Number(sFormattedEndDate.split("+")[0]),
					dateTo = new Date(iFinalEndDate).toISOString().split('T')[0];  
				if (currentDate >= dateFrom && currentDate <= dateTo && subs.Active) {
					//pull if today date between substitute date
					let oUserObj = {
						email: subs.SubstituteEmail,
						ID: subs.SubstituteId,
						fullName: subs.SubstituteName
					}
                    if(!isNamedContact){
                        aSubstituteFinalApprover.push(oUserObj);
                        data.push(subs);
                    }else if(!data.filter(approver => approver.ID === oUserObj.ID).length){
                        aSubstituteFinalApprover.push(oUserObj);
                    }
				}
			});		
			return aSubstituteFinalApprover;
		},
        _setInfoMsgModel:function(oController,sInfoText){
            oController.getView().setModel(new JSONModel({
                HTML : sInfoText,
                offSet:sInfoText && sInfoText.length > 480 ? -44:0
            }),"infoMsgModel")
        },
        //show info/hint message
        _onShowInfoMessage: function (oEvent, oController) {
            const sKey = oEvent.getSource().getCustomData()[0].getKey(),
                  oAppConfigModel = appView.getOwnerComponent().getModel("mrrAppConfigModel").getData();
            let oBoundObj = sKey !=="midSectionText" ? oAppConfigModel[sKey][0].fieldDesc :"";
            if(sKey === "midSectionText"){
                //set mid section text
                let oBindingSearchContext = oController.getView().getId().includes("ManagerDetailPage") ?
                oController.getView().getModel("employee").getData():   oEvent.getSource().getParent().getBindingContext("employee").getObject(),
                    sRoleArea =  oBindingSearchContext.TempEmployee.TempRoleAreas.length ?oBindingSearchContext.TempEmployee.TempRoleAreas[0].ID:"";
                switch (sRoleArea) {
					case "0006":
						oBoundObj = oAppConfigModel["Role_ArchAdvsory_InfoBubble"][0].fieldDesc;
						break;
                    case "0003":
                        oBoundObj = oAppConfigModel["Role_SolnAdvsory_InfoBubble"][0].fieldDesc;
						break;
					default:
						break;
				}
            }
            this._setInfoMsgModel(oController,oBoundObj)
            if (!oController.pInfoPopOverDialog) {
                oController.pInfoPopOverDialog = oController.loadFragment({
                    name: "com.dealsupport.melodyrequest.fragments.InfoMessagePopOver"
                });
            }
            oController.pInfoPopOverDialog.then(function (oDialog) {
                oDialog.openBy(oEvent.getSource());
            });
        },
        _empSort:function(aEmployeeList,objParams){
            //sort user list
            aEmployeeList.sort((a, b) => {
                const empNameA = a[objParams].toUpperCase(); // ignore upper and lowercase
                const empNameB = b[objParams].toUpperCase(); // ignore upper and lowercase
                if (empNameA < empNameB) {
                  return -1;
                }
                if (empNameA > empNameB) {
                  return 1;
                }
              
                // names must be equal
                return 0;
              })
        },
           /**Git 181 (SalesOrg + SalesOffice mapping)
         * Call Profit center master data
         * @param {object} self -The context of the calling contollrer object, typically the controller.
         * @param {boolean} isOpp - Opportuniy or account
         * @param {boolean} bIsForward - Flag to indicate if the request is for a forward operation or create request.
         */
        _callProfitCenterMasterData:function(self,isOpp,bIsForward,engType){
			//Git #181 Profitceter mapping (Sales Org+ Sales Office)
            let sPFCUrlEndPoint = "/YC_MR_M_TRTRYPC",
			sSalesOrgNumber,
            sSalesOfficeId,
            sEngagementType,
            sSalesGroupShort,
			oUrlParams;
			if(isOpp){
                //request type = opportunity
                 //opp selection or switch
				// sSalesOrgNumber = appView.oFinalData.OrgID ?appView.oFinalData.OrgID.split("SORG-")[1] :'',
				sSalesOrgNumber = appView.oFinalData.defaultOrgID ?appView.oFinalData.defaultOrgID.split("SORG-")[1] :'',
                sSalesOfficeId = appView.oFinalData.salesOfficeId ? appView.oFinalData.salesOfficeId:'*',
                sSalesGroupShort = appView.oFinalData.sSalesGroupShort ? appView.oFinalData.sSalesGroupShort:'',    //GIT-320 Configuration- Added sales group to PC master data query
                sEngagementType=appView.getOwnerComponent().getModel("mrrAppEngModel").getData().engagementSelectedKey
				//set url params for profit center data
                //initial load => get all the profitcenter master data and default value
                // oUrlParams = !appView.getOwnerComponent().getModel("territoriesPFCMaster").getData().length  ? {
                //    $filter:`SearchParam eq 'SALESORG=${sSalesOrgNumber},SALESOFFICECODE=${sSalesOfficeId}' and engTypeID eq '${sEngagementType}'`
                //    }:
                //     {
                //         $filter: `SearchParam eq 'SALESORG=${sSalesOrgNumber},SALESOFFICECODE=${sSalesOfficeId}' and IsDefault eq 'X' and engTypeID eq '${sEngagementType}'`
                //     };
                oUrlParams =  {
                   $filter:`SearchParam eq 'SALESORG=${sSalesOrgNumber},SALESOFFICECODE=${sSalesOfficeId},SALESOFFICEGROUP=${sSalesGroupShort}' and engTypeID eq '${sEngagementType}'`
                   }
        }
            else if(bIsForward){
                oUrlParams={
                    $filter:`engTypeID eq '${engType}'`
                }
                sEngagementType=engType
            }else{
                sEngagementType=appView.getOwnerComponent().getModel("mrrAppEngModel").getData().engagementSelectedKey
                oUrlParams={
                    $filter:`engTypeID eq '${sEngagementType}'`
                }

            }

        let bNoDefaultProfitCenter = !isOpp ? true:false,
                fnCallBackProfitCenter = bIsForward ? false:self.fnSuccessProfitCenterCallBack;
         //Retrieves the profit center master data from the specified endpoint.
            models._getProfitCenterMasterData(self,sPFCUrlEndPoint,fnCallBackProfitCenter,oUrlParams,bNoDefaultProfitCenter,bIsForward,sEngagementType);
        },
          /**Git 132 (Form template changes + add new opp fields)
         * set deal info fields (Opportunity details)
         * @param {object} data - Opportuniy response
         * @param {object} that -The context of the calling contollrer object, typically the controller.
         */
        parseGetOppDataResponse: function (data,that) {
            if (data) {
                //create deal info object
                const oDealInfo = {
                    accName: data.ACCOUNT_NAME,
                    accountId:data.ACCOUNT,
                    oppName: data.DESCRIPTION,
                    decision: data.DECISION,
                    reviewerName: data.DQReview.REVIEWER1_NAME,
                    forecast: data.FORECAST,
                    onPremRevenue: data.LICENSE_REVENUE,
                    cloudRevenue: data.CLOUD_REVENUE,
                    currency: data.CURRENCY,
                    CURR_PHASE: data.CURR_PHASE,
                    STATUS: data.STATUS,
                    TCV: data.Items.results.length ? data.Items.results[0].TOTAL_TCV : ""
                };
                if(!that.getView().getModel().getProperty("/NewOppDetails/Opp_SalesOrg_Name")){
                    //update new opp details for request created before the git 132 changes
                    let aInternalOrder = [];
                    data.INTERNAL_ORDER1 = data.INTERNAL_ORDER1 ? Number(data.INTERNAL_ORDER1):"";
                    data.INTERNAL_ORDER2 = data.INTERNAL_ORDER2 ? Number(data.INTERNAL_ORDER2):"";
                    data.INTERNAL_ORDER1 ? aInternalOrder.push(data.INTERNAL_ORDER1) : false;
                    data.INTERNAL_ORDER2 ? aInternalOrder.push(data.INTERNAL_ORDER2) : false;
                    const oOppDetails = {
                            CLOSE_DATE:formatter._setDateFormat(data.EXPECT_END),
							Opp_Sales_Office: data.SALES_OFFICE_TEXT,
							Opp_Partner:data.PARTNER_NAME,
							Opp_SalesGroupName:	data.SALES_GROUP_TEXT,
							Opp_InternalOrder:aInternalOrder.length ? aInternalOrder.toString():"",
							Opp_SalesOrg_Name:that.getView().getModel().getProperty("isResourceProfile") ? that.getView().getModel().getProperty("/SalesOrg"):data["SALES_ORG_TEXT"],
							Executive_Summary: data.Notes.results.length ? data.Notes.results[0]["CONC_LINES"]:"",
							DealInfo:data
                    }
                    if(!that.getView().getModel().getProperty("/NewOppDetails")){
                         that.getView().getModel().setProperty("/NewOppDetails",oOppDetails);
                    }else{
                        that.getView().getModel().setProperty("/NewOppDetails",Object.assign(that.getView().getModel().getProperty("/NewOppDetails"),oOppDetails))
                    }
                    that.getView().getModel().refresh();
                }
                

                //set close date and last deal review date
                if (!data.EXPECT_END && that.getView().getModel().getProperty("/NewOppDetails")) {
                    oDealInfo.closingDate = that.getView().getModel().getProperty("/NewOppDetails/CLOSE_DATE");
                }else{
                    oDealInfo.closingDate =   formatter._setDateFormat(data.EXPECT_END);
                }
              
                const jsonReviewDate = data.DQReview.REVIEW_DATE1,
                    reviewDateFull = jsonReviewDate ? new Date(parseInt(jsonReviewDate.substr(6))) : null;
                oDealInfo.reviewDate = reviewDateFull;

                //process Notes
                const aNotes = data.Notes.results;
                for (let i = 0; i < aNotes.length; i++) {
                    switch (aNotes[i].TDID) {
                        case "ZD01":
                            oDealInfo.compelEventText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD02":
                            oDealInfo.fundingText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD03":
                            oDealInfo.custStakeText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD04":
                            oDealInfo.custChallengesText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD05":
                            oDealInfo.custBusDriversText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD06":
                            oDealInfo.solutionText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD07":
                            oDealInfo.competitorsText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD08":
                            oDealInfo.partnersText = aNotes[i].CONC_LINES;
                            break;
                        case "ZD10":
                            oDealInfo.execSummary = aNotes[i].CONC_LINES;
                            break;
                        default:
                    }
                }

                //process Attributes
                const aAttributes = data.Attributes.results;
                for (let i = 0; i < aAttributes.length; i++) {
                    switch (aAttributes[i].ATTR_CODE) {
                        case "AS0103":
                            oDealInfo.compelEventQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0104":
                            oDealInfo.fundingQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0105":
                            oDealInfo.custStakeQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0106":
                            oDealInfo.custChallengesQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0107":
                            oDealInfo.custBusDriversQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0108":
                            oDealInfo.solutionQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0109":
                            oDealInfo.competitorsQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0110":
                            oDealInfo.partnersQual = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0132":
                            oDealInfo.decision = aAttributes[i].ATTR_VALUE;
                            break;
                        case "AS0133":
                            oDealInfo.reviewerName = aAttributes[i].ATTR_DESCR;
                            break;
                        case "AS0134":
                            oDealInfo.reviewDate = new Date(aAttributes[i].ATTR_VALUE.slice(0, 4) + "-" + aAttributes[i].ATTR_VALUE.slice(4, 6) + "-" +
                                aAttributes[i].ATTR_VALUE.slice(-2));
                            break;
                        default:
                    }
                }

                oDealInfo.attributes = aAttributes;
                // that.common._defineDealQualificationMeetingStructure(data);
                // oDealInfo.QAReviewDetails = oDealInfo.attributes.length ? that.common._tabilifyQAMeetingsData(that,data.QAMeetings):[];
                const sLatestRevieweDateLabel = that.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/HarmonyLatestReviewDate/0/fieldDesc"),
                      sReviewerLabel = that.getOwnerComponent().getModel("mrrAppConfigModel").getProperty("/Reviewer/0/fieldDesc"),
                      sFinalDate = formatter.formatDateWithOrdinalNumberSuffixes(oDealInfo.reviewDate);
                oDealInfo.latesReviewDateField = oDealInfo.reviewDate ? `${sLatestRevieweDateLabel}: ${sFinalDate}`:"";
                oDealInfo.reviewerField = oDealInfo.reviewerName ? `${sReviewerLabel}: ${oDealInfo.reviewerName}`:"";
                that.getView().getModel().setProperty("/dealInfo", oDealInfo);
                that.getView().getModel().refresh();
                if(that.getView().getModel("multiReqModel") && that.getView().getModel("multiReqModel").getProperty("/subcontext/0/currentStepID") === "REQSUB"){
                    let aPartiesInvolved = data?.PartiesInvolved?.results;
                    let oAccountOwnerDetails = {accOwnerDetails:{}};
                    let oOppOwnerDetails = {oppOwnerDetails:{}};
                    aPartiesInvolved.forEach(function (val) {
                        if (val?.ROLE === "ZOZOPA01") {
                            //set account owner details
                            oAccountOwnerDetails.accOwnerDetails.id = val.USER_ID;
                            oAccountOwnerDetails.accOwnerDetails.email = val.EMAIL;
                            oAccountOwnerDetails.accOwnerDetails.fullName = val.NAME;
                        } else if (val?.ROLE === "ZOZOPO01") {
                              //set opp owner details
                            oOppOwnerDetails.oppOwnerDetails.id = val.USER_ID;
                            oOppOwnerDetails.oppOwnerDetails.email = val.EMAIL;
                            oOppOwnerDetails.oppOwnerDetails.fullName = val.NAME;
                        }
                    });
                    let aEmpIds = [
                        oAccountOwnerDetails?.accOwnerDetails?.id,
                        oOppOwnerDetails?.oppOwnerDetails?.id
                    ].filter(Boolean);
                    that.common.checkUserActive(that,aEmpIds,oAccountOwnerDetails,oOppOwnerDetails,true);
                }
                if (that && that.getView().getId().includes("SubmitReq")) {
                    //update iacValue
                    that.getView().byId("idDealInfoSec").setBusy(false);
                    let sIacVal = that.getView().getModel("multiReqModel").getProperty("/subcontext/0/iacValue");
                       that.getView().getModel().setProperty("/iacValue",sIacVal);
                }
            }
        },
         /**
         * @description check opp/account owner is active
         * @function checkUserActive
         * @param {object} that -The context of the calling contollrer object, typically the controller.
         * @param {object} aEmpIds - account/opp owner Ids
         * @param {object} oAccountOwnerDetails - account owner context
         * @param {object} oOppOwnerDetails - opportunity owner context
         * @param {boolean} isReqView - Requestor page =>true / false
         */
        checkUserActive: async function (that, aEmpIds,oAccountOwnerDetails,oOppOwnerDetails,isReqView) {
            //Call ls employee hr service to check user
            let oData = await models.checkUserActive(that, aEmpIds);
            // Process the array
            if (oData?.results?.length) {
                oData.results.forEach(obj => {
                    // Check both flags
                    if (obj.OldFlag && obj.DeleteFlag) {
                        obj.Email = ""; // Clear email
                    }

                    // Update related objects
                    if (oAccountOwnerDetails?.accOwnerDetails?.id === obj.EmpId) {
                        oAccountOwnerDetails.accOwnerDetails.email = obj.Email;
                    }
                    if (oOppOwnerDetails?.oppOwnerDetails?.id === obj.EmpId) {
                        oOppOwnerDetails.oppOwnerDetails.email = obj.Email;
                    }
                });
                let oOwnerDetails = {
                    oAccountOwnerDetails: oAccountOwnerDetails,
                    oOppOwnerDetails: oOppOwnerDetails
                };
                if (isReqView && that.getView().getModel("multiReqModel")) {
                    //requestor page
                    //set opp and account owner detials
                    let oMuliReqModel = that.getView().getModel("multiReqModel").getProperty("/subcontext");
                    oMuliReqModel.forEach(function (item) {
                        item.accOwnerDetails = oOwnerDetails?.oAccountOwnerDetails?.accOwnerDetails && Object.keys(oOwnerDetails?.oAccountOwnerDetails?.accOwnerDetails).length > 0 ?
                            oOwnerDetails?.oAccountOwnerDetails?.accOwnerDetails : {
                                id: "",
                                email: "",
                                fullName: ""
                            };
                        item.oppOwnerDetails = oOwnerDetails?.oOppOwnerDetails?.oppOwnerDetails && Object.keys(oOwnerDetails?.oOppOwnerDetails?.oppOwnerDetails).length > 0 ?
                            oOwnerDetails?.oOppOwnerDetails?.oppOwnerDetails :
                            {
                                id: "",
                                email: "",
                                fullName: ""
                            };
                    });
                    that.getView().getModel("multiReqModel").refresh();
                } else {
                    //manager/resource/io owner page
                     //set opp and account owner detials
                    oOwnerDetails.oAccountOwnerDetails?.accOwnerDetails && Object.keys(oOwnerDetails?.oAccountOwnerDetails?.accOwnerDetails).length > 0 ?
                        that.getView().getModel().setProperty("/accOwnerDetails", oOwnerDetails.oAccountOwnerDetails.accOwnerDetails) :
                        that.getView().getModel().setProperty("/accOwnerDetails", that.getView().getModel().setProperty(that.getView().getModel().getProperty("/accOwnerDetails")));
                    oOwnerDetails.oOppOwnerDetails?.oppOwnerDetails && Object.keys(oOwnerDetails.oOppOwnerDetails.oppOwnerDetails).length > 0 ?
                        that.getView().getModel().setProperty("/oppOwnerDetails", oOwnerDetails.oOppOwnerDetails.oppOwnerDetails) :
                        that.getView().getModel().setProperty("/oppOwnerDetails", that.getView().getModel().setProperty(that.getView().getModel().getProperty("/oppOwnerDetails")));
                    that.getView().getModel().refresh();
                }
            }
        },
        _defineDealQualificationMeetingStructure: function (data) {
			data.QAMeetings = {
				"results": []
			};
			const aAttributeKeys = ["AS0132", "AS0133", "AS0134", "AS0135", "AS0138", "AS0139", "AS0140", "AS0141", "AS0142", "AS0145",
				"AS0146",
				"AS0147", "AS0151", "AS0152", "AS0153", "AS0154", "AS0158", "AS0159", "AS0164", "AS0160", "AS0161", "AS0162", "AS0163"
			];
			aAttributeKeys.forEach(function (key) {
				const aFilter = data.Attributes.results.filter(function (d) {
					return (d.ATTR_CODE === key);
				});
				if (aFilter.length > 0) {
					data.QAMeetings.results.push(aFilter[0]);
				} else {
					data.QAMeetings.results.push({
						"ATTRS_CODE": "AS025",
						"ATTR_VALUE": "",
						"ATTR_CODE": key
					});
				}
			});
			
		},
        	/**
		 * @private
		 * @function _tabilifyQAMeetingsData
		 */
		_tabilifyQAMeetingsData: function (self,data) {
			const fnCheckCondition = (index) => (data.results[index].ATTR_VALUE !== "") && (data.results[index].MODE !== "D");
			const aMeetingstabledata = [];
			const fnBuildObj = (sId, sMeetingText, iRevIndex, iDateIndex, iScoreIndex, sDecision, iSecondRevIndex = null) => {
				const oResult = {
					ID: sId,
					MEETING: sMeetingText,
					REVIEWER1: data.results[iRevIndex].ATTR_DESCR,
					REVIEWERID1: data.results[iRevIndex].ATTR_VALUE,
					SCORE: (data.results[iScoreIndex].ATTR_VALUE || 0),
					DECISION: sDecision
				};
				// if (iSecondRevIndex) {
				// 	oResult.REVIEWER2 = data.results[iSecondRevIndex].ATTR_DESCR;
				// 	oResult.REVIEWERID2 = data.results[iSecondRevIndex].ATTR_VALUE;
				// }
				return oResult;
			};
            const i18nModel =  self.getOwnerComponent().getModel("i18n").getResourceBundle();
			if (fnCheckCondition(1)) {
				const sMeetingText = i18nModel.getText("QualificationLE");
				aMeetingstabledata.push(fnBuildObj("QALicence", sMeetingText, 1, 2, 3, data.results[0].ATTR_VALUE));
			}
			if (fnCheckCondition(5)) {
				const sMeetingText = i18nModel.getText("QualificationSE");
				aMeetingstabledata.push(fnBuildObj("QAService", sMeetingText, 5, 7, 8, data.results[4].ATTR_VALUE, 6));
			}
			if (fnCheckCondition(9)) {
				const sMeetingText =i18nModel.getText("PRINT_OPTION_DEAL_REVIEW") + " (Licence)";
				aMeetingstabledata.push(fnBuildObj("DRLicence", sMeetingText, 9, 10, 11, "EP"));
			}
			if (fnCheckCondition(12)) {
				const sMeetingText = i18nModel.getText("PRINT_OPTION_DEAL_REVIEW") + " (Service)";
				aMeetingstabledata.push(fnBuildObj("DRService", sMeetingText, 12, 14, 15, "EP", 13));
			}
			if (fnCheckCondition(16)) {
				const sMeetingText = i18nModel.getText("CPProgressCheck") + " (Licence)";
				aMeetingstabledata.push(fnBuildObj("CPLicence", sMeetingText, 16, 17, 18, "EP"));
			}
			if (fnCheckCondition(19)) {
				const sMeetingText = i18nModel.getText("CPProgressCheck") + " (Service)";
				aMeetingstabledata.push(fnBuildObj("CPService", sMeetingText, 19, 21, 22, "EP", 20));
			}
			self.common._noMeetingData(aMeetingstabledata);
			return {
				results: aMeetingstabledata
			};
		},
        	/**
		 * ITSNDEX-3755 show no meeting if there are no meetings mentained
		 * @function _noMeetingData
		 * @private
		 * @param {array} aMeetingstabledata - Meetingstructure
		 */
		_noMeetingData: function (aMeetingstabledata) {
			const aIdMap = aMeetingstabledata.map(Item => Item.ID);
			const fnGetBasicObj = (sId, sText) => {
				return {
					ID: sId,
					REVIEWER1: "",
					REVIEWERID1: "",
					DATE: "",
					SCORE: "",
					DECISION: ""
				};
			};
			if (!aIdMap.includes("QALicence") && !aIdMap.includes("QAService")) {
				aMeetingstabledata.push(fnGetBasicObj("QANo", "QUALTIFICATION_DECISION"));
			}
			if (!aIdMap.includes("DRLicence") && !aIdMap.includes("DRService")) {
				aMeetingstabledata.push(fnGetBasicObj("DRNo", "DEAL_REVIEW_MEETING"));
			}
			if (!aIdMap.includes("CPLicence") && !aIdMap.includes("CPService")) {
				aMeetingstabledata.push(fnGetBasicObj("CPNo", "CPProgressCheck"));
			}
		},
        /**Git 132 (Form template/standardization )
         * set header fields for manager,ioOwner and object page
         * @param {object} that -The context of the calling contollrer object, typically the controller.
         */
          setHeaderDetails: function (that) {
            const oModel = that.getView().getModel("multiReqModel") ? that.getView().getModel("multiReqModel"):that.getView().getModel(),
                  oWfInstanceModel = that.getView().getModel("wfInstanceModel"),
                  oModelData = that.getView().getModel("multiReqModel") ? oModel.getProperty("/subcontext/0"):oModel.getData(),
                  oI18nModel = that.getOwnerComponent().getModel("i18n").getResourceBundle(),
                    sOppLabel =oI18nModel.getText("OPP_DESC"),
                    sAccountLabel = oI18nModel.getText("ACCOUNT_NAME"),
                    sIacLabel = oI18nModel.getText("iacLabel"),
                    sRequestorLabel = oI18nModel.getText("requester"),
                    sOppVal = oWfInstanceModel.getProperty("/OpportunityDesc"),
                    sAccountVal = oWfInstanceModel.getProperty("/Account_name"),
                    sRequesteor =oWfInstanceModel.getProperty("/EmpRequester_Name"),
                    sHarmonyUrl = that.getOwnerComponent().getModel("appConstants").getProperty("/HarmonyURL/0/Value"),
                    sAccountId = oWfInstanceModel.getProperty("/Account_ID"),
                    sAccountUrl = `${sHarmonyUrl }Account/${sAccountId}`,
                    sIAC = oModelData.aResourceProfileApprovers && oModelData.aResourceProfileApprovers.IAC.length && oModelData["RequestType"] === 'Opportunity'  ? oModelData.aResourceProfileApprovers.IAC[0].IAC_Desc:"",
                    listItems = [];
      
            //create dynamic header obj
            let data = [
                { Name: sRequestorLabel, Desc: sRequesteor, active: true, url:  `${that.getOwnerComponent().getModel("appConstants").getProperty("/userProfileUrl/0/Value")}${oModelData.requesterDetails.id}`,id:"idReq"},
                { Name: sAccountLabel, Desc: sAccountVal, active: true,  url:  sAccountUrl, id:"idAccount"},
                { Name: sOppLabel, Desc: sOppVal, active: true,  url:oModelData.extSystemsUrls.harmony, id:"idOpp"},
                { Name: sIacLabel, Desc: sIAC, active: false, url:false, id:"idIAC" }
            ];
            data.forEach(function (item) {
                if (item.Desc) {
                    //push the header field if the field value is available
                    let listItem = {
                        Name: item.Name,
                        Desc: item.Desc,
                        active: item.active,
                        id:item.id,
                        url:item.url
                    };
                    listItems.push(listItem);
                }
            });
            //set header model
            let oHeaderModel = new sap.ui.model.json.JSONModel();
            oHeaderModel.setData(
                listItems
            );
            that.getView().setModel(oHeaderModel, "headerModel");
        },
           /**Git 132 (Form template changes)
         *get resource search details
        * @param {object} that - controller scope
        */
        getResFieldDetails: function (that) {
            const bResProfile = that.getView().getModel().getData().isResourceProfile;
            let aResProfile,
                sSolutionAreaDesc,
                aProcessorShortList = [],
                aProcessorMoreList = [],
                sMoreProcessorText,
                descStringBAindustry,
                addSolutions,
                contextData,
                finalHeaderModelData=[];
                var wfDefinition=that.getView().getModel("wfInstanceModel").getData().WorkflowDefinition
        if(wfDefinition==='Multiple_Request_Areas' && that.getView().getModel().getData().aReqAreas.length>1){
            that.getView().getModel().getData().aReqAreas.forEach(obj=>{
                if(bResProfile){
            
                aResProfile =obj.aResourceProfileApprovers.ResourceProfileDetails
                contextData=obj
            
                descStringBAindustry = aResProfile.BAIndustries.map(function (obj) {
                    return obj.Desc;
                }).join(',');
                if (aResProfile.SolutionAreas && aResProfile.SolutionAreas.length) {                    
                         sSolutionAreaDesc = aResProfile.SolutionAreas.map(function (obj) {
                            return obj.SelectedSolutionArea;
                        }).join(',');                    
                }else{
                    sSolutionAreaDesc = "";
            }
            // if (aResProfile.AdditionalSolutions && aResProfile.AdditionalSolutions.length) {                
            //     addSolutions = aResProfile.AdditionalSolutions.map(function (obj) {
            //                 return obj.soln_name;
            //             }).join(',');
            // } else {
            //     addSolutions = ""
            // }
            const descPC = contextData.selectedProfitCenter[0].SelectedDesc;
            let listItems = [];
            const sProfitCenterI18n = that.i18nModel.getText("profitCenter");
            const sSLAi18n = that.i18nModel.getText("solutionArea");
            const sRoleAreaI18n = that.i18nModel.getText("roleAreaPrimary");
                const sRoleI18n = that.i18nModel.getText("rolePrimary");
                const sBAIi18n = that.i18nModel.getText("businessAreaIndustryPrimary");
           
                let data = [
                    { Name: sProfitCenterI18n, Desc: descPC },
                    { Name: sRoleAreaI18n, Desc: aResProfile.Role_GUID.RoleAreaDesc },
                    { Name: sSLAi18n, Desc: sSolutionAreaDesc },
                    { Name: sBAIi18n, Desc: descStringBAindustry }
                ];
                if(contextData.aResourceProfileApprovers.ResourceProfileDetails.SelectedRole){
                    let sRoleDesc;
                    if (contextData.aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RolesData.length > 1) {
                        sRoleDesc = contextData.aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RolesData.map(function (obj) {
                          return obj.RoleDesc;
                      }).join(',');
                  }else{
                      sRoleDesc =  contextData.aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.Desc;
                  }
                     data = [
                        { Name: sProfitCenterI18n, Desc: descPC },
                    { Name: sRoleAreaI18n, Desc: aResProfile.Role_GUID.RoleAreaDesc },
                    { Name: sRoleI18n, Desc: sRoleDesc },
                    { Name: sSLAi18n, Desc: sSolutionAreaDesc },
                    { Name: sBAIi18n, Desc: descStringBAindustry }
                   
                ];
                }
                data.forEach(function (item) {
                    if (item.Desc) {
                        let listItem = {
                            Name: item.Name,
                            Desc: item.Desc
                        };
                        listItems.push(listItem);
                    }
                });
               
                //Git 132 (Form template/standardization ) start
                //set request page header
                //processor list
                let aProcessorList = contextData.aResourceProfileApprovers.ApproverDetails;
                aProcessorList.length ? aProcessorList[0].bIsTitle = true : false;
                //sort processor list
                that.common._empSort(aProcessorList,"fullName");
				var aActionProcessorStateID=["WRESAP","WIOAPP","RSBCOM","REQCOM","RSBREJ","IOREJT","REQREJ","REQTER"] 
				var wfInstanceData=that.getView().getModel("wfInstanceModel").getData()
				if(wfInstanceData){
					if(aActionProcessorStateID.includes(wfInstanceData.currentStateID) && wfDefinition !== 'Multiple_Request_Areas'){
						aProcessorList=[{
							"ID":wfInstanceData.ReqApproverID,
							"email":wfInstanceData.ReqApproverEmail,
							"fullName":wfInstanceData.ReqApproverName
						}]
					}
				}
                if(aProcessorList.length > 2){
                   const iProcessorMoreCount = (aProcessorList.length - 2).toString(),
                         si18nMoreText = that.i18nModel.getText("more");
                        sMoreProcessorText = `(${iProcessorMoreCount} ${si18nMoreText})`;
                    aProcessorShortList = aProcessorList.slice(0, 2); // visible approver list ( max 2 processors)
                    aProcessorMoreList = aProcessorList.slice(2);// array point to link to show more processors
                } else {
                    aProcessorShortList = aProcessorList;
                }                
            }           
             
 
                //set object for request header model
                const oHeaderFields = {
                    profitCenterHeader:bResProfile ? contextData.selectedProfitCenter[0].desc:"",
                    roleHeader: bResProfile ? aResProfile.Role_GUID.SelectedRoleDesc ? aResProfile.Role_GUID.SelectedRoleDesc : aResProfile.Role_GUID.RolesData.map(obj => { return obj.RoleDesc }).join(", ") : "",
                    solnHeader:bResProfile ? sSolutionAreaDesc:"",
                    // addSolutions:bResProfile ? addSolutions:"",
                    addSolutions:bResProfile && aResProfile.AdditionalSolutions && aResProfile.AdditionalSolutions.length? aResProfile.AdditionalSolutions:[],
                    indHeader:bResProfile ? descStringBAindustry :"",
                    rolAreaHeader:bResProfile ? aResProfile.Role_GUID.RoleAreaDesc:"",
                    reqNameHeader:contextData.requesterDetails,
                    processorShortList:bResProfile ? aProcessorShortList:[],
                    processorMoreList:bResProfile ? aProcessorMoreList:[],
                    moreProcessorText:bResProfile ? sMoreProcessorText:"",
                    groupDesc: bResProfile && aResProfile?.SelectedGroup?.length ? aResProfile.SelectedGroup[0].GroupDesc : "",
                    isRes:true,
                    resource:{},
                    currentScope:that,
                    processorDisplayList:bResProfile && sMoreProcessorText ? aProcessorShortList.concat([{
                        ID:"idMoreText",
                        fullName:sMoreProcessorText
                    }]):aProcessorShortList,                    
                    urlToProfile:`${that.getOwnerComponent().getModel("appConstants").getProperty("/userProfileUrl/0/Value")}${contextData.requesterDetails["id"]}`,
                    panelVisibility: true,
                    searchFieldsText:contextData.searchFieldsText,
                    panelExpanded: true
                };
                  //resource list
             if (that.getView().getModel().getProperty("/currentStepID") === "RESAPP" || that.getView().getModel().getProperty("/currentStepID") === "REQCOM" || that.getView().getModel().getProperty("/currentStepID") === "IOOAPP" ) {
                 let oBaseModel = that.getView().getModel(),
                     oAssignment = oBaseModel.getProperty("/AllAssignmentDetails") ? oBaseModel.getProperty("/AllAssignmentDetails"):oBaseModel.getProperty("/AssignmentApprove"),
                     aAssignment = oAssignment ? oAssignment:[oBaseModel.getProperty("/io_OwnerResource")],
                     aResourceList = [];
                     aAssignment = aAssignment[0] ? aAssignment:oBaseModel.getProperty("/Assignment")
                 oHeaderFields.bResourceField = true;
                 aAssignment.forEach(function (item) {
                     aResourceList = aResourceList.concat(item.NominatedResources)
                 });
                  //sort resource list
                 
                 that.common._empSort(aResourceList, "fullName");
                 let aResourceShortList = [],
                     aResourceMoreList = [],
                     sMoreResourceText;
                 if (aResourceList.length > 2) {
                     const iResourceMoreCount = (aResourceList.length - 2).toString(),
                         si18nMoreText = that.i18nModel.getText("more");
                     sMoreResourceText = `(${iResourceMoreCount} ${si18nMoreText})`;
                     aResourceShortList = aResourceList.slice(0, 2); // visible approver list ( max 2 processors)
                     aResourceMoreList = aResourceList.slice(2);// array point to link to show more processors  
                 } else {
                     aResourceShortList = aResourceList;
                 }
                    oHeaderFields.resource.processorShortList = aResourceShortList;
                    oHeaderFields.resource.processorMoreList = aResourceMoreList;
                    oHeaderFields.resource.moreProcessorText = sMoreResourceText;
                    oHeaderFields.resource.processorDisplayList = sMoreResourceText ? aResourceShortList.concat([{
                        ID:"idMoreText",
                        fullName:sMoreResourceText
                    }]):aResourceShortList;
             }else{
                oHeaderFields.bResourceField = false;
             }
             finalHeaderModelData.push(oHeaderFields)

            })
        }else{

        
        if(bResProfile){
            if(wfDefinition==='Multiple_Request_Areas'){
                aResProfile =that.getView().getModel().getData().aReqAreas[0].aResourceProfileApprovers.ResourceProfileDetails
                contextData=that.getView().getModel().getData().aReqAreas[0]
            }else{
                aResProfile =that.getView().getModel().getData().aResourceProfileApprovers.ResourceProfileDetails;
                contextData=that.getView().getModel().getData()
            }
                descStringBAindustry = aResProfile.BAIndustries.map(function (obj) {
                    return obj.Desc;
                }).join(',');
                if (aResProfile.SolutionAreas && aResProfile.SolutionAreas.length) {                    
                         sSolutionAreaDesc = aResProfile.SolutionAreas.map(function (obj) {
                            return obj.SelectedSolutionArea;
                        }).join(',');                    
                }else{
                    sSolutionAreaDesc = "";
            }
            // if (aResProfile.AdditionalSolutions && aResProfile.AdditionalSolutions.length) {                
            //     addSolutions = aResProfile.AdditionalSolutions.map(function (obj) {
            //                 return obj.soln_name;
            //             }).join(',');
            // } else {
            //     addSolutions = ""
            // }
            const descPC = contextData.selectedProfitCenter[0].SelectedDesc;
            let listItems = [];
            const sProfitCenterI18n = that.i18nModel.getText("profitCenter");
            const sSLAi18n = that.i18nModel.getText("solutionArea");
            const sRoleAreaI18n = that.i18nModel.getText("roleAreaPrimary");
                const sRoleI18n = that.i18nModel.getText("rolePrimary");
                const sBAIi18n = that.i18nModel.getText("businessAreaIndustryPrimary");
           
                let data = [
                    { Name: sProfitCenterI18n, Desc: descPC },
                    { Name: sRoleAreaI18n, Desc: aResProfile.Role_GUID.RoleAreaDesc },
                    { Name: sSLAi18n, Desc: sSolutionAreaDesc },
                    { Name: sBAIi18n, Desc: descStringBAindustry }
                ];
                if(contextData.aResourceProfileApprovers.ResourceProfileDetails.SelectedRole){
                    let sRoleDesc;
                    if (contextData.aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RolesData.length > 1) {
                        sRoleDesc = contextData.aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RolesData.map(function (obj) {
                          return obj.RoleDesc;
                      }).join(',');
                  }else{
                      sRoleDesc =  contextData.aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.Desc;
                  }
                     data = [
                        { Name: sProfitCenterI18n, Desc: descPC },
                    { Name: sRoleAreaI18n, Desc: aResProfile.Role_GUID.RoleAreaDesc },
                    { Name: sRoleI18n, Desc: sRoleDesc },
                    { Name: sSLAi18n, Desc: sSolutionAreaDesc },
                    { Name: sBAIi18n, Desc: descStringBAindustry }
                   
                ];
                }
                data.forEach(function (item) {
                    if (item.Desc) {
                        let listItem = {
                            Name: item.Name,
                            Desc: item.Desc
                        };
                        listItems.push(listItem);
                    }
                });
               
                //Git 132 (Form template/standardization ) start
                //set request page header
                //processor list
                let aProcessorList = contextData.aResourceProfileApprovers.ApproverDetails;
                aProcessorList.length ? aProcessorList[0].bIsTitle = true : false;
                //sort processor list
                that.common._empSort(aProcessorList,"fullName");
				var aActionProcessorStateID=["WRESAP","WIOAPP","RSBCOM","REQCOM","RSBREJ","IOREJT","REQREJ","REQTER"] 
				var wfInstanceData=that.getView().getModel("wfInstanceModel").getData()
				if(wfInstanceData){
					if(aActionProcessorStateID.includes(wfInstanceData.currentStateID) && wfDefinition !== 'Multiple_Request_Areas'){
						aProcessorList=[{
							"ID":wfInstanceData.ReqApproverID,
							"email":wfInstanceData.ReqApproverEmail,
							"fullName":wfInstanceData.ReqApproverName
						}]
					}
				}
                if(aProcessorList.length > 2){
                   const iProcessorMoreCount = (aProcessorList.length - 2).toString(),
                         si18nMoreText = that.i18nModel.getText("more");
                        sMoreProcessorText = `(${iProcessorMoreCount} ${si18nMoreText})`;
                    aProcessorShortList = aProcessorList.slice(0, 2); // visible approver list ( max 2 processors)
                    aProcessorMoreList = aProcessorList.slice(2);// array point to link to show more processors
                } else {
                    aProcessorShortList = aProcessorList;
                }                
            }           
             
 
                //set object for request header model
                const oHeaderFields = {
                    profitCenterHeader:bResProfile ? contextData.selectedProfitCenter[0].desc:"",
                    // roleHeader:bResProfile ? aResProfile.Role_GUID.RoleDesc:"",
                    roleHeader: bResProfile ? aResProfile.Role_GUID.SelectedRoleDesc ? aResProfile.Role_GUID.SelectedRoleDesc : aResProfile.Role_GUID.RolesData.map(obj => { return obj.RoleDesc }).join(", ") : "",
                    solnHeader:bResProfile ? sSolutionAreaDesc:"",
                    // addSolutions:bResProfile ? addSolutions:"",
                    addSolutions:bResProfile && aResProfile.AdditionalSolutions && aResProfile.AdditionalSolutions.length? aResProfile.AdditionalSolutions:[],
                    indHeader:bResProfile ? descStringBAindustry :"",
                    rolAreaHeader:bResProfile ? aResProfile.Role_GUID.RoleAreaDesc:"",
                    reqNameHeader:contextData.requesterDetails,
                    processorShortList:bResProfile ? aProcessorShortList:[],
                    processorMoreList:bResProfile ? aProcessorMoreList:[],
                    moreProcessorText:bResProfile ? sMoreProcessorText:"",
                    groupDesc: bResProfile && aResProfile?.SelectedGroup?.length ? aResProfile.SelectedGroup[0].GroupDesc : "",
                    isRes:true,
                    resource:{},
                    currentScope:that,
                    processorDisplayList:bResProfile && sMoreProcessorText ? aProcessorShortList.concat([{
                        ID:"idMoreText",
                        fullName:sMoreProcessorText
                    }]):aProcessorShortList,                    
                    urlToProfile:`${that.getOwnerComponent().getModel("appConstants").getProperty("/userProfileUrl/0/Value")}${contextData.requesterDetails["id"]}`,
                    panelVisibility: false,
                    searchFieldsText:contextData.searchFieldsText,
                    panelExpanded: false
                };
                  //resource list
             if (that.getView().getModel().getProperty("/currentStepID") === "RESAPP" || that.getView().getModel().getProperty("/currentStepID") === "REQCOM" || that.getView().getModel().getProperty("/currentStepID") === "IOOAPP" ) {
                 let oBaseModel = that.getView().getModel(),
                     oAssignment = oBaseModel.getProperty("/AllAssignmentDetails") ? oBaseModel.getProperty("/AllAssignmentDetails"):oBaseModel.getProperty("/AssignmentApprove"),
                     aAssignment = oAssignment ? oAssignment:[oBaseModel.getProperty("/io_OwnerResource")],
                     aResourceList = [];
                     aAssignment = aAssignment[0] ? aAssignment:oBaseModel.getProperty("/Assignment")
                 oHeaderFields.bResourceField = true;
                 aAssignment.forEach(function (item) {
                     aResourceList = aResourceList.concat(item.NominatedResources)
                 });
                  //sort resource list
                 
                 that.common._empSort(aResourceList, "fullName");
                 let aResourceShortList = [],
                     aResourceMoreList = [],
                     sMoreResourceText;
                 if (aResourceList.length > 2) {
                     const iResourceMoreCount = (aResourceList.length - 2).toString(),
                         si18nMoreText = that.i18nModel.getText("more");
                     sMoreResourceText = `(${iResourceMoreCount} ${si18nMoreText})`;
                     aResourceShortList = aResourceList.slice(0, 2); // visible approver list ( max 2 processors)
                     aResourceMoreList = aResourceList.slice(2);// array point to link to show more processors  
                 } else {
                     aResourceShortList = aResourceList;
                 }
                    oHeaderFields.resource.processorShortList = aResourceShortList;
                    oHeaderFields.resource.processorMoreList = aResourceMoreList;
                    oHeaderFields.resource.moreProcessorText = sMoreResourceText;
                    oHeaderFields.resource.processorDisplayList = sMoreResourceText ? aResourceShortList.concat([{
                        ID:"idMoreText",
                        fullName:sMoreResourceText
                    }]):aResourceShortList;
             }else{
                oHeaderFields.bResourceField = false;
             }
             finalHeaderModelData.push(oHeaderFields)
            }
 
                //set request page header model
                const oModelHeader = new sap.ui.model.json.JSONModel();
                oModelHeader.setData(
                    // oHeaderFields
                    finalHeaderModelData
                );
                //set header model
                that.getView().setModel(oModelHeader, "requestHeaderModel");
        },
        /**Git 132 (Form template/standardization )
         * Call comment service and update comments (Post)
         * @param {object} oEvent -The context of the current control.
         */
        onPostComment:function(oEvent){
            const oWfInstanceModel = this.getView().getModel("wfInstanceModel") ? 
            this.getView().getModel("wfInstanceModel"):this.getOwnerComponent().getModel("wfInstanceModel");
            //payload
            let oCommentPayload = {
                "instanceID":oWfInstanceModel.getProperty("/InstanceID"),
                "commentText":formatter.formatEscCharActionHistroy(oEvent.getParameter("value")),
                "userID": this.getOwnerComponent().getModel("userDetails").getProperty("/user_name"),
                "userEmail": this.getOwnerComponent().getModel("userDetails").getProperty("/email"),
                "userName":this.getOwnerComponent().getModel("userDetails").getProperty("/name"),
                "userRole": oWfInstanceModel.getProperty("/taskOwnerRole"),
                "createdAt": new Date().toISOString(),
                "modifiedAt":  new Date().toISOString(),
                "commentType": "CHAT"
            };
            let oContext =  this.getView().getModel("multiReqModel") ? this.getView().getModel("multiReqModel").getData().subcontext[0] : this.getView().getModel().getData();
            oContext.userChatCommentDetails = oCommentPayload;
            let oFinalPayload = {
                "context": JSON.stringify(oContext) 
            }

            //call comment service
            models._getUserComments(this,oCommentPayload["instanceID"],"POST",oFinalPayload)
        },
        _setResourceAssignment: function (oAssignmentData,oController) {
            let aFinalAssignment = [];
            oAssignmentData.forEach(function (assignment, iIndex) {
                const oFinalAssignmentContext = {

                }
                //initialize assignment properties
                oFinalAssignmentContext.AssignmentID = iIndex + 1;
                oFinalAssignmentContext.comments = assignment.comments ? assignment.comments.trim():"";
                oFinalAssignmentContext.selectedNominees = assignment.NominatedResources;
                oFinalAssignmentContext.maxNoOfDaysToBookIO = assignment.NominatedResources[0].maxNoOfDaysToBookIO;
                oFinalAssignmentContext.staffingDateRange = assignment.NominatedResources[0].staffingDateRange;
                oFinalAssignmentContext.staffingPurpose = assignment.NominatedResources[0].staffingPurpose;
                oFinalAssignmentContext.staffingPurposeKey = assignment.NominatedResources[0].staffingPurposeKey;
                oFinalAssignmentContext.taskLevelKey = assignment.NominatedResources[0].taskLevelKey;
                oFinalAssignmentContext.taskLevelVal = assignment.NominatedResources[0].taskLevelVal;
                oFinalAssignmentContext.internalOrderFormVisible = assignment.internalOrderFormVisible;
                oFinalAssignmentContext.taskLevelVisible = assignment.taskLevelVisible;
                oFinalAssignmentContext.staffingDateRangeVisible = assignment.staffingDateRangeVisible;
                oFinalAssignmentContext.maxNoOfDaysToBookIOVisible = assignment.maxNoOfDaysToBookIOVisible;
                oFinalAssignmentContext.taskLevelEnable = assignment.taskLevelEnable;
                oFinalAssignmentContext.assignmentComments = oFinalAssignmentContext.comments;
                oFinalAssignmentContext.NominatedResources = assignment.NominatedResources;
                oFinalAssignmentContext.staffingPurposeVisible = assignment.staffingPurposeVisible;
                //Git #230 Activity integration start
                //set activity flag
                oFinalAssignmentContext.enableActivityRegister = assignment.enableActivityRegister;
                oFinalAssignmentContext.activityLists = assignment.activityLists ? assignment.activityLists:"";
                 if(!oFinalAssignmentContext.activityLists){
                       //update activity lists for very old requests
                    oFinalAssignmentContext.activityLists =  assignment.NominatedResources && assignment.NominatedResources[0].activityLists ? assignment.NominatedResources[0].activityLists:[];
                     oFinalAssignmentContext.enableActivityRegister = assignment.NominatedResources && assignment.NominatedResources[0].enableActivityRegister ? assignment.NominatedResources[0].enableActivityRegister : false;
                }
                //Git #230 Activity integration end
                //Git 132 (Form template/standardization ) start
                //processor list
                const aProcessorList = assignment.NominatedResources;
                aProcessorList.length ? aProcessorList[0].bIsTitle = true : false;
                //sort processor list
                oController.common._empSort(aProcessorList, "fullName");
                let aProcessorShortList = [],
                    aProcessorMoreList = [],
                    sMoreProcessorText;
                if (aProcessorList.length > 2) {
                    const iProcessorMoreCount = (aProcessorList.length - 2).toString(),
                        si18nMoreText = oController.getOwnerComponent().getModel("i18n").getResourceBundle().getText("more");
                    sMoreProcessorText = `(${iProcessorMoreCount} ${si18nMoreText})`;
                    aProcessorShortList = aProcessorList.slice(0, 2); // visible approver list ( max 2 processors)
                    aProcessorMoreList = aProcessorList.slice(2);// array point to link to show more processors	
                } else {
                    aProcessorShortList = aProcessorList;
                }
                //set object for request header model
                oFinalAssignmentContext.resourceList = {
                    processorShortList: aProcessorShortList,
                    processorMoreList: aProcessorMoreList,
                    moreProcessorText: sMoreProcessorText,
                    processorDisplayList: sMoreProcessorText ? aProcessorShortList.concat([{
                        ID: "idMoreText",
                        fullName: sMoreProcessorText
                    }]) : aProcessorShortList
                }
                oFinalAssignmentContext.resourceList.currentScope = oController;
                aFinalAssignment.push(oFinalAssignmentContext);
            })
            return aFinalAssignment;
        },
          /**Git 234 (extend solution hierachy )
         * Search solution area
         * @param {object} oEvent -The context of the current control.
         * @param {object} that -controller scope.
         */
        onSearchSlnHierachy: function (evt, that) {
            const sQuery = evt.getParameter("query") ? encodeURI(evt.getParameter("query").trim()):"";
          that.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/tempParentGuid", []);
            const oLSSystemModel = models.systemLSDataModel(that);
            if (sQuery) {
                let sQueryAddSln = that.getOwnerComponent().getModel("SolutionAreaMasterData").getProperty("/showDisplayMaterials") ? "X" : "";
                models._callGETOdata(oLSSystemModel, `/YC_MR_M_SOL_SEARCH(P_Search='${sQuery}',P_IncludeAddlSol='${sQueryAddSln}')/Set`).then(function (oData) {
                    let oResponse = oData.results;
                    if(that.getOwnerComponent().getModel("SolutionAreaMasterData").getProperty("/solHierarchyMap")){
                        var mSolutionHierarchyMap=that.getOwnerComponent().getModel("SolutionAreaMasterData").getProperty("/solHierarchyMap")
                        
                     }else{
                         var mSolutionHierarchyMap=new Map()
                     }
                    function buildTree(data, that) {
                        const rootMap = {};
                        data.forEach(item => {
                            const names = item.soln_path.split(" > ").map(s => s.trim());
                            const idParts = item.id_path.split(" > ").map(s => s.trim());
                            const guidParts = item.path.split(" > ").map(s => s.trim());
                            const guidsDup = item.path.replace(/,$/, "").split(" > ").map(s => s.trim()); // remove trailing comma

                            const guids = []
                            guidsDup.forEach(function (item) {
                                guids.push(item);
                            });
                            let currentLevel = rootMap;

                            names.forEach((name, idx) => {
                                const guid = guids[idx];
                                const solnId = idParts[idx];
                                if (!currentLevel[guid]) {

                                    currentLevel[guid] = {
                                        soln_guid: guid,
                                        IsSelectable: "X",
                                        IsViewable: "X",
                                        active:true,
                                        SolGuid: guid,
                                        SolName: name,
                                        is_final:item.is_final,
                                        SolnId: solnId,
                                        soln_id: solnId,
                                        name:name,
                                        soln_name: name,
                                        full_sol_id:idParts.slice(0, idx + 1).join(" > "),
                                        full_sol_guid:guidParts.slice(0, idx + 1).join(" > "),
                                        full_sol_name: names.slice(0, idx + 1).join(" > "),
                                        LevelId: idx + 1
                                    };

                                    if (idx > 0) {
                                        currentLevel[guid].soln_prnt_guid = guids[idx - 1];
                                        currentLevel[guid].SolPrntGuid = guids[idx - 1];
                                        currentLevel[guid].id = guid;
                                    } else {
                                        currentLevel[guid].soln_prnt_guid = "00000000-0000-0000-0000-000000000000";
                                        currentLevel[guid].SolPrntGuid = "00000000-0000-0000-0000-000000000000";
                                    }
                                }
                                if (idx < names.length - 1) {
                                    if (!currentLevel[guid].levels) {
                                        currentLevel[guid].levels = {};
                                    }
                                    currentLevel = currentLevel[guid].levels;
                                }
                                if (!mSolutionHierarchyMap.get(guid)) {
                                    mSolutionHierarchyMap.set(guid, currentLevel[guid])
                                }
                            });
                        });

                        // Recursive conversion from map to array
                        function convert(obj) {
                            return Object.values(obj).map(node => {
                                if (node.levels) {
                                    node.levels = convert(node.levels);
                                } else {
                                    node.levels = [];
                                }
                                if (!mSolutionHierarchyMap.get(node.SolGuid)) {
                                    mSolutionHierarchyMap.set(node.SolGuid, node)
                                }
                                const oSlnAreaModel = that.getOwnerComponent().getModel("SolutionAreaMasterData"),
                                    oSlnTempParentGuid = oSlnAreaModel.getProperty("/tempParentGuid"),
                                    aAddSlns = oSlnAreaModel.getProperty("/displayTokensAdditionalSolution") ? oSlnAreaModel.getProperty("/displayTokensAdditionalSolution") : [];
                                if (aAddSlns.length) {
                                    const aNodeCheck = aAddSlns.filter(item => item.soln_guid === node.soln_guid);
                                    if (aNodeCheck.length) {
                                        node.selected = true;
                                        oSlnAreaModel.getProperty("/tempParentGuid").push(node.SolPrntGuid);
                                        oSlnAreaModel.refresh();
                                    }

                                }
                                if (that.getView().getId().includes("Worklist")) {
                                    let aSolutionAreas = that.getView().getModel("employee").getData().TempEmployee.SolutionAreas;
                                    if (aSolutionAreas && aSolutionAreas.length) {
                                        const aNodFiltereCheck = aSolutionAreas.filter(obj => obj.soln_guid === node.soln_guid);
                                        if (aNodFiltereCheck.length) {
                                            node.selected = true;
                                        }
                                    }
                    
                                }
                                if (oSlnTempParentGuid.length) {
                                    const aParentNodeCheck = oSlnTempParentGuid.filter(item => item === node.soln_guid);
                                    if (aParentNodeCheck.length) {
                                        node.selected = true;
                                        oSlnAreaModel.getProperty("/tempParentGuid").push(node.SolPrntGuid);
                                        oSlnAreaModel.refresh();
                                    }
                                }
                                return node;
                            });
                        }
                        return convert(rootMap);
                    }
                    const output = buildTree(oResponse, that);
                       that.bDisableExpandAPICall = true;
                    that.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/solHierarchy", output);
                    let solutionForFilter = that.getView().getModel("employee").getProperty("/solutionForFilter");
                    const oSolutionAreaDataModel = that.getOwnerComponent().getModel("SolutionAreaMasterData");
                    const aSolnModelMasterData = oSolutionAreaDataModel.getProperty("/solHierarchy");
                    if (that.getView().getId().includes("Worklist")) {
                        // if (node.LevelId === 2) {
                        //     let sParentGuid = node.soln_prnt_guid;
                        //     aSolnModelMasterData.forEach(function (item) {
                        //         if (item.soln_guid === sParentGuid) {
                        //             item.selected = true;
                        //             item.partialSelection = solutionForFilter.filter(val => val.soln_guid === item.soln_guid).length ? false : true;
                        //         }
                        //     })
                        // }
                        aSolnModelMasterData.forEach(function(items){
                            let aLevels = items.levels.filter(child=>child.selected);
                            if(aLevels.length){
                               items.selected = true

                            }
                        })
                    }

                    that.getOwnerComponent().getModel("SolutionAreaMasterData").setProperty("/solHierarchyMap", mSolutionHierarchyMap);
                    that.getOwnerComponent().getModel("SolutionAreaMasterData").refresh();
                    that.getView().byId("idSolutionTree").expandToLevel(10);
                }.bind(that))
            } else {
                models.getSolutionAreaMasterData(that, true);
            }
        },
             _onOpenSolutionSelectConfimDialog: function (that,oChildCntrl, oSelectedRow, bIsSelected, solutionAreaDataModel) {
            let oAppConstantsModel = appView.getOwnerComponent().getModel("mrrAppConfigModel");
            let sHtmlMessage = oAppConstantsModel.getProperty("/solutionSelectConfirmMsg/0/fieldDesc"),
                sHeaderText = oAppConstantsModel.getProperty("/solutionConfirmHeaderText/0/fieldDesc"),
                sCloseIconText = oAppConstantsModel.getProperty("/solutionMsgCloseIcon/0/fieldDesc"),
                bIsCloseIconVisible = oAppConstantsModel.getProperty("/solutionMsgCloseIcon/0/isActive") ? true:false,
                bConfirmText = oAppConstantsModel.getProperty("/solutionMsgDialogButtonKeep/0/fieldDesc"),
                bClearText = oAppConstantsModel.getProperty("/solutionMsgDialogButtonClear/0/fieldDesc"),
                oFormattedText = new sap.m.FormattedText({
                    htmlText: sHtmlMessage
                }),
                oHeader = new sap.m.Bar({
                    contentLeft: [
                        new sap.m.Title({ text: sHeaderText })
                    ],
                    contentRight: [
                        new Button({
                            icon: "sap-icon://decline",
                            tooltip:sCloseIconText,
                            visible:bIsCloseIconVisible,
                            press: function () {
                                oDialog.close();
                                that.newRadioSelect = false;
                            }
                        })
                    ]
                }),

                // Create dialog
                oDialog = new sap.m.Dialog({
                    type: "Message",
                    contentWidth: "42%",
                    customHeader: oHeader,
                    content: [
                        oFormattedText
                    ],
                    beginButton: new Button({
                        text: bConfirmText,
                        tooltip:bConfirmText,
                        type: library.ButtonType.Emphasized,
                        press: function () {
                            that.newRadioSelect = false;
                            that.prevRadioSelect = false;
                            that.onSlnCheckBoxEvent = false;
                            oDialog.close();
                        }
                    }),
                    endButton: new Button({
                        text: bClearText,
                        tooltip:bClearText,
                        type: library.ButtonType.Attention,
                        press: function () {
                            if (!oChildCntrl) {
                                that.onSolAreaRadioSelectConfirm(that.newRadioSelect);
                            } else {
                                that.onL3L4Select(oChildCntrl, oSelectedRow, bIsSelected, solutionAreaDataModel, true)
                            }
                            that.newRadioSelect = false;
                            that.prevRadioSelect = false;
                            that.onSlnCheckBoxEvent = false;
                            oDialog.close();
                        }
                    }),
                    afterClose: function () {
                        oDialog.destroy();
                    }
                });

            oDialog.open();


        },
           /**
         * Display activity Lead details
         * @param {object} oEvent -The context of the current control.
         * @param {object} that -controller scope.
         */
        onDisplayActLeadInfo: function (oEvent,that) {
			if (!that.ActEmployeeDetails) {
				that.ActEmployeeDetails = sap.ui.xmlfragment(that.getView().getId(),
					"com.dealsupport.melodyrequest.fragments.ActEmployeeDet", that);
				that.getView().addDependent(that.ActEmployeeDetails);
			}
			that.ActEmployeeDetails.openBy(oEvent.getSource());
			// models.getActTeamMemberDetails(oEvent.getSource().getInitials(),this);
            	var aFilter = [new Filter("ID", "EQ", oEvent.getSource().getInitials())];
			models.getActTeamMemberDetails(aFilter,that).then(function (result) {
				var oData = result.data.results;
				that.getView().getModel().setProperty("/actEmpData", oData[0]);
			}.bind(that));
            
		},
          /**
         * Display activity Team details
         * @param {object} oEvent -The context of the current control.
         * @param {object} that -controller scope.
         */
        onTeamDetailPressed: function (oEvent,that) {
			that.getView().getModel().setProperty("/teamDetail",oEvent.getSource().getBinding("text").getValue()[0]);
			if (!that.teamViewFragment) {
				that.teamViewFragment = sap.ui.xmlfragment(that.getView().getId(),
					"com.dealsupport.melodyrequest.fragments.TeamDetails", that);
				that.getView().addDependent(that.teamViewFragment);
			}
			that.teamViewFragment.setTitle(oEvent.getSource().getParent().getParent().getItems()[1].getText());
             that.getView().getModel().refresh();
			that.teamViewFragment.openBy(oEvent.getSource());
		},
        /**
         * Trigger Activity Team email
         * @param {object} oEvent -The context of the current control.
         */
        handleSendMailClick: function (oEvent) {
           window.open("mailto:"+oEvent.getSource().getBindingContext().getProperty("EMAIL"))
        },
          /**
         * Trigger Activity Team phone
         * @param {object} oEvent -The context of the current control.
         */
        handleCallClick: function (evt) {
            library.URLHelper.triggerTel(evt.getSource().getBindingContext().getProperty("MobileNumber"));
    
        },
          /**
         * Function to view list of team members in pop-up
         * @param {object} oEvent -The context of the current control.
         * @param {object} that -controller scope.
         */
        viewDetails: function (oEvent,that) {
            if (!that.userDetailPopup) {
                that.userDetailPopup = sap.ui.xmlfragment(that.getView().getId(),
                    "com.dealsupport.melodyrequest.fragments.ActteamViewDetails", that);
                that.userDetailPopup.setModel(oEvent.getSource().getModel());
                that.getView().addDependent(that.userDetailPopup);
            }
            that.userDetailPopup.bindElement(oEvent.getSource().getBindingContext().getPath());
            that.userDetailPopup.openBy(oEvent.getSource());
        },
         /**Git 277 
         * Common function to set action history data
         * @param {object} oController -The context of the calling contollrer object, typically the controller.
         * @param {object} oDynamicSideView - Action history side view reference
         * @param {object} oOPSideContentBtn - Action history button reference
         */
        _setActionHistoryModel: async function (oController, oDynamicSideView, oOPSideContentBtn,bCommentUpdate) {
            try {
                if (!oController.aWfLogs || bCommentUpdate) {
                    let sNewReq = oController.getView().getModel("multiReqModel") ? oController.getView().getModel("multiReqModel").getProperty("/subcontext/0/NewRequest") :
                        oController.getView().getModel().getProperty("/NewRequest");
                    let aApprovalHistory;
                    if (!sNewReq) {
                        aApprovalHistory = oController.getView().getModel("multiReqModel") ? oController.getView().getModel("multiReqModel").getProperty("/subcontext/0/approvalHistory") :
                            oController.getView().getModel().getProperty("/approvalHistory");
                    } else {
                        const sInstanceID = oController.getView().getModel("wfInstanceModel").getProperty("/InstanceID");
                        aApprovalHistory = await models.fnGetActionHistory(sInstanceID, oController)
                    }
                    let aApproverDetails = oController.getView().getModel("multiReqModel") ? oController.getView().getModel("multiReqModel").getProperty("/subcontext/0/approverDetails") :
                        oController.getView().getModel().getProperty("/approverDetails");
                    let aSubstituteApprover = oController.getView().getModel("multiReqModel") ? oController.getView().getModel("multiReqModel").getProperty("/subcontext/0/substituteApproverDetails") :
                        oController.getView().getModel().getProperty("/substituteApproverDetails");
                    let aAssigmentApprove = oController.getView().getModel("multiReqModel") ? oController.getView().getModel("multiReqModel").getProperty("/subcontext/0/AssignmentApprove") :
                        oController.getView().getModel().getProperty("/AssignmentApprove");
                    let aApproverData = [];
                    if (aApproverDetails) {
                        aApproverData = aApproverDetails;
                    }
                    if (aSubstituteApprover) {
                        aApproverData = aApproverData.concat(aSubstituteApprover);
                    }
                    if (aAssigmentApprove) {
                        aAssigmentApprove.forEach(function (assignments) {
                            if (assignments.NominatedResources) {
                                assignments.NominatedResources.forEach(function (resource) {
                                    aApproverData = aApproverData.concat(resource);
                                })
                            }
                        });
                    }
                    for (let i = 0; i < aApprovalHistory.length; i++) {
                        try {
                            aApprovalHistory[i].userId = aApproverData.filter((user) => user.fullName.toLowerCase() === aApprovalHistory[i].UserName.toLowerCase())[
                                0].userId;
                        } catch (err) {

                        }
                    };
                    let bSkipResources = oController.getView().getModel("multiReqModel") ? oController.getView().getModel("multiReqModel").getProperty("/subcontext/0/Skip_Resource_Approver") :
                        oController.getView().getModel().getProperty("/Skip_Resource_Approver")
                    if (bSkipResources) {
                        let aAssignments = [];
                        let aAppHistoryFiltered = []
                        aApprovalHistory.forEach(function (history, index, object) {
                            if (!history.StepID && history.StepName === "Presales Resource Approval") {
                                history.StepID = "RESAPP";
                            }
                            if (history.StepID === "RESAPP") {
                                aAssignments.push(history.userId);
                                // object.splice(index, 1);
                            } else {
                                aAppHistoryFiltered.push(history)
                            }
                        });
                        aApprovalHistory = aAppHistoryFiltered
                        if (aApprovalHistory) {
                            if (!aApprovalHistory[aApprovalHistory.length - 1].StepID && aApprovalHistory[aApprovalHistory.length - 1].StepName === "Presales Manager Approval") {
                                aApprovalHistory[aApprovalHistory.length - 1].StepID = "MANAPP";
                            }
                            if (aApprovalHistory[aApprovalHistory.length - 1].StepID === "MANAPP") {
                                aApprovalHistory[aApprovalHistory.length - 1].Skip_Resource_Approver = oController.getView().getModel().getProperty("/Skip_Resource_Approver");
                                aApprovalHistory[aApprovalHistory.length - 1].resourceCount = aAssignments.length;
                                aApprovalHistory[aApprovalHistory.length - 1].resourcesId = aAssignments.join(";");
                            }
                        }
                    }

                    // const oWfLogs = aApprovalHistory.reverse();
                    oController.aWfLogs = aApprovalHistory;
                    const oModel = new JSONModel();
                    oModel.setData(aApprovalHistory);
                    oController.getView().setModel(oModel, "wfLogs");
                }
            } catch (oErr) {
                ErrorHandle.setErrorMessage(oErr, oController)
            }
            if (oDynamicSideView && !bCommentUpdate) {
                oController.getView().byId("idTimeline").setGrowing(false);
                oController.getView().byId("idTimeline").setGrowingThreshold(1000);
                const sCurrentBreakpoint = oDynamicSideView.getCurrentBreakpoint();
                if (sCurrentBreakpoint === "S") {
                    oDynamicSideView.toggle();
                } else {
                    oDynamicSideView.setShowSideContent(true);
                }
                oOPSideContentBtn.setVisible(false);
            }else if(!bCommentUpdate){
                oController.getView().byId("idTimeline").setGrowing(true);
                oController.getView().byId("idTimeline").setGrowingThreshold(1);
            }
            sap.ui.core.BusyIndicator.hide();
        },
        fnPressMoreActionHistory: function () {
            this.getView().byId("idTimeline").setForceGrowing(true);
            this.getView().byId("idTimeline").setGrowingThreshold(1000);
            this.getView().byId("idTimeline").setForceGrowing(false);
        },
        onUserNameClick: function (evt) {
            let oContext = evt.getSource().getBindingContext("wfLogs").getObject();
            let sUserId = [oContext.UserId];
            let sName = "Recipients";
            let oValType = "ID"
            if (sUserId) {
                Users.callEmpApi(sUserId, evt, this, sName, oValType);
            }
 
        },
        /**
            *@function getApproversGroup
            *@description Set Header text and info icon key based on service call (Git 720 -> Grouping substitutes and managers)
            * 001 => FS, 002=BS and ORE=> ORE service key
            * @param {object} oContext -Binding context of the list items
        */
        getApproversGroup: function (oContext) {
            let isDelegates = oContext.getProperty("isDelegates"),
                sServiceId = oContext.getProperty("serviceId");
            const serviceConfig = {
                "0001": {
                    headerText: "Resource Coordinators",
                    infoKey: "ResCoordinator_InfoBubble"
                },
                "0002": {
                    headerText: "Resource Administrators",
                    infoKey: "ResAdministrator_InfoBubble"
                },
                "ORE": {
                    headerText: "Managers",
                    infoKey: "Manager_InfoBubble"
                }
            };

            const config = serviceConfig[sServiceId] || {};

            return {
                key: isDelegates ? "Delegates" : config.headerText,
                infoBubbleKey: isDelegates ? "Delegates_InfoBubble" : config.infoKey
            };
        },
        /**
            *@function getApproversGroupHeader
            *@description *Factory function to set group header (Git 720 -> Grouping substitutes and managers)
            * 001 => FS, 002=BS and ORE=> ORE service key
            * @param {object} oGroup -Binding context of the list items
        */
        getApproversGroupHeader: function (oGroup) {
            const oTitle = new sap.m.Title({
                text: oGroup.key
            }).addStyleClass("sapUiSmallMarginBegin sapUiSmallMarginTop");

            const oIcon = new sap.ui.core.Icon({
                src: "sap-icon://hint",
                press: (oEvent) => {
                    this.common._onShowInfoMessage(oEvent, this);
                },
                customData: [
                    new sap.ui.core.CustomData({
                        key: oGroup.infoBubbleKey
                    })
                ]
            }).addStyleClass("size1 sapUiTinyMarginBegin sapUiSmallMarginTop");

            const oHBox = new sap.m.HBox({
                items: [oTitle, oIcon]
            });

            return new sap.m.CustomListItem({
                content: oHBox
            });
        },
            /**
        * call ore service to get manager,role and group master data
        * @function _callOreMasterData
        */
        _callOreMasterData: function (that) {
            //call role(area) master data
               const oLSSystemModel = models.systemLSUserDetailsDataModel(that);
                const sUrlParams = {
                    $expand: `N_RoleTypeToRole`,
                };
                models._callGETOdata(oLSSystemModel, `/YC_OR_M_ROLE_TYPESet`, sUrlParams)
                    .then(function (oData) {
                        if (oData && oData.results) {
                            that.common.loadRoleTypeMasterData(oData.results, that);
                        }
                    })
                    .catch(function (oError) {

                        ErrorHandle.setErrorMessage(oError, that, false, true);
                    });
                models._callGETOdata(oLSSystemModel, `/YC_OR_M_MGR_HIERSet`)
                    .then(function (oData) {
                           if (oData && oData.results) {
                             that.common.loadManagers(oData.results, that)
                        }
                    })
                    .catch(function (oError) {

                        ErrorHandle.setErrorMessage(oError, that, false, true);
                    });
                models._callGETOdata(oLSSystemModel, `/YC_OR_M_GROUP_HIEARCHY`)
                    .then(function (oData) {
                        if (oData && oData.results) {
                            that.setModel(new sap.ui.model.json.JSONModel(oData.results.group), "grpHierarchyForFilter");
                             that.common.loadGroupData(oData.results,that)
                        }
                    })
                    .catch(function (oError) {

                        ErrorHandle.setErrorMessage(oError, that, false, true);
                    });
                models._callGETOdata(oLSSystemModel, `/YC_OR_M_GRP_CLUSTER`)
                    .then(function (oData) {
                        if (oData && oData.results) {
                            that.setModel(new sap.ui.model.json.JSONModel(oData.results), "grpCluster");
                            let aData = JSON.parse(JSON.stringify(oData.results));
                            let newField = {
                                GrpClstrDesc: "All",
                                GrpClstrGuid: "00000000-0000-0000-0000-000000000000",
                                GrpClstrId: "0003",
                            };
                            aData.push(newField);
                            aData.sort((a, b) => a.GrpClstrDesc.localeCompare(b.GrpClstrDesc));
                            that.setModel(new sap.ui.model.json.JSONModel(JSON.parse(JSON.stringify(aData))), "grpClusterWithAll");
                            that.setModel(new sap.ui.model.json.JSONModel(JSON.parse(JSON.stringify(aData))), "grpClusterWithAll");
                        }
                    })
                    .catch(function (oError) {

                        ErrorHandle.setErrorMessage(oError, that, false, true);
                    });
                models._callGETOdata(oLSSystemModel, `/YC_OR_M_SOLUTN_HIER`)
                    .then(function (oData) {
                     if (oData &&  oData.results && oData.results.length) {
                             that.common.loadSolutionArea(oData.results,that)
                        }
                    })
                    .catch(function (oError) {

                        ErrorHandle.setErrorMessage(oError, that, false, true);
                    });
        },
        loadSolutionArea: function (results,that) {

			let aSolutionAreas = results,
				aSAList = [];
			for (let i = 0; i < aSolutionAreas.length; i++) {
				// Missing field - DefaultSel,DisplayGroup
				if (aSolutionAreas[i].SolL1Guid === "005056a2-d550-1eef-aef2-860b60e0d2d9") {
					aSolutionAreas[i].DisplayGroup = "2";
				}
				let oL1 = aSAList.find(item => item.Guid === aSolutionAreas[i].SolL1Guid);
				if (!oL1 && aSolutionAreas[i].SolL1Guid && aSolutionAreas[i].SolL1Guid !== "" && aSolutionAreas[i].SolL1Guid !==
					"00000000-0000-0000-0000-000000000000" && aSolutionAreas[i].L1Viewable.toUpperCase() === "X") {
					oL1 = {
						Guid: aSolutionAreas[i].SolL1Guid,
						ID: aSolutionAreas[i].SolL1Id,
						Desc: aSolutionAreas[i].SolL1Desc,
						LevelId: 1,
						SolAreal1Guid: aSolutionAreas[i].SolL1Guid,
						SolAreal1Desc: aSolutionAreas[i].SolL1Desc,
						DisplayGuid: aSolutionAreas[i].SolL1Guid,
						DisplayDesc: aSolutionAreas[i].SolL1Desc,
						// RoleAreaGuid: element.RoleAreaGuid,
						IsDefault: (aSolutionAreas[i].L1DefaultSel && aSolutionAreas[i].L1DefaultSel === "X") ? true : false,
						IsNonFocused: (aSolutionAreas[i].DisplayGroup && aSolutionAreas[i].DisplayGroup === "2") ? true : false,
						IsPrimaryRequire: (aSolutionAreas[i].L1Primary && aSolutionAreas[i].L1Primary.toUpperCase() === "X") ? true : false,
						IsPrimary: false,
						IsEnabled: (aSolutionAreas[i].DisplayGroup !== "4"),
						IsSelected: false,
						IsViewable: (aSolutionAreas[i].L1Viewable && aSolutionAreas[i].L1Viewable.toUpperCase() === "X") ? true : false,
						IsSelectable: (aSolutionAreas[i].L1Selectable && aSolutionAreas[i].L1Selectable.toUpperCase() === "X") ? true : false,
						IsPrimCatalyst: (aSolutionAreas[i].L1PrimCatalyst && aSolutionAreas[i].L1PrimCatalyst.toUpperCase() === "X") ? true : false,
						IsMaterial: false,
						IsSelectableFlag: (aSolutionAreas[i].L1Selectable && aSolutionAreas[i].L1Selectable.toUpperCase() === "X") ? true : false,
						IsPrimCatalystFlag: (aSolutionAreas[i].L1PrimCatalyst && aSolutionAreas[i].L1PrimCatalyst.toUpperCase() === "X") ? true : false,
						IsPrimaryFlag: (aSolutionAreas[i].L1Primary && aSolutionAreas[i].L1Primary.toUpperCase() === "X") ? true : false,
						Levels: [],
					};
					aSAList.push(oL1);
					aSAList.sort((a, b) => a.Desc.localeCompare(b.Desc));
				}
				if (oL1) {
					let oL2 = oL1.Levels.find(item => item.Guid === aSolutionAreas[i].SolL2Guid);
					if (!oL2 && aSolutionAreas[i].SolL2Guid && aSolutionAreas[i].SolL2Guid !== "" && aSolutionAreas[i].SolL2Guid !==
						"00000000-0000-0000-0000-000000000000" && aSolutionAreas[i].L2Viewable.toUpperCase() === "X") {
						oL2 = {
							Guid: aSolutionAreas[i].SolL2Guid,
							ID: aSolutionAreas[i].SolL2Id,
							Desc: aSolutionAreas[i].SolL2Desc,
							LevelId: 2,
							SolAreal1Guid: aSolutionAreas[i].SolL1Guid,
							SolAreal1Desc: aSolutionAreas[i].SolL1Desc,
							SolAreal2Guid: aSolutionAreas[i].SolL2Guid,
							SolAreal2Desc: aSolutionAreas[i].SolL2Desc,
							DisplayGuid: oL1.DisplayGuid + "," + aSolutionAreas[i].SolL2Guid,
							DisplayDesc: oL1.DisplayDesc + " > " + aSolutionAreas[i].SolL2Desc,
							IsDefault: (aSolutionAreas[i].L1DefaultSel && aSolutionAreas[i].L1DefaultSel === "X") ? true : false,
							IsNonFocused: (aSolutionAreas[i].DisplayGroup && aSolutionAreas[i].DisplayGroup === "2") ? true : false,
							IsPrimaryRequire: (aSolutionAreas[i].L2Primary && aSolutionAreas[i].L2Primary.toUpperCase() === "X") ? true : false,
							IsPrimary: false,
							IsEnabled: (aSolutionAreas[i].DisplayGroup !== "4"),
							IsSelected: false,
							IsViewable: (aSolutionAreas[i].L2Viewable && aSolutionAreas[i].L2Viewable.toUpperCase() === "X") ? true : false,
							IsSelectable: (aSolutionAreas[i].L2Selectable && aSolutionAreas[i].L2Selectable.toUpperCase() === "X") ? true : false,
							IsPrimCatalyst: (aSolutionAreas[i].L2PrimCatalyst && aSolutionAreas[i].L2PrimCatalyst.toUpperCase() === "X") ? true : false,
							IsMaterial: false,
							IsSelectableFlag: (aSolutionAreas[i].L2Selectable && aSolutionAreas[i].L2Selectable.toUpperCase() === "X") ? true : false,
							IsPrimCatalystFlag: (aSolutionAreas[i].L2PrimCatalyst && aSolutionAreas[i].L2PrimCatalyst.toUpperCase() === "X") ? true : false,
							IsPrimaryFlag: (aSolutionAreas[i].L2Primary && aSolutionAreas[i].L2Primary.toUpperCase() === "X") ? true : false,
							Levels: []
						};
						oL1.Levels.push(oL2);
						oL1.Levels.sort((a, b) => a.Desc.localeCompare(b.Desc));
					}
					if (oL2) {
						let oL3 = oL2.Levels.find(item => item.Guid === aSolutionAreas[i].SolL3Guid);
						if (!oL3 && aSolutionAreas[i].SolL3Guid && aSolutionAreas[i].SolL3Guid !== "" && aSolutionAreas[i].SolL3Guid !==
							"00000000-0000-0000-0000-000000000000" && aSolutionAreas[i].L3Viewable.toUpperCase() === "X") {
							oL3 = {
								Guid: aSolutionAreas[i].SolL3Guid,
								ID: aSolutionAreas[i].SolL3Id,
								Desc: aSolutionAreas[i].SolL3Desc,
								LevelId: 3,
								SolAreal1Guid: aSolutionAreas[i].SolL1Guid,
								SolAreal1Desc: aSolutionAreas[i].SolL1Desc,
								SolAreal2Guid: aSolutionAreas[i].SolL2Guid,
								SolAreal2Desc: aSolutionAreas[i].SolL2Desc,
								SolAreal3Guid: aSolutionAreas[i].SolL3Guid,
								SolAreal3Desc: aSolutionAreas[i].SolL3Desc,
								DisplayGuid: oL2.DisplayGuid + "," + aSolutionAreas[i].SolL3Guid,
								DisplayDesc: oL2.DisplayDesc + " > " + aSolutionAreas[i].SolL3Desc,
								IsDefault: (aSolutionAreas[i].L1DefaultSel && aSolutionAreas[i].L1DefaultSel === "X") ? true : false,
								IsNonFocused: (aSolutionAreas[i].DisplayGroup && aSolutionAreas[i].DisplayGroup === "2") ? true : false,
								IsPrimaryRequire: (aSolutionAreas[i].L3Primary && aSolutionAreas[i].L3Primary.toUpperCase() === "X") ? true : false,
								IsPrimary: false,
								IsEnabled: (aSolutionAreas[i].DisplayGroup !== "4"),
								IsSelected: false,
								IsViewable: (aSolutionAreas[i].L3Viewable && aSolutionAreas[i].L3Viewable.toUpperCase() === "X") ? true : false,
								IsSelectable: (aSolutionAreas[i].L3Selectable && aSolutionAreas[i].L3Selectable.toUpperCase() === "X") ? true : false,
								IsPrimCatalyst: (aSolutionAreas[i].L3PrimCatalyst && aSolutionAreas[i].L3PrimCatalyst.toUpperCase() === "X") ? true : false,
								IsMaterial: false,
								IsSelectableFlag: (aSolutionAreas[i].L3Selectable && aSolutionAreas[i].L3Selectable.toUpperCase() === "X") ? true : false,
								IsPrimCatalystFlag: (aSolutionAreas[i].L3PrimCatalyst && aSolutionAreas[i].L3PrimCatalyst.toUpperCase() === "X") ? true : false,
								IsPrimaryFlag: (aSolutionAreas[i].L3Primary && aSolutionAreas[i].L3Primary.toUpperCase() === "X") ? true : false,
								Levels: []
							};
							oL2.Levels.push(oL3);
							oL2.Levels.sort((a, b) => a.Desc.localeCompare(b.Desc));
						}
						if (oL3) {
							let oL4 = oL3.Levels.find(item => item.Guid === aSolutionAreas[i].SolL4Guid);
							if (!oL4 && aSolutionAreas[i].SolL4Guid && aSolutionAreas[i].SolL4Guid !== "" && aSolutionAreas[i].SolL4Guid !==
								"00000000-0000-0000-0000-000000000000" && aSolutionAreas[i].L4Viewable.toUpperCase() === "X") {
								oL4 = {
									Guid: aSolutionAreas[i].SolL4Guid,
									ID: aSolutionAreas[i].SolL4Id,
									Desc: aSolutionAreas[i].SolL4Desc,
									LevelId: 4,
									SolAreal1Guid: aSolutionAreas[i].SolL1Guid,
									SolAreal1Desc: aSolutionAreas[i].SolL1Desc,
									SolAreal2Guid: aSolutionAreas[i].SolL2Guid,
									SolAreal2Desc: aSolutionAreas[i].SolL2Desc,
									SolAreal3Guid: aSolutionAreas[i].SolL3Guid,
									SolAreal3Desc: aSolutionAreas[i].SolL3Desc,
									SolAreal4Guid: aSolutionAreas[i].SolL4Guid,
									SolAreal4Desc: aSolutionAreas[i].SolL4Desc,
									DisplayGuid: oL3.DisplayGuid + "," + aSolutionAreas[i].SolL4Guid,
									DisplayDesc: oL3.DisplayDesc + " > " + aSolutionAreas[i].SolL4Desc,
									IsDefault: (aSolutionAreas[i].L1DefaultSel && aSolutionAreas[i].L1DefaultSel === "X") ? true : false,
									IsNonFocused: (aSolutionAreas[i].DisplayGroup && aSolutionAreas[i].DisplayGroup === "2") ? true : false,
									IsPrimaryRequire: (aSolutionAreas[i].L4Primary && aSolutionAreas[i].L4Primary.toUpperCase() === "X") ? true : false,
									IsPrimary: false,
									IsEnabled: (aSolutionAreas[i].DisplayGroup !== "4"),
									IsSelected: false,
									IsViewable: (aSolutionAreas[i].L4Viewable && aSolutionAreas[i].L4Viewable.toUpperCase() === "X") ? true : false,
									IsSelectable: (aSolutionAreas[i].L4Selectable && aSolutionAreas[i].L4Selectable.toUpperCase() === "X") ? true : false,
									IsPrimCatalyst: (aSolutionAreas[i].L4PrimCatalyst && aSolutionAreas[i].L4PrimCatalyst.toUpperCase() === "X") ? true : false,
									IsMaterial: false,
									IsSelectableFlag: (aSolutionAreas[i].L4Selectable && aSolutionAreas[i].L4Selectable.toUpperCase() === "X") ? true : false,
									IsPrimCatalystFlag: (aSolutionAreas[i].L4PrimCatalyst && aSolutionAreas[i].L4PrimCatalyst.toUpperCase() === "X") ? true : false,
									IsPrimaryFlag: (aSolutionAreas[i].L4Primary && aSolutionAreas[i].L4Primary.toUpperCase() === "X") ? true : false,
									Levels: []
								};
								oL3.Levels.push(oL4);
								oL3.Levels.sort((a, b) => a.Desc.localeCompare(b.Desc));
							}
							if (oL4) {
								let oL5 = oL4.Levels.find(item => item.Guid === aSolutionAreas[i].SolL5Guid);
								if (!oL5 && aSolutionAreas[i].SolL5Guid && aSolutionAreas[i].SolL5Guid !== "" && aSolutionAreas[i].SolL5Guid !==
									"00000000-0000-0000-0000-000000000000" && aSolutionAreas[i].L5Viewable.toUpperCase() === "X") {
									oL5 = {
										Guid: aSolutionAreas[i].SolL5Guid,
										ID: aSolutionAreas[i].SolL5Id,
										Desc: aSolutionAreas[i].SolL5Desc,
										LevelId: 5,
										SolAreal1Guid: aSolutionAreas[i].SolL1Guid,
										SolAreal1Desc: aSolutionAreas[i].SolL1Desc,
										SolAreal2Guid: aSolutionAreas[i].SolL2Guid,
										SolAreal2Desc: aSolutionAreas[i].SolL2Desc,
										SolAreal3Guid: aSolutionAreas[i].SolL3Guid,
										SolAreal3Desc: aSolutionAreas[i].SolL3Desc,
										SolAreal4Guid: aSolutionAreas[i].SolL4Guid,
										SolAreal4Desc: aSolutionAreas[i].SolL4Desc,
										SolAreal5Guid: aSolutionAreas[i].SolL5Guid,
										SolAreal5Desc: aSolutionAreas[i].SolL5Desc,
										DisplayGuid: oL4.DisplayGuid + "," + aSolutionAreas[i].SolL5Guid,
										DisplayDesc: oL4.DisplayDesc + " > " + aSolutionAreas[i].SolL5Desc,
										IsDefault: (aSolutionAreas[i].L1DefaultSel && aSolutionAreas[i].L1DefaultSel === "X") ? true : false,
										IsNonFocused: (aSolutionAreas[i].DisplayGroup && aSolutionAreas[i].DisplayGroup === "2") ? true : false,
										IsPrimaryRequire: (aSolutionAreas[i].L5Primary && aSolutionAreas[i].L5Primary.toUpperCase() === "X") ? true : false,
										IsPrimary: false,
										IsEnabled: (aSolutionAreas[i].DisplayGroup !== "4"),
										IsSelected: false,
										IsViewable: (aSolutionAreas[i].L5Viewable && aSolutionAreas[i].L5Viewable.toUpperCase() === "X") ? true : false,
										IsSelectable: (aSolutionAreas[i].L5Selectable && aSolutionAreas[i].L5Selectable.toUpperCase() === "X") ? true : false,
										IsPrimCatalyst: (aSolutionAreas[i].L5PrimCatalyst && aSolutionAreas[i].L5PrimCatalyst.toUpperCase() === "X") ? true : false,
										IsMaterial: false,
										IsSelectableFlag: (aSolutionAreas[i].L5Selectable && aSolutionAreas[i].L5Selectable.toUpperCase() === "X") ? true : false,
										IsPrimCatalystFlag: (aSolutionAreas[i].L5PrimCatalyst && aSolutionAreas[i].L5PrimCatalyst.toUpperCase() === "X") ? true : false,
										IsPrimaryFlag: (aSolutionAreas[i].L5Primary && aSolutionAreas[i].L5Primary.toUpperCase() === "X") ? true : false

									};
									oL4.Levels.push(oL5);
									oL4.Levels.sort((a, b) => a.Desc.localeCompare(b.Desc));
								}
							}
						}
					}
				}
			}

			let oSln = {
				mastersolutionareas: results,
				solutionareas: aSAList
			};
              that.setModel(new sap.ui.model.json.JSONModel(oSln), "solutionAreaFilterMasterData");
		},
        loadGroupData: function (results, that) {
            const aGroups = [];
            const aGroupsWithoutCluster = [];
            for (let i = 0; i < results.length; i++) {
                let oCluster = aGroups.find(item => item.guid === results[i].GrpClstrGuid);
                if (!oCluster && results[i].GrpClstrDesc && results[i].GrpClstrDesc !== "") {
                    oCluster = {
                        guid: results[i].GrpClstrGuid,
                        id: results[i].GrpClstrId,
                        desc: results[i].GrpClstrDesc,
                        cluster: results[i].GrpClstrGuid,
                        parent: "",
                        displayguid: results[i].GrpClstrGuid,
                        display: results[i].GrpClstrDesc,
						GroupGuidAndId: results[i].GrpClstrGuid + "|" + results[i].GrpClstrId,
						GroupGuidAndDesc: results[i].GrpClstrGuid + "|" + results[i].GrpClstrDesc,
						editableLead: false,
						selectedLead: false,
						nodes: [],
						GrpClstrGuid: results[i].GrpClstrGuid,
						GrpClstrDesc: results[i].GrpClstrDesc,
						partiallySelected: false,
						LevelId: 0
					};
					aGroups.push(oCluster);

					aGroups.sort((a, b) => a.desc.localeCompare(b.desc));
				}

				if (oCluster) {
					const aL1 = oCluster.nodes;

					let oL1 = aL1.find(item => item.guid === results[i].GroupL1Guid);
					if (!oL1 && results[i].GroupL1Desc && results[i].GroupL1Desc !== "") {
						oL1 = {
							guid: results[i].GroupL1Guid,
							id: results[i].GroupL1ID,
							desc: results[i].GroupL1Desc,
							cluster: results[i].GrpClstrGuid,
							parent: results[i].GrpClstrGuid,
							displayguid: results[i].GrpClstrGuid + "," + results[i].GroupL1Guid,
							display: results[i].GrpClstrDesc + " > " + results[i].GroupL1Desc,
							GroupGuidAndId: results[i].GrpClstrGuid + "|" + results[i].GrpClstrId + "," + results[i].GroupL1Guid + "|" +
								results[i].GroupL1ID,
							GroupGuidAndDesc: results[i].GrpClstrGuid + "|" + results[i].GrpClstrDesc + "," + results[i].GroupL1Guid + "|" +
								results[i].GroupL1Desc,
							editableLead: true,
							selectedLead: false,
							nodes: [],
							GrpClstrGuid: results[i].GrpClstrGuid,
							GrpClstrDesc: results[i].GrpClstrDesc,
							GroupL1Guid: results[i].GroupL1Guid,
							GroupL1Desc: results[i].GroupL1Desc,
							partiallySelected: false,
							LevelId: 1
						};
						aL1.push(oL1);

						aL1.sort((a, b) => a.desc.localeCompare(b.desc));
					}

					if (oL1) {
						const aL2 = oL1.nodes;
						let oL2 = aL2.find(item => item.guid === results[i].GroupL2Guid);

						if (!oL2 && results[i].GroupL2Desc && results[i].GroupL2Desc !== "") {
							oL2 = {
								guid: results[i].GroupL2Guid,
								id: results[i].GroupL2ID,
								desc: results[i].GroupL2Desc,
								cluster: results[i].GrpClstrGuid,
								parent: results[i].GroupL1Guid,
								displayguid: results[i].GrpClstrGuid + "," + results[i].GroupL1Guid + "," + results[i].GroupL2Guid,
								display: results[i].GrpClstrDesc + " > " + results[i].GroupL1Desc + " > " + results[i].GroupL2Desc,
								GroupGuidAndId: results[i].GrpClstrGuid + "|" + results[i].GrpClstrId + "," + results[i].GroupL1Guid + "|" +
									results[i].GroupL1ID + "," + results[i].GroupL2Guid + "|" + results[i].GroupL2ID,
								GroupGuidAndDesc: results[i].GrpClstrGuid + "|" + results[i].GrpClstrDesc + "," + results[i].GroupL1Guid + "|" +
									results[i].GroupL1Desc + "," + results[i].GroupL2Guid + "|" + results[i].GroupL2Desc,
								editableLead: true,
								selectedLead: false,
								nodes: [],
								GrpClstrGuid: results[i].GrpClstrGuid,
								GrpClstrDesc: results[i].GrpClstrDesc,
								GroupL1Guid: results[i].GroupL1Guid,
								GroupL1Desc: results[i].GroupL1Desc,
								GroupL2Guid: results[i].GroupL2Guid,
								GroupL2Desc: results[i].GroupL2Desc,
								partiallySelected: false,
								LevelId: 2
							};
							aL2.push(oL2);
							aL2.sort((a, b) => a.desc.localeCompare(b.desc));
						}

						if (oL2) {
							const aL3 = oL2.nodes;
							let oL3 = aL3.find(item => item.guid === results[i].GroupL3Guid);
							if (!oL3 && results[i].GroupL3Desc && results[i].GroupL3Desc !== "") {
								oL3 = {
									guid: results[i].GroupL3Guid,
									id: results[i].GroupL3ID,
									desc: results[i].GroupL3Desc,
									cluster: results[i].GrpClstrGuid,
									parent: results[i].GroupL2Guid,
									displayguid: results[i].GrpClstrGuid + "," + results[i].GroupL1Guid + "," + results[i].GroupL2Guid + "," +
										results[i].GroupL3Guid,
									display: results[i].GrpClstrDesc + " > " + results[i].GroupL1Desc + " > " + results[i].GroupL2Desc + " > " +
										results[i].GroupL3Desc,
									GroupGuidAndId: results[i].GrpClstrGuid + "|" + results[i].GrpClstrId + "," + results[i].GroupL1Guid + "|" +
										results[i].GroupL1ID + "," + results[i].GroupL2Guid + "|" + results[i].GroupL2ID + "," +
										results[i].GroupL3Guid + "|" + results[i].GroupL3ID,
									GroupGuidAndDesc: results[i].GrpClstrGuid + "|" + results[i].GrpClstrDesc + "," + results[i].GroupL1Guid + "|" +
										results[i].GroupL1Desc + "," + results[i].GroupL2Guid + "|" + results[i].GroupL2Desc + "," +
										results[i].GroupL3Guid + "|" + results[i].GroupL3Desc,
									editableLead: true,
									selectedLead: false,
									nodes: [],
									GrpClstrGuid: results[i].GrpClstrGuid,
									GrpClstrDesc: results[i].GrpClstrDesc,
									GroupL1Guid: results[i].GroupL1Guid,
									GroupL1Desc: results[i].GroupL1Desc,
									GroupL2Guid: results[i].GroupL2Guid,
									GroupL2Desc: results[i].GroupL2Desc,
									GroupL3Guid: results[i].GroupL3Guid,
									GroupL3Desc: results[i].GroupL3Desc,
									partiallySelected: false,
									LevelId: 3
								};
								aL3.push(oL3);
								aL3.sort((a, b) => a.desc.localeCompare(b.desc));
							}

							if (oL3) {
								const aL4 = oL3.nodes;
								let oL4 = aL4.find(item => item.guid === results[i].GroupL4Guid);
								if (!oL4 && results[i].GroupL4Desc && results[i].GroupL4Desc !== "") {
									oL4 = {
										guid: results[i].GroupL4Guid,
										id: results[i].GroupL4ID,
										desc: results[i].GroupL4Desc,
										cluster: results[i].GrpClstrGuid,
										parent: results[i].GroupL3Guid,
										displayguid: results[i].GrpClstrGuid + "," + results[i].GroupL1Guid + "," + results[i].GroupL2Guid + "," +
											results[i].GroupL3Guid + "," + results[i].GroupL4Guid,
										display: results[i].GrpClstrDesc + " > " + results[i].GroupL1Desc + " > " + results[i].GroupL2Desc + " > " +
											results[i].GroupL3Desc + " > " +
											results[i].GroupL4Desc,
										GroupGuidAndId: results[i].GrpClstrGuid + "|" + results[i].GrpClstrId + "," + results[i].GroupL1Guid + "|" +
											results[i].GroupL1ID + "," + results[i].GroupL2Guid + "|" + results[i].GroupL2ID + "," +
											results[i].GroupL3Guid + "|" + results[i].GroupL3ID + "," + results[i].GroupL4Guid + "|" + results[i].GroupL4ID,
										GroupGuidAndDesc: results[i].GrpClstrGuid + "|" + results[i].GrpClstrDesc + "," + results[i].GroupL1Guid + "|" +
											results[i].GroupL1Desc + "," + results[i].GroupL2Guid + "|" + results[i].GroupL2Desc + "," +
											results[i].GroupL3Guid + "|" + results[i].GroupL3Desc + "," + results[i].GroupL4Guid + "|" + results[i].GroupL4Desc,
										editableLead: true,
										selectedLead: false,
										nodes: [],
										GrpClstrGuid: results[i].GrpClstrGuid,
										GrpClstrDesc: results[i].GrpClstrDesc,
										GroupL1Guid: results[i].GroupL1Guid,
										GroupL1Desc: results[i].GroupL1Desc,
										GroupL2Guid: results[i].GroupL2Guid,
										GroupL2Desc: results[i].GroupL2Desc,
										GroupL3Guid: results[i].GroupL3Guid,
										GroupL3Desc: results[i].GroupL3Desc,
										GroupL4Guid: results[i].GroupL4Guid,
										GroupL4Desc: results[i].GroupL4Desc,
										partiallySelected: false,
										LevelId: 4
									};
									aL4.push(oL4);
									aL4.sort((a, b) => a.desc.localeCompare(b.desc));
								}

								if (oL4) {
									const aL5 = oL4.nodes;
									let oL5 = aL5.find(item => item.guid === results[i].GroupL5Guid);
									if (!oL5 && results[i].GroupL5Desc && results[i].GroupL5Desc !== "") {
										oL5 = {
											guid: results[i].GroupL5Guid,
											id: results[i].GroupL5ID,
											desc: results[i].GroupL5Desc,
											cluster: results[i].GrpClstrGuid,
											parent: results[i].GroupL4Guid,
											displayguid: results[i].GrpClstrGuid + "," + results[i].GroupL1Guid + "," + results[i].GroupL2Guid + "," +
												results[i].GroupL3Guid + "," + results[i].GroupL4Guid + "," + results[i].GroupL5Guid,
											display: results[i].GrpClstrDesc + " > " + results[i].GroupL1Desc + " > " + results[i].GroupL2Desc + " > " +
												results[i].GroupL3Desc + " > " +
												results[i].GroupL4Desc + " > " + results[i].GroupL5Desc,
											GroupGuidAndId: results[i].GrpClstrGuid + "|" + results[i].GrpClstrId + "," + results[i].GroupL1Guid + "|" +
												results[i].GroupL1ID + "," + results[i].GroupL2Guid + "|" + results[i].GroupL2ID + "," +
												results[i].GroupL3Guid + "|" + results[i].GroupL3ID + "," + results[i].GroupL4Guid + "|" + results[i].GroupL4ID +
												"," + results[i].GroupL5Guid + "|" + results[i].GroupL5ID,
											GroupGuidAndDesc: results[i].GrpClstrGuid + "|" + results[i].GrpClstrDesc + "," + results[i].GroupL1Guid + "|" +
												results[i].GroupL1Desc + "," + results[i].GroupL2Guid + "|" + results[i].GroupL2Desc + "," +
												results[i].GroupL3Guid + "|" + results[i].GroupL3Desc + "," + results[i].GroupL4Guid + "|" + results[i].GroupL4Desc +
												"," + results[i].GroupL5Guid + "|" + results[i].GroupL5Desc,
											editableLead: true,
											selectedLead: false,
											nodes: [],
											GrpClstrGuid: results[i].GrpClstrGuid,
											GrpClstrDesc: results[i].GrpClstrDesc,
											GroupL1Guid: results[i].GroupL1Guid,
											GroupL1Desc: results[i].GroupL1Desc,
											GroupL2Guid: results[i].GroupL2Guid,
											GroupL2Desc: results[i].GroupL2Desc,
											GroupL3Guid: results[i].GroupL3Guid,
											GroupL3Desc: results[i].GroupL3Desc,
											GroupL4Guid: results[i].GroupL4Guid,
											GroupL4Desc: results[i].GroupL4Desc,
											GroupL5Guid: results[i].GroupL5Guid,
											GroupL5Desc: results[i].GroupL5Desc,
											partiallySelected: false,
											LevelId: 5
										};
										aL5.push(oL5);
										aL5.sort((a, b) => a.desc.localeCompare(b.desc));
									}
								}
							}
						}
					}
				}
			}

			for (let i = 0; i < aGroups.length; i++) {
				aGroupsWithoutCluster.push(...aGroups[i].nodes);
            }
            that.setModel(new sap.ui.model.json.JSONModel(aGroupsWithoutCluster), "aGroupsWithoutCluster");
            that.getModel("grpHierarchyForFilter").setData(aGroups);
            that.getModel("grpHierarchyForFilter").refresh();
			return {
				group: aGroups,
				groupWithoutCluster: aGroupsWithoutCluster
			};
		},
        loadRoleTypeMasterData: function (results, that) {
            const noGuid = "00000000-0000-0000-0000-000000000000";
            const aRoleTypes = [];
            const aRoleMaster = [];
            const aRoleMasterWithoutDuplicate = [];
            for (let i = 0; i < results.length; i++) {
                const oRoleType = {
                    Guid: results[i].RoleTypeGuid,
                    ID: results[i].RoleTypeID,
                    Desc: results[i].RoleTypeDesc,
                    Roles: [],
                    IsPrimary: false,
                    IsEnabled: true,
                    IsSelected: false,
                };

                if (results[i].N_RoleTypeToRole && results[i].N_RoleTypeToRole.results) {
                    const roles = results[i].N_RoleTypeToRole.results;

                    for (let j = 0; j < roles.length; j++) {
                        roles[j].RoleAreas = [];
                        roles[j].Guid = roles[j].RoleGuid;
                        roles[j].ID = roles[j].RoleID;
                        roles[j].Desc = roles[j].RoleDesc;
                        roles[j].IsPrimary = false;
                        roles[j].IsEnabled = true;
                        roles[j].IsSelected = false;
                        roles[j].RoleTypeDesc = results[i].RoleTypeDesc;
                        roles[j].IsVisible = true;
                        const oRoleAreas = {
                            Guid: roles[j].RoleAreaGuid,
                            ID: roles[j].RoleAreaID,
                            Desc: roles[j].RoleAreaDesc,
                            RoleGuid: roles[j].RoleGuid,
                            IsPrimary: false,
                            IsEnabled: true,
                            IsSelected: false,
                            IsPrimaryRole: false,
                            BAIndustries: [],
                            BALoBs: [],
                            BASegments: [],
                            CrossCvg: [],
                            GroupClstrGuid: roles[j].GroupClstrGuid,
                            GroupL1Guid: roles[j].GroupL1Guid,
                            GroupL2Guid: roles[j].GroupL2Guid,
                            GroupL3Guid: roles[j].GroupL3Guid,
                            GroupL4Guid: roles[j].GroupL4Guid,
                            GroupL5Guid: roles[j].GroupL5Guid,
                            RoleTypeDesc: results[i].RoleTypeDesc,
                            RoleTypeGuid: results[i].RoleTypeGuid,
                            ExceptionFlag: roles[j].ExceptionFlag,
                            Metadata: {
                                BAINDMeta: "G",
                                BALOBMeta: "G",
                                BASEGMeta: "G",
                                InnovationMeta: "G"
                            },
                        };

                        let oRole = oRoleType.Roles.find(item => roles[j].RoleGuid === item.RoleGuid && ((roles[j].GroupClstrGuid === noGuid && roles[j]
                            .GroupL1Guid === noGuid && roles[j].GroupL2Guid === noGuid && roles[j].GroupL3Guid === noGuid && roles[j].GroupL4Guid ===
                            noGuid && roles[j].GroupL5Guid === noGuid) || ((roles[j].GroupClstrGuid !== noGuid && roles[j]
                                .GroupClstrGuid === item.GroupClstrGuid) || (roles[j].GroupL1Guid !==
                                    noGuid && roles[j].GroupL1Guid === item.GroupL1Guid) || (roles[j].GroupL2Guid !== noGuid && roles[j].GroupL2Guid ===
                                        item.GroupL2Guid) || (roles[j].GroupL3Guid !== noGuid && roles[j].GroupL3Guid === item.GroupL3Guid) || (roles[j].GroupL4Guid !==
                                            noGuid && roles[j].GroupL4Guid === item.GroupL4Guid) || (roles[j].GroupL5Guid !== noGuid && roles[j].GroupL5Guid ===
                                                item.GroupL5Guid))));
                        if (!oRole) {
                            roles[j].RoleAreas.push(oRoleAreas);
                            oRoleType.Roles.push(roles[j]);
                        } else if (oRole) {
                            const iIndex = oRoleType.Roles.findIndex(item => roles[j].RoleGuid === item.RoleGuid);
                            oRoleType.Roles[iIndex].RoleAreas.push(oRoleAreas);
                        }

                        const oDuplicateRole = aRoleMasterWithoutDuplicate.find(item => roles[j].RoleGuid === item.RoleGuid);
                        if (!oDuplicateRole) {
                            aRoleMasterWithoutDuplicate.push(roles[j]);
                            aRoleMasterWithoutDuplicate.sort((a, b) => a.Desc.localeCompare(b.Desc));
                        }
                        aRoleMaster.push(roles[j]);
                    }
                }
                aRoleTypes.push(oRoleType);
            }
            that.setModel(new sap.ui.model.json.JSONModel(aRoleMasterWithoutDuplicate), "roleMasterDataFilter");
        },
        loadManagers: function (results, that) {
            const aManagers1 = [];
            const aManagers2 = [];
            const aManagers3 = [];
            for (var i = 0; i < results.length; i++) {

                const oResult = results[i];

                const iManager1Index = aManagers1.findIndex((item) => {
                    return item.Manager1IPPID === oResult.Manager1IPPID;
                });

                if (iManager1Index === -1 && oResult.Manager2IPPID && oResult.Manager1IPPID !== "") {
                    aManagers1.push(oResult);
                }

                const iManager2Index = aManagers2.findIndex((item) => {
                    return item.Manager2IPPID === oResult.Manager2IPPID;
                });

                if (iManager2Index === -1 && oResult.Manager2IPPID && oResult.Manager2IPPID !== "") {
                    aManagers2.push({
                        Manager2IPPID: oResult.Manager2IPPID,
                        Manager2IPP: oResult.Manager2IPP,
                        Manager1IPPID: oResult.Manager1IPPID,
                        Manager1IPP: oResult.Manager1IPP
                    });
                }

                const iManager3Index = aManagers3.findIndex((item) => {
                    return item.Manager3IPPID === oResult.Manager3IPPID;
                });

                if (iManager3Index === -1 && oResult.Manager3IPPID && oResult.Manager3IPPID !== "") {
                    aManagers3.push({
                        Manager3IPPID: oResult.Manager3IPPID,
                        Manager3IPP: oResult.Manager3IPP,
                        Manager1IPPID: oResult.Manager1IPPID,
                        Manager1IPP: oResult.Manager1IPP
                    });
                }
            }
            that.setModel(new sap.ui.model.json.JSONModel(aManagers1), "managers");
            that.getModel("managers").setSizeLimit(99999);
            that.getModel("managers").refresh();
        },
        valueHelpRequestGroup: function (controller, isFilter, oEvent, bIsCreateReq) {
            const that = controller;
            let oView = controller.getView();
            if (!controller._pFilterGroup) {
                controller._pFilterGroup = Fragment.load({
                    id: oView.getId(),
                    name: "com.dealsupport.melodyrequest.fragments.filter.group",
                    controller: controller
                }).then(function (oDialog) {
                    that.pFilterGrpDialog = oDialog;
                    oView.addDependent(oDialog);
                    return oDialog;
                });
            }
            controller._pFilterGroup.then(function (oDialog) {
                    that.getView().getModel("employee").setProperty("/sSearchBoxText", "");
                if (isFilter) {
                    that.onSearchGroupFilter();
                    let aSelectedGrp = that.getView().getModel("employee").getProperty("/filter/Group/SelectedKeys");
                    let aExtendedGrp = jQuery.extend(true, [], aSelectedGrp);
                    that.getView().getModel("employee").setProperty("/filter/dialogselGroup", JSON.parse(JSON.stringify(aExtendedGrp)));
                    that.getView().getModel("employee").setProperty("/filter/oTempEmployee/TempGroupFilters", JSON.parse(JSON.stringify(aExtendedGrp)));
                    that.getView().getModel("employee").setProperty("/filter/TempGroupFilters", JSON.parse(JSON.stringify(aExtendedGrp)));
                    aExtendedGrp.length ? that.getView().getModel("employee").setProperty("/filter/dialogselGroupVisible", true) :
                        that.getView().getModel("employee").setProperty("/filter/dialogselGroupVisible", false)
                    that.getView().getModel("employee").refresh();
                    that.setGroupFilterHierarchySelection();
                    that.fnSelectGroupFilterCluster("grpHierarchyForFilter");
                } else if(bIsCreateReq) {
                    const oBindingIndex = Number(oEvent.getSource().getBindingContext("employee").getPath().split('/')[2]);
                    that.getView().getModel("employee").setProperty(`/searchItems/${oBindingIndex}/iIndex`, oBindingIndex);
                    that.getOwnerComponent().getModel("grpHierarchyForFilter").setProperty("/selectedGrpID",that.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}`)?.TempEmployee?.SelectedGroup?.[0]?.GroupID)
                    that.getView().setModel(new sap.ui.model.json.JSONModel(), "masterDataModel");
                    const oMasterDataModel = that.getView().getModel("masterDataModel");
                    oMasterDataModel.setData(that.getView().getModel("employee").getProperty(`/searchItems/${oBindingIndex}`));
                    that.getView().getModel("masterDataModel").refresh();
                } else {
                    that.getView().setModel(new sap.ui.model.json.JSONModel(), "masterDataModel");
                    const oMasterDataModel = that.getView().getModel("masterDataModel");
                    oMasterDataModel.setData(that.getView().getModel("employee").getData());
                    that.getOwnerComponent().getModel("grpHierarchyForFilter").setProperty("/selectedGrpID",that.getView().getModel("employee").getData()?.TempEmployee?.SelectedGroup?.[0]?.GroupID)
                    that.getView().getModel("masterDataModel").refresh();

                }
                const groupTree = that.byId("grpFilterHierarchyTableId")			    
			    groupTree.collapseAll();
                oDialog.open();
                // that.byId("grpFilterHierarchyTableId").getBinding("items").refresh();

            });

        },
           /**
         * open busy indicator for activity type changes
         * @function _OpenBusyIndicator
         */
        _OpenBusyIndicator: function (oController, sBusyText) {
            if (!oController._oBusyDialog) {
                oController._oBusyDialog = new sap.m.BusyDialog({
                    text: sBusyText
                });
            } else {
                oController._oBusyDialog.setText(sBusyText);
            }
            oController._oBusyDialog.open();
        },
        /**
      * close busy indicator for activity type changes
      * @function _closeBusyIndicator
      */
        _closeBusyIndicator: function (oController) {
            if (oController?._oBusyDialog) {
                oController._oBusyDialog.close();
            }
        }



    };
});
