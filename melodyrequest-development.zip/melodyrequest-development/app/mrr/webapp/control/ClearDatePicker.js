sap.ui.define([
    "sap/m/DatePicker",
    "sap/ui/core/Icon",
    "sap/m/DatePickerRenderer"
], function (DatePicker, Icon, DatePickerRenderer) {
    "use strict";

   return DatePicker.extend("com.dealsupport.melodyrequest.control.ClearDatePicker", {


        metadata: {
            properties: {}
        },

        renderer: DatePickerRenderer, // Use original renderer

        onAfterRendering: function () {
            DatePicker.prototype.onAfterRendering.apply(this, arguments);

            const $root = this.$();
            const $input = $root.find("input");

            // add padding so text does not overlap icon
            $input.css("padding-right", "2rem");

            // Create clear icon if not already created
            if (!this._oClearIcon) {
                this._oClearIcon = new Icon({
                    src: "sap-icon://decline",
                    press: function () {
                        this.setValue("");
                        this.setDateValue(null);
                        this._updateIconVisibility();
                    }.bind(this)
                });

                this._oClearIcon.addStyleClass("myClearIcon myClearIconHidden");

                // Render Icon inside the DatePicker DOM after icon itself is rendered
                this._oClearIcon.addEventDelegate({
                    onAfterRendering: function () {
                        // append to root ONLY the icon's HTML, not create new control instance
                        $root.append(this._oClearIcon.getDomRef());
                    }.bind(this)
                });

                // trigger UI5 lifecycle for Icon (required!)
                this._oClearIcon.placeAt(this);
            }

            // update icon visibility based on value
            this._updateIconVisibility();
        },

        /** Show/hide clear icon depending on value */
        _updateIconVisibility: function () {
            if (!this._oClearIcon) return;

            const hasValue = !!this.getValue();
            this._oClearIcon.toggleStyleClass("myClearIconHidden", !hasValue);
        },

        /** Override value setters */
        setValue: function (v) {
            const r = DatePicker.prototype.setValue.apply(this, arguments);
            this._updateIconVisibility();
            return r;
        },

        setDateValue: function (v) {
            const r = DatePicker.prototype.setDateValue.apply(this, arguments);
            this._updateIconVisibility();
            return r;
        }
    });
});
