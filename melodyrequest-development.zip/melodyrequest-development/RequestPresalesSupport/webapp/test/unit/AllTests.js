sap.ui.define([
	"com/sap/bpm/RequestPresalesSupport/test/unit/controller/App.controller"
], function () {
	"use strict";
});
