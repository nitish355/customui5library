sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function (JSONModel, Device,MessageBox,MessageToast) {
	"use strict";

	return {

		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		getAppConstants: function (fnSuccess, self) {
			const sFormattedUrl = self.getManifestEntry("/sap.app/id").replaceAll(".", "/");
			const componentPath = sap.ui.require.toUrl(sFormattedUrl);
			const sFinalUrl = componentPath + "/resources";
			jQuery.ajax({
				async: false,
				contentType: "application/json",
				url: `${sFinalUrl}/req-area-api-/Parameter`,
				type: "GET",
				success: function (oData) {
					return fnSuccess(oData, self);

				}.bind(this),
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide();
					if (oError.responseText) {
						MessageBox.warning(oError.responseText, {
						});
					}
				}
			});

		},
		_getRuntimeBaseURL: function (self, isComponentScope) {
			var componentName =
				isComponentScope ? self.getManifestEntry("/sap.app/id").replaceAll(".", "/")
					: self.getOwnerComponent().getManifestEntry("/sap.app/id").replaceAll(".", "/");
			var componentPath = sap.ui.require.toUrl(componentName);
			return componentPath;
		},
		     //Save Draft
			 postSaveDraftFormDetails: function (appView,oPayload,sServiceEndPoint,sMethod) {
				const sBaseUrl = this._getWfServiceRuntimeBaseURL(appView);
				const sGetTokenUrl = (sServiceEndPoint === "DF_WFIns_Parent") ? "DF_WFIns_Parent":"DF_WFIns";
				const that = this;
				$.ajax({
					url: `${sBaseUrl}/ore-api-/${sGetTokenUrl}`,
					async: true,
					method:"GET",
					headers: {
						"X-CSRF-Token": "Fetch"
					},
					success: function (result, xhr, data) {
						var token = data.getResponseHeader("X-CSRF-Token");
						$.ajax({
							url: `${sBaseUrl}/ore-api-/${sServiceEndPoint}`,
							method: sMethod,
							async: true,
							data: JSON.stringify(oPayload),
							headers: {
								"X-CSRF-Token": token,
								"Content-Type": "application/json"
							},
							success: function (result, xhr, data) {
								if(sServiceEndPoint !== "DF_WFIns_Parent"){
									appView.getView().setBusy(false);
									const sI18nText = appView.getOwnerComponent().getModel("i18n").getResourceBundle().getText("draftSuccess");
									MessageToast.show(sI18nText);
								}
							}.bind(this),
							error: function (oError) {
								appView.getView().setBusy(false);
								if (oError.responseText && sServiceEndPoint !== "DF_WFIns_Parent") {
									MessageBox.warning(oError.responseText, {
									});
								}
							}
						});
					}.bind(this),
					error: function (oError) {
						if (oError.responseText) {
							MessageBox.warning(oError.responseText, {
							});
						}
					}
				});
			},
			   //delete Draft
			deleteSaveDraftFormDetails: function (appView, sServiceEndPoint, sMethod) {
				const sBaseUrl = this._getWfServiceRuntimeBaseURL(appView);
				$.ajax({
					url: `${sBaseUrl}/ore-api-/${sServiceEndPoint}`,
					method: "GET",
					async: true,
					headers: {
						"X-CSRF-Token": "Fetch"
					},
					success: function (result, xhr, data) {
						var token = data.getResponseHeader("X-CSRF-Token");
						$.ajax({
							url: `${sBaseUrl}/ore-api-/${sServiceEndPoint}`,
							method: sMethod,
							async: true,
							headers: {
								"X-CSRF-Token": token,
								"Content-Type": "application/json"
							},
							success: function (result, xhr, data) {
								// MessageToast.show("Draft saves successfully");
							}.bind(this),
							error: function (oError) {
								if (oError.responseText) {
									MessageBox.warning(oError.responseText, {
									});
								}
							}
						});
					}.bind(this),
					error: function (oError) {
						if (oError.responseText) {
							MessageBox.warning(oError.responseText, {
							});
						}
					}
				});
			},
			_getWfServiceRuntimeBaseURL: function (self, isComponentScope) {
                return this._getRuntimeBaseURL(self, isComponentScope) + "/resources";
            },
			//get draft details
            getSaveDraftFormDetails: function (instanceId, fnSuccess, self, isSaveDraft) {
                const sBaseUrl = this._getWfServiceRuntimeBaseURL(self);
                $.ajax({
                    url: `${sBaseUrl}/ore-api-/YC_dFWfins_Details?$filter=parentInstance_GUID eq '${instanceId}'`,
                    method: "GET",
                    async: false,
                    headers: {
                        "X-CSRF-Token": "Fetch"
                    },
                    success: function (result, xhr, data) {
                        $.ajax({
                            url: `${sBaseUrl}/ore-api-/DF_ReqForm_URL?$filter=WFIns_parentInstance_GUID eq '${instanceId}'`,
                            method: "GET",
                            async: false,
                            headers: {
                                "X-CSRF-Token": "Fetch"
                            },
                            success: function (urlResponse, xhr, data) {
                                 return fnSuccess(result,self,isSaveDraft,urlResponse);

                            }.bind(this),
                            error: function (oError) {
                                if (oError.responseText) {
									MessageBox.warning(oError.responseText, {
									});
								}
                            }
                        });

                    }.bind(this),
                    error: function (oError) {
						if (oError.responseText) {
							MessageBox.warning(oError.responseText, {
							});
						}
                    }
                });
            }
        }
    });