sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/m/UploadCollectionParameter",
	"sap/ui/core/format/DateFormat",
	"sap/ui/core/library",
	"sap/ui/core/Fragment",
	"com/sap/bpm/RequestPresalesSupport/model/models",
	'sap/m/library',
], function (BaseController, JSONModel, MessageBox, MessageToast, UploadCollectionParameter, DateFormat, CoreLibrary, Fragment, models,mLibrary) {
	"use strict";

	var workflowInstanceId,
		token,
		ValueState = CoreLibrary.ValueState;

	return BaseController.extend("com.sap.bpm.RequestPresalesSupport.controller.App", {

			onAfterRendering: function(){
					var that = this;
					setTimeout(function(that) {
						// const oDetailView = that.getComponentData().inboxHandle.inboxDetailView;
						// const aFooterBtns = oDetailView.getView().getContent()[0].getFooter().getContentRight();
						// const aClaimBtn = aFooterBtns.filter((btn) => btn.getText() === "Claim");
						// let oAppConstantsModel = that.getOwnerComponent().getModel("appConstants");
						// let sDownTimeFlag = oAppConstantsModel.getProperty("/DownTime/0/Operational_Status");
						// if (sDownTimeFlag) {
						// 	oDetailView.getView().getContent()[0].setFooter(false);
						// }
						// if (aClaimBtn.length) {
						// 	aClaimBtn[0].setVisible(false);
						// }
						// oDetailView.getView().byId("myInbox_SHARE").setVisible(false);
						that._hideMyInboxFooterBtns(that)
						// oDetailView.getView().byId("LogButtonID").setVisible(false);
					}, 1000, this);
			},

			onInit: function () {
			this.unSavedData = [];
            this.getContentDensityClass();
			let oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
			let sDownTimeFlag = oAppConstantsModel.getProperty("/DownTime/0/Operational_Status");
		if (!sDownTimeFlag) {
            var oMdlCommon = this.getParentModel("mCommon");
            this.setModel(oMdlCommon, "mCommon");
			var oModelData = this.getModel("multiReqModel").getData();
			//add OrgId,OrgType,RequestType for older tasks
			if (typeof (oModelData["SalesOrgID"]) === "string") {
				oModelData["OrgID"] = oModelData["SalesOrgID"];
				oModelData["OrgType"] = "SORG";
				oModelData["RequestType"] = "Opportunity"
			}
            var oMultiReqModel = {
			};

			//restructuring the response
			if (oModelData.aReqAreas && oModelData.aReqAreas.length) {
				var aFormattedContext = [];
				for (var i = 0; i < oModelData.aReqAreas.length; i++) {
					var oContextNew = Object.assign(oModelData.aReqAreas[i],oModelData);
					delete oContextNew.aReqAreas;
					aFormattedContext.push(oContextNew);
				}
				oMultiReqModel["subcontext"] = aFormattedContext;
			} else {
				oMultiReqModel["subcontext"] = [oModelData];
			}

            this.getModel("multiReqModel").setData(oMultiReqModel);
			var that = this;
			if (!this.getModel("multiReqModel").getData().subcontext[0].isResourceProfile) {
				this.getModel("multiReqModel").getData().subcontext[0].legacyApprovers = []
				if (!this.getModel("multiReqModel").getData().subcontext[0].isRework) {

					for (let i = 0; i < this.getModel("multiReqModel").getData().subcontext.length; i++) {
						this.getModel("multiReqModel").getData().subcontext[i].legacyApprovers = []
						const sGUID = this.getModel("multiReqModel").getData().subcontext[i].GUID;
						let sUrl = `/ReadResources?$filter=GUID eq (${sGUID})`;
						let sMode = i;
						that.getAdminViewDetail(that.fnSuccessAppCallback, that.fnErrorAppCallback, that, sUrl, sMode);

					}
				} else {
					const sGUID = this.getModel("multiReqModel").getData().subcontext[0].GUID;
					let sUrl = `/ReadResources?$filter=GUID eq (${sGUID})`;
					let sMode = 0;
					this.getAdminViewDetail(that.fnSuccessAppCallback, that.fnErrorAppCallback, that, sUrl, sMode);
				}
			}

			let sOrgID ;
			this.sOrgID = this.getModel("multiReqModel").getData().subcontext[0].OrgID;
			if(this.getModel("multiReqModel").getData().subcontext[0].OrgType === 'SORG'){
				this.sOrgID = Number(this.sOrgID.replace('SORG-', '')).toString();
			}
			var isComponentScope = false;
			this.getMRRLanugaueData(this.fnLangSuccess, this, isComponentScope, this.sOrgID);

            // document service interaction
            this.oAttachmentsModel = new JSONModel();
            this.setModel(this.oAttachmentsModel, "attachmentsModel");
            this._fetchFormConfigData(this);

            /*fetch and set dropdown values*/
            this._fetchFormValues(this);
            this._fetchFormActions(this);
         
            

            this.configureView();

            

            workflowInstanceId = this.getParentModel("taskInstanceModel").getProperty("/workflowInstanceId");

            /* Start of Code for CurrentTask Instance ID Update  */
                this.updateCurrentInstance();
            /* End of Code for CurrentTask Instance ID Update  */

            var oMrqModelData = this.getView().getModel("multiReqModel").getData().subcontext;
			//this.checkIfFolderExists("WorkflowManagement");
			//this.loadAttachments(oMrqModelData[0]);
            var that = this;
            var oMdlCommon = this.getModel("mCommon");

			for (var i = 0; i < oMrqModelData.length; i++) {
				//athis._createWorkFlowFileUploadId(oMrqModelData[i]);
				oMrqModelData[i].namesOfPartiesVisible = false;
				oMrqModelData[i].isParticipantTypeSelected = false;
				if (oMrqModelData[i].requestArea && oMrqModelData[i].isResourceProfile) {
					var aReqAreaSplit = oMrqModelData[i].requestArea.split("-");
					if (aReqAreaSplit[aReqAreaSplit.length - 1] == "RISE") {
						oMrqModelData[i].isRISE = true;
					} else {
						oMrqModelData[i].isRISE = false;
					}
				} else {
					oMrqModelData[i].isRISE = false;
				}
				that.onSwitchStateChange();
				if (oMrqModelData[i].requestAreaPath && oMrqModelData[i].isResourceProfile) {
					var aReqAreaPathSplit = oMrqModelData[i].requestAreaPath.split("-");
					if (aReqAreaPathSplit[0] == "Solution Large Enterprise" || aReqAreaPathSplit[0] == "Midmarket") {
						oMrqModelData[i].isSolutionRelated = true;
					} else {
						oMrqModelData[i].isSolutionRelated = false;
					}
				} else {
					oMrqModelData[i].isSolutionRelated = false;
				}

				if (oMdlCommon.getProperty("/DefaultMeetingType")) {
                    var sDefMTKey = oMdlCommon.getProperty("/DefaultMeetingType")[0];
                    var aMeetingTypes = oMdlCommon.getProperty("/MeetingTypes");
                    for (var j = 0; j < aMeetingTypes.length; j++) {
                        if (this.getMessage(aMeetingTypes[j].key) === sDefMTKey) {
                            oMrqModelData[i].meetingType = this.getMessage(aMeetingTypes[j].text);
                            let meetTypes = this.getView().getModel("formValConfigModel").getData().idmeet_type;
                            let matchingType = meetTypes.find(type => type.Value === oMrqModelData[i].meetingType);
                            if (matchingType) {
                                oMrqModelData[i].meetingTypeKey = matchingType.ID;
                            }
                        }
                    }
                }
				if (this.getView().getModel("formValConfigModel").getProperty("/idmeet_type")) {
					let sDefaultMeetingType = this.formatFormMultiDefaultSelect(this.getView().getModel("formValConfigModel").getProperty(
						"/idmeet_type"));
					oMrqModelData[i].meetingTypeKey = sDefaultMeetingType;
					let meetingTypes = this.getView().getModel("formValConfigModel").getData().idmeet_type;
					let matchingMeetingType = meetingTypes.find(meetType => meetType.ID ===  sDefaultMeetingType);
					if (matchingMeetingType) {
						oMrqModelData[i].meetingType = matchingMeetingType.Value;
					}
				}
 
				this.getView().getModel("formValConfigModel").setProperty("/idlang" , that.getView().getModel("mrrLanguageConfigModel").getData());
				 if (this.getModel("formValConfigModel").getProperty("/idlang")) {
                    var sDefaultLanguageType = this.formatFormMultiDefaultSelect(this.getView().getModel("mrrLanguageConfigModel").getData());
                    oMrqModelData[i].languageKey = sDefaultLanguageType[0];
                        let langTypes = this.getView().getModel("mrrLanguageConfigModel").getData();
                    let matchingLang = langTypes.find(lang => lang.ID === oMrqModelData[i].languageKey);
                    if (matchingLang) {
                        oMrqModelData[i].language = matchingLang.Value;
                    }
                }
 
				if (this.getModel("formValConfigModel").getProperty("/idsupp_type")) {
					var sDefaultSupportType = this.formatFormMultiDefaultSelect(this.getModel("formValConfigModel").getProperty("/idsupp_type"));
					oMrqModelData[i].supportType = sDefaultSupportType[0];
				}
				if (i !== 0) {
					oMrqModelData[i].copyContentCheckBox = true;
					oMrqModelData[i].selected = false;
					if(oMrqModelData[i].isResourceProfile){
						oMrqModelData[i].copyContentLabel = "Copy content from " + oMrqModelData[i - 1].searchFieldsText + " - Request";
					}else{
						oMrqModelData[i].copyContentLabel = "Copy content from " + oMrqModelData[i - 1].requestArea + " - Request";
					}
				} else {
					oMrqModelData[i].copyContentCheckBox = false;
					oMrqModelData[i].selected = false;
				}
				if (oMrqModelData[i].isRework) {
					that._setPrevioslySelectedValues(oMrqModelData[i],oMrqModelData[i].requestDetails);
					oMrqModelData[i].attachmentUrls = oMrqModelData[i].attachmentUrls ? oMrqModelData[i].attachmentUrls : [];
					if (!oMrqModelData[i].attachmentUrls.length) {
						that.onAddNewUrl(false, i);
					}
				} else {
					oMrqModelData[i].isMeetingPlanned = false;
				}

            }
            this.getView().getModel("multiReqModel").refresh(true);

            // set min date for calendar
            this.byId("meetingDateInputMrq").setMinDate(new Date());
			this._setDefaultFormValue();
			// check if 'WorkflowManagement' folder exists
            // this.checkIfFolderExists("WorkflowManagement");
			// this.loadAttachments(oMrqModelData[0]);
			if(this.getView().getModel("multiReqModel").getData().subcontext[0].isResourceProfile){
				this.getResProfileDetails(0);
			}
			//get draft details
			const sInstanceId =  this.getView().getModel("taskInstanceModel").getProperty("/workflowInstanceId");
			models.getSaveDraftFormDetails(sInstanceId,this.fnSuccessCallbackGetDraft,this)
				
				//initialize attachment urls
				if (!oMrqModelData[0].isRework) {
					this._initializeUrls(0);
				}
			 //pre select draft tab
			 if (this.getView().getModel("multiReqModel").getData().subcontext.length > 1 && this.getView().getModel("draftTable").getData().length) {
				 let aTabIdSort = this.getView().getModel("draftTable").getData().sort((a, b) =>
					 a.tabID.localeCompare(b.tabID));
				 let oNavContainer = this.getView().byId("idNavContainerMrq");
				 let currentPageId = oNavContainer._pageStack[0].id;
				 let tabId = Number(aTabIdSort[aTabIdSort.length - 1].tabID);
				 let iPageTabId;
				 let iCurrenrPagTabId;
				 if (this.getView().getModel("multiReqModel").getData().subcontext.length === tabId) {
					 iPageTabId = tabId - 1;
					 iCurrenrPagTabId = tabId - 2;
				 } else {
					 iPageTabId = tabId;
					 iCurrenrPagTabId = tabId - 1;
				 }
				 
				 let sNextPageId = currentPageId.replace(/\idNavContainerMrq[^\s]*/g, "") + "idNavContainerMrq-" + (iPageTabId).toString();
				 let aPageStack = [{
					 data: {},
					 id: currentPageId.replace(/\idNavContainerMrq[^\s]*/g, "") + "idNavContainerMrq-" + (iCurrenrPagTabId).toString(),
					 transition:
						 "slide"
				 }];
				 oNavContainer._pageStack = aPageStack
				 this.navtoReqArea(sNextPageId, "next");
				 
			 }
			 if (that.getModel("multiReqModel").getProperty("/subcontext/0/approvalHistory")) {
				that.getModel("multiReqModel").getProperty("/subcontext/0/approvalHistory").reverse();
			}
			that.getModel("multiReqModel").refresh();
		}else{
			this.getOwnerComponent().getRouter().navTo(
				"NotFound"
			);
		}
        },
		getMRRLanugaueData: function (fnSuccess, self, isComponentScope, sOrgID) {
			const sBaseurl = this._getRuntimeBaseURL(self, isComponentScope);
			$.ajax({
				async: false,
				contentType: "application/json",
				url: `${sBaseurl}/resources/req-area-api-/MR_Language?$filter=orgID eq '${sOrgID}'`,
				type: "GET",
				success: function (oData) {
					return fnSuccess(oData, self);

				}.bind(this),
				error: function (oError) {
				}
			});
		},
		fnLangSuccess: function(oResponse, self){
			let sValues = oResponse.value;
			let oModel = new sap.ui.model.json.JSONModel();
			oModel.setData(sValues);
			self.getOwnerComponent().setModel(oModel, "mrrLanguageConfigModel");
		},
		_hideMyInboxFooterBtns:function(that){
			const oDetailView = that.getComponentData().inboxHandle.inboxDetailView;
			const aFooterBtns = oDetailView.getView().getContent()[0].getFooter().getContentRight();
			const aClaimBtn = aFooterBtns.filter((btn) => btn.getText() === "Claim");
			let oAppConstantsModel = this.getOwnerComponent().getModel("appConstants");
			let sDownTimeFlag = oAppConstantsModel.getProperty("/DownTime/0/Operational_Status");
			if (sDownTimeFlag) {
				oDetailView.getView().getContent()[0].setFooter(false);
			}
			if(aClaimBtn.length){
				aClaimBtn[0].setVisible(false);
			}
			if(oDetailView.getView().byId("myInbox_SHARE") && oDetailView.getView().byId("LogButtonID")){
			oDetailView.getView().byId("myInbox_SHARE").setVisible(false);
			oDetailView.getView().byId("LogButtonID").setVisible(false);
			}
		},
		fnSuccessCallbackGetDraft: function (result, that,isSaveDraft,urlResponse) {
			let groupedUrls = [];
			if(urlResponse.value.length){
				const aUrlDraftData = urlResponse.value;
				 groupedUrls = Object.entries(
					// What you have done
					aUrlDraftData.reduce((urlData, { urlName,urlCountID, tabID, url,instanceDF_GUID,parentInstanceGUID }) => {
					  // Group initialization
					  if (!urlData[tabID]) {
						urlData[tabID] = [];
					  }
					  
					  // Grouping
					  // FIX: only pushing the object that contains urlName and url
					  urlData[tabID].push({ urlName,urlCountID, url,instanceDF_GUID,parentInstanceGUID });
				  
					  return urlData;
					}, {})
				  ).map(([tabID, attachmentUrls]) => ({ tabID, attachmentUrls }));
				if (!isSaveDraft) {
					groupedUrls.forEach(function (data) {
						const aSubContext = that.getView().getModel("multiReqModel").getData().subcontext;
						const iIndex = aSubContext[0].isRework ? 0 : Number(data.tabID) - 1
						aSubContext[iIndex].attachmentUrls = data.attachmentUrls;
					});
				}
			}
			if(result.value.length && !isSaveDraft){
				const aDraftData = result.value;
				aDraftData.forEach(function(data){
					const aSubContext = that.getView().getModel("multiReqModel").getData().subcontext;
					const iIndex = aSubContext[0].isRework ? 0: Number(data.tabID)-1
					aSubContext[iIndex].typeOfSupport = data.need_from_CustAdvisory ? data.need_from_CustAdvisory:"";
					aSubContext[iIndex].isMeetingPlanned = data.cust_asked_forMeeting ? true:false;
					aSubContext[iIndex].meetingTypeID = data.meetingTypeKey ? data.meetingTypeKey:"";
					aSubContext[iIndex].comments = data.comments ? data.comments:"";
					aSubContext[iIndex].solutionsInScope = data.solution_Models ? data.solution_Models:"";
					aSubContext[iIndex].preferredPresales = data.custAdvisory_Resource ? data.custAdvisory_Resource:"";
					aSubContext[iIndex].meetingGoal = data.Meeting_Goal ? data.Meeting_Goal:"";
					aSubContext[iIndex].meetingLocation = data.meetingLocation ? data.meetingLocation:"";
					aSubContext[iIndex].meetingDate = data.meetingDate ? data.meetingDate:"";
					aSubContext[iIndex].meetingTime = data.meetingDate ? data.meetingTime:"";
					aSubContext[iIndex].involvedPartiesNames = data.involved_SAP_Parties_Name ? data.involved_SAP_Parties_Name:"";
					aSubContext[iIndex].participantTypeDetails = data.Participants_Type_Details ? data.Participants_Type_Details:"";
					
					if(aSubContext[iIndex].isMeetingPlanned){
						aSubContext[iIndex].involvedPartiesKey = data.Involved_SAP_PartiesIDs ? data.Involved_SAP_PartiesIDs:"";
						aSubContext[iIndex].involvedPartiesKeys  = data.Involved_SAP_PartiesIDs? data.Involved_SAP_PartiesIDs.split(";").join().split(","): [];
						aSubContext[iIndex].involvedParties =  data.Involved_SAP_PartiesIDs ? that.getDropDownValues( data.Involved_SAP_PartiesIDs,"involvedParties"):"";
						aSubContext[iIndex].languageKey =  data.LanguageIDs ?  data.LanguageIDs : "";
						aSubContext[iIndex].language =  data.LanguageIDs ? that.getDropDownValues(data.LanguageIDs,"language"):"";
						aSubContext[iIndex].supportTypeKey = data.SupportTypeIDs ? data.SupportTypeIDs :"";
						aSubContext[iIndex].supportType =  data.SupportTypeIDs ? that.getDropDownValues(data.SupportTypeIDs,"supportType"):"";
						aSubContext[iIndex].participantTypeKey = data.ParticipantTypeIDs? data.ParticipantTypeIDs:"";
						aSubContext[iIndex].participantType =  data.ParticipantTypeIDs ? that.getDropDownValues(data.ParticipantTypeIDs,"participantType"):"";
						aSubContext[iIndex].meetingTypeKey =  data.meetingTypeID ? data.meetingTypeID:"";
						aSubContext[iIndex].meetingType =  data.meetingTypeID ? that.getDropDownValues(data.meetingTypeID,"meetingType"):"";
					}
				
				});
				that._setPrevioslySelectedValues(that.getView().getModel("multiReqModel").getData().subcontext[0],that.getView().getModel("multiReqModel").getData().subcontext[0]);

			}
			const oModel = new sap.ui.model.json.JSONModel();
			oModel.setData(result.value);
			that.getView().setModel(oModel, "draftTable");
			that.getView().getModel("multiReqModel").refresh();
			//set drafturl
			const oUrlModel = new sap.ui.model.json.JSONModel();
			oUrlModel.setData(groupedUrls);
			that.getView().setModel(oUrlModel, "draftUrlTable");
			sap.ui.core.BusyIndicator.hide();
		},
		getDropDownValues:function(values,fieldName){
			const oFormModelData = this.getView().getModel("formValConfigModel").getData();
			const aSupportTypes = oFormModelData["idsupp_type"],
			aMeetingTypes = oFormModelData["idmeet_type"],
			aLanguages = oFormModelData["idlang"],
			aParticipantTypes = oFormModelData["idparticpnt_type"],
			aInvolvedParties = oFormModelData["idsap_parties"],
			aSupportTypesRISE = oFormModelData["idrise_dealphase"];

			if (fieldName === "involvedParties") {
				const aInvolvedPartiesKey = values.split(";");
				const aInvolvedPartiesDesc = [];
				aInvolvedPartiesKey.forEach(function (key) {
					const sDesc = aInvolvedParties.filter((item) => item.ID === key.trim())[0].Value;
					aInvolvedPartiesDesc.push(sDesc);
				})
				return aInvolvedPartiesDesc.join("; ")
			}
			if (fieldName === "language") {
				const aLanguageKey = values.split(";");
				const aLanguagesDesc = [];
				aLanguageKey.forEach(function (key) {
					const sDesc = aLanguages.filter((item) => item.ID === key.trim())[0].Value;
					aLanguagesDesc.push(sDesc);
				})
				return aLanguagesDesc.join("; ")
			}
			if (fieldName === "supportType") {
				const aSupportTypeKey = values.split(";");
				const aSupportTypeDesc = [];
				aSupportTypeKey.forEach(function (key) {
					const sDesc = aSupportTypes.filter((item) => item.ID === key.trim())[0].Value;
					aSupportTypeDesc.push(sDesc);
				})
				return aSupportTypeDesc.join("; ")
			}
			if (fieldName === "participantType") {
				const aParticipantTypeKey = values.split(";");
				const aParticipantTypeDesc = [];
				aParticipantTypeKey.forEach(function (key) {
					const sDesc = aParticipantTypes.filter((item) => item.ID === key.trim())[0].Value;
					aParticipantTypeDesc.push(sDesc);
				})
				return aParticipantTypeDesc.join("; ")
			}
			if (fieldName === "meetingType") {
				const aMeetingTypeKey = values.split(";");
				const aMeetingTypeDesc = [];
				aMeetingTypeKey.forEach(function (key) {
					const sDesc = aMeetingTypes.filter((item) => item.ID === key.trim())[0].Value;
					aMeetingTypeDesc.push(sDesc);
				})
				return aMeetingTypeDesc.join("; ")
			}
		},
		getAdminViewDetail: function (fnSuccess, fnError, self, sUrl, sMode) {
			var workflowBaseurl = this._getAdminWfServiceRuntimeBaseURL(self);
			jQuery.ajax({
				async: false,
				contentType: "application/json",
				url: `${workflowBaseurl}${sUrl}`,
				type: "GET",
				success: function (oData) {
					return fnSuccess(oData, self, sMode);

				}.bind(this),
				error: function (oError) {
					// ErrorHandle.setErrorMessage(oError, self);
				}
			});

		},
		_getAdminWfServiceRuntimeBaseURL: function (self, isComponentScope) {
			return this._getRuntimeBaseURL(self, isComponentScope) + "/adminresources/resources";
		},
		fnSuccessAppCallback: function (oData, self, sMode) {
			self.getModel("multiReqModel").getData().subcontext[sMode].legacyApprovers[0] = oData.value[0].Approvers;

		},
		onClickApproversList: function (oEvent) {
			this.oevt = oEvent.getSource();
			const that = this;
			if (!this.getView().getModel("multiReqModel").getData().subcontext[0].isResourceProfile) {
				// let oevt = oEvent.getSource();
				this.onRequesterContactIcon(this.oevt, this);
			} else {
				let oContextObj = oEvent.getSource().getBindingContext("multiReqModel").getObject().aResourceProfileApprovers.ApproverDetails
				//sort user list
				oContextObj.sort((a, b) => {
					const empNameA = a["fullName"].toUpperCase(); // ignore upper and lowercase
					const empNameB = b["fullName"].toUpperCase(); // ignore upper and lowercase
					if (empNameA < empNameB) {
						return -1;
					}
					if (empNameA > empNameB) {
						return 1;
					}

					// names must be equal
					return 0;
				})

				let empDataApp = new JSONModel(oContextObj);
				this.getView().setModel(empDataApp, "EmpListDetails");
				let oView = this.getView();
				if (!this._pApproversPopover) {
					Fragment.load({
						id: oView.getId(),
						name: "com.sap.bpm.RequestPresalesSupport.fragments.ApproversSubmitPageList",
						controller: this
					}).then(function (oPopover) {
						oView.addDependent(oPopover);
						this._pApproversPopover = oPopover;
						oPopover.openBy(that.oevt);
					}.bind(this));
				} else {
					this._pApproversPopover.openBy(this.oevt);
				}
			}

		},
		onHandleokPress: function () {
			if(!this.getView().getModel("multiReqModel").getData().subcontext[0].isResourceProfile && this.contactFragmentsList){
				this.contactFragmentsList.close();
			}else if(this._pApproversPopover) {
				this._pApproversPopover.close();
			}
		},
		onRequesterContactIcon: function (oEvent, self) {
			sap.ui.core.BusyIndicator.show(0);

			let sName = "Approvers";
			let subcontext = self.getView().getModel("multiReqModel").getData().subcontext;
			let selectedReqArea = self.getView().byId("iconTabHeader").getSelectedKey();
			function findIndexWithRequestArea(array) {
				return array.findIndex(obj => obj.requestArea === selectedReqArea);
			}

			let index = findIndexWithRequestArea(subcontext);
			let sRequester = self.getView().getModel("multiReqModel").getData().subcontext[index].legacyApprovers[0];
			let oValType = "ID";
			this.callEmpApi(sRequester, oEvent, self, sName, oValType);

		},
		QuickViewCard: function (oModel, oevt, self, sName) {
			let oButton = oevt.getSource();
			self.getView().setModel(oModel, "EmpDetails");
			let EmployeeDetails = self.getView().getModel("EmpDetails");
			this._contactslistFragment(EmployeeDetails, oevt, self, sName).openBy(oButton);
			sap.ui.core.BusyIndicator.hide();
		},
		currentAvatarDisplay: function (userId) {
			return this.getOwnerComponent().getModel("appConstants").getProperty("/userImg/0/Value") + userId;
		},
		onPressEmpEmail: function (oEvent) {
			const sUrl = oEvent.getSource().getProperty("text");
			URLHelper.triggerEmail(sUrl, "Info Request - MRR", false, false, false, true);
		},
		callEmpApi: function (userId, oevt, self, sName, oValType,isListView) {
			var sQuery = "/Employees?$count=true&$filter=";
			var arr;
			if (sName !== "Recipients") {
			    arr = oValType === "ID" ? userId.split(";") : userId.split(",");
			}else{
				arr = userId;
			}
			var array = [];
			var sArr = [];
			var sArrLen = arr.length;
			for (var i = 0; i < arr.length; i++) {
				var searchUserId = arr[i];
				if (oValType === "ID") {
					var sQueryApi = `${sQuery}(ID eq '${searchUserId}')`
					this.funcApi(searchUserId, sQueryApi, this.empData, oevt, self, array, sArrLen, sArr, sName,isListView);
				} else if (oValType === "Email") {
					var sQueryApi = `${sQuery}(email eq '${searchUserId}')`
					this.funcApi(searchUserId, sQueryApi, this.empData, oevt, self, array, sArrLen, sArr, sName,isListView);
				}
			}
		},
		funcApi: function (searchUserId, sQueryApi, empData, oevt, self, array, sArrLen, sArr, sName,isListView) {
			var workflowBaseurl = self._getWfServiceRuntimeBaseURL(self);
			jQuery.ajax({
				contentType: "application/json",
				url: `${workflowBaseurl}${sQueryApi}`,
				type: "GET",
				success: function (oData) {
					var value = oData.value[0];
					return empData(value, oevt, self, array, sArrLen, sArr, sName,isListView);

				}.bind(this),
				error: function (oError) {
					// return funcerror(oError, self);
				}
			});
		},
		_getWfServiceRuntimeBaseURL: function (self) {
			return this._getRuntimeBaseURL(self) + "/sapit-employee-data";
		},
		empData: function (value, oevt, self, array, sArrLen, sArr, sName,isListView) {
			var arr = value;
			sArr.push(arr);
			if(value !== undefined){
				array.push(arr)
			}
			var oModel = new sap.ui.model.json.JSONModel();
			if (sArr.length == sArrLen) {
				// for(var i=0 ; i< array.length ; i++){
				// 	function capitalizeFirstLetter(sName) {
                //      return sName.toLowerCase().split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
                // }
            
                // let formattedFirstName = capitalizeFirstLetter(array[i].firstName);
                // let formattedLastName = capitalizeFirstLetter(array[i].lastName);
                //     array[i].firstName = formattedFirstName;
				// 	array[i].lastName = formattedLastName;
				// }
				oModel.setData(array);
				//    self.getView().setModel(oModel, "EmployeeDetails");
				// var oButton = oevt.getSource();
        self.getView().setModel(oModel, "EmpDetails");
        var EmployeeDetails = self.getView().getModel("EmpDetails");
        self._contactslistFragment(EmployeeDetails, oevt, self, sName).openBy(oevt);
        sap.ui.core.BusyIndicator.hide();

			}

		},
		funcerror: function (oError, self) {
			MessageBox.error(oError.responseText, {
				contentWidth: "600px"
			});
			sap.ui.core.BusyIndicator.hide();
		},
		_contactslistFragment: function (EmployeeDetails, oevt, self, sName) {
			if (!this.contactFragmentsList) {
				this.contactFragmentsList = sap.ui.xmlfragment("com.sap.bpm.RequestPresalesSupport.fragments.EmployeesDetail", this);
				self.getView().addDependent(this.contactFragmentsList);
			}
			
			var aModel = new sap.ui.model.json.JSONModel(EmployeeDetails);
			self.contactFragmentsList.setModel(aModel);
			self.contactFragmentsList.setProperty("title", sName);
			return self.contactFragmentsList;
		},
		// onHandleokPress: function () {
		// 	// this.EmpDetailsFrag.close();
		// 	this._contactslistFragment().close();
		// },
		_createWorkFlowFileUploadId: function (oModelData) {
		//generating unique id for fileUploader
			var workflowInstanceId = this.getParentModel("taskInstanceModel").getProperty("/workflowInstanceId");
			var aSubContext = this.getView().getModel("multiReqModel").getData().subcontext;

			if (aSubContext.length > 1) {
				var aReqArea = oModelData.requestArea;
				var sFormattedId = aReqArea.replace(/[\s~`!@#$%^&*()_+\-={[}\]|\\:;"'<,>.?/]+/g, '-').toLowerCase();
				oModelData.workflowFileUploadId = workflowInstanceId + sFormattedId;
			} else if (oModelData.workflowFileUploadId) {
				oModelData.workflowFileUploadId = oModelData.workflowFileUploadId;
			} else {
				oModelData.workflowFileUploadId = workflowInstanceId;
			}
			this.getView().getModel("multiReqModel").refresh(true);
			if(this.getView().getModel("multiReqModel").getData().subcontext[0].isResourceProfile){
				this.getResProfileDetails();
			}
		},
		_fetchFormActions: function (self) {
			const sOrgID = 'ParentOrgID' in self.getModel("multiReqModel").getData().subcontext[0] ? self.getModel("multiReqModel").getData().subcontext[0].ParentOrgID : self.getModel("multiReqModel").getData().subcontext[0].OrgID;
			var sOrgType = self.getModel("multiReqModel").getData().subcontext[0].OrgType;
			var sUsertask = "Requester";
			var sFormatOrgID = self._getOrgIDnumber(sOrgID,sOrgType);
			var sUrl = self._getRuntimeBaseURL() +
				`/resources/req-area-api-/Action?$filter=(orgID eq '${sFormatOrgID}' and orgType eq '${sOrgType}') and (UserTask eq '${sUsertask}')`;

			$.ajax({
				contentType: "application/json",
				url: sUrl,
				async: false,
				type: "GET",
				success: function (oData) {
					var aFormActionsValues = oData.value;
					var oFormValue = aFormActionsValues.reduce(function (formVal, val) {
						(formVal[val.Action_ID] = formVal[val.Action_ID] || []).push(val);
						return formVal;
					}, {})
					var oFormActionsConfigModel = new JSONModel(oFormValue);
					self.getView().setModel(oFormActionsConfigModel, "formActionsConfigModel");

				},
				error: function (oError) {

				}
			});	
			
		},
		_fetchFormValues: function (self) {
			const sOrgID = 'ParentOrgID' in self.getModel("multiReqModel").getData().subcontext[0] ? self.getModel("multiReqModel").getData().subcontext[0].ParentOrgID : self.getModel("multiReqModel").getData().subcontext[0].OrgID;
			var sOrgType = self.getModel("multiReqModel").getData().subcontext[0].OrgType;
			var sFormatOrgID = self._getOrgIDnumber(sOrgID,sOrgType);
			var sUrl = self._getRuntimeBaseURL() + `/resources/req-area-api-/Form_values?$filter=(orgID eq '${sFormatOrgID}' and orgType eq '${sOrgType}')`;
			$.ajax({
				contentType: "application/json",
				url: sUrl,
				async: false,
				type: "GET",
				success: function (oData) {
					var aFormValues = oData.value;
					var oFormValue = aFormValues.reduce(function (formVal, val) {
						(formVal[val.Field_ID] = formVal[val.Field_ID] || []).push(val);
						return formVal;
					}, {})
					var oFormValConfigModel = new JSONModel(oFormValue);
					self.getView().setModel(oFormValConfigModel, "formValConfigModel");
				},
				error: function (oError) {

				}
			});

		},
		formatFormMultiDefaultSelect: function (formVal) {
			if (formVal) {
				var aSelectedKeys = [];
				for (var i = 0; i < formVal.length; i++) {
					if (formVal[i].Default_Flag === "X") {
						aSelectedKeys.push(formVal[i].ID);
						if (formVal[i].Field_ID === "idmeet_type") {
							aSelectedKeys = formVal[i].ID;
						}
					}
				}
				return aSelectedKeys;
			}

		},
		//start code of form config
		//set form configurable model
		_getOrgIDnumber: function (sOrgID, sOrgType) {
			if(sOrgType === "SORG"){
				return Number(sOrgID.replace('SORG-', '')).toString();
			}else{
				return sOrgID;
			}

		},
		_fetchFormConfigData: function (self) {
			const sOrgID = 'ParentOrgID' in self.getModel("multiReqModel").getData().subcontext[0] ? self.getModel("multiReqModel").getData().subcontext[0].ParentOrgID : self.getModel("multiReqModel").getData().subcontext[0].OrgID;
			var sOrgType = self.getModel("multiReqModel").getData().subcontext[0].OrgType;
			var sFormatOrgID = self._getOrgIDnumber(sOrgID,sOrgType);
			var sUrl = self._getRuntimeBaseURL() +
				`/resources/req-area-api-/Form_Tab?$expand=Fields&&$filter=orgID eq '${sFormatOrgID}' and orgType eq '${sOrgType}'`;
				$.ajax({
				contentType: "application/json",
				url: sUrl,
				async: false,
				type: "GET",
				success: function (oData) {
					var aDataNew = [];

					for (var i = 0; i < oData.value.length; i++) {
						if (!aDataNew[oData.value[i].ID]) {
							aDataNew[oData.value[i].ID] = [];
						}
						aDataNew[oData.value[i].ID] = oData.value[i];
						var aDataNewFields = [];
						for (var j = 0; j < oData.value[i].Fields.length; j++) {

							if (!aDataNew[oData.value[i].Fields[j].ID]) {
								aDataNewFields[oData.value[i].Fields[j].ID] = [];
							}
							aDataNewFields[oData.value[i].Fields[j].ID] = oData.value[i].Fields[j];
						}
						aDataNew[oData.value[i].ID].Fields = aDataNewFields;
					}
					var oFormConfigModel = new JSONModel(aDataNew);
					self.getView().setModel(oFormConfigModel, "formConfigModel");

					var oMrqModelData = self.getModel("multiReqModel").getData().subcontext;
					var oReqAreaLabel = self.getView().getModel("formConfigModel").getProperty("/idrequestdetails/Fields/idreqarea/Label");
					if(oMrqModelData.length !== 1){
						for(var i=0;i<oMrqModelData.length;i++){
							oMrqModelData[i].reqAreaLabel = oReqAreaLabel +" #"+[i+1];
						}
					}else{
						oMrqModelData[0].reqAreaLabel = oReqAreaLabel;
					}
					self.getModel("multiReqModel").refresh(true);
				},
				error: function (oError) {

				}
			});
		},
		formatFormConfigVisibility: function (sVal) {
			if (sVal === "X") {
				return true;
			} else {
				return false;
			}
		},
		formatFormConfigReqAreaVisibility:function(sVal , isResourceProfile){
			return sVal === "X" && !(isResourceProfile);
		},
				formatFieldForNonRise: function (isRise, formVisibility) {
			if (formVisibility === "X") {
				var isRiseVisibility = !isRise;
				return isRiseVisibility;
			} else {
				return false;
			}
		},
		formatFieldBasedOnMultipleProperties: function (bVal, formVisibility) {
			if (formVisibility === "X") {
				return bVal;
			} else {
				return false;
			}
		},
		formatFieldSelectField: function (bVal, formVisibility,isMeetingPlanned) {
			if (formVisibility === "X") {
				if (isMeetingPlanned === true) {
					return bVal;
				} else {
					return false;
				}
			} else {
				return false;
			}
		},

		//end code of form config
		_onCopyContent: function (oModel,iIndex,that) {
			var bSelected = oModel.subcontext[iIndex].selected;
			var oContextData = oModel.subcontext[iIndex];
			//var iIndex = Number(sBindingContextPath.slice(-1));
			var oModelData ;
				if(this.getView().getModel("multiReqModel").getData().subcontext[0].isRework){
					 oModelData = this.getView().getModel("multiReqModel").getData().subcontext[0].requestDetails;
				}else{
					 oModelData = this.getView().getModel("multiReqModel").getData().subcontext
				}
			var oModelData = this.getView().getModel("multiReqModel").getData().subcontext;
			var prevObject = oModelData[iIndex - 1];
			var oFormModelData = this.getView().getModel("formValConfigModel").getData();

			oContextData.meetingGoal = (prevObject.meetingGoal && bSelected) ? prevObject.meetingGoal : "";
			oContextData.supportType = (prevObject.supportType && bSelected) ? prevObject.supportType :oFormModelData[
				"supp_type"];
			oContextData.meetingType = (prevObject.meetingType && bSelected) ? prevObject.meetingType : "";
			oContextData.meetingLocation = (prevObject.meetingLocation && bSelected) ? prevObject.meetingLocation : "";
			oContextData.meetingDate = (prevObject.meetingDate && bSelected) ? prevObject.meetingDate : "";
			oContextData.meetingTime = (prevObject.meetingTime && bSelected) ? prevObject.meetingTime : "";
			oContextData.language = (prevObject.language && bSelected) ? prevObject.language : oFormModelData["lang"];
			oContextData.participantType = (prevObject.participantType && bSelected) ? prevObject.participantType : oFormModelData["particpnt_type"];
			oContextData.participantTypeDetails = (prevObject.participantTypeDetails && bSelected) ? prevObject.participantTypeDetails : "";
			oContextData.involvedParties = (prevObject.involvedParties && bSelected) ? prevObject.involvedParties :oFormModelData["sap_parties"];
			oContextData.involvedPartiesKeys = (prevObject.involvedPartiesKeys && bSelected) ? prevObject.involvedPartiesKeys : [];
			oContextData.involvedPartiesNames = (prevObject.involvedPartiesNames && bSelected) ? prevObject.involvedPartiesNames : "";
			oContextData.preferredPresales = (prevObject.preferredPresales && bSelected) ? prevObject.preferredPresales : "";
			oContextData.supportTypeRISE = (prevObject.supportTypeRISE && bSelected) ? prevObject.supportTypeRISE :oFormModelData["support_rise"];
			oContextData.isMeetingPlanned = (prevObject.isMeetingPlanned && bSelected) ? true : false;
			oContextData.isMeetingPlannedText = (prevObject.isMeetingPlannedText && bSelected) ? prevObject.isMeetingPlannedText : "";
			oContextData.typeOfSupport = (prevObject.typeOfSupport && bSelected) ? prevObject.typeOfSupport : "";
			oContextData.solutionsInScope = (prevObject.solutionsInScope && bSelected) ? prevObject.solutionsInScope : "";
			oContextData.isParticipantTypeSelected = (prevObject.isParticipantTypeSelected && bSelected) ? true : false
			oContextData.supportTypeKey = (prevObject.supportTypeKey && bSelected) ? prevObject.supportTypeKey : "";
			oContextData.participantTypeKey = (prevObject.participantTypeKey && bSelected) ? prevObject.participantTypeKey : "";
			oContextData.languageKey = (prevObject.languageKey && bSelected) ? prevObject.languageKey : "";
			oContextData.involvedPartiesKey = (prevObject.involvedPartiesKey && bSelected) ? prevObject.involvedPartiesKey : "";
			oContextData.meetingTypeKey = (prevObject.meetingTypeKey && bSelected) ? prevObject.meetingTypeKey : "";
			oContextData.comments = (prevObject.comments && bSelected) ? prevObject.comments : "";
			oContextData.attachmentUrls = (prevObject.attachmentUrls.length && bSelected) ? JSON.parse(JSON.stringify(prevObject.attachmentUrls)) : [{
				"urlName": "",
				"url": "",
				"urlDelete": false,
				"urlNameValueState": "None",
				"urlValueStateText":"",
				"urlValueState": "None"
			}];
			

			var oModelData = that.getView().getModel("multiReqModel").getData().subcontext[iIndex];
			that._setPrevioslySelectedValues(oContextData, oContextData);
			if (bSelected) {
				that._validateFormFields(oContextData);
			}


		},
		
		onCopyContent: function (oEvent) {
		//copy the content from prev reqArea
			var oBindingContext = oEvent.getSource().getBindingContext("multiReqModel");
			var sBindingContextPath = oBindingContext.getPath();
			var iIndex = Number(sBindingContextPath.slice(-1));
			var oModelData = this.getView().getModel("multiReqModel").getData();
			this._onCopyContent(oModelData,iIndex,this);
		},
		_setDefaultFormValue: function () {
			//set default dropDown value for form fields
			var aDefaultSupportTypes = this.getModel("formValConfigModel").getProperty("/idsupp_type").filter(obj => {
				return obj.Default_Flag === "X";
			}),
				aDefaultMeetingTypes = this.getModel("formValConfigModel").getProperty("/idmeet_type").filter(obj => {
					return obj.Default_Flag === "X";
				}),
				aDefaultLanguages = this.getModel("formValConfigModel").getProperty("/idlang").filter(obj => {
					return obj.Default_Flag === "X";
				}),
				aDefaultParticipantTypes = this.getModel("formValConfigModel").getProperty("/idparticpnt_type").filter(obj => {
					return obj.Default_Flag === "X";
				}),
				aDefaultInvolvedParties = this.getModel("formValConfigModel").getProperty("/idsap_parties").filter(obj => {
					return obj.Default_Flag === "X";
				}),
				aDefaultSupportRise = this.getModel("formValConfigModel").getProperty("/idrise_dealphase").filter(obj => {
					return obj.Default_Flag === "X";
				}),
				oFormModel = this.getModel("formValConfigModel").getData();
			oFormModel.supp_type = [];
			oFormModel.meet_type = [];
			oFormModel.lang = [];
			oFormModel.particpnt_type = [];
			oFormModel.sap_parties = [];
			oFormModel.support_rise = [];

			aDefaultSupportTypes.forEach(function (defValue) {
				oFormModel.supp_type.push(defValue.Value)
			});
			oFormModel.supp_type = oFormModel.supp_type.join("; ")

			aDefaultMeetingTypes.forEach(function (defValue) {
				oFormModel.meet_type.push(defValue.Value)
			});
			oFormModel.meet_type = oFormModel.meet_type.join("; ")

			aDefaultLanguages.forEach(function (defValue) {
				oFormModel.lang.push(defValue.Value)
			});
			oFormModel.lang = oFormModel.lang.join("; ")

			aDefaultParticipantTypes.forEach(function (defValue) {
				oFormModel.particpnt_type.push(defValue.Value)
			});
			oFormModel.particpnt_type = oFormModel.particpnt_type.join("; ")

			aDefaultInvolvedParties.forEach(function (defValue) {
				oFormModel.sap_parties.push(defValue.Value)
			});
			oFormModel.sap_parties = oFormModel.sap_parties.join("; ")

			aDefaultSupportRise.forEach(function (defValue) {
				oFormModel.support_rise.push(defValue.Value)
			});
			oFormModel.support_rise = oFormModel.support_rise.join("; ")

			this.getModel("formValConfigModel").refresh(true);
		},
		// set previously selected values if the request was sent back
		_setPrevioslySelectedValues: function (oModelData,oRequestDetails,bNavigation) {
			var oFormModelData = this.getView().getModel("formValConfigModel").getData();
			//set values for Inputs
			oModelData["meetingGoal"] = oRequestDetails.meetingGoal;
			oModelData["meetingDate"] = oRequestDetails.meetingDate;
			oModelData["meetingTime"] = oRequestDetails.meetingTime;
			oModelData["preferredPresales"] = oRequestDetails.preferredPresales;
			oModelData["isMeetingPlanned"] = oRequestDetails.isMeetingPlanned;
			oModelData["solutionsInScope"] = oRequestDetails.solutionsInScope;
			oModelData["typeOfSupport"] = oRequestDetails.typeOfSupport;
			oModelData["participantTypeDetails"] = oRequestDetails.participantTypeDetails;
			oModelData["isParticipantTypeSelected"] = oRequestDetails.isParticipantTypeSelected;
			oModelData["meetingLocation"] = oRequestDetails.meetingLocation;
			oModelData["language"] = oRequestDetails.language;
			oModelData["supportType"] = oRequestDetails.supportType;
			oModelData["participantType"] = oRequestDetails.participantType;
			oModelData["involvedParties"] = oRequestDetails.involvedParties;
			oModelData["involvedPartiesNames"] = oRequestDetails.involvedPartiesNames;
			oModelData["meetingGoal"] = oRequestDetails.meetingGoal;
			oModelData["supportTypeKey"] = oRequestDetails.supportTypeKey;
			oModelData["meetingTypeKey"] = oRequestDetails.meetingTypeKey;
			oModelData["languageKey"] = oRequestDetails.languageKey;
			oModelData["involvedPartiesKeys"] = oRequestDetails.involvedPartiesKey;
			oModelData["participantTypeKey"] = oRequestDetails.participantTypeKey;
			oModelData["attachmentUrls"] = oRequestDetails.attachmentUrls;
			oModelData["comments"] = "";

			//set values for Selects
				var aSupportTypes = oFormModelData["idsupp_type"] ,
				aMeetingTypes =oFormModelData["idmeet_type"] ,
				aLanguages = oFormModelData["idlang"] ,				
				aParticipantTypes = oFormModelData["idparticpnt_type"] ,
				aInvolvedParties = oFormModelData["idsap_parties"] ,
				aSupportTypesRISE = oFormModelData["idrise_dealphase"];

			var aSupportTypesKeys = [];
			for (var i = 0; i < aSupportTypes.length; i++) {
				aSupportTypes[i].Default_Flag = "";
				if (oRequestDetails.supportType) {
					var aSupportTypesValues = oRequestDetails.supportType.split("; ");
					for (var j = 0; j < aSupportTypesValues.length; j++) {
						if (this.getMessage(aSupportTypes[i].Value) === aSupportTypesValues[j]) {
							aSupportTypes[i].Default_Flag = "X";
							aSupportTypesKeys.push(aSupportTypes[i]);
						}
					}
				}
			}
			if (aMeetingTypes) {
				for (var i = 0; i < aMeetingTypes.length; i++) {
					aMeetingTypes[i].Default_Flag = "";
					if (this.getMessage(aMeetingTypes[i].Value) === oRequestDetails.meetingType) {
						this.byId("MeetingTypeSelectMrq").setSelectedKey(aMeetingTypes[i].key);
						oRequestDetails["meetingType"] = oRequestDetails.meetingType;
						aMeetingTypes[i].Default_Flag = "X";
					}
				}
			}
			var aLanguageKeys = [];
			for (var i = 0; i < aLanguages.length; i++) {
				aLanguages[i].Default_Flag = "";
				if (oRequestDetails.language) {
					var aLanguageValues = oRequestDetails.language.split("; ");
					for (var j = 0; j < aLanguageValues.length; j++) {
						if (this.getMessage(aLanguages[i].Value) === aLanguageValues[j]) {
							aLanguages[i].Default_Flag = "X";
							aLanguageKeys.push(aLanguages[i]);
						}
					}
				}
			}
			var aParticipantTypesKeys = [];
			for (var i = 0; i < aParticipantTypes.length; i++) {
				aParticipantTypes[i].Default_Flag = "";
				if (oRequestDetails.participantType) {
					var aParticipantTypesValues = oRequestDetails.participantType.split("; ");
					for (var j = 0; j < aParticipantTypesValues.length; j++) {
						if (this.getMessage(aParticipantTypes[i].Value) === aParticipantTypesValues[j]) {
							aParticipantTypes[i].Default_Flag = "X";
							aParticipantTypesKeys.push(aParticipantTypes[i]);
						}
					}
				}
			}

			if (oModelData["participantType"]) {
				oModelData["isParticipantTypeSelected"] = true;
			} else {
				oModelData["isParticipantTypeSelected"] = false;
			}

			var aInvolvedPartiesKeys = [];
			for (var i = 0; i < aInvolvedParties.length; i++) {
				aInvolvedParties[i].Default_Flag = "";
				if (oRequestDetails.involvedParties) {
					var aInvolvedPartiesValues = oRequestDetails.involvedParties.split("; ");
					for (var j = 0; j < aInvolvedPartiesValues.length; j++) {
						if (this.getMessage(aInvolvedParties[i].Value) === aInvolvedPartiesValues[j]) {
							aInvolvedParties[i].Default_Flag = "X";
							aInvolvedPartiesKeys.push(aInvolvedParties[i].Value);
						}
					}
				}
			}

			if (aInvolvedPartiesKeys.length > 0) {
				if (!aInvolvedPartiesKeys.includes("None")) {
					oModelData["namesOfPartiesVisible"] = true;
				} else {
					oModelData["namesOfPartiesVisible"] = false;
				}

			} else {
				oModelData["namesOfPartiesVisible"] = false;
			}

			var aSupportTypesRISEKeys = [];
			for (var i = 0; i < aSupportTypesRISE.length; i++) {
				aSupportTypesRISE[i].Default_Flag = "";
				if (oRequestDetails.supportTypeRISE) {
					var aSupportTypesRISEValues = oRequestDetails.supportTypeRISE.split("; ");
					for (var j = 0; j < aSupportTypesRISEValues.length; j++) {
						if (this.getMessage(aSupportTypesRISE[i].Value) === aSupportTypesRISEValues[j]) {
							aSupportTypesRISE[i].Default_Flag = "X";
							aSupportTypesRISEKeys.push(aSupportTypesRISE[i].Value);
						}
					}
				}
			}
			oModelData["supportTypeRISE"] = oRequestDetails.supportTypeRISE;
			this.getModel("multiReqModel").refresh(true);
			this.onSwitchStateChange();
			if (bNavigation !== true) {
				this.getModel("formValConfigModel").refresh(true);
			} else {
				this.getModel("formValConfigModel").refresh(true);
			}
		},

		configureView: function () {
			var startupParameters = this.getComponentData().startupParameters;
			var sendRequestText = this.getMessage("SUBMIT_REQUEST");
			var terminateRequestText = this.getMessage("TERMINATE");
			var oFormActionsModelData = this.getView().getModel("formActionsConfigModel").getData();
			const saveDratText =  this.getMessage("saveDraft");
			var oThisController = this;
			if (this.getModel("multiReqModel").getData().subcontext.length === 1) {
				// Implementation for the sendRequest action
				var oSendRequestAction = {
					sBtnTxt: sendRequestText,
					onBtnPressed: function () {
						var model = oThisController.getModel("multiReqModel");
						model.refresh(true);
						var processContext = model.getData().subcontext[0];
						//attachment urls
						oThisController._removeEmptyUrl(0);

						// Call a local method to perform further action
						oThisController._validateInput(
							processContext,
							startupParameters.taskModel.getData().InstanceID,
							"Submit Request",
							 "",
							"Complete",
							0
						);
					}
				};

				if (oFormActionsModelData.idsubmit[0].Visibility === "X") {
					// Add 'SendRequest' action to the task
					startupParameters.inboxAPI.addAction({
							action: oFormActionsModelData.idsubmit[0].Label,
							label: oFormActionsModelData.idsubmit[0].Label,
							type: "Accept"
						},
						// Set the onClick function
						oSendRequestAction.onBtnPressed);
				}

				// Implementation for the sendRequest action
				var oTerminateRequestAction = {
					sBtnTxt: terminateRequestText,
					onBtnPressed: function () {
						var model = oThisController.getModel("multiReqModel");
						model.refresh(true);
						var processContext = model.getData().subcontext[0];

						// Call a local method to perform further action
						oThisController._triggerComplete(
							processContext,
							startupParameters.taskModel.getData().InstanceID,
							"Terminate"
						);
					}
				};
				if (oFormActionsModelData.idterminate[0].Visibility === "X") {
					// Add 'Terminate' action to the task
					startupParameters.inboxAPI.addAction({
							action: oFormActionsModelData.idterminate[0].Label,
							label: oFormActionsModelData.idterminate[0].Label,
							type: "Reject"
						},
						// Set the onClick function
						oTerminateRequestAction.onBtnPressed);
				}
			} else {
				//multiple req area
				
				this._setMultiReqButtons(startupParameters);
			}
			// Implementation for the save draft action
			var oNavContainer = this.getView().byId("idNavContainerMrq");
			var currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
			var iIndex = Number(currentPageId.slice(-1));
			if(this.getModel("multiReqModel").getData().subcontext.length-1 === iIndex){
			var oSaveDraftAction = {
				sBtnTxt: terminateRequestText,
				onBtnPressed: function () {
					oThisController.onSaveDraft();
				}
			};
		
				// Add 'save draft' action to the task
				startupParameters.inboxAPI.addAction({
						action: "SaveDraft",
						label: saveDratText,
						type: "Accept"
					},
					// Set the onClick function
					oSaveDraftAction.onBtnPressed);
				}

		},
		navtoReqArea: function (navtoPageId,sAction) {
			//navingation to reqArea
			var startupParameters = this.getComponentData().startupParameters;
			var iMultiReqContextIndex;
			var oView = this.getView();
			var oNavContainer = oView.byId("idNavContainerMrq")
			var oModel = this.getView().getModel("multiReqModel").getData();
			var currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
			var iIndex = Number(currentPageId.slice(-1));
			oNavContainer.to(navtoPageId);
			var sKey = this.getView().byId(navtoPageId).getBindingContext("multiReqModel").getProperty("requestArea");
			this.getView().byId("iconTabHeader").setSelectedKey(sKey);
			this._setMultiReqButtons(startupParameters);
			this.getView().getModel("multiReqModel").refresh(true);
			var i18nModel =  this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var that = this;
			if (sAction === "next") {
				iMultiReqContextIndex = iIndex + 1;
				//attachment urls
				this._initializeUrls(iMultiReqContextIndex);
				if(oModel.subcontext[iIndex].isResourceProfile){
					this.getResProfileDetails(iMultiReqContextIndex);
				}
				oModel.subcontext[iIndex].requestCopyDetails = this._formRequestDetails(oModel.subcontext[iIndex]);
				if (oModel.subcontext[iMultiReqContextIndex].currentRequestDetails) {
					if (oModel.subcontext[iIndex + 1].selected) {
						if (oModel.subcontext[iIndex].requestCopyDetails.attachmentUrls) {
							if (!oModel.subcontext[iIndex].requestCopyDetails.attachmentUrls.length) {
								oModel.subcontext[iIndex].requestCopyDetails.attachmentUrls = [{
									"urlName": "",
									"url": "",
									"urlDelete": false,
									"urlNameValueState": "None",
									"urlValueStateText": "",
									"urlValueState": "None"
								}];
							}
						}
						if (JSON.stringify(oModel.subcontext[iIndex].requestCopyDetails) !==
							JSON.stringify(oModel.subcontext[iMultiReqContextIndex].currentRequestDetails)) {
								const sCopyMsg = oModel.subcontext[iIndex].isResourceProfile ? i18nModel.getText("searchReqMsg") : i18nModel.getText("reqAreaMsg")
								let sAreaText;
								let sCurrentSearchText;
								if(oModel.subcontext[iIndex].isResourceProfile){
								    sAreaText = oModel.subcontext[iIndex].searchFieldsText;
									sCurrentSearchText = oModel.subcontext[iIndex+1].searchFieldsText;
								}else{
									sAreaText = oModel.subcontext[iIndex].requestAreaPath;
									sCurrentSearchText = oModel.subcontext[iIndex+1].requestAreaPath;
								}
								MessageBox.show(
									`The form values on ${sCopyMsg} '${sAreaText}' has been changed.\n Do you want to overwrite same on ${sCopyMsg} '${sCurrentSearchText}' ?`, {
									icon: MessageBox.Icon.WARNING,
								title: `${i18nModel.getText("copyConfirmation")}`,
								actions: [MessageBox.Action.YES, MessageBox.Action.NO],
								emphasizedAction: MessageBox.Action.YES,
								onClose: function (oAction) {
									if (oAction === MessageBox.Action.YES) {
										that._onCopyContent(oModel, iMultiReqContextIndex, that);

									} else {
										oModel.subcontext[iMultiReqContextIndex].selected=false;
										that.getView().getModel("multiReqModel").refresh(true);
									}

								}
							}
							);
						}
						
					}
				}
			} else {
				iMultiReqContextIndex = iIndex - 1;
				
				//attachment urls
				this._initializeUrls(iMultiReqContextIndex);
				oModel.subcontext[iIndex].currentRequestDetails = this._formRequestDetails(oModel.subcontext[iIndex]);
			}	
			var oContextData = this.getView().getModel("multiReqModel").getData().subcontext[iMultiReqContextIndex];
			this._setPrevioslySelectedValues(oContextData,oContextData,true);
			//this.checkIfFolderExists("WorkflowManagement");
			//this.loadAttachments(oContextData);
			this._hideMyInboxFooterBtns(this);
		},
		_setMultiReqButtons: function (startupParameters) {
			var oFormActionsModelData = this.getView().getModel("formActionsConfigModel").getData();
			var oNavContainer = this.getView().byId("idNavContainerMrq");
			var currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
			var oModel = this.getView().getModel("multiReqModel").getData();
			var iIndex = Number(currentPageId.slice(-1));
			var oNavContainer = this.getView().byId("idNavContainerMrq");
			const saveDratText =  this.getMessage("saveDraft");
			var terminateRequestText = this.getMessage("TERMINATE");
			var sendRequestText = this.getMessage("SUBMIT_REQUEST");
			var that = this;
			var navtoPageId;
			var startupParameters = this.getComponentData().startupParameters;
			
			var sPrevReqAreaButtonText;
			var sNextReqAreaButtonText;
			if(!oModel.subcontext[0].isResourceProfile){
				 sPrevReqAreaButtonText = this.getMessage("PREV_REQAREA_BTN_TEXT");
				 sNextReqAreaButtonText = this.getMessage("NEXT_REQAREA_BTN_TEXT");
			}else{
				 sPrevReqAreaButtonText = this.getMessage("PREV_RESPRO_BTN_TEXT");
				 sNextReqAreaButtonText = this.getMessage("NEXT_RESPRO_BTN_TEXT");
			}
			
			
			//remove all buttons
			startupParameters.inboxAPI.removeAction("SaveDraft");
			startupParameters.inboxAPI.removeAction(sPrevReqAreaButtonText);
			startupParameters.inboxAPI.removeAction(sPrevReqAreaButtonText);
			startupParameters.inboxAPI.removeAction(sNextReqAreaButtonText);
			startupParameters.inboxAPI.removeAction( oFormActionsModelData.idsubmit[0].Label);
			startupParameters.inboxAPI.removeAction( oFormActionsModelData.idterminate[0].Label);
			// Implementation for the prevReqArea action
			var oPrevReqAreaButton = {
				sBtnTxt: sPrevReqAreaButtonText,
				onBtnPressed: function () {
					startupParameters.inboxAPI.removeAction(terminateRequestText);
					// that.navtoReqArea(navtoPageId, "prev");
					that.getView().getModel("multiReqModel").refresh(true);
					let oNavContainer = that.getView().byId("idNavContainerMrq");
				let currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
				let iIndex = Number(currentPageId.slice(-1));
				const oContextData = that.getView().getModel("multiReqModel").getData().subcontext[iIndex];
				let navtoPageId = currentPageId.replace(/\idNavContainerMrq[^\s]*/g, "") + "idNavContainerMrq-" + (iIndex - 1).toString();
				that.navtoReqArea(navtoPageId, "prev");
				
				that.getView().getModel("multiReqModel").refresh(true);
			// 	for (let i = 0; i < this.unSavedData.length; i++) {
			// 	if (this.unSavedData[i].iIndex === iIndex) {
			// 		this.unSavedData.splice(i, 1)
			// 	}
			// }

				if (that.getView().getModel("multiReqModel").getData().subcontext.length > 1 && that.unSavedData.length) {
					let i18nModel =  that.getOwnerComponent().getModel("i18n").getResourceBundle();
					const si18nDraftMsg1 = i18nModel.getText("draftPropmptMsg1");
					const si18nDraftMsg2 = i18nModel.getText("draftPropmptMsg2");
					const si18nDraftMsg3 = i18nModel.getText("draftPropmptMsg3");
				let sCurrentReq;
					if(oContextData.isResourceProfile){
						 sCurrentReq = oContextData.searchFieldsText ? oContextData.searchFieldsText :"";
					}else{
						sCurrentReq = oContextData.requestArea ? oContextData.requestArea :"";
					}
				let aMsgs = [];
				that.unSavedData.forEach(function(data){
					const sSearchFieldText = data.searchFieldsText ?  data.searchFieldsText:"";
					aMsgs.push(`${data.requestArea} ${sSearchFieldText}`)
				});
				let sDraftDynamicMsg =aMsgs.join(" , "); 
				MessageBox.show(
					`${si18nDraftMsg1} "${sCurrentReq}".`, {
					icon: MessageBox.Icon.WARNING,
					title:"Warning",
					contentWidth:"600px",
					actions: [MessageBox.Action.OK],
					onClose: function (oAction) {
						if (oAction === MessageBox.Action.OK) {
							that.unSavedData = [];
							// that._onSaveDraft();

						} 
					}
				}
				);
			}else{
				that.unSavedData = [];
			}

				}
			};

			// Implementation for the nextReqArea action
			var oNextReqAreaButton = {
				sBtnTxt: sNextReqAreaButtonText,
				type: "Emphasized",
				onBtnPressed: function () {
					var processContext = that.getView().getModel("multiReqModel").getData().subcontext[iIndex];
					navtoPageId = currentPageId.replace(/\idNavContainerMrq[^\s]*/g, "") + "idNavContainerMrq-" + (iIndex + 1).toString();
					//attachment urls
					//remove empty url object
					that._removeEmptyUrl(iIndex);
					that._validateInput(processContext, startupParameters.taskModel.getData().InstanceID, "Next", navtoPageId,false,iIndex);
				}
			};
			// Implementation for the Submit Request action
			var oSendRequestAction = {
				sBtnTxt: sendRequestText,
				onBtnPressed: function () {
					var model = that.getModel("multiReqModel");
					model.refresh(true);
					var processContext = model.getData().subcontext[iIndex];
					navtoPageId = currentPageId.replace(/\idNavContainerMrq[^\s]*/g, "") + "idNavContainerMrq-" + (iIndex + 1).toString();
					//attachment urls
					that._removeEmptyUrl(iIndex);
					// Call a local method to perform further action
					that._validateInput(
						processContext,
						startupParameters.taskModel.getData().InstanceID,
						"Submit Request",
						"Complete",
						false,
						iIndex
					);
				}
			};
			// Implementation for the terminate action
			var oTerminateRequestAction = {
				sBtnTxt: terminateRequestText,
				onBtnPressed: function () {
					var model = that.getModel("multiReqModel");
					model.refresh(true);
					var processContext = model.getData().subcontext[0];

					// Call a local method to perform further action
					that._triggerComplete(
						processContext,
						startupParameters.taskModel.getData().InstanceID,
						"Terminate"
					);
				}
			};
			//Add terminate action
			if (oFormActionsModelData.idterminate[0].Visibility === "X") {
				// Add 'Terminate' action to the task
				startupParameters.inboxAPI.addAction({
					action: oFormActionsModelData.idterminate[0].Label,
					label: oFormActionsModelData.idterminate[0].Label,
					type: "Reject"
				},
					// Set the onClick function
					oTerminateRequestAction.onBtnPressed);
			}
			if (oModel.subcontext[iIndex + 1]) {
				if (iIndex !== 0) {
					// Add 'Previous Request Area' action to the task
					startupParameters.inboxAPI.addAction({
							action: sPrevReqAreaButtonText,
							label: sPrevReqAreaButtonText,
							type: "Accept"
						},
						// Set the onClick function
						oPrevReqAreaButton.onBtnPressed);
				}
				
				// Add 'Next Request Area' action to the task
				startupParameters.inboxAPI.addAction({
						action: sNextReqAreaButtonText,
						label: sNextReqAreaButtonText,
						type: "Accept"
					},
					// Set the onClick function
					oNextReqAreaButton.onBtnPressed);
			} else {
				// Add 'Previous Request Area' action to the task
				startupParameters.inboxAPI.addAction({
					action: sPrevReqAreaButtonText,
					label: sPrevReqAreaButtonText,
					type: "Accept"
				},
				// Set the onClick function
				oPrevReqAreaButton.onBtnPressed);

				if(this.getModel("multiReqModel").getData().subcontext.length-1 === iIndex){
					var oSaveDraftAction = {
						sBtnTxt: terminateRequestText,
						onBtnPressed: function () {
							that.onSaveDraft();
						}
					};
				
						// Add 'save draft' action to the task
						startupParameters.inboxAPI.addAction({
								action: "SaveDraft",
								label: saveDratText,
								type: "Accept"
							},
							// Set the onClick function
							oSaveDraftAction.onBtnPressed);
					}else{
						startupParameters.inboxAPI.removeAction("SaveDraft");
					}
			// Add 'SendRequest' action to the task
			startupParameters.inboxAPI.addAction({
				action: oFormActionsModelData.idsubmit[0].Label,
				label: oFormActionsModelData.idsubmit[0].Label,
				type: "Accept"
			},
				// Set the onClick function
				oSendRequestAction.onBtnPressed);
					
			}	
		},
		  /**
         * Validate submit form page
         * @param {object} processContext - context details
         * @param {boolean} bIsSaveDraft - Action 'Save Draft' => bIsSaveDraft 'true'
         */
		_validateFormFields:function(processContext,bIsSaveDraft) {
			this.errorExist = false;
			var oThisController = this,
				oMCommon = oThisController.getModel("mCommon");
			var requestDetailsFields = this._configFormValidation(processContext);
			var requestDetailsValue;
			if (!bIsSaveDraft) {
				//Save and proceed or submit request action validation
			for (var i = 0; i < requestDetailsFields.length; i++) {
				requestDetailsValue = processContext[requestDetailsFields[i]];
				if (requestDetailsValue && requestDetailsValue.trim() && requestDetailsValue !== "" && requestDetailsValue !== "undefined" &&
					requestDetailsValue !==
					"null") {
					oMCommon.setProperty("/" + requestDetailsFields[i] + "State", "None");
				} else {
					oThisController.errorExist = true;
					if (requestDetailsFields[i] === "supportTypeRISE") {
						oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_SUPPORT_TYPE_RISE");
					}
					if (requestDetailsFields[i] === "supportType") {
						oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_SUPPORT_TYPE");
					}
					if (requestDetailsFields[i] === "involvedParties") {
						oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_INVOLVED_PARTIES");
					}
					if (requestDetailsFields[i] === "typeOfSupport") {
						oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_TYPE_OF_SUPPORT");
					}
					if (requestDetailsFields[i] === "solutionsInScope") {
						oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_SOLUTIONS_IN_SCOPE");
					}
					if (requestDetailsFields[i] === "participantTypeDetails") {
						oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_PARTICIPANT_TYPE_DETAILS");
					}
					if (requestDetailsFields[i] === "preferredPresales") {
						oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_PREFERRED_PRESALES");
					}
					if (requestDetailsFields[i] === "meetingGoal") {
						oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_MEETING_GOAL_TEXT");
					}
					if (requestDetailsFields[i] === "language") {
						oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_LANGUAGE");
					}
					if (requestDetailsFields[i] === "meetingDate") {
						oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_MEETING_DATE");
					}
					if (requestDetailsFields[i] === "meetingLocation") {
						oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_MEETING_LOCATION");
					}
					if (requestDetailsFields[i] === "meetingTime") {
						oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_MEETING_TIME");
					}
					if (requestDetailsFields[i] === "participantType") {
						oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_PARTICIPANT_TYPE");
					}
					if (requestDetailsFields[i] === "requestArea" && !processContext.isResourceProfile) {
						oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_REQUEST_AREA");
					}
					if (requestDetailsFields[i] === "involvedPartiesNames") {
						oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_INVOLVED_SAP_NAMES");
					}
					if (requestDetailsFields[i] === "comments") {
						oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_ERROR_COMMENTS");
					}
					if (requestDetailsFields[i] === "meetingType") {
						oMCommon.setProperty("/" + requestDetailsFields[i] + "StateText", "FIELD_VALIDATION_MEETING_TYPE");
					}
					oMCommon.setProperty("/" + requestDetailsFields[i] + "State", "Error");
				}
			}
		}

		if (processContext.isMeetingPlanned && processContext.meetingGoal) {
			if (processContext.meetingGoal.length > 5000) {
				oThisController.errorExist = true;
				oMCommon.setProperty("/meetingGoalStateText", "FIELD_EXCEED_TEXT");
				oMCommon.setProperty("/meetingGoal", "Error");
			}
		}
		if(processContext.typeOfSupport){
			if (processContext.typeOfSupport.length > 5000) {
				oThisController.errorExist = true;
				oMCommon.setProperty("/typeOfSupportStateText", "FIELD_EXCEED_TEXT");
				oMCommon.setProperty("/typeOfSupportState", "Error");
			}
		}
		if(processContext.isMeetingPlanned && processContext.participantTypeDetails && processContext.participantType){
			if (processContext.participantTypeDetails.length > 5000) {
				oThisController.errorExist = true;
				oMCommon.setProperty("/participantTypeDetailsStateText", "FIELD_EXCEED_TEXT");
				oMCommon.setProperty("/participantTypeDetailsState", "Error");
			}
		}
		if(processContext.isMeetingPlanned && processContext.involvedPartiesNames){
			if (processContext.involvedPartiesNames.length > 5000) {
				oThisController.errorExist = true;
				oMCommon.setProperty("/involvedPartiesNamesStateText", "FIELD_EXCEED_TEXT");
				oMCommon.setProperty("/involvedPartiesNames", "Error");
			}
		}
		if(processContext.comments){
			if (processContext.comments.length > 5000) {
				oThisController.errorExist = true;
				oMCommon.setProperty("/commentsStateText", "FIELD_EXCEED_TEXT");
				oMCommon.setProperty("/commentsState", "Error");
			}
		}
		if(bIsSaveDraft && !this.errorExist){
			//Save draft action validation
			this._onSaveDraft();
		}

		},

		/**
		 * Convenience method for all Input validation errors.
		 * @public
		 * @returns Validate all the required input fields.
		 */
		_validateInput: function (processContext, taskId, sDecision, navtoPageId,sFormAction,iIndex) {
			var oThisController = this;
			this.getView().setBusy(true);
			this._validateFormFields(processContext);
			//attachment urls
			const oAttchementUrls = this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls;
			if(oAttchementUrls){
				const aUrlValidation = oAttchementUrls.filter(item => item.urlValueState === "Error");
				if(aUrlValidation.length){
					this.errorExist = true;
				}
			}
			if (this.errorExist) {
				var sGenericErrorText = oThisController.getMessage("FIELD_VALIDATION_ERROR_GENERIC");
				MessageToast.show(sGenericErrorText)
				oThisController.getView().setBusy(false);
				return;
			} else {
				if(sFormAction === "Complete"){
					oThisController._triggerComplete(processContext, taskId, sDecision);
				}else{
					if(sDecision === "Submit Request"){
						oThisController._triggerComplete(processContext, taskId, sDecision);
					}else{
						oThisController.onSaveDraft()
						oThisController.navtoReqArea(navtoPageId,"next");
					}
					
					oThisController.getView().setBusy(false);
				}
			}
		},
		_configFormValidation: function (processContext) {
			var oFormModelData = this.getModel("formConfigModel").getData();
			var aMandtInputs = [];
			if (oFormModelData.idrequestdetails) {
				var oRequestDetailFields = oFormModelData.idrequestdetails.Fields;
				var oRequestDetailFieldValues = Object.values(oRequestDetailFields);
				oRequestDetailFieldValues.forEach(function (reqDetField) {
					switch (reqDetField.ID) {
					case "idcustad_resorc":
						if (reqDetField.Visibility === "X" && reqDetField.Mandatory === "X") {
							aMandtInputs.push("preferredPresales")
						}
						break;
					case "idcustadd":
						if (reqDetField.Visibility === "X" && reqDetField.Mandatory === "X") {
							if (!processContext.isRISE) {
								aMandtInputs.push("typeOfSupport")
							}
						}
						break;
					case "idgoalmeet":
						if (reqDetField.Visibility === "X" && reqDetField.Mandatory === "X") {
							if (processContext.isMeetingPlanned) {
								aMandtInputs.push("meetingGoal");
							}
						}
						break;
					case "idlang":
						if (reqDetField.Visibility === "X" && reqDetField.Mandatory === "X") {
							if (processContext.isMeetingPlanned) {
								aMandtInputs.push("language");
							}
						}
						break;
					case "idmeet_date":
						if (reqDetField.Visibility === "X" && reqDetField.Mandatory === "X") {
							if (processContext.isMeetingPlanned) {
								aMandtInputs.push("meetingDate");
							}
						}
						break;
					case "idmeet_loc":
						if (reqDetField.Visibility === "X" && reqDetField.Mandatory === "X") {
							if (processContext.isMeetingPlanned) {
								aMandtInputs.push("meetingLocation");
							}
						}
						break;
					case "idmeet_time":
						if (reqDetField.Visibility === "X" && reqDetField.Mandatory === "X") {
							if (processContext.isMeetingPlanned) {
								aMandtInputs.push("meetingTime");
							}
						}
						break;
					case "idmeet_type":
						if (reqDetField.Visibility === "X" && reqDetField.Mandatory === "X") {
							if (processContext.isMeetingPlanned) {
								aMandtInputs.push("meetingType");
							}
						}
						break;
					case "idparticpnt_det":
						if (reqDetField.Visibility === "X" && reqDetField.Mandatory === "X") {
							if (processContext.isMeetingPlanned) {
								if (processContext.isParticipantTypeSelected) {
									aMandtInputs.push("participantTypeDetails");
								}
							}

						}
						break;
					case "idparticpnt_type":
						if (reqDetField.Visibility === "X" && reqDetField.Mandatory === "X") {
							if (processContext.isMeetingPlanned) {
								aMandtInputs.push("participantType");
							}
						}
						break;
					case "idreqarea":
						if (reqDetField.Visibility === "X" && reqDetField.Mandatory === "X" && !processContext.isResourceProfile) {
							aMandtInputs.push("requestArea")
						}
						break;
					case "idsap_party":
						if (reqDetField.Visibility === "X" && reqDetField.Mandatory === "X") {
							aMandtInputs.push("involvedPartiesNames")
						}
						break;
					case "idsap_parties":
						if (reqDetField.Visibility === "X" && reqDetField.Mandatory === "X") {
							if (processContext.isMeetingPlanned) {
								aMandtInputs.push("involvedParties");
							}
						}
						break;
					case "idsolmod":
						if (reqDetField.Visibility === "X" && reqDetField.Mandatory === "X") {
							if (processContext.isSolutionRelated) {
								aMandtInputs.push("solutionsInScope")
							}
						}
						break;
					case "idsupp_type":
						if (reqDetField.Visibility === "X" && reqDetField.Mandatory === "X") {
							if (processContext.isMeetingPlanned) {
								aMandtInputs.push("supportType")
							}
						}
						break;
						case "idrise_dealphase":
							if (reqDetField.Visibility === "X" && reqDetField.Mandatory === "X") {
								if (processContext.isRISE) {
									aMandtInputs.push("supportTypeRISE")
								}
							}
							break;
					}

				})

			}
			if (oFormModelData.idcomment) {
				if (oFormModelData.idcomment.Visibility && oFormModelData.Mandatory === "X") {
					aMandtInputs.push("comments")
				}
			}
			return aMandtInputs;
		},
		onNavigationFinished:function(){
			this.getModel("formValConfigModel").refresh(true);
		},
		_formRequestDetails:function(processContext){
			var oFormValues = {
				"comments": processContext.comments ? processContext.comments : "",
				"meetingGoal": processContext.meetingGoal ? processContext.meetingGoal : "",
				"supportType": processContext.supportType ? processContext.supportType : "",
				"supportTypeKey": processContext.supportTypeKey ? processContext.supportTypeKey : "",
				"meetingType": processContext.meetingType ? processContext.meetingType : "",
				"meetingTypeKey": processContext.meetingTypeKey ? processContext.meetingTypeKey : "",
				"meetingLocation": processContext.meetingLocation ? processContext.meetingLocation : "",
				"meetingDate": processContext.meetingDate ? processContext.meetingDate : "",
				"meetingTime": processContext.meetingTime ? processContext.meetingTime : "",
				"language": processContext.language ? processContext.language : "",
				"languageKey": processContext.languageKey ? processContext.languageKey : "",
				"participantType": processContext.participantType ? processContext.participantType : "",
				"participantTypeKey": processContext.participantTypeKey ? processContext.participantTypeKey : "",
				"participantTypeDetails": processContext.participantTypeDetails ? processContext.participantTypeDetails : "",
				"involvedParties": processContext.involvedParties ? processContext.involvedParties : "",
				"involvedPartiesKey": processContext.involvedPartiesKey ? processContext.involvedPartiesKey : "",
				"involvedPartiesKeys": processContext.involvedPartiesKeys ? processContext.involvedPartiesKeys : [],
				"involvedPartiesNames": processContext.involvedPartiesNames ? processContext.involvedPartiesNames : "",
				"preferredPresales": processContext.preferredPresales ? processContext.preferredPresales : "",
				"isRISE": processContext.isRISE ? true : false,
				"supportTypeRISE": processContext.supportTypeRISE ? processContext.supportTypeRISE : "",
				"isMeetingPlanned": processContext.isMeetingPlanned ? true : false,
				"isMeetingPlannedText": processContext.isMeetingPlannedText  ? processContext.isMeetingPlannedText:"No",
				"typeOfSupport": processContext.typeOfSupport ? processContext.typeOfSupport : "",
				"solutionsInScope": processContext.solutionsInScope ? processContext.solutionsInScope : "",
				"isSolutionRelated": processContext.isSolutionRelated ? true : false,
				"isParticipantTypeSelected": processContext.isParticipantTypeSelected ? true : false,
				"RequestType":processContext.RequestType,
				"isAttachment":processContext.isAttachment ? true:false,
				"attachmentUrls": processContext.attachmentUrls ? processContext.attachmentUrls : [],
			};
			if (processContext.RequestType === "Account") {
				oFormValues.PE_Name = processContext.PE_Name;
				oFormValues.Industryname = processContext.IndustryName;
				oFormValues.accountUrl = processContext.accountUrl;
				oFormValues.AccountOwner  = processContext.AccountOwner;
				oFormValues.AccountOwnerUserId  = processContext.AccountOwnerUserId;
				oFormValues.AccountOwnerEmail  = processContext.AccountOwnerEmail; 
			} else if (processContext.RequestType === "Opportunity") {
				oFormValues.Opp_Desc = processContext.Opp_Desc;
			}
			return oFormValues;
		},
		_getOpportunitiesRuntimeBaseURL: function (self) {
            return self._getRuntimeBaseURL() + "/intic";
        },
		 /**
			 * This method is called when the confirm button is click by the end user
			 *
			 * @param {object} processContext - Payload data for submit request
			 * @param {string} taskId - indicates workflow instance ID
			 * @param {string} currentDecision - Indicates the decision of workflow trigger (Submit or Terminate)
			 * 
			 */
		_triggerComplete: function (processContext, taskId, currentDecision) {
			const oThisController = this;
			this.getView().setBusy(true);
			if (processContext.RequestType === "Opportunity") {
					const oOppId = processContext.opportunityId;
					const OpportunitiesBaseUrl = oThisController._getOpportunitiesRuntimeBaseURL(oThisController);
				$.ajax({
					url: `${OpportunitiesBaseUrl}/sap/opu/odata/sap/zharmony_callidus_srv/Opportunities('${oOppId}')?$expand=Notes,PartiesInvolved,DQReview,Attributes,CloseplanActivities,DocFlow,Attachments,Items,Pricing,RevenueSplitPlanH,RevenueSplitPlanI,SalesTeamWF,CustomerIncentive,S2SActivities,S2SActivities/PartiesInvolved,S2SActivities/Goals,RenewalExecution`,
					dataType: 'json',
					async: false,
					method: "GET",
					success: function (data) {
						processContext.INTERNAL_ORDER1 = data.d.INTERNAL_ORDER1;
						processContext.INTERNAL_ORDER2 = data.d.INTERNAL_ORDER2;  
						let OppDetails =  {
							STATUS: data.d.STATUS,
							CURR_PHASE: data.d.CURR_PHASE,
							STATUS_DESC: oThisController.getOppState(data.d.STATUS),
							CURR_PHASE_DESC: oThisController.getCurrentPhase(data.d.CURR_PHASE),
							CLOSE_DATE:oThisController._setDateFormat(data.d.EXPECT_END)
						};
						oThisController.getView().getModel("multiReqModel").setProperty("/NewOppDetails",OppDetails)
						oThisController._fnTriggerFinalSubmitCall(processContext,taskId,currentDecision,oThisController)
					}.bind(this),
					error: function (oError) {
						oThisController.setBusy(false);
						MessageToast.show(oThisController.getOwnerComponent().getModel("appConstants").getProperty("/ServiceDown/0/Value"));
					}
				});
				
			}else{
				this._fnTriggerFinalSubmitCall(processContext,taskId,currentDecision,this)
			}
		},
		 /**
			 * Worfkflow service call
			 *
			 * @param {object} processContext - Payload data for submit request
			 * @param {string} taskId - indicates workflow instance ID
			 * @param {string} currentDecision - Indicates the decision of workflow trigger (Submit or Terminate)
			 * @param {object} self - controller scope
			 */
		_fnTriggerFinalSubmitCall: function (processContext, taskId, currentDecision,self) {

			var oThisController = self;

            oThisController.setBusy(true);
			
			var workflowBaseurl = this._getWorkflowRuntimeBaseURL();
			var oModelData = oThisController.getView().getModel("multiReqModel").getData().subcontext;
			var oRequestDetails;

			
			$.ajax({
				// Call workflow API to get the xsrf token
				url: workflowBaseurl + "/xsrf-token",
				method: "GET",
				headers: {
					"X-CSRF-Token": "Fetch"
				},
				success: function (result, xhr, data) {

					// After retrieving the xsrf token successfully
					var token = data.getResponseHeader("X-CSRF-Token");

					// form the context that will be updated
					var oPayloadContext;
					var aMultipleRequestAreaContext = [];
					let decisionID;
								if (currentDecision === "Submit Request") {
									decisionID = oThisController.getView().getModel("formActionsConfigModel").getData().idsubmit[0].ID;
								} else if (currentDecision === "Terminate") {
									decisionID = oThisController.getView().getModel("formActionsConfigModel").getData().idterminate[0].ID;
								}
					
					if (!oModelData[0].isRework) {
						for (var i = 0; i < oModelData.length; i++) {
							var oParentContext = {};
							processContext = oModelData[i];
							oRequestDetails = oThisController._formRequestDetails(processContext);
							//add payload for attachmentUrl
							if(processContext.attachmentUrls){
								if(!processContext.attachmentUrls[0] || !processContext.attachmentUrls[0].url){
                                    processContext.attachmentUrls = [];
                                }
							}
							oParentContext.systemId = processContext.systemId;
							oParentContext.accountName = processContext.accountName;
							oParentContext.accountId = processContext.accountId;
							oParentContext.opportunityId = processContext.opportunityId;
							oParentContext.extSystemsUrls = processContext.extSystemsUrls;
							oParentContext.requesterDetails = processContext.requesterDetails;
							oParentContext.aResourceProfileApprovers = processContext.aResourceProfileApprovers;
							oParentContext.isResourceProfile = processContext.isResourceProfile;
							oParentContext.isRoleAreaSelection = processContext.isRoleAreaSelection;
							oParentContext.selectedProfitCenter = processContext.selectedProfitCenter;
							oParentContext.OrgID = processContext.OrgID;
							oParentContext.oppOrgId = processContext.oppOrgId;
							const hasParentOrgID = 'ParentOrgID' in processContext;
							if (hasParentOrgID) { oParentContext.ParentOrgID = processContext.ParentOrgID; }
							oParentContext.OrgType = processContext.OrgType;
							oParentContext.GUID = processContext.GUID;
							oParentContext.requestArea = processContext.requestArea;
							oParentContext.uploadUrl = oParentContext.uploadUrl;
							oParentContext.requestAreaPath = processContext.requestAreaPath;
							oParentContext.requestDetails = oRequestDetails;
							oParentContext.requestDetails.attachmentUrls = processContext.attachmentUrls;
							oParentContext.searchFieldsText = processContext.searchFieldsText;
							oParentContext.comments =  processContext.comments;
							oParentContext.decision = "Submit Request";
							oParentContext.submitPageUserTaskID = oThisController.getView().getModel("taskInstanceModel").getProperty("/id");
							// if (currentDecision === "Submit Request"){
							// 	oParentContext.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idsubmit[0].ID;
							// }else if (currentDecision === "Terminate"){
							// 	oParentContext.decision_ID = oThisController.getView().getModel("formActionsConfigModel").getData().idterminate[0].ID;
							// }
							oParentContext.decision_ID = decisionID;
							oParentContext.workflowFileUploadId = processContext.workflowFileUploadId;
							oParentContext.FirstIterationRA = true;
							oParentContext.RequestType = processContext.RequestType;
							if (processContext.RequestType === "Account") {
								oParentContext.PE_Name = processContext.PE_Name;
								oParentContext.IndustryName = processContext.IndustryName;
								oParentContext.accountUrl = processContext.accountUrl;
								oParentContext.AccountOwner  = processContext.AccountOwner;
								oParentContext.AccountOwnerUserId  = processContext.AccountOwnerUserId;
								oParentContext.AccountOwnerEmail  = processContext.AccountOwnerEmail; 
							} else if (processContext.RequestType === "Opportunity") {
								oParentContext.Opp_Desc = processContext.Opp_Desc;
								oParentContext.INTERNAL_ORDER1 = processContext.INTERNAL_ORDER1;
								oParentContext.INTERNAL_ORDER2 = processContext.INTERNAL_ORDER2;
							}
  							//update orgid,orgtype and requesttype for older task
							if (typeof (processContext["SalesOrgID"]) === "string") {
								oParentContext["OrgID"] = processContext["SalesOrgID"];
								oParentContext["OrgType"] = "SORG";
								oParentContext["RequestType"] = "Opportunity"
								//update areapath call
								var OrgID_Num = oThisController._getOrgIDnumber(oParentContext["OrgID"], oParentContext["OrgType"]);
								var aAreaPathCallRequests = [{
									id: "1",
									method: "GET",
									url: "/Resources(GUID=" + processContext.GUID + ",IsActiveEntity=true)",
									headers: { "content-type": "application/json;IEEE754Compatible=true" }
								},
								// To fetch Email template details
								{
									id: "2",
									method: "GET",
									url: "/Email_Body?$filter=orgID eq '" + OrgID_Num + "' and orgType eq '" + oParentContext["OrgType"] + "'",
									headers: { "content-type": "application/json;IEEE754Compatible=true" }
								},
								// End of code for Melody Resource Request Tool Sprint 1
								// to fetch Email Delegates Details
								{
									id: "3",
									method: "GET",
									url: "/Email_Delegates?$filter=orgID eq '" + oParentContext["OrgID"] + "'",
									headers: { "content-type": "application/json;IEEE754Compatible=true" }
								},
								// to check routing flags 
								{
									id: "4",
									method: "GET",
									url: "/WF_Routing?$filter=orgID eq '" + oParentContext["OrgID"] + "'",
									headers: { "content-type": "application/json;IEEE754Compatible=true" }
								}];
								oParentContext.areaPathCall = {
									"Request":{
										"requests" : aAreaPathCallRequests
									}
								};
							};
							aMultipleRequestAreaContext.push(oParentContext)
						}
						oPayloadContext = {
							"context": {
								"ReqFormDelDraftUrl":oThisController.requestDraftUrls ? oThisController.requestDraftUrls:[],
								"CountMultiReqArea": 0,
								"aReqAreas": aMultipleRequestAreaContext,
								"decision": currentDecision,
								"decision_ID" : decisionID
							},
							"status": "COMPLETED"
						};
					} else {
						processContext = oModelData[0];
						if(processContext.attachmentUrls){
							if(!processContext.attachmentUrls[0] || (processContext.attachmentUrls.length && !processContext.attachmentUrls[0]["url"])){
								processContext.attachmentUrls = [];
							}
						}
						processContext.submitPageUserTaskID = oThisController.getView().getModel("taskInstanceModel").getProperty("/id");
						oRequestDetails = oThisController._formRequestDetails(processContext);
						oRequestDetails.attachmentUrls = processContext.attachmentUrls;
						oPayloadContext = {
							"context": {
								"ReqFormDelDraftUrl":oThisController.requestDraftUrls ? oThisController.requestDraftUrls:[],
								"workflowFileUploadId":processContext.workflowFileUploadId,
								"requestDetails": oRequestDetails,
								"comments": processContext.comments ? processContext.comments : "",
								//attachment urls
								"attachmentUrls": processContext.attachmentUrls,
								"decision": currentDecision,
								"submitPageUserTaskID": oThisController.getView().getModel("taskInstanceModel").getProperty("/id"),
								"decision_ID" : oThisController.getView().getModel("formActionsConfigModel").getData().idsubmit[0].ID
							},
							"status": "COMPLETED"
						};
						if (processContext.RequestType === "Opportunity") {
							oPayloadContext.context.Opp_Desc = processContext.Opp_Desc;
							oPayloadContext.context.INTERNAL_ORDER1 = processContext.INTERNAL_ORDER1;
							oPayloadContext.context.INTERNAL_ORDER2 = processContext.INTERNAL_ORDER2;
						}
						//update orgid,orgtype and requesttype for older task
						if (typeof (processContext["SalesOrgID"]) === "string") {
							oPayloadContext.context.OrgID = processContext["SalesOrgID"];
							oPayloadContext.context.OrgType = "SORG";
							oPayloadContext.context.RequestType = "Opportunity";

							//update areapath call
							var OrgID_Num = oThisController._getOrgIDnumber(oPayloadContext.context.OrgID, oPayloadContext.context.OrgType);
							var aAreaPathCallRequests = [{
								id: "1",
								method: "GET",
								url: "/Resources(GUID=" + processContext.GUID + ",IsActiveEntity=true)",
								headers: { "content-type": "application/json;IEEE754Compatible=true" }
							},
							// To fetch Email template details
							{
								id: "2",
								method: "GET",
								url: "/Email_Body?$filter=orgID eq '" + OrgID_Num + "' and orgType eq '" + oPayloadContext.context.OrgType + "'",
								headers: { "content-type": "application/json;IEEE754Compatible=true" }
							},
							// End of code for Melody Resource Request Tool Sprint 1
							// to fetch Email Delegates Details
							{
								id: "3",
								method: "GET",
								url: "/Email_Delegates?$filter=orgID eq '" + oPayloadContext.context.OrgID + "'",
								headers: { "content-type": "application/json;IEEE754Compatible=true" }
							},
							// to check routing flags 
							{
								id: "4",
								method: "GET",
								url: "/WF_Routing?$filter=orgID eq '" + oPayloadContext.context.OrgID + "'",
								headers: { "content-type": "application/json;IEEE754Compatible=true" }
							}];
							oPayloadContext.context.areaPathCall = {
								"Request":{
									"requests" : aAreaPathCallRequests
								}
							};
						}

					}
					
					 //update refrence id for older request
					if (oThisController.getModel("multiReqModel").getData().subcontext[0].isRework && typeof oThisController.getModel("multiReqModel").getData().subcontext[0].RequestID !== "object") {
						if (oThisController.getModel("multiReqModel").getProperty("/subcontext/0/updatedRefId")) {
							oPayloadContext.context.RequestID = {
								"value": oThisController.getModel("multiReqModel").getProperty("/subcontext/0/updatedRefId")
							}
						}
					}
					//old request befor substitute functionality
					if(oModelData[0].RequestType=== "Opportunity" && !oModelData[0]["NewOppDetails"]){
						oPayloadContext.context.NewOppDetails = oThisController.getView().getModel("multiReqModel").getProperty("/NewOppDetails");
					}
					if(oModelData[0].RequestType !== "Opportunity" && !oModelData[0]["NewOppDetails"]){
						oPayloadContext.context.NewOppDetails = {
							STATUS:"",
							CURR_PHASE: "",
							STATUS_DESC: "",
							CURR_PHASE_DESC: "",
							CLOSE_DATE:""
						};
					}
					$.ajax({
						// Call workflow API to complete the task
						url: workflowBaseurl + "/task-instances/" + taskId,
						method: "PATCH",
						contentType: "application/json",
						// pass the updated context to the API
						data: JSON.stringify(oPayloadContext),
						headers: {
							// pass the xsrf token retrieved earlier
							"X-CSRF-Token": token
						},
						// refreshTask needs to be called on successful completion
						success: function (result, xhr, data) {
							oThisController._refreshTask();
							oThisController.setBusy(false);
						},
						error: function (err) {
							oThisController.setBusy(false);
							MessageToast.show(oThisController.getMessage("WORKFLOW_ACCESS_TOKEN_ERROR "));
						}

					});
				},
				error: function (err) {
					oThisController.setBusy(false);
					MessageToast.show(oThisController.getMessage("WORKFLOW_SERVICE_ERROR"));
				}
			});

		},

		// Request Inbox to refresh the control once the task is completed
		_refreshTask: function () {
			var taskId = this.getComponentData().startupParameters.taskModel.getData().InstanceID;
			this.getComponentData().startupParameters.inboxAPI.updateTask("NA", taskId);
			console.log("task is refreshed");
		},

		onDateRangeChange: function (oEvent) {
			var sFrom = oEvent.getParameter("from"),
				sTo = oEvent.getParameter("to"),
				bValid = oEvent.getParameter("valid"),
				oEventSource = oEvent.getSource();

			if (bValid) {
				oEventSource.setValueState(ValueState.None);
			} else {
				oEventSource.setValueState(ValueState.Error);
			}
			this._setUnsavedData();
		},

		onTimeChange: function (oEvent) {
			var oTP = oEvent.getSource(),
				bValid = oEvent.getParameter("valid");

			if (bValid) {
				oTP.setValueState(ValueState.None);
			} else {
				oTP.setValueState(ValueState.Error);
			}
		},
		onSelectTab: function () {
			var oNavContainer = this.getView().byId("idNavContainerMrq");
			var currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;

			var sKey = this.getView().byId(currentPageId).getBindingContext("multiReqModel").getProperty("requestArea");
			this.getView().byId("iconTabHeader").setSelectedKey(sKey);
		},

		onSelectChange: function (oEvent) {

			var oModel = this.getParentModel();
			var sSelectedItemText = oEvent.getSource().getSelectedItem().getText();
			let sSelectedItemKey = oEvent.getSource().getSelectedItem().getKey();
			var oBindingContext = oEvent.getSource().getBindingContext("multiReqModel");
			var oContextData = oBindingContext.getObject();

			var oInput = oEvent.getSource();
			var sId = oInput.getId();
			

			if (sId.includes("MeetingTypeSelectMrq") === true) {
				oContextData["meetingType"] =  sSelectedItemText;
				oContextData["meetingTypeKey"] = sSelectedItemKey;
			}

			if (sSelectedItemText.length > 0) {
				oInput.setProperty("valueState", "None");
			}
			this._setUnsavedData();
		},

		onSwitchStateChange: function (evt) {
			var oView = this.getView();
			var oNavContainer = oView.byId("idNavContainerMrq")
			var currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
			var iIndex = Number(currentPageId.slice(-1));
			var omrqModelData = this.getView().getModel("multiReqModel").getData().subcontext[iIndex];
			var isMeetingPlanned = omrqModelData.isMeetingPlanned;

			if (isMeetingPlanned) {
				omrqModelData.isMeetingPlannedText = this.getMessage("YES");
			} else {
				omrqModelData.isMeetingPlannedText = this.getMessage("NO");
			}
			if (evt) {
				this._setUnsavedData();
			}
		},

			onMultiComboBoxChange: function (oEvent) {
				var aSelectedItems = oEvent.getParameter("selectedItems");
				var sSelectedItemsTexts = "";
				var sSelectedItemsKeys = "";

				if (aSelectedItems.length > 0) {
					sSelectedItemsTexts = aSelectedItems[0].getText();
					sSelectedItemsKeys = aSelectedItems[0].getKey();
				}
				for (var i = 1; i < aSelectedItems.length; i++) {
					sSelectedItemsTexts += "; " + aSelectedItems[i].getText();
					sSelectedItemsKeys += "; " + aSelectedItems[i].getKey();
				}

				var sId = oEvent.getSource().getId();

				var oNavContainer = this.getView().byId("idNavContainerMrq");
				var currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
				var iIndex = Number(currentPageId.slice(-1));
				var oModelData = this.getView().getModel("multiReqModel").getData().subcontext;
				// var oContextModelData = oModelData[iIndex];

				if (sId.includes("ParticipantTypeSelectMrq")) {
					oModelData[iIndex].participantType = sSelectedItemsTexts;
					oModelData[iIndex].participantTypeKey = sSelectedItemsKeys;
					oModelData[iIndex].isParticipantTypeSelected = aSelectedItems.length > 0;
				} else if (sId.includes("InvolvedPartiesSelectMrq")) {
					oModelData[iIndex].involvedParties = sSelectedItemsTexts;
					oModelData[iIndex].involvedPartiesKey = sSelectedItemsKeys;
					var aInvolvedPartiesKeys = [];
					for (var j = 0; j < aSelectedItems.length; j++) {
						aInvolvedPartiesKeys.push(aSelectedItems[j].getKey());
					}
					oModelData[iIndex].involvedPartiesKeys = aInvolvedPartiesKeys;
					if (!aInvolvedPartiesKeys.includes("None")) {
						oModelData[iIndex].namesOfPartiesVisible = true;
					} else {
						oModelData[iIndex].namesOfPartiesVisible = false;
					}
				} else if (sId.includes("LanguageSelectMrq")) {
					oModelData[iIndex].language = sSelectedItemsTexts;
					oModelData[iIndex].languageKey = sSelectedItemsKeys;
				} else if (sId.includes("SupportTypeSelectRISEMrq")) {
					oModelData[iIndex].supportTypeRISE = sSelectedItemsTexts;
					oModelData[iIndex].supportTypeRISEKey = sSelectedItemsKeys;
				} else if (sId.includes("SupportTypesSelectMrq")) {
					oModelData[iIndex].supportType = sSelectedItemsTexts;
					oModelData[iIndex].supportTypeKey = sSelectedItemsKeys;
					var aSupportTypeKeys = [];
					for (var j = 0; j < aSelectedItems.length; j++) {
						aSupportTypeKeys.push(aSelectedItems[j].getKey());
					}
					if (aSupportTypeKeys.includes("9")) { // Others
						MessageToast.show(this.i18nModel.getText("SUPPORT_TYPE_OTHERS_INFO"));
					}
				}

				if (sSelectedItemsTexts.length > 0) {
					oEvent.getSource().setProperty("valueState", "None");
				}
				var oBindingContext = oEvent.getSource().getBindingContext("multiReqModel");
				var sBindingContextPath = oBindingContext.getPath();
				var oContextData = oBindingContext.getObject();
				var iIndex = Number(sBindingContextPath.slice(-1));
				this.getView().getModel("multiReqModel").refresh(true);
				var oModelData = this.getView().getModel("multiReqModel").getData().subcontext[iIndex];
				if (aSelectedItems.length > 1) {
					this._setPrevioslySelectedValues(oContextData, oContextData, true);
				}
				this._setUnsavedData();
		},
		onChange: function (oEvent) {
			var oInput = oEvent.getSource();
			if (oEvent.getParameter("value")) {
				oInput.setProperty("valueState", "None");
			}
			this._setUnsavedData();
		},
		_setUnsavedData:function(){
			const oNavContainer = this.getView().byId("idNavContainerMrq");
			const currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
			const iIndex = Number(currentPageId.slice(-1));
			const oContextData = this.getView().getModel("multiReqModel").getData().subcontext[iIndex];
			const isUnsavedData = this.unSavedData.filter((data) => data.iIndex === iIndex);
			if (!isUnsavedData.length) {
				this.unSavedData.push({
					iIndex: iIndex,
					searchFieldsText: oContextData.searchFieldsText ? oContextData.searchFieldsText : "",
					requestArea: oContextData.requestArea
				})
			}

		},

		/*
		 * DOCUMENT SERVICE INTERACTIONS
		 */
		// check if folder with a given name exists
		checkIfFolderExists: function (folderName) {

			var oUploadCollection = this.byId("UploadCollectionMrq");
			oUploadCollection.setBusy(true);
			var responseStatusCode;
			var docServieBaseUrl = this._getDocServiceRuntimeBaseURL();
			var oModelData = this.getView().getModel("multiReqModel").getData().subcontext;
			var oNavContainer = this.getView().byId("idNavContainerMrq")
			var currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
			var iIndex = Number(currentPageId.slice(-1));

			if (folderName == "WorkflowManagement") {
				var sUrl = docServieBaseUrl + "/WorkflowManagement/";
			} else if (folderName == "HarmonyPresalesRequests") {
				var sUrl = docServieBaseUrl + "/WorkflowManagement/HarmonyPresalesRequests/";
			} else {
				var sUrl = docServieBaseUrl + "/WorkflowManagement/HarmonyPresalesRequests/" + folderName + "/";
			}
			var oSettings = {
				"url": sUrl,
				"method": "GET",
				"async": false,
				"headers": {
					"ContentType": 'application/json',
					"Accept": 'application/json',
					"cache": false,
					'X-CSRF-Token': 'Fetch'
				}
			};

			var oThisController = this;

			$.ajax(oSettings)
				.done(function (results, textStatus, request) {
					token = request.getResponseHeader('X-Csrf-Token');
					responseStatusCode = request.status;
				})
				.fail(function (err) {
					token = err.getResponseHeader('X-Csrf-Token');
					responseStatusCode = err.status;
					if (responseStatusCode != 404) {
						if (!err) {
							MessageBox.error(oThisController.getMessage("UNKNOWN_ERROR"));
						}
					}
				});

			if (folderName == "WorkflowManagement") {
				if (responseStatusCode == 404) {
					this.createFolder(folderName);
				} else if (responseStatusCode == 200) {
					console.log("folder 'root/WorkflowManagement' already exisits");
					this.checkIfFolderExists("HarmonyPresalesRequests");
				} else {
					console.log("something is wrong");
				}
			} else if (folderName == "HarmonyPresalesRequests") {
				if (responseStatusCode == 404) {
					this.createFolder(folderName);
				} else if (responseStatusCode == 200) {
					console.log("folder with a name 'HarmonyPresalesRequests' already exisits");
					// var tempFolderName = this.getParentModel().getProperty("/requestId");
					//workflowInstanceId = this.getParentModel("taskInstanceModel").getProperty("/workflowInstanceId");
					this.checkIfFolderExists(oModelData[iIndex].workflowFileUploadId);
				} else {
					console.log("something is wrong");
				}
			} else {
				if (responseStatusCode == 200) {
					console.log("target folder is already there");
					var oUploadCollection = oThisController.byId("UploadCollectionMrq");
					var sAttachmentsUploadURL = docServieBaseUrl + "/WorkflowManagement/HarmonyPresalesRequests/" + folderName + "/";
					// oUploadCollection.setUploadUrl(sAttachmentsUploadURL);
					// oThisController.getModel("attachmentsModel").setProperty("uploadUrl", sAttachmentsUploadURL);
					// oUploadCollection.setInstantUpload(false);
					this.loadAttachments(oModelData[iIndex]);
				} else if (responseStatusCode == 404) {
					//workflowInstanceId = this.getParentModel("taskInstanceModel").getProperty("/workflowInstanceId");
					oThisController.createFolder(oModelData[iIndex].workflowFileUploadId);
				} else {
					console.log("something is wrong");
				}
			}
		},

		// create folder with a given name
		createFolder: function (folderName) {

			var oThisController = this;
			var docServieBaseUrl = this._getDocServiceRuntimeBaseURL();
			var oModelData = this.getView().getModel("multiReqModel").getData().subcontext;
			var oNavContainer = this.getView().byId("idNavContainerMrq")
			var currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
			var iIndex = Number(currentPageId.slice(-1));
			let sUrl;
			if (folderName == "WorkflowManagement") {
				console.log("creating a folder 'root/WorkflowManagement'");
				 sUrl = docServieBaseUrl + "/";
			} else if (folderName == "HarmonyPresalesRequests") {
				console.log("creating a folder 'root/WorkflowManagement/HarmonyPresalesRequests'");
				 sUrl = docServieBaseUrl + "/WorkflowManagement/";
			} else {
				console.log("creating a folder with a name '" + folderName + "'");
				 sUrl = docServieBaseUrl + "/WorkflowManagement/HarmonyPresalesRequests/";
			}
			var oFormData = new window.FormData();
			oFormData.append("cmisAction", "createFolder");
			oFormData.append("succinct", "true");
			oFormData.append("propertyId[0]", "cmis:name");
			oFormData.append("propertyValue[0]", folderName);
			oFormData.append("propertyId[1]", "cmis:objectTypeId");
			oFormData.append("propertyValue[1]", "cmis:folder");
			var oSettings = {
				"url": sUrl,
				"method": "POST",
				"async": false,
				"data": oFormData,
				"cache": false,
				"contentType": false,
				"processData": false,
				"headers": {
					'X-CSRF-Token': token
				}
			};
			$.ajax(oSettings)
				.done(function (results) {
					if (folderName == "WorkflowManagement") {
						oThisController.checkIfFolderExists("HarmonyPresalesRequests");
					} else if (folderName == "HarmonyPresalesRequests") {
						oThisController.checkIfFolderExists(oModelData[iIndex].workflowFileUploadId);

					} else {
						// tempFolderObjId = results.succinctProperties["cmis:objectId"];
						oThisController.loadAttachments(oModelData[iIndex]);
					}
				})
				.fail(function (err) {
					if (err !== undefined) {
						// var oErrorResponse = $.parseJSON(err.responseText);
						// MessageToast.show(oErrorResponse.message, {
						// 	duration: 6000
						// });
					} else {
						//MessageToast.show(oThisController.getMessage("UNKNOWN_ERROR"));
					}
				});
		},

		loadAttachments: function (modelData) {
			var oUploadCollection = this.byId("UploadCollectionMrq");
			this.sAttachmentsUploadURL = this.formatFileUploadUrl(modelData);
			var sUrl = this.sAttachmentsUploadURL + "?succinct=true";
			var oSettings = {
				"url": sUrl,
				"method": "GET",
				"async": false
			};

			var oThisController = this;
			this.modelData = modelData;
			$.ajax(oSettings)
				.done(function (results) {
					oThisController._mapAttachmentsModel(results);
					if(results.objects && results.objects.length){
						oThisController.modelData.isAttachment = true;
					}else{
						oThisController.modelData.isAttachment = false;
					}
					oUploadCollection.setBusy(false);
							//attachment urls
					if(!oThisController.modelData.attachmentUrls){
						const aUploadedUrlObj = results.objects;
						if (modelData.isRework && aUploadedUrlObj.length) {
							let oAppConstantsModel = oThisController.getOwnerComponent().getModel("appConstants");
							let sAttachmentRouteUrl = oAppConstantsModel.getProperty("/AttachmentRouteURL/0/Value");
							let sAttachmentUploadUrl = oThisController.sAttachmentsUploadURL.replace("/dealsupportapp.comsapbpmRequestPresalesSupport","");
							oThisController.modelData.attachmentUrls = [];
							aUploadedUrlObj.forEach(function (obj) {
								//form uploaded attachment url
								const objectId = obj.object.succinctProperties["cmis:objectId"];
								const sFileName = obj.object.succinctProperties["cmis:name"];
								const sQuery = `?objectId=${objectId}&cmisselector=content`;
								const oUrl = {
									"urlName": sFileName,
									"url": `${sAttachmentRouteUrl}${sAttachmentUploadUrl.replace(/^\./, "")}${sQuery}`,
									"urlDelete": false,
									"urlNameValueState": "None",
									"urlValueStateText": "",
									"urlValueState": "None"
								}
								modelData.attachmentUrls.push(oUrl);
								
				
							});
						}
					}else if(modelData.isRework){
						oThisController._initializeUrls(0);
					}
					oThisController.getModel("multiReqModel").refresh();
				})
				.fail(function (err) {
					if (err !== undefined) {
						// var oErrorResponse = $.parseJSON(err.responseText);
						// MessageToast.show(oErrorResponse.message, {
						// 	duration: 6000
						// });
					} else {
						//MessageToast.show(oThisController.getMessage("UNKNOWN_ERROR"));
					}
				});
				
		},

		uploadFile: function (oFile, sFileName,oEvent) {

			var oUploadCollection = this.byId("UploadCollectionMrq");
			var  oContextData;
			if (!oEvent.workflowFileUploadId) {
				oContextData = oEvent.getSource().getBindingContext("multiReqModel").getObject();
			} else {
				oContextData = oEvent;
			}
			var sUrl = this.formatFileUploadUrl(oContextData);
			

			var oThisController = this;
			oUploadCollection.setBusy(true);

			var oFormData = new window.FormData();
			oFormData.append("cmisAction", "createDocument");
			oFormData.append("propertyId[0]", "cmis:objectTypeId");
			oFormData.append("propertyValue[0]", "cmis:document");
			oFormData.append("propertyId[1]", "cmis:name");
			oFormData.append("propertyValue[1]", sFileName);
			oFormData.append("uploadCollectionMrq", oFile, sFileName);

			var oSettings = {
				"url": sUrl,
				"method": "POST",
				// "async": false,
				"data": oFormData,
				"cache": false,
				"contentType": false,
				"processData": false,
				"headers": {
					'X-CSRF-Token': token
				}
			};

			$.ajax(oSettings)
				.done(function (results) {
					oUploadCollection.setBusy(false);
					oThisController.loadAttachments(oContextData)
					MessageToast.show(oThisController.getMessage("FILE_IS_UPLOADED"));
				})
				.fail(function (err) {
					oUploadCollection.setBusy(false);
					oThisController.loadAttachments(oContextData);
					if (err !== undefined) {
						var oErrorResponse = err.responseText;
						MessageToast.show(oErrorResponse, {
							duration: 6000
						});
					} else {
						MessageToast.show(oThisController.getMessage("UNKNOWN_ERROR"));
					}
				});
		},

		// assign data to attachments model
		_mapAttachmentsModel: function (data) {
			var oUploadCollection = this.byId("UploadCollectionMrq");
			oUploadCollection.destroyItems();

			this.oAttachmentsModel = this.getModel("attachmentsModel");
			this.oAttachmentsModel.setData(data);
			this.oAttachmentsModel.refresh();
		},

		// set parameters that are rendered as a hidden input field and used in ajax requests
		onAttachmentsChange: function (oEvent) {
			var oNavContainer = this.getView().byId("idNavContainerMrq");
			var currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
			var iIndex = Number(currentPageId.slice(-1));
			var oModel = this.getView().getModel("multiReqModel").getData().subcontext;
			var oThisController = this;
			var reader = new FileReader();
			var file = oEvent.getParameter("files")[0];

			reader.onload = function (e) {
				var oFile = new Blob([e.target.result]); // creating blob...
				var sFileName = file.name;
				// oThisController.openBusyDialog();
				oThisController.uploadFile(oFile, sFileName,oModel[iIndex]);
			};

			reader.onerror = function (e) {
				sap.m.MessageToast.show("error");
			};
			reader.readAsArrayBuffer(file);
		},

		// show message when user attempts to attach file with size more than 10 MB
		onFileSizeExceed: function (oEvent) {
			var maxSize = oEvent.getSource().getMaximumFileSize();
			var sFileSizeErrorText = this.getMessage("FILE_SIZE_EXCEEDED_ERROR");
			MessageToast.show(sFileSizeErrorText + " " + maxSize + " MB");
		},

		// set parameters and headers before upload
		onBeforeUploadStarts: function (oEvent) {
			var oUploadCollection = this.getView().byId("UploadCollectionMrq"),
				oFileUploader = oUploadCollection._getFileUploader();

			// use multipart content (multipart/form-data) for posting files
			oFileUploader.setUseMultipart(true);
			oFileUploader.setButtonText(this.getMessage("UPLOAD"));

			console.log("Before Upload starts");

			// ad csrf token to header of request
			var oTokenHeader = new UploadCollectionParameter({
				name: "X-CSRF-Token",
				value: token
			});
			oEvent.getParameters().addHeaderParameter(oTokenHeader);
		},

		// refresh attachments collection after file was uploaded
		onUploadComplete: function (oEvent) {

			// workaround to remove busy indicator
			var oUploadCollection = this.byId("UploadCollectionMrq"),
				cItems = oUploadCollection.aItems.length,
				i;
				var oContextData = oEvent.getSource().getBindingContext("multiReqModel").getObject();

			for (i = 0; i < cItems; i++) {
				if (oUploadCollection.aItems[i]._status === "uploading") {
					oUploadCollection.aItems[i]._percentUploaded = 100;
					oUploadCollection.aItems[i]._status = oUploadCollection._displayStatus;
					oUploadCollection._oItemToUpdate = null;
					break;
				}
			}
			if (oEvent.getParameter("files")[0].status != 201) {
				var response = JSON.parse(oEvent.getParameter("files")[0].responseRaw);
				MessageToast.show(response.message);
			}
			oUploadCollection.getBinding("items").refresh();
			this.loadAttachments(oContextData);
		},

		formatUploadUrl: function (workflowFileUploadId) {
			var docServieBaseUrl = this._getDocServiceRuntimeBaseURL();
			return docServieBaseUrl + "/WorkflowManagement/HarmonyPresalesRequests/" + workflowFileUploadId + "/"
		},
		formatFileUploadUrl:function(oModelData){	
			var docServieBaseUrl = this._getDocServiceRuntimeBaseURL();
			return docServieBaseUrl + "/WorkflowManagement/HarmonyPresalesRequests/" + oModelData.workflowFileUploadId + "/"
		},

		// attributes formatting functions
		formatTimestampToDate: function (timestamp) {
			var oFormat = DateFormat.getDateTimeInstance();
			return oFormat.format(new Date(timestamp));
		},

		formatFileLength: function (fileSizeInBytes) {
			var i = -1;
			var byteUnits = [' kB', ' MB', ' GB', ' TB', 'PB', 'EB', 'ZB', 'YB'];
			do {
				fileSizeInBytes = fileSizeInBytes / 1024;
				i++;
			} while (fileSizeInBytes > 1024);

			return Math.max(fileSizeInBytes, 0.1).toFixed(1) + byteUnits[i];
		},

		formatDownloadUrl: function (objectId) {
			var oUploadCollection = this.byId("UploadCollectionMrq");
			var sAttachmentsUploadURL = oUploadCollection.getUploadUrl();

			return sAttachmentsUploadURL + "?objectId=" + objectId + "&cmisselector=content";
		},

		// delete document from temp folder based on users' input
		onDeletePressed: function (oEvent) {
			//var sAttachmentsUploadURL = this.byId("UploadCollectionMrq").getUploadUrl();
			var oContextData = oEvent.getSource().getBindingContext("multiReqModel").getObject();
			var sAttachmentsUploadURL = this.formatFileUploadUrl(oContextData);
			var item = oEvent.getSource().getBindingContext("attachmentsModel").getModel("attachmentsModel")
				.getProperty(oEvent.getSource().getBindingContext("attachmentsModel").getPath());
			var objectId = item.object.succinctProperties["cmis:objectId"];
			var fileName = item.object.succinctProperties["cmis:name"];

			var oThisController = this;

			var oFormData = new window.FormData();
			oFormData.append("cmisAction", "delete");
			oFormData.append("objectId", objectId);

			var oSettings = {
				"url": sAttachmentsUploadURL,
				"method": "POST",
				"async": false,
				"data": oFormData,
				"cache": false,
				"contentType": false,
				"processData": false,
				"headers": {
					'X-CSRF-Token': token
				}
			};

			$.ajax(oSettings)
				.done(function (results) {
					MessageToast.show("File '" + fileName + "' is deleted");
				})
				.fail(function (err) {
					if (err !== undefined) {
						var oErrorResponse = err.responseText;
						MessageToast.show(oErrorResponse, {
							duration: 6000
						});
					} else {
						MessageToast.show(oThisController.getMessage("UNKNOWN_ERROR"));
					}
				});

			this.loadAttachments(oContextData);

		},

		_getRuntimeBaseURL: function () {
			var appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
			var appPath = appId.replaceAll(".", "/");
			var appModulePath = sap.ui.require.toUrl(appPath);
			return appModulePath;
		},

		_getWorkflowRuntimeBaseURL: function () {
			return this._getRuntimeBaseURL() + "/workflowruntime/v1";
		},

		_getDocServiceRuntimeBaseURL: function () {
			return this._getRuntimeBaseURL() + "/docservice";
		},

		_getConstantsBaseURL: function () {
			return this._getRuntimeBaseURL() + "/resources/req-area-api-/Parameter";
		},
  
				onSupportlinkpress: function () {
			var aConstants = this.getView().getModel("ConstantsAPIData").getData().value;
			aConstants.forEach(function (item) {
				if (item.Type_desc === "supporturl" && item.Operational_Status) {
					sap.m.URLHelper.redirect(item.Value, true);
					return;
				}
			});
		},

		/* Start of Code for CurrentTask Instance ID Update  */
		updateCurrentInstance: function () {
			var WfExt_data = {};
				var URL = this._getRuntimeBaseURL() + "/resources/wf/WfInstance";
				var oModelData = this.getView().getModel("multiReqModel").getData().subcontext[0];
				WfExt_data.instance_GUID = this.getView().getModel("taskInstanceModel").getProperty("/workflowInstanceId");
				if(oModelData.isRework){
					WfExt_data.parentInstance_GUID = oModelData.parentInstanceID;
				}else{
					WfExt_data.parentInstance_GUID = this.getView().getModel("taskInstanceModel").getProperty("/workflowInstanceId");
				}
				const instGuid = `(instance_GUID='${WfExt_data.instance_GUID}',parentInstance_GUID='${WfExt_data.parentInstance_GUID}')`
				let that = this;
				WfExt_data.currentTaskInstanceID = this.getView().getModel("taskInstanceModel").getProperty("/id");
				WfExt_data.currentTaskURL = window.location.href;
				// WfExt_data.submitPageUserTaskID = this.getView().getModel("taskInstanceModel").getProperty("/id");
				//update OrgId,OrgType,RequestType for older tasks
				
				// if (typeof (oModelData["SalesOrgID"]) === "string") {
					// var sOrgID = this._getOrgIDnumber(oModelData["SalesOrgID"], "SORG");
					// WfExt_data.orgID = sOrgID;
					// WfExt_data.orgID = oModelData["SalesOrgID"];
					// WfExt_data.orgType = "SORG";
				// }	
				$.ajax({
					url: URL,
					type: "GET",
					async: true,
					beforeSend: function (xhr) {
						xhr.setRequestHeader("X-CSRF-Token", "Fetch");
					},
					complete: function (xhr) {
						token = xhr.getResponseHeader("X-CSRF-Token");
						var oSettings = {
							"url": URL + instGuid,
							"method": "PATCH",
							"async": false,
							"data": JSON.stringify(WfExt_data),
							"headers": {
								'X-CSRF-Token': token
							},
							"contentType": "application/json",
						};
						$.ajax(oSettings)
							.done(function (results) {
								if (that.getModel("multiReqModel").getData().subcontext[0].isRework && typeof that.getModel("multiReqModel").getData().subcontext[0].RequestID !== "object" && typeof results === "object") {
									if (results.refID) {
										that.getModel("multiReqModel").setProperty("/subcontext/0/updatedRefId", results.refID)
									}
								}
							})
							.fail(function (err) {
								MessageBox.error("Current user Instance ID update failed!");
							});
					}
				});
		},
		/* End of Code for CurrentTask Instance ID Update  */
		onClickResourceProfileDialog: function (oEvent) {
			if (!this._resourceProfilePopover) {
				this._resourceProfilePopover = sap.ui.xmlfragment("com.sap.bpm.RequestPresalesSupport.fragments.ResourceProfileSearchPopover", this);
				this.getView().addDependent(this._resourceProfilePopover);
			}
			this.getResProfileDetails();
			this._resourceProfilePopover.openBy(oEvent.getSource());
		},
		getResProfileDetails: function (iIndex) {
			const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
		const aResProfile =this.getView().getModel("multiReqModel").getData().subcontext[iIndex].aResourceProfileApprovers.ResourceProfileDetails;
				let sSolutionAreaDesc;
				const that = this;
				const descStringBAindustry = aResProfile.BAIndustries.map(function (obj) {
					return obj.Desc;
				}).join(',');
				if (aResProfile.SolutionAreas) {
					if (aResProfile.SolutionAreas.length) {
						 sSolutionAreaDesc = aResProfile.SolutionAreas.map(function (obj) {
							return obj.soln_name;
						}).join(',');
					}
				}else{
					sSolutionAreaDesc = "";
				}
				const descPC = this.getView().getModel("multiReqModel").getData().subcontext[0].selectedProfitCenter[0].SelectedDesc;
				let listItems = [];
				const sProfitCenterI18n = i18nModel.getText("profitCenter");
				const sSLAi18n = i18nModel.getText("solutionArea");
				const sRoleAreaI18n = i18nModel.getText("roleAreaPrimary");
				const sRoleI18n = i18nModel.getText("rolePrimary");
				const sBAIi18n = i18nModel.getText("businessAreaIndustryPrimary");
				let data = [
					{ Name: sProfitCenterI18n, Desc: descPC },
					{ Name: sRoleAreaI18n, Desc: aResProfile.Role_GUID.RoleAreaDesc },
					{ Name: sSLAi18n, Desc: sSolutionAreaDesc },
					{ Name: sBAIi18n, Desc: descStringBAindustry }
				];
				if(this.getView().getModel("multiReqModel").getData().subcontext[iIndex].aResourceProfileApprovers.ResourceProfileDetails.SelectedRole){
					let sRoleDesc; 
					if (that.getView().getModel("multiReqModel").getData().subcontext[iIndex].aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RolesData.length > 1) {
						sRoleDesc = that.getView().getModel("multiReqModel").getData().subcontext[iIndex].aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RolesData.map(function (obj) {
						  return obj.RoleDesc;
					  }).join(',');
				  }else{
					  sRoleDesc =  that.getView().getModel("multiReqModel").getData().subcontext[iIndex].aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.Desc;
				  }
					 data = [
						{ Name: sProfitCenterI18n, Desc: descPC },
						{ Name: sRoleAreaI18n, Desc: aResProfile.Role_GUID.RoleAreaDesc },
						{ Name: sRoleI18n, Desc: sRoleDesc },
						{ Name: sSLAi18n, Desc: sSolutionAreaDesc },
						{ Name: sBAIi18n, Desc: descStringBAindustry }
				];
				}
				data.forEach(function (item) {
					if (item.Desc) {
						let listItem = {
							Name: item.Name,
							Desc: item.Desc
						};
						listItems.push(listItem);
					}
				});
				let oModelResPr = new sap.ui.model.json.JSONModel();
				oModelResPr.setData(
					listItems
				);
 
				this.getView().setModel(oModelResPr, "ResProfileModel");
		},
		onChangeLengthValidation: function (oEvent) {
			const oInput = oEvent.getSource();
			if (oEvent.getParameter("value") && oEvent.getParameter("value").length < 5000) {
				oInput.setProperty("valueState", "None");
			}
			if(oEvent.getParameter("value").length > 5000){
				oInput.setProperty("valueStateText", this.i18nModel.getText("FIELD_EXCEED_TEXT"));
			}
			this._setUnsavedData();
		},
		onSaveDraft:function(){
			const oNavContainer = this.getView().byId("idNavContainerMrq");
			const currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
			const iIndex = Number(currentPageId.slice(-1));
			const oContextData = this.getView().getModel("multiReqModel").getData().subcontext[iIndex];
			//remove unsaved data after save draft
			for (let i = 0; i < this.unSavedData.length; i++) {
				if (this.unSavedData[i].iIndex === iIndex) {
					this.unSavedData.splice(i, 1)
				}
			}
			//validate form fields before save draft
			this._validateFormFields(oContextData,true);	

			
		},
		_onSaveDraft:function(){
			this.getView().setBusy(true);
			const oNavContainer = this.getView().byId("idNavContainerMrq");
			const currentPageId = oNavContainer._pageStack[oNavContainer._pageStack.length - 1].id;
			const iIndex = Number(currentPageId.slice(-1));
			const oContextData = this.getView().getModel("multiReqModel").getData().subcontext[iIndex];
			const oRequestDetails = this._formRequestDetails(oContextData);
			const sInstanceID = this.getView().getModel("taskInstanceModel").getProperty("/workflowInstanceId");
			const sMilliSeconds = new Date().getUTCMilliseconds();
			const sTabId = iIndex + 1;
			models.getSaveDraftFormDetails(sInstanceID,this.fnSuccessCallbackGetDraft,this,true)
			const oDraftModel = this.getModel("draftTable").getData();
			const aDraftTable =  oDraftModel.filter((draft) => draft.tabID ===  sTabId.toString());	
			const sSearchGuid = aDraftTable.length ? aDraftTable[0].instanceDF_GUID : `${sInstanceID}${sMilliSeconds}${sTabId}`;
			const that = this;
			if (!that.requestDraftUrls) {
				that.requestDraftUrls = [];
			} else {
                that.requestDraftUrls = [...new Set(that.requestDraftUrls)];
			}

			if(aDraftTable.length){
			
			}
			//Post parent constant table
			if (!oDraftModel.length) {
				const oDF_WFInsParentPayload = {};
				oDF_WFInsParentPayload.parentInstance_GUID = sInstanceID ? sInstanceID : "";
				oDF_WFInsParentPayload.refID = oContextData.UT_refID;
				oDF_WFInsParentPayload.orgID = oContextData.OrgID ? oContextData.OrgID : "";
				oDF_WFInsParentPayload.orgType = oContextData.OrgType ? oContextData.OrgType : "";
				oDF_WFInsParentPayload.reqTypeID = oContextData.RequestTypeValue ? oContextData.RequestTypeValue.ID : "";
				oDF_WFInsParentPayload.OpportunityID = oContextData.opportunityId ? oContextData.opportunityId : "";
				oDF_WFInsParentPayload.opportunityDesc = oContextData.Opp_Desc ? oContextData.Opp_Desc : "";
				oDF_WFInsParentPayload.Account_ID = oContextData.accountId ? oContextData.accountId : "",
					oDF_WFInsParentPayload.Account_name = oContextData.accountName ? oContextData.accountName : "",
					oDF_WFInsParentPayload.SystemID = oContextData.systemId ? oContextData.systemId : "";
				oDF_WFInsParentPayload.industryName = oContextData.IndustryName ? oContextData.IndustryName : "";
				oDF_WFInsParentPayload.pE_Name = oContextData.PE_Name ? oContextData.PE_Name : "";
				oDF_WFInsParentPayload.ExtSystemsUrl = oContextData.extSystemsUrls ? oContextData.extSystemsUrls.harmony : "";
				that.requestDraftUrls.push(`/DF_WFIns_Parent(parentInstance_GUID='${oDF_WFInsParentPayload.parentInstance_GUID}')`);
				models.postSaveDraftFormDetails(this, oDF_WFInsParentPayload, "DF_WFIns_Parent", "POST");
			}

			//Post main table
			const oDF_WFInsPayload = this._formDF_WFInsPayload(oContextData,oRequestDetails,iIndex,sSearchGuid);
			const sMethod = aDraftTable.length ? "PATCH":"POST";
			that.requestDraftUrls.push(`/DF_WFIns(instanceDF_GUID='${oDF_WFInsPayload.instanceDF_GUID}',parentInstance_GUID='${oDF_WFInsPayload.parentInstance_GUID}')`);
			const sPostUrl = (sMethod === "POST") ? "DF_WFIns" : `DF_WFIns(instanceDF_GUID='${oDF_WFInsPayload.instanceDF_GUID}',parentInstance_GUID='${oDF_WFInsPayload.parentInstance_GUID}')`;
			models.postSaveDraftFormDetails(this, oDF_WFInsPayload,sPostUrl,sMethod);
		},
		_formDF_WFInsPayload:function(oContextData,oRequestDetails,iIndex,sSearchGuid){
			const now = new Date();
			const sCurrentDate = now.toISOString().split('T')[0];
			const sCurrentTime = now.toISOString().split('T')[1].replace('Z', '');
			const sCreationDate =  this.getModel("multiReqModel").getData().subcontext[0].DBCall.WfInstanceResponse.responses[0].body.dtCreation_tdate;
			const sCreationTime =  this.getModel("multiReqModel").getData().subcontext[0].DBCall.WfInstanceResponse.responses[0].body.dtCreation_ttime;
			const sInstanceID = this.getView().getModel("taskInstanceModel").getProperty("/workflowInstanceId");
			const sTabId = iIndex + 1;
			const oFormActionsModelData = this.getView().getModel("formActionsConfigModel").getData();
			const sDecisionId = oFormActionsModelData.iddraft[0].ID;
			//language
			const sLanguageKey = oRequestDetails.languageKey;
			const aLanguage = []; 
			if (oRequestDetails.isMeetingPlanned && sLanguageKey) {
				const aLanguageKeys = sLanguageKey.split(";");
				aLanguageKeys.forEach(function (key) {
					const oDF_ReqForm_LanguagePayload = {
						"languageID": key.trim()

					};
					aLanguage.push(oDF_ReqForm_LanguagePayload);
				});
			}
			//support type
			const aSupportType = [];
			const sSupportKey = oRequestDetails.supportTypeKey;
			if (oRequestDetails.isMeetingPlanned && sSupportKey) {
				const aSupportKeys = sSupportKey.split(";");
				aSupportKeys.forEach(function (key) {
					const oDF_ReqForm_SupportTypePayload = {
						"supportTypeID": key.trim()
					};
					aSupportType.push(oDF_ReqForm_SupportTypePayload);
				});
			}

			//Participant type
			const aPartcpType = [];
			const sParticipantTypeKey = oRequestDetails.participantTypeKey;
			if (oRequestDetails.isMeetingPlanned && sParticipantTypeKey) {
				const aParticipantTypeKeys = sParticipantTypeKey.split(";")
				aParticipantTypeKeys.forEach(function (key) {
					const oDF_ReqForm_PartcpTypePayload = {
						"participantTypeID": key.trim()
					};
					aPartcpType.push(oDF_ReqForm_PartcpTypePayload);
				});
			}

			//Involved sap parties
			const aInvSAP_Party = [];
			const sInvSap = oRequestDetails.involvedPartiesKey;
			if (oRequestDetails.isMeetingPlanned && sInvSap) {
				const aInvSapKeys = sInvSap.split(";");
				aInvSapKeys.forEach(function (key) {
					const oDF_ReqForm_InvSAP_PartyPayload = {
						"involved_SAP_PartiesID": key.trim()
					};
					aInvSAP_Party.push(oDF_ReqForm_InvSAP_PartyPayload);

				});
			}
			//attachmentUrls
			const aWfInsUrls = [];
			if (!oRequestDetails.attachmentUrls[0]) {
				oRequestDetails.attachmentUrls = [{
					"urlName": "",
					"url": "",
					"urlDelete": false,
					"urlNameValueState": "None",
					"urlValueStateText": "",
					"urlValueState": "None"
				}];
			}
			if (oRequestDetails.attachmentUrls) {
				oRequestDetails.attachmentUrls.forEach(function (item, iIndex) {
					if (!item.url && !item.urlName) {
						oRequestDetails.attachmentUrls.splice(iIndex, 1);
					}
				});
				const aAttachmentUrls = oRequestDetails.attachmentUrls;
				for (let i = 0; i < aAttachmentUrls.length; i++) {
					let oPayload = {
						"urlCountID": i + 1,
						"tabID": sTabId.toString(),
						"url": aAttachmentUrls[i].url,
						"urlName": aAttachmentUrls[i].urlName,
					}
					aWfInsUrls.push(oPayload);
				}
			}
			return {
				instanceDF_GUID: sSearchGuid,
				tabID:sTabId.toString(),
				parentInstance_GUID: sInstanceID,
				technicalStateID: this.getModel("multiReqModel").getData().subcontext[0].DBCall.WfInstanceResponse.responses[0].body.technicalStateID,
				reqAreaGUID: oContextData.reqAreaGUID ? oContextData.reqAreaGUID : "",
				create_Date: sCreationDate,
				create_Time: sCreationTime,
				change_Date: sCurrentDate,
				change_Time: sCurrentTime,
				decisionID: sDecisionId,
				need_from_CustAdvisory: oRequestDetails.typeOfSupport,
				cust_asked_forMeeting: oRequestDetails.isMeetingPlanned ?"X":"",
				meetingTypeID: oRequestDetails.isMeetingPlanned? oRequestDetails.meetingTypeKey:"",
				comments: oContextData.comments,
				solution_Models: oRequestDetails.solutionsInScope,
				custAdvisory_Resource: oRequestDetails.preferredPresales,
				Meeting_Goal: oRequestDetails.isMeetingPlanned?oContextData.meetingGoal:"",
				meetingLocation:oRequestDetails.isMeetingPlanned? oRequestDetails.meetingLocation:"",
				meetingDate: oRequestDetails.isMeetingPlanned?oRequestDetails.meetingDate:"",
				meetingTime:oRequestDetails.isMeetingPlanned? oRequestDetails.meetingTime:"",
				involved_SAP_Parties_Name: oRequestDetails.isMeetingPlanned? oRequestDetails.involvedPartiesNames:"",
				Participants_Type_Details:  oRequestDetails.isMeetingPlanned ?oRequestDetails.participantTypeDetails:"",
				language:aLanguage,
				SupportType:aSupportType,
				PartcpType:aPartcpType,
				InvSAP_Party:aInvSAP_Party,
				WfinsURL:aWfInsUrls
			}
		},
		//initialize url model//attachment urls
		_initializeUrls: function (iIndex) {
			//initialize urls model
			//myChaange
			if(this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls){
				if(!this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls[0]){
					this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls = [{
						"urlName": "",
						"url": "",
						"urlDelete": false,
						"urlNameValueState": "None",
						"urlValueStateText":"",
						"urlValueState": "None"
					}];
				}
			}
			if (!this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls && this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].currentStepID === "REQSUB") {
				this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls = [];
				this.onAddNewUrl(false, iIndex);
			} else if (this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls) {
				const oContextUrls = this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls;
				oContextUrls.forEach(function (obj, iIndex) {
					const oFinalUrlContext = {

					}
					//initialize assignment properties
					oFinalUrlContext.urlNameValueState = "None";
					oFinalUrlContext.urlValueState = "None";
					oFinalUrlContext.urlName = obj.urlName;
					oFinalUrlContext.url = obj.url;
				});
				this._setUrlDeleBtn(oContextUrls);
			} else {
				this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls = [];
			}

		},
		//add new url
		onAddNewUrl: function (evt, iIndex) {
			if (evt) {
				const oBindingContext = evt.getSource().getBindingContext("multiReqModel").getPath();
				const sIndex = oBindingContext.split('/subcontext/')[1];
				iIndex = Number(sIndex);
			}
			const oModelData = this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls;
			const oUrl = {
				"urlName": "",
				"url": "",
				"urlDelete": true,
				"urlNameValueState": "None",
				"urlValueStateText": "",
				"urlValueState": "None"
			}
			oModelData.push(oUrl);
			this._setUrlDeleBtn(oModelData);
			this.getView().getModel("multiReqModel").refresh(true);
		},
		_setUrlDeleBtn: function (oModelData) {
			if (oModelData.length === 1) {
				oModelData[0].urlDelete = false;
			} else {
				oModelData.forEach(function (val) {
					val.urlDelete = true;
				});
			}
		},
		//delete attachment url
		onDeleteUrl: function (evt) {
			const oContextPath = evt.getSource().getBindingContext("multiReqModel").getPath();
			const oUrlObj = evt.getSource().getBindingContext("multiReqModel").getObject();
			const iIndex = Number(oContextPath.split('/')[2]);
			const oModelData = this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls;
			const filteredArray = oModelData.filter(e => e !== oUrlObj);
			if (filteredArray.length === 1) {
				filteredArray[0].urlDelete = false;
			} else {
				filteredArray.forEach(function (val) {
					val.urlDelete = true;
				});
			}
			this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls = filteredArray;
			this.getView().getModel("multiReqModel").refresh(true);
		},
		//live change attachment url input
		onUrlChange: function (evt) {
			const sValue = evt.getParameter("value");
			const oContextPath = evt.getSource().getBindingContext("multiReqModel").getPath();
			const oUrlObj = evt.getSource().getBindingContext("multiReqModel").getObject();
			const iIndex = Number(oContextPath.split('/')[2]);
			const iUrlObjIndex = Number(oContextPath.split('/')[4]);
			const oModelData = this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls;
			const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			let bUrlDuplicate;
			oUrlObj.url = sValue;
			oModelData.forEach(function (item, index) {
				if (index !== iUrlObjIndex && oUrlObj.url === item.url) {
					bUrlDuplicate = true;
				}
			});
			//regexp for checking valid url
			const bValidUrl = new RegExp(
                /((([A-Za-z]{3,9}:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)/
 
              ).test(oUrlObj.url);
			if (sValue && !bValidUrl) {
				//invalid url
				oUrlObj.urlValueState = "Error";
				oUrlObj.urlValueStateText = i18nModel.getText("INVALID_URL")
			} else if (sValue && bUrlDuplicate) {
				//duplicate url
				oUrlObj.urlValueState = "Error";
				oUrlObj.urlValueStateText = i18nModel.getText("URL_ALREADY_EXIST")
			} else {
				oUrlObj.urlValueState = "None";
			}
			this.getView().getModel("multiReqModel").refresh();
		},
		//remove the empty url objects
		_removeEmptyUrl: function (iIndex) {
			const i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			const oModelData = this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls;
			const isAllUrlEmpty = oModelData.every(v => v.url === "");
			if (!isAllUrlEmpty) {
				const aFinalUrls = oModelData.filter(item => item.url !== "");
				this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls = aFinalUrls;
			} else {
				this.getView().getModel("multiReqModel").getProperty("/subcontext")[iIndex].attachmentUrls.length = 1;
			}
			this.getView().getModel("multiReqModel").refresh(true);
			const aDuplicates = oModelData.filter((item, index) => oModelData.some((elem, idx) => elem.url === item.url && idx !== index));
			if (!aDuplicates.length) {
				oModelData.forEach(function (item) {
					if (item.urlValueStateText === i18nModel.getText("URL_ALREADY_EXIST")) {
						item.urlValueState = "None"
					}
				})
			}
			this.getView().getModel("multiReqModel").refresh(true);
		},
		onPreviewUrl: function (evt) {
			const oUrlObj = evt.getSource().getBindingContext("multiReqModel").getObject();
			const URLHelper = mLibrary.URLHelper;
			if (oUrlObj.url && oUrlObj.urlValueState === "None") {
				URLHelper.redirect(oUrlObj.url, true);
			}
		},
		iconTabHeaderText: function(sReqArea, sSearchField , isResProfile){
			if(isResProfile){
				return sSearchField;
			}else{
				return sReqArea;
			}
		},
		getOppState: function(sCurrstate){
			const oppState = {
				   "E0001": "In Process",
				"E0002": "Discontinued",
				"E0003": "Won",
				"E0004": "Booked",
				"E0005": "Lost",
				"E0007" :"New",
				"E0014": "Discontinuation check"
			};
		   
			function getFormattedText(sCurrstate) {
				return oppState[sCurrstate] || sCurrstate;
			}
			return (getFormattedText(sCurrstate));
		   
		},
		getCurrentPhase: function(sCurrPhase){
			const salesPhase = {
				"ZP1": "F - Recognize",
				"ZP2": "E - Consider",
				"ZP3": "D - Evaluate",
				"ZP4": "C - Select",
				"ZP5": "B - Negotiate",
				"ZP6": "A - Purchase",
				"ZM1": "D - Evaluate",
				"ZM2": "C - Select",
				"ZM3": "B - Negotiate",
				"ZM4": "A - Purchase",
				"ZM5": "E - Consider",
				"ZF1": "F - Recognize (FS)",
				"ZF2": "E - Consider (FS)",
				"ZF3": "D - Evaluate (FS)",
				"ZF4": "C - Select (FS)",
				"ZF5": "B - Negotiate (FS)",
				"ZF6": "A - Purchase (FS)"
			};
		   
			function getFormattedText(sCurrPhase) {
				return salesPhase[sCurrPhase] || sCurrPhase;
			}
			return (getFormattedText(sCurrPhase));
		   
		},
		/* format date (Ex: date from  '/Date(1650326400000)/' format to 'Mar 20, 2022')
		* @function _setDateFormat
		* @public
		* @param {object} date - String which holds date value
		* @return {String} formatted date
		**/
	   _setDateFormat:function(date){
		   if(date){
			 return new Date(parseInt(date.substr(6))).toLocaleDateString('en-US', {
				   year: 'numeric',
				   month: 'long',
				   day: 'numeric'
				 });
		   }else{
			   return ""
		   }

	   }

	});
});