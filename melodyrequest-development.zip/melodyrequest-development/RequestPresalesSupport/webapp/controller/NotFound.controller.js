sap.ui.define([
   "sap/ui/core/mvc/Controller"

], function (Controller) {
   "use strict";
   return Controller.extend("com.sap.bpm.RequestPresalesSupport.controller.NotFound", {

      onInit: function () {
      },

   });
});