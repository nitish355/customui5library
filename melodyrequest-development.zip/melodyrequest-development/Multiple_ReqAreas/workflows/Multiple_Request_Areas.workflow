{
	"contents": {
		"e9c792ae-ec48-4777-ad5b-154a1260872a": {
			"classDefinition": "com.sap.bpm.wfs.Model",
			"id": "Multiple_Request_Areas",
			"subject": "Customer Advisory Multiple Requests for Opportunity ${context.opportunityId}",
			"businessKey": "${context.opportunityId}",
			"name": "Multiple_Request_Areas",
			"documentation": "Multiple Request Areas",
			"lastIds": "62d7f4ed-4063-4c44-af8b-39050bd44926",
			"events": {
				"11a9b5ee-17c0-4159-9bbf-454dcfdcd5c3": {
					"name": "StartEvent1"
				},
				"2798f4e7-bc42-4fad-a248-159095a2f40a": {
					"name": "EndEvent1"
				},
				"bb67abb2-ff1f-425e-8429-e7cd3415b384": {
					"name": "EndEvent2"
				}
			},
			"activities": {
				"c5e8caa3-ba01-4ad1-978a-d1f84601cb5a": {
					"name": "Prepare Payload to trigger WF"
				},
				"5dcab437-a293-460d-a700-e4f688ebc292": {
					"name": "Trigger Workflow"
				},
				"82529b58-522a-4417-bbe3-c3671778e0e0": {
					"name": "Check ReqArea Count"
				},
				"99730619-9b67-4a66-bbb1-f3ad5e650493": {
					"name": "Requestor Form"
				},
				"8fc0a239-d5a7-400b-a399-5cf22ed0b937": {
					"name": "Decision"
				},
				"b0f1087b-f809-4427-a417-0365c63fff78": {
					"name": "Process Task Termination"
				},
				"fe5202b5-b8be-4624-a11e-9fc33f5bf103": {
					"name": "Process Initialise Request"
				},
				"8003d764-0e52-4230-b538-f87a3a403097": {
					"name": "Create WFInstance"
				},
				"818fdf7b-ef8f-45ad-8c32-7e04f19ac6b5": {
					"name": "Check WFInstance Create"
				},
				"bb8dcde6-7715-4d54-99f5-500c8b6fb2de": {
					"name": "Retry"
				},
				"9f703322-1081-49a3-b319-431a4f293c74": {
					"name": "Process WfInstance Complete Success"
				},
				"b3d35e62-2f49-4f38-bff4-7d06431e4e1f": {
					"name": "ProcessWFInstanceComplete"
				},
				"77a8c74c-8e29-4771-a9a5-8ce70480de6d": {
					"name": "CheckBatchCall"
				},
				"3f15dfcb-725d-456d-ba6f-dc6cf7b693df": {
					"name": "retry?"
				},
				"cbb8932b-2520-4f87-a8ee-fd61ed0a60c9": {
					"name": "Process Task Temination"
				},
				"9e099813-db05-433b-be3f-b607c2cf9c0f": {
					"name": "CaptureDateTime"
				},
				"ec1d0963-aec5-4b64-93d4-d5795df3b9e6": {
					"name": "Get CurrentState Data"
				},
				"89b62786-0371-47ec-bcef-d26afa4b0c95": {
					"name": "Process CurrentState ID"
				},
				"19011fc3-3641-4626-91fc-c42a77afc56f": {
					"name": "Process resource profile Data "
				},
				"f8acbc29-95e5-4e25-b50c-9dbf0ea7c808": {
					"name": "Get Refrence ID"
				},
				"392fb158-4913-458d-aaba-bd9394b5a1f0": {
					"name": "Process Draft Delete Call"
				},
				"c83790fa-9ad8-408f-9d98-fb88d909cd48": {
					"name": "Process Delete Draft Call"
				},
				"d1bf56b1-4bad-469e-9db9-e8b3c95e7ee6": {
					"name": "ExclusiveGateway5"
				}
			},
			"sequenceFlows": {
				"c6b99f32-5fe6-4ab6-b60a-80fba1b9ae0f": {
					"name": "SequenceFlow1"
				},
				"5492ae8a-aab4-4d77-aa94-fe9c466bbfeb": {
					"name": "SequenceFlow2"
				},
				"dabbc9dc-e5f9-4be1-a84e-26752feef631": {
					"name": "SequenceFlow3"
				},
				"10d572d3-a06a-41bf-b3b1-67d4d73d7daa": {
					"name": "Yes"
				},
				"209cf9e0-f178-4369-8314-85af6da4ccd2": {
					"name": "No"
				},
				"d9c2edce-788f-4d8e-b5d7-8643fc1251bb": {
					"name": "SequenceFlow6"
				},
				"9e58d09c-db50-455b-a19c-b53542a6320c": {
					"name": "Submit"
				},
				"d3284938-7a9d-42f5-87f4-a5fc6ba77b3b": {
					"name": "Terminate"
				},
				"cfc8d300-0320-4d90-9d36-4801736f2f6a": {
					"name": "SequenceFlow9"
				},
				"ac2a6991-3cbc-4ff6-9f4f-267289ae3ab8": {
					"name": "SequenceFlow10"
				},
				"8b2eaf63-53f7-47f9-8e54-7515e8dc6809": {
					"name": "SequenceFlow11"
				},
				"1df7a0ed-2930-45e8-a7d1-99012d463577": {
					"name": "SequenceFlow12"
				},
				"825cbff7-8d5d-40db-a19b-556949d49d45": {
					"name": "No"
				},
				"2dbc0445-23b0-4785-9fcf-3049f4971e52": {
					"name": "Yes"
				},
				"7a5244f2-080f-4ebf-a31e-7f6df286dc25": {
					"name": "SequenceFlow15"
				},
				"15a6c6c6-3b04-45eb-a9b0-2926386d8d31": {
					"name": "SequenceFlow16"
				},
				"73c632d7-419d-4006-9475-32781ff21934": {
					"name": "SequenceFlow17"
				},
				"73962fc2-7733-41cd-b8b0-a10f157d1360": {
					"name": "No"
				},
				"827cb222-05af-4e76-8e20-d42a47328139": {
					"name": "Yes"
				},
				"a6dc5040-c8d9-4141-b6c3-13f7db5e4a74": {
					"name": "SequenceFlow21"
				},
				"34ac48bb-0a03-4873-b704-14d6ff2e08c1": {
					"name": "SequenceFlow22"
				},
				"7ea8d1df-7b7c-4799-ad62-8636510d292b": {
					"name": "SequenceFlow23"
				},
				"77601f12-84b3-4782-a16b-fa53337ebc2c": {
					"name": "SequenceFlow24"
				},
				"f3afcce4-69d6-41b6-bcdd-572f22451716": {
					"name": "SequenceFlow25"
				},
				"d49af99c-5c9e-4875-80cf-64b316c5857c": {
					"name": "SequenceFlow29"
				},
				"8cbf65da-7e0e-4ad5-805d-43420a8a9ab2": {
					"name": "SequenceFlow30"
				},
				"28aa9681-7f1b-41ea-a6a3-8bccdcae17e8": {
					"name": "SequenceFlow31"
				},
				"9eb3b33d-ecd5-43a4-96ec-0b4ef02bf494": {
					"name": "Yes"
				},
				"884513b0-649f-423c-a443-613edc236abe": {
					"name": "No"
				}
			},
			"diagrams": {
				"42fa7a2d-c526-4a02-b3ba-49b5168ba644": {}
			}
		},
		"11a9b5ee-17c0-4159-9bbf-454dcfdcd5c3": {
			"classDefinition": "com.sap.bpm.wfs.StartEvent",
			"id": "startevent1",
			"name": "StartEvent1"
		},
		"2798f4e7-bc42-4fad-a248-159095a2f40a": {
			"classDefinition": "com.sap.bpm.wfs.EndEvent",
			"id": "endevent1",
			"name": "EndEvent1"
		},
		"bb67abb2-ff1f-425e-8429-e7cd3415b384": {
			"classDefinition": "com.sap.bpm.wfs.EndEvent",
			"id": "endevent2",
			"name": "EndEvent2"
		},
		"c5e8caa3-ba01-4ad1-978a-d1f84601cb5a": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Multiple_Request_Areas/PreparePayloadToTriggerWF.js",
			"id": "scripttask1",
			"name": "Prepare Payload to trigger WF"
		},
		"5dcab437-a293-460d-a700-e4f688ebc292": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "WF_PresalesRequestApproval",
			"destinationSource": "consumer",
			"httpMethod": "POST",
			"requestVariable": "${context.wftrigger.Request}",
			"responseVariable": "${context.wftrigger.Response}",
			"id": "servicetask1",
			"name": "Trigger Workflow"
		},
		"82529b58-522a-4417-bbe3-c3671778e0e0": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway1",
			"name": "Check ReqArea Count",
			"default": "209cf9e0-f178-4369-8314-85af6da4ccd2"
		},
		"99730619-9b67-4a66-bbb1-f3ad5e650493": {
			"classDefinition": "com.sap.bpm.wfs.UserTask",
			"subject": "Request Support for ${context.accNameFormatted} ${context.Approval_subject}",
			"priority": "MEDIUM",
			"isHiddenInLogForParticipant": false,
			"supportsForward": false,
			"userInterface": "sapui5://dealsupportapp.comsapbpmRequestPresalesSupport/com.sap.bpm.RequestPresalesSupport",
			"recipientUsers": "${context.requesterDetails.id}",
			"id": "usertask1",
			"name": "Requestor Form"
		},
		"8fc0a239-d5a7-400b-a399-5cf22ed0b937": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway2",
			"name": "Decision",
			"default": "9e58d09c-db50-455b-a19c-b53542a6320c"
		},
		"b0f1087b-f809-4427-a417-0365c63fff78": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Multiple_Request_Areas/ProcessTaskTermination.js",
			"id": "scripttask2",
			"name": "Process Task Termination"
		},
		"fe5202b5-b8be-4624-a11e-9fc33f5bf103": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Multiple_Request_Areas/ProcessInitialiseWFRequest.js",
			"id": "scripttask3",
			"name": "Process Initialise Request"
		},
		"8003d764-0e52-4230-b538-f87a3a403097": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.DBCall.WfInstanceRequest}",
			"responseVariable": "${context.DBCall.WfInstanceResponse}",
			"id": "servicetask2",
			"name": "Create WFInstance"
		},
		"818fdf7b-ef8f-45ad-8c32-7e04f19ac6b5": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Multiple_Request_Areas/CheckWFInstanceCreation.js",
			"id": "scripttask4",
			"name": "Check WFInstance Create"
		},
		"bb8dcde6-7715-4d54-99f5-500c8b6fb2de": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway3",
			"name": "Retry",
			"default": "825cbff7-8d5d-40db-a19b-556949d49d45"
		},
		"9f703322-1081-49a3-b319-431a4f293c74": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Multiple_Request_Areas/ProcessWFInstanceComplete.js",
			"id": "scripttask5",
			"name": "Process WfInstance Complete Success"
		},
		"b3d35e62-2f49-4f38-bff4-7d06431e4e1f": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.DBCall.Request}",
			"responseVariable": "${context.DBCall.Response}",
			"id": "servicetask3",
			"name": "ProcessWFInstanceComplete"
		},
		"77a8c74c-8e29-4771-a9a5-8ce70480de6d": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Multiple_Request_Areas/CheckBatchCall.js",
			"id": "scripttask6",
			"name": "CheckBatchCall"
		},
		"3f15dfcb-725d-456d-ba6f-dc6cf7b693df": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway4",
			"name": "retry?",
			"default": "73962fc2-7733-41cd-b8b0-a10f157d1360"
		},
		"cbb8932b-2520-4f87-a8ee-fd61ed0a60c9": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.DBCall.Request}",
			"responseVariable": "${context.DBCall.Response}",
			"id": "servicetask4",
			"name": "Process Task Temination"
		},
		"9e099813-db05-433b-be3f-b607c2cf9c0f": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Multiple_Request_Areas/CaptureDateTime.js",
			"id": "scripttask8",
			"name": "CaptureDateTime"
		},
		"ec1d0963-aec5-4b64-93d4-d5795df3b9e6": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "resources/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.CurrentStateDBCall.Request}",
			"responseVariable": "${context.CurrentStateDBCall.Response}",
			"id": "servicetask5",
			"name": "Get CurrentState Data"
		},
		"89b62786-0371-47ec-bcef-d26afa4b0c95": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Multiple_Request_Areas/ProcessCurrentStateIDRequest.js",
			"id": "scripttask9",
			"name": "Process CurrentState ID"
		},
		"19011fc3-3641-4626-91fc-c42a77afc56f": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Multiple_Request_Areas/ProcessResourceProfileData .js",
			"id": "scripttask10",
			"name": "Process resource profile Data "
		},
		"f8acbc29-95e5-4e25-b50c-9dbf0ea7c808": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "Refrence_Id/getId()",
			"httpMethod": "GET",
			"responseVariable": "${context.RefrenceID.Response}",
			"id": "servicetask7",
			"name": "Get Refrence ID"
		},
		"392fb158-4913-458d-aaba-bd9394b5a1f0": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/Multiple_Request_Areas/ProcessDraftDeleteCall.js",
			"id": "scripttask12",
			"name": "Process Draft Delete Call"
		},
		"c83790fa-9ad8-408f-9d98-fb88d909cd48": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/ore-api-/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.DelDraft.Request}",
			"responseVariable": "${context.DelDraft.Response}",
			"id": "servicetask8",
			"name": "Process Delete Draft Call"
		},
		"d1bf56b1-4bad-469e-9db9-e8b3c95e7ee6": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway5",
			"name": "ExclusiveGateway5",
			"default": "884513b0-649f-423c-a443-613edc236abe"
		},
		"c6b99f32-5fe6-4ab6-b60a-80fba1b9ae0f": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow1",
			"name": "SequenceFlow1",
			"sourceRef": "11a9b5ee-17c0-4159-9bbf-454dcfdcd5c3",
			"targetRef": "f8acbc29-95e5-4e25-b50c-9dbf0ea7c808"
		},
		"5492ae8a-aab4-4d77-aa94-fe9c466bbfeb": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow2",
			"name": "SequenceFlow2",
			"sourceRef": "c5e8caa3-ba01-4ad1-978a-d1f84601cb5a",
			"targetRef": "5dcab437-a293-460d-a700-e4f688ebc292"
		},
		"dabbc9dc-e5f9-4be1-a84e-26752feef631": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow3",
			"name": "SequenceFlow3",
			"sourceRef": "5dcab437-a293-460d-a700-e4f688ebc292",
			"targetRef": "82529b58-522a-4417-bbe3-c3671778e0e0"
		},
		"10d572d3-a06a-41bf-b3b1-67d4d73d7daa": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.CountMultiReqArea == context.LenMultiReqArea}",
			"id": "sequenceflow4",
			"name": "Yes",
			"sourceRef": "82529b58-522a-4417-bbe3-c3671778e0e0",
			"targetRef": "9f703322-1081-49a3-b319-431a4f293c74"
		},
		"209cf9e0-f178-4369-8314-85af6da4ccd2": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow5",
			"name": "No",
			"sourceRef": "82529b58-522a-4417-bbe3-c3671778e0e0",
			"targetRef": "c5e8caa3-ba01-4ad1-978a-d1f84601cb5a"
		},
		"d9c2edce-788f-4d8e-b5d7-8643fc1251bb": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow6",
			"name": "SequenceFlow6",
			"sourceRef": "99730619-9b67-4a66-bbb1-f3ad5e650493",
			"targetRef": "392fb158-4913-458d-aaba-bd9394b5a1f0"
		},
		"9e58d09c-db50-455b-a19c-b53542a6320c": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow7",
			"name": "Submit",
			"sourceRef": "8fc0a239-d5a7-400b-a399-5cf22ed0b937",
			"targetRef": "9e099813-db05-433b-be3f-b607c2cf9c0f"
		},
		"d3284938-7a9d-42f5-87f4-a5fc6ba77b3b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.decision == \"Terminate\"}",
			"id": "sequenceflow8",
			"name": "Terminate",
			"sourceRef": "8fc0a239-d5a7-400b-a399-5cf22ed0b937",
			"targetRef": "b0f1087b-f809-4427-a417-0365c63fff78"
		},
		"cfc8d300-0320-4d90-9d36-4801736f2f6a": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow9",
			"name": "SequenceFlow9",
			"sourceRef": "b0f1087b-f809-4427-a417-0365c63fff78",
			"targetRef": "cbb8932b-2520-4f87-a8ee-fd61ed0a60c9"
		},
		"ac2a6991-3cbc-4ff6-9f4f-267289ae3ab8": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow10",
			"name": "SequenceFlow10",
			"sourceRef": "fe5202b5-b8be-4624-a11e-9fc33f5bf103",
			"targetRef": "19011fc3-3641-4626-91fc-c42a77afc56f"
		},
		"8b2eaf63-53f7-47f9-8e54-7515e8dc6809": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow11",
			"name": "SequenceFlow11",
			"sourceRef": "8003d764-0e52-4230-b538-f87a3a403097",
			"targetRef": "818fdf7b-ef8f-45ad-8c32-7e04f19ac6b5"
		},
		"1df7a0ed-2930-45e8-a7d1-99012d463577": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow12",
			"name": "SequenceFlow12",
			"sourceRef": "818fdf7b-ef8f-45ad-8c32-7e04f19ac6b5",
			"targetRef": "bb8dcde6-7715-4d54-99f5-500c8b6fb2de"
		},
		"825cbff7-8d5d-40db-a19b-556949d49d45": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow13",
			"name": "No",
			"sourceRef": "bb8dcde6-7715-4d54-99f5-500c8b6fb2de",
			"targetRef": "99730619-9b67-4a66-bbb1-f3ad5e650493"
		},
		"2dbc0445-23b0-4785-9fcf-3049f4971e52": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.retry}",
			"id": "sequenceflow14",
			"name": "Yes",
			"sourceRef": "bb8dcde6-7715-4d54-99f5-500c8b6fb2de",
			"targetRef": "8003d764-0e52-4230-b538-f87a3a403097"
		},
		"7a5244f2-080f-4ebf-a31e-7f6df286dc25": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow15",
			"name": "SequenceFlow15",
			"sourceRef": "9f703322-1081-49a3-b319-431a4f293c74",
			"targetRef": "b3d35e62-2f49-4f38-bff4-7d06431e4e1f"
		},
		"15a6c6c6-3b04-45eb-a9b0-2926386d8d31": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow16",
			"name": "SequenceFlow16",
			"sourceRef": "b3d35e62-2f49-4f38-bff4-7d06431e4e1f",
			"targetRef": "77a8c74c-8e29-4771-a9a5-8ce70480de6d"
		},
		"73c632d7-419d-4006-9475-32781ff21934": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow17",
			"name": "SequenceFlow17",
			"sourceRef": "77a8c74c-8e29-4771-a9a5-8ce70480de6d",
			"targetRef": "3f15dfcb-725d-456d-ba6f-dc6cf7b693df"
		},
		"73962fc2-7733-41cd-b8b0-a10f157d1360": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow18",
			"name": "No",
			"sourceRef": "3f15dfcb-725d-456d-ba6f-dc6cf7b693df",
			"targetRef": "2798f4e7-bc42-4fad-a248-159095a2f40a"
		},
		"827cb222-05af-4e76-8e20-d42a47328139": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.retry}",
			"id": "sequenceflow19",
			"name": "Yes",
			"sourceRef": "3f15dfcb-725d-456d-ba6f-dc6cf7b693df",
			"targetRef": "b3d35e62-2f49-4f38-bff4-7d06431e4e1f"
		},
		"a6dc5040-c8d9-4141-b6c3-13f7db5e4a74": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow21",
			"name": "SequenceFlow21",
			"sourceRef": "cbb8932b-2520-4f87-a8ee-fd61ed0a60c9",
			"targetRef": "bb67abb2-ff1f-425e-8429-e7cd3415b384"
		},
		"34ac48bb-0a03-4873-b704-14d6ff2e08c1": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow22",
			"name": "SequenceFlow22",
			"sourceRef": "9e099813-db05-433b-be3f-b607c2cf9c0f",
			"targetRef": "c5e8caa3-ba01-4ad1-978a-d1f84601cb5a"
		},
		"7ea8d1df-7b7c-4799-ad62-8636510d292b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow23",
			"name": "SequenceFlow23",
			"sourceRef": "ec1d0963-aec5-4b64-93d4-d5795df3b9e6",
			"targetRef": "fe5202b5-b8be-4624-a11e-9fc33f5bf103"
		},
		"77601f12-84b3-4782-a16b-fa53337ebc2c": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow24",
			"name": "SequenceFlow24",
			"sourceRef": "89b62786-0371-47ec-bcef-d26afa4b0c95",
			"targetRef": "ec1d0963-aec5-4b64-93d4-d5795df3b9e6"
		},
		"f3afcce4-69d6-41b6-bcdd-572f22451716": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow25",
			"name": "SequenceFlow25",
			"sourceRef": "19011fc3-3641-4626-91fc-c42a77afc56f",
			"targetRef": "8003d764-0e52-4230-b538-f87a3a403097"
		},
		"d49af99c-5c9e-4875-80cf-64b316c5857c": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow29",
			"name": "SequenceFlow29",
			"sourceRef": "f8acbc29-95e5-4e25-b50c-9dbf0ea7c808",
			"targetRef": "89b62786-0371-47ec-bcef-d26afa4b0c95"
		},
		"8cbf65da-7e0e-4ad5-805d-43420a8a9ab2": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow30",
			"name": "SequenceFlow30",
			"sourceRef": "392fb158-4913-458d-aaba-bd9394b5a1f0",
			"targetRef": "d1bf56b1-4bad-469e-9db9-e8b3c95e7ee6"
		},
		"28aa9681-7f1b-41ea-a6a3-8bccdcae17e8": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow31",
			"name": "SequenceFlow31",
			"sourceRef": "c83790fa-9ad8-408f-9d98-fb88d909cd48",
			"targetRef": "8fc0a239-d5a7-400b-a399-5cf22ed0b937"
		},
		"9eb3b33d-ecd5-43a4-96ec-0b4ef02bf494": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.delDraft}",
			"id": "sequenceflow32",
			"name": "Yes",
			"sourceRef": "d1bf56b1-4bad-469e-9db9-e8b3c95e7ee6",
			"targetRef": "c83790fa-9ad8-408f-9d98-fb88d909cd48"
		},
		"884513b0-649f-423c-a443-613edc236abe": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow33",
			"name": "No",
			"sourceRef": "d1bf56b1-4bad-469e-9db9-e8b3c95e7ee6",
			"targetRef": "8fc0a239-d5a7-400b-a399-5cf22ed0b937"
		},
		"42fa7a2d-c526-4a02-b3ba-49b5168ba644": {
			"classDefinition": "com.sap.bpm.wfs.ui.Diagram",
			"symbols": {
				"df898b52-91e1-4778-baad-2ad9a261d30e": {},
				"53e54950-7757-4161-82c9-afa7e86cff2c": {},
				"6bb141da-d485-4317-93b8-e17711df4c32": {},
				"8c28d6f5-c3e5-4a11-8ff5-5c3e0819e996": {},
				"414599e8-05eb-4f2e-b953-0e50b7734912": {},
				"6b603939-bac5-4029-b9c0-e74d0437d182": {},
				"216f7e9f-4cc3-452d-a101-6f1993733e46": {},
				"1f27f48f-0972-41ef-8602-3671ca93e260": {},
				"c9983627-d6ea-4e25-85f8-0fc31b20d1ee": {},
				"ca245629-b223-4526-9ab3-5608fe9a2d95": {},
				"da4ac02a-0ce3-48f5-b625-6c51da4e8b05": {},
				"2f649ff2-ce06-44f7-b20b-996ad0aefa56": {},
				"c8a15291-df28-40c5-95d7-1c579964a9b1": {},
				"8614a8bb-a832-4ae4-81b0-b9cb8a949b72": {},
				"bfc686e6-4211-439a-a45f-3838d8a66724": {},
				"686a223a-2fd9-44c7-8cca-ab58dbd54b7b": {},
				"d5e94d21-927a-48e5-a5d0-e75aa6fceebe": {},
				"a06a2503-aca2-4533-8b40-15f1969a0eec": {},
				"0bc1fe4d-171f-4cb0-8be9-eaf99ed4e751": {},
				"4d27b2d8-5ab6-4bb9-8e37-ab9837f4322f": {},
				"d2faeb49-4f09-46be-aac8-4794ae06a8ec": {},
				"768d2723-eb94-4a5c-a048-c169183d41b8": {},
				"8157cce4-f05e-4130-a05e-9e328480c8d0": {},
				"6fe044c0-c958-4222-a34a-978219160a69": {},
				"63c8486a-2cc3-4bd0-a3c4-05b85e7c525d": {},
				"4f34698c-d9b5-4fd6-a3ac-8f27b3501b86": {},
				"9899ab0d-be9f-4d05-adbb-7e417773d576": {},
				"01e5b016-f117-4033-bdb0-42040787b845": {},
				"b9c7ccb1-98f8-448e-97ea-1224b2b67083": {},
				"07e25037-08f5-4759-9374-d600f4713618": {},
				"1a78fd9c-2658-4961-98be-590565892b57": {},
				"e1adc670-1c85-402a-afe7-7ecbafa3433d": {},
				"ceefa2fa-bbb9-43f8-9e8b-e073166d6208": {},
				"6d49b352-dc18-4df5-975f-135a332d05bb": {},
				"fdf33cf4-0819-4d84-ab05-d4385407ca69": {},
				"9cba23df-0d93-4db2-8a9d-e0eeb9c195ed": {},
				"ec5ddd13-f0a1-436c-a0cf-dab240077440": {},
				"9035c030-d251-44c2-a0ef-ae855afa6ddd": {},
				"154bd4ef-078b-48df-892b-a92b6f5b03ff": {},
				"5e559443-a795-4edc-a222-7787cc510c41": {},
				"324348a5-4bbd-462d-bebb-4709d78e0e76": {},
				"5510b5a5-4de6-4745-ad87-2f1bfdc71475": {},
				"8d17c0dc-fd1e-4d98-942f-0779a1a53b5e": {},
				"3d2d6f07-f900-4b38-a622-987fb062c0a8": {},
				"1c3f3506-ac40-4668-b651-2bca3339d75f": {},
				"0764bc48-4f30-4095-8009-eb89bcee7080": {},
				"2fba1504-f53e-4061-9017-4cd11315850f": {},
				"633bd08f-20cb-4fff-bb20-4eba93a538b0": {},
				"d6ff334c-9c40-4c9b-a82d-7c208537f337": {},
				"89240b2b-162f-4e26-9a39-7c02a9602439": {},
				"5c94cf84-cc92-4a10-a7d2-a10507a9a8fa": {},
				"1bd0b95b-2d54-40dc-b26d-1b89c2dec79c": {},
				"be56776f-e3d0-456c-93da-28b6e370c8ff": {},
				"f5e0e02b-b6f5-4a4d-be3b-0a85e0c6940a": {},
				"38c7d9f6-5f6c-4743-816b-7ccc65fef053": {}
			}
		},
		"df898b52-91e1-4778-baad-2ad9a261d30e": {
			"classDefinition": "com.sap.bpm.wfs.ui.StartEventSymbol",
			"x": -1737,
			"y": 90,
			"width": 32,
			"height": 32,
			"object": "11a9b5ee-17c0-4159-9bbf-454dcfdcd5c3"
		},
		"53e54950-7757-4161-82c9-afa7e86cff2c": {
			"classDefinition": "com.sap.bpm.wfs.ui.EndEventSymbol",
			"x": 1315,
			"y": 98,
			"width": 35,
			"height": 35,
			"object": "2798f4e7-bc42-4fad-a248-159095a2f40a"
		},
		"6bb141da-d485-4317-93b8-e17711df4c32": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1721,109 -1588,109",
			"sourceSymbol": "df898b52-91e1-4778-baad-2ad9a261d30e",
			"targetSymbol": "2fba1504-f53e-4061-9017-4cd11315850f",
			"object": "c6b99f32-5fe6-4ab6-b60a-80fba1b9ae0f"
		},
		"8c28d6f5-c3e5-4a11-8ff5-5c3e0819e996": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 440,
			"y": 86,
			"width": 100,
			"height": 60,
			"object": "c5e8caa3-ba01-4ad1-978a-d1f84601cb5a"
		},
		"414599e8-05eb-4f2e-b953-0e50b7734912": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "490,116 611,116",
			"sourceSymbol": "8c28d6f5-c3e5-4a11-8ff5-5c3e0819e996",
			"targetSymbol": "6b603939-bac5-4029-b9c0-e74d0437d182",
			"object": "5492ae8a-aab4-4d77-aa94-fe9c466bbfeb"
		},
		"6b603939-bac5-4029-b9c0-e74d0437d182": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 561,
			"y": 86,
			"width": 100,
			"height": 60,
			"object": "5dcab437-a293-460d-a700-e4f688ebc292"
		},
		"216f7e9f-4cc3-452d-a101-6f1993733e46": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "611,116 702,116",
			"sourceSymbol": "6b603939-bac5-4029-b9c0-e74d0437d182",
			"targetSymbol": "1f27f48f-0972-41ef-8602-3671ca93e260",
			"object": "dabbc9dc-e5f9-4be1-a84e-26752feef631"
		},
		"1f27f48f-0972-41ef-8602-3671ca93e260": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 681,
			"y": 95,
			"object": "82529b58-522a-4417-bbe3-c3671778e0e0"
		},
		"c9983627-d6ea-4e25-85f8-0fc31b20d1ee": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "702,116 805,116",
			"sourceSymbol": "1f27f48f-0972-41ef-8602-3671ca93e260",
			"targetSymbol": "01e5b016-f117-4033-bdb0-42040787b845",
			"object": "10d572d3-a06a-41bf-b3b1-67d4d73d7daa"
		},
		"ca245629-b223-4526-9ab3-5608fe9a2d95": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "702,136.5 702,196.5 490,196.5 490,145.5",
			"sourceSymbol": "1f27f48f-0972-41ef-8602-3671ca93e260",
			"targetSymbol": "8c28d6f5-c3e5-4a11-8ff5-5c3e0819e996",
			"object": "209cf9e0-f178-4369-8314-85af6da4ccd2"
		},
		"da4ac02a-0ce3-48f5-b625-6c51da4e8b05": {
			"classDefinition": "com.sap.bpm.wfs.ui.UserTaskSymbol",
			"x": -445,
			"y": 82,
			"width": 100,
			"height": 60,
			"object": "99730619-9b67-4a66-bbb1-f3ad5e650493"
		},
		"2f649ff2-ce06-44f7-b20b-996ad0aefa56": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-395,112 -215,112",
			"sourceSymbol": "da4ac02a-0ce3-48f5-b625-6c51da4e8b05",
			"targetSymbol": "d6ff334c-9c40-4c9b-a82d-7c208537f337",
			"object": "d9c2edce-788f-4d8e-b5d7-8643fc1251bb"
		},
		"c8a15291-df28-40c5-95d7-1c579964a9b1": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 184,
			"y": 95,
			"object": "8fc0a239-d5a7-400b-a399-5cf22ed0b937"
		},
		"8614a8bb-a832-4ae4-81b0-b9cb8a949b72": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "205,116 340,116",
			"sourceSymbol": "c8a15291-df28-40c5-95d7-1c579964a9b1",
			"targetSymbol": "154bd4ef-078b-48df-892b-a92b6f5b03ff",
			"object": "9e58d09c-db50-455b-a19c-b53542a6320c"
		},
		"bfc686e6-4211-439a-a45f-3838d8a66724": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 148,
			"y": 229,
			"width": 100,
			"height": 60,
			"object": "b0f1087b-f809-4427-a417-0365c63fff78"
		},
		"686a223a-2fd9-44c7-8cca-ab58dbd54b7b": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "201.5,136.5 201.5,239",
			"sourceSymbol": "c8a15291-df28-40c5-95d7-1c579964a9b1",
			"targetSymbol": "bfc686e6-4211-439a-a45f-3838d8a66724",
			"object": "d3284938-7a9d-42f5-87f4-a5fc6ba77b3b"
		},
		"d5e94d21-927a-48e5-a5d0-e75aa6fceebe": {
			"classDefinition": "com.sap.bpm.wfs.ui.EndEventSymbol",
			"x": 187.5,
			"y": 494.5,
			"width": 35,
			"height": 35,
			"object": "bb67abb2-ff1f-425e-8429-e7cd3415b384"
		},
		"a06a2503-aca2-4533-8b40-15f1969a0eec": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "198,259 198,388",
			"sourceSymbol": "bfc686e6-4211-439a-a45f-3838d8a66724",
			"targetSymbol": "ec5ddd13-f0a1-436c-a0cf-dab240077440",
			"object": "cfc8d300-0320-4d90-9d36-4801736f2f6a"
		},
		"0bc1fe4d-171f-4cb0-8be9-eaf99ed4e751": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -1149,
			"y": 82,
			"width": 100,
			"height": 60,
			"object": "fe5202b5-b8be-4624-a11e-9fc33f5bf103"
		},
		"4d27b2d8-5ab6-4bb9-8e37-ab9837f4322f": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1099,112 -956,112",
			"sourceSymbol": "0bc1fe4d-171f-4cb0-8be9-eaf99ed4e751",
			"targetSymbol": "1c3f3506-ac40-4668-b651-2bca3339d75f",
			"object": "ac2a6991-3cbc-4ff6-9f4f-267289ae3ab8"
		},
		"d2faeb49-4f09-46be-aac8-4794ae06a8ec": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -862,
			"y": 82,
			"width": 100,
			"height": 60,
			"object": "8003d764-0e52-4230-b538-f87a3a403097"
		},
		"768d2723-eb94-4a5c-a048-c169183d41b8": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-812,112 -672,112",
			"sourceSymbol": "d2faeb49-4f09-46be-aac8-4794ae06a8ec",
			"targetSymbol": "8157cce4-f05e-4130-a05e-9e328480c8d0",
			"object": "8b2eaf63-53f7-47f9-8e54-7515e8dc6809"
		},
		"8157cce4-f05e-4130-a05e-9e328480c8d0": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -722,
			"y": 82,
			"width": 100,
			"height": 60,
			"object": "818fdf7b-ef8f-45ad-8c32-7e04f19ac6b5"
		},
		"6fe044c0-c958-4222-a34a-978219160a69": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-672,112 -514,112",
			"sourceSymbol": "8157cce4-f05e-4130-a05e-9e328480c8d0",
			"targetSymbol": "63c8486a-2cc3-4bd0-a3c4-05b85e7c525d",
			"object": "1df7a0ed-2930-45e8-a7d1-99012d463577"
		},
		"63c8486a-2cc3-4bd0-a3c4-05b85e7c525d": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -535,
			"y": 91,
			"object": "bb8dcde6-7715-4d54-99f5-500c8b6fb2de"
		},
		"4f34698c-d9b5-4fd6-a3ac-8f27b3501b86": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-514,112 -395,112",
			"sourceSymbol": "63c8486a-2cc3-4bd0-a3c4-05b85e7c525d",
			"targetSymbol": "da4ac02a-0ce3-48f5-b625-6c51da4e8b05",
			"object": "825cbff7-8d5d-40db-a19b-556949d49d45"
		},
		"9899ab0d-be9f-4d05-adbb-7e417773d576": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-514,132.5 -514,192.5 -812,192.5 -812,141.5",
			"sourceSymbol": "63c8486a-2cc3-4bd0-a3c4-05b85e7c525d",
			"targetSymbol": "d2faeb49-4f09-46be-aac8-4794ae06a8ec",
			"object": "2dbc0445-23b0-4785-9fcf-3049f4971e52"
		},
		"01e5b016-f117-4033-bdb0-42040787b845": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 755,
			"y": 86,
			"width": 100,
			"height": 60,
			"object": "9f703322-1081-49a3-b319-431a4f293c74"
		},
		"b9c7ccb1-98f8-448e-97ea-1224b2b67083": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "805,116 945,116",
			"sourceSymbol": "01e5b016-f117-4033-bdb0-42040787b845",
			"targetSymbol": "07e25037-08f5-4759-9374-d600f4713618",
			"object": "7a5244f2-080f-4ebf-a31e-7f6df286dc25"
		},
		"07e25037-08f5-4759-9374-d600f4713618": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 895,
			"y": 86,
			"width": 100,
			"height": 60,
			"object": "b3d35e62-2f49-4f38-bff4-7d06431e4e1f"
		},
		"1a78fd9c-2658-4961-98be-590565892b57": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "945,116 1100,116",
			"sourceSymbol": "07e25037-08f5-4759-9374-d600f4713618",
			"targetSymbol": "e1adc670-1c85-402a-afe7-7ecbafa3433d",
			"object": "15a6c6c6-3b04-45eb-a9b0-2926386d8d31"
		},
		"e1adc670-1c85-402a-afe7-7ecbafa3433d": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 1050,
			"y": 86,
			"width": 100,
			"height": 60,
			"object": "77a8c74c-8e29-4771-a9a5-8ce70480de6d"
		},
		"ceefa2fa-bbb9-43f8-9e8b-e073166d6208": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1100,117.5 1216,117.5",
			"sourceSymbol": "e1adc670-1c85-402a-afe7-7ecbafa3433d",
			"targetSymbol": "6d49b352-dc18-4df5-975f-135a332d05bb",
			"object": "73c632d7-419d-4006-9475-32781ff21934"
		},
		"6d49b352-dc18-4df5-975f-135a332d05bb": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 1195,
			"y": 98,
			"object": "3f15dfcb-725d-456d-ba6f-dc6cf7b693df"
		},
		"fdf33cf4-0819-4d84-ab05-d4385407ca69": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1216,117.25 1332.5,117.25",
			"sourceSymbol": "6d49b352-dc18-4df5-975f-135a332d05bb",
			"targetSymbol": "53e54950-7757-4161-82c9-afa7e86cff2c",
			"object": "73962fc2-7733-41cd-b8b0-a10f157d1360"
		},
		"9cba23df-0d93-4db2-8a9d-e0eeb9c195ed": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1212,108 1212,35.5 943,35.5 943,93",
			"sourceSymbol": "6d49b352-dc18-4df5-975f-135a332d05bb",
			"targetSymbol": "07e25037-08f5-4759-9374-d600f4713618",
			"object": "827cb222-05af-4e76-8e20-d42a47328139"
		},
		"ec5ddd13-f0a1-436c-a0cf-dab240077440": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 148,
			"y": 358,
			"width": 100,
			"height": 60,
			"object": "cbb8932b-2520-4f87-a8ee-fd61ed0a60c9"
		},
		"9035c030-d251-44c2-a0ef-ae855afa6ddd": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "201.5,388 201.5,512",
			"sourceSymbol": "ec5ddd13-f0a1-436c-a0cf-dab240077440",
			"targetSymbol": "d5e94d21-927a-48e5-a5d0-e75aa6fceebe",
			"object": "a6dc5040-c8d9-4141-b6c3-13f7db5e4a74"
		},
		"154bd4ef-078b-48df-892b-a92b6f5b03ff": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 290,
			"y": 86,
			"width": 100,
			"height": 60,
			"object": "9e099813-db05-433b-be3f-b607c2cf9c0f"
		},
		"5e559443-a795-4edc-a222-7787cc510c41": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "340,116 490,116",
			"sourceSymbol": "154bd4ef-078b-48df-892b-a92b6f5b03ff",
			"targetSymbol": "8c28d6f5-c3e5-4a11-8ff5-5c3e0819e996",
			"object": "34ac48bb-0a03-4873-b704-14d6ff2e08c1"
		},
		"324348a5-4bbd-462d-bebb-4709d78e0e76": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -1306,
			"y": 82,
			"width": 100,
			"height": 60,
			"object": "ec1d0963-aec5-4b64-93d4-d5795df3b9e6"
		},
		"5510b5a5-4de6-4745-ad87-2f1bfdc71475": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1256,112 -1099,112",
			"sourceSymbol": "324348a5-4bbd-462d-bebb-4709d78e0e76",
			"targetSymbol": "0bc1fe4d-171f-4cb0-8be9-eaf99ed4e751",
			"object": "7ea8d1df-7b7c-4799-ad62-8636510d292b"
		},
		"8d17c0dc-fd1e-4d98-942f-0779a1a53b5e": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -1473,
			"y": 82,
			"width": 100,
			"height": 60,
			"object": "89b62786-0371-47ec-bcef-d26afa4b0c95"
		},
		"3d2d6f07-f900-4b38-a622-987fb062c0a8": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1423,112 -1256,112",
			"sourceSymbol": "8d17c0dc-fd1e-4d98-942f-0779a1a53b5e",
			"targetSymbol": "324348a5-4bbd-462d-bebb-4709d78e0e76",
			"object": "77601f12-84b3-4782-a16b-fa53337ebc2c"
		},
		"1c3f3506-ac40-4668-b651-2bca3339d75f": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -1006,
			"y": 82,
			"width": 100,
			"height": 60,
			"object": "19011fc3-3641-4626-91fc-c42a77afc56f"
		},
		"0764bc48-4f30-4095-8009-eb89bcee7080": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-956,112 -812,112",
			"sourceSymbol": "1c3f3506-ac40-4668-b651-2bca3339d75f",
			"targetSymbol": "d2faeb49-4f09-46be-aac8-4794ae06a8ec",
			"object": "f3afcce4-69d6-41b6-bcdd-572f22451716"
		},
		"2fba1504-f53e-4061-9017-4cd11315850f": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -1638,
			"y": 82,
			"width": 100,
			"height": 60,
			"object": "f8acbc29-95e5-4e25-b50c-9dbf0ea7c808"
		},
		"633bd08f-20cb-4fff-bb20-4eba93a538b0": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1588,112 -1423,112",
			"sourceSymbol": "2fba1504-f53e-4061-9017-4cd11315850f",
			"targetSymbol": "8d17c0dc-fd1e-4d98-942f-0779a1a53b5e",
			"object": "d49af99c-5c9e-4875-80cf-64b316c5857c"
		},
		"d6ff334c-9c40-4c9b-a82d-7c208537f337": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -265,
			"y": 82,
			"width": 100,
			"height": 60,
			"object": "392fb158-4913-458d-aaba-bd9394b5a1f0"
		},
		"89240b2b-162f-4e26-9a39-7c02a9602439": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-215,112 -79,112",
			"sourceSymbol": "d6ff334c-9c40-4c9b-a82d-7c208537f337",
			"targetSymbol": "be56776f-e3d0-456c-93da-28b6e370c8ff",
			"object": "8cbf65da-7e0e-4ad5-805d-43420a8a9ab2"
		},
		"5c94cf84-cc92-4a10-a7d2-a10507a9a8fa": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 23,
			"y": 82,
			"width": 100,
			"height": 60,
			"object": "c83790fa-9ad8-408f-9d98-fb88d909cd48"
		},
		"1bd0b95b-2d54-40dc-b26d-1b89c2dec79c": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "73,114 205,114",
			"sourceSymbol": "5c94cf84-cc92-4a10-a7d2-a10507a9a8fa",
			"targetSymbol": "c8a15291-df28-40c5-95d7-1c579964a9b1",
			"object": "28aa9681-7f1b-41ea-a6a3-8bccdcae17e8"
		},
		"be56776f-e3d0-456c-93da-28b6e370c8ff": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -100,
			"y": 91,
			"object": "d1bf56b1-4bad-469e-9db9-e8b3c95e7ee6"
		},
		"f5e0e02b-b6f5-4a4d-be3b-0a85e0c6940a": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-79,112 73,112",
			"sourceSymbol": "be56776f-e3d0-456c-93da-28b6e370c8ff",
			"targetSymbol": "5c94cf84-cc92-4a10-a7d2-a10507a9a8fa",
			"object": "9eb3b33d-ecd5-43a4-96ec-0b4ef02bf494"
		},
		"38c7d9f6-5f6c-4743-816b-7ccc65fef053": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-82,97 -82,45 208,45 208,97",
			"sourceSymbol": "be56776f-e3d0-456c-93da-28b6e370c8ff",
			"targetSymbol": "c8a15291-df28-40c5-95d7-1c579964a9b1",
			"object": "884513b0-649f-423c-a443-613edc236abe"
		},
		"62d7f4ed-4063-4c44-af8b-39050bd44926": {
			"classDefinition": "com.sap.bpm.wfs.LastIDs",
			"sequenceflow": 33,
			"startevent": 1,
			"endevent": 2,
			"usertask": 1,
			"servicetask": 8,
			"scripttask": 12,
			"exclusivegateway": 5
		}
	}
}