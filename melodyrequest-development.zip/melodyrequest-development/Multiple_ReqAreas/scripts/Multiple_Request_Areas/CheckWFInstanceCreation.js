
var responses = $.context.DBCall.WfInstanceResponse.responses;
$.context.retry = false;

responses.forEach(function (response) {
    if (!(response.status >= 200 && response.status <= 300)) {
        $.context.retry = true;
    }
});

