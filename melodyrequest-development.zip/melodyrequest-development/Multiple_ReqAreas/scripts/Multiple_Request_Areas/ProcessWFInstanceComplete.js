$.context.lastActivityDate = new Date();
$.context.currentState = $.context.CurrentStateValue.REQCRT.Value;

var now = new Date();
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');

if (!$.context.DBCall) {
    $.context.DBCall = {};
}

$.context.DBCall.Request = {};

// Prepare data for WFINSTANCE New Table 
var wfIns_data = {};
wfIns_data.instance_GUID = $.info.workflowInstanceId;
wfIns_data.parentInstance_GUID = $.info.workflowInstanceId;
wfIns_data.technicalStateID = $.context.TechnicalStateValue.COMP.ID;
wfIns_data.currentStateID = $.context.CurrentStateValue.REQCRT.ID;
wfIns_data.currentStepID = $.context.CurrentStepValue.REQSUB.ID;
if ($.context.currentProcessor) {
    wfIns_data.currentProcessorID = $.context.currentProcessor.id;
    wfIns_data.currentProcessor = $.context.currentProcessor.fullName;
    wfIns_data.currentProcessorEmail = $.context.currentProcessor.email;
} else if ($.context.requesterDetails) {
    wfIns_data.currentProcessorID = $.context.requesterDetails.id;
    wfIns_data.currentProcessor = $.context.requesterDetails.fullName;
    wfIns_data.currentProcessorEmail = $.context.requesterDetails.email;
} else {
    wfIns_data.currentProcessorID = "";
    wfIns_data.currentProcessor = "";
    wfIns_data.currentProcessorEmail = "";
}
wfIns_data.decisionID  = $.context.decision_ID;
wfIns_data.dtLastActivity_tdate   = date;
wfIns_data.dtCreation_ttime = time;

// prepare data for ReqHistory 
var ReqHistory_data = {};
ReqHistory_data.InstanceID = $.info.workflowInstanceId;
ReqHistory_data.UserTaskID = $.context.submitPageUserTaskID;
ReqHistory_data.AssignmentID = "0";
ReqHistory_data.User_ID = $.context.requesterDetails.id;
ReqHistory_data.User_Name = $.context.requesterDetails.fullName;
ReqHistory_data.User_EMail = $.context.requesterDetails.email;
//ReqHistory_data.UserTaskName = $.context.CurrentStateValue.REQSUB.ID; 
ReqHistory_data.StateID = $.context.CurrentStateValue.REQCRT.ID; 
ReqHistory_data.Role = "Requester";
ReqHistory_data.Decision = $.context.decision_ID;
ReqHistory_data.Comments = $.context.lastRequestorComments;
ReqHistory_data.Date = date;
ReqHistory_data.Time = time;
if (!$.context.UT_refID) {
    $.context.UT_refID = 1;
}
else {
    $.context.UT_refID += 1;
}
ReqHistory_data.UT_refID = $.context.UT_refID;

$.context.DBCall.Request.requests = [];

var wfRequest = {
    id: "1",
    method: "PATCH",
    url: "/WfInstance(instance_GUID='" + $.info.workflowInstanceId + "',parentInstance_GUID='" + $.info.workflowInstanceId + "')",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    body: wfIns_data
};
$.context.DBCall.Request.requests.push(wfRequest);

var wfhistory = {   
    id: "2",
    method: "POST",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WFHistory",
    body: ReqHistory_data
};
$.context.DBCall.Request.requests.push(wfhistory);