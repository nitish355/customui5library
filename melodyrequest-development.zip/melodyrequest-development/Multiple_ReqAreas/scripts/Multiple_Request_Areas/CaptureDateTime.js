var now = new Date();
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');

$.context.UpdatedCreatedDate = date;
$.context.UpdatedCreatedTime = time;