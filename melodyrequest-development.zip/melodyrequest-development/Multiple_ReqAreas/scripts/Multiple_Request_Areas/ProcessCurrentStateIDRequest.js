$.context.CurrentStateDBCall = {}
$.context.CurrentStateDBCall.Request = {};
$.context.CurrentStateDBCall.Request.requests = [];
if (!$.context.EngagementType){
    $.context.EngagementType = "0001";
}
$.context.CurrentStateDBCall.Request.requests.push({
    id: "1",
    method: "GET",
    url: "/CurrentState",
    headers: { "content-type": "application/json;IEEE754Compatible=true" }
},
    {
        id: "2",
        method: "GET",
        url: "/TechnicalState",
        headers: { "content-type": "application/json;IEEE754Compatible=true" }
    },
    {
        id: "3",
        method: "GET",
        url: "/WF_Defination",
        headers: { "content-type": "application/json;IEEE754Compatible=true" }
    },
    {
        id: "4",
        method: "GET",
        url: "/RequestType?$filter=requestType eq '" + $.context.RequestType + "'",
        headers: { "content-type": "application/json;IEEE754Compatible=true" }
    },
    {
        id: "5",
        method: "GET",
        url: "/CurrentStep",
        headers: { "content-type": "application/json;IEEE754Compatible=true" }
    },
    {
        id: "6",
        method: "GET",
        url: "/MR_UserTask",
        headers: { "content-type": "application/json;IEEE754Compatible=true" }
    },
    {
        id: "7",
        method: "GET",
        url: "/EngagementType?$filter=eng_type_ID eq '" + $.context.EngagementType + "'",
        headers: { "content-type": "application/json;IEEE754Compatible=true" }
    }
)    ;