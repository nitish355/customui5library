
// if ($.context.isResourceProfile === true) {
//     for (var a = 0; a < $.context.aReqAreas.length; a++) {

//         var BA_Segment = $.context.aReqAreas[a].aResourceProfileApprovers.ResourceProfileDetails.BASegments;
//         for (var i = 0; i < BA_Segment.length; i++) {
//             $.context.DBCall.WfInstanceRequest.requests.push({
//                 id: (i + 5).toString(),
//                 dependsOn: ["1"],
//                 method: "POST",
//                 headers: { "content-type": "application/json;IEEE754Compatible=true" },
//                 url: "/ResProfileSel_Header",
//                 body: {
//                     InstanceID: $.info.workflowInstanceId,
//                     role_ID: $.context.aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RoleID,
//                     roleArea_ID: $.context.aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RoleAreaID,
//                     BA_Segment_ID: BA_Segment[i].ID,
//                     role_Desc: $.context.aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RoleDesc,
//                     roleArea_Desc: $.context.aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RoleAreaDesc,
//                     BA_Segment_Desc: BA_Segment[i].Desc,
//                     ProfitCenter_GUID: $.context.selectedProfitCenter[0].guid
//                 }
//             });
//         };

//         var BALOB = $.context.aReqAreas[a].aResourceProfileApprovers.ResourceProfileDetails.BALoBs;
//         for (var j = 0; j < BALOB.length; j++) {
//             $.context.DBCall.WfInstanceRequest.requests.push({
//                 id: (j + 6 + BA_Segment.length).toString(),
//                 dependsOn: ["1"],
//                 method: "POST",
//                 headers: { "content-type": "application/json;IEEE754Compatible=true" },
//                 url: "/ResProfileSel_BALOB",
//                 body: {
//                     InstanceID: $.info.workflowInstanceId,
//                     BA_LOB_ID: BALOB[j].ID,
//                     BA_LOB_Desc: BALOB[j].Desc
//                 }
//             });
//         };

//         var CrossCvrg = $.context.aReqAreas[a].aResourceProfileApprovers.ResourceProfileDetails.cross_CVRG_P_GUIDArray;
//         for (var k = 0; k < CrossCvrg.length; k++) {
//             $.context.DBCall.WfInstanceRequest.requests.push({
//                 id: (k + 7 + BA_Segment.length + BALOB.length).toString(),
//                 dependsOn: ["1"],
//                 method: "POST",
//                 headers: { "content-type": "application/json;IEEE754Compatible=true" },
//                 url: "/ResProfileSel_CrossCvrg",
//                 body: {
//                     InstanceID: $.info.workflowInstanceId,
//                     crossCoverage_ID: CrossCvrg[k].ID,
//                     crossCoverage_Desc: CrossCvrg[k].Desc
//                 }
//             });
//         };

//         // var Hubs = $.context.aResourceProfileApprovers.ResourceProfileDetails.Hubs;
//         // for (var l = 0; l < Hubs.length; l++) {
//         //     $.context.DBCall.WfInstanceRequest.requests.push({
//         //         id: ( l + 8 + BA_Segment.length + BALOB.length + CrossCvrg.length).toString(),
//         //         dependsOn: ["1"],
//         //         method: "POST",
//         //         headers: { "content-type": "application/json;IEEE754Compatible=true" },
//         //         url: "/ResProfileSel_HubLOB",
//         //         body: {
//         //             InstanceID: $.info.workflowInstanceId,
//         //             hub_LOB_GUID: Hubs[l].HubGuid,
//         //             hub_LOB_Desc: Hubs[l].HubDesc,
//         //             hub_Type: Hubs[l].Type
//         //         }
//         //     });
//         // };

//         var BAIndustries = $.context.aReqAreas[a].aResourceProfileApprovers.ResourceProfileDetails.BAIndustries;
//         for (var m = 0; m < BAIndustries.length; m++) {
//             $.context.DBCall.WfInstanceRequest.requests.push({
//                 id: (m + 9 + BA_Segment.length + BALOB.length + CrossCvrg.length).toString(),
//                 dependsOn: ["1"],
//                 method: "POST",
//                 headers: { "content-type": "application/json;IEEE754Compatible=true" },
//                 url: "/ResProfileSel_BAIndustry",
//                 body: {
//                     InstanceID: $.info.workflowInstanceId,
//                     BA_Industry_ID: BAIndustries[m].BaIndId,
//                     BA_Industry_Desc: BAIndustries[m].Desc,
//                 }
//             });
//         }
//     }
// }