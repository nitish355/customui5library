$.context.DBCall = {};
$.context.DBCall.WfInstanceRequest = {};
$.context.DBCall.WfInstanceRequest.requests = []; 

var CurrentStateResponse = $.context.CurrentStateDBCall.Response.responses[0].body.value;
var CurrentStateValue = {};

CurrentStateResponse.forEach(function (val) {
    // Check if the ID already exists in CurrentStateValue, if not add it
    if (!(val.ID in CurrentStateValue)) {
        CurrentStateValue[val.ID] = {
            "ID": val.ID,
            "Value": val.Value
        };
    }
});
$.context.CurrentStateValue = CurrentStateValue;

var TechnicalStateResponse = $.context.CurrentStateDBCall.Response.responses[1].body.value;
var TechnicalStateValue = {};
TechnicalStateResponse.forEach(function (val) {
    // Check if the ID already exists in TechnicalStateValue, if not add it
    if (!(val.ID in TechnicalStateValue)) {
        TechnicalStateValue[val.ID] = {
            "ID": val.ID,
            "Value": val.technicalState
        };
    }
});
$.context.TechnicalStateValue = TechnicalStateValue;
var EngagementTypeResponse = $.context.CurrentStateDBCall.Response.responses[6].body.value;
var EngagementTypeValue = {
            "ID": EngagementTypeResponse[0].eng_type_ID,
            "Value": EngagementTypeResponse[0].eng_type_Desc
        };
$.context.EngagementTypeValue = EngagementTypeValue;
var RequestTypeResponse = $.context.CurrentStateDBCall.Response.responses[3].body.value;
var RequestTypeValue = {
            "ID": RequestTypeResponse[0].ID,
            "Value": RequestTypeResponse[0].requestType
        };
$.context.RequestTypeValue = RequestTypeValue;

var DefinitionIdResponseValue = $.context.CurrentStateDBCall.Response.responses[2].body.value;
$.context.DefinitionIdValue = DefinitionIdResponseValue;

var CuurentStepResponse = $.context.CurrentStateDBCall.Response.responses[4].body.value;
var CurrentStepValue = {};
CuurentStepResponse.forEach(function (val) {
    // Check if the ID already exists in CurrentStepValue, if not add it
    if (!(val.ID in CurrentStepValue)) {
        CurrentStepValue[val.ID] = {
            "ID": val.ID,
            "Value": val.currentStep
        };
    }
});
$.context.CurrentStepValue = CurrentStepValue;
var UserTaskLabelResponse = $.context.CurrentStateDBCall.Response.responses[5].body.value;
var UserTaskLabelValue = {};
UserTaskLabelResponse.forEach(function (val) {
    // Check if the userTask already exists in UserTaskLabelValue, if not add it
    if (!(val.userTask in UserTaskLabelValue)) {
        UserTaskLabelValue[val.userTask] = {
            "userTaskID" : val.userTaskID,
            "userTask": val.userTask,
            "userTaskName": val.userTaskName
        };
    }
});
$.context.UserTaskLabelValue = UserTaskLabelValue;
$.context.currentProcessorRole = "Requestor";
$.context.currentStepName = $.context.CurrentStepValue.REQSUB.Value;//"Request Submission";
$.context.currentStepID = $.context.CurrentStepValue.REQSUB.ID;
$.context.currentState = $.context.CurrentStateValue.REQSUB.Value;

var FullextSystemsUrls;

//Code to convert SalesOrgID from SORG-XXXX to XXXX
if ($.context.OrgType == "SORG" || $.context.OrgType == "MUID" )
{ 
var OrgID_Num = $.context.OrgID.substring(5, 9);
//Code to remove leading Zeroes
OrgID_Num = OrgID_Num.replace(/^0+/, '');
}
else if ($.context.OrgType == "PC")
{
    OrgID_Num = $.context.OrgID

}

// escape

//Begin of code of changes by C5350612
var now = new Date();
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');

if (!$.context.isLegacy) {
    $.context.isLegacy = true;
    }

if ($.context.isResourceProfile === true) {
    
    var aReqareas = "";
    var aReqareaPath = "";
}
else{
    
    //begin code for multiple Reqarea comma saperated 
    var reqlen = $.context.aReqAreas.length;
    var aReqareas = "";
    var aReqareaPath = "";
    for (var j = 0; j < reqlen; j++) {
        aReqareas += $.context.aReqAreas[j].requestArea + ",";
        aReqareaPath += $.context.aReqAreas[j].requestAreaPath + ",";
    }
    aReqareas = aReqareas.substring(0, aReqareas.length - 1);
    aReqareaPath = aReqareaPath.substring(0, aReqareaPath.length - 1);
}

$.context.accNameFormatted = $.context.accountName.length > 20 ? $.context.accountName.slice(0, 20) + "..." : $.context.accountName;
$.context.Approval_subject = "";

if (!$.context.RequestType) {
    $.context.isAccount = false;
} else {
    if ($.context.RequestType == "Account") {
        $.context.isAccount = true;
        $.context.opportunityId = "";
        $.context.Opp_Desc = "";
        $.context.Approval_subject = "/ Acc." + $.context.accountId;
        FullextSystemsUrls = $.context.accountUrl;
        $.context.EmailRequestTypeID = $.context.accountId;
    }
    else {
        $.context.isAccount = false;
        FullextSystemsUrls = $.context.extSystemsUrls.harmony;
        $.context.Approval_subject = "/ Opp." + $.context.opportunityId;
        $.context.IndustryName = "";
        $.context.PE_Name = "";
        $.context.EmailRequestTypeID = $.context.opportunityId;
    }
}
var refrenceID = $.context.RefrenceID.Response.value;

// Prepare data for WFINSTANCE Table 
var wfIns_data = {};
wfIns_data.instance_GUID = $.info.workflowInstanceId;
wfIns_data.parentInstance_GUID = $.info.workflowInstanceId;
if (refrenceID != "") {
    wfIns_data.refID = parseInt(refrenceID);
}
wfIns_data.definitionID = $.context.DefinitionIdValue[0].ID;
wfIns_data.technicalStateID = $.context.TechnicalStateValue.INPR.ID;
wfIns_data.currentStateID = $.context.CurrentStateValue.REQSUB.ID;
wfIns_data.currentStepID = $.context.CurrentStepValue.REQSUB.ID;
wfIns_data.currentProcessorID = $.context.requesterDetails.id;
wfIns_data.currentProcessor = $.context.requesterDetails.fullName;
wfIns_data.currentProcessorEmail = $.context.requesterDetails.email;
wfIns_data.dtCreation_tdate = date;
wfIns_data.dtCreation_ttime = time;
wfIns_data.dtLastActivity_tdate = date;
wfIns_data.dtLastActivity_ttime = time;
wfIns_data.reqAreaGUID = $.context.GUID;
if($.context.UserTaskLabelValue)
    {
        wfIns_data.userTaskID = $.context.UserTaskLabelValue.Requestor.userTaskID;
    }
// Prepare data for Wfinstance Parent table
var wfInsParent_data = {};
wfInsParent_data.instance_GUID = $.info.workflowInstanceId;
if (refrenceID != "") {
wfInsParent_data.refID = parseInt(refrenceID);
}
wfInsParent_data.definitionID = $.context.DefinitionIdValue[0].ID;
wfInsParent_data.orgID = OrgID_Num;
wfInsParent_data.orgType = $.context.OrgType;
if ($.context.OrgType == "SORG") {
    wfInsParent_data.orgID_L = $.context.OrgID;
}
wfInsParent_data.reqTypeID  = $.context.RequestTypeValue.ID;
wfInsParent_data.eng_type_ID  = $.context.EngagementTypeValue.ID;
wfInsParent_data.opportunityID = $.context.opportunityId;
wfInsParent_data.opportunityDesc = $.context.Opp_Desc;
wfInsParent_data.account_ID = $.context.accountId;
wfInsParent_data.account_name  = $.context.accountName;   
wfInsParent_data.empRequester_ID = $.context.requesterDetails.id;
wfInsParent_data.empRequester_Name = $.context.requesterDetails.fullName;
wfInsParent_data.empRequester_EMail = $.context.requesterDetails.email;
wfInsParent_data.systemID = $.context.systemId;
wfInsParent_data.industryName = $.context.IndustryName;
wfInsParent_data.pE_Name = $.context.PE_Name;
wfInsParent_data.extSystemsUrl  = FullextSystemsUrls;

/* Prepare data for WfInsProcessor (Current Processor) Table */
var WfInsProc_data = {};
WfInsProc_data.InstanceID = $.info.workflowInstanceId;
WfInsProc_data.assignmentID = "1";
WfInsProc_data.currentProcessorID = $.context.requesterDetails.id;
WfInsProc_data.currentProcessorName = $.context.requesterDetails.fullName;
WfInsProc_data.currentProcessorEmail = $.context.requesterDetails.email;

/* Prepare DB Call for Workflow Tables */
$.context.DBCall.WfInstanceRequest.requests.push({
    id: "1",
    method: "POST",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WfInstance",
    body: wfIns_data
},
    {
        id: "2",
        method: "POST",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: "/WFInsParent",
        body: wfInsParent_data
    },
    {
        id: "3",
        method: "POST",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: "/WfInsProcessor",
        body: WfInsProc_data
    }
);
$.context.UT_refID = 0;
$.context.delDraft = false;