if ($.context.isResourceProfile === true) {
	
	if ($.context.CountMultiReqArea == 0) {
		$.context.LenMultiReqArea = $.context.aReqAreas.length; //1;
	}
	var i = $.context.CountMultiReqArea;
	$.context.aReqAreas[i].parentInstanceID = $.info.workflowInstanceId;
	$.context.aReqAreas[i].NewOppDetails = $.context.NewOppDetails;
	$.context.aReqAreas[i].EmailRequestTypeID = $.context.EmailRequestTypeID;
	$.context.aReqAreas[i].EngagementType = $.context.EngagementType ? $.context.EngagementType : "0001";
}
else {

	
	if ($.context.CountMultiReqArea == 0) {
		$.context.LenMultiReqArea = $.context.aReqAreas.length;
	}

	var i = $.context.CountMultiReqArea;

	$.context.aReqAreas[i].parentInstanceID = $.info.workflowInstanceId;
}

if($.context.draftCreated == true)
	{
		$.context.aReqAreas[i].draftCreated = true;
	}
$.context.wftrigger = {};
$.context.wftrigger = {
	Request: {
		"definitionId": "PresalesRequestApproval",
		"context": $.context.aReqAreas[i]
	}
}

$.context.CountMultiReqArea += 1; 