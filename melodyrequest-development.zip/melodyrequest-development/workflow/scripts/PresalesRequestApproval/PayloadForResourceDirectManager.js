$.context.User_NotifDBCallPayload = {};
var users = {};
var UserNotifpayload = {};
UserNotifpayload.notif_Id = "16";
UserNotifpayload.notifVal_Id = "0001";
if ( $.context.ResDirectManagerEmail && $.context.ResDirectManagerId) {
  users.oldProssOrDirectMgr = [{
    userId: $.context.ResDirectManagerId.toUpperCase(),
    email: $.context.ResDirectManagerEmail
  }];
}
if ( Object.keys(users).length > 0) {
  UserNotifpayload.users = users;
  $.context.User_NotifDBCallPayload = UserNotifpayload;
}