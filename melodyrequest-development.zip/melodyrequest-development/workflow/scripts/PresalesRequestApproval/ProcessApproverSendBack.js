var decision = {
    "UserId": $.context.currentProcessor.id, // Userid for approvalHistory
    "UserName": $.context.currentProcessor.fullName,
    "Role": $.context.currentProcessorRole,
    "StepName": $.context.currentStepName,
    "StepID" :$.context.currentStepID,
    "Decision": $.context.decision,
    "Comments": $.context.comments,
    "Date": new Date()
};
var now = new Date();
$.context.history  = {};   
$.context.history.UserName = $.context.currentProcessor.fullName;
$.context.history.LastStep = 'Review - Processor';
$.context.history.StepName = 'Review - Processor - Sent Back to Requestor';
$.context.history.Decision = 'Sent the request back to the Requestor';
$.context.history.Comments = $.context.comments ? $.context.comments : "";
var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
var day = ("0" + now.getUTCDate()).slice(-2), month = months[now.getUTCMonth()],year = now.getUTCFullYear();
$.context.history.DateUTC = month + " " + day + ", " + year;
var hours = now.getUTCHours(), minutes = ("0" + now.getUTCMinutes()).slice(-2),ampm = hours >= 12 ? 'PM' : 'AM';
hours = hours % 12;
hours = hours ? hours : 12; 
$.context.history.TimeUTC = hours + ":" + minutes + " " + ampm + " UTC";
$.context.history.class = "";
$.context.history.HistoryData = "History-Data";
$.context.EmailTemplateVars.approvalHistoryEmail.splice($.context.EmailTemplateVars.HistoryCount, 0 , $.context.history);
while($.context.EmailTemplateVars.approvalHistoryEmail.length<20){
  $.context.EmailTemplateVars.approvalHistoryEmail.push({class :"hidden-row", HistoryData:"hide-row"});
}
$.context.EmailTemplateVars.HistoryCount++;
$.context.EmailTemplateVars.LastActionDateTime = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].DateUTC + " at " + $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].TimeUTC;
$.context.EmailTemplateVars.LastAction = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].UserName +" – "+ $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].LastStep+" – "+$.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].Decision;
$.context.EmailTemplateVars.LastActionComment = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].Comments;
$.context.approverData = $.context.currentProcessor;

var approverId = "";
$.context.approverData = $.context.currentProcessor;
if ($.context.isResourceProfile === true)
{ 
    if ($.context.lastDecisionTask == 11 ){
    approverId = $.usertasks.usertask11.last.processor;
    
}
    else {
        approverId = $.usertasks.usertask10.last.processor;
       
    }
   
}
else {
if ($.context.lastDecisionTask == 3) {
    approverId = $.usertasks.usertask5.last.processor
} else if ($.context.lastDecisionTask == 2) {
    approverId = $.usertasks.usertask4.last.processor
} else if ($.context.lastDecisionTask == 1) {
    approverId = $.usertasks.usertask2.last.processor
}
}

$.context.approverData.id  = approverId;


$.context.approvalHistory.push(decision);
$.context.lastApproverComments = $.context.comments ? $.context.comments : "";
$.context.isRework = true;
$.context.lastActivityDate = new Date();
$.context.currentState = $.context.CurrentStateValue.REESUB.Value;

$.context.currentProcessorRole = "Requestor"
$.context.currentProcessor = $.context.requesterDetails;
$.context.PreviousProcessEmail_Notif = "";
$.context.RequesterEmail_NotifFwd = "";