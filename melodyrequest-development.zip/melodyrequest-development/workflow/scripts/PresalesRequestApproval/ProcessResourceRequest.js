var resources = [];
var statusCode = $.context.areaPathCall.Response.responses[0].status;
$.context.retry = false;

if (statusCode >= 200 && statusCode <= 300) {
    if ($.context.areaPathCall.Response && $.context.areaPathCall.Response.responses && $.context.areaPathCall.Response.responses.length > 0) {
        var requestAreaResponse = $.context.areaPathCall.Response.responses[0].body
        if (requestAreaResponse && requestAreaResponse.Resources) {
            requestAreaResponse.Resources.split(';').forEach(function (val) {
                if (val !== "" && resources.indexOf(val) === -1) {
                    resources.push(val.trim());
                }
            });
        }

        if (requestAreaResponse && requestAreaResponse.Approvers) {
            requestAreaResponse.Approvers.split(';').forEach(function (val) {
                if (val !== "" && resources.indexOf(val) === -1) {
                    resources.push(val.trim());
                }
            });
        }

        if (requestAreaResponse && requestAreaResponse.SubstituteApprovers) {
            requestAreaResponse.SubstituteApprovers.split(';').forEach(function (val) {
                if (val !== "" && resources.indexOf(val) === -1) {
                    resources.push(val.trim());
                }
            });
        }
    }

// Start of changes by C5305610 for Email Delegates
    var statusCode_Email_delegates = $.context.areaPathCall.Response.responses[2].status;
    if (statusCode_Email_delegates >= 200 && statusCode_Email_delegates <= 300) {
        var emaildelegates = $.context.areaPathCall.Response.responses[2].body.value;
        if (emaildelegates.length > 0) {
            if (emaildelegates && emaildelegates[0].Email_Delegates) {
                emaildelegates[0].Email_Delegates.split(';').forEach(function (val) {
                    if (val !== "" && resources.indexOf(val) === -1) {
                        resources.push(val.trim());
                    }
                });
            }
        }

    } 
// end of changes by C5305610 for Email Delegates
    
    $.context.CPICalls.getResourcesFromCRM = {
        Request: {
           // "opportunityId": $.context.opportunityId,
            "requestIntent": "GET_RESOURCES",
            "resources": resources
        }
    }
} else {
    $.context.retry = true;
}

// Code for Email Text changes
var statusCode_Email = $.context.areaPathCall.Response.responses[1].status;
if (statusCode_Email >= 200 && statusCode_Email <= 300) {
    var EmailResponse = $.context.areaPathCall.Response.responses[1].body.value;
    for (var i = 0; i < EmailResponse.length; i++) {
        var UserEmail = "",
            UserId = "",
            UserName = "";
        if (EmailResponse[i].Parameter == "Signature") { 
            $.context.Email_Signature =  EmailResponse[i].Email_Text;
        }
        if (EmailResponse[i].Parameter == "Initial") {
            $.context.Email_Initial =  EmailResponse[i].Email_Text;
        }
        if (EmailResponse[i].Parameter == "IgnoreText") {
            $.context.IgnoreMessage =  EmailResponse[i].Email_Text;
        }
        if (EmailResponse[i].Parameter == "OppAccOwnerEmail") {
            var oppAccountEmail = EmailResponse[i].Email_Text;
            if ( oppAccountEmail !== null && oppAccountEmail !== "") {
                var UserDetails = oppAccountEmail.split(",");
                if(UserDetails.length >= 3){
                    UserEmail = UserDetails[0];
                    UserId = UserDetails[1];
                    UserName = UserDetails[2];
                }
            } 
            $.context.NewReqOppAccOwnerDetails = {};
            $.context.NewReqOppAccOwnerDetails.email = UserEmail;
            $.context.NewReqOppAccOwnerDetails.id = UserId;
            $.context.NewReqOppAccOwnerDetails.name = UserName;
        }
        
      }
}
// end of email text changes 

//code for Routing 
$.context.Skip_Resource_Approver = false;
$.context.Skip_IO_Owner_WF = false;
var statusCode_routing = $.context.areaPathCall.Response.responses[3].status;
if (statusCode_routing >= 200 && statusCode_routing <= 300) {
    var Routing = $.context.areaPathCall.Response.responses[3].body.value;
    for (var i = 0; i < Routing.length; i++) {
        if (Routing[i].routing == "SKIP_RESOURCE_APPROVER" && Routing[i].operationalStatus == "X") {
            $.context.Skip_Resource_Approver = true;
        }
        else if (Routing[i].routing == "SKIP_IO_OWNER_WF" && Routing[i].operationalStatus == "X") {
            $.context.Skip_IO_Owner_WF = true;
        }

    }
}
// end of Routing 
