var mResources = $.context.CPICalls.getResourcesFromCRM.Response.results;
$.context.approverDetails = [];
$.context.substituteApproverDetails = [];
$.context.primaryApproverDetails = [];
$.context.EmailDelegatesDetails = [];
var now = new Date();
$.context.history  = {};   
$.context.history.UserName = $.context.requesterDetails.fullName;
$.context.history.LastStep = 'Review - Requestor';
$.context.history.StepName =  'Review - Requestor - Submitted';
$.context.history.Decision = 'Submitted the request for '+ $.context.RequestType +" "+ $.context.EmailRequestTypeID;
$.context.history.Comments = $.context.comments ? $.context.comments : '';
var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
var day = ("0" + now.getUTCDate()).slice(-2), month = months[now.getUTCMonth()],year = now.getUTCFullYear();
$.context.history.DateUTC = month + " " + day + ", " + year;
var hours = now.getUTCHours(), minutes = ("0" + now.getUTCMinutes()).slice(-2),ampm = hours >= 12 ? 'PM' : 'AM';
hours = hours % 12;
hours = hours ? hours : 12; 
$.context.history.TimeUTC = hours + ":" + minutes + " " + ampm + " UTC";
$.context.history.class = "";
$.context.history.HistoryData = "History-Data";
$.context.EmailTemplateVars.approvalHistoryEmail.splice($.context.EmailTemplateVars.HistoryCount,0,$.context.history);
while($.context.EmailTemplateVars.approvalHistoryEmail.length<20){
  $.context.EmailTemplateVars.approvalHistoryEmail.push({class :"hidden-row", HistoryData:"hide-row"});
}
$.context.EmailTemplateVars.HistoryCount++; 
$.context.EmailTemplateVars.LastActionDateTime = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].DateUTC + " at " + $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].TimeUTC;
$.context.EmailTemplateVars.LastAction = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].UserName +" – "+ $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].LastStep+" – "+$.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].Decision;
$.context.EmailTemplateVars.LastActionComment = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].Comments;
var approver = $.context.aResourceProfileApprovers.ApproverDetails;
var subsapprover = ($.context["aResourceProfileApprovers"]["SubstituteApproverDetails"]) ? $.context.aResourceProfileApprovers.SubstituteApproverDetails : [];
var primaryApprovers = ($.context["aResourceProfileApprovers"]["aApprovers"]) ? $.context.aResourceProfileApprovers.aApprovers : $.context.aResourceProfileApprovers.ApproverDetails;
$.context.hasSubstitute = false;
if (subsapprover.length >0){
  $.context.hasSubstitute = true;
}
approver.forEach(function (val) {
	if (val.ID !== "" && mResources[val.ID]) {
        var name = val.fullName;
        name = name.replace(/^(\S).*\s(\S+)$/, function(_, first, last) {
            // Capitalize the first initial and add a period, and capitalize the last name correctly
            return first.toUpperCase() + '. ' + last.charAt(0).toUpperCase() + last.slice(1).toLowerCase();    
        });
		var data = {
            Name: name,
			fullName: val.fullName,
			email: mResources[val.ID].EMAIL,
			partnerId: mResources[val.ID].PARTNER,
			address: mResources[val.ID].ADDRESS,
			userId: mResources[val.ID].USERID,
			country: mResources[val.ID].COUNTRY
		};
		$.context.approverDetails.push(data);	}});
subsapprover.forEach(function (val) {
	if (val.ID !== "" && mResources[val.ID]) {        
		var data = {
			fullName: val.fullName,
			email: mResources[val.ID].EMAIL,
			partnerId: mResources[val.ID].PARTNER,
			address: mResources[val.ID].ADDRESS,
			userId: mResources[val.ID].USERID,
			country: mResources[val.ID].COUNTRY
		};
		$.context.substituteApproverDetails.push(data); }});
primaryApprovers.forEach(function (val) {
	if (val.ID !== "" && mResources[val.ID]) {        
		var data = {
			fullName: val.fullName,
			email: mResources[val.ID].EMAIL,
			partnerId: mResources[val.ID].PARTNER,
			address: mResources[val.ID].ADDRESS,
			userId: mResources[val.ID].USERID,
			country: mResources[val.ID].COUNTRY
		};
		$.context.primaryApproverDetails.push(data); }});

if ($.context.areaPathCall.Response && $.context.areaPathCall.Response.responses && $.context.areaPathCall.Response.responses.length > 0 ) {
    if ( $.context.areaPathCall.Response.responses[1].body.value.length > 0 ){
    var emaildelegates = $.context.areaPathCall.Response.responses[1].body.value[0] ; 
    if (emaildelegates && emaildelegates.Email_Delegates) {
        emaildelegates.Email_Delegates.split(';').forEach(function (val) {
            if (val !== "" && mResources[val]) {
                var data = {
                    fullName: mResources[val].NAME,
                    email: mResources[val].EMAIL,
                    partnerId: mResources[val].PARTNER,
                    address: mResources[val].ADDRESS,
                    userId: mResources[val].USERID,
                    country: mResources[val].COUNTRY
                };
                $.context.EmailDelegatesDetails.push(data);
            }
        });
    }
}

}

// email
var aApproversData = $.context.approverDetails,
    sApproverIntro = "Dear " + aApproversData[0].fullName + ",",
    sApproverEmails = aApproversData[0].email,
    sApproverIds = aApproversData[0].userId,
    sApproverNames = aApproversData[0].fullName;
if (aApproversData.length > 1) {
    for (var i = 1; i < aApproversData.length; i++) {
        sApproverIntro += "\nDear " + aApproversData[i].fullName + ",";
        sApproverEmails += "," + aApproversData[i].email;
        sApproverIds += "," + aApproversData[i].userId,
        sApproverNames += "," + aApproversData[i].fullName;
    }
}
//substitute email
if($.context.substituteApproverDetails.length != 0 ){
var aSubApproversData = $.context.substituteApproverDetails,    
    sSubApproverEmails = aSubApproversData[0].email,
    sSubApproverIds = aSubApproversData[0].userId,
    sSubApproverNames = aSubApproversData[0].fullName;
if (aSubApproversData.length > 1) {
    for (var i = 1; i < aSubApproversData.length; i++) {       
        sSubApproverEmails += "," + aSubApproversData[i].email;
        sSubApproverIds += "," + aSubApproversData[i].userId,
        sSubApproverNames += "," + aSubApproversData[i].fullName;
    }
}
$.context.subApproverNames = sSubApproverNames;
$.context.subApproversEmails = sSubApproverEmails;
$.context.subApproversIds = sSubApproverIds;
}
//primary approvers
if($.context.primaryApproverDetails.length != 0 ){
var aPrimaryApproversData = $.context.primaryApproverDetails,    
    sPrimaryApproverEmails = aPrimaryApproversData[0].email,
    sPrimaryApproverIds = aPrimaryApproversData[0].userId,
    sPrimaryApproverNames = aPrimaryApproversData[0].fullName;
if (aPrimaryApproversData.length > 1) {
    for (var i = 1; i < aPrimaryApproversData.length; i++) {       
        sPrimaryApproverEmails += "," + aPrimaryApproversData[i].email;
        sPrimaryApproverIds += "," + aPrimaryApproversData[i].userId,
        sPrimaryApproverNames += "," + aPrimaryApproversData[i].fullName;
    }
}
$.context.primaryApproverNames = sPrimaryApproverNames;
$.context.primaryApproversEmails = sPrimaryApproverEmails;
$.context.primaryApproversIds = sPrimaryApproverIds;
}

$.context.approverNames = sApproverNames;
$.context.notifyApproversEmailIntro = sApproverIntro;
$.context.approversEmails = sApproverEmails;
$.context.approversIds = sApproverIds;



//for email delegates - email intro, recipients etc 
if ($.context.EmailDelegatesDetails.length > 0) {
var aDelegatesData = $.context.EmailDelegatesDetails,

      sDelegatesIntro = "Dear " + aDelegatesData[0].fullName + ",",
    sDelegatesEmails = aDelegatesData[0].email,
    sDelegatesIds = aDelegatesData[0].userId,
    sDelegatesNames = aDelegatesData[0].fullName;
    if (aDelegatesData.length > 1) {
    for (var i = 1; i < aDelegatesData.length; i++) {
        sDelegatesIntro += "\nDear " + aDelegatesData[i].fullName + ",";
        sDelegatesEmails += "," + aDelegatesData[i].email;
        sDelegatesIds += "," + aDelegatesData[i].userId,
        sDelegatesNames += "," + aDelegatesData[i].fullName;
    }
}


$.context.DelegatesNames = sDelegatesNames;
$.context.NotifyDelegatesEmailIntro = sDelegatesIntro;
$.context.DelegatesEmails = sDelegatesEmails;
$.context.DelegatesIds = sDelegatesIds;

}
//dynamic email configuration
if ( $.context.RequestType == "Opportunity" ) {
    $.context.Opp_ID = "Opportunity ID:" ;
    $.context.CRev_L = "Cloud Revenue:" ;
    $.context.OpRev_L = "On Premise Revenue:" ;
    
}
if(!$.context["aResourceProfileApprovers"]["ResourceProfileDetails"]["SolutionAreas"]){
    $.context["aResourceProfileApprovers"]["ResourceProfileDetails"]["SolutionAreas"] =[];
}