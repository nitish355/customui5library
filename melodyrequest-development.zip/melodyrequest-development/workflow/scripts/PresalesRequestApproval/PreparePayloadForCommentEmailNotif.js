$.context.commentNotif_flag = false;
var UserTaskRole = "";
if ($.context.UserTaskLabelValue) {
	UserTaskRole = $.context.UserTaskLabelValue.Processor.userTask;
}
if ($.context.comments && $.context.comments.trim() !== "") {
	var userChatCommentDetails = {};
	userChatCommentDetails.commentText = $.context.comments;
	userChatCommentDetails.userID = $.context.currentProcessor.id;
	userChatCommentDetails.userEmail = $.context.currentProcessor.email;
	userChatCommentDetails.userName = $.context.currentProcessor.fullName;
	userChatCommentDetails.userRole = UserTaskRole;
	userChatCommentDetails.commentType = "ACTION";
	$.context.commentNotif_flag = true;
	$.context.userChatCommentDetails = userChatCommentDetails;
	var CommentNotifPayload = {};
	CommentNotifPayload.context = {};
	CommentNotifPayload.context = JSON.stringify($.context);
	$.context.CommentNotifPayload = CommentNotifPayload;
}
$.context.comments = "";