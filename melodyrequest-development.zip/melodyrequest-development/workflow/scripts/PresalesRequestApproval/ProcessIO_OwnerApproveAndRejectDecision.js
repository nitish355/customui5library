//Filtering out IO Owner Decision based on assignments
var IOOwnerId = [];
var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
if ($.context.io_OwnerResource.length > 0) {
    for (var i = 0; i < $.context.io_OwnerResource.length; i++) {
        var now = new Date();
        $.context.history  = {};
        $.context.history.StepName = $.context.CurrentStepValue.IOOAPP.Value; 
        $.context.history.class = "";
        $.context.history.HistoryData = "History-Data";
        var day = ("0" + now.getUTCDate()).slice(-2), month = months[now.getUTCMonth()],year = now.getUTCFullYear();
        $.context.history.DateUTC = month + " " + day + ", " + year;
        var hours = now.getUTCHours(), minutes = ("0" + now.getUTCMinutes()).slice(-2),ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12; 
        $.context.history.TimeUTC = hours + ":" + minutes + " " + ampm + " UTC";
        var io_OwnerDetails = $.context.io_OwnerResource[i].NominatedResources[0].ioOwnerDetails;
        var comments = $.context.io_OwnerResource[i].NominatedResources[0].IOownerComments? $.context.io_OwnerResource[i].NominatedResources[0].IOownerComments:"";
        if ($.context.io_OwnerResource[i].NominatedResources[0].Io_Decision === "Approve" || $.context.io_OwnerResource[i].NominatedResources[0].Io_Decision === "Proceed"  ) {
            $.context.io_OwnerApproveResource.push($.context.io_OwnerResource[i]);
            var decision = {                
                "UserName": io_OwnerDetails.IOOwnerName,
                "Role": "IO Owner",
                "StepName": $.context.CurrentStepValue.IOOAPP.Value,//"Presales IO Owner Approval",
                "StepID" : $.context.CurrentStepValue.IOOAPP.ID,
                "Decision": "The staffing request of " + $.context.io_OwnerResource[i].NominatedResources[0].fullName + " is approved by " + io_OwnerDetails.IOOwnerName,
                "Comments": comments,
                "Date": new Date()
            };
            $.context.approvalHistory.push(decision);
            $.context.history.UserName = io_OwnerDetails.IOOwnerName; 
            $.context.history.LastStep = $.context.history.StepName 
            $.context.history.StepName = $.context.history.StepName + " - Staffing Approved"        
            $.context.history.Decision = "The staffing request of " + $.context.io_OwnerResource[i].NominatedResources[0].fullName + " is approved by " + io_OwnerDetails.IOOwnerName;
            $.context.history.Comments = decision.Comments;
            $.context.EmailTemplateVars.approvalHistoryEmail.splice($.context.EmailTemplateVars.HistoryCount, 0 , $.context.history);
            while($.context.EmailTemplateVars.approvalHistoryEmail.length<20){
            $.context.EmailTemplateVars.approvalHistoryEmail.push({class :"hidden-row", HistoryData:"hide-row"});
            }
            $.context.EmailTemplateVars.HistoryCount++;            
            IOOwnerId.push(io_OwnerDetails.IOOwnerUserId);
        }
        else if ($.context.io_OwnerResource[i].NominatedResources[0].Io_Decision === "Reject") {
            var reqResource = $.context.reqResource.split(",");
            var result = [];
            for (var j = 0; j < reqResource.length; j++) {
                if (reqResource[j] && reqResource[j] !== $.context.io_OwnerResource[i].NominatedResources[0].userId) {
                    result.push(reqResource[j]);
                }
            }
            $.context.reqResource = result.join(",") + ",";           
            $.context.io_OwnerRejectResource.push($.context.io_OwnerResource[i]);
            var nominated = $.context.io_OwnerResource[i].NominatedResources[0];
            var AssignmentApprove = [];                      
            for (var k = 0; k < $.context.AssignmentApprove.length; k++) {
                var AssignedResource = $.context.AssignmentApprove[k];
                var resourceUserId = AssignedResource.ResCurrentProcessor.userId;
                var resourceAssignmentId = AssignedResource.AssignmentID;                
                if (!(resourceUserId === nominated.userId &&
                    String(resourceAssignmentId) === String(nominated.AssignmentID))) {                    
                    AssignmentApprove.push(AssignedResource);
                }
            }           
            $.context.AssignmentApprove = AssignmentApprove;           
            var decision = {                
                "UserName": io_OwnerDetails.IOOwnerName,
                "Role": "IO Owner",
                "StepName": $.context.CurrentStepValue.IOOAPP.Value,//"Presales IO Owner Approval",
                "StepID" : $.context.CurrentStepValue.IOOAPP.ID,
                "Decision": "The staffing request of " + $.context.io_OwnerResource[i].NominatedResources[0].fullName + " is Sent back to processor by " + io_OwnerDetails.IOOwnerName,
                "Comments": comments,
                "Date": new Date()
            };            
            $.context.approvalHistory.push(decision); 
            $.context.history.UserName = io_OwnerDetails.IOOwnerName;  
            $.context.history.LastStep = $.context.history.StepName; 
            $.context.history.StepName = $.context.history.StepName + " - Sent Back to Processor";         
            $.context.history.Decision = "The staffing request of " + $.context.io_OwnerResource[i].NominatedResources[0].fullName + " is Sent back to processor by " + io_OwnerDetails.IOOwnerName ;
            $.context.history.Comments = decision.Comments;
            $.context.EmailTemplateVars.approvalHistoryEmail.splice($.context.EmailTemplateVars.HistoryCount, 0 , $.context.history);
            while($.context.EmailTemplateVars.approvalHistoryEmail.length<20){
            $.context.EmailTemplateVars.approvalHistoryEmail.push({class :"hidden-row", HistoryData:"hide-row"});
            }
            $.context.EmailTemplateVars.HistoryCount++;            
             IOOwnerId.push(io_OwnerDetails.IOOwnerUserId);
        }
        else {
            var decision = {
                "UserName": $.context.currentProcessor.fullName,
                "Role": "IO Owner",
                "StepName": $.context.CurrentStepValue.IOOAPP.Value,
                "StepID": $.context.CurrentStepValue.IOOAPP.ID,
                "Decision": "Reject/Closed",
                "Comments": comments,
                "Date": new Date()
            };
            $.context.approvalHistory.push(decision); 
            $.context.history.UserName = io_OwnerDetails.IOOwnerName;  
            $.context.history.LastStep = $.context.history.StepName;  
            $.context.history.StepName = $.context.history.StepName + " - Staffing Rejected";     
            $.context.history.Decision = "The staffing request of " + $.context.io_OwnerResource[i].NominatedResources[0].fullName + " is Rejected by " + io_OwnerDetails.IOOwnerName;         
            $.context.history.Comments = decision.Comments;
            $.context.EmailTemplateVars.approvalHistoryEmail.splice($.context.EmailTemplateVars.HistoryCount, 0 , $.context.history);
            while($.context.EmailTemplateVars.approvalHistoryEmail.length<20){
            $.context.EmailTemplateVars.approvalHistoryEmail.push({class :"hidden-row", HistoryData:"hide-row"});
            }
            $.context.EmailTemplateVars.HistoryCount++;            
             IOOwnerId.push(io_OwnerDetails.IOOwnerUserId);
        }
    }
}
$.context.EmailTemplateVars.LastActionDateTime = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].DateUTC + " at " + $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].TimeUTC;
$.context.EmailTemplateVars.LastAction = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].UserName +" – "+ $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].LastStep+" – "+$.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].Decision;
$.context.EmailTemplateVars.LastActionComment = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].Comments;

if ($.context.io_OwnerRejectResource.length > 0) {
    for (var i = 0; i < $.context.io_OwnerRejectResource.length; i++) {
        $.context.AssignmentReject.push($.context.io_OwnerRejectResource[i]);
    }
    $.context.ResReject = true;
}

$.context.LenAssigntReject += $.context.io_OwnerRejectResource.length;
$.context.approvalHistoryTemp = $.context.approvalHistory;

var IO_id = "";
var IO_uniqueIds = {};
//remove duplicates
IOOwnerId.forEach(function(id) {
    if (!(id in IO_uniqueIds)) {
        IO_uniqueIds[id] = id;
        IO_id += id + ",";
    }
});
$.context.reqIOApprover = IO_id.slice(0, -1);