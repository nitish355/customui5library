if ($.context.isRework) {
    $.context.currentStepName = $.context.CurrentStepValue.REESUB.Value;//"Request Re-Submission"
    $.context.currentStepID = $.context.CurrentStepValue.REESUB.ID;
}

var decision = {
    "UserId": $.context.requesterDetails.id, //Userid for approvalHistory
    "UserName": $.context.requesterDetails.fullName,
    "Role": $.context.currentProcessorRole,
    "StepName": $.context.currentStepName,
    "StepID" : $.context.currentStepID,
    "Decision": $.context.decision,
    "Comments": $.context.comments,
    "Date": new Date()
};
$.context.history  = {};  
var now = new Date();
var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
var day = ("0" + now.getUTCDate()).slice(-2), month = months[now.getUTCMonth()],year = now.getUTCFullYear();
$.context.history.DateUTC = month + " " + day + ", " + year;
var hours = now.getUTCHours(), minutes = ("0" + now.getUTCMinutes()).slice(-2),ampm = hours >= 12 ? 'PM' : 'AM';
hours = hours % 12;
hours = hours ? hours : 12; 
$.context.history.TimeUTC = hours + ":" + minutes + " " + ampm + " UTC"; 
$.context.history.UserName = $.context.requesterDetails.fullName;
$.context.history.LastStep = 'Review - Requestor';
$.context.history.StepName = 'Review - Requestor - Cancelled';
$.context.history.Decision = 'Cancelled the Request for '+ $.context.RequestType +" "+ $.context.EmailRequestTypeID;
$.context.history.Comments = $.context.comments? $.context.comments:"";
$.context.history.class = "";
$.context.history.HistoryData = "History-Data";
$.context.EmailTemplateVars.approvalHistoryEmail.splice($.context.EmailTemplateVars.HistoryCount, 0 , $.context.history);
while($.context.EmailTemplateVars.approvalHistoryEmail.length<20){
  $.context.EmailTemplateVars.approvalHistoryEmail.push({class :"hidden-row", HistoryData:"hide-row"});
}
$.context.EmailTemplateVars.HistoryCount++;
$.context.EmailTemplateVars.LastActionDateTime = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].DateUTC + " at " + $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].TimeUTC;
$.context.EmailTemplateVars.LastAction = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].UserName +" – "+ $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].LastStep+" – "+$.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].Decision;
$.context.EmailTemplateVars.LastActionComment = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].Comments;
$.context.approvalHistory.push(decision);
$.context.lastRequestorComments = $.context.comments ? $.context.comments : "";
$.context.comments = "";
$.context.lastActivityDate = new Date();
$.context.currentState = $.context.CurrentStateValue.REQTER.Value;
$.context.currentStateID = $.context.CurrentStateValue.REQTER.ID;