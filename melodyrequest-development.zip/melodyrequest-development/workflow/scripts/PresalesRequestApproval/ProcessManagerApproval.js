$.context.lastActivityDate = new Date();
$.context.currentState = $.context.CurrentStateValue.WMNAPP.Value;
$.context.currentStepName = $.context.CurrentStepValue.MANAPP.Value; //"Presales Manager Approval";
$.context.currentStepID = $.context.CurrentStepValue.MANAPP.ID;
$.context.currentProcessorRole = "Approver";
$.context.lastDecisionTask = 1;