//code for email template
$.context.approverData.Shortname = $.context.approverData.fullName.replace(/^(\S).*\s(\S+)$/, function (_, first, last) {
	return first.toUpperCase() + '. ' + last.charAt(0).toUpperCase() + last.slice(1).toLowerCase();
});
var resourcesAllNames = "";
var resourcesAllEmails = "";
var resourcesAllIDs = "";
for (var i = 0; i < $.context.UniqueNominatedResources.length; i++) {
    resourcesAllNames += $.context.UniqueNominatedResources[i].fullName + ",";
    resourcesAllEmails += $.context.UniqueNominatedResources[i].email + ",";
    resourcesAllIDs += $.context.UniqueNominatedResources[i].userId + ",";
}
resourcesAllEmails = resourcesAllEmails.substring(0, resourcesAllEmails.length - 1);
resourcesAllNames = resourcesAllNames.substring(0, resourcesAllNames.length - 1);
resourcesAllIDs = resourcesAllIDs.substring(0, resourcesAllIDs.length - 1);
$.context.DBCall.Request.requests[0].body.currentProcessor = resourcesAllNames;
$.context.DBCall.Request.requests[0].body.currentProcessorEmail = resourcesAllEmails;
$.context.DBCall.Request.requests[0].body.currentProcessorID = resourcesAllIDs;
$.context.approvalHistoryTemp = [];
$.context.approvalHistoryTemp = $.context.approvalHistory;

$.context.resourcecomment = [];

if ($.context.isResourceProfile === true) {
	for (var i = 0; i < 10; i++) {
		if (i >= $.context.ProcessorComment.length) {			
			$.context.resourcecomment.push({ reqResource: [], comment: "",assignedActivity :[], class: "hidden-row", ActivityHide: "hidden-row" });
		} else {
			var processorEntry = $.context.ProcessorComment[i];
			var reqResourceArray = [];
			var reqActivityArray =[];
			for (var j = 0; j < processorEntry.assignedActivity.length; j++) {
				var Activity = {
					ActivityUrl: processorEntry.assignedActivity[j].activityUrl,
					ActivityDesc: processorEntry.assignedActivity[j].ActivityDesc,
					class: "styled-link"
				};				
				if (j !== processorEntry.assignedActivity.length - 1 && j<4) {
					Activity.Separator = ",";
				}

				reqActivityArray.push(Activity);
			}
				var resource = {
					resourceID: processorEntry.reqResource[0].resourceID,
					fullName: processorEntry.reqResource[0].fullName,
					resourceName: processorEntry.reqResource[0].resourceName,
					class: "styled-link"
				};				
			reqResourceArray.push(resource);
			while (reqActivityArray.length < 10) {
				reqActivityArray.push({ class: "hidden-row" });
			}
			var ActivityHide = processorEntry.assignedActivity.length == 0 ? "hidden-row" : "";
			$.context.resourcecomment.push({
				reqResource: reqResourceArray,
				comment: processorEntry.comment,
				assignedActivity: reqActivityArray,
				ActivityHide: ActivityHide,
				class: "styled-link"
			});
		}
	}
	
	
}

var UserTaskRole = "";
var newdate = new Date().toISOString();
if ($.context.UserTaskLabelValue) {
          UserTaskRole = $.context.UserTaskLabelValue.Processor.userTask; }

if ($.context.ProcessorComment) {
	for (var j = 0; j < $.context.ProcessorComment.length; j++) {
		if ($.context.ProcessorComment[j].comment && $.context.ProcessorComment[j].comment.trim() !== "") {
			var cmt = $.context.ProcessorComment[j].comment;
			$.context.DBCall.Request.requests.push({
				id: (j + 6 + $.context.Assignment.length + $.context.Assignment.length + $.context.WfInsProc_DelURLsLength.length).toString(),
				method: "POST",
				headers: { "content-type": "application/json;IEEE754Compatible=true" },
				url: "/Comments",
				body: {
					instanceID: $.info.workflowInstanceId,
					actionId: $.context.decision_ID,
					commentText: cmt,
					userID: $.context.approverData.id,
					userEmail: $.context.approverData.email,
					userName: $.context.approverData.fullName,
					userRole: UserTaskRole,
					createdAt: newdate,
					modifiedAt: newdate
				}
			});
		}
	}
}
$.context.PreviousProcessEmail_Notif = "";