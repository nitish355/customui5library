//// Temporary Code For Single IO Owner for all assignments

// var io_OwnerResource = $.context.io_OwnerResource,
// 	io_OwnerUserId = io_OwnerResource[0].NominatedResources[0].ioOwnerDetails.IOOwnerUserId;
// var io_owner_one = {},
// 	io_owner_two = {};
// 	io_owner_two.Assignment = [];
// 	io_owner_one.Assignment = [];
// $.context.io_OwnerResourceAssign = []
// if(io_OwnerResource.length > 0) {
// for (var i = 0; i < io_OwnerResource.length; i++) {
// 	if (io_OwnerUserId != io_OwnerResource[i].NominatedResources[0].ioOwnerDetails.IOOwnerUserId) {
// 		io_owner_two.ioOwnerDetails = io_OwnerResource[i].NominatedResources[0].ioOwnerDetails;
// 		io_owner_two.Assignment.push(io_OwnerResource[i]);
// 	}
// 	else {
// 	io_owner_one.ioOwnerDetails = io_OwnerResource[i].NominatedResources[0].ioOwnerDetails;
// 		io_owner_one.Assignment.push(io_OwnerResource[i]);
// 	}
// }
//   if(io_owner_one.Assignment.length > 0) {
// 	$.context.io_OwnerResourceAssign.push(io_owner_one);
	
//   }
//   if(io_owner_two.Assignment.length > 0) {
// 	$.context.io_OwnerResourceAssign.push(io_owner_two);
//   }
 
// }
// else{
    
//     $.context.io_OwnerResourceAssign[0].Assignment = [];
//     $.context.io_OwnerResourceAssign[0].ioOwnerDetails = io_OwnerResource[0].NominatedResources[0].ioOwnerDetails;
//     $.context.io_OwnerResourceAssign[0].Assignment.push(io_OwnerResource[0]);
// }
