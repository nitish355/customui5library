
$.context.ResRework = false;
$.context.ResReject = false;
$.context.ResApprove = false;
var aAssignment = $.context.Assignment;
$.context.WfInsRes_DelURLs = [];
if (aAssignment.length > 0) {
	for (var i = 0; i < aAssignment.length; i++) {

		if (aAssignment[i].ResDecision == "Send Back to Requestor") {
			$.context.reworkAssignID = aAssignment[i].AssignmentID ;
			$.context.Assignment[i].ResCurrentStepName = $.context.CurrentStepValue.RESAPP.Value;//"Presales Resource Approval";
			$.context.Assignment[i].ResCurrentProcessorRole = "Requestor";
			$.context.ResRework = true;
			$.context.comments = aAssignment[i].ResComments;
			$.context.currentProcessor = $.context.requesterDetails;
			$.context.decision = aAssignment[i].ResDecision;
			$.context.currentProcessorRole = "Requestor";
			$.context.currentStepName = $.context.CurrentStepValue.RESAPP.Value;//"Presales Resource Approval";
			$.context.currentStepID = $.context.CurrentStepValue.RESAPP.ID;
			$.context.ResReworkProcessor = aAssignment[i].ResCurrentProcessor.fullname;
			$.context.ResReworkProcessorId = aAssignment[i].ResCurrentProcessor.userId;  // userId for History
			$.context.RerReworkRole = "Assignment ID " + aAssignment[i].AssignmentID + " - Asignee"

			//Start of Comment on 04/05/24 -- DELETE LATER
			// for (var k = 0; k < aAssignment[i].NominatedResources.length; k++) {
			// 	if (aAssignment[i].NominatedResources[k].NomResRejectDecision == "Reject") {
			// 		var id = aAssignment[i].NominatedResources[k].userId;
			// 		delete $.context.DBCall.ResourcesDeleteURLs[id];
			// 	}
			// }
			//End of Comment on 04/05/24 -- DELETE LATER



		}

		if (aAssignment[i].ResDecision == "Reject") {
			$.context.ResReject = true;

			//Start of Comment on 04/05/24 -- DELETE LATER
			// for (var k = 0; k < aAssignment[i].NominatedResources.length; k++) {
			// 	if (aAssignment[i].NominatedResources[k].NomResRejectDecision == "Reject") {
			// 		var id = aAssignment[i].NominatedResources[k].userId;
			// 		delete $.context.DBCall.ResourcesDeleteURLs[id];
			// 	}
			// }
			//End of Comment on 04/05/24 -- DELETE LATER

		}

		if (aAssignment[i].ResDecision == "Approve") {
			$.context.ResApprove = true;

			//Start of Comment on 04/05/24 -- DELETE LATER
			// for (var k = 0; k < aAssignment[i].NominatedResources.length; k++) {
			// 	if (aAssignment[i].NominatedResources[k].NomResRejectDecision == "Reject") {
			// 		var id = aAssignment[i].NominatedResources[k].userId;
			// 		delete $.context.DBCall.ResourcesDeleteURLs[id];
			// 	}
			// }
			//End of Comment on 04/05/24 -- DELETE LATER

		}
		if(!aAssignment[i].ResDecision){
			var WfInsRes_DelURLs = "/WfInsProcessor(InstanceID=" + $.info.workflowInstanceId + ",assignmentID='" + aAssignment[i].AssignmentID + "',currentProcessorID='" + aAssignment[i].NominatedResources[0].userId + "')";
			$.context.WfInsRes_DelURLs.push(WfInsRes_DelURLs);
		}

	}


}

$.context.AllReject = false;
if ($.context.ResApprove === false && $.context.ResRework === false && $.context.ResReject === true) {
	$.context.AllReject = true;
}
if (!$.context.io_Owner_email) {
    $.context.io_Owner_email = $.context.extSystemsUrls.MRRInboxURL + "IOOwnerDetailPage/" + $.info.workflowInstanceId;
    $.context.requestor_email = $.context.extSystemsUrls.MRRInboxURL + "SubmitReq/" + $.info.workflowInstanceId;
    $.context.processor_email = $.context.extSystemsUrls.MRRInboxURL + "ManagerDetailPage/" + $.info.workflowInstanceId;
}

