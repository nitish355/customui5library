var allApproveResource = $.context.AssignmentApprove;
$.context.io_Owner = false;
$.context.autoStaffedResource = [];
$.context.io_OwnerApproveResource = [];
$.context.io_OwnerRejectResource = [];
$.context.io_OwnerResource = [];
$.context.io_OwnerDetails = [];

//filtering out the autostaffed resources
for (var i = 0; i < allApproveResource.length; i++) {
	var isIOStaffing = allApproveResource[i].isIOStaffing;
	if (isIOStaffing === true) {
		var aNominatedPresales = allApproveResource[i].NominatedResources;
		var resCurrentProcessor_email = allApproveResource[i].ResCurrentProcessor.email;
		aNominatedPresales.forEach(function (val) {
			if (val.email === resCurrentProcessor_email) {
				if ((val.isAutoStaffing === true) || (val.isAutoStaffingCompanyCode === true) || (val.isPartOfException === true)) {
					$.context.autoStaffedResource.push(allApproveResource[i]);
				}
				else if($.context.Skip_IO_Owner_WF === true && val.isAutoStaffingCompanyCode === false);
				else {
					$.context.io_Owner = true;
					$.context.io_OwnerDetails.push(val.ioOwnerDetails);
					$.context.io_OwnerResource.push(allApproveResource[i]);

				}
			}
		});
	}
	else {
		$.context.autoStaffedResource.push(allApproveResource[i]);
	}
}

if ($.context.io_OwnerResource.length > 0) {
	for (var i = 0; i < $.context.io_OwnerResource.length; i++) {
		var aNominatedPresales = $.context.io_OwnerResource[i].NominatedResources;
		var resCurrentProcessor_email = $.context.io_OwnerResource[i].ResCurrentProcessor.email;
		aNominatedPresales.forEach(function (val) {
			if (val.email === resCurrentProcessor_email) {
				$.context.io_OwnerResource[i].NominatedResources = [];
				$.context.io_OwnerResource[i].NominatedResources[0] = val;
			}
		});
	}
}


// $.context.isAllNotStaffedResource = true;
// if ($.context.autoStaffedResource.length > 0) {
// 	$.context.isAllNotStaffedResource = false;
	// $.context.LenAssigntApprove = "";
	// $.context.AssignmentApprove = [];
	// $.context.LenAssigntApprove = $.context.autoStaffedResource.length;
	// $.context.AssignmentApprove = $.context.autoStaffedResource;
// }