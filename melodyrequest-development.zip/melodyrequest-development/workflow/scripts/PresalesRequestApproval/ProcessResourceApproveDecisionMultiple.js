var now = new Date();
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');


var len = $.context.LenAssigntApprove;
    len = len - 1;
var aAssignmentApprove = $.context.AssignmentApprove[len];
var LenAssignApprAll = $.context.AssignmentApproveAll.length;
if (!$.context.comments) {
    $.context.comments = "";
}
$.context.lastAcceptorComments = $.context.ResComments ? $.context.ResComments : "";
$.context.resCurrentProcessor_id = aAssignmentApprove.ResCurrentProcessor.userId;
$.context.resCurrentProcessor_fullName = aAssignmentApprove.ResCurrentProcessor.fullname;
$.context.resCurrentProcessor_email = aAssignmentApprove.ResCurrentProcessor.email;

$.context.reqResource += aAssignmentApprove.ResCurrentProcessor.userId + ",";
//$.context.acceptorComment = $.context.ResComments;
$.context.comments = "";

// enrich current processor details  
var aAssignedPresales = aAssignmentApprove.NominatedResources //$.context.assignedPresales;
aAssignedPresales.forEach(function (val) {
    if (val.email === aAssignmentApprove.ResCurrentProcessor.email) { // $.context.currentProcessor.email) {
    
        $.context.AssignmentApprove[len].ResCurrentProcessor.id = val.userId;
        $.context.ResCurrentProcessorEmailFinal = aAssignmentApprove.ResCurrentProcessor.email;
        $.context.ResDirectManagerEmail = aAssignmentApprove.NominatedResources[0].resourceManagerDetails.EMAIL;
        $.context.ResDirectManagerId = aAssignmentApprove.NominatedResources[0].resourceManagerDetails.ID;

        //Logic to fill ResCurrentProcessor details for $.context.AssignmentApproveAll
        for (var p = 0; p < LenAssignApprAll; p++) {
            if ( $.context.AssignmentApproveAll[p].ResCurrentProcessor.email === aAssignmentApprove.ResCurrentProcessor.email) {
                $.context.AssignmentApproveAll[p].ResCurrentProcessor.id = val.userId;
            }
        }
    }
});

if ($.context.RequestType == "Account") {
$.context.AccountassignedResourceDetails = {
    "fullName": aAssignmentApprove.ResCurrentProcessor.fullname,
    "UserID": $.context.AssignmentApprove[len].ResCurrentProcessor.id,
    "email": aAssignmentApprove.ResCurrentProcessor.email,
    "roleID": aAssignmentApprove.ResAssignedRoleData.id
}
}


var fullNames = [];
fullNames.push($.context.requesterDetails.id);
var fullApproveDearText = "Dear " + $.context.requesterDetails.fullName + ",\n";

if ($.context.oppOwnerDetails.fullName && fullNames.indexOf($.context.oppOwnerDetails.id) === -1) {
    fullNames.push($.context.oppOwnerDetails.id);
    fullApproveDearText += "Dear " + $.context.oppOwnerDetails.fullName + ",\n";
}
if ($.context.accOwnerDetails.fullName && fullNames.indexOf($.context.accOwnerDetails.id) === -1) {
    fullNames.push($.context.accOwnerDetails.id);
    fullApproveDearText += "Dear " + $.context.accOwnerDetails.fullName + ",\n";
}
if ($.context.approverData.fullName && fullNames.indexOf($.context.approverData.id) === -1) {
    fullNames.push($.context.approverData.id);
    fullApproveDearText += "Dear " + $.context.approverData.fullName + ",\n";
}
if (aAssignmentApprove.ResCurrentProcessor.fullname && 
        fullNames.indexOf($.context.AssignmentApprove[len].ResCurrentProcessor.id) === -1) {
    fullNames.push($.context.AssignmentApprove[len].ResCurrentProcessor.id);
    fullApproveDearText += "Dear " + aAssignmentApprove.ResCurrentProcessor.fullname + ",\n";
} 

$.context.fullApproveDearText = fullApproveDearText;
// To be used in Email Task 'Notify About Resource Approval'
$.context.ResourceApproveCurrentProcessor = aAssignmentApprove.ResCurrentProcessor.fullname;
$.context.ResourceApproveAssignedRoleDataName = aAssignmentApprove.ResAssignedRoleData.name;
$.context.ResourceApproveExpectedTimeInvestment = aAssignmentApprove.TimeInvestment;
$.context.acceptorComment = aAssignmentApprove.ResComments;

$.context.LenAssigntApprove -= 1;

if ($.context.Skip_Resource_Approver == true) {    
//prepare data for ReqHistory 
$.context.WFHistory = {};
$.context.WFHistory.Request = {};
$.context.WFHistory.Request.requests = [];
var ReqHistory_data = {};
ReqHistory_data.InstanceID = $.info.workflowInstanceId;
ReqHistory_data.UserTaskID = aAssignmentApprove.ResourcesUserTaskID;
ReqHistory_data.AssignmentID = aAssignmentApprove.AssignmentID;
ReqHistory_data.User_ID = aAssignmentApprove.ResCurrentProcessor.id;
ReqHistory_data.User_Name = aAssignmentApprove.ResCurrentProcessor.fullname;
ReqHistory_data.User_EMail = aAssignmentApprove.ResCurrentProcessor.email;
ReqHistory_data.StateID = $.context.CurrentStateValue.WRESAP.ID;
ReqHistory_data.StepID = $.context.CurrentStepValue.RESAPP.ID;
ReqHistory_data.ActionTaken = "Approve";
ReqHistory_data.Role = "Resource";
ReqHistory_data.Decision = $.context.decision_ID;
ReqHistory_data.Comments = aAssignmentApprove.comments;
ReqHistory_data.Date = date;
ReqHistory_data.Time = time;
if (!$.context.UT_refID) {
    $.context.UT_refID = 1;
}
else {
    $.context.UT_refID += 1;
}
ReqHistory_data.UT_refID = $.context.UT_refID;

$.context.WFHistory.Request.requests.push({   
    id: "1",
    method: "POST",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WFHistory",
    body: ReqHistory_data
});
}
if(!$.context.io_OwnerEmails){
	$.context.io_OwnerEmails ="";
}

$.context.User_NotifDBCallPayload = {};
var users = {};
var UserNotifpayload = {};
UserNotifpayload.notif_Id = "15";
UserNotifpayload.notifVal_Id = "0002";
if ( aAssignmentApprove.ResCurrentProcessor.id && aAssignmentApprove.ResCurrentProcessor.email) {
    $.context.AllApprovedResources.push({
        userId: aAssignmentApprove.ResCurrentProcessor.id.toUpperCase(),
        email: aAssignmentApprove.ResCurrentProcessor.email
});
  users.resource = [{
    userId: aAssignmentApprove.ResCurrentProcessor.id.toUpperCase(),
    email: aAssignmentApprove.ResCurrentProcessor.email
  }];  
}
if ( Object.keys(users).length > 0) {
  UserNotifpayload.users = users;
  $.context.User_NotifDBCallPayload = UserNotifpayload;
}