var now = new Date();
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');

// $.context.DBCall = {};
if (!$.context.DBCall) {
    $.context.DBCall = {};
}
$.context.DBCall.isWfInstanceUpdate = true;
$.context.DBCall.Request = {};
 
// Prepare data for WFINSTANCE New Table 
var wfIns_data = {};
wfIns_data.instance_GUID = $.info.workflowInstanceId;
wfIns_data.parentInstance_GUID = $.context.parentInstanceID;
wfIns_data.technicalStateID = $.context.TechnicalStateValue.COMP.ID;
wfIns_data.currentStateID = $.context.currentStateID;
wfIns_data.currentStepID = $.context.CurrentStepValue.REQSUB.ID;
//wfIns_data.comments = $.context.comments;
if ($.context.isRework) {
    wfIns_data.currentStepID = $.context.CurrentStepValue.REESUB.ID;
}
if ($.context.currentProcessor) {
    wfIns_data.currentProcessorID = $.context.currentProcessor.id;
    wfIns_data.currentProcessor = $.context.currentProcessor.fullName;
    wfIns_data.currentProcessorEmail = $.context.currentProcessor.email;
} else if ($.context.requesterDetails) {
    wfIns_data.currentProcessorID = $.context.requesterDetails.id;
    wfIns_data.currentProcessor = $.context.requesterDetails.fullName;
    wfIns_data.currentProcessorEmail = $.context.requesterDetails.email;
} else {
    wfIns_data.currentProcessorID = "";
    wfIns_data.currentProcessor = "";
    wfIns_data.currentProcessorEmail = "";
}
if ($.context.decision_ID) {
wfIns_data.decisionID  = $.context.decision_ID;
}
wfIns_data.dtLastActivity_tdate   = date;
wfIns_data.dtLastActivity_ttime = time;
if($.context.UserTaskLabelValue)
    {
        wfIns_data.userTaskID = $.context.UserTaskLabelValue.None.userTaskID;
    }
 
/* Prepare data for WfInsProcessor (Current Processor) Table */
var WfInsProc_data = {};
WfInsProc_data.InstanceID = $.info.workflowInstanceId;
WfInsProc_data.assignmentID = "1";
WfInsProc_data.currentProcessorID = wfIns_data.currentProcessorID;
WfInsProc_data.currentProcessorName = wfIns_data.CurrentProcessor;
WfInsProc_data.currentProcessorEmail = wfIns_data.currentProcessorEmail;

//prepare data for WFhistory
var ReqHistory_data = {};
ReqHistory_data.InstanceID = $.info.workflowInstanceId;
ReqHistory_data.UserTaskID =  $.usertasks.usertask1.last.id;
ReqHistory_data.AssignmentID = "0";
ReqHistory_data.User_ID =  $.context.requesterDetails.id;
ReqHistory_data.User_Name =  $.context.requesterDetails.fullName;
ReqHistory_data.User_EMail = $.context.requesterDetails.email;
ReqHistory_data.StateID = $.context.CurrentStateValue.REQTER.ID;
ReqHistory_data.StepID = $.context.currentStepID;
ReqHistory_data.ActionTaken = "Cancelled the Request";
ReqHistory_data.Role = "Requester";
ReqHistory_data.Decision = $.context.decision_ID;
ReqHistory_data.Comments = $.context.comments;
ReqHistory_data.Date = date;
ReqHistory_data.Time = time;
if (!$.context.UT_refID) {
    $.context.UT_refID = 1;
}
else {
    $.context.UT_refID += 1;
}
ReqHistory_data.UT_refID = $.context.UT_refID;

/* Prepare DB Call for Workflow Tables */
$.context.DBCall.Request.requests = [];
var wfRequest = {
    id: "1",
    method: "PATCH",
    url: "/WfInstance(instance_GUID='" + $.info.workflowInstanceId + "',parentInstance_GUID='" + $.context.parentInstanceID + "')",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    body: wfIns_data
};
$.context.DBCall.Request.requests.push(wfRequest);
 
var WfInsProc_Request = {
    id: "2",
    method: "PATCH",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WfInsProcessor(InstanceID=" + $.info.workflowInstanceId + ",assignmentID='1',currentProcessorID='" + wfIns_data.currentProcessorID + "')",
    body: WfInsProc_data
};
$.context.DBCall.Request.requests.push(WfInsProc_Request);

var wfhistory_Request = {   
    id: "3",
    method: "POST",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WFHistory",
    body: ReqHistory_data
};
$.context.DBCall.Request.requests.push(wfhistory_Request);
if(!$.context.io_OwnerEmails){
	$.context.io_OwnerEmails ="";
}
$.context.commentNotif_flag = false;
// Push Comments request only if a comment was provided
if ($.context.comments && $.context.comments.trim() !== "") {
    var UserTaskRole = "";
    var newdate = new Date().toISOString();
    if ($.context.UserTaskLabelValue) {
        UserTaskRole = $.context.UserTaskLabelValue.Requestor.userTask;
    }
    $.context.DBCall.Request.requests.push({
        id: "4",
        method: "POST",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: "/Comments",
        body: {
            instanceID: $.info.workflowInstanceId,
            actionId: $.context.decision_ID,
            commentText: $.context.comments,
            userID: $.context.requesterDetails.id,
            userEmail: $.context.requesterDetails.email,
            userName: $.context.requesterDetails.fullName,
            userRole: UserTaskRole,
            createdAt: newdate,
            modifiedAt: newdate
        }
    });
    var userChatCommentDetails = {};
        userChatCommentDetails.commentText = $.context.comments;
        userChatCommentDetails.userID = $.context.requesterDetails.id;
        userChatCommentDetails.userEmail = $.context.requesterDetails.email;
        userChatCommentDetails.userName = $.context.requesterDetails.fullName;
        userChatCommentDetails.userRole = UserTaskRole;
        userChatCommentDetails.commentType =  "ACTION";
        $.context.commentNotif_flag = true;
        $.context.userChatCommentDetails = userChatCommentDetails;
        var CommentNotifPayload = {};
        CommentNotifPayload.context = {};
        CommentNotifPayload.context = JSON.stringify($.context);
        $.context.CommentNotifPayload = CommentNotifPayload;
}