var now = new Date();
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');
if (!$.context.DBCall) {
    $.context.DBCall = {};
}
$.context.DBCall.isWfInstanceUpdate = $.context.wasReworked ? true : false;

$.context.DBCall.Request = {};

// Prepare data for WFINSTANCE New Table
var wfIns_data = {};
wfIns_data.instance_GUID             = $.info.workflowInstanceId;
wfIns_data.parentInstance_GUID      = $.context.parentInstanceID;
wfIns_data.currentTaskInstanceID     = null;
wfIns_data.technicalStateID = $.context.TechnicalStateValue.INPR.ID;
wfIns_data.currentStateID = $.context.CurrentStateValue.WMNAPP.ID;
wfIns_data.currentStepID = $.context.CurrentStepValue.MANAPP.ID;
wfIns_data.currentProcessorID = $.context.approversIds;
wfIns_data.currentProcessor = $.context.approverNames;
wfIns_data.currentProcessorEmail = $.context.approversEmails;
wfIns_data.substituteProcessorID = "";
wfIns_data.substituteProcessor = "";
wfIns_data.substituteProcessorEmail = "";
wfIns_data.approvers = $.context.ApproverInfo;
wfIns_data.dtLastActivity_tdate = date;
wfIns_data.dtLastActivity_ttime = time;
wfIns_data.reqAreaGUID               =$.context.GUID;
wfIns_data.decisionID                = $.context.decision_ID;
//wfIns_data.comments = $.context.comments;
wfIns_data.reqApprover_ID = $.context.currentProcessor.id;
wfIns_data.reqApprover_Name = $.context.currentProcessor.fullName;
wfIns_data.reqApprover_EMail = $.context.currentProcessor.email;
wfIns_data.currentTaskURL = null;

var approvertaskid = "";
$.context.approverData = $.context.currentProcessor;
if ($.context.checkIsResource === true) {
    if ($.context.lastDecisionTask == 11) {
        approvertaskid = $.usertasks.usertask11.last.id;
    }
    else {
        approvertaskid = $.usertasks.usertask10.last.id;
    }
}
else {
if ($.context.lastDecisionTask == 3) {
    approvertaskid = $.usertasks.usertask5.last.id;
} else if ($.context.lastDecisionTask == 2) {
    approvertaskid = $.usertasks.usertask4.last.id;
} else if ($.context.lastDecisionTask == 1) {
    approvertaskid = $.usertasks.usertask2.last.id;
}
}
// prepare data for wfhistory
var ReqHistory_data = {};
ReqHistory_data.InstanceID = $.info.workflowInstanceId;
ReqHistory_data.UserTaskID = approvertaskid;
ReqHistory_data.AssignmentID = "0";
ReqHistory_data.User_ID =  $.context.currentProcessor.id;
ReqHistory_data.User_Name = $.context.currentProcessor.fullName;
ReqHistory_data.User_EMail = $.context.currentProcessor.email;
ReqHistory_data.StateID = $.context.CurrentStateValue.WMNAPP.ID;
ReqHistory_data.StepID = $.context.currentStepID;
ReqHistory_data.ActionTaken = "Forwarded from "+ $.context.oldReqArea + " to " + $.context.requestArea;
ReqHistory_data.Role = "Approver";
ReqHistory_data.Decision = $.context.decision_ID;
ReqHistory_data.Comments = $.context.comments;
ReqHistory_data.Date = date;
ReqHistory_data.Time = time;
if (!$.context.UT_refID) {
    $.context.UT_refID = 1;
}
else {
    $.context.UT_refID += 1;
}
ReqHistory_data.UT_refID = $.context.UT_refID;

$.context.DBCall.Request.requests = [];

var wfUrl = "/WfInstance(instance_GUID='" + $.info.workflowInstanceId + "',parentInstance_GUID='" + $.context.parentInstanceID + "')";
   

var wfRequest = {
    id: "1",
    method: "PATCH",
    url: wfUrl,
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    body: wfIns_data
};

$.context.DBCall.Request.requests.push(wfRequest);

$.context.DBCall.Request.requests.push({   
    id: "2",
    method: "POST",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WFHistory",
    body: ReqHistory_data
});

//Logic to DELETE Current Processors from table WfInsProcessor
var len_wfInsProc_DelURL = $.context.WfInsProc_DelURLs.length;
for (var i = 0; i < len_wfInsProc_DelURL; i++) {
    $.context.DBCall.Request.requests.push({
        id: (i + 3).toString(),
        dependsOn: ["1"],
        method: "DELETE",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: $.context.WfInsProc_DelURLs[i]
    });
}

$.context.WfInsProc_DelURLs = [];
//Logic to POST Current Processors (i.e. Resources) to table WfInsProcessor
for (var j = 0; j < $.context.approverDetails.length; j++) {
    $.context.DBCall.Request.requests.push({
        id: (j + 4 + len_wfInsProc_DelURL).toString(),
        //dependsOn: ["1"],
        dependsOn: [$.context.DBCall.Request.requests[$.context.DBCall.Request.requests.length-1].id],
        method: "POST",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: "/WfInsProcessor",
        body: {
            InstanceID: $.info.workflowInstanceId,
            assignmentID: "1",
            currentProcessorID: $.context.approverDetails[j].userId,
            currentProcessorName: $.context.approverDetails[j].fullName,
            currentProcessorEmail: $.context.approverDetails[j].email,
        }
    });
    var wfInsProc_DelURL = "/WfInsProcessor(InstanceID=" + $.info.workflowInstanceId + ",assignmentID='1',currentProcessorID='" + $.context.approverDetails[j].userId + "')";
    $.context.WfInsProc_DelURLs.push(wfInsProc_DelURL);
}

// Push Comments request only if a comment was provided
if ($.context.comments && $.context.comments.trim() !== "") {
     var UserTaskRole = "";
     var newdate = new Date().toISOString();
    if ($.context.UserTaskLabelValue) {
        UserTaskRole = $.context.UserTaskLabelValue.Processor.userTask;
    }
    $.context.DBCall.Request.requests.push({
        id: ( 5 + $.context.approverDetails.length + len_wfInsProc_DelURL).toString(),
        method: "POST",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: "/Comments",
        body: {
            instanceID: $.info.workflowInstanceId,
            actionId: $.context.decision_ID,
            commentText: $.context.comments,
            userID: $.context.currentProcessor.id,
            userEmail: $.context.currentProcessor.email,
            userName: $.context.currentProcessor.fullName,
            userRole: UserTaskRole,
            createdAt: newdate,
            modifiedAt: newdate
        }
    });
}

if($.context.isResourceProfile === false){
    $.context.checkIsResource = false;
}
$.context.comments = "";