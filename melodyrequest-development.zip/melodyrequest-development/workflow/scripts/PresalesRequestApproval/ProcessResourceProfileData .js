$.context.Em_ResPro = {};
var BA_IndString = "";

if ($.context.isResourceProfile === true) {
//    var BA_Segment = $.context.aResourceProfileApprovers.ResourceProfileDetails.BASegments;
   var Role = $.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedRole;
    var ResProfileSel_DelUrl = [];
    $.context.ResProfileSel_DelUrl = [];
   for (var i = 0; i < Role.length; i++) {
        $.context.DBCall.WfInstanceRequest.requests.push({
            id: (5 + i).toString(),
            dependsOn: ["1"],
            method: "POST",
            headers: { "content-type": "application/json;IEEE754Compatible=true" },
            url: "/ResProfileSel_Header",
            body: {
                InstanceID: $.info.workflowInstanceId,
                role_ID: $.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedRole[i].RoleID,
                roleArea_ID: $.context.aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RoleAreaID,             
                role_Desc: $.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedRole[i].RoleDesc,
                roleArea_Desc: $.context.aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RoleAreaDesc,
                ProfitCenter_GUID: $.context.selectedProfitCenter[0].guid
            }
        });

        ResProfileSel_DelUrl = "/ResProfileSel_Header(InstanceID=" + $.info.workflowInstanceId + ",role_ID='" + $.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedRole[i].RoleID + "',roleArea_ID='" + $.context.aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RoleAreaID + "')";
        $.context.ResProfileSel_DelUrl.push(ResProfileSel_DelUrl);
    };

    var BAIndustries = $.context.aResourceProfileApprovers.ResourceProfileDetails.BAIndustries;
    for (var m = 0; m < BAIndustries.length; m++) {
        $.context.DBCall.WfInstanceRequest.requests.push({
            id: (m + 9 + Role.length).toString(),
            dependsOn: ["1"],
            method: "POST",
            headers: { "content-type": "application/json;IEEE754Compatible=true" },
            url: "/ResProfileSel_BAIndustry",
            body: {
                InstanceID: $.info.workflowInstanceId,
                BA_Industry_ID: BAIndustries[m].BaIndId,
                BA_Industry_Desc: BAIndustries[m].Desc,
            }
        });

        //details used in email 
        BA_IndString += BAIndustries[m].Desc + ",";

        ResProfileSel_DelUrl = "/ResProfileSel_BAIndustry(InstanceID=" + $.info.workflowInstanceId + ",BA_Industry_ID='" + BAIndustries[m].BaIndId + "')";
        $.context.ResProfileSel_DelUrl.push(ResProfileSel_DelUrl);
    }

    var instanceId = $.info.workflowInstanceId,
        SolAreas = {},
        solutions = $.context.aResourceProfileApprovers.ResourceProfileDetails.AdditionalSolutions ? $.context.aResourceProfileApprovers.ResourceProfileDetails.AdditionalSolutions : [],
        materials = $.context.aResourceProfileApprovers.ResourceProfileDetails.Materials ? $.context.aResourceProfileApprovers.ResourceProfileDetails.Materials : [];
    var mainSolnPayload = {};
    if ($.context.aResourceProfileApprovers.ResourceProfileDetails.SolutionAreas && $.context.aResourceProfileApprovers.ResourceProfileDetails.SolutionAreas.length > 0) {
        SolAreas = $.context.aResourceProfileApprovers.ResourceProfileDetails.SolutionAreas[0];
        mainSolnPayload.InstanceID = instanceId;
        mainSolnPayload.solution_guid = SolAreas.soln_guid;
        mainSolnPayload.is_MainSoln = 'X';
    }
    if (Object.keys(mainSolnPayload).length !== 0) {
        var solnMatrlpayload = {};
        solnMatrlpayload.InstanceID = instanceId;
        solnMatrlpayload.additionalSolns = [];
        solnMatrlpayload.solMtrlList = [];
        if (solutions.length > 0 || materials.length > 0) {
            solnMatrlpayload = saveSolutionMatrlDataPayload(instanceId, solutions, materials);
        }
        solnMatrlpayload.additionalSolns.push(mainSolnPayload);

        $.context.DBCall.WfInstanceRequest.requests.push({
            id: (100 + Role.length + BAIndustries.length).toString(),
            dependsOn: ["1"],
            method: "POST",
            headers: { "content-type": "application/json;IEEE754Compatible=true" },
            url: "/saveSolutionMatrlData",
            body: solnMatrlpayload
        });
    }


    $.context.Em_ResPro.Role = $.context.aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RoleDesc;
    $.context.Em_ResPro.RoleArea = $.context.aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RoleAreaDesc;
    $.context.Em_ResPro.BA_Ind = BA_IndString;
}

function saveSolutionMatrlDataPayload(instanceId, solutions, materials) {
    return {
        InstanceID: instanceId,
        additionalSolns: solutions.map(function (sol) {
            return {
                InstanceID: instanceId,
                solution_guid: sol.soln_guid,
                is_MainSoln: ''
            };
        }),
        solMtrlList: materials.map(function (mat) {
            return {
                InstanceID: instanceId,
                MAT_ID: String(mat.MatId),
                SOL_YEAR: String(mat.SolYear)
            };
        })
    };
}