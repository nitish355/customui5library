var aSubtitutorsData = $.context.substituteApproverDetails,
    sSubtitutorIntro = "Dear " + aSubtitutorsData[0].fullName + ",",
    sSubtitutorEmails = aSubtitutorsData[0].email,
    sSubtitutorIds = aSubtitutorsData[0].userId,
    sApproverNames = aSubtitutorsData[0].fullName;
if (aSubtitutorsData.length > 1) {
    for (var i = 1; i < aSubtitutorsData.length; i++) {
        sSubtitutorIntro += "\nDear " + aSubtitutorsData[i].fullName + ",";
        sSubtitutorEmails += "," + aSubtitutorsData[i].email;
        sSubtitutorIds += "," + aSubtitutorsData[i].userId;
        sApproverNames += "," + aSubtitutorsData[i].fullName;
    }
}
//deployment test
$.context.currentState = $.context.CurrentStateValue.WSUBMN.Value;

$.context.subtitutorsNames = sApproverNames;
$.context.notifySubtitutorsEmailIntro = sSubtitutorIntro;
$.context.subtitutorsEmails = sSubtitutorEmails;
$.context.subtitutorsIds = sSubtitutorIds;

$.context.lastDecisionTask = 2;



//Temporary code  for managing Older requests available in My inbox.

if ($.context.RequestType == "Opportunity") {
	$.context.Opp_ID = "Opportunity ID:" ;
    $.context.CRev_L = "Cloud Revenue:" ;
    $.context.OpRev_L = "On Premise Revenue:" ;

	// code for dynamic email
	$.context.CRev = $.context.dealInfo.cloudRevenueFormatted;
	$.context.OpRev = $.context.dealInfo.onPremRevenueFormatted;

	$.context.isAccount = false;

	$.context.Approval_subject = "/ Opp." + $.context.opportunityId;
}
if (!$.context.io_Owner_email) {
    $.context.io_Owner_email = $.context.extSystemsUrls.MRRInboxURL + "IOOwnerDetailPage/" + $.info.workflowInstanceId;
    $.context.requestor_email = $.context.extSystemsUrls.MRRInboxURL + "SubmitReq/" + $.info.workflowInstanceId;
    $.context.processor_email = $.context.extSystemsUrls.MRRInboxURL + "ManagerDetailPage/" + $.info.workflowInstanceId;
}


    