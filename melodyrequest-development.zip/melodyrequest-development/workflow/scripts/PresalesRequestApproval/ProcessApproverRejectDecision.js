var decision = {
    "UserId": $.context.currentProcessor.id, // Userid for approvalHistory
    "UserName": $.context.currentProcessor.fullName,
    "Role": $.context.currentProcessorRole,
    "StepName": $.context.currentStepName,
    "StepID": $.context.currentStepID,
    "Decision": $.context.decision,
    "RejectionReason": $.context.rejectReason ? $.context.rejectReason:"",
    "Comments": $.context.comments,
    "Date": new Date()
};

$.context.approverData = $.context.currentProcessor;

var approverId = "";
$.context.approverData = $.context.currentProcessor;
if ($.context.isResourceProfile === true)
{
    if ($.context.lastDecisionTask == 11 ){
    approverId = $.usertasks.usertask11.last.processor;
}
    else {
        approverId = $.usertasks.usertask10.last.processor;
    }
}
else {
if ($.context.lastDecisionTask == 3) {
    approverId = $.usertasks.usertask5.last.processor
} else if ($.context.lastDecisionTask == 2) {
    approverId = $.usertasks.usertask4.last.processor
} else if ($.context.lastDecisionTask == 1) {
    approverId = $.usertasks.usertask2.last.processor
}
}

$.context.approverData.id = approverId;
$.context.approvalHistory.push(decision);
$.context.lastApproverComments = $.context.comments ? $.context.comments : "";
// $.context.comments = "";
$.context.lastActivityDate = new Date();
if ($.context.isResourceProfile === true){
    $.context.currentState = $.context.requestState;
    $.context.currentStateID = $.context.requestStateID;
}
else
{
    $.context.currentState = $.context.CurrentStateValue.REQREJ.Value;
    $.context.currentStateID =  $.context.CurrentStateValue.REQREJ.ID;
}
