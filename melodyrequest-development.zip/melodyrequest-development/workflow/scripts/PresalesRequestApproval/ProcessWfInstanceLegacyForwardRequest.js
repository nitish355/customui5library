var now = new Date();
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');
var wfIns_data = {};
wfIns_data.instance_GUID = $.info.workflowInstanceId;
wfIns_data.parentInstance_GUID = $.context.parentInstanceID;
wfIns_data.currentTaskInstanceID = null;
wfIns_data.technicalStateID = $.context.TechnicalStateValue.INPR.ID;
wfIns_data.currentStateID = $.context.CurrentStateValue.WMNAPP.ID;
wfIns_data.currentStepID = $.context.CurrentStepValue.MANAPP.ID;
wfIns_data.currentProcessorID = $.context.approversIds;
wfIns_data.currentProcessor = $.context.approverNames;
wfIns_data.currentProcessorEmail = $.context.approversEmails;
if ($.context.substituteApproverDetails.length != 0) {
    wfIns_data.substituteProcessorID = $.context.subApproversIds;
    wfIns_data.substituteProcessor = $.context.subApproverNames;
    wfIns_data.substituteProcessorEmail = $.context.subApproversEmails;
}else {
    wfIns_data.substituteProcessorID = "";
    wfIns_data.substituteProcessor = "";
    wfIns_data.substituteProcessorEmail = "";
}
wfIns_data.approvers = $.context.ApproverInfo;
wfIns_data.dtLastActivity_tdate = date;
wfIns_data.dtLastActivity_ttime = time;
wfIns_data.reqAreaGUID = $.context.GUID;
wfIns_data.decisionID  = $.context.decision_ID;
wfIns_data.reqApprover_ID = $.context.currentProcessor.id;
wfIns_data.reqApprover_Name = $.context.currentProcessor.fullName;
wfIns_data.reqApprover_EMail = $.context.currentProcessor.email;
wfIns_data.currentTaskURL = null;
if ($.context.aResourceProfileApprovers.IAC[0].IAC_RoleMap_GUID) {
    wfIns_data.IAC_RoleMap_GUID = $.context.aResourceProfileApprovers.IAC[0].IAC_RoleMap_GUID;
}
var approvertaskid = "";
$.context.approverData = $.context.currentProcessor;
if ($.context.isResourceProfile === true) {
    if ($.context.lastDecisionTask == 11 ){ 
        approvertaskid = $.usertasks.usertask11.last.id;
    } else {  
            approvertaskid = $.usertasks.usertask10.last.id;
        }}
else {
    if ($.context.lastDecisionTask == 3) {
        approvertaskid = $.usertasks.usertask5.last.id;
    } else if ($.context.lastDecisionTask == 2) {
        approvertaskid = $.usertasks.usertask4.last.id;
    } else if ($.context.lastDecisionTask == 1) {
        approvertaskid = $.usertasks.usertask2.last.id;
    }}
var ReqHistory_data = {};
ReqHistory_data.InstanceID = $.info.workflowInstanceId;
ReqHistory_data.UserTaskID = approvertaskid;
ReqHistory_data.AssignmentID = "0";
ReqHistory_data.User_ID = $.context.currentProcessor.id;
ReqHistory_data.User_Name = $.context.currentProcessor.fullName;
ReqHistory_data.User_EMail = $.context.currentProcessor.email;
if ($.context.isSubstitute === true){
    ReqHistory_data.StateID = $.context.CurrentStateValue.WSUBMN.ID;
}
else{
    ReqHistory_data.StateID = $.context.CurrentStateValue.WMNAPP.ID;
}
ReqHistory_data.StepID = $.context.currentStepID;
if ($.context.ForwardAction == "Edit Profile") {
    ReqHistory_data.ActionTaken = 'Edited Profile. Processor(s) updated from "' + $.context.lastForwardedBy + '" to ' + '"' + $.context.approverNames + '"';
}
else {
    ReqHistory_data.ActionTaken = 'Edited Processor from "' + $.context.lastForwardedBy + '" to ' + '"' + $.context.approverNames + '"';
}
ReqHistory_data.Role = "Approver";
ReqHistory_data.Decision = $.context.decision_ID;
ReqHistory_data.Comments = $.context.comments;
ReqHistory_data.Date = date;
ReqHistory_data.Time = time;
if (!$.context.UT_refID) {
    $.context.UT_refID = 1;
}
else {
    $.context.UT_refID += 1;
}
ReqHistory_data.UT_refID = $.context.UT_refID;
var wfUrl = "/WfInstance(instance_GUID='" + $.info.workflowInstanceId + "',parentInstance_GUID='" + $.context.parentInstanceID + "')";
var wfRequest = {
    id: "1",
    method: "PATCH",
    url: wfUrl,
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    body: wfIns_data
};
$.context.DBCall.Request.requests.push(wfRequest);
if($.context.aResourceProfileApprovers &&  $.context.aResourceProfileApprovers.ResourceProfileDetails &&
  $.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedGroup &&  $.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedGroup.length>0 &&
  $.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedGroup[0].GroupID){
    $.context.SelectedGroupID =  $.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedGroup[0].GroupID;
  }
if ($.context.EngagementType && $.context.EngagementType === '0001' && $.context.SelectedGroupID) {
    var wfIns_ext_data = {};
    wfIns_ext_data.group_ID = $.context.SelectedGroupID;
    var wfExtRequest = {
        id: "2",
        method: "PATCH",
        url: "/WfInstanceExt(instance_Guid='" + $.info.workflowInstanceId+ "')",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        body: wfIns_ext_data
    };
    $.context.DBCall.Request.requests.push(wfExtRequest);
}
$.context.DBCall.Request.requests.push({
    id: "3",
    method: "POST",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WFHistory",
    body: ReqHistory_data
});
var WfInsProc_DelURLs = $.context.WfInsProc_DelURLs;
    var WfInsProc_length = WfInsProc_DelURLs.length;
    $.context.WfInsProc_length = WfInsProc_length;
    for (var n = 0; n < WfInsProc_length; n++) { 
        $.context.DBCall.Request.requests.push({
            id: (n + 4).toString(),
            dependsOn: ["1"],
            method: "DELETE",
            headers: { "content-type": "application/json;IEEE754Compatible=true" },
            url: WfInsProc_DelURLs[n]
        });    }
    WfInsProc_DelURLs = [];
    $.context.WfInsProc_DelURLs = [];  
for (var q = 0; q < $.context.approverDetails.length; q++) {
    $.context.DBCall.Request.requests.push({
        id: (q + 5 + WfInsProc_length).toString(),
        //dependsOn: ["1"],
        dependsOn: [$.context.DBCall.Request.requests[$.context.DBCall.Request.requests.length-1].id],
        method: "POST",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: "/WfInsProcessor",
        body: {
            InstanceID: $.info.workflowInstanceId,
            assignmentID: "1",
            currentProcessorID: $.context.approverDetails[q].userId,
            currentProcessorName: $.context.approverDetails[q].fullName,
            currentProcessorEmail: $.context.approverDetails[q].email,
        }});
    var wfInsProc_DelURLs = "/WfInsProcessor(InstanceID=" + $.info.workflowInstanceId + ",assignmentID='1',currentProcessorID='" + $.context.approverDetails[q].userId + "')";
    $.context.WfInsProc_DelURLs.push(wfInsProc_DelURLs);  }
