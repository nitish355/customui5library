$.context.lastForwardedBy = $.context.currentProcessor.fullName;
$.context.approverData = $.context.currentProcessor.fullName;
var OrgID_Num = $.context.OrgID.substring(5, 9);
OrgID_Num = OrgID_Num.replace(/^0+/, '');
$.context.lastApproverComments = $.context.comments ? $.context.comments : "";
$.context.lastActivityDate = new Date();
$.context.currentState = $.context.CurrentStateValue.REQFWD.Value;
$.context.PreviousApproverDetails = $.context.approverDetails;
$.context.approverDetails = [];
$.context.substituteApproverDetails = [];
$.context.primaryApproverDetails = [];
var approver = $.context.aResourceProfileApprovers.ApproverDetails;
var subsapprover = ($.context["aResourceProfileApprovers"]["SubstituteApproverDetails"]) ? $.context.aResourceProfileApprovers.SubstituteApproverDetails : [];
var primaryApprovers = ($.context["aResourceProfileApprovers"]["aApprovers"]) ? $.context.aResourceProfileApprovers.aApprovers : $.context.aResourceProfileApprovers.ApproverDetails;
$.context.hasSubstitute = false;
if (subsapprover.length >0){
    $.context.hasSubstitute = true;
  }
if (approver.length != 0) {
    approver.forEach(function (val) {
        var name = val.fullName;
        name = name.replace(/^(\S).*\s(\S+)$/, function(_, first, last) {   return first.toUpperCase() + '. ' + last.charAt(0).toUpperCase() + last.slice(1).toLowerCase();    });
        var data = { 
            Name: name,  fullName: val.fullName, email: val.email,userId: val.ID
        };
        $.context.approverDetails.push(data)        
    });
}
if (subsapprover.length != 0) {
    subsapprover.forEach(function (val) {
        var data = {
            fullName: val.fullName, email: val.email, userId: val.ID
        };
        $.context.substituteApproverDetails.push(data)       
    });
}
if (primaryApprovers.length != 0) {
    primaryApprovers.forEach(function (val) {
        var data = {
            fullName: val.fullName, email: val.email, userId: val.ID
        };
        $.context.primaryApproverDetails.push(data)        
    });
}
var currentApproverIds = {};
for (var i = 0; i < $.context.approverDetails.length; i++) {
    if ($.context.approverDetails[i].userId) {
        currentApproverIds[$.context.approverDetails[i].userId] = true;
    }}
var previousIds = {};
for (var i = 0; i < $.context.PreviousApproverDetails.length; i++) {
  previousIds[$.context.PreviousApproverDetails[i].userId] = true;
}
var filteredPreviousApprovers = [];
for (var j = 0; j < $.context.PreviousApproverDetails.length; j++) {
    if (!currentApproverIds[$.context.PreviousApproverDetails[j].userId]) {
        filteredPreviousApprovers.push($.context.PreviousApproverDetails[j]);
    }}
var filteredExistingApprovers = [];
for (var j = 0; j < $.context.PreviousApproverDetails.length; j++) {
    if (currentApproverIds[$.context.PreviousApproverDetails[j].userId]) {
        filteredExistingApprovers.push($.context.PreviousApproverDetails[j]);
    }}
var newApprovers = [];
for (var j = 0; j < $.context.approverDetails.length; j++) {
  var userId = $.context.approverDetails[j].userId;
  if (!previousIds[userId]) {
    newApprovers.push($.context.approverDetails[j]);  
  }}
$.context.PreviousApproverDetails = filteredPreviousApprovers;
$.context.ExistingApproverDetails = filteredExistingApprovers;
$.context.NewApproverDetails = newApprovers
var aApproversData = $.context.approverDetails,
    sApproverIntro = "Dear " + aApproversData[0].fullName + ",",
    sApproverEmails = aApproversData[0].email,
    sApproverIds = aApproversData[0].userId,
    sApproverNames = aApproversData[0].fullName,
    sApproverInfo = aApproversData[0].fullName + "(" + aApproversData[0].userId + "," + aApproversData[0].email + ")";
if (aApproversData.length > 1) {
    for (var i = 1; i < aApproversData.length; i++) {
        sApproverIntro += "\nDear " + aApproversData[i].fullName + ",";
        sApproverEmails += "," + aApproversData[i].email;
        sApproverIds += "," + aApproversData[i].userId,
            sApproverNames += "," + aApproversData[i].fullName;
            sApproverInfo += "," + aApproversData[i].fullName + "(" + aApproversData[i].userId + "," + aApproversData[i].email + ")";
    }}
if($.context.substituteApproverDetails.length != 0 ){
var aSubApproversData = $.context.substituteApproverDetails,    
    sSubApproverEmails = aSubApproversData[0].email,
    sSubApproverIds = aSubApproversData[0].userId,
    sSubApproverNames = aSubApproversData[0].fullName;
if (aSubApproversData.length > 1) {
    for (var i = 1; i < aSubApproversData.length; i++) {       
        sSubApproverEmails += "," + aSubApproversData[i].email;
        sSubApproverIds += "," + aSubApproversData[i].userId,
        sSubApproverNames += "," + aSubApproversData[i].fullName;
    }}
$.context.subApproverNames = sSubApproverNames;
$.context.subApproversEmails = sSubApproverEmails;
$.context.subApproversIds = sSubApproverIds;
}
if($.context.primaryApproverDetails.length != 0 ){
var aPrimaryApproversData = $.context.primaryApproverDetails,    
    sPrimaryApproverEmails = aPrimaryApproversData[0].email,
    sPrimaryApproverIds = aPrimaryApproversData[0].userId,
    sPrimaryApproverNames = aPrimaryApproversData[0].fullName;
if (aPrimaryApproversData.length > 1) {
    for (var i = 1; i < aPrimaryApproversData.length; i++) {       
        sPrimaryApproverEmails += "," + aPrimaryApproversData[i].email;
        sPrimaryApproverIds += "," + aPrimaryApproversData[i].userId,
        sPrimaryApproverNames += "," + aPrimaryApproversData[i].fullName;
    }}
$.context.primaryApproverNames = sPrimaryApproverNames;
$.context.primaryApproversEmails = sPrimaryApproverEmails;
$.context.primaryApproversIds = sPrimaryApproverIds;
}
$.context.approverNames = sApproverNames;
$.context.notifyApproversEmailIntro = sApproverIntro;
$.context.approversEmails = sApproverEmails;
$.context.approversIds = sApproverIds;
$.context.ApproverInfo = sApproverInfo;
//code for email template
var entries = $.context.approverDetails; 
var approverurl = [];
for (var count = 0; count < 20; count++) {
	if(count >= entries.length){
		approverurl.push({ class : "hidden-row" });
	} else {
		entries[count].class = "styled-link";
        if (count != entries.length-1){
            entries[count].Separator = "," 
        }           
		approverurl.push(entries[count]);
	}
}
$.context.approverurl = approverurl;
//dynamic email configuration
if ($.context.RequestType == "Opportunity") {
    $.context.Opp_ID = "Opportunity ID:";
    $.context.CRev_L = "Cloud Revenue:";
    $.context.OpRev_L = "On Premise Revenue:";
}
var decision = {
    "UserId": $.context.currentProcessor.id, // Userid for approvalHistory
    "UserName": $.context.currentProcessor.fullName,
    "Role": $.context.currentProcessorRole,
    "StepName": $.context.currentStepName,
    "StepID" :$.context.currentStepID,
    "Decision": "Forwarded from " + $.context.lastForwardedBy + " to " + $.context.approverNames,
    "Comments": $.context.comments,
    "Date": new Date()
};
if ($.context.ForwardAction == "Edit Profile") {
    decision.Decision = 'Edited Profile. Processor(s) updated from "' + $.context.lastForwardedBy + '" to ' + '"' + $.context.approverNames + '"';
    $.context.ForwardDecision = 'Edited Profile. Processor(s) updated from ' + $.context.lastForwardedBy + ' to ' +  $.context.approverNames;
}
else {
    decision.Decision = 'Edited Processor from "' + $.context.lastForwardedBy + '" to ' + '"' + $.context.approverNames + '"';
    $.context.ForwardDecision = 'Edited Processor from ' + $.context.lastForwardedBy + ' to ' +  $.context.approverNames ;
}
$.context.approvalHistory.push(decision);
if ($.context.OrgType == "SORG" || $.context.OrgType == "MUID" )
    { 
            var OrgID_Num= $.context.OrgID.substring(5,9);            
            OrgID_Num = OrgID_Num.replace(/^0+/, ''); 
        }    
    else if ($.context.OrgType == "PC")
    {
        var OrgID_Num = $.context.OrgID
    
    }   
    var encodedPath = encodeURIComponent($.context.requestAreaPath)
    $.context.areaPathCall = {}
    $.context.areaPathCall.Request = {};
    $.context.areaPathCall.Request.requests = [];
    $.context.areaPathCall.Request.requests.push(    
    {
        id: "1",
        method: "GET",
        url: "/Email_Body?$filter=orgID eq '" + OrgID_Num + "' ",
        headers: { "content-type": "application/json;IEEE754Compatible=true" }
    },
        // to fetch Email Delegates Details
        {
            id: "2",
            method: "GET",
            url: "/Email_Delegates?$filter=orgID eq '" + OrgID_Num + "'",
            headers: { "content-type": "application/json;IEEE754Compatible=true" }
        },
        // to fetch routing flags 
        {
            id: "3",
            method: "GET",
            url: "/WF_Routing?$filter=orgID eq '" + OrgID_Num + "' and eng_Type_ID eq '" + $.context.EngagementType + "'",
            headers: { "content-type": "application/json;IEEE754Compatible=true" }
            },
            {
                id: "4",
                method: "GET",
                url: "/RemindMail?$filter=OrgID eq '" + OrgID_Num + "' and eng_Type_ID eq '" + $.context.EngagementType + "' ",      
                headers:   {"content-type": "application/json;IEEE754Compatible=true"}
            }
    );
    

$.context.lastActivityDate = new Date();
$.context.currentState = $.context.CurrentStateValue.WMNAPP.Value;
$.context.currentStepName = $.context.CurrentStepValue.MANAPP.Value;//"Presales Manager Approval";
$.context.currentStepID = $.context.CurrentStepValue.MANAPP.ID;
$.context.currentProcessorRole = "Approver"
if(!$.context["aResourceProfileApprovers"]["ResourceProfileDetails"]["SolutionAreas"]){
    $.context["aResourceProfileApprovers"]["ResourceProfileDetails"]["SolutionAreas"] =[];
}