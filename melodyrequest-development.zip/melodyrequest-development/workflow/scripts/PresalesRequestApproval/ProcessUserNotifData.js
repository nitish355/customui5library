var response =$.context.User_NotifDBCallPayload.Response;
$.context.RequesterEmail_Notif = "";
$.context.ProcessorEmail_Notif = "";
$.context.SubstituteProcessorEmail_Notif  = "";
$.context.ResourceEmail_Notif = "";
$.context.PreviousProcessEmail_Notif = "";
$.context.RequesterEmail_NotifFwd = "";
$.context.ReqTypeOwnerEmail_Notif = "";
$.context.newProcessorEmail_Notif = "";
$.context.ExistingProcessorEmail_Notif = "";
$.context.RequesterEmailNotif_flag = false;
$.context.ResourceEmailNotif_flag = false; 
$.context.AllProssEmailNotif_flag = false;
$.context.ReqTerProjRejEmailNotif_flag = false;
$.context.ReqClosureEmailNotif_flag = false;
$.context.newProcessorActionEmailNotif_flag = false;
$.context.ExistingProcessorActionEmailNotif_flag = false;

if (response.requester && response.requester.length > 0) {
  $.context.RequesterEmail_Notif = collectEmails("requester", true);
  $.context.RequesterEmail_NotifFwd = $.context.RequesterEmail_Notif;
  $.context.RequesterEmailNotif_flag = true ; 
  $.context.ReqTerProjRejEmailNotif_flag = true;
  $.context.ReqClosureEmailNotif_flag = true;
}

if (response.processor && response.processor.length > 0) {
  $.context.ProcessorEmail_Notif = collectEmails("processor", false);
  $.context.ReqTerProjRejEmailNotif_flag = true;
  $.context.ReqClosureEmailNotif_flag = true;
}

if (response.substitute && response.substitute.length > 0) {
  $.context.SubstituteProcessorEmail_Notif = collectEmails("substitute", false);
  $.context.ReqTerProjRejEmailNotif_flag = true;
  $.context.ReqClosureEmailNotif_flag = true;
}

if (response.newProcessor && response.newProcessor.length > 0) {
  $.context.newProcessorEmail_Notif = collectEmails("newProcessor", false);
  $.context.newProcessorActionEmailNotif_flag = true;
 
}
if (response.ExistingProcessor && response.ExistingProcessor.length > 0) {
  $.context.ExistingProcessorEmail_Notif = collectEmails("ExistingProcessor", false);
  $.context.ExistingProcessorActionEmailNotif_flag = true;
 
}
if (response.resource && response.resource.length > 0) {
  $.context.ResourceEmail_Notif = collectEmails("resource", false); 
  $.context.ResourceEmailNotif_flag = true;
  $.context.ReqClosureEmailNotif_flag = true;
}

if(response.oldProssOrDirectMgr && response.oldProssOrDirectMgr.length > 0) {
  $.context.PreviousProcessEmail_Notif = collectEmails("oldProssOrDirectMgr", false);
}

if(response.reqTypeOwner && response.reqTypeOwner.length > 0)
{
  $.context.ReqTypeOwnerEmail_Notif = collectEmails("reqTypeOwner", true);
   $.context.RequesterEmailNotif_flag = true ; 
   $.context.ReqTerProjRejEmailNotif_flag = true;
   $.context.ReqClosureEmailNotif_flag = true;
}
$.context.User_NotifResDirectManagerPayload = {};
var users = {};
var UserNotifpayload = {};
UserNotifpayload.notif_Id = "16";
UserNotifpayload.notifVal_Id = "0001";
if ( $.context.ResDirectManagerEmail && $.context.ResDirectManagerId) {
  users.oldProssOrDirectMgr = [{
    userId: $.context.ResDirectManagerId.toUpperCase(),
    email: $.context.ResDirectManagerEmail
  }];
}
if ( Object.keys(users).length > 0) {
  UserNotifpayload.users = users;
  $.context.User_NotifResDirectManagerPayload = UserNotifpayload;
}

if(response.processor && response.processor.length > 0 || response.substitute && response.substitute.length > 0 ){
  $.context.AllProssEmailNotif_flag = true; 
}

function collectEmails(role, single) {
  var users = response[role];
  if (!Array.isArray(users)) return single ? "" : [];

  var emails = users
    .filter(function (u) { return u.email; })
    .map(function (u) { return u.email; });

  return single ? (emails[0] || "") : emails.join(",");
}
