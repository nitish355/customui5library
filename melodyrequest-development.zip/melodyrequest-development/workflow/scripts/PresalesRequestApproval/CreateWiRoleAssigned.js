var now = new Date();
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');
if (!$.context.DBCall) {
    $.context.DBCall = {};
};
$.context.DBCall.Request = {};
$.context.DBCall.Request.requests = [];
var AllNominatedResources = [];

for (var p = 0; p < $.context.Assignment.length; p++) {
    var nom = $.context.Assignment[p].NominatedResources;
    for (var q = 0; q < nom.length; q++) {
        AllNominatedResources.push(nom[q]);
    }
}
var approvertaskid = "";
if ($.context.isResourceProfile === true)
{  
    if ($.context.lastDecisionTask == 11) {
        approvertaskid = $.usertasks.usertask11.last.id;
    }
    else {
        approvertaskid = $.usertasks.usertask10.last.id;
    }
}
else {
if ($.context.lastDecisionTask == 3) {
    approvertaskid = $.usertasks.usertask5.last.id;
} else if ($.context.lastDecisionTask == 2) {
    approvertaskid = $.usertasks.usertask4.last.id;
} else if ($.context.lastDecisionTask == 1) {
    approvertaskid = $.usertasks.usertask2.last.id;
}
}

var ReqHistory_data = {};
ReqHistory_data.InstanceID = $.info.workflowInstanceId;
ReqHistory_data.UserTaskID = approvertaskid;
ReqHistory_data.AssignmentID = "0";
ReqHistory_data.User_ID = $.context.approverData.id;
ReqHistory_data.User_Name = $.context.approverData.fullName;
ReqHistory_data.User_EMail = $.context.approverData.email;
ReqHistory_data.StateID = $.context.CurrentStateValue.REQREJ.ID;
ReqHistory_data.StepID = $.context.currentStepID;
ReqHistory_data.ActionTaken = "Reject";
if ($.context.rejectReasonID) {
    ReqHistory_data.RejID = $.context.rejectReasonID;
}
ReqHistory_data.Role = "Approver";
ReqHistory_data.Decision = $.context.decision_ID;
ReqHistory_data.Comments = $.context.comments;
ReqHistory_data.Date = date;
ReqHistory_data.Time = time;
if (!$.context.UT_refID) {
    $.context.UT_refID = 1;
}
else {
    $.context.UT_refID += 1;
}
ReqHistory_data.UT_refID = $.context.UT_refID;

$.context.DBCall.Request.requests = [];
$.context.DBCall.Request.requests.push({   
    id: "1",
    method: "POST",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WFHistory",
    body: ReqHistory_data
});
