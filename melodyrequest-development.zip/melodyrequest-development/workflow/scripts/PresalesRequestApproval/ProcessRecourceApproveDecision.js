
if (!$.context.comments) {
    $.context.comments = "";
}

var decision = {
    "UserId": $.context.currentProcessor.id, // Userid for approvalHistory
    "UserName": $.context.currentProcessor.fullName,
    "Role": $.context.currentProcessorRole,
    "StepName": $.context.currentStepName,
    "StepID" :$.context.currentStepID,
    "Decision": $.context.decision,
    "Comments": $.context.comments,
    "Date": new Date()
};

$.context.approvalHistory.push(decision);
$.context.lastAcceptorComments = $.context.comments ? $.context.comments : "";

$.context.acceptorComment = $.context.comments;
$.context.comments = "";

// enrich current processor details
var aAssignedPresales = $.context.assignedPresales;
aAssignedPresales.forEach(function (val) {
    if (val.email === $.context.currentProcessor.email) {
        $.context.currentProcessor.partnerId = val.partnerId;
        $.context.currentProcessor.address = val.address;
        $.context.currentProcessor.country = val.country;
        $.context.currentProcessor.id = val.userId;
    }
});

$.context.assignedResourceDetails = {
    "fullName": $.context.currentProcessor.fullName,
    "partnerId": $.context.currentProcessor.partnerId,
    "address": $.context.currentProcessor.address,
    "country": $.context.currentProcessor.country,
    "email": $.context.currentProcessor.email,
    "roleData": $.context.assignedRoleData
}

$.context.CPICalls.updateDataInCRM = {
    Request: {
        "opportunityId": $.context.opportunityId,
        "requestIntent": "UPDATE_DATA",
        "assignedResourceData": $.context.assignedResourceDetails
    }
}

var fullNames = [];
fullNames.push($.context.requesterDetails.id);
var fullApproveDearText = "Dear " + $.context.requesterDetails.fullName + ",\n";

if ($.context.oppOwnerDetails.fullName && fullNames.indexOf($.context.oppOwnerDetails.id) === -1) {
    fullNames.push($.context.oppOwnerDetails.id);
    fullApproveDearText += "Dear " + $.context.oppOwnerDetails.fullName + ",\n";
}
if ($.context.accOwnerDetails.fullName && fullNames.indexOf($.context.accOwnerDetails.id) === -1) {
    fullNames.push($.context.accOwnerDetails.id);
    fullApproveDearText += "Dear " + $.context.accOwnerDetails.fullName + ",\n";
}
if ($.context.approverData.fullName && fullNames.indexOf($.context.approverData.id) === -1) {
    fullNames.push($.context.approverData.id);
    fullApproveDearText += "Dear " + $.context.approverData.fullName + ",\n";
}
if ($.context.currentProcessor.fullName && fullNames.indexOf($.context.currentProcessor.id) === -1) {
    fullNames.push($.context.currentProcessor.id);
    fullApproveDearText += "Dear " + $.context.currentProcessor.fullName + ",\n";
}

$.context.fullApproveDearText = fullApproveDearText;