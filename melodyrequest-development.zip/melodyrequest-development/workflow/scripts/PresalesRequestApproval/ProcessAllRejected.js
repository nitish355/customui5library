$.context.currentState = $.context.CurrentStateValue.WMNAPP.Value;
$.context.currentStepName = $.context.CurrentStepValue.MANAPP.Value;
$.context.currentStepID = $.context.CurrentStepValue.MANAPP.ID;
$.context.currentProcessorRole = "Approver";