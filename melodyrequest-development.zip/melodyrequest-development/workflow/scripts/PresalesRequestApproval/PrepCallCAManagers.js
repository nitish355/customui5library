$.context.DBCall.GetCAManagers = {};
$.context.DBCall.GetCAManagers.requests = [{
    id: "1",
    method: "GET",
    url: "/SalesGroup2Emp?$filter=SalesGroup eq '" + encodeURIComponent($.context.salesGroup) + "' and SalesGroupName eq '" + encodeURIComponent($.context.salesGroupName) + "'&$count=true",
    headers: { "content-type": "application/json;IEEE754Compatible=true" }
}];