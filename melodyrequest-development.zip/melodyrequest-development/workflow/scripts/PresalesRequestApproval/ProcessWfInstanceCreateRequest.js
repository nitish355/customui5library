var now = new Date();
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');
if (!$.context.DBCall) {
    $.context.DBCall = {};
}
$.context.DBCall.isWfInstanceUpdate = $.context.wasReworked ? true : false;
$.context.DBCall.Request = {};
$.context.WfInsProc_DelURLs = [];
// Prepare data for WFINSTANCE Table
var wfIns_data = {};
wfIns_data.instance_GUID             = $.info.workflowInstanceId;
wfIns_data.parentInstance_GUID      = $.context.parentInstanceID;
wfIns_data.technicalStateID = $.context.TechnicalStateValue.INPR.ID;
wfIns_data.currentStateID = $.context.CurrentStateValue.WMNAPP.ID;
wfIns_data.currentStepID = $.context.CurrentStepValue.MANAPP.ID;
wfIns_data.currentProcessorID = $.context.approversIds;
wfIns_data.currentProcessor = $.context.approverNames;
wfIns_data.currentProcessorEmail = $.context.approversEmails;
if ($.context.isResourceProfile === true && $.context.substituteApproverDetails.length != 0 ){
wfIns_data.substituteProcessorID = $.context.subApproversIds;
wfIns_data.substituteProcessor = $.context.subApproverNames;
wfIns_data.substituteProcessorEmail = $.context.subApproversEmails;}
wfIns_data.approvers = $.context.ApproverInfo;
wfIns_data.dtLastActivity_tdate = date;
wfIns_data.dtLastActivity_ttime = time;
wfIns_data.decisionID                = $.context.decision_ID;
wfIns_data.currency                  = $.context.dealInfoForDb.currency;
wfIns_data.revenueCloud              = $.context.dealInfoForDb.cloudRevenue;
wfIns_data.revenuePremise            = $.context.dealInfoForDb.onPremRevenue;
wfIns_data.dealScore = $.context.dealInfoForDb.dealScore;
wfIns_data.need_from_CustAdvisory = $.context.requestDetails.typeOfSupport;
if($.context.requestDetails.isMeetingPlanned === true)   {
        wfIns_data.cust_asked_forMeeting = "X";
    }   else{
        wfIns_data.cust_asked_forMeeting = "";    }
wfIns_data.meetingTypeID = $.context.requestDetails.meetingTypeKey;
wfIns_data.solution_Models = $.context.requestDetails.solutionsInScope;
wfIns_data.custAdvisory_Resource = $.context.requestDetails.preferredPresales;
wfIns_data.meeting_Goal = $.context.requestDetails.meetingGoal;
wfIns_data.meetingLocation = $.context.requestDetails.meetingLocation;
wfIns_data.meetingDate = $.context.requestDetails.meetingDate;
wfIns_data.meetingTime = $.context.requestDetails.meetingTime;
wfIns_data.involved_SAP_Parties_Name = $.context.requestDetails.involvedPartiesNames;
wfIns_data.participants_Type_Details = $.context.requestDetails.participantTypeDetails;
if ($.context.requestDetails.isAttachment === true) {
    wfIns_data.isAttachment = "X";
} else {
    wfIns_data.isAttachment = ""; }
if($.context.UserTaskLabelValue)
{
    wfIns_data.userTaskID = $.context.UserTaskLabelValue.Processor.userTaskID;
}
// prepare data for ReqHistory 
var ReqHistory_data = {};
ReqHistory_data.InstanceID = $.info.workflowInstanceId;
ReqHistory_data.UserTaskID = $.context.submitPageUserTaskID;
ReqHistory_data.AssignmentID = "0";
ReqHistory_data.User_ID = $.context.requesterDetails.id;
ReqHistory_data.User_Name = $.context.requesterDetails.fullName;
ReqHistory_data.User_EMail = $.context.requesterDetails.email;
ReqHistory_data.StateID = $.context.CurrentStateValue.REQSUB.ID; 
ReqHistory_data.StepID = $.context.isRework ? $.context.CurrentStepValue.REESUB.ID : $.context.CurrentStepValue.REQSUB.ID;
ReqHistory_data.ActionTaken = "Submit Request";
ReqHistory_data.Role = "Requester";
ReqHistory_data.Decision = $.context.decision_ID;
ReqHistory_data.Comments = $.context.lastRequestorComments;
ReqHistory_data.Date = date;
ReqHistory_data.Time = time;
if (!$.context.UT_refID) {
    $.context.UT_refID = 1;
} else {
    $.context.UT_refID += 1; }
ReqHistory_data.UT_refID = $.context.UT_refID;
$.context.DBCall.Request.requests = [];
var wfRequest = {
    id: "1",
    method: "PATCH",
    url: "/WfInstance(instance_GUID='" + $.info.workflowInstanceId + "',parentInstance_GUID='" + $.context.parentInstanceID + "')",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    body: wfIns_data
};
$.context.DBCall.Request.requests.push(wfRequest);
var wfhistory = {   
    id: "2",    
    method: "POST",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WFHistory",
    body: ReqHistory_data
};
$.context.DBCall.Request.requests.push(wfhistory);
if ($.context.wasReworked) {
    var currProc_DelURL = $.context.WfInsProc_DelURLs_Manager_SBR;
} else {
    var currProc_DelURL = "/WfInsProcessor(InstanceID=" + $.info.workflowInstanceId + ",assignmentID='1',currentProcessorID='" + $.context.requesterDetails.id + "')";
} 
var wfInsProc_Del = {
    id: "3",
    dependsOn: [$.context.DBCall.Request.requests[$.context.DBCall.Request.requests.length-1].id],
    method: "DELETE",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: currProc_DelURL
}
$.context.DBCall.Request.requests.push(wfInsProc_Del); 
for (var i = 0; i < $.context.approverDetails.length; i++) {
    $.context.DBCall.Request.requests.push({
        id: (i + 4).toString(),
        dependsOn: [$.context.DBCall.Request.requests[$.context.DBCall.Request.requests.length-1].id],
        method: "POST",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: "/WfInsProcessor",
        body: {
            InstanceID: $.info.workflowInstanceId,
            assignmentID: "1",
            currentProcessorID: $.context.approverDetails[i].userId,
            currentProcessorName: $.context.approverDetails[i].fullName,
            currentProcessorEmail: $.context.approverDetails[i].email,
        }
    });
    var wfInsProc_DelURL = "/WfInsProcessor(InstanceID=" + $.info.workflowInstanceId + ",assignmentID='1',currentProcessorID='" + $.context.approverDetails[i].userId + "')";
    $.context.WfInsProc_DelURLs.push(wfInsProc_DelURL);
}
var count = 0;
var invldParties = $.context.requestDetails.involvedPartiesKey||"",
    lang = $.context.requestDetails.languageKey||"",
    particpntTyp = $.context.requestDetails.participantTypeKey||"",
    supportTyp = $.context.requestDetails.supportTypeKey||"";
if ($.context.wasReworked) {
    for (var j = 0; j < $.context.ReqFormDelUrl.length; j++) {
        $.context.DBCall.Request.requests.push({
            id: (count + 5 + $.context.approverDetails.length).toString(),
            method: "DELETE",
            headers: { "content-type": "application/json;IEEE754Compatible=true" },
            url: $.context.ReqFormDelUrl[j]
        });
        count += 1;
    }
}
$.context.ReqFormDelUrl = [];
if (invldParties != "") {
    invldParties.split(';').forEach(function (val) {
        var invldPartiesUrl = "/ReqForm_InvSAP_Party(InstanceID=" + $.info.workflowInstanceId + ",involved_SAP_PartiesID='" + val.trim() + "')";
        $.context.DBCall.Request.requests.push({
            id: (count + 6 + $.context.approverDetails.length).toString(),
            dependsOn: [$.context.DBCall.Request.requests[$.context.DBCall.Request.requests.length-1].id],
            method: "POST",
            headers: { "content-type": "application/json;IEEE754Compatible=true" },
            url: "/ReqForm_InvSAP_Party",
            body: {
                InstanceID: $.info.workflowInstanceId,
                involved_SAP_PartiesID: val.trim()
            }
        });
        count += 1;
        $.context.ReqFormDelUrl.push(invldPartiesUrl);
    });
}
if (lang != "") {
    lang.split(';').forEach(function (val) {
        var langUrl = "/ReqForm_Language(InstanceID=" + $.info.workflowInstanceId + ",languageID='" + val.trim() + "')";
        $.context.DBCall.Request.requests.push({
            id: (count + 7 + $.context.approverDetails.length).toString(),
            dependsOn: [$.context.DBCall.Request.requests[$.context.DBCall.Request.requests.length-1].id],
            method: "POST",
            headers: { "content-type": "application/json;IEEE754Compatible=true" },
            url: "/ReqForm_Language",
            body: {
                InstanceID: $.info.workflowInstanceId,
                languageID: val.trim()
            }
        });
        count += 1;
        $.context.ReqFormDelUrl.push(langUrl);
    });
}
if (particpntTyp != "") {
    particpntTyp.split(';').forEach(function (val) {
        var particpntTypUrl = "/ReqForm_PartcpType(InstanceID=" + $.info.workflowInstanceId + ",participantTypeID='" + val.trim() + "')";
        $.context.DBCall.Request.requests.push({
            id: (count + 8 + $.context.approverDetails.length).toString(),
            dependsOn: [$.context.DBCall.Request.requests[$.context.DBCall.Request.requests.length-1].id],
            method: "POST",
            headers: { "content-type": "application/json;IEEE754Compatible=true" },
            url: "/ReqForm_PartcpType",
            body: {
                InstanceID: $.info.workflowInstanceId,
                participantTypeID: val.trim()
            }
        });
        count += 1;
        $.context.ReqFormDelUrl.push(particpntTypUrl);
    });
}
if (supportTyp != "") {
    supportTyp.split(';').forEach(function (val) {
        var supportTypUrl = "/ReqForm_SupportType(InstanceID=" + $.info.workflowInstanceId + ",supportTypeID='" + val.trim() + "')";
        $.context.DBCall.Request.requests.push({
            id: (count + 9 + $.context.approverDetails.length).toString(),
            dependsOn: [$.context.DBCall.Request.requests[$.context.DBCall.Request.requests.length-1].id],
            method: "POST",
            headers: { "content-type": "application/json;IEEE754Compatible=true" },
            url: "/ReqForm_SupportType",
            body: {
                InstanceID: $.info.workflowInstanceId,
                supportTypeID: val.trim()
            }
        });
        count += 1;
        $.context.ReqFormDelUrl.push(supportTypUrl);
    });
}
$.context.ReqFormcount = count;