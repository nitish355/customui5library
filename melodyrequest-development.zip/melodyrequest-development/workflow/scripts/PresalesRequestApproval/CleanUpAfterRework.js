$.context.currentStepName = $.context.CurrentStepValue.REESUB.Value;//"Request Submission";
$.context.currentStepID = $.context.CurrentStepValue.REESUB.ID;
$.context.wasReworked = true;
$.context.AssignmentApproveAll = [];
$.context.ResReject = false;