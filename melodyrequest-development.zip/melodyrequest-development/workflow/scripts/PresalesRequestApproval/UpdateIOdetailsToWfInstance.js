var now = new Date();
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');

var io_OwnerData = $.context.io_OwnerDetails,
    io_OwnerEmails = io_OwnerData[0].IOOwnerEmail,
    io_OwnerIds = io_OwnerData[0].IOOwnerUserId,
    //io_OwnerUserId_one = io_OwnerData[0].IOOwnerUserId,
   // io_OwnerUserId_two = "",
    io_OwnerNames = io_OwnerData[0].IOOwnerName;
if (io_OwnerData.length > 0) {
    for (var i = 1; i < io_OwnerData.length; i++) {
      //  if (io_OwnerUserId_one != io_OwnerData[i].IOOwnerUserId && io_OwnerUserId_two != io_OwnerData[i].IOOwnerUserId ) {
            io_OwnerEmails += "," + io_OwnerData[i].IOOwnerEmail;
            io_OwnerIds += "," + io_OwnerData[i].IOOwnerUserId;
          //  io_OwnerUserId_two = io_OwnerData[i].IOOwnerUserId
            io_OwnerNames += "," + io_OwnerData[i].IOOwnerName;
      //  }
    }
}

$.context.currentStepName = $.context.CurrentStepValue.IOOAPP.Value;//"Presales IO Owner Approval";
$.context.currentStepID = $.context.CurrentStepValue.IOOAPP.ID;

// Prepare data for WFINSTANCE New Table
var wfIns_data = {};
wfIns_data.instance_GUID             = $.info.workflowInstanceId;
wfIns_data.parentInstance_GUID      = $.context.parentInstanceID;
wfIns_data.technicalStateID = $.context.TechnicalStateValue.INPR.ID;
wfIns_data.currentStateID = $.context.CurrentStateValue.WIOAPP.ID;
wfIns_data.currentStepID = $.context.CurrentStepValue.IOOAPP.ID;
wfIns_data.currentProcessorID = io_OwnerIds;
wfIns_data.currentProcessor = io_OwnerNames;
wfIns_data.currentProcessorEmail = io_OwnerEmails;
wfIns_data.dtLastActivity_tdate = date;
wfIns_data.dtLastActivity_ttime = time;
wfIns_data.decisionID = $.context.decision_ID;
wfIns_data.reqResources = "";
if ($.context.reqResources != "") {
    wfIns_data.reqResources = $.context.reqResource.slice(0, -1);
}
if($.context.UserTaskLabelValue)
    {
        wfIns_data.userTaskID = $.context.UserTaskLabelValue.IoOwner.userTaskID;
    }    

$.context.DBCall.Request.requests = [];

var wfRequest = {
    id: "1",
    method: "PATCH",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WfInstance(instance_GUID='" + $.info.workflowInstanceId + "',parentInstance_GUID='" + $.context.parentInstanceID + "')",
    body: wfIns_data
};

$.context.DBCall.Request.requests.push(wfRequest);

var AssignData = {};
//AssignData.TechnicalState = "inProcess";
AssignData.technicalStateID = $.context.TechnicalStateValue.INPR.ID;
//AssignData.CurrentState = $.context.CurrentStateValue.WIOAPP;
AssignData.currentStateID = $.context.CurrentStateValue.WIOAPP.ID;
AssignData.CurrentStepName = $.context.CurrentStepValue.IOOAPP.Value;//"Presales IO Owner Approval";
AssignData.currentStepID = $.context.CurrentStepValue.IOOAPP.ID;
AssignData.DTLastActivity_tdate = date;
AssignData.DTLastActivity_ttime = time;

if ($.context.io_OwnerResource.length > 0) {
    for (var i = 0; i < $.context.io_OwnerResource.length; i++) {
        var aAssignmentID = $.context.io_OwnerResource[i].AssignmentID;
        AssignData.CurrentProcessor = $.context.io_OwnerResource[i].NominatedResources[0].ioOwnerDetails.IOOwnerName;
        var WfAssignPatchURL = "/WfInstanceAssignment(InstanceID='" + $.info.workflowInstanceId + "',AssignmentID='" + aAssignmentID + "')";
        $.context.DBCall.Request.requests.push({
            id: (i + 2).toString(),
            dependsOn: ["1"],
            method: "PATCH",
            headers: { "content-type": "application/json;IEEE754Compatible=true" },
            url: WfAssignPatchURL,
            body: AssignData
        });
    }
}

//Logic to DELETE Current Processors from table WfInsProcessor
var len_wfInsProc_DelURL = $.context.WfInsProc_DelURLs.length;
for (var a = 0; a < len_wfInsProc_DelURL; a++) {
    $.context.DBCall.Request.requests.push({
        id: (a + 3 + $.context.io_OwnerResource.length).toString(),
        dependsOn: ["1"],
        method: "DELETE",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: $.context.WfInsProc_DelURLs[a]
    });
}
$.context.WfInsProc_DelURLs = [];
//Logic to POST Current Processors (i.e. Resources) to table WfInsProcessor
for (var j = 0; j < $.context.io_OwnerResource.length; j++) {
    $.context.DBCall.Request.requests.push({
        id: (j + 4 + $.context.io_OwnerResource.length + len_wfInsProc_DelURL).toString(),
       // dependsOn: ["1"],
        dependsOn: [$.context.DBCall.Request.requests[$.context.DBCall.Request.requests.length-1].id],
        method: "POST",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: "/WfInsProcessor",
        body: {
            InstanceID: $.info.workflowInstanceId,
            assignmentID: $.context.io_OwnerResource[j].AssignmentID,
            currentProcessorID: $.context.io_OwnerResource[j].NominatedResources[0].ioOwnerDetails.IOOwnerUserId,
            currentProcessorName: $.context.io_OwnerResource[j].NominatedResources[0].ioOwnerDetails.IOOwnerName,
            currentProcessorEmail: $.context.io_OwnerResource[j].NominatedResources[0].ioOwnerDetails.IOOwnerEmail,
        }
    });
    var wfInsProc_DelURL = "/WfInsProcessor(InstanceID=" + $.info.workflowInstanceId + ",assignmentID='" + $.context.io_OwnerResource[j].AssignmentID + "',currentProcessorID='" + $.context.io_OwnerResource[j].NominatedResources[0].ioOwnerDetails.IOOwnerUserId + "')";
    $.context.WfInsProc_DelURLs.push(wfInsProc_DelURL);
}