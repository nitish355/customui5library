var id = $.usertasks.usertask3.last.processor
var deleteURL = "/WIRoleAssigned(InstanceID='" + $.info.workflowInstanceId + "',RoleType='Resource',EmpID='" + id + "')";

$.context.DBCall.Request = {};
$.context.DBCall.Request.requests = [];
$.context.DBCall.Request.requests.push({
    id: "1",
    method: "DELETE",
    headers:   {"content-type": "application/json;IEEE754Compatible=true"},
    url: deleteURL
});

delete $.context.DBCall.ResourcesDeleteURLs[id];