$.context.CAManagersList = $.context.DBCall.GetCAManagers.Response.responses[0].body;
$.context.isCAManagersListNotEmpty= $.context.CAManagersList["@odata.count"] > 0 ? true : false;