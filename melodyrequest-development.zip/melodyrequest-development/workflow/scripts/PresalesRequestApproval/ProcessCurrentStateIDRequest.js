$.context.CurrentStateDBCall = {}
$.context.CurrentStateDBCall.Request = {};
$.context.CurrentStateDBCall.Request.requests = [];
if(!$.context.EngagementType){
    $.context.EngagementType = '0001';
}
$.context.CurrentStateDBCall.Request.requests.push({
    id: "1",
    method: "GET",
    url: "/CurrentState",
    headers: { "content-type": "application/json;IEEE754Compatible=true" }
},
    {
        id: "2",
        method: "GET",
        url: "/TechnicalState",
        headers: { "content-type": "application/json;IEEE754Compatible=true" }
    },
    {
        id: "3",
        method: "GET",
        url: "/WF_Defination",
        headers: { "content-type": "application/json;IEEE754Compatible=true" }
    },
    {
        id: "4",
        method: "GET",
        url: "/RequestType?$filter=requestType eq '" + $.context.RequestType + "'",
        headers: { "content-type": "application/json;IEEE754Compatible=true" }
    },
    {
        id: "5",
        method: "GET",
        url: "/CurrentStep",
        headers: { "content-type": "application/json;IEEE754Compatible=true" }
    },
    {
        id: "6",
        method: "GET",
        url: "/RemindMail?$filter=OrgID eq '" + $.context.OrgID + "' and eng_Type_ID eq '" + $.context.EngagementType + "' ",
        headers: { "content-type": "application/json;IEEE754Compatible=true" }
    },
    {
        id: "7",
        method: "GET",
        url: "/MR_UserTask",
        headers: { "content-type": "application/json;IEEE754Compatible=true" }
    },
     {
        id: "8",
        method: "GET",
        url: "/EngagementType?$filter=eng_type_ID eq '" + $.context.EngagementType + "'",
        headers: { "content-type": "application/json;IEEE754Compatible=true" }
    }    
    );

$.context.UT_refID = 1;

$.context.io_Owner_email = $.context.extSystemsUrls.MRRInboxURL + "IOOwnerDetailPage/" + $.info.workflowInstanceId;
$.context.requestor_email = $.context.extSystemsUrls.MRRInboxURL + "SubmitReq/" + $.info.workflowInstanceId;
$.context.processor_email = $.context.extSystemsUrls.MRRInboxURL + "ManagerDetailPage/" + $.info.workflowInstanceId;
$.context.RequestID = {};
$.context.RequestID.value = {};
$.context.RequestID.value = $.context.RefrenceID.Response.value;
$.context.EmailTemplateVars = {};
if($.context.RequestType === 'Account'){
    $.context.EmailTemplateVars.OppHide = "hidden-row";
    $.context.EmailTemplateVars.EmailSubject = $.context.accountName;
}
else{
   $.context.EmailTemplateVars.EmailSubject = $.context.Opp_Desc + ", " + $.context.accountName;
}
if (!$.context.EmailRequestTypeID) {
    if($.context.RequestType === 'Account'){
    $.context.EmailRequestTypeID = $.context.accountId;
    }
else {
    $.context.EmailRequestTypeID = $.context.opportunityId;
}
}
$.context.NewRequest = true;
$.context.PreviousProcessEmail_Notif = "";
$.context.isRework = false;