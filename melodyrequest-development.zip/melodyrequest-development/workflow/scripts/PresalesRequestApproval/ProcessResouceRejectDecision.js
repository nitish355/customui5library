var decision = {
    "UserId": $.context.currentProcessor.id, // Userid for approvalHistory
    "UserName": $.context.currentProcessor.fullName,
    "Role": $.context.currentProcessorRole,
    "StepName": $.context.currentStepName,
    "StepID" :$.context.currentStepID,
    "Decision": $.context.decision,
    "Comments": $.context.comments,
    "Date": new Date()
};

$.context.approvalHistory.push(decision);
$.context.lastAcceptorComments = $.context.comments ? $.context.comments : "";
$.context.comments = "";

var resources = $.context.assignedResourcesIds.split(',');
var filtered = resources.filter(function (val) {
    return val !== $.usertasks.usertask3.last.processor
});
$.context.assignedResourcesIds = filtered.join(',');
$.context.assignedResourcesCount -= 1;

$.context.lastActivityDate = new Date();
