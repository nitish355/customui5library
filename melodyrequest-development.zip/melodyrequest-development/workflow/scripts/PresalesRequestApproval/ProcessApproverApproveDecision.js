var decision = {
    "UserId": $.context.currentProcessor.id, //UserId for approvalHistory
    "UserName": $.context.currentProcessor.fullName,
    "Role": $.context.currentProcessorRole,
    "StepName": $.context.currentStepName,
    "StepID": $.context.currentStepID,
    "Decision": $.context.decision,
    "Comments": $.context.comments,
    "Date": new Date()
};
var approverId = "";
var approvertaskid = "";
$.context.approverData = $.context.currentProcessor;
if ($.context.isResourceProfile === true)
{
   
    if ($.context.lastDecisionTask == 11 ){
    approverId = $.usertasks.usertask11.last.processor;
    approvertaskid = $.usertasks.usertask11.last.id;
}
    else {
        approverId = $.usertasks.usertask10.last.processor;
        approvertaskid = $.usertasks.usertask10.last.id;
    }

}
else {
if ($.context.lastDecisionTask == 3) {
    approverId = $.usertasks.usertask5.last.processor;
    approvertaskid = $.usertasks.usertask5.last.id;
} else if ($.context.lastDecisionTask == 2) {
    approverId = $.usertasks.usertask4.last.processor;
    approvertaskid = $.usertasks.usertask4.last.id;
} else if ($.context.lastDecisionTask == 1) {
    approverId = $.usertasks.usertask2.last.processor;
    approvertaskid = $.usertasks.usertask2.last.id;
}
}

$.context.approverData.id = approverId;
$.context.approverData.itaskid = approvertaskid;


$.context.approvalHistory.push(decision);

$.context.lastApproverComments = $.context.comments ? $.context.comments : "";
$.context.comments = "";

$.context.currentState = $.context.CurrentStateValue.WRESAP.Value;
$.context.lastActivityDate = new Date();
$.context.currentStepName = $.context.CurrentStepValue.RESAPP.Value;//"Presales Resource Approval";
$.context.currentStepID = $.context.CurrentStepValue.RESAPP.ID;
$.context.currentProcessorRole = "Asignee";
$.context.ProcessorComment = [];
var commentForResource = [];
var aResourceData = $.context.Assignment,    
    sResourceNames = aResourceData[0].NominatedResources[0].fullName;
if(aResourceData[0].comments && aResourceData[0].comments !== "")
    {
        commentForResource.push(
      aResourceData[0].NominatedResources[0].fullName +
      " → " +
      aResourceData[0].comments
    );
    }    
if (aResourceData.length > 1) {
    for (var i = 1; i < aResourceData.length; i++) {
        if (aResourceData.length === 2) {
            sResourceNames += " and " + aResourceData[i].NominatedResources[0].fullName;
        }
        else if (i === aResourceData.length - 1) {
            sResourceNames += ", and " + aResourceData[i].NominatedResources[0].fullName;
        } else {
            sResourceNames += ", " + aResourceData[i].NominatedResources[0].fullName;

        }

        if (aResourceData[i].comments && aResourceData[i].comments !== "") {
            commentForResource.push(
                aResourceData[i].NominatedResources[0].fullName +
                " → " +
                aResourceData[i].comments
            );
        }

    }
}
$.context.resourceNames = sResourceNames;
$.context.AllCommentsForResource = commentForResource.length ? commentForResource.join("\n") : "";;
var now = new Date();
$.context.history  = {};   
$.context.history.UserName = $.context.currentProcessor.fullName;
$.context.history.LastStep = 'Review - Processor';
$.context.history.StepName ='Review - Processor - Resource Assigned';
$.context.history.Decision = "Assigned the request for "  + $.context.RequestType + " " + $.context.EmailRequestTypeID + ". Assigned " +  $.context.resourceNames + ".";
$.context.history.Comments = commentForResource.length ? commentForResource.join(", ") : "";
var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
var day = ("0" + now.getUTCDate()).slice(-2), month = months[now.getUTCMonth()],year = now.getUTCFullYear();
$.context.history.DateUTC = month + " " + day + ", " + year;
var hours = now.getUTCHours(), minutes = ("0" + now.getUTCMinutes()).slice(-2),ampm = hours >= 12 ? 'PM' : 'AM';
hours = hours % 12;
hours = hours ? hours : 12; 
$.context.history.TimeUTC = hours + ":" + minutes + " " + ampm + " UTC";
$.context.history.class = "";
$.context.history.HistoryData = "History-Data";
$.context.EmailTemplateVars.approvalHistoryEmail.splice($.context.EmailTemplateVars.HistoryCount, 0 , $.context.history);
while($.context.EmailTemplateVars.approvalHistoryEmail.length<20){
  $.context.EmailTemplateVars.approvalHistoryEmail.push({class :"hidden-row", HistoryData:"hide-row"});
}
$.context.EmailTemplateVars.HistoryCount++;
$.context.EmailTemplateVars.LastActionDateTime = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].DateUTC + " at " + $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].TimeUTC;
$.context.EmailTemplateVars.LastAction = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].UserName +" – "+ $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].LastStep+" – "+$.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].Decision;
$.context.EmailTemplateVars.LastActionComment = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].Comments;
$.context.EmailTemplateVars.approvalHistoryEmail = $.context.EmailTemplateVars.approvalHistoryEmail;