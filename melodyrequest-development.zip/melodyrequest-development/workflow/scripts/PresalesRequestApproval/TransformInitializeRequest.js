if (!$.context.FirstIterationRA) {
    $.context.FirstIterationRA = false;
}

$.context.requestId = new Date().getTime();
$.context.approvalHistory = [];
$.context.AssignmentApproveAll = [];
if (!$.context.DBCall) {
    $.context.DBCall = {};
}
$.context.DBCall.WfInstanceRequest = {};
$.context.DBCall.WfInstanceRequest.requests = [];

$.context.currentProcessorRole = "Requestor";
$.context.currentStepName = $.context.CurrentStepValue.REQSUB.Value;//"Request Submission";
$.context.currentStepID = $.context.CurrentStepValue.REQSUB.ID;
$.context.currentState = $.context.CurrentStateValue.REQSUB.Value;
$.context.lastActivityDate = new Date();
$.context.WfID_PresalesRequestApproval = $.info.workflowInstanceId;

var OrgID_Num = "";
//Code to convert OrgID from SORG-XXXX to XXXX OR MUID-XXXX to XXXX
if ($.context.OrgType == "SORG" || $.context.OrgType == "MUID" )
{ 
        OrgID_Num = $.context.OrgID.substring(5, 9);
        //Code to remove leading Zeroes
        OrgID_Num = OrgID_Num.replace(/^0+/, '');
    }
else if ($.context.OrgType == "PC")
{
    OrgID_Num = $.context.OrgID

}

$.context.CPICalls = {};
$.context.CPICalls.getDataFromCRM = {
    Request: {
        "opportunityId": $.context.opportunityId,
        "requestIntent": "GET_DATA"
    }
}

$.context.accNameFormatted = $.context.accountName.length > 20 ? $.context.accountName.slice(0, 20) + "..." : $.context.accountName;

if ($.context.requestAreaPath.charAt(0) === '\'') {
    $.context.requestAreaPath = $.context.requestAreaPath.substring(1);
}
if ($.context.GUID.charAt(0) === '\'') {
    $.context.GUID = $.context.GUID.substring(1);
}
// escape
//var encodedPath = encodeURIComponent($.context.requestAreaPath)
$.context.areaPathCall = {}
$.context.areaPathCall.Request = {};
$.context.areaPathCall.Request.requests = [];
$.context.areaPathCall.Request.requests.push({
    id: "1",
    method: "GET",
    //    url: "/Resources(RequestArea='" + encodedPath + "',IsActiveEntity=true)",
    url: "/Resources(GUID=" + $.context.GUID + ",IsActiveEntity=true)",
    headers: { "content-type": "application/json;IEEE754Compatible=true" }
},
    // To fetch Email template details
    {
        id: "2",
        method: "GET",
        url: "/Email_Body?$filter=orgID eq '" + OrgID_Num + "' ",
        headers: { "content-type": "application/json;IEEE754Compatible=true" }
    },
    // to fetch Email Delegates Details
    {
        id: "3",
        method: "GET",
        url: "/Email_Delegates?$filter=orgID eq '" + OrgID_Num + "'",
        headers: { "content-type": "application/json;IEEE754Compatible=true" }
    },
    // to fetch routing flags 
    {
        id: "4",
        method: "GET",
        url: "/WF_Routing?$filter=orgID eq '" + OrgID_Num + "' and eng_Type_ID eq '" + $.context.EngagementType + "'",
        headers: { "content-type": "application/json;IEEE754Compatible=true" }
    }

);
$.context.Approval_subject = "";
var FullextSystemsUrls;
if (!$.context.RequestType) {
    $.context.isAccount = false;
} else {
    if ($.context.RequestType == "Account") {
        $.context.isAccount = true;
        $.context.opportunityId = "";
        $.context.Opp_Desc = "";
        $.context.Approval_subject = "/ Acc." + $.context.accountId;
        FullextSystemsUrls = $.context.accountUrl;
    }
    else {
        $.context.isAccount = false;
        FullextSystemsUrls = $.context.extSystemsUrls.harmony;
        $.context.Approval_subject = "/ Opp." + $.context.opportunityId;
        $.context.IndustryName = "";
        $.context.PE_Name = "";
    }
}

//Begin of code of changes by C5350612
var now = new Date();
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');

var refrenceID = $.context.RefrenceID.Response.value;

// Prepare data for WFINSTANCE New Table
var wfIns_data = {};
wfIns_data.instance_GUID = $.info.workflowInstanceId;
wfIns_data.parentInstance_GUID = $.context.parentInstanceID;
if (refrenceID != "") {
    wfIns_data.refID = parseInt(refrenceID);
}
wfIns_data.definitionID = $.context.DefinitionIdValue[1].ID;
wfIns_data.technicalStateID = $.context.TechnicalStateValue.INPR.ID;
wfIns_data.currentStateID = $.context.CurrentStateValue.REQSUB.ID;
wfIns_data.currentStepID = $.context.CurrentStepValue.REQSUB.ID;
wfIns_data.currentProcessorID = $.context.requesterDetails.id;
wfIns_data.currentProcessor = $.context.requesterDetails.fullName;
wfIns_data.currentProcessorEmail = $.context.requesterDetails.email;
wfIns_data.dtCreation_tdate = date;
wfIns_data.dtCreation_ttime = time;
wfIns_data.dtLastActivity_tdate = date;
wfIns_data.dtLastActivity_ttime = time;
wfIns_data.reqAreaGUID = $.context.GUID;
wfIns_data.decisionID = $.context.decision_ID;

// Fields from Submit Request Form
wfIns_data.need_from_CustAdvisory = $.context.requestDetails.typeOfSupport;
if ($.context.requestDetails.isMeetingPlanned === true) {
    wfIns_data.cust_asked_forMeeting = "X";
}
else {
    wfIns_data.cust_asked_forMeeting = "";
}
wfIns_data.meetingTypeID = $.context.requestDetails.meetingTypeKey;
wfIns_data.solution_Models = $.context.requestDetails.solutionsInScope;
wfIns_data.custAdvisory_Resource = $.context.requestDetails.preferredPresales;
wfIns_data.meeting_Goal = $.context.requestDetails.meetingGoal;
wfIns_data.meetingLocation = $.context.requestDetails.meetingLocation;
wfIns_data.meetingDate = $.context.requestDetails.meetingDate;
wfIns_data.meetingTime = $.context.requestDetails.meetingTime;
wfIns_data.involved_SAP_Parties_Name = $.context.requestDetails.involvedPartiesNames;
wfIns_data.participants_Type_Details = $.context.requestDetails.participantTypeDetails;
//wfIns_data.comments = $.context.lastRequestorComments;
if ($.context.requestDetails.isAttachment === true) {
    wfIns_data.isAttachment = "X";
} else {
    wfIns_data.isAttachment = "";
}
//prepare for WfInstance Extention
if ($.context.EngagementType && $.context.EngagementType === '0002') {
    var wfIns_ext_data = {};
    wfIns_ext_data.instance_Guid = $.info.workflowInstanceId;
    wfIns_ext_data.Opp_Number = $.context.requestDetails.Opp_Number;
    wfIns_ext_data.io_Number = $.context.requestDetails.io_Number;
    wfIns_ext_data.contact_Prsn_Id = $.context.requestDetails.contact_Prsn_Id;
    wfIns_ext_data.contact_Prsn_Email = $.context.requestDetails.contact_Prsn_Email;
    wfIns_ext_data.need_From_Fbs = $.context.requestDetails.need_From_Fbs;
    if ($.context.requestDetails.c2c_Deal === true) {
        wfIns_ext_data.c2c_Deal = "X";
    } else {
        wfIns_ext_data.c2c_Deal = "";
    }
    wfIns_ext_data.oppclosing_Date = $.context.requestDetails.oppclosing_Date;
    wfIns_ext_data.contract_Start_Date = $.context.requestDetails.contract_Start_Date;
    wfIns_ext_data.contract_End_Date = $.context.requestDetails.contract_End_Date;
    wfIns_ext_data.supp_Type_FBS_Id = $.context.requestDetails.supp_Type_FBS;
    wfIns_ext_data.supp_Type_Pqa_Id = $.context.requestDetails.supp_Type_Pqa_Id;
    wfIns_ext_data.solution_Id = $.context.requestDetails.solution_Id;
    wfIns_ext_data.est_Acv = $.context.requestDetails.est_Acv;
    wfIns_ext_data.model_Id = $.context.requestDetails.model_Id;
    wfIns_ext_data.isp_Id = $.context.requestDetails.isp_Id;
    wfIns_ext_data.opp_Origin_Id = $.context.requestDetails.opp_Origin_Id;
}
/* Prepare data for WfInsProcessor (Current Processor) Table */
var WfInsProc_data = {};
WfInsProc_data.InstanceID = $.info.workflowInstanceId;
WfInsProc_data.assignmentID = "1";
WfInsProc_data.currentProcessorID = $.context.requesterDetails.id;
WfInsProc_data.currentProcessorName = $.context.requesterDetails.fullName;
WfInsProc_data.currentProcessorEmail = $.context.requesterDetails.email;

/* Prepare DB Call for Workflow Tables */
$.context.DBCall.WfInstanceRequest.requests.push({

    id: "1",
    method: "POST",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WfInstance",
    body: wfIns_data
},
{
    id: "2",
    method: "POST",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WfInsProcessor",
    body: WfInsProc_data
}
);
if ($.context.EngagementType && $.context.EngagementType === '0002') {
    $.context.DBCall.WfInstanceRequest.requests.push({
        id: "3",
        method: "POST",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: "/WfInstanceExt",
        body: wfIns_ext_data
    });
}
// Push Comments request only if a comment was provided
if ($.context.comments && $.context.comments.trim() !== "") {
    var UserTaskRole = "";
    var newdate = new Date().toISOString();
    if ($.context.UserTaskLabelValue) {
        UserTaskRole = $.context.UserTaskLabelValue.Requestor.userTask;
    }
    $.context.DBCall.WfInstanceRequest.requests.push({
        id: "4",
        method: "POST",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: "/Comments",
        body: {
            instanceID: $.info.workflowInstanceId,
            actionId: $.context.decision_ID,
            commentText: $.context.comments,
            userID: $.context.requesterDetails.id,
            userEmail: $.context.requesterDetails.email,
            userName: $.context.requesterDetails.fullName,
            userRole: $.context.UserTaskRole,
             createdAt: newdate,
            modifiedAt: newdate
        }
    });
}
$.context.wasReworked = false;
$.context.ResRework = false;
$.context.ResReject = false;
$.context.io_Owner = false;
$.context.delDraft = false;