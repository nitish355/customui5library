var decision = {
    "UserId": $.context.currentProcessor.id, // Userid for approvalHistory
    "UserName": $.context.currentProcessor.fullName,
    "Role": $.context.currentProcessorRole,
    "StepName": $.context.currentStepName,
    "StepID": $.context.currentStepID,
    "Decision": "Forwarded from "+ $.context.oldReqArea + " to " + $.context.requestArea,
    "Comments": $.context.comments,
    "Date": new Date()
};

$.context.lastForwardedBy = $.context.currentProcessor;
$.context.approverData = $.context.currentProcessor;

//Code to convert SalesOrgID from SORG-XXXX to XXXX
if ($.context.OrgType == "SORG" || $.context.OrgType == "MUID" )
{ 
        var OrgID_Num= $.context.OrgID.substring(5,9);
        //Code to remove leading Zeroes
        OrgID_Num = OrgID_Num.replace(/^0+/, ''); 
    }    
else if ($.context.OrgType == "PC")
{
    OrgID_Num = $.context.OrgID

}
// escape
var encodedPath = encodeURIComponent($.context.requestAreaPath)
$.context.areaPathCall = {}
$.context.areaPathCall.Request = {};
$.context.areaPathCall.Request.requests = [];
$.context.areaPathCall.Request.requests.push({
    id: "1",
    method: "GET",
// Start of code for Melody Resource Request Tool Sprint 1
    url: "/Resources(GUID=" + $.context.forwardGUID  + ",IsActiveEntity=true)",
    headers:   {"content-type": "application/json;IEEE754Compatible=true"}
},
// To fetch Email template details
{
    id: "2",
    method: "GET",
    url: "/Email_Body?$filter=orgID eq '" +  OrgID_Num  + "' " ,     
    headers:   {"content-type": "application/json;IEEE754Compatible=true"}
},
// End of code for Melody Resource Request Tool Sprint 1
// to fetch Email Delegates Details
{
    id: "3",
    method: "GET",
    url: "/Email_Delegates?$filter=orgID eq '" +  OrgID_Num  + "'",      
    headers:   {"content-type": "application/json;IEEE754Compatible=true"}
},
// to check routing flags 
{
    id: "4",
    method: "GET",
    url: "/WF_Routing?$filter=orgID eq '" +  OrgID_Num  + "' and eng_Type_ID eq '" + $.context.EngagementType + "'" ,    
    headers:   {"content-type": "application/json;IEEE754Compatible=true"}
}
);

$.context.approvalHistory.push(decision);
$.context.lastApproverComments = $.context.comments ? $.context.comments : "";
// $.context.comments = "";
$.context.lastActivityDate = new Date();
$.context.currentState = $.context.CurrentStateValue.REQFWD.Value;
