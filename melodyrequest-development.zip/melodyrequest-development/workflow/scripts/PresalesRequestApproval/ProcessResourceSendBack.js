var decision = {
    "UserId" : $.context.ResReworkProcessorId, //UserId for approvalHistory
    "UserName": $.context.ResReworkProcessor,
    "Role": $.context.RerReworkRole,
    "StepName": $.context.currentStepName,
    "StepID" : $.context.currentStepID,
    "Decision": $.context.decision,
    "Comments": $.context.comments,
    "Date": new Date()
};
var now = new Date();
$.context.history  = {};   
$.context.history.UserName = $.context.ResReworkProcessor;
$.context.history.LastStep = 'Review - Resource';
$.context.history.StepName = 'Review - Resource - Sent Back to Requestor';
$.context.history.Decision = 'Sent the request back to the Requestor.';
$.context.history.Comments = $.context.comments? $.context.comments: "";
var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
var day = ("0" + now.getUTCDate()).slice(-2), month = months[now.getUTCMonth()],year = now.getUTCFullYear();
$.context.history.DateUTC = month + " " + day + ", " + year;
var hours = now.getUTCHours(), minutes = ("0" + now.getUTCMinutes()).slice(-2),ampm = hours >= 12 ? 'PM' : 'AM';
hours = hours % 12;
hours = hours ? hours : 12; 
$.context.history.TimeUTC = hours + ":" + minutes + " " + ampm + " UTC";
$.context.history.class = "";
$.context.history.HistoryData = "History-Data";
$.context.EmailTemplateVars.approvalHistoryEmail.splice($.context.EmailTemplateVars.HistoryCount, 0 , $.context.history);
while($.context.EmailTemplateVars.approvalHistoryEmail.length<20){
  $.context.EmailTemplateVars.approvalHistoryEmail.push({class :"hidden-row", HistoryData:"hide-row"});
}
$.context.EmailTemplateVars.HistoryCount++;
$.context.EmailTemplateVars.LastActionDateTime = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].DateUTC + " at " + $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].TimeUTC;
$.context.EmailTemplateVars.LastAction = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].UserName +" – "+ $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].LastStep+" – "+$.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].Decision;
$.context.EmailTemplateVars.LastActionComment = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].Comments;
$.context.approvalHistory.push(decision);
$.context.lastAcceptorComments = $.context.comments ? $.context.comments : "";
$.context.isRework = true;

$.context.currentState = $.context.CurrentStateValue.REESUB.Value;
$.context.lastActivityDate = new Date();

$.context.currentProcessorRole = "Requestor"
$.context.currentProcessor = $.context.requesterDetails;