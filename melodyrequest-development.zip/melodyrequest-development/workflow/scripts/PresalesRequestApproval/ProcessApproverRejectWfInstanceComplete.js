if (!$.context.DBCall) {
    $.context.DBCall = {};
}
$.context.DBCall.isWfInstanceUpdate = true;
$.context.DBCall.Request = {};
$.context.DBCall.Request.requests = [];

var now = new Date();
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');

var approverId = "";
var approvertaskid = "";
if ($.context.isResourceProfile === true) {
    if ($.context.lastDecisionTask == 11) {
        approverId = $.usertasks.usertask11.last.processor;
        approvertaskid = $.usertasks.usertask11.last.id;
    }
    else {
        approverId = $.usertasks.usertask10.last.processor;
        approvertaskid = $.usertasks.usertask10.last.id;
    }
}
else {
    if ($.context.lastDecisionTask == 3) {
        approverId = $.usertasks.usertask5.last.processor;
        approvertaskid = $.usertasks.usertask5.last.id;
    } else if ($.context.lastDecisionTask == 2) {
        approverId = $.usertasks.usertask4.last.processor;
        approvertaskid = $.usertasks.usertask4.last.id;
    } else if ($.context.lastDecisionTask == 1) {
        approverId = $.usertasks.usertask2.last.processor;
        approvertaskid = $.usertasks.usertask2.last.id;
    }
}
// Prepare data for WFINSTANCE New Table
var wfIns_data = {};
wfIns_data.instance_GUID             = $.info.workflowInstanceId;
wfIns_data.parentInstance_GUID      = $.context.parentInstanceID;
wfIns_data.technicalStateID = $.context.TechnicalStateValue.COMP.ID;
wfIns_data.currentStateID = $.context.currentStateID;
wfIns_data.currentStepID = $.context.CurrentStepValue.MANAPP.ID;
if ($.context.currentProcessor) {
    wfIns_data.currentProcessorID = $.context.currentProcessor.id;
    wfIns_data.currentProcessor = $.context.currentProcessor.fullName;
    wfIns_data.currentProcessorEmail  = $.context.currentProcessor.email;
} else if ($.context.requesterDetails) {
    wfIns_data.currentProcessorID = $.context.requesterDetails.id;
    wfIns_data.currentProcessor = $.context.requesterDetails.fullName;
    wfIns_data.currentProcessorEmail  = $.context.requesterDetails.email;
} else {
    wfIns_data.currentProcessor = "";
    wfIns_data.currentProcessorEmail = "";
    wfIns_data.currentProcessorID = "";
}
wfIns_data.substituteProcessorID = "";
wfIns_data.substituteProcessor = "";
wfIns_data.substituteProcessorEmail = "";
wfIns_data.dtLastActivity_tdate = date;
wfIns_data.dtLastActivity_ttime = time;
if ($.context.decision_ID) {
wfIns_data.decisionID                = $.context.decision_ID;
}
//wfIns_data.comments = $.context.comments;
wfIns_data.reqApprover_ID = approverId;
wfIns_data.reqApprover_Name = $.context.approverData.fullName;
wfIns_data.reqApprover_EMail = $.context.approverData.email;
if($.context.UserTaskLabelValue)
    {
        wfIns_data.userTaskID = $.context.UserTaskLabelValue.None.userTaskID;
    }

/* Prepare data for WfInsProcessor (Current Processor) Table */
var WfInsProc_data = {};
WfInsProc_data.InstanceID = $.info.workflowInstanceId;
WfInsProc_data.assignmentID = "1";
WfInsProc_data.currentProcessorID = wfIns_data.currentProcessorID;
WfInsProc_data.currentProcessorName = wfIns_data.currentProcessor;
WfInsProc_data.currentProcessorEmail = wfIns_data.currentProcessorEmail;

//prepare data for WFHistory

var ReqHistory_data = {};
ReqHistory_data.InstanceID = $.info.workflowInstanceId;
ReqHistory_data.UserTaskID = approvertaskid;
ReqHistory_data.AssignmentID = "0";
ReqHistory_data.User_ID = approverId;
ReqHistory_data.User_Name = $.context.approverData.fullName;
ReqHistory_data.User_EMail = $.context.approverData.email;
if ($.context.isSubstitute === true){
    ReqHistory_data.StateID = $.context.CurrentStateValue.WSUBMN.ID;
}
else
{
    ReqHistory_data.StateID = $.context.CurrentStateValue.WMNAPP.ID;
}
ReqHistory_data.StepID = $.context.currentStepID;
ReqHistory_data.ActionTaken = "Reject";
if ($.context.rejectReasonID) {
    ReqHistory_data.RejID = $.context.rejectReasonID;
}
ReqHistory_data.Role = "Approver";
ReqHistory_data.Decision = $.context.decision_ID;
ReqHistory_data.Comments = $.context.comments;
ReqHistory_data.Date = date;
ReqHistory_data.Time = time;
if (!$.context.UT_refID) {
    $.context.UT_refID = 1;
}
else {
    $.context.UT_refID += 1;
}
ReqHistory_data.UT_refID = $.context.UT_refID;

var wfRequest = {
    id: "1",
    method: "PATCH",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WfInstance(instance_GUID='" + $.info.workflowInstanceId + "',parentInstance_GUID='" + $.context.parentInstanceID + "')",
    body: wfIns_data
};
$.context.DBCall.Request.requests.push(wfRequest);
 
// var WfInsProc_Request = {
//     id: "2",
//     method: "PATCH",
//     headers: { "content-type": "application/json;IEEE754Compatible=true" },
//     url:"/WfInsProcessor(InstanceID="+ $.info.workflowInstanceId +",assignmentID='1',currentProcessorID='"+ wfIns_data.currentProcessorID +"')",
//     body: WfInsProc_data
// };
// $.context.DBCall.Request.requests.push(WfInsProc_Request);

var wfhistory_Request = {   
    id: "2",
    method: "POST",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WFHistory",
    body: ReqHistory_data
};
$.context.DBCall.Request.requests.push(wfhistory_Request);

var WfInsProc_DelURLs = $.context.WfInsProc_DelURLs;
    var WfInsProc_length = WfInsProc_DelURLs.length;
    for (var p = 0; p < WfInsProc_length; p++) { 
        $.context.DBCall.Request.requests.push({
            id: (p + 3).toString(),
            dependsOn: ["1"],
            method: "DELETE",
            headers: { "content-type": "application/json;IEEE754Compatible=true" },
            url: WfInsProc_DelURLs[p]
        });
    }
    WfInsProc_DelURLs = [];
    $.context.WfInsProc_DelURLs = [];   
        $.context.DBCall.Request.requests.push({
            id: ( 4 + WfInsProc_length).toString(),            
            dependsOn: [$.context.DBCall.Request.requests[$.context.DBCall.Request.requests.length-1].id],
            method: "POST",
            headers: { "content-type": "application/json;IEEE754Compatible=true" },
            url: "/WfInsProcessor",
            body: WfInsProc_data            
        });
        WfInsProc_DelURLs =  "/WfInsProcessor(InstanceID=" + $.info.workflowInstanceId + ",assignmentID='1',currentProcessorID='" + wfIns_data.currentProcessorID + "')";
        $.context.WfInsProc_DelURLs.push(WfInsProc_DelURLs);

// Push Comments request only if a comment was provided
if ($.context.comments && $.context.comments.trim() !== "") {
    var UserTaskRole = "";
    var newdate = new Date().toISOString();
    if ($.context.UserTaskLabelValue) {
        UserTaskRole = $.context.UserTaskLabelValue.Processor.userTask;
    }
    $.context.DBCall.Request.requests.push({
        id: (5 + WfInsProc_length).toString(),
        method: "POST",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: "/Comments",
        body: {
            instanceID: $.info.workflowInstanceId,
            actionId: $.context.decision_ID,
            commentText: $.context.comments,
            userID: approverId,
            userEmail: $.context.approverData.email,
            userName: $.context.approverData.fullName,
            userRole: UserTaskRole,
            createdAt: newdate,
            modifiedAt: newdate
        }
    });
}