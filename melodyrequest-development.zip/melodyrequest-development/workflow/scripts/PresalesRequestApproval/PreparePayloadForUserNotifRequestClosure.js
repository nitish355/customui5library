var UserNotifpayload = {};
var users = {};
UserNotifpayload.notif_Id = "11";
UserNotifpayload.notifVal_Id = "0002";
var requesterUser = getFormattedObject($.context.requesterDetails);
if (requesterUser.length > 0) {
  users.requester = requesterUser;
}

var processorUsers = getFormattedObject($.context.primaryApproverDetails);
if (processorUsers.length > 0) {
  users.processor = processorUsers;
}

var substituteUsers = getFormattedObject($.context.substituteApproverDetails);
if (substituteUsers.length > 0) {
  users.substitute = substituteUsers;
}
var previousProcessor = getFormattedObject($.context.PreviousApproverDetails)
if (previousProcessor.length > 0) {
  users.oldProssOrDirectMgr = previousProcessor;
}
var Allresources = getFormattedObject($.context.AllApprovedResources)
if (Allresources.length > 0) {
  users.resource = Allresources;
}
if ($.context.RequestType == "Opportunity") {
  if ($.context.oppOwnerDetails && $.context.oppOwnerDetails.id && $.context.oppOwnerDetails.email) {
    users.reqTypeOwner = [{
      userId: $.context.oppOwnerDetails.id.toUpperCase(),
      email: $.context.oppOwnerDetails.email
    }];
  }
} else {
  if ($.context.accOwnerDetails && $.context.accOwnerDetails.id && $.context.accOwnerDetails.email) {
    users.reqTypeOwner = [{
      userId: $.context.accOwnerDetails.id.toUpperCase(),
      email: $.context.accOwnerDetails.email
    }];
  }
}

UserNotifpayload.users = users;

$.context.User_NotifDBCallPayload = {};
$.context.User_NotifDBCallPayload = UserNotifpayload;

function getFormattedObject(ProcessorDetails) {

  var GetUserNotifData = [];


  var list = [];

  if (Array.isArray(ProcessorDetails) && ProcessorDetails.length > 0 && ProcessorDetails[0].NominatedResources) {
    ProcessorDetails.forEach(function (a) {
      if (a.NominatedResources && a.NominatedResources[0]) {
        list.push(a.NominatedResources[0]);
      }
    });
  }
  else if (Array.isArray(ProcessorDetails)) {
    list = ProcessorDetails;
  }
  else {
    list = [ProcessorDetails];
  }

  list.forEach(function (val) {
    var uid = val.userId || val.id;
    if (uid && val.email) {
    GetUserNotifData.push({
        userId: uid.toUpperCase(),
        email: val.email
      });
    }
  });

  return GetUserNotifData;

};