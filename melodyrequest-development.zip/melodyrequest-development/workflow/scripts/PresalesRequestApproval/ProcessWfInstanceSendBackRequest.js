var now = new Date();
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');

$.context.DBCall.isWfInstanceUpdate = true;
$.context.DBCall.Request = {};
$.context.CheckResReworkFlag = false;
// Prepare data for WFINSTANCE New Table
var wfIns_data = {};
wfIns_data.instance_GUID             = $.info.workflowInstanceId;
wfIns_data.parentInstance_GUID      = $.context.parentInstanceID;
wfIns_data.currentTaskInstanceID     = null;
wfIns_data.technicalStateID = $.context.TechnicalStateValue.INPR.ID;
wfIns_data.currentStateID = $.context.CurrentStateValue.REESUB.ID;
wfIns_data.currentStepID = $.context.CurrentStepValue.REESUB.ID;
wfIns_data.currentProcessorID = $.context.currentProcessor.id;
wfIns_data.currentProcessor = $.context.currentProcessor.fullName;
wfIns_data.currentProcessorEmail = $.context.currentProcessor.email;
wfIns_data.substituteProcessorID = "";
wfIns_data.substituteProcessor = "";
wfIns_data.substituteProcessorEmail = "";
wfIns_data.reqApprover_ID = $.context.approverData.id;
wfIns_data.reqApprover_Name = $.context.approverData.fullName;
wfIns_data.reqApprover_EMail = $.context.approverData.email;
wfIns_data.dtLastActivity_tdate = date;
wfIns_data.dtLastActivity_ttime = time;
wfIns_data.decisionID                = $.context.decision_ID;
//wfIns_data.comments = $.context.comments;
wfIns_data.currentTaskURL = null;
if($.context.UserTaskLabelValue)
    {
        wfIns_data.userTaskID = $.context.UserTaskLabelValue.Requestor.userTaskID;
    }

$.context.DBCall.Request.requests = [];
var wfRequest = {
    id: "1",
    method: "PATCH",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WfInstance(instance_GUID='" + $.info.workflowInstanceId + "',parentInstance_GUID='" + $.context.parentInstanceID + "')",
    body: wfIns_data
};
$.context.DBCall.Request.requests.push(wfRequest);

var approvertaskId = "";

if ($.context.isResourceProfile === true)
{   
    if ($.context.lastDecisionTask == 11 ){
    approvertaskId = $.usertasks.usertask11.last.id;
}
    else {
        approvertaskId = $.usertasks.usertask10.last.id;
    }
}
else {
    if ($.context.lastDecisionTask == 3) {
        approvertaskId = $.usertasks.usertask5.last.id;
    } else if ($.context.lastDecisionTask == 2) {
        approvertaskId = $.usertasks.usertask4.last.id;
    } else if ($.context.lastDecisionTask == 1) {
        approvertaskId = $.usertasks.usertask2.last.id;

    }

}


// prepare data for ReqHistory 
var ReqHistory_data = {};
ReqHistory_data.InstanceID = $.info.workflowInstanceId;
ReqHistory_data.UserTaskID = approvertaskId;
if ($.context.reworkAssignID) {
    $.context.Assignment.forEach(function(val){
        if (val.ResDecision == "Send Back to Requestor")
        {
            ReqHistory_data.User_ID = val.ResCurrentProcessor.userId;
            ReqHistory_data.User_Name = val.ResCurrentProcessor.fullname;
            ReqHistory_data.User_EMail = val.ResCurrentProcessor.email;
            ReqHistory_data.UserTaskID = val.ResourcesUserTaskID;
            $.context.CheckResReworkFlag =true;
        }

        
    });
    ReqHistory_data.AssignmentID = $.context.reworkAssignID;
    ReqHistory_data.StateID = $.context.CurrentStateValue.WRESAP.ID;
    ReqHistory_data.Role = "Resource";
    
}
else {
    ReqHistory_data.UserTaskID = approvertaskId;
    ReqHistory_data.AssignmentID = "0";
    if ($.context.isSubstitute === true){
        ReqHistory_data.StateID = $.context.CurrentStateValue.WSUBMN.ID;
    }
    else{
        ReqHistory_data.StateID = $.context.CurrentStateValue.WMNAPP.ID;
    }   
    ReqHistory_data.Role = "Approver";
    ReqHistory_data.User_ID = $.context.approverData.id;
    ReqHistory_data.User_Name = $.context.approverData.fullName;
    ReqHistory_data.User_EMail = $.context.approverData.email;
}
ReqHistory_data.Decision = $.context.decision_ID;
if ($.context.ResRework) {
    ReqHistory_data.StepID = $.context.CurrentStepValue.RESAPP.ID;
}
else {
    ReqHistory_data.StepID = $.context.CurrentStepValue.MANAPP.ID;
}
ReqHistory_data.ActionTaken = "Send Back to Requestor" ;
ReqHistory_data.Comments = $.context.comments;
ReqHistory_data.Date = date;
ReqHistory_data.Time = time;
if (!$.context.UT_refID) {
    $.context.UT_refID = 1;
}
else {
    $.context.UT_refID += 1;
}
ReqHistory_data.UT_refID = $.context.UT_refID; 
var wfhistory = {   
    id: "2",
    method: "POST",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WFHistory",
    body: ReqHistory_data
                };
$.context.DBCall.Request.requests.push(wfhistory);

//Logic to DELETE Current Processors from table WfInsProcessor
if($.context.ResRework){
    $.context.WfInsProc_DelURLs = $.context.WfInsRes_DelURLs;
}
if ($.context.WfInsProc_DelURLs) {
    var len_wfInsProc_DelURL = $.context.WfInsProc_DelURLs.length;
    for (var i = 0; i < len_wfInsProc_DelURL; i++) {
        $.context.DBCall.Request.requests.push({
            id: (i + 3 ).toString(),
            dependsOn: [$.context.DBCall.Request.requests[$.context.DBCall.Request.requests.length-1].id],
            method: "DELETE",
            headers: { "content-type": "application/json;IEEE754Compatible=true" },
            url: $.context.WfInsProc_DelURLs[i]
        });
    }
}
$.context.WfInsProc_DelURLs_Manager_SBR = "";
//Logic to POST Current Processors (i.e. Resources) to table WfInsProcessor
        $.context.DBCall.Request.requests.push({
            id: (4  + len_wfInsProc_DelURL).toString(),
           // dependsOn: ["1"],
            dependsOn: [$.context.DBCall.Request.requests[$.context.DBCall.Request.requests.length-1].id],
            method: "POST",
            headers: { "content-type": "application/json;IEEE754Compatible=true" },
            url: "/WfInsProcessor",
            body: {
                InstanceID: $.info.workflowInstanceId,
                assignmentID: "1",
                currentProcessorID: $.context.currentProcessor.id,
                currentProcessorName: $.context.currentProcessor.fullName,
                currentProcessorEmail: $.context.currentProcessor.email,
            }
        });
        $.context.WfInsProc_DelURLs_Manager_SBR = "/WfInsProcessor(InstanceID=" + $.info.workflowInstanceId + ",assignmentID='1',currentProcessorID='" + $.context.currentProcessor.id + "')";
 
// Push Comments request only if a comment was provided
$.context.commentNotif_flag = false;
if ($.context.CheckResReworkFlag !== true) {
    if ($.context.comments && $.context.comments.trim() !== "") {
        var UserTaskRole = "";
        var newdate = new Date().toISOString();
        if ($.context.UserTaskLabelValue) {
            UserTaskRole = $.context.UserTaskLabelValue.Processor.userTask;
        }
        $.context.DBCall.Request.requests.push({
            id: (5 + len_wfInsProc_DelURL).toString(),
            method: "POST",
            headers: { "content-type": "application/json;IEEE754Compatible=true" },
            url: "/Comments",
            body: {
                instanceID: $.info.workflowInstanceId,
                actionId: $.context.decision_ID,
                commentText: $.context.comments,
                userID: $.context.approverData.id,
                userEmail: $.context.approverData.email,
                userName: $.context.approverData.fullName,
                userRole: UserTaskRole,
                createdAt: newdate,
                modifiedAt: newdate
            }
        });
        var userChatCommentDetails = {};
        userChatCommentDetails.commentText = $.context.comments;
        userChatCommentDetails.userID = $.context.approverData.id;
        userChatCommentDetails.userEmail = $.context.approverData.email;
        userChatCommentDetails.userName = $.context.approverData.fullName;
        userChatCommentDetails.userRole = UserTaskRole;
        userChatCommentDetails.commentType =  "ACTION";
        $.context.commentNotif_flag = true;
        $.context.userChatCommentDetails = userChatCommentDetails;
        var CommentNotifPayload = {};
        CommentNotifPayload.context = {};
        CommentNotifPayload.context = JSON.stringify($.context);
        $.context.CommentNotifPayload = CommentNotifPayload;

    }
}
if($.context.ResRework){
        if ($.context.Assignment) {
            var LenAssign = $.context.Assignment.length;
            for (var k = 0; k < LenAssign; k++) {
                var aAssignmentID = $.context.Assignment[k].AssignmentID;
                var WfAssigndeleteURL = "/WfInstanceAssignment(InstanceID='" + $.info.workflowInstanceId + "',AssignmentID='" + aAssignmentID + "')";
                $.context.DBCall.Request.requests.push({
                    id: (k + 6 + len_wfInsProc_DelURL).toString(),
                    dependsOn: ["1"],
                    method: "DELETE",
                    headers: { "content-type": "application/json;IEEE754Compatible=true" },
                    url: WfAssigndeleteURL,
                });
            }
        }
    }
    if($.context.isRework && $.context.AssignmentApprove){      
            var LenAssign = $.context.AssignmentApprove.length;
            for (var k = 0; k < LenAssign; k++) {
                var aAssignmentID = $.context.AssignmentApprove[k].AssignmentID;
                var WfAssigndeleteURL = "/WfInstanceAssignment(InstanceID='" + $.info.workflowInstanceId + "',AssignmentID='" + aAssignmentID + "')";
                $.context.DBCall.Request.requests.push({
                    id: (k + 6 + len_wfInsProc_DelURL).toString(),
                    dependsOn: ["1"],
                    method: "DELETE",
                    headers: { "content-type": "application/json;IEEE754Compatible=true" },
                    url: WfAssigndeleteURL,
                });
            }
        }  

$.context.comments = ""; //Clearing processor comment
$.context.reworkAssignID = false;
$.context.RequesterEmail_NotifFwd = "";