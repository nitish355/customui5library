var mResources = $.context.CPICalls.getResourcesFromCRM.Response.results;
$.context.approverDetails = [];
$.context.substituteApproverDetails = [];
$.context.availableResources = [];
$.context.EmailDelegatesDetails = [];

if ($.context.areaPathCall.Response && $.context.areaPathCall.Response.responses && $.context.areaPathCall.Response.responses.length > 0 ) {
    var requestAreaResponse = $.context.areaPathCall.Response.responses[0].body
    if (requestAreaResponse && requestAreaResponse.Resources) {
        requestAreaResponse.Resources.split(';').forEach(function (val) {
            if (val !== "" && mResources[val]) {
                var data = {
                    fullName: mResources[val].NAME,
                    email: mResources[val].EMAIL,
                    partnerId: mResources[val].PARTNER,
                    address: mResources[val].ADDRESS,
                    userId: mResources[val].USERID,
                    country: mResources[val].COUNTRY
                };
                $.context.availableResources.push(data);
            }
        });
    }

    if (requestAreaResponse && requestAreaResponse.SubstituteApprovers) {
        requestAreaResponse.SubstituteApprovers.split(';').forEach(function (val) {
            if (val !== "" && mResources[val]) {
                var data = {
                    fullName: mResources[val].NAME,
                    email: mResources[val].EMAIL,
                    partnerId: mResources[val].PARTNER,
                    address: mResources[val].ADDRESS,
                    userId: mResources[val].USERID,
                    country: mResources[val].COUNTRY
                };
                $.context.substituteApproverDetails.push(data);
            }
        });
    }

    if (requestAreaResponse && requestAreaResponse.Approvers) {
        requestAreaResponse.Approvers.split(';').forEach(function (val) {
            if (val !== "" && mResources[val]) {
                var data = {
                    fullName: mResources[val].NAME,
                    email: mResources[val].EMAIL,
                    partnerId: mResources[val].PARTNER,
                    address: mResources[val].ADDRESS,
                    userId: mResources[val].USERID,
                    country: mResources[val].COUNTRY
                };
                $.context.approverDetails.push(data);
            }
        });
    }
    if ( $.context.areaPathCall.Response.responses[2].body.value.length > 0 ){
    var emaildelegates = $.context.areaPathCall.Response.responses[2].body.value[0] ; 
    }
    if (emaildelegates && emaildelegates.Email_Delegates) {
        emaildelegates.Email_Delegates.split(';').forEach(function (val) {
            if (val !== "" && mResources[val]) {
                var data = {
                    fullName: mResources[val].NAME,
                    email: mResources[val].EMAIL,
                    partnerId: mResources[val].PARTNER,
                    address: mResources[val].ADDRESS,
                    userId: mResources[val].USERID,
                    country: mResources[val].COUNTRY
                };
                $.context.EmailDelegatesDetails.push(data);
            }
        });
    }

}

// email
var aApproversData = $.context.approverDetails,
    sApproverIntro = "Dear " + aApproversData[0].fullName + ",",
    sApproverEmails = aApproversData[0].email,
    sApproverIds = aApproversData[0].userId,
    sApproverNames = aApproversData[0].fullName,
    sApproverInfo = aApproversData[0].fullName + "(" + aApproversData[0].userId + "," + aApproversData[0].email + ")";

if (aApproversData.length > 1) {
    for (var i = 1; i < aApproversData.length; i++) {
        sApproverIntro += "\nDear " + aApproversData[i].fullName + ",";
        sApproverEmails += "," + aApproversData[i].email;
        sApproverIds += "," + aApproversData[i].userId,
        sApproverNames += "," + aApproversData[i].fullName;
        sApproverInfo += "," + aApproversData[i].fullName + "(" + aApproversData[i].userId + "," + aApproversData[i].email + ")";
    }
}

$.context.approverNames = sApproverNames;
$.context.notifyApproversEmailIntro = sApproverIntro;
$.context.approversEmails = sApproverEmails;
$.context.approversIds = sApproverIds;
$.context.ApproverInfo = sApproverInfo;

//for email delegates - email intro, recipients etc 
if ($.context.EmailDelegatesDetails.length > 0) {
var aDelegatesData = $.context.EmailDelegatesDetails,

      sDelegatesIntro = "Dear " + aDelegatesData[0].fullName + ",",
    sDelegatesEmails = aDelegatesData[0].email,
    sDelegatesIds = aDelegatesData[0].userId,
    sDelegatesNames = aDelegatesData[0].fullName;
    if (aDelegatesData.length > 1) {
    for (var i = 1; i < aDelegatesData.length; i++) {
        sDelegatesIntro += "\nDear " + aDelegatesData[i].fullName + ",";
        sDelegatesEmails += "," + aDelegatesData[i].email;
        sDelegatesIds += "," + aDelegatesData[i].userId,
        sDelegatesNames += "," + aDelegatesData[i].fullName;
    }
}


$.context.DelegatesNames = sDelegatesNames;
$.context.NotifyDelegatesEmailIntro = sDelegatesIntro;
$.context.DelegatesEmails = sDelegatesEmails;
$.context.DelegatesIds = sDelegatesIds;

}
//dynamic email configuration
if ( $.context.RequestType == "Opportunity" ) {
    $.context.Opp_ID = "Opportunity ID:" ;
    $.context.CRev_L = "Cloud Revenue:" ;
    $.context.OpRev_L = "On Premise Revenue:" ;
    
}