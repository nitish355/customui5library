$.context.lastActivityDate = new Date();
var currentStateID = "";
if ($.context.AllReject){    
    $.context.currentState = $.context.requestState; 
    currentStateID = $.context.requestStateID;
}
else {
    $.context.currentState = $.context.requestState; 
    currentStateID = $.context.requestStateID;
}

var now = new Date();
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');

if (!$.context.DBCall) {
    $.context.DBCall = {};
}
$.context.DBCall.isWfInstanceUpdate = true;
$.context.DBCall.Request = {};

// Prepare data for WFINSTANCE New Table
var wfIns_data = {};
wfIns_data.instance_GUID             = $.info.workflowInstanceId;
wfIns_data.parentInstance_GUID      = $.context.parentInstanceID;
wfIns_data.technicalStateID = $.context.TechnicalStateValue.COMP.ID;
wfIns_data.dtLastActivity_tdate = date;
wfIns_data.dtLastActivity_ttime = time;
wfIns_data.currentProcessorID = $.context.resCurrentProcessor_id ? $.context.resCurrentProcessor_id : $.context.currentProcessor.id;
wfIns_data.currentProcessor = $.context.resCurrentProcessor_fullName ? $.context.resCurrentProcessor_fullName : $.context.currentProcessor.fullName;
wfIns_data.currentProcessorEmail = $.context.resCurrentProcessor_email ? $.context.resCurrentProcessor_email : $.context.currentProcessor.email;
wfIns_data.substituteProcessorID = "";
wfIns_data.substituteProcessor = "";
wfIns_data.substituteProcessorEmail = "";
wfIns_data.reqResources = "";
wfIns_data.reqIOApprover = "";
if ($.context.reqResources != "") {
    wfIns_data.reqResources = $.context.reqResource.slice(0, -1);
}
if ($.context.reqIOApprover != "") {
    wfIns_data.reqIOApprover = $.context.reqIOApprover;
}
wfIns_data.currentStateID = currentStateID;
wfIns_data.reqApprover_ID = $.context.approverData.id;
wfIns_data.reqApprover_Name = $.context.approverData.fullName;
wfIns_data.reqApprover_EMail = $.context.approverData.email;
wfIns_data.decisionID = $.context.decision_ID;
if($.context.UserTaskLabelValue)
    {
        wfIns_data.userTaskID = $.context.UserTaskLabelValue.None.userTaskID;
    }

$.context.DBCall.Request.requests = [];
var wfRequest = {
    id: "1",
    method: "PATCH",
    url: "/WfInstance(instance_GUID='" + $.info.workflowInstanceId + "',parentInstance_GUID='" + $.context.parentInstanceID + "')",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    body: wfIns_data
};
$.context.DBCall.Request.requests.push(wfRequest);

var LenAssign = $.context.Assignment.length;

for (var k = 0; k < LenAssign; k++) {
    var aAssignmentID = $.context.Assignment[k].AssignmentID;
    var WfAssignPatchURL = "/WfInstanceAssignment(InstanceID='" + $.info.workflowInstanceId + "',AssignmentID='" + aAssignmentID + "')";
    $.context.DBCall.Request.requests.push({
        id: (k + 2).toString(),
        dependsOn: ["1"],
        method: "PATCH",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: WfAssignPatchURL,
        body: {
            InstanceID: $.info.workflowInstanceId,
            AssignmentID: aAssignmentID,
            //TechnicalState: "complete",
            technicalStateID:  $.context.TechnicalStateValue.COMP.ID,
            DTLastActivity_tdate: date,
            DTLastActivity_ttime: time,
            decisionID: $.context.decision_ID,
           // CurrentState: $.context.currentState,
           currentStateID : currentStateID,
            CurrentStepName: $.context.currentStepName,
            CurrentProcessor: $.context.resCurrentProcessor_fullName ? $.context.resCurrentProcessor_fullName : $.context.currentProcessor.fullName,
            reqResource_ID: $.context.Assignment[k].ResCurrentProcessor.userId,
            reqResource_Name: $.context.Assignment[k].ResCurrentProcessor.fullname,
            reqResource_EMail: $.context.Assignment[k].ResCurrentProcessor.email
        }
    });
}
//Logic to DELETE Current Processors from table WfInsProcessor
var len_wfInsProc_DelURL = $.context.WfInsProc_DelURLs.length;
for (var i = 0; i < len_wfInsProc_DelURL; i++) {
    $.context.DBCall.Request.requests.push({
        id: (i + 3 + LenAssign).toString(),
        dependsOn: ["1"],
        method: "DELETE",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: $.context.WfInsProc_DelURLs[i]
    });
}
if ($.context.isSubstitute === true){
    var StateID =  $.context.CurrentStateValue.RSBCOM.ID;
}
else
{
    var StateID =  $.context.CurrentStateValue.REQCOM.ID;
}
if ($.context.WFHistoryMAXUT_refID) {
    $.context.DBCall.Request.requests.push({
        id: "100",
        method: "PATCH",
        url: "/WFHistory(InstanceID=" + $.info.workflowInstanceId + ",UserTaskID=" + $.context.WFHistoryMAXUT_refID.value[0].UserTaskID + ")",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        body: {
            StateID: StateID,
            // Date: date,
            // Time: time
        }
    });

}