$.context.currentState = $.context.CurrentStateValue.WMNAPP.Value;
$.context.currentStepName = $.context.CurrentStepValue.MANAPP.Value;//"Presales Manager Approval";
$.context.currentStepID = $.context.CurrentStepValue.MANAPP.ID;
$.context.currentProcessorRole = "Approver";

var now = new Date();
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');

if (!$.context.DBCall) {
    $.context.DBCall = {};
}
$.context.DBCall.isWfInstanceUpdate = $.context.wasReworked ? true : false;

$.context.DBCall.Request = {};

var data = {}

data.InstanceID = $.info.workflowInstanceId;

//data.TechnicalState = "inProcess";
data.technicalStateID = $.context.TechnicalStateValue.INPR.ID;

//data.CurrentState = $.context.currentState;
data.CurrentStepName = $.context.currentStepName;
data.currentStepID = $.context.CurrentStepValue.MANAPP.ID;
data.CurrentProcessor = $.context.currentProcessor.fullName;
data.currentProcessorID = $.context.currentProcessor.id;
data.currentProcessorEmail = $.context.currentProcessor.email;
data.currentStateID = $.context.CurrentStateValue.WMNAPP.ID;

data.DTLastActivity_tdate = date;
data.DTLastActivity_ttime = time;

$.context.DBCall.Request.requests = [];

var wfUrl = "/WfInstance('" + $.info.workflowInstanceId + "')";

var wfRequest = {
    id: "1",
    method: "PATCH",
    url: wfUrl,
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    body: data
};

$.context.DBCall.Request.requests.push(wfRequest);