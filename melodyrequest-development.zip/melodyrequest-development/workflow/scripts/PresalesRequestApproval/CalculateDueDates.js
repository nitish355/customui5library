// calculte timestamps for sending task to substitute/CA manager
var oneDayInMs = 86400 * 1000;
var twoDaysInMs = 86400 * 2 * 1000;
var currentTs = new Date().getTime() + 3600 * 2 * 1000;

$.context.tsUntilSubstituteNotif = calculateDueDate(oneDayInMs);
$.context.tsUntilEscalateNotif = calculateDueDate(twoDaysInMs);

$.context.dueDateForManagerApproval = calculateDuration(currentTs, $.context.tsUntilSubstituteNotif);
$.context.dueDateForSubstituteApproval = calculateDuration($.context.tsUntilSubstituteNotif, $.context.tsUntilEscalateNotif);
$.context.Skipreminderflag =  false;
if ($.context.isResourceProfile == true){
    if ($.context.EmailReminderValue != 0){
    var emailreminderMS = $.context.EmailReminderValue * 3600 * 1000;
    var emailreminderDuration = calculateDueDate(emailreminderMS);
    $.context.EmailReminder = calculateDuration(currentTs, emailreminderDuration);}
    else
    {
        $.context.Skipreminderflag =  true;
    }

}

function calculateDueDate(dueTime) {
    var dueDateInMs = null;
    var currentTimestamp = new Date().getTime() + 3600 * 2 * 1000;
    var currentDate = new Date(currentTimestamp);
    currentDate.setHours(0, 0, 0, 0);

    // if request was created over the weekend
    if (currentDate.getDay() == 6 || currentDate.getDay() == 0) {
        var nextMonday = currentDate.setDate(currentDate.getDate() + (((1 + 7 - currentDate.getDay()) % 7) || 7));
        dueDateInMs = nextMonday + dueTime;
    }
    // if request was created on a business day
    else {
        var nextSaturday = currentDate.setDate(currentDate.getDate() + (((6 + 7 - currentDate.getDay()) % 7) || 7));
        nextSaturday = new Date(nextSaturday).setHours(0, 0, 0, 0); // timestamp of next Saturday 00:00
        var timeBeforeSaturday = nextSaturday - currentTimestamp;
        if (dueTime > timeBeforeSaturday) {
            var remainingTimeInMs = dueTime - timeBeforeSaturday;
            var nextMonday = currentDate.setDate(currentDate.getDate() + (((1 + 7 - currentDate.getDay()) % 7) || 7));
            dueDateInMs = nextMonday + remainingTimeInMs;
        } else {
            dueDateInMs = currentTimestamp + dueTime;
        }
    }
    return dueDateInMs;
}

function calculateDuration(start, end) {
    // var start = new Date().getTime() + 3600 * 2 * 1000;
    var milliseconds = Math.abs(end - start).toString()
    var seconds = parseInt(milliseconds / 1000);
    var minutes = parseInt(seconds / 60);
    var hours = parseInt(minutes / 60);
    var days = parseInt(hours / 24);

    return "P" + days + "DT" + hours % 24 + "H" + minutes % 60 + "M" + seconds % 60 + "S";
}

//for forward decision
$.context.oldReqArea  =  $.context.requestArea ; 

//temp code 
if ($.context.isResourceProfile == true){

$.context.RP_role = $.context.aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RoleDesc;
 $.context.RP_rolearea = $.context.aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RoleAreaDesc;
 $.context.RP_BusinessInd = $.context.Em_ResPro.BA_Ind;
$.context.RP_BusinessLOB = $.context.Em_ResPro.BAlob;
 $.context.RP_CrossCover = $.context.Em_ResPro.CrsCvg;
 //$.context.RP_BusinessSeg = $.context.Em_ResPro.BA_Segment;
 $.context.RP_Hub = $.context.Em_ResPro.Hub;
 if($.context.isResourceProfile === true){
    $.context.checkIsResource = true;
 }else{
    $.context.checkIsResource = false;
 }

}
$.context.isSubstitute = false;
$.context.PreviousApproverDetails = [];
$.context.NewApproverDetails = [];
$.context.ExistingApproverDetails =[];
