if ($.context.isResourceProfile === true) {
    var ResProfileSel_DelUrl = $.context.ResProfileSel_DelUrl;
    var ResProfileSel_length = ResProfileSel_DelUrl.length;
    for (var p = 0; p < ResProfileSel_DelUrl.length; p++) {
        $.context.DBCall.Request.requests.push({
            id: (p + 6 + $.context.WfInsProc_length + $.context.approverDetails.length).toString(),
            dependsOn: ["1"],
            method: "DELETE",
            headers: { "content-type": "application/json;IEEE754Compatible=true" },
            url: ResProfileSel_DelUrl[p]
        });    }
    ResProfileSel_DelUrl = [];
    $.context.ResProfileSel_DelUrl = [];
    var Role = $.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedRole;
    for (var i = 0; i < Role.length; i++) {
        $.context.DBCall.Request.requests.push({
            id: ( 7  + i + $.context.WfInsProc_length + $.context.approverDetails.length + ResProfileSel_length).toString(),
            dependsOn: [$.context.DBCall.Request.requests[$.context.DBCall.Request.requests.length-1].id],
            method: "POST",
            headers: { "content-type": "application/json;IEEE754Compatible=true" },
            url: "/ResProfileSel_Header",
            body: {
                InstanceID: $.info.workflowInstanceId,
                role_ID: $.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedRole[i].RoleID,
                roleArea_ID: $.context.aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RoleAreaID,
                role_Desc: $.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedRole[i].RoleDesc,
                roleArea_Desc: $.context.aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RoleAreaDesc,
                ProfitCenter_GUID: $.context.selectedProfitCenter[0].guid
            }
        });
        ResProfileSel_DelUrl = "/ResProfileSel_Header(InstanceID=" + $.info.workflowInstanceId + ",role_ID='" + $.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedRole[i].RoleID + "',roleArea_ID='" + $.context.aResourceProfileApprovers.ResourceProfileDetails.Role_GUID.RoleAreaID + "')";
        $.context.ResProfileSel_DelUrl.push(ResProfileSel_DelUrl);
    };        
    var BAIndustries = $.context.aResourceProfileApprovers.ResourceProfileDetails.BAIndustries;
    for (var m = 0; m < BAIndustries.length; m++) {
        $.context.DBCall.Request.requests.push({
            id: (m + 10 + $.context.WfInsProc_length + $.context.approverDetails.length + ResProfileSel_length + Role.length).toString(),
            dependsOn: [$.context.DBCall.Request.requests[$.context.DBCall.Request.requests.length-1].id],
            method: "POST",
            headers: { "content-type": "application/json;IEEE754Compatible=true" },
            url: "/ResProfileSel_BAIndustry",
            body: {
                InstanceID: $.info.workflowInstanceId,
                BA_Industry_ID: BAIndustries[m].BaIndId,
                BA_Industry_Desc: BAIndustries[m].Desc,
            }});
        ResProfileSel_DelUrl = "/ResProfileSel_BAIndustry(InstanceID=" + $.info.workflowInstanceId + ",BA_Industry_ID='" + BAIndustries[m].BaIndId + "')";
        $.context.ResProfileSel_DelUrl.push(ResProfileSel_DelUrl);
    };    
    $.context.DBCall.Request.requests.push({        
        id: (12  + BAIndustries.length + $.context.WfInsProc_length + $.context.approverDetails.length + ResProfileSel_length + Role.length).toString(),
        method: "PATCH",
        url: "/WFInsParent(instance_GUID='" + $.context.parentInstanceID + "')",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        body: {
            "orgID": $.context.OrgID
        }
    });

    if ($.context.comments && $.context.comments.trim() !== "") {
        var UserTaskRole = "";
        var newdate = new Date().toISOString();
        if ($.context.UserTaskLabelValue) {
        UserTaskRole = $.context.UserTaskLabelValue.Processor.userTask;
    }
        $.context.DBCall.Request.requests.push({       
        id: (13 +  BAIndustries.length + $.context.WfInsProc_length + $.context.approverDetails.length + ResProfileSel_length + Role.length).toString(),  
        method: "POST",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: "/Comments",
        body: {
            instanceID: $.info.workflowInstanceId,
            actionId: $.context.decision_ID,
            commentText: $.context.comments,
            userID: $.context.currentProcessor.id,
            userEmail: $.context.currentProcessor.email,
            userName: $.context.currentProcessor.fullName,
            userRole: UserTaskRole,
            createdAt: newdate,
            modifiedAt: newdate
        }});}}
$.context.lastDecisionTask = 10;
