var resources = [];
//var statusCode = $.context.areaPathCall.Response.responses[0].status;
$.context.retry = false;
//var availableResources = $.context.aResourceProfileApprovers.ResourceDetails;
//var approver = $.context.ApproverDetailsFromORE;
var approver = $.context.aResourceProfileApprovers.ApproverDetails;
if (approver.length != 0) {
    approver.forEach(function (val) {
        if(val.ID !== "" && resources.indexOf(val.ID) === -1){
        resources.push(val.ID);
        }
    });
}
// if (availableResources.length != 0) {
//     availableResources.forEach(function (val) {
//         if(val.ID !== "" && resources.indexOf(val.ID) === -1){
//         resources.push(val.ID);}
//     });
// }

// Start of changes for Email Delegates
var statusCode_Email_delegates = $.context.areaPathCall.Response.responses[1].status;
if (statusCode_Email_delegates >= 200 && statusCode_Email_delegates <= 300) {
    var emaildelegates = $.context.areaPathCall.Response.responses[1].body.value;
    if (emaildelegates.length > 0) {
        if (emaildelegates && emaildelegates[0].Email_Delegates) {
            emaildelegates[0].Email_Delegates.split(';').forEach(function (val) {
                if (val !== "" && resources.indexOf(val) === -1) {
                    resources.push(val.trim());
                }
            });
        }
    }
}
// end of changes by for Email Delegates

$.context.CPICalls.getResourcesFromCRM = {
    Request: {
        "requestIntent": "GET_RESOURCES",
        "resources": resources
    }
}

// Code for Email Text changes
var statusCode_Email = $.context.areaPathCall.Response.responses[0].status;
if (statusCode_Email >= 200 && statusCode_Email <= 300) {
    var EmailResponse = $.context.areaPathCall.Response.responses[0].body.value;
    for (var i = 0; i < EmailResponse.length; i++) {
        var UserEmail = "",
            UserId = "",
            UserName = "";
        if (EmailResponse[i].Parameter == "Signature") {
            $.context.Email_Signature = EmailResponse[i].Email_Text;
        }
        if (EmailResponse[i].Parameter == "Initial") {
            $.context.Email_Initial = EmailResponse[i].Email_Text;
        }
        if (EmailResponse[i].Parameter == "IgnoreText") {
            $.context.IgnoreMessage = EmailResponse[i].Email_Text;
        }
        if (EmailResponse[i].Parameter == "OppAccOwnerEmail") {
            var oppAccountEmail = EmailResponse[i].Email_Text;
            if (oppAccountEmail !== null && oppAccountEmail !== "") {
                var UserDetails = oppAccountEmail.split(",");
                if (UserDetails.length >= 0) {
                    UserEmail = UserDetails[0];
                    UserId = UserDetails[1];
                    UserName = UserDetails[2];
                }
            }

            $.context.NewReqOppAccOwnerDetails = {};
            $.context.NewReqOppAccOwnerDetails.email = UserEmail;
            $.context.NewReqOppAccOwnerDetails.id = UserId;
            $.context.NewReqOppAccOwnerDetails.name = UserName;
        }
    }
                                                                                                                                                                                                                                                                                                                                               }
// end of email text changes 

//code for Routing 
if (!$.context.Skip_Resource_Approver) {
    $.context.Skip_Resource_Approver = false;
}
if (!$.context.Skip_IO_Owner_WF) {
    $.context.Skip_IO_Owner_WF = false;
}
var statusCode_routing = $.context.areaPathCall.Response.responses[2].status;
if (statusCode_routing >= 200 && statusCode_routing <= 300) {
    var Routing = $.context.areaPathCall.Response.responses[2].body.value;
    for (var i = 0; i < Routing.length; i++) {
        if (Routing[i].routing == "SKIP_RESOURCE_APPROVER" && Routing[i].operationalStatus == "X") {
            $.context.Skip_Resource_Approver = true;
        }
        else if (Routing[i].routing == "SKIP_IO_OWNER_WF" && Routing[i].operationalStatus == "X") {
            $.context.Skip_IO_Owner_WF = true;
        }

    }
}
// end of Routing 
