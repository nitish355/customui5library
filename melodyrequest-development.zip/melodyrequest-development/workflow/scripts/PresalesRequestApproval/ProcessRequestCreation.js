if ($.context.isRework) {
    $.context.currentStepName = $.context.CurrentStepValue.REESUB.Value;
    $.context.currentStepID = $.context.CurrentStepValue.REESUB.ID;
    $.context.initialRequestStatus = "updated";
} else {
    $.context.initialRequestStatus = "created"; }
$.context.dealInfo = {};
$.context.dealInfoForDb = {};
var decision = {
    "UserId": $.context.requesterDetails.id,
    "UserName": $.context.requesterDetails.fullName,
    "Role": $.context.currentProcessorRole,
    "StepName": $.context.currentStepName,
    "StepID" :$.context.currentStepID,
    "Decision": $.context.decision,
    "Comments": $.context.comments,
    "Date": new Date()
};
$.context.approvalHistory.push(decision);
$.context.lastRequestorComments = $.context.comments;
$.context.requestorComments = $.context.comments;
$.context.comments = "";
$.context.lastActivityDate = new Date();
$.context.currentState = $.context.CurrentStateValue.WMNAPP.Value;
$.context.currentStepName = $.context.CurrentStepValue.MANAPP.Value;
$.context.currentStepID = $.context.CurrentStepValue.MANAPP.ID;
$.context.currentProcessorRole = "Approver"
var aApproversData = $.context.approverDetails,
    sApproverIntro = "Dear " + aApproversData[0].fullName + ",",
    sApproverEmails = aApproversData[0].email,
    sApproverIds = aApproversData[0].userId,
    sApproverNames = aApproversData[0].fullName,
    sApproverInfo = aApproversData[0].fullName + "(" + aApproversData[0].userId + "," + aApproversData[0].email + ")";
if (aApproversData.length > 1) {
    for (var i = 1; i < aApproversData.length; i++) {
        sApproverIntro += "\nDear " + aApproversData[i].fullName + ",";
        sApproverEmails += "," + aApproversData[i].email;
        sApproverIds += "," + aApproversData[i].userId;
        sApproverNames += "," + aApproversData[i].fullName;
        sApproverInfo += "," + aApproversData[i].fullName + "(" + aApproversData[i].userId + "," + aApproversData[i].email + ")";
    }
}
$.context.notifyApproversEmailIntro = sApproverIntro;
$.context.approversEmails = sApproverEmails;
$.context.approversIds = sApproverIds;
$.context.approverNames = sApproverNames;
$.context.ApproverInfo = sApproverInfo;
$.context.lastDecisionTask = 1;
var fullIds = [];
fullIds.push($.context.requesterDetails.id);
var fullCreationDearText = "Dear " + $.context.requesterDetails.fullName + ",\n";
$.context.ReqTypeOwner = "";
if ($.context.RequestType == "Account") {
    $.context.dealInfo.currency = null;
    $.context.dealInfo.cloudRevenueFormatted = null;
    $.context.dealInfo.onPremRevenueFormatted = null;
    $.context.dealInfoForDb.currency = null;
    $.context.dealInfoForDb.cloudRevenue = null;
    $.context.dealInfoForDb.onPremRevenue = null;
    $.context.dealInfoForDb.dealScore = null;
    $.context.isSLE = false;
    $.context.oppOwnerDetails.shortName = "";
    if ($.context.accOwnerDetails.fullName && fullIds.indexOf($.context.accOwnerDetails.id) === -1) {
        fullIds.push($.context.accOwnerDetails.fullName);
        fullCreationDearText += "Dear " + $.context.accOwnerDetails.fullName + ",\n";  }
    $.context.ReqTypeOwner =  $.context.accOwnerDetails.email;
} else {
    // calculate deal score
    var aAttributes = $.context.CPICalls.getDataFromCRM.Response.d.Attributes.results;
    var iScore = 0;
    if (aAttributes) {
        var aScoreJSON = {
            "0": 0,
            "1": 6.25,
            "2": 12.5 };
        aAttributes.forEach(function (val) {
            if (val.ATTR_VALUE === "0" || val.ATTR_VALUE === "1" || val.ATTR_VALUE === "2") {
                iScore += aScoreJSON[val.ATTR_VALUE];
            } else {
                iScore += aScoreJSON["0"];
            }
        });
    }
    $.context.dealScore = iScore;
    $.context.dealInfo.currency = $.context.CPICalls.getDataFromCRM.Response.d.CURRENCY;
    $.context.dealInfo.cloudRevenueFormatted = formatMoney(parseFloat($.context.CPICalls.getDataFromCRM.Response.d.CLOUD_REVENUE), '.', 3, 2);
    $.context.dealInfo.onPremRevenueFormatted = formatMoney(parseFloat($.context.CPICalls.getDataFromCRM.Response.d.LICENSE_REVENUE), '.', 3, 2);
    $.context.dealInfoForDb.currency = $.context.dealInfo.currency;
    $.context.dealInfoForDb.cloudRevenue = $.context.CPICalls.getDataFromCRM.Response.d.CLOUD_REVENUE;
    $.context.dealInfoForDb.onPremRevenue = $.context.CPICalls.getDataFromCRM.Response.d.LICENSE_REVENUE;
    $.context.dealInfoForDb.dealScore = $.context.dealScore ? $.context.dealScore.toString() : "0.0";
    // get account and opportunity owners details
    var aPartiesInvolved = $.context.CPICalls.getDataFromCRM.Response.d.PartiesInvolved.results;
    if ($.context.oppOwnerDetails.fullName && fullIds.indexOf($.context.oppOwnerDetails.id) === -1) {
        fullIds.push($.context.oppOwnerDetails.fullName);
        fullCreationDearText += "Dear " + $.context.oppOwnerDetails.fullName + ",\n"; }
    if ($.context.accOwnerDetails.fullName && fullIds.indexOf($.context.accOwnerDetails.id) === -1) {
        fullIds.push($.context.accOwnerDetails.fullName);
        fullCreationDearText += "Dear " + $.context.accOwnerDetails.fullName + ",\n"; }
    $.context.ReqTypeOwner = $.context.oppOwnerDetails.email;
    // check if request area path starts with 'Solution Large Enterprise'
    $.context.isSLE = $.context.requestAreaPath.split("-")[0] == 'Solution Large Enterprise' ? true : false;
    // write sales group to context
    $.context.salesGroup = $.context.CPICalls.getDataFromCRM.Response.d.SALES_GROUP_SHORT;
    $.context.salesGroupName = $.context.CPICalls.getDataFromCRM.Response.d.SALES_GROUP_TEXT;
    if ($.context.NewOppDetails) {
        $.context.Opp_Sales_Office = $.context.NewOppDetails.Opp_Sales_Office ? $.context.NewOppDetails.Opp_Sales_Office : "";
        $.context.Opp_Partner = $.context.NewOppDetails.Opp_Partner ? $.context.NewOppDetails.Opp_Partner : "";
        $.context.Opp_SalesOrg_Name = $.context.NewOppDetails.Opp_SalesOrg_Name ? $.context.NewOppDetails.Opp_SalesOrg_Name : "";
        $.context.Opp_SalesGroupName = $.context.NewOppDetails.Opp_SalesGroupName ? $.context.NewOppDetails.Opp_SalesGroupName : "";
    }
    //delete unused structures for CPI response
    if ($.context.CPICalls.getDataFromCRM.Response.d.DocFlow) {
        delete $.context.CPICalls.getDataFromCRM.Response.d.DocFlow; }
    if ($.context.CPICalls.getDataFromCRM.Response.d.RevenueSplitPlanI) {
        delete $.context.CPICalls.getDataFromCRM.Response.d.RevenueSplitPlanI; }
    if ($.context.CPICalls.getDataFromCRM.Response.d.RevenueSplitPlanH) {
        delete $.context.CPICalls.getDataFromCRM.Response.d.RevenueSplitPlanH; }
    if ($.context.CPICalls.getDataFromCRM.Response.d.CustomerIncentive) {
        delete $.context.CPICalls.getDataFromCRM.Response.d.CustomerIncentive; }
    if ($.context.CPICalls.getDataFromCRM.Response.d.CloseplanActivities) {
        delete $.context.CPICalls.getDataFromCRM.Response.d.CloseplanActivities; }
    if ($.context.CPICalls.getDataFromCRM.Response.d.SalesHandoverActivities) {
        delete $.context.CPICalls.getDataFromCRM.Response.d.SalesHandoverActivities; }
    if ($.context.CPICalls.getDataFromCRM.Response.d.SalesTeamWF) {
        delete $.context.CPICalls.getDataFromCRM.Response.d.SalesTeamWF; }
    if ($.context.CPICalls.getDataFromCRM.Response.d.Attachments) {
        delete $.context.CPICalls.getDataFromCRM.Response.d.Attachments; }
    if ($.context.CPICalls.getDataFromCRM.Response.d.Pricing) {
        delete $.context.CPICalls.getDataFromCRM.Response.d.Pricing; }
    if ($.context.CPICalls.getDataFromCRM.Response.d.__metadata) {
        delete $.context.CPICalls.getDataFromCRM.Response.d.__metadata; }
    if ($.context.CPICalls.getDataFromCRM.Response.d.CHANGE_FLAGS) {
        delete $.context.CPICalls.getDataFromCRM.Response.d.CHANGE_FLAGS; }
}
$.context.fullCreationDearText = fullCreationDearText;
function formatMoney(x, sep, grp, dec) {
    //add decimals
    var y = x.toFixed(dec);
    //strip decimals
    var x_integer = y.split('.')[0];
    var x_fraction = y.split('.')[1];
    var x_fractionString = "";
    if (dec > 0) {
        x_fractionString = ',' + x_fraction;
    }
    var sx = ('' + x_integer).split('.'),
        s = '',
        i, j;
    sep || (sep = ' '); // default seperator
    grp || grp === 0 || (grp = 3); // default grouping
    i = sx[0].length;
    while (i > grp) {
        j = i - grp;
        s = sep + sx[0].slice(j, i) + s;
        i = j;
    }
    s = sx[0].slice(0, i) + s;
    sx[0] = s;
    return sx.join('.') + x_fractionString
}
// code ofr dynamic email
$.context.CRev = $.context.dealInfo.cloudRevenueFormatted ;
$.context.OpRev = $.context.dealInfo.onPremRevenueFormatted ;