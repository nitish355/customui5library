//Prepare delete call for draft tables
if(!$.context.delDraft)
    {
        $.context.delDraft = false;
    }
$.context.DelDraft = {};
$.context.DelDraft.Request = {};
$.context.DelDraft.Request.requests = [];
if ($.context.ReqFormDelDraftUrl.length > 0) {
    for (var j = 0; j < $.context.ReqFormDelDraftUrl.length; j++) {
        $.context.DelDraft.Request.requests.push({
            id: (j + 1).toString(),
           // dependsOn: ["1"],
            method: "DELETE",
            headers: { "content-type": "application/json;IEEE754Compatible=true" },
            url: $.context.ReqFormDelDraftUrl[j],
        });
    }

    $.context.delDraft = true;
    $.context.ReqFormDelDraftUrl = [];
}
$.context.AssignmentApprove = [];

