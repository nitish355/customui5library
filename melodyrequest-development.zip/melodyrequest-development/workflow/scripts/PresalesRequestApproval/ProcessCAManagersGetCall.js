var oEmpData = $.context.CPICalls.getCAManagersDetails.Response.results;
var oCAManagersIds = $.context.CPICalls.getCAManagersDetails.Request.resources;

var aCAManagersData = []

oCAManagersIds.forEach(function (val) {
    if (val !== "" && oEmpData[val]) {
        var data = {
            fullName: oEmpData[val].NAME,
            email: oEmpData[val].EMAIL,
            partnerId: oEmpData[val].PARTNER,
            address: oEmpData[val].ADDRESS,
            userId: oEmpData[val].USERID,
            country: oEmpData[val].COUNTRY
        };
        aCAManagersData.push(data);
    }
});

// prepare context data to notify CA Managers by email

var sCAManagerIntro = "Dear " + aCAManagersData[0].fullName + ",",
    sCAManagerEmails = aCAManagersData[0].email,
    sCAManagerIds = aCAManagersData[0].userId;
if (aCAManagersData.length > 1) {
    for (var i = 1; i < aCAManagersData.length; i++) {
        sCAManagerIntro += "\nDear " + aCAManagersData[i].fullName + ",";
        sCAManagerEmails += "," + aCAManagersData[i].email;
    }
}

$.context.notifyCAManagersEmailIntro = sCAManagerIntro;
$.context.CAManagersEmails = sCAManagerEmails;
