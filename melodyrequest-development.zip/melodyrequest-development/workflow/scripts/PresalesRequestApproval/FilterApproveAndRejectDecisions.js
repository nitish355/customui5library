$.context.AssignmentApprove = [];
$.context.AssignmentReject = [];
$.context.AllApprovedResources = [];
if ($.context.Skip_Resource_Approver == true) {
	for (var j = 0; j < $.context.Assignment.length; j++) {
		$.context.Assignment[j].ResCurrentProcessor = {};
		$.context.Assignment[j].ResCurrentProcessor.userId = $.context.Assignment[j].NominatedResources[0].userId;
		$.context.Assignment[j].ResCurrentProcessor.fullname = $.context.Assignment[j].NominatedResources[0].fullName;
		$.context.Assignment[j].ResCurrentProcessor.email = $.context.Assignment[j].NominatedResources[0].email;
		$.context.Assignment[j].ResAssignedRoleData = {};
		$.context.Assignment[j].ResAssignedRoleData = $.context.Assignment[j].NominatedResources[0].assignedRoleData;
	}}else{$.context.WfInsProc_DelURLs = [];}
var aAssignmentApprove = [],aAssignmentReject = [];
var aAssignment = $.context.Assignment, Role = "", decision = {}, NomResRejectComment = "";
$.context.approvalHistory = $.context.approvalHistoryTemp;
$.context.ProcessorComment = [];
var reqResource = {}, assignedActivity = {}, ProcessorComment = {  reqResource: [], assignedActivity:[]};
$.context.resourcecomment = [];
var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
if($.context.AllAssignmentDetails && $.context.AllAssignmentDetails.length>0){
	var Assignmentdetails = $.context.AllAssignmentDetails;
}else{
	var Assignmentdetails = $.context.Assignment;
}
if (aAssignment.length > 0) {
	for (var i = 0; i < aAssignment.length; i++) {
		var now = new Date();
		if ($.context.isResourceProfile === true) {
			ProcessorComment = { reqResource: [], assignedActivity:[]};			
			var assignedNominatedResource = Assignmentdetails[i].NominatedResources;			
			var assignedActivityList = Assignmentdetails[i].activityLists; 
			assignedNominatedResource.forEach(function (val) {
				reqResource = {};
				reqResource.resourceID = val.userId;
				var name = val.fullName;
				name = name.replace(/^(\S).*\s(\S+)$/, function (_, first, last) { return first.toUpperCase() + '. ' + last.charAt(0).toUpperCase() + last.slice(1).toLowerCase(); });
				reqResource.resourceName = name;
				reqResource.fullName = val.fullName;
				ProcessorComment.reqResource.push(reqResource)});
			assignedActivityList.forEach(function (val) {
				assignedActivity = {};
				assignedActivity.ActivityDesc = val.ActivityDesc;
				assignedActivity.activityUrl = val.activityUrl;
				ProcessorComment.assignedActivity.push(assignedActivity)});
			ProcessorComment.comment = Assignmentdetails[i].comments;  
    	$.context.ProcessorComment.push(ProcessorComment);		}
		$.context.history  = {};  
		var day = ("0" + now.getUTCDate()).slice(-2), month = months[now.getUTCMonth()],year = now.getUTCFullYear();
		$.context.history.DateUTC = month + " " + day + ", " + year;
		var hours = now.getUTCHours(), minutes = ("0" + now.getUTCMinutes()).slice(-2),ampm = hours >= 12 ? 'PM' : 'AM';
		hours = hours % 12;
		hours = hours ? hours : 12; 
		$.context.history.TimeUTC = hours + ":" + minutes + " " + ampm + " UTC";
		$.context.Assignment[i].ResCurrentStepName = $.context.CurrentStepValue.RESAPP.Value;//"Presales Resource Approval";
		$.context.Assignment[i].ResCurrentProcessorRole = "Asignee";
		aAssignment[i].ResCurrentStepName = $.context.CurrentStepValue.RESAPP.Value;//"Presales Resource Approval";
		aAssignment[i].ResCurrentProcessorRole = "- Asignee";
		if (aAssignment[i].ResDecision == "Approve" || $.context.Skip_Resource_Approver == true) {
			aAssignmentApprove.push(aAssignment[i]);
			$.context.AssignmentApproveAll.push(aAssignment[i]);			
			Role = "Assignment ID " + aAssignment[i].AssignmentID + aAssignment[i].ResCurrentProcessorRole;
			decision = {
				"UserId" : aAssignment[i].ResCurrentProcessor.userId, 
				"UserName": aAssignment[i].ResCurrentProcessor.fullname,
				"Role": Role,
				"StepName": $.context.CurrentStepValue.RESAPP.Value,
				"StepID": $.context.CurrentStepValue.RESAPP.ID,
				"Decision": aAssignment[i].ResDecision ? aAssignment[i].ResDecision : "" , 
				"Comments": aAssignment[i].ResComments ? aAssignment[i].ResComments : "" , 
				"Date": new Date()
			};
			$.context.approvalHistory.push(decision);
			$.context.history.UserName = aAssignment[i].ResCurrentProcessor.fullname;
			$.context.history.LastStep = 'Review - Resource';
			$.context.history.StepName = 'Review - Resource - Acknowledged';
			$.context.history.Decision = 'Acknowledged the request for '+ $.context.RequestType +" "+ $.context.EmailRequestTypeID;
			$.context.history.Comments = decision.Comments;	
			$.context.history.class = "";
			$.context.history.HistoryData = "History-Data";
			$.context.EmailTemplateVars.approvalHistoryEmail.splice($.context.EmailTemplateVars.HistoryCount, 0 , $.context.history);
			$.context.EmailTemplateVars.HistoryCount++;			
		}
		if (aAssignment[i].ResDecision == "Reject") {
			aAssignmentReject.push(aAssignment[i]);
			if (!$.context.ResSendBackDecision) {
				$.context.ResSendBackDecision = "Send back to Processor";}			
			Role = "Assignment ID " + aAssignment[i].AssignmentID + aAssignment[i].ResCurrentProcessorRole;
			NomResRejectComment = "";
			for (var k = 0; k < aAssignment[i].NominatedResources.length; k++) {
				NomResRejectComment = aAssignment[i].NominatedResources[k].NomResRejectComment;
				decision = {
					"UserId": aAssignment[i].NominatedResources[k].userId, 
					"UserName": aAssignment[i].NominatedResources[k].fullName,
					"Role": Role,					
					"StepName": $.context.CurrentStepValue.RESAPP.Value,
					"StepID": $.context.CurrentStepValue.RESAPP.ID,
					"Decision": $.context.ResSendBackDecision, 
					"Comments": NomResRejectComment,
					"Date": new Date()};
				$.context.approvalHistory.push(decision);			
			$.context.history.UserName = aAssignment[i].ResCurrentProcessor.fullname;
			$.context.history.LastStep = 'Review - Resource';
			$.context.history.StepName = 'Review - Resource - Sent Back to Processor';
			$.context.history.Decision = 'Sent the request back to the processor';
			$.context.history.Comments = decision.Comments;
			$.context.history.class = "";
			$.context.history.HistoryData = "History-Data";
			$.context.EmailTemplateVars.approvalHistoryEmail.splice($.context.EmailTemplateVars.HistoryCount, 0 , $.context.history);
			$.context.EmailTemplateVars.HistoryCount++;	}}}}
$.context.EmailTemplateVars.LastActionDateTime = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].DateUTC + " at " + $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].TimeUTC;
$.context.EmailTemplateVars.LastAction = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].UserName +" – "+ $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].LastStep+" – "+$.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].Decision;
$.context.EmailTemplateVars.LastActionComment = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].Comments;		
if ($.context.isResourceProfile === true && $.context.ProcessorComment) {
	for (var l = 0; l < 10; l++) {
		if (l >= $.context.ProcessorComment.length) {
			$.context.resourcecomment.push({ reqResource: [], comment: "", assignedActivity: [], class: "hidden-row" ,ActivityHide: "hidden-row"});
		} else {
			var processorEntry = $.context.ProcessorComment[l];
			var reqResourceArray = [], reqActivityArray = [];
			for (var m = 0; m < processorEntry.assignedActivity.length; m++) {
				var Activity = {
					ActivityUrl: processorEntry.assignedActivity[m].activityUrl,
					ActivityDesc: processorEntry.assignedActivity[m].ActivityDesc,
					class: "styled-link"};
				if (m !== processorEntry.assignedActivity.length - 1 && m<4) {
					Activity.Separator = ",";}
				reqActivityArray.push(Activity);}
			var resource = {
				resourceID: processorEntry.reqResource[0].resourceID,
				resourceName: processorEntry.reqResource[0].resourceName,
				fullName: processorEntry.reqResource[0].fullName,
				class: "styled-link"};
			reqResourceArray.push(resource);
			while (reqActivityArray.length < 10) {
				reqActivityArray.push({ class: "hidden-row" });			}
			var ActivityHide = processorEntry.assignedActivity.length == 0 ? "hidden-row" : "";
			$.context.resourcecomment.push({
				reqResource: reqResourceArray,
				comment: processorEntry.comment,
				ActivityHide: ActivityHide,
				assignedActivity: reqActivityArray,
				class: "styled-link"});	}}}
$.context.AssignmentApprove = aAssignmentApprove; 
$.context.LenAssigntApprove = $.context.AssignmentApprove.length;
$.context.AssignmentReject = aAssignmentReject; 
$.context.LenAssigntReject = $.context.AssignmentReject.length;
if($.context.RequestType == "Opportunity"){
$.context.CPICalls.getDataFromCRM.Response.d.PartiesInvolved = {};}
if (!$.context.ResApprove) {
	$.context.ResApprove = false;}
if ($.context.Skip_Resource_Approver == true) {
	$.context.ResApprove = true;
	$.context.ResReject = false;}
$.context.reqIOApprover = "";
var AssignmentActivityList = $.context.AssignmentApprove;
var ActivityPayload = {};
ActivityPayload.ActivityListsData = [];
$.context.deleteActvityList = false;
for (var i = 0; i < AssignmentActivityList.length; i++) {
	if (AssignmentActivityList[i].activityLists && AssignmentActivityList[i].activityLists.length > 0) {
		var objectTypeActvtPayload = {};
		objectTypeActvtPayload.AssignmentID = AssignmentActivityList[i].activityLists[0].assignmentID;
		objectTypeActvtPayload.INSTANCE_GUID = $.info.workflowInstanceId;
		ActivityPayload.ActivityListsData.push(objectTypeActvtPayload)
        $.context.deleteActvityList = true;	}}
$.context.deleteApprovedReqActivityListData = ActivityPayload;