var UserNotifpayload = {};
$.context.User_NotifDBCallPayload = {};
var users = {};
var r = $.context.requesterDetails;
UserNotifpayload.notifVal_Id = "0002";
if($.context.decision  && $.context.decision  == "Submit Request")
{
UserNotifpayload.notif_Id = "12";
}

if($.context.decision  && $.context.decision  == "Send Back to Requestor")
{
UserNotifpayload.notif_Id = "10";
}

if ($.context.decision == "Terminate") {
  UserNotifpayload.notif_Id = "11";
  var processorUsers = getFormattedObject($.context.approverDetails);
  if (processorUsers.length > 0) {
    users.processor = processorUsers;
  }
}

if (r && r.id && r.email) {
  users.requester = [{
    userId: r.id.toUpperCase(),
    email: r.email
  }];
}

if ($.context.RequestType == "Opportunity") {
  if ($.context.oppOwnerDetails && $.context.oppOwnerDetails.id && $.context.oppOwnerDetails.email) {
    users.reqTypeOwner = [{
      userId: $.context.oppOwnerDetails.id.toUpperCase(),
      email: $.context.oppOwnerDetails.email
    }];
  }
} else {
  if ($.context.accOwnerDetails && $.context.accOwnerDetails.id && $.context.accOwnerDetails.email) {
    users.reqTypeOwner = [{
      userId: $.context.accOwnerDetails.id.toUpperCase(),
      email: $.context.accOwnerDetails.email
    }];
  }
}

if ( Object.keys(users).length > 0) {
  UserNotifpayload.users = users;
  $.context.User_NotifDBCallPayload = UserNotifpayload;
}

function getFormattedObject(ProcessorDetails) {

  var GetUserNotifData = [];


  var list = [];

  if (Array.isArray(ProcessorDetails) && ProcessorDetails.length > 0 && ProcessorDetails[0].NominatedResources) {
    ProcessorDetails.forEach(function (a) {
      if (a.NominatedResources && a.NominatedResources[0]) {
        list.push(a.NominatedResources[0]);
      }
    });
  }
  else if (Array.isArray(ProcessorDetails)) {
    list = ProcessorDetails;
  }
  else {
    list = [ProcessorDetails];
  }

  list.forEach(function (val) {
    var uid = val.userId || val.id;
    if (uid && val.email) {
    GetUserNotifData.push({
        userId: uid.toUpperCase(),
        email: val.email
      });
    }
  });

  return GetUserNotifData;

};