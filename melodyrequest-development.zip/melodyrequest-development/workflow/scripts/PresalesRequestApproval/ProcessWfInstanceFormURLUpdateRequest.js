if ($.context.NewReqOppAccOwnerDetails) {
    if ($.context.RequestType == "Opportunity") { $.context.oppOwnerDetails.email = $.context.NewReqOppAccOwnerDetails.email;
        $.context.oppOwnerDetails.id = $.context.NewReqOppAccOwnerDetails.id;
        $.context.oppOwnerDetails.fullName = $.context.NewReqOppAccOwnerDetails.name;
        $.context.accOwnerDetails.email = $.context.NewReqOppAccOwnerDetails.email;
        $.context.accOwnerDetails.id = $.context.NewReqOppAccOwnerDetails.id;
        $.context.accOwnerDetails.fullName = $.context.NewReqOppAccOwnerDetails.name;
        $.context.ReqTypeOwner = $.context.oppOwnerDetails.email;
    } else { $.context.accOwnerDetails.email = $.context.NewReqOppAccOwnerDetails.email;
        $.context.accOwnerDetails.id = $.context.NewReqOppAccOwnerDetails.id;
        $.context.accOwnerDetails.fullName = $.context.NewReqOppAccOwnerDetails.name;
        $.context.ReqTypeOwner = $.context.accOwnerDetails.email; }}
//prepare for WfInstance Extention
$.context.EmailTemplateVars.FBSStyle = "";
if ($.context.EngagementType && $.context.EngagementType === '0002') {
    var wfIns_ext_data = {};
    wfIns_ext_data.instance_Guid = $.info.workflowInstanceId;
    wfIns_ext_data.Opp_Number = $.context.requestDetails.Opp_Number;
    wfIns_ext_data.io_Number = $.context.requestDetails.io_Number;
    wfIns_ext_data.contact_Prsn_Id = $.context.requestDetails.contact_Prsn_Id;
    wfIns_ext_data.contact_Prsn_Email = $.context.requestDetails.contact_Prsn_Email;
    wfIns_ext_data.need_From_Fbs = $.context.requestDetails.need_From_Fbs;
    if ($.context.requestDetails.c2c_Deal === true) {
        wfIns_ext_data.c2c_Deal = "X";
    } else {
        wfIns_ext_data.c2c_Deal = "";
    }
    wfIns_ext_data.oppclosing_Date = $.context.requestDetails.oppclosing_Date;
    wfIns_ext_data.contract_Start_Date = $.context.requestDetails.contract_Start_Date;
    wfIns_ext_data.contract_End_Date = $.context.requestDetails.contract_End_Date;
    wfIns_ext_data.supp_Type_FBS_Id = $.context.requestDetails.supp_Type_FBS;
    wfIns_ext_data.supp_Type_Pqa_Id = $.context.requestDetails.supp_Type_Pqa_Id;
    wfIns_ext_data.solution_Id = $.context.requestDetails.solution_Id;
    wfIns_ext_data.est_Acv = $.context.requestDetails.est_Acv;
    wfIns_ext_data.model_Id = $.context.requestDetails.model_Id;
    wfIns_ext_data.isp_Id = $.context.requestDetails.isp_Id;
    wfIns_ext_data.opp_Origin_Id = $.context.requestDetails.opp_Origin_Id;
    $.context.EmailTemplateVars.FBSStyle = "hidden-row";
    $.context.EmailTemplateVars.Requestor_need = $.context.requestDetails.need_From_Fbs ? $.context.requestDetails.need_From_Fbs : "Not specified by requestor";
    $.context.EmailTemplateVars.supportType = $.context.requestDetails.supportTypeText ? $.context.requestDetails.supportTypeText : "Not specified by Requestor";
}
else{    
    $.context.EmailTemplateVars.Requestor_need = $.context.requestDetails.typeOfSupport ? $.context.requestDetails.typeOfSupport : "Not specified by requestor";
    $.context.EmailTemplateVars.supportType = $.context.requestDetails.supportType ? $.context.requestDetails.supportType : "Not specified by Requestor";
}
var attachmentUrls = [];
if ($.context.requestDetails.attachmentUrls) {
    attachmentUrls = $.context.requestDetails.attachmentUrls;
}

var count = $.context.ReqFormcount;

for (var k = 0; k < attachmentUrls.length; k++)
    {
        $.context.DBCall.Request.requests.push({
            id: ( k + count + 10 + $.context.approverDetails.length).toString(),
            dependsOn: [$.context.DBCall.Request.requests[$.context.DBCall.Request.requests.length-1].id],
            method: "POST",
            headers: { "content-type": "application/json;IEEE754Compatible=true" },
            url: "/ReqForm_URL",
            body: {
                instance_GUID: $.info.workflowInstanceId,
                urlCountID: k + 1,
                urlName: attachmentUrls[k].urlName,
                url: attachmentUrls[k].url
            }
        });
       var attachURL = "/ReqForm_URL(instance_GUID='" + $.info.workflowInstanceId + "',urlCountID=" + parseInt(k + 1) + ")";
        $.context.ReqFormDelUrl.push(attachURL);
        count += 1;
    }
if ($.context.EngagementType && $.context.EngagementType === '0002') {
    var wfExtRequest = {
        id: (attachmentUrls.length + count + 11 + $.context.approverDetails.length).toString(),
        method: "PATCH",
        url: "/WfInstanceExt(instance_Guid='" + $.info.workflowInstanceId+ "')",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        body: wfIns_ext_data
    };
    $.context.DBCall.Request.requests.push(wfExtRequest);
}
//code for email template
var entries = $.context.approverDetails; 
var shortName = $.context.requesterDetails.fullName;
        shortName = shortName.replace(/^(\S).*\s(\S+)$/, function(_, first, last) {
                        return first.toUpperCase() + '. ' + last.charAt(0).toUpperCase() + last.slice(1).toLowerCase();    
        });
        $.context.requesterDetails.shortName = shortName
var approverurl = [];
for (var count = 0; count < 20; count++) {
	if(count >= entries.length){
		approverurl.push({ class : "hidden-row" });
	} else {
		entries[count].class = "styled-link";
        if (count != entries.length-1){
            entries[count].Separator = "," 
        }
           
		approverurl.push(entries[count]);
	}
}
$.context.accOwnerDetails.shortName = "";
$.context.oppOwnerDetails.shortName = "";
$.context.approverurl = approverurl;
if ($.context.accOwnerDetails.fullName) {
    $.context.accOwnerDetails.shortName = $.context.accOwnerDetails.fullName.replace(/^(\S).*\s(\S+)$/, function (_, first, last) {
        return first.toUpperCase() + '. ' + last.charAt(0).toUpperCase() + last.slice(1).toLowerCase();
    });
}
if ($.context.oppOwnerDetails.fullName) {
    $.context.oppOwnerDetails.shortName = $.context.oppOwnerDetails.fullName.replace(/^(\S).*\s(\S+)$/, function (_, first, last) { return first.toUpperCase() + '. ' + last.charAt(0).toUpperCase() + last.slice(1).toLowerCase(); });
}
$.context.reqResource = "";