//code for Routing 
$.context.Skip_Resource_Approver = false;
$.context.Skip_IO_Owner_WF = false;
var statusCode_routing = $.context.areaPathCall.Response.responses[2].status;
if (statusCode_routing >= 200 && statusCode_routing <= 300) {
    var Routing = $.context.areaPathCall.Response.responses[2].body.value;
    for (var i = 0; i < Routing.length; i++) {
        if (Routing[i].routing == "SKIP_RESOURCE_APPROVER" && Routing[i].operationalStatus == "X") {
            $.context.Skip_Resource_Approver = true;
        }
        else if (Routing[i].routing == "SKIP_IO_OWNER_WF" && Routing[i].operationalStatus == "X") {
            $.context.Skip_IO_Owner_WF = true;
        }

    }
}
// end of Routing 
var EmailReminderResponse = $.context.areaPathCall.Response.responses[3].body.value;
if (EmailReminderResponse.length > 0 ){
$.context.EmailReminderValue = EmailReminderResponse[0].RemindAfter;
}
else {
    $.context.EmailReminderValue = 0;
}
if (!$.context.DBCall) {
    $.context.DBCall = {};
}
$.context.DBCall.isWfInstanceUpdate = $.context.wasReworked ? true : false;
$.context.DBCall.Request = {};

$.context.DBCall.Request.requests = [];
var instanceId = $.info.workflowInstanceId,
    SolAreas = {},
    solutions = $.context.aResourceProfileApprovers.ResourceProfileDetails.AdditionalSolutions ? $.context.aResourceProfileApprovers.ResourceProfileDetails.AdditionalSolutions : [],
    materials = $.context.aResourceProfileApprovers.ResourceProfileDetails.Materials ? $.context.aResourceProfileApprovers.ResourceProfileDetails.Materials : [];

var mainSolnPayload = {};
if ($.context.aResourceProfileApprovers.ResourceProfileDetails.SolutionAreas && $.context.aResourceProfileApprovers.ResourceProfileDetails.SolutionAreas.length > 0) {
    SolAreas = $.context.aResourceProfileApprovers.ResourceProfileDetails.SolutionAreas[0];
    mainSolnPayload.InstanceID = instanceId;
    mainSolnPayload.solution_guid = SolAreas.soln_guid;
    mainSolnPayload.is_MainSoln = 'X';
}
if (Object.keys(mainSolnPayload).length !== 0) {

    var solnMatrlpayload = {};
    solnMatrlpayload.InstanceID = instanceId;
    solnMatrlpayload.additionalSolns = [];
    solnMatrlpayload.solMtrlList = [];
    if (solutions.length > 0 || materials.length > 0) {
        solnMatrlpayload = saveSolutionMatrlDataPayload(instanceId, solutions, materials);
    }
    solnMatrlpayload.additionalSolns.push(mainSolnPayload);
    $.context.DBCall.Request.requests.push({
        id: "500",
        method: "POST",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: "/saveSolutionMatrlData",
        body: solnMatrlpayload
    });
}  

function saveSolutionMatrlDataPayload(instanceId, solutions, materials) {
    return {
        InstanceID: instanceId,
        additionalSolns: solutions.map(function(sol) {
            return {
                InstanceID: instanceId,
                solution_guid: sol.soln_guid,
                is_MainSoln: ''   
            };
        }),
        solMtrlList: materials.map(function(mat) {
            return {
                InstanceID: instanceId,
                MAT_ID: String(mat.MatId),
                SOL_YEAR: String(mat.SolYear)
            };
        })
    };
}
if ($.context.aResourceProfileApprovers.ResourceProfileDetails.SolutionAreas && $.context.aResourceProfileApprovers.ResourceProfileDetails.SolutionAreas.length > 0) {
    var SelectedSol = {}
    SelectedSol = $.context.aResourceProfileApprovers.ResourceProfileDetails.SolutionAreas[0];
}
if ($.context.aResourceProfileApprovers.ResourceProfileDetails.BAIndustries && $.context.aResourceProfileApprovers.ResourceProfileDetails.BAIndustries.length > 0) {
    var SelectedIndustry = {}
    SelectedIndustry = $.context.aResourceProfileApprovers.ResourceProfileDetails.BAIndustries[0];
}
if ($.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedGroup && $.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedGroup.length > 0) {
        var SelectedGroup = {}
        SelectedGroup = $.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedGroup[0];
    }
$.context.EmailTemplateVars.Solution_Area = SelectedSol ? SelectedSol.SelectedSolutionArea : "Not selected";
$.context.EmailTemplateVars.BA_Industry = SelectedIndustry ? SelectedIndustry.Desc : "Not selected";
$.context.EmailTemplateVars.Group = SelectedGroup ? SelectedGroup.SelectedGroup : "Not selected";
var now = new Date();
$.context.history  = {};   
$.context.history.UserName = $.context.currentProcessor.fullName;
$.context.history.LastStep = 'Review - Processor';
$.context.history.StepName = 'Review - Processor - Forwarded';
$.context.history.Decision = $.context.ForwardDecision;
var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
var day = ("0" + now.getUTCDate()).slice(-2), month = months[now.getUTCMonth()],year = now.getUTCFullYear();
$.context.history.DateUTC = month + " " + day + ", " + year;
var hours = now.getUTCHours(), minutes = ("0" + now.getUTCMinutes()).slice(-2),ampm = hours >= 12 ? 'PM' : 'AM';
hours = hours % 12;
hours = hours ? hours : 12; 
$.context.history.TimeUTC = hours + ":" + minutes + " " + ampm + " UTC";
$.context.history.Comments = $.context.comments? $.context.comments: "";
$.context.history.class = "";
$.context.history.HistoryData = "History-Data";
$.context.EmailTemplateVars.approvalHistoryEmail.splice($.context.EmailTemplateVars.HistoryCount, 0 , $.context.history);
while($.context.EmailTemplateVars.approvalHistoryEmail.length<20){
  $.context.EmailTemplateVars.approvalHistoryEmail.push({class :"hidden-row", HistoryData:"hide-row"});
}
$.context.EmailTemplateVars.HistoryCount++;
$.context.EmailTemplateVars.LastActionDateTime = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].DateUTC + " at " + $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].TimeUTC;
$.context.EmailTemplateVars.LastAction = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].UserName +" – "+ $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].LastStep+" – "+$.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].Decision;
$.context.EmailTemplateVars.LastActionComment = $.context.EmailTemplateVars.approvalHistoryEmail[$.context.EmailTemplateVars.HistoryCount-1].Comments;