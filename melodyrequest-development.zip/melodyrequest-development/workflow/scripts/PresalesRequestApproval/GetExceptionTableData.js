var orgid = $.context.OrgID;
orgid = orgid.slice( 5, 9 );
var allApproveResource = $.context.AssignmentApprove;
$.context.DBExceptionTableCall = {};
$.context.DBExceptionTableCall.Request = {};
$.context.DBExceptionTableCall.Request.requests = [];

for(var i = 0; i <allApproveResource.length; i++){
$.context.DBExceptionTableCall.Request.requests.push({

	id: (i + 1).toString(),
    method: "GET",
    url: "/IOStaffException?$filter=bukrs eq '" +  allApproveResource[i].NominatedResources[0].companyCode  + "' and  usrId eq '" + allApproveResource[i].NominatedResources[0].userId + "'",      
    headers:   {"content-type": "application/json;IEEE754Compatible=true"}
});
}