var now = new Date();
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');

if (!$.context.DBCall) {
    $.context.DBCall = {};
}
$.context.DBCall.isWfInstanceUpdate = $.context.wasReworked ? true : false;

$.context.DBCall.Request = {};

// Prepare data for WFINSTANCE Table
var wfIns_data = {};
wfIns_data.instance_GUID = $.info.workflowInstanceId;
wfIns_data.parentInstance_GUID = $.context.parentInstanceID;
wfIns_data.technicalStateID = $.context.TechnicalStateValue.INPR.ID;
wfIns_data.currentStateID = $.context.CurrentStateValue.WSUBMN.ID;
wfIns_data.currentStepID = $.context.CurrentStepValue.MANAPP.ID;
wfIns_data.currentProcessorID = $.context.subtitutorsIds;
wfIns_data.currentProcessor = $.context.subtitutorsNames;
wfIns_data.currentProcessorEmail = $.context.subtitutorsEmails;
wfIns_data.dtLastActivity_tdate = date;
wfIns_data.dtLastActivity_ttime = time;


$.context.DBCall.Request.requests = [];

var wfRequest = {
    id: "1",
    method: "PATCH",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WfInstance(instance_GUID='" + $.info.workflowInstanceId + "',parentInstance_GUID='" + $.context.parentInstanceID + "')",
    body: wfIns_data
};

$.context.DBCall.Request.requests.push(wfRequest);

//Logic to DELETE Current Processors from table WfInsProcessor
var len_wfInsProc_DelURL = $.context.WfInsProc_DelURLs.length;
for (var i = 0; i < len_wfInsProc_DelURL; i++) {
    $.context.DBCall.Request.requests.push({
        id: (i + 2).toString(),
        dependsOn: ["1"],
        method: "DELETE",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: $.context.WfInsProc_DelURLs[i]
    });
}
$.context.WfInsProc_DelURLs = [];
for (var j = 0; j < $.context.substituteApproverDetails.length; j++) {
    $.context.DBCall.Request.requests.push({
        id: (j + 3 + len_wfInsProc_DelURL).toString(),
        //dependsOn: ["1"],
        dependsOn: [$.context.DBCall.Request.requests[$.context.DBCall.Request.requests.length-1].id],
        method: "POST",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: "/WfInsProcessor",
        body: {
            InstanceID: $.info.workflowInstanceId,
            assignmentID: "1",
            currentProcessorID: $.context.substituteApproverDetails[j].userId,
            currentProcessorName: $.context.substituteApproverDetails[j].fullName,
            currentProcessorEmail: $.context.substituteApproverDetails[j].email,
        }
    });
    var wfInsProc_DelURL = "/WfInsProcessor(InstanceID=" + $.info.workflowInstanceId + ",assignmentID='1',currentProcessorID='" + $.context.substituteApproverDetails[j].userId + "')";
    $.context.WfInsProc_DelURLs.push(wfInsProc_DelURL);
}