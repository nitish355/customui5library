var CurrentStateResponse = $.context.CurrentStateDBCall.Response.responses[0].body.value;
var CurrentStateValue = {};

CurrentStateResponse.forEach(function (val) {
    // Check if the ID already exists in CurrentStateValue, if not add it
    if (!(val.ID in CurrentStateValue)) {
        CurrentStateValue[val.ID] = {
            "ID": val.ID,
            "Value": val.Value
        };
    }
});
$.context.CurrentStateValue = CurrentStateValue;

var TechnicalStateResponse = $.context.CurrentStateDBCall.Response.responses[1].body.value;
var TechnicalStateValue = {};
TechnicalStateResponse.forEach(function (val) {
    // Check if the ID already exists in TechnicalStateValue, if not add it
    if (!(val.ID in TechnicalStateValue)) {
        TechnicalStateValue[val.ID] = {
            "ID": val.ID,
            "Value": val.technicalState
        };
    }
});
$.context.TechnicalStateValue = TechnicalStateValue;

var RequestTypeResponse = $.context.CurrentStateDBCall.Response.responses[3].body.value;
var RequestTypeValue = {
    "ID": RequestTypeResponse[0].ID,
    "Value": RequestTypeResponse[0].requestType
};
$.context.RequestTypeValue = RequestTypeValue;


var DefinitionIdResponseValue = $.context.CurrentStateDBCall.Response.responses[2].body.value;
$.context.DefinitionIdValue = DefinitionIdResponseValue;

var CuurentStepResponse = $.context.CurrentStateDBCall.Response.responses[4].body.value;
var CurrentStepValue = {};
CuurentStepResponse.forEach(function (val) {
    // Check if the ID already exists in CurrentStepValue, if not add it
    if (!(val.ID in CurrentStepValue)) {
        CurrentStepValue[val.ID] = {
            "ID": val.ID,
            "Value": val.currentStep
        };
    }
});
$.context.CurrentStepValue = CurrentStepValue;

var UserTaskLabelResponse = $.context.CurrentStateDBCall.Response.responses[6].body.value;
var UserTaskLabelValue = {};
UserTaskLabelResponse.forEach(function (val) {
    // Check if the userTask already exists in UserTaskLabelValue, if not add it
    if (!(val.userTask in UserTaskLabelValue)) {
        UserTaskLabelValue[val.userTask] = {
			"userTaskID" : val.userTaskID,
            "userTask": val.userTask,
            "userTaskName": val.userTaskName
        };
    }
});

$.context.UserTaskLabelValue = UserTaskLabelValue;
var EngagementTypeResponse = $.context.CurrentStateDBCall.Response.responses[7].body.value;
var EngagementTypeValue = {
            "ID": EngagementTypeResponse[0].eng_type_ID,
            "Value": EngagementTypeResponse[0].eng_type_Desc
        };
$.context.EngagementTypeValue = EngagementTypeValue;
$.context.EmailTemplateVars.FBSStyle = "";
if ($.context.EngagementType && $.context.EngagementType === "0002") {
    $.context.EmailTemplateVars.FBSStyle = "hidden-row";
    $.context.EmailTemplateVars.Requestor_need = $.context.requestDetails.need_From_Fbs ? $.context.requestDetails.need_From_Fbs : "Not specified by Requestor";
    $.context.EmailTemplateVars.supportType = $.context.requestDetails.supportTypeText ? $.context.requestDetails.supportTypeText : "Not specified by Requestor";
} else {    
    $.context.EmailTemplateVars.Requestor_need = $.context.requestDetails.typeOfSupport ? $.context.requestDetails.typeOfSupport : "Not specified by Requestor";
    $.context.EmailTemplateVars.supportType = $.context.requestDetails.supportType ? $.context.requestDetails.supportType : "Not specified by Requestor";
}

if ($.context.aResourceProfileApprovers.ResourceProfileDetails.SolutionAreas && $.context.aResourceProfileApprovers.ResourceProfileDetails.SolutionAreas.length > 0) {
    var SelectedSol = {}    
    SelectedSol = $.context.aResourceProfileApprovers.ResourceProfileDetails.SolutionAreas[0];
}
if($.context.aResourceProfileApprovers.ResourceProfileDetails.BAIndustries && $.context.aResourceProfileApprovers.ResourceProfileDetails.BAIndustries.length >0){
    var SelectedIndustry = {}    
    SelectedIndustry = $.context.aResourceProfileApprovers.ResourceProfileDetails.BAIndustries[0];
}
if ($.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedGroup && $.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedGroup.length > 0) {
        var SelectedGroup = {}
        SelectedGroup = $.context.aResourceProfileApprovers.ResourceProfileDetails.SelectedGroup[0];
    }
$.context.EmailTemplateVars.Solution_Area = SelectedSol? SelectedSol.SelectedSolutionArea : "Not selected";
$.context.EmailTemplateVars.BA_Industry = SelectedIndustry? SelectedIndustry.Desc : "Not selected";
$.context.EmailTemplateVars.Group = SelectedGroup ? SelectedGroup.SelectedGroup : "Not selected";