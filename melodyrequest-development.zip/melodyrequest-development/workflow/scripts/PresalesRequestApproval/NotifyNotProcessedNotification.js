var approverNames = [];
var subApproverNames = [];

for (var i = 0; i < $.context.approverDetails.length; i++) {
    if ($.context.approverDetails[i].email) {
        approverNames.push($.context.approverDetails[i].fullName);
    }
}

for (var i = 0; i < $.context.substituteApproverDetails.length; i++) {
    if ($.context.substituteApproverDetails[i].email) {
        subApproverNames.push($.context.substituteApproverDetails[i].fullName);
    }
}

$.context.approverNames = approverNames.join(',');
$.context.subApproverNames = subApproverNames.join(',');
$.context.lastDecisionTask = 3;


//Temporary code  for managing Older requests available in My inbox.

if ($.context.RequestType == "Opportunity") {
	$.context.Opp_ID = "Opportunity ID:" ;
    $.context.CRev_L = "Cloud Revenue:" ;
    $.context.OpRev_L = "On Premise Revenue:" ;

	// code for dynamic email
	$.context.CRev = $.context.dealInfo.cloudRevenueFormatted;
	$.context.OpRev = $.context.dealInfo.onPremRevenueFormatted;

	$.context.isAccount = false;
}
if (!$.context.io_Owner_email) {
    $.context.io_Owner_email = $.context.extSystemsUrls.MRRInboxURL + "IOOwnerDetailPage/" + $.info.workflowInstanceId;
    $.context.requestor_email = $.context.extSystemsUrls.MRRInboxURL + "SubmitReq/" + $.info.workflowInstanceId;
    $.context.processor_email = $.context.extSystemsUrls.MRRInboxURL + "ManagerDetailPage/" + $.info.workflowInstanceId;
}


