
var aCAManagersIds = [];

$.context.CAManagersList.value.forEach(function (val) {
    if (val !== "" && aCAManagersIds.indexOf(val) === -1) {
        aCAManagersIds.push(val.EmpID.trim());
    }
});

$.context.CPICalls.getCAManagersDetails = {
    Request: {
        "requestIntent": "GET_RESOURCES",
        "resources": aCAManagersIds
    }
}