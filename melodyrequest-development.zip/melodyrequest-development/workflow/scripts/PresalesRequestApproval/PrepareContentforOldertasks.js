 
if ($.context.RequestType == "Opportunity") {
	$.context.Opp_ID = "Opportunity ID:" ;
    $.context.CRev_L = "Cloud Revenue:" ;
    $.context.OpRev_L = "On Premise Revenue:" ;
 
	// code for dynamic email
	$.context.CRev = $.context.dealInfo.cloudRevenueFormatted;
	$.context.OpRev = $.context.dealInfo.onPremRevenueFormatted;
 
	$.context.isAccount = false;
 
	$.context.Approval_subject = "/ Opp." + $.context.opportunityId;
}
if (!$.context.io_Owner_email) {
    $.context.io_Owner_email = $.context.extSystemsUrls.MRRInboxURL + "IOOwnerDetailPage/" + $.info.workflowInstanceId;
    $.context.requestor_email = $.context.extSystemsUrls.MRRInboxURL + "SubmitReq/" + $.info.workflowInstanceId;
    $.context.processor_email = $.context.extSystemsUrls.MRRInboxURL + "ManagerDetailPage/" + $.info.workflowInstanceId;
}
if(!$.context.io_OwnerEmails){
	$.context.io_OwnerEmails ="";
}
$.context.taskApprover =  [{}];
//code for email template
$.context.taskApprover[0].Name = $.context.currentProcessor.fullName.replace(/^(\S).*\s(\S+)$/, function (_, first, last) {
	return first.toUpperCase() + '. ' + last.charAt(0).toUpperCase() + last.slice(1).toLowerCase();
});
$.context.taskApprover[0].userId = $.context.currentProcessor.id;
$.context.taskApprover[0].fullName = $.context.currentProcessor.fullName;
var entries = $.context.taskApprover; 
var approverurl = [];
for (var count = 0; count < 16; count++) {
	if(count >= entries.length){
		approverurl.push({ class : "hidden-row" });
	} else {
		entries[count].class = "styled-link";
        if (count != entries.length-1){
            entries[count].Separator = "," 
        }
		approverurl.push(entries[count]);
	}
}
 
$.context.approverurl = approverurl;
$.context.AllAssignmentDetails = [];