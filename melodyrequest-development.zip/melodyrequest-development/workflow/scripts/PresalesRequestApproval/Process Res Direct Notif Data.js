var response = $.context.User_NotifResDirectManagerPayload.Response;
$.context.ResDirectManagerNotif = false;
$.context.ResDirectManagerEmail_Notif = "";
if (response.oldProssOrDirectMgr && response.oldProssOrDirectMgr.length > 0) {
  $.context.ResDirectManagerEmail_Notif = collectEmails("oldProssOrDirectMgr", false);
  $.context.ResDirectManagerNotif = true;
}

function collectEmails(role, single) {
  var users = response[role];
  if (!Array.isArray(users)) return single ? "" : [];

  var emails = users
    .filter(function (u) { return u.email; })
    .map(function (u) { return u.email; });

  return single ? (emails[0] || "") : emails.join(",");
}
