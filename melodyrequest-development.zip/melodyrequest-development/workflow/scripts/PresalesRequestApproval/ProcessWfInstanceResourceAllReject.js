$.context.currentState = $.context.CurrentStateValue.WMNAPP.Value;
$.context.currentStepName = $.context.CurrentStepValue.MANAPP.Value;//"Presales Manager Approval";
$.context.currentStepID = $.context.CurrentStepValue.MANAPP.ID;
$.context.currentProcessorRole = "Approver";
$.context.PreviousProcessEmail_Notif = "";
 
var now = new Date();
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');
 
if (!$.context.DBCall) {
    $.context.DBCall = {};
}
$.context.DBCall.isWfInstanceUpdate = $.context.wasReworked ? true : false;
$.context.DBCall.Request = {};
 
// Prepare data for WFINSTANCE New Table
var wfIns_data = {};
wfIns_data.instance_GUID             = $.info.workflowInstanceId;
wfIns_data.parentInstance_GUID      = $.context.parentInstanceID;
wfIns_data.currentTaskInstanceID     = null;
wfIns_data.technicalStateID = $.context.TechnicalStateValue.INPR.ID;
wfIns_data.currentStateID = $.context.CurrentStateValue.WMNAPP.ID;
wfIns_data.currentStepID = $.context.CurrentStepValue.MANAPP.ID;
wfIns_data.currentProcessorID = $.context.approversIds;
wfIns_data.currentProcessor = $.context.approverNames;
wfIns_data.currentProcessorEmail = $.context.approversEmails;
wfIns_data.reqResources = "";
wfIns_data.reqIOApprover = "";
if ($.context.reqResources != "") {
    wfIns_data.reqResources = $.context.reqResource.slice(0, -1);
}
if ($.context.reqIOApprover != "") {
    wfIns_data.reqIOApprover = $.context.reqIOApprover;
}
wfIns_data.dtLastActivity_tdate = date;
wfIns_data.dtLastActivity_ttime = time;
wfIns_data.decisionID                = $.context.decision_ID;
//wfIns_data.comments = $.context.comments;
wfIns_data.currentTaskURL = null;
if($.context.UserTaskLabelValue)
    {
        wfIns_data.userTaskID = $.context.UserTaskLabelValue.Processor.userTaskID;
    }

//Code logic to prepare data for table WfInstance_Assignment
// var AssignData = {};
// AssignData.InstanceID = $.info.workflowInstanceId;
// //AssignData.TechnicalState = "inProcess";
// AssignData.technicalStateID = $.context.TechnicalStateValue.INPR.ID;
// //AssignData.CurrentState = $.context.currentState;
// AssignData.currentStateID = $.context.CurrentStateValue.WMNAPP.ID;
// AssignData.CurrentStepName = $.context.currentStepName;
// AssignData.currentStepID = $.context.CurrentStepValue.MANAPP.ID;
// //AssignData.CurrentProcessor = $.context.currentProcessor.fullName;
// AssignData.DTLastActivity_tdate = date;
// AssignData.DTLastActivity_ttime = time;
// //AssignData.Decision = "Reject";
// AssignData.decisionID = $.context.decision_ID;
$.context.DBCall.Request.requests = [];
var wfRequest = {
    id: "1",
    method: "PATCH",
    url: "/WfInstance(instance_GUID='" + $.info.workflowInstanceId + "',parentInstance_GUID='" + $.context.parentInstanceID + "')",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    body: wfIns_data
};
$.context.DBCall.Request.requests.push(wfRequest);
 
var LenAssignReject = $.context.AssignmentReject.length;
for (var k = 0; k < LenAssignReject; k++) {
    var aAssignmentID = $.context.AssignmentReject[k].AssignmentID;
    // AssignData.CurrentProcessor = $.context.AssignmentReject[k].ResCurrentProcessor.fullname;
    // AssignData.reqResource_ID = $.context.AssignmentReject[k].ResCurrentProcessor.userId;
    // AssignData.reqResource_Name = $.context.AssignmentReject[k].ResCurrentProcessor.fullname,
    // AssignData.reqResource_EMail = $.context.AssignmentReject[k].ResCurrentProcessor.email;
    var WfAssignPatchURL = "/WfInstanceAssignment(InstanceID='" + $.info.workflowInstanceId + "',AssignmentID='" + aAssignmentID + "')";
    $.context.DBCall.Request.requests.push({
        id: (k + 2).toString(),
        dependsOn: ["1"],
        method: "DELETE",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: WfAssignPatchURL
        //body: AssignData
    });
}
 
//Logic to DELETE Current Processors from table WfInsProcessor
var len_wfInsProc_DelURL = $.context.WfInsProc_DelURLs.length;
for (var i = 0; i < len_wfInsProc_DelURL; i++) {
    $.context.DBCall.Request.requests.push({
        id: (i + 3 + LenAssignReject).toString(),
        dependsOn: ["1"],
        method: "DELETE",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: $.context.WfInsProc_DelURLs[i]
    });
}
$.context.WfInsProc_DelURLs = [];
for (var j = 0; j < $.context.approverDetails.length; j++) {
    $.context.DBCall.Request.requests.push({
        id: (j + 4 + LenAssignReject + len_wfInsProc_DelURL).toString(),
        //dependsOn: ["1"],
        dependsOn: [$.context.DBCall.Request.requests[$.context.DBCall.Request.requests.length-1].id],
        method: "POST",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: "/WfInsProcessor",
        body: {
            InstanceID: $.info.workflowInstanceId,
            assignmentID: "1",
            currentProcessorID: $.context.approverDetails[j].userId,
            currentProcessorName: $.context.approverDetails[j].fullName,
            currentProcessorEmail: $.context.approverDetails[j].email,
        }
    });
    var wfInsProc_DelURL = "/WfInsProcessor(InstanceID=" + $.info.workflowInstanceId + ",assignmentID='1',currentProcessorID='" + $.context.approverDetails[j].userId + "')";
    $.context.WfInsProc_DelURLs.push(wfInsProc_DelURL);
}