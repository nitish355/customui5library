var UserNotifpayload = {};
var users = {};
UserNotifpayload.notifVal_Id = "0002";
UserNotifpayload.notif_Id = "10";

var processorUsers = getFormattedObject($.context.primaryApproverDetails);
if (processorUsers.length > 0) {
  users.processor = processorUsers;
}

var substituteUsers = getFormattedObject($.context.substituteApproverDetails);
if (substituteUsers.length > 0) {
  users.substitute = substituteUsers;
}

UserNotifpayload.users = users;

$.context.User_NotifDBCallPayload = {};
$.context.User_NotifDBCallPayload = UserNotifpayload;

function getFormattedObject(ProcessorDetails) {

  var GetUserNotifData = [];


  var list = [];

  if (Array.isArray(ProcessorDetails) && ProcessorDetails.length > 0 && ProcessorDetails[0].NominatedResources) {
    ProcessorDetails.forEach(function (a) {
      if (a.NominatedResources && a.NominatedResources[0]) {
        list.push(a.NominatedResources[0]);
      }
    });
  }
  else if (Array.isArray(ProcessorDetails)) {
    list = ProcessorDetails;
  }
  else {
    list = [ProcessorDetails];
  }

  list.forEach(function (val) {
    var uid = val.userId || val.id;
    if (uid && val.email) {
    GetUserNotifData.push({
        userId: uid.toUpperCase(),
        email: val.email
      });
    }
  });

  return GetUserNotifData;

};