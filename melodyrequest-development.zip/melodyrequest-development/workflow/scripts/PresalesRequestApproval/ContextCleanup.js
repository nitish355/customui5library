//Clearing unnecessary context
if ($.context.isSubstitute === true){
    $.context.requestState = $.context.CurrentStateValue.RSBCOM.Value;
    $.context.requestStateID =  $.context.CurrentStateValue.RSBCOM.ID;
}
else
{
    $.context.requestState = $.context.CurrentStateValue.REQCOM.Value;
    $.context.requestStateID =  $.context.CurrentStateValue.REQCOM.ID;
}
//code for email template
if($.context.isResourceProfile === true)
    {
    
    if (!$.context.resourcecomment) {
        $.context.resourcecomment = [];	
    }   
    
    while ($.context.resourcecomment.length < 10) {
        var reqResource = [{ class: "hidden-row" }];  
        var  assignedActivity =[];
        for (var i = 0; i < 5; i++) {
            assignedActivity.push({ class: "hidden-row" });
        }
        $.context.resourcecomment.push({
            reqResource: reqResource,
            assignedActivity: assignedActivity,
            ActivityHide: "hidden-row",
            comment: "",
            class: "hidden-row"
        });
    }
    }