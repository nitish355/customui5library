var now = new Date();
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');
if (!$.context.DBCall) {
    $.context.DBCall = {};}
$.context.DBCall.isWfInstanceUpdate = $.context.wasReworked ? true : false;
$.context.DBCall.Request = {};
var approverId = $.context.approverData.id ;
var approvertaskid = $.context.approverData.itaskid ;
// Prepare data for WFINSTANCE New Table
var wfIns_data = {};
wfIns_data.instance_GUID = $.info.workflowInstanceId;
wfIns_data.parentInstance_GUID = $.context.parentInstanceID;
wfIns_data.currentTaskInstanceID = null;
wfIns_data.technicalStateID = $.context.TechnicalStateValue.INPR.ID;
wfIns_data.currentStateID = $.context.CurrentStateValue.WRESAP.ID;
wfIns_data.currentStepID = $.context.CurrentStepValue.RESAPP.ID;
wfIns_data.substituteProcessorID = "";
wfIns_data.substituteProcessor = "";
wfIns_data.substituteProcessorEmail = "";
wfIns_data.reqApprover_ID = approverId;
wfIns_data.reqApprover_Name = $.context.approverData.fullName;
wfIns_data.reqApprover_EMail = $.context.approverData.email;
wfIns_data.dtLastActivity_tdate = date;
wfIns_data.dtLastActivity_ttime = time;
wfIns_data.decisionID = $.context.decision_ID;
//wfIns_data.comments = $.context.comments;
wfIns_data.currentTaskURL = null;
if ($.context.Skip_Resource_Approver === false && $.context.UserTaskLabelValue )    {
     wfIns_data.userTaskID = $.context.UserTaskLabelValue.Resource.userTaskID;     }
// prepare data for wfhistory
var ReqHistory_data = {};
ReqHistory_data.InstanceID = $.info.workflowInstanceId;
ReqHistory_data.UserTaskID = approvertaskid;
ReqHistory_data.AssignmentID = "0";
ReqHistory_data.User_ID = approverId;
ReqHistory_data.User_Name = $.context.approverData.fullName;
ReqHistory_data.User_EMail = $.context.approverData.email;
if ($.context.isSubstitute === true){
    ReqHistory_data.StateID = $.context.CurrentStateValue.WSUBMN.ID; }
else{
    ReqHistory_data.StateID = $.context.CurrentStateValue.WMNAPP.ID; }
ReqHistory_data.StepID = $.context.CurrentStepValue.MANAPP.ID;
ReqHistory_data.ActionTaken = "Assigned the request for "  + $.context.RequestType + " " + $.context.EmailRequestTypeID + ". Assigned " +  $.context.resourceNames + ".";
ReqHistory_data.Role = "Approver";
ReqHistory_data.Decision = $.context.decision_ID;
if($.context.AllCommentsForResource){
ReqHistory_data.Comments = $.context.AllCommentsForResource;
}
ReqHistory_data.Date = date;
ReqHistory_data.Time = time;
if (!$.context.UT_refID) {
    $.context.UT_refID = 1;
} else {
    $.context.UT_refID += 1; }
ReqHistory_data.UT_refID = $.context.UT_refID;
$.context.DBCall.Request.requests = [];
var wfRequest = {
    id: "1",
    method: "PATCH",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WfInstance(instance_GUID='" + $.info.workflowInstanceId + "',parentInstance_GUID='" + $.context.parentInstanceID + "')",
    body: wfIns_data};
$.context.DBCall.Request.requests.push(wfRequest);
$.context.DBCall.Request.requests.push({   
    id: "2",
    method: "POST",
    headers: { "content-type": "application/json;IEEE754Compatible=true" },
    url: "/WFHistory",
    body: ReqHistory_data});
var LenAssignment = $.context.Assignment.length;
var reqResource = {};
var assignedActivity = {};
var ProcessorComment = {  reqResource: [], assignedActivity:[]};
for (var k = 0; k < LenAssignment; k++) {
    ProcessorComment = { reqResource: [], assignedActivity:[]};
    var WfAssignUrl = "";
    var aAssignmentID = $.context.Assignment[k].AssignmentID;
    var isIOStaffing = $.context.Assignment[k].isIOStaffing;    
    WfAssignUrl = "/WfInstanceAssignment(InstanceID='" + $.info.workflowInstanceId + "',AssignmentID='" + aAssignmentID + "')";
    var WfAssignBody = {};
    var staffingPurpose = "",staffingDateRange = "",taskLevel = "", maxNoOfDaysToBookIO = "";
    if (isIOStaffing === true) {
        staffingPurpose = $.context.Assignment[k].NominatedResources[0].staffingPurpose;
        staffingDateRange = $.context.Assignment[k].NominatedResources[0].staffingDateRange;
        maxNoOfDaysToBookIO = $.context.Assignment[k].NominatedResources[0].maxNoOfDaysToBookIO;
        taskLevel = $.context.Assignment[k].NominatedResources[0].taskLevelVal;    }
    WfAssignBody.InstanceID = $.info.workflowInstanceId;
    WfAssignBody.AssignmentID = $.context.Assignment[k].AssignmentID;   
    WfAssignBody.technicalStateID = $.context.TechnicalStateValue.INPR.ID;   
    WfAssignBody.currentStateID =  $.context.CurrentStateValue.WRESAP.ID;
    WfAssignBody.CurrentStepName = $.context.currentStepName;
    WfAssignBody.currentStepID = $.context.CurrentStepValue.RESAPP.ID;
    var assignedNominatedResource = $.context.Assignment[k].NominatedResources;
    var assignedActivityList = $.context.Assignment[k].activityLists; 
    var wWfAssignCurrentProcessor = "",  reqResource_ID = "",reqResource_Name = "", reqResource_EMail = "";
    assignedNominatedResource.forEach(function (val) {
        reqResource ={};
        reqResource.resourceID = val.userId;
        var name = val.fullName;
        name = name.replace(/^(\S).*\s(\S+)$/, function(_, first, last) {  return first.toUpperCase() + '. ' + last.charAt(0).toUpperCase() + last.slice(1).toLowerCase();    });
        reqResource.resourceName = name;
        reqResource.fullName = val.fullName;
        ProcessorComment.reqResource.push(reqResource)
        wWfAssignCurrentProcessor += val.fullName + ";";
        reqResource_ID += val.userId + ";";
        reqResource_Name += val.fullName + ";";
        reqResource_EMail += val.email + ";";
    });
     assignedActivityList.forEach(function (val) {
        assignedActivity = {};
         assignedActivity.ActivityDesc = val.ActivityDesc;
         assignedActivity.ActivityUrl = val.activityUrl;
         ProcessorComment.assignedActivity.push(assignedActivity) });
    wWfAssignCurrentProcessor = wWfAssignCurrentProcessor.slice(0, -1);
    reqResource_ID = reqResource_ID.slice(0, -1);
    reqResource_Name = reqResource_Name.slice(0, -1);
    reqResource_EMail = reqResource_EMail.slice(0, -1);    
    WfAssignBody.CurrentProcessor = wWfAssignCurrentProcessor;
    WfAssignBody.comments = $.context.Assignment[k].comments;    
    ProcessorComment.comment = $.context.Assignment[k].comments;  
    $.context.ProcessorComment.push(ProcessorComment);
    if (!$.context.ResReject) {
        WfAssignBody.DTCreation_tdate = date;
        WfAssignBody.DTCreation_ttime = time;    }
    WfAssignBody.DTLastActivity_tdate = date;
    WfAssignBody.DTLastActivity_ttime = time;
    WfAssignBody.decisionID = $.context.decision_ID;
    WfAssignBody.staffingPurpose = staffingPurpose;
    WfAssignBody.taskLevel = taskLevel;
    WfAssignBody.staffingDateRange = staffingDateRange.toString();
    WfAssignBody.maxNoOfDaysToBookIO = maxNoOfDaysToBookIO.toString();
    WfAssignBody.reqResource_ID = reqResource_ID;
    WfAssignBody.reqResource_Name = reqResource_Name;
    WfAssignBody.reqResource_EMail = reqResource_EMail;
    $.context.DBCall.Request.requests.push({
         id: (k + 3).toString(),
        dependsOn: ["1"],
        method: "PATCH", //$.context.ResReject ? "PATCH" : "POST", // "POST", 
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: WfAssignUrl, //"/WfInstanceAssignment",
        body: WfAssignBody
    }); }
var len_wfInsProc_DelURL = $.context.WfInsProc_DelURLs.length;
for (var i = 0; i < len_wfInsProc_DelURL; i++) {
    $.context.DBCall.Request.requests.push({
        id: (i + 4 + LenAssignment).toString(),
        dependsOn: ["1"],
        method: "DELETE",
        headers: { "content-type": "application/json;IEEE754Compatible=true" },
        url: $.context.WfInsProc_DelURLs[i]
    }); }

$.context.WfInsProc_DelURLsLength = $.context.WfInsProc_DelURLs;
$.context.WfInsProc_DelURLs = [];
//Logic to POST Current Processors (i.e. Resources) to table WfInsProcessor
var count = 0;
for (var a = 0; a < LenAssignment; a++) {
    var aNominatedRes = $.context.Assignment[a].NominatedResources;
    var AassignmentID = $.context.Assignment[a].AssignmentID;
    for (var b = 0; b < aNominatedRes.length; b++) {
        $.context.DBCall.Request.requests.push({
            id: (count + 5 + LenAssignment + len_wfInsProc_DelURL).toString(),          
            dependsOn: [$.context.DBCall.Request.requests[$.context.DBCall.Request.requests.length-1].id],
            method: "POST",
            headers: { "content-type": "application/json;IEEE754Compatible=true" },
            url: "/WfInsProcessor",
            body: {
                InstanceID: $.info.workflowInstanceId,
                assignmentID: AassignmentID,
                currentProcessorID: aNominatedRes[b].userId,
                currentProcessorName: aNominatedRes[b].fullName,
                currentProcessorEmail: aNominatedRes[b].email,
            } });
        var wfInsProc_DelURL = "/WfInsProcessor(InstanceID=" + $.info.workflowInstanceId + ",assignmentID='" + AassignmentID + "',currentProcessorID='" + aNominatedRes[b].userId + "')";
        $.context.WfInsProc_DelURLs.push(wfInsProc_DelURL);
        count += 1;    }}
var AllNominatedResources = [];
for (var p = 0; p < LenAssignment; p++) {
    var nom = $.context.Assignment[p].NominatedResources;
    for (var q = 0; q < nom.length; q++) {
        AllNominatedResources.push(nom[q]);    }}
var UniqueRes = [];
var objects = {};
AllNominatedResources.forEach(function (value) {
    if (!objects[value.userId]) {
        UniqueRes.push(value);
        objects[value.userId] = true;    }});
$.context.UniqueNominatedResources = UniqueRes;
var LenUniqueNomRes = $.context.UniqueNominatedResources.length;