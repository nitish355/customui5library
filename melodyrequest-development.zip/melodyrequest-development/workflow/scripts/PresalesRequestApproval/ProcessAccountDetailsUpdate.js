var now = new Date();
var data = {};
var date = now.toISOString().split('T')[0];
var time = now.toISOString().split('T')[1].replace('Z', '');
var OrgID_Num= $.context.OrgID.substring(5,9);
//Code to remove leading Zeroes
OrgID_Num = OrgID_Num.replace(/^0+/, ''); 

$.context.DBCall.AccountDataUpdateRequest = {};
$.context.DBCall.AccountDataUpdateRequest = {
    "wfInstance":$.info.workflowInstanceId,
    "accountID":$.context.accountId,
    "accountName":$.context.accountName,
    "orgID":OrgID_Num,
    "reqArea":$.context.requestAreaPath,
    "roleID":$.context.AccountassignedResourceDetails.roleID,
    "date":date,
    "time":time,
    "resource_ID":$.context.AccountassignedResourceDetails.UserID,
    "resource_Name":$.context.AccountassignedResourceDetails.fullName,
    "resource_EMail": $.context.AccountassignedResourceDetails.email
};