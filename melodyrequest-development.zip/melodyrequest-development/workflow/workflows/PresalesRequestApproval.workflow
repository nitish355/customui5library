{
	"contents": {
		"4e263c9f-34e0-428f-9ef2-9f5c116fb836": {
			"classDefinition": "com.sap.bpm.wfs.Model",
			"id": "PresalesRequestApproval",
			"subject": "Customer Advisory Request for Opportunity ${context.opportunityId}",
			"businessKey": "${context.opportunityId}",
			"customAttributes": [{
				"id": "CurrentState",
				"label": "Current State",
				"type": "string",
				"value": "${context.currentState}"
			}, {
				"id": "Currency",
				"label": "Currency",
				"type": "string",
				"value": "${context.dealInfo.currency}"
			}, {
				"id": "OnPremRevenue",
				"label": "On Premise Revenue",
				"type": "string",
				"value": "${context.dealInfo.onPremRevenue}"
			}, {
				"id": "CloudRevenue",
				"label": "Cloud Revenue",
				"type": "string",
				"value": "${context.dealInfo.cloudRevenue}"
			}, {
				"id": "RequestAreaPath",
				"label": "Request Area Path",
				"type": "string",
				"value": "${context.requestAreaPath}"
			}, {
				"id": "DealScore",
				"label": "Deal Score",
				"type": "string",
				"value": "${context.dealScore}"
			}, {
				"id": "RequestID",
				"label": "Request ID",
				"type": "string",
				"value": "${context.requestId}"
			}, {
				"id": "RequesterName",
				"label": "Requester Name",
				"type": "string",
				"value": "${context.requesterDetails.fullName}"
			}, {
				"id": "RequestArea",
				"label": "Request Area",
				"type": "string",
				"value": "${context.requestArea}"
			}, {
				"id": "ApproverName",
				"label": "Approver Name",
				"type": "string",
				"value": "${context.approverData.fullName}"
			}, {
				"id": "AccountName",
				"label": "Account Name",
				"type": "string",
				"value": "${context.accountName}"
			}, {
				"id": "AccountId",
				"label": "Account ID",
				"type": "string",
				"value": "${context.accountId}"
			}],
			"name": "PresalesRequestApproval",
			"documentation": "",
			"lastIds": "62d7f4ed-4063-4c44-af8b-39050bd44926",
			"events": {
				"11a9b5ee-17c0-4159-9bbf-454dcfdcd5c3": {
					"name": "Start Approval Process"
				},
				"2798f4e7-bc42-4fad-a248-159095a2f40a": {
					"name": "End Approval Process"
				},
				"06fa1e99-4325-4dea-81d7-a92461eb15e3": {
					"name": "End Approval Process"
				},
				"5c249566-d8e1-4b0f-8766-c66a3b6471eb": {
					"name": "BoundaryTimerEvent1"
				},
				"15e032f9-93a1-47b5-88f6-2e955a9372b3": {
					"name": "EndEvent6"
				},
				"9b854ad4-6864-4d21-8538-b72fa1ddc83c": {
					"name": "BoundaryTimerEvent2"
				},
				"24a33845-446b-4d18-95b1-fd65eba5ee35": {
					"name": "BoundaryTimerEvent3"
				}
			},
			"activities": {
				"06891468-ae19-4a5e-96aa-e97bb68a42c1": {
					"name": "Requestor Form"
				},
				"b2212f4e-72da-486e-be4f-680e98345b6b": {
					"name": "Processor Form"
				},
				"d8ba0d32-0e90-49ca-927a-3931f0881f9e": {
					"name": "what is a decision?"
				},
				"fdf35015-9267-4b31-ba80-49759b8bb63b": {
					"name": "Notify Requester About Rework"
				},
				"99b92cdc-05ca-4bf6-9cba-bbe8e381696c": {
					"name": "Process Initialize Request"
				},
				"8dcd09bd-99d5-4347-9bfb-102a27f1a949": {
					"name": "Notify About Request Creation / Update"
				},
				"bb21eb22-a546-402c-b871-3b0fbd7b4d97": {
					"name": "Process Request Creation"
				},
				"4490dec5-f12b-4640-838f-09c439a9e1aa": {
					"name": "Notify Approver"
				},
				"81bd8d37-a4b5-43e8-9d31-1cf5b701aaff": {
					"name": "Get Opp Details From CRM"
				},
				"35021842-30c7-473a-bdbe-d322a823068f": {
					"name": "Process Approver's Send Back Decision"
				},
				"31bddefd-3970-487e-ae69-8c79c03d2b4e": {
					"name": "Process Approver's Reject Decision"
				},
				"3e842588-71b2-4462-83ca-f9ab3743e423": {
					"name": "Process Approver's Approve Decision"
				},
				"056b1a11-e7a7-4ac2-bfe7-16e06a4e3b17": {
					"name": "Do Clean-Up"
				},
				"2e2f15da-55b8-4578-81b9-740ff2b6a218": {
					"name": "Assign Substitute Approver"
				},
				"9d325103-1963-4f0e-a1d1-f409d3dc59d5": {
					"name": "Notify Substitute Approver"
				},
				"8337f8c5-dd5f-4fbd-8f7c-ea374f6b36b2": {
					"name": "Processor Form"
				},
				"233a6b4d-a2b6-458f-bae8-c7bc788013af": {
					"name": "decision"
				},
				"3cfbbea0-301e-47fe-b1cb-1162c50fb37a": {
					"name": "Process Task Termination"
				},
				"854f2bea-0180-42e1-9f60-4d102de7726d": {
					"name": "Process Approver Forward Decision"
				},
				"bdcfb412-7dd8-43c5-b6ec-2c9af8b32b5a": {
					"name": "Process Resources Request"
				},
				"e21e9ddd-8ffe-497a-ae19-c05a308de69b": {
					"name": "Get Additional Approvers Data"
				},
				"30c8a446-373c-4f80-94ad-066f5a25dbbc": {
					"name": "Process Resources Response"
				},
				"d9f5c825-a8f0-4fdb-8f9d-3685b671d121": {
					"name": "Process Resource Request"
				},
				"a2ba93b6-86bb-4bf0-a149-037fa740d0f7": {
					"name": "Process Resources Response"
				},
				"7567c7a1-d73a-4be2-9f55-def62b30ddca": {
					"name": "Get Additional Approvers Data"
				},
				"ff47561f-1004-41a7-ae18-5de2cf4400ef": {
					"name": "Manager Approval"
				},
				"00dd4b02-bd67-4515-ae82-999f1c8f3f4a": {
					"name": "Notify Request Not Been Processed"
				},
				"bd2a38e1-d493-4123-8ee1-876a83a6f5f8": {
					"name": "Processor Form"
				},
				"50acc690-0ad0-473a-a524-2e56b078405b": {
					"name": "Process Not Processed Notification"
				},
				"3d3cf404-1e67-41e1-9348-c87eeb0397bf": {
					"name": "Manager Approval Gate"
				},
				"b9f3fd94-bc43-40b0-b03f-6cfa4e1fb969": {
					"name": "Manger Task Processed"
				},
				"2ec0658e-6a17-4d0d-90ea-62c4336623b5": {
					"name": "Substitute Task Processed"
				},
				"08e8ea17-39f4-48cc-83cf-5fe60227f741": {
					"name": "is req area SLE?"
				},
				"aaa547a7-dc46-44ab-8255-960716a6bcae": {
					"name": "Get CA Industry Managers"
				},
				"0e163838-d068-4dee-a204-ed54fb74af92": {
					"name": "Process Response"
				},
				"9f42ea35-64e3-4e39-ad1c-963db78f4393": {
					"name": "list not empty?"
				},
				"d58f5ffb-c7f1-4d48-a312-241110ebf41e": {
					"name": "Prepare Payload"
				},
				"701fc339-9099-4f8b-8058-7100f5ae4c5d": {
					"name": "Get CA Managers Details"
				},
				"caf7be2b-e43a-4f14-a826-9cfb68ab4172": {
					"name": "Process Response"
				},
				"efba8741-f361-4ace-9a71-eb817f466415": {
					"name": "Notify CA Managers"
				},
				"d204364a-1439-481f-9b7c-9c638f58d815": {
					"name": "was reworked?"
				},
				"0479076d-17a8-470b-8382-d5459eb052a3": {
					"name": "Process Wf Instance Request"
				},
				"0c9df6a2-4743-4ca1-8068-f61ecf547f56": {
					"name": "Call CAP Batch"
				},
				"ef831483-933c-4efb-998b-082196738ef1": {
					"name": "Process Wf Instance Send Back"
				},
				"37ec0a64-b924-4866-a246-b6e91fc7fa06": {
					"name": "Process Wf Instance Substitute"
				},
				"4d353ff7-225a-4475-abbd-ca72eb0b8974": {
					"name": "WfInstance Update"
				},
				"6a35041a-d16e-4cbc-9e6a-6aa51d639be2": {
					"name": "Process Wf Instance Approver Approve"
				},
				"7048bfa2-ab10-4afa-af8a-d038f581ae65": {
					"name": "WfInstance Update"
				},
				"13adc3d3-6b22-4055-ae85-0401add7744c": {
					"name": "Process Wf Instance Complete"
				},
				"21b87d2f-678d-4b03-9d16-a2bef8a4cb18": {
					"name": "WfInstance Complete"
				},
				"8430762c-d6c3-4ade-bc13-3db24226917f": {
					"name": "Process Wf Instance Forward"
				},
				"a8cd3376-6607-467a-ad8a-e981bdb681d9": {
					"name": "WfInstance Update"
				},
				"eeff2bdf-7aaa-47a3-b8f0-134ab18e9e8e": {
					"name": "Process WfInstance Complete Success"
				},
				"1d99fb56-2463-47d5-b95c-b61fddfa93e4": {
					"name": "Process WfInstance Complete"
				},
				"2d5fb220-87ab-4e1d-8095-c41dc8a6306d": {
					"name": "Get Approvers"
				},
				"ad99fde2-287e-4495-9b62-ef4fc532adf0": {
					"name": "Get Approvers"
				},
				"abd1eb59-b34c-489e-81da-2426d5ccd452": {
					"name": "ExclusiveGateway14"
				},
				"c8116791-4591-4339-b807-e69c36f74171": {
					"name": "Calculate Due Date"
				},
				"354d2614-4245-499d-981c-800e57c8b91b": {
					"name": "ExclusiveGateway15"
				},
				"f275da51-5617-4333-83d9-aff034b1c70e": {
					"name": "Prepare Batch Call CA Managers"
				},
				"67dac61a-5d8d-403c-93a1-a56f3823a247": {
					"name": "was Sent Back?"
				},
				"50aa8137-fd50-44ed-a195-e4765d4f1c69": {
					"name": "Set Wf Instance to Complete"
				},
				"e62a9b1b-ce64-4fc4-b605-617b23ded67a": {
					"name": "Set Wf Instance to Complete"
				},
				"8242f728-507b-4793-b9fb-629dc3cc79e2": {
					"name": "retry?"
				},
				"5461095c-4eec-4521-ab96-7e568c905bff": {
					"name": "Check Batch Call"
				},
				"898272e4-5a6b-4718-8c09-8aedec202321": {
					"name": "retry?"
				},
				"68ed2872-5482-465b-b560-49979b07b5dd": {
					"name": "Check Batch Call"
				},
				"fb8a7793-4c34-4ad7-8c40-48079bb1661f": {
					"name": "retry?"
				},
				"2bcd6216-3f70-461b-92b7-cf05f6d439ec": {
					"name": "Check Batch Call"
				},
				"df48d131-ba3e-4f87-8430-e9467164626b": {
					"name": "retry?"
				},
				"ade99b22-6ac9-4e1d-8811-1534d90745e8": {
					"name": "retry?"
				},
				"a552781b-d824-4782-a4da-5bf466645df7": {
					"name": "Check Batch Call"
				},
				"3cfb8f37-57c4-4fef-abcb-fb6c90d03197": {
					"name": "retry?"
				},
				"77d837e2-2e1a-40ad-88a3-73192fbfd1c0": {
					"name": "Check Batch Call"
				},
				"ed625063-4a14-4208-a032-83a5f425bccc": {
					"name": "retry?"
				},
				"b6021f22-e46b-417e-b1bb-872c603b5736": {
					"name": "Check Batch Call"
				},
				"9dd72e42-191f-468a-9647-a628c8fd17e6": {
					"name": "retry?"
				},
				"0cbbabb8-3988-416b-b310-77659b4225b6": {
					"name": "Create WfInstance"
				},
				"8e4664d1-e4bc-4b0f-8386-e37aa621fc85": {
					"name": "retry?"
				},
				"acd3716f-1a35-4503-9739-85361bef5f85": {
					"name": "Check WfInstance Create"
				},
				"c09525f9-e84e-486c-9ee4-3255981f9f30": {
					"name": "Check For Rework and Reject"
				},
				"19dbe20f-9499-4d84-b2a6-59f2577bc887": {
					"name": "Is Rework?"
				},
				"83164bc9-e708-4115-89f1-90702519e7d9": {
					"name": "Process Resource's Approve Decision (Multiple)"
				},
				"56449570-8bd1-47f8-8a8b-e8cd7d8bec49": {
					"name": "Check ResApprove Count"
				},
				"15a3e187-5366-4134-b217-f1fa7fa383ae": {
					"name": "ReferencedSubflow3"
				},
				"586b13f2-76b5-4ed7-a64c-ed62c9f185d8": {
					"name": "Is Reject?"
				},
				"76998587-b436-46d5-9654-f1d5b54cea7c": {
					"name": "Process Resource's Send Back Decision"
				},
				"cf128b14-466a-48b6-bbcf-c5ac8fc4c7b9": {
					"name": "Is Resource Reject?"
				},
				"bc4a7c70-7b35-4903-845d-70c4e5f3242f": {
					"name": "Clear Resource Reject"
				},
				"77009387-aab8-4f42-8f7c-f4e10985f460": {
					"name": "Notify Requester About Rejection"
				},
				"884ff1e1-f344-46c9-9cac-f8cf678a5a78": {
					"name": "WfInstance Update"
				},
				"e55968cd-4af7-4797-9fc6-466f04cfbeea": {
					"name": "Process WfInstance Resource AllReject"
				},
				"d646474d-3529-41a6-ae57-d4a43aa49800": {
					"name": "WfInstance Update"
				},
				"3634b4b9-98ac-4d8c-96cf-bf11d09e060f": {
					"name": "Check Batch Call"
				},
				"4db9678a-18f4-4646-939c-a4e6effc31ee": {
					"name": "retry?"
				},
				"700a6d8f-16e3-4952-9283-2eeb3bf5d7ad": {
					"name": "Context Cleanup"
				},
				"e60d84ca-b7e8-4f08-8390-059aab21d6bf": {
					"name": "Reject  Gateway "
				},
				"150a24e2-88c0-4dcb-a84c-20d93b376d7d": {
					"name": "Is Approve ?"
				},
				"1add78a6-c2b5-4286-a14b-eb75518972a4": {
					"name": "Filter Approve and Reject Decisions "
				},
				"151ee67a-db52-4540-8b6a-f591a7b71f4a": {
					"name": "Create WiRoleAssigned"
				},
				"af0a4614-e737-4ead-b301-67aa489ca082": {
					"name": "WfRoleAssigned Create"
				},
				"354a4d17-0c0c-4245-bfca-fe0064bfad23": {
					"name": "Check Batch Call"
				},
				"c00f2a6f-6814-4c28-a548-49650d55e9f2": {
					"name": "retry ?"
				},
				"a92f0f95-9eb7-414a-9dbb-1d9df0785f8c": {
					"name": "Check First Time ReqArea"
				},
				"f5065acc-ca90-4eb5-b50c-5499b2d3a333": {
					"name": "Routing Check"
				},
				"41c3c126-fb82-4a1d-b79c-765a13db7625": {
					"name": "IsAccount"
				},
				"00a7fee2-04b8-47c7-a454-81a8431932a4": {
					"name": "IsAccount"
				},
				"3868830c-d756-46b5-bf27-6a6af1cefb8e": {
					"name": "Update Account Details"
				},
				"ed0992f0-1881-4231-bded-2d6fae63bfcb": {
					"name": "Update Account"
				},
				"188c8349-34ce-4d4f-bb98-1b8c5e8de814": {
					"name": "Prepare Content for Older tasks"
				},
				"f77539b1-89c8-4ef9-82ca-ee0ffb34b3ab": {
					"name": "isAccount"
				},
				"8b42abcb-2e53-48d1-afdd-be0b1825b791": {
					"name": "filter Auto Staffed Resource"
				},
				"79b7e998-0eb2-45e9-b322-2e5d832d4957": {
					"name": "isAccount/IO_Owner"
				},
				"6ee8995c-c5b8-4bd7-8a79-f768b73174fe": {
					"name": "ExclusiveGateway60"
				},
				"4276f295-a1b2-40c0-bce3-304fffe6aa62": {
					"name": "Process IO_Owner Approve/Reject Decision"
				},
				"ff37bfbb-d8b6-451b-a1b9-e762b6e8347f": {
					"name": "WfInstance Update"
				},
				"e9776d6f-986e-4f0e-9385-50ed77dbbc26": {
					"name": "Process Wf Instance Io_Owner"
				},
				"28a0934a-bd2f-4d09-8e45-144459be00d5": {
					"name": "Process Nominated IO Owners"
				},
				"50af6a3b-96a3-4c1e-b141-0e14052384f8": {
					"name": "IO_Owner Subflow"
				},
				"61b35d98-875a-4caa-9dd6-908ee777b1f4": {
					"name": "Process Initialize Request"
				},
				"67439b2d-26da-4526-89c7-7ab805d2940c": {
					"name": "isResourceProfile"
				},
				"2e2c1228-70ce-4e3e-a17f-6f0e57a3fddb": {
					"name": "isResourceProfile"
				},
				"08463fa9-cbff-4d54-83c3-642f3e6fb2cc": {
					"name": "isResourceProfile"
				},
				"0491100d-c3d7-4a10-b987-a51714fe03b9": {
					"name": "Process Resource Request Legacy"
				},
				"c3782cf7-1ebf-4b75-a47a-64c27487fddd": {
					"name": "Process Wf Instance Forward Legacy Request"
				},
				"838d04ab-576c-4221-94a0-1a081c7fd564": {
					"name": "Process Forward Request"
				},
				"b77b8193-43b4-43b2-8c7a-113c804fa906": {
					"name": "isResourceProfile"
				},
				"791b12f7-5553-4f20-bf99-da491f7b35db": {
					"name": "Process Resource Response Legacy"
				},
				"14a0fe86-1d2a-4966-b335-741b6be5059e": {
					"name": "WF Update"
				},
				"d4a748dc-7b7a-42a4-94ad-aeab5ff9b049": {
					"name": "Get CurrentState Data"
				},
				"364045a0-c6e7-4afc-94d4-82ec2f1d03c9": {
					"name": "Process CurrentState ID"
				},
				"f4be14cb-e3ee-40ee-89a4-bc7ec4ef4585": {
					"name": "isResourceProfile"
				},
				"b7fe7321-8af8-4b59-8e14-50773a7d2406": {
					"name": "Processor Form"
				},
				"26a6e01b-1b1e-499a-854e-ccf5425cc013": {
					"name": "Process Resource Profile Data"
				},
				"0c3397ab-660e-4a01-be0d-e17c50fac2b0": {
					"name": "Notify Approver ResProfile"
				},
				"df47c6db-fc0a-4195-b54e-582286587c3b": {
					"name": "Reminder Mail"
				},
				"644f787d-b26c-4962-a09c-4dad807bc97c": {
					"name": "Processor Form"
				},
				"9576a80b-3c74-4cd2-83cb-1db026b2955c": {
					"name": "Process Manager action"
				},
				"dce010fe-7fea-40cf-bf0c-71b0fdbc065b": {
					"name": "Skip reminder mail"
				},
				"c91eb81e-c617-472f-9da7-08e778091ec3": {
					"name": "Get Refrence ID"
				},
				"6650cdb4-09e8-4a73-ae96-bedea01e4693": {
					"name": "Process Delete Draft Call"
				},
				"256073f1-1da8-4b77-8f03-f1038d4987f9": {
					"name": "Process Draft Delete Call"
				},
				"f1c40679-3ce3-4adc-a831-ad69100e2f9a": {
					"name": "Check Draft Delete"
				},
				"4c031674-0350-4056-988f-30a547a88f59": {
					"name": "Process Wf Instance Form URL Update Request"
				},
				"254fe491-2ef3-44e4-8b0a-77f4f99b190d": {
					"name": "Get WF History Data"
				},
				"5062881a-cb6f-4ed0-90d2-490f02801e8b": {
					"name": "Get Request ID"
				},
				"689fa697-0d89-4c8a-b038-811933578504": {
					"name": "Get Request ID"
				},
				"ba9fca6d-ac19-4573-8b8f-42d4e9ec6a1b": {
					"name": "Get Request ID"
				},
				"4e0b6f65-a8e8-4277-bad0-646c7a1015cf": {
					"name": "Process CureentState Data"
				},
				"eed87f50-5ffa-451a-8ebd-d258a2a883a7": {
					"name": "Get Routing Data"
				},
				"1761e0a8-2a2c-4580-ba6e-e239da8cdc9a": {
					"name": "Get Routing Data"
				},
				"49ceda69-aeb0-4377-bb38-9f7b75d6deda": {
					"name": "Notify Requestor about request Termination"
				},
				"0962e38d-f08a-4e79-bf07-0f5dfd82e983": {
					"name": "Is Resource Profile?"
				},
				"61e68c5b-b834-4d67-bd92-85b4c078fdeb": {
					"name": "Is Resource Profile?"
				},
				"164ff510-3ccd-463d-a0f7-6820d5bff0dd": {
					"name": "Notify Requester About Rejection"
				},
				"58e19ac0-7b08-4243-80ae-b02fd1c8b018": {
					"name": "Is Resource Profile"
				},
				"6aa491a3-33f5-428c-82f2-4c911cc1a087": {
					"name": "Notify Request Area Requester About Rework"
				},
				"f39b3834-3b10-49fa-9e9e-8712a79017d7": {
					"name": "Notify Request Area Resource Approval"
				},
				"db552930-7437-4f8f-9056-3a37b194590d": {
					"name": "Is Resource Profile"
				},
				"0e75953e-aa04-40f1-83f3-ce7f382926a5": {
					"name": "Notify About Resource Approval to Resource"
				},
				"5cd8cdad-b206-47fa-9a69-d5a148329397": {
					"name": "isResourceProfile"
				},
				"b46ffe03-6e9e-443f-911b-e8e8f01c2d31": {
					"name": "Notify About Request Creation / Update"
				},
				"cebf1053-229e-4ba3-a75f-ebae890a536a": {
					"name": "Process get Resource Comment"
				},
				"2edba57b-3b16-4bb3-8a87-65c324f5ccc6": {
					"name": "Update Current State"
				},
				"82b83e36-bb6a-490a-b97a-248c6121c9f5": {
					"name": "Is Resource Profile?"
				},
				"894232bf-957c-4e96-9bff-7b029be4391b": {
					"name": "Notify About Resource Approval"
				},
				"37d6cb53-75f5-41ba-a49c-9c783cc7a31a": {
					"name": "Delete Activity Lists ?"
				},
				"b80468b1-0eec-4cd2-b814-5f0b68305fe1": {
					"name": "Delete Approved Req Activity Data"
				},
				"c4d2b059-6975-4dd7-aae8-b5bf03d80d5a": {
					"name": "Routing Check"
				},
				"29b0a44f-4005-48a5-8de9-41a4315e46b8": {
					"name": "Prepare Payload For UserNotif RequestCreation"
				},
				"873a3e95-1481-4253-946d-dec2435b5e5e": {
					"name": "Get User Notif Data Request Creation"
				},
				"d7519588-4503-490f-8c6b-2824c558ff2e": {
					"name": "Process User Notif Data"
				},
				"b19f799c-827d-4efa-88e2-a17f7678dfb8": {
					"name": "Payload For UserNotif RequestModificationProcessor"
				},
				"c2f6848b-b53f-48d6-9a1b-c4fe07641521": {
					"name": "Get User Notif Data Request ModificationProcessor"
				},
				"cbe4be68-f965-4841-bdef-c35716ac6c09": {
					"name": "Process User Notif Data"
				},
				"dab92ecd-01ed-4792-a03a-4dd389cf16e1": {
					"name": "Prepare Payload For UserNotif Request SentBackAction"
				},
				"67f9522c-2fa9-4e5b-9eab-36406162541e": {
					"name": "Get UserNotif Send Back to RequesterAction"
				},
				"dcb51126-0d0e-4846-9e4a-abfd8999ebfa": {
					"name": "Process User Notif Data"
				},
				"fea4d57a-0882-412f-891f-b7c6b15ae174": {
					"name": "ServiceTask69"
				},
				"57ccb261-0689-431d-9ab3-0bda27e02dae": {
					"name": "Process User Notif Data"
				},
				"30a7f6e6-bb09-4cdd-bc98-0f26bfc4c4b3": {
					"name": "Payload For UserNotif Request Closure"
				},
				"de105fa5-c4a1-4579-8dc3-1d7de4ba9288": {
					"name": "ServiceTask70"
				},
				"53047d61-27f0-4197-bb50-1e3f021c657a": {
					"name": "Process User Notif Data"
				},
				"e96d3276-d4b5-4a0d-b0e7-d26d9c3ef2d4": {
					"name": "Payload For UserNotif  Prossor Rej Action"
				},
				"b08f281a-cf6e-4d5d-b659-6716a1830378": {
					"name": "ServiceTask71"
				},
				"3e19ecbd-1340-465c-8976-82efa862cfe8": {
					"name": "Process User Notif Data"
				},
				"6a0c923c-5bf1-4ace-be3c-26e0c029a0ef": {
					"name": "ServiceTask72"
				},
				"fb3b491e-00c5-46f0-bd63-8be142ff9afb": {
					"name": "Process Res Direct Manager Data"
				},
				"27736dd6-1b84-467b-8286-9ba3b99c2d95": {
					"name": "Notify About Resource Approval to Manager"
				},
				"a13be89b-e4fc-432a-b14e-605cd21a47c9": {
					"name": "ExclusiveGateway88"
				},
				"04c2516e-f970-4c59-abba-d57b4e78a3fc": {
					"name": "ResDirect Mgr Flag"
				},
				"0a34cbbb-0781-423a-a550-c0900b8f51c2": {
					"name": "Payload For UserNotif Req TerminateAction"
				},
				"5623d2f2-5e02-49f3-a96b-bcf58d76c3d4": {
					"name": "ServiceTask73"
				},
				"e16d155c-2186-46c1-b37c-6d342092c68f": {
					"name": "Process User Notif Data"
				},
				"e16ccd4d-94a4-4355-9291-977b33e1b91a": {
					"name": "Email Flag"
				},
				"bf0bc050-60c0-4e34-839c-6baca8156286": {
					"name": "Email Flag"
				},
				"a66aa8f6-ce7d-466e-b8ff-0b5bbdfe81b3": {
					"name": "Email Flag"
				},
				"167969ee-99a3-4d35-9711-1cb7a7cbec12": {
					"name": "Email Flag"
				},
				"b5288eba-8fc8-411b-a9b8-048c8a0d8a65": {
					"name": "Prepare Payload For UserNotif RequestAction"
				},
				"b2b5df75-228e-4e7d-bfe0-e03177186322": {
					"name": "Get User Notif Data Request Action"
				},
				"675f37df-4e36-4dca-bd2a-d373fef4aa09": {
					"name": "Process User Notif Data"
				},
				"dc1860ba-eae3-41ff-96cf-780880391467": {
					"name": "Prepare Payload For UserNotif RequestAction"
				},
				"019c17a6-e0c0-46b9-b712-c0d34cf252e5": {
					"name": "Get User Notif Data Request Action"
				},
				"5718cc40-784a-446f-804a-686f62b8a38d": {
					"name": "Process User Notif Data"
				},
				"7ade6462-abd5-40a6-9e34-08a157ba9cf0": {
					"name": "Comment Email Flag"
				},
				"d26896e5-5e29-4c01-8fa3-c4f2f5f52837": {
					"name": "ExclusiveGateway95"
				},
				"57733068-a0f9-45ef-98a4-b14c150c9705": {
					"name": "ServiceTask77"
				},
				"4a2ba629-a4ac-4c75-bad3-6465304ac364": {
					"name": "Comment Email Flag"
				},
				"ada573ed-5ba3-4e9d-88a5-69fb301817f3": {
					"name": "ServiceTask78"
				},
				"47ec03ab-1a9b-4611-ad45-62f351176504": {
					"name": "Comment Email Flag"
				},
				"7afcbd35-981f-40ad-be79-b73c357b3e88": {
					"name": "ServiceTask80"
				},
				"91b9adda-ddfc-4028-8044-a9897babddfb": {
					"name": "Prepare Payload For Comment Email Notif"
				},
				"22c0a6d3-9563-45cd-a631-16ace9e8fdbe": {
					"name": "Email Flag"
				},
				"1626e402-eabe-408f-9fa8-2b65959fff3a": {
					"name": "Email Flag"
				},
				"9d91e666-d780-414b-aedd-55ee0147bec9": {
					"name": "Email FLag"
				},
				"cddc4689-b295-4ff2-bba3-42988d40ae93": {
					"name": "Email Flag"
				},
				"26d15377-8229-412a-941f-f4b55b9d8660": {
					"name": "Notify Approver ResProfile Modification"
				},
				"a0f2bc94-21d8-43c4-9726-2de6188586ed": {
					"name": "Notify Approver ResProfile Action"
				},
				"095a8d5e-d3f8-4251-957a-3ef0b54b43c6": {
					"name": "Processor added?"
				},
				"154c1d85-9385-4c63-985b-f7c22edcc182": {
					"name": "Is Foward?"
				},
				"80d8290b-5d1e-489b-9196-04a30020661e": {
					"name": "isRework?"
				},
				"dc46d7b3-eeb3-4c5d-a22e-53573488ff79": {
					"name": "Process Payload for Forward Request"
				}
			},
			"sequenceFlows": {
				"c6b99f32-5fe6-4ab6-b60a-80fba1b9ae0f": {
					"name": "SequenceFlow1"
				},
				"cbff60a3-b01a-46c9-b6d4-c4f02c5e8d86": {
					"name": "SequenceFlow2"
				},
				"67f85457-a01d-4c63-b4b6-872a00f0f8b9": {
					"name": "SequenceFlow3"
				},
				"dd7946a1-f238-4c7a-a5fd-c1ed7094b7e1": {
					"name": "send back"
				},
				"c89124c5-dab8-481c-8307-beef67357aeb": {
					"name": "approve"
				},
				"31e25202-6cca-4025-acb8-0b632fe0fd4d": {
					"name": "SequenceFlow23"
				},
				"c342097f-192a-4660-a73e-da0ebd797b89": {
					"name": "SequenceFlow24"
				},
				"56a8a81c-f5f3-4070-bfe3-fa5e476b01fa": {
					"name": "SequenceFlow31"
				},
				"bfe4859f-9e9f-4f37-847e-63d2fcfa69e2": {
					"name": "SequenceFlow38"
				},
				"eef1bd83-3d87-4465-a7c3-c92800f9c48b": {
					"name": "SequenceFlow41"
				},
				"29abf8e7-c8a3-4777-81a0-49ec1fe6ccbd": {
					"name": "Submit"
				},
				"db84c2ec-911f-4964-8e9a-50d9821cc474": {
					"name": "Terminate"
				},
				"8b19b064-884f-4f12-8a81-c45f49a7d7a8": {
					"name": "SequenceFlow51"
				},
				"61617f44-0d68-482f-a241-7b5c65fb9d50": {
					"name": "SequenceFlow54"
				},
				"a48cfdbe-2f35-40d3-9d30-7921d68617f6": {
					"name": "SequenceFlow58"
				},
				"f1790b57-eb7a-4f5d-915c-0710ac27fb9a": {
					"name": "SequenceFlow60"
				},
				"f3e9e518-b00d-421e-bd91-abaf88253b58": {
					"name": "forward"
				},
				"b8a123dc-fb1a-4f67-92d6-ab415991e790": {
					"name": "SequenceFlow62"
				},
				"3d12733b-6286-4b08-934e-3b5ebbc924cb": {
					"name": "SequenceFlow65"
				},
				"a2a7c0b0-a677-490a-b05b-61f83ec61545": {
					"name": "SequenceFlow71"
				},
				"c3e5f663-1d55-4b75-80a9-e2d2540536bd": {
					"name": "SequenceFlow75"
				},
				"681f78f5-2f89-4781-8d90-404af29f559a": {
					"name": "SequenceFlow76"
				},
				"32682168-7f79-48ec-a5db-73ec3b828f1d": {
					"name": "SequenceFlow79"
				},
				"7a02df10-8590-4cf9-8fd5-433bc0ffdd79": {
					"name": "SequenceFlow81"
				},
				"a8c41d51-a14f-4fec-8f40-49a107a4083d": {
					"name": "SequenceFlow86"
				},
				"36c49a76-b960-48bf-9d16-ff018a8b66a2": {
					"name": "No"
				},
				"dee51f9a-8c65-44d9-814a-a42fce41ab06": {
					"name": "SequenceFlow93"
				},
				"5e7233d7-b513-46d0-a5e1-3797e89ef6c1": {
					"name": "SequenceFlow94"
				},
				"b4251b51-8ecb-46e0-a28f-3d479f8963d4": {
					"name": "SequenceFlow95"
				},
				"ff29f679-cb09-4ff6-9830-80537ff53755": {
					"name": "no"
				},
				"f62aac86-d615-4105-869a-3b66f94a5d8e": {
					"name": "yes"
				},
				"bf8ae7ef-156c-4b07-a9db-d7494e301aac": {
					"name": "SequenceFlow99"
				},
				"7c0df5b1-973c-4cd6-a293-94a40467a169": {
					"name": "SequenceFlow100"
				},
				"9f702c5c-c132-4c75-8ddd-91aeb3cdc3c1": {
					"name": "no"
				},
				"00d8e9e7-7de4-4d9e-a338-424dce2e60b9": {
					"name": "yes"
				},
				"ab07db2a-d54f-4353-95d7-e058fde5c5a7": {
					"name": "SequenceFlow106"
				},
				"a2b4ba53-c764-412e-872d-0d621ff3bac3": {
					"name": "SequenceFlow107"
				},
				"8cbe862a-01cd-44b8-b8bb-4d175436c687": {
					"name": "SequenceFlow108"
				},
				"3e61da83-19ba-4b9a-97e8-2893c9de6e7d": {
					"name": "no"
				},
				"8b6b6507-0682-4403-b21c-663dd4adb5cf": {
					"name": "yes"
				},
				"a2e490fc-09fd-4187-a6a3-95aa56069181": {
					"name": "SequenceFlow112"
				},
				"328d0b8c-7512-48a7-a305-060df9161e20": {
					"name": "SequenceFlow122"
				},
				"86c031b4-a5f1-45ac-946f-461d81c12fe1": {
					"name": "SequenceFlow126"
				},
				"331bb888-15e6-437c-8f0e-bbe1f02f5034": {
					"name": "SequenceFlow128"
				},
				"324a90d6-31fa-4db2-a2e0-2da3cb51a4aa": {
					"name": "SequenceFlow129"
				},
				"8da188fa-85e3-4eba-9efd-50d12ec31967": {
					"name": "SequenceFlow132"
				},
				"2f5ef6cc-abba-440d-9c3e-6020b86a5f76": {
					"name": "SequenceFlow133"
				},
				"360372f3-3e99-4de0-ae65-a5d1f593da08": {
					"name": "SequenceFlow134"
				},
				"f790d345-c914-4baa-8c6a-834c3e7aac10": {
					"name": "SequenceFlow135"
				},
				"921d2dd0-9298-431e-a862-1f64ff318b4e": {
					"name": "SequenceFlow142"
				},
				"1b2e9457-c8de-4ae7-b015-2f1634f21461": {
					"name": "SequenceFlow143"
				},
				"94014aa8-48f5-459c-af49-6a77afd84b15": {
					"name": "SequenceFlow144"
				},
				"e6e6913b-614a-499e-a0b2-aac182bd2e36": {
					"name": "SequenceFlow145"
				},
				"2e5195ca-3c2d-4dc5-ac02-8f33009641a4": {
					"name": "SequenceFlow146"
				},
				"95bae7c8-4c50-4f6f-88dd-7f029ed4c3f7": {
					"name": "SequenceFlow148"
				},
				"dc729b7f-2d1c-4dd0-9431-8e0d50a609da": {
					"name": "SequenceFlow149"
				},
				"068488e5-c4c3-43b7-b7f3-1507c06fcfac": {
					"name": "SequenceFlow150"
				},
				"4991edf8-64e2-45c6-940f-0d6ef0824213": {
					"name": "SequenceFlow153"
				},
				"20a90dc8-035f-48e8-9e94-28565aeb83eb": {
					"name": "SequenceFlow155"
				},
				"a30405d6-7b62-4efe-acae-569f11a6f2ef": {
					"name": "SequenceFlow156"
				},
				"1c9a1904-19ca-4191-a3c0-2ec00228eaca": {
					"name": "no"
				},
				"abc20477-9cb6-4188-95ca-ca2e7270f712": {
					"name": "yes"
				},
				"2fc44807-25d8-4446-bd9e-49f49cb335fe": {
					"name": "SequenceFlow160"
				},
				"1a7a45f9-b2b0-4166-b5b4-334e18f73a92": {
					"name": "SequenceFlow165"
				},
				"47ed3840-7e44-4957-a7b6-7d0f80d8cac1": {
					"name": "no"
				},
				"02df9f15-66cd-498e-9ecb-fb671e20d8ce": {
					"name": "SequenceFlow169"
				},
				"166aa69f-ccf8-43dc-8637-fad42d6582c2": {
					"name": "SequenceFlow170"
				},
				"05fab4cb-d8c4-47b3-9485-6529df557015": {
					"name": "yes"
				},
				"8c7d2af6-903b-4a8f-80fe-b35409ee5a5b": {
					"name": "no"
				},
				"c729c403-aae0-4560-b7cb-6b1529fee388": {
					"name": "yes"
				},
				"6deb1b7f-2512-40b3-b58d-5759a05cad55": {
					"name": "SequenceFlow174"
				},
				"0aaa828d-8a31-4c3f-b85b-caab990f21ee": {
					"name": "SequenceFlow175"
				},
				"36fffba7-d3b4-402e-ae69-28c0227d023c": {
					"name": "SequenceFlow183"
				},
				"34ed1d1c-df8f-4100-ae31-42e0a196de43": {
					"name": "no"
				},
				"32d9bce6-141f-4ed5-870d-a8c9eef80013": {
					"name": "yes"
				},
				"c932376d-73eb-401f-97f6-3fcdf897527e": {
					"name": "SequenceFlow186"
				},
				"b3d57f26-0e70-490d-809a-1bebdca98041": {
					"name": "SequenceFlow187"
				},
				"a55bee0b-2803-4600-9f8a-f67425cc3e13": {
					"name": "yes"
				},
				"c709ae80-5a3a-4a14-a6ef-833e31546070": {
					"name": "no"
				},
				"c4e79006-a40c-4168-891d-f51b3688fbe2": {
					"name": "yes"
				},
				"67c691df-76a3-4191-a3e2-d052b039ba39": {
					"name": "SequenceFlow192"
				},
				"f65eaf2d-b91e-46ef-8ca8-2d8d661d6d8b": {
					"name": "no"
				},
				"5f86cbe2-6a96-4334-97f7-b6c877752c9e": {
					"name": "yes"
				},
				"76b97217-0a87-4a46-a465-ff636ade22ce": {
					"name": "SequenceFlow198"
				},
				"2d70c319-e451-4336-b4ec-4a01a405cd16": {
					"name": "SequenceFlow200"
				},
				"9d7aeb3e-0a5b-4a25-b8ae-65c2eb1dd31f": {
					"name": "yes"
				},
				"bc832fdd-9634-4fcf-9266-7322b82aded4": {
					"name": "SequenceFlow209"
				},
				"701e242d-aa44-43d2-a412-438b2eb725ed": {
					"name": "no"
				},
				"dbf112ee-4a31-4dd2-adc1-34ba62da883e": {
					"name": "yes"
				},
				"59c94139-b2a5-4f3a-a81d-0f5ae8b05088": {
					"name": "SequenceFlow214"
				},
				"75130ec0-c22d-446c-8c3d-d87cf2a6a170": {
					"name": "SequenceFlow216"
				},
				"5e4ff83f-97cf-45d5-bfeb-2806c6ab3edf": {
					"name": "no"
				},
				"da8fedd5-802e-4093-87bc-2cf327e38afa": {
					"name": "SequenceFlow224"
				},
				"fcd9609c-ab96-4009-b528-74a340aaaa80": {
					"name": "No"
				},
				"bdf95749-dcef-4cb9-b50b-63e565a7649a": {
					"name": "Yes"
				},
				"0840dd77-7f25-4882-a5e4-e10f4010a3c8": {
					"name": "SequenceFlow230"
				},
				"76c5606f-384a-4e96-895f-53cc34961857": {
					"name": "No"
				},
				"ac960d55-35e5-4657-9c58-efd1cda5e74f": {
					"name": "Yes"
				},
				"fd28d3ea-e700-47e9-a55b-974a5c22c44e": {
					"name": "No"
				},
				"ae7e3c1d-ecf2-4d12-9a54-72fad6b8d3da": {
					"name": "SequenceFlow239"
				},
				"da0d2b45-e64b-4fa1-9508-a71729321442": {
					"name": "Yes"
				},
				"bb8d0430-5643-45d5-8e85-b90725e3159f": {
					"name": "reject"
				},
				"37bd7e76-3fd0-482e-b3f8-6690e4915208": {
					"name": "Yes"
				},
				"5b84c5e1-c843-41c0-ab5b-376262e1869a": {
					"name": "No"
				},
				"b2fc9b55-32c1-4ec5-8f65-83988df60ca8": {
					"name": "SequenceFlow256"
				},
				"54a8904a-f070-4ea9-8d64-e5b07eafe485": {
					"name": "SequenceFlow259"
				},
				"27566425-a069-4cf3-aede-efa584513bfd": {
					"name": "SequenceFlow262"
				},
				"3f41cb7f-93bc-4c0f-b548-530ecc1211a1": {
					"name": "SequenceFlow263"
				},
				"8c621dca-bf5a-415a-8717-34f423b4793a": {
					"name": "SequenceFlow264"
				},
				"b1fe490a-52b0-42c0-b0d1-4425931edf89": {
					"name": "No"
				},
				"0cd66587-5e5b-4bc7-a827-fc0712254f31": {
					"name": "Yes"
				},
				"7179827e-2dba-4c0d-a86f-07fc4fb8320e": {
					"name": "No"
				},
				"87c37b70-30a4-463a-a3c7-33c7d15a78cc": {
					"name": "SequenceFlow268"
				},
				"75d6c528-28cf-4f01-915f-fba4eb40f575": {
					"name": "yes"
				},
				"b89c7f06-ae33-4900-a4c8-f95d85887f72": {
					"name": "No"
				},
				"80b34501-6e5b-4db5-97ca-0bf53550e22b": {
					"name": "SequenceFlow273"
				},
				"473dfa99-dfa2-40b7-985e-62ca3cda6913": {
					"name": "SequenceFlow274"
				},
				"ddb81cb4-0d8a-4c22-8f74-27bd375a40d4": {
					"name": "SequenceFlow275"
				},
				"071967f1-e2f1-49d6-9e80-c9eafbcb18df": {
					"name": "SequenceFlow276"
				},
				"06bbfc0a-c342-4208-855c-62a1ffde7850": {
					"name": "SequenceFlow278"
				},
				"ca6f3230-2b40-4163-9c31-2c5b9c00a775": {
					"name": "No"
				},
				"dfd21a8a-1b17-4dcb-aeac-dbcc99c8d817": {
					"name": "SequenceFlow282"
				},
				"ad3d14f4-64f8-4682-9636-353c11ea56a1": {
					"name": "yes"
				},
				"4dfa1b2a-2536-4efa-8427-7efa45ef68f3": {
					"name": "No"
				},
				"d06753fc-9d95-49d5-be33-c0ddd62966cb": {
					"name": "Yes"
				},
				"1c436edf-5127-4046-b900-0e4dd4fe63ff": {
					"name": "no"
				},
				"eaef82ac-a7dc-4b3b-94a5-19dffbdb5a52": {
					"name": "No"
				},
				"3b3113a8-70ff-4758-8b9b-acef4e3f5952": {
					"name": "Yes"
				},
				"75896328-c6d4-4c1b-b927-19d825b6ea0a": {
					"name": "Yes"
				},
				"a0226c8b-64d3-4426-8403-7d082dd38502": {
					"name": "No"
				},
				"de40e5a9-db13-4e67-9d93-2904497e9574": {
					"name": "yes"
				},
				"5eb4b3c7-c7e8-4ce3-a618-3794f5a6dc64": {
					"name": "No"
				},
				"c1c5e7ff-e337-4f24-8657-c4bcd5d6795e": {
					"name": "Yes"
				},
				"ffe81886-f21d-482a-92d6-b54e3f2648b4": {
					"name": "SequenceFlow315"
				},
				"a32dc0ac-277e-4aac-bb00-82dd66bbe5d4": {
					"name": "SequenceFlow316"
				},
				"f8f8ead3-4a3c-4f27-b26b-e153bfe76dbc": {
					"name": "SequenceFlow317"
				},
				"048510c6-d11d-44d2-b520-292930deb72e": {
					"name": "No"
				},
				"c37991b2-2378-4111-972c-33fb47f3a010": {
					"name": "Yes"
				},
				"5a52e8ec-d8f1-4027-a781-a95484b6f0a7": {
					"name": "SequenceFlow342"
				},
				"b5a8f5fe-779b-4fed-be76-f2179e51e2f4": {
					"name": "Yes"
				},
				"6dda97f8-aa4d-4713-92c5-fef77fc49c28": {
					"name": "No"
				},
				"0054aef6-5b38-4068-b61f-cfed96558c2c": {
					"name": "SequenceFlow354"
				},
				"29ec8dc3-eea5-45f6-a560-7d4331f8c93b": {
					"name": "Yes"
				},
				"e3ffcdf1-f689-4dba-8f1c-36c0b5f9863d": {
					"name": "SequenceFlow370"
				},
				"e084355f-1259-40cd-aa4d-b665b8c372be": {
					"name": "SequenceFlow371"
				},
				"6773827d-cbb0-496a-a861-13db7c9727bd": {
					"name": "SequenceFlow380"
				},
				"1a1c487e-b25d-4e56-a1be-162733240567": {
					"name": "SequenceFlow382"
				},
				"cde72047-4f3f-4457-9c17-467731a2cf5b": {
					"name": "No"
				},
				"612bd3cc-c675-4e42-ad1f-5d6e2e9b23d9": {
					"name": "Yes"
				},
				"2510cd26-b393-4ae2-b41a-b02b5dd030cb": {
					"name": "SequenceFlow387"
				},
				"fa649f89-29e9-41c0-b6dc-cea1d2e142e9": {
					"name": "No"
				},
				"f0a70486-2531-43e6-8b75-9c0befb108a3": {
					"name": "Yes"
				},
				"82800f1a-6ec4-4427-baf1-9429a8c2b4c3": {
					"name": "No"
				},
				"634919b7-63f5-4a36-9c78-0562c8c0028e": {
					"name": "Yes"
				},
				"5c7c8944-3239-448f-9b50-6759facec636": {
					"name": "SequenceFlow393"
				},
				"a3349dc9-3f51-4722-af94-b5c076be0c2f": {
					"name": "SequenceFlow394"
				},
				"8b8b3075-c0db-4b59-b420-eb37244af2c0": {
					"name": "No"
				},
				"581ee665-0b96-4981-b4a7-f66531eba313": {
					"name": "Yes"
				},
				"6ad1fe1a-4b51-4943-9a56-0b59fe9c543c": {
					"name": "SequenceFlow397"
				},
				"27fa05bd-a7f2-45a6-833f-624d491e07f2": {
					"name": "SequenceFlow401"
				},
				"3f75ac14-53d6-42a4-9715-1b74f63bb931": {
					"name": "SequenceFlow402"
				},
				"c386d94c-0df1-441f-82ac-f5b2e0f25099": {
					"name": "SequenceFlow406"
				},
				"d4d8710b-449f-4585-94ef-a0523880bf17": {
					"name": "SequenceFlow407"
				},
				"254c8a19-c6c5-48ec-b6fd-a834ad4c4b4b": {
					"name": "No"
				},
				"85827e2c-3fdf-4a2d-bead-fcbee8b326ab": {
					"name": "Yes"
				},
				"b912078e-831a-4aa6-8c00-900383d2ba6e": {
					"name": "SequenceFlow410"
				},
				"7acb88cb-58a2-45c7-b6c1-7b025ec2f28e": {
					"name": "SequenceFlow411"
				},
				"d6974bcc-4712-441f-a548-bd1fb7fa4f53": {
					"name": "SequenceFlow412"
				},
				"89984e21-7f8c-406e-be26-33f972d5de21": {
					"name": "SequenceFlow418"
				},
				"0171a61e-5b11-464b-92bf-00ddd7961ed2": {
					"name": "SequenceFlow419"
				},
				"1c16677c-031c-4a61-8921-a14082a99a9d": {
					"name": "SequenceFlow423"
				},
				"367f6933-543d-4bc9-89eb-b2139923fe1b": {
					"name": "SequenceFlow424"
				},
				"65342618-613e-405c-b073-18b951a82cb5": {
					"name": "SequenceFlow425"
				},
				"8f71b6c3-9e86-4732-9033-1f1923376080": {
					"name": "no"
				},
				"0ee9acb9-3c5e-4b8b-b809-ed7e7d492756": {
					"name": "yes"
				},
				"b835f668-ad15-4f1a-8b80-22b61f76b854": {
					"name": "SequenceFlow428"
				},
				"71ddd529-f7dd-4e4d-9f25-398ea612cc88": {
					"name": "SequenceFlow429"
				},
				"7ae673a4-bba8-4367-8c1e-efb5534038ee": {
					"name": "SequenceFlow431"
				},
				"5e9b142d-a945-42a4-b004-073712da66e7": {
					"name": "SequenceFlow432"
				},
				"f42fba9c-730e-4bfd-8a1a-63ff5ec991d4": {
					"name": "Yes"
				},
				"8d8a1e14-6bbb-4096-a559-9df3df7bb857": {
					"name": "No"
				},
				"64b7882e-e829-430c-be5a-11bc40a302c0": {
					"name": "SequenceFlow435"
				},
				"1357c6b2-d880-4bf8-8abe-aafea3f5de05": {
					"name": "SequenceFlow436"
				},
				"e99d9e75-52e0-43f2-b3f9-4e1c6dbd00db": {
					"name": "SequenceFlow440"
				},
				"c73e5d37-9315-45b4-a68e-ccfe62e311f3": {
					"name": "SequenceFlow445"
				},
				"665287f4-59e9-432c-ba87-38af8b88f3c9": {
					"name": "SequenceFlow446"
				},
				"f61420f5-8e5f-4895-8999-de8a2498dc26": {
					"name": "SequenceFlow458"
				},
				"e08d2891-83d8-4f46-b797-e84b68f63538": {
					"name": "SequenceFlow459"
				},
				"7d0f4538-6183-41dc-8555-9f153fbee9ee": {
					"name": "SequenceFlow460"
				},
				"c4027015-c438-479e-97f3-accc635e5711": {
					"name": "SequenceFlow461"
				},
				"768100d8-d481-4919-81bc-c384e2e77e3f": {
					"name": "SequenceFlow462"
				},
				"a2d6d864-339b-4867-9d1e-0adb53e630a2": {
					"name": "SequenceFlow464"
				},
				"34dddbcf-b9b5-41dc-8823-068ce4d5bd5f": {
					"name": "Yes"
				},
				"30498ce2-4056-4ce4-96e1-6b360a1994e4": {
					"name": "No"
				},
				"82ea66a9-8c66-4f4b-a6a5-b92e0fe1d1eb": {
					"name": "Yes"
				},
				"caac9569-57be-47db-8c24-ff8e2c603209": {
					"name": "No"
				},
				"d843345a-e732-4dec-bf08-ff96b41fad57": {
					"name": "SequenceFlow469"
				},
				"7acfecc6-d7af-49db-b8dd-dedbe7bc9b9a": {
					"name": "No"
				},
				"02d34c31-0507-4cf8-9ed7-b17a2338fa34": {
					"name": "Yes"
				},
				"1c9dad2e-5635-4fee-856c-2c874b7b279c": {
					"name": "SequenceFlow473"
				},
				"0ca8ee77-ffaf-4175-bbea-df88657b35e0": {
					"name": "SequenceFlow474"
				},
				"8042c00a-02ac-4882-846f-9b10f3eba07d": {
					"name": "Yes"
				},
				"37f1e805-4ec6-4a21-be72-bb1768430f12": {
					"name": "No"
				},
				"ce31d71c-1d0c-4f0d-b8a4-1cd44762469f": {
					"name": "SequenceFlow477"
				},
				"35c2a2ff-ba31-40df-9210-bdeacbce327d": {
					"name": "SequenceFlow478"
				},
				"3e3e4ddd-69fb-4c5d-a5d5-0d32ef13f11e": {
					"name": "Yes"
				},
				"7e350b76-f56b-4cd9-85fd-32e05b782f36": {
					"name": "No"
				},
				"632e0cca-a529-4e1c-b2cf-20f3c86d795f": {
					"name": "SequenceFlow481"
				},
				"4e8a9a04-dc3b-467e-bc80-70ed030fb5a6": {
					"name": "SequenceFlow482"
				},
				"59da0ed4-53aa-4f78-abc8-1e191ef991d1": {
					"name": "SequenceFlow490"
				},
				"9a719e3a-4b4e-47c3-9d20-dd818a05fa36": {
					"name": "Yes"
				},
				"d70da814-e8af-4a63-aaa8-7aa8cd89329a": {
					"name": "No"
				},
				"ebab49e6-386a-4308-a721-c2364b004304": {
					"name": "SequenceFlow493"
				},
				"4bd665ed-407c-4621-99b2-7af671158353": {
					"name": "No"
				},
				"29ddfff3-14ff-411e-a0da-d8c1e9a45f73": {
					"name": "Yes"
				},
				"34e41670-0063-4599-b99b-81251884edac": {
					"name": "SequenceFlow496"
				},
				"139012bb-af50-4732-a899-04f6dcee5cc3": {
					"name": "Yes"
				},
				"5a69f96e-36f6-4618-a44a-43cb2add3a32": {
					"name": "No"
				},
				"737059f1-bb71-45fa-9ceb-56da13ca09a1": {
					"name": "SequenceFlow499"
				},
				"8eb2275a-90e5-44b6-8e97-1eb50668583e": {
					"name": "SequenceFlow500"
				},
				"331266c9-f582-4c70-b39a-afa20d6a957f": {
					"name": "SequenceFlow501"
				},
				"e7590ffb-5f9e-405e-a2ad-e8ed5f3a9e15": {
					"name": "SequenceFlow504"
				},
				"1d9457a7-4513-40e3-a852-07693c287086": {
					"name": "SequenceFlow505"
				},
				"a7e519ea-06df-433e-b265-0944ea4c572c": {
					"name": "SequenceFlow506"
				},
				"139d6bcd-e3e7-432e-af92-d9987bade40b": {
					"name": "SequenceFlow508"
				},
				"9790ef71-abfc-4466-99b5-7787e4a44ee5": {
					"name": "SequenceFlow509"
				},
				"254e45f8-4375-4f04-9181-afbfa83439c7": {
					"name": "SequenceFlow510"
				},
				"10ff8aa6-d387-4b52-a6fa-7dc71ae00203": {
					"name": "SequenceFlow511"
				},
				"d8c39022-9a9e-4444-babb-e04ce1fbd08c": {
					"name": "SequenceFlow512"
				},
				"e24ea8e0-e501-4390-a80f-39ed7ad60844": {
					"name": "SequenceFlow513"
				},
				"5f2c758f-f63b-4525-82c7-8b695b1c0732": {
					"name": "SequenceFlow514"
				},
				"06abd4d1-7afa-435d-a01c-7be5656bcfeb": {
					"name": "SequenceFlow515"
				},
				"289cca64-0c9e-495a-9ef6-74c48a2a4806": {
					"name": "SequenceFlow516"
				},
				"98a897ec-86e6-419f-978d-19ee6e429257": {
					"name": "SequenceFlow517"
				},
				"cbf3a6c6-9fc8-48b8-b70c-b126b7a7b8bf": {
					"name": "SequenceFlow518"
				},
				"9867138c-d426-41ca-baf3-78cf58c98725": {
					"name": "SequenceFlow520"
				},
				"36b25802-a4e9-46b3-bf4c-724424a85990": {
					"name": "SequenceFlow522"
				},
				"05834487-26f0-48af-9ab7-ff1fe9de6fe1": {
					"name": "SequenceFlow523"
				},
				"496fae2a-0f83-448c-9101-ff234eeaa32b": {
					"name": "SequenceFlow524"
				},
				"a2172b45-2f6f-4b29-bca4-54943585f156": {
					"name": "Yes"
				},
				"83f51d6f-26be-450a-96fd-8076045b8195": {
					"name": "No"
				},
				"e6de11d8-0f55-4fd9-b9bd-c8f228050d7d": {
					"name": "SequenceFlow527"
				},
				"08ab5f9e-fa04-4ca8-842e-34dddba41756": {
					"name": "SequenceFlow528"
				},
				"a03b44f6-6be4-4601-9629-b9bbbc656218": {
					"name": "SequenceFlow529"
				},
				"d80efe57-812b-4fe7-aaef-878d145bfc4f": {
					"name": "SequenceFlow530"
				},
				"fe46f5ab-4090-4397-9348-8ee45fceb7cb": {
					"name": "yes"
				},
				"9466e5a4-73ef-41ca-9751-48a4f769200c": {
					"name": "No"
				},
				"b71c9f7b-8efe-42f0-a3bf-6f3335f5620b": {
					"name": "yes"
				},
				"3d42fc68-48d4-461a-9dea-ab0ffe851fe5": {
					"name": "No"
				},
				"5286ac24-b81b-4d14-9afe-640211fe21bb": {
					"name": "yes"
				},
				"aa2128da-a24e-4223-887f-2e4bf5990270": {
					"name": "No"
				},
				"d9c0d596-5fd7-49ff-983c-a1a5e9455a1a": {
					"name": "yes"
				},
				"2d634131-11aa-4995-88aa-252966acf207": {
					"name": "SequenceFlow538"
				},
				"80cf9ad3-c3eb-41b0-8107-a553a8fa6fda": {
					"name": "SequenceFlow539"
				},
				"7dd6270a-4c50-48ac-9034-accecd52ac3d": {
					"name": "SequenceFlow540"
				},
				"29878ea2-4eb5-48d1-b06a-08b1ac15de59": {
					"name": "SequenceFlow541"
				},
				"36582cd5-a4d5-44f3-8a81-bcb13eb9af5a": {
					"name": "SequenceFlow542"
				},
				"e682a9c6-3eab-4852-82f5-b8afed35e709": {
					"name": "SequenceFlow543"
				},
				"de475d99-d316-45b2-bb3d-35472efe34ec": {
					"name": "SequenceFlow544"
				},
				"a4c1276f-ced6-49a0-a4df-212c8f2fe429": {
					"name": "Yes"
				},
				"1e1be659-516b-44a2-a9fb-664eab510819": {
					"name": "SequenceFlow546"
				},
				"0b6bcc4d-09c0-48e5-82bc-5db593c6fe31": {
					"name": "SequenceFlow547"
				},
				"910787e8-1f48-4f73-83dc-66f49a969a17": {
					"name": "No"
				},
				"e25811f9-89f2-490f-ae80-0908436bc420": {
					"name": "Yes"
				},
				"5b0dbaa7-0833-4852-8544-a3e0066e354b": {
					"name": "SequenceFlow550"
				},
				"0bc7bdaa-432e-45a2-9405-b60c205429b1": {
					"name": "No"
				},
				"b37335ab-ce98-4134-8396-6fa4f72b2d36": {
					"name": "Yes"
				},
				"8cbbfa2a-4135-482e-8e03-1025a17802d8": {
					"name": "SequenceFlow559"
				},
				"0239ecf6-2bde-462e-ab54-dcaf8be3a422": {
					"name": "No"
				},
				"30862a01-6244-400c-8890-44d7f4d8475c": {
					"name": "SequenceFlow561"
				},
				"cd8798ef-1418-4af7-9969-6f67bebd2e98": {
					"name": "Yes"
				},
				"0651d623-3b71-4c71-9dd8-df42359ad9e1": {
					"name": "No"
				},
				"9291e3f6-627b-42b7-950d-d7a0d164f0b7": {
					"name": "Yes"
				},
				"785cb1c9-0e29-4cda-92f9-027cd6c963e9": {
					"name": "No"
				},
				"68ffff6d-17e1-4d54-b116-f00b434144ba": {
					"name": "Yes"
				},
				"13c8467d-cc25-4919-82aa-981c927ba3bf": {
					"name": "No"
				},
				"e498b954-ab68-4fa1-b71f-daf6d3269041": {
					"name": "SequenceFlow568"
				},
				"d08f284a-ff9b-434b-9e3b-4c688fd2fb36": {
					"name": "No"
				},
				"17796642-ed13-403d-a704-e368ef4ee67f": {
					"name": "SequenceFlow570"
				},
				"0744a753-e469-45c8-887a-d8fe06650cea": {
					"name": "SequenceFlow571"
				},
				"5e7d40e9-1f0a-4fbe-a0b4-944d5e1ceeb7": {
					"name": "Yes"
				},
				"3d919f92-7c4a-4f80-88c2-faa8232b7b13": {
					"name": "No"
				},
				"202b6dcf-65ff-41c6-af1b-3086209603bb": {
					"name": "No"
				},
				"ec30671a-4a08-44ae-bee3-8b9cb9dfd810": {
					"name": "yes"
				},
				"5c8fa50a-b66a-4c55-8e7a-b5e595365f46": {
					"name": "No"
				},
				"afca7dd8-ef3c-41b8-a481-4845463558b7": {
					"name": "Yes"
				},
				"333972f2-059e-458c-a84e-12ded628c45b": {
					"name": "SequenceFlow578"
				}
			},
			"diagrams": {
				"42fa7a2d-c526-4a02-b3ba-49b5168ba644": {}
			}
		},
		"11a9b5ee-17c0-4159-9bbf-454dcfdcd5c3": {
			"classDefinition": "com.sap.bpm.wfs.StartEvent",
			"id": "startevent1",
			"name": "Start Approval Process"
		},
		"2798f4e7-bc42-4fad-a248-159095a2f40a": {
			"classDefinition": "com.sap.bpm.wfs.EndEvent",
			"id": "endevent1",
			"name": "End Approval Process"
		},
		"06fa1e99-4325-4dea-81d7-a92461eb15e3": {
			"classDefinition": "com.sap.bpm.wfs.EndEvent",
			"id": "endevent2",
			"name": "End Approval Process"
		},
		"5c249566-d8e1-4b0f-8766-c66a3b6471eb": {
			"classDefinition": "com.sap.bpm.wfs.BoundaryEvent",
			"isCanceling": true,
			"id": "boundarytimerevent1",
			"name": "BoundaryTimerEvent1",
			"attachedToRef": "b2212f4e-72da-486e-be4f-680e98345b6b",
			"eventDefinitions": {
				"98c59642-47ee-4e32-b6b8-c1de8e088aae": {}
			}
		},
		"15e032f9-93a1-47b5-88f6-2e955a9372b3": {
			"classDefinition": "com.sap.bpm.wfs.EndEvent",
			"id": "endevent6",
			"name": "EndEvent6"
		},
		"9b854ad4-6864-4d21-8538-b72fa1ddc83c": {
			"classDefinition": "com.sap.bpm.wfs.BoundaryEvent",
			"isCanceling": true,
			"id": "boundarytimerevent2",
			"name": "BoundaryTimerEvent2",
			"attachedToRef": "8337f8c5-dd5f-4fbd-8f7c-ea374f6b36b2",
			"eventDefinitions": {
				"7ff0ae59-6f83-41ab-81e1-247c80cde3b1": {}
			}
		},
		"24a33845-446b-4d18-95b1-fd65eba5ee35": {
			"classDefinition": "com.sap.bpm.wfs.BoundaryEvent",
			"isCanceling": true,
			"id": "boundarytimerevent3",
			"name": "BoundaryTimerEvent3",
			"attachedToRef": "b7fe7321-8af8-4b59-8e14-50773a7d2406",
			"eventDefinitions": {
				"82042a91-c97f-430c-89e0-8b30a0314700": {}
			}
		},
		"06891468-ae19-4a5e-96aa-e97bb68a42c1": {
			"classDefinition": "com.sap.bpm.wfs.UserTask",
			"subject": "Request Support for ${context.accNameFormatted} ${context.Approval_subject}",
			"priority": "MEDIUM",
			"isHiddenInLogForParticipant": false,
			"supportsForward": false,
			"userInterface": "sapui5://dealsupportapp.comsapbpmRequestPresalesSupport/com.sap.bpm.RequestPresalesSupport",
			"recipientUsers": "${context.requesterDetails.id}",
			"id": "usertask1",
			"name": "Requestor Form"
		},
		"b2212f4e-72da-486e-be4f-680e98345b6b": {
			"classDefinition": "com.sap.bpm.wfs.UserTask",
			"subject": "Approve Request for ${context.accNameFormatted} ${context.Approval_subject}",
			"priority": "MEDIUM",
			"isHiddenInLogForParticipant": false,
			"supportsForward": false,
			"userInterface": "sapui5://dealsupportapp.comsapbpmPresalesRequestApproval/com.sap.bpm.PresalesRequestApproval",
			"recipientUsers": "${context.approversIds}",
			"id": "usertask2",
			"name": "Processor Form",
			"documentation": "approval of request and resource assignment",
			"dueDateRef": "98c59642-47ee-4e32-b6b8-c1de8e088aae"
		},
		"d8ba0d32-0e90-49ca-927a-3931f0881f9e": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway1",
			"name": "what is a decision?",
			"default": "c89124c5-dab8-481c-8307-beef67357aeb"
		},
		"fdf35015-9267-4b31-ba80-49759b8bb63b": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask2",
			"name": "Notify Requester About Rework",
			"mailDefinitionRef": "71ad5630-5148-4aa9-b810-d19b107aa21c"
		},
		"99b92cdc-05ca-4bf6-9cba-bbe8e381696c": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/TransformInitializeRequest.js",
			"id": "scripttask2",
			"name": "Process Initialize Request"
		},
		"8dcd09bd-99d5-4347-9bfb-102a27f1a949": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask8",
			"name": "Notify About Request Creation / Update",
			"mailDefinitionRef": "e3c79aa7-cfc9-48b0-914c-925e5315bb67"
		},
		"bb21eb22-a546-402c-b871-3b0fbd7b4d97": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessRequestCreation.js",
			"id": "scripttask3",
			"name": "Process Request Creation"
		},
		"4490dec5-f12b-4640-838f-09c439a9e1aa": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask9",
			"name": "Notify Approver",
			"mailDefinitionRef": "7e5d6e1f-3e4b-4316-8def-97efa27a04e7"
		},
		"81bd8d37-a4b5-43e8-9d31-1cf5b701aaff": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_CPI_Neo",
			"destinationSource": "consumer",
			"path": "/http/presales/cp-workflow-req",
			"httpMethod": "POST",
			"requestVariable": "${context.CPICalls.getDataFromCRM.Request}",
			"responseVariable": "${context.CPICalls.getDataFromCRM.Response}",
			"id": "servicetask4",
			"name": "Get Opp Details From CRM"
		},
		"35021842-30c7-473a-bdbe-d322a823068f": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessApproverSendBack.js",
			"id": "scripttask5",
			"name": "Process Approver's Send Back Decision"
		},
		"31bddefd-3970-487e-ae69-8c79c03d2b4e": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessApproverRejectDecision.js",
			"id": "scripttask6",
			"name": "Process Approver's Reject Decision"
		},
		"3e842588-71b2-4462-83ca-f9ab3743e423": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessApproverApproveDecision.js",
			"id": "scripttask7",
			"name": "Process Approver's Approve Decision"
		},
		"056b1a11-e7a7-4ac2-bfe7-16e06a4e3b17": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/CleanUpAfterRework.js",
			"id": "scripttask12",
			"name": "Do Clean-Up"
		},
		"2e2f15da-55b8-4578-81b9-740ff2b6a218": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/AssignSubstituteApprover.js",
			"id": "scripttask13",
			"name": "Assign Substitute Approver"
		},
		"9d325103-1963-4f0e-a1d1-f409d3dc59d5": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask10",
			"name": "Notify Substitute Approver",
			"mailDefinitionRef": "4bdf6465-e88a-41d5-b713-9412db07e0c2"
		},
		"8337f8c5-dd5f-4fbd-8f7c-ea374f6b36b2": {
			"classDefinition": "com.sap.bpm.wfs.UserTask",
			"subject": "Approve Request for ${context.accNameFormatted} ${context.Approval_subject}",
			"priority": "MEDIUM",
			"isHiddenInLogForParticipant": false,
			"supportsForward": false,
			"userInterface": "sapui5://dealsupportapp.comsapbpmPresalesRequestApproval/com.sap.bpm.PresalesRequestApproval",
			"recipientUsers": "${context.subtitutorsIds}",
			"id": "usertask4",
			"name": "Processor Form",
			"dueDateRef": "7ff0ae59-6f83-41ab-81e1-247c80cde3b1"
		},
		"233a6b4d-a2b6-458f-bae8-c7bc788013af": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway3",
			"name": "decision",
			"default": "29abf8e7-c8a3-4777-81a0-49ec1fe6ccbd"
		},
		"3cfbbea0-301e-47fe-b1cb-1162c50fb37a": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessTerminateTask.js",
			"id": "scripttask14",
			"name": "Process Task Termination"
		},
		"854f2bea-0180-42e1-9f60-4d102de7726d": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessApproverForwardDecision.js",
			"id": "scripttask15",
			"name": "Process Approver Forward Decision"
		},
		"bdcfb412-7dd8-43c5-b6ec-2c9af8b32b5a": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessResourceRequest.js",
			"id": "scripttask16",
			"name": "Process Resources Request"
		},
		"e21e9ddd-8ffe-497a-ae19-c05a308de69b": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_CPI_Neo",
			"destinationSource": "consumer",
			"path": "/http/presales/cp-workflow-req",
			"httpMethod": "POST",
			"requestVariable": "${context.CPICalls.getResourcesFromCRM.Request}",
			"responseVariable": "${context.CPICalls.getResourcesFromCRM.Response}",
			"id": "servicetask10",
			"name": "Get Additional Approvers Data"
		},
		"30c8a446-373c-4f80-94ad-066f5a25dbbc": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessResourceResponse.js",
			"id": "scripttask17",
			"name": "Process Resources Response"
		},
		"d9f5c825-a8f0-4fdb-8f9d-3685b671d121": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessResourceRequest.js",
			"id": "scripttask18",
			"name": "Process Resource Request"
		},
		"a2ba93b6-86bb-4bf0-a149-037fa740d0f7": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessResourceResponse.js",
			"id": "scripttask19",
			"name": "Process Resources Response"
		},
		"7567c7a1-d73a-4be2-9f55-def62b30ddca": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_CPI_Neo",
			"destinationSource": "consumer",
			"path": "/http/presales/cp-workflow-req",
			"httpMethod": "POST",
			"requestVariable": "${context.CPICalls.getResourcesFromCRM.Request}",
			"responseVariable": "${context.CPICalls.getResourcesFromCRM.Response}",
			"id": "servicetask12",
			"name": "Get Additional Approvers Data"
		},
		"ff47561f-1004-41a7-ae18-5de2cf4400ef": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessManagerApproval.js",
			"id": "scripttask20",
			"name": "Manager Approval"
		},
		"00dd4b02-bd67-4515-ae82-999f1c8f3f4a": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask11",
			"name": "Notify Request Not Been Processed",
			"mailDefinitionRef": "c3a9ea3f-906e-40f0-8ba2-0cd2048aa210"
		},
		"bd2a38e1-d493-4123-8ee1-876a83a6f5f8": {
			"classDefinition": "com.sap.bpm.wfs.UserTask",
			"subject": "Approve Request for Presales Support of Opportunity ${context.opportunityId}",
			"priority": "MEDIUM",
			"isHiddenInLogForParticipant": false,
			"supportsForward": false,
			"userInterface": "sapui5://dealsupportapp.comsapbpmPresalesRequestApproval/com.sap.bpm.PresalesRequestApproval",
			"recipientUsers": "${context.subtitutorsIds}",
			"id": "usertask5",
			"name": "Processor Form"
		},
		"50acc690-0ad0-473a-a524-2e56b078405b": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/NotifyNotProcessedNotification.js",
			"id": "scripttask21",
			"name": "Process Not Processed Notification"
		},
		"3d3cf404-1e67-41e1-9348-c87eeb0397bf": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway6",
			"name": "Manager Approval Gate"
		},
		"b9f3fd94-bc43-40b0-b03f-6cfa4e1fb969": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway7",
			"name": "Manger Task Processed"
		},
		"2ec0658e-6a17-4d0d-90ea-62c4336623b5": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway8",
			"name": "Substitute Task Processed"
		},
		"08e8ea17-39f4-48cc-83cf-5fe60227f741": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway9",
			"name": "is req area SLE?",
			"default": "ff29f679-cb09-4ff6-9830-80537ff53755"
		},
		"aaa547a7-dc46-44ab-8255-960716a6bcae": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.DBCall.GetCAManagers}",
			"responseVariable": "${context.DBCall.GetCAManagers.Response}",
			"id": "servicetask13",
			"name": "Get CA Industry Managers",
			"documentation": "fetch CAP OData service"
		},
		"0e163838-d068-4dee-a204-ed54fb74af92": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessResponseCAP.js",
			"id": "scripttask24",
			"name": "Process Response"
		},
		"9f42ea35-64e3-4e39-ad1c-963db78f4393": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway10",
			"name": "list not empty?",
			"default": "9f702c5c-c132-4c75-8ddd-91aeb3cdc3c1"
		},
		"d58f5ffb-c7f1-4d48-a312-241110ebf41e": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/GetCAManagersData.js",
			"id": "scripttask26",
			"name": "Prepare Payload",
			"documentation": "to get CA Managers details (emails)"
		},
		"701fc339-9099-4f8b-8058-7100f5ae4c5d": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_CPI_Neo",
			"destinationSource": "consumer",
			"path": "/http/presales/cp-workflow-req",
			"httpMethod": "POST",
			"requestVariable": "${context.CPICalls.getCAManagersDetails.Request}",
			"responseVariable": "${context.CPICalls.getCAManagersDetails.Response}",
			"id": "servicetask14",
			"name": "Get CA Managers Details"
		},
		"caf7be2b-e43a-4f14-a826-9cfb68ab4172": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessCAManagersGetCall.js",
			"id": "scripttask27",
			"name": "Process Response"
		},
		"efba8741-f361-4ace-9a71-eb817f466415": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask12",
			"name": "Notify CA Managers",
			"mailDefinitionRef": "67a9e533-d9ac-48ef-b077-8ba84a9773fc"
		},
		"d204364a-1439-481f-9b7c-9c638f58d815": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway11",
			"name": "was reworked?",
			"default": "3e61da83-19ba-4b9a-97e8-2893c9de6e7d"
		},
		"0479076d-17a8-470b-8382-d5459eb052a3": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessWfInstanceCreateRequest.js",
			"id": "scripttask28",
			"name": "Process Wf Instance Request"
		},
		"0c9df6a2-4743-4ca1-8068-f61ecf547f56": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.DBCall.Request}",
			"responseVariable": "${context.DBCall.Response}",
			"headers": [{
				"name": "Content-Type",
				"value": "application/json;IEEE754Compatible=true"
			}],
			"id": "servicetask16",
			"name": "Call CAP Batch"
		},
		"ef831483-933c-4efb-998b-082196738ef1": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessWfInstanceSendBackRequest.js",
			"id": "scripttask29",
			"name": "Process Wf Instance Send Back"
		},
		"37ec0a64-b924-4866-a246-b6e91fc7fa06": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessWfInstanceSubstituteRequest.js",
			"id": "scripttask31",
			"name": "Process Wf Instance Substitute"
		},
		"4d353ff7-225a-4475-abbd-ca72eb0b8974": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.DBCall.Request}",
			"responseVariable": "${context.DBCall.Response}",
			"headers": [{
				"name": "Content-Type",
				"value": "application/json;IEEE754Compatible=true"
			}],
			"id": "servicetask19",
			"name": "WfInstance Update"
		},
		"6a35041a-d16e-4cbc-9e6a-6aa51d639be2": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessWfInstanceApproverApproveRequest.js",
			"id": "scripttask32",
			"name": "Process Wf Instance Approver Approve"
		},
		"7048bfa2-ab10-4afa-af8a-d038f581ae65": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.DBCall.Request}",
			"responseVariable": "${context.DBCall.Response}",
			"headers": [{
				"name": "Content-Type",
				"value": "application/json;IEEE754Compatible=true"
			}],
			"id": "servicetask20",
			"name": "WfInstance Update"
		},
		"13adc3d3-6b22-4055-ae85-0401add7744c": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessApproverRejectWfInstanceComplete.js",
			"id": "scripttask33",
			"name": "Process Wf Instance Complete"
		},
		"21b87d2f-678d-4b03-9d16-a2bef8a4cb18": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.DBCall.Request}",
			"responseVariable": "${context.DBCall.Response}",
			"headers": [{
				"name": "Content-Type",
				"value": "application/json;IEEE754Compatible=true"
			}],
			"id": "servicetask21",
			"name": "WfInstance Complete"
		},
		"8430762c-d6c3-4ade-bc13-3db24226917f": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessWfInstanceForwardRequest.js",
			"id": "scripttask34",
			"name": "Process Wf Instance Forward"
		},
		"a8cd3376-6607-467a-ad8a-e981bdb681d9": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"xsrfPath": "",
			"requestVariable": "${context.DBCall.Request}",
			"responseVariable": "${context.DBCall.Response}",
			"headers": [{
				"name": "Content-Type",
				"value": "application/json;IEEE754Compatible=true"
			}],
			"id": "servicetask22",
			"name": "WfInstance Update"
		},
		"eeff2bdf-7aaa-47a3-b8f0-134ab18e9e8e": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessWfInstanceCompleteSuccess.js",
			"id": "scripttask36",
			"name": "Process WfInstance Complete Success"
		},
		"1d99fb56-2463-47d5-b95c-b61fddfa93e4": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.DBCall.Request}",
			"responseVariable": "${context.DBCall.Response}",
			"headers": [{
				"name": "Content-Type",
				"value": "application/json;IEEE754Compatible=true"
			}],
			"id": "servicetask24",
			"name": "Process WfInstance Complete"
		},
		"2d5fb220-87ab-4e1d-8095-c41dc8a6306d": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/resources/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.areaPathCall.Request}",
			"responseVariable": "${context.areaPathCall.Response}",
			"id": "servicetask25",
			"name": "Get Approvers"
		},
		"ad99fde2-287e-4495-9b62-ef4fc532adf0": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/resources/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.areaPathCall.Request}",
			"responseVariable": "${context.areaPathCall.Response}",
			"id": "servicetask26",
			"name": "Get Approvers"
		},
		"abd1eb59-b34c-489e-81da-2426d5ccd452": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway14",
			"name": "ExclusiveGateway14"
		},
		"c8116791-4591-4339-b807-e69c36f74171": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/CalculateDueDates.js",
			"id": "scripttask38",
			"name": "Calculate Due Date",
			"documentation": "https://port8888-workspaces-ws-1jzvu.eu10.applicationstudio.cloud.sap/1.1000.22/webapp/index.html?sap-ide-static-ws&sap-ide-iframe&static-ws-ui5-root=https%3A%2F%2Fsapui5.hana.ondemand.com%2F1.71.75%2Fresources%2F#"
		},
		"354d2614-4245-499d-981c-800e57c8b91b": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway15",
			"name": "ExclusiveGateway15"
		},
		"f275da51-5617-4333-83d9-aff034b1c70e": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/PrepCallCAManagers.js",
			"id": "scripttask39",
			"name": "Prepare Batch Call CA Managers"
		},
		"67dac61a-5d8d-403c-93a1-a56f3823a247": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway16",
			"name": "was Sent Back?",
			"default": "1c9a1904-19ca-4191-a3c0-2ec00228eaca"
		},
		"50aa8137-fd50-44ed-a195-e4765d4f1c69": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessWfInstanceComplete.js",
			"id": "scripttask40",
			"name": "Set Wf Instance to Complete"
		},
		"e62a9b1b-ce64-4fc4-b605-617b23ded67a": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.DBCall.Request}",
			"responseVariable": "${context.DBCall.Response}",
			"id": "servicetask28",
			"name": "Set Wf Instance to Complete"
		},
		"8242f728-507b-4793-b9fb-629dc3cc79e2": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway18",
			"name": "retry?",
			"default": "47ed3840-7e44-4957-a7b6-7d0f80d8cac1"
		},
		"5461095c-4eec-4521-ab96-7e568c905bff": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/CheckBatchCall.js",
			"id": "scripttask43",
			"name": "Check Batch Call"
		},
		"898272e4-5a6b-4718-8c09-8aedec202321": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway19",
			"name": "retry?",
			"default": "8c7d2af6-903b-4a8f-80fe-b35409ee5a5b"
		},
		"68ed2872-5482-465b-b560-49979b07b5dd": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/CheckBatchCallCA.js",
			"id": "scripttask46",
			"name": "Check Batch Call"
		},
		"fb8a7793-4c34-4ad7-8c40-48079bb1661f": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway22",
			"name": "retry?",
			"default": "34ed1d1c-df8f-4100-ae31-42e0a196de43"
		},
		"2bcd6216-3f70-461b-92b7-cf05f6d439ec": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/CheckBatchCall.js",
			"id": "scripttask47",
			"name": "Check Batch Call"
		},
		"df48d131-ba3e-4f87-8430-e9467164626b": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway23",
			"name": "retry?",
			"default": "1c436edf-5127-4046-b900-0e4dd4fe63ff"
		},
		"ade99b22-6ac9-4e1d-8811-1534d90745e8": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway24",
			"name": "retry?",
			"default": "c709ae80-5a3a-4a14-a6ef-833e31546070"
		},
		"a552781b-d824-4782-a4da-5bf466645df7": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/CheckBatchCall.js",
			"id": "scripttask48",
			"name": "Check Batch Call"
		},
		"3cfb8f37-57c4-4fef-abcb-fb6c90d03197": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway25",
			"name": "retry?",
			"default": "f65eaf2d-b91e-46ef-8ca8-2d8d661d6d8b"
		},
		"77d837e2-2e1a-40ad-88a3-73192fbfd1c0": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/CheckBatchCall.js",
			"id": "scripttask50",
			"name": "Check Batch Call"
		},
		"ed625063-4a14-4208-a032-83a5f425bccc": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway27",
			"name": "retry?",
			"default": "fd28d3ea-e700-47e9-a55b-974a5c22c44e"
		},
		"b6021f22-e46b-417e-b1bb-872c603b5736": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/CheckBatchCall.js",
			"id": "scripttask53",
			"name": "Check Batch Call"
		},
		"9dd72e42-191f-468a-9647-a628c8fd17e6": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway30",
			"name": "retry?",
			"default": "701e242d-aa44-43d2-a412-438b2eb725ed"
		},
		"0cbbabb8-3988-416b-b310-77659b4225b6": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"xsrfPath": "",
			"requestVariable": "${context.DBCall.WfInstanceRequest}",
			"responseVariable": "${context.DBCall.WfInstanceResponse}",
			"id": "servicetask29",
			"name": "Create WfInstance"
		},
		"8e4664d1-e4bc-4b0f-8386-e37aa621fc85": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway31",
			"name": "retry?",
			"default": "5e4ff83f-97cf-45d5-bfeb-2806c6ab3edf"
		},
		"acd3716f-1a35-4503-9739-85361bef5f85": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/CheckWfInstanceCreate.js",
			"id": "scripttask54",
			"name": "Check WfInstance Create"
		},
		"c09525f9-e84e-486c-9ee4-3255981f9f30": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/CheckForReworkAndReject.js",
			"id": "scripttask55",
			"name": "Check For Rework and Reject"
		},
		"19dbe20f-9499-4d84-b2a6-59f2577bc887": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway33",
			"name": "Is Rework?",
			"default": "fcd9609c-ab96-4009-b528-74a340aaaa80"
		},
		"83164bc9-e708-4115-89f1-90702519e7d9": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessResourceApproveDecisionMultiple.js",
			"id": "scripttask58",
			"name": "Process Resource's Approve Decision (Multiple)"
		},
		"56449570-8bd1-47f8-8a8b-e8cd7d8bec49": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway34",
			"name": "Check ResApprove Count",
			"default": "76c5606f-384a-4e96-895f-53cc34961857"
		},
		"15a3e187-5366-4134-b217-f1fa7fa383ae": {
			"classDefinition": "com.sap.bpm.wfs.ReferencedSubflow",
			"definitionId": "subflow_multiple_resource",
			"multiInstanceLoopCharacteristics": {
				"type": "parallel",
				"collection": "${context.Assignment}",
				"completionCondition": "${context.Assignment[loop.counter].ResDecision==\"Send Back to Requestor\"}"
			},
			"inParameters": [{
				"sourceExpression": "${context.substituteApproverDetails}",
				"targetVariable": "${context.substituteApproverDetails}"
			}, {
				"sourceExpression": "${context.primaryApproverDetails}",
				"targetVariable": "${context.primaryApproverDetails}"
			}, {
				"sourceExpression": "${context.NewRequest}",
				"targetVariable": "${context.NewRequest}"
			}, {
				"sourceExpression": "${context.UserTaskLabelValue}",
				"targetVariable": "${context.UserTaskLabelValue}"
			}, {
				"sourceExpression": "${context.EmailTemplateVars}",
				"targetVariable": "${context.EmailTemplateVars}"
			}, {
				"sourceExpression": "${context.EngagementType}",
				"targetVariable": "${context.EngagementType}"
			}, {
				"sourceExpression": "${context.Assignment}",
				"targetVariable": "${context.AllAssignmentDetails}"
			}, {
				"sourceExpression": "${context.WfInsProc_DelURLs}",
				"targetVariable": "${context.WfInsProc_DelURLs}"
			}, {
				"sourceExpression": "${context.isSubstitute}",
				"targetVariable": "${context.isSubstitute}"
			}, {
				"sourceExpression": "${context.resourcecomment}",
				"targetVariable": "${context.resourcecomment}"
			}, {
				"sourceExpression": "${context.approverData.Shortname}",
				"targetVariable": "${context.approverData.Shortname}"
			}, {
				"sourceExpression": "${context.NewOppDetails}",
				"targetVariable": "${context.NewOppDetails}"
			}, {
				"sourceExpression": "${context.requesterDetails}",
				"targetVariable": "${context.requesterDetails}"
			}, {
				"sourceExpression": "${context.approverData.id}",
				"targetVariable": "${context.approverData.id}"
			}, {
				"sourceExpression": "${context.ProcessorComment}",
				"targetVariable": "${context.ProcessorComment}"
			}, {
				"sourceExpression": "${context.approverurl}",
				"targetVariable": "${context.approverurl}"
			}, {
				"sourceExpression": "${context.Assignment[loop.counter].comments}",
				"targetVariable": "${context.assignmentComments}"
			}, {
				"sourceExpression": "${context.decision_ID}",
				"targetVariable": "${context.decision_ID}"
			}, {
				"sourceExpression": "${context.RefrenceID}",
				"targetVariable": "${context.RefrenceID}"
			}, {
				"sourceExpression": "${context.RequestID}",
				"targetVariable": "${context.RequestID}"
			}, {
				"sourceExpression": "${context.parentInstanceID}",
				"targetVariable": "${context.parentInstanceID}"
			}, {
				"sourceExpression": "${context.processor_email}",
				"targetVariable": "${context.processor_email}"
			}, {
				"sourceExpression": "${context.UT_refID}",
				"targetVariable": "${context.UT_refID}"
			}, {
				"sourceExpression": "${context.CurrentStepValue}",
				"targetVariable": "${context.CurrentStepValue}"
			}, {
				"sourceExpression": "${context.currentStepID}",
				"targetVariable": "${context.currentStepID}"
			}, {
				"sourceExpression": "${context.oppOrgId}",
				"targetVariable": "${context.oppOrgId}"
			}, {
				"sourceExpression": "${context.aResourceProfileApprovers}",
				"targetVariable": "${context.aResourceProfileApprovers}"
			}, {
				"sourceExpression": "${context.selectedProfitCenter}",
				"targetVariable": "${context.selectedProfitCenter}"
			}, {
				"sourceExpression": "${context.isResourceProfile}",
				"targetVariable": "${context.isResourceProfile}"
			}, {
				"sourceExpression": "${context.CurrentStateValue}",
				"targetVariable": "${context.CurrentStateValue}"
			}, {
				"sourceExpression": "${context.IgnoreMessage}",
				"targetVariable": "${context.IgnoreMessage}"
			}, {
				"sourceExpression": "${context.Approval_subject}",
				"targetVariable": "${context.Approval_subject}"
			}, {
				"sourceExpression": "${context.OpRev}",
				"targetVariable": "${context.OpRev}"
			}, {
				"sourceExpression": "${context.CRev}",
				"targetVariable": "${context.CRev}"
			}, {
				"sourceExpression": "${context.Opp_ID}",
				"targetVariable": "${context.Opp_ID}"
			}, {
				"sourceExpression": "${context.CRev_L}",
				"targetVariable": "${context.CRev_L}"
			}, {
				"sourceExpression": "${context.OpRev_L}",
				"targetVariable": "${context.OpRev_L}"
			}, {
				"sourceExpression": "${context.Opp_Desc}",
				"targetVariable": "${context.Opp_Desc}"
			}, {
				"sourceExpression": "${context.IndustryName}",
				"targetVariable": "${context.IndustryName}"
			}, {
				"sourceExpression": "${context.PE_Name}",
				"targetVariable": "${context.PE_Name}"
			}, {
				"sourceExpression": "${context.RequestType}",
				"targetVariable": "${context.RequestType}"
			}, {
				"sourceExpression": "${context.OrgType}",
				"targetVariable": "${context.OrgType}"
			}, {
				"sourceExpression": "${context.OrgID}",
				"targetVariable": "${context.OrgID}"
			}, {
				"sourceExpression": "${context.workflowFileUploadId}",
				"targetVariable": "${context.workflowFileUploadId}"
			}, {
				"sourceExpression": "${context.CPICalls.getDataFromCRM.Response}",
				"targetVariable": "${context.CPICalls.getDataFromCRM.Response}"
			}, {
				"sourceExpression": "${context.requestDetails}",
				"targetVariable": "${context.requestDetails}"
			}, {
				"sourceExpression": "${context.dealInfo}",
				"targetVariable": "${context.dealInfo}"
			}, {
				"sourceExpression": "${context.dealInfoForDb}",
				"targetVariable": "${context.dealInfoForDb}"
			}, {
				"sourceExpression": "${context.extSystemsUrls}",
				"targetVariable": "${context.extSystemsUrls}"
			}, {
				"sourceExpression": "${context.approverData.fullName}",
				"targetVariable": "${context.approverData.fullName}"
			}, {
				"sourceExpression": "${context.lastApproverComments}",
				"targetVariable": "${context.lastApproverComments}"
			}, {
				"sourceExpression": "${context.Assignment[loop.counter].AssignmentID}",
				"targetVariable": "${context.AssignmentID}"
			}, {
				"sourceExpression": "${context.Assignment[loop.counter].NominatedResources}",
				"targetVariable": "${context.NominatedResources}"
			}, {
				"sourceExpression": "${context.approverData.email}",
				"targetVariable": "${context.approverData.email}"
			}, {
				"sourceExpression": "${context.accountName}",
				"targetVariable": "${context.accountName}"
			}, {
				"sourceExpression": "${context.accNameFormatted}",
				"targetVariable": "${context.accNameFormatted}"
			}, {
				"sourceExpression": "${context.opportunityId}",
				"targetVariable": "${context.opportunityId}"
			}, {
				"sourceExpression": "${context.oppOwnerDetails}",
				"targetVariable": "${context.oppOwnerDetails}"
			}, {
				"sourceExpression": "${context.accOwnerDetails}",
				"targetVariable": "${context.accOwnerDetails}"
			}, {
				"sourceExpression": "${context.approvalHistory}",
				"targetVariable": "${context.approvalHistory}"
			}, {
				"sourceExpression": "${context.requestArea}",
				"targetVariable": "${context.requestArea}"
			}, {
				"sourceExpression": "${context.accountId}",
				"targetVariable": "${context.accountId}"
			}, {
				"sourceExpression": "${context.Email_Signature}",
				"targetVariable": "${context.Email_Signature}"
			}, {
				"sourceExpression": "${context.DBCall.ResourcesDeleteURLs}",
				"targetVariable": "${context.DBCall.ResourcesDeleteURLs}"
			}, {
				"sourceExpression": "${context.WfID_PresalesRequestApproval}",
				"targetVariable": "${context.WfID_PresalesRequestApproval}"
			}],
			"outParameters": [{
				"sourceExpression": "${context.WfInsProc_DelURLs}",
				"targetVariable": "${context.WfInsProc_DelURLs}"
			}, {
				"sourceExpression": "${context.EngagementType}",
				"targetVariable": "${context.EngagementType}"
			}, {
				"sourceExpression": "${context.AllAssignmentDetails}",
				"targetVariable": "${context.AllAssignmentDetails}"
			}, {
				"sourceExpression": "${context.selectedProfitCenter}",
				"targetVariable": "${context.selectedProfitCenter}"
			}, {
				"sourceExpression": "${context.aResourceProfileApprovers}",
				"targetVariable": "${context.aResourceProfileApprovers}"
			}, {
				"sourceExpression": "${context.approverData.Shortname}",
				"targetVariable": "${context.approverData.Shortname}"
			}, {
				"sourceExpression": "${context.resourcecomment}",
				"targetVariable": "${context.resourcecomment}"
			}, {
				"sourceExpression": "${context.RefrenceID}",
				"targetVariable": "${context.RefrenceID}"
			}, {
				"sourceExpression": "${context.RequestID}",
				"targetVariable": "${context.RequestID}"
			}, {
				"sourceExpression": "${context.decision_ID}",
				"targetVariable": "${context.decision_ID}"
			}, {
				"sourceExpression": "${context.ResSendBackDecision}",
				"targetVariable": "${context.ResSendBackDecision}"
			}, {
				"sourceExpression": "${context.UT_refID}",
				"targetVariable": "${context.UT_refID}"
			}, {
				"sourceExpression": "${context.ResourcesUserTaskID}",
				"targetVariable": "${context.Assignment[loop.counter].ResourcesUserTaskID}"
			}, {
				"sourceExpression": "${context.resourcetaskID}",
				"targetVariable": "${context.Assignment[loop.counter].resourcetaskID}"
			}, {
				"sourceExpression": "${context.currentProcessor.id}",
				"targetVariable": "${context.Assignment[loop.counter].ResCurrentProcessor.userId}"
			}, {
				"sourceExpression": "${context.NominatedResources}",
				"targetVariable": "${context.Assignment[loop.counter].NominatedResources}"
			}, {
				"sourceExpression": "${context.approvalHistory}",
				"targetVariable": "${context.approvalHistory}"
			}, {
				"sourceExpression": "${context.DBCall.ResourcesDeleteURLs}",
				"targetVariable": "${context.DBCall.ResourcesDeleteURLs}"
			}, {
				"sourceExpression": "${context.decision}",
				"targetVariable": "${context.Assignment[loop.counter].ResDecision}"
			}, {
				"sourceExpression": "${context.currentProcessor.fullName}",
				"targetVariable": "${context.Assignment[loop.counter].ResCurrentProcessor.fullname}"
			}, {
				"sourceExpression": "${context.currentProcessorRole}",
				"targetVariable": "${context.Assignment[loop.counter].ResCurrentProcessorRole}"
			}, {
				"sourceExpression": "${context.currentStepName}",
				"targetVariable": "${context.Assignment[loop.counter].ResCurrentStepName}"
			}, {
				"sourceExpression": "${context.comments}",
				"targetVariable": "${context.Assignment[loop.counter].ResComments}"
			}, {
				"sourceExpression": "${context.currentProcessor.email}",
				"targetVariable": "${context.Assignment[loop.counter].ResCurrentProcessor.email}"
			}, {
				"sourceExpression": "${context.assignedCRMRoleData}",
				"targetVariable": "${context.Assignment[loop.counter].ResAssignedRoleData}"
			}],
			"id": "referencedsubflow3",
			"name": "ReferencedSubflow3"
		},
		"586b13f2-76b5-4ed7-a64c-ed62c9f185d8": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway36",
			"name": "Is Reject?",
			"default": "7179827e-2dba-4c0d-a86f-07fc4fb8320e"
		},
		"76998587-b436-46d5-9654-f1d5b54cea7c": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessResourceSendBack.js",
			"id": "scripttask61",
			"name": "Process Resource's Send Back Decision"
		},
		"cf128b14-466a-48b6-bbcf-c5ac8fc4c7b9": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway37",
			"name": "Is Resource Reject?",
			"default": "5b84c5e1-c843-41c0-ab5b-376262e1869a"
		},
		"bc4a7c70-7b35-4903-845d-70c4e5f3242f": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ClearResourceReject.js",
			"id": "scripttask62",
			"name": "Clear Resource Reject"
		},
		"77009387-aab8-4f42-8f7c-f4e10985f460": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask1",
			"name": "Notify Requester About Rejection",
			"mailDefinitionRef": "7e0efa31-790f-4201-9262-3fb36ff6bbfa"
		},
		"884ff1e1-f344-46c9-9cac-f8cf678a5a78": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.DBCall.Request}",
			"responseVariable": "${context.DBCall.Response}",
			"id": "servicetask31",
			"name": "WfInstance Update"
		},
		"e55968cd-4af7-4797-9fc6-466f04cfbeea": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessWfInstanceResourceAllReject.js",
			"id": "scripttask63",
			"name": "Process WfInstance Resource AllReject"
		},
		"d646474d-3529-41a6-ae57-d4a43aa49800": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.DBCall.Request}",
			"responseVariable": "${context.DBCall.Response}",
			"id": "servicetask32",
			"name": "WfInstance Update"
		},
		"3634b4b9-98ac-4d8c-96cf-bf11d09e060f": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/CheckBatchCall.js",
			"id": "scripttask64",
			"name": "Check Batch Call"
		},
		"4db9678a-18f4-4646-939c-a4e6effc31ee": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway39",
			"name": "retry?",
			"default": "b1fe490a-52b0-42c0-b0d1-4425931edf89"
		},
		"700a6d8f-16e3-4952-9283-2eeb3bf5d7ad": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ContextCleanup.js",
			"id": "scripttask65",
			"name": "Context Cleanup"
		},
		"e60d84ca-b7e8-4f08-8390-059aab21d6bf": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway40",
			"name": "Reject  Gateway "
		},
		"150a24e2-88c0-4dcb-a84c-20d93b376d7d": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway41",
			"name": "Is Approve ?",
			"default": "b89c7f06-ae33-4900-a4c8-f95d85887f72"
		},
		"1add78a6-c2b5-4286-a14b-eb75518972a4": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/FilterApproveAndRejectDecisions.js",
			"id": "scripttask56",
			"name": "Filter Approve and Reject Decisions "
		},
		"151ee67a-db52-4540-8b6a-f591a7b71f4a": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/CreateWiRoleAssigned.js",
			"id": "scripttask66",
			"name": "Create WiRoleAssigned"
		},
		"af0a4614-e737-4ead-b301-67aa489ca082": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.DBCall.Request}",
			"responseVariable": "${context.DBCall.Response}",
			"id": "servicetask33",
			"name": "WfRoleAssigned Create"
		},
		"354a4d17-0c0c-4245-bfca-fe0064bfad23": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/CheckBatchCall.js",
			"id": "scripttask68",
			"name": "Check Batch Call"
		},
		"c00f2a6f-6814-4c28-a548-49650d55e9f2": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway42",
			"name": "retry ?",
			"default": "ca6f3230-2b40-4163-9c31-2c5b9c00a775"
		},
		"a92f0f95-9eb7-414a-9dbb-1d9df0785f8c": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway45",
			"name": "Check First Time ReqArea",
			"default": "4dfa1b2a-2536-4efa-8427-7efa45ef68f3"
		},
		"f5065acc-ca90-4eb5-b50c-5499b2d3a333": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway46",
			"name": "Routing Check",
			"default": "eaef82ac-a7dc-4b3b-94a5-19dffbdb5a52"
		},
		"41c3c126-fb82-4a1d-b79c-765a13db7625": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway47",
			"name": "IsAccount",
			"default": "a0226c8b-64d3-4426-8403-7d082dd38502"
		},
		"00a7fee2-04b8-47c7-a454-81a8431932a4": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway52",
			"name": "IsAccount",
			"default": "5eb4b3c7-c7e8-4ce3-a618-3794f5a6dc64"
		},
		"3868830c-d756-46b5-bf27-6a6af1cefb8e": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessAccountDetailsUpdate.js",
			"id": "scripttask72",
			"name": "Update Account Details"
		},
		"ed0992f0-1881-4231-bded-2d6fae63bfcb": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/Account",
			"httpMethod": "POST",
			"requestVariable": "${context.DBCall.AccountDataUpdateRequest}",
			"responseVariable": "${context.DBCall.AccountDataUpdateResponse}",
			"id": "servicetask35",
			"name": "Update Account"
		},
		"188c8349-34ce-4d4f-bb98-1b8c5e8de814": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/PrepareContentforOldertasks.js",
			"id": "scripttask73",
			"name": "Prepare Content for Older tasks"
		},
		"f77539b1-89c8-4ef9-82ca-ee0ffb34b3ab": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway53",
			"name": "isAccount",
			"default": "048510c6-d11d-44d2-b520-292930deb72e"
		},
		"8b42abcb-2e53-48d1-afdd-be0b1825b791": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/filterAutoStaffedResource.js",
			"id": "scripttask75",
			"name": "filter Auto Staffed Resource"
		},
		"79b7e998-0eb2-45e9-b322-2e5d832d4957": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway57",
			"name": "isAccount/IO_Owner",
			"default": "6dda97f8-aa4d-4713-92c5-fef77fc49c28"
		},
		"6ee8995c-c5b8-4bd7-8a79-f768b73174fe": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway60",
			"name": "ExclusiveGateway60"
		},
		"4276f295-a1b2-40c0-bce3-304fffe6aa62": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessIO_OwnerApproveAndRejectDecision.js",
			"id": "scripttask81",
			"name": "Process IO_Owner Approve/Reject Decision"
		},
		"ff37bfbb-d8b6-451b-a1b9-e762b6e8347f": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.DBCall.Request}",
			"responseVariable": "${context.DBCall.Response}",
			"id": "servicetask42",
			"name": "WfInstance Update"
		},
		"e9776d6f-986e-4f0e-9385-50ed77dbbc26": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/UpdateIOdetailsToWfInstance.js",
			"id": "scripttask82",
			"name": "Process Wf Instance Io_Owner"
		},
		"28a0934a-bd2f-4d09-8e45-144459be00d5": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessNominatedIO_Owners.js",
			"id": "scripttask84",
			"name": "Process Nominated IO Owners"
		},
		"50af6a3b-96a3-4c1e-b141-0e14052384f8": {
			"classDefinition": "com.sap.bpm.wfs.ReferencedSubflow",
			"definitionId": "subflow_multiple_io_owner",
			"multiInstanceLoopCharacteristics": {
				"type": "parallel",
				"collection": "${context.io_OwnerResource}"
			},
			"inParameters": [{
				"sourceExpression": "${context.substituteApproverDetails}",
				"targetVariable": "${context.substituteApproverDetails}"
			}, {
				"sourceExpression": "${context.Assignment}",
				"targetVariable": "${context.Assignment}"
			}, {
				"sourceExpression": "${context.primaryApproverDetails}",
				"targetVariable": "${context.primaryApproverDetails}"
			}, {
				"sourceExpression": "${context.NewRequest}",
				"targetVariable": "${context.NewRequest}"
			}, {
				"sourceExpression": "${context.UserTaskLabelValue}",
				"targetVariable": "${context.UserTaskLabelValue}"
			}, {
				"sourceExpression": "${context.EmailTemplateVars}",
				"targetVariable": "${context.EmailTemplateVars}"
			}, {
				"sourceExpression": "${context.EngagementType}",
				"targetVariable": "${context.EngagementType}"
			}, {
				"sourceExpression": "${context.isSubstitute}",
				"targetVariable": "${context.isSubstitute}"
			}, {
				"sourceExpression": "${context.selectedProfitCenter}",
				"targetVariable": "${context.selectedProfitCenter}"
			}, {
				"sourceExpression": "${context.aResourceProfileApprovers}",
				"targetVariable": "${context.aResourceProfileApprovers}"
			}, {
				"sourceExpression": "${context.isResourceProfile}",
				"targetVariable": "${context.isResourceProfile}"
			}, {
				"sourceExpression": "${context.approverData.Shortname}",
				"targetVariable": "${context.approverData.Shortname}"
			}, {
				"sourceExpression": "${context.resourcecomment}",
				"targetVariable": "${context.resourcecomment}"
			}, {
				"sourceExpression": "${context.NewOppDetails}",
				"targetVariable": "${context.NewOppDetails}"
			}, {
				"sourceExpression": "${context.requesterDetails}",
				"targetVariable": "${context.requesterDetails}"
			}, {
				"sourceExpression": "${context.approverData.id}",
				"targetVariable": "${context.approverData.id}"
			}, {
				"sourceExpression": "${context.ProcessorComment}",
				"targetVariable": "${context.ProcessorComment}"
			}, {
				"sourceExpression": "${context.approverurl}",
				"targetVariable": "${context.approverurl}"
			}, {
				"sourceExpression": "${context.ReqTypeOwner}",
				"targetVariable": "${context.ReqTypeOwner}"
			}, {
				"sourceExpression": "${context.decision_ID}",
				"targetVariable": "${context.decision_ID}"
			}, {
				"sourceExpression": "${context.RequestType}",
				"targetVariable": "${context.RequestType}"
			}, {
				"sourceExpression": "${context.RefrenceID}",
				"targetVariable": "${context.RefrenceID}"
			}, {
				"sourceExpression": "${context.RequestID}",
				"targetVariable": "${context.RequestID}"
			}, {
				"sourceExpression": "${context.parentInstanceID}",
				"targetVariable": "${context.parentInstanceID}"
			}, {
				"sourceExpression": "${context.processor_email}",
				"targetVariable": "${context.processor_email}"
			}, {
				"sourceExpression": "${context.io_Owner_email}",
				"targetVariable": "${context.io_Owner_email}"
			}, {
				"sourceExpression": "${context.UT_refID}",
				"targetVariable": "${context.UT_refID}"
			}, {
				"sourceExpression": "${context.CurrentStateValue}",
				"targetVariable": "${context.CurrentStateValue}"
			}, {
				"sourceExpression": "${context.CurrentStepValue}",
				"targetVariable": "${context.CurrentStepValue}"
			}, {
				"sourceExpression": "${context.currentStepID}",
				"targetVariable": "${context.currentStepID}"
			}, {
				"sourceExpression": "${context.oppOrgId}",
				"targetVariable": "${context.oppOrgId}"
			}, {
				"sourceExpression": "${context.ParentOrgID}",
				"targetVariable": "${context.ParentOrgID}"
			}, {
				"sourceExpression": "${context.approverData.fullName}",
				"targetVariable": "${context.approverData.fullName}"
			}, {
				"sourceExpression": "${context.approverData.email}",
				"targetVariable": "${context.approverData.email}"
			}, {
				"sourceExpression": "${context.CPICalls.getDataFromCRM.Response}",
				"targetVariable": "${context.CPICalls.getDataFromCRM.Response}"
			}, {
				"sourceExpression": "${context.extSystemsUrls}",
				"targetVariable": "${context.extSystemsUrls}"
			}, {
				"sourceExpression": "${context.WfID_PresalesRequestApproval}",
				"targetVariable": "${context.WfID_PresalesRequestApproval}"
			}, {
				"sourceExpression": "${context.OrgType}",
				"targetVariable": "${context.OrgType}"
			}, {
				"sourceExpression": "${context.OrgID}",
				"targetVariable": "${context.OrgID}"
			}, {
				"sourceExpression": "${context.requestDetails}",
				"targetVariable": "${context.requestDetails}"
			}, {
				"sourceExpression": "${context.workflowFileUploadId}",
				"targetVariable": "${context.workflowFileUploadId}"
			}, {
				"sourceExpression": "${context.accountId}",
				"targetVariable": "${context.accountId}"
			}, {
				"sourceExpression": "${context.io_OwnerResource[loop.counter].ResCurrentStepName}",
				"targetVariable": "${context.io_OwnerResource.ResCurrentStepName}"
			}, {
				"sourceExpression": "${context.io_OwnerResource[loop.counter].staffingPurposeVisible}",
				"targetVariable": "${context.io_OwnerResource.staffingPurposeVisible}"
			}, {
				"sourceExpression": "${context.io_OwnerResource[loop.counter].AssignmentID}",
				"targetVariable": "${context.io_OwnerResource.AssignmentID}"
			}, {
				"sourceExpression": "${context.io_OwnerResource[loop.counter].internalOrderFormVisible}",
				"targetVariable": "${context.io_OwnerResource.internalOrderFormVisible}"
			}, {
				"sourceExpression": "${context.io_OwnerResource[loop.counter].ioOwnerFieldVisible}",
				"targetVariable": "${context.io_OwnerResource.ioOwnerFieldVisible}"
			}, {
				"sourceExpression": "${context.io_OwnerResource[loop.counter].taskLevelEnable}",
				"targetVariable": "${context.io_OwnerResource.taskLevelEnable}"
			}, {
				"sourceExpression": "${context.io_OwnerResource[loop.counter].taskLevelVisible}",
				"targetVariable": "${context.io_OwnerResource.taskLevelVisible}"
			}, {
				"sourceExpression": "${context.io_OwnerResource[loop.counter].TimeInvestment}",
				"targetVariable": "${context.io_OwnerResource.TimeInvestment}"
			}, {
				"sourceExpression": "${context.io_OwnerResource[loop.counter].ResCurrentProcessor}",
				"targetVariable": "${context.io_OwnerResource.ResCurrentProcessor}"
			}, {
				"sourceExpression": "${context.io_OwnerResource[loop.counter].staffingDateRangeVisible}",
				"targetVariable": "${context.io_OwnerResource.staffingDateRangeVisible}"
			}, {
				"sourceExpression": "${context.io_OwnerResource[loop.counter].isIOStaffing}",
				"targetVariable": "${context.io_OwnerResource.isIOStaffing}"
			}, {
				"sourceExpression": "${context.io_OwnerResource[loop.counter].ResAssignedRoleData}",
				"targetVariable": "${context.io_OwnerResource.ResAssignedRoleData}"
			}, {
				"sourceExpression": "${context.io_OwnerResource[loop.counter].ResCurrentProcessorRole}",
				"targetVariable": "${context.io_OwnerResource.ResCurrentProcessorRole}"
			}, {
				"sourceExpression": "${context.io_OwnerResource[loop.counter].NominatedResources}",
				"targetVariable": "${context.io_OwnerResource.NominatedResources}"
			}, {
				"sourceExpression": "${context.io_OwnerResource[loop.counter].maxNoOfDaysToBookIOVisible}",
				"targetVariable": "${context.io_OwnerResource.maxNoOfDaysToBookIOVisible}"
			}, {
				"sourceExpression": "${context.IgnoreMessage}",
				"targetVariable": "${context.IgnoreMessage}"
			}, {
				"sourceExpression": "${context.dealInfo}",
				"targetVariable": "${context.dealInfo}"
			}, {
				"sourceExpression": "${context.dealInfoForDb}",
				"targetVariable": "${context.dealInfoForDb}"
			}, {
				"sourceExpression": "${context.accOwnerDetails}",
				"targetVariable": "${context.accOwnerDetails}"
			}, {
				"sourceExpression": "${context.requestArea}",
				"targetVariable": "${context.requestArea}"
			}, {
				"sourceExpression": "${context.Email_Signature}",
				"targetVariable": "${context.Email_Signature}"
			}, {
				"sourceExpression": "${context.accountName}",
				"targetVariable": "${context.accountName}"
			}, {
				"sourceExpression": "${context.accNameFormatted}",
				"targetVariable": "${context.accNameFormatted}"
			}, {
				"sourceExpression": "${context.opportunityId}",
				"targetVariable": "${context.opportunityId}"
			}, {
				"sourceExpression": "${context.oppOwnerDetails}",
				"targetVariable": "${context.oppOwnerDetails}"
			}, {
				"sourceExpression": "${context.approvalHistory}",
				"targetVariable": "${context.approvalHistory}"
			}, {
				"sourceExpression": "${context.Opp_Desc}",
				"targetVariable": "${context.Opp_Desc}"
			}, {
				"sourceExpression": "${context.Opp_ID}",
				"targetVariable": "${context.Opp_ID}"
			}, {
				"sourceExpression": "${context.CRev_L}",
				"targetVariable": "${context.CRev_L}"
			}, {
				"sourceExpression": "${context.OpRev_L}",
				"targetVariable": "${context.OpRev_L}"
			}, {
				"sourceExpression": "${context.OpRev}",
				"targetVariable": "${context.OpRev}"
			}, {
				"sourceExpression": "${context.CRev}",
				"targetVariable": "${context.CRev}"
			}],
			"outParameters": [{
				"sourceExpression": "${context.EngagementType}",
				"targetVariable": "${context.EngagementType}"
			}, {
				"sourceExpression": "${context.io_OwnerEmails}",
				"targetVariable": "${context.io_OwnerEmails}"
			}, {
				"sourceExpression": "${context.decision_ID}",
				"targetVariable": "${context.decision_ID}"
			}, {
				"sourceExpression": "${context.RefrenceID}",
				"targetVariable": "${context.RefrenceID}"
			}, {
				"sourceExpression": "${context.RequestID}",
				"targetVariable": "${context.RequestID}"
			}, {
				"sourceExpression": "${context.UT_refID}",
				"targetVariable": "${context.UT_refID}"
			}, {
				"sourceExpression": "${context.approvalHistory}",
				"targetVariable": "${context.approvalHistory}"
			}, {
				"sourceExpression": "${context.io_OwnerResource.ResCurrentStepName}",
				"targetVariable": "${context.io_OwnerResource[loop.counter].ResCurrentStepName}"
			}, {
				"sourceExpression": "${context.io_OwnerResource.staffingPurposeVisible}",
				"targetVariable": "${context.io_OwnerResource[loop.counter].staffingPurposeVisible}"
			}, {
				"sourceExpression": "${context.io_OwnerResource.AssignmentID}",
				"targetVariable": "${context.io_OwnerResource[loop.counter].AssignmentID}"
			}, {
				"sourceExpression": "${context.io_OwnerResource.internalOrderFormVisible}",
				"targetVariable": "${context.io_OwnerResource[loop.counter].internalOrderFormVisible}"
			}, {
				"sourceExpression": "${context.io_OwnerResource.ioOwnerFieldVisible}",
				"targetVariable": "${context.io_OwnerResource[loop.counter].ioOwnerFieldVisible}"
			}, {
				"sourceExpression": "${context.io_OwnerResource.taskLevelEnable}",
				"targetVariable": "${context.io_OwnerResource[loop.counter].taskLevelEnable}"
			}, {
				"sourceExpression": "${context.io_OwnerResource.taskLevelVisible}",
				"targetVariable": "${context.io_OwnerResource[loop.counter].taskLevelVisible}"
			}, {
				"sourceExpression": "${context.io_OwnerResource.TimeInvestment}",
				"targetVariable": "${context.io_OwnerResource[loop.counter].TimeInvestment}"
			}, {
				"sourceExpression": "${context.io_OwnerResource.ResCurrentProcessor}",
				"targetVariable": "${context.io_OwnerResource[loop.counter].ResCurrentProcessor}"
			}, {
				"sourceExpression": "${context.io_OwnerResource.staffingDateRangeVisible}",
				"targetVariable": "${context.io_OwnerResource[loop.counter].staffingDateRangeVisible}"
			}, {
				"sourceExpression": "${context.io_OwnerResource.isIOStaffing}",
				"targetVariable": "${context.io_OwnerResource[loop.counter].isIOStaffing}"
			}, {
				"sourceExpression": "${context.io_OwnerResource.ResAssignedRoleData}",
				"targetVariable": "${context.io_OwnerResource[loop.counter].ResAssignedRoleData}"
			}, {
				"sourceExpression": "${context.io_OwnerResource.ResCurrentProcessorRole}",
				"targetVariable": "${context.io_OwnerResource[loop.counter].ResCurrentProcessorRole}"
			}, {
				"sourceExpression": "${context.io_OwnerResource.NominatedResources}",
				"targetVariable": "${context.io_OwnerResource[loop.counter].NominatedResources}"
			}, {
				"sourceExpression": "${context.io_OwnerResource.maxNoOfDaysToBookIOVisible}",
				"targetVariable": "${context.io_OwnerResource[loop.counter].maxNoOfDaysToBookIOVisible}"
			}],
			"id": "referencedsubflow5",
			"name": "IO_Owner Subflow"
		},
		"61b35d98-875a-4caa-9dd6-908ee777b1f4": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/TransformInitialiseLegacyRequest.js",
			"id": "scripttask86",
			"name": "Process Initialize Request"
		},
		"67439b2d-26da-4526-89c7-7ab805d2940c": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway65",
			"name": "isResourceProfile",
			"default": "cde72047-4f3f-4457-9c17-467731a2cf5b"
		},
		"2e2c1228-70ce-4e3e-a17f-6f0e57a3fddb": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway66",
			"name": "isResourceProfile",
			"default": "fa649f89-29e9-41c0-b6dc-cea1d2e142e9"
		},
		"08463fa9-cbff-4d54-83c3-642f3e6fb2cc": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway67",
			"name": "isResourceProfile",
			"default": "82800f1a-6ec4-4427-baf1-9429a8c2b4c3"
		},
		"0491100d-c3d7-4a10-b987-a51714fe03b9": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessResourceRequestLegacy.js",
			"id": "scripttask87",
			"name": "Process Resource Request Legacy"
		},
		"c3782cf7-1ebf-4b75-a47a-64c27487fddd": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessWfInstanceLegacyForwardRequest.js",
			"id": "scripttask88",
			"name": "Process Wf Instance Forward Legacy Request"
		},
		"838d04ab-576c-4221-94a0-1a081c7fd564": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessForwardRequest.js",
			"id": "scripttask89",
			"name": "Process Forward Request"
		},
		"b77b8193-43b4-43b2-8c7a-113c804fa906": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway68",
			"name": "isResourceProfile",
			"default": "8b8b3075-c0db-4b59-b420-eb37244af2c0"
		},
		"791b12f7-5553-4f20-bf99-da491f7b35db": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessLegacyResourceResponse.js",
			"id": "scripttask90",
			"name": "Process Resource Response Legacy"
		},
		"14a0fe86-1d2a-4966-b335-741b6be5059e": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/$batch",
			"httpMethod": "POST",
			"xsrfPath": "",
			"requestVariable": "${context.WFHistory.Request}",
			"responseVariable": "${context.WFHistory.Response}",
			"id": "servicetask44",
			"name": "WF Update"
		},
		"d4a748dc-7b7a-42a4-94ad-aeab5ff9b049": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "resources/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.CurrentStateDBCall.Request}",
			"responseVariable": "${context.CurrentStateDBCall.Response}",
			"id": "servicetask47",
			"name": "Get CurrentState Data"
		},
		"364045a0-c6e7-4afc-94d4-82ec2f1d03c9": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessCurrentStateIDRequest.js",
			"id": "scripttask91",
			"name": "Process CurrentState ID"
		},
		"f4be14cb-e3ee-40ee-89a4-bc7ec4ef4585": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway70",
			"name": "isResourceProfile",
			"default": "254c8a19-c6c5-48ec-b6fd-a834ad4c4b4b"
		},
		"b7fe7321-8af8-4b59-8e14-50773a7d2406": {
			"classDefinition": "com.sap.bpm.wfs.UserTask",
			"subject": "Approve Request for ${context.accNameFormatted} ${context.Approval_subject}",
			"priority": "MEDIUM",
			"isHiddenInLogForParticipant": false,
			"supportsForward": false,
			"userInterface": "sapui5://dealsupportapp.comsapbpmPresalesRequestApproval/com.sap.bpm.PresalesRequestApproval",
			"recipientUsers": "${context.approversIds}",
			"id": "usertask10",
			"name": "Processor Form",
			"dueDateRef": "78d59f76-b426-4436-9d0d-c22a7a9fb0d8"
		},
		"26a6e01b-1b1e-499a-854e-ccf5425cc013": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessResourceProfileData .js",
			"id": "scripttask92",
			"name": "Process Resource Profile Data"
		},
		"0c3397ab-660e-4a01-be0d-e17c50fac2b0": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask21",
			"name": "Notify Approver ResProfile",
			"mailDefinitionRef": "8c92cdae-0ffa-4890-aea9-10bac198992f"
		},
		"df47c6db-fc0a-4195-b54e-582286587c3b": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask22",
			"name": "Reminder Mail",
			"mailDefinitionRef": "f9fbe70e-28cc-4b97-8291-31cbbeddf2fa"
		},
		"644f787d-b26c-4962-a09c-4dad807bc97c": {
			"classDefinition": "com.sap.bpm.wfs.UserTask",
			"subject": "Approve Request for ${context.accNameFormatted} ${context.Approval_subject}",
			"priority": "MEDIUM",
			"isHiddenInLogForParticipant": false,
			"supportsForward": false,
			"userInterface": "sapui5://dealsupportapp.comsapbpmPresalesRequestApproval/com.sap.bpm.PresalesRequestApproval",
			"recipientUsers": "${context.approversIds}",
			"id": "usertask11",
			"name": "Processor Form"
		},
		"9576a80b-3c74-4cd2-83cb-1db026b2955c": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessReminderManagerAction.js",
			"id": "scripttask96",
			"name": "Process Manager action"
		},
		"dce010fe-7fea-40cf-bf0c-71b0fdbc065b": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway72",
			"name": "Skip reminder mail",
			"default": "8f71b6c3-9e86-4732-9033-1f1923376080"
		},
		"c91eb81e-c617-472f-9da7-08e778091ec3": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "Refrence_Id/getId()",
			"httpMethod": "GET",
			"responseVariable": "${context.RefrenceID.Response}",
			"id": "servicetask49",
			"name": "Get Refrence ID"
		},
		"6650cdb4-09e8-4a73-ae96-bedea01e4693": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/ore-api-/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.DelDraft.Request}",
			"responseVariable": "${context.DelDraft.Response}",
			"id": "servicetask51",
			"name": "Process Delete Draft Call"
		},
		"256073f1-1da8-4b77-8f03-f1038d4987f9": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessDraftDeleteCall.js",
			"id": "scripttask97",
			"name": "Process Draft Delete Call"
		},
		"f1c40679-3ce3-4adc-a831-ad69100e2f9a": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway73",
			"name": "Check Draft Delete",
			"default": "8d8a1e14-6bbb-4096-a559-9df3df7bb857"
		},
		"4c031674-0350-4056-988f-30a547a88f59": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessWfInstanceFormURLUpdateRequest.js",
			"id": "scripttask98",
			"name": "Process Wf Instance Form URL Update Request"
		},
		"254fe491-2ef3-44e4-8b0a-77f4f99b190d": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "wf/WFHistory?$filter=InstanceID eq ${context.WfID_PresalesRequestApproval}&$orderby=UT_refID desc&$top=1",
			"httpMethod": "GET",
			"responseVariable": "${context.WFHistoryMAXUT_refID}",
			"id": "servicetask52",
			"name": "Get WF History Data"
		},
		"5062881a-cb6f-4ed0-90d2-490f02801e8b": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "wf/WfInstance(instance_GUID='${context.WfID_PresalesRequestApproval}',parentInstance_GUID='${context.parentInstanceID}')/refID",
			"httpMethod": "GET",
			"responseVariable": "${context.RequestID}",
			"id": "servicetask58",
			"name": "Get Request ID"
		},
		"689fa697-0d89-4c8a-b038-811933578504": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "wf/WfInstance(instance_GUID='${context.WfID_PresalesRequestApproval}',parentInstance_GUID='${context.parentInstanceID}')/refID",
			"httpMethod": "GET",
			"responseVariable": "${context.RequestID}",
			"id": "servicetask60",
			"name": "Get Request ID"
		},
		"ba9fca6d-ac19-4573-8b8f-42d4e9ec6a1b": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "wf/WfInstance(instance_GUID='${context.WfID_PresalesRequestApproval}',parentInstance_GUID='${context.parentInstanceID}')/refID",
			"httpMethod": "GET",
			"responseVariable": "${context.RequestID}",
			"id": "servicetask61",
			"name": "Get Request ID"
		},
		"4e0b6f65-a8e8-4277-bad0-646c7a1015cf": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessCurrentStateData.js",
			"id": "scripttask105",
			"name": "Process CureentState Data"
		},
		"eed87f50-5ffa-451a-8ebd-d258a2a883a7": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/resources/$batch",
			"httpMethod": "POST",
			"requestVariable": "${context.areaPathCall.Request}",
			"responseVariable": "${context.areaPathCall.Response}",
			"id": "servicetask62",
			"name": "Get Routing Data"
		},
		"1761e0a8-2a2c-4580-ba6e-e239da8cdc9a": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessWfInstanceGetRoutingData.js",
			"id": "scripttask107",
			"name": "Get Routing Data"
		},
		"49ceda69-aeb0-4377-bb38-9f7b75d6deda": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask24",
			"name": "Notify Requestor about request Termination",
			"mailDefinitionRef": "6e75faa4-5745-4bb1-bd96-312865114c7a"
		},
		"0962e38d-f08a-4e79-bf07-0f5dfd82e983": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway78",
			"name": "Is Resource Profile?",
			"default": "30498ce2-4056-4ce4-96e1-6b360a1994e4"
		},
		"61e68c5b-b834-4d67-bd92-85b4c078fdeb": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway79",
			"name": "Is Resource Profile?",
			"default": "caac9569-57be-47db-8c24-ff8e2c603209"
		},
		"164ff510-3ccd-463d-a0f7-6820d5bff0dd": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask25",
			"name": "Notify Requester About Rejection",
			"mailDefinitionRef": "c4889ea2-831b-48a1-9806-4127a9ee3299"
		},
		"58e19ac0-7b08-4243-80ae-b02fd1c8b018": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway80",
			"name": "Is Resource Profile",
			"default": "7acfecc6-d7af-49db-b8dd-dedbe7bc9b9a"
		},
		"6aa491a3-33f5-428c-82f2-4c911cc1a087": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask26",
			"name": "Notify Request Area Requester About Rework",
			"mailDefinitionRef": "aade502f-3086-4101-b265-66fad4d16978"
		},
		"f39b3834-3b10-49fa-9e9e-8712a79017d7": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask27",
			"name": "Notify Request Area Resource Approval",
			"mailDefinitionRef": "7f89ed22-2c77-480c-8b2f-e9ae77700f77"
		},
		"db552930-7437-4f8f-9056-3a37b194590d": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway81",
			"name": "Is Resource Profile",
			"default": "37f1e805-4ec6-4a21-be72-bb1768430f12"
		},
		"0e75953e-aa04-40f1-83f3-ce7f382926a5": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask28",
			"name": "Notify About Resource Approval to Resource",
			"mailDefinitionRef": "545ea428-c798-40d6-a1d2-8b938ef1ec54"
		},
		"5cd8cdad-b206-47fa-9a69-d5a148329397": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway82",
			"name": "isResourceProfile",
			"default": "7e350b76-f56b-4cd9-85fd-32e05b782f36"
		},
		"b46ffe03-6e9e-443f-911b-e8e8f01c2d31": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask29",
			"name": "Notify About Request Creation / Update",
			"mailDefinitionRef": "51ac265c-56c7-48e6-b177-a00d4576dd48"
		},
		"cebf1053-229e-4ba3-a75f-ebae890a536a": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessGetResourceComment.js",
			"id": "scripttask108",
			"name": "Process get Resource Comment"
		},
		"2edba57b-3b16-4bb3-8a87-65c324f5ccc6": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessUpdateCurrentState.js",
			"id": "scripttask111",
			"name": "Update Current State"
		},
		"82b83e36-bb6a-490a-b97a-248c6121c9f5": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway85",
			"name": "Is Resource Profile?",
			"default": "d70da814-e8af-4a63-aaa8-7aa8cd89329a"
		},
		"894232bf-957c-4e96-9bff-7b029be4391b": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask32",
			"name": "Notify About Resource Approval",
			"mailDefinitionRef": "6429402e-86a3-4387-a1b9-c866b78aed78"
		},
		"37d6cb53-75f5-41ba-a49c-9c783cc7a31a": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway86",
			"name": "Delete Activity Lists ?",
			"default": "4bd665ed-407c-4621-99b2-7af671158353"
		},
		"b80468b1-0eec-4cd2-b814-5f0b68305fe1": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/activity-/deleteActivtyList",
			"httpMethod": "POST",
			"requestVariable": "${context.deleteApprovedReqActivityListData}",
			"responseVariable": "${context.deleteApprovedReqActivityListData.Response}",
			"id": "servicetask64",
			"name": "Delete Approved Req Activity Data"
		},
		"c4d2b059-6975-4dd7-aae8-b5bf03d80d5a": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway87",
			"name": "Routing Check",
			"default": "5a69f96e-36f6-4618-a44a-43cb2add3a32"
		},
		"29b0a44f-4005-48a5-8de9-41a4315e46b8": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/PreparePayloadForUserNotifRequestCreation.js",
			"id": "scripttask112",
			"name": "Prepare Payload For UserNotif RequestCreation"
		},
		"873a3e95-1481-4253-946d-dec2435b5e5e": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/GetUserNotificationSettings",
			"httpMethod": "POST",
			"requestVariable": "${context.User_NotifDBCallPayload}",
			"responseVariable": "${context.User_NotifDBCallPayload.Response}",
			"id": "servicetask65",
			"name": "Get User Notif Data Request Creation"
		},
		"d7519588-4503-490f-8c6b-2824c558ff2e": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessUserNotifData.js",
			"id": "scripttask113",
			"name": "Process User Notif Data"
		},
		"b19f799c-827d-4efa-88e2-a17f7678dfb8": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/PreparePayloadForUserNotifReqProsAction.js",
			"id": "scripttask115",
			"name": "Payload For UserNotif RequestModificationProcessor"
		},
		"c2f6848b-b53f-48d6-9a1b-c4fe07641521": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/GetUserNotificationSettings",
			"httpMethod": "POST",
			"requestVariable": "${context.User_NotifDBCallPayload}",
			"responseVariable": "${context.User_NotifDBCallPayload.Response}",
			"id": "servicetask67",
			"name": "Get User Notif Data Request ModificationProcessor"
		},
		"cbe4be68-f965-4841-bdef-c35716ac6c09": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessUserNotifData.js",
			"id": "scripttask116",
			"name": "Process User Notif Data"
		},
		"dab92ecd-01ed-4792-a03a-4dd389cf16e1": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/PreparePayloadForUserNotifRequestCreation.js",
			"id": "scripttask118",
			"name": "Prepare Payload For UserNotif Request SentBackAction"
		},
		"67f9522c-2fa9-4e5b-9eab-36406162541e": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/GetUserNotificationSettings",
			"httpMethod": "POST",
			"requestVariable": "${context.User_NotifDBCallPayload}",
			"responseVariable": "${context.User_NotifDBCallPayload.Response}",
			"id": "servicetask68",
			"name": "Get UserNotif Send Back to RequesterAction"
		},
		"dcb51126-0d0e-4846-9e4a-abfd8999ebfa": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessUserNotifData.js",
			"id": "scripttask119",
			"name": "Process User Notif Data"
		},
		"fea4d57a-0882-412f-891f-b7c6b15ae174": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/GetUserNotificationSettings",
			"httpMethod": "POST",
			"requestVariable": "${context.User_NotifDBCallPayload}",
			"responseVariable": "${context.User_NotifDBCallPayload.Response}",
			"id": "servicetask69",
			"name": "ServiceTask69"
		},
		"57ccb261-0689-431d-9ab3-0bda27e02dae": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessUserNotifData.js",
			"id": "scripttask120",
			"name": "Process User Notif Data"
		},
		"30a7f6e6-bb09-4cdd-bc98-0f26bfc4c4b3": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/PreparePayloadForUserNotifRequestClosure.js",
			"id": "scripttask121",
			"name": "Payload For UserNotif Request Closure"
		},
		"de105fa5-c4a1-4579-8dc3-1d7de4ba9288": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/GetUserNotificationSettings",
			"httpMethod": "POST",
			"requestVariable": "${context.User_NotifDBCallPayload}",
			"responseVariable": "${context.User_NotifDBCallPayload.Response}",
			"id": "servicetask70",
			"name": "ServiceTask70"
		},
		"53047d61-27f0-4197-bb50-1e3f021c657a": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessUserNotifData.js",
			"id": "scripttask122",
			"name": "Process User Notif Data"
		},
		"e96d3276-d4b5-4a0d-b0e7-d26d9c3ef2d4": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/PreparePayloadForUserNotifReqProsAction.js",
			"id": "scripttask123",
			"name": "Payload For UserNotif  Prossor Rej Action"
		},
		"b08f281a-cf6e-4d5d-b659-6716a1830378": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/GetUserNotificationSettings",
			"httpMethod": "POST",
			"xsrfPath": "",
			"requestVariable": "${context.User_NotifDBCallPayload}",
			"responseVariable": "${context.User_NotifDBCallPayload.Response}",
			"id": "servicetask71",
			"name": "ServiceTask71"
		},
		"3e19ecbd-1340-465c-8976-82efa862cfe8": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessUserNotifData.js",
			"id": "scripttask124",
			"name": "Process User Notif Data"
		},
		"6a0c923c-5bf1-4ace-be3c-26e0c029a0ef": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/GetUserNotificationSettings",
			"httpMethod": "POST",
			"requestVariable": "${context.User_NotifResDirectManagerPayload}",
			"responseVariable": "${context.User_NotifResDirectManagerPayload.Response}",
			"id": "servicetask72",
			"name": "ServiceTask72"
		},
		"fb3b491e-00c5-46f0-bd63-8be142ff9afb": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/Process Res Direct Notif Data.js",
			"id": "scripttask128",
			"name": "Process Res Direct Manager Data"
		},
		"27736dd6-1b84-467b-8286-9ba3b99c2d95": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask33",
			"name": "Notify About Resource Approval to Manager",
			"mailDefinitionRef": "4023193b-0e84-485c-856d-97960b3877b3"
		},
		"a13be89b-e4fc-432a-b14e-605cd21a47c9": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway88",
			"name": "ExclusiveGateway88"
		},
		"04c2516e-f970-4c59-abba-d57b4e78a3fc": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway89",
			"name": "ResDirect Mgr Flag",
			"default": "83f51d6f-26be-450a-96fd-8076045b8195"
		},
		"0a34cbbb-0781-423a-a550-c0900b8f51c2": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/PreparePayloadForUserNotifRequestCreation.js",
			"id": "scripttask129",
			"name": "Payload For UserNotif Req TerminateAction"
		},
		"5623d2f2-5e02-49f3-a96b-bcf58d76c3d4": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/GetUserNotificationSettings",
			"httpMethod": "POST",
			"requestVariable": "${context.User_NotifDBCallPayload}",
			"responseVariable": "${context.User_NotifDBCallPayload.Response}",
			"id": "servicetask73",
			"name": "ServiceTask73"
		},
		"e16d155c-2186-46c1-b37c-6d342092c68f": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessUserNotifData.js",
			"id": "scripttask130",
			"name": "Process User Notif Data"
		},
		"e16ccd4d-94a4-4355-9291-977b33e1b91a": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway90",
			"name": "Email Flag",
			"default": "9466e5a4-73ef-41ca-9751-48a4f769200c"
		},
		"bf0bc050-60c0-4e34-839c-6baca8156286": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway91",
			"name": "Email Flag",
			"default": "3d42fc68-48d4-461a-9dea-ab0ffe851fe5"
		},
		"a66aa8f6-ce7d-466e-b8ff-0b5bbdfe81b3": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway92",
			"name": "Email Flag",
			"default": "aa2128da-a24e-4223-887f-2e4bf5990270"
		},
		"167969ee-99a3-4d35-9711-1cb7a7cbec12": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway93",
			"name": "Email Flag",
			"default": "2d634131-11aa-4995-88aa-252966acf207"
		},
		"b5288eba-8fc8-411b-a9b8-048c8a0d8a65": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/PreparePayloadForResRejectAction.js",
			"id": "scripttask131",
			"name": "Prepare Payload For UserNotif RequestAction"
		},
		"b2b5df75-228e-4e7d-bfe0-e03177186322": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/GetUserNotificationSettings",
			"httpMethod": "POST",
			"requestVariable": "${context.User_NotifDBCallPayload}",
			"responseVariable": "${context.User_NotifDBCallPayload.Response}",
			"id": "servicetask74",
			"name": "Get User Notif Data Request Action"
		},
		"675f37df-4e36-4dca-bd2a-d373fef4aa09": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessUserNotifData.js",
			"id": "scripttask132",
			"name": "Process User Notif Data"
		},
		"dc1860ba-eae3-41ff-96cf-780880391467": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/PreparePayloadForUserNotifReqProsAction.js",
			"id": "scripttask133",
			"name": "Prepare Payload For UserNotif RequestAction"
		},
		"019c17a6-e0c0-46b9-b712-c0d34cf252e5": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/GetUserNotificationSettings",
			"httpMethod": "POST",
			"xsrfPath": "",
			"requestVariable": "${context.User_NotifDBCallPayload}",
			"responseVariable": "${context.User_NotifDBCallPayload.Response}",
			"id": "servicetask75",
			"name": "Get User Notif Data Request Action"
		},
		"5718cc40-784a-446f-804a-686f62b8a38d": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/ProcessUserNotifData.js",
			"id": "scripttask134",
			"name": "Process User Notif Data"
		},
		"7ade6462-abd5-40a6-9e34-08a157ba9cf0": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway94",
			"name": "Comment Email Flag",
			"default": "910787e8-1f48-4f73-83dc-66f49a969a17"
		},
		"d26896e5-5e29-4c01-8fa3-c4f2f5f52837": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway95",
			"name": "ExclusiveGateway95"
		},
		"57733068-a0f9-45ef-98a4-b14c150c9705": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/UserCommentUpdate",
			"httpMethod": "POST",
			"requestVariable": "${context.CommentNotifPayload}",
			"responseVariable": "${context.CommentNotifPayload.Response}",
			"id": "servicetask77",
			"name": "ServiceTask77"
		},
		"4a2ba629-a4ac-4c75-bad3-6465304ac364": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway96",
			"name": "Comment Email Flag",
			"default": "0bc7bdaa-432e-45a2-9405-b60c205429b1"
		},
		"ada573ed-5ba3-4e9d-88a5-69fb301817f3": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": " /wf/UserCommentUpdate",
			"httpMethod": "POST",
			"requestVariable": "${context.CommentNotifPayload}",
			"responseVariable": "${context.CommentNotifPayload.Response}",
			"id": "servicetask78",
			"name": "ServiceTask78"
		},
		"47ec03ab-1a9b-4611-ad45-62f351176504": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway100",
			"name": "Comment Email Flag",
			"default": "0239ecf6-2bde-462e-ab54-dcaf8be3a422"
		},
		"7afcbd35-981f-40ad-be79-b73c357b3e88": {
			"classDefinition": "com.sap.bpm.wfs.ServiceTask",
			"destination": "ext_DealSupportAppCAP",
			"destinationSource": "consumer",
			"path": "/wf/UserCommentUpdate",
			"httpMethod": "POST",
			"requestVariable": "${context.CommentNotifPayload}",
			"responseVariable": "${context.CommentNotifPayload.Response}",
			"id": "servicetask80",
			"name": "ServiceTask80"
		},
		"91b9adda-ddfc-4028-8044-a9897babddfb": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/PreparePayloadForCommentEmailNotif.js",
			"id": "scripttask135",
			"name": "Prepare Payload For Comment Email Notif"
		},
		"22c0a6d3-9563-45cd-a631-16ace9e8fdbe": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway101",
			"name": "Email Flag",
			"default": "0651d623-3b71-4c71-9dd8-df42359ad9e1"
		},
		"1626e402-eabe-408f-9fa8-2b65959fff3a": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway102",
			"name": "Email Flag",
			"default": "785cb1c9-0e29-4cda-92f9-027cd6c963e9"
		},
		"9d91e666-d780-414b-aedd-55ee0147bec9": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway103",
			"name": "Email FLag",
			"default": "13c8467d-cc25-4919-82aa-981c927ba3bf"
		},
		"cddc4689-b295-4ff2-bba3-42988d40ae93": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway104",
			"name": "Email Flag",
			"default": "d08f284a-ff9b-434b-9e3b-4c688fd2fb36"
		},
		"26d15377-8229-412a-941f-f4b55b9d8660": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask34",
			"name": "Notify Approver ResProfile Modification",
			"mailDefinitionRef": "d96bac8e-558d-408c-a8e9-3be31a5cec6e"
		},
		"a0f2bc94-21d8-43c4-9726-2de6188586ed": {
			"classDefinition": "com.sap.bpm.wfs.MailTask",
			"destinationSource": "consumer",
			"id": "mailtask35",
			"name": "Notify Approver ResProfile Action",
			"mailDefinitionRef": "01aa41fd-b119-49a8-af71-453f6bebcc89"
		},
		"095a8d5e-d3f8-4251-957a-3ef0b54b43c6": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway105",
			"name": "Processor added?",
			"default": "3d919f92-7c4a-4f80-88c2-faa8232b7b13"
		},
		"154c1d85-9385-4c63-985b-f7c22edcc182": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway106",
			"name": "Is Foward?",
			"default": "202b6dcf-65ff-41c6-af1b-3086209603bb"
		},
		"80d8290b-5d1e-489b-9196-04a30020661e": {
			"classDefinition": "com.sap.bpm.wfs.ExclusiveGateway",
			"id": "exclusivegateway107",
			"name": "isRework?",
			"default": "5c8fa50a-b66a-4c55-8e7a-b5e595365f46"
		},
		"dc46d7b3-eeb3-4c5d-a22e-53573488ff79": {
			"classDefinition": "com.sap.bpm.wfs.ScriptTask",
			"reference": "/scripts/PresalesRequestApproval/PreparePayloadforForwardRequest.js",
			"id": "scripttask136",
			"name": "Process Payload for Forward Request"
		},
		"c6b99f32-5fe6-4ab6-b60a-80fba1b9ae0f": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow1",
			"name": "SequenceFlow1",
			"sourceRef": "11a9b5ee-17c0-4159-9bbf-454dcfdcd5c3",
			"targetRef": "c91eb81e-c617-472f-9da7-08e778091ec3"
		},
		"cbff60a3-b01a-46c9-b6d4-c4f02c5e8d86": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow2",
			"name": "SequenceFlow2",
			"sourceRef": "06891468-ae19-4a5e-96aa-e97bb68a42c1",
			"targetRef": "256073f1-1da8-4b77-8f03-f1038d4987f9"
		},
		"67f85457-a01d-4c63-b4b6-872a00f0f8b9": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow3",
			"name": "SequenceFlow3",
			"sourceRef": "b2212f4e-72da-486e-be4f-680e98345b6b",
			"targetRef": "b9f3fd94-bc43-40b0-b03f-6cfa4e1fb969"
		},
		"dd7946a1-f238-4c7a-a5fd-c1ed7094b7e1": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.decision  == \"Send Back to Requestor\"}",
			"id": "sequenceflow7",
			"name": "send back",
			"sourceRef": "d8ba0d32-0e90-49ca-927a-3931f0881f9e",
			"targetRef": "35021842-30c7-473a-bdbe-d322a823068f"
		},
		"c89124c5-dab8-481c-8307-beef67357aeb": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow9",
			"name": "approve",
			"sourceRef": "d8ba0d32-0e90-49ca-927a-3931f0881f9e",
			"targetRef": "3e842588-71b2-4462-83ca-f9ab3743e423"
		},
		"31e25202-6cca-4025-acb8-0b632fe0fd4d": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow23",
			"name": "SequenceFlow23",
			"sourceRef": "8dcd09bd-99d5-4347-9bfb-102a27f1a949",
			"targetRef": "dc1860ba-eae3-41ff-96cf-780880391467"
		},
		"c342097f-192a-4660-a73e-da0ebd797b89": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow24",
			"name": "SequenceFlow24",
			"sourceRef": "bb21eb22-a546-402c-b871-3b0fbd7b4d97",
			"targetRef": "0479076d-17a8-470b-8382-d5459eb052a3"
		},
		"56a8a81c-f5f3-4070-bfe3-fa5e476b01fa": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow31",
			"name": "SequenceFlow31",
			"sourceRef": "35021842-30c7-473a-bdbe-d322a823068f",
			"targetRef": "58e19ac0-7b08-4243-80ae-b02fd1c8b018"
		},
		"bfe4859f-9e9f-4f37-847e-63d2fcfa69e2": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow38",
			"name": "SequenceFlow38",
			"sourceRef": "fdf35015-9267-4b31-ba80-49759b8bb63b",
			"targetRef": "056b1a11-e7a7-4ac2-bfe7-16e06a4e3b17"
		},
		"eef1bd83-3d87-4465-a7c3-c92800f9c48b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow41",
			"name": "SequenceFlow41",
			"sourceRef": "056b1a11-e7a7-4ac2-bfe7-16e06a4e3b17",
			"targetRef": "ef831483-933c-4efb-998b-082196738ef1"
		},
		"29abf8e7-c8a3-4777-81a0-49ec1fe6ccbd": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow47",
			"name": "Submit",
			"sourceRef": "233a6b4d-a2b6-458f-bae8-c7bc788013af",
			"targetRef": "41c3c126-fb82-4a1d-b79c-765a13db7625"
		},
		"db84c2ec-911f-4964-8e9a-50d9821cc474": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.decision == \"Terminate\"}",
			"id": "sequenceflow48",
			"name": "Terminate",
			"sourceRef": "233a6b4d-a2b6-458f-bae8-c7bc788013af",
			"targetRef": "3cfbbea0-301e-47fe-b1cb-1162c50fb37a"
		},
		"8b19b064-884f-4f12-8a81-c45f49a7d7a8": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow51",
			"name": "SequenceFlow51",
			"sourceRef": "3cfbbea0-301e-47fe-b1cb-1162c50fb37a",
			"targetRef": "67dac61a-5d8d-403c-93a1-a56f3823a247"
		},
		"61617f44-0d68-482f-a241-7b5c65fb9d50": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow54",
			"name": "SequenceFlow54",
			"sourceRef": "3e842588-71b2-4462-83ca-f9ab3743e423",
			"targetRef": "6a35041a-d16e-4cbc-9e6a-6aa51d639be2"
		},
		"a48cfdbe-2f35-40d3-9d30-7921d68617f6": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow58",
			"name": "SequenceFlow58",
			"sourceRef": "99b92cdc-05ca-4bf6-9cba-bbe8e381696c",
			"targetRef": "0cbbabb8-3988-416b-b310-77659b4225b6"
		},
		"f1790b57-eb7a-4f5d-915c-0710ac27fb9a": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow60",
			"name": "SequenceFlow60",
			"sourceRef": "854f2bea-0180-42e1-9f60-4d102de7726d",
			"targetRef": "ad99fde2-287e-4495-9b62-ef4fc532adf0"
		},
		"f3e9e518-b00d-421e-bd91-abaf88253b58": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.decision  == \"Forward\"}",
			"id": "sequenceflow61",
			"name": "forward",
			"sourceRef": "d8ba0d32-0e90-49ca-927a-3931f0881f9e",
			"targetRef": "08463fa9-cbff-4d54-83c3-642f3e6fb2cc"
		},
		"b8a123dc-fb1a-4f67-92d6-ab415991e790": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow62",
			"name": "SequenceFlow62",
			"sourceRef": "bdcfb412-7dd8-43c5-b6ec-2c9af8b32b5a",
			"targetRef": "ade99b22-6ac9-4e1d-8811-1534d90745e8"
		},
		"3d12733b-6286-4b08-934e-3b5ebbc924cb": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow65",
			"name": "SequenceFlow65",
			"sourceRef": "30c8a446-373c-4f80-94ad-066f5a25dbbc",
			"targetRef": "ff47561f-1004-41a7-ae18-5de2cf4400ef"
		},
		"a2a7c0b0-a677-490a-b05b-61f83ec61545": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow71",
			"name": "SequenceFlow71",
			"sourceRef": "7567c7a1-d73a-4be2-9f55-def62b30ddca",
			"targetRef": "b77b8193-43b4-43b2-8c7a-113c804fa906"
		},
		"c3e5f663-1d55-4b75-80a9-e2d2540536bd": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow75",
			"name": "SequenceFlow75",
			"sourceRef": "a2ba93b6-86bb-4bf0-a149-037fa740d0f7",
			"targetRef": "bb21eb22-a546-402c-b871-3b0fbd7b4d97"
		},
		"681f78f5-2f89-4781-8d90-404af29f559a": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow76",
			"name": "SequenceFlow76",
			"sourceRef": "3d3cf404-1e67-41e1-9348-c87eeb0397bf",
			"targetRef": "b19f799c-827d-4efa-88e2-a17f7678dfb8"
		},
		"32682168-7f79-48ec-a5db-73ec3b828f1d": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow79",
			"name": "SequenceFlow79",
			"sourceRef": "00dd4b02-bd67-4515-ae82-999f1c8f3f4a",
			"targetRef": "bd2a38e1-d493-4123-8ee1-876a83a6f5f8"
		},
		"7a02df10-8590-4cf9-8fd5-433bc0ffdd79": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow81",
			"name": "SequenceFlow81",
			"sourceRef": "50acc690-0ad0-473a-a524-2e56b078405b",
			"targetRef": "00dd4b02-bd67-4515-ae82-999f1c8f3f4a"
		},
		"a8c41d51-a14f-4fec-8f40-49a107a4083d": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow86",
			"name": "SequenceFlow86",
			"sourceRef": "9d325103-1963-4f0e-a1d1-f409d3dc59d5",
			"targetRef": "8337f8c5-dd5f-4fbd-8f7c-ea374f6b36b2"
		},
		"36c49a76-b960-48bf-9d16-ff018a8b66a2": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow92",
			"name": "No",
			"sourceRef": "b9f3fd94-bc43-40b0-b03f-6cfa4e1fb969",
			"targetRef": "188c8349-34ce-4d4f-bb98-1b8c5e8de814"
		},
		"dee51f9a-8c65-44d9-814a-a42fce41ab06": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow93",
			"name": "SequenceFlow93",
			"sourceRef": "8337f8c5-dd5f-4fbd-8f7c-ea374f6b36b2",
			"targetRef": "2ec0658e-6a17-4d0d-90ea-62c4336623b5"
		},
		"5e7233d7-b513-46d0-a5e1-3797e89ef6c1": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow94",
			"name": "SequenceFlow94",
			"sourceRef": "bd2a38e1-d493-4123-8ee1-876a83a6f5f8",
			"targetRef": "2ec0658e-6a17-4d0d-90ea-62c4336623b5"
		},
		"b4251b51-8ecb-46e0-a28f-3d479f8963d4": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow95",
			"name": "SequenceFlow95",
			"sourceRef": "2ec0658e-6a17-4d0d-90ea-62c4336623b5",
			"targetRef": "b9f3fd94-bc43-40b0-b03f-6cfa4e1fb969"
		},
		"ff29f679-cb09-4ff6-9830-80537ff53755": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow96",
			"name": "no",
			"sourceRef": "08e8ea17-39f4-48cc-83cf-5fe60227f741",
			"targetRef": "5cd8cdad-b206-47fa-9a69-d5a148329397"
		},
		"f62aac86-d615-4105-869a-3b66f94a5d8e": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isSLE}",
			"id": "sequenceflow97",
			"name": "yes",
			"sourceRef": "08e8ea17-39f4-48cc-83cf-5fe60227f741",
			"targetRef": "d204364a-1439-481f-9b7c-9c638f58d815"
		},
		"bf8ae7ef-156c-4b07-a9db-d7494e301aac": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow99",
			"name": "SequenceFlow99",
			"sourceRef": "aaa547a7-dc46-44ab-8255-960716a6bcae",
			"targetRef": "68ed2872-5482-465b-b560-49979b07b5dd"
		},
		"7c0df5b1-973c-4cd6-a293-94a40467a169": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow100",
			"name": "SequenceFlow100",
			"sourceRef": "0e163838-d068-4dee-a204-ed54fb74af92",
			"targetRef": "9f42ea35-64e3-4e39-ad1c-963db78f4393"
		},
		"9f702c5c-c132-4c75-8ddd-91aeb3cdc3c1": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow102",
			"name": "no",
			"sourceRef": "9f42ea35-64e3-4e39-ad1c-963db78f4393",
			"targetRef": "abd1eb59-b34c-489e-81da-2426d5ccd452"
		},
		"00d8e9e7-7de4-4d9e-a338-424dce2e60b9": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isCAManagersListNotEmpty}",
			"id": "sequenceflow105",
			"name": "yes",
			"sourceRef": "9f42ea35-64e3-4e39-ad1c-963db78f4393",
			"targetRef": "d58f5ffb-c7f1-4d48-a312-241110ebf41e"
		},
		"ab07db2a-d54f-4353-95d7-e058fde5c5a7": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow106",
			"name": "SequenceFlow106",
			"sourceRef": "d58f5ffb-c7f1-4d48-a312-241110ebf41e",
			"targetRef": "701fc339-9099-4f8b-8058-7100f5ae4c5d"
		},
		"a2b4ba53-c764-412e-872d-0d621ff3bac3": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow107",
			"name": "SequenceFlow107",
			"sourceRef": "701fc339-9099-4f8b-8058-7100f5ae4c5d",
			"targetRef": "caf7be2b-e43a-4f14-a826-9cfb68ab4172"
		},
		"8cbe862a-01cd-44b8-b8bb-4d175436c687": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow108",
			"name": "SequenceFlow108",
			"sourceRef": "caf7be2b-e43a-4f14-a826-9cfb68ab4172",
			"targetRef": "efba8741-f361-4ace-9a71-eb817f466415"
		},
		"3e61da83-19ba-4b9a-97e8-2893c9de6e7d": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow110",
			"name": "no",
			"sourceRef": "d204364a-1439-481f-9b7c-9c638f58d815",
			"targetRef": "f275da51-5617-4333-83d9-aff034b1c70e"
		},
		"8b6b6507-0682-4403-b21c-663dd4adb5cf": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.wasReworked}",
			"id": "sequenceflow111",
			"name": "yes",
			"sourceRef": "d204364a-1439-481f-9b7c-9c638f58d815",
			"targetRef": "5cd8cdad-b206-47fa-9a69-d5a148329397"
		},
		"a2e490fc-09fd-4187-a6a3-95aa56069181": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow112",
			"name": "SequenceFlow112",
			"sourceRef": "efba8741-f361-4ace-9a71-eb817f466415",
			"targetRef": "abd1eb59-b34c-489e-81da-2426d5ccd452"
		},
		"328d0b8c-7512-48a7-a305-060df9161e20": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow122",
			"name": "SequenceFlow122",
			"sourceRef": "ef831483-933c-4efb-998b-082196738ef1",
			"targetRef": "884ff1e1-f344-46c9-9cac-f8cf678a5a78"
		},
		"86c031b4-a5f1-45ac-946f-461d81c12fe1": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow126",
			"name": "SequenceFlow126",
			"sourceRef": "2e2f15da-55b8-4578-81b9-740ff2b6a218",
			"targetRef": "37ec0a64-b924-4866-a246-b6e91fc7fa06"
		},
		"331bb888-15e6-437c-8f0e-bbe1f02f5034": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow128",
			"name": "SequenceFlow128",
			"sourceRef": "37ec0a64-b924-4866-a246-b6e91fc7fa06",
			"targetRef": "4d353ff7-225a-4475-abbd-ca72eb0b8974"
		},
		"324a90d6-31fa-4db2-a2e0-2da3cb51a4aa": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow129",
			"name": "SequenceFlow129",
			"sourceRef": "0479076d-17a8-470b-8382-d5459eb052a3",
			"targetRef": "4c031674-0350-4056-988f-30a547a88f59"
		},
		"8da188fa-85e3-4eba-9efd-50d12ec31967": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow132",
			"name": "SequenceFlow132",
			"sourceRef": "7048bfa2-ab10-4afa-af8a-d038f581ae65",
			"targetRef": "77d837e2-2e1a-40ad-88a3-73192fbfd1c0"
		},
		"2f5ef6cc-abba-440d-9c3e-6020b86a5f76": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow133",
			"name": "SequenceFlow133",
			"sourceRef": "6a35041a-d16e-4cbc-9e6a-6aa51d639be2",
			"targetRef": "cebf1053-229e-4ba3-a75f-ebae890a536a"
		},
		"360372f3-3e99-4de0-ae65-a5d1f593da08": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow134",
			"name": "SequenceFlow134",
			"sourceRef": "31bddefd-3970-487e-ae69-8c79c03d2b4e",
			"targetRef": "13adc3d3-6b22-4055-ae85-0401add7744c"
		},
		"f790d345-c914-4baa-8c6a-834c3e7aac10": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow135",
			"name": "SequenceFlow135",
			"sourceRef": "13adc3d3-6b22-4055-ae85-0401add7744c",
			"targetRef": "21b87d2f-678d-4b03-9d16-a2bef8a4cb18"
		},
		"921d2dd0-9298-431e-a862-1f64ff318b4e": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow142",
			"name": "SequenceFlow142",
			"sourceRef": "8430762c-d6c3-4ade-bc13-3db24226917f",
			"targetRef": "a8cd3376-6607-467a-ad8a-e981bdb681d9"
		},
		"1b2e9457-c8de-4ae7-b015-2f1634f21461": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow143",
			"name": "SequenceFlow143",
			"sourceRef": "ff47561f-1004-41a7-ae18-5de2cf4400ef",
			"targetRef": "8430762c-d6c3-4ade-bc13-3db24226917f"
		},
		"94014aa8-48f5-459c-af49-6a77afd84b15": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow144",
			"name": "SequenceFlow144",
			"sourceRef": "a8cd3376-6607-467a-ad8a-e981bdb681d9",
			"targetRef": "a552781b-d824-4782-a4da-5bf466645df7"
		},
		"e6e6913b-614a-499e-a0b2-aac182bd2e36": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow145",
			"name": "SequenceFlow145",
			"sourceRef": "eeff2bdf-7aaa-47a3-b8f0-134ab18e9e8e",
			"targetRef": "1d99fb56-2463-47d5-b95c-b61fddfa93e4"
		},
		"2e5195ca-3c2d-4dc5-ac02-8f33009641a4": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow146",
			"name": "SequenceFlow146",
			"sourceRef": "1d99fb56-2463-47d5-b95c-b61fddfa93e4",
			"targetRef": "b6021f22-e46b-417e-b1bb-872c603b5736"
		},
		"95bae7c8-4c50-4f6f-88dd-7f029ed4c3f7": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow148",
			"name": "SequenceFlow148",
			"sourceRef": "e21e9ddd-8ffe-497a-ae19-c05a308de69b",
			"targetRef": "30c8a446-373c-4f80-94ad-066f5a25dbbc"
		},
		"dc729b7f-2d1c-4dd0-9431-8e0d50a609da": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow149",
			"name": "SequenceFlow149",
			"sourceRef": "2d5fb220-87ab-4e1d-8095-c41dc8a6306d",
			"targetRef": "2e2c1228-70ce-4e3e-a17f-6f0e57a3fddb"
		},
		"068488e5-c4c3-43b7-b7f3-1507c06fcfac": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow150",
			"name": "SequenceFlow150",
			"sourceRef": "ad99fde2-287e-4495-9b62-ef4fc532adf0",
			"targetRef": "bdcfb412-7dd8-43c5-b6ec-2c9af8b32b5a"
		},
		"4991edf8-64e2-45c6-940f-0d6ef0824213": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow153",
			"name": "SequenceFlow153",
			"sourceRef": "abd1eb59-b34c-489e-81da-2426d5ccd452",
			"targetRef": "5cd8cdad-b206-47fa-9a69-d5a148329397"
		},
		"20a90dc8-035f-48e8-9e94-28565aeb83eb": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow155",
			"name": "SequenceFlow155",
			"sourceRef": "354d2614-4245-499d-981c-800e57c8b91b",
			"targetRef": "c8116791-4591-4339-b807-e69c36f74171"
		},
		"a30405d6-7b62-4efe-acae-569f11a6f2ef": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow156",
			"name": "SequenceFlow156",
			"sourceRef": "f275da51-5617-4333-83d9-aff034b1c70e",
			"targetRef": "aaa547a7-dc46-44ab-8255-960716a6bcae"
		},
		"1c9a1904-19ca-4191-a3c0-2ec00228eaca": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow157",
			"name": "no",
			"sourceRef": "67dac61a-5d8d-403c-93a1-a56f3823a247",
			"targetRef": "15e032f9-93a1-47b5-88f6-2e955a9372b3"
		},
		"abc20477-9cb6-4188-95ca-ca2e7270f712": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.wasReworked}",
			"id": "sequenceflow159",
			"name": "yes",
			"sourceRef": "67dac61a-5d8d-403c-93a1-a56f3823a247",
			"targetRef": "50aa8137-fd50-44ed-a195-e4765d4f1c69"
		},
		"2fc44807-25d8-4446-bd9e-49f49cb335fe": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow160",
			"name": "SequenceFlow160",
			"sourceRef": "50aa8137-fd50-44ed-a195-e4765d4f1c69",
			"targetRef": "4a2ba629-a4ac-4c75-bad3-6465304ac364"
		},
		"1a7a45f9-b2b0-4166-b5b4-334e18f73a92": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow165",
			"name": "SequenceFlow165",
			"sourceRef": "d9f5c825-a8f0-4fdb-8f9d-3685b671d121",
			"targetRef": "8242f728-507b-4793-b9fb-629dc3cc79e2"
		},
		"47ed3840-7e44-4957-a7b6-7d0f80d8cac1": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow167",
			"name": "no",
			"sourceRef": "8242f728-507b-4793-b9fb-629dc3cc79e2",
			"targetRef": "7567c7a1-d73a-4be2-9f55-def62b30ddca"
		},
		"02df9f15-66cd-498e-9ecb-fb671e20d8ce": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow169",
			"name": "SequenceFlow169",
			"sourceRef": "0c9df6a2-4743-4ca1-8068-f61ecf547f56",
			"targetRef": "5461095c-4eec-4521-ab96-7e568c905bff"
		},
		"166aa69f-ccf8-43dc-8637-fad42d6582c2": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow170",
			"name": "SequenceFlow170",
			"sourceRef": "5461095c-4eec-4521-ab96-7e568c905bff",
			"targetRef": "898272e4-5a6b-4718-8c09-8aedec202321"
		},
		"05fab4cb-d8c4-47b3-9485-6529df557015": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.retry}",
			"id": "sequenceflow171",
			"name": "yes",
			"sourceRef": "898272e4-5a6b-4718-8c09-8aedec202321",
			"targetRef": "0c9df6a2-4743-4ca1-8068-f61ecf547f56"
		},
		"8c7d2af6-903b-4a8f-80fe-b35409ee5a5b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow172",
			"name": "no",
			"sourceRef": "898272e4-5a6b-4718-8c09-8aedec202321",
			"targetRef": "29b0a44f-4005-48a5-8de9-41a4315e46b8"
		},
		"c729c403-aae0-4560-b7cb-6b1529fee388": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.retry}",
			"id": "sequenceflow173",
			"name": "yes",
			"sourceRef": "8242f728-507b-4793-b9fb-629dc3cc79e2",
			"targetRef": "2d5fb220-87ab-4e1d-8095-c41dc8a6306d"
		},
		"6deb1b7f-2512-40b3-b58d-5759a05cad55": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow174",
			"name": "SequenceFlow174",
			"sourceRef": "81bd8d37-a4b5-43e8-9d31-1cf5b701aaff",
			"targetRef": "2d5fb220-87ab-4e1d-8095-c41dc8a6306d"
		},
		"0aaa828d-8a31-4c3f-b85b-caab990f21ee": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow175",
			"name": "SequenceFlow175",
			"sourceRef": "e62a9b1b-ce64-4fc4-b605-617b23ded67a",
			"targetRef": "0962e38d-f08a-4e79-bf07-0f5dfd82e983"
		},
		"36fffba7-d3b4-402e-ae69-28c0227d023c": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow183",
			"name": "SequenceFlow183",
			"sourceRef": "68ed2872-5482-465b-b560-49979b07b5dd",
			"targetRef": "fb8a7793-4c34-4ad7-8c40-48079bb1661f"
		},
		"34ed1d1c-df8f-4100-ae31-42e0a196de43": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow184",
			"name": "no",
			"sourceRef": "fb8a7793-4c34-4ad7-8c40-48079bb1661f",
			"targetRef": "0e163838-d068-4dee-a204-ed54fb74af92"
		},
		"32d9bce6-141f-4ed5-870d-a8c9eef80013": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.retry}",
			"id": "sequenceflow185",
			"name": "yes",
			"sourceRef": "fb8a7793-4c34-4ad7-8c40-48079bb1661f",
			"targetRef": "aaa547a7-dc46-44ab-8255-960716a6bcae"
		},
		"c932376d-73eb-401f-97f6-3fcdf897527e": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow186",
			"name": "SequenceFlow186",
			"sourceRef": "4d353ff7-225a-4475-abbd-ca72eb0b8974",
			"targetRef": "2bcd6216-3f70-461b-92b7-cf05f6d439ec"
		},
		"b3d57f26-0e70-490d-809a-1bebdca98041": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow187",
			"name": "SequenceFlow187",
			"sourceRef": "2bcd6216-3f70-461b-92b7-cf05f6d439ec",
			"targetRef": "df48d131-ba3e-4f87-8430-e9467164626b"
		},
		"a55bee0b-2803-4600-9f8a-f67425cc3e13": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.retry}",
			"id": "sequenceflow189",
			"name": "yes",
			"sourceRef": "df48d131-ba3e-4f87-8430-e9467164626b",
			"targetRef": "4d353ff7-225a-4475-abbd-ca72eb0b8974"
		},
		"c709ae80-5a3a-4a14-a6ef-833e31546070": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow190",
			"name": "no",
			"sourceRef": "ade99b22-6ac9-4e1d-8811-1534d90745e8",
			"targetRef": "e21e9ddd-8ffe-497a-ae19-c05a308de69b"
		},
		"c4e79006-a40c-4168-891d-f51b3688fbe2": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.retry}",
			"id": "sequenceflow191",
			"name": "yes",
			"sourceRef": "ade99b22-6ac9-4e1d-8811-1534d90745e8",
			"targetRef": "ad99fde2-287e-4495-9b62-ef4fc532adf0"
		},
		"67c691df-76a3-4191-a3e2-d052b039ba39": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow192",
			"name": "SequenceFlow192",
			"sourceRef": "a552781b-d824-4782-a4da-5bf466645df7",
			"targetRef": "3cfb8f37-57c4-4fef-abcb-fb6c90d03197"
		},
		"f65eaf2d-b91e-46ef-8ca8-2d8d661d6d8b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow193",
			"name": "no",
			"sourceRef": "3cfb8f37-57c4-4fef-abcb-fb6c90d03197",
			"targetRef": "3d3cf404-1e67-41e1-9348-c87eeb0397bf"
		},
		"5f86cbe2-6a96-4334-97f7-b6c877752c9e": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.retry}",
			"id": "sequenceflow194",
			"name": "yes",
			"sourceRef": "3cfb8f37-57c4-4fef-abcb-fb6c90d03197",
			"targetRef": "a8cd3376-6607-467a-ad8a-e981bdb681d9"
		},
		"76b97217-0a87-4a46-a465-ff636ade22ce": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow198",
			"name": "SequenceFlow198",
			"sourceRef": "21b87d2f-678d-4b03-9d16-a2bef8a4cb18",
			"targetRef": "06fa1e99-4325-4dea-81d7-a92461eb15e3"
		},
		"2d70c319-e451-4336-b4ec-4a01a405cd16": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow200",
			"name": "SequenceFlow200",
			"sourceRef": "77d837e2-2e1a-40ad-88a3-73192fbfd1c0",
			"targetRef": "ed625063-4a14-4208-a032-83a5f425bccc"
		},
		"9d7aeb3e-0a5b-4a25-b8ae-65c2eb1dd31f": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.retry}",
			"id": "sequenceflow202",
			"name": "yes",
			"sourceRef": "ed625063-4a14-4208-a032-83a5f425bccc",
			"targetRef": "7048bfa2-ab10-4afa-af8a-d038f581ae65"
		},
		"bc832fdd-9634-4fcf-9266-7322b82aded4": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow209",
			"name": "SequenceFlow209",
			"sourceRef": "b6021f22-e46b-417e-b1bb-872c603b5736",
			"targetRef": "9dd72e42-191f-468a-9647-a628c8fd17e6"
		},
		"701e242d-aa44-43d2-a412-438b2eb725ed": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow210",
			"name": "no",
			"sourceRef": "9dd72e42-191f-468a-9647-a628c8fd17e6",
			"targetRef": "2798f4e7-bc42-4fad-a248-159095a2f40a"
		},
		"dbf112ee-4a31-4dd2-adc1-34ba62da883e": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.retry}",
			"id": "sequenceflow211",
			"name": "yes",
			"sourceRef": "9dd72e42-191f-468a-9647-a628c8fd17e6",
			"targetRef": "1d99fb56-2463-47d5-b95c-b61fddfa93e4"
		},
		"59c94139-b2a5-4f3a-a81d-0f5ae8b05088": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow214",
			"name": "SequenceFlow214",
			"sourceRef": "0cbbabb8-3988-416b-b310-77659b4225b6",
			"targetRef": "acd3716f-1a35-4503-9739-85361bef5f85"
		},
		"75130ec0-c22d-446c-8c3d-d87cf2a6a170": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow216",
			"name": "SequenceFlow216",
			"sourceRef": "acd3716f-1a35-4503-9739-85361bef5f85",
			"targetRef": "8e4664d1-e4bc-4b0f-8386-e37aa621fc85"
		},
		"5e4ff83f-97cf-45d5-bfeb-2806c6ab3edf": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow217",
			"name": "no",
			"sourceRef": "8e4664d1-e4bc-4b0f-8386-e37aa621fc85",
			"targetRef": "a92f0f95-9eb7-414a-9dbb-1d9df0785f8c"
		},
		"da8fedd5-802e-4093-87bc-2cf327e38afa": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow224",
			"name": "SequenceFlow224",
			"sourceRef": "c09525f9-e84e-486c-9ee4-3255981f9f30",
			"targetRef": "19dbe20f-9499-4d84-b2a6-59f2577bc887"
		},
		"fcd9609c-ab96-4009-b528-74a340aaaa80": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow225",
			"name": "No",
			"sourceRef": "19dbe20f-9499-4d84-b2a6-59f2577bc887",
			"targetRef": "1add78a6-c2b5-4286-a14b-eb75518972a4"
		},
		"bdf95749-dcef-4cb9-b50b-63e565a7649a": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.ResRework}",
			"id": "sequenceflow226",
			"name": "Yes",
			"sourceRef": "19dbe20f-9499-4d84-b2a6-59f2577bc887",
			"targetRef": "76998587-b436-46d5-9654-f1d5b54cea7c"
		},
		"0840dd77-7f25-4882-a5e4-e10f4010a3c8": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow230",
			"name": "SequenceFlow230",
			"sourceRef": "83164bc9-e708-4115-89f1-90702519e7d9",
			"targetRef": "c4d2b059-6975-4dd7-aae8-b5bf03d80d5a"
		},
		"76c5606f-384a-4e96-895f-53cc34961857": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow233",
			"name": "No",
			"sourceRef": "56449570-8bd1-47f8-8a8b-e8cd7d8bec49",
			"targetRef": "83164bc9-e708-4115-89f1-90702519e7d9"
		},
		"ac960d55-35e5-4657-9c58-efd1cda5e74f": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.LenAssigntApprove == 0}",
			"id": "sequenceflow234",
			"name": "Yes",
			"sourceRef": "56449570-8bd1-47f8-8a8b-e8cd7d8bec49",
			"targetRef": "82b83e36-bb6a-490a-b97a-248c6121c9f5"
		},
		"fd28d3ea-e700-47e9-a55b-974a5c22c44e": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow238",
			"name": "No",
			"sourceRef": "ed625063-4a14-4208-a032-83a5f425bccc",
			"targetRef": "f5065acc-ca90-4eb5-b50c-5499b2d3a333"
		},
		"ae7e3c1d-ecf2-4d12-9a54-72fad6b8d3da": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow239",
			"name": "SequenceFlow239",
			"sourceRef": "15a3e187-5366-4134-b217-f1fa7fa383ae",
			"targetRef": "c09525f9-e84e-486c-9ee4-3255981f9f30"
		},
		"da0d2b45-e64b-4fa1-9508-a71729321442": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.ResReject}",
			"id": "sequenceflow247",
			"name": "Yes",
			"sourceRef": "586b13f2-76b5-4ed7-a64c-ed62c9f185d8",
			"targetRef": "e55968cd-4af7-4797-9fc6-466f04cfbeea"
		},
		"bb8d0430-5643-45d5-8e85-b90725e3159f": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.decision == \"Reject\"}",
			"id": "sequenceflow250",
			"name": "reject",
			"sourceRef": "d8ba0d32-0e90-49ca-927a-3931f0881f9e",
			"targetRef": "61e68c5b-b834-4d67-bd92-85b4c078fdeb"
		},
		"37bd7e76-3fd0-482e-b3f8-6690e4915208": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.ResReject}",
			"id": "sequenceflow252",
			"name": "Yes",
			"sourceRef": "cf128b14-466a-48b6-bbcf-c5ac8fc4c7b9",
			"targetRef": "bc4a7c70-7b35-4903-845d-70c4e5f3242f"
		},
		"5b84c5e1-c843-41c0-ab5b-376262e1869a": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow253",
			"name": "No",
			"sourceRef": "cf128b14-466a-48b6-bbcf-c5ac8fc4c7b9",
			"targetRef": "31bddefd-3970-487e-ae69-8c79c03d2b4e"
		},
		"b2fc9b55-32c1-4ec5-8f65-83988df60ca8": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow256",
			"name": "SequenceFlow256",
			"sourceRef": "77009387-aab8-4f42-8f7c-f4e10985f460",
			"targetRef": "cf128b14-466a-48b6-bbcf-c5ac8fc4c7b9"
		},
		"54a8904a-f070-4ea9-8d64-e5b07eafe485": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow259",
			"name": "SequenceFlow259",
			"sourceRef": "884ff1e1-f344-46c9-9cac-f8cf678a5a78",
			"targetRef": "7ade6462-abd5-40a6-9e34-08a157ba9cf0"
		},
		"27566425-a069-4cf3-aede-efa584513bfd": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow262",
			"name": "SequenceFlow262",
			"sourceRef": "e55968cd-4af7-4797-9fc6-466f04cfbeea",
			"targetRef": "d646474d-3529-41a6-ae57-d4a43aa49800"
		},
		"3f41cb7f-93bc-4c0f-b548-530ecc1211a1": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow263",
			"name": "SequenceFlow263",
			"sourceRef": "3634b4b9-98ac-4d8c-96cf-bf11d09e060f",
			"targetRef": "4db9678a-18f4-4646-939c-a4e6effc31ee"
		},
		"8c621dca-bf5a-415a-8717-34f423b4793a": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow264",
			"name": "SequenceFlow264",
			"sourceRef": "d646474d-3529-41a6-ae57-d4a43aa49800",
			"targetRef": "3634b4b9-98ac-4d8c-96cf-bf11d09e060f"
		},
		"b1fe490a-52b0-42c0-b0d1-4425931edf89": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow265",
			"name": "No",
			"sourceRef": "4db9678a-18f4-4646-939c-a4e6effc31ee",
			"targetRef": "b5288eba-8fc8-411b-a9b8-048c8a0d8a65"
		},
		"0cd66587-5e5b-4bc7-a827-fc0712254f31": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.retry}",
			"id": "sequenceflow266",
			"name": "Yes",
			"sourceRef": "4db9678a-18f4-4646-939c-a4e6effc31ee",
			"targetRef": "d646474d-3529-41a6-ae57-d4a43aa49800"
		},
		"7179827e-2dba-4c0d-a86f-07fc4fb8320e": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow267",
			"name": "No",
			"sourceRef": "586b13f2-76b5-4ed7-a64c-ed62c9f185d8",
			"targetRef": "254fe491-2ef3-44e4-8b0a-77f4f99b190d"
		},
		"87c37b70-30a4-463a-a3c7-33c7d15a78cc": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow268",
			"name": "SequenceFlow268",
			"sourceRef": "700a6d8f-16e3-4952-9283-2eeb3bf5d7ad",
			"targetRef": "db552930-7437-4f8f-9056-3a37b194590d"
		},
		"75d6c528-28cf-4f01-915f-fba4eb40f575": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.ResApprove}",
			"id": "sequenceflow271",
			"name": "yes",
			"sourceRef": "150a24e2-88c0-4dcb-a84c-20d93b376d7d",
			"targetRef": "37d6cb53-75f5-41ba-a49c-9c783cc7a31a"
		},
		"b89c7f06-ae33-4900-a4c8-f95d85887f72": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow272",
			"name": "No",
			"sourceRef": "150a24e2-88c0-4dcb-a84c-20d93b376d7d",
			"targetRef": "e60d84ca-b7e8-4f08-8390-059aab21d6bf"
		},
		"80b34501-6e5b-4db5-97ca-0bf53550e22b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow273",
			"name": "SequenceFlow273",
			"sourceRef": "e60d84ca-b7e8-4f08-8390-059aab21d6bf",
			"targetRef": "586b13f2-76b5-4ed7-a64c-ed62c9f185d8"
		},
		"473dfa99-dfa2-40b7-985e-62ca3cda6913": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow274",
			"name": "SequenceFlow274",
			"sourceRef": "1add78a6-c2b5-4286-a14b-eb75518972a4",
			"targetRef": "150a24e2-88c0-4dcb-a84c-20d93b376d7d"
		},
		"ddb81cb4-0d8a-4c22-8f74-27bd375a40d4": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow275",
			"name": "SequenceFlow275",
			"sourceRef": "151ee67a-db52-4540-8b6a-f591a7b71f4a",
			"targetRef": "af0a4614-e737-4ead-b301-67aa489ca082"
		},
		"071967f1-e2f1-49d6-9e80-c9eafbcb18df": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow276",
			"name": "SequenceFlow276",
			"sourceRef": "bc4a7c70-7b35-4903-845d-70c4e5f3242f",
			"targetRef": "151ee67a-db52-4540-8b6a-f591a7b71f4a"
		},
		"06bbfc0a-c342-4208-855c-62a1ffde7850": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow278",
			"name": "SequenceFlow278",
			"sourceRef": "af0a4614-e737-4ead-b301-67aa489ca082",
			"targetRef": "354a4d17-0c0c-4245-bfca-fe0064bfad23"
		},
		"ca6f3230-2b40-4163-9c31-2c5b9c00a775": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow280",
			"name": "No",
			"sourceRef": "c00f2a6f-6814-4c28-a548-49650d55e9f2",
			"targetRef": "e60d84ca-b7e8-4f08-8390-059aab21d6bf"
		},
		"dfd21a8a-1b17-4dcb-aeac-dbcc99c8d817": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow282",
			"name": "SequenceFlow282",
			"sourceRef": "354a4d17-0c0c-4245-bfca-fe0064bfad23",
			"targetRef": "c00f2a6f-6814-4c28-a548-49650d55e9f2"
		},
		"ad3d14f4-64f8-4682-9636-353c11ea56a1": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.retry}",
			"id": "sequenceflow283",
			"name": "yes",
			"sourceRef": "c00f2a6f-6814-4c28-a548-49650d55e9f2",
			"targetRef": "af0a4614-e737-4ead-b301-67aa489ca082"
		},
		"4dfa1b2a-2536-4efa-8427-7efa45ef68f3": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow297",
			"name": "No",
			"sourceRef": "a92f0f95-9eb7-414a-9dbb-1d9df0785f8c",
			"targetRef": "06891468-ae19-4a5e-96aa-e97bb68a42c1"
		},
		"d06753fc-9d95-49d5-be33-c0ddd62966cb": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.FirstIterationRA}",
			"id": "sequenceflow298",
			"name": "Yes",
			"sourceRef": "a92f0f95-9eb7-414a-9dbb-1d9df0785f8c",
			"targetRef": "233a6b4d-a2b6-458f-bae8-c7bc788013af"
		},
		"1c436edf-5127-4046-b900-0e4dd4fe63ff": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow299",
			"name": "no",
			"sourceRef": "df48d131-ba3e-4f87-8430-e9467164626b",
			"targetRef": "9d325103-1963-4f0e-a1d1-f409d3dc59d5"
		},
		"eaef82ac-a7dc-4b3b-94a5-19dffbdb5a52": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow300",
			"name": "No",
			"sourceRef": "f5065acc-ca90-4eb5-b50c-5499b2d3a333",
			"targetRef": "15a3e187-5366-4134-b217-f1fa7fa383ae"
		},
		"3b3113a8-70ff-4758-8b9b-acef4e3f5952": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.retry}",
			"id": "sequenceflow302",
			"name": "Yes",
			"sourceRef": "8e4664d1-e4bc-4b0f-8386-e37aa621fc85",
			"targetRef": "0cbbabb8-3988-416b-b310-77659b4225b6"
		},
		"75896328-c6d4-4c1b-b927-19d825b6ea0a": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.Skip_Resource_Approver}",
			"id": "sequenceflow303",
			"name": "Yes",
			"sourceRef": "f5065acc-ca90-4eb5-b50c-5499b2d3a333",
			"targetRef": "1add78a6-c2b5-4286-a14b-eb75518972a4"
		},
		"a0226c8b-64d3-4426-8403-7d082dd38502": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow304",
			"name": "No",
			"sourceRef": "41c3c126-fb82-4a1d-b79c-765a13db7625",
			"targetRef": "81bd8d37-a4b5-43e8-9d31-1cf5b701aaff"
		},
		"de40e5a9-db13-4e67-9d93-2904497e9574": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isAccount}",
			"id": "sequenceflow305",
			"name": "yes",
			"sourceRef": "41c3c126-fb82-4a1d-b79c-765a13db7625",
			"targetRef": "2d5fb220-87ab-4e1d-8095-c41dc8a6306d"
		},
		"5eb4b3c7-c7e8-4ce3-a618-3794f5a6dc64": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow313",
			"name": "No",
			"sourceRef": "00a7fee2-04b8-47c7-a454-81a8431932a4",
			"targetRef": "700a6d8f-16e3-4952-9283-2eeb3bf5d7ad"
		},
		"c1c5e7ff-e337-4f24-8657-c4bcd5d6795e": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isAccount}",
			"id": "sequenceflow314",
			"name": "Yes",
			"sourceRef": "00a7fee2-04b8-47c7-a454-81a8431932a4",
			"targetRef": "3868830c-d756-46b5-bf27-6a6af1cefb8e"
		},
		"ffe81886-f21d-482a-92d6-b54e3f2648b4": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow315",
			"name": "SequenceFlow315",
			"sourceRef": "3868830c-d756-46b5-bf27-6a6af1cefb8e",
			"targetRef": "ed0992f0-1881-4231-bded-2d6fae63bfcb"
		},
		"a32dc0ac-277e-4aac-bb00-82dd66bbe5d4": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow316",
			"name": "SequenceFlow316",
			"sourceRef": "ed0992f0-1881-4231-bded-2d6fae63bfcb",
			"targetRef": "700a6d8f-16e3-4952-9283-2eeb3bf5d7ad"
		},
		"f8f8ead3-4a3c-4f27-b26b-e153bfe76dbc": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow317",
			"name": "SequenceFlow317",
			"sourceRef": "188c8349-34ce-4d4f-bb98-1b8c5e8de814",
			"targetRef": "d8ba0d32-0e90-49ca-927a-3931f0881f9e"
		},
		"048510c6-d11d-44d2-b520-292930deb72e": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow320",
			"name": "No",
			"sourceRef": "f77539b1-89c8-4ef9-82ca-ee0ffb34b3ab",
			"targetRef": "8b42abcb-2e53-48d1-afdd-be0b1825b791"
		},
		"c37991b2-2378-4111-972c-33fb47f3a010": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isAccount}",
			"id": "sequenceflow321",
			"name": "Yes",
			"sourceRef": "f77539b1-89c8-4ef9-82ca-ee0ffb34b3ab",
			"targetRef": "83164bc9-e708-4115-89f1-90702519e7d9"
		},
		"5a52e8ec-d8f1-4027-a781-a95484b6f0a7": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow342",
			"name": "SequenceFlow342",
			"sourceRef": "8b42abcb-2e53-48d1-afdd-be0b1825b791",
			"targetRef": "83164bc9-e708-4115-89f1-90702519e7d9"
		},
		"b5a8f5fe-779b-4fed-be76-f2179e51e2f4": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isAccount}",
			"id": "sequenceflow350",
			"name": "Yes",
			"sourceRef": "79b7e998-0eb2-45e9-b322-2e5d832d4957",
			"targetRef": "6ee8995c-c5b8-4bd7-8a79-f768b73174fe"
		},
		"6dda97f8-aa4d-4713-92c5-fef77fc49c28": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow353",
			"name": "No",
			"sourceRef": "79b7e998-0eb2-45e9-b322-2e5d832d4957",
			"targetRef": "6ee8995c-c5b8-4bd7-8a79-f768b73174fe"
		},
		"0054aef6-5b38-4068-b61f-cfed96558c2c": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow354",
			"name": "SequenceFlow354",
			"sourceRef": "6ee8995c-c5b8-4bd7-8a79-f768b73174fe",
			"targetRef": "586b13f2-76b5-4ed7-a64c-ed62c9f185d8"
		},
		"29ec8dc3-eea5-45f6-a560-7d4331f8c93b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.io_Owner}",
			"id": "sequenceflow364",
			"name": "Yes",
			"sourceRef": "79b7e998-0eb2-45e9-b322-2e5d832d4957",
			"targetRef": "e9776d6f-986e-4f0e-9385-50ed77dbbc26"
		},
		"e3ffcdf1-f689-4dba-8f1c-36c0b5f9863d": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow370",
			"name": "SequenceFlow370",
			"sourceRef": "ff37bfbb-d8b6-451b-a1b9-e762b6e8347f",
			"targetRef": "28a0934a-bd2f-4d09-8e45-144459be00d5"
		},
		"e084355f-1259-40cd-aa4d-b665b8c372be": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow371",
			"name": "SequenceFlow371",
			"sourceRef": "e9776d6f-986e-4f0e-9385-50ed77dbbc26",
			"targetRef": "ff37bfbb-d8b6-451b-a1b9-e762b6e8347f"
		},
		"6773827d-cbb0-496a-a861-13db7c9727bd": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow380",
			"name": "SequenceFlow380",
			"sourceRef": "28a0934a-bd2f-4d09-8e45-144459be00d5",
			"targetRef": "50af6a3b-96a3-4c1e-b141-0e14052384f8"
		},
		"1a1c487e-b25d-4e56-a1be-162733240567": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow382",
			"name": "SequenceFlow382",
			"sourceRef": "50af6a3b-96a3-4c1e-b141-0e14052384f8",
			"targetRef": "4276f295-a1b2-40c0-bce3-304fffe6aa62"
		},
		"cde72047-4f3f-4457-9c17-467731a2cf5b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow385",
			"name": "No",
			"sourceRef": "67439b2d-26da-4526-89c7-7ab805d2940c",
			"targetRef": "99b92cdc-05ca-4bf6-9cba-bbe8e381696c"
		},
		"612bd3cc-c675-4e42-ad1f-5d6e2e9b23d9": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isResourceProfile}",
			"id": "sequenceflow386",
			"name": "Yes",
			"sourceRef": "67439b2d-26da-4526-89c7-7ab805d2940c",
			"targetRef": "61b35d98-875a-4caa-9dd6-908ee777b1f4"
		},
		"2510cd26-b393-4ae2-b41a-b02b5dd030cb": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow387",
			"name": "SequenceFlow387",
			"sourceRef": "61b35d98-875a-4caa-9dd6-908ee777b1f4",
			"targetRef": "26a6e01b-1b1e-499a-854e-ccf5425cc013"
		},
		"fa649f89-29e9-41c0-b6dc-cea1d2e142e9": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow388",
			"name": "No",
			"sourceRef": "2e2c1228-70ce-4e3e-a17f-6f0e57a3fddb",
			"targetRef": "d9f5c825-a8f0-4fdb-8f9d-3685b671d121"
		},
		"f0a70486-2531-43e6-8b75-9c0befb108a3": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isResourceProfile}",
			"id": "sequenceflow389",
			"name": "Yes",
			"sourceRef": "2e2c1228-70ce-4e3e-a17f-6f0e57a3fddb",
			"targetRef": "0491100d-c3d7-4a10-b987-a51714fe03b9"
		},
		"82800f1a-6ec4-4427-baf1-9429a8c2b4c3": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow390",
			"name": "No",
			"sourceRef": "08463fa9-cbff-4d54-83c3-642f3e6fb2cc",
			"targetRef": "854f2bea-0180-42e1-9f60-4d102de7726d"
		},
		"634919b7-63f5-4a36-9c78-0562c8c0028e": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isResourceProfile}",
			"id": "sequenceflow391",
			"name": "Yes",
			"sourceRef": "08463fa9-cbff-4d54-83c3-642f3e6fb2cc",
			"targetRef": "838d04ab-576c-4221-94a0-1a081c7fd564"
		},
		"5c7c8944-3239-448f-9b50-6759facec636": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow393",
			"name": "SequenceFlow393",
			"sourceRef": "c3782cf7-1ebf-4b75-a47a-64c27487fddd",
			"targetRef": "dc46d7b3-eeb3-4c5d-a22e-53573488ff79"
		},
		"a3349dc9-3f51-4722-af94-b5c076be0c2f": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow394",
			"name": "SequenceFlow394",
			"sourceRef": "838d04ab-576c-4221-94a0-1a081c7fd564",
			"targetRef": "eed87f50-5ffa-451a-8ebd-d258a2a883a7"
		},
		"8b8b3075-c0db-4b59-b420-eb37244af2c0": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow395",
			"name": "No",
			"sourceRef": "b77b8193-43b4-43b2-8c7a-113c804fa906",
			"targetRef": "a2ba93b6-86bb-4bf0-a149-037fa740d0f7"
		},
		"581ee665-0b96-4981-b4a7-f66531eba313": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isResourceProfile}",
			"id": "sequenceflow396",
			"name": "Yes",
			"sourceRef": "b77b8193-43b4-43b2-8c7a-113c804fa906",
			"targetRef": "791b12f7-5553-4f20-bf99-da491f7b35db"
		},
		"6ad1fe1a-4b51-4943-9a56-0b59fe9c543c": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow397",
			"name": "SequenceFlow397",
			"sourceRef": "791b12f7-5553-4f20-bf99-da491f7b35db",
			"targetRef": "bb21eb22-a546-402c-b871-3b0fbd7b4d97"
		},
		"27fa05bd-a7f2-45a6-833f-624d491e07f2": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow401",
			"name": "SequenceFlow401",
			"sourceRef": "0491100d-c3d7-4a10-b987-a51714fe03b9",
			"targetRef": "7567c7a1-d73a-4be2-9f55-def62b30ddca"
		},
		"3f75ac14-53d6-42a4-9715-1b74f63bb931": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow402",
			"name": "SequenceFlow402",
			"sourceRef": "14a0fe86-1d2a-4966-b335-741b6be5059e",
			"targetRef": "00a7fee2-04b8-47c7-a454-81a8431932a4"
		},
		"c386d94c-0df1-441f-82ac-f5b2e0f25099": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow406",
			"name": "SequenceFlow406",
			"sourceRef": "d4a748dc-7b7a-42a4-94ad-aeab5ff9b049",
			"targetRef": "4e0b6f65-a8e8-4277-bad0-646c7a1015cf"
		},
		"d4d8710b-449f-4585-94ef-a0523880bf17": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow407",
			"name": "SequenceFlow407",
			"sourceRef": "364045a0-c6e7-4afc-94d4-82ec2f1d03c9",
			"targetRef": "d4a748dc-7b7a-42a4-94ad-aeab5ff9b049"
		},
		"254c8a19-c6c5-48ec-b6fd-a834ad4c4b4b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow408",
			"name": "No",
			"sourceRef": "f4be14cb-e3ee-40ee-89a4-bc7ec4ef4585",
			"targetRef": "4490dec5-f12b-4640-838f-09c439a9e1aa"
		},
		"85827e2c-3fdf-4a2d-bead-fcbee8b326ab": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isResourceProfile}",
			"id": "sequenceflow409",
			"name": "Yes",
			"sourceRef": "f4be14cb-e3ee-40ee-89a4-bc7ec4ef4585",
			"targetRef": "a66aa8f6-ce7d-466e-b8ff-0b5bbdfe81b3"
		},
		"b912078e-831a-4aa6-8c00-900383d2ba6e": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow410",
			"name": "SequenceFlow410",
			"sourceRef": "b7fe7321-8af8-4b59-8e14-50773a7d2406",
			"targetRef": "b9f3fd94-bc43-40b0-b03f-6cfa4e1fb969"
		},
		"7acb88cb-58a2-45c7-b6c1-7b025ec2f28e": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow411",
			"name": "SequenceFlow411",
			"sourceRef": "5c249566-d8e1-4b0f-8766-c66a3b6471eb",
			"targetRef": "689fa697-0d89-4c8a-b038-811933578504"
		},
		"d6974bcc-4712-441f-a548-bd1fb7fa4f53": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow412",
			"name": "SequenceFlow412",
			"sourceRef": "26a6e01b-1b1e-499a-854e-ccf5425cc013",
			"targetRef": "0cbbabb8-3988-416b-b310-77659b4225b6"
		},
		"89984e21-7f8c-406e-be26-33f972d5de21": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow418",
			"name": "SequenceFlow418",
			"sourceRef": "4490dec5-f12b-4640-838f-09c439a9e1aa",
			"targetRef": "b2212f4e-72da-486e-be4f-680e98345b6b"
		},
		"0171a61e-5b11-464b-92bf-00ddd7961ed2": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow419",
			"name": "SequenceFlow419",
			"sourceRef": "c8116791-4591-4339-b807-e69c36f74171",
			"targetRef": "f4be14cb-e3ee-40ee-89a4-bc7ec4ef4585"
		},
		"1c16677c-031c-4a61-8921-a14082a99a9d": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow423",
			"name": "SequenceFlow423",
			"sourceRef": "df47c6db-fc0a-4195-b54e-582286587c3b",
			"targetRef": "644f787d-b26c-4962-a09c-4dad807bc97c"
		},
		"367f6933-543d-4bc9-89eb-b2139923fe1b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow424",
			"name": "SequenceFlow424",
			"sourceRef": "644f787d-b26c-4962-a09c-4dad807bc97c",
			"targetRef": "9576a80b-3c74-4cd2-83cb-1db026b2955c"
		},
		"65342618-613e-405c-b073-18b951a82cb5": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow425",
			"name": "SequenceFlow425",
			"sourceRef": "9576a80b-3c74-4cd2-83cb-1db026b2955c",
			"targetRef": "b9f3fd94-bc43-40b0-b03f-6cfa4e1fb969"
		},
		"8f71b6c3-9e86-4732-9033-1f1923376080": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow426",
			"name": "no",
			"sourceRef": "dce010fe-7fea-40cf-bf0c-71b0fdbc065b",
			"targetRef": "b7fe7321-8af8-4b59-8e14-50773a7d2406"
		},
		"0ee9acb9-3c5e-4b8b-b809-ed7e7d492756": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.Skipreminderflag}",
			"id": "sequenceflow427",
			"name": "yes",
			"sourceRef": "dce010fe-7fea-40cf-bf0c-71b0fdbc065b",
			"targetRef": "644f787d-b26c-4962-a09c-4dad807bc97c"
		},
		"b835f668-ad15-4f1a-8b80-22b61f76b854": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow428",
			"name": "SequenceFlow428",
			"sourceRef": "4276f295-a1b2-40c0-bce3-304fffe6aa62",
			"targetRef": "6ee8995c-c5b8-4bd7-8a79-f768b73174fe"
		},
		"71ddd529-f7dd-4e4d-9f25-398ea612cc88": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow429",
			"name": "SequenceFlow429",
			"sourceRef": "c91eb81e-c617-472f-9da7-08e778091ec3",
			"targetRef": "364045a0-c6e7-4afc-94d4-82ec2f1d03c9"
		},
		"7ae673a4-bba8-4367-8c1e-efb5534038ee": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow431",
			"name": "SequenceFlow431",
			"sourceRef": "6650cdb4-09e8-4a73-ae96-bedea01e4693",
			"targetRef": "233a6b4d-a2b6-458f-bae8-c7bc788013af"
		},
		"5e9b142d-a945-42a4-b004-073712da66e7": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow432",
			"name": "SequenceFlow432",
			"sourceRef": "256073f1-1da8-4b77-8f03-f1038d4987f9",
			"targetRef": "f1c40679-3ce3-4adc-a831-ad69100e2f9a"
		},
		"f42fba9c-730e-4bfd-8a1a-63ff5ec991d4": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.delDraft}",
			"id": "sequenceflow433",
			"name": "Yes",
			"sourceRef": "f1c40679-3ce3-4adc-a831-ad69100e2f9a",
			"targetRef": "6650cdb4-09e8-4a73-ae96-bedea01e4693"
		},
		"8d8a1e14-6bbb-4096-a559-9df3df7bb857": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow434",
			"name": "No",
			"sourceRef": "f1c40679-3ce3-4adc-a831-ad69100e2f9a",
			"targetRef": "233a6b4d-a2b6-458f-bae8-c7bc788013af"
		},
		"64b7882e-e829-430c-be5a-11bc40a302c0": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow435",
			"name": "SequenceFlow435",
			"sourceRef": "4c031674-0350-4056-988f-30a547a88f59",
			"targetRef": "0c9df6a2-4743-4ca1-8068-f61ecf547f56"
		},
		"1357c6b2-d880-4bf8-8abe-aafea3f5de05": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow436",
			"name": "SequenceFlow436",
			"sourceRef": "254fe491-2ef3-44e4-8b0a-77f4f99b190d",
			"targetRef": "eeff2bdf-7aaa-47a3-b8f0-134ab18e9e8e"
		},
		"e99d9e75-52e0-43f2-b3f9-4e1c6dbd00db": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow440",
			"name": "SequenceFlow440",
			"sourceRef": "5062881a-cb6f-4ed0-90d2-490f02801e8b",
			"targetRef": "167969ee-99a3-4d35-9711-1cb7a7cbec12"
		},
		"c73e5d37-9315-45b4-a68e-ccfe62e311f3": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow445",
			"name": "SequenceFlow445",
			"sourceRef": "689fa697-0d89-4c8a-b038-811933578504",
			"targetRef": "2e2f15da-55b8-4578-81b9-740ff2b6a218"
		},
		"665287f4-59e9-432c-ba87-38af8b88f3c9": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow446",
			"name": "SequenceFlow446",
			"sourceRef": "ba9fca6d-ac19-4573-8b8f-42d4e9ec6a1b",
			"targetRef": "50acc690-0ad0-473a-a524-2e56b078405b"
		},
		"f61420f5-8e5f-4895-8999-de8a2498dc26": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow458",
			"name": "SequenceFlow458",
			"sourceRef": "24a33845-446b-4d18-95b1-fd65eba5ee35",
			"targetRef": "5062881a-cb6f-4ed0-90d2-490f02801e8b"
		},
		"e08d2891-83d8-4f46-b797-e84b68f63538": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow459",
			"name": "SequenceFlow459",
			"sourceRef": "9b854ad4-6864-4d21-8538-b72fa1ddc83c",
			"targetRef": "ba9fca6d-ac19-4573-8b8f-42d4e9ec6a1b"
		},
		"7d0f4538-6183-41dc-8555-9f153fbee9ee": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow460",
			"name": "SequenceFlow460",
			"sourceRef": "4e0b6f65-a8e8-4277-bad0-646c7a1015cf",
			"targetRef": "67439b2d-26da-4526-89c7-7ab805d2940c"
		},
		"c4027015-c438-479e-97f3-accc635e5711": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow461",
			"name": "SequenceFlow461",
			"sourceRef": "eed87f50-5ffa-451a-8ebd-d258a2a883a7",
			"targetRef": "1761e0a8-2a2c-4580-ba6e-e239da8cdc9a"
		},
		"768100d8-d481-4919-81bc-c384e2e77e3f": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow462",
			"name": "SequenceFlow462",
			"sourceRef": "1761e0a8-2a2c-4580-ba6e-e239da8cdc9a",
			"targetRef": "c3782cf7-1ebf-4b75-a47a-64c27487fddd"
		},
		"a2d6d864-339b-4867-9d1e-0adb53e630a2": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow464",
			"name": "SequenceFlow464",
			"sourceRef": "49ceda69-aeb0-4377-bb38-9f7b75d6deda",
			"targetRef": "15e032f9-93a1-47b5-88f6-2e955a9372b3"
		},
		"34dddbcf-b9b5-41dc-8823-068ce4d5bd5f": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isResourceProfile}",
			"id": "sequenceflow465",
			"name": "Yes",
			"sourceRef": "0962e38d-f08a-4e79-bf07-0f5dfd82e983",
			"targetRef": "0a34cbbb-0781-423a-a550-c0900b8f51c2"
		},
		"30498ce2-4056-4ce4-96e1-6b360a1994e4": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow466",
			"name": "No",
			"sourceRef": "0962e38d-f08a-4e79-bf07-0f5dfd82e983",
			"targetRef": "15e032f9-93a1-47b5-88f6-2e955a9372b3"
		},
		"82ea66a9-8c66-4f4b-a6a5-b92e0fe1d1eb": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isResourceProfile}",
			"id": "sequenceflow467",
			"name": "Yes",
			"sourceRef": "61e68c5b-b834-4d67-bd92-85b4c078fdeb",
			"targetRef": "2edba57b-3b16-4bb3-8a87-65c324f5ccc6"
		},
		"caac9569-57be-47db-8c24-ff8e2c603209": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow468",
			"name": "No",
			"sourceRef": "61e68c5b-b834-4d67-bd92-85b4c078fdeb",
			"targetRef": "164ff510-3ccd-463d-a0f7-6820d5bff0dd"
		},
		"d843345a-e732-4dec-bf08-ff96b41fad57": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow469",
			"name": "SequenceFlow469",
			"sourceRef": "164ff510-3ccd-463d-a0f7-6820d5bff0dd",
			"targetRef": "cf128b14-466a-48b6-bbcf-c5ac8fc4c7b9"
		},
		"7acfecc6-d7af-49db-b8dd-dedbe7bc9b9a": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow470",
			"name": "No",
			"sourceRef": "58e19ac0-7b08-4243-80ae-b02fd1c8b018",
			"targetRef": "6aa491a3-33f5-428c-82f2-4c911cc1a087"
		},
		"02d34c31-0507-4cf8-9ed7-b17a2338fa34": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isResourceProfile}",
			"id": "sequenceflow471",
			"name": "Yes",
			"sourceRef": "58e19ac0-7b08-4243-80ae-b02fd1c8b018",
			"targetRef": "dab92ecd-01ed-4792-a03a-4dd389cf16e1"
		},
		"1c9dad2e-5635-4fee-856c-2c874b7b279c": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow473",
			"name": "SequenceFlow473",
			"sourceRef": "6aa491a3-33f5-428c-82f2-4c911cc1a087",
			"targetRef": "056b1a11-e7a7-4ac2-bfe7-16e06a4e3b17"
		},
		"0ca8ee77-ffaf-4175-bbea-df88657b35e0": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow474",
			"name": "SequenceFlow474",
			"sourceRef": "76998587-b436-46d5-9654-f1d5b54cea7c",
			"targetRef": "58e19ac0-7b08-4243-80ae-b02fd1c8b018"
		},
		"8042c00a-02ac-4882-846f-9b10f3eba07d": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isResourceProfile}",
			"id": "sequenceflow475",
			"name": "Yes",
			"sourceRef": "db552930-7437-4f8f-9056-3a37b194590d",
			"targetRef": "fea4d57a-0882-412f-891f-b7c6b15ae174"
		},
		"37f1e805-4ec6-4a21-be72-bb1768430f12": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow476",
			"name": "No",
			"sourceRef": "db552930-7437-4f8f-9056-3a37b194590d",
			"targetRef": "f39b3834-3b10-49fa-9e9e-8712a79017d7"
		},
		"ce31d71c-1d0c-4f0d-b8a4-1cd44762469f": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow477",
			"name": "SequenceFlow477",
			"sourceRef": "f39b3834-3b10-49fa-9e9e-8712a79017d7",
			"targetRef": "56449570-8bd1-47f8-8a8b-e8cd7d8bec49"
		},
		"35c2a2ff-ba31-40df-9210-bdeacbce327d": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow478",
			"name": "SequenceFlow478",
			"sourceRef": "0e75953e-aa04-40f1-83f3-ce7f382926a5",
			"targetRef": "6a0c923c-5bf1-4ace-be3c-26e0c029a0ef"
		},
		"3e3e4ddd-69fb-4c5d-a5d5-0d32ef13f11e": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isResourceProfile}",
			"id": "sequenceflow479",
			"name": "Yes",
			"sourceRef": "5cd8cdad-b206-47fa-9a69-d5a148329397",
			"targetRef": "80d8290b-5d1e-489b-9196-04a30020661e"
		},
		"7e350b76-f56b-4cd9-85fd-32e05b782f36": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow480",
			"name": "No",
			"sourceRef": "5cd8cdad-b206-47fa-9a69-d5a148329397",
			"targetRef": "b46ffe03-6e9e-443f-911b-e8e8f01c2d31"
		},
		"632e0cca-a529-4e1c-b2cf-20f3c86d795f": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow481",
			"name": "SequenceFlow481",
			"sourceRef": "b46ffe03-6e9e-443f-911b-e8e8f01c2d31",
			"targetRef": "c8116791-4591-4339-b807-e69c36f74171"
		},
		"4e8a9a04-dc3b-467e-bc80-70ed030fb5a6": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow482",
			"name": "SequenceFlow482",
			"sourceRef": "cebf1053-229e-4ba3-a75f-ebae890a536a",
			"targetRef": "7048bfa2-ab10-4afa-af8a-d038f581ae65"
		},
		"59da0ed4-53aa-4f78-abc8-1e191ef991d1": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow490",
			"name": "SequenceFlow490",
			"sourceRef": "2edba57b-3b16-4bb3-8a87-65c324f5ccc6",
			"targetRef": "e96d3276-d4b5-4a0d-b0e7-d26d9c3ef2d4"
		},
		"9a719e3a-4b4e-47c3-9d20-dd818a05fa36": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isResourceProfile}",
			"id": "sequenceflow491",
			"name": "Yes",
			"sourceRef": "82b83e36-bb6a-490a-b97a-248c6121c9f5",
			"targetRef": "30a7f6e6-bb09-4cdd-bc98-0f26bfc4c4b3"
		},
		"d70da814-e8af-4a63-aaa8-7aa8cd89329a": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow492",
			"name": "No",
			"sourceRef": "82b83e36-bb6a-490a-b97a-248c6121c9f5",
			"targetRef": "79b7e998-0eb2-45e9-b322-2e5d832d4957"
		},
		"ebab49e6-386a-4308-a721-c2364b004304": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow493",
			"name": "SequenceFlow493",
			"sourceRef": "894232bf-957c-4e96-9bff-7b029be4391b",
			"targetRef": "79b7e998-0eb2-45e9-b322-2e5d832d4957"
		},
		"4bd665ed-407c-4621-99b2-7af671158353": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow494",
			"name": "No",
			"sourceRef": "37d6cb53-75f5-41ba-a49c-9c783cc7a31a",
			"targetRef": "f77539b1-89c8-4ef9-82ca-ee0ffb34b3ab"
		},
		"29ddfff3-14ff-411e-a0da-d8c1e9a45f73": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.deleteActvityList}",
			"id": "sequenceflow495",
			"name": "Yes",
			"sourceRef": "37d6cb53-75f5-41ba-a49c-9c783cc7a31a",
			"targetRef": "b80468b1-0eec-4cd2-b814-5f0b68305fe1"
		},
		"34e41670-0063-4599-b99b-81251884edac": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow496",
			"name": "SequenceFlow496",
			"sourceRef": "b80468b1-0eec-4cd2-b814-5f0b68305fe1",
			"targetRef": "f77539b1-89c8-4ef9-82ca-ee0ffb34b3ab"
		},
		"139012bb-af50-4732-a899-04f6dcee5cc3": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.Skip_Resource_Approver}",
			"id": "sequenceflow497",
			"name": "Yes",
			"sourceRef": "c4d2b059-6975-4dd7-aae8-b5bf03d80d5a",
			"targetRef": "14a0fe86-1d2a-4966-b335-741b6be5059e"
		},
		"5a69f96e-36f6-4618-a44a-43cb2add3a32": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow498",
			"name": "No",
			"sourceRef": "c4d2b059-6975-4dd7-aae8-b5bf03d80d5a",
			"targetRef": "00a7fee2-04b8-47c7-a454-81a8431932a4"
		},
		"737059f1-bb71-45fa-9ceb-56da13ca09a1": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow499",
			"name": "SequenceFlow499",
			"sourceRef": "29b0a44f-4005-48a5-8de9-41a4315e46b8",
			"targetRef": "873a3e95-1481-4253-946d-dec2435b5e5e"
		},
		"8eb2275a-90e5-44b6-8e97-1eb50668583e": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow500",
			"name": "SequenceFlow500",
			"sourceRef": "873a3e95-1481-4253-946d-dec2435b5e5e",
			"targetRef": "d7519588-4503-490f-8c6b-2824c558ff2e"
		},
		"331266c9-f582-4c70-b39a-afa20d6a957f": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow501",
			"name": "SequenceFlow501",
			"sourceRef": "d7519588-4503-490f-8c6b-2824c558ff2e",
			"targetRef": "08e8ea17-39f4-48cc-83cf-5fe60227f741"
		},
		"e7590ffb-5f9e-405e-a2ad-e8ed5f3a9e15": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow504",
			"name": "SequenceFlow504",
			"sourceRef": "b19f799c-827d-4efa-88e2-a17f7678dfb8",
			"targetRef": "c2f6848b-b53f-48d6-9a1b-c4fe07641521"
		},
		"1d9457a7-4513-40e3-a852-07693c287086": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow505",
			"name": "SequenceFlow505",
			"sourceRef": "c2f6848b-b53f-48d6-9a1b-c4fe07641521",
			"targetRef": "cbe4be68-f965-4841-bdef-c35716ac6c09"
		},
		"a7e519ea-06df-433e-b265-0944ea4c572c": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow506",
			"name": "SequenceFlow506",
			"sourceRef": "cbe4be68-f965-4841-bdef-c35716ac6c09",
			"targetRef": "26d15377-8229-412a-941f-f4b55b9d8660"
		},
		"139d6bcd-e3e7-432e-af92-d9987bade40b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow508",
			"name": "SequenceFlow508",
			"sourceRef": "dab92ecd-01ed-4792-a03a-4dd389cf16e1",
			"targetRef": "67f9522c-2fa9-4e5b-9eab-36406162541e"
		},
		"9790ef71-abfc-4466-99b5-7787e4a44ee5": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow509",
			"name": "SequenceFlow509",
			"sourceRef": "67f9522c-2fa9-4e5b-9eab-36406162541e",
			"targetRef": "dcb51126-0d0e-4846-9e4a-abfd8999ebfa"
		},
		"254e45f8-4375-4f04-9181-afbfa83439c7": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow510",
			"name": "SequenceFlow510",
			"sourceRef": "dcb51126-0d0e-4846-9e4a-abfd8999ebfa",
			"targetRef": "e16ccd4d-94a4-4355-9291-977b33e1b91a"
		},
		"10ff8aa6-d387-4b52-a6fa-7dc71ae00203": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow511",
			"name": "SequenceFlow511",
			"sourceRef": "fea4d57a-0882-412f-891f-b7c6b15ae174",
			"targetRef": "57ccb261-0689-431d-9ab3-0bda27e02dae"
		},
		"d8c39022-9a9e-4444-babb-e04ce1fbd08c": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow512",
			"name": "SequenceFlow512",
			"sourceRef": "57ccb261-0689-431d-9ab3-0bda27e02dae",
			"targetRef": "bf0bc050-60c0-4e34-839c-6baca8156286"
		},
		"e24ea8e0-e501-4390-a80f-39ed7ad60844": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow513",
			"name": "SequenceFlow513",
			"sourceRef": "30a7f6e6-bb09-4cdd-bc98-0f26bfc4c4b3",
			"targetRef": "de105fa5-c4a1-4579-8dc3-1d7de4ba9288"
		},
		"5f2c758f-f63b-4525-82c7-8b695b1c0732": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow514",
			"name": "SequenceFlow514",
			"sourceRef": "de105fa5-c4a1-4579-8dc3-1d7de4ba9288",
			"targetRef": "53047d61-27f0-4197-bb50-1e3f021c657a"
		},
		"06abd4d1-7afa-435d-a01c-7be5656bcfeb": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow515",
			"name": "SequenceFlow515",
			"sourceRef": "53047d61-27f0-4197-bb50-1e3f021c657a",
			"targetRef": "cddc4689-b295-4ff2-bba3-42988d40ae93"
		},
		"289cca64-0c9e-495a-9ef6-74c48a2a4806": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow516",
			"name": "SequenceFlow516",
			"sourceRef": "e96d3276-d4b5-4a0d-b0e7-d26d9c3ef2d4",
			"targetRef": "b08f281a-cf6e-4d5d-b659-6716a1830378"
		},
		"98a897ec-86e6-419f-978d-19ee6e429257": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow517",
			"name": "SequenceFlow517",
			"sourceRef": "b08f281a-cf6e-4d5d-b659-6716a1830378",
			"targetRef": "3e19ecbd-1340-465c-8976-82efa862cfe8"
		},
		"cbf3a6c6-9fc8-48b8-b70c-b126b7a7b8bf": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow518",
			"name": "SequenceFlow518",
			"sourceRef": "3e19ecbd-1340-465c-8976-82efa862cfe8",
			"targetRef": "9d91e666-d780-414b-aedd-55ee0147bec9"
		},
		"9867138c-d426-41ca-baf3-78cf58c98725": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow520",
			"name": "SequenceFlow520",
			"sourceRef": "6a0c923c-5bf1-4ace-be3c-26e0c029a0ef",
			"targetRef": "fb3b491e-00c5-46f0-bd63-8be142ff9afb"
		},
		"36b25802-a4e9-46b3-bf4c-724424a85990": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow522",
			"name": "SequenceFlow522",
			"sourceRef": "fb3b491e-00c5-46f0-bd63-8be142ff9afb",
			"targetRef": "04c2516e-f970-4c59-abba-d57b4e78a3fc"
		},
		"05834487-26f0-48af-9ab7-ff1fe9de6fe1": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow523",
			"name": "SequenceFlow523",
			"sourceRef": "27736dd6-1b84-467b-8286-9ba3b99c2d95",
			"targetRef": "a13be89b-e4fc-432a-b14e-605cd21a47c9"
		},
		"496fae2a-0f83-448c-9101-ff234eeaa32b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow524",
			"name": "SequenceFlow524",
			"sourceRef": "a13be89b-e4fc-432a-b14e-605cd21a47c9",
			"targetRef": "56449570-8bd1-47f8-8a8b-e8cd7d8bec49"
		},
		"a2172b45-2f6f-4b29-bca4-54943585f156": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.ResDirectManagerNotif}",
			"id": "sequenceflow525",
			"name": "Yes",
			"sourceRef": "04c2516e-f970-4c59-abba-d57b4e78a3fc",
			"targetRef": "27736dd6-1b84-467b-8286-9ba3b99c2d95"
		},
		"83f51d6f-26be-450a-96fd-8076045b8195": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow526",
			"name": "No",
			"sourceRef": "04c2516e-f970-4c59-abba-d57b4e78a3fc",
			"targetRef": "a13be89b-e4fc-432a-b14e-605cd21a47c9"
		},
		"e6de11d8-0f55-4fd9-b9bd-c8f228050d7d": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow527",
			"name": "SequenceFlow527",
			"sourceRef": "0a34cbbb-0781-423a-a550-c0900b8f51c2",
			"targetRef": "5623d2f2-5e02-49f3-a96b-bcf58d76c3d4"
		},
		"08ab5f9e-fa04-4ca8-842e-34dddba41756": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow528",
			"name": "SequenceFlow528",
			"sourceRef": "5623d2f2-5e02-49f3-a96b-bcf58d76c3d4",
			"targetRef": "e16d155c-2186-46c1-b37c-6d342092c68f"
		},
		"a03b44f6-6be4-4601-9629-b9bbbc656218": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow529",
			"name": "SequenceFlow529",
			"sourceRef": "e16d155c-2186-46c1-b37c-6d342092c68f",
			"targetRef": "1626e402-eabe-408f-9fa8-2b65959fff3a"
		},
		"d80efe57-812b-4fe7-aaef-878d145bfc4f": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow530",
			"name": "SequenceFlow530",
			"sourceRef": "0c3397ab-660e-4a01-be0d-e17c50fac2b0",
			"targetRef": "dce010fe-7fea-40cf-bf0c-71b0fdbc065b"
		},
		"fe46f5ab-4090-4397-9348-8ee45fceb7cb": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.RequesterEmailNotif_flag}",
			"id": "sequenceflow531",
			"name": "yes",
			"sourceRef": "e16ccd4d-94a4-4355-9291-977b33e1b91a",
			"targetRef": "fdf35015-9267-4b31-ba80-49759b8bb63b"
		},
		"9466e5a4-73ef-41ca-9751-48a4f769200c": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow532",
			"name": "No",
			"sourceRef": "e16ccd4d-94a4-4355-9291-977b33e1b91a",
			"targetRef": "056b1a11-e7a7-4ac2-bfe7-16e06a4e3b17"
		},
		"b71c9f7b-8efe-42f0-a3bf-6f3335f5620b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.ResourceEmailNotif_flag}",
			"id": "sequenceflow533",
			"name": "yes",
			"sourceRef": "bf0bc050-60c0-4e34-839c-6baca8156286",
			"targetRef": "0e75953e-aa04-40f1-83f3-ce7f382926a5"
		},
		"3d42fc68-48d4-461a-9dea-ab0ffe851fe5": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow534",
			"name": "No",
			"sourceRef": "bf0bc050-60c0-4e34-839c-6baca8156286",
			"targetRef": "6a0c923c-5bf1-4ace-be3c-26e0c029a0ef"
		},
		"5286ac24-b81b-4d14-9afe-640211fe21bb": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.AllProssEmailNotif_flag}",
			"id": "sequenceflow535",
			"name": "yes",
			"sourceRef": "a66aa8f6-ce7d-466e-b8ff-0b5bbdfe81b3",
			"targetRef": "154c1d85-9385-4c63-985b-f7c22edcc182"
		},
		"aa2128da-a24e-4223-887f-2e4bf5990270": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow536",
			"name": "No",
			"sourceRef": "a66aa8f6-ce7d-466e-b8ff-0b5bbdfe81b3",
			"targetRef": "dce010fe-7fea-40cf-bf0c-71b0fdbc065b"
		},
		"d9c0d596-5fd7-49ff-983c-a1a5e9455a1a": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.AllProssEmailNotif_flag}",
			"id": "sequenceflow537",
			"name": "yes",
			"sourceRef": "167969ee-99a3-4d35-9711-1cb7a7cbec12",
			"targetRef": "df47c6db-fc0a-4195-b54e-582286587c3b"
		},
		"2d634131-11aa-4995-88aa-252966acf207": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow538",
			"name": "SequenceFlow538",
			"sourceRef": "167969ee-99a3-4d35-9711-1cb7a7cbec12",
			"targetRef": "644f787d-b26c-4962-a09c-4dad807bc97c"
		},
		"80cf9ad3-c3eb-41b0-8107-a553a8fa6fda": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow539",
			"name": "SequenceFlow539",
			"sourceRef": "b5288eba-8fc8-411b-a9b8-048c8a0d8a65",
			"targetRef": "b2b5df75-228e-4e7d-bfe0-e03177186322"
		},
		"7dd6270a-4c50-48ac-9034-accecd52ac3d": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow540",
			"name": "SequenceFlow540",
			"sourceRef": "b2b5df75-228e-4e7d-bfe0-e03177186322",
			"targetRef": "675f37df-4e36-4dca-bd2a-d373fef4aa09"
		},
		"29878ea2-4eb5-48d1-b06a-08b1ac15de59": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow541",
			"name": "SequenceFlow541",
			"sourceRef": "675f37df-4e36-4dca-bd2a-d373fef4aa09",
			"targetRef": "c8116791-4591-4339-b807-e69c36f74171"
		},
		"36582cd5-a4d5-44f3-8a81-bcb13eb9af5a": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow542",
			"name": "SequenceFlow542",
			"sourceRef": "dc1860ba-eae3-41ff-96cf-780880391467",
			"targetRef": "019c17a6-e0c0-46b9-b712-c0d34cf252e5"
		},
		"e682a9c6-3eab-4852-82f5-b8afed35e709": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow543",
			"name": "SequenceFlow543",
			"sourceRef": "019c17a6-e0c0-46b9-b712-c0d34cf252e5",
			"targetRef": "5718cc40-784a-446f-804a-686f62b8a38d"
		},
		"de475d99-d316-45b2-bb3d-35472efe34ec": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow544",
			"name": "SequenceFlow544",
			"sourceRef": "5718cc40-784a-446f-804a-686f62b8a38d",
			"targetRef": "c8116791-4591-4339-b807-e69c36f74171"
		},
		"a4c1276f-ced6-49a0-a4df-212c8f2fe429": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.commentNotif_flag}",
			"id": "sequenceflow545",
			"name": "Yes",
			"sourceRef": "7ade6462-abd5-40a6-9e34-08a157ba9cf0",
			"targetRef": "57733068-a0f9-45ef-98a4-b14c150c9705"
		},
		"1e1be659-516b-44a2-a9fb-664eab510819": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow546",
			"name": "SequenceFlow546",
			"sourceRef": "d26896e5-5e29-4c01-8fa3-c4f2f5f52837",
			"targetRef": "06891468-ae19-4a5e-96aa-e97bb68a42c1"
		},
		"0b6bcc4d-09c0-48e5-82bc-5db593c6fe31": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow547",
			"name": "SequenceFlow547",
			"sourceRef": "57733068-a0f9-45ef-98a4-b14c150c9705",
			"targetRef": "d26896e5-5e29-4c01-8fa3-c4f2f5f52837"
		},
		"910787e8-1f48-4f73-83dc-66f49a969a17": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow548",
			"name": "No",
			"sourceRef": "7ade6462-abd5-40a6-9e34-08a157ba9cf0",
			"targetRef": "d26896e5-5e29-4c01-8fa3-c4f2f5f52837"
		},
		"e25811f9-89f2-490f-ae80-0908436bc420": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.commentNotif_flag}",
			"id": "sequenceflow549",
			"name": "Yes",
			"sourceRef": "4a2ba629-a4ac-4c75-bad3-6465304ac364",
			"targetRef": "ada573ed-5ba3-4e9d-88a5-69fb301817f3"
		},
		"5b0dbaa7-0833-4852-8544-a3e0066e354b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow550",
			"name": "SequenceFlow550",
			"sourceRef": "ada573ed-5ba3-4e9d-88a5-69fb301817f3",
			"targetRef": "e62a9b1b-ce64-4fc4-b605-617b23ded67a"
		},
		"0bc7bdaa-432e-45a2-9405-b60c205429b1": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow551",
			"name": "No",
			"sourceRef": "4a2ba629-a4ac-4c75-bad3-6465304ac364",
			"targetRef": "e62a9b1b-ce64-4fc4-b605-617b23ded67a"
		},
		"b37335ab-ce98-4134-8396-6fa4f72b2d36": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.commentNotif_flag}",
			"id": "sequenceflow558",
			"name": "Yes",
			"sourceRef": "47ec03ab-1a9b-4611-ad45-62f351176504",
			"targetRef": "7afcbd35-981f-40ad-be79-b73c357b3e88"
		},
		"8cbbfa2a-4135-482e-8e03-1025a17802d8": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow559",
			"name": "SequenceFlow559",
			"sourceRef": "7afcbd35-981f-40ad-be79-b73c357b3e88",
			"targetRef": "a8cd3376-6607-467a-ad8a-e981bdb681d9"
		},
		"0239ecf6-2bde-462e-ab54-dcaf8be3a422": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow560",
			"name": "No",
			"sourceRef": "47ec03ab-1a9b-4611-ad45-62f351176504",
			"targetRef": "a8cd3376-6607-467a-ad8a-e981bdb681d9"
		},
		"30862a01-6244-400c-8890-44d7f4d8475c": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow561",
			"name": "SequenceFlow561",
			"sourceRef": "91b9adda-ddfc-4028-8044-a9897babddfb",
			"targetRef": "47ec03ab-1a9b-4611-ad45-62f351176504"
		},
		"cd8798ef-1418-4af7-9969-6f67bebd2e98": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.RequesterEmailNotif_flag}",
			"id": "sequenceflow562",
			"name": "Yes",
			"sourceRef": "22c0a6d3-9563-45cd-a631-16ace9e8fdbe",
			"targetRef": "8dcd09bd-99d5-4347-9bfb-102a27f1a949"
		},
		"0651d623-3b71-4c71-9dd8-df42359ad9e1": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow563",
			"name": "No",
			"sourceRef": "22c0a6d3-9563-45cd-a631-16ace9e8fdbe",
			"targetRef": "dc1860ba-eae3-41ff-96cf-780880391467"
		},
		"9291e3f6-627b-42b7-950d-d7a0d164f0b7": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.ReqTerProjRejEmailNotif_flag}",
			"id": "sequenceflow564",
			"name": "Yes",
			"sourceRef": "1626e402-eabe-408f-9fa8-2b65959fff3a",
			"targetRef": "49ceda69-aeb0-4377-bb38-9f7b75d6deda"
		},
		"785cb1c9-0e29-4cda-92f9-027cd6c963e9": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow565",
			"name": "No",
			"sourceRef": "1626e402-eabe-408f-9fa8-2b65959fff3a",
			"targetRef": "15e032f9-93a1-47b5-88f6-2e955a9372b3"
		},
		"68ffff6d-17e1-4d54-b116-f00b434144ba": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.ReqTerProjRejEmailNotif_flag}",
			"id": "sequenceflow566",
			"name": "Yes",
			"sourceRef": "9d91e666-d780-414b-aedd-55ee0147bec9",
			"targetRef": "77009387-aab8-4f42-8f7c-f4e10985f460"
		},
		"13c8467d-cc25-4919-82aa-981c927ba3bf": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow567",
			"name": "No",
			"sourceRef": "9d91e666-d780-414b-aedd-55ee0147bec9",
			"targetRef": "cf128b14-466a-48b6-bbcf-c5ac8fc4c7b9"
		},
		"e498b954-ab68-4fa1-b71f-daf6d3269041": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.ReqClosureEmailNotif_flag}",
			"id": "sequenceflow568",
			"name": "SequenceFlow568",
			"sourceRef": "cddc4689-b295-4ff2-bba3-42988d40ae93",
			"targetRef": "894232bf-957c-4e96-9bff-7b029be4391b"
		},
		"d08f284a-ff9b-434b-9e3b-4c688fd2fb36": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow569",
			"name": "No",
			"sourceRef": "cddc4689-b295-4ff2-bba3-42988d40ae93",
			"targetRef": "79b7e998-0eb2-45e9-b322-2e5d832d4957"
		},
		"17796642-ed13-403d-a704-e368ef4ee67f": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow570",
			"name": "SequenceFlow570",
			"sourceRef": "26d15377-8229-412a-941f-f4b55b9d8660",
			"targetRef": "095a8d5e-d3f8-4251-957a-3ef0b54b43c6"
		},
		"0744a753-e469-45c8-887a-d8fe06650cea": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow571",
			"name": "SequenceFlow571",
			"sourceRef": "a0f2bc94-21d8-43c4-9726-2de6188586ed",
			"targetRef": "354d2614-4245-499d-981c-800e57c8b91b"
		},
		"5e7d40e9-1f0a-4fbe-a0b4-944d5e1ceeb7": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.newProcessorActionEmailNotif_flag}",
			"id": "sequenceflow572",
			"name": "Yes",
			"sourceRef": "095a8d5e-d3f8-4251-957a-3ef0b54b43c6",
			"targetRef": "a0f2bc94-21d8-43c4-9726-2de6188586ed"
		},
		"3d919f92-7c4a-4f80-88c2-faa8232b7b13": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow573",
			"name": "No",
			"sourceRef": "095a8d5e-d3f8-4251-957a-3ef0b54b43c6",
			"targetRef": "354d2614-4245-499d-981c-800e57c8b91b"
		},
		"202b6dcf-65ff-41c6-af1b-3086209603bb": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow574",
			"name": "No",
			"sourceRef": "154c1d85-9385-4c63-985b-f7c22edcc182",
			"targetRef": "0c3397ab-660e-4a01-be0d-e17c50fac2b0"
		},
		"ec30671a-4a08-44ae-bee3-8b9cb9dfd810": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.decision  == \"Forward\"}",
			"id": "sequenceflow575",
			"name": "yes",
			"sourceRef": "154c1d85-9385-4c63-985b-f7c22edcc182",
			"targetRef": "dce010fe-7fea-40cf-bf0c-71b0fdbc065b"
		},
		"5c8fa50a-b66a-4c55-8e7a-b5e595365f46": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow576",
			"name": "No",
			"sourceRef": "80d8290b-5d1e-489b-9196-04a30020661e",
			"targetRef": "22c0a6d3-9563-45cd-a631-16ace9e8fdbe"
		},
		"afca7dd8-ef3c-41b8-a481-4845463558b7": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"condition": "${context.isRework}",
			"id": "sequenceflow577",
			"name": "Yes",
			"sourceRef": "80d8290b-5d1e-489b-9196-04a30020661e",
			"targetRef": "dc1860ba-eae3-41ff-96cf-780880391467"
		},
		"333972f2-059e-458c-a84e-12ded628c45b": {
			"classDefinition": "com.sap.bpm.wfs.SequenceFlow",
			"id": "sequenceflow578",
			"name": "SequenceFlow578",
			"sourceRef": "dc46d7b3-eeb3-4c5d-a22e-53573488ff79",
			"targetRef": "91b9adda-ddfc-4028-8044-a9897babddfb"
		},
		"42fa7a2d-c526-4a02-b3ba-49b5168ba644": {
			"classDefinition": "com.sap.bpm.wfs.ui.Diagram",
			"symbols": {
				"df898b52-91e1-4778-baad-2ad9a261d30e": {},
				"53e54950-7757-4161-82c9-afa7e86cff2c": {},
				"6bb141da-d485-4317-93b8-e17711df4c32": {},
				"2621149b-aca7-4304-bccf-468e1c675fac": {},
				"3a991716-0f67-4501-b459-7820d56fea4d": {},
				"e7fc0df5-1f89-4e96-b6b5-7c39e046bf15": {},
				"03c339f3-b51a-46da-a68e-55098c986dda": {},
				"bc6fdfbc-6cfc-42a2-a532-b2861246a582": {},
				"49bfb5ef-0612-4192-bd49-b570cd450f11": {},
				"07892177-a393-4560-a641-3a13f003bca1": {},
				"dfd5a7de-7635-437d-a06a-b1e60b4d4729": {},
				"8b1d07e6-3b8e-4949-aa8b-4e831706c6d3": {},
				"660a3d29-5f0b-41d6-8483-a5102eb1d03a": {},
				"ebaae79e-d937-4c84-95af-11e971f6f273": {},
				"98eb0743-9d24-4fa6-8b28-9b9007e68186": {},
				"8feadb9e-9c15-4f91-b058-d27176e52036": {},
				"67913ec9-a0b9-4db3-8749-99e5e98bd02d": {},
				"7e2860b1-6f50-4aee-9c30-6e802a4175a5": {},
				"9395ff70-a472-490c-bf2e-38c46e38eb3a": {},
				"cd79d258-0677-451e-bbf1-dea2f587007d": {},
				"3f48b167-b9f5-4753-a098-cc8651377020": {},
				"1a7ea469-a95b-4019-a06d-962422e501ea": {},
				"5caefecc-6cd1-45a7-a89a-9dec5f87fbd8": {},
				"3513d8c6-6ed8-4a3e-882d-45a9ce719ee8": {},
				"103721ef-5a92-424c-ab80-e00e9093d0be": {},
				"844021d5-6eb4-4039-a4b3-c6e47f92ef87": {},
				"f22441c0-6710-410e-b8d6-b7087b6d1289": {},
				"c47e39b6-4858-4b3b-8613-b8e111e19d70": {},
				"4cd48edb-2ae6-444d-a029-7d889eea070d": {},
				"d9d65df8-894c-4780-851a-eecde4a4f09d": {},
				"301fd250-bc03-45dc-b66b-023576527860": {},
				"306ffc10-0d26-432c-8499-c22c29b43db4": {},
				"20b3727c-9d9f-4892-aa55-f63e60fa213a": {},
				"4e2480c2-0ab3-4fe8-b196-e1ec91b66df3": {},
				"ab8d6480-6c17-4d7f-9d7c-11a4f7dfc68d": {},
				"cfc28ee3-34a4-4fcc-8b57-ad5f1f187d7e": {},
				"606e578d-742c-4294-a057-cba00c2b95bc": {},
				"53ba6ebb-f6b8-4259-8e35-39bfddeefcf2": {},
				"863fc501-edeb-4770-b019-33a732d91f63": {},
				"47993291-0f07-43e9-b3c9-f93a859a0dcf": {},
				"31f05be5-0a40-439b-9686-a11ffd14fa6f": {},
				"5434b063-a41b-4a7f-9761-87a68e5d13f3": {},
				"787ffd9d-fd9a-4622-9598-13f3a405a621": {},
				"41a9ad41-dc95-48bd-b7ad-de378b1e7494": {},
				"c7eb7d0a-df5b-4a68-9ff6-63cc6bf67275": {},
				"9275932d-7614-4d6b-8bd2-53d1327315ac": {},
				"94b99184-c273-4bfa-a504-6c7c2a26966b": {},
				"171e8fa5-92a4-473b-b5fc-e1a5b27c4362": {},
				"121fb8cc-7457-464f-82f9-ece9a7fd42fa": {},
				"e83a5349-6f88-4f64-9cb9-c0e2e3649c75": {},
				"6375b8c4-6c05-4ae7-877c-2cc66375d078": {},
				"ff884ddf-41cf-42ea-b298-123f2ff83137": {},
				"d182234d-e5e6-4aaa-add2-0861531bc0c4": {},
				"3f3017fe-0e50-4593-96c6-670a0195798d": {},
				"92a95762-7766-47bb-8557-57da54b24f29": {},
				"43db4445-f24a-447d-af48-cf63cfc5f4b6": {},
				"3a80ecc6-2285-4149-9652-a3c5dcc72b01": {},
				"dca8bda7-e66d-486a-9a50-13e4a9462ddd": {},
				"4bfe8669-ec22-4922-93a8-7783be8a5a70": {},
				"79801fa1-cab8-4e92-80b8-506914da49c2": {},
				"1288ead1-1ad6-4b88-aca3-f761ee8862b1": {},
				"615150f5-269c-427a-85ac-7eea8863d484": {},
				"fc94b3fd-552b-4e40-b340-9d812410f046": {},
				"9cc135ac-3a6b-4fce-a442-43f5ae5eed86": {},
				"7f998f7a-67e3-44a4-a2d0-7d8baa07aa6d": {},
				"d56f87ee-5e54-4842-872c-0dc7e548e4a8": {},
				"c54df1cf-41d3-4482-bb9f-a9354cf294ba": {},
				"dfb11ba5-be42-4ef9-9274-f1802e2637f2": {},
				"77e8f4ab-0f45-4c04-9a4b-fe81fb9aa3d7": {},
				"29106054-e5ad-4f5b-8a6c-b1e96c96681d": {},
				"6fcee76d-0ed7-424c-ba0a-247437d757bb": {},
				"c3907832-d9da-44dd-894c-15b375c73179": {},
				"36df7ab0-b389-4bc8-965e-49ba395e7870": {},
				"db592951-f348-4cf8-a354-c7c4a7659699": {},
				"1017d15a-1c87-4885-b6b6-15ef22dd4390": {},
				"46b2157f-4d04-424d-9fe9-ba0e73bdda45": {},
				"1fcbdb09-d5d3-45e8-b321-3fa2f334bbe8": {},
				"acf8ff97-f004-4c05-b90c-16c52b76b5c9": {},
				"e812a0b6-7ce3-4a0f-8bb3-5ef4a70cd325": {},
				"924033e1-ecd5-444b-953d-29505106191c": {},
				"e2cf8dfe-830a-49a1-87dd-a5456a5cfdf3": {},
				"9772b0ad-e1ae-459a-951a-a47b0bbe6eff": {},
				"4cf7cb53-ab6f-48ad-9518-0db97d6c7577": {},
				"89d781c6-ff21-4bcd-8db2-880a8f91521a": {},
				"32d1af0d-ca71-40d3-8575-7e26f064a118": {},
				"88578040-c8e0-4756-98db-683694de425e": {},
				"957b7128-0d4d-4afb-8218-9d95cf6ac77e": {},
				"ff3b4afb-3adf-41e7-a14a-663eb9a4185c": {},
				"f9ab9845-cd09-4716-862c-8f7d4b4a8a62": {},
				"aa2a08df-81e6-43f6-a120-8a48175b5eb4": {},
				"9014bdcd-de46-4088-9a9e-d461c999cb99": {},
				"cfc047d4-3aa1-497e-a95a-2a87a2323a4f": {},
				"c4fbac88-6c25-48b2-8c3e-58d41fec1baf": {},
				"c592ce35-371e-43ca-9f9d-c87c96212403": {},
				"0030d14d-f989-4985-a587-d30cdff9872a": {},
				"67fc2f6f-0a02-4eb2-8304-26ee0fbbe753": {},
				"50e4d209-3ff1-46f0-a9b3-832f270ef38c": {},
				"9296ebed-ff46-473e-a29f-d36871fa696b": {},
				"8861ac74-c10d-4497-8b2b-5494756058b5": {},
				"98b8fd74-57a7-4038-9406-ff8031f5480c": {},
				"3cec4dbf-5aed-4529-bff8-741fd7249f21": {},
				"91497e4b-752b-4ef8-a492-7057b707bf6a": {},
				"e00568be-1261-474b-b951-1628158d8bf8": {},
				"2b4f1117-7461-41bb-85e0-ef3c45a41971": {},
				"03cd082b-a89d-48ef-b323-9b3681487576": {},
				"f5a71cf1-a25a-44eb-83fc-39272bcddb77": {},
				"24fe8e17-fe7a-4104-bfdb-a575f47c606b": {},
				"27e7fbea-25f0-4e60-809a-5fb8e3cf5f0b": {},
				"34f093c8-7a03-46b6-9f58-92d0c848c917": {},
				"0122faf4-2d34-426b-9496-69702adaf663": {},
				"8e2c8089-f912-4177-b101-7f5992f30871": {},
				"cdc5fd4d-9cfa-49e8-8e2b-a1c20011bb6d": {},
				"7cf1f501-6d02-4477-984f-bc340d4df5bf": {},
				"e595b480-97d6-4b3d-bc7e-9a56253a2e0c": {},
				"1437fcee-0f68-45da-bb2d-3e8a5e0b20f9": {},
				"25607da7-fc8b-4db0-8a8d-8f1c2fc11042": {},
				"6e1fa95c-6edc-497c-9f26-e667fd1ea2c1": {},
				"6bcd1d17-1c80-4135-8e35-de10fe7e4d49": {},
				"9fa9362b-448b-4458-bf5d-554f0665365c": {},
				"9a4c92f5-20d9-4d36-abe5-971113fbf059": {},
				"3da8774e-916f-4f8a-bcf9-7987280ab61b": {},
				"045387fa-4c7c-467e-8918-c50bc4da8297": {},
				"85440f67-5781-4de5-a8f0-03ac320a5628": {},
				"6e186c83-62fe-4b36-a14a-fc0223fa5c68": {},
				"30f544b9-5e9f-4b2b-ae7e-8b1329b0939f": {},
				"2732499b-8d60-41a4-a689-5a4097a719cd": {},
				"d2c24999-d31f-4e27-b38a-c2a62b54928a": {},
				"0e43ea46-0ea4-4373-9ea0-6eb016bfedcd": {},
				"c8bc2972-c126-4274-a338-ab7a632750af": {},
				"3ca537c6-c0f5-41f6-9653-858bfa70a34d": {},
				"cbd817f7-dcb9-4351-bff3-4ad6430bd533": {},
				"c89ca974-b11a-4450-959e-86ebbbc1738a": {},
				"21bad0a2-d6e3-433d-8944-6dc28022f143": {},
				"4fb3579d-b2f3-4e27-ac82-b5e0ca1fb445": {},
				"169f3af9-f19f-494b-881c-b314123bde71": {},
				"9c008f40-4847-4240-8a28-9d35d0f20687": {},
				"49331e46-8649-49f3-82af-65776b6b2b97": {},
				"97bbc8e1-60c5-4c09-b0e6-606f748f5df2": {},
				"53eacba1-7038-424c-9bbf-702f5fa9a4b3": {},
				"ccca4b83-5983-4c94-b4c7-cf57310f20f5": {},
				"df3be51d-2bfb-4025-9846-7ebf3d912420": {},
				"7a8d3bf0-cdb2-4931-9e25-aad100f8aaf6": {},
				"35e3afb0-2b0c-4dfd-80fb-d9f8209de2eb": {},
				"685fbb9e-c129-4e1f-82fe-f1ae39faa8a4": {},
				"4f6edc66-2f91-4702-80f9-cd5d0c25a814": {},
				"24880f93-8769-4786-813e-ef2ed5adf4f0": {},
				"0dc7ea91-5cad-40cb-a4b2-4714ecfbaced": {},
				"7cc312f2-51ff-4c6a-a81c-31d311450f17": {},
				"af00e15e-5bfe-4895-97e4-422e6b8ff101": {},
				"64040a6a-9ae0-4cd4-aa3f-ee8e6e280864": {},
				"b0332aec-f22c-4d2a-9ad4-50aa6a45d127": {},
				"68661a79-2604-4820-a826-200c07601a4e": {},
				"0afe4a2d-0b7f-400e-8107-54e717b8d6f1": {},
				"655cd9c8-680f-45a7-893f-8de6033b058f": {},
				"d10c530e-d834-401c-88af-1a4ddcd37251": {},
				"ce6b16ca-c5aa-46da-b3fb-be897e0dc290": {},
				"a73b9479-a812-4570-82fd-7ef4785a3eaa": {},
				"9b3429a5-2499-4ea8-a004-6c626ea1cb7c": {},
				"597100a3-39c4-4893-b0ba-8e97784c6737": {},
				"aa848e00-df77-4d65-b7c6-665193495c7a": {},
				"51d50305-ef0c-4ccf-8f50-ad241ec43bcf": {},
				"5627ed87-4588-4f43-9fc5-bdac55c915a9": {},
				"3b4db367-b143-48e8-a1a1-47962f0d0add": {},
				"890b6660-4b5e-4c42-a197-f63bee98a590": {},
				"0e1ffb32-eff0-4f52-978d-5ea5e5b7697f": {},
				"9564665e-ad8d-43d8-9cdb-58bf986948eb": {},
				"73e35dd0-a32a-478a-82bc-ad9861f8cca8": {},
				"590f14b7-9928-48cc-a7a7-15975724541c": {},
				"c9224d24-8eef-4f72-9152-ba0757292971": {},
				"80389e88-012a-4351-b50e-8965f1119375": {},
				"bd90d11c-983d-46cc-b438-749d98267604": {},
				"8865b959-4554-4b0b-a53d-25dda0a3a7af": {},
				"c653ed50-d0b4-49f4-877e-33a724095592": {},
				"f00005d7-ce72-44f7-b03a-a360f4bf546c": {},
				"380c924b-fc7a-487c-a075-665d7a6fddf1": {},
				"772c915a-89e3-40c1-81ab-142b6fff851e": {},
				"a4323751-bcc5-4cf0-a12a-8d88d03d7677": {},
				"4537fbcb-6aa9-49cf-b2b2-63494e81b2fb": {},
				"c3bb08e1-d00b-4b90-890f-7403590936a2": {},
				"77dba93a-8df6-4018-8808-701c58eac3bd": {},
				"3b898206-27c4-4f32-a524-32f297422438": {},
				"6b9fd3c7-c0fc-466b-94ed-869fe0d91a7c": {},
				"0694b614-b220-4a78-8cf5-4bd4bdd801d6": {},
				"468dd65c-26b8-47e6-b0ba-157490f3b2b2": {},
				"3271f36a-10f0-4482-b650-1a5b8d2b1c8d": {},
				"5779acb8-540d-411a-8ec2-73bbbd994e47": {},
				"466ae39f-55de-48e1-bc70-519f0e92fe6c": {},
				"466aed42-84bc-4172-9e3b-ee4c94d91334": {},
				"766b9d0a-985d-4aa9-b1f1-db4430b5b0a4": {},
				"81ff534f-de61-4ce2-8d70-17452fd71559": {},
				"4631dc3d-febd-45e1-a507-c40a11176e54": {},
				"cf10fba9-92cc-4115-a7bd-8b0097b0e268": {},
				"6d2722e7-d064-4781-8e80-5f52c4e10ff8": {},
				"feb3344a-3cd7-426b-9678-64c544cc7b05": {},
				"2351c119-2466-4e25-9d4b-1d8762143abc": {},
				"d9952f9f-efda-46f7-9d22-b294e1199d99": {},
				"3b4476ff-bdbc-4d38-9414-7132f5eeb041": {},
				"048874ef-105c-4b68-9f65-8964b44af9b1": {},
				"4d62f9b8-050a-4209-afd9-125a72448ee1": {},
				"6d4beb80-62d9-451f-b118-c47219880f55": {},
				"7eb5935a-3caf-4314-9ff0-1449d4d9c094": {},
				"e2518623-a595-4f88-986b-cad2990c1bd2": {},
				"323852f8-5099-40f0-8228-af9911d71dd9": {},
				"fdd1a361-a248-4163-ab4e-f1370174c0b1": {},
				"739128ba-e730-4b67-b5f3-69309d425e57": {},
				"5e979401-1d9a-4f75-a0f0-8b3a4261e955": {},
				"a6f5200e-e5cc-45c9-b724-0da533fff498": {},
				"0ed199e0-4676-43ca-b314-d85e8bb84e43": {},
				"a239056d-dd1d-4757-8e6d-adc9a0518f93": {},
				"652976b4-9933-4e4d-89c3-d0dad8e42b1c": {},
				"9fa71286-3452-4dac-953b-857ca537ef7a": {},
				"827000e5-faff-4653-91b0-8ebd01cfebdc": {},
				"19217147-6e76-43b2-a45c-4498ffcf14aa": {},
				"d80bcc7d-a79c-4382-8f98-3237b35f18f5": {},
				"dee7bf7e-22a0-4ab1-84bf-8a7301f79caf": {},
				"51844daf-1dc9-45fb-9de0-3eb2c4f6d4c5": {},
				"7b5635e9-9db0-4a5b-92dd-b94444d3c6f1": {},
				"c860905f-11db-4878-bc08-e8f4d950a5fc": {},
				"b72928d5-20c2-4a6d-a392-6b232b7f0ab9": {},
				"77d0fe04-649e-4263-b280-67c9901f538c": {},
				"6581082d-10ee-467f-8b7e-bedf5c35707c": {},
				"94f6f1bb-ea12-4367-b0e7-d5da1e033787": {},
				"11342345-76e0-491b-8f28-8ab7cee7fdab": {},
				"0a0377f0-9453-4fa2-9b2f-166bf15c4cf6": {},
				"69511806-fa2b-45fd-bf59-5a4d738d404d": {},
				"c99a12bc-9546-4a8d-b9b9-68cdcbf5bc57": {},
				"bae1c41e-4795-4768-9958-33a590d3e735": {},
				"5bb48ff4-725f-4547-bae4-44db2d2c3a5e": {},
				"e993a4e1-6901-437c-857c-72e147cfb2ca": {},
				"16d45710-8451-4962-81f8-ce010bc73a3e": {},
				"f8a19cae-6eaa-4b5d-a9b4-4baab54494c5": {},
				"16c2c824-ea82-40ef-9788-35c5bae8e9de": {},
				"bb8fde7d-3253-4f78-9a04-39946bb52057": {},
				"3c646481-25bf-4488-b777-ad5ede05b026": {},
				"2282dcd6-9e25-4642-b623-fcbe98c52637": {},
				"4246423a-712a-4adb-bd7a-fbb7e847169f": {},
				"1a830bfb-eaa3-4073-bab5-43fb6bc39729": {},
				"f9938e7e-351c-4292-816b-b29391c18b31": {},
				"6cf73f92-88d8-45bd-882f-c4954b2095fd": {},
				"171fa25d-9feb-4b8c-8cf9-93f36807998d": {},
				"cf78967e-83a3-4b91-aebf-4d64f9118bd3": {},
				"ccb71dce-fddc-4892-9737-d7b811918998": {},
				"66bfe4dc-af6a-4348-8d92-2da13d8f7a7a": {},
				"c0792ee4-03ad-4835-bcae-62a05f6c3b4d": {},
				"8864b501-df15-408a-bb0b-58911d53a2f3": {},
				"54b25b91-3f8b-4394-8d29-caa2a3eb9be5": {},
				"59c6f92a-28a9-4090-972a-ba07f2373132": {},
				"4d2b7e7f-29f1-44f2-93d9-4f37d4032c06": {},
				"98478846-955f-4ffd-a91a-007a839791cc": {},
				"c28d9314-2120-410b-8516-184c3382a3cf": {},
				"16b11f81-e13c-4a9c-8d87-8d0c61e9f321": {},
				"70b001ec-8375-4669-963d-b789bb50018a": {},
				"eefd155f-d80e-4254-b495-9b56c8811f05": {},
				"7e9a1a4c-e821-4c7d-ad14-314493be1d9e": {},
				"3ba0aa03-c964-4c25-b74d-87e1b7adecbf": {},
				"afcd29a4-9cda-49a5-a389-3c7ad2cd3f3a": {},
				"c4033ce4-f4a9-4667-91a9-aaf53bb29b29": {},
				"404dbd01-211a-4e6d-8541-1e7b6e81f553": {},
				"78cbe836-7c06-45d3-905e-73e7dabb9a38": {},
				"bb1f173b-e982-4843-86e9-23c94adf6c18": {},
				"f21c00e3-b2ef-4b03-850e-da21df6a9fe9": {},
				"ad38a4e4-cd50-4f73-9f3e-29469669aae3": {},
				"3a64dcd9-10ff-45c0-bee0-55f5aebeccb6": {},
				"9d40d8a0-fe63-436a-a438-1886c2c546f4": {},
				"462a68f6-ee52-47eb-a2f9-71944020c8ea": {},
				"4dbf970f-b9f0-4c65-8194-39ea017c10bc": {},
				"9561b1c4-fef0-4f62-a786-e6c2972a42a7": {},
				"6eb65aa6-6c72-4e5f-851f-fa00a9b8682e": {},
				"06e4457d-dcda-4144-a9dc-851c127b2c87": {},
				"ee75e1cf-1556-46cf-ac98-751765f11b27": {},
				"464090ea-c764-4385-bd6b-813f5e5a66c4": {},
				"873bde12-20a0-4fb2-87f5-40efafd221e6": {},
				"d430478b-2859-47f2-8b43-201a700f437b": {},
				"71571374-f673-4350-b0a2-bae222ba90aa": {},
				"f1fe5eeb-ca33-41e7-9a76-c11ada1bac89": {},
				"f42b6e9f-15ee-451e-a043-136a8e5c9aaf": {},
				"6eff193d-17f7-439c-8f0a-e2acb7ccc58c": {},
				"a6f88a86-ce4d-43b9-a79b-1c6925cd2284": {},
				"ddfcb5c7-7239-4f55-ba6c-d14e748e6601": {},
				"bd3d3822-dc6c-4407-addf-63cb902f96e7": {},
				"3d145dbf-7bff-4924-b515-5423fb8c0109": {},
				"9d6dfb1b-305b-4cd7-b0a1-f64fd6d4e2a6": {},
				"2ba71b67-db72-4d22-a431-421f852caadb": {},
				"829fcaf6-1b27-413b-a6d7-a7d092745ed4": {},
				"02e17155-9f0e-4ef3-a5e7-063cee532c43": {},
				"739ba5b2-103c-4064-9656-caf9b3e858f3": {},
				"9145e63a-15ec-4952-827c-c39efffae1e6": {},
				"2cfeb210-aab7-4db5-b6cc-873ab8334a8a": {},
				"bbaa0dc8-f6dd-4390-9fdc-da8e213775aa": {},
				"baaf4802-c270-4e22-bf68-11aa9a70cc24": {},
				"a876129b-0815-4751-bdc7-9186c5321a03": {},
				"c9d78c30-20d9-418f-a688-d972baacc2f5": {},
				"54348a65-ee18-4189-a7a0-0b42f6bf61c8": {},
				"ae7f8462-9ce9-459c-97c2-e423b167ae26": {},
				"85643fbe-7260-4cb5-aee3-39f2104b4bed": {},
				"a30179d8-9214-460c-b10c-7a3bb660160f": {},
				"cafd65c9-643a-48fe-89f3-87a208afb747": {},
				"4fd53405-b26f-42a6-b518-3f2eefb9fe44": {},
				"3888a9b7-3535-449c-a325-cae4c9b1a548": {},
				"1d8c154b-3426-4d2e-a488-706667b0d880": {},
				"fd965f4d-e7ea-4637-b3d1-eb6d2f0b501f": {},
				"72481e90-5a48-4468-8e27-dfae740f0eb5": {},
				"08fb1454-a464-4ed6-9a6e-b09e6b6e8e86": {},
				"ab5c72be-c019-47d8-a3ae-a35a9b1c300b": {},
				"a1dd697b-6fa0-4b96-babe-0c4999c6b111": {},
				"4516b0b0-af2c-4803-962c-43c5c195795e": {},
				"d85b1965-70fa-4857-aae5-bb6b2d518e39": {},
				"1d555f2b-34cc-4126-a9cc-3169adc4cd55": {},
				"749449d2-021d-4b18-9e5f-0f79b87ee4c4": {},
				"b52f1431-f643-4833-8746-300141968fd4": {},
				"5a7c5c15-4cd5-4cea-b449-d488e5c2b9ff": {},
				"1c9569e3-e506-4ab6-9dd3-d57d08187c26": {},
				"f2530fb4-4ef3-49ec-b456-37969b2642aa": {},
				"5d4d01f9-64e3-4190-ba2a-78ac5b98c538": {},
				"57566077-b623-4181-8b1d-7a71395f4b0a": {},
				"8fa9bd0f-67b9-4b43-b335-46cdc674e5de": {},
				"bd616d84-fea6-4cde-856c-a3c81f853daa": {},
				"d2e6419a-34e5-4713-b3f8-1fb936cec3eb": {},
				"e48046f8-cd49-4e98-81ad-0ec5b10fcd63": {},
				"98db1bee-6b9a-438f-89aa-362013ed4d86": {},
				"77d170f7-116d-489a-8dea-b7ac3d3a6834": {},
				"7b3f3085-dec5-43c9-99a5-18dc0c29b599": {},
				"cef9ee46-1778-4deb-b87b-311034e58c92": {},
				"f79645bf-1501-47c9-87e1-334e4a631dd9": {},
				"15dda7d5-2248-4dc5-a31c-54c96f038e0c": {},
				"3ea2efd7-d638-46a8-88af-84aa38ce50d7": {},
				"c39c41bf-b110-425c-9c22-7b720a112a7b": {},
				"d877c2ff-65a7-4304-98d2-bce475314b72": {},
				"e03a4f62-89e4-4056-ac05-dbde495cf23f": {},
				"d9d612e3-6f0c-4f2b-b264-950bb5ce73e9": {},
				"74cb00fd-d2f0-4072-be13-b66300bf4446": {},
				"385ab0ca-5f57-4db4-8b49-232722080f0d": {},
				"43e1bd17-2487-4a7b-a769-9f6ac9c6b374": {},
				"0059b1f1-4e9b-4a18-a3b9-b48db2fef97f": {},
				"623a6dd3-834c-407d-b62d-5a084913e2f2": {},
				"2490bdd7-756d-4ae0-8441-33d090347b38": {},
				"03736adf-11d0-4556-9668-a92d84279781": {},
				"14927b3d-2c59-4020-9047-37f3afb9b112": {},
				"ca8458b4-3c66-4497-820c-6c24ec97150e": {},
				"f8040caa-1aa3-4382-bc3f-0aa8d96aad57": {},
				"a5cff74a-0b74-446e-93cc-f0436f2c26f0": {},
				"3425df6d-5e25-49b4-b6d9-984872505c17": {},
				"3dd77514-5b56-4bbe-995f-ce875ce86169": {},
				"acbaf306-e127-43ac-b0e7-c19072c134cb": {},
				"faf87618-214d-4336-8526-df3b80d1cda4": {},
				"58956c4e-ca11-412a-b761-b434a00f54fe": {},
				"92018014-8c66-4a67-bbc0-a61d8b598196": {},
				"b001d6f8-61a5-420b-bb52-599abfb9b183": {},
				"61b1be29-a1f2-4b7f-9a76-e06fe4d448d9": {},
				"d1ef8548-e447-426e-9069-353f2e9e3650": {},
				"18fa87af-2c4b-4b55-9c24-7497e2a7e634": {},
				"e2734640-32b4-420c-9acb-fa70fac853e9": {},
				"133c3981-0d1d-4c58-97f7-6df3f1599ba4": {},
				"d2122e52-dd83-4b16-a6f2-3252f20eb093": {},
				"8cc1cb9d-c76d-4f57-98d7-2bf5dfb3d6a9": {},
				"ac8d228e-4428-4e34-95dd-97325024b3c6": {},
				"ef5167e5-9895-42e4-a841-5d44f24f9dff": {},
				"aede55ed-5969-481a-a089-d520922a9abd": {},
				"d0503980-58a4-4bef-9730-f4ba20d9189d": {},
				"f8db9202-47ac-49e9-b440-fd5e4da9032b": {},
				"3d037c4c-877e-49e8-a2e2-f379409bafaf": {},
				"7a178339-588d-49d5-ada1-1e4ccdad29f6": {},
				"32908a03-7617-4289-9810-e2182f4a99c0": {},
				"841ed19d-6ca3-4da9-a306-ff413978db1d": {},
				"d06eec50-2ee1-487a-9aa6-5f3fe69ca611": {},
				"bdaa6d71-84f5-4fc2-a883-6a68229a8fae": {},
				"7f751e4d-6391-4f7e-b47c-17d2fa7676cc": {},
				"b7c9bd36-b35f-49f7-81a8-7ace1b4f8157": {},
				"f37773b8-7bd6-4db7-b677-f334285959ad": {},
				"49eeab01-2101-4d4d-b090-d9d3526d29b1": {},
				"e066526b-87b9-4f23-8d7f-d0bfc01ed767": {},
				"441a9e75-03d1-4fc4-992a-7374b22f6a37": {},
				"0a165d54-7c92-4d42-bcfc-5f8043744719": {},
				"551917d5-bd40-4f30-9f95-55fca43bbba5": {},
				"08f6cd37-7b66-4ef9-91ee-59cc76ad734f": {},
				"e5c036fd-c784-45f0-a92f-6ca4ecefd4e4": {},
				"df424ed1-9d9e-4d10-afcd-fe422bf305c3": {},
				"21dee0d2-2916-4ee8-b8c3-c8ea5a3023a1": {},
				"5c52d157-2c8f-444d-940a-c75ce8e68250": {},
				"c7edafca-fd6e-49b2-84ba-8663d8d6f9f4": {},
				"3b2a9e5e-2834-4259-8402-f7380602223f": {},
				"a9d43fab-8ac7-4d0f-9b76-a23b3de1ff31": {},
				"55846249-4335-4c2a-8455-35dfc9765340": {},
				"62e54757-5905-42c9-a59d-c68a56ba6c5f": {},
				"a49ccabf-f9b0-43f4-9d24-0669e47a5f8c": {},
				"b54db3f9-d38d-4b83-addf-e24947aae002": {},
				"6ba64dd6-bec6-4c30-824c-cbde159d4fb9": {},
				"fc3c54be-e85c-472d-8532-1b5e00b25096": {},
				"8da1f857-8c7f-4cdb-8e54-06275ecda30a": {},
				"24d6ea83-d84c-409c-be85-a7f011fe55e4": {},
				"7871179c-7000-42c4-a56c-54b050927d44": {},
				"60237e2f-5886-4d68-b0f7-4e8b774aa675": {},
				"9fca1dcf-92cc-4f8f-be83-a338196b369d": {},
				"b9f8d773-3e0a-4d02-8505-2391fcf3c388": {},
				"be1f513f-ae43-42cd-838a-0303927ecf9e": {},
				"0723ae60-12b6-472a-8b71-249c48f0b316": {},
				"d0a1d687-b9a3-40d9-a6b3-afc1edfb2e0a": {},
				"0de46006-bff1-4d24-b755-8d0ac78533e7": {},
				"fdb9d9b1-1a9e-47f2-a9aa-8eb892473ab8": {},
				"0578e208-82c2-45a7-b857-6ca5b45ae17d": {},
				"d5413ef6-da9e-43d8-ae69-a80062b119af": {},
				"b015ef5f-fc16-4534-9629-deac3979462f": {},
				"6db98fcb-fad7-43f1-abf9-fca76d7cd0e3": {},
				"728a1971-46f6-4a43-a979-29fc4405f3c5": {},
				"852b5e99-992d-4b66-93c3-8954b069bba9": {},
				"506ca5f8-b7d1-45ba-9d78-8127e7d52f40": {},
				"c85b5838-8e1b-47d0-8e08-f1b7b026582e": {},
				"f1ed94e4-94e5-4a7a-aef0-d6cf04d6a822": {},
				"bea46baf-264b-4c1f-ae49-5517b3b15a46": {},
				"3887c4ea-17d9-4bf3-a91c-416eeff91243": {},
				"98ddb0b6-caf7-4237-aa67-e1c524f13b42": {},
				"4c5f0488-a9a1-4cd0-8da1-7a9416b05f99": {},
				"47269bc9-ecee-462c-85e3-b32efa1609ba": {},
				"5ace9704-3e72-456a-a46f-82c9d2f29c2e": {},
				"4fda1d81-72e9-41b1-98b8-0143d70afb4d": {},
				"9a2dce04-8542-465c-8d7d-a7b9d197a2fa": {},
				"ca1d97dc-794c-45eb-a3fa-07ee09dcb382": {},
				"0bebc4ba-9728-4c50-a9ac-c74d7a9170a0": {},
				"77130385-7528-4001-8f8d-93c3ef2fd1f9": {},
				"acd0c922-8b55-42ff-9d8a-f55469550929": {},
				"f902178d-a1b3-4862-826b-6e2ddce959e3": {},
				"c37e0645-c8c3-4d02-958f-ac7e5cf2108e": {},
				"d6511c14-79c0-4c67-ba83-04e5f410d364": {},
				"9b0c6168-c85a-4d68-9254-d0181d673574": {},
				"db761406-8775-4020-9da0-51201491c5ca": {},
				"67a77b1e-6acb-47df-9360-3d98648f6292": {},
				"5ee26c9b-3dde-4b3e-b54b-02d1f637e793": {},
				"670a878a-fae3-4282-9836-f8417f92cd5d": {},
				"07139315-6c37-49a8-a918-f1bff5748cd8": {},
				"67d463f2-2b8b-433e-bfe4-e7e91e2dc87b": {},
				"59707c4f-c9aa-4aac-819c-6bdd6ed15aba": {},
				"1651eff1-88bd-40ac-a46a-ff8f5d8e9fde": {},
				"46667c02-7853-4dcc-af85-188a988d05c2": {},
				"042addef-e08a-40cc-8ba6-501d488e734a": {},
				"b4a2e539-4800-40a8-bcfd-ee88aa0b3dc9": {},
				"5594a598-73a5-44be-ac8c-2113b3fb06d5": {},
				"1365748b-5e08-4545-8c00-d8391c463001": {},
				"cbc34bec-ab71-4442-b697-c448f03ba4c3": {},
				"0971dc07-ebe7-49da-86fe-bfcb757c1cd6": {},
				"660834bd-6b89-4a6f-8b34-dee9e0236e6e": {},
				"e91caad3-33aa-447e-bd1c-e8f4da6fc1aa": {},
				"d3e84c2b-2e66-4ced-abce-2042b4f043aa": {},
				"adc5e448-fc04-4161-8bc6-b3718a0a32f8": {},
				"59c4c290-c264-4b50-973c-e7162dbb0dd3": {},
				"d57d1795-be54-4416-af46-7d2b8029dfe0": {},
				"a9397022-e0a8-445e-b385-bac87118a6cb": {},
				"e8c92712-7777-4912-8ccc-c47aeb286d5f": {},
				"09eeb1e6-70b1-46bd-9cbe-9a9d58c05631": {},
				"18ba362f-e367-4667-b593-6d7f17a251a2": {},
				"349239b9-5330-40f6-ac8b-7e8560cf0048": {},
				"0650bfa5-bfb7-4d9f-8ac8-9c7d330a9a06": {},
				"93765a8a-5d39-45a2-a440-3b73c16c8c62": {},
				"e0ccfa44-f4b9-4a3b-8222-cf914c277316": {},
				"ad093538-694e-45ad-a6a9-661e5744d309": {},
				"485d2eab-a474-4a3f-85ad-02be30e07dad": {},
				"2b620b62-94c5-40dc-a99a-47a58c9552fe": {},
				"dfb72021-5c6d-49d4-9dd6-263ad0636e6b": {},
				"488257b9-8db2-4b28-9e5e-aed44715ba71": {},
				"4ce7f597-2fe6-47b2-b1d7-3f84f77d51b5": {},
				"d61035ef-45d9-43f5-bc69-da8677c4042b": {},
				"9870c605-a3d9-4aea-9912-65d035b7d1aa": {},
				"02736b5b-7fac-4591-b3dd-82e79746e867": {},
				"86d1683f-9234-4bff-9320-6c7b7eec9fda": {},
				"39a43e9f-87ed-4389-beb0-b8b1a48f3d60": {},
				"6ca15b50-64b1-45fd-944f-a97c3c905523": {},
				"c71fafc5-7a20-4429-a6d6-c3fff1d74d87": {},
				"c5e3dae7-4d95-415e-8565-2367472cd98b": {},
				"1070a4f4-dfc1-4b84-af9a-c2df1bd5abc3": {},
				"21f9ce31-19a0-40b7-83dd-176475275da8": {},
				"3745f820-7a13-4ad7-8fba-5288af9e2ebf": {},
				"5fb4b40e-4967-404e-ba97-f9c5e087faab": {},
				"36a3205f-cce4-4396-a3e2-2c1c00709f25": {},
				"209a3aa2-738c-43ef-b9f5-f3d1fce3056c": {},
				"ca42c5b7-2431-41c4-ad56-2cf2765339dc": {},
				"31b3b274-fad2-4d0d-8ad4-f83ba36a1d61": {},
				"7dd8df71-41a5-4f42-a253-f6e7d0a2867f": {},
				"ddc65328-2d5c-46e0-a44a-686a97b4d884": {},
				"326ebfc0-6694-41dd-bd60-53cb947da1d7": {},
				"53affbee-7661-4b67-9d38-e95cafcba922": {},
				"81744fb7-fd2d-4c53-9218-1b78524ac2aa": {},
				"b0e3917c-b47c-4800-9123-14b80008cc81": {},
				"9f449b53-f4ab-4b9a-9f14-e82e87d5848d": {},
				"dee0880d-f855-48e4-9b82-e64279983b0b": {},
				"903ec1b6-2807-446a-a805-7cc3706af569": {},
				"ef9100e8-8a33-4c0b-8e66-989ce2dfbea2": {},
				"47b11331-572f-4403-83f9-6ad0e44e0ff3": {},
				"84291a6b-6f7f-4b46-a8b1-0db27cb68793": {},
				"3278c541-6bde-451e-ab6f-7527ed4eed51": {},
				"c97a3c68-e80a-4b2b-9b29-6257cf4d3765": {},
				"ace97e49-f873-4cc2-8644-726863f0a818": {},
				"7d06faca-4539-4701-a573-6a8a324a9f5e": {},
				"fd06416a-c363-4ba7-8f87-3f33f74b6e12": {},
				"79d130a1-1524-41fa-aec4-443fd1d75247": {},
				"222c7ea3-86ea-4f7b-bcd3-a5103ee41e0e": {},
				"d15ae76a-43d4-416e-8b67-e09e1070165f": {},
				"d0c5a1ee-0a3f-4afd-8c09-e5027577ad70": {},
				"b19c9780-add2-464a-8c0e-57a35a452467": {},
				"ad908f6a-e301-4b43-8d11-e5c045dae99c": {},
				"891b6d68-eec7-47a8-95ab-955e88576ad3": {},
				"e04f4199-f4d9-4467-aefc-ed22ffe5088e": {},
				"bf9c3dbf-15f4-46e7-a951-436bd57e7a13": {},
				"eb104195-38a5-4c59-a5d6-baa9b6edac97": {},
				"7a82d9c6-8b1e-4b22-8799-a4c844c742e8": {},
				"2fb44982-d44f-422d-941a-e79245c6d891": {},
				"3f7354cf-b1dd-413d-ac1c-e2a1a6c0ee83": {},
				"2783eea5-493f-4c66-b43a-cbfff9be6936": {},
				"dcc44d42-af77-43e5-9c07-4bba0ac9f2a6": {},
				"05c9fda3-3626-4b78-a45d-97604fac4b79": {},
				"9e9f79f1-c0be-42b9-ab70-2bda04a87757": {},
				"3d4bca1a-ff07-4cea-b008-fdfb86b2dbec": {},
				"a0d47f16-4fd4-48dc-a136-075f6b8d056f": {},
				"ed48ec5d-a3af-4ec9-99b5-decdaa749e1b": {},
				"8881f1a1-0d15-4464-b393-a3c13c4f0628": {}
			}
		},
		"98c59642-47ee-4e32-b6b8-c1de8e088aae": {
			"classDefinition": "com.sap.bpm.wfs.TimerEventDefinition",
			"timeDuration": "${context.dueDateForManagerApproval}",
			"id": "timereventdefinition1"
		},
		"7ff0ae59-6f83-41ab-81e1-247c80cde3b1": {
			"classDefinition": "com.sap.bpm.wfs.TimerEventDefinition",
			"timeDuration": "${context.dueDateForSubstituteApproval}",
			"id": "timereventdefinition5"
		},
		"82042a91-c97f-430c-89e0-8b30a0314700": {
			"classDefinition": "com.sap.bpm.wfs.TimerEventDefinition",
			"timeDuration": "${context.EmailReminder}",
			"id": "timereventdefinition16"
		},
		"df898b52-91e1-4778-baad-2ad9a261d30e": {
			"classDefinition": "com.sap.bpm.wfs.ui.StartEventSymbol",
			"x": -3518,
			"y": 99,
			"width": 32,
			"height": 32,
			"object": "11a9b5ee-17c0-4159-9bbf-454dcfdcd5c3"
		},
		"53e54950-7757-4161-82c9-afa7e86cff2c": {
			"classDefinition": "com.sap.bpm.wfs.ui.EndEventSymbol",
			"x": 5711,
			"y": -41,
			"width": 35,
			"height": 35,
			"object": "2798f4e7-bc42-4fad-a248-159095a2f40a"
		},
		"6bb141da-d485-4317-93b8-e17711df4c32": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-3502,115 -3380,115",
			"sourceSymbol": "df898b52-91e1-4778-baad-2ad9a261d30e",
			"targetSymbol": "98db1bee-6b9a-438f-89aa-362013ed4d86",
			"object": "c6b99f32-5fe6-4ab6-b60a-80fba1b9ae0f"
		},
		"2621149b-aca7-4304-bccf-468e1c675fac": {
			"classDefinition": "com.sap.bpm.wfs.ui.UserTaskSymbol",
			"x": -1918,
			"y": 85,
			"width": 100,
			"height": 60,
			"object": "06891468-ae19-4a5e-96aa-e97bb68a42c1"
		},
		"3a991716-0f67-4501-b459-7820d56fea4d": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1868,115 -1646,115",
			"sourceSymbol": "2621149b-aca7-4304-bccf-468e1c675fac",
			"targetSymbol": "f79645bf-1501-47c9-87e1-334e4a631dd9",
			"object": "cbff60a3-b01a-46c9-b6d4-c4f02c5e8d86"
		},
		"e7fc0df5-1f89-4e96-b6b5-7c39e046bf15": {
			"classDefinition": "com.sap.bpm.wfs.ui.UserTaskSymbol",
			"x": -18.25,
			"y": 277.75,
			"width": 100,
			"height": 60,
			"object": "b2212f4e-72da-486e-be4f-680e98345b6b",
			"symbols": {
				"8235f323-4756-495b-893a-2b5584e59c19": {}
			}
		},
		"03c339f3-b51a-46da-a68e-55098c986dda": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "31.75,306 211,306 211,122.875",
			"sourceSymbol": "e7fc0df5-1f89-4e96-b6b5-7c39e046bf15",
			"targetSymbol": "79801fa1-cab8-4e92-80b8-506914da49c2",
			"object": "67f85457-a01d-4c63-b4b6-872a00f0f8b9"
		},
		"bc6fdfbc-6cfc-42a2-a532-b2861246a582": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 458.625,
			"y": 105.625,
			"object": "d8ba0d32-0e90-49ca-927a-3931f0881f9e"
		},
		"49bfb5ef-0612-4192-bd49-b570cd450f11": {
			"classDefinition": "com.sap.bpm.wfs.ui.EndEventSymbol",
			"x": 1888.3125,
			"y": 306.0625,
			"width": 35,
			"height": 35,
			"object": "06fa1e99-4325-4dea-81d7-a92461eb15e3"
		},
		"07892177-a393-4560-a641-3a13f003bca1": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "480,115.625 480,-128 366.953125,-128",
			"sourceSymbol": "bc6fdfbc-6cfc-42a2-a532-b2861246a582",
			"targetSymbol": "cd79d258-0677-451e-bbf1-dea2f587007d",
			"object": "dd7946a1-f238-4c7a-a5fd-c1ed7094b7e1"
		},
		"dfd5a7de-7635-437d-a06a-b1e60b4d4729": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": -725,
			"y": -149,
			"width": 100,
			"height": 60,
			"object": "fdf35015-9267-4b31-ba80-49759b8bb63b"
		},
		"8b1d07e6-3b8e-4949-aa8b-4e831706c6d3": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "489.625,113 581,113 581,-7.6875",
			"sourceSymbol": "bc6fdfbc-6cfc-42a2-a532-b2861246a582",
			"targetSymbol": "5caefecc-6cd1-45a7-a89a-9dec5f87fbd8",
			"object": "c89124c5-dab8-481c-8307-beef67357aeb"
		},
		"660a3d29-5f0b-41d6-8483-a5102eb1d03a": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -2618,
			"y": 85,
			"width": 100,
			"height": 60,
			"object": "99b92cdc-05ca-4bf6-9cba-bbe8e381696c"
		},
		"ebaae79e-d937-4c84-95af-11e971f6f273": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": -414,
			"y": 399,
			"width": 100,
			"height": 60,
			"object": "8dcd09bd-99d5-4347-9bfb-102a27f1a949"
		},
		"98eb0743-9d24-4fa6-8b28-9b9007e68186": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-364,429 -364,336",
			"sourceSymbol": "ebaae79e-d937-4c84-95af-11e971f6f273",
			"targetSymbol": "02736b5b-7fac-4591-b3dd-82e79746e867",
			"object": "31e25202-6cca-4025-acb8-0b632fe0fd4d"
		},
		"8feadb9e-9c15-4f91-b058-d27176e52036": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -945,
			"y": 838,
			"width": 100,
			"height": 60,
			"object": "bb21eb22-a546-402c-b871-3b0fbd7b4d97"
		},
		"67913ec9-a0b9-4db3-8749-99e5e98bd02d": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-895,868 -895,959",
			"sourceSymbol": "8feadb9e-9c15-4f91-b058-d27176e52036",
			"targetSymbol": "957b7128-0d4d-4afb-8218-9d95cf6ac77e",
			"object": "c342097f-192a-4660-a73e-da0ebd797b89"
		},
		"7e2860b1-6f50-4aee-9c30-6e802a4175a5": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": -160,
			"y": 308,
			"width": 100,
			"height": 60,
			"object": "4490dec5-f12b-4640-838f-09c439a9e1aa"
		},
		"9395ff70-a472-490c-bf2e-38c46e38eb3a": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -939,
			"y": 88,
			"width": 100,
			"height": 60,
			"object": "81bd8d37-a4b5-43e8-9d31-1cf5b701aaff"
		},
		"cd79d258-0677-451e-bbf1-dea2f587007d": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 316,
			"y": -152,
			"width": 100,
			"height": 60,
			"object": "35021842-30c7-473a-bdbe-d322a823068f"
		},
		"3f48b167-b9f5-4753-a098-cc8651377020": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "366,-122 233.25,-122 233.25,-276 130,-276",
			"sourceSymbol": "cd79d258-0677-451e-bbf1-dea2f587007d",
			"targetSymbol": "ef5167e5-9895-42e4-a841-5d44f24f9dff",
			"object": "56a8a81c-f5f3-4070-bfe3-fa5e476b01fa"
		},
		"1a7ea469-a95b-4019-a06d-962422e501ea": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 1414.3125,
			"y": 300.5625,
			"width": 100,
			"height": 60,
			"object": "31bddefd-3970-487e-ae69-8c79c03d2b4e"
		},
		"5caefecc-6cd1-45a7-a89a-9dec5f87fbd8": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 531,
			"y": -39,
			"width": 100,
			"height": 60,
			"object": "3e842588-71b2-4462-83ca-f9ab3743e423"
		},
		"3513d8c6-6ed8-4a3e-882d-45a9ce719ee8": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-675,-119 -800,-119",
			"sourceSymbol": "dfd5a7de-7635-437d-a06a-b1e60b4d4729",
			"targetSymbol": "103721ef-5a92-424c-ab80-e00e9093d0be",
			"object": "bfe4859f-9e9f-4f37-847e-63d2fcfa69e2"
		},
		"103721ef-5a92-424c-ab80-e00e9093d0be": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -850,
			"y": -149,
			"width": 100,
			"height": 60,
			"object": "056b1a11-e7a7-4ac2-bfe7-16e06a4e3b17"
		},
		"844021d5-6eb4-4039-a4b3-c6e47f92ef87": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-800,-119 -967,-119",
			"sourceSymbol": "103721ef-5a92-424c-ab80-e00e9093d0be",
			"targetSymbol": "f9ab9845-cd09-4716-862c-8f7d4b4a8a62",
			"object": "eef1bd83-3d87-4465-a7c3-c92800f9c48b"
		},
		"f22441c0-6710-410e-b8d6-b7087b6d1289": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -4,
			"y": 505,
			"width": 100,
			"height": 60,
			"object": "2e2f15da-55b8-4578-81b9-740ff2b6a218"
		},
		"c47e39b6-4858-4b3b-8613-b8e111e19d70": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": 4,
			"y": 743,
			"width": 100,
			"height": 43,
			"object": "9d325103-1963-4f0e-a1d1-f409d3dc59d5"
		},
		"4cd48edb-2ae6-444d-a029-7d889eea070d": {
			"classDefinition": "com.sap.bpm.wfs.ui.UserTaskSymbol",
			"isAdjustToContent": false,
			"x": 4,
			"y": 804,
			"width": 100,
			"height": 52,
			"object": "8337f8c5-dd5f-4fbd-8f7c-ea374f6b36b2",
			"symbols": {
				"61b93211-8d17-4109-9dd8-2657acf9b417": {}
			}
		},
		"d9d65df8-894c-4780-851a-eecde4a4f09d": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -1320,
			"y": 93,
			"object": "233a6b4d-a2b6-458f-bae8-c7bc788013af"
		},
		"301fd250-bc03-45dc-b66b-023576527860": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1299,112.5 -1162,112.5",
			"sourceSymbol": "d9d65df8-894c-4780-851a-eecde4a4f09d",
			"targetSymbol": "6cf73f92-88d8-45bd-882f-c4954b2095fd",
			"object": "29abf8e7-c8a3-4777-81a0-49ec1fe6ccbd"
		},
		"306ffc10-0d26-432c-8499-c22c29b43db4": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -1351,
			"y": 258,
			"width": 100,
			"height": 60,
			"object": "3cfbbea0-301e-47fe-b1cb-1162c50fb37a"
		},
		"20b3727c-9d9f-4892-aa55-f63e60fa213a": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1300,114 -1300,288",
			"sourceSymbol": "d9d65df8-894c-4780-851a-eecde4a4f09d",
			"targetSymbol": "306ffc10-0d26-432c-8499-c22c29b43db4",
			"object": "db84c2ec-911f-4964-8e9a-50d9821cc474"
		},
		"4e2480c2-0ab3-4fe8-b196-e1ec91b66df3": {
			"classDefinition": "com.sap.bpm.wfs.ui.EndEventSymbol",
			"x": -1319,
			"y": 557.5,
			"width": 35,
			"height": 35,
			"object": "15e032f9-93a1-47b5-88f6-2e955a9372b3"
		},
		"ab8d6480-6c17-4d7f-9d7c-11a4f7dfc68d": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1301,288 -1301,405",
			"sourceSymbol": "306ffc10-0d26-432c-8499-c22c29b43db4",
			"targetSymbol": "30f544b9-5e9f-4b2b-ae7e-8b1329b0939f",
			"object": "8b19b064-884f-4f12-8a81-c45f49a7d7a8"
		},
		"cfc28ee3-34a4-4fcc-8b57-ad5f1f187d7e": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "581,-9 581,-176.75 717,-176.75 717,-344",
			"sourceSymbol": "5caefecc-6cd1-45a7-a89a-9dec5f87fbd8",
			"targetSymbol": "67fc2f6f-0a02-4eb2-8304-26ee0fbbe753",
			"object": "61617f44-0d68-482f-a241-7b5c65fb9d50"
		},
		"606e578d-742c-4294-a057-cba00c2b95bc": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 632,
			"y": 426,
			"width": 100,
			"height": 60,
			"object": "854f2bea-0180-42e1-9f60-4d102de7726d"
		},
		"53ba6ebb-f6b8-4259-8e35-39bfddeefcf2": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-2568,115 -2329,115",
			"sourceSymbol": "660a3d29-5f0b-41d6-8483-a5102eb1d03a",
			"targetSymbol": "bd90d11c-983d-46cc-b438-749d98267604",
			"object": "a48cfdbe-2f35-40d3-9d30-7921d68617f6"
		},
		"863fc501-edeb-4770-b019-33a732d91f63": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "682,452.5 862,452.5",
			"sourceSymbol": "606e578d-742c-4294-a057-cba00c2b95bc",
			"targetSymbol": "25607da7-fc8b-4db0-8a8d-8f1c2fc11042",
			"object": "f1790b57-eb7a-4f5d-915c-0710ac27fb9a"
		},
		"47993291-0f07-43e9-b3c9-f93a859a0dcf": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "479.8125,126.625 479.8125,270",
			"sourceSymbol": "bc6fdfbc-6cfc-42a2-a532-b2861246a582",
			"targetSymbol": "ddfcb5c7-7239-4f55-ba6c-d14e748e6601",
			"object": "f3e9e518-b00d-421e-bd91-abaf88253b58"
		},
		"31f05be5-0a40-439b-9686-a11ffd14fa6f": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 991,
			"y": 419,
			"width": 100,
			"height": 60,
			"object": "bdcfb412-7dd8-43c5-b6ec-2c9af8b32b5a"
		},
		"5434b063-a41b-4a7f-9761-87a68e5d13f3": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1039,449 1039,526",
			"sourceSymbol": "31f05be5-0a40-439b-9686-a11ffd14fa6f",
			"targetSymbol": "0afe4a2d-0b7f-400e-8107-54e717b8d6f1",
			"object": "b8a123dc-fb1a-4f67-92d6-ab415991e790"
		},
		"787ffd9d-fd9a-4622-9598-13f3a405a621": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 1141,
			"y": 479,
			"width": 100,
			"height": 60,
			"object": "e21e9ddd-8ffe-497a-ae19-c05a308de69b"
		},
		"41a9ad41-dc95-48bd-b7ad-de378b1e7494": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 1153,
			"y": 595,
			"width": 100,
			"height": 60,
			"object": "30c8a446-373c-4f80-94ad-066f5a25dbbc"
		},
		"c7eb7d0a-df5b-4a68-9ff6-63cc6bf67275": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1203,625 1049,625",
			"sourceSymbol": "41a9ad41-dc95-48bd-b7ad-de378b1e7494",
			"targetSymbol": "6375b8c4-6c05-4ae7-877c-2cc66375d078",
			"object": "3d12733b-6286-4b08-934e-3b5ebbc924cb"
		},
		"9275932d-7614-4d6b-8bd2-53d1327315ac": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -939,
			"y": 369,
			"width": 100,
			"height": 60,
			"object": "d9f5c825-a8f0-4fdb-8f9d-3685b671d121"
		},
		"94b99184-c273-4bfa-a504-6c7c2a26966b": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -939,
			"y": 747,
			"width": 100,
			"height": 60,
			"object": "a2ba93b6-86bb-4bf0-a149-037fa740d0f7"
		},
		"171e8fa5-92a4-473b-b5fc-e1a5b27c4362": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -939,
			"y": 524,
			"width": 100,
			"height": 60,
			"object": "7567c7a1-d73a-4be2-9f55-def62b30ddca"
		},
		"121fb8cc-7457-464f-82f9-ece9a7fd42fa": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-889,554 -889,633",
			"sourceSymbol": "171e8fa5-92a4-473b-b5fc-e1a5b27c4362",
			"targetSymbol": "9145e63a-15ec-4952-827c-c39efffae1e6",
			"object": "a2a7c0b0-a677-490a-b05b-61f83ec61545"
		},
		"e83a5349-6f88-4f64-9cb9-c0e2e3649c75": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-892,777 -892,868",
			"sourceSymbol": "94b99184-c273-4bfa-a504-6c7c2a26966b",
			"targetSymbol": "8feadb9e-9c15-4f91-b058-d27176e52036",
			"object": "c3e5f663-1d55-4b75-80a9-e2d2540536bd"
		},
		"6375b8c4-6c05-4ae7-877c-2cc66375d078": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 999,
			"y": 595,
			"width": 100,
			"height": 60,
			"object": "ff47561f-1004-41a7-ae18-5de2cf4400ef"
		},
		"ff884ddf-41cf-42ea-b298-123f2ff83137": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "881,1056 881,1132.5 -235,1132.5 -235,870",
			"sourceSymbol": "4bfe8669-ec22-4922-93a8-7783be8a5a70",
			"targetSymbol": "0de46006-bff1-4d24-b755-8d0ac78533e7",
			"object": "681f78f5-2f89-4781-8d90-404af29f559a"
		},
		"d182234d-e5e6-4aaa-add2-0861531bc0c4": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": 125,
			"y": 1018,
			"width": 100,
			"height": 60,
			"object": "00dd4b02-bd67-4515-ae82-999f1c8f3f4a"
		},
		"3f3017fe-0e50-4593-96c6-670a0195798d": {
			"classDefinition": "com.sap.bpm.wfs.ui.UserTaskSymbol",
			"x": 247,
			"y": 1018,
			"width": 100,
			"height": 60,
			"object": "bd2a38e1-d493-4123-8ee1-876a83a6f5f8"
		},
		"92a95762-7766-47bb-8557-57da54b24f29": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "175,1048 297,1048",
			"sourceSymbol": "d182234d-e5e6-4aaa-add2-0861531bc0c4",
			"targetSymbol": "3f3017fe-0e50-4593-96c6-670a0195798d",
			"object": "32682168-7f79-48ec-a5db-73ec3b828f1d"
		},
		"43db4445-f24a-447d-af48-cf63cfc5f4b6": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 9,
			"y": 1018,
			"width": 100,
			"height": 60,
			"object": "50acc690-0ad0-473a-a524-2e56b078405b"
		},
		"3a80ecc6-2285-4149-9652-a3c5dcc72b01": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "59,1048 175,1048",
			"sourceSymbol": "43db4445-f24a-447d-af48-cf63cfc5f4b6",
			"targetSymbol": "d182234d-e5e6-4aaa-add2-0861531bc0c4",
			"object": "7a02df10-8590-4cf9-8fd5-433bc0ffdd79"
		},
		"dca8bda7-e66d-486a-9a50-13e4a9462ddd": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "54,764.5 54,830",
			"sourceSymbol": "c47e39b6-4858-4b3b-8613-b8e111e19d70",
			"targetSymbol": "4cd48edb-2ae6-444d-a029-7d889eea070d",
			"object": "a8c41d51-a14f-4fec-8f40-49a107a4083d"
		},
		"4bfe8669-ec22-4922-93a8-7783be8a5a70": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 860,
			"y": 1035,
			"object": "3d3cf404-1e67-41e1-9348-c87eeb0397bf"
		},
		"79801fa1-cab8-4e92-80b8-506914da49c2": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 190,
			"y": 102,
			"object": "b9f3fd94-bc43-40b0-b03f-6cfa4e1fb969"
		},
		"1288ead1-1ad6-4b88-aca3-f761ee8862b1": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "211,123 269.5,123 269.5,132 358,132",
			"sourceSymbol": "79801fa1-cab8-4e92-80b8-506914da49c2",
			"targetSymbol": "98478846-955f-4ffd-a91a-007a839791cc",
			"object": "36c49a76-b960-48bf-9d16-ff018a8b66a2"
		},
		"615150f5-269c-427a-85ac-7eea8863d484": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 247,
			"y": 775,
			"object": "2ec0658e-6a17-4d0d-90ea-62c4336623b5"
		},
		"fc94b3fd-552b-4e40-b340-9d812410f046": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "54,831.7333374023438 175.75,831.7333374023438 175.75,798 260,798",
			"sourceSymbol": "4cd48edb-2ae6-444d-a029-7d889eea070d",
			"targetSymbol": "615150f5-269c-427a-85ac-7eea8863d484",
			"object": "dee51f9a-8c65-44d9-814a-a42fce41ab06"
		},
		"9cc135ac-3a6b-4fce-a442-43f5ae5eed86": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "297,1048 297,917.25 268,917.25 268,796",
			"sourceSymbol": "3f3017fe-0e50-4593-96c6-670a0195798d",
			"targetSymbol": "615150f5-269c-427a-85ac-7eea8863d484",
			"object": "5e7233d7-b513-46d0-a5e1-3797e89ef6c1"
		},
		"7f998f7a-67e3-44a4-a2d0-7d8baa07aa6d": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "267.5,796 267.5,459.5 253,459.5 253,123 211.5,123",
			"sourceSymbol": "615150f5-269c-427a-85ac-7eea8863d484",
			"targetSymbol": "79801fa1-cab8-4e92-80b8-506914da49c2",
			"object": "b4251b51-8ecb-46e0-a28f-3d479f8963d4"
		},
		"d56f87ee-5e54-4842-872c-0dc7e548e4a8": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -590,
			"y": 93,
			"object": "08e8ea17-39f4-48cc-83cf-5fe60227f741"
		},
		"c54df1cf-41d3-4482-bb9f-a9354cf294ba": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-569,115.5 -523,115.5 -523,156 -477,156",
			"sourceSymbol": "d56f87ee-5e54-4842-872c-0dc7e548e4a8",
			"targetSymbol": "49eeab01-2101-4d4d-b090-d9d3526d29b1",
			"object": "ff29f679-cb09-4ff6-9830-80537ff53755"
		},
		"dfb11ba5-be42-4ef9-9274-f1802e2637f2": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-571,114 -571,235",
			"sourceSymbol": "d56f87ee-5e54-4842-872c-0dc7e548e4a8",
			"targetSymbol": "4cf7cb53-ab6f-48ad-9518-0db97d6c7577",
			"object": "f62aac86-d615-4105-869a-3b66f94a5d8e"
		},
		"77e8f4ab-0f45-4c04-9a4b-fe81fb9aa3d7": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -623,
			"y": 494,
			"width": 100,
			"height": 60,
			"object": "aaa547a7-dc46-44ab-8255-960716a6bcae"
		},
		"29106054-e5ad-4f5b-8a6c-b1e96c96681d": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -623,
			"y": 709,
			"width": 100,
			"height": 60,
			"object": "0e163838-d068-4dee-a204-ed54fb74af92"
		},
		"6fcee76d-0ed7-424c-ba0a-247437d757bb": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-573,524 -573,624",
			"sourceSymbol": "77e8f4ab-0f45-4c04-9a4b-fe81fb9aa3d7",
			"targetSymbol": "35e3afb0-2b0c-4dfd-80fb-d9f8209de2eb",
			"object": "bf8ae7ef-156c-4b07-a9db-d7494e301aac"
		},
		"c3907832-d9da-44dd-894c-15b375c73179": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -594.5,
			"y": 796,
			"object": "9f42ea35-64e3-4e39-ad1c-963db78f4393"
		},
		"36df7ab0-b389-4bc8-965e-49ba395e7870": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-573.25,739 -573.25,817",
			"sourceSymbol": "29106054-e5ad-4f5b-8a6c-b1e96c96681d",
			"targetSymbol": "c3907832-d9da-44dd-894c-15b375c73179",
			"object": "7c0df5b1-973c-4cd6-a293-94a40467a169"
		},
		"db592951-f348-4cf8-a354-c7c4a7659699": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-573.5,816.5 -321,816.5",
			"sourceSymbol": "c3907832-d9da-44dd-894c-15b375c73179",
			"targetSymbol": "6bcd1d17-1c80-4135-8e35-de10fe7e4d49",
			"object": "9f702c5c-c132-4c75-8ddd-91aeb3cdc3c1"
		},
		"1017d15a-1c87-4885-b6b6-15ef22dd4390": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -623,
			"y": 906,
			"width": 100,
			"height": 60,
			"object": "d58f5ffb-c7f1-4d48-a312-241110ebf41e"
		},
		"46b2157f-4d04-424d-9fe9-ba0e73bdda45": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-573.25,817 -573.25,936",
			"sourceSymbol": "c3907832-d9da-44dd-894c-15b375c73179",
			"targetSymbol": "1017d15a-1c87-4885-b6b6-15ef22dd4390",
			"object": "00d8e9e7-7de4-4d9e-a338-424dce2e60b9"
		},
		"1fcbdb09-d5d3-45e8-b321-3fa2f334bbe8": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -623,
			"y": 1000,
			"width": 100,
			"height": 60,
			"object": "701fc339-9099-4f8b-8058-7100f5ae4c5d"
		},
		"acf8ff97-f004-4c05-b90c-16c52b76b5c9": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-573,936 -573,1021",
			"sourceSymbol": "1017d15a-1c87-4885-b6b6-15ef22dd4390",
			"targetSymbol": "1fcbdb09-d5d3-45e8-b321-3fa2f334bbe8",
			"object": "ab07db2a-d54f-4353-95d7-e058fde5c5a7"
		},
		"e812a0b6-7ce3-4a0f-8bb3-5ef4a70cd325": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -623,
			"y": 1092,
			"width": 100,
			"height": 60,
			"object": "caf7be2b-e43a-4f14-a826-9cfb68ab4172"
		},
		"924033e1-ecd5-444b-953d-29505106191c": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-573,1030 -573,1122",
			"sourceSymbol": "1fcbdb09-d5d3-45e8-b321-3fa2f334bbe8",
			"targetSymbol": "e812a0b6-7ce3-4a0f-8bb3-5ef4a70cd325",
			"object": "a2b4ba53-c764-412e-872d-0d621ff3bac3"
		},
		"e2cf8dfe-830a-49a1-87dd-a5456a5cfdf3": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": -371,
			"y": 1092,
			"width": 100,
			"height": 60,
			"object": "efba8741-f361-4ace-9a71-eb817f466415"
		},
		"9772b0ad-e1ae-459a-951a-a47b0bbe6eff": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-573,1122 -321,1122",
			"sourceSymbol": "e812a0b6-7ce3-4a0f-8bb3-5ef4a70cd325",
			"targetSymbol": "e2cf8dfe-830a-49a1-87dd-a5456a5cfdf3",
			"object": "8cbe862a-01cd-44b8-b8bb-4d175436c687"
		},
		"4cf7cb53-ab6f-48ad-9518-0db97d6c7577": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -594,
			"y": 214,
			"object": "d204364a-1439-481f-9b7c-9c638f58d815"
		},
		"89d781c6-ff21-4bcd-8db2-880a8f91521a": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-573,235 -573,399",
			"sourceSymbol": "4cf7cb53-ab6f-48ad-9518-0db97d6c7577",
			"targetSymbol": "85440f67-5781-4de5-a8f0-03ac320a5628",
			"object": "3e61da83-19ba-4b9a-97e8-2893c9de6e7d"
		},
		"32d1af0d-ca71-40d3-8575-7e26f064a118": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-573,235 -525,235 -525,156 -477,156",
			"sourceSymbol": "4cf7cb53-ab6f-48ad-9518-0db97d6c7577",
			"targetSymbol": "49eeab01-2101-4d4d-b090-d9d3526d29b1",
			"object": "8b6b6507-0682-4403-b21c-663dd4adb5cf"
		},
		"88578040-c8e0-4756-98db-683694de425e": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-321,1122 -321,816",
			"sourceSymbol": "e2cf8dfe-830a-49a1-87dd-a5456a5cfdf3",
			"targetSymbol": "6bcd1d17-1c80-4135-8e35-de10fe7e4d49",
			"object": "a2e490fc-09fd-4187-a6a3-95aa56069181"
		},
		"957b7128-0d4d-4afb-8218-9d95cf6ac77e": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -945,
			"y": 929,
			"width": 100,
			"height": 60,
			"object": "0479076d-17a8-470b-8382-d5459eb052a3"
		},
		"ff3b4afb-3adf-41e7-a14a-663eb9a4185c": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -945,
			"y": 1143,
			"width": 100,
			"height": 60,
			"object": "0c9df6a2-4743-4ca1-8068-f61ecf547f56"
		},
		"f9ab9845-cd09-4716-862c-8f7d4b4a8a62": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -1017,
			"y": -149,
			"width": 100,
			"height": 60,
			"object": "ef831483-933c-4efb-998b-082196738ef1"
		},
		"aa2a08df-81e6-43f6-a120-8a48175b5eb4": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-967,-119 -1133,-119",
			"sourceSymbol": "f9ab9845-cd09-4716-862c-8f7d4b4a8a62",
			"targetSymbol": "6d4beb80-62d9-451f-b118-c47219880f55",
			"object": "328d0b8c-7512-48a7-a305-060df9161e20"
		},
		"9014bdcd-de46-4088-9a9e-d461c999cb99": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 125,
			"y": 505,
			"width": 100,
			"height": 60,
			"object": "37ec0a64-b924-4866-a246-b6e91fc7fa06"
		},
		"cfc047d4-3aa1-497e-a95a-2a87a2323a4f": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 120,
			"y": 585,
			"width": 100,
			"height": 60,
			"object": "4d353ff7-225a-4475-abbd-ca72eb0b8974"
		},
		"c4fbac88-6c25-48b2-8c3e-58d41fec1baf": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "46,535 175,535",
			"sourceSymbol": "f22441c0-6710-410e-b8d6-b7087b6d1289",
			"targetSymbol": "9014bdcd-de46-4088-9a9e-d461c999cb99",
			"object": "86c031b4-a5f1-45ac-946f-461d81c12fe1"
		},
		"c592ce35-371e-43ca-9f9d-c87c96212403": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "172.5,535 172.5,615",
			"sourceSymbol": "9014bdcd-de46-4088-9a9e-d461c999cb99",
			"targetSymbol": "cfc047d4-3aa1-497e-a95a-2a87a2323a4f",
			"object": "331bb888-15e6-437c-8f0e-bbe1f02f5034"
		},
		"0030d14d-f989-4985-a587-d30cdff9872a": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-895,959 -895,1060",
			"sourceSymbol": "957b7128-0d4d-4afb-8218-9d95cf6ac77e",
			"targetSymbol": "e03a4f62-89e4-4056-ac05-dbde495cf23f",
			"object": "324a90d6-31fa-4db2-a2e0-2da3cb51a4aa"
		},
		"67fc2f6f-0a02-4eb2-8304-26ee0fbbe753": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 667,
			"y": -374,
			"width": 100,
			"height": 60,
			"object": "6a35041a-d16e-4cbc-9e6a-6aa51d639be2"
		},
		"50e4d209-3ff1-46f0-a9b3-832f270ef38c": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 929,
			"y": -374,
			"width": 100,
			"height": 60,
			"object": "7048bfa2-ab10-4afa-af8a-d038f581ae65"
		},
		"9296ebed-ff46-473e-a29f-d36871fa696b": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 1551,
			"y": 301,
			"width": 100,
			"height": 60,
			"object": "13adc3d3-6b22-4055-ae85-0401add7744c"
		},
		"8861ac74-c10d-4497-8b2b-5494756058b5": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 1693,
			"y": 301,
			"width": 100,
			"height": 60,
			"object": "21b87d2f-678d-4b03-9d16-a2bef8a4cb18"
		},
		"98b8fd74-57a7-4038-9406-ff8031f5480c": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "979,-344 1094,-344",
			"sourceSymbol": "50e4d209-3ff1-46f0-a9b3-832f270ef38c",
			"targetSymbol": "5627ed87-4588-4f43-9fc5-bdac55c915a9",
			"object": "8da188fa-85e3-4eba-9efd-50d12ec31967"
		},
		"3cec4dbf-5aed-4529-bff8-741fd7249f21": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "717,-344 849,-344",
			"sourceSymbol": "67fc2f6f-0a02-4eb2-8304-26ee0fbbe753",
			"targetSymbol": "08f6cd37-7b66-4ef9-91ee-59cc76ad734f",
			"object": "2f5ef6cc-abba-440d-9c3e-6020b86a5f76"
		},
		"91497e4b-752b-4ef8-a492-7057b707bf6a": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1464.15625,330.78125 1601.15625,330.78125",
			"sourceSymbol": "1a7ea469-a95b-4019-a06d-962422e501ea",
			"targetSymbol": "9296ebed-ff46-473e-a29f-d36871fa696b",
			"object": "360372f3-3e99-4de0-ae65-a5d1f593da08"
		},
		"e00568be-1261-474b-b951-1628158d8bf8": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1601,331 1743,331",
			"sourceSymbol": "9296ebed-ff46-473e-a29f-d36871fa696b",
			"targetSymbol": "8861ac74-c10d-4497-8b2b-5494756058b5",
			"object": "f790d345-c914-4baa-8c6a-834c3e7aac10"
		},
		"2b4f1117-7461-41bb-85e0-ef3c45a41971": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 828,
			"y": 599,
			"width": 100,
			"height": 60,
			"object": "8430762c-d6c3-4ade-bc13-3db24226917f"
		},
		"03cd082b-a89d-48ef-b323-9b3681487576": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 828,
			"y": 701,
			"width": 100,
			"height": 60,
			"object": "a8cd3376-6607-467a-ad8a-e981bdb681d9"
		},
		"f5a71cf1-a25a-44eb-83fc-39272bcddb77": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "878,629 878,731",
			"sourceSymbol": "2b4f1117-7461-41bb-85e0-ef3c45a41971",
			"targetSymbol": "03cd082b-a89d-48ef-b323-9b3681487576",
			"object": "921d2dd0-9298-431e-a862-1f64ff318b4e"
		},
		"24fe8e17-fe7a-4104-bfdb-a575f47c606b": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1049,627 878,627",
			"sourceSymbol": "6375b8c4-6c05-4ae7-877c-2cc66375d078",
			"targetSymbol": "2b4f1117-7461-41bb-85e0-ef3c45a41971",
			"object": "1b2e9457-c8de-4ae7-b015-2f1634f21461"
		},
		"27e7fbea-25f0-4e60-809a-5fb8e3cf5f0b": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "879.5,731 879.5,837",
			"sourceSymbol": "03cd082b-a89d-48ef-b323-9b3681487576",
			"targetSymbol": "ce6b16ca-c5aa-46da-b3fb-be897e0dc290",
			"object": "94014aa8-48f5-459c-af49-6a77afd84b15"
		},
		"34f093c8-7a03-46b6-9f58-92d0c848c917": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 6274,
			"y": -53,
			"width": 100,
			"height": 60,
			"object": "eeff2bdf-7aaa-47a3-b8f0-134ab18e9e8e"
		},
		"0122faf4-2d34-426b-9496-69702adaf663": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "6324,-23 6177,-23",
			"sourceSymbol": "34f093c8-7a03-46b6-9f58-92d0c848c917",
			"targetSymbol": "8e2c8089-f912-4177-b101-7f5992f30871",
			"object": "e6e6913b-614a-499e-a0b2-aac182bd2e36"
		},
		"8e2c8089-f912-4177-b101-7f5992f30871": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 6127,
			"y": -53,
			"width": 100,
			"height": 60,
			"object": "1d99fb56-2463-47d5-b95c-b61fddfa93e4"
		},
		"cdc5fd4d-9cfa-49e8-8e2b-a1c20011bb6d": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "6177,-23 6005,-23",
			"sourceSymbol": "8e2c8089-f912-4177-b101-7f5992f30871",
			"targetSymbol": "9564665e-ad8d-43d8-9cdb-58bf986948eb",
			"object": "2e5195ca-3c2d-4dc5-ac02-8f33009641a4"
		},
		"7cf1f501-6d02-4477-984f-bc340d4df5bf": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1188.5,509 1188.5,628",
			"sourceSymbol": "787ffd9d-fd9a-4622-9598-13f3a405a621",
			"targetSymbol": "41a9ad41-dc95-48bd-b7ad-de378b1e7494",
			"object": "95bae7c8-4c50-4f6f-88dd-7f029ed4c3f7"
		},
		"e595b480-97d6-4b3d-bc7e-9a56253a2e0c": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -939,
			"y": 169,
			"width": 100,
			"height": 60,
			"object": "2d5fb220-87ab-4e1d-8095-c41dc8a6306d"
		},
		"1437fcee-0f68-45da-bb2d-3e8a5e0b20f9": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-889,199 -889,270",
			"sourceSymbol": "e595b480-97d6-4b3d-bc7e-9a56253a2e0c",
			"targetSymbol": "f42b6e9f-15ee-451e-a043-136a8e5c9aaf",
			"object": "dc729b7f-2d1c-4dd0-9431-8e0d50a609da"
		},
		"25607da7-fc8b-4db0-8a8d-8f1c2fc11042": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 812,
			"y": 419,
			"width": 100,
			"height": 60,
			"object": "ad99fde2-287e-4495-9b62-ef4fc532adf0"
		},
		"6e1fa95c-6edc-497c-9f26-e667fd1ea2c1": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "862,449 1041,449",
			"sourceSymbol": "25607da7-fc8b-4db0-8a8d-8f1c2fc11042",
			"targetSymbol": "31f05be5-0a40-439b-9686-a11ffd14fa6f",
			"object": "068488e5-c4c3-43b7-b7f3-1507c06fcfac"
		},
		"6bcd1d17-1c80-4135-8e35-de10fe7e4d49": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -342,
			"y": 795,
			"object": "abd1eb59-b34c-489e-81da-2426d5ccd452"
		},
		"9fa9362b-448b-4458-bf5d-554f0665365c": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-317.5,816 -317.5,486 -509,486 -509,156 -481,156",
			"sourceSymbol": "6bcd1d17-1c80-4135-8e35-de10fe7e4d49",
			"targetSymbol": "49eeab01-2101-4d4d-b090-d9d3526d29b1",
			"object": "4991edf8-64e2-45c6-940f-0d6ef0824213"
		},
		"9a4c92f5-20d9-4d36-abe5-971113fbf059": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -332,
			"y": 84,
			"width": 100,
			"height": 60,
			"object": "c8116791-4591-4339-b807-e69c36f74171"
		},
		"3da8774e-916f-4f8a-bcf9-7987280ab61b": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -294,
			"y": 285,
			"object": "354d2614-4245-499d-981c-800e57c8b91b"
		},
		"045387fa-4c7c-467e-8918-c50bc4da8297": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-273,306 -273,214.5 -282,214.5 -282,114",
			"sourceSymbol": "3da8774e-916f-4f8a-bcf9-7987280ab61b",
			"targetSymbol": "9a4c92f5-20d9-4d36-abe5-971113fbf059",
			"object": "20a90dc8-035f-48e8-9e94-28565aeb83eb"
		},
		"85440f67-5781-4de5-a8f0-03ac320a5628": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -623,
			"y": 369,
			"width": 100,
			"height": 60,
			"object": "f275da51-5617-4333-83d9-aff034b1c70e"
		},
		"6e186c83-62fe-4b36-a14a-fc0223fa5c68": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-573,399 -573,524",
			"sourceSymbol": "85440f67-5781-4de5-a8f0-03ac320a5628",
			"targetSymbol": "77e8f4ab-0f45-4c04-9a4b-fe81fb9aa3d7",
			"object": "a30405d6-7b62-4efe-acae-569f11a6f2ef"
		},
		"30f544b9-5e9f-4b2b-ae7e-8b1329b0939f": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -1322,
			"y": 384,
			"object": "67dac61a-5d8d-403c-93a1-a56f3823a247"
		},
		"2732499b-8d60-41a4-a689-5a4097a719cd": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1301.25,405 -1301.25,575",
			"sourceSymbol": "30f544b9-5e9f-4b2b-ae7e-8b1329b0939f",
			"targetSymbol": "4e2480c2-0ab3-4fe8-b196-e1ec91b66df3",
			"object": "1c9a1904-19ca-4191-a3c0-2ec00228eaca"
		},
		"d2c24999-d31f-4e27-b38a-c2a62b54928a": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -1451,
			"y": 371,
			"width": 100,
			"height": 60,
			"object": "50aa8137-fd50-44ed-a195-e4765d4f1c69"
		},
		"0e43ea46-0ea4-4373-9ea0-6eb016bfedcd": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -1846,
			"y": 371,
			"width": 100,
			"height": 60,
			"object": "e62a9b1b-ce64-4fc4-b605-617b23ded67a"
		},
		"c8bc2972-c126-4274-a338-ab7a632750af": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1301,403 -1401,403",
			"sourceSymbol": "30f544b9-5e9f-4b2b-ae7e-8b1329b0939f",
			"targetSymbol": "d2c24999-d31f-4e27-b38a-c2a62b54928a",
			"object": "abc20477-9cb6-4188-95ca-ca2e7270f712"
		},
		"3ca537c6-c0f5-41f6-9653-858bfa70a34d": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1401,401 -1513,401",
			"sourceSymbol": "d2c24999-d31f-4e27-b38a-c2a62b54928a",
			"targetSymbol": "31b3b274-fad2-4d0d-8ad4-f83ba36a1d61",
			"object": "2fc44807-25d8-4446-bd9e-49f49cb335fe"
		},
		"cbd817f7-dcb9-4351-bff3-4ad6430bd533": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -796,
			"y": 378,
			"object": "8242f728-507b-4793-b9fb-629dc3cc79e2"
		},
		"c89ca974-b11a-4450-959e-86ebbbc1738a": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-889,399 -775,399",
			"sourceSymbol": "9275932d-7614-4d6b-8bd2-53d1327315ac",
			"targetSymbol": "cbd817f7-dcb9-4351-bff3-4ad6430bd533",
			"object": "1a7a45f9-b2b0-4166-b5b4-334e18f73a92"
		},
		"21bad0a2-d6e3-433d-8944-6dc28022f143": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-775,399 -775,472 -889,472 -889,554",
			"sourceSymbol": "cbd817f7-dcb9-4351-bff3-4ad6430bd533",
			"targetSymbol": "171e8fa5-92a4-473b-b5fc-e1a5b27c4362",
			"object": "47ed3840-7e44-4957-a7b6-7d0f80d8cac1"
		},
		"4fb3579d-b2f3-4e27-ac82-b5e0ca1fb445": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -945,
			"y": 1252,
			"width": 100,
			"height": 60,
			"object": "5461095c-4eec-4521-ab96-7e568c905bff"
		},
		"169f3af9-f19f-494b-881c-b314123bde71": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-894,1173 -894,1282",
			"sourceSymbol": "ff3b4afb-3adf-41e7-a14a-663eb9a4185c",
			"targetSymbol": "4fb3579d-b2f3-4e27-ac82-b5e0ca1fb445",
			"object": "02df9f15-66cd-498e-9ecb-fb671e20d8ce"
		},
		"9c008f40-4847-4240-8a28-9d35d0f20687": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -766,
			"y": 1155,
			"object": "898272e4-5a6b-4718-8c09-8aedec202321"
		},
		"49331e46-8649-49f3-82af-65776b6b2b97": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-895,1282 -746,1282 -746,1196",
			"sourceSymbol": "4fb3579d-b2f3-4e27-ac82-b5e0ca1fb445",
			"targetSymbol": "9c008f40-4847-4240-8a28-9d35d0f20687",
			"object": "166aa69f-ccf8-43dc-8637-fad42d6582c2"
		},
		"97bbc8e1-60c5-4c09-b0e6-606f748f5df2": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-766,1174.25 -895,1174.25",
			"sourceSymbol": "9c008f40-4847-4240-8a28-9d35d0f20687",
			"targetSymbol": "ff3b4afb-3adf-41e7-a14a-663eb9a4185c",
			"object": "05fab4cb-d8c4-47b3-9485-6529df557015"
		},
		"53eacba1-7038-424c-9bbf-702f5fa9a4b3": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-745,1176 -745,1011",
			"sourceSymbol": "9c008f40-4847-4240-8a28-9d35d0f20687",
			"targetSymbol": "60237e2f-5886-4d68-b0f7-4e8b774aa675",
			"object": "8c7d2af6-903b-4a8f-80fe-b35409ee5a5b"
		},
		"ccca4b83-5983-4c94-b4c7-cf57310f20f5": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-774,399 -774,197 -889,197",
			"sourceSymbol": "cbd817f7-dcb9-4351-bff3-4ad6430bd533",
			"targetSymbol": "e595b480-97d6-4b3d-bc7e-9a56253a2e0c",
			"object": "c729c403-aae0-4560-b7cb-6b1529fee388"
		},
		"df3be51d-2bfb-4025-9846-7ebf3d912420": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-889,118 -889,199",
			"sourceSymbol": "9395ff70-a472-490c-bf2e-38c46e38eb3a",
			"targetSymbol": "e595b480-97d6-4b3d-bc7e-9a56253a2e0c",
			"object": "6deb1b7f-2512-40b3-b58d-5759a05cad55"
		},
		"7a8d3bf0-cdb2-4931-9e25-aad100f8aaf6": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1796.5,401 -1796.5,503",
			"sourceSymbol": "0e43ea46-0ea4-4373-9ea0-6eb016bfedcd",
			"targetSymbol": "61b1be29-a1f2-4b7f-9a76-e06fe4d448d9",
			"object": "0aaa828d-8a31-4c3f-b85b-caab990f21ee"
		},
		"35e3afb0-2b0c-4dfd-80fb-d9f8209de2eb": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -623,
			"y": 594,
			"width": 100,
			"height": 60,
			"object": "68ed2872-5482-465b-b560-49979b07b5dd"
		},
		"685fbb9e-c129-4e1f-82fe-f1ae39faa8a4": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -469,
			"y": 603,
			"object": "fb8a7793-4c34-4ad7-8c40-48079bb1661f"
		},
		"4f6edc66-2f91-4702-80f9-cd5d0c25a814": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-573,624 -448,624",
			"sourceSymbol": "35e3afb0-2b0c-4dfd-80fb-d9f8209de2eb",
			"targetSymbol": "685fbb9e-c129-4e1f-82fe-f1ae39faa8a4",
			"object": "36fffba7-d3b4-402e-ae69-28c0227d023c"
		},
		"24880f93-8769-4786-813e-ef2ed5adf4f0": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-448,624 -448,738 -573,738",
			"sourceSymbol": "685fbb9e-c129-4e1f-82fe-f1ae39faa8a4",
			"targetSymbol": "29106054-e5ad-4f5b-8a6c-b1e96c96681d",
			"object": "34ed1d1c-df8f-4100-ae31-42e0a196de43"
		},
		"0dc7ea91-5cad-40cb-a4b2-4714ecfbaced": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-448,603 -448,524 -522.5,524",
			"sourceSymbol": "685fbb9e-c129-4e1f-82fe-f1ae39faa8a4",
			"targetSymbol": "77e8f4ab-0f45-4c04-9a4b-fe81fb9aa3d7",
			"object": "32d9bce6-141f-4ed5-870d-a8c9eef80013"
		},
		"7cc312f2-51ff-4c6a-a81c-31d311450f17": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -2,
			"y": 585,
			"width": 100,
			"height": 60,
			"object": "2bcd6216-3f70-461b-92b7-cf05f6d439ec"
		},
		"af00e15e-5bfe-4895-97e4-422e6b8ff101": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 28,
			"y": 659,
			"object": "df48d131-ba3e-4f87-8430-e9467164626b"
		},
		"64040a6a-9ae0-4cd4-aa3f-ee8e6e280864": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "170,615 41,615",
			"sourceSymbol": "cfc047d4-3aa1-497e-a95a-2a87a2323a4f",
			"targetSymbol": "7cc312f2-51ff-4c6a-a81c-31d311450f17",
			"object": "c932376d-73eb-401f-97f6-3fcdf897527e"
		},
		"b0332aec-f22c-4d2a-9ad4-50aa6a45d127": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "49.5,615 49.5,673",
			"sourceSymbol": "7cc312f2-51ff-4c6a-a81c-31d311450f17",
			"targetSymbol": "af00e15e-5bfe-4895-97e4-422e6b8ff101",
			"object": "b3d57f26-0e70-490d-809a-1bebdca98041"
		},
		"68661a79-2604-4820-a826-200c07601a4e": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "49,680 170,680 170,644.5",
			"sourceSymbol": "af00e15e-5bfe-4895-97e4-422e6b8ff101",
			"targetSymbol": "cfc047d4-3aa1-497e-a95a-2a87a2323a4f",
			"object": "a55bee0b-2803-4600-9f8a-f67425cc3e13"
		},
		"0afe4a2d-0b7f-400e-8107-54e717b8d6f1": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 1016,
			"y": 505,
			"object": "ade99b22-6ac9-4e1d-8811-1534d90745e8"
		},
		"655cd9c8-680f-45a7-893f-8de6033b058f": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1037,517.5 1191,517.5",
			"sourceSymbol": "0afe4a2d-0b7f-400e-8107-54e717b8d6f1",
			"targetSymbol": "787ffd9d-fd9a-4622-9598-13f3a405a621",
			"object": "c709ae80-5a3a-4a14-a6ef-833e31546070"
		},
		"d10c530e-d834-401c-88af-1a4ddcd37251": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1037,526 862,526 862,478.5",
			"sourceSymbol": "0afe4a2d-0b7f-400e-8107-54e717b8d6f1",
			"targetSymbol": "25607da7-fc8b-4db0-8a8d-8f1c2fc11042",
			"object": "c4e79006-a40c-4168-891d-f51b3688fbe2"
		},
		"ce6b16ca-c5aa-46da-b3fb-be897e0dc290": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 831,
			"y": 807,
			"width": 100,
			"height": 60,
			"object": "a552781b-d824-4782-a4da-5bf466645df7"
		},
		"a73b9479-a812-4570-82fd-7ef4785a3eaa": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "879,837 879,932",
			"sourceSymbol": "ce6b16ca-c5aa-46da-b3fb-be897e0dc290",
			"targetSymbol": "9b3429a5-2499-4ea8-a004-6c626ea1cb7c",
			"object": "67c691df-76a3-4191-a3e2-d052b039ba39"
		},
		"9b3429a5-2499-4ea8-a004-6c626ea1cb7c": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 856,
			"y": 911,
			"object": "3cfb8f37-57c4-4fef-abcb-fb6c90d03197"
		},
		"597100a3-39c4-4893-b0ba-8e97784c6737": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "879,932 879,1056",
			"sourceSymbol": "9b3429a5-2499-4ea8-a004-6c626ea1cb7c",
			"targetSymbol": "4bfe8669-ec22-4922-93a8-7783be8a5a70",
			"object": "f65eaf2d-b91e-46ef-8ca8-2d8d661d6d8b"
		},
		"aa848e00-df77-4d65-b7c6-665193495c7a": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "877,934 978.5,934 978.5,731 927.5,731",
			"sourceSymbol": "9b3429a5-2499-4ea8-a004-6c626ea1cb7c",
			"targetSymbol": "03cd082b-a89d-48ef-b323-9b3681487576",
			"object": "5f86cbe2-6a96-4334-97f7-b6c877752c9e"
		},
		"51d50305-ef0c-4ccf-8f50-ad241ec43bcf": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1743,323.78125 1905.8125,323.78125",
			"sourceSymbol": "8861ac74-c10d-4497-8b2b-5494756058b5",
			"targetSymbol": "49bfb5ef-0612-4192-bd49-b570cd450f11",
			"object": "76b97217-0a87-4a46-a465-ff636ade22ce"
		},
		"5627ed87-4588-4f43-9fc5-bdac55c915a9": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 1044,
			"y": -374,
			"width": 100,
			"height": 60,
			"object": "77d837e2-2e1a-40ad-88a3-73192fbfd1c0"
		},
		"3b4db367-b143-48e8-a1a1-47962f0d0add": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 949,
			"y": -219,
			"object": "ed625063-4a14-4208-a032-83a5f425bccc"
		},
		"890b6660-4b5e-4c42-a197-f63bee98a590": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1095,-344 1095,-266.25 972,-266.25 972,-208",
			"sourceSymbol": "5627ed87-4588-4f43-9fc5-bdac55c915a9",
			"targetSymbol": "3b4db367-b143-48e8-a1a1-47962f0d0add",
			"object": "2d70c319-e451-4336-b4ec-4a01a405cd16"
		},
		"0e1ffb32-eff0-4f52-978d-5ea5e5b7697f": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "970,-201 970,-266.5 979,-266.5 979,-314.5",
			"sourceSymbol": "3b4db367-b143-48e8-a1a1-47962f0d0add",
			"targetSymbol": "50e4d209-3ff1-46f0-a9b3-832f270ef38c",
			"object": "9d7aeb3e-0a5b-4a25-b8ae-65c2eb1dd31f"
		},
		"9564665e-ad8d-43d8-9cdb-58bf986948eb": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 5955,
			"y": -53,
			"width": 100,
			"height": 60,
			"object": "b6021f22-e46b-417e-b1bb-872c603b5736"
		},
		"73e35dd0-a32a-478a-82bc-ad9861f8cca8": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "6005,-23 5858,-23",
			"sourceSymbol": "9564665e-ad8d-43d8-9cdb-58bf986948eb",
			"targetSymbol": "590f14b7-9928-48cc-a7a7-15975724541c",
			"object": "bc832fdd-9634-4fcf-9266-7322b82aded4"
		},
		"590f14b7-9928-48cc-a7a7-15975724541c": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 5837,
			"y": -44,
			"object": "9dd72e42-191f-468a-9647-a628c8fd17e6"
		},
		"c9224d24-8eef-4f72-9152-ba0757292971": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "5858,-23.25 5728.5,-23.25",
			"sourceSymbol": "590f14b7-9928-48cc-a7a7-15975724541c",
			"targetSymbol": "53e54950-7757-4161-82c9-afa7e86cff2c",
			"object": "701e242d-aa44-43d2-a412-438b2eb725ed"
		},
		"80389e88-012a-4351-b50e-8965f1119375": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "5858,-27 5858,-103.5 6177,-103.5 6177,-52.5",
			"sourceSymbol": "590f14b7-9928-48cc-a7a7-15975724541c",
			"targetSymbol": "8e2c8089-f912-4177-b101-7f5992f30871",
			"object": "dbf112ee-4a31-4dd2-adc1-34ba62da883e"
		},
		"bd90d11c-983d-46cc-b438-749d98267604": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -2379,
			"y": 85,
			"width": 100,
			"height": 60,
			"object": "0cbbabb8-3988-416b-b310-77659b4225b6"
		},
		"8865b959-4554-4b0b-a53d-25dda0a3a7af": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -2125,
			"y": 93,
			"object": "8e4664d1-e4bc-4b0f-8386-e37aa621fc85"
		},
		"c653ed50-d0b4-49f4-877e-33a724095592": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -2251,
			"y": 85,
			"width": 100,
			"height": 60,
			"object": "acd3716f-1a35-4503-9739-85361bef5f85"
		},
		"f00005d7-ce72-44f7-b03a-a360f4bf546c": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-2279.5,115 -2250.5,115",
			"sourceSymbol": "bd90d11c-983d-46cc-b438-749d98267604",
			"targetSymbol": "c653ed50-d0b4-49f4-877e-33a724095592",
			"object": "59c94139-b2a5-4f3a-a81d-0f5ae8b05088"
		},
		"380c924b-fc7a-487c-a075-665d7a6fddf1": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-2151.5,114.5 -2124.5,114.5",
			"sourceSymbol": "c653ed50-d0b4-49f4-877e-33a724095592",
			"targetSymbol": "8865b959-4554-4b0b-a53d-25dda0a3a7af",
			"object": "75130ec0-c22d-446c-8c3d-d87cf2a6a170"
		},
		"772c915a-89e3-40c1-81ab-142b6fff851e": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-2104,114 -2071.25,114 -2071.25,106 -2039,106",
			"sourceSymbol": "8865b959-4554-4b0b-a53d-25dda0a3a7af",
			"targetSymbol": "f8a19cae-6eaa-4b5d-a9b4-4baab54494c5",
			"object": "5e4ff83f-97cf-45d5-bfeb-2806c6ab3edf"
		},
		"a4323751-bcc5-4cf0-a12a-8d88d03d7677": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 1183,
			"y": -358,
			"width": 100,
			"height": 60,
			"object": "c09525f9-e84e-486c-9ee4-3255981f9f30"
		},
		"4537fbcb-6aa9-49cf-b2b2-63494e81b2fb": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 1205,
			"y": -454,
			"object": "19dbe20f-9499-4d84-b2a6-59f2577bc887"
		},
		"c3bb08e1-d00b-4b90-890f-7403590936a2": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1229.5,-357.5 1229.5,-412.5",
			"sourceSymbol": "a4323751-bcc5-4cf0-a12a-8d88d03d7677",
			"targetSymbol": "4537fbcb-6aa9-49cf-b2b2-63494e81b2fb",
			"object": "da8fedd5-802e-4093-87bc-2cf327e38afa"
		},
		"77dba93a-8df6-4018-8808-701c58eac3bd": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1226,-433 1363,-433",
			"sourceSymbol": "4537fbcb-6aa9-49cf-b2b2-63494e81b2fb",
			"targetSymbol": "b72928d5-20c2-4a6d-a392-6b232b7f0ab9",
			"object": "fcd9609c-ab96-4009-b528-74a340aaaa80"
		},
		"3b898206-27c4-4f32-a524-32f297422438": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1226,-433 1049,-433",
			"sourceSymbol": "4537fbcb-6aa9-49cf-b2b2-63494e81b2fb",
			"targetSymbol": "cf10fba9-92cc-4115-a7bd-8b0097b0e268",
			"object": "bdf95749-dcef-4cb9-b50b-63e565a7649a"
		},
		"6b9fd3c7-c0fc-466b-94ed-869fe0d91a7c": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 2701,
			"y": -482,
			"width": 100,
			"height": 60,
			"object": "83164bc9-e708-4115-89f1-90702519e7d9"
		},
		"0694b614-b220-4a78-8cf5-4bd4bdd801d6": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "2751,-454.5 2917,-454.5",
			"sourceSymbol": "6b9fd3c7-c0fc-466b-94ed-869fe0d91a7c",
			"targetSymbol": "8da1f857-8c7f-4cdb-8e54-06275ecda30a",
			"object": "0840dd77-7f25-4882-a5e4-e10f4010a3c8"
		},
		"468dd65c-26b8-47e6-b0ba-157490f3b2b2": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 3799,
			"y": -465,
			"object": "56449570-8bd1-47f8-8a8b-e8cd7d8bec49"
		},
		"3271f36a-10f0-4482-b650-1a5b8d2b1c8d": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "3820,-423.5 3820,-370.5 2751,-370.5 2751,-422.5",
			"sourceSymbol": "468dd65c-26b8-47e6-b0ba-157490f3b2b2",
			"targetSymbol": "6b9fd3c7-c0fc-466b-94ed-869fe0d91a7c",
			"object": "76c5606f-384a-4e96-895f-53cc34961857"
		},
		"5779acb8-540d-411a-8ec2-73bbbd994e47": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "3820,-443.5 3983,-443.5",
			"sourceSymbol": "468dd65c-26b8-47e6-b0ba-157490f3b2b2",
			"targetSymbol": "5c52d157-2c8f-444d-940a-c75ce8e68250",
			"object": "ac960d55-35e5-4657-9c58-efd1cda5e74f"
		},
		"466ae39f-55de-48e1-bc70-519f0e92fe6c": {
			"classDefinition": "com.sap.bpm.wfs.ui.ReferencedSubflowSymbol",
			"x": 1157,
			"y": -167,
			"width": 100,
			"height": 60,
			"object": "15a3e187-5366-4134-b217-f1fa7fa383ae"
		},
		"466aed42-84bc-4172-9e3b-ee4c94d91334": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "970,-200 1026.25,-200 1026.25,-139 1081,-139",
			"sourceSymbol": "3b4db367-b143-48e8-a1a1-47962f0d0add",
			"targetSymbol": "2282dcd6-9e25-4642-b623-fcbe98c52637",
			"object": "fd28d3ea-e700-47e9-a55b-974a5c22c44e"
		},
		"766b9d0a-985d-4aa9-b1f1-db4430b5b0a4": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1210.5,-137 1210.5,-233.25 1229.5,-233.25 1229.5,-328",
			"sourceSymbol": "466ae39f-55de-48e1-bc70-519f0e92fe6c",
			"targetSymbol": "a4323751-bcc5-4cf0-a12a-8d88d03d7677",
			"object": "ae7e3c1d-ecf2-4d12-9a54-72fad6b8d3da"
		},
		"81ff534f-de61-4ce2-8d70-17452fd71559": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 6300,
			"y": -460,
			"object": "586b13f2-76b5-4ed7-a64c-ed62c9f185d8"
		},
		"4631dc3d-febd-45e1-a507-c40a11176e54": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "6317,-439 6317,-661.5 1917,-661.5",
			"sourceSymbol": "81ff534f-de61-4ce2-8d70-17452fd71559",
			"targetSymbol": "e2518623-a595-4f88-986b-cad2990c1bd2",
			"object": "da0d2b45-e64b-4fa1-9508-a71729321442"
		},
		"cf10fba9-92cc-4115-a7bd-8b0097b0e268": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 999,
			"y": -463,
			"width": 100,
			"height": 60,
			"object": "76998587-b436-46d5-9654-f1d5b54cea7c"
		},
		"6d2722e7-d064-4781-8e80-5f52c4e10ff8": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 758,
			"y": 204,
			"object": "cf128b14-466a-48b6-bbcf-c5ac8fc4c7b9"
		},
		"feb3344a-3cd7-426b-9678-64c544cc7b05": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "479.625,137 479.625,175.8125 539,175.8125 539,225",
			"sourceSymbol": "bc6fdfbc-6cfc-42a2-a532-b2861246a582",
			"targetSymbol": "e2734640-32b4-420c-9acb-fa70fac853e9",
			"object": "bb8d0430-5643-45d5-8e85-b90725e3159f"
		},
		"2351c119-2466-4e25-9d4b-1d8762143abc": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 849,
			"y": 118,
			"width": 100,
			"height": 60,
			"object": "bc4a7c70-7b35-4903-845d-70c4e5f3242f"
		},
		"d9952f9f-efda-46f7-9d22-b294e1199d99": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "779,204.5 779,147 849.5,147",
			"sourceSymbol": "6d2722e7-d064-4781-8e80-5f52c4e10ff8",
			"targetSymbol": "2351c119-2466-4e25-9d4b-1d8762143abc",
			"object": "37bd7e76-3fd0-482e-b3f8-6690e4915208"
		},
		"3b4476ff-bdbc-4d38-9414-7132f5eeb041": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "779,225 1107.15625,225 1107.15625,250 1464.3125,250 1464.3125,329.78125",
			"sourceSymbol": "6d2722e7-d064-4781-8e80-5f52c4e10ff8",
			"targetSymbol": "1a7ea469-a95b-4019-a06d-962422e501ea",
			"object": "5b84c5e1-c843-41c0-ab5b-376262e1869a"
		},
		"048874ef-105c-4b68-9f65-8964b44af9b1": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": 1158.3125,
			"y": 309.5625,
			"width": 100,
			"height": 60,
			"object": "77009387-aab8-4f42-8f7c-f4e10985f460"
		},
		"4d62f9b8-050a-4209-afd9-125a72448ee1": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1193,339.78125 1193,277.53125 779,277.53125 779,229",
			"sourceSymbol": "048874ef-105c-4b68-9f65-8964b44af9b1",
			"targetSymbol": "6d2722e7-d064-4781-8e80-5f52c4e10ff8",
			"object": "b2fc9b55-32c1-4ec5-8f65-83988df60ca8"
		},
		"6d4beb80-62d9-451f-b118-c47219880f55": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -1183,
			"y": -149,
			"width": 100,
			"height": 60,
			"object": "884ff1e1-f344-46c9-9cac-f8cf678a5a78"
		},
		"7eb5935a-3caf-4314-9ff0-1449d4d9c094": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1133,-119 -1257,-119",
			"sourceSymbol": "6d4beb80-62d9-451f-b118-c47219880f55",
			"targetSymbol": "1070a4f4-dfc1-4b84-af9a-c2df1bd5abc3",
			"object": "54a8904a-f070-4ea9-8d64-e5b07eafe485"
		},
		"e2518623-a595-4f88-986b-cad2990c1bd2": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 1867,
			"y": -692,
			"width": 100,
			"height": 60,
			"object": "e55968cd-4af7-4797-9fc6-466f04cfbeea"
		},
		"323852f8-5099-40f0-8228-af9911d71dd9": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 1712,
			"y": -692,
			"width": 100,
			"height": 60,
			"object": "d646474d-3529-41a6-ae57-d4a43aa49800"
		},
		"fdd1a361-a248-4163-ab4e-f1370174c0b1": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1867.5,-662 1808,-662",
			"sourceSymbol": "e2518623-a595-4f88-986b-cad2990c1bd2",
			"targetSymbol": "323852f8-5099-40f0-8228-af9911d71dd9",
			"object": "27566425-a069-4cf3-aede-efa584513bfd"
		},
		"739128ba-e730-4b67-b5f3-69309d425e57": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 1559,
			"y": -692,
			"width": 100,
			"height": 60,
			"object": "3634b4b9-98ac-4d8c-96cf-bf11d09e060f"
		},
		"5e979401-1d9a-4f75-a0f0-8b3a4261e955": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1609,-662 1478,-662",
			"sourceSymbol": "739128ba-e730-4b67-b5f3-69309d425e57",
			"targetSymbol": "0ed199e0-4676-43ca-b314-d85e8bb84e43",
			"object": "3f41cb7f-93bc-4c0f-b548-530ecc1211a1"
		},
		"a6f5200e-e5cc-45c9-b724-0da533fff498": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1712.5,-662 1658.5,-662",
			"sourceSymbol": "323852f8-5099-40f0-8228-af9911d71dd9",
			"targetSymbol": "739128ba-e730-4b67-b5f3-69309d425e57",
			"object": "8c621dca-bf5a-415a-8717-34f423b4793a"
		},
		"0ed199e0-4676-43ca-b314-d85e8bb84e43": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 1457,
			"y": -683,
			"object": "4db9678a-18f4-4646-939c-a4e6effc31ee"
		},
		"a239056d-dd1d-4757-8e6d-adc9a0518f93": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1478,-663.5 1478,-767.5 -257,-767.5 -257,-685.5",
			"sourceSymbol": "0ed199e0-4676-43ca-b314-d85e8bb84e43",
			"targetSymbol": "2b620b62-94c5-40dc-a99a-47a58c9552fe",
			"object": "b1fe490a-52b0-42c0-b0d1-4425931edf89"
		},
		"652976b4-9933-4e4d-89c3-d0dad8e42b1c": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1478,-682.5 1478,-742.5 1762,-742.5 1762,-691.5",
			"sourceSymbol": "0ed199e0-4676-43ca-b314-d85e8bb84e43",
			"targetSymbol": "323852f8-5099-40f0-8228-af9911d71dd9",
			"object": "0cd66587-5e5b-4bc7-a827-fc0712254f31"
		},
		"9fa71286-3452-4dac-953b-857ca537ef7a": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "6321,-439 6424,-439 6424,-132",
			"sourceSymbol": "81ff534f-de61-4ce2-8d70-17452fd71559",
			"targetSymbol": "74cb00fd-d2f0-4072-be13-b66300bf4446",
			"object": "7179827e-2dba-4c0d-a86f-07fc4fb8320e"
		},
		"827000e5-faff-4653-91b0-8ebd01cfebdc": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 3398,
			"y": -478,
			"width": 100,
			"height": 60,
			"object": "700a6d8f-16e3-4952-9283-2eeb3bf5d7ad"
		},
		"19217147-6e76-43b2-a45c-4498ffcf14aa": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "3448,-448 3597,-448",
			"sourceSymbol": "827000e5-faff-4653-91b0-8ebd01cfebdc",
			"targetSymbol": "841ed19d-6ca3-4da9-a306-ff413978db1d",
			"object": "87c37b70-30a4-463a-a3c7-33c7d15a78cc"
		},
		"d80bcc7d-a79c-4382-8f98-3237b35f18f5": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 1460,
			"y": -319,
			"object": "e60d84ca-b7e8-4f08-8390-059aab21d6bf"
		},
		"dee7bf7e-22a0-4ab1-84bf-8a7301f79caf": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 1460,
			"y": -454,
			"object": "150a24e2-88c0-4dcb-a84c-20d93b376d7d"
		},
		"51844daf-1dc9-45fb-9de0-3eb2c4f6d4c5": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1481,-435 1844,-435",
			"sourceSymbol": "dee7bf7e-22a0-4ab1-84bf-8a7301f79caf",
			"targetSymbol": "62e54757-5905-42c9-a59d-c68a56ba6c5f",
			"object": "75d6c528-28cf-4f01-915f-fba4eb40f575"
		},
		"7b5635e9-9db0-4a5b-92dd-b94444d3c6f1": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1482,-415 1482,-292",
			"sourceSymbol": "dee7bf7e-22a0-4ab1-84bf-8a7301f79caf",
			"targetSymbol": "d80bcc7d-a79c-4382-8f98-3237b35f18f5",
			"object": "b89c7f06-ae33-4900-a4c8-f95d85887f72"
		},
		"c860905f-11db-4878-bc08-e8f4d950a5fc": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1494.5,-301 1922,-301 1922,-153 6321,-153 6321,-418.5",
			"sourceSymbol": "d80bcc7d-a79c-4382-8f98-3237b35f18f5",
			"targetSymbol": "81ff534f-de61-4ce2-8d70-17452fd71559",
			"object": "80b34501-6e5b-4db5-97ca-0bf53550e22b"
		},
		"b72928d5-20c2-4a6d-a392-6b232b7f0ab9": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 1313,
			"y": -463,
			"width": 100,
			"height": 60,
			"object": "1add78a6-c2b5-4286-a14b-eb75518972a4"
		},
		"77d0fe04-649e-4263-b280-67c9901f538c": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1363,-433 1481,-433",
			"sourceSymbol": "b72928d5-20c2-4a6d-a392-6b232b7f0ab9",
			"targetSymbol": "dee7bf7e-22a0-4ab1-84bf-8a7301f79caf",
			"object": "473dfa99-dfa2-40b7-985e-62ca3cda6913"
		},
		"6581082d-10ee-467f-8b7e-bedf5c35707c": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 988,
			"y": 118,
			"width": 100,
			"height": 60,
			"object": "151ee67a-db52-4540-8b6a-f591a7b71f4a"
		},
		"94f6f1bb-ea12-4367-b0e7-d5da1e033787": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1038,148 1178,148",
			"sourceSymbol": "6581082d-10ee-467f-8b7e-bedf5c35707c",
			"targetSymbol": "0a0377f0-9453-4fa2-9b2f-166bf15c4cf6",
			"object": "ddb81cb4-0d8a-4c22-8f74-27bd375a40d4"
		},
		"11342345-76e0-491b-8f28-8ab7cee7fdab": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "948.5,148 988.5,148",
			"sourceSymbol": "2351c119-2466-4e25-9d4b-1d8762143abc",
			"targetSymbol": "6581082d-10ee-467f-8b7e-bedf5c35707c",
			"object": "071967f1-e2f1-49d6-9e80-c9eafbcb18df"
		},
		"0a0377f0-9453-4fa2-9b2f-166bf15c4cf6": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 1128,
			"y": 118,
			"width": 100,
			"height": 60,
			"object": "af0a4614-e737-4ead-b301-67aa489ca082"
		},
		"69511806-fa2b-45fd-bf59-5a4d738d404d": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1178,148 1316,148",
			"sourceSymbol": "0a0377f0-9453-4fa2-9b2f-166bf15c4cf6",
			"targetSymbol": "c99a12bc-9546-4a8d-b9b9-68cdcbf5bc57",
			"object": "06bbfc0a-c342-4208-855c-62a1ffde7850"
		},
		"c99a12bc-9546-4a8d-b9b9-68cdcbf5bc57": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 1266,
			"y": 118,
			"width": 100,
			"height": 60,
			"object": "354a4d17-0c0c-4245-bfca-fe0064bfad23"
		},
		"bae1c41e-4795-4768-9958-33a590d3e735": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 1457,
			"y": 127,
			"object": "c00f2a6f-6814-4c28-a548-49650d55e9f2"
		},
		"5bb48ff4-725f-4547-bae4-44db2d2c3a5e": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1479,127.5 1479,-284",
			"sourceSymbol": "bae1c41e-4795-4768-9958-33a590d3e735",
			"targetSymbol": "d80bcc7d-a79c-4382-8f98-3237b35f18f5",
			"object": "ca6f3230-2b40-4163-9c31-2c5b9c00a775"
		},
		"e993a4e1-6901-437c-857c-72e147cfb2ca": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1365.5,148 1469,148",
			"sourceSymbol": "c99a12bc-9546-4a8d-b9b9-68cdcbf5bc57",
			"targetSymbol": "bae1c41e-4795-4768-9958-33a590d3e735",
			"object": "dfd21a8a-1b17-4dcb-aeac-dbcc99c8d817"
		},
		"16d45710-8451-4962-81f8-ce010bc73a3e": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1478,168.5 1478,228.5 1178,228.5 1178,177.5",
			"sourceSymbol": "bae1c41e-4795-4768-9958-33a590d3e735",
			"targetSymbol": "0a0377f0-9453-4fa2-9b2f-166bf15c4cf6",
			"object": "ad3d14f4-64f8-4682-9636-353c11ea56a1"
		},
		"f8a19cae-6eaa-4b5d-a9b4-4baab54494c5": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -2060,
			"y": 85,
			"object": "a92f0f95-9eb7-414a-9dbb-1d9df0785f8c"
		},
		"16c2c824-ea82-40ef-9788-35c5bae8e9de": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-2039,106 -1968,106 -1968,115 -1868,115",
			"sourceSymbol": "f8a19cae-6eaa-4b5d-a9b4-4baab54494c5",
			"targetSymbol": "2621149b-aca7-4304-bccf-468e1c675fac",
			"object": "4dfa1b2a-2536-4efa-8427-7efa45ef68f3"
		},
		"bb8fde7d-3253-4f78-9a04-39946bb52057": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-2040,85 -2040,34.5 -1299,34.5 -1299,93",
			"sourceSymbol": "f8a19cae-6eaa-4b5d-a9b4-4baab54494c5",
			"targetSymbol": "d9d65df8-894c-4780-851a-eecde4a4f09d",
			"object": "d06753fc-9d95-49d5-be33-c0ddd62966cb"
		},
		"3c646481-25bf-4488-b777-ad5ede05b026": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "51.5,700.5 51.5,743.3583374023438",
			"sourceSymbol": "af00e15e-5bfe-4895-97e4-422e6b8ff101",
			"targetSymbol": "c47e39b6-4858-4b3b-8613-b8e111e19d70",
			"object": "1c436edf-5127-4046-b900-0e4dd4fe63ff"
		},
		"2282dcd6-9e25-4642-b623-fcbe98c52637": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 1060,
			"y": -162,
			"object": "f5065acc-ca90-4eb5-b50c-5499b2d3a333"
		},
		"4246423a-712a-4adb-bd7a-fbb7e847169f": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1081,-139 1207,-139",
			"sourceSymbol": "2282dcd6-9e25-4642-b623-fcbe98c52637",
			"targetSymbol": "466ae39f-55de-48e1-bc70-519f0e92fe6c",
			"object": "eaef82ac-a7dc-4b3b-94a5-19dffbdb5a52"
		},
		"1a830bfb-eaa3-4073-bab5-43fb6bc39729": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-2104,134.5 -2104,195.5 -2329,195.5 -2329,144.5",
			"sourceSymbol": "8865b959-4554-4b0b-a53d-25dda0a3a7af",
			"targetSymbol": "bd90d11c-983d-46cc-b438-749d98267604",
			"object": "3b3113a8-70ff-4758-8b9b-acef4e3f5952"
		},
		"f9938e7e-351c-4292-816b-b29391c18b31": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1081,-141 1081,-240 1363,-240 1363,-433",
			"sourceSymbol": "2282dcd6-9e25-4642-b623-fcbe98c52637",
			"targetSymbol": "b72928d5-20c2-4a6d-a392-6b232b7f0ab9",
			"object": "75896328-c6d4-4c1b-b927-19d825b6ea0a"
		},
		"6cf73f92-88d8-45bd-882f-c4954b2095fd": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -1183,
			"y": 90,
			"object": "41c3c126-fb82-4a1d-b79c-765a13db7625"
		},
		"171fa25d-9feb-4b8c-8cf9-93f36807998d": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1162,114.5 -889,114.5",
			"sourceSymbol": "6cf73f92-88d8-45bd-882f-c4954b2095fd",
			"targetSymbol": "9395ff70-a472-490c-bf2e-38c46e38eb3a",
			"object": "a0226c8b-64d3-4426-8403-7d082dd38502"
		},
		"cf78967e-83a3-4b91-aebf-4d64f9118bd3": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1162,131.5 -1162,199 -938.5,199",
			"sourceSymbol": "6cf73f92-88d8-45bd-882f-c4954b2095fd",
			"targetSymbol": "e595b480-97d6-4b3d-bc7e-9a56253a2e0c",
			"object": "de40e5a9-db13-4e67-9d93-2904497e9574"
		},
		"ccb71dce-fddc-4892-9737-d7b811918998": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 3192,
			"y": -465,
			"object": "00a7fee2-04b8-47c7-a454-81a8431932a4"
		},
		"66bfe4dc-af6a-4348-8d92-2da13d8f7a7a": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "3213,-446 3448,-446",
			"sourceSymbol": "ccb71dce-fddc-4892-9737-d7b811918998",
			"targetSymbol": "827000e5-faff-4653-91b0-8ebd01cfebdc",
			"object": "5eb4b3c7-c7e8-4ce3-a618-3794f5a6dc64"
		},
		"c0792ee4-03ad-4835-bcae-62a05f6c3b4d": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "3211,-444 3211,-577 3284,-577",
			"sourceSymbol": "ccb71dce-fddc-4892-9737-d7b811918998",
			"targetSymbol": "8864b501-df15-408a-bb0b-58911d53a2f3",
			"object": "c1c5e7ff-e337-4f24-8657-c4bcd5d6795e"
		},
		"8864b501-df15-408a-bb0b-58911d53a2f3": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 3234,
			"y": -605,
			"width": 100,
			"height": 60,
			"object": "3868830c-d756-46b5-bf27-6a6af1cefb8e"
		},
		"54b25b91-3f8b-4394-8d29-caa2a3eb9be5": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "3284,-574.5 3449,-574.5",
			"sourceSymbol": "8864b501-df15-408a-bb0b-58911d53a2f3",
			"targetSymbol": "59c6f92a-28a9-4090-972a-ba07f2373132",
			"object": "ffe81886-f21d-482a-92d6-b54e3f2648b4"
		},
		"59c6f92a-28a9-4090-972a-ba07f2373132": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 3392,
			"y": -605,
			"width": 100,
			"height": 60,
			"object": "ed0992f0-1881-4231-bded-2d6fae63bfcb"
		},
		"4d2b7e7f-29f1-44f2-93d9-4f37d4032c06": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "3438.5,-574 3438.5,-447",
			"sourceSymbol": "59c6f92a-28a9-4090-972a-ba07f2373132",
			"targetSymbol": "827000e5-faff-4653-91b0-8ebd01cfebdc",
			"object": "a32dc0ac-277e-4aac-bb00-82dd66bbe5d4"
		},
		"98478846-955f-4ffd-a91a-007a839791cc": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 307,
			"y": 102,
			"width": 102,
			"height": 60,
			"object": "188c8349-34ce-4d4f-bb98-1b8c5e8de814"
		},
		"c28d9314-2120-410b-8516-184c3382a3cf": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "358,129.3125 479.625,129.3125",
			"sourceSymbol": "98478846-955f-4ffd-a91a-007a839791cc",
			"targetSymbol": "bc6fdfbc-6cfc-42a2-a532-b2861246a582",
			"object": "f8f8ead3-4a3c-4f27-b26b-e153bfe76dbc"
		},
		"16b11f81-e13c-4a9c-8d87-8d0c61e9f321": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 2343,
			"y": -467,
			"object": "f77539b1-89c8-4ef9-82ca-ee0ffb34b3ab"
		},
		"70b001ec-8375-4669-963d-b789bb50018a": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "2364,-447 2526,-447",
			"sourceSymbol": "16b11f81-e13c-4a9c-8d87-8d0c61e9f321",
			"targetSymbol": "7e9a1a4c-e821-4c7d-ad14-314493be1d9e",
			"object": "048510c6-d11d-44d2-b520-292930deb72e"
		},
		"eefd155f-d80e-4254-b495-9b56c8811f05": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "2366,-466.5 2366,-532.5 2751,-532.5 2751,-481.5",
			"sourceSymbol": "16b11f81-e13c-4a9c-8d87-8d0c61e9f321",
			"targetSymbol": "6b9fd3c7-c0fc-466b-94ed-869fe0d91a7c",
			"object": "c37991b2-2378-4111-972c-33fb47f3a010"
		},
		"7e9a1a4c-e821-4c7d-ad14-314493be1d9e": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 2476,
			"y": -478,
			"width": 100,
			"height": 60,
			"object": "8b42abcb-2e53-48d1-afdd-be0b1825b791"
		},
		"3ba0aa03-c964-4c25-b74d-87e1b7adecbf": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 4572,
			"y": -460,
			"object": "79b7e998-0eb2-45e9-b322-2e5d832d4957"
		},
		"afcd29a4-9cda-49a5-a389-3c7ad2cd3f3a": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "2526,-450 2751,-450",
			"sourceSymbol": "7e9a1a4c-e821-4c7d-ad14-314493be1d9e",
			"targetSymbol": "6b9fd3c7-c0fc-466b-94ed-869fe0d91a7c",
			"object": "5a52e8ec-d8f1-4027-a781-a95484b6f0a7"
		},
		"c4033ce4-f4a9-4667-91a9-aaf53bb29b29": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "4593,-445.5 4593,-521 6207,-521 6207,-445.5",
			"sourceSymbol": "3ba0aa03-c964-4c25-b74d-87e1b7adecbf",
			"targetSymbol": "78cbe836-7c06-45d3-905e-73e7dabb9a38",
			"object": "b5a8f5fe-779b-4fed-be76-f2179e51e2f4"
		},
		"404dbd01-211a-4e6d-8541-1e7b6e81f553": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "4593,-439 4593,-321 6203,-321 6203,-439",
			"sourceSymbol": "3ba0aa03-c964-4c25-b74d-87e1b7adecbf",
			"targetSymbol": "78cbe836-7c06-45d3-905e-73e7dabb9a38",
			"object": "6dda97f8-aa4d-4713-92c5-fef77fc49c28"
		},
		"78cbe836-7c06-45d3-905e-73e7dabb9a38": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 6183,
			"y": -460,
			"object": "6ee8995c-c5b8-4bd7-8a79-f768b73174fe"
		},
		"bb1f173b-e982-4843-86e9-23c94adf6c18": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "6204,-439 6321,-439",
			"sourceSymbol": "78cbe836-7c06-45d3-905e-73e7dabb9a38",
			"targetSymbol": "81ff534f-de61-4ce2-8d70-17452fd71559",
			"object": "0054aef6-5b38-4068-b61f-cfed96558c2c"
		},
		"f21c00e3-b2ef-4b03-850e-da21df6a9fe9": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 5364,
			"y": -460,
			"width": 100,
			"height": 60,
			"object": "4276f295-a1b2-40c0-bce3-304fffe6aa62"
		},
		"ad38a4e4-cd50-4f73-9f3e-29469669aae3": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "4593,-434.5 4743,-434.5",
			"sourceSymbol": "3ba0aa03-c964-4c25-b74d-87e1b7adecbf",
			"targetSymbol": "462a68f6-ee52-47eb-a2f9-71944020c8ea",
			"object": "29ec8dc3-eea5-45f6-a560-7d4331f8c93b"
		},
		"3a64dcd9-10ff-45c0-bee0-55f5aebeccb6": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 4867,
			"y": -460,
			"width": 100,
			"height": 60,
			"object": "ff37bfbb-d8b6-451b-a1b9-e762b6e8347f"
		},
		"9d40d8a0-fe63-436a-a438-1886c2c546f4": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "4917,-430 5085,-430",
			"sourceSymbol": "3a64dcd9-10ff-45c0-bee0-55f5aebeccb6",
			"targetSymbol": "9561b1c4-fef0-4f62-a786-e6c2972a42a7",
			"object": "e3ffcdf1-f689-4dba-8f1c-36c0b5f9863d"
		},
		"462a68f6-ee52-47eb-a2f9-71944020c8ea": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 4693,
			"y": -460,
			"width": 100,
			"height": 60,
			"object": "e9776d6f-986e-4f0e-9385-50ed77dbbc26"
		},
		"4dbf970f-b9f0-4c65-8194-39ea017c10bc": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "4743,-431 4917,-431",
			"sourceSymbol": "462a68f6-ee52-47eb-a2f9-71944020c8ea",
			"targetSymbol": "3a64dcd9-10ff-45c0-bee0-55f5aebeccb6",
			"object": "e084355f-1259-40cd-aa4d-b665b8c372be"
		},
		"9561b1c4-fef0-4f62-a786-e6c2972a42a7": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 5035,
			"y": -460,
			"width": 100,
			"height": 60,
			"object": "28a0934a-bd2f-4d09-8e45-144459be00d5"
		},
		"6eb65aa6-6c72-4e5f-851f-fa00a9b8682e": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "5085,-437.5 5245,-437.5",
			"sourceSymbol": "9561b1c4-fef0-4f62-a786-e6c2972a42a7",
			"targetSymbol": "06e4457d-dcda-4144-a9dc-851c127b2c87",
			"object": "6773827d-cbb0-496a-a861-13db7c9727bd"
		},
		"06e4457d-dcda-4144-a9dc-851c127b2c87": {
			"classDefinition": "com.sap.bpm.wfs.ui.ReferencedSubflowSymbol",
			"x": 5189,
			"y": -460,
			"width": 100,
			"height": 60,
			"object": "50af6a3b-96a3-4c1e-b141-0e14052384f8"
		},
		"ee75e1cf-1556-46cf-ac98-751765f11b27": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "5239,-430 5414,-430",
			"sourceSymbol": "06e4457d-dcda-4144-a9dc-851c127b2c87",
			"targetSymbol": "f21c00e3-b2ef-4b03-850e-da21df6a9fe9",
			"object": "1a1c487e-b25d-4e56-a1be-162733240567"
		},
		"464090ea-c764-4385-bd6b-813f5e5a66c4": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -2531,
			"y": 237,
			"width": 100,
			"height": 60,
			"object": "61b35d98-875a-4caa-9dd6-908ee777b1f4"
		},
		"873bde12-20a0-4fb2-87f5-40efafd221e6": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -2765,
			"y": 94,
			"object": "67439b2d-26da-4526-89c7-7ab805d2940c"
		},
		"d430478b-2859-47f2-8b43-201a700f437b": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-2744,115 -2568,115",
			"sourceSymbol": "873bde12-20a0-4fb2-87f5-40efafd221e6",
			"targetSymbol": "660a3d29-5f0b-41d6-8483-a5102eb1d03a",
			"object": "cde72047-4f3f-4457-9c17-467731a2cf5b"
		},
		"71571374-f673-4350-b0a2-bae222ba90aa": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-2744,135.5 -2744,186.5 -2481,186.5 -2481,237.5",
			"sourceSymbol": "873bde12-20a0-4fb2-87f5-40efafd221e6",
			"targetSymbol": "464090ea-c764-4385-bd6b-813f5e5a66c4",
			"object": "612bd3cc-c675-4e42-ad1f-5d6e2e9b23d9"
		},
		"f1fe5eeb-ca33-41e7-9a76-c11ada1bac89": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-2496.75,267 -2411.75,267 -2411.75,327 -2343,327",
			"sourceSymbol": "464090ea-c764-4385-bd6b-813f5e5a66c4",
			"targetSymbol": "a1dd697b-6fa0-4b96-babe-0c4999c6b111",
			"object": "2510cd26-b393-4ae2-b41a-b02b5dd030cb"
		},
		"f42b6e9f-15ee-451e-a043-136a8e5c9aaf": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -910,
			"y": 249,
			"object": "2e2c1228-70ce-4e3e-a17f-6f0e57a3fddb"
		},
		"6eff193d-17f7-439c-8f0a-e2acb7ccc58c": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-889,270 -889,399",
			"sourceSymbol": "f42b6e9f-15ee-451e-a043-136a8e5c9aaf",
			"targetSymbol": "9275932d-7614-4d6b-8bd2-53d1327315ac",
			"object": "fa649f89-29e9-41c0-b6dc-cea1d2e142e9"
		},
		"a6f88a86-ce4d-43b9-a79b-1c6925cd2284": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-889,270 -1028,270 -1028,399",
			"sourceSymbol": "f42b6e9f-15ee-451e-a043-136a8e5c9aaf",
			"targetSymbol": "9d6dfb1b-305b-4cd7-b0a1-f64fd6d4e2a6",
			"object": "f0a70486-2531-43e6-8b75-9c0befb108a3"
		},
		"ddfcb5c7-7239-4f55-ba6c-d14e748e6601": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 459,
			"y": 249,
			"object": "08463fa9-cbff-4d54-83c3-642f3e6fb2cc"
		},
		"bd3d3822-dc6c-4407-addf-63cb902f96e7": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "482,270 482,456 679,456",
			"sourceSymbol": "ddfcb5c7-7239-4f55-ba6c-d14e748e6601",
			"targetSymbol": "606e578d-742c-4294-a057-cba00c2b95bc",
			"object": "82800f1a-6ec4-4427-baf1-9429a8c2b4c3"
		},
		"3d145dbf-7bff-4924-b515-5423fb8c0109": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "480,272 399,272 399,436",
			"sourceSymbol": "ddfcb5c7-7239-4f55-ba6c-d14e748e6601",
			"targetSymbol": "02e17155-9f0e-4ef3-a5e7-063cee532c43",
			"object": "634919b7-63f5-4a36-9c78-0562c8c0028e"
		},
		"9d6dfb1b-305b-4cd7-b0a1-f64fd6d4e2a6": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -1075,
			"y": 369,
			"width": 100,
			"height": 60,
			"object": "0491100d-c3d7-4a10-b987-a51714fe03b9"
		},
		"2ba71b67-db72-4d22-a431-421f852caadb": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 354,
			"y": 629,
			"width": 100,
			"height": 60,
			"object": "c3782cf7-1ebf-4b75-a47a-64c27487fddd"
		},
		"829fcaf6-1b27-413b-a6d7-a7d092745ed4": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "404,659 404,741",
			"sourceSymbol": "2ba71b67-db72-4d22-a431-421f852caadb",
			"targetSymbol": "ed48ec5d-a3af-4ec9-99b5-decdaa749e1b",
			"object": "5c7c8944-3239-448f-9b50-6759facec636"
		},
		"02e17155-9f0e-4ef3-a5e7-063cee532c43": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 354,
			"y": 406,
			"width": 100,
			"height": 60,
			"object": "838d04ab-576c-4221-94a0-1a081c7fd564"
		},
		"739ba5b2-103c-4064-9656-caf9b3e858f3": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "404,436 404,509",
			"sourceSymbol": "02e17155-9f0e-4ef3-a5e7-063cee532c43",
			"targetSymbol": "3dd77514-5b56-4bbe-995f-ce875ce86169",
			"object": "a3349dc9-3f51-4722-af94-b5c076be0c2f"
		},
		"9145e63a-15ec-4952-827c-c39efffae1e6": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -910,
			"y": 612,
			"object": "b77b8193-43b4-43b2-8c7a-113c804fa906"
		},
		"2cfeb210-aab7-4db5-b6cc-873ab8334a8a": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-889,633 -889,777",
			"sourceSymbol": "9145e63a-15ec-4952-827c-c39efffae1e6",
			"targetSymbol": "94b99184-c273-4bfa-a504-6c7c2a26966b",
			"object": "8b8b3075-c0db-4b59-b420-eb37244af2c0"
		},
		"bbaa0dc8-f6dd-4390-9fdc-da8e213775aa": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-889,633 -1029,633 -1029,756",
			"sourceSymbol": "9145e63a-15ec-4952-827c-c39efffae1e6",
			"targetSymbol": "baaf4802-c270-4e22-bf68-11aa9a70cc24",
			"object": "581ee665-0b96-4981-b4a7-f66531eba313"
		},
		"baaf4802-c270-4e22-bf68-11aa9a70cc24": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -1082,
			"y": 726,
			"width": 100,
			"height": 60,
			"object": "791b12f7-5553-4f20-bf99-da491f7b35db"
		},
		"a876129b-0815-4751-bdc7-9186c5321a03": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1023,756 -1023,866 -895,866",
			"sourceSymbol": "baaf4802-c270-4e22-bf68-11aa9a70cc24",
			"targetSymbol": "8feadb9e-9c15-4f91-b058-d27176e52036",
			"object": "6ad1fe1a-4b51-4943-9a56-0b59fe9c543c"
		},
		"c9d78c30-20d9-418f-a688-d972baacc2f5": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1025,428.5 -1025,554 -938.5,554",
			"sourceSymbol": "9d6dfb1b-305b-4cd7-b0a1-f64fd6d4e2a6",
			"targetSymbol": "171e8fa5-92a4-473b-b5fc-e1a5b27c4362",
			"object": "27fa05bd-a7f2-45a6-833f-624d491e07f2"
		},
		"54348a65-ee18-4189-a7a0-0b42f6bf61c8": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 3045,
			"y": -478,
			"width": 100,
			"height": 60,
			"object": "14a0fe86-1d2a-4966-b335-741b6be5059e"
		},
		"ae7f8462-9ce9-459c-97c2-e423b167ae26": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "3095,-446 3213,-446",
			"sourceSymbol": "54348a65-ee18-4189-a7a0-0b42f6bf61c8",
			"targetSymbol": "ccb71dce-fddc-4892-9737-d7b811918998",
			"object": "3f75ac14-53d6-42a4-9715-1b74f63bb931"
		},
		"85643fbe-7260-4cb5-aee3-39f2104b4bed": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -3141,
			"y": 85,
			"width": 100,
			"height": 60,
			"object": "d4a748dc-7b7a-42a4-94ad-aeab5ff9b049"
		},
		"a30179d8-9214-460c-b10c-7a3bb660160f": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-3091,115 -2906,115",
			"sourceSymbol": "85643fbe-7260-4cb5-aee3-39f2104b4bed",
			"targetSymbol": "a5cff74a-0b74-446e-93cc-f0436f2c26f0",
			"object": "c386d94c-0df1-441f-82ac-f5b2e0f25099"
		},
		"cafd65c9-643a-48fe-89f3-87a208afb747": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -3291,
			"y": 85,
			"width": 100,
			"height": 60,
			"object": "364045a0-c6e7-4afc-94d4-82ec2f1d03c9"
		},
		"4fd53405-b26f-42a6-b518-3f2eefb9fe44": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-3241,115 -3091,115",
			"sourceSymbol": "cafd65c9-643a-48fe-89f3-87a208afb747",
			"targetSymbol": "85643fbe-7260-4cb5-aee3-39f2104b4bed",
			"object": "d4d8710b-449f-4585-94ef-a0523880bf17"
		},
		"3888a9b7-3535-449c-a325-cae4c9b1a548": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -191,
			"y": 229,
			"object": "f4be14cb-e3ee-40ee-89a4-bc7ec4ef4585"
		},
		"1d8c154b-3426-4d2e-a488-706667b0d880": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-170,252.5 -170,289.5 -110,289.5 -110,335.5",
			"sourceSymbol": "3888a9b7-3535-449c-a325-cae4c9b1a548",
			"targetSymbol": "7e2860b1-6f50-4aee-9c30-6e802a4175a5",
			"object": "254c8a19-c6c5-48ec-b6fd-a834ad4c4b4b"
		},
		"fd965f4d-e7ea-4637-b3d1-eb6d2f0b501f": {
			"classDefinition": "com.sap.bpm.wfs.ui.UserTaskSymbol",
			"x": 58,
			"y": -29,
			"width": 100,
			"height": 60,
			"object": "b7fe7321-8af8-4b59-8e14-50773a7d2406",
			"symbols": {
				"a07a81c0-e4c5-42e9-8ff7-d5ea37b6f271": {}
			}
		},
		"72481e90-5a48-4468-8e27-dfae740f0eb5": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-170,250 -170,178",
			"sourceSymbol": "3888a9b7-3535-449c-a325-cae4c9b1a548",
			"targetSymbol": "349239b9-5330-40f6-ac8b-7e8560cf0048",
			"object": "85827e2c-3fdf-4a2d-bead-fcbee8b326ab"
		},
		"08fb1454-a464-4ed6-9a6e-b09e6b6e8e86": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "157.5,1 209,1 209,102.5",
			"sourceSymbol": "fd965f4d-e7ea-4637-b3d1-eb6d2f0b501f",
			"targetSymbol": "79801fa1-cab8-4e92-80b8-506914da49c2",
			"object": "b912078e-831a-4aa6-8c00-900383d2ba6e"
		},
		"ab5c72be-c019-47d8-a3ae-a35a9b1c300b": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "31.75,353.75 31.75,373.375 46,373.375 46,423",
			"sourceSymbol": "8235f323-4756-495b-893a-2b5584e59c19",
			"targetSymbol": "623a6dd3-834c-407d-b62d-5a084913e2f2",
			"object": "7acb88cb-58a2-45c7-b6c1-7b025ec2f28e"
		},
		"a1dd697b-6fa0-4b96-babe-0c4999c6b111": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -2393,
			"y": 297,
			"width": 100,
			"height": 60,
			"object": "26a6e01b-1b1e-499a-854e-ccf5425cc013"
		},
		"4516b0b0-af2c-4803-962c-43c5c195795e": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-2343,327 -2343,220.75 -2364,220.75 -2364,115",
			"sourceSymbol": "a1dd697b-6fa0-4b96-babe-0c4999c6b111",
			"targetSymbol": "bd90d11c-983d-46cc-b438-749d98267604",
			"object": "d6974bcc-4712-441f-a548-bd1fb7fa4f53"
		},
		"d85b1965-70fa-4857-aae5-bb6b2d518e39": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": -245,
			"y": -59,
			"width": 100,
			"height": 60,
			"object": "0c3397ab-660e-4a01-be0d-e17c50fac2b0"
		},
		"1d555f2b-34cc-4126-a9cc-3169adc4cd55": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-110,339.875 -38.875,339.875 -38.875,305.875 31.75,305.875",
			"sourceSymbol": "7e2860b1-6f50-4aee-9c30-6e802a4175a5",
			"targetSymbol": "e7fc0df5-1f89-4e96-b6b5-7c39e046bf15",
			"object": "89984e21-7f8c-406e-be26-33f972d5de21"
		},
		"749449d2-021d-4b18-9e5f-0f79b87ee4c4": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-232.5,111.5 -211.25,111.5 -211.25,252.5 -190.5,252.5",
			"sourceSymbol": "9a4c92f5-20d9-4d36-abe5-971113fbf059",
			"targetSymbol": "3888a9b7-3535-449c-a325-cae4c9b1a548",
			"object": "0171a61e-5b11-464b-92bf-00ddd7961ed2"
		},
		"b52f1431-f643-4833-8746-300141968fd4": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": -54,
			"y": 199,
			"width": 100,
			"height": 46,
			"object": "df47c6db-fc0a-4195-b54e-582286587c3b"
		},
		"5a7c5c15-4cd5-4cea-b449-d488e5c2b9ff": {
			"classDefinition": "com.sap.bpm.wfs.ui.UserTaskSymbol",
			"x": 96,
			"y": 199,
			"width": 100,
			"height": 60,
			"object": "644f787d-b26c-4962-a09c-4dad807bc97c"
		},
		"1c9569e3-e506-4ab6-9dd3-d57d08187c26": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-20,225.5 96.5,225.5",
			"sourceSymbol": "b52f1431-f643-4833-8746-300141968fd4",
			"targetSymbol": "5a7c5c15-4cd5-4cea-b449-d488e5c2b9ff",
			"object": "1c16677c-031c-4a61-8921-a14082a99a9d"
		},
		"f2530fb4-4ef3-49ec-b456-37969b2642aa": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 70,
			"y": 64,
			"width": 100,
			"height": 60,
			"object": "9576a80b-3c74-4cd2-83cb-1db026b2955c"
		},
		"5d4d01f9-64e3-4190-ba2a-78ac5b98c538": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "143,237 143,161.25 123,161.25 123,94",
			"sourceSymbol": "5a7c5c15-4cd5-4cea-b449-d488e5c2b9ff",
			"targetSymbol": "f2530fb4-4ef3-49ec-b456-37969b2642aa",
			"object": "367f6933-543d-4bc9-89eb-b2139923fe1b"
		},
		"57566077-b623-4181-8b1d-7a71395f4b0a": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "120,94 180.25,94 180.25,123 190.5,123",
			"sourceSymbol": "f2530fb4-4ef3-49ec-b456-37969b2642aa",
			"targetSymbol": "79801fa1-cab8-4e92-80b8-506914da49c2",
			"object": "65342618-613e-405c-b073-18b951a82cb5"
		},
		"8fa9bd0f-67b9-4b43-b335-46cdc674e5de": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -60,
			"y": 15,
			"object": "dce010fe-7fea-40cf-bf0c-71b0fdbc065b"
		},
		"bd616d84-fea6-4cde-856c-a3c81f853daa": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-39,36 20,36 20,1 108,1",
			"sourceSymbol": "8fa9bd0f-67b9-4b43-b335-46cdc674e5de",
			"targetSymbol": "fd965f4d-e7ea-4637-b3d1-eb6d2f0b501f",
			"object": "8f71b6c3-9e86-4732-9033-1f1923376080"
		},
		"d2e6419a-34e5-4713-b3f8-1fb936cec3eb": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-39,36 -82,36 -82,255 104,255",
			"sourceSymbol": "8fa9bd0f-67b9-4b43-b335-46cdc674e5de",
			"targetSymbol": "5a7c5c15-4cd5-4cea-b449-d488e5c2b9ff",
			"object": "0ee9acb9-3c5e-4b8b-b809-ed7e7d492756"
		},
		"e48046f8-cd49-4e98-81ad-0ec5b10fcd63": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "5414,-430 5823.75,-430 5823.75,-439 6183.5,-439",
			"sourceSymbol": "f21c00e3-b2ef-4b03-850e-da21df6a9fe9",
			"targetSymbol": "78cbe836-7c06-45d3-905e-73e7dabb9a38",
			"object": "b835f668-ad15-4f1a-8b80-22b61f76b854"
		},
		"98db1bee-6b9a-438f-89aa-362013ed4d86": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -3430,
			"y": 85,
			"width": 100,
			"height": 60,
			"object": "c91eb81e-c617-472f-9da7-08e778091ec3"
		},
		"77d170f7-116d-489a-8dea-b7ac3d3a6834": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-3380,115 -3241,115",
			"sourceSymbol": "98db1bee-6b9a-438f-89aa-362013ed4d86",
			"targetSymbol": "cafd65c9-643a-48fe-89f3-87a208afb747",
			"object": "71ddd529-f7dd-4e4d-9f25-398ea612cc88"
		},
		"7b3f3085-dec5-43c9-99a5-18dc0c29b599": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -1451,
			"y": 85,
			"width": 100,
			"height": 60,
			"object": "6650cdb4-09e8-4a73-ae96-bedea01e4693"
		},
		"cef9ee46-1778-4deb-b87b-311034e58c92": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1401,114.5 -1299,114.5",
			"sourceSymbol": "7b3f3085-dec5-43c9-99a5-18dc0c29b599",
			"targetSymbol": "d9d65df8-894c-4780-851a-eecde4a4f09d",
			"object": "7ae673a4-bba8-4367-8c1e-efb5534038ee"
		},
		"f79645bf-1501-47c9-87e1-334e4a631dd9": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -1696,
			"y": 85,
			"width": 100,
			"height": 60,
			"object": "256073f1-1da8-4b77-8f03-f1038d4987f9"
		},
		"15dda7d5-2248-4dc5-a31c-54c96f038e0c": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1646,109 -1561.25,109 -1561.25,117 -1506,117",
			"sourceSymbol": "f79645bf-1501-47c9-87e1-334e4a631dd9",
			"targetSymbol": "3ea2efd7-d638-46a8-88af-84aa38ce50d7",
			"object": "5e9b142d-a945-42a4-b004-073712da66e7"
		},
		"3ea2efd7-d638-46a8-88af-84aa38ce50d7": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -1527,
			"y": 90,
			"object": "f1c40679-3ce3-4adc-a831-ad69100e2f9a"
		},
		"c39c41bf-b110-425c-9c22-7b720a112a7b": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1506,113 -1401,113",
			"sourceSymbol": "3ea2efd7-d638-46a8-88af-84aa38ce50d7",
			"targetSymbol": "7b3f3085-dec5-43c9-99a5-18dc0c29b599",
			"object": "f42fba9c-730e-4bfd-8a1a-63ff5ec991d4"
		},
		"d877c2ff-65a7-4304-98d2-bce475314b72": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1506,90.5 -1506,12 -1299,12 -1299,103",
			"sourceSymbol": "3ea2efd7-d638-46a8-88af-84aa38ce50d7",
			"targetSymbol": "d9d65df8-894c-4780-851a-eecde4a4f09d",
			"object": "8d8a1e14-6bbb-4096-a559-9df3df7bb857"
		},
		"e03a4f62-89e4-4056-ac05-dbde495cf23f": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -945,
			"y": 1030,
			"width": 100,
			"height": 60,
			"object": "4c031674-0350-4056-988f-30a547a88f59"
		},
		"d9d612e3-6f0c-4f2b-b264-950bb5ce73e9": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-895,1060 -895,1173",
			"sourceSymbol": "e03a4f62-89e4-4056-ac05-dbde495cf23f",
			"targetSymbol": "ff3b4afb-3adf-41e7-a14a-663eb9a4185c",
			"object": "64b7882e-e829-430c-be5a-11bc40a302c0"
		},
		"74cb00fd-d2f0-4072-be13-b66300bf4446": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 6374,
			"y": -162,
			"width": 100,
			"height": 60,
			"object": "254fe491-2ef3-44e4-8b0a-77f4f99b190d"
		},
		"385ab0ca-5f57-4db4-8b49-232722080f0d": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "6424,-132 6424,-21 6324,-21",
			"sourceSymbol": "74cb00fd-d2f0-4072-be13-b66300bf4446",
			"targetSymbol": "34f093c8-7a03-46b6-9f58-92d0c848c917",
			"object": "1357c6b2-d880-4bf8-8abe-aafea3f5de05"
		},
		"43e1bd17-2487-4a7b-a769-9f6ac9c6b374": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -54,
			"y": 69,
			"width": 100,
			"height": 50,
			"object": "5062881a-cb6f-4ed0-90d2-490f02801e8b"
		},
		"0059b1f1-4e9b-4a18-a3b9-b48db2fef97f": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-4,94 -4,128.25 5,128.25 5,158",
			"sourceSymbol": "43e1bd17-2487-4a7b-a769-9f6ac9c6b374",
			"targetSymbol": "e0ccfa44-f4b9-4a3b-8222-cf914c277316",
			"object": "e99d9e75-52e0-43f2-b3f9-4e1c6dbd00db"
		},
		"623a6dd3-834c-407d-b62d-5a084913e2f2": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -4,
			"y": 393,
			"width": 100,
			"height": 60,
			"object": "689fa697-0d89-4c8a-b038-811933578504"
		},
		"2490bdd7-756d-4ae0-8441-33d090347b38": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "46,423 46,535",
			"sourceSymbol": "623a6dd3-834c-407d-b62d-5a084913e2f2",
			"targetSymbol": "f22441c0-6710-410e-b8d6-b7087b6d1289",
			"object": "c73e5d37-9315-45b4-a68e-ccfe62e311f3"
		},
		"03736adf-11d0-4556-9668-a92d84279781": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 518,
			"y": 856,
			"width": 100,
			"height": 60,
			"object": "ba9fca6d-ac19-4573-8b8f-42d4e9ec6a1b"
		},
		"14927b3d-2c59-4020-9047-37f3afb9b112": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "581,886 581,958 59,958 59,1048",
			"sourceSymbol": "03736adf-11d0-4556-9668-a92d84279781",
			"targetSymbol": "43db4445-f24a-447d-af48-cf63cfc5f4b6",
			"object": "665287f4-59e9-432c-ba87-38af8b88f3c9"
		},
		"ca8458b4-3c66-4497-820c-6c24ec97150e": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "108,47 108,58 -4,58 -4,94",
			"sourceSymbol": "a07a81c0-e4c5-42e9-8ff7-d5ea37b6f271",
			"targetSymbol": "43e1bd17-2487-4a7b-a769-9f6ac9c6b374",
			"object": "f61420f5-8e5f-4895-8999-de8a2498dc26"
		},
		"f8040caa-1aa3-4382-bc3f-0aa8d96aad57": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "54,872 54,886 568,886",
			"sourceSymbol": "61b93211-8d17-4109-9dd8-2657acf9b417",
			"targetSymbol": "03736adf-11d0-4556-9668-a92d84279781",
			"object": "e08d2891-83d8-4f46-b797-e84b68f63538"
		},
		"a5cff74a-0b74-446e-93cc-f0436f2c26f0": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -2956,
			"y": 85,
			"width": 100,
			"height": 60,
			"object": "4e0b6f65-a8e8-4277-bad0-646c7a1015cf"
		},
		"3425df6d-5e25-49b4-b6d9-984872505c17": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-2906,117 -2744,117",
			"sourceSymbol": "a5cff74a-0b74-446e-93cc-f0436f2c26f0",
			"targetSymbol": "873bde12-20a0-4fb2-87f5-40efafd221e6",
			"object": "7d0f4538-6183-41dc-8555-9f153fbee9ee"
		},
		"3dd77514-5b56-4bbe-995f-ce875ce86169": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 354,
			"y": 479,
			"width": 100,
			"height": 60,
			"object": "eed87f50-5ffa-451a-8ebd-d258a2a883a7"
		},
		"acbaf306-e127-43ac-b0e7-c19072c134cb": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "404,509 404,585",
			"sourceSymbol": "3dd77514-5b56-4bbe-995f-ce875ce86169",
			"targetSymbol": "faf87618-214d-4336-8526-df3b80d1cda4",
			"object": "c4027015-c438-479e-97f3-accc635e5711"
		},
		"faf87618-214d-4336-8526-df3b80d1cda4": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 354,
			"y": 555,
			"width": 100,
			"height": 60,
			"object": "1761e0a8-2a2c-4580-ba6e-e239da8cdc9a"
		},
		"58956c4e-ca11-412a-b761-b434a00f54fe": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "403,585 403,659",
			"sourceSymbol": "faf87618-214d-4336-8526-df3b80d1cda4",
			"targetSymbol": "2ba71b67-db72-4d22-a431-421f852caadb",
			"object": "768100d8-d481-4919-81bc-c384e2e77e3f"
		},
		"92018014-8c66-4a67-bbc0-a61d8b598196": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": -1433,
			"y": 628,
			"width": 100,
			"height": 60,
			"object": "49ceda69-aeb0-4377-bb38-9f7b75d6deda"
		},
		"b001d6f8-61a5-420b-bb52-599abfb9b183": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1383,658 -1298,658 -1298,575",
			"sourceSymbol": "92018014-8c66-4a67-bbc0-a61d8b598196",
			"targetSymbol": "4e2480c2-0ab3-4fe8-b196-e1ec91b66df3",
			"object": "a2d6d864-339b-4867-9d1e-0adb53e630a2"
		},
		"61b1be29-a1f2-4b7f-9a76-e06fe4d448d9": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -1817,
			"y": 482,
			"object": "0962e38d-f08a-4e79-bf07-0f5dfd82e983"
		},
		"d1ef8548-e447-426e-9069-353f2e9e3650": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1794.5,503 -1794.5,611",
			"sourceSymbol": "61b1be29-a1f2-4b7f-9a76-e06fe4d448d9",
			"targetSymbol": "1365748b-5e08-4545-8c00-d8391c463001",
			"object": "34dddbcf-b9b5-41dc-8823-068ce4d5bd5f"
		},
		"18fa87af-2c4b-4b55-9c24-7497e2a7e634": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1796,502.5 -1301.5,502.5 -1301.5,575",
			"sourceSymbol": "61b1be29-a1f2-4b7f-9a76-e06fe4d448d9",
			"targetSymbol": "4e2480c2-0ab3-4fe8-b196-e1ec91b66df3",
			"object": "30498ce2-4056-4ce4-96e1-6b360a1994e4"
		},
		"e2734640-32b4-420c-9acb-fa70fac853e9": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 518,
			"y": 204,
			"object": "61e68c5b-b834-4d67-bd92-85b4c078fdeb"
		},
		"133c3981-0d1d-4c58-97f7-6df3f1599ba4": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "540,225 540,341 569,341",
			"sourceSymbol": "e2734640-32b4-420c-9acb-fa70fac853e9",
			"targetSymbol": "df424ed1-9d9e-4d10-afcd-fe422bf305c3",
			"object": "82ea66a9-8c66-4f4b-a6a5-b92e0fe1d1eb"
		},
		"d2122e52-dd83-4b16-a6f2-3252f20eb093": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "542,220 601,220 601,158 692,158",
			"sourceSymbol": "e2734640-32b4-420c-9acb-fa70fac853e9",
			"targetSymbol": "8cc1cb9d-c76d-4f57-98d7-2bf5dfb3d6a9",
			"object": "caac9569-57be-47db-8c24-ff8e2c603209"
		},
		"8cc1cb9d-c76d-4f57-98d7-2bf5dfb3d6a9": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": 642,
			"y": 132,
			"width": 100,
			"height": 60,
			"object": "164ff510-3ccd-463d-a0f7-6820d5bff0dd"
		},
		"ac8d228e-4428-4e34-95dd-97325024b3c6": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "692,162 750.25,162 750.25,225 779,225",
			"sourceSymbol": "8cc1cb9d-c76d-4f57-98d7-2bf5dfb3d6a9",
			"targetSymbol": "6d2722e7-d064-4781-8e80-5f52c4e10ff8",
			"object": "d843345a-e732-4dec-bf08-ff96b41fad57"
		},
		"ef5167e5-9895-42e4-a841-5d44f24f9dff": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 109,
			"y": -297,
			"object": "58e19ac0-7b08-4243-80ae-b02fd1c8b018"
		},
		"aede55ed-5969-481a-a089-d520922a9abd": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": -240,
			"y": -297,
			"width": 100,
			"height": 60,
			"object": "6aa491a3-33f5-428c-82f2-4c911cc1a087"
		},
		"d0503980-58a4-4bef-9730-f4ba20d9189d": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "130,-273 -206,-273",
			"sourceSymbol": "ef5167e5-9895-42e4-a841-5d44f24f9dff",
			"targetSymbol": "aede55ed-5969-481a-a089-d520922a9abd",
			"object": "7acfecc6-d7af-49db-b8dd-dedbe7bc9b9a"
		},
		"f8db9202-47ac-49e9-b440-fd5e4da9032b": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "133,-276 133,-122 -74,-122",
			"sourceSymbol": "ef5167e5-9895-42e4-a841-5d44f24f9dff",
			"targetSymbol": "728a1971-46f6-4a43-a979-29fc4405f3c5",
			"object": "02d34c31-0507-4cf8-9ed7-b17a2338fa34"
		},
		"3d037c4c-877e-49e8-a2e2-f379409bafaf": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-189,-264 -790,-264 -790,-119",
			"sourceSymbol": "aede55ed-5969-481a-a089-d520922a9abd",
			"targetSymbol": "103721ef-5a92-424c-ab80-e00e9093d0be",
			"object": "1c9dad2e-5635-4fee-856c-2c874b7b279c"
		},
		"7a178339-588d-49d5-ada1-1e4ccdad29f6": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1056,-433 133,-433 133,-266",
			"sourceSymbol": "cf10fba9-92cc-4115-a7bd-8b0097b0e268",
			"targetSymbol": "ef5167e5-9895-42e4-a841-5d44f24f9dff",
			"object": "0ca8ee77-ffaf-4175-bbea-df88657b35e0"
		},
		"32908a03-7617-4289-9810-e2182f4a99c0": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": 3625,
			"y": -581,
			"width": 100,
			"height": 60,
			"object": "f39b3834-3b10-49fa-9e9e-8712a79017d7"
		},
		"841ed19d-6ca3-4da9-a306-ff413978db1d": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 3576,
			"y": -469,
			"object": "db552930-7437-4f8f-9056-3a37b194590d"
		},
		"d06eec50-2ee1-487a-9aa6-5f3fe69ca611": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "3596.5,-448 3596.5,-321",
			"sourceSymbol": "841ed19d-6ca3-4da9-a306-ff413978db1d",
			"targetSymbol": "3887c4ea-17d9-4bf3-a91c-416eeff91243",
			"object": "8042c00a-02ac-4882-846f-9b10f3eba07d"
		},
		"bdaa6d71-84f5-4fc2-a883-6a68229a8fae": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "3597,-469 3597,-551 3675,-551",
			"sourceSymbol": "841ed19d-6ca3-4da9-a306-ff413978db1d",
			"targetSymbol": "32908a03-7617-4289-9810-e2182f4a99c0",
			"object": "37f1e805-4ec6-4a21-be72-bb1768430f12"
		},
		"7f751e4d-6391-4f7e-b47c-17d2fa7676cc": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "3675,-545 3762.25,-545 3762.25,-446 3810,-446",
			"sourceSymbol": "32908a03-7617-4289-9810-e2182f4a99c0",
			"targetSymbol": "468dd65c-26b8-47e6-b0ba-157490f3b2b2",
			"object": "ce31d71c-1d0c-4f0d-b8a4-1cd44762469f"
		},
		"b7c9bd36-b35f-49f7-81a8-7ace1b4f8157": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": 3827,
			"y": -254,
			"width": 100,
			"height": 60,
			"object": "0e75953e-aa04-40f1-83f3-ce7f382926a5"
		},
		"f37773b8-7bd6-4db7-b677-f334285959ad": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "3877,-224 3993,-224",
			"sourceSymbol": "b7c9bd36-b35f-49f7-81a8-7ace1b4f8157",
			"targetSymbol": "67a77b1e-6acb-47df-9360-3d98648f6292",
			"object": "35c2a2ff-ba31-40df-9210-bdeacbce327d"
		},
		"49eeab01-2101-4d4d-b090-d9d3526d29b1": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -498,
			"y": 135,
			"object": "5cd8cdad-b206-47fa-9a69-d5a148329397"
		},
		"e066526b-87b9-4f23-8d7f-d0bfc01ed767": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-477,156 -477,213.5 -469,213.5 -469,271",
			"sourceSymbol": "49eeab01-2101-4d4d-b090-d9d3526d29b1",
			"targetSymbol": "9e9f79f1-c0be-42b9-ab70-2bda04a87757",
			"object": "3e3e4ddd-69fb-4c5d-a5d5-0d32ef13f11e"
		},
		"441a9e75-03d1-4fc4-992a-7374b22f6a37": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": -498,
			"y": 34,
			"width": 100,
			"height": 60,
			"object": "b46ffe03-6e9e-443f-911b-e8e8f01c2d31"
		},
		"0a165d54-7c92-4d42-bcfc-5f8043744719": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-477,156 -477,114.5 -451,114.5 -451,55",
			"sourceSymbol": "49eeab01-2101-4d4d-b090-d9d3526d29b1",
			"targetSymbol": "441a9e75-03d1-4fc4-992a-7374b22f6a37",
			"object": "7e350b76-f56b-4cd9-85fd-32e05b782f36"
		},
		"551917d5-bd40-4f30-9f95-55fca43bbba5": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-460,65 -364.75,65 -364.75,116 -288,116",
			"sourceSymbol": "441a9e75-03d1-4fc4-992a-7374b22f6a37",
			"targetSymbol": "9a4c92f5-20d9-4d36-abe5-971113fbf059",
			"object": "632e0cca-a529-4e1c-b2cf-20f3c86d795f"
		},
		"08f6cd37-7b66-4ef9-91ee-59cc76ad734f": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 799,
			"y": -374,
			"width": 100,
			"height": 60,
			"object": "cebf1053-229e-4ba3-a75f-ebae890a536a"
		},
		"e5c036fd-c784-45f0-a92f-6ca4ecefd4e4": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "849,-344 979,-344",
			"sourceSymbol": "08f6cd37-7b66-4ef9-91ee-59cc76ad734f",
			"targetSymbol": "50e4d209-3ff1-46f0-a9b3-832f270ef38c",
			"object": "4e8a9a04-dc3b-467e-bc80-70ed030fb5a6"
		},
		"df424ed1-9d9e-4d10-afcd-fe422bf305c3": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 568,
			"y": 310,
			"width": 100,
			"height": 60,
			"object": "2edba57b-3b16-4bb3-8a87-65c324f5ccc6"
		},
		"21dee0d2-2916-4ee8-b8c3-c8ea5a3023a1": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "618,340 746,340",
			"sourceSymbol": "df424ed1-9d9e-4d10-afcd-fe422bf305c3",
			"targetSymbol": "acd0c922-8b55-42ff-9d8a-f55469550929",
			"object": "59da0ed4-53aa-4f78-abc8-1e191ef991d1"
		},
		"5c52d157-2c8f-444d-940a-c75ce8e68250": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 3962,
			"y": -464,
			"object": "82b83e36-bb6a-490a-b97a-248c6121c9f5"
		},
		"c7edafca-fd6e-49b2-84ba-8663d8d6f9f4": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "3983,-443 4070,-443",
			"sourceSymbol": "5c52d157-2c8f-444d-940a-c75ce8e68250",
			"targetSymbol": "5ace9704-3e72-456a-a46f-82c9d2f29c2e",
			"object": "9a719e3a-4b4e-47c3-9d20-dd818a05fa36"
		},
		"3b2a9e5e-2834-4259-8402-f7380602223f": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "3983,-443 3983,-514 4592,-514 4592,-443",
			"sourceSymbol": "5c52d157-2c8f-444d-940a-c75ce8e68250",
			"targetSymbol": "3ba0aa03-c964-4c25-b74d-87e1b7adecbf",
			"object": "d70da814-e8af-4a63-aaa8-7aa8cd89329a"
		},
		"a9d43fab-8ac7-4d0f-9b76-a23b3de1ff31": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": 4445,
			"y": -473,
			"width": 100,
			"height": 60,
			"object": "894232bf-957c-4e96-9bff-7b029be4391b"
		},
		"55846249-4335-4c2a-8455-35dfc9765340": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "4495,-441 4593,-441",
			"sourceSymbol": "a9d43fab-8ac7-4d0f-9b76-a23b3de1ff31",
			"targetSymbol": "3ba0aa03-c964-4c25-b74d-87e1b7adecbf",
			"object": "ebab49e6-386a-4308-a721-c2364b004304"
		},
		"62e54757-5905-42c9-a59d-c68a56ba6c5f": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 1823,
			"y": -458,
			"object": "37d6cb53-75f5-41ba-a49c-9c783cc7a31a"
		},
		"a49ccabf-f9b0-43f4-9d24-0669e47a5f8c": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1844,-437 2104,-437 2104,-446 2364,-446",
			"sourceSymbol": "62e54757-5905-42c9-a59d-c68a56ba6c5f",
			"targetSymbol": "16b11f81-e13c-4a9c-8d87-8d0c61e9f321",
			"object": "4bd665ed-407c-4621-99b2-7af671158353"
		},
		"b54db3f9-d38d-4b83-addf-e24947aae002": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 2058,
			"y": -393,
			"width": 100,
			"height": 60,
			"object": "b80468b1-0eec-4cd2-b814-5f0b68305fe1"
		},
		"6ba64dd6-bec6-4c30-824c-cbde159d4fb9": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1842,-423 1842,-370 2061,-370",
			"sourceSymbol": "62e54757-5905-42c9-a59d-c68a56ba6c5f",
			"targetSymbol": "b54db3f9-d38d-4b83-addf-e24947aae002",
			"object": "29ddfff3-14ff-411e-a0da-d8c1e9a45f73"
		},
		"fc3c54be-e85c-472d-8532-1b5e00b25096": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "2157.5,-363 2366,-363 2366,-433",
			"sourceSymbol": "b54db3f9-d38d-4b83-addf-e24947aae002",
			"targetSymbol": "16b11f81-e13c-4a9c-8d87-8d0c61e9f321",
			"object": "34e41670-0063-4599-b99b-81251884edac"
		},
		"8da1f857-8c7f-4cdb-8e54-06275ecda30a": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 2896,
			"y": -478,
			"object": "c4d2b059-6975-4dd7-aae8-b5bf03d80d5a"
		},
		"24d6ea83-d84c-409c-be85-a7f011fe55e4": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "2912,-461.5 2991.5,-461.5 2991.5,-451.5 3095,-451.5",
			"sourceSymbol": "8da1f857-8c7f-4cdb-8e54-06275ecda30a",
			"targetSymbol": "54348a65-ee18-4189-a7a0-0b42f6bf61c8",
			"object": "139012bb-af50-4732-a899-04f6dcee5cc3"
		},
		"7871179c-7000-42c4-a56c-54b050927d44": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "2917,-457 2917,-546 3206,-546 3206,-448",
			"sourceSymbol": "8da1f857-8c7f-4cdb-8e54-06275ecda30a",
			"targetSymbol": "ccb71dce-fddc-4892-9737-d7b811918998",
			"object": "5a69f96e-36f6-4618-a44a-43cb2add3a32"
		},
		"60237e2f-5886-4d68-b0f7-4e8b774aa675": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -795,
			"y": 981,
			"width": 100,
			"height": 60,
			"object": "29b0a44f-4005-48a5-8de9-41a4315e46b8"
		},
		"9fca1dcf-92cc-4f8f-be83-a338196b369d": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-745,1011 -745,919",
			"sourceSymbol": "60237e2f-5886-4d68-b0f7-4e8b774aa675",
			"targetSymbol": "b9f8d773-3e0a-4d02-8505-2391fcf3c388",
			"object": "737059f1-bb71-45fa-9ceb-56da13ca09a1"
		},
		"b9f8d773-3e0a-4d02-8505-2391fcf3c388": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -795,
			"y": 889,
			"width": 100,
			"height": 60,
			"object": "873a3e95-1481-4253-946d-dec2435b5e5e"
		},
		"be1f513f-ae43-42cd-838a-0303927ecf9e": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-745,919 -745,816",
			"sourceSymbol": "b9f8d773-3e0a-4d02-8505-2391fcf3c388",
			"targetSymbol": "0723ae60-12b6-472a-8b71-249c48f0b316",
			"object": "8eb2275a-90e5-44b6-8e97-1eb50668583e"
		},
		"0723ae60-12b6-472a-8b71-249c48f0b316": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -795,
			"y": 786,
			"width": 100,
			"height": 60,
			"object": "d7519588-4503-490f-8c6b-2824c558ff2e"
		},
		"d0a1d687-b9a3-40d9-a6b3-afc1edfb2e0a": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-745,816 -745,109 -569,109",
			"sourceSymbol": "0723ae60-12b6-472a-8b71-249c48f0b316",
			"targetSymbol": "d56f87ee-5e54-4842-872c-0dc7e548e4a8",
			"object": "331266c9-f582-4c70-b39a-afa20d6a957f"
		},
		"0de46006-bff1-4d24-b755-8d0ac78533e7": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -266,
			"y": 840,
			"width": 100,
			"height": 60,
			"object": "b19f799c-827d-4efa-88e2-a17f7678dfb8"
		},
		"fdb9d9b1-1a9e-47f2-a9aa-8eb892473ab8": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-216,870 -216,765",
			"sourceSymbol": "0de46006-bff1-4d24-b755-8d0ac78533e7",
			"targetSymbol": "0578e208-82c2-45a7-b857-6ca5b45ae17d",
			"object": "e7590ffb-5f9e-405e-a2ad-e8ed5f3a9e15"
		},
		"0578e208-82c2-45a7-b857-6ca5b45ae17d": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -266,
			"y": 735,
			"width": 100,
			"height": 60,
			"object": "c2f6848b-b53f-48d6-9a1b-c4fe07641521"
		},
		"d5413ef6-da9e-43d8-ae69-a80062b119af": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-216,765 -216,675",
			"sourceSymbol": "0578e208-82c2-45a7-b857-6ca5b45ae17d",
			"targetSymbol": "b015ef5f-fc16-4534-9629-deac3979462f",
			"object": "1d9457a7-4513-40e3-a852-07693c287086"
		},
		"b015ef5f-fc16-4534-9629-deac3979462f": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -266,
			"y": 645,
			"width": 100,
			"height": 60,
			"object": "cbe4be68-f965-4841-bdef-c35716ac6c09"
		},
		"6db98fcb-fad7-43f1-abf9-fca76d7cd0e3": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-216,675 -216,595",
			"sourceSymbol": "b015ef5f-fc16-4534-9629-deac3979462f",
			"targetSymbol": "891b6d68-eec7-47a8-95ab-955e88576ad3",
			"object": "a7e519ea-06df-433e-b265-0944ea4c572c"
		},
		"728a1971-46f6-4a43-a979-29fc4405f3c5": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -124,
			"y": -152,
			"width": 100,
			"height": 60,
			"object": "dab92ecd-01ed-4792-a03a-4dd389cf16e1"
		},
		"852b5e99-992d-4b66-93c3-8954b069bba9": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-74,-122 -207,-122",
			"sourceSymbol": "728a1971-46f6-4a43-a979-29fc4405f3c5",
			"targetSymbol": "506ca5f8-b7d1-45ba-9d78-8127e7d52f40",
			"object": "139d6bcd-e3e7-432e-af92-d9987bade40b"
		},
		"506ca5f8-b7d1-45ba-9d78-8127e7d52f40": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -257,
			"y": -152,
			"width": 100,
			"height": 60,
			"object": "67f9522c-2fa9-4e5b-9eab-36406162541e"
		},
		"c85b5838-8e1b-47d0-8e08-f1b7b026582e": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-207,-120.5 -392,-120.5",
			"sourceSymbol": "506ca5f8-b7d1-45ba-9d78-8127e7d52f40",
			"targetSymbol": "f1ed94e4-94e5-4a7a-aef0-d6cf04d6a822",
			"object": "9790ef71-abfc-4466-99b5-7787e4a44ee5"
		},
		"f1ed94e4-94e5-4a7a-aef0-d6cf04d6a822": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -442,
			"y": -149,
			"width": 100,
			"height": 60,
			"object": "dcb51126-0d0e-4846-9e4a-abfd8999ebfa"
		},
		"bea46baf-264b-4c1f-ae49-5517b3b15a46": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-392,-119 -530,-119",
			"sourceSymbol": "f1ed94e4-94e5-4a7a-aef0-d6cf04d6a822",
			"targetSymbol": "59c4c290-c264-4b50-973c-e7162dbb0dd3",
			"object": "254e45f8-4375-4f04-9181-afbfa83439c7"
		},
		"3887c4ea-17d9-4bf3-a91c-416eeff91243": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 3542,
			"y": -351,
			"width": 100,
			"height": 60,
			"object": "fea4d57a-0882-412f-891f-b7c6b15ae174"
		},
		"98ddb0b6-caf7-4237-aa67-e1c524f13b42": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "3600,-321 3600,-272.25 3626,-272.25 3626,-212",
			"sourceSymbol": "3887c4ea-17d9-4bf3-a91c-416eeff91243",
			"targetSymbol": "4c5f0488-a9a1-4cd0-8da1-7a9416b05f99",
			"object": "10ff8aa6-d387-4b52-a6fa-7dc71ae00203"
		},
		"4c5f0488-a9a1-4cd0-8da1-7a9416b05f99": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 3576,
			"y": -254,
			"width": 100,
			"height": 60,
			"object": "57ccb261-0689-431d-9ab3-0bda27e02dae"
		},
		"47269bc9-ecee-462c-85e3-b32efa1609ba": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "3626,-224 3732,-224",
			"sourceSymbol": "4c5f0488-a9a1-4cd0-8da1-7a9416b05f99",
			"targetSymbol": "e8c92712-7777-4912-8ccc-c47aeb286d5f",
			"object": "d8c39022-9a9e-4444-babb-e04ce1fbd08c"
		},
		"5ace9704-3e72-456a-a46f-82c9d2f29c2e": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 4020,
			"y": -473,
			"width": 100,
			"height": 60,
			"object": "30a7f6e6-bb09-4cdd-bc98-0f26bfc4c4b3"
		},
		"4fda1d81-72e9-41b1-98b8-0143d70afb4d": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "4070,-443 4183,-443",
			"sourceSymbol": "5ace9704-3e72-456a-a46f-82c9d2f29c2e",
			"targetSymbol": "9a2dce04-8542-465c-8d7d-a7b9d197a2fa",
			"object": "e24ea8e0-e501-4390-a80f-39ed7ad60844"
		},
		"9a2dce04-8542-465c-8d7d-a7b9d197a2fa": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 4133,
			"y": -473,
			"width": 100,
			"height": 60,
			"object": "de105fa5-c4a1-4579-8dc3-1d7de4ba9288"
		},
		"ca1d97dc-794c-45eb-a3fa-07ee09dcb382": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "4183,-447.5 4308,-447.5",
			"sourceSymbol": "9a2dce04-8542-465c-8d7d-a7b9d197a2fa",
			"targetSymbol": "0bebc4ba-9728-4c50-a9ac-c74d7a9170a0",
			"object": "5f2c758f-f63b-4525-82c7-8b695b1c0732"
		},
		"0bebc4ba-9728-4c50-a9ac-c74d7a9170a0": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 4258,
			"y": -482,
			"width": 100,
			"height": 60,
			"object": "53047d61-27f0-4197-bb50-1e3f021c657a"
		},
		"77130385-7528-4001-8f8d-93c3ef2fd1f9": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "4308,-452 4403,-452",
			"sourceSymbol": "0bebc4ba-9728-4c50-a9ac-c74d7a9170a0",
			"targetSymbol": "d0c5a1ee-0a3f-4afd-8c09-e5027577ad70",
			"object": "06abd4d1-7afa-435d-a01c-7be5656bcfeb"
		},
		"acd0c922-8b55-42ff-9d8a-f55469550929": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 696,
			"y": 310,
			"width": 100,
			"height": 60,
			"object": "e96d3276-d4b5-4a0d-b0e7-d26d9c3ef2d4"
		},
		"f902178d-a1b3-4862-826b-6e2ddce959e3": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "746,340 869,340",
			"sourceSymbol": "acd0c922-8b55-42ff-9d8a-f55469550929",
			"targetSymbol": "c37e0645-c8c3-4d02-958f-ac7e5cf2108e",
			"object": "289cca64-0c9e-495a-9ef6-74c48a2a4806"
		},
		"c37e0645-c8c3-4d02-958f-ac7e5cf2108e": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 819,
			"y": 310,
			"width": 100,
			"height": 60,
			"object": "b08f281a-cf6e-4d5d-b659-6716a1830378"
		},
		"d6511c14-79c0-4c67-ba83-04e5f410d364": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "869,340 1008,340",
			"sourceSymbol": "c37e0645-c8c3-4d02-958f-ac7e5cf2108e",
			"targetSymbol": "9b0c6168-c85a-4d68-9254-d0181d673574",
			"object": "98a897ec-86e6-419f-978d-19ee6e429257"
		},
		"9b0c6168-c85a-4d68-9254-d0181d673574": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 958,
			"y": 310,
			"width": 100,
			"height": 60,
			"object": "3e19ecbd-1340-465c-8976-82efa862cfe8"
		},
		"db761406-8775-4020-9da0-51201491c5ca": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1008,340 1115,340",
			"sourceSymbol": "9b0c6168-c85a-4d68-9254-d0181d673574",
			"targetSymbol": "79d130a1-1524-41fa-aec4-443fd1d75247",
			"object": "cbf3a6c6-9fc8-48b8-b70c-b126b7a7b8bf"
		},
		"67a77b1e-6acb-47df-9360-3d98648f6292": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 3943,
			"y": -254,
			"width": 100,
			"height": 60,
			"object": "6a0c923c-5bf1-4ace-be3c-26e0c029a0ef"
		},
		"5ee26c9b-3dde-4b3e-b54b-02d1f637e793": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "3993,-222.5 4154,-222.5",
			"sourceSymbol": "67a77b1e-6acb-47df-9360-3d98648f6292",
			"targetSymbol": "670a878a-fae3-4282-9836-f8417f92cd5d",
			"object": "9867138c-d426-41ca-baf3-78cf58c98725"
		},
		"670a878a-fae3-4282-9836-f8417f92cd5d": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 4104,
			"y": -254,
			"width": 100,
			"height": 60,
			"object": "fb3b491e-00c5-46f0-bd63-8be142ff9afb"
		},
		"07139315-6c37-49a8-a918-f1bff5748cd8": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "4154,-224 4247,-224 4247,-366 4154,-366",
			"sourceSymbol": "670a878a-fae3-4282-9836-f8417f92cd5d",
			"targetSymbol": "042addef-e08a-40cc-8ba6-501d488e734a",
			"object": "36b25802-a4e9-46b3-bf4c-724424a85990"
		},
		"67d463f2-2b8b-433e-bfe4-e7e91e2dc87b": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": 3983,
			"y": -396,
			"width": 100,
			"height": 60,
			"object": "27736dd6-1b84-467b-8286-9ba3b99c2d95"
		},
		"59707c4f-c9aa-4aac-819c-6bdd6ed15aba": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "4033,-364.5 3948,-364.5",
			"sourceSymbol": "67d463f2-2b8b-433e-bfe4-e7e91e2dc87b",
			"targetSymbol": "1651eff1-88bd-40ac-a46a-ff8f5d8e9fde",
			"object": "05834487-26f0-48af-9ab7-ff1fe9de6fe1"
		},
		"1651eff1-88bd-40ac-a46a-ff8f5d8e9fde": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 3927,
			"y": -387,
			"object": "a13be89b-e4fc-432a-b14e-605cd21a47c9"
		},
		"46667c02-7853-4dcc-af85-188a988d05c2": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "3948,-366 3884,-366 3884,-444 3828,-444",
			"sourceSymbol": "1651eff1-88bd-40ac-a46a-ff8f5d8e9fde",
			"targetSymbol": "468dd65c-26b8-47e6-b0ba-157490f3b2b2",
			"object": "496fae2a-0f83-448c-9101-ff234eeaa32b"
		},
		"042addef-e08a-40cc-8ba6-501d488e734a": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 4133,
			"y": -387,
			"object": "04c2516e-f970-4c59-abba-d57b4e78a3fc"
		},
		"b4a2e539-4800-40a8-bcfd-ee88aa0b3dc9": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "4154,-366 4033,-366",
			"sourceSymbol": "042addef-e08a-40cc-8ba6-501d488e734a",
			"targetSymbol": "67d463f2-2b8b-433e-bfe4-e7e91e2dc87b",
			"object": "a2172b45-2f6f-4b29-bca4-54943585f156"
		},
		"5594a598-73a5-44be-ac8c-2113b3fb06d5": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "4154,-345.5 4154,-295 3948,-295 3948,-345.5",
			"sourceSymbol": "042addef-e08a-40cc-8ba6-501d488e734a",
			"targetSymbol": "1651eff1-88bd-40ac-a46a-ff8f5d8e9fde",
			"object": "83f51d6f-26be-450a-96fd-8076045b8195"
		},
		"1365748b-5e08-4545-8c00-d8391c463001": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -1846,
			"y": 575,
			"width": 100,
			"height": 60,
			"object": "0a34cbbb-0781-423a-a550-c0900b8f51c2"
		},
		"cbc34bec-ab71-4442-b697-c448f03ba4c3": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1796,605 -1796,659 -1678,659",
			"sourceSymbol": "1365748b-5e08-4545-8c00-d8391c463001",
			"targetSymbol": "0971dc07-ebe7-49da-86fe-bfcb757c1cd6",
			"object": "e6de11d8-0f55-4fd9-b9bd-c8f228050d7d"
		},
		"0971dc07-ebe7-49da-86fe-bfcb757c1cd6": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -1728,
			"y": 628,
			"width": 100,
			"height": 60,
			"object": "5623d2f2-5e02-49f3-a96b-bcf58d76c3d4"
		},
		"660834bd-6b89-4a6f-8b34-dee9e0236e6e": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1678,658 -1553,658",
			"sourceSymbol": "0971dc07-ebe7-49da-86fe-bfcb757c1cd6",
			"targetSymbol": "e91caad3-33aa-447e-bd1c-e8f4da6fc1aa",
			"object": "08ab5f9e-fa04-4ca8-842e-34dddba41756"
		},
		"e91caad3-33aa-447e-bd1c-e8f4da6fc1aa": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -1603,
			"y": 628,
			"width": 100,
			"height": 60,
			"object": "e16d155c-2186-46c1-b37c-6d342092c68f"
		},
		"d3e84c2b-2e66-4ced-abce-2042b4f043aa": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1553,658 -1469,658",
			"sourceSymbol": "e91caad3-33aa-447e-bd1c-e8f4da6fc1aa",
			"targetSymbol": "ace97e49-f873-4cc2-8644-726863f0a818",
			"object": "a03b44f6-6be4-4601-9629-b9bbbc656218"
		},
		"adc5e448-fc04-4161-8bc6-b3718a0a32f8": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-195,-26.5 -102.25,-26.5 -102.25,33.5 -39,33.5",
			"sourceSymbol": "d85b1965-70fa-4857-aae5-bb6b2d518e39",
			"targetSymbol": "8fa9bd0f-67b9-4b43-b335-46cdc674e5de",
			"object": "d80efe57-812b-4fe7-aaef-878d145bfc4f"
		},
		"59c4c290-c264-4b50-973c-e7162dbb0dd3": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -551,
			"y": -140,
			"object": "e16ccd4d-94a4-4355-9291-977b33e1b91a"
		},
		"d57d1795-be54-4416-af46-7d2b8029dfe0": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-530,-119 -675,-119",
			"sourceSymbol": "59c4c290-c264-4b50-973c-e7162dbb0dd3",
			"targetSymbol": "dfd5a7de-7635-437d-a06a-b1e60b4d4729",
			"object": "fe46f5ab-4090-4397-9348-8ee45fceb7cb"
		},
		"a9397022-e0a8-445e-b385-bac87118a6cb": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-530,-119 -530,-14 -792,-14 -792,-119",
			"sourceSymbol": "59c4c290-c264-4b50-973c-e7162dbb0dd3",
			"targetSymbol": "103721ef-5a92-424c-ab80-e00e9093d0be",
			"object": "9466e5a4-73ef-41ca-9751-48a4f769200c"
		},
		"e8c92712-7777-4912-8ccc-c47aeb286d5f": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 3711,
			"y": -245,
			"object": "bf0bc050-60c0-4e34-839c-6baca8156286"
		},
		"09eeb1e6-70b1-46bd-9cbe-9a9d58c05631": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "3732,-224 3877,-224",
			"sourceSymbol": "e8c92712-7777-4912-8ccc-c47aeb286d5f",
			"targetSymbol": "b7c9bd36-b35f-49f7-81a8-7ace1b4f8157",
			"object": "b71c9f7b-8efe-42f0-a3bf-6f3335f5620b"
		},
		"18ba362f-e367-4667-b593-6d7f17a251a2": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "3732,-224 3732,-172 3993,-172 3993,-224",
			"sourceSymbol": "e8c92712-7777-4912-8ccc-c47aeb286d5f",
			"targetSymbol": "67a77b1e-6acb-47df-9360-3d98648f6292",
			"object": "3d42fc68-48d4-461a-9dea-ab0ffe851fe5"
		},
		"349239b9-5330-40f6-ac8b-7e8560cf0048": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -191,
			"y": 157,
			"object": "a66aa8f6-ce7d-466e-b8ff-0b5bbdfe81b3"
		},
		"0650bfa5-bfb7-4d9f-8ac8-9c7d330a9a06": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-172,178 -172,94",
			"sourceSymbol": "349239b9-5330-40f6-ac8b-7e8560cf0048",
			"targetSymbol": "2783eea5-493f-4c66-b43a-cbfff9be6936",
			"object": "5286ac24-b81b-4d14-9afe-640211fe21bb"
		},
		"93765a8a-5d39-45a2-a440-3b73c16c8c62": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-170,178 -170,154 -100,154 -100,36 -39,36",
			"sourceSymbol": "349239b9-5330-40f6-ac8b-7e8560cf0048",
			"targetSymbol": "8fa9bd0f-67b9-4b43-b335-46cdc674e5de",
			"object": "aa2128da-a24e-4223-887f-2e4bf5990270"
		},
		"e0ccfa44-f4b9-4a3b-8222-cf914c277316": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -16,
			"y": 137,
			"object": "167969ee-99a3-4d35-9711-1cb7a7cbec12"
		},
		"ad093538-694e-45ad-a6a9-661e5744d309": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "5,158 5,189 -4,189 -4,222",
			"sourceSymbol": "e0ccfa44-f4b9-4a3b-8222-cf914c277316",
			"targetSymbol": "b52f1431-f643-4833-8746-300141968fd4",
			"object": "d9c0d596-5fd7-49ff-983c-a1a5e9455a1a"
		},
		"485d2eab-a474-4a3f-85ad-02be30e07dad": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "5,158 101,158 101,229",
			"sourceSymbol": "e0ccfa44-f4b9-4a3b-8222-cf914c277316",
			"targetSymbol": "5a7c5c15-4cd5-4cea-b449-d488e5c2b9ff",
			"object": "2d634131-11aa-4995-88aa-252966acf207"
		},
		"2b620b62-94c5-40dc-a99a-47a58c9552fe": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -307,
			"y": -717,
			"width": 100,
			"height": 60,
			"object": "b5288eba-8fc8-411b-a9b8-048c8a0d8a65"
		},
		"dfb72021-5c6d-49d4-9dd6-263ad0636e6b": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-257,-687 -257,-571",
			"sourceSymbol": "2b620b62-94c5-40dc-a99a-47a58c9552fe",
			"targetSymbol": "488257b9-8db2-4b28-9e5e-aed44715ba71",
			"object": "80cf9ad3-c3eb-41b0-8107-a553a8fa6fda"
		},
		"488257b9-8db2-4b28-9e5e-aed44715ba71": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -307,
			"y": -601,
			"width": 100,
			"height": 60,
			"object": "b2b5df75-228e-4e7d-bfe0-e03177186322"
		},
		"4ce7f597-2fe6-47b2-b1d7-3f84f77d51b5": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-257,-571 -257,-519.75 -249,-519.75 -249,-469",
			"sourceSymbol": "488257b9-8db2-4b28-9e5e-aed44715ba71",
			"targetSymbol": "d61035ef-45d9-43f5-bc69-da8677c4042b",
			"object": "7dd6270a-4c50-48ac-9034-accecd52ac3d"
		},
		"d61035ef-45d9-43f5-bc69-da8677c4042b": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -299,
			"y": -499,
			"width": 100,
			"height": 60,
			"object": "675f37df-4e36-4dca-bd2a-d373fef4aa09"
		},
		"9870c605-a3d9-4aea-9912-65d035b7d1aa": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-249,-469 -349.5,-469 -349.5,-177.75 -282,-177.75 -282,114",
			"sourceSymbol": "d61035ef-45d9-43f5-bc69-da8677c4042b",
			"targetSymbol": "9a4c92f5-20d9-4d36-abe5-971113fbf059",
			"object": "29878ea2-4eb5-48d1-b06a-08b1ac15de59"
		},
		"02736b5b-7fac-4591-b3dd-82e79746e867": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -414,
			"y": 306,
			"width": 100,
			"height": 60,
			"object": "dc1860ba-eae3-41ff-96cf-780880391467"
		},
		"86d1683f-9234-4bff-9320-6c7b7eec9fda": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-369,336 -369,254",
			"sourceSymbol": "02736b5b-7fac-4591-b3dd-82e79746e867",
			"targetSymbol": "39a43e9f-87ed-4389-beb0-b8b1a48f3d60",
			"object": "36582cd5-a4d5-44f3-8a81-bcb13eb9af5a"
		},
		"39a43e9f-87ed-4389-beb0-b8b1a48f3d60": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -414,
			"y": 226,
			"width": 100,
			"height": 60,
			"object": "019c17a6-e0c0-46b9-b712-c0d34cf252e5"
		},
		"6ca15b50-64b1-45fd-944f-a97c3c905523": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-371,256 -371,178",
			"sourceSymbol": "39a43e9f-87ed-4389-beb0-b8b1a48f3d60",
			"targetSymbol": "c71fafc5-7a20-4429-a6d6-c3fff1d74d87",
			"object": "e682a9c6-3eab-4852-82f5-b8afed35e709"
		},
		"c71fafc5-7a20-4429-a6d6-c3fff1d74d87": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": -414,
			"y": 148,
			"width": 100,
			"height": 60,
			"object": "5718cc40-784a-446f-804a-686f62b8a38d"
		},
		"c5e3dae7-4d95-415e-8565-2367472cd98b": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-364,178 -364,130 -382.5,130 -382.5,114 -282,114",
			"sourceSymbol": "c71fafc5-7a20-4429-a6d6-c3fff1d74d87",
			"targetSymbol": "9a4c92f5-20d9-4d36-abe5-971113fbf059",
			"object": "de475d99-d316-45b2-bb3d-35472efe34ec"
		},
		"1070a4f4-dfc1-4b84-af9a-c2df1bd5abc3": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -1278,
			"y": -140,
			"object": "7ade6462-abd5-40a6-9e34-08a157ba9cf0"
		},
		"21f9ce31-19a0-40b7-83dd-176475275da8": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1257,-119 -1370,-119",
			"sourceSymbol": "1070a4f4-dfc1-4b84-af9a-c2df1bd5abc3",
			"targetSymbol": "36a3205f-cce4-4396-a3e2-2c1c00709f25",
			"object": "a4c1276f-ced6-49a0-a4df-212c8f2fe429"
		},
		"3745f820-7a13-4ad7-8fba-5288af9e2ebf": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -1519,
			"y": -140,
			"object": "d26896e5-5e29-4c01-8fa3-c4f2f5f52837"
		},
		"5fb4b40e-4967-404e-ba97-f9c5e087faab": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1498,-118 -1874,-118 -1874,115",
			"sourceSymbol": "3745f820-7a13-4ad7-8fba-5288af9e2ebf",
			"targetSymbol": "2621149b-aca7-4304-bccf-468e1c675fac",
			"object": "1e1be659-516b-44a2-a9fb-664eab510819"
		},
		"36a3205f-cce4-4396-a3e2-2c1c00709f25": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -1420,
			"y": -149,
			"width": 100,
			"height": 60,
			"object": "57733068-a0f9-45ef-98a4-b14c150c9705"
		},
		"209a3aa2-738c-43ef-b9f5-f3d1fce3056c": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1370,-119 -1498,-119",
			"sourceSymbol": "36a3205f-cce4-4396-a3e2-2c1c00709f25",
			"targetSymbol": "3745f820-7a13-4ad7-8fba-5288af9e2ebf",
			"object": "0b6bcc4d-09c0-48e5-82bc-5db593c6fe31"
		},
		"ca42c5b7-2431-41c4-ad56-2cf2765339dc": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1257,-139.5 -1257,-190.5 -1498,-190.5 -1498,-139.5",
			"sourceSymbol": "1070a4f4-dfc1-4b84-af9a-c2df1bd5abc3",
			"targetSymbol": "3745f820-7a13-4ad7-8fba-5288af9e2ebf",
			"object": "910787e8-1f48-4f73-83dc-66f49a969a17"
		},
		"31b3b274-fad2-4d0d-8ad4-f83ba36a1d61": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -1534,
			"y": 380,
			"object": "4a2ba629-a4ac-4c75-bad3-6465304ac364"
		},
		"7dd8df71-41a5-4f42-a253-f6e7d0a2867f": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1513,401 -1614,401",
			"sourceSymbol": "31b3b274-fad2-4d0d-8ad4-f83ba36a1d61",
			"targetSymbol": "ddc65328-2d5c-46e0-a44a-686a97b4d884",
			"object": "e25811f9-89f2-490f-ae80-0908436bc420"
		},
		"ddc65328-2d5c-46e0-a44a-686a97b4d884": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": -1664,
			"y": 371,
			"width": 100,
			"height": 60,
			"object": "ada573ed-5ba3-4e9d-88a5-69fb301817f3"
		},
		"326ebfc0-6694-41dd-bd60-53cb947da1d7": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1614,401 -1796,401",
			"sourceSymbol": "ddc65328-2d5c-46e0-a44a-686a97b4d884",
			"targetSymbol": "0e43ea46-0ea4-4373-9ea0-6eb016bfedcd",
			"object": "5b0dbaa7-0833-4852-8544-a3e0066e354b"
		},
		"53affbee-7661-4b67-9d38-e95cafcba922": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1513,380.5 -1513,329.5 -1798,329.5 -1798,380.5",
			"sourceSymbol": "31b3b274-fad2-4d0d-8ad4-f83ba36a1d61",
			"targetSymbol": "0e43ea46-0ea4-4373-9ea0-6eb016bfedcd",
			"object": "0bc7bdaa-432e-45a2-9405-b60c205429b1"
		},
		"81744fb7-fd2d-4c53-9218-1b78524ac2aa": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 622,
			"y": 711,
			"object": "47ec03ab-1a9b-4611-ad45-62f351176504"
		},
		"b0e3917c-b47c-4800-9123-14b80008cc81": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "643,731.5 739,731.5",
			"sourceSymbol": "81744fb7-fd2d-4c53-9218-1b78524ac2aa",
			"targetSymbol": "9f449b53-f4ab-4b9a-9f14-e82e87d5848d",
			"object": "b37335ab-ce98-4134-8396-6fa4f72b2d36"
		},
		"9f449b53-f4ab-4b9a-9f14-e82e87d5848d": {
			"classDefinition": "com.sap.bpm.wfs.ui.ServiceTaskSymbol",
			"x": 689,
			"y": 701,
			"width": 100,
			"height": 60,
			"object": "7afcbd35-981f-40ad-be79-b73c357b3e88"
		},
		"dee0880d-f855-48e4-9b82-e64279983b0b": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "739,731 878,731",
			"sourceSymbol": "9f449b53-f4ab-4b9a-9f14-e82e87d5848d",
			"targetSymbol": "03cd082b-a89d-48ef-b323-9b3681487576",
			"object": "8cbbfa2a-4135-482e-8e03-1025a17802d8"
		},
		"903ec1b6-2807-446a-a805-7cc3706af569": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "643,752.5 643,803 799,803 799,752.5 853,752.5",
			"sourceSymbol": "81744fb7-fd2d-4c53-9218-1b78524ac2aa",
			"targetSymbol": "03cd082b-a89d-48ef-b323-9b3681487576",
			"object": "0239ecf6-2bde-462e-ab54-dcaf8be3a422"
		},
		"ef9100e8-8a33-4c0b-8e66-989ce2dfbea2": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 489,
			"y": 711,
			"width": 100,
			"height": 60,
			"object": "91b9adda-ddfc-4028-8044-a9897babddfb"
		},
		"47b11331-572f-4403-83f9-6ad0e44e0ff3": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "539,741.5 605.75,741.5 605.75,731.5 643,731.5",
			"sourceSymbol": "ef9100e8-8a33-4c0b-8e66-989ce2dfbea2",
			"targetSymbol": "81744fb7-fd2d-4c53-9218-1b78524ac2aa",
			"object": "30862a01-6244-400c-8890-44d7f4d8475c"
		},
		"84291a6b-6f7f-4b46-a8b1-0db27cb68793": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -477,
			"y": 366,
			"object": "22c0a6d3-9563-45cd-a631-16ace9e8fdbe"
		},
		"3278c541-6bde-451e-ab6f-7527ed4eed51": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-456,387 -456,429 -364,429",
			"sourceSymbol": "84291a6b-6f7f-4b46-a8b1-0db27cb68793",
			"targetSymbol": "ebaae79e-d937-4c84-95af-11e971f6f273",
			"object": "cd8798ef-1418-4af7-9969-6f67bebd2e98"
		},
		"c97a3c68-e80a-4b2b-9b29-6257cf4d3765": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-435.5,386 -367,386 -367,347",
			"sourceSymbol": "84291a6b-6f7f-4b46-a8b1-0db27cb68793",
			"targetSymbol": "02736b5b-7fac-4591-b3dd-82e79746e867",
			"object": "0651d623-3b71-4c71-9dd8-df42359ad9e1"
		},
		"ace97e49-f873-4cc2-8644-726863f0a818": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -1490,
			"y": 637,
			"object": "1626e402-eabe-408f-9fa8-2b65959fff3a"
		},
		"7d06faca-4539-4701-a573-6a8a324a9f5e": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1469,658 -1383,658",
			"sourceSymbol": "ace97e49-f873-4cc2-8644-726863f0a818",
			"targetSymbol": "92018014-8c66-4a67-bbc0-a61d8b598196",
			"object": "9291e3f6-627b-42b7-950d-d7a0d164f0b7"
		},
		"fd06416a-c363-4ba7-8f87-3f33f74b6e12": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-1469,637.5 -1469,575 -1318.5,575",
			"sourceSymbol": "ace97e49-f873-4cc2-8644-726863f0a818",
			"targetSymbol": "4e2480c2-0ab3-4fe8-b196-e1ec91b66df3",
			"object": "785cb1c9-0e29-4cda-92f9-027cd6c963e9"
		},
		"79d130a1-1524-41fa-aec4-443fd1d75247": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 1094,
			"y": 319,
			"object": "9d91e666-d780-414b-aedd-55ee0147bec9"
		},
		"222c7ea3-86ea-4f7b-bcd3-a5103ee41e0e": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1115,339.78125 1208.3125,339.78125",
			"sourceSymbol": "79d130a1-1524-41fa-aec4-443fd1d75247",
			"targetSymbol": "048874ef-105c-4b68-9f65-8964b44af9b1",
			"object": "68ffff6d-17e1-4d54-b116-f00b434144ba"
		},
		"d15ae76a-43d4-416e-8b67-e09e1070165f": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "1115,319.5 1115,290 775,290 775,240",
			"sourceSymbol": "79d130a1-1524-41fa-aec4-443fd1d75247",
			"targetSymbol": "6d2722e7-d064-4781-8e80-5f52c4e10ff8",
			"object": "13c8467d-cc25-4919-82aa-981c927ba3bf"
		},
		"d0c5a1ee-0a3f-4afd-8c09-e5027577ad70": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": 4382,
			"y": -473,
			"object": "cddc4689-b295-4ff2-bba3-42988d40ae93"
		},
		"b19c9780-add2-464a-8c0e-57a35a452467": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "4403,-452.5 4495,-452.5",
			"sourceSymbol": "d0c5a1ee-0a3f-4afd-8c09-e5027577ad70",
			"targetSymbol": "a9d43fab-8ac7-4d0f-9b76-a23b3de1ff31",
			"object": "e498b954-ab68-4fa1-b71f-daf6d3269041"
		},
		"ad908f6a-e301-4b43-8d11-e5c045dae99c": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "4404,-438 4404,-381 4558,-381 4558,-439 4593,-439",
			"sourceSymbol": "d0c5a1ee-0a3f-4afd-8c09-e5027577ad70",
			"targetSymbol": "3ba0aa03-c964-4c25-b74d-87e1b7adecbf",
			"object": "d08f284a-ff9b-434b-9e3b-4c688fd2fb36"
		},
		"891b6d68-eec7-47a8-95ab-955e88576ad3": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": -266,
			"y": 565,
			"width": 100,
			"height": 60,
			"object": "26d15377-8229-412a-941f-f4b55b9d8660"
		},
		"e04f4199-f4d9-4467-aefc-ed22ffe5088e": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-213.5,595 -213.5,505",
			"sourceSymbol": "891b6d68-eec7-47a8-95ab-955e88576ad3",
			"targetSymbol": "7a82d9c6-8b1e-4b22-8799-a4c844c742e8",
			"object": "17796642-ed13-403d-a704-e368ef4ee67f"
		},
		"bf9c3dbf-15f4-46e7-a951-436bd57e7a13": {
			"classDefinition": "com.sap.bpm.wfs.ui.MailTaskSymbol",
			"x": -170,
			"y": 393,
			"width": 100,
			"height": 60,
			"object": "a0f2bc94-21d8-43c4-9726-2de6188586ed"
		},
		"eb104195-38a5-4c59-a5d6-baa9b6edac97": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-120,423 -211.25,423 -211.25,306 -273,306",
			"sourceSymbol": "bf9c3dbf-15f4-46e7-a951-436bd57e7a13",
			"targetSymbol": "3da8774e-916f-4f8a-bcf9-7987280ab61b",
			"object": "0744a753-e469-45c8-887a-d8fe06650cea"
		},
		"7a82d9c6-8b1e-4b22-8799-a4c844c742e8": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -232,
			"y": 484,
			"object": "095a8d5e-d3f8-4251-957a-3ef0b54b43c6"
		},
		"2fb44982-d44f-422d-941a-e79245c6d891": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-211,505 -180,505 -180,423 -120,423",
			"sourceSymbol": "7a82d9c6-8b1e-4b22-8799-a4c844c742e8",
			"targetSymbol": "bf9c3dbf-15f4-46e7-a951-436bd57e7a13",
			"object": "5e7d40e9-1f0a-4fbe-a0b4-944d5e1ceeb7"
		},
		"3f7354cf-b1dd-413d-ac1c-e2a1a6c0ee83": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-219,491 -273,491 -273,306",
			"sourceSymbol": "7a82d9c6-8b1e-4b22-8799-a4c844c742e8",
			"targetSymbol": "3da8774e-916f-4f8a-bcf9-7987280ab61b",
			"object": "3d919f92-7c4a-4f80-88c2-faa8232b7b13"
		},
		"2783eea5-493f-4c66-b43a-cbfff9be6936": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -195,
			"y": 73,
			"object": "154c1d85-9385-4c63-985b-f7c22edcc182"
		},
		"dcc44d42-af77-43e5-9c07-4bba0ac9f2a6": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-174,94 -174,37 -195,37 -195,-29",
			"sourceSymbol": "2783eea5-493f-4c66-b43a-cbfff9be6936",
			"targetSymbol": "d85b1965-70fa-4857-aae5-bb6b2d518e39",
			"object": "202b6dcf-65ff-41c6-af1b-3086209603bb"
		},
		"05c9fda3-3626-4b78-a45d-97604fac4b79": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-174,94 -106.5,94 -106.5,36 -39,36",
			"sourceSymbol": "2783eea5-493f-4c66-b43a-cbfff9be6936",
			"targetSymbol": "8fa9bd0f-67b9-4b43-b335-46cdc674e5de",
			"object": "ec30671a-4a08-44ae-bee3-8b9cb9dfd810"
		},
		"9e9f79f1-c0be-42b9-ab70-2bda04a87757": {
			"classDefinition": "com.sap.bpm.wfs.ui.ExclusiveGatewaySymbol",
			"x": -490,
			"y": 250,
			"object": "80d8290b-5d1e-489b-9196-04a30020661e"
		},
		"3d4bca1a-ff07-4cea-b008-fdfb86b2dbec": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-469,271 -469,329 -456,329 -456,387",
			"sourceSymbol": "9e9f79f1-c0be-42b9-ab70-2bda04a87757",
			"targetSymbol": "84291a6b-6f7f-4b46-a8b1-0db27cb68793",
			"object": "5c8fa50a-b66a-4c55-8e7a-b5e595365f46"
		},
		"a0d47f16-4fd4-48dc-a136-075f6b8d056f": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "-469,271 -431,271 -431,336 -364,336",
			"sourceSymbol": "9e9f79f1-c0be-42b9-ab70-2bda04a87757",
			"targetSymbol": "02736b5b-7fac-4591-b3dd-82e79746e867",
			"object": "afca7dd8-ef3c-41b8-a481-4845463558b7"
		},
		"ed48ec5d-a3af-4ec9-99b5-decdaa749e1b": {
			"classDefinition": "com.sap.bpm.wfs.ui.ScriptTaskSymbol",
			"x": 354,
			"y": 711,
			"width": 100,
			"height": 60,
			"object": "dc46d7b3-eeb3-4c5d-a22e-53573488ff79"
		},
		"8881f1a1-0d15-4464-b393-a3c13c4f0628": {
			"classDefinition": "com.sap.bpm.wfs.ui.SequenceFlowSymbol",
			"points": "404,741 539,741",
			"sourceSymbol": "ed48ec5d-a3af-4ec9-99b5-decdaa749e1b",
			"targetSymbol": "ef9100e8-8a33-4c0b-8e66-989ce2dfbea2",
			"object": "333972f2-059e-458c-a84e-12ded628c45b"
		},
		"8235f323-4756-495b-893a-2b5584e59c19": {
			"classDefinition": "com.sap.bpm.wfs.ui.BoundaryEventSymbol",
			"x": 15.75,
			"y": 321.75,
			"object": "5c249566-d8e1-4b0f-8766-c66a3b6471eb"
		},
		"61b93211-8d17-4109-9dd8-2657acf9b417": {
			"classDefinition": "com.sap.bpm.wfs.ui.BoundaryEventSymbol",
			"x": 38,
			"y": 840,
			"object": "9b854ad4-6864-4d21-8538-b72fa1ddc83c"
		},
		"a07a81c0-e4c5-42e9-8ff7-d5ea37b6f271": {
			"classDefinition": "com.sap.bpm.wfs.ui.BoundaryEventSymbol",
			"x": 92,
			"y": 15,
			"object": "24a33845-446b-4d18-95b1-fd65eba5ee35"
		},
		"62d7f4ed-4063-4c44-af8b-39050bd44926": {
			"classDefinition": "com.sap.bpm.wfs.LastIDs",
			"terminateeventdefinition": 1,
			"messageeventdefinition": 1,
			"timereventdefinition": 17,
			"maildefinition": 32,
			"escalationeventdefinition": 1,
			"intermediateescalationevent": 1,
			"sequenceflow": 578,
			"startevent": 2,
			"intermediatemessageevent": 1,
			"intermediatetimerevent": 6,
			"boundarytimerevent": 3,
			"endevent": 7,
			"usertask": 11,
			"servicetask": 80,
			"scripttask": 136,
			"mailtask": 35,
			"exclusivegateway": 107,
			"parallelgateway": 4,
			"referencedsubflow": 5
		},
		"71ad5630-5148-4aa9-b810-d19b107aa21c": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition1",
			"to": "${context.RequesterEmail_Notif}",
			"subject": "Melody Request - Action Required ${context.RequestID.value} - ${context.EmailTemplateVars.EmailSubject}",
			"reference": "/webcontent/PresalesRequestApproval/Resubmission.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition1"
		},
		"e3c79aa7-cfc9-48b0-914c-925e5315bb67": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition3",
			"to": "${context.RequesterEmail_Notif}",
			"cc": "${context.ReqTypeOwnerEmail_Notif}",
			"subject": "Melody Request - Created ${context.RequestID.value} - ${context.EmailTemplateVars.EmailSubject}",
			"reference": "/webcontent/PresalesRequestApproval/Submision.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition3"
		},
		"7e5d6e1f-3e4b-4316-8def-97efa27a04e7": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition6",
			"to": "${context.approversEmails}",
			"subject": "Melody Request ${context.RequestID.value} is waiting for review - System Generated Email",
			"reference": "/webcontent/PresalesRequestApproval/RA_Review.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition6"
		},
		"4bdf6465-e88a-41d5-b713-9412db07e0c2": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition8",
			"to": "${context.subtitutorsEmails}",
			"subject": "Melody Request ${context.RequestID.value} is waiting for review - System Generated Email",
			"reference": "/webcontent/PresalesRequestApproval/Review_substitute.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition8"
		},
		"c3a9ea3f-906e-40f0-8ba2-0cd2048aa210": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition9",
			"to": "${context.DelegatesEmails}",
			"subject": "Melody Request ${context.RequestID.value} is waiting for review - System Generated Email",
			"reference": "/webcontent/PresalesRequestApproval/Review_substitute.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition9"
		},
		"67a9e533-d9ac-48ef-b077-8ba84a9773fc": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition10",
			"to": "${context.CAManagersEmails}",
			"subject": "Melody Request ${context.RequestID.value} is waiting for review - System Generated Email",
			"reference": "/webcontent/PresalesRequestApproval/Review.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition10"
		},
		"7e0efa31-790f-4201-9262-3fb36ff6bbfa": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition13",
			"to": "${context.RequesterEmail_Notif}",
			"cc": "${context.ProcessorEmail_Notif},${context.SubstituteProcessorEmail_Notif},${context.ReqTypeOwnerEmail_Notif},${context.io_OwnerEmails}",
			"subject": "Melody Request - Rejected ${context.RequestID.value} - ${context.EmailTemplateVars.EmailSubject}",
			"reference": "/webcontent/PresalesRequestApproval/Rejected.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition13"
		},
		"8c92cdae-0ffa-4890-aea9-10bac198992f": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition18",
			"to": "${context.ProcessorEmail_Notif},${context.SubstituteProcessorEmail_Notif}",
			"cc": "",
			"subject": "Melody Request - Action Required ${context.RequestID.value} - ${context.EmailTemplateVars.EmailSubject}",
			"reference": "/webcontent/PresalesRequestApproval/Review.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition18"
		},
		"f9fbe70e-28cc-4b97-8291-31cbbeddf2fa": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition19",
			"to": "${context.ProcessorEmail_Notif},${context.SubstituteProcessorEmail_Notif}",
			"subject": "[REMINDER] Melody Request - Action Required ${context.RequestID.value} - ${context.EmailTemplateVars.EmailSubject}",
			"reference": "/webcontent/PresalesRequestApproval/Review.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition19"
		},
		"78d59f76-b426-4436-9d0d-c22a7a9fb0d8": {
			"classDefinition": "com.sap.bpm.wfs.TimerEventDefinition",
			"timeDuration": "${context.dueDateForManagerApproval}",
			"id": "timereventdefinition17"
		},
		"6e75faa4-5745-4bb1-bd96-312865114c7a": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition20",
			"to": "${context.ProcessorEmail_Notif},${context.SubstituteProcessorEmail_Notif}",
			"cc": "${context.RequesterEmail_Notif},${context.ReqTypeOwnerEmail_Notif},${context.io_OwnerEmails}",
			"subject": "Melody Request - Cancelled ${context.RequestID.value} - ${context.EmailTemplateVars.EmailSubject}",
			"reference": "/webcontent/PresalesRequestApproval/Request_terminated.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition20"
		},
		"c4889ea2-831b-48a1-9806-4127a9ee3299": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition22",
			"to": "${context.requesterDetails.email},${context.oppOwnerDetails.email}",
			"subject": "Melody Request ${context.RequestID.value} has been closed in Melody - System Generated Email",
			"reference": "/webcontent/PresalesRequestApproval/RA_Rejected.html",
			"id": "maildefinition22"
		},
		"aade502f-3086-4101-b265-66fad4d16978": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition23",
			"to": "${context.requesterDetails.email}",
			"subject": "Melody Request ${context.RequestID.value} is waiting for review - System Generated Email",
			"reference": "/webcontent/PresalesRequestApproval/Resubmission_RA.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition23"
		},
		"7f89ed22-2c77-480c-8b2f-e9ae77700f77": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition24",
			"to": "${context.requesterDetails.email},${context.oppOwnerDetails.email},${context.accOwnerDetails.email},${context.approverData.email},${context.ResCurrentProcessorEmailFinal}",
			"subject": "Melody Request ${context.RequestID.value} has been closed in Melody - System Generated Email",
			"reference": "/webcontent/PresalesRequestApproval/Resource_Assigned_RA.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition24"
		},
		"545ea428-c798-40d6-a1d2-8b938ef1ec54": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition25",
			"to": "${context.ResourceEmail_Notif}",
			"subject": "Melody Request - Your Assignment ${context.RequestID.value} - ${context.EmailTemplateVars.EmailSubject}",
			"reference": "/webcontent/PresalesRequestApproval/Resource_assigned.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition25"
		},
		"51ac265c-56c7-48e6-b177-a00d4576dd48": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition26",
			"to": "${context.requesterDetails.email},${context.ReqTypeOwner},${context.approversEmails}",
			"subject": "Melody Request ${context.RequestID.value} has been submitted - System Generated Email",
			"reference": "/webcontent/PresalesRequestApproval/SubmisionReqArea.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition26"
		},
		"47942cdc-0fd2-4a51-9374-131b7eae140a": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"id": "id47942cdc-0fd2-4a51-9374-131b7eae140a"
		},
		"6429402e-86a3-4387-a1b9-c866b78aed78": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition29",
			"to": "${context.RequesterEmail_Notif}",
			"cc": "${context.ReqTypeOwnerEmail_Notif},${context.ProcessorEmail_Notif},${context.SubstituteProcessorEmail_Notif},${context.ResourceEmail_Notif},${context.io_OwnerEmails}",
			"subject": "Melody Request - Resource Assigned ${context.RequestID.value} - ${context.EmailTemplateVars.EmailSubject}",
			"reference": "/webcontent/PresalesRequestApproval/Resource_assigned_processor.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition29"
		},
		"4023193b-0e84-485c-856d-97960b3877b3": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition30",
			"to": "${context.ResDirectManagerEmail_Notif}",
			"subject": "Melody Request - Direct Report Assigned ${context.RequestID.value} - ${context.EmailTemplateVars.EmailSubject}",
			"reference": "/webcontent/PresalesRequestApproval/Resource_assigned.html",
			"ignoreInvalidRecipients": true,
			"id": "maildefinition30"
		},
		"d96bac8e-558d-408c-a8e9-3be31a5cec6e": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition31",
			"to": "${context.RequesterEmail_NotifFwd},${context.ExistingProcessorEmail_Notif},${context.ReqTypeOwnerEmail_Notif}",
			"cc": "${context.PreviousProcessEmail_Notif}",
			"subject": "Melody Request - Processor Revised ${context.RequestID.value} - ${context.EmailTemplateVars.EmailSubject}",
			"reference": "/webcontent/PresalesRequestApproval/Processor_Modification.html",
			"id": "maildefinition31"
		},
		"01aa41fd-b119-49a8-af71-453f6bebcc89": {
			"classDefinition": "com.sap.bpm.wfs.MailDefinition",
			"name": "maildefinition32",
			"to": "${context.newProcessorEmail_Notif}",
			"subject": "Melody Request - Action Required ${context.RequestID.value} - ${context.EmailTemplateVars.EmailSubject}",
			"reference": "/webcontent/PresalesRequestApproval/Review.html",
			"id": "maildefinition32"
		}
	}
}