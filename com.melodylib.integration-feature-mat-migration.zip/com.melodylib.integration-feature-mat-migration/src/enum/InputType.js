sap.ui.define(
	{
		Account: "Account",
		Opportunity: "Opportunity",
	},
	true
);
