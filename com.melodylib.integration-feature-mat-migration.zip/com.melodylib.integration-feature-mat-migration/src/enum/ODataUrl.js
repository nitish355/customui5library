sap.ui.define(
	{
		DataSources: [
			{
				name: "activityModel",
				url: "/sap/opu/odata/sap/YACTIVITY_SRV",
			},
			{
				name: "utility",
				url: "/sap/opu/odata/sap/YUTILITY_SRV",
			},
			{
				name: "harmony",
				url: "/int_ic/sap/opu/odata/sap/zharmony_callidus_srv",
			},
			{
				name: "opportunity",
				url: "/sap/opu/odata/sap/YOPPORTUNITY_SRV",
			},
			{
				name: "oreModel",
				url: "/sap/opu/odata/sap/YUTILITY_SRV",
			},
			{
				name: "utility",
				url: "/sap/opu/odata/sap/YUTILITY_SRV",
			},
			{
				name: "mtr",
				url: "/sap/opu/odata/sap/YMTR_SRV",
			},
			{
				name: "activity",
				url: "/sap/opu/odata/sap/YACTIVITY_SRV",
			},
			{
				name: "activityList",
				url: "/sap/opu/odata/sap/YACTIVITYLIST_SRV",
			},
			{
				name: "isp",
				url: "/int_ic/sap/opu/odata/sap/ZCATSXTMO",
			},
			{
				name: "successLine",
				url: "/sap/opu/odata/sap/YSUCCESSLINE_SRV",
			},
		],
	},
	true
);
