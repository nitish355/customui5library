/*!
 * ${copyright}
 */

/**
 * Initialization Code and shared classes of library com.melodylib.integration.
 */
sap.ui.define(["sap/ui/core/library"], function () {
	"use strict";

	// delegate further initialization of this library to the Core
	// Hint: sap.ui.getCore() must still be used to support preload with sync bootstrap!
	sap.ui.getCore().initLibrary({
		name: "com.melodylib.integration",
		version: "${version}",
		dependencies: [
			// keep in sync with the ui5.yaml and .library files
			"sap.ui.core",
		],
		types: ["com.melodylib.integration.ExampleColor"],
		interfaces: [],
		controls: [
			"com.melodylib.integration.Example",
			"com.melodylib.integration.controls.AccountControl",
			"com.melodylib.integration.controls.OpportunityControl",
			"com.melodylib.integration.util.opportunity.DiscontinuedOpportunityController",
			"com.melodylib.integration.controls.OpportunitySelect",
			"com.melodylib.integration.controls.AccountSelect"
		],
		elements: [
			"com.melodylib.integration.util.account.Account",
			"com.melodylib.integration.util.account.AccountHelper",
			"com.melodylib.integration.util.account.AccountDialogController",
			"com.melodylib.integration.util.Opportunity",
			"com.melodylib.integration.util.opportunity.Opportunity",
			"com.melodylib.integration.util.opportunity.OpportunityHelper",
			"com.melodylib.integration.util.opportunity.DiscontinuedOpportunity",
			"com.melodylib.integration.util.opportunity.DiscontinuedOpportunityController",
			"com.melodylib.integration.util.opportunity.OpportunityDialogController",
			"com.melodylib.integration.util.Algorithm",
			"com.melodylib.integration.state.OpportunityState",
		],
		noLibraryCSS: false, // if no CSS is provided, you can disable the library.css load here
	});

	/**
	 * Some description about <code>com.melodylib.integration</code>
	 *
	 * @namespace
	 * @name com.melodylib.integration
	 * @author DARSHAN PULIKESHI
	 * @version ${version}
	 * @public
	 */
	var thisLib = com.melodylib.integration;

	/**
	 * Semantic Colors of the <code>com.melodylib.integration.Example</code>.
	 *
	 * @enum {string}
	 * @public
	 */
	thisLib.ExampleColor = {
		/**
		 * Default color (brand color)
		 * @public
		 */
		Default: "Default",

		/**
		 * Highlight color
		 * @public
		 */
		Highlight: "Highlight",
	};

	return thisLib;
});
