import Controller from "sap/ui/core/mvc/Controller";

/**
 * @name com.melodylib.integration.component.opportunityInput.OpportunityInput
 */
export default class OpportunityInput extends Controller {
	onInit () {
		/* const component = this.getOwnerComponent();
		const opportunityState = OpportunityState.getInstance();

		const model = opportunityState.getModel();
		component.setModel(model, "opportunityState"); */

	}

	async onValueHelpRequest () {
		// create dialog lazily
		this.oDialog ??= await this.loadFragment({
			name: "com.melodylib.integration.component.opportunityInput.fragment.ActiveOpportunityDialog"
		});
	
		this.oDialog.open();
	}

	selectOpportunity (event) {
		const source = event.getSource();
		const id = event.data("id");
	}
}