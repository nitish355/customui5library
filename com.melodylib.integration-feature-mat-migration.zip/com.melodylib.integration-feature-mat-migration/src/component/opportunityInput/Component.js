import UIComponent from "sap/ui/core/UIComponent";
import JSONModel from "sap/ui/model/json/JSONModel";
import Device from "sap/ui/Device";
import OpportunityState from "com/melodylib/integration/state/OpportunityState";

/**
 * @name com.melodylib.integration.component.opportunityInput.Component
 */
export default class Component extends UIComponent {
	metadata = {
		manifest: "json",
		properties : {
            opportunity: { type : "string", defaultValue : ""}
        },
        aggregations : { },
        events : {
            select : {
                parameters : {
                    opportunity : {type : "object"}
                }
            }
        },
		rootView: {
			viewName: "com.melodylib.integration.component.opportunityInput.OpportunityInput",
			type: "XML",
			id: "opportunityInput",
		},
		interfaces: ["sap.ui.core.IAsyncContentCreation"],
	}

	init () {
		var oModel;
 		UIComponent.prototype.init.apply(this, arguments);
		oModel = new JSONModel(Device);
		oModel.setDefaultBindingMode("OneWay");
		this.setModel(oModel, "device");

		const opportunityState = OpportunityState.getInstance();
		const model = opportunityState.getModel();
		this.setModel(model, "opportunityState");
	}
}

Component.prototype.setOpportunity = function(opportunity) {
	this.setProperty("opportunity", opportunity);
	return this;
};