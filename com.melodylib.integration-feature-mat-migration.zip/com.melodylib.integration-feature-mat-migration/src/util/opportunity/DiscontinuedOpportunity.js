// Importing SAPUI5 base Object
import * as BaseObject from "sap/ui/base/Object";

// Importing JSONModel from SAPUI5 model library
import JSONModel from "sap/ui/model/json/JSONModel";

// Importing custom modules from your application namespace
import Fragment from "sap/ui/core/Fragment";
import Actions from "com/melodylib/integration/enum/Actions";
import ResourceModel from "sap/ui/model/resource/ResourceModel";
import Opportunity from "com/melodylib/integration/util/opportunity/OpportunityUtil";
import OpportunityService from "com/melodylib/integration/service/OpportunityService";
import DiscontinuedOpportunityController from "./DiscontinuedOpportunityController";

/**
 * @name com.melodylib.integration.util.opportunityUtil.DiscontinuedOpportunity
 */

export default class DiscontinuedOppUtil extends BaseObject {
	static instance = null;

	constructor() {
		super();
		this.model = this.getModel();
	}

	// Static method to get the instance
	static getInstance() {
		if (!this.instance) {
			this.instance = new DiscontinuedOppUtil();
		}
		return this.instance;
	}

	//function to get model
	getModel(data) {
		data = data ? data : {};
		if (!this.model) {
			this.model = new JSONModel(data);
			this.model.setSizeLimit(99999);
		}
		return this.model;
	}

	/**
	 * @author DARSHAN,RAKESH
	 * @function getUserRecords
	 * @description function to get Discontinued Opportunity based on user activities
	 */
	async getUserRecords(DialogController) {
		let discontinuedOppModel = this.model;
		try {
			let { data } = await OpportunityService.getUserRecords();
			if (data?.results && data.results.length) {
				discontinuedOppModel.setProperty("/UserActivities", data.results);
				discontinuedOppModel.refresh();
				sap.ui.getCore().setModel(discontinuedOppModel, "discontinuedOppModel");
				this.getDiscontinuedOpp(data.results, DialogController);
			}
		} catch (error) {
			console.log("ERROR IN getUserRecords : ", error);
		}
	}

	/**
	 * @author DARSHAN,RAKESH
	 * @function getDiscontinuedOpp
	 * @description function to get Discontinued Opp
	 */
	getDiscontinuedOpp(userActivities, DialogController) {
		let oThisController = this;
		//get unique optid from data.result and pass to filters
		let distOpp = [
			...new Set(userActivities.map((data) => data.OpportunityId)),
		];
		let batchChanges = [];
		for (let i = 0; i < distOpp.length; i++) {
			let sOpportunityId = distOpp[i];
			let oParameters = {
				urlParameters: {
					$select: Actions.DisContinuedOpportunityTeamUrlParm.select,
					$expand: Actions.DisContinuedOpportunityTeamUrlParm.expand,
				},
				filters: [],
			};
			batchChanges.push(
				OpportunityService.getOpportunityTeam(sOpportunityId, oParameters)
			);
		}
		Promise.all(batchChanges)
			.then((aResponse) => {
				let aResults = aResponse.map((response) => {
					if (response.data.OPPT_ID) {
						return response.data;
					}
				});

				if (aResults.length) {
					oThisController.getDiscontOppResults(aResults, DialogController);
				}
			})
			.catch((oError) => {
				//TODO handle Error
			});
	}

	/**
	 * @author DARSHAN,RAKESH
	 * @function getDiscontOppResults
	 */
	getDiscontOppResults(aDiscontiunedOpp, DialogController) {
		let aFormattedDiscntOpp = [];
		let oDefaultModel = this.model;

		//FILTERING OUT THE E0002 OPPORTUNITIES
		let updatedDiscOpp = aDiscontiunedOpp.filter((data) => {
			return data.STATUS === "E0002";
		});
		let userActivitiesData = oDefaultModel.getProperty("/UserActivities") || [];

		for (let i = 0; i < userActivitiesData.length; i++) {
			let tempUserActData = userActivitiesData[i];
			let tempDiscOpp =
				updatedDiscOpp.find((data) => {
					return tempUserActData.OpportunityId === data.OPPT_ID;
				}) || false;
			if (tempDiscOpp && tempDiscOpp.REPLACED_BY) {
				//Replacing string starting with 0
				tempDiscOpp.REPLACED_BY = tempDiscOpp.REPLACED_BY.replace(/^0+/, "");
				if (tempUserActData.OpportunityId !== tempDiscOpp.REPLACED_BY) {
					tempUserActData.NewOppId = tempDiscOpp.REPLACED_BY;
					tempUserActData.Description = tempDiscOpp.ACCOUNT_NAME;
					aFormattedDiscntOpp.push(tempUserActData);
				}
			} else {
				tempUserActData.NewOppId = tempDiscOpp.REPLACED_BY;
				tempUserActData.Description = tempDiscOpp.ACCOUNT_NAME;
				aFormattedDiscntOpp.push(tempUserActData);
			}
		}

		this.setDiscontinuedOppData(aFormattedDiscntOpp, DialogController);
	}

	/**
	 * @author DARSHAN,RAKESH
	 * @function setDiscontinuedOppData
	 * @description function to set Discontinued Opp Data
	 */
	setDiscontinuedOppData(updatedDiscOpp, DialogController) {
		let oDefaultModel = this.model;
		oDefaultModel.setProperty("/DiscontinuedOppData", updatedDiscOpp);
		oDefaultModel.refresh(true);
		this.fnCheckDiscontinuedOppDialog(DialogController);
	}

	/**
	 * @author DARSHAN,RAKESH
	 * @function fnCheckDiscontinuedOppDialog
	 * @description function to check to open discontinued Opp Dialog
	 */
	async fnCheckDiscontinuedOppDialog(DialogController) {
		try {
			let oDefaultModel = this.model;
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let DiscontinuedOppData = $.extend(
				true,
				[],
				oDefaultModel.getProperty("/DiscontinuedOppData")
			);
			if (DiscontinuedOppData.length) {
				if (!this.DiscontinueDialogController) {
					this.DiscontinueDialogController = DiscontinuedOpportunityController
						? new DiscontinuedOpportunityController(this)
						: new DialogController(this);
				}
				//open discontiuned Opp Fragment
				if (!this.discntOppDialog) {
					this.discntOppDialog = Fragment.load({
						id: "_DiscontinuedOppFragment",
						name: "com.melodylib.integration.fragments.DiscontinuedOpportunity",
						controller: this.DiscontinueDialogController,
					}).then(
						function (oDialog) {
							oDialog.setModel(oDefaultModel);
							let i18nModel = new ResourceModel({
								bundleName: "com.melodylib.integration.messagebundle",
							});
							oDialog.setModel(i18nModel, "i18n");
							return oDialog;
						}.bind(this)
					);
				}
				let oDialog = await this.discntOppDialog;
				if (oDialog) {
					oDialog.open();
				}
				// self.fnOpenDisContinuedOppotunities(true);
			}
			oStorage.put("pcDiscontinuedOppUpdated", true);
		} catch (error) {
			console.log("ERROR IN fnCheckDiscontinuedOppDialog : ", error);
		}
	}

	/**
	 * @author DARSHAN,RAKESH
	 * @function fnOpenDisContinuedOppotunities
	 * @description function
	 */
	fnOpenDisContinuedOppotunities(bVAl) {
		let oDefaultModel = this.model;
		let isDiscntOppDialogOpen = oPrerequisiteModel.getProperty(
			"/isDiscntOppDialogOpen"
		);
		if (oPrerequisiteModel) {
			if (!isDiscntOppDialogOpen) {
				oActivityFormRefModel.setProperty("/isDiscntOppDialogOpen", bVAl);
				if (bVAl) {
					self.discntOppDialog.open();
				}
			} else {
				oActivityFormRefModel.setProperty("/isDiscntOppDialogOpen", bVAl);
			}
		} else if (oPrerequisiteModel) {
			if (!isDiscntOppDialogOpen) {
				oPrerequisiteModel.setProperty("/isDiscntOppDialogOpen", bVAl);
				if (bVAl) {
					self.discntOppDialog.open();
				}
			}
		} else {
			if (bVAl) {
				self.discntOppDialog.open(); //Other Apps
			}
		}
	}
}
