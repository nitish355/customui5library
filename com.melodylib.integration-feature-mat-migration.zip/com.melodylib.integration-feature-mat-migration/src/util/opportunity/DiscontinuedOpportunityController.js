import Filter from "sap/ui/model/Filter";
import Fragment from "sap/ui/core/Fragment";
import * as BaseObject from "sap/ui/base/Object";
import Controller from "sap/ui/core/mvc/Controller";
import FilterOperator from "sap/ui/model/FilterOperator";
import JSONModel from "sap/ui/model/json/JSONModel";
import Actions from "com/melodylib/integration/enum/Actions";
import DateFormat from "sap/ui/core/format/DateFormat";
import IndexedDB from "com/melodylib/core/db/IndexedDB";
import ResourceModel from "sap/ui/model/resource/ResourceModel";
import IntegrationLibraryModel from "com/melodylib/integration/model/IntergrationLibraryModel";

export default class DiscontinuedOpportunityController extends Controller {
	constructor(oParentRef) {
		super();
		this.oParentRef = oParentRef;
	}

	/**
	 * @author DARSHAN
	 * @function fnGetDialogUsingId
	 * @description function to get element from fragment using id
	 * @param1 {String} dialogId
	 * @param2 {String} contentId
	 */
	fnGetDialogUsingId(dialogId, contentId) {
		return sap.ui.core.Fragment.byId(dialogId, contentId);
	}

	/**
	 * @author DARSHAN,RAKESH
	 * @function onUpdateDiscontOpp
	 * @description function to handle onUpdateDiscontOpp Press to update old OpportunityId with new Opportunity Id
	 * @param1 {String} dialogId
	 * @param2 {String} contentId
	 */
	async onUpdateDiscontOpp(oEvent) {
		let promiseArr = [];
		let opportunityData = [];
		let updateDiscntOpp = [];
		let dialog = oEvent.getSource().getParent();
		let table = dialog.getContent()[0];
		let items = table ? table.getSelectedContextPaths() : [];
		if (items.length) {
			for (let i = 0; i < items.length; i++) {
				let context = items[i];
				let data = table?.getModel()?.getProperty(context) || false;
				if (data) {
					updateDiscntOpp.push(data);
					delete data.Description;
					delete data.to_slact;
					// promiseArr.push(
					// 	OpportunityService.setDisconntiunedOpportunities(
					// 		data.GUID,
					// 		data
					// 	)
					// );
				}
			}

			// if (promiseArr.length) {
			// 	let responses = await Promise.all(promiseArr);
			// 	for (let i = 0; i < opportunityData.length; i++) {
			// 		let tempOpportunity = opportunityData[i]?.OPPT_ID;
			// 		let updateOppData = updateDiscntOpp.find((data) => {
			// 			return data.OpportunityId === tempOpportunity;
			// 		});
			// 		if (updateOppData) {
			// 			if (updateOppData.NewOppId) {
			// 				//update
			// 			}
			// 		}
			// 	}
			// }
		}
		this.onCloseDiscontOppDialog();
	}

	//function on click of cancel
	async onCloseDiscontOppDialog(oEvent) {
		let oDialog = await this.oParentRef.discntOppDialog;
		if (oDialog) {
			oDialog.close();
		}
	}
}
