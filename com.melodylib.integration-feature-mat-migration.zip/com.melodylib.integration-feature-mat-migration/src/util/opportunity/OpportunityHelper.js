import Filter from "sap/ui/model/Filter";
import Fragment from "sap/ui/core/Fragment";
import * as BaseObject from "sap/ui/base/Object";
import FilterOperator from "sap/ui/model/FilterOperator";
import JSONModel from "sap/ui/model/json/JSONModel";
import Actions from "com/melodylib/integration/enum/Actions";
import ResourceModel from "sap/ui/model/resource/ResourceModel";
import OpportunityService from "com/melodylib/integration/service/OpportunityService";
import Opportunity from "com/melodylib/integration/classes/opportunity/Opportunity";
import OpportunityDialogController from "com/melodylib/integration/util/opportunity/OpportunityDialogController";

/**
 * @name com.melodylib.integration.util.opportunity.OpportunityHelper
 */

// export default {
export default class OpportunityHelper extends BaseObject {
	static instance = null;
	constructor() {
		super();
	}

	// Static method to get the instance
	static getInstance() {
		if (!this.instance) {
			this.instance = new OpportunityHelper();
		}
		return this.instance;
	}

	/**
	 * @author DARSHAN
	 * @async
	 * @function getGeneratedYears
	 * @description function to generate Previous and Future year
	 * @public
	 */
	getGeneratedYears() {
		let currentDate = new Date();
		let year = currentDate.getFullYear(),
			monthPluseOne = currentDate.getMonth() + 1,
			month = monthPluseOne < 10 ? "0" + monthPluseOne : monthPluseOne,
			day =
				currentDate.getDate() < 10
					? "0" + currentDate.getDate()
					: currentDate.getDate();
		let previousYear = new Date(
			year - 1 + "-" + month + "-" + day + "T00:00:00Z"
		);
		let futureFiveYear = new Date(
			year + 5 + "-" + month + "-" + day + "T23:59:00Z"
		);
		return {
			previousYear,
			futureFiveYear,
		};
	}

	/**
	 * @author DARSHAN
	 * @function fnGetActiveOpportunity
	 * @description function to get Active Opportunities
	 * @param {Array} aPcOppList
	 * @param {Object} oYear
	 */
	fnGetActiveOpportunity(aPcOppList) {
		let oYearData = this.getGeneratedYears();
		let prvYear = oYearData.previousYear;
		let nextYear = oYearData.futureFiveYear;
		let aTempData = $.extend(true, [], aPcOppList);

		//For MSL Exists Sort the Opp Data for Active Opp Data from opp data
		aTempData = this.fnSortDataBasedOnKey(aTempData, "AccountName");

		let aValidationStatus = ["E0001", "E0007"];
		$.each(aTempData, function (index, value) {
			value.ExpectedEnd = value.ExpectedEnd
				? new Date(value.ExpectedEnd)
				: null;
			if (
				value.ExpectedEnd < prvYear ||
				value.ExpectedEnd > nextYear ||
				aValidationStatus.indexOf(value.Status) === -1
			) {
				value.active = 0; // false
			} else {
				value.active = 1; // true
			}
		});
		return aTempData;
	}

	/**
	 * @author DARSHAN
	 * @function fnSortDataBasedOnKey
	 * @description function to sort data
	 * @param {Array} aDataForSort
	 * @param {String} sKey
	 */
	fnSortDataBasedOnKey(dataForSort, sKey) {
		dataForSort.sort(function (current, next) {
			return current[sKey].trim().localeCompare(next[sKey].trim());
		});
		return dataForSort;
	}

	/**
	 * @author DARSHAN
	 * @function fnSetFormatActOppData
	 * @description function to make SLExists and bAdditionalOpp as false for actopp Data
	 * @param {Array} actOppdata
	 * @param {String} sViewName
	 */
	fnSetFormatActOppData(actOppdata, sViewName) {
		if (!actOppdata.length) {
			return [];
		}
		if (!sViewName) {
			for (let i = 0; i < actOppdata.length; i++) {
				let tempOppData = actOppdata[i];
				tempOppData.bAdditionalOpp = false;
				if (
					tempOppData.hasOwnProperty("bUIMainOppChange") &&
					tempOppData.bUIMainOppChange
				) {
					tempOppData.bUIMainOppChange = false;
				}
			}
		}
		return actOppdata;
	}

	/**
	 * @author DARSHAN
	 * @function fnGetDialogUsingId
	 * @description function to get Dialog with ID
	 * @param dialogId - String-Control-Id
	 * @param contentId - String-Control-Id
	 */
	fnGetDialogUsingId(dialogId, contentId) {
		return sap.ui.core.Fragment.byId(dialogId, contentId);
	}

	/**
	 * @author DARSHAN
	 * @function fnSetFormatOpportunityTeamData
	 * @description function to format and set the opportunity team data based on Opportunity Selected
	 * @param {Array} response
	 */
	fnSetFormatOpportunityTeamData(response) {
		if (!response || !response.length) {
			return [];
		}
		let opportunityTeamData = [];
		for (let i = 0; i < response.length; i++) {
			let partiesInvolved = response[i];
			if (partiesInvolved.USER_ID && partiesInvolved.EMAIL) {
				let teamObj = {
					ROLE: partiesInvolved.ROLE ? partiesInvolved.ROLE : "",
					ROLE_DESC: partiesInvolved.ROLE_DESCR
						? partiesInvolved.ROLE_DESCR
						: "",
					ID: partiesInvolved.USER_ID ? partiesInvolved.USER_ID : "",
					NAME: partiesInvolved.NAME ? partiesInvolved.NAME : "",
					PhoneNumber: partiesInvolved.TELEPHONE_NUMBER
						? partiesInvolved.TELEPHONE_NUMBER
						: "",
					MobileNumber: partiesInvolved.MOBILE_NUMBER
						? partiesInvolved.MOBILE_NUMBER
						: "",
					EMAIL: partiesInvolved.EMAIL ? partiesInvolved.EMAIL : "",
				};
				opportunityTeamData.push(teamObj);
			}
			if (partiesInvolved.ROLE === Actions.ZOZOPA01) {
				let accountOwner = {
					ID: partiesInvolved.USER_ID,
					NAME: partiesInvolved.NAME,
					EMAIL: partiesInvolved.EMAIL,
					ROLE: partiesInvolved.ROLE,
					ROLE_DESC: partiesInvolved.ROLE_DESCR,
				};
				// defaultModel.setProperty(
				// 	"/selectedOpportunityTeam/ACCOUNT_OWNER",
				// 	accountOwner
				// );
			}
		}
		return opportunityTeamData;
	}
}
