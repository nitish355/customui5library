import Filter from "sap/ui/model/Filter";
import * as BaseObject from "sap/ui/base/Object";
import FilterOperator from "sap/ui/model/FilterOperator";
import JSONModel from "sap/ui/model/json/JSONModel";
import Actions from "com/melodylib/integration/enum/Actions";
import OpportunityService from "com/melodylib/integration/service/OpportunityService";
import IntergrationLibraryModel from "com/melodylib/integration/model/IntergrationLibraryModel";


/**
 * @name com.melodylib.integration.util.opportunity.VATTeamUtil
 */

export default class VATTeamUtil extends BaseObject {

	constructor() {
		super();
		this.model = this.getModel();
	}

	// Static method to get the instance
	static getInstance() {
		if (!this.instance) {
			this.instance = new VATTeamUtil();
		}
		return this.instance;
	}

	//function to get model
	getModel(data) {
		data = data ? data : {};
		if (!this.model) {
			this.model = new JSONModel(data);
			this.model.setSizeLimit(99999);
		}
		return this.model;
	}

	//Function to link SL to Harmony, Parallel opportunity case //TODO Testing is pending
	fnParallelOpppLinkSlToHarmony(discontinuedOppos) {
		let oThisController = this;
		for (let i = 0; i < discontinuedOppos.length; i++) {
			if (discontinuedOppos[i].Type === "SuccessLine") {
				let SlId = discontinuedOppos[i].ID;
				SlId = SlId.padStart(10, "0");
				let OpportunityId = discontinuedOppos[i].NewOppId;
				OpportunityId = OpportunityId.replace(/^0+/, "");
				setTimeout(function () {
					oThisController.fnLinkSlToHarmony(SlId, OpportunityId);
				});
			}
		}
	}

	//Function to link SL to Harmony, after an SL is created. //TODO Testing is pending
	fnLinkSlToHarmony(SlId, OpportunityId) {
		let slUrl =
			window.location.origin +
			window.location.pathname +
			"#sl-App&/SlDetail?SuccessLineID=" +
			SlId;
		let urlParameters = {
			MODE: "A",
			URL: slUrl,
			ARC_DOC_ID: "",
			ATTACHMENT_TYPE: "",
			OPPT_ID: OpportunityId,
			FILENAME: "Melody SuccessLine",
			DESCRIPTION: "Link to SL Application",
		};

		OpportunityService.getServiceToHandleAttachments(urlParameters)
			.then((oResponse) => { })
			.catch((oError) => { });
	}

	/**
	 * @author RAVI,DARRSHAN
	 * @function fnProvideOppoAccess
	 * @description Automatically add activity team memeber to opportunity VAT team 10/11/2022. Function to set opportunity access for  activity user
	 * @param {Object} oNoAccessUsrs
	 * @param {String} OpportunityId
	 * @param {Function} successFn
	 * @param {Boolean} isInit
	 */
	fnProvideOppoAccess(
		oNoAccessUsrs,
		OpportunityId,
		successFn,
		isInit
	) {
		let length = oNoAccessUsrs.length;
		let selectedNonVATOppData = {};
		//TODO:CHECK MODEL
		// oStorageModel.getProperty("/oSelectedNonVATOppData") || {};
		let nonVATKeysArr = Object.keys(selectedNonVATOppData);

		IntergrationLibraryModel.setProperty("/NoAccessUsers", oNoAccessUsrs);
		IntergrationLibraryModel.setProperty("/VATOpportunity", OpportunityId);
		IntergrationLibraryModel.setProperty(
			"/VATNoAccessUsersLength",
			length
		);
		if (isInit) {
			let usersObj = $.extend(true, [], oNoAccessUsrs);
			IntergrationLibraryModel.setProperty("/InitNoAccessUsers", usersObj);
			IntergrationLibraryModel.setProperty("/oTotalFnCount", 1);
		} else {
			let totalFnCount =
				IntergrationLibraryModel.getProperty("/oTotalFnCount");
			totalFnCount = totalFnCount + 1;
			IntergrationLibraryModel.setProperty(
				"/oTotalFnCount",
				totalFnCount
			);
		}

		//Validation for NON-VAT Opp Data submit
		if (nonVATKeysArr.length) {
			this.fnHandleNonVATOppSubmit(
				oNoAccessUsrs,
				OpportunityId,
				successFn,
				nonVATKeysArr,
				selectedNonVATOppData
			);
		} else {
			this.fnFindSelectedOpportunity(
				oNoAccessUsrs,
				OpportunityId,
				successFn
			);
		}
	}

	/**
	 * @author RAVI,DARRSHAN
	 * @function fnFindSelectedOpportunity
	 * @description function to find the selected Opportunity Data
	 * @param {Object} oNoAccessUsrs
	 * @param {String} OpportunityId
	 * @param {Function} successFn
	 */
	fnFindSelectedOpportunity(
		oNoAccessUsrs,
		OpportunityId,
		successFn
	) {
		let oThisController = this;
		let selectedOpp = {};
		const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
		let pcOpportunities = oStorage.get("pcOpportunities") || [];
		if (pcOpportunities.length) {
			pcOpportunities.filter(function (obj) {
				if (obj.OPPT_ID === OpportunityId) {
					selectedOpp.GUID = obj.GUID;
					selectedOpp.OPPT_ID = obj.OPPT_ID;
					selectedOpp.CHANGED_AT = obj.CHANGED_AT;
					selectedOpp.EXPECT_END = new Date(obj.EXPECT_END);
					IntergrationLibraryModel.setProperty("/OppoID", obj.OPPT_ID);
					IntergrationLibraryModel.setProperty("/OppoOwner", obj.OWNER);
				}
			});
			if (Object.keys(selectedOpp).length) {
				if (!selectedOpp.CHANGED_AT || !selectedOpp.GUID) {
					this.fnGetSelOpportunityData(
						oNoAccessUsrs,
						OpportunityId,
						successFn
					);
				} else {
					IntergrationLibraryModel.setProperty("/OppoLookUp", selectedOpp);
					this.fnSendActTeamUser(
						oNoAccessUsrs,
						OpportunityId,
						successFn,
						0
					);
				}
			} else {
				this.fnGetSelOpportunityData(
					oNoAccessUsrs,
					OpportunityId,
					successFn
				);
			}
		} else {
			this.fnGetSelOpportunityData(oNoAccessUsrs, OpportunityId, successFn);
		}
	}

	/**
	 * @author RAVI,DARRSHAN
	 * @function fnGetSelOpportunityData
	 * @description function to get selected opportunity data
	 * @param {Object} oNoAccessUsrs
	 * @param {String} OpportunityId
	 * @param {Function} successFn
	 */
	fnGetSelOpportunityData(
		oNoAccessUsrs,
		OpportunityId,
		successFn
	) {
		let oThisController = this;
		let OppoLookUp = $.extend(
			true,
			{},
			IntergrationLibraryModel.getProperty("/OppoLookUp")
		);
		if (OppoLookUp[OpportunityId]) {
			this.fnSendActTeamUser(oNoAccessUsrs, OpportunityId, successFn, 0);
		} else {
			let oOppoFilter = new Filter(
				"OPPT_ID",
				FilterOperator.EQ,
				OpportunityId
			);
			let oUrlParameters = {
				filters: [oOppoFilter],
				urlParameters: {
					$select:
						"CHANGED_AT,EXPECT_END,GUID,OPPT_ID,OWNER_NAME,OWNER_EMPID,OWNER",
				},
			};
			OpportunityService.getOpportunityForVAT(OpportunityId, oUrlParameters)
				.then((oResponse) => {
					let oData = oResponse.data.results[0];
					OppoLookUp[OpportunityId] = oData;
					IntergrationLibraryModel.setProperty("/OppoID", oData.OPPT_ID);
					IntergrationLibraryModel.setProperty("/OppoOwner", oData.OWNER);
					IntergrationLibraryModel.setProperty("/OppoLookUp", oData);
					oThisController.fnSendActTeamUser(
						oNoAccessUsrs,
						OpportunityId,
						successFn,
						0
					);
				})
				.catch((oError) => { });
		}
	}

	/**
	 * @author RAVI,DARRSHAN
	 * @function fnSendActTeamUser
	 * @description function to pass UserID one by one, after opportunity data is available
	 * @param {Object} oNoAccessUsrs - User data
	 * @param {String} OpportunityId  Opportunity Id
	 * @param {Function} successFn  success function
	 * @param {Number} index index
	 */
	fnSendActTeamUser(
		oNoAccessUsrs,
		OpportunityId,
		successFn,
		index
	) {
		let oThisController = this;
		if (oNoAccessUsrs[index]) {
			if (oNoAccessUsrs[index] && !oNoAccessUsrs[index].IsDuplicate) {
				IntergrationLibraryModel.setProperty("/NoAccesUserIndex", index);
				oThisController.getActTeamUserPartnerId(
					oNoAccessUsrs[index],
					OpportunityId,
					successFn
				);
			} else {
				let length = IntergrationLibraryModel.getProperty(
					"/VATNoAccessUsersLength"
				);
				let NoAccesUserIndex =
					IntergrationLibraryModel.getProperty("/NoAccesUserIndex");
				NoAccesUserIndex = NoAccesUserIndex + 1;
				if (NoAccesUserIndex <= length) {
					let OpportunityId =
						IntergrationLibraryModel.getProperty("/OppoID");
					let NoAccessUsers =
						IntergrationLibraryModel.getProperty("/NoAccessUsers");
					IntergrationLibraryModel.setProperty(
						"/NoAccesUserIndex",
						NoAccesUserIndex
					);
					oThisController.fnSendActTeamUser(
						NoAccessUsers,
						OpportunityId,
						successFn,
						NoAccesUserIndex
					);
				}
			}
		} else {
			oThisController.fnGetUserCRMRole(OpportunityId, successFn);
		}
	}

	/**
	 * @author RAVI,DARRSHAN
	 * @function getActTeamUserPartnerId
	 * @description function to get BP Id of activity team user //TODO FIND SOLUTION FOR METADATA
	 * @param {Object} teamMember
	 * @param {String} OpportunityId
	 * @param {Function} successFn
	 * @param {Object} oParams
	 */
	getActTeamUserPartnerId(
		teamMember,
		OpportunityId,
		successFn,
		oParams
	) {
		let oThisController = this;
		// let bMetadataLoaded = !this.oOppoDataModel.isMetadataLoadingFailed();
		let oBPUsers = $.extend(
			true,
			{},
			IntergrationLibraryModel.getProperty("/BPUsers")
		);
		if (true) {
			let userID = oParams ? oParams.OppoOwner : teamMember.ID;
			let urlParameters = {
				filters: [
					new Filter({
						path: "TYPE",
						operator: "EQ",
						value1: "E",
					}),
				],
				search: userID,
			};
			OpportunityService.getBusinessPartners(
				urlParameters.search,
				urlParameters.filters
			)
				.then((oResponse) => {
					let oData = oResponse.data.results[0];
					if (oParams) {
						let aList = oResponse.data.results || [];
						let oUser = aList.find(function (obj) {
							return obj.PARTNER === oParams.OppoOwner;
						});
						oThisController.fnSaveOppoVATTeamMembers(
							oParams.ActivityId,
							oParams.SlId,
							oParams.ResultData,
							oParams.successfn,
							oUser.USERID
						);
					} else {
						if (oData) {
							teamMember.NAME = oData.NAME;
							teamMember.USERID = teamMember.ID;
							teamMember.ID = oData.PARTNER;
							oBPUsers[teamMember.USERID] = oData;
							IntergrationLibraryModel.setProperty("/BPUsers", oBPUsers);
							oThisController.fnTriggerNextUserBpId(successFn);
						} else {
							//IsDuplicate property is set, for the Users who are no part of Organization.
							teamMember.IsDuplicate = true;
							oBPUsers[teamMember.USERID] = oData;
							IntergrationLibraryModel.setProperty("/BPUsers", oBPUsers);
							oThisController.fnTriggerNextUserBpId(successFn);
						}
					}
				})
				.catch((oError) => { });
		} else {
			successFn("HARMONY_SERVER_DOWN");
		}
	}

	/**
	 * @author RAVI,DARRSHAN
	 * @function fnTriggerNextUserBpId
	 * @description function to find next User's BP ID
	 * @param {Function} successFn
	 */
	fnTriggerNextUserBpId(successFn) {
		let oThisController = this;
		let OpportunityId = IntergrationLibraryModel.getProperty("/OppoID");
		let length = IntergrationLibraryModel.getProperty(
			"/VATNoAccessUsersLength"
		);
		let NoAccesUserIndex =
			IntergrationLibraryModel.getProperty("/NoAccesUserIndex");
		NoAccesUserIndex = NoAccesUserIndex + 1;
		if (NoAccesUserIndex < length) {
			let NoAccessUsers =
				IntergrationLibraryModel.getProperty("/NoAccessUsers");
			IntergrationLibraryModel.setProperty(
				"/NoAccesUserIndex",
				NoAccesUserIndex
			);
			oThisController.fnSendActTeamUser(
				NoAccessUsers,
				OpportunityId,
				successFn,
				NoAccesUserIndex
			);
		} else {
			oThisController.fnGetUserCRMRole(OpportunityId, successFn);
		}
	}

	/**
	 * @author RAVI,DARRSHAN
	 * @function fnGetUserCRMRole
	 * @description function to get User's CRM Role ID and Desc
	 * @param {String} OpportunityId
	 * @param {Function} successFn
	 */
	fnGetUserCRMRole(OpportunityId, successFn) {
		let oThisController = this;
		let aFilter = [];
		let NoAccessUsers = $.extend(
			true,
			[],
			IntergrationLibraryModel.getProperty("/NoAccessUsers")
		);
		for (let i = 0; i < NoAccessUsers.length; i++) {
			if (
				!NoAccessUsers[i].CRMRoleId &&
				!NoAccessUsers[i].CRMRoleDesc &&
				!NoAccessUsers[i].IsDuplicate
			) {
				aFilter.push(new Filter("ID", "EQ", NoAccessUsers[i].USERID));
			}
		}
		if (aFilter.length) {
			let oParams = {
				filters: aFilter,
			};

			OpportunityService.getServiceToUserSearch(oParams)
				.then((oResponse) => {
					let aResponse = oResponse.data.results;
					NoAccessUsers.filter(function (NoUserObj) {
						aResponse.filter(function (obj) {
							if (obj.ID === NoUserObj.USERID) {
								NoUserObj.CRMRoleId = obj.CrmRoleId;
								NoUserObj.CRMRoleDesc = obj.CrmRoleDesc;
							}
						});
					});
					IntergrationLibraryModel.setProperty(
						"/NoAccessUsers",
						NoAccessUsers
					);
					oThisController.fnFormPartiesInvolvedPayload(OpportunityId, successFn);
				})
				.catch((oError) => { });
		} else {
			oThisController.fnFormPartiesInvolvedPayload(OpportunityId, successFn);
		}
	}

	/**
	 * @author RAVI,DARRSHAN
	 * @function fnFormPartiesInvolvedPayload
	 * @description function to form payload to add activity team to opportunity team
	 * @param {String} OpportunityId
	 * @param {Function} successFn
	 */
	fnFormPartiesInvolvedPayload(OpportunityId, successFn) {
		let oThisController = this;
		let oppoData = IntergrationLibraryModel.getProperty("/OppoLookUp");
		let oUsers = IntergrationLibraryModel.getProperty("/NoAccessUsers");
		let oPartiesInvolved = [];
		for (let i = 0; i < oUsers.length; i++) {
			if (!oUsers[i].IsDuplicate) {
				let obj = {
					ADDRESS: "",
					COUNTRY: "",
					EMAIL: oUsers[i].EMAIL,
					ID: oUsers[i].ID,
					IS_EDITABLE: "",
					MODE: "A",
					MAINPARTNER: false,
					NAME: oUsers[i].NAME,
					PARTY_TYPE: "EMPLOYEE",
					ROLE: oUsers[i].CRMRoleId,
					ROLE_DESCR: oUsers[i].CRMRoleDesc,
					WEBSITE: "",
				};
				oPartiesInvolved.push(obj);
			}
		}
		oppoData.PartiesInvolved = oPartiesInvolved;
		// oStorageModel.setProperty("/aNonVATTeam", oPartiesInvolved);
		//clearing NON-VAT Data for the next cycle of selection
		OpportunityService.getServiceToPostOpportunityData(oppoData)
			.then((oResponse) => {
				successFn();
			})
			.catch((oError) => {
				successFn("HARMONY_SERVER_DOWN", oError);
			});
	}

	/**
	 * @author RAVI,DARRSHAN
	 * @function fnGetOpportunityOwner
	 * @description function to get Opportunity Owner
	 * @param {String} ActivityId for ActivityId
	 * @param {String} SlId for  SlId
	 * @param {Object} ResultData for ResultData
	 * @param {Function} successFn for successFn
	 */
	fnGetOpportunityOwner(
		ActivityId,
		SlId,
		ResultData,
		successfn
	) {
		let OppoOwner = IntergrationLibraryModel.getProperty("/OppoOwner");
		let oTempObj = {
			SlId: SlId,
			OppoOwner: OppoOwner,
			successfn: successfn,
			ActivityId: ActivityId,
			ResultData: ResultData,
		};
		if (OppoOwner) {
			this.getActTeamUserPartnerId("", "", "", oTempObj);
		} else {
			//Error message Owner BP ID is not available
		}
	}

	/**
	 * @author RAVI,DARRSHAN
	 * @function fnSaveOppoVATTeamMembers
	 * @description function to save VAT team addes users for email notification
	 * @param {String} ActivityId
	 * @param {String} SlId
	 * @param {Object} ResultData
	 * @param {Object} OppoOwner
	 */
	fnSaveOppoVATTeamMembers(
		ActivityId,
		SlId,
		ResultData,
		successfn,
		OppoOwner
	) {
		let oTempArr = [];
		let OppoID = IntergrationLibraryModel.getProperty("/OppoID");
		let oNoAccessUsrs =
			IntergrationLibraryModel.getProperty("/InitNoAccessUsers");
		for (let i = 0; i < oNoAccessUsrs.length; i++) {
			if (!oNoAccessUsrs[i]["IsDuplicate"]) {
				let oTempObj = {
					SlId: SlId,
					OppOwnerId: OppoOwner,
					ActivityId: ActivityId,
					OpportunityId: OppoID,
					UserId: oNoAccessUsrs[i]["ID"],
					UserAddedAt: new Date().toJSON().split(".")[0] + "Z",
				};
				oTempArr.push(oTempObj);
			}
		}
		let oPayload = {
			to_team: oTempArr,
			OpportunityId: OppoID,
		};
		OpportunityService.getServiceToSaveOppVAT(oPayload)
			.then((oResponse) => {
				successfn(ResultData);
			})
			.catch(() => {
				successfn(ResultData, true);
			});
	}

	/**
	 * @author RAVI,DARRSHAN
	 * @function
	 * @description function to set selected Opp for VAT TEAM Submit
	 * @param {Object} selectedOpp
	 * @param {Object} obj
	 */
	fnSetSelectedOppDataForVATTeam(selectedOpp, obj) {
		selectedOpp.GUID = obj.Guid;
		selectedOpp.OPPT_ID = obj.OpportunityId;
		selectedOpp.CHANGED_AT = obj.ChangedAt;
		selectedOpp.EXPECT_END = new Date(obj.ExpectedEnd);
		return selectedOpp;
	}

	/**
	 * @author DARRSHAN
	 * @function
	 * @description function to handle NON-VAT Opportunity Submit
	 * @param {Object} oNoAccessUsrs
	 * @param {String} OpportunityId
	 * @param {Function} successFn
	 * @param {Array} aNonVATKeys
	 * @param {Object} oSelectedNonVATOppData
	 */
	fnHandleNonVATOppSubmit(
		oNoAccessUsrs,
		OpportunityId,
		successFn,
		aNonVATKeys,
		oSelectedNonVATOppData
	) {
		let selectedOpp = {};
		let validationCount = 0;
		let aValidationKeys = [
			"Guid",
			"OpportunityId",
			"ChangedAt",
			"ExpectedEnd",
			"Owner",
		];
		aValidationKeys.map((keys) => {
			if (aNonVATKeys.indexOf(keys) !== -1) {
				validationCount += 1;
			}
		});
		if (validationCount === aValidationKeys.length) {
			selectedOpp = this.fnSetSelectedOppDataForVATTeam(
				selectedOpp,
				oSelectedNonVATOppData
			);
			IntergrationLibraryModel.setProperty(
				"/OppoID",
				oSelectedNonVATOppData.OpportunityId
			);
			IntergrationLibraryModel.setProperty(
				"/OppoOwner",
				oSelectedNonVATOppData.Owner
			);
			IntergrationLibraryModel.setProperty("/OppoLookUp", selectedOpp);
			this.fnSendActTeamUser(oNoAccessUsrs, OpportunityId, successFn, 0);
		} else {
			//TO BE DISCUSSED //TODO
		}
	}
}