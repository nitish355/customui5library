import Filter from "sap/ui/model/Filter";
import Fragment from "sap/ui/core/Fragment";
import * as BaseObject from "sap/ui/base/Object";
import JSONModel from "sap/ui/model/json/JSONModel";
import FilterOperator from "sap/ui/model/FilterOperator";
import IndexedDB from "com/melodylib/core/db/IndexedDB";
import AuthState from "com/melodylib/core/state/AuthState";
import UserUtil from "com/melodylib/core/util/user/UserUtil";
import Actions from "com/melodylib/integration/enum/Actions";
import CoreLibraryModel from "com/melodylib/core/model/CoreLibraryModel";
import VATTeam from "com/melodylib/integration/util/opportunity/VATTeamUtil";
import OpportunityService from "com/melodylib/integration/service/OpportunityService";
import IntergrationLibraryModel from "com/melodylib/integration/model/IntergrationLibraryModel";
import Opportunity from "com/melodylib/integration/classes/opportunity/Opportunity";
import OpportunityHelper from "com/melodylib/integration/util/opportunity/OpportunityHelper";
import OpportunityDialogController from "com/melodylib/integration/util/opportunity/OpportunityDialogController";
import CPIService from "com/melodylib/core/service/CPIService"

/**
 * @name com.melodylib.integration.util.opportunity.OpportunityUtil
 */

//const OpportunityUtility = {
class OpportunityUtility extends BaseObject {
	static instance = null;
	constructor(parentref) {
		super();
		if (parentref) {
			this.parentCtrl = parentref;
		}
		this.UserUtil = UserUtil.getInstance();
		this.AuthState = AuthState.getInstance();
	}

	// Static method to get the instance
	static getInstance(parentref) {
		if (!this.instance) {
			this.instance = new OpportunityUtility(parentref);
		}
		return this.instance;
	}

	/**
	 * @author DARSHAN
	 * @async
	 * @function getStatus
	 * @description function to get Opportunity Status
	 * @return {Promise<string>} The data from the URL. || {Array}
	 * @public
	 */
	async getStatus() {
		let oppStatus =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "myopportunity-data",
				storeName: "opportunitystore",
				keyName: "pcoppstatusmasterdata",
			})) || {};
		if (
			(oppStatus instanceof Object && !Object.keys(oppStatus).length) ||
			!oppStatus.length
		) {
			oppStatus = await this.getAppValueHelps("status");
		}
		return oppStatus;
	}

	/**
	 * @author DARSHAN
	 * @async
	 * @function getPhases
	 * @description function to get Opportunity Phases
	 * @return {Promise<string>} The data from the URL. || {Array}
	 * @public
	 */
	async getPhases() {
		let oppPhases =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "myopportunity-data",
				storeName: "opportunitystore",
				keyName: "pcoppphasemasterdata",
			})) || {};
		if (
			(oppPhases instanceof Object && !Object.keys(oppPhases).length) ||
			!oppPhases.length
		) {
			oppPhases = await this.getAppValueHelps("phase");
		}
		return oppPhases;
	}

	/**
	 * @author DARSHAN
	 * @async
	 * @function getAppValueHelps
	 * @description function to fetch Opportunity status Phases
	 * @return {Promise<string>} The data from the URL. || {Array}
	 * @public
	 */
	async getAppValueHelps(masterdataType) {
		let appPath = "com.test.mtapocappui".replaceAll(".", "/");
		let appModulePath = jQuery.sap.getModulePath(appPath);
		let oppStatus =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "myopportunity-data",
				storeName: "opportunitystore",
				keyName: "pcoppstatusmasterdata",
			})) || {};
		let oppPhases =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "myopportunity-data",
				storeName: "opportunitystore",
				keyName: "pcoppphasemasterdata",
			})) || {};

		//Check for Opp phase and status
		let bAppValueValidated = this.getAppValueHelpValidation(
			oppPhases,
			oppStatus
		);

		if (bAppValueValidated) {
			return {
				oppPhases,
				oppStatus,
			};
		}

		let sFilter =
			"?$filter=(ENTITY_NAME eq 'OPPORTUNITY' and (FIELD_NAME eq 'STATUS' or FIELD_NAME eq 'PHASE'))";
		let sFinalURL = `${appModulePath}/ext_harmony_btp/v2/appvalues/AppValueHelps`;
		// sFinalURL = sFinalURL + sFilter;
		// $.ajax({
		// 	url: sFinalURL,
		// 	method: "GET",
		// 	async: false,
		// 	contentType: "application/json",
		// 	success: function (oResponse) {
		// 		// console.log(oResponse);
		// 		let aResults = oResponse.d.results || [];
		// 		const oStatusMasterDataMap = {},
		// 			oPhaseMasterDataMap = {};
		// 		aResults.forEach(function (status) {
		// 			switch (status.FIELD_NAME) {
		// 				case "STATUS":
		// 					oStatusMasterDataMap[status.KEY] = status;
		// 					break;
		// 				case "PHASE":
		// 					oPhaseMasterDataMap[status.KEY] = status;
		// 					break;
		// 				default:
		// 					break;
		// 			}
		// 		});
		// 		storage.put("pcOppStatusMasterMap", oStatusMasterDataMap);
		// 		storage.put("pcOppPhaseMasterMap", oPhaseMasterDataMap);
		// 	},
		// 	error: function (oError) {
		// 		jQuery.sap.log(oError);
		// 	},
		// });
		const oResult = await OpportunityService.getAppValueHelps();
		const oData = oResult.data;
		const oStatusMasterDataMap = {},
			oPhaseMasterDataMap = {};

		oData.results.forEach(function (status) {
			switch (status.FIELD_NAME) {
				case "STATUS":
					oStatusMasterDataMap[status.KEY] = status;
					break;
				case "PHASE":
					oPhaseMasterDataMap[status.KEY] = status;
					break;
				default:
					break;
			}
		});
		IndexedDB.fnInsertDataToDB({
			dbName: "myopportunity-data",
			storeName: "opportunitystore",
			keyName: "pcoppstatusmasterdata",
			aObjectsToInsert: oStatusMasterDataMap,
		});
		IndexedDB.fnInsertDataToDB({
			dbName: "myopportunity-data",
			storeName: "opportunitystore",
			keyName: "pcoppphasemasterdata",
			aObjectsToInsert: oPhaseMasterDataMap,
		});
		if (masterdataType === "status") {
			return oStatusMasterDataMap;
		}

		if (masterdataType === "phase") {
			return oPhaseMasterDataMap;
		}
	}

	/**
	 * @author DARSHAN
	 * @async
	 * @function getAppValueHelpValidation
	 * @description function to validate app value help data
	 * @public
	 */
	getAppValueHelpValidation(oppPhases, oppStatus) {
		let bPhaseValidate = false;
		let bStatusValidate = false;
		if (
			(oppPhases &&
				oppPhases instanceof Object &&
				Object.keys(oppPhases).length) ||
			(oppPhases && oppPhases instanceof Array && oppPhases.length)
		) {
			bPhaseValidate = true;
		}

		if (
			(oppStatus &&
				oppStatus instanceof Object &&
				Object.keys(oppStatus).length) ||
			(oppStatus && oppStatus instanceof Array && oppStatus.length)
		) {
			bStatusValidate = true;
		}
		return bPhaseValidate && bStatusValidate;
	}

	/**
	 * @author DARSHAN
	 * @async
	 * @function getUserDetail
	 * @description function to fetch user data
	 * @return {Promise<string>} The data from the URL. || {Object}
	 * NEED TO REMOVE THIS
	 * @public
	 */
	async getUserDetail() {
		const oResult = await OpportunityService.getUserDetail();
		return oResult.data.results[0];
	}

	/**
	 * @author DARSHAN
	 * @async
	 * @function getBusinessPartner
	 * @description function to fetch user BP using user-id
	 * @return {Promise<string>} The data from the URL. || {Object}
	 * @param {String} userId for BPID
	 * @public
	 */
	async getBusinessPartner(userId) {
		const storage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
		let userData = CoreLibraryModel.getProperty("/oUserData") || false;
		let partnerId;
		if (!userData) {
			userData = await this.UserUtil.authenticate();
		}
		if (userId || userData) {
			userId = userId
				? userId
				: userData.UserId
				? userData.UserId
				: userData.id;
			const filters = [new Filter("TYPE", FilterOperator.EQ, "E")];
			const result = await OpportunityService.getBusinessPartners(
				userId,
				filters
			);
			const data = result?.data;
			partnerId = data?.results[0]?.PARTNER;
			storage.put("PartnerId", partnerId);
		}
		return partnerId;
	}

	/**
	 * @author BALWANT,DARSHAN
	 * @async
	 * @function getAllOpportunities
	 * @description function to fetch default Opportunities
	 * @return {Promise<string>} The data from the URL. || {Array}
	 * @param {Object} mParameters for All Opportunity Data
	 * @public
	 */
	async getAllOpportunities(mParameters) {
		const batches = [];
		const storage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
		let oppStatusMasterMap =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "myopportunity-data",
				storeName: "opportunitystore",
				keyName: "pcoppstatusmasterdata",
			})) || {};
		let oppPhaseMasterMap =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "myopportunity-data",
				storeName: "opportunitystore",
				keyName: "pcoppphasemasterdata",
			})) || {};
		let partnerId = mParameters ? mParameters.PartnerId : null;
		let isActiveOnly = mParameters ? mParameters.ActiveOnly : null;
		partnerId = storage.get("PartnerId") || false;
		let lastYearCount =
			mParameters && mParameters.LastYearCount
				? parseInt(mParameters.LastYearCount, 10)
				: null;
		try {
			//Check if data present in indexedDB
			let opportunityData = storage.get("myopportunities") || [];

			if (
				opportunityData &&
				opportunityData instanceof Array &&
				opportunityData.length
			) {
				return opportunityData;
			}

			if (!partnerId) {
				partnerId = await this.getBusinessPartner();
			}
			const businessPartnerFilter = new Filter(
				"SALES_TEAM_MEMBER",
				FilterOperator.EQ,
				partnerId
			);
			const statusFilters = [];
			if (isActiveOnly !== false) {
				statusFilters.push(
					new Filter({
						filters: [
							new Filter({
								path: "STATUS",
								operator: FilterOperator.EQ,
								value1: "E0007",
							}),
							new Filter({
								path: "STATUS",
								operator: FilterOperator.EQ,
								value1: "E0001",
							}),
						],
						and: false,
					})
				);
			}

			if (lastYearCount) {
				let currentYear = new Date().getFullYear();
				currentYear = currentYear - 1;
				for (let i = 1; i <= lastYearCount; i++) {
					const quarterFilter = new Filter(
						"QUARTER_ID",
						FilterOperator.EQ,
						currentYear + "0"
					);
					const filters = [
						new Filter({
							filters: [businessPartnerFilter, quarterFilter, ...statusFilters],
							and: true,
						}),
					];
					batches.push({
						Filters: filters,
					});
					currentYear++;
				}
			} else {
				const filters = [
					new Filter({
						filters: [businessPartnerFilter, ...statusFilters],
						and: true,
					}),
				];
				batches.push({
					Filters: filters,
					parameters: {
						$select: Actions.GetOpportunityUrlParam.select,
					},
				});
			}
			const result = await OpportunityService.getOpportunities(batches);
			const batchResponses = result.data.__batchResponses;
			let opportunitytData = [];
			for (let i = 0; i < batchResponses.length; i++) {
				if (
					batchResponses[i].data &&
					batchResponses[i].data.hasOwnProperty("results")
				) {
					const batchResult = batchResponses[i].data.results;
					let batchOpportunities = batchResult.map(function (opp) {
						return new Opportunity({
							OpportunityId: opp.OPPT_ID,
							OpportunityName: opp.DESCRIPTION,
							Description: opp.DESCRIPTION,
							AccountId: opp.ACCOUNT,
							AccountName: opp.ACCOUNT_NAME,
							Status: opp.STATUS,
							Phase: opp.CURR_PHASE,
							ExpectedEnd: opp.EXPECT_END,
							ExpectedValue: opp.EXPECTED_VALUE,
							Owner: opp.OWNER,
							OwnerName: opp.OWNER_NAME,
							Industry_MasterCode_Text: opp.INDUSTRY_MASTERCODE_TEXT,
							Industry: opp.INDUSTRY,
							Industry_Text: opp.INDURSTRY_TEXT,
							Sales_Org_Desc: opp.SALES_ORG_TEXT,
							Industry_MasterCode: opp.INDUSTRY_MASTERCODE,
							Guid: opp.GUID,
							ChangedAt: opp.CHANGED_AT,
							StatusDescription:
								Object.keys(oppStatusMasterMap).length && opp.STATUS
									? oppStatusMasterMap[opp.STATUS].VALUE
									: "",
							PhaseValue:
								Object.keys(oppPhaseMasterMap).length && opp.CURR_PHASE
									? oppPhaseMasterMap[opp.CURR_PHASE].VALUE
									: "",
						});
					});
					opportunitytData = opportunitytData.concat(batchOpportunities);
				}
			}

			//removing model object in-case if we want to store opportunity data to storage
			let tempOpptData = opportunitytData.map((opp) => {
				delete opp?.model;
				return {
					...opp,
				};
			});

			//Create Key Pairs of Opportunities
			const opportunitymap = tempOpptData.reduce((oppMap, oppData) => {
				oppMap[oppData.OpportunityId] = oppData;
				return oppMap;
			}, {});

			storage.put("myopportunities", tempOpptData);
			storage.put("myopportunities_map", opportunitymap);

			if (mParameters && mParameters?.isActive) {
				tempOpptData = OpportunityHelper.fnGetActiveOpportunity(
					tempOpptData,
					"",
					mParameters.oYears
				);
				storage.put("myopportunities", tempOpptData);
			}

			return tempOpptData;
		} catch (error) {
			console.log("getAllOpportunities :", error);
		}
	}

	/**
	 * @author BALWANT,DARSHAN
	 * @async
	 * @function searchOpportunities
	 * @description Function to search Opportunity with <b>AccountId/AccountDesc/OppoId/OppoDesc<b/>
	 * @return {Promise<string>} The data from the URL. || {Array}
	 * @param {Object} parameters for All Opportunity Data
	 * @public
	 */
	async searchOpportunities(parameters) {
		let url = parameters.Url;
		const mParameters = this.fnGetServiceParameters(parameters);
		const result = await OpportunityService.searchOpportunities(
			url,
			mParameters
		);
		return result.data.results;
	}

	/**
	 * @author BALWANT,DARSHAN
	 * @async
	 * @function searchOpportunities
	 * @description Function to get Opportunity details //TODO: check this function
	 * @return {Promise<string>} The data from the URL. || {Array}
	 * @param {Object} parameters for All Opportunity Data
	 * @public
	 */
	async fnGetOpportunitiesDetails(parameters) {
		const batches = [];
		let url = parameters.Url;
		const opportunityIds = parameters.OpportunityIds;
		for (let i = 0; i < opportunityIds.length; i++) {
			const mParameters = this.fnGetServiceParameters(parameters);
			batches.push({
				type: "read",
				parameters: mParameters,
				url: url + "('" + opportunityIds[i] + "')",
			});
		}
		console.log("Before call");
		this.UserUtil._service.models.harmony.setUseBatch(true);
		let result = await OpportunityService.fnGetOpportunitiesDetails(
			url,
			batches
		);
		result = this.fnProcessBatchResponses(result);
		return result;
	}

	/**
	 * @author BALWANT
	 * @function fnGetServiceParameters
	 * @description Function to form service parameters
	 * @return {Object} The parameters data for the URL.
	 * @param {Object} parameters for All Opportunity Data
	 * @public
	 */
	fnGetServiceParameters(parameters) {
		let urlParameters = {};
		let selectQuery = parameters ? parameters.Select : "";
		selectQuery ? (urlParameters["$select"] = selectQuery) : "";
		let expandEntity = parameters ? parameters.Expand : "";
		expandEntity ? (urlParameters["$expand"] = expandEntity) : "";
		const filters = parameters["Filters"];

		let mParameters = {};
		mParameters.urlParameters = urlParameters;
		filters ? (filters.length ? (mParameters.filters = filters) : "") : "";
		return mParameters;
	}

	/**
	 * @author BALWANT
	 * @function fnProcessBatchResponses
	 * @description Function to process batch responses
	 * @return {Object} The parameters data for the URL.
	 * @param {Object} oResult for Opportunity Data
	 * @public
	 */
	fnProcessBatchResponses(result) {
		let oData = [];
		result = result.data.__batchResponses;
		result.filter(function (obj) {
			oData.push(obj.data);
		});
		return oData;
	}

	/**
	 * @author DARSHAN
	 * @async
	 * @function fnOpportunityValueHelpHandler
	 * @description function to set prerequisites opportunity valuehelp fragment
	 * @return {Promise<string>} {Object}
	 * @public
	 * @param {Object} projectInstanceParam for perform account based filters if any
	 * @param {Function} fnOpenDialogs for open fragment
	 * @param {Function} callback for To call function if any
	 */
	async fnOpportunityValueHelpHandler(
		projectInstanceParam,
		fnOpenDialogs,
		callback
	) {
		let functionResponse = {};
		let activeOppListControl;
		let activeOppListFilters = [];
		const storage = jQuery.sap.storage(jQuery.sap.storage.Type.session);

		let masterOpportunityList = storage.get("myopportunities") || [];
		let masterActiveOpportunityList = storage.get("myactiveopportunity") || [];
		const defaultModel = this.getModel();
		const controlId = this.getId();

		defaultModel.setProperty("/oppSearchValue", "");
		defaultModel.setProperty("/nonvatoppsearchvalue", "");
		defaultModel.setProperty("/NonVatOpportunitiesList", []);
		defaultModel.setProperty(
			"/activeOppDialogDefaultIconTab",
			Actions.oActiveOppTabKeys.active_opportunities
		);

		try {
			if (projectInstanceParam.bOpportunity) {
				defaultModel.getProperty("/isOpptDilogBusy", true);
				if (
					!masterOpportunityList.length &&
					!masterActiveOpportunityList.length
				) {
					defaultModel.setProperty("/Opportunities", []); //clear the data
					functionResponse.opportunityList =
						await this.OpportunityUtil.getAllOpportunities();
					functionResponse.activeOpportunityList =
						this.OpportunityHelper.fnGetActiveOpportunity(
							functionResponse.opportunityList
						);
					storage.put(
						"myactiveopportunity",
						functionResponse.activeOpportunityList
					); //Add to storage
					activeOppListControl = this.OpportunityUtil.fnGetDialogUsingId(
						`${controlId}_ActiveOpportunityDialog`,
						"idActOpptList"
					);

					if (projectInstanceParam.cvaSelected) {
						if (projectInstanceParam.cvaAccountId) {
							let query = projectInstanceParam.cvaAccountId;
							if (query && query.length > 0) {
								let filter = new sap.ui.model.Filter(
									"AccountId",
									sap.ui.model.FilterOperator.EQ,
									query
								);
								activeOppListFilters.push(filter);
							}
						}
					}
					if (activeOppListControl) {
						activeOppListControl
							.getBinding("items")
							.filter(activeOppListFilters);
					}
					defaultModel.setProperty(
						"/ActiveOppDialogFilters",
						activeOppListFilters
					);
					defaultModel.refresh();
				} else {
					//VAT TEAM VALIDATION START HERE

					//VAT TEAM VALIDATION END HERE
					activeOppListControl = this.OpportunityUtil.fnGetDialogUsingId(
						`${controlId}_ActiveOpportunityDialog`,
						"idActOpptList"
					);
					if (projectInstanceParam.projectType === Actions.Actvt) {
						if (
							!masterActiveOpportunityList.length &&
							masterOpportunityList.length
						) {
							masterActiveOpportunityList =
								this.OpportunityHelper.fnGetActiveOpportunity(
									masterOpportunityList
								);
							storage.put("myactiveopportunity", masterActiveOpportunityList);
						}
						functionResponse.activeOpportunityList =
							masterActiveOpportunityList;

						if (projectInstanceParam.cvaSelected) {
							if (projectInstanceParam.cvaAccountId) {
								let query = projectInstanceParam.cvaAccountId;
								if (query && query.length > 0) {
									let filter = new sap.ui.model.Filter(
										"AccountId",
										sap.ui.model.FilterOperator.EQ,
										query
									);
									activeOppListFilters.push(filter);
								}
							}
						}
						defaultModel.setProperty(
							"/ActiveOppDialogFilters",
							activeOppListFilters
						);
						defaultModel.refresh();
					}
				}
				defaultModel.getProperty("/isOpptDilogBusy", true); //NEED TO CHECK THIS
				return functionResponse;
			}
		} catch (error) {
			console.log("fnOpportunityValueHelpHandler: ", error);
			defaultModel.getProperty("/isOpportunityDialogBusy", false);
		}
	}

	/**
	 * @author DARSHAN
	 * @function getOpportunitiesTeam
	 * @description function to get OpportunitiesTeam
	 * @param {string} sOpportunityId for filter
	 * @param {Boolean} selectParam for url $select
	 * @param {Array} filters for comparison
	 */
	async getOpportunitiesTeam(opportunityId, selectParam, filters) {
		let filterData = [];
		if (opportunityId) {
			if (filters && filters.length > 0) {
				filterData = filters;
			}

			let parameters = {
				urlParameters: {
					$select: selectParam
						? selectParam
						: Actions.OpportunityTeamUrlParm.select,
					$expand: Actions.OpportunityTeamUrlParm.expand,
				},
				filters: filterData,
			};
			let oResponse = OpportunityService.getOpportunityTeam(
				opportunityId,
				parameters
			);
			return oResponse;
		}
	}

	/**
	 * @author DARSHAN
	 * @function getOpportunityTeamDetails
	 * @descriptionfunction to get the opportunity team details
	 * @return {Promise<string>}
	 * @param {String} sOpportunityId for opportunity team;
	 */
	async getOpportunityTeamDetails(opportunityId) {
		if (opportunityId) {
			let oResponse = this.getOpportunitiesTeam(
				opportunityId,
				Actions.PartiesInvolved
			);
		} else {
			sap.m.MessageBox.error("Opportunity not found");
		}
	}

	/**
	 * @author DARSHAN
	 * @function fnGetDialogUsingId
	 * @description function to get element from fragment using id
	 * @param1 {String} dialogId
	 * @param2 {String} contentId
	 */
	fnGetDialogUsingId(dialogId, contentId) {
		return sap.ui.core.Fragment.byId(dialogId, contentId);
	}

	/**
	 * @author DARSHAN
	 * @function fnFetchOpportunityData
	 * @description function to fetch the Opportunity Details Based on Opportunity Id:
	 * @param {String} opportunityId
	 */
	async fnFetchOpportunityData(opportunityId) {
		let opportunityData;
		let response = await this.getOpportunitiesTeam(opportunityId);
		let urlConstants =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "harmonyconstanturls",
			})) || [];
		if (response && response?.data) {
			let data = response.data;
			opportunityData = new Opportunity({
				OpportunityId: data.OPPT_ID,
				OpportunityName: data.DESCRIPTION,
				Description: data.DESCRIPTION,
				AccountId: data.ACCOUNT,
				AccountName: data.ACCOUNT_NAME,
				Status: data.STATUS,
				Phase: data.CURR_PHASE,
				ExpectedEnd: data.EXPECT_END,
				ExpectedValue: data.EXPECTED_VALUE,
				Owner: data.OWNER,
				OwnerName: data.OWNER_NAME,
				Industry_MasterCode_Text: data.INDUSTRY_MASTERCODE_TEXT,
				Industry: data.INDUSTRY,
				Industry_Text: data.INDURSTRY_TEXT,
				Sales_Org_Desc: data.SALES_ORG_TEXT,
				Industry_MasterCode: data.INDUSTRY_MASTERCODE,
				Guid: data.GUID,
				ChangedAt: data.CHANGED_AT,
			});
		}
		if (response && response?.data?.PartiesInvolved) {
			opportunityData.opportunityTeamData =
				this.parentCtrl.OpportunityHelper.fnSetFormatOpportunityTeamData(
					response.data.PartiesInvolved.results
				);
			opportunityData.harmonyLink =
				Object.keys(urlConstants).length && urlConstants.hasOwnProperty("0011")
					? urlConstants["0011"].field_value + response.data.OPPT_ID + "/plan"
					: "";
			return opportunityData;
		} else {
			return response;
		}
	}

	/**
	 * @author DARSHAN
	 * @function getConstantData
	 * @description function to get constants
	 */
	async getConstantData() {
		let constants = {};

		let constantsData =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "harmonyconstanturls",
			})) || [];

		constantsData =
			constantsData && constantsData instanceof Array && !constantsData.length
				? {}
				: constantsData;

		if (!Object.keys(constantsData).length) {
			let { data } = await OpportunityService.getConstants();
			let aData = data?.results ?? [];
			for (let index in aData) {
				constants[aData[index].const_id] = aData[index];
			}
			IndexedDB.fnInsertDataToDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "harmonyconstanturls",
				aObjectsToInsert: constants,
			});
			return constants;
		}
		return constantsData;
	}

	/**
	 * @author DARSHAN
	 * @function fnParallelOpppLinkSlToHarmony
	 * @description function to link SL to Harmony, Parallel opportunity case //TODO Testing is pending
	 * @param {Array} discontinuedOppos;
	 */
	fnParallelOpppLinkSlToHarmony(discontinuedOppos) {
		let oThiscontroller = this;
		for (let i = 0; i < discontinuedOppos.length; i++) {
			if (discontinuedOppos[i].Type === "SuccessLine") {
				let slId = discontinuedOppos[i].ID;
				slId = slId.padStart(10, "0");
				let OpportunityId = discontinuedOppos[i].NewOppId;
				OpportunityId = OpportunityId.replace(/^0+/, "");
				setTimeout(function () {
					oThiscontroller.fnLinkSlToHarmony(slId, OpportunityId);
				});
			}
		}
	}

	/**
	 * @author DARSHAN
	 * @function fnLinkSlToHarmony
	 * @description function to link SL to Harmony, after an SL is created. //TODO Testing is pending
	 * @param {String} SlId
	 * @param {String} OpportunityId
	 */
	fnLinkSlToHarmony(SlId, OpportunityId) {
		let slUrl =
			window.location.origin +
			window.location.pathname +
			"#sl-App&/SlDetail?SuccessLineID=" +
			SlId;
		let urlParameters = {
			MODE: "A",
			URL: slUrl,
			ARC_DOC_ID: "",
			ATTACHMENT_TYPE: "",
			OPPT_ID: OpportunityId,
			FILENAME: "Melody SuccessLine",
			DESCRIPTION: "Link to SL Application",
		};

		OpportunityService.getServiceToHandleAttachments(urlParameters)
			.then((oResponse) => {})
			.catch((oError) => {});
	}

	/**
	 * @author DARSHAN
	 * @function fnFormatFilterParamsForNonVat
	 * @description function to format filters & Params for non-vat
	 * @param {Object} params;
	 * @param {String} loadedRecords;
	 * @return {Object} The URL Param data from the URL.
	 */
	fnFormatFilterParamsForNonVat(params, loadedRecords) {
		let filterData = [];
		/**
			 * uncomment this when requried
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let sPartnerId = oStorage.get("PartnerId") || "";
			if (sPartnerId) {
			let oSalesOrg = new Filter({
				path: "SALES_TEAM_MEMBER",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: sPartnerId
			});
			filterData.push(oSalesOrg);
			}
			let oSalesOrg = new Filter({
				path: "SALES_ORG",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: "O 50002557"
			});
			filterData.push(oSalesOrg);
			let aStatus = ["E0001", "E0007", "E0003"];*/
		// let status = ["E0001", "E0007"];
		// let statusFilter = status.map((value) => {
		// 	return new Filter({
		// 		path: "STATUS",
		// 		operator: sap.ui.model.FilterOperator.EQ,
		// 		value1: value,
		// 	});
		// });
		// filterData = filterData.concat(statusFilter);
		/*let aQuater = ["CURR_QTR"];
			let aQuaterFilter = aQuater.map((value) => {
				return new Filter({
					path: "QUARTER_ID",
					operator: sap.ui.model.FilterOperator.NE,
					value1: value
				});
			});*/
		//let quaterFilter = this.fnGenerateQuaterId();
		//Check if it is Opportunity-ID Search for quater-id
		// if (params && "isOppSearch" in params && params.isOppSearch) {
		// 	let allQuater = new Filter({
		// 		path: "QUARTER_ID",
		// 		operator: sap.ui.model.FilterOperator.EQ,
		// 		value1: "99990",
		// 	});
		// 	filterData.push(allQuater);
		// } else {
		// 	filterData = filterData.concat(quaterFilter);
		// }
		/*	let oDisplayAuth = new Filter({
					path: "DISP_AUTH",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: true
				});
				aFilters.push(oDisplayAuth);
				let aForeCast = ["1", "2", "3"];
				let aForeCastFilter = aForeCast.map((value) => {
					return new Filter({
						path: "FORECAST",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: value
					});
				});
				aFilters = aFilters.concat(aForeCastFilter);*/
		let harmonyType = new Filter({
			path: "HARMONY_TYPE",
			operator: sap.ui.model.FilterOperator.EQ,
			value1: "HQ",
		});
		filterData.push(harmonyType);

		/*let newFitler = [
			new Filter({
				filters: filterData,
				and: false,
			}),
		];*/

		if (params && params.filters) {
			filterData = filterData.concat(params.filters);
		}

		let urlParameters = {
			$skip: loadedRecords ? loadedRecords : 0,
			$top: 10,
			$select: Actions.GetOpportunityNonVATListUrlParam.select,
			"search-focus": "ACCOUNT",
			search:
				params && "searchQuery" in params && params.searchQuery
					? `${params.searchQuery}`
					: "",
		};

		return {
			filters: filterData,
			params: urlParameters,
		};
	}

	/**
	 * @author DARSHAN
	 * @async
	 * @function fnFetchNONVATForCVJ
	 * @description function to fetch NON-VAT Opportunity for CVJ
	 * @param1 {Object} params;
	 * @param2 {String} loadedRecords;
	 * @return {Object} The  data from the URL.
	 */
	async fnFetchNONVATForCVJ(params, loadedRecords) {
		const defaultModel = this.parentCtrl.getModel();
		let actualNonvatLoaded =
			defaultModel.getProperty("/iActualNonvatLoaded") || 0;
		let isRequiredTotalCount = defaultModel.getProperty("/bRequiredTotalCount");
		if (!loadedRecords) {
			actualNonvatLoaded = 0;
		}
		let serviceData = this.fnFormatFilterParamsForNonVat(params, loadedRecords);
		let mParameters = {
			filters: serviceData.filters,
			urlParameters: serviceData.params,
		};
		try {
			if (isRequiredTotalCount) {
				let totalCount = await this.fnFetchTotalNonVatCount(mParameters);
				totalCount = totalCount || 0;
				defaultModel.setProperty("/bRequiredTotalCount", false);
				defaultModel.setProperty("/iNonvatTotalCount", Number(totalCount));
				defaultModel.setSizeLimit(99999);
			}
			let results = await this.fnFetchNonVATOppData(mParameters);
			actualNonvatLoaded = 10 + Number(actualNonvatLoaded);
			defaultModel.setProperty("/iActualNonvatLoaded", actualNonvatLoaded);
			defaultModel.refresh();
			return results;
		} catch (error) {
			console.log("NON-VAT ERROR :", error);
		}
	}

	/**
	 * @author DARSHAN
	 * @async
	 * @function fnSetFormatParamsForNonVATOppData
	 * @description function set params to fetch NON-VAT Opportunity Data
	 * @param {Object} params
	 * @param {String} iLoadedRecords
	 * @return {Object} The  data from the URL.
	 */
	async fnSetFormatParamsForNonVATOppData(params, iLoadedRecords) {
		let serviceData = this.fnFormatFilterParamsForNonVat(params);
		let filters = serviceData.filters;
		let parameters = serviceData.params;

		let mParameters = {
			filters: filters,
			urlParameters: parameters,
		};

		try {
			return await this.fnFetchNonVATOppData(mParameters);
		} catch (error) {
			console.log("NON-VAT ERROR :", error);
		}
	}

	/**
	 * @author DARSHAN
	 * @function fnGenerateQuaterId
	 * @description function to generate quater ID for fetching NON-VAT Data
	 * @return {Array} The  data from the URL.
	 */
	fnGenerateQuaterId() {
		let quarter = "";
		let quarterFilter = [];
		let currentYear = new Date().getFullYear();
		currentYear = currentYear - 1;
		for (let i = 1; i <= 7; i++) {
			quarter = currentYear + "0";
			quarterFilter.push(new Filter("QUARTER_ID", FilterOperator.EQ, quarter));
			currentYear++;
		}
		return quarterFilter;
	}

	/**
	 * @author DARSHAN
	 * @async
	 * @function fnFetchTotalNonVatCount
	 * @description function to fetch the total non-vat records count
	 * @param {Object} mParameters
	 * @returns {Number} count for non vat data
	 */
	async fnFetchTotalNonVatCount(mParameters) {
		let urlParam = $.extend(true, {}, mParameters);
		delete urlParam.urlParameters["$skip"];
		delete urlParam.urlParameters["$top"];
		delete urlParam.urlParameters["$select"];
		urlParam.count = "/$count";
		let count = await OpportunityService.getNonVATOpportunityList(urlParam);
		count = count && count.hasOwnProperty("data") ? count.data : 0;
		return count;
	}

	/**
	 * @author DARSHAN
	 * @async
	 * @function fnFetchNonVATOppData
	 * @description function to fetch NON-VAT OPPortunity Data
	 * @param {Object} mParameters;
	 * @return {Promise<string>} The data from the URL.
	 */
	async fnFetchNonVATOppData(mParameters) {
		try {
			let response = await OpportunityService.getNonVATOpportunityList(
				mParameters
			);
			let result =
				response && response?.data && response.data?.results
					? response.data.results
					: [];
			if (result.length) {
				return this.fnSetFormatOpportunityList(result);
			} else {
				return [];
			}
		} catch (error) {
			console.log("NON-VAT ERROR :", error);
		}
	}

	/**
	 * @author DARSHAN
	 * @function fnSetFormatOpportunityList
	 * @description function to format opportunityData for non-vat
	 * @param {Array} responseData;
	 * @returns {Array}
	 */
	async fnSetFormatOpportunityList(responseData) {
		let oppStatusMasterMap =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "myopportunity-data",
				storeName: "opportunitystore",
				keyName: "pcoppstatusmasterdata",
			})) || {};
		let oppPhaseMasterMap =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "myopportunity-data",
				storeName: "opportunitystore",
				keyName: "pcoppphasemasterdata",
			})) || {};
		let opportunityList = responseData.map((opp) => {
			let opportunity = new Opportunity({
				DisplayAuth: opp.DISP_AUTH,
				OpportunityId: opp.OPPT_ID,
				OpportunityName: opp.DESCRIPTION,
				Description: opp.DESCRIPTION,
				AccountId: opp.ACCOUNT,
				AccountName: opp.ACCOUNT_NAME,
				Status: opp.STATUS,
				Phase: opp.CURR_PHASE,
				ExpectedEnd: opp.EXPECT_END,
				ExpectedValue: opp.EXPECTED_VALUE,
				Guid: opp.GUID,
				Owner: opp.OWNER,
				ChangedAt: opp.CHANGED_AT,
				OwnerName: opp.OWNER_NAME,
				Industry_MasterCode_Text: opp.INDUSTRY_MASTERCODE_TEXT,
				Industry: opp.INDUSTRY,
				Industry_Text: opp.INDURSTRY_TEXT,
				Sales_Org_Desc: opp.SALES_ORG_TEXT,
				Industry_MasterCode: opp.INDUSTRY_MASTERCODE,
				StatusDescription:
					Object.keys(oppStatusMasterMap).length && opp.STATUS
						? oppStatusMasterMap[opp.STATUS].VALUE
						: "",
				PhaseValue:
					Object.keys(oppPhaseMasterMap).length && opp.CURR_PHASE
						? oppPhaseMasterMap[opp.CURR_PHASE].VALUE
						: "",
			});
			delete opportunity.model;
			opportunity.active = 1;
			return opportunity;
		});
		return opportunityList;
	}

	/**
	 * @author DARSHAN
	 * @function getTeamMembersBP
	 * @description function to get
	 * @param {aUserIds} Userdata
	 * @returns {Array}
	 */
	async getTeamMembersBP(aUserIds) {
		let aPromises = [];
		let aFilters = [
			new sap.ui.model.Filter({
				path: "TYPE",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: "E",
			}),
		];
		aUserIds.forEach(function (element) {
			aPromises.push(
				OpportunityService.getBusinessPartners(element.userid, aFilters)
			);
		});
		return Promise.all(aPromises);
	}

	/**
	 * @author DARSHAN
	 * @private
	 * @function _getTeamOpportunities
	 * @description function to fetch Opportunities based on users data (Helper Function)
	 * @param {aUserIds} Userdata
	 * @returns {Array}
	 */
	async _getTeamOpportunities(responce) {
		let promises = [];
		let userCount = 2;
		let aResponse = $.extend(true, [], responce);
		let totalRecords = aResponse.length;
		let totalUsers = Math.ceil(totalRecords / userCount);
		let aPromise = [];
		for (let i = 0; i < totalUsers; i++) {
			let parameters;
			let startIndex = i * userCount;
			let endIndex = startIndex + userCount;
			let batchCallRecords = aResponse.slice(startIndex, endIndex);
			let partnerFilter = [];
			let statusFilter = new Filter({
				filters: [
					new Filter({
						path: "STATUS",
						operator: FilterOperator.EQ,
						value1: "E0001",
					}),
					new Filter({
						path: "STATUS",
						operator: FilterOperator.EQ,
						value1: "E0007",
					}),
				],
				bAnd: false,
			});
			batchCallRecords.forEach(function (element) {
				if (element.data.results.length) {
					let partnerIdFilter = new Filter({
						path: "SALES_TEAM_MEMBER",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: element.data.results[0].PARTNER,
					});
					partnerFilter.push(partnerIdFilter);
				}
			});
			parameters = {
				filters: [
					new Filter({
						filters: [
							new Filter({
								filters: partnerFilter,
								bAnd: false,
							}),
							statusFilter,
						],
						bAnd: true,
					}),
				],
				urlParameters: {
					$select: Actions.OpportunityTeamUrlParm.select,
				},
			};
			promises.push(OpportunityService.getOpportunity(parameters));
		}
		return Promise.all(promises);
	}

	/**
	 * @author DARSHAN
	 * @private
	 * @function getTeamOpportunity
	 * @description function to fetch Opportunities based on users data
	 * @param {aUserIds} Userdata
	 * @returns {Array}
	 */
	async getTeamOpportunity() {
		try {
			let loggedInUserData = await this.AuthState.getUser();
			let teamMembersData = (await this.AuthState.getMyTeamMembers()) || [];
			teamMembersData = teamMembersData.filter((userData) => {
				return userData.userid !== loggedInUserData?.id;
			});
			let tempMemberBPData = await this.getTeamMembersBP(teamMembersData);
			let batchCount = 100;
			let bpResponse = $.extend(true, [], tempMemberBPData);
			let totalRecords = bpResponse.length;
			let totalBatches = Math.ceil(totalRecords / batchCount);
			let promises = [];
			for (let i = 0; i < totalBatches; i++) {
				let startIndex = i * batchCount;
				let endIndex = startIndex + batchCount;
				let batchCallRecords = bpResponse.slice(startIndex, endIndex);
				promises.push(this._getTeamOpportunities(batchCallRecords));
			}
			if (promises.length) {
				let responses = (await Promise.allSettled(promises)) || [];
				let tempResult = responses.map((odata) => {
					return odata["value"];
				});
				let oppResponseData = [].concat(...tempResult);
				if (oppResponseData.length) {
					let concatData = [];
					for (let i = 0; i < oppResponseData.length; i++) {
						concatData = concatData.concat(oppResponseData[i].data.results);
					}
					debugger;
				}
			}
		} catch (error) {
			console.log("ERROR IN getTeamOpportunity : ", error);
		}
	}
	async getOppTeamWithOREAccess(oppId) {
			if (oppId) {
				let oOppIdFilter = new Filter("OPPT_ID", FilterOperator.EQ, oppId);
				let oResponse = await CPIService.getOppTeamWithOREAccess([oOppIdFilter])
				return oResponse?.data?.results || [];
			}
		}
}

//EXPORTS
// export const opportunituUil = OpportunityUtility.getInstance();
export default OpportunityUtility;
