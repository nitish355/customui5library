import Filter from "sap/ui/model/Filter";
import Fragment from "sap/ui/core/Fragment";
import * as BaseObject from "sap/ui/base/Object";
import Controller from "sap/ui/core/mvc/Controller";
import FilterOperator from "sap/ui/model/FilterOperator";
import JSONModel from "sap/ui/model/json/JSONModel";
import Actions from "com/melodylib/integration/enum/Actions";
import DateFormat from "sap/ui/core/format/DateFormat";
import formatter from "com/melodylib/integration/model/formatter";
import IndexedDB from "com/melodylib/core/db/IndexedDB";
import ResourceModel from "sap/ui/model/resource/ResourceModel";
import CVA from "com/melodylib/integration/classes/opportunity/CVA";
import OpportunityService from "com/melodylib/integration/service/OpportunityService";
import Opportunity from "com/melodylib/integration/util/opportunity/OpportunityUtil";
import IntegrationLibraryModel from "com/melodylib/integration/model/IntergrationLibraryModel";
import OpportunityHelper from "com/melodylib/integration/util/opportunity/OpportunityHelper";
import DiscontinuedOpportunity from "com/melodylib/integration/util/opportunity/DiscontinuedOpportunity";

/**
 * @name com.melodylib.integration.util.opportunity.OpportunityDialogController
 */

export default class OpportunityDialogController extends Controller {
	/**
	 * @author DARSHAN
	 * @function constructor
	 * @description function to initial Parent this.sef ref to current this.
	 * @public
	 * @param {Object} oParentref for "this" reference
	 */
	constructor(parentref) {
		super();
		if (parentref) {
			this.parentCtrl = parentref;
		}
	}

	/**
	 * @author DARSHAN
	 * @function handleOpportunityClose
	 * @description function to handle after open in active opportunity fragment.
	 * @param {Event} oEvent;
	 */
	onAfterOpenActiveOppDialog(oEvent) {
		let controlId = this.parentCtrl.getId();
		let defaultModel = this.parentCtrl.getModel();
		let activeOppDialogFilters =
			defaultModel?.getProperty("/ActiveOppDialogFilters") || [];
		let activeOppListControl = this.fnGetDialogUsingId(
			`${controlId}_ActiveOpportunityDialog`,
			"idActOpptList"
		);
		if (activeOppListControl) {
			activeOppListControl.getBinding("items").filter(activeOppDialogFilters);
		}
		defaultModel?.refresh();
	}

	/**
	 * @author DARSHAN
	 * @function handleOpportunityClose
	 * @description function to close Opportunity Fragment.
	 * @param {Event} oEvent;
	 * Revisit
	 */
	handleOpportunityClose(oEvent) {
		oEvent.getSource().getBinding("items").filter([]);
	}

	/**
	 * @author DARSHAN
	 * @async
	 * @function onPressOpportunitySelect
	 * @description function to handle select btn in Opportunity/Active Opportunity Fragments.
	 * @param {Event} oEvent;
	 */
	async onPressOpportunitySelect(oEvent) {
		let isNonVATOpportunity = false;
		let selectedOppData;
		const controlId = this.parentCtrl.getId();
		const defaultModel = this.parentCtrl.getModel();
		let sourceId = oEvent.getSource().getId();
		let isActNonVATOppList = sourceId
			? sourceId.includes("idActOpptListNonVat")
			: false; //TO CHECK NON-VAT
		const projectType = this.parentCtrl.getProjectType();
		const selectedItem = oEvent.getParameter("selectedItem");
		defaultModel.setProperty("/isOpportunityDialogBusy", true);
		let urlConstants =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "harmonyconstanturls",
			})) || {};
		let activeOppListControl;
		//TO CHECK NON-VAT
		if (isActNonVATOppList) {
			isNonVATOpportunity = true;
			activeOppListControl = this.fnGetDialogUsingId(
				`${controlId}_ActiveOpportunityDialog`,
				"idActOpptListNonVat"
			);
		} else {
			activeOppListControl = this.fnGetDialogUsingId(
				`${controlId}_ActiveOpportunityDialog`,
				"idActOpptList"
			);
		}

		if (projectType === Actions.Actvt) {
			selectedOppData = oEvent.getSource().getBindingContext().getObject();
			if (activeOppListControl) {
				activeOppListControl.getBinding("items").filter([]);
			}
			this.handleActOpportunityClose();
			defaultModel.setProperty("/selectedOpportunityTeam/SUPPORT", {});
			defaultModel.setProperty(
				"/selectedOpportunityTeam/ACCOUNT_EXECUTIVE",
				{}
			);
		} else {
			const oBindingContext = selectedItem.getBindingContext();
			const sPath = oBindingContext.getPath();
			selectedOppData = defaultModel.getProperty(sPath);
		}

		defaultModel.setProperty("/selectedOpportunity", selectedOppData);
		//create harmony link for selected Opportunity
		selectedOppData.harmonyLink =
			Object.keys(urlConstants).length && urlConstants.hasOwnProperty("0011")
				? urlConstants["0011"].field_value +
				  selectedOppData.OpportunityId +
				  "/plan"
				: "";
		selectedOppData.bNonVATOpportunity = isNonVATOpportunity;
		this.parentCtrl.setSelectedOpportunity(selectedOppData);
		defaultModel.setProperty("/isOpportunityDialogBusy", false);
		defaultModel.refresh();
	}

	/**
	 * @author DARSHAN
	 * @function handleActOpportunityClose
	 * @description function to close active opportunity fragment
	 * @param {Event} oEvent
	 */
	async handleActOpportunityClose(oEvent) {
		const controlId = this.parentCtrl.getId();
		const defaultModel = this.parentCtrl.getModel();
		defaultModel.setProperty(
			"/activeOppDialogDefaultIconTab",
			Actions.oActiveOppTabKeys.active_opportunities
		);
		defaultModel.setProperty("/oFilterParam", "");
		const oActiveOppListControl = this.fnGetDialogUsingId(
			`${controlId}_ActiveOpportunityDialog`,
			"idActOpptList"
		);
		let dialog = await this.parentCtrl._oActOpportunityDialog;
		if (dialog) {
			oActiveOppListControl?.getBinding("items").filter([]);
			dialog.close();
			dialog.destroy();
			this.parentCtrl._oActOpportunityDialog = "";
		}
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function onOppStatusSelectHandler
	 * @description function to handle Opp Status Select
	 * @param {Event} oEvent
	 */
	async onOppStatusSelectHandler(oEvent) {
		let filters = [];
		const controlId = this.parentCtrl.getId();
		const defaultModel = this.parentCtrl.getModel();
		const selectedStatusKey = oEvent.getSource().getSelectedKey();
		const isCvaSelected = defaultModel.getProperty("/isCvaSelected");
		const activeOppListControl = this.fnGetDialogUsingId(
			`${controlId}_ActiveOpportunityDialog`,
			"idActOpptList"
		);
		const selectedAccountData = this.parentCtrl.getAccountFilter() || {};
		let accountId = selectedAccountData?.AccountId
			? selectedAccountData.AccountId
			: "";

		if (isCvaSelected && accountId) {
			filters.push(new sap.ui.model.Filter("AccountId", "EQ", accountId));
		}
		if (selectedStatusKey !== "") {
			filters.push(new sap.ui.model.Filter("active", "EQ", selectedStatusKey));
			activeOppListControl.getBinding("items").filter(filters);
		} else {
			activeOppListControl.getBinding("items").filter(filters);
		}
		defaultModel.setProperty("/oppSearchValue", "");
		defaultModel.refresh();
	}

	/**
	 * @author DARSHAN
	 * @function onActOpportunitySearchHandler
	 * @description function to handle Active Opportunity Search
	 * @param {Event} oEvent
	 */
	onActOpportunitySearchHandler(oEvent) {
		const controlId = this.parentCtrl.getId();
		const defaultModel = this.parentCtrl.getModel();
		const activeOppListControl = this.fnGetDialogUsingId(
			`${controlId}_ActiveOpportunityDialog`,
			"idActOpptList"
		);
		let value = oEvent.getParameter("query");
		let statusSelected =
			defaultModel.getProperty("/oppStatusSelectedKey") || "";
		this.searchOpportunities(activeOppListControl, value, statusSelected);
	}

	/**
	 * @author DARSHAN
	 * @function onOpportunitySearch
	 * @description function to handle opportunity search
	 * @param {Event} oEvent
	 */
	onOpportunitySearch(oEvent) {
		let value = oEvent.getParameter("value");
		let oppListControl = oEvent.getSource();
		this.searchOpportunities(oppListControl, value);
	}

	/**
	 * @author DARSHAN
	 * @function searchOpportunities
	 * @description function to handle opportunity search
	 * @param {Object} oSource - Control
	 * @param {String} sValue
	 * @param {String} sStatus
	 */
	searchOpportunities(oSource, sValue, sStatus) {
		const defaultModel = this.parentCtrl.getModel();
		const isCvaSelected = defaultModel.getProperty("/isCvaSelected");
		const selectedAccountData = this.parentCtrl.getAccountFilter() || {};
		let accountId = selectedAccountData.hasOwnProperty("AccountId")
			? selectedAccountData.AccountId
			: "";

		let opportunityFilters = new Filter({
			filters: [
				new Filter("AccountName", FilterOperator.Contains, sValue),
				new Filter("OpportunityId", FilterOperator.Contains, sValue),
				new Filter("Description", FilterOperator.Contains, sValue),
				new Filter("AccountId", FilterOperator.Contains, sValue),
			],
			and: false,
		});
		if (sStatus) {
			let searchFilter = opportunityFilters;
			let statusFilter = new Filter("active", FilterOperator.EQ, sStatus);
			opportunityFilters = new Filter({
				filters: [searchFilter, statusFilter],
				and: true,
			});
		}
		if (isCvaSelected && accountId) {
			let searchFilter1 = opportunityFilters;
			let accountFilter = new Filter("AccountId", FilterOperator.EQ, accountId);
			opportunityFilters = new Filter({
				filters: [searchFilter1, accountFilter],
				and: true,
			});
		}
		if (oSource) {
			let binding = oSource.getBinding("items");
			binding.filter([opportunityFilters]);
		}
	}

	/**
	 * @author DARSHAN
	 * @function fnGetDialogUsingId
	 * @description function to get element from fragment using id
	 * @param {String} dialogId for Control-ID
	 * @param {String} contentId for Control-Id
	 */
	fnGetDialogUsingId(dialogId, contentId) {
		return sap.ui.core.Fragment.byId(dialogId, contentId);
	}

	/**
	 * @author DARSHAN
	 * @function onNavToCRM
	 * @description function to handle navigation in Opportunity Information Popup
	 */
	async onNavToCRM() {
		const defaultModel = this.parentCtrl.getModel();
		let oConstants =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "harmonyconstanturls",
			})) || {};
		let selectedOppData = $.extend(
			true,
			{},
			defaultModel.getProperty("/selectedOpportunity")
		);
		window.open(
			oConstants["0011"]?.field_value + selectedOppData.OpportunityId + "/plan",
			"_blank"
		);
	}

	/**
	 * @author DARSHAN
	 * @function onCloseOppInfo
	 * @description function to close Opportunity Info
	 * @param {Event} oEvent
	 */
	async onCloseOppInfo(oEvent) {
		let dialog = await this.parentCtrl._oOpportunityInfoDialog;
		if (dialog) {
			dialog.close();
			dialog.destroy();
			this.parentCtrl._oOpportunityInfoDialog = "";
		}
	}

	/**
	 * @author DARSHAN
	 * @function getOpportunityStatus
	 * @description function to get status value based on status-ID
	 * @param {String} StatusId
	 */
	async getOpportunityStatus(StatusId) {
		let oppStatus =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "myopportunity-data",
				storeName: "opportunitystore",
				keyName: "pcoppstatusmasterdata",
			})) || {};
		if (Object.keys(oppStatus).length) {
			return oppStatus[StatusId].VALUE;
		} else {
			return StatusId;
		}
	}

	/**
	 * @author DARSHAN
	 * @function getOpportunityDate
	 * @description function to formate Opportunity Date
	 * @param {String} date
	 */
	getOpportunityDate(date) {
		let dateFormat = DateFormat.getDateInstance({
			style: "medium",
		});
		if (date && date !== null && date !== "") {
			date = new Date(date);
			return dateFormat.format(date);
		} else {
			return null;
		}
	}

	/**
	 * @author DARSHAN
	 * @function fnCheckEmpty
	 * @description function to check value empty
	 * @param {String} value
	 */
	fnCheckEmpty(value) {
		if (value && value !== "") {
			return value;
		} else {
			return "Unavailable";
		}
	}

	/**
	 * @author DARSHAN
	 * @function onSelectOpportunityTab
	 * @description function to handle icon tabs in active opportunities fragment
	 * @param {Event} oEvent
	 */
	onSelectOpportunityTab(oEvent) {
		let mParameters = "";
		let oThisController = this;
		let defaultModel = this.parentCtrl.getModel();
		let selectedKey = oEvent.getParameter("selectedKey");
		const OpportunityUtil = this.parentCtrl.OpportunityUtil;
		const OpportunityHelper = this.parentCtrl.OpportunityHelper;
		const accountFilterData = this.parentCtrl.getAccountFilter() || {};
		let nonVatOpportunitiesList =
			defaultModel.getProperty("/NonVatOpportunitiesList") || [];
		let bRequiredTotalCount = true;
		switch (selectedKey) {
			case Actions.oActiveOppTabKeys.active_opportunities:
				defaultModel.setProperty("/oppSearchValue", "");
				break;
			case Actions.oActiveOppTabKeys.nonvat_opportunity_list:
				defaultModel.setProperty("/nonvatoppsearchvalue", "");
				//If data available dont make service calls
				if (nonVatOpportunitiesList.length) {
					return;
				}

				//If account Data is present
				let accountFilter = this.fnAddAccountIdFilterToNONVat();
				if (accountFilter) {
					mParameters = {
						filters: [accountFilter],
					};
					defaultModel.setProperty("/oFilterParam", mParameters);
				} else {
					defaultModel.setProperty("/oFilterParam", "");
				}

				defaultModel.setProperty("/NonVatOpportunitiesList", []);
				defaultModel.setProperty("/isOpptNonVATListTabBusy", true);
				defaultModel.setProperty("/bNONVatLoadMoreBtnVisible", false);
				defaultModel.setProperty("/bRequiredTotalCount", bRequiredTotalCount);
				OpportunityUtil.fnFetchNONVATForCVJ(mParameters).then((results) => {
					results =
						results && results.length
							? oThisController.fnFilterActiveOppFromNonVatOpp(results)
							: [];
					defaultModel.setProperty("/iNonvatLoaded", results.length);
					defaultModel.setProperty("/NonVatOpportunitiesList", results);
					defaultModel.setProperty("/isOpptNonVATListTabBusy", false);
					defaultModel.refresh();
				});
				break;
			default:
		}
	}

	/**
	 * @author DARSHAN
	 * @function onNonVATOpportunitySearchHandler
	 * @description function to handle NON-VAT Opportunity Fitler
	 * @param {Event} oEvent
	 */
	onNonVATOpportunitySearchHandler(oEvent) {
		let aFilters = [];
		let mParameters = "";
		let searchFilter = "";
		let oThisController = this;
		let isOpportunityId = false;
		let defaultModel = this.parentCtrl.getModel();
		let searchQuery = oEvent.getParameter("query") || "";
		const OpportunityUtil = this.parentCtrl.OpportunityUtil;
		const OpportunityHelper = this.parentCtrl.OpportunityHelper;
		defaultModel.setProperty("/isOpptNonVATListTabBusy", true);
		defaultModel.setProperty("/bRequiredTotalCount", true);

		//Account Based Opportunity Scenario
		let accountFilter = this.fnAddAccountIdFilterToNONVat();
		if (accountFilter) {
			aFilters.push(accountFilter);
		}

		searchQuery = searchQuery.trim();
		if (searchQuery) {
			let numberRegEx = /^[0-9]+$/;
			isOpportunityId = numberRegEx.test(searchQuery);
			//Only Opportunity-ID
			if (isOpportunityId) {
				aFilters.push(
					new Filter({
						path: "OPPT_ID",
						// operator: sap.ui.model.FilterOperator.Contains,
						operator: sap.ui.model.FilterOperator.EQ,
						value1: searchQuery,
					})
				);
			}
		}

		if (aFilters.length) {
			searchFilter = new Filter({
				filters: aFilters,
				and: true,
			});
		}
		mParameters = {
			filters: searchFilter,
			isOppSearch: isOpportunityId,
			searchQuery: !isOpportunityId && searchQuery ? searchQuery : "",
		};

		defaultModel.setProperty("/oFilterParam", mParameters);
		defaultModel.setProperty("/NonVatOpportunitiesList", []);
		OpportunityUtil.fnFetchNONVATForCVJ(mParameters).then((results) => {
			results =
				results && results instanceof Array
					? oThisController.fnFilterActiveOppFromNonVatOpp(results)
					: [];
			defaultModel.setProperty("/iNonvatLoaded", results.length);
			defaultModel.setProperty("/NonVatOpportunitiesList", results);
			defaultModel.setProperty("/isOpptNonVATListTabBusy", false);
			defaultModel.refresh();
		});
	}

	/**
	 * @author DARSHAN
	 * @function onLoadMoreNonVATLib
	 * @description function to handle scroll loadMore for NON-VAT
	 * @param {Event} oEvent
	 */
	async onLoadMoreNonVATLib(oEvent) {
		const controlId = this.parentCtrl.getId();
		let defaultModel = this.parentCtrl.getModel();
		const OpportunityUtil = this.parentCtrl.OpportunityUtil;
		let filterParam = defaultModel.getProperty("/oFilterParam");
		let nonVatOpportunitiesList =
			defaultModel.getProperty("/NonVatOpportunitiesList") || [];
		let iActualNonvatLoaded =
			defaultModel.getProperty("/iActualNonvatLoaded") || 0;
		const OpportunityHelper = this.parentCtrl.OpportunityHelper;
		defaultModel.setProperty("/isOpptNonVATListTabBusy", true);
		let results = await OpportunityUtil.fnFetchNONVATForCVJ(
			filterParam,
			Number(iActualNonvatLoaded)
		);
		let prevNonVatData = $.extend([], true, nonVatOpportunitiesList);
		if (results && !results.length) {
			defaultModel.setProperty("/bNONVatLoadMoreBtnVisible", false);
		}
		results =
			results && results instanceof Array
				? this.fnFilterActiveOppFromNonVatOpp(results)
				: [];
		if (results && results.length) {
			nonVatOpportunitiesList = nonVatOpportunitiesList.concat(results);
			defaultModel.setProperty(
				"/iNonvatLoaded",
				nonVatOpportunitiesList.length
			);
			defaultModel.setProperty(
				"/NonVatOpportunitiesList",
				nonVatOpportunitiesList
			);
		}
		//List Sorting based on display auth
		let navVatList = this.fnGetDialogUsingId(
			`${controlId}_ActiveOpportunityDialog`,
			"idActOpptListNonVat"
		);
		setTimeout(() => {
			if (navVatList) {
				let aListItems = navVatList.getItems() || [];
				if (aListItems.length) {
					let aSortedData = prevNonVatData.filter((oList) => {
						// return oList.getBindingContext().getObject()["DisplayAuth"];
						return oList["DisplayAuth"];
					});
					let focusCount = aSortedData.length + 1;
					navVatList.getItems()[focusCount].focus();
				}
			}
		}, 30);
		defaultModel.setProperty("/isOpptNonVATListTabBusy", false);
		defaultModel.refresh();
	}

	/**
	 * @author DARSHAN
	 * @function fnFilterActiveOppFromNonVatOpp
	 * @description function to filter Active Opportunties in NON-VAT Opportunity
	 * @param {Array} aNonVatOppData  of NON-VAT Data
	 */
	fnFilterActiveOppFromNonVatOpp(nonVatOppData) {
		let nonVatSegregatedData = [];
		let defaultModel = this.parentCtrl.getModel();
		const mtrSettingsModel = sap.ui.getCore().getModel("mtrSettings");
		let activeOpportunity = defaultModel.getProperty("/Opportunities") || [];
		for (let i = 0; i < nonVatOppData.length; i++) {
			let tempNonVatOppData = nonVatOppData[i];
			let nonVatOppId = tempNonVatOppData.OpportunityId;
			if (nonVatOppId) {
				let index = activeOpportunity.findIndex((oOppData) => {
					return oOppData.OpportunityId === nonVatOppId;
				});
				if (index === -1) {
					nonVatSegregatedData.push(tempNonVatOppData);
				}
			}
		}
		this.fnSetNONVATLoadMoreVisibilty(nonVatSegregatedData, defaultModel);
		if (mtrSettingsModel) {
			mtrSettingsModel.setProperty("/aNONVatOppData", nonVatSegregatedData);
			mtrSettingsModel.refresh();
		}
		return nonVatSegregatedData;
	}

	/**
	 * @author DARSHAN
	 * @function fnSetNONVATLoadMoreVisibilty
	 * @description function to handle NON-VAT load more visibilty
	 * @param {Array} aResults
	 */
	fnSetNONVATLoadMoreVisibilty(aResults) {
		let defaultModel = this.parentCtrl.getModel();
		let nonvatTotalCount = defaultModel.getProperty("/iNonvatTotalCount");
		let actualNonvatLoaded =
			defaultModel.getProperty("/iActualNonvatLoaded") || 0;
		if (actualNonvatLoaded < nonvatTotalCount) {
			defaultModel.setProperty("/bNONVatLoadMoreBtnVisible", true);
		} else if (
			actualNonvatLoaded === nonvatTotalCount ||
			nonvatTotalCount < 10
		) {
			defaultModel.setProperty("/bNONVatLoadMoreBtnVisible", false);
		}
		defaultModel.refresh();
	}

	/**
	 * @author DARSHAN
	 * @function fnAddAccountIdFilterToNONVat
	 * @description function to add account id FILTER
	 * @param1 {Boolean}||{String} accountIdArg
	 */
	fnAddAccountIdFilterToNONVat(accountIdArg) {
		let defaultModel = this.parentCtrl.getModel();
		const selectedAccountData = this.parentCtrl.getAccountFilter() || {};
		let accountId = selectedAccountData.hasOwnProperty("AccountId")
			? selectedAccountData.AccountId
			: "";
		//If account Data is present
		if (accountIdArg || accountId) {
			accountId = accountIdArg || accountId;
			let searchFilter = new Filter({
				filters: [
					new Filter({
						path: "ACCOUNT",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: accountId,
					}),
				],
			});
			return searchFilter;
		}
		return false;
	}
}
