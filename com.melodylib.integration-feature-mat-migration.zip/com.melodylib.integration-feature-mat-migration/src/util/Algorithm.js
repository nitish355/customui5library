sap.ui.define(
	["sap/ui/base/Object", "sap/m/MessageToast"],
	function (Object, MessageToast) {
		"use strict";
		var Algorithm = {
			setItem: function (key, value) {
				const oValue = {};
				oValue[key] = value;
				return oValue;
			},

			findItem: function (key, oItems) {
				return oItems[key];
			},

			//function to sort the data using Array.sort
			fnSortArrayData: function (aArrayToSort, sortType, key) {
				if (!sortType) {
					aArrayToSort.sort(function (current, next) {
						return current[sKey].trim().localeCompare(next[sKey].trim());
					});
					return aArrayToSort;
				}

				if (sortType === "descending") {
					aArrayToSort.sort(function (current, next) {
						return next[sKey].trim().localeCompare(current[sKey].trim());
					});
					return aArrayToSort;
				}
			},

			//function to perform quick sort only for Id's //TODO:Need to improve all the cases
			fnQuickSort: function (aArrayToSort, key) {
				if (aArrayToSort.length <= 1) {
					return aArrayToSort;
				}

				const pivotPoint = Number(aArrayToSort[aArrayToSort.length - 1][key]);
				const aLeft = [];
				const aRight = [];
				for (let i = 0; i < aArrayToSort.length - 1; i++) {
					let oTempData = aArrayToSort[i];
					let tempId = Number(oTempData[key]);
					if (tempId < pivotPoint) {
						aLeft.push(oTempData);
					} else {
						aRight.push(oTempData);
					}
				}
				return [
					...quickSort(aLeft, key),
					aArrayToSort[aArrayToSort.length - 1],
					...quickSort(aRight, key),
				];
			},

			//function to perform binary seach only for Id //NOTE: Only sorted array //TODO: Need to improve all the cases
			fnBinarySearch: function (aArrayToFind, target, key) {
				aArrayToFind = this.fnSortArrayData(aArrayToFind, "", key);
				target = Number(target);
				let left = 0;
				let right = aArrayToFind.length - 1;

				while (left <= right) {
					const mid = Math.floor((left + right) / 2);
					if (aArrayToFind[mid][key] === target) {
						return aArrayToFind[mid]; // Found the target
					} else if (aArrayToFind[mid][key] < target) {
						left = mid + 1;
					} else {
						right = mid - 1;
					}
				}
				return -1; // Target not found
			},

			//function to perform batch calls
			fnPerformPromiseInBatch: async function (records, batchCount) {
				let self = this;
				const totalRecords = records.length;
				const totalBatches = Math.ceil(totalRecords / batchCount);
				const aBatches = [];
				try {
					for (let i = 0; i < totalBatches; i++) {
						const startIndex = i * batchCount;
						const endIndex = startIndex + batchCount;
						const batch = records.slice(startIndex, endIndex);
						let aResults = await this.fnProcessBatch(batch);
						const aComnbinedResult = aResults.reduce(
							(combined, result) => combined.concat(result),
							[]
						);
					}
				} catch (error) {
					MessageToast.show("PROMISE BATCH FAILED");
					console.error(error);
				}
			},

			//function promise batch
			fnProcessBatch: async function (data) {
				const results = await Promise.all(data);
				return results;
			},
		};
		return Algorithm;
	}
);
