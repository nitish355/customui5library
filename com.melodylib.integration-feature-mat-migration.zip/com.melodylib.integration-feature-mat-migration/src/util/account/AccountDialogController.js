import Filter from "sap/ui/model/Filter";
import Fragment from "sap/ui/core/Fragment";
import MessageToast from "sap/m/MessageToast";
import JSONModel from "sap/ui/model/json/JSONModel";
import Controller from "sap/ui/core/mvc/Controller";
import ManagedObject from "sap/ui/base/ManagedObject";
import DateFormat from "sap/ui/core/format/DateFormat";
import FilterOperator from "sap/ui/model/FilterOperator";
import Actions from "com/melodylib/integration/enum/Actions";
import ResourceModel from "sap/ui/model/resource/ResourceModel";
import formatter from "com/melodylib/integration/model/formatter";
import Account from "com/melodylib/integration/util/account/AccountUtil";
import AccountService from "com/melodylib/integration/service/AccountService";
import AccountHelper from "com/melodylib/integration/util/account/AccountHelper";
import IntergrationLibraryModel from "com/melodylib/integration/model/IntergrationLibraryModel";

/**
 * @name com.melodylib.integration.util.account.AccountDialogController
 */

export default class DialogController extends Controller {
	constructor(parentref) {
		super();
		this.parentCtrl = parentref;
		this.accountUtil = parentref.accountUtil;
		this.accountHelper = parentref.accountHelper;
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function fnGetDialogUsingId
	 * @description function toget element from fragment using id
	 * @public
	 * @param {string} dialogId
	 * @param {string} contentId
	 */
	fnGetDialogUsingId(dialogId, contentId) {
		return sap.ui.core.Fragment.byId(dialogId, contentId);
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function onPagination
	 * @description function to handle pagiantion
	 * @public
	 * @param {Object} evt
	 */
	onPagination(evt) {
		if (evt.getParameter("reason") === "Filter") {
			this.IsFilter = true;
		}
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function onUpdateFinished
	 * @description function to handle update finished
	 * @public
	 * @param {Object} evt
	 */
	onUpdateFinished(evt) {
		const fetchAdvanceSearch = [];
		const count = evt.getParameter("actual");
		if (evt.getParameter("reason") === "Growing" || (this.IsFilter && count)) {
			if (this.IsFilter && count) {
				this.IsFilter = false;
			}
			if (count && count !== "") {
				const source = evt.getSource();
				const model = this.parentCtrl.getModel();
				const items = source.getAggregation("items");
				for (let i = 0; i < items.length; i++) {
					const bindingContext = items[i].getBindingContext();
					const path = bindingContext.getPath();
					const account = model.getProperty(path);
					if (!account.IsAdvanceSearched) {
						fetchAdvanceSearch.push(account);
					}
				}
			}

			if (fetchAdvanceSearch.length > 0) {
				this._getAdvanceDetails(fetchAdvanceSearch);
			} else {
				this._searching(false);
			}
		}
	}

	_searching(bValue) {
		const model = this.parentCtrl.getModel();
		model.setProperty("/isSimpleSearchAccBusy", bValue);
	}

	/**
	 * @author DARSHAN
	 * @function _getAdvanceDetails
	 * @description function to get advanced account data
	 * @public
	 * @param {Array} accounts
	 */
	_getAdvanceDetails(accounts) {
		const AccountUtil = this.accountUtil;
		const AccountHelper = this.accountHelper;
		accounts = accounts && accounts.length ? accounts : [];
		if (!accounts || accounts.length === 0) {
			const model = this.parentCtrl.getModel();
			accounts = model.getProperty("/SearchedAccounts");
		}

		const filteredAccounts = accounts.filter((item) => {
			return !item.IsAdvanceSearched;
		});

		AccountUtil.getAdvanceDetails(filteredAccounts).then((data) => {
			self._setSearchedAccounts(data);
			self._searching(false);
		});
	}

	/**
	 * @author DARSHAN
	 * @function _setSearchedAccounts
	 * @description function to set advanced account data
	 * @public
	 * @param {Array} accounts
	 */
	_setSearchedAccounts(accounts) {
		const model = this.parentCtrl.getModel();
		const searchedAccounts = model.getProperty("/SearchedAccounts");
		const newAccounts = [];
		for (let i = 0; i < accounts.length; i++) {
			const index = searchedAccounts.findIndex((item) => {
				return item.AccountId.trim() === accounts[i].AccountId.trim();
			});

			if (index !== -1) {
				if (!searchedAccounts[index].IsAdvanceSearched) {
					searchedAccounts[index].setData(accounts[i]);
				}
			} else {
				newAccounts.push(accounts[i]);
			}
		}
		searchedAccounts.push(...newAccounts);
		model.refresh(true);
	}

	/**
	 * @author DARSHAN
	 * @function onCloseAccountSearch
	 * @description function to close the account search dialog
	 * @public
	 * @param {Object} oEvent
	 */
	async onCloseAccountSearch(oEvent) {
		const oDialog = await this.parentCtrl._oAccountDialog;
		if (oDialog) {
			oDialog.close();
			oDialog.destroy();
			this.parentCtrl._oAccountDialog = "";
		}
	}

	/**
	 * @author DARSHAN
	 * @function handleAccountSearch
	 * @description funciton to handle Advance search from AccountAdvancedSearch Fragment
	 * @public
	 * @param {Object} oEvent
	 */
	async handleAccountSearch(oEvent) {
		let accountValue = "";
		let eventType = typeof oEvent;
		if (eventType === "object") {
			accountValue = oEvent.getSource().getValue();
		} else if (eventType === "string") {
			accountValue = oEvent;
		}
		accountValue = accountValue.toLowerCase();
		const AccountUtil = this.accountUtil;
		const AccountHelper = this.accountHelper;
		let accountModel = this.parentCtrl.getModel();
		let selectedIconTabKey = accountModel.getProperty("/selectedIconTabKey");
		if (accountValue.length >= 3) {
			AccountHelper.fnAccountSearchHandler(
				accountValue,
				selectedIconTabKey,
				eventType
			);
		} else if (accountValue === "") {
			this.onClearFilterAdvSearchAccounts();
			accountModel.setProperty("/aMasterAccountData", []);
			accountModel.setProperty("/isMyAccountsCountVisible", true);
			accountModel.setProperty("/sSearchQuery", "");
			AccountHelper.fnSetAccountMasterData(true);
		} else {
			//TODO: Need to check
			MessageToast.show("Please enter minimum of 3 characters to search");
		}
	}

	/**
	 * @author DARSHAN
	 * @function onClearFilterAdvSearchAccounts
	 * @description function to clear filter values in advanced search dialog
	 * @public
	 * @param {Object} oEvent
	 */
	onClearFilterAdvSearchAccounts(oEvent) {
		const AccountUtil = this.accountUtil;
		const AccountHelper = this.accountHelper;
		AccountHelper.fnClearFilterAdvSearchAccounts(oEvent);
	}

	/**
	 * @author DARSHAN
	 * @function onAdvSrchFragFilterChangeHandler
	 * @description function to handle change event of select control from advance search fragment
	 * @public
	 * @param {Object} oEvent
	 */
	onAdvSrchFragFilterChangeHandler(oEvent) {
		const AccountUtil = this.accountUtil;
		const AccountHelper = this.accountHelper;
		AccountHelper.fnFilterAdvSearchAccounts(oEvent);
	}

	/**
	 * @author DARSHAN
	 * @function onSelectAccountData
	 * @description function to handle select btn from advance search dialog
	 * @public
	 * @param {Object} oEvent
	 */
	onSelectAccountData(oEvent) {
		this.onFetchAccountDetails(oEvent);
	}

	/**
	 * @author DARSHAN
	 * @function onFetchAccountDetails
	 * @description function to handle select btn from advance seach and simple search dialog
	 * @public
	 * @param {Object} oEvent
	 * @param {string} searchType
	 */
	async onFetchAccountDetails(oEvent, searchType) {
		let selectedItem = oEvent.getParameter("listItem");
		const AccountUtil = this.accountUtil;
		const AccountHelper = this.accountHelper;
		let accountSearchModel = this.parentCtrl.getModel();
		let selectedAccount = selectedItem?.getBindingContext()?.getObject() || {};
		let accountId = selectedAccount.AccountId;
		let urlConstants = IntergrationLibraryModel.getProperty("/oConstants");
		accountSearchModel.setProperty("/isAccountDialogBusy", true);
		let response = await Promise.all(
			AccountUtil.fnProvideBPAttributeSetSearchAccount({
				bAccountId: true,
				AccountId: accountId,
			})
		);
		let data = response[0].data;
		if (selectedAccount.setBPAttributeSetData instanceof Function) {
			selectedAccount.setBPAttributeSetData(data);
		}
		selectedAccount.harmonyLink =
			urlConstants["0052"].field_value + selectedAccount.AccountId + "/plan";
		AccountHelper.fnFetchAccountDetailHelperFunction(selectedAccount);
		accountSearchModel.refresh();
	}

	/**
	 * @author DARSHAN
	 * @function onNavToCRMwithCvaAccnt
	 * @description function to handle navigation in Account Info Popup
	 * @public
	 */
	onNavToCRMwithCvaAccnt() {
		let accountSearchModel = this.parentCtrl.getModel();
		let constants = IntergrationLibraryModel.getProperty("/oConstants");
		let selectedAccountData = accountSearchModel.getProperty(
			"/oSelectedAccountData"
		);

		window.open(
			constants["0052"].field_value + selectedAccountData.AccountId + "/plan",
			"_blank"
		);
	}

	/**
	 * @author DARSHAN
	 * @function onCloseAccountInfo
	 * @description function to close the Account Info Popup
	 * @public
	 */
	async onCloseAccountInfo() {
		let oDialog = await this.parentCtrl._oAccountInfoDialog;
		if (oDialog) {
			oDialog.close();
			oDialog.destroy();
			this.parentCtrl._oAccountInfoDialog = "";
		}
	}

	/**
	 * @author DARSHAN
	 * @function getOpportunityDate
	 * @description function to formate Opportunity Date
	 * @public
	 * @param {string} date
	 */
	getOpportunityDate(date) {
		let dateFormat = DateFormat.getDateInstance({
			style: "medium",
		});
		if (date && date !== null && date !== "") {
			date = new Date(date);
			return dateFormat.format(date);
		} else {
			return null;
		}
	}

	/**
	 * @author DARSHAN
	 * @function fnCheckEmpty
	 * @description function to check value empty
	 * @public
	 * @param {string} value
	 */
	fnCheckEmpty(value) {
		if (value && value !== "") {
			return value;
		} else {
			return "Unavailable";
		}
	}
}
