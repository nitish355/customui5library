import Filter from "sap/ui/model/Filter";
import Fragment from "sap/ui/core/Fragment";
import * as BaseObject from "sap/ui/base/Object";
import FilterOperator from "sap/ui/model/FilterOperator";
import JSONModel from "sap/ui/model/json/JSONModel";
import Actions from "com/melodylib/integration/enum/Actions";
import Algorithm from "com/melodylib/integration/util/Algorithm";
import AccountClass from "com/melodylib/integration/classes/Account"; // Assuming class
import ResourceModel from "sap/ui/model/resource/ResourceModel";
import AccountUtil from "com/melodylib/integration/util/account/AccountUtil"; // Assuming utility class
import AccountService from "com/melodylib/integration/service/AccountService";
import OpportunityService from "com/melodylib/integration/service/OpportunityService";
import AccountDialogController from "com/melodylib/integration/util/account/AccountDialogController";
import IntergrationLibraryModel from "com/melodylib/integration/model/IntergrationLibraryModel";

/**
 * @name com.melodylib.integration.util.account.AccountHelper
 */

export default class AccountHelperUtil extends BaseObject {
	constructor(parentref) {
		super();
		if (parentref) {
			this.parentCtrl = parentref;
		}
	}

	// Static method to get the instance
	static getInstance(parentref) {
		if (!this.instance) {
			this.instance = new AccountHelperUtil(parentref);
		}
		return this.instance;
	}

	//function to get Dialog with ID
	fnGetDialogUsingId(dialogId, contentId) {
		return sap.ui.core.Fragment.byId(dialogId, contentId);
	}

	/**
	 * @author DARSHAN
	 * @function fnLoadResourceBundle
	 * @description function to load i18n for dialogs
	 * @public
	 * @param {string} dialog
	 */
	fnLoadResourceBundle(dialog) {
		let i18nModel = new ResourceModel({
			bundleName: "com.melodylib.integration.i18n.i18n",
		});
		if (dialog) {
			dialog.setModel(i18nModel, "i18n");
		}
	}

	/**
	 * @author DARSHAN
	 * @function fnClearFilterAdvSearchAccounts
	 * @description function to clear/reset the data in model
	 * @public
	 * @param {string} dialog
	 */
	fnClearFilterAdvSearchAccounts(oEvent) {
		const AccountUtil = this.parentCtrl.accountUtil;
		const AccountHelper = this.parentCtrl.accountHelper;
		let accountSearchModel = this.parentCtrl.getModel();
		accountSearchModel.setProperty("/sPlanningEntities", false);
		accountSearchModel.setProperty("/sGlobalUltimate", false);
		accountSearchModel.setProperty("/sIndustryKey", "");
		accountSearchModel.setProperty("/sRegionKey", "");
		accountSearchModel.setProperty("/sCountryKey", "");
		this.fnFilterAdvSearchAccounts(oEvent);
		accountSearchModel.refresh();
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function fnAdvancedSearchHandler
	 * @description funtion to handle advance search from the fragment
	 * @public
	 * @param {string} eventType
	 * @param {string} sValue
	 * @param {Object} oPrevStateQueryData
	 * @param {Object} oAccountModel
	 */
	async fnAdvancedSearchHandler(
		eventType,
		sValue,
		oPrevStateQueryData,
		accountModel
	) {
		let prevSavedKey;
		const AccountUtil = this.parentCtrl.accountUtil;
		let stateKeys = Object.keys(oPrevStateQueryData) || [];
		if (stateKeys.length) {
			let iAccountIndex = stateKeys.indexOf(sValue);
			prevSavedKey = iAccountIndex !== -1 ? stateKeys[iAccountIndex] : "";
		}

		try {
			if (prevSavedKey) {
				if (eventType === "object") {
					this.fnClearFilterAdvSearchAccounts();
				}
				accountModel.setProperty(
					"/aPrevStateQueryIndex",
					oPrevStateQueryData[prevSavedKey]
				);
				let accountsData = (await AccountUtil.searchAccounts(sValue)) || [];
				this.fnSuccessSearchAccounts(
					sValue,
					accountsData,
					true,
					"",
					Actions.AdvanceAccountSearch,
					Actions.ContainsQuery
				);
			} else {
				if (eventType === "object") {
					this.fnClearFilterAdvSearchAccounts();
				}
				let accountsData = (await AccountUtil.searchAccounts(sValue)) || [];
				this.fnSuccessSearchAccounts(
					sValue,
					accountsData,
					true,
					"",
					Actions.AdvanceAccountSearch
				);
			}
		} catch (error) {
			console.log("ERROR IN fnAdvancedSearchHandler :", error);
		}
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function fnSuccessSearchAccounts
	 * @description function to handle searchAccounts success
	 * @public
	 * @param {string} searchValue
	 * @param {Array} accountResults
	 * @param {Boolearn} bCvaFlag
	 * @param {Object} oControl
	 * @param {String} searchType
	 * @param {String} sPrevQueryState
	 */
	fnSuccessSearchAccounts(
		searchValue,
		accountResults,
		bCvaFlag,
		oControl,
		searchType,
		sPrevQueryState
	) {
		let accountSearchModel = this.parentCtrl.getModel();
		let filter = new Filter({
			filters: [
				new Filter("AccountName", "Contains", searchValue),
				new Filter("AccountId", "Contains", searchValue),
			],
			and: false,
		});

		searchValue = searchValue.toLowerCase();
		const filteredData = [];
		for (let i = 0; i < accountResults.length; i++) {
			let tempData = accountResults[i];
			let account = tempData.AccountId;
			let accountName = tempData.AccountName.toLowerCase();
			if (account.includes(searchValue) || accountName.includes(searchValue)) {
				filteredData.push(tempData);
			}
		}
		//TODO: SET aCvaModelAccountData If Required HERE
		//
		this.fnHandleDataBasedOnSearchedType(
			searchValue,
			searchType,
			filteredData,
			sPrevQueryState,
			bCvaFlag,
			accountResults,
			oControl,
			filter
		);

		accountSearchModel.refresh();
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function fnHandleDataBasedOnSearchedType
	 * @description function to handle cva flag
	 * @public
	 * @param {string} searchValue
	 * @param {string} searchType
	 * @param {Array} aFilteredData
	 * @param {String} sPrevQueryState
	 * @param {Boolean} bCvaFlag
	 * @param {Array} aAccountResults
	 * @param {Object} oControl
	 * @param {Array} aFilter
	 */
	fnHandleDataBasedOnSearchedType(
		searchValue,
		searchType,
		aFilteredData,
		sPrevQueryState,
		bCvaFlag,
		aAccountResults,
		oControl,
		aFilter
	) {
		let oThisController = this;
		let oAccountSearchModel = this.parentCtrl.getModel();
		switch (searchType) {
			case Actions.AdvanceAccountSearch:
				oAccountSearchModel.setProperty("/aMasterAccountData", []);
				let oPrevStateQueryData = $.extend(
					true,
					{},
					oAccountSearchModel.getProperty("/oPrevStateQueryData")
				);
				if (aFilteredData.length) {
					this.fnHandleAdvancedSearchType(aFilteredData, sPrevQueryState);
				} else {
					//TODO: CLEAR aCvaModelAccountData If Required
					oPrevStateQueryData[searchValue] = aFilteredData;
					oAccountSearchModel.setProperty(
						"/oPrevStateQueryData",
						oPrevStateQueryData
					);
					oAccountSearchModel.refresh(true);
				}
				break;
			default:
		}
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function fnHandleAdvancedSearchType
	 * @description function to handle AdvancedSearchType
	 * @public
	 * @param {Array} aFilteredData
	 * @param {String} sPrevQueryState
	 */
	async fnHandleAdvancedSearchType(aFilteredData, sPrevQueryState) {
		try {
			const AccountUtil = this.parentCtrl.accountUtil;
			let dataLength = aFilteredData.length;
			let accountSearchModel = this.parentCtrl.getModel();
			let masterAccountData = $.extend(
				true,
				[],
				accountSearchModel.getProperty("/aMasterAccountData")
			);
			let prevStateQueryData = $.extend(
				true,
				{},
				accountSearchModel.getProperty("/oPrevStateQueryData")
			);
			if (dataLength > 100) {
				dataLength = 100;
			}
			let promiseArray = [];
			let aTrackAccountId = [];
			for (let i = 0; i < dataLength; i++) {
				let iIndex = i;
				let oTempObj = aFilteredData[i];
				switch (sPrevQueryState) {
					case Actions.ContainsQuery:
						let aPrevStateQueryIndex = $.extend(
							true,
							[],
							accountSearchModel.getProperty("/aPrevStateQueryIndex")
						);
						let oSearchedObj = this.fnFindSameAccountObject(
							"AccountId",
							oTempObj.AccountId,
							aPrevStateQueryIndex
						);
						if (oSearchedObj) {
							if (oSearchedObj.hasOwnProperty("GlobalUltimate")) {
								masterAccountData.push(oSearchedObj);
							} else {
								masterAccountData.push(oTempObj);
								promiseArray.push(
									AccountUtil.getAccountDetailsFromBupaInfoSet(
										oTempObj.AccountId
									)
								);
							}
						} else {
							masterAccountData.push(oTempObj);
							promiseArray.push(
								AccountUtil.getAccountDetailsFromBupaInfoSet(oTempObj.AccountId)
							);
						}
						aTrackAccountId.push(oTempObj.AccountId);
						accountSearchModel.setProperty(
							"/aMasterAccountData",
							masterAccountData
						);
						accountSearchModel.setProperty("/isAccountDialogBusy", false);
						if (iIndex + 1 === length) {
							accountSearchModel.setProperty("/lastUpdatedIndex", iIndex);
							accountSearchModel.setProperty(
								"/oPrevStateQueryData",
								prevStateQueryData
							);
							this.fnSetAccountMasterData();
						}
						break;
					default:
						accountSearchModel.setProperty("/lastUpdatedIndex", iIndex);
						masterAccountData.push(oTempObj);
						accountSearchModel.setProperty(
							"/aMasterAccountData",
							masterAccountData
						);
						aTrackAccountId.push(oTempObj.AccountId);

						promiseArray.push(
							AccountUtil.getAccountDetailsFromBupaInfoSet(oTempObj.AccountId)
						);
				}
			}

			//TODO: Need to check this
			if (promiseArray.length) {
				accountSearchModel.setProperty("/isAccountDialogBusy", true);
				const responses = await Promise.all(promiseArray);
				let aAccountData = [];
				for (let i = 0; i < responses.length; i++) {
					let oResponseData = responses[i].data;
					let oSelDataObj = masterAccountData.find((oData) => {
						if (oData.AccountId === oResponseData.GlobalUltimateId) {
							return true;
						}
						//worst case if data not found
						if (oData.AccountId === oResponseData.BusinessPartnerNumber) {
							return true;
						}
					});

					if (oSelDataObj) {
						let oAccountData = this.fnHandlerGetAccountDetailSuccess(
							oSelDataObj,
							oResponseData
						);
						aAccountData.push(oAccountData);
					}
				}

				accountSearchModel.setProperty("/isAccountDialogBusy", false);
				accountSearchModel.setProperty("/aMasterAccountData", aAccountData);
				this.fnCreateHashDataBasedOnAccId(aAccountData);
				this.fnFilterAdvSearchAccounts();
				return aAccountData;
			}
		} catch (error) {
			console.log("ERROR IN fnHandleAdvancedSearchType : ", error);
		}
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function fnFindSameAccountObject
	 * @description Function to find if an same object is present in the array already
	 * @public
	 * @param {String} sProperty
	 * @param {String} Value
	 * @param {Array} responseData
	 */
	fnFindSameAccountObject(sProperty, Value, responseData) {
		let searchedObj = responseData.find(function (object) {
			return object[sProperty] === Value;
		});
		return searchedObj;
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function fnHandlerGetAccountDetailSuccess
	 * @description function to handle Get Account Detail Success
	 * @public
	 * @param {Object} oSelDataObj
	 * @param {Object} oResponse
	 * @param {Boolean} isMyAccounts
	 */
	fnHandlerGetAccountDetailSuccess(oSelDataObj, oResponse, isMyAccounts) {
		let lastAccountObj = {};
		const AccountUtil = this.parentCtrl.accountUtil;
		let currentAccObj = oSelDataObj.AccountId;
		let accountSearchModel = this.parentCtrl.getModel();
		let lastUpdateIndex = accountSearchModel.getProperty("/lastUpdatedIndex");

		if (oSelDataObj.setBupaInfoSetData instanceof Function) {
			oSelDataObj.setBupaInfoSetData(oResponse);
		}
		if (isMyAccounts) {
			lastAccountObj = accountSearchModel.getProperty(
				"/aMyMasterAccountData/" + lastUpdateIndex + "/AccountId"
			);
		} else {
			lastAccountObj = accountSearchModel.getProperty(
				"/aMasterAccountData/" + lastUpdateIndex + "/AccountId"
			);
		}
		if (currentAccObj === lastAccountObj) {
			this.fnSetAccountMasterData(isMyAccounts);
			accountSearchModel.setProperty("/isAccountDialogBusy", false);
		}

		if (oResponse.IndustryName && oResponse.Industry) {
			let industryObj = {
				Description: oResponse.IndustryName,
				IndustryId: oResponse.Industry,
			};
			let industryArr = $.extend(
				true,
				[],
				accountSearchModel.getProperty("/aIndustry")
			);
			let industryPresent = this.fnFindSameAccountObject(
				"IndustryId",
				oResponse.Industry,
				industryArr
			);
			if (!industryPresent) {
				industryArr.push(industryObj);
			}
			accountSearchModel.setProperty("/aIndustry", industryArr);
		}
		accountSearchModel.refresh();
		return oSelDataObj;
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function fnSetAccountMasterData
	 * @description function to handle Get Account Detail Success
	 * @public
	 * @param {Boolean} isMyAccounts
	 */
	fnSetAccountMasterData(isMyAccounts) {
		let accounts;
		let accountSearchModel = this.parentCtrl.getModel();
		let lastUpdateIndex = accountSearchModel.getProperty("/lastUpdatedIndex");
		let myMasterAccountData = $.extend(
			true,
			[],
			accountSearchModel.getProperty("/myMasterAccountData")
		);
		let masterAccountData = $.extend(
			true,
			[],
			accountSearchModel.getProperty("/aMasterAccountData")
		);
		let oPrevStateQueryData = $.extend(
			true,
			{},
			accountSearchModel.getProperty("/oPrevStateQueryData")
		);
		if (isMyAccounts) {
			accounts = accountSearchModel.getProperty("/myMasterAccountData");
		} else {
			accounts = accountSearchModel.getProperty("/masterAccountData");
		}
		//Below lines of code is used to store Search query and its result array data, to avoid same service calls again and again
		if (!isMyAccounts) {
			let sSearchQuery = accountSearchModel.getProperty("/sSearchQuery") || "";
			let sGlobalSearchQuery =
				IntergrationLibraryModel.getProperty("/sSearchQuery");
			if (!sSearchQuery && sGlobalSearchQuery) {
				sSearchQuery = sGlobalSearchQuery;
				accountSearchModel.setProperty("/sSearchQuery", sGlobalSearchQuery);
			}
			sSearchQuery = sSearchQuery.split(" ").join("");
			sSearchQuery = sSearchQuery.toLowerCase();
			if (!oPrevStateQueryData[sSearchQuery]) {
				oPrevStateQueryData[sSearchQuery] = masterAccountData;
				oPrevStateQueryData[sSearchQuery + "_AllAccounts"] = masterAccountData;
				oPrevStateQueryData[sSearchQuery + "_LastUpdatedIndex"] =
					lastUpdateIndex;
				accountSearchModel.setProperty(
					"/oPrevStateQueryData",
					oPrevStateQueryData
				);
			} else {
				oPrevStateQueryData[sSearchQuery] = masterAccountData;
				accountSearchModel.setProperty(
					"/oPrevStateQueryData",
					oPrevStateQueryData
				);
			}
		} else {
			accountSearchModel.setProperty(
				"/aMasterAccountData",
				myMasterAccountData
			);
		}
		accountSearchModel.setProperty("/isAccountDialogBusy", false);
		accountSearchModel.refresh(true);
		this.fnFilterAdvSearchAccounts();
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function fnFilterAdvSearchAccounts
	 * @description Function to filter Accounts in Advanced search
	 * @public
	 * @param {Object} oEvent
	 */
	fnFilterAdvSearchAccounts(oEvent) {
		let filters = [],
			planningEntitiesKey = "",
			globalUltimateKey = "";
		let accountSearchModel = this.parentCtrl.getModel();
		let accountDialogId = this.fnFormatControlId("_AccountDialog");
		// FilterTimeout = await setTimeout(() => {}, 5);
		let table = this.fnGetDialogUsingId(
			accountDialogId,
			"ACCOUNT_ADV_SEARCH_TBL"
		);
		if (!table) {
			return;
		}
		// clearTimeout(FilterTimeout);
		try {
			table.getBinding("items").filter([]);
			let planningEntities =
				accountSearchModel.getProperty("/sPlanningEntities");
			let globalUltimate = accountSearchModel.getProperty("/sGlobalUltimate");
			let industryKey = accountSearchModel.getProperty("/sIndustryKey");
			let regionKey = accountSearchModel.getProperty("/sRegionKey");
			let countryKey = accountSearchModel.getProperty("/sCountryKey");
			if (oEvent) {
				if (
					oEvent.getSource().getMetadata().getElementName() === "sap.m.CheckBox"
				) {
					if (planningEntities) {
						if (
							oEvent.getSource().getName() === "PLANNING_ENTITY" ||
							planningEntities
						) {
							planningEntitiesKey =
								planningEntities === true ? "true" : "false";
						}
					}
					if (globalUltimate) {
						if (
							oEvent.getSource().getName() === "GLOBAL_ULTIMATE" ||
							globalUltimate
						) {
							globalUltimateKey = globalUltimate === true ? "true" : "false";
						}
					}
				} else {
					if (planningEntities) {
						planningEntitiesKey = planningEntities === true ? "true" : "false";
					}
					if (globalUltimate) {
						globalUltimateKey = globalUltimate === true ? "true" : "false";
					}
				}
			} else {
				if (planningEntities) {
					planningEntitiesKey = planningEntities === true ? "true" : "false";
				}
				if (globalUltimate) {
					globalUltimateKey = globalUltimate === true ? "true" : "false";
				}
			}
			if (planningEntitiesKey) {
				filters.push(
					new sap.ui.model.Filter("IsPlanningEntity", "EQ", planningEntitiesKey)
				);
			}
			if (globalUltimateKey) {
				filters.push(
					new sap.ui.model.Filter("GlobalUltimate", "EQ", globalUltimateKey)
				);
			}
			if (industryKey) {
				filters.push(
					new sap.ui.model.Filter("IndustryCode", "EQ", industryKey)
				);
			}
			if (regionKey) {
				filters.push(new sap.ui.model.Filter("GlobalRegion", "EQ", regionKey));
			}
			if (countryKey) {
				filters.push(new sap.ui.model.Filter("Country", "EQ", countryKey));
			}
			table.getBinding("items").filter(filters);
		} catch (error) {
			console.log("fnFilterAdvSearchAccounts :", error);
		}
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function fnSaveAccSearchFilterVariant
	 * @description Function to save User's Account Search filter variant
	 * @public
	 */
	async fnSaveAccSearchFilterVariant() {
		let oThisController = this;
		let accountSearchModel = this.parentCtrl.getModel();
		let userId = accountSearchModel.getProperty("/userId");
		let planningEntities = accountSearchModel.getProperty("/sPlanningEntities");
		let globalUltimate = accountSearchModel.getProperty("/sGlobalUltimate");
		let industryKey = accountSearchModel.getProperty("/sIndustryKey");
		let regionKey = accountSearchModel.getProperty("/sRegionKey");
		let countryKey = accountSearchModel.getProperty("/sCountryKey");
		let searchQuery = accountSearchModel.getProperty("/sSearchQuery");
		let variantid = accountSearchModel.getProperty("/variantid");

		if (!userId) {
			let oResponse = await OpportunityService.getUserDetail();
			userId = oResponse.data.results[0].UserId;
			accountSearchModel.setProperty("/userId", userId);
		}
		if (!variantid) {
			variantid = "";
		}
		let oFilterData = {
			sPlanningEntities: planningEntities,
			sGlobalUltimate: globalUltimate,
			sIndustryKey: industryKey,
			sRegionKey: regionKey,
			sCountryKey: countryKey,
			sSearchQuery: searchQuery,
		};
		let oData = {
			variantid: variantid,
			variant_name: "Filter Variant",
			author: userId,
			type: "P",
			filterstring: JSON.stringify(oFilterData),
			applicationid: "ACCNT",
			operationflag: false,
		};

		AccountService.setUserSrchAcctVariant(oData)
			.then((oResponse) => {
				let { data } = oResponse;
				oThisController.fnSetUserFilterVariant(data);
			})
			.catch((oError) => {
				sap.m.MessageBox.error("Error in saving Filter variant");
			});
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function fnSetUserFilterVariant
	 * @description Function to update the user filter variant
	 * @public
	 * @param {Object} oResponse
	 */
	fnSetUserFilterVariant(oResponse) {
		let data = "";
		if (oResponse.hasOwnProperty("results")) {
			data = oResponse.results[0];
		} else {
			data = oResponse;
		}
		let accountSearchModel = this.parentCtrl.getModel();
		if (!data) {
			accountSearchModel.setProperty("/variantid", "");
			accountSearchModel.setProperty("/sPlanningEntities", false);
			accountSearchModel.setProperty("/sGlobalUltimate", false);
			accountSearchModel.setProperty("/sIndustryKey", "");
			accountSearchModel.setProperty("/sRegionKey", "");
			accountSearchModel.setProperty("/sCountryKey", "");
			accountSearchModel.setProperty("/sSearchQuery", "");
			IntergrationLibraryModel.setProperty("/sSearchQuery", "");
		} else {
			accountSearchModel.setProperty("/variantid", data.variantid);
			if (data.filterstring) {
				data = JSON.parse(data.filterstring);
			}
			accountSearchModel.setProperty(
				"/sPlanningEntities",
				data.sPlanningEntities
			);
			accountSearchModel.setProperty("/sGlobalUltimate", data.sGlobalUltimate);
			accountSearchModel.setProperty("/sIndustryKey", data.sIndustryKey);
			accountSearchModel.setProperty("/sRegionKey", data.sRegionKey);
			accountSearchModel.setProperty("/sCountryKey", data.sCountryKey);
			accountSearchModel.setProperty("/sSearchQuery", data.sSearchQuery);
			IntergrationLibraryModel.setProperty("/sSearchQuery", data.sSearchQuery);
		}
		accountSearchModel.refresh();
		IntergrationLibraryModel.refresh();
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function fnSearchDataInPrevStateObject
	 * @description function to search the data in prevStateObject
	 * @public
	 * @param {string} sValue
	 * @param {Object} oPrevStateQueryData
	 */
	fnSearchDataInPrevStateObject(sValue, oPrevStateQueryData) {
		try {
			let accountResult = [];
			let bValuePresent = false;
			sValue = sValue.toString().trim();
			let isId = Number(sValue) ? true : false;
			let accountSearchModel = this.parentCtrl.getModel();
			let accountHashData = $.extend(
				true,
				{},
				accountSearchModel.getProperty("/oAccountHashData")
			);
			let accountKeys = Object.keys(oPrevStateQueryData);
			if (!accountKeys.length) {
				return {
					bValuePresent,
				};
			}

			if (isId && Object.keys(accountHashData).length) {
				let account = Algorithm.findItem(sValue, accountHashData);
				if (account) {
					bValuePresent = true;
					accountResult.push(account);
				}
				if (accountResult.length) {
					return {
						bValuePresent,
						accountResult,
					};
				}
			}
			//Below logic is to find data in deeper objects from the prevQueryStateData
			accountResult = [];
			sValue = sValue.toLowerCase();
			let isMoreWords = sValue.split(" ").length >= 2 ? true : false;
			let sFirstWord = isMoreWords ? sValue.split(" ")[0] : "";
			let indexSearchedKey = -1;
			if (sFirstWord) {
				indexSearchedKey = accountKeys.indexOf(sFirstWord);
			}
			let oQueryResult = this.fnFindDeeperInQueryData({
				bValuePresent,
				accountKeys,
				indexSearchedKey,
				accountResult,
				isMoreWords,
				oPrevStateQueryData,
				sValue,
			});
			return oQueryResult;
		} catch (error) {
			console.log("ERROR IN fnSearchDataInPrevStateObject : ", error);
		}
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function fnFindDeeperInQueryData
	 * @description funtion to find data deeper in all oPrevQueryStateData
	 * @public
	 * @param {Object} oQueryObject
	 */
	fnFindDeeperInQueryData(oQueryObject) {
		let oThisController = this;
		let {
			bValuePresent,
			accountKeys,
			indexSearchedKey,
			accountResult,
			isMoreWords,
			oPrevStateQueryData,
			sValue,
		} = oQueryObject;
		for (let i = 0; i < accountKeys.length; i++) {
			let sTempKey = accountKeys[i];
			let oTempResult;
			if (indexSearchedKey !== -1) {
				let aTempPrevQueryData = $.extend(
					true,
					[],
					oPrevStateQueryData[accountKeys[indexSearchedKey]]
				);
				oTempResult = oThisController.fnFindDataInPrevQueryData(
					accountResult,
					aTempPrevQueryData,
					sValue
				);
				if (oTempResult.bValuePresent) {
					return oTempResult;
				}
			}

			let aTempValue = $.extend(true, [], oPrevStateQueryData[sTempKey]);
			if (aTempValue.length) {
				const oTempResult = aTempValue.find((oData) => {
					let accountName = oData.AccountName;
					if (accountName) {
						accountName = accountName.toLowerCase();
					}
					if (
						isMoreWords &&
						(oData.AccountId.includes(sValue) || accountName.includes(sValue))
					) {
						return true;
					}
				});
				if (oTempResult) {
					const iIndex = accountResult.findIndex((oAccData) => {
						return oAccData.AccountId === oTempResult.AccountId;
					});
					if (iIndex === -1) {
						bValuePresent = true;
						accountResult.push(oTempResult);
					}
				}
			}
		}
		return {
			bValuePresent,
			accountResult,
		};
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function fnFindDataInPrevQueryData
	 * @description function to find data inside the prevQueryState Data
	 * @public
	 * @param {Array} AccountResult
	 * @param {Array} aQueryData
	 * @param {String} value
	 */
	fnFindDataInPrevQueryData(AccountResult, aQueryData, value) {
		let bValuePresent = false;
		for (let i = 0; i < aQueryData.length; i++) {
			let tempData = aQueryData[i];
			let accountName = tempData.AccountName;
			if (accountName) {
				accountName = accountName.toLowerCase();
			}
			if (accountName.includes(value)) {
				let iIndex = AccountResult.findIndex((oAccData) => {
					return oAccData.AccountId === tempData.AccountId;
				});
				if (iIndex === -1) {
					bValuePresent = true;
					AccountResult.push(tempData);
				}
			}
		}
		return {
			bValuePresent: bValuePresent,
			AccountResult: AccountResult,
		};
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function fnAccountSearchHandler
	 * @description function to handle search
	 * @public
	 * @param {String} sValue
	 * @param {String} selectedIconTabKey
	 * @param {String} eventType
	 */
	async fnAccountSearchHandler(sValue, selectedIconTabKey, eventType) {
		try {
			let oThisController = this;
			sValue = sValue.toLowerCase();
			const AccountUtil = this.parentCtrl.accountUtil;
			let accountModel = this.parentCtrl.getModel();
			accountModel.setProperty("/isAccountDialogBusy", true);
			accountModel.setProperty("/aMasterAccountData", []);
			accountModel.setProperty("/isMyAccountsCountVisible", false);
			switch (selectedIconTabKey) {
				case Actions.AdvanceAccountSearch:
					let prevStateQueryData = $.extend(
						true,
						{},
						accountModel.getProperty("/oPrevStateQueryData")
					);
					let sTempValue = sValue.replace(/\s+/g, "");
					if (
						prevStateQueryData[sTempValue] &&
						prevStateQueryData[sTempValue] instanceof Array &&
						prevStateQueryData[sTempValue].length
					) {
						accountModel.setProperty(
							"/aMasterAccountData",
							prevStateQueryData[sTempValue]
						);
						oThisController.fnSetAccountMasterData();
						accountModel.refresh(true);
						accountModel.setProperty("/isAccountDialogBusy", false);
						return;
					}
					let oDataSetPresent = oThisController.fnSearchDataInPrevStateObject(
						sValue,
						prevStateQueryData
					);
					if (oDataSetPresent.bValuePresent) {
						accountModel.setProperty(
							"/aMasterAccountData",
							oDataSetPresent.AccountResult
						);
						oThisController.fnSetAccountMasterData();
						accountModel.refresh(true);
						accountModel.setProperty("/isAccountDialogBusy", false);
						return;
					}
					accountModel.setProperty("/isAccountDialogBusy", true);
					setTimeout(function () {
						oThisController.fnAdvancedSearchHandler(
							eventType,
							sValue,
							prevStateQueryData,
							accountModel
						);
					}, 300);
					break;
				default:
			}
		} catch (error) {
			console.log("fnAccountSearchHandler :", error);
		}
	}

	/**
	 * @author DARSHAN
	 * @function fnCreateHashDataBasedOnAccId
	 * @description function to create hash table search for accounts based on ID
	 * @public
	 * @param {Array} aFormattedData
	 */
	fnCreateHashDataBasedOnAccId(aFormattedData) {
		let accountModel = this.parentCtrl.getModel();
		accountModel.setProperty("/isMyAccountsCountVisible", true);
		let hashData = $.extend(
			true,
			{},
			accountModel.getProperty("/oAccountHashData")
		);
		for (let i = 0; i < aFormattedData.length; i++) {
			let oTempData = aFormattedData[i];
			let accountId = oTempData.AccountId;
			let accountName = oTempData.AccountName;
			if (!hashData[accountId] && accountId) {
				hashData[accountId] = oTempData;
			}
		}
		accountModel.setProperty("/oAccountHashData", hashData);
		accountModel.setProperty("/isMyAccountsCountVisible", false);
		accountModel.refresh();
	}

	/**
	 * @author DARSHAN
	 * @function fnGetAccSearchFilterVariant
	 * @description Function to get User's Account Search filter variant
	 * @public
	 */
	fnGetAccSearchFilterVariant(init, variantId) {
		let oThisController = this;
		let response = AccountService.getUserSrchAcctVariant();
		response.then((oResponse) => {
			let { data } = oResponse;
			if (data && data.hasOwnProperty("results")) {
				let oVariant = $.extend(true, {}, data.results[0]);
				oThisController.fnSetUserFilterVariant(oVariant);
			}
		});
	}

	/**
	 * @author DARSHAN
	 * @function fnFetchAccountDetailHelperFunction
	 * @description function to help fetchAccountDetails for Advance Search //TODO:This function move to dialogcontroller
	 * @public
	 * @param {Object} oAccount
	 */
	fnFetchAccountDetailHelperFunction(oAccount) {
		let oThisController = this;
		let accountSearchModel = this.parentCtrl.getModel();
		this.fnSaveAccSearchFilterVariant();
		this.fnSetOpportunityBasedOnAccount(oAccount).then(async (aResponse) => {
			oAccount.oOpportunityData = aResponse;
			oThisController.parentCtrl.setSelectedAccount(oAccount);
			let dialog = await oThisController.parentCtrl._oAccountDialog;
			if (dialog) {
				dialog.close();
				dialog.destroy();
				oThisController.parentCtrl._oAccountDialog = null;
			}
			accountSearchModel.refresh();
		});
	}

	/**
	 * @author DARSHAN
	 * @function fnSetOpportunityBasedOnAccount
	 * @description function to set Opportunities to selected Account Data
	 * @public
	 * @param {Object} oAccount
	 */
	fnSetOpportunityBasedOnAccount(oAccount) {
		let filterOpportunityData = [];
		return new Promise((resolve, reject) => {
			return resolve(filterOpportunityData);
		});
	}

	/**
	 * @author DARSHAN
	 * @function fnFormatControlId
	 * @description function to get control ID
	 * @public
	 * @param {String} _controlId
	 */
	fnFormatControlId(_controlId) {
		const controlId = this.parentCtrl.getId();
		return `${controlId}${_controlId}`;
	}
}
