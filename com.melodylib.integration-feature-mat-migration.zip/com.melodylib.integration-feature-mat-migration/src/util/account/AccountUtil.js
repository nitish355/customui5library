import Filter from "sap/ui/model/Filter";
import MessageToast from "sap/m/MessageToast";
import * as BaseObject from "sap/ui/base/Object";
import FilterOperator from "sap/ui/model/FilterOperator";
import JSONModel from "sap/ui/model/json/JSONModel";
import IndexedDB from "com/melodylib/core/db/IndexedDB";
import Actions from "com/melodylib/integration/enum/Actions";
import Algorithm from "com/melodylib/integration/util/Algorithm";
import Account from "com/melodylib/integration/classes/Account";
import AccountService from "com/melodylib/integration/service/AccountService";
import OpportunityService from "com/melodylib/integration/service/OpportunityService";
import IntergrationLibraryModel from "com/melodylib/integration/model/IntergrationLibraryModel";

/**
 * @name com.melodylib.integration.util.account.AccountUtility
 */

export default class AccountUtility extends BaseObject {

	constructor(parentref) {
		super();
		if (parentref) {
			this.parentCtrl = parentref;
		}
	}

	// Static method to get the instance
	static getInstance(parentref) {
		if (!this.instance) {
			this.instance = new AccountUtility(parentref);
		}
		return this.instance;
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function fnInit
	 * @description to initialize the this.parentCtrl to the parent "this" pointer
	 * @public
	 * Need to Revisit this and check the placement of the functions
	 */
	fnInit() {
		try {
			this.parentCtrl.accountHelper.fnGetAccSearchFilterVariant(true);
			this.getConstantData();
		} catch (oError) { }
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function searchAccounts
	 * @description Function to fetch logged in user details from WorkFlow service.
	 * @return {Array} The data from the Accounts
	 * @public
	 * @param {string} value
	 */
	async searchAccounts(value) {
		const filters = [new Filter("TYPE", FilterOperator.EQ, "A")];
		let model;
		if (this?.parentCtrl) {
			model = this.parentCtrl.getModel();
		}
		try {
			const response = await OpportunityService.getBusinessPartners(
				value.toLowerCase(),
				filters
			);
			let { data } = response;
			let results = data?.results ? data.results : [];
			let accounts = results.map(
				(data) =>
					new Account({
						AccountId: data.PARTNER,
						AccountName: data.NAME,
						Description: "",
						AccountId_Name: data.NAME + "-" + data.PARTNER,
					})
			);
			return accounts || [];
		} catch (oError) {
			if (model) {
				model.setProperty("/isAccountDialogBusy", false);
			}
			console.error(`Account data for ${value} not found`);
		}
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function getAdvanceDetails
	 * @description Function to create account data
	 * @return {Array} The data from the Accounts
	 * @public
	 * @param {Array} accounts
	 */
	async getAdvanceDetails(accounts) {
		const accountArr = [];
		const responses = await AccountService.getAdvanceDetails(accounts);
		for (let i = 0; i < responses.length; i++) {
			if (responses[i].status === "success") {
				const result = JSON.parse(responses[i].value);
				let bGlobalUltimate = false,
					account,
					accountName,
					industryCode,
					industry,
					planningEntityId,
					planningEntityName,
					country,
					city,
					street;
				if (result?.globalUltimate) {
					bGlobalUltimate = true;
				}

				if (result?.address) {
					if (result.address.line1) {
						street = result.address.line1;
					}

					if (result?.address?.line2) {
						if (street) {
							street = street + ", " + result.address.line2;
						} else {
							street = result.address.line2;
						}
					}

					if (result?.address?.line3) {
						city = result.address.line3;
					}
				}

				if (result?.masterData) {
					if (result?.masterData?.account) {
						account = result.masterData.account.id;
						accountName = result.masterData.account.description;
					}

					if (result?.masterData?.country) {
						country = result.masterData.country.description;
					}

					if (result?.masterData?.masterCode) {
						industryCode = result.masterData.masterCode.id;
						industry = result.masterData.masterCode.description;
					}

					if (result?.masterData?.planningEntity) {
						planningEntityId = result.masterData.planningEntity.id;
						planningEntityName = result.masterData.planningEntity.description;
					}
				}

				const accountData = new Account({
					AccountId: account,
					AccountName: accountName,
					Industry: industry,
					IndustryCode: industryCode,
					PlanningEntityId: planningEntityId,
					PlanningEntityName: planningEntityName,
					Country: country,
					City: city,
					Street: street,
					IsPlanningEntity:
						planningEntityId && sAccount && planningEntityId === sAccount
							? true
							: false,
					IsGlobalUltimate: bGlobalUltimate,
					IsAdvanceSearched: true,
				});
				accountArr.push(accountData);
			}
		}
		return accountArr;
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function getCountryMasterData
	 * @description function to get Country Master Data
	 * @return {Promise<Array>} The data from the URL. || {Object}
	 * @public
	 */
	async getCountryMasterData() {
		let response = await AccountService.getCountryMasterData();
		return response;
	}

	/**
	 * @author DARSHAN
	 * @function filterAccounts
	 * @description function to handle filterAccount
	 * @public
	 */
	filterAccounts() {
		let accountDialogId =
			this.parentCtrl.accountHelper.fnFormatControlId("_AccountDialog");
		const simpleSearchList = this.fnGetDialogUsingId(
			accountDialogId,
			"idSimpleSearchList"
		);
		const filters = this.parentCtrl.filters;
		if (!filters || filters.length === 0) {
			filters.push(new Filter("IsMyAccount", FilterOperator.EQ, true));
		}
		const bindedItems = simpleSearchList.getBinding("items") || false;
		if (bindedItems) {
			bindedItems.filter(filters);
		}
	}

	/**
	 * @author DARSHAN
	 * @function fnGetDialogUsingId
	 * @description function to get Dialog with ID
	 * @public
	 */
	fnGetDialogUsingId(dialogId, contentId) {
		return sap.ui.core.Fragment.byId(dialogId, contentId);
	}

	/**
	 * @author DARSHAN
	 * @function getAccountDetailsFromBupaInfoSet
	 * @description function to get account details from BUPA Info Set
	 * @public
	 */
	async getAccountDetailsFromBupaInfoSet(accountId) {
		if (accountId) {
			let response = AccountService.getZSBupaInfoSet(accountId);
			return response;
		}
	}

	/**
	 * @author DARSHAN
	 * @function getAccountDetails
	 * @description function to get Account Details from Business Partner
	 * @public
	 */
	async getAccountDetails(AccountId, cvaFlag, isAccountChanged) {
		let response = await OpportunityService.getBusinessPartnerAttribSet(
			AccountId
		);
		return response;
	}

	/**
	 * @author DARSHAN
	 * @function fnFetchAccountDetails
	 * @description function to fetch All Data of Account Based on AccountId:
	 * @public
	 */
	async fnFetchAccountDetails(accountId) {
		let accountData;
		let accountBupa;
		let oUrlConstants = $.extend(
			true,
			{},
			IntergrationLibraryModel.getProperty("/oConstants")
		);

		let accountPromise = [
			this.searchAccounts(accountId),
			AccountService.getZSBupaInfoSet(accountId),
		];

		let accountResponse = await Promise.all(accountPromise);

		if (accountResponse && accountResponse.length) {
			accountResponse = accountResponse.flat();
			[accountData, accountBupa] = accountResponse;
			accountBupa = accountBupa && accountBupa?.data ? accountBupa.data : null;
		}

		if (accountData.setBupaInfoSetData instanceof Function && accountBupa) {
			accountData.setBupaInfoSetData(accountBupa);
		}

		//Need to check this part
		// if (accountData.setBPAttributeSetData instanceof Function) {
		// 	accountData.setBPAttributeSetData(oBPdata);
		// }

		accountData.harmonyLink =
			Object.keys(oUrlConstants).length && oUrlConstants.hasOwnProperty("0052")
				? oUrlConstants["0052"].field_value + accountData.AccountId + "/plan"
				: "";
		return new Promise((resolve, reject) => {
			return resolve(accountData);
		});
	}

	/**
	 * @author DARSHAN
	 * @function fnSetControlPropertiesBasedOnView
	 * @description function to set data,clear icon & info icon based on visible
	 * @public
	 */
	async fnSetControlPropertiesBasedOnView(accountData) {
		let formattedAccountData;
		let accountId = accountData.accountId;
		if (accountId) {
			let responseData = await this.fnFetchAccountDetails(accountId);
			formattedAccountData = Account.setFormatAccountData(responseData);
			return formattedAccountData;
		}
		return false;
	}

	/**
	 * @author DARSHAN
	 * @function fnSetControlPropertiesBasedOnView
	 * @description function to get Promise for SearchAccount
	 * @public
	 * Revisit
	 */
	fnProvideBPAttributeSetSearchAccount(promiseDetails) {
		let promise = [];
		let results = promiseDetails.aResults;
		if (promiseDetails.bAccountId) {
			promise.push(
				OpportunityService.getBusinessPartnerAttribSet(promiseDetails.AccountId)
			);
			return promise;
		}

		for (let i = 0; i < results.length; i++) {
			let tempData = results[i];
			promise.push(
				OpportunityService.getBusinessPartnerAttribSet(tempData.PARTNER)
			);
		}
		return promise;
	}

	/**
	 * @author DARSHAN
	 * @function fnSetControlPropertiesBasedOnView
	 * @description function to get constants
	 * @public
	 */
	async getConstantData() {
		let constants =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "harmonyconstanturls",
			})) || [];

		constants =
			constants && constants instanceof Array && !constants.length
				? {}
				: constants;

		if (!Object.keys(constants).length) {
			let constants = {};
			let { data } = await OpportunityService.getConstants();
			let results = data?.results ?? [];
			for (let index in results) {
				constants[results[index].const_id] = results[index];
			}
			IntergrationLibraryModel.setProperty("/oConstants", constants);
			IntergrationLibraryModel.refresh();
			IndexedDB.fnInsertDataToDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "harmonyconstanturls",
				aObjectsToInsert: constants,
			});
		} else {
			IntergrationLibraryModel.setProperty("/oConstants", constants);
			IntergrationLibraryModel.refresh();
		}
	}

	/**
	 * @author DARSHAN
	 * @function fnGetAccountSearchQuery
	 * @description function to get previously search key data
	 * @public
	 */
	async fnGetAccountSearchQuery() {
		let { data } = await AccountService.getUserSrchAcctVariant();
		if (data && data?.results && data.results.length) {
			let filterData = data.results[0];
			let searchData = JSON.parse(filterData.filterstring) || {};
			return searchData;
		}
		return false;
	}

	/**
	 * @author DARSHAN
	 * @function fnFetchAccountTableDataBasedOnKey
	 * @description Function to fetch data for Advanced search Account table
	 * @public
	 */
	async fnFetchAccountTableDataBasedOnKey(value) {
		let promise = [];
		let accountsData = [];
		let oThisController = this;
		try {
			if (!value) {
				let oSearchData = await this.fnGetAccountSearchQuery();
				if (
					oSearchData &&
					"sSearchQuery" in oSearchData &&
					oSearchData.sSearchQuery
				) {
					value = oSearchData.sSearchQuery;
				}
			}
			let accounts = await this.searchAccounts(value);
			if (accounts && accounts.length) {
				promise = accounts.map((oAccount) => {
					return oThisController.getAccountDetailsFromBupaInfoSet(
						oAccount.AccountId
					);
				});
			}

			if (promise.length) {
				let responses = await Promise.all(promise);
				for (let i = 0; i < responses.length; i++) {
					let responseData = responses[i].data;
					let accountObj = accounts.find((data) => {
						if (data.AccountId === responseData.GlobalUltimateId) {
							return true;
						}
						//worst case if data not found
						if (data.AccountId === responseData.BusinessPartnerNumber) {
							return true;
						}
					});

					if (accountObj) {
						if (accountObj.setBupaInfoSetData instanceof Function) {
							accountObj.setBupaInfoSetData(responseData);
						}
						accountsData.push(accountObj);
					}
				}
			}

			return new Promise((resolve, reject) => {
				resolve(accountsData);
			});
		} catch (error) {
			return new Promise((resolve, reject) => {
				console.log("fnFetchAccountTableDataBasedOnKey : ", error);
				reject({ message: "Failed to fetch account data" });
			});
		}
	}
};

