import Filter from "sap/ui/model/Filter";
import Helper from "com/melodylib/core/util/Helper";
import IndexedDB from "com/melodylib/core/db/IndexedDB";
import FilterOperator from "sap/ui/model/FilterOperator";
import AuthState from "com/melodylib/core/state/AuthState";
import BaseState from "com/melodylib/core/state/BaseState";
import Actions from "com/melodylib/integration/enum/Actions";
import Account from "com/melodylib/integration/classes/Account";
import OppService from "com/melodylib/integration/service/OppService";
import MasterDataState from "com/melodylib/core/state/MasterDataState";
import Opportunity from "com/melodylib/integration/classes/Opportunity";
import AccountState from "com/melodylib/integration/state/AccountState";

/**
 * @name com.melodylib.integration.state.OpportunityState
 */
export default class OpportunityState extends BaseState {
	constructor() {
		super(OppService.getInstance());
		this.authState = AuthState.getInstance();
		this.accountState = AccountState.getInstance();
		this.masterDataState = MasterDataState.getInstance();
		this._data = {
			busy: {
				opportunities: true,
				nonVatOpportunities: true,
				discontinuedOpportunities: true,
			},
			opportunities: [],
			teamOpportunities: [],
			opportunitiesMap: {},
			nonVatOpportunities: [],
			statuses: [],
			phases: [],
			owners: [],
		};
	}

	static getInstance() {
		if (!this._instance) {
			this._instance = new OpportunityState();
		}
		return this._instance;
	}

	async init() {
		try {
			await this.authState.getBusinessPartner();
			await this.getAppValueHelps();
			await this.getActiveOpportunities(true);
		} catch (error) {
			console.log("Error in OpportunityState : ", error);
		}
	}

	async getAppValueHelps() {
		let statuses =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "myopportunity-data",
				storeName: "opportunitystore",
				keyName: "pcoppstatusmasterdata",
			})) || {};
		let phases =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "myopportunity-data",
				storeName: "opportunitystore",
				keyName: "pcoppphasemasterdata",
			})) || {};

		//Check for Opp phase and status
		let bAppValueValidated = this._checkAppValueHelpValidation(
			phases,
			statuses
		);

		if (bAppValueValidated) {
			this.setStatuses(statuses);
			this.setPhases(phases);
			this.updateModel();
			return;
		}
		const { data } = await this._service.getAppValueHelps();
		const results = data?.results;
		if (results.length > 0) {
			results.forEach(function (item) {
				switch (item.FIELD_NAME) {
					case "STATUS":
						statuses[item.KEY] = item;
						break;
					case "PHASE":
						phases[item.KEY] = item;
						break;
					default:
						break;
				}
			});
		}
		this.setStatuses(statuses, true);
		this.setPhases(phases, true);
		this.updateModel();
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function _checkAppValueHelpValidation
	 * @description function to validate app value help data
	 * @public
	 */
	_checkAppValueHelpValidation(phases, statuses) {
		let bPhaseValidate = false;
		let bStatusValidate = false;
		if (
			(phases && phases instanceof Object && Object.keys(phases).length) ||
			(phases && phases instanceof Array && phases.length)
		) {
			bPhaseValidate = true;
		}

		if (
			(statuses &&
				statuses instanceof Object &&
				Object.keys(statuses).length) ||
			(statuses && statuses instanceof Array && statuses.length)
		) {
			bStatusValidate = true;
		}
		return bPhaseValidate && bStatusValidate;
	}

	setStatuses(statuses, insertToDB = false) {
		if (!this._data) {
			this._data = {
				statuses: statuses,
			};
		} else {
			this._data.statuses = statuses;
		}
		if (insertToDB) {
			IndexedDB.fnInsertDataToDB({
				dbName: "myopportunity-data",
				storeName: "opportunitystore",
				keyName: "pcoppstatusmasterdata",
				aObjectsToInsert: statuses,
			});
		}
	}

	setPhases(phases, insertToDB = false) {
		if (!this._data) {
			this._data = {
				phases: phases,
			};
		} else {
			this._data.phases = phases;
		}
		if (insertToDB) {
			IndexedDB.fnInsertDataToDB({
				dbName: "myopportunity-data",
				storeName: "opportunitystore",
				keyName: "pcoppphasemasterdata",
				aObjectsToInsert: phases,
			});
		}
	}

	getOpportunities() {
		let opportunities = this.getData().opportunities;
		return opportunities;
	}

	/**
	 * @author BALWANT,DARSHAN
	 * @function setOpportunitiesBusy
	 * @description function to set opportunities busy indicator
	 * @param {Boolean} isBusy
	 */
	setOpportunitiesBusy(isBusy) {
		this.getModel().setProperty("/busy/opportunities", isBusy ? true : false);
	}

	/**
	 * @author DARSHAN
	 * @function getOpportunityTotalCount
	 * @description function to get opportunities total count
	 * @param {Object} params
	 */
	async getOpportunityTotalCount(params) {
		let urlParams = { ...params };
		delete urlParams.select;
		const response = await this._service.getOpportunityCount(urlParams);
		let count = response && "data" in response ? Number(response.data) : 0;
		return count;
	}

	/**
	 * @author BALWANT,DARSHAN
	 * @function getActiveOpportunities
	 * @description function to get active opportunities based on logged-in user's BP ID
	 * @param {Boolean} hardRefresh
	 */
	async getActiveOpportunities(hardRefresh) {
		let owners = [];
		let accounts = [];
		const accountMap = new Map();
		const ownerMap = new Map();
		this.setOpportunitiesBusy(true);
		const storage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
		const storageOpportunites = storage.get("myopportunities") || [];
		let opportunities = this.getData().opportunities || [];

		//Data is present session Storage
		if (storageOpportunites.length) {
			this.formatStorageOpportunities(storageOpportunites);
			this.setOpportunitiesBusy(false);
			this.updateModel();
			return storageOpportunites;
		}

		if (!hardRefresh && opportunities.length) {
			return opportunities;
		}
		const partnerId = this.authState.getData().partnerId;

		const businessPartnerFilter = new Filter(
			"SALES_TEAM_MEMBER",
			FilterOperator.EQ,
			partnerId
		);

		const statusFilters = [
			new Filter({
				filters: [
					new Filter({
						path: "STATUS",
						operator: FilterOperator.EQ,
						value1: "E0007",
					}),
					new Filter({
						path: "STATUS",
						operator: FilterOperator.EQ,
						value1: "E0001",
					}),
				],
				and: false,
			}),
		];

		const filters = [
			new Filter({
				filters: [businessPartnerFilter, ...statusFilters],
				and: true,
			}),
		];

		const params = {
			filters: filters,
			select: Actions.GetOpportunityUrlParam.select,
		};

		//Calculate the batch and call the opportunities batchwise
		const batchCount = 10;
		let promises = [];
		let startIndex = 0;
		let batchResponses = [];
		const totalCount = await this.getOpportunityTotalCount(params);
		const batches = Math.ceil(totalCount / batchCount);
		for (let i = 0; i < batches; i++) {
			let skip = 0;
			params.top = batchCount;
			if (i !== 0) {
				skip = startIndex + batchCount;
			}
			startIndex = skip;
			params.skip = skip;
			promises.push(this._service.getOpportunities(params));
		}

		const responses = await Promise.all(promises);
		if (!responses || !responses.length) {
			return [];
		}

		batchResponses = responses.reduce((responses, response) => {
			return (responses = responses.concat(response.data.results));
		}, []);

		// const { data } = await this._service.getOpportunities(params);
		// const results = data?.results ?? [];
		for (let i = 0; i < batchResponses.length; i++) {
			const opportunity = new Opportunity(batchResponses[i]);
			if (opportunity?.accountId && !accountMap.has(opportunity.accountId)) {
				const account = new Account({
					id: opportunity?.accountId || "",
					name: opportunity?.accountName || "",
					isUserAccount: true,
				});
				accountMap.set(opportunity.accountId, account);
			}

			if (batchResponses[i].STATUS && batchResponses[i].STATUS !== "") {
				const status = this._data.statuses[batchResponses[i].STATUS] || {};
				opportunity.setStatus({
					key: status?.KEY,
					value: status?.VALUE,
				});
			}

			if (batchResponses[i].CURR_PHASE && batchResponses[i].CURR_PHASE !== "") {
				const phase = this._data.phases[batchResponses[i].CURR_PHASE] || {};
				opportunity.setPhase({
					key: phase?.KEY,
					value: phase?.VALUE,
				});
			}

			opportunity.setActive();
			if (!ownerMap.has(opportunity.owner)) {
				ownerMap.set(opportunity.owner, opportunity);
			}

			this._data.opportunities.push(opportunity);
		}
		accounts = Array.from(accountMap.values());
		this.accountState?.setAccount(accounts);
		this._data.owners = Array.from(ownerMap.values());
		this.setOpportunitiesBusy(false);
		this.updateModel();

		const oppIds = this._data.opportunities.map((opp) => opp.id);
		this.getOpportunityDetail(oppIds).then(() => {
			this.getOpportunitySlDetails();
			this.generateOpportunityMap();
		});

		return this._data.opportunities;
	}

	/**
	 * @public
	 * @author DARSHAN
	 * @function formatStorageOpportunities
	 * @description function to format storage opportunties
	 */
	formatStorageOpportunities(storageOpportunites) {
		let owners = [];
		let accounts = [];
		const accountMap = new Map();
		const ownerMap = new Map();
		for (let i = 0; i < storageOpportunites.length; i++) {
			const data = storageOpportunites[i];
			let opportunity = new Opportunity();
			opportunity = Object.assign(opportunity, data);
			if (opportunity?.accountId && !accountMap.has(opportunity.accountId)) {
				const account = new Account({
					id: opportunity?.accountId || "",
					name: opportunity?.accountName || "",
					isUserAccount: true,
				});
				accountMap.set(opportunity.accountId, account);
			}

			if (!ownerMap.has(opportunity.owner)) {
				ownerMap.set(opportunity.owner, opportunity);
			}

			this._data.opportunities.push(opportunity);
		}
		accounts = Array.from(accountMap.values());
		this.accountState?.setAccount(accounts);
		this._data.owners = Array.from(ownerMap.values());
	}

	/**
	 * @public
	 * @author DARSHAN
	 * @function generateOpportunityMap
	 * @description function to generate opportunity map data
	 */
	generateOpportunityMap() {
		const opportunities = this._data.opportunities || [];
		const storage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
		this._data.opportunitiesMap = storage.get("myopportunities_map") || {};
		const storageOpportunites = storage.get("myopportunities") || [];
		if (
			this._data?.opportunitiesMap &&
			Object.keys(this._data.opportunitiesMap).length
		) {
			return this._data.opportunitiesMap;
		}
		if (opportunities.length) {
			const opportunitiesMap = opportunities.reduce((opportunityMap, data) => {
				opportunityMap[data.id] = data;
				return opportunityMap;
			}, {});
			this._data.opportunitiesMap = opportunitiesMap;
			storage.put("myopportunities_map", opportunitiesMap);
			return opportunitiesMap;
		}
		// storage.put("myopportunities", opportunities);
		return this._data.opportunitiesMap;
	}

	async getOpportunityDetail(oppIds) {
		const opportunities = this._data.opportunities || [];
		const payloadIds = opportunities
			.map((opportunity) => {
				if (!opportunity.isDetailAvailable) {
					return opportunity.id;
				}
			})
			.filter((id) => id);
		const responses = await this._service.getOpportunityDetail(payloadIds);
		for (let i = 0; i < responses.length; i++) {
			if (responses[i].status === "fulfilled") {
				const { data } = responses[i].value;
				let opportunity = opportunities.find(
					(item) => item.id === data.OPPT_ID
				);
				const status = this._data.statuses[data.STATUS];
				const phase = this._data.phases[data.CURR_PHASE];
				if (opportunity) {
					if (!opportunity.description) {
						opportunity.setData(
							data,
							{
								key: status?.KEY,
								value: status?.VALUE,
							},
							{
								key: phase?.KEY,
								value: phase?.VALUE,
							},
							true
						);
					} else {
						opportunity.setDetail(data);
					}
				} else {
					opportunity = new Opportunity(
						data,
						{
							key: status?.KEY,
							value: status?.VALUE,
						},
						{
							key: phase?.KEY,
							value: phase?.VALUE,
						},
						true
					);
					opportunities.push(opportunity);
				}
			} else if (responses[i].status === "rejected") {
			}
		}
		this.updateModel();
	}

	/**
	 * @author DARSHAN
	 * @function getOpportunitySlDetails
	 * @description function to fetch the Sl Details based on opportunities
	 */
	async getOpportunitySlDetails(teamOpportunity = []) {
		try {
			let postOpportunities = [];
			const parameters = {
				filters: [],
			};
			const storage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let opportunities = [...this._data.opportunities] || [];
			if (teamOpportunity.length) {
				opportunities = opportunities.concat(teamOpportunity);
				parameters.filters = teamOpportunity.map((opportunity) => {
					return new Filter("Opportunityno", FilterOperator.EQ, opportunity.id);
				});
				this._data.opportunities = opportunities;
			} else {
				parameters.filters = opportunities.map((opportunity) => {
					return new Filter("Opportunityno", FilterOperator.EQ, opportunity.id);
				});
			}

			let { data } = await this._service.getOpportunitySlDetails(parameters);
			let results = data?.results || [];

			for (let i = 0; i < results.length; i++) {
				let response = results[i];
				let opportunity = this._data.opportunities.find((item) => {
					return item.id === response.Opportunityno;
				});
				if (opportunity) {
					if (!("slsnro" in opportunity)) {
						opportunity.setSlDetail(response);
					}
				}
			}
			this.updateModel();
			storage.put("myopportunities", opportunities);
		} catch (error) {
			console.log("ERROR IN getOpportunitySlDetails : ", error);
		}
	}

	/**
	 * @author DARSHAN
	 * @function fetchOpportunityData
	 * @description function to fetch the Opportunity Details Based on Opportunity Id:
	 * @param {String} opportunityId
	 */
	async getOpportunityById(opportunityId) {
		try {
			let opportunityData;
			let response = await this.getOpportunitiesTeam(opportunityId);
			let urlConstants =
				(await IndexedDB.fnGetAllDatafromDB({
					dbName: "master-data",
					storeName: "master-data-table",
					keyName: "harmonyconstanturls",
				})) || [];
			let urlConstant =
				urlConstants.find((url) => {
					return url.id === "0011";
				}) || false;
			if (response && response?.data) {
				let data = response.data;
				opportunityData = new Opportunity(data);
			}
			if (response && response?.data?.PartiesInvolved) {
				opportunityData.opportunityTeamData = []; // Add OpportunityTeam
				if (urlConstant) {
					opportunityData.harmonyLink = `${urlConstant.field_value}${response.data.OPPT_ID}/plan`;
				} else {
					opportunityData.harmonyLink = "";
				}
				return opportunityData;
			} else {
				return response;
			}
		} catch (error) {
			console.log("ERROR IN fetchOpportunityData : ", error);
		}
	}

	async getNonVATOpportunities(
		accountId,
		opportunityId,
		loadedRecords,
		query,
		fetchTotalCount
	) {
		let count;
		let opportunities = [];
		let filters = [];
		let quaterFilter = [];
		const statuses = ["E0001", "E0007"];

		// status filter
		const statusFilter = statuses.map((status) => {
			return new Filter({
				path: "STATUS",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: status,
			});
		});

		if (opportunityId) {
			filters.push(
				new Filter({
					path: "QUARTER_ID",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: "99990",
				})
			);
			filters.push(
				new Filter({
					path: "OPPT_ID",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: opportunityId,
				})
			);
		} else {
			quaterFilter = this.getQuaterFilter();
		}

		filters = [...filters, ...statusFilter, ...quaterFilter];

		filters.push(
			new Filter({
				path: "HARMONY_TYPE",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: "HQ",
			})
		);

		if (accountId && accountId !== "") {
			filters.push(
				new Filter({
					path: "ACCOUNT",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: accountId,
				})
			);
		}

		const params = {
			filters: filters,
			"search-focus": "ACCOUNT",
			search: query || "",
		};

		if (fetchTotalCount) {
			count = await this._service.getNonVATOpportunities(params, true);
			count = count && count.data ? count.data : 0;
		}

		params.skip = loadedRecords || 0;
		params.top = 10;
		params.select = Actions.GetOpportunityNonVATListUrlParam.select;

		const { data } = await this._service.getNonVATOpportunities(params);
		if (data?.results.length) {
			const results = data.results;
			for (let i = 0; i < results.length; i++) {
				const opportunity = new Opportunity(results[i]);
				opportunity.setNonVAT(results[i]);
				opportunity.setDetail(results[i]);
				if (results[i].STATUS && results[i].STATUS !== "") {
					const status = this._data.statuses[results[i].STATUS] || {};
					opportunity.setStatus({
						key: status?.KEY,
						value: status?.VALUE,
					});
				}

				if (results[i].CURR_PHASE && results[i].CURR_PHASE !== "") {
					const phase = this._data.phases[results[i].CURR_PHASE] || {};
					opportunity.setPhase({
						key: phase?.KEY,
						value: phase?.VALUE,
					});
				}

				opportunities.push(opportunity);
			}
			// opportunities = Array.from(results, (opportunity) => new Opportunity(opportunity));
		}
		return {
			count: count,
			opportunities: opportunities,
		};
	}

	getQuaterFilter() {
		let quarter = "";
		const quarterFilter = [];
		let currentYear = new Date().getFullYear() - 1;
		for (let i = 1; i <= 7; i++) {
			quarter = currentYear + "0";
			quarterFilter.push(new Filter("QUARTER_ID", FilterOperator.EQ, quarter));
			currentYear++;
		}
		return quarterFilter;
	}

	/**
	 * @author DARSHAN
	 * @function getOpportunitiesTeam
	 * @description function to get OpportunitiesTeam
	 * @param {string} sOpportunityId for filter
	 * @param {Boolean} selectParam for url $select
	 * @param {Array} filters for comparison
	 */
	async getOpportunitiesTeam(opportunityId, selectParam, filters) {
		let filterData = [];
		if (opportunityId) {
			if (filters && filters.length > 0) {
				filterData = filters;
			}

			let parameters = {
				urlParameters: {
					$select: selectParam
						? selectParam
						: Actions.OpportunityTeamUrlParm.select,
					$expand: Actions.OpportunityTeamUrlParm.expand,
				},
				filters: filterData,
			};
			let oResponse = this._service.getOpportunityTeam(
				opportunityId,
				parameters
			);
			return oResponse;
		}
	}

	/**
	 * @author DARSHAN
	 * @function getTeamBP
	 * @description function to get
	 * @param {Array} team
	 * @returns {Array}
	 */
	async getTeamBP(team) {
		let promises = [];
		team.forEach((user) => {
			promises.push(this._service.getBusinessPartner(user.id));
		});
		return Promise.all(promises);
	}

	/**
	 * @author DARSHAN
	 * @private
	 * @function _getTeamOpportunities
	 * @description function to fetch Opportunities based on users data (Helper Function)
	 * @returns {Array} businessPartners
	 */
	async _getTeamOpportunities(businessPartners) {
		const promises = [];
		const bpCount = 2;
		const records = businessPartners.length;
		const iteration = Math.ceil(records / bpCount);
		for (let i = 0; i < iteration; i++) {
			let parameters;
			const partnerFilter = [];
			const startIndex = i * bpCount;
			const endIndex = startIndex + bpCount;
			let batchRecords = businessPartners.slice(startIndex, endIndex);
			let statusFilter = new Filter({
				filters: [
					new Filter({
						path: "STATUS",
						operator: FilterOperator.EQ,
						value1: "E0001",
					}),
					new Filter({
						path: "STATUS",
						operator: FilterOperator.EQ,
						value1: "E0007",
					}),
				],
				bAnd: false,
			});
			batchRecords.forEach(function (userBp) {
				if (userBp.data.results.length) {
					const businessPartner = userBp.data.results[0].PARTNER;
					let partnerIdFilter = new Filter({
						path: "SALES_TEAM_MEMBER",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: businessPartner,
					});
					partnerFilter.push(partnerIdFilter);
				}
			});
			parameters = {
				filters: [
					new Filter({
						filters: [
							new Filter({
								filters: partnerFilter,
								bAnd: false,
							}),
							statusFilter,
						],
						bAnd: true,
					}),
				],
				urlParameters: {
					$select: Actions.OpportunityTeamUrlParm.select,
				},
			};
			promises.push(this._service.getOpportunity(parameters));
		}
		return Promise.all(promises);
	}

	/**
	 * @author DARSHAN
	 * @private
	 * @function getTeamOpportunity
	 * @description function to fetch Opportunities based on users data
	 * @param {Array} userIds
	 * @returns {Array}
	 */
	async getTeamOpportunity(teamMembers = []) {
		try {
			if (this._data.teamOpportunities.length) {
				return this._data.teamOpportunities;
			}

			// this.setOpportunitiesBusy(true);
			const user = await this.authState.getUser();
			let team = [];
			if (teamMembers.length) {
				team = team.concat(teamMembers);
			} else {
				team = await this.authState.getMyTeam();
			}
			const teamBPData = await this.getTeamBP(team);
			const batchCount = 100;
			const totalRecords = teamBPData.length;
			const batches = Math.ceil(totalRecords / batchCount);
			const promises = [];
			for (let i = 0; i < batches; i++) {
				const startIndex = i * batchCount;
				const endIndex = startIndex + batchCount;
				const records = teamBPData.slice(startIndex, endIndex);
				promises.push(this._getTeamOpportunities(records));
			}
			if (promises.length) {
				let responses = (await Promise.allSettled(promises)) || [];
				let tempResult = responses.map((odata) => {
					return odata["value"];
				});
				let oppResponseData = [].concat(...tempResult);
				if (oppResponseData.length) {
					let concatData = [];
					for (let i = 0; i < oppResponseData.length; i++) {
						concatData = concatData.concat(oppResponseData[i].data.results);
					}
					// this._data.teamOpportunities =
					// 	this._data.teamOpportunities.concat(concatData);
					this._data.teamOpportunities = this.formatOpportunityData(concatData);
					this.getOpportunitySlDetails(this._data.teamOpportunities);
					this.updateModel();
					return this._data.teamOpportunities;
				}
			}
			// this.setOpportunitiesBusy(false);
		} catch (error) {
			this.setOpportunitiesBusy(false);
			console.log("ERROR IN getTeamOpportunity : ", error);
		}
	}

	/**
	 * @author DARSHAN
	 * @private
	 * @function formatOpportunityData
	 * @description function to format Opportunities as a class
	 * @param {Array} results
	 * @returns {Array}
	 */
	formatOpportunityData(results) {
		let opportunities = [];
		for (let i = 0; i < results.length; i++) {
			const opportunity = new Opportunity(results[i]);
			if (results[i].STATUS && results[i].STATUS !== "") {
				const status = this._data.statuses[results[i].STATUS] || {};
				opportunity.setStatus({
					key: status?.KEY,
					value: status?.VALUE,
				});
			}

			if (results[i].CURR_PHASE && results[i].CURR_PHASE !== "") {
				const phase = this._data.phases[results[i].CURR_PHASE] || {};
				opportunity.setPhase({
					key: phase?.KEY,
					value: phase?.VALUE,
				});
			}

			opportunity.setActive();
			opportunities.push(opportunity);
		}
		return opportunities;
	}

	async setTimeConfig(config) {
		const opportunities = this._data.opportunities;
		for (let i = 0; i < config.length; i++) {
			let opportunity = opportunities.find(function (item) {
				return item.id === config[i].OpportunityID;
			});

			if (opportunity) {
				opportunity.time.associatedIO = config[i].AssociatedIO;
				opportunity.time.isDefault = config[i].IsDefault === "X" ? true : false;
				opportunity.time.isVisible = config[i].IsVisible === "X" ? true : false;
				opportunity.time.isArchive = config[i].IsArchive === "X" ? true : false;
				opportunity.time.indicator = "";
			}
		}
		this.updateModel();
	}
}
