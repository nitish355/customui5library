import BaseState from "com/melodylib/core/state/BaseState";
import Account from "com/melodylib/integration/classes/Account";
import AccService from "com/melodylib/integration/service/AccService";
import AccountVariant from "com/melodylib/integration/classes/AccountVariant";
/**
 * @name com.melodylib.integration.state.AccountState
 */
export default class AccountState extends BaseState {
	constructor() {
		super(AccService.getInstance());
		this._data = {
			accounts: [],
			variant: new AccountVariant(),
			countries: [],
			searchedAccounts: {},
		};
		this.init();
	}

	static getInstance() {
		if (!this._instance) {
			this._instance = new AccountState();
		}
		return this._instance;
	}

	async init() {
		await this.getAccountSearchVariant(true);
	}

	/**
	 * @author DARSHAN
	 * @function setAccount
	 * @description function to set user's active account data from opportunities
	 * @param {Array} accounts
	 */
	setAccount(accounts) {
		this.getModel().setProperty("/accounts", accounts);
		this.updateModel();
	}

	async getAccountSearchVariant(hardRefresh) {
		let variant = this._data.variant;
		if (!hardRefresh && variant && variant.variantId !== "") {
			return variant;
		}
		const { data } = await this._service.getAccountSearchVariant();
		if (data?.results.length) {
			let result = data.results[0];
			const variantId = result.variantid;
			if (result.filterstring) {
				result = JSON.parse(result.filterstring);
			}
			result.variantid = variantId;
			variant = new AccountVariant(result);
		} else {
			variant = new AccountVariant();
		}

		this._data.variant = variant;
		this.updateModel();
		return data;
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function _searchDataInPrevStateObject
	 * @description function to search the data in accountStateData
	 * @param {String} query
	 * @param {Object} accountStateData
	 */
	_searchDataInPrevStateObject(query, accountStateData) {
		try {
			let accountResult = [];
			let valuePresent = false;
			query = query.toString().trim();
			let isId = Number(query) ? true : false;
			let accountKeys = Object.keys(accountStateData);
			if (!query || !accountKeys.length) {
				return {
					valuePresent,
				};
			}

			//check the key and value
			if (query && accountStateData) {
				accountResult = accountStateData[query];
				if (accountResult && accountResult.length) {
					valuePresent = true;
					return {
						valuePresent,
						accountResult,
					};
				}
			}

			//Below logic is to find data in deeper objects from the prevQueryStateData
			accountResult = [];
			query = query.toLowerCase();
			let isMoreWords = query.split(" ").length >= 2 ? true : false;
			let firstWords = isMoreWords ? query.split(" ")[0] : "";
			let indexSearchedKey = -1;
			if (firstWords) {
				indexSearchedKey = accountKeys.indexOf(firstWords);
			}
			let queryResult = this._findDeeperInQueryData({
				valuePresent,
				accountKeys,
				indexSearchedKey,
				accountResult,
				isMoreWords,
				accountStateData,
				query,
			});
			return queryResult;
		} catch (error) {
			console.log("ERROR IN _searchDataInPrevStateObject : ", error);
		}
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function _findDeeperInQueryData
	 * @description funtion to find data deeper in all accountStateData
	 * @param {Object} options
	 */
	_findDeeperInQueryData(options) {
		try {
			let {
				valuePresent,
				accountKeys,
				indexSearchedKey,
				accountResult,
				isMoreWords,
				accountStateData,
				query,
			} = options;
			for (let i = 0; i < accountKeys.length; i++) {
				let accountkey = accountKeys[i];
				let result;
				if (indexSearchedKey !== -1) {
					let queryData = $.extend(
						true,
						[],
						accountStateData[accountKeys[indexSearchedKey]]
					);
					result = this._findDataInPrevQueryData(
						accountResult,
						queryData,
						query
					);
					if (result.valuePresent) {
						return result;
					}
				}

				let accountValues = $.extend(true, [], accountStateData[accountkey]);
				if (accountValues.length) {
					const result = accountValues.find((data) => {
						let accountName = data.name || "";
						if (accountName) {
							accountName = accountName.toLowerCase();
						}
						if (data.id.includes(query) || accountName.includes(query)) {
							return true;
						}
					});
					if (result) {
						const index = accountResult.findIndex((data) => {
							return data.id === result.id;
						});
						if (index === -1) {
							valuePresent = true;
							accountResult.push(result);
						}
					}
				}
			}
			return {
				valuePresent,
				accountResult,
			};
		} catch (error) {
			console.log("ERROR IN _findDeeperInQueryData : ", error);
		}
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function _findDataInPrevQueryData
	 * @description function to find data inside the prevQueryState Data
	 * @param {Array} accountResult
	 * @param {Array} queryData
	 * @param {String} value
	 */
	_findDataInPrevQueryData(accountResult, queryData, value) {
		let valuePresent = false;
		for (let i = 0; i < queryData.length; i++) {
			const data = queryData[i];
			let accountName = data.name || "";
			if (accountName) {
				accountName = accountName.toLowerCase();
			}
			if (accountName.includes(value)) {
				let index = accountResult.findIndex((item) => {
					return item.id === data.id;
				});
				if (index === -1) {
					valuePresent = true;
					accountResult.push(data);
				}
			}
		}
		return {
			valuePresent,
			accountResult,
		};
	}

	async search(query) {
		if (!query) {
			return [];
		}
		query = query.toLowerCase();
		let accountStateData =
			this._searchDataInPrevStateObject(query, this._data.searchedAccounts) ||
			{};
		if (accountStateData?.valuePresent) {
			this._data.searchedAccounts[query] = accountStateData.accountResult;
			return accountStateData.accountResult;
		}
		const { data } = await this._service.getUserAccounts(query);
		let results = data?.results ? data.results : [];
		let accounts = Array.from(
			results,
			(account) =>
				new Account({
					id: account.PARTNER,
					name: account.NAME,
				})
		);
		accounts = await this.getAccountsDetail(accounts);
		this._data.searchedAccounts[query] = accounts;
		return accounts;
	}

	async getAccountsDetail(accounts) {
		if (!accounts) {
			return [];
		}

		const results = await this._service.getZSBupaInfoSet(accounts);
		for (let i = 0; i < results.length; i++) {
			if (results[i].status === "fulfilled") {
				const { data } = results[i].value;

				const account = accounts.find((item) => {
					if (item.id === data.GlobalUltimateId) {
						return true;
					}
					//worst case if data not found
					if (item.id === data.BusinessPartnerNumber) {
						return true;
					}
				});

				if (account) {
					const street = data.HouseNo
						? "#" + data.HouseNo + ", " + data.Street
						: data.Street;
					account.globalUltimate =
						data.GlobalUltimateId === this.AccountId ? true : false;
					account.street = street
						? data.ZipCode
							? street + ", " + data.ZipCode
							: street
						: data.ZipCode
							? data.ZipCode
							: "";
					account.countryKey = data.Country;
					account.industryName = data.IndustryName;
					account.industryKey = data.Industry;
					account.isPlanningEntity = data.PlanningEntityId ? true : false;
					account.peId = data.PlanningEntityId;
					account.peName = data.PlanningEntityName;
					account.city = data.City;
					account.regionCode = data.Region;
					account.region = data.Region;
				}
			}
		}
		return accounts;
	}
}
