sap.ui.define(
	[
		"sap/ui/model/Sorter",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"com/melodylib/core/service/CoreService",
	],
	function (Sorter, Filter, FilterOperator, CoreService) {
		"use strict";

		var AccountService = CoreService.extend(
			"com.melodylib.integration.service.AccountService",
			{
				//Deprecated function TODO: Need to check
				getMyAccounts: function () {
					return this.http(
						"/xs_app-Harmony_Insight/gsu/accounts/my-accounts"
					).get();
				},

				//Deprecated function TODO: Need to check
				getAdvanceDetails: function (accounts) {
					Promise.allSettled = function (promises) {
						let mappedPromises = promises.map((p) => {
							return p
								.then((value) => {
									return {
										status: "success",
										value,
									};
								})
								.catch((reason) => {
									return {
										status: "error",
										reason,
									};
								});
						});
						return Promise.all(mappedPromises);
					};

					const aPromises = [];

					for (let i = 0; i < accounts.length; i++) {
						aPromises.push(
							this.http(
								"/xs_app-Harmony_Insight/gsu/accounts/" + accounts[i].AccountId
							).get()
						);
					}

					return Promise.allSettled(aPromises);
				},

				//function to fetch the country master data
				getCountryMasterData: function () {
					return this.odata("/YC_UT_M_COUNTRY").get("utility");
				},

				//function to set user searched/selected account data
				setUserSrchAcctVariant: function (oData) {
					return this.odata("/YC_UT_ACC_VARIANT").post("utility", oData);
				},

				//function to get user searched/selected account data
				getUserSrchAcctVariant: function (oData) {
					return this.odata("/YC_UT_ACC_VARIANT").get("utility");
				},

				//function to get Z1S CRM BUPA Info Set
				getZSBupaInfoSet: function (accountId) {
					let oParameters = {
						urlParameters: {
							$select:
								"PARTNER,PARTNER_NAME,GTM_ISS_DESC,TG_ACCOUNT_DESC,SEGMENT,SEGMENT_DESC, GTM_ISS,GTM_ISS_DESC, PARENT_ACC_OWNR_NM,PARENT_ACC_OWNER,STATUS_DESC,STATUS_DESC,GTM_BUY_REG_DESC,GTM_BUY_GLB_DESC,SEGMENT_DESC,ERP_ID,",
						},
					};
					return this.odata("/Z1S_CRM_BUPA_INFOSet('" + accountId + "')").get(
						"harmony"
					);
				},
			}
		);
		return new AccountService();
	}
);
