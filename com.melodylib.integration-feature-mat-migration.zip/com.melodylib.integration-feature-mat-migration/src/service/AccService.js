import CoreService from "com/melodylib/core/service/CoreService";
import Filter from "sap/ui/model/Filter";
import FilterOperator from "sap/ui/model/FilterOperator";
import OppService from "com/melodylib/integration/service/OppService";

/**
 * @name com.melodylib.integration.service.AccService
 */
export default class AccService extends CoreService {
    constructor () {
		super();
        this.opportunityService = OppService.getInstance();
	}
    static getInstance() {
        if (!this.instance) {
            this.instance = new AccService();
        }
        return this.instance;
    }

    //function to get user searched/selected account data
    getAccountSearchVariant () {
        return this.odata("/YC_UT_ACC_VARIANT").get("utility");
    }

    getUserAccounts (search) {
        return this.opportunityService.getBusinessPartner(search, [new Filter("TYPE", FilterOperator.EQ, "A")]);
    }

    getZSBupaInfoSet (accounts) {
        const promises = [];
        const url = "/Z1S_CRM_BUPA_INFOSet";
        for (let i = 0; i < accounts.length; i++) {
            promises.push(this.odata(url + "('" + accounts[i].id + "')").get("harmony"));
		}
        return Promise.allSettled(promises);
    }
}