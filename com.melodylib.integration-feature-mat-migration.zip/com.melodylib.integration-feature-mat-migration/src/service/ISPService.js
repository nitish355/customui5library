import CoreService from "com/melodylib/core/service/CoreService";

/**
 * @name com.melodylib.integration.service.ISPService
 */
export default class ISPService extends CoreService {
    constructor() {
        super();
    }

    static getInstance() {
        if (!this.instance) {
            this.instance = new ISPService();
        }
        return this.instance;
    }

    getUserInfo () {
        return this.odata("/Userinfo").get("isp");
    }

    getISPData (userId, fromDate, toDate, entity) {
        const url = this._generateISPURL(userId, fromDate, toDate, entity);
        return this.odata(url).get("isp");
    }

    _generateISPURL (sUserId, sFromDate, sToDate, sEntity) {
        return "/Param(Pernr='" + sUserId + "',Datefrom='" + sFromDate + "',Dateto='" + sToDate + "')/" + sEntity;
    }

    submitEntries (entries) {
        const batches = [];
        for (let i = 0; i < batches.length; i++) {
            batches.push({
                type: "createEntry",
                url: "/ActivityHeader",
                data: entries[i]
            });
        }
        return this.odata("/ActivityHeader").batchCreateEntry("isp", batches, "isp");
    }


}