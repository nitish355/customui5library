import Filter from "sap/ui/model/Filter";
import FilterOperator from "sap/ui/model/FilterOperator";
import Actions from "com/melodylib/integration/enum/Actions";
import CoreService from "com/melodylib/core/service/CoreService";

/**
 * @name com.melodylib.integration.service.OppService
 */
export default class OppService extends CoreService {
	constructor() {
		super();
	}
	static getInstance() {
		if (!this.instance) {
			this.instance = new OppService();
		}
		return this.instance;
	}

	getAppValueHelps() {
		const parameters = {};
		const fieldFilter = new Filter({
			filters: [
				new Filter("FIELD_NAME", FilterOperator.EQ, "STATUS"),
				new Filter("FIELD_NAME", FilterOperator.EQ, "PHASE"),
			],
			and: false,
		});
		parameters.filters = [
			new Filter({
				filters: [
					fieldFilter,
					new Filter("ENTITY_NAME", FilterOperator.EQ, "Opportunity"),
				],
				and: true,
			}),
		];
		return this.odata("/AppValueHelps").get("harmony", parameters);
	}

	getConstants() {
		return this.odata("/Yc_Mac_M_Constants").get("activity");
	}

	getBusinessPartner(
		search,
		filters = [new Filter("TYPE", FilterOperator.EQ, "E")]
	) {
		if (search) {
			search = search.toLowerCase();
		}

		const params = {
			search: search,
			filters: filters,
		};
		const options = this.getUrlParameters(params);
		return this.odata("/BusinessPartners").get("harmony", options);
	}

	getNonVATOpportunities(params, isCount) {
		const url = isCount ? "/Opportunities/$count" : "/Opportunities";
		const options = this.getUrlParameters(params);
		return this.odata(url).get("harmony", options);
	}

	getOpportunities(params) {
		const options = this.getUrlParameters(params);
		return this.odata("/Opportunities").get("harmony", options);
	}

	getOpportunityCount(params) {
		const options = this.getUrlParameters(params);
		return this.odata("/Opportunities/$count").get("harmony", options);
	}

	getOpportunityDetail(oppIds) {
		const promises = [];
		const params = {
			select: Actions.GetOpportunityDetailParam.select,
			expand: "PartiesInvolved",
		};
		const url = "/Opportunities";
		for (let i = 0; i < oppIds.length; i++) {
			const options = this.getUrlParameters(params);
			promises.push(
				this.odata(url + "('" + oppIds[i] + "')").get("harmony", options)
			);
		}
		return Promise.allSettled(promises);
	}

	getOpportunity(mParameters) {
		return this.odata("/Opportunities").get("harmony", mParameters);
	}

	getOpportunityTeam(opportunityId, parameters) {
		return this.odata("/Opportunities('" + opportunityId + "')").get(
			"harmony",
			parameters
		);
	}

	getOpportunitySlDetails(options) {
		let parameters = {
			filters: options?.filters,
			urlParameters: options?.urlParams,
		};
		return this.odata("/OPPORTUNITYNOSet").get("activityList", parameters);
	}

	/* getOpportunityDetail (oppIds) {
        let batches = [];
        const params = {
            select: "CLOUD_REVENUE,SALES_ORG_TEXT,SALES_ORG_SHORT,OPPT_ID," +
            "INTERNAL_ORDER1,INTERNAL_ORDER2,LICENSE_REVENUE,REPLACED_BY,STATUS_SINCE",
            expand: "PartiesInvolved"
        }
        const url = "/Opportunities";
        for (let i = 0; i < oppIds.length; i++) {
            const options = this.getUrlParameters(params);
            batches.push({
                type: "read",
                parameters: options,
                url: url + "('" + oppIds[i] + "')",
            });
        }
        return this.odata(url).batch("harmony", batches, "opportunity");
    } */
}
