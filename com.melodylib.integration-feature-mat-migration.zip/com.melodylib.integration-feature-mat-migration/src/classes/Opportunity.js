import Object from "sap/ui/base/Object";
import AuthState from "com/melodylib/core/state/AuthState";
import IndexedDB from "com/melodylib/core/db/IndexedDB";
import StaffingState from "com/melodylib/time/state/StaffingState";
import Staffing from "com/melodylib/time/classes/Staffing";
import DateUtility from "com/melodylib/core/util/DateUtility";
import InternalOrder from "com/melodylib/time/classes/InternalOrder";

/**
 * @namespace com.melodylib.integration.classes.Opportunity
 */
export default class Opportunity extends Object {
	constructor(data, status, phase, isDetailAvailable) {
		super();
		this.time = {};
		this.associatedIO = {};
		this.setData(data, status, phase, isDetailAvailable);
	}

	setData(data, status, phase, isDetailAvailable) {
		if (!data) {
			data = {};
		}
		this.id = data.OPPT_ID || "";
		this.guid = data.GUID || "";
		this.description = data.DESCRIPTION || "";
		this.accountId = data.ACCOUNT || "";
		this.accountName = data.ACCOUNT_NAME ? data.ACCOUNT_NAME : "";
		this.expectedValue = data.EXPECTED_VALUE || "";
		this.expectedEndDate = data.EXPECT_END || null;
		this.owner = data.OWNER || "";
		this.ownerEmpId = data.OWNER_EMPID || "";
		this.ownerName = data.OWNER_NAME || "";
		this.replacedBy = data.REPLACED_BY || "";

		this.account = {
			id: data.ACCOUNT || "",
			name: data.ACCOUNT_NAME || ""
		};

		if (status) {
			this.setStatus(status);
		}

		if (phase) {
			this.setPhase(phase);
		}

		this.isDetailAvailable = isDetailAvailable ? true : false;

		if (this.isDetailAvailable) {
			this.setDetail(data);
		}

		this.setTeam(data.PartiesInvolved?.results);
	}

	getUser() {
		const authState = AuthState.getInstance();
		return authState.getData();
	}

	setStatus(status) {
		this.status = status;
	}

	setPhase(phase) {
		this.phase = phase;
	}

	calculateGracePeriod(expectedEndDate) {
		if (expectedEndDate) {
			const date = Date.parse(expectedEndDate);
			const expEndDate = isNaN(parseFloat(date))
				? new Date(expectedEndDate.match(/\d+/)[0] * 1)
				: expectedEndDate;
			const currentDate = new Date();
			const timeDiff = currentDate.getTime() - expEndDate.getTime();
			const daysLeft = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
			return daysLeft;
		}
		return 0;
	}

	setAllowed(gracePeriod) {
		if (gracePeriod && this.status) {
			if (
				gracePeriod > 90 &&
				["E0002", "E0003", "E0004", "E0005"].includes(this.status.key)
			) {
				return false;
			} else {
				return true;
			}
		}
		return null;
	}

	setIOSetting(salesOrg) {
		const user = this.getUser();
		const updateIOArtes = user.updateIOArtes;
		const companyCode = user.companyCode;

		const isCloud = this.isCloud();

		let ioSetting = "No";
		if (updateIOArtes === "1") {
			// condition for 'Default Yes'
			ioSetting = "Yes";
		} else if (updateIOArtes === "2") {
			// condition for 'Default No'
			ioSetting = "No";
		} else if (updateIOArtes === "3") {
			// condition for 'Autoset'
			if (isCloud === "Error") {
				ioSetting = "Error";
			} else {
				if (companyCode === salesOrg) {
					ioSetting = "No";
				} else {
					ioSetting = "Yes";
				}
			}
		} else if (updateIOArtes === "4") {
			// condition for 'Yes ex Cloud'
			if (isCloud === "Yes") {
				ioSetting = "No";
			} else if (isCloud === "Error") {
				ioSetting = "Error";
			} else {
				// else IO Setting is Yes
				ioSetting = "Yes";
			}
		} else if (updateIOArtes === "5") {
			if (companyCode === salesOrg || isCloud === "Yes") {
				ioSetting = "No";
			} else if (isCloud === "Error") {
				ioSetting = "Error";
			} else {
				// else IO Setting is Yes
				ioSetting = "Yes";
			}
		}
		return ioSetting;
	}

	isCloud() {
		// if Opportunity's License Revenue not exist and Cloud Revenue is more than zero,
		// then the Opportunity is On Cloud else On Prem
		if (this.id) {
			const licenseRevenue = parseFloat(this.licenseRevenue);
			const cloudRevenue = parseFloat(this.cloudRevenue);
			if (
				(isNaN(licenseRevenue) || licenseRevenue === 0) &&
				!isNaN(cloudRevenue) &&
				cloudRevenue > 0
			) {
				return "Yes";
			} else if (
				(isNaN(licenseRevenue) || licenseRevenue === 0) &&
				!isNaN(cloudRevenue) &&
				cloudRevenue === 0
			) {
				return "Error";
			}
		}
		return "No";
	}

	setDetail(data) {
		this.licenseRevenue = data.LICENSE_REVENUE || "";
		this.cloudRevenue = data.CLOUD_REVENUE || "";
		this.revenueType = data.REVENUE_TYPE || "";
		this.internalOrder1 = data.INTERNAL_ORDER1 ? data.INTERNAL_ORDER1 : "";
		this.internalOrder2 = data.INTERNAL_ORDER2 ? data.INTERNAL_ORDER2 : "";
		this.gracePeriod = this.calculateGracePeriod(data.EXPECT_END);
		this.replacedBy = data.REPLACED_BY ? data.REPLACED_BY : "";

		this.salesOrgText = data.SALES_ORG ? data.SALES_ORG_TEXT : "";
		this.source = data.SOURCE ? data.SOURCE : "";
		this.statusSince = data.STATUS_SINCE ? data.STATUS_SINCE : null;
		this.isDetailAvailable = true;

		this.isAllowed = this.setAllowed(this.gracePeriod);
		this.gracePeriodStatus = this.isAllowed
			? this.calculateGracePeriod(data.STATUS_SINCE)
			: "";
		this.isAllowedStatus = this.isAllowed
			? this.setAllowed(this.gracePeriodStatus)
			: "";

		this.salesOrgShort = data.SALES_ORG_SHORT ? data.SALES_ORG_SHORT : "";
		let salesOrg = this.salesOrgShort.split("-");
		salesOrg = salesOrg && salesOrg.length > 1 ? salesOrg[1] : "";
		this.ioSetting = this.setIOSetting(salesOrg);
		const internalOrders = [];
		const staffingState = StaffingState.getInstance();
		const staffings = staffingState.getData() || [];
		if (data.INTERNAL_ORDER1) {
			const internalOrder1 = data.INTERNAL_ORDER1.replace(/^0+/, "");
			const staffings1 = staffings.filter(function (item) {
				return (
					item.internalOrder !== "" && item.internalOrder === internalOrder1
				);
			});

			staffings1.sort(function (a, b) {
				const dT1 = DateUtility.formatStringDate(a.EndDate);
				const dT2 = DateUtility.formatStringDate(b.EndDate);
				return dT2 > dT1 ? -1 : 1;
			});

			internalOrders.push(new InternalOrder({
				id: internalOrder1,
				description: (staffings1.length) ? staffings1[0].description : "",
				objnr: (staffings1.length) ? staffings1[0].objnr : "",
				obart: (staffings1.length) ? staffings1[0].obart : "",
				raufnr: (staffings1.length) ? staffings1[0].raufnr : "",
				staffings: staffings1
			}));
		}
		if (data.INTERNAL_ORDER2 && data.INTERNAL_ORDER2 !== "") {
			const internalOrder2 = data.INTERNAL_ORDER2.replace(/^0+/, "");
			const staffings2 = staffings.filter(function (item) {
				return (
					item.internalOrder !== "" && item.internalOrder === internalOrder2
				);
			});
			internalOrders.push(new InternalOrder({
				id: internalOrder2,
				description: (staffings2.length) ? staffings2[0].description : "",
				objnr: (staffings2.length) ? staffings2[0].objnr : "",
				obart: (staffings2.length) ? staffings2[0].obart : "",
				raufnr: (staffings2.length) ? staffings2[0].raufnr : "",
				staffings: staffings2
			}));
		}
		if (internalOrders.length > 0) {
			if (this.associatedIO.id) {
				const associatedIO = internalOrders.find(item => item.id === this.associatedIO.id);
				if (associatedIO) {
					this.associatedIO = associatedIO;
				} else {
					this.associatedIO = internalOrders[0];
				}
			} else {
				this.associatedIO = internalOrders[0];
			}
		}
		this.availableIOs = internalOrders;
	}

	/**
	 * @author DARSHAN
	 * @function setNonVAT
	 * @description function to set NONVAT Properties
	 */
	setNonVAT(data) {
		this.displayAuth = data.DISP_AUTH ? data.DISP_AUTH : false;
	}

	/**
	 * @author DARSHAN
	 * @function setActive
	 * @description function to set Active Opportunity
	 */
	setActive() {
		const now = new Date();
		now.setHours(0, 0, 0, 0);

		const previous = new Date(now);
		previous.setFullYear(now.getFullYear() - 1);

		const next = new Date(now);
		next.setFullYear(now.getFullYear() + 5);

		const statuses = ["E0001", "E0007"];
		if (
			this.expectedEndDate < previous ||
			this.expectedEndDate > next ||
			statuses.indexOf(this.status.key) === -1
		) {
			this.isActive = false;
		} else {
			this.isActive = true;
		}
	}

	/**
	 * @author DARSHAN
	 * @function setSlDetail
	 * @description function to set SL Related Data
	 */
	setSlDetail(data) {
		this.activities = data?.Activities || "0";
		this.manager = data?.Manager || "";
		this.slsnro = data?.Slsnro || "";
	}

	/**
	 * @author SRIKARI
	 * @function setTeam
	 * @description function to set team membes data
	 */
	setTeam(data) {
		this.team = data?.map(user =>{
			return {
				id: user.USER_ID,
				name: user.NAME,
				email: user.EMAIL,
				roleDescription: user.ROLE_DESCR
			}
		})
	}
}