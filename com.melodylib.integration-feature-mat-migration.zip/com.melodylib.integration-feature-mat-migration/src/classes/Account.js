import Object from "sap/ui/base/Object";
/**
 * @namespace com.melodylib.integration.classes.Account
 */
export default class Account extends Object {
    constructor(data) {
        super();
        if (data) {
            this.id = data?.id || "";
            this.name = data?.name || "";
            this.isUserAccount = data?.isUserAccount || false;
        }
    }
}