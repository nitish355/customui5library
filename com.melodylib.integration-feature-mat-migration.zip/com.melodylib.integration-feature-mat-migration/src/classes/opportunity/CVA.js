sap.ui.define(
	["com/melodylib/integration/classes/BaseObject"],
	function (BaseObject) {
		"use strict";
		var Cva = BaseObject.extend("com.melody.lib.classes.CVA.Opportunity", {
			constructor: function (oData) {
				BaseObject.call(this);
				this.setData(oData);
			},

			setData: function (oData) {
				this.accountid = oData.PARTNER;
				this.ACCOUNT_NAME = oData.PARTNER_NAME;
				this.SEGMENT = oData.SEGMENT_DESC;
				this.OWNER_NAME = oData.PARENT_ACC_OWNR_NM;
				this.OWNER = oData.PARENT_ACC_OWNER;
				this.ISS = oData.GTM_ISS_DESC;
				this.STATUS_DESC = oData.STATUS_DESC;
				this.Active_Account_Status = oData.STATUS_DESC;
				this.Regional_Buying_Classificatio = oData.GTM_BUY_REG_DESC;
				this.Regional_Buying_Lifecycle = oData.GTM_BUY_GLB_DESC;
				this.Internal_Account_Classification = oData.TG_ACCOUNT_DESC;
				this.IMS = oData.SEGMENT_DESC;
				this.ERPID = oData.ERP_ID;
				this.AccountId_Name = oData.PARTNER_NAME + "-" + oData.PARTNER;
			},
		});
		return Cva;
	}
);
