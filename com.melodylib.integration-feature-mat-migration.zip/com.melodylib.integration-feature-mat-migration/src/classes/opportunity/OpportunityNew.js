import * as BaseObject from "../BaseObject";

export default class Opportunity extends BaseObject {
	constructor(data) {
		super();
		this.setData(data);
	}

	setData(data) {
		this.AccountId = data && data.AccountId ? data.AccountId : "";
		this.AccountName = data && data.AccountName ? data.AccountName : "";
		this.OpportunityId = data && data.OpportunityId ? data.OpportunityId : "";
		this.OpportunityName =
			data && data.OpportunityName ? data.OpportunityName : "";
		this.Description = data && data.Description ? data.Description : "";
		this.Status = data && data.Status ? data.Status : "";
		this.ExpectedEnd = data && data.ExpectedEnd ? data.ExpectedEnd : "";
		this.ExpectedValue = data && data.ExpectedValue ? data.ExpectedValue : "";
		this.Phase = data && data.Phase ? data.Phase : "";
		this.Owner = data && data.Owner ? data.Owner : "";
		this.OwnerName = data && data.OwnerName ? data.OwnerName : "";
		this.Industry_MasterCode_Text =
			data && data.Industry_MasterCode_Text
				? data.Industry_MasterCode_Text
				: "";
		this.Industry = data && data.Industry ? data.Industry : "";
		this.Industry_Text = data && data.Industry_Text ? data.Industry_Text : "";
		this.Sales_Org_Desc =
			data && data.Sales_Org_Desc ? data.Sales_Org_Desc : "";
		this.Industry_MasterCode =
			data && data.Industry_MasterCode ? data.Industry_MasterCode : "";
		this.StatusDescription =
			data && data.StatusDescription ? data.StatusDescription : "";
		this.Guid = data && "Guid" in data ? data.Guid : "";
		this.ChangedAt = data && "ChangedAt" in data ? data.ChangedAt : "";
		this.DisplayAuth = data && "DisplayAuth" in data ? data.DisplayAuth : false;
	}

	setDefault() {
		return {
			bShowOpportunityDetails: false,
			selectedOpportunityTeam: {
				ACCOUNT_EXECUTIVE: {},
				PRESALES_LEAD: {},
				PRESALES_MANAGER: [],
				PRESALES_TEAM: [],
				EXECUTIVE_SPONSOR: [],
				PCSM: [],
				SUPPORT: {},
				RESOURCE_MANAGER: [],
				EA_ENGAGEMENT_CSD: {},
				EA_ENGAGEMENT_GAD: {},
				EA_ENGAGEMENT_IAE: {},
				EA_ENGAGEMENT_DIRECTOR: {},
				EA_ENGAGEMENT_IVE: {},
				REQUESTOR_MANAGER: {},
				// "EA_ENGAGEMENT_TEAM": [],
				HSC_TEAM: [],
				ACCOUNT_OWNER: {},
			},
			selectedOpportunity: {
				OPPT_ID: "",
			},
			opptValueState: "None",
			opptEnabled: true,
			opportunity: [],
			isOpptDilogBusy: false,
			bActiveOppGrowing: false,
			aActiveOppStatus: [
				{
					key: "",
					value: "All",
				},
				{
					key: "1",
					value: "Active",
				},
				{
					key: "0",
					value: "In Active",
				},
			],
		};
	}
}
