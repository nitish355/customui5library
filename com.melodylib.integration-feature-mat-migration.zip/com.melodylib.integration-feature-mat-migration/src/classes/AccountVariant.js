import Object from "sap/ui/base/Object";
/**
 * @namespace com.melodylib.integration.classes.AccountVariant
 */
export default class AccountVariant extends Object {
    constructor(data) {
        super();
        if(data) {
            this.variantId = data.variantid ? data.variantid : "";
            this.isPlanningEntity = data.sPlanningEntities ? true : false;
            this.globalUltimate = data.sGlobalUltimate ? true : false;
            this.industryKey = data.sIndustryKey ? data.sIndustryKey : "";
            this.regionKey = data.sRegionKey ? data.sRegionKey : "";
            this.countryKey = data.sCountryKey ? data.sCountryKey : "";
            this.searchQuery = data.sSearchQuery ? data.sSearchQuery : "";
        }
    }

    copy(data) {
        this.variantId = data.variantId;
        this.isPlanningEntity = data.isPlanningEntity;
        this.globalUltimate = data.globalUltimate;
        this.industryKey = data.industryKey;
        this.regionKey = data.regionKey;
        this.countryKey = data.countryKey;
        this.searchQuery = data.searchQuery;
    }

    clear() {
        this.isPlanningEntity = false;
        this.globalUltimate = false;
        this.industryKey = "";
        this.regionKey = "";
        this.countryKey = "";
        this.searchQuery = "";
    }
}