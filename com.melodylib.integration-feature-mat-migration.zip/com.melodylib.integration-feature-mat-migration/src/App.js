sap.ui.define(
	["com/melodylib/core/model/IntergrationLibraryModel"],
	function (oIntergrationLibraryModel) {
		"use strict";
		return {
			//Function to set parent application
			setApplication: async function (options) {
				let ApplicationId =
					oIntergrationLibraryModel.getProperty("/ApplicationId");
				if (!ApplicationId) {
					oIntergrationLibraryModel.setProperty(
						"/ApplicationId",
						options.appId
					);
					oIntergrationLibraryModel.setProperty(
						"/bUseBatch",
						options.bUseBatch
					);
				}
				var appPath = options.appId.replaceAll(".", "/");
				var appModulePath = jQuery.sap.getModulePath(appPath);
				console.log("APPLICATION MODULE PATH LIBRARY : ", appModulePath);
				oIntergrationLibraryModel.refresh();
				return new Promise((resolve, reject) => {
					resolve();
				});
			},

			testFunction: function (appId) {
				console.log("WORKING CROSS LIB FUNCTION CALL");
			},
		};
	}
);
