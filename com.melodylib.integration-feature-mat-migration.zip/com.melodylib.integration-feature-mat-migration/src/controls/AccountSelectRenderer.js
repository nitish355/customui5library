/*!
 * ${copyright}
 */
import Actions from "com/melodylib/integration/enum/Actions";
/**
 * AccountSelect renderer.
 * @namespace
 */
export default {
	apiVersion: 2, // usage of DOM Patcher

	/**
	 * Renders the HTML for the given control, using the provided {@link RenderManager}.
	 *
	 * @param rm The reference to the <code>sap.ui.core.RenderManager</code>
	 * @param control The control instance to be rendered
	 */
	render: function (rm, control) {
		let controlType = control.getType();
		controlType = controlType.toUpperCase();
		rm.openStart("div", control);
		rm.class("accountSelectContainer");
		rm.openEnd();
		switch (controlType) {
			case Actions.Icon:
				rm.renderControl(control.getAggregation("_icon"));
				break;
			case Actions.Input:
				control.getAggregation("_input").setWidth("95%");
				rm.renderControl(control.getAggregation("_input"));
				break;
			case Actions.Link:
				rm.renderControl(control.getAggregation("_link"));
				break;
			default:
		}
		rm.renderControl(control.getAggregation("_clearIcon"));
		rm.renderControl(control.getAggregation("_infoIcon"));
		rm.close("div");
	},
};
