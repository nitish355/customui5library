/*!
 * ${copyright}
 */

import Lib from "sap/ui/core/Lib";
import Actions from "com/melodylib/integration/enum/Actions";

/**
 * Example renderer.
 * @namespace
 */
export default {
	apiVersion: 2, // usage of DOM Patcher

	/**
	 * Renders the HTML for the given control, using the provided {@link RenderManager}.
	 *
	 * @param rm The reference to the <code>sap.ui.core.RenderManager</code>
	 * @param control The control instance to be rendered
	 */
	render: function (rm, control) {
		let controlType = control.getType();
		controlType = controlType.toUpperCase();
		const i18n = Lib.getResourceBundleFor("com.melodylib.integration");
		rm.openStart("div", control);
		//add this controls style class (plus any additional ones the developer has specified)
		rm.class("opportunitySelectContainer");
		rm.openEnd();
		//render controls based on controlType
		switch (controlType) {
			case Actions.Icon:
				rm.renderControl(control.getAggregation("_icon"));
				break;
			case Actions.Input:
				control.getAggregation("_input").setWidth("95%");
				rm.renderControl(control.getAggregation("_input"));
				break;
			case Actions.Link:
				rm.renderControl(control.getAggregation("_link"));
				break;
			default:
		}
		rm.renderControl(control.getAggregation("_clearIcon"));
		rm.renderControl(control.getAggregation("_infoIcon"));
		rm.close("div");
	},
};
