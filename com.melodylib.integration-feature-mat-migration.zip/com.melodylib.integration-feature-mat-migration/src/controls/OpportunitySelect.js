/*!
 * ${copyright}
 */
import Filter from "sap/ui/model/Filter";
import Control from "sap/ui/core/Control";
import Helper from "com/melodylib/core/util/Helper";
import Controller from "sap/ui/core/mvc/Controller";
import JSONModel from "sap/ui/model/json/JSONModel";
import DateFormat from "sap/ui/core/format/DateFormat";
import IndexedDB from "com/melodylib/core/db/IndexedDB";
import FilterOperator from "sap/ui/model/FilterOperator";
import Actions from "com/melodylib/integration/enum/Actions";
import OpportunitySelectRenderer from "./OpportunitySelectRenderer";
import OpportunityState from "com/melodylib/integration/state/OpportunityState";

class OpportunityInputController extends Controller {
	constructor(control) {
		super();
		this.control = control;
		this.opportunityState = OpportunityState.getInstance();
	}

	onInit() { }

	/***********GENERAL FUNCTIONALITIES STARTS HERE**********/

	/**
	 * @author DARSHAN
	 * @function getDialog
	 * @description function to get element from fragment using id
	 * @param {String} dialogId for Control-ID
	 * @param {String} contentId for Control-Id
	 */
	getDialog(dialogId, contentId) {
		return sap.ui.core.Fragment.byId(dialogId, contentId);
	}

	/**
	 * @author DARSHAN
	 * @function getUrlConstant
	 * @description function to get url constant "0011"
	 */
	async getUrlConstant() {
		let urlConstants =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "harmonyconstanturls",
			})) || [];
		let urlConstant =
			urlConstants.find((url) => {
				return url.id === "0011";
			}) || false;
		return urlConstant;
	}

	/**
	 * @author BALWANT,DARSHAN
	 * @function onSelectOpportunityTab
	 * @description function to handle icon tabs in active opportunities fragment
	 * @param {Event} event
	 */
	async onSelectOpportunityTab(event) {
		const selectedKey = event.getParameter("selectedKey");
		const model = this.getModel();
		const accountId = this.control.getAccountId() || null;
		try {
			switch (selectedKey) {
				case "active":
					model.setProperty("/active/searchValue", "");
					model.setProperty("/active/activeStatusSelectedKey", "");
					break;
				case "nonvat":
					let formattedData = [];
					model.setProperty("/nonVAT/loaded", 0);
					let nonVATOpportunities =
						model.getProperty("/nonVAT/opportunities") || [];
					model.setProperty("/nonVAT/busy", true);
					if (!nonVATOpportunities.length) {
						const data = await this.opportunityState.getNonVATOpportunities(
							accountId,
							false,
							0,
							"",
							true
						);
						model.setProperty("/nonVAT/count", data.count);
						formattedData = this.removeActiveOpportunity(data.opportunities);
						const concatArr = [...nonVATOpportunities, ...formattedData];
						this.setLoadMoreForNONVAT(concatArr);
						nonVATOpportunities = [
							...new Map(
								concatArr.map((obj) => [`${obj.id}:${obj.guid}`, obj])
							).values(),
						];
						model.setProperty("/nonVAT/loaded", nonVATOpportunities.length);
						model.setProperty("/nonVAT/opportunities", nonVATOpportunities);
					}
					model.setProperty("/nonVAT/busy", false);
					break;
				default:
					model.setProperty("/active/searchValue", "");
			}
		} catch (error) {
			console.log("ERROR IN onSelectOpportunityTab : ", error);
			model.setProperty("/nonVAT/busy", false);
		}
		model.refresh();
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function getActiveListControl
	 * @description function to get Active Opportunity List control
	 */
	getActiveListControl() {
		const controlId = this.control.getId();
		const list = this.getDialog(
			`${controlId}_ActiveOpportunityDialog`,
			"activeList"
		);
		return list ?? false;
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function getNonVatListControl
	 * @description function to get NON-VAT Opportunity List control
	 */
	getNonVatListControl() {
		const controlId = this.control.getId();
		let list = this.getDialog(
			`${controlId}_ActiveOpportunityDialog`,
			"nonVatList"
		);
		return list ?? false;
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function getModel
	 * @description function to get control Model
	 */
	getModel() {
		return this.control.getModel();
	}

	/**
	 * @author DARSHAN
	 * @function closeDialog
	 * @description function to close active opportunity fragment
	 * @param {Event} oEvent
	 */
	async closeDialog(event) {
		try {
			const model = this.getModel();
			this.control._resetDialogProperties();
			const activeListControl = this.getActiveListControl();
			let dialog = await this.control._oActOpportunityDialog;
			if (dialog) {
				activeListControl?.getBinding("items")?.filter([]);
				dialog.close();
				dialog.destroy();
				this.control._oActOpportunityDialog = "";
			}
			model.refresh();
		} catch (error) {
			console.log("ERROR IN closeDialog : ", error);
		}
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function onPressOpportunitySelect
	 * @description function to handle select btn in NONVAT/Active Opportunity Fragments.
	 * @param {Event} event;
	 * @param {String} opportunityType;
	 */
	async onPressOpportunitySelect(event, opportunityType) {
		try {
			let listControl;
			let helper;
			let isNonVATOpportunity = false;
			let selectedOppData = {};
			const model = this.getModel();
			model.setProperty("/active/busy", true);

			let urlConstant = await this.getUrlConstant();

			//TO CHECK NON-VAT
			if (opportunityType === "nonVAT") {
				helper = this._nonVATSelectBtnHelper(event, opportunityType);
				listControl = helper.listControl;
			} else {
				helper = this._activeSelectBtnHelper(event, opportunityType);
				listControl = helper.listControl;
			}

			selectedOppData = helper.selectedData;
			if (listControl) {
				listControl.getBinding("items").filter([]);
			}
			this.closeDialog();

			//create harmony link for selected Opportunity
			selectedOppData.harmonyLink = urlConstant
				? `${urlConstant.value}${selectedOppData.id}/plan`
				: "";
			this.control.setSelectedOpportunity(selectedOppData);
			model.setProperty("/active/busy", false);
			model.refresh();
		} catch (error) {
			console.log("ERROR IN onPressOpportunitySelect : ", error);
		}
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function _activeSelectBtnHelper
	 * @description function to handle select btn in Active Opportunity Fragments.
	 * @param {Event} event;
	 * @param {String} opportunityType;
	 */
	_activeSelectBtnHelper(event, opportunityType) {
		const listControl = this.getNonVatListControl();
		const selectedData =
			event.getSource()?.getBindingContext("opportunityState")?.getObject() ||
			{};
		selectedData.isNonVATOpportunity = false;
		return {
			listControl,
			selectedData,
		};
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function _nonVATSelectBtnHelper
	 * @description function to handle select btn in Opportunity NONVAT Opportunity Fragments.
	 * @param {Event} event;
	 * @param {String} opportunityType;
	 */
	_nonVATSelectBtnHelper(event, opportunityType) {
		const listControl = this.getNonVatListControl();
		const selectedData =
			event.getSource()?.getBindingContext()?.getObject() || {};
		selectedData.isNonVATOpportunity = true;
		return {
			listControl,
			selectedData,
		};
	}

	/**
	 * @author DARSHAN
	 * @function onNavToCRM
	 * @description function to handle navigation in Opportunity Information Popup
	 */
	async onNavToCRM() {
		const model = this.getModel();
		let urlConstant = await this.getUrlConstant();
		let selectedOppData = $.extend(
			true,
			{},
			model.getProperty("/selectedOpportunity")
		);
		window.open(urlConstant?.value + selectedOppData.id + "/plan", "_blank");
	}

	/**
	 * @author DARSHAN
	 * @function closePopover
	 * @description function to close Opportunity Info
	 * @param {Event} oEvent
	 */
	async closePopover(oEvent) {
		let dialog = await this.control._oOpportunityInfoDialog;
		if (dialog) {
			dialog.close();
			dialog.destroy();
			this.control._oOpportunityInfoDialog = "";
		}
	}

	/**
	 * @author DARSHAN
	 * @function getOpportunityStatus
	 * @description function to get status value based on status-ID
	 * @param {String} statusId
	 */
	async getOpportunityStatus(statusId) {
		let statuses =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "myopportunity-data",
				storeName: "opportunitystore",
				keyName: "pcoppstatusmasterdata",
			})) || {};
		if (Object.keys(statuses).length) {
			return statuses[statusId].VALUE;
		} else {
			return statusId;
		}
	}

	/**
	 * @author DARSHAN
	 * @function getOpportunityDate
	 * @description function to formate Opportunity Date
	 * @param {String} date
	 */
	getOpportunityDate(date) {
		let dateFormat = DateFormat.getDateInstance({
			style: "medium",
		});
		if (date && date !== null && date !== "") {
			date = new Date(date);
			return dateFormat.format(date);
		} else {
			return null;
		}
	}

	/**
	 * @author DARSHAN
	 * @function checkIsEmpty
	 * @description function to check value empty
	 * @param {String} value
	 */
	checkIsEmpty(value) {
		return value ? value : "Unavailable";
	}

	/**
	 * @author DARSHAN
	 * @function onAfterOpenDialog
	 * @description function to handle event after opening dialog
	 * @param {Object} event
	 */
	onAfterOpenDialog(event) {
		let accountId = this.control.getAccountId();
		let activeListControl = this.getActiveListControl();
		if (accountId) {
			let filter = new sap.ui.model.Filter(
				"accountId",
				sap.ui.model.FilterOperator.EQ,
				accountId
			);
			if (activeListControl) {
				activeListControl.getBinding("items").filter([filter]);
			}
		}
	}

	/***********GENERAL FUNCTIONALITIES STARTS ENDS**********/

	/***********ACTIVE OPPORTUNITIES STARTS HERE**********/

	/**
	 * @async
	 * @author DARSHAN
	 * @function onActiveOppStatusSelectHandler
	 * @description function to handle Opp Status Select
	 * @param {Event} oEvent
	 */
	async onActiveOppStatusSelectHandler(oEvent) {
		try {
			let filters = [];
			const model = this.getModel();
			let accountId = this.control.getAccountId() || null;
			let selectedStatusKey = oEvent.getSource().getSelectedKey();
			const isCvaSelected = model.getProperty("/isCvaSelected");
			const activeListControl = this.getActiveListControl();

			if (accountId) {
				filters.push(new sap.ui.model.Filter("accountId", "EQ", accountId));
			}
			if (selectedStatusKey !== "" && activeListControl) {
				selectedStatusKey = selectedStatusKey === "1" ? true : false;
				filters.push(
					new sap.ui.model.Filter("isActive", "EQ", selectedStatusKey)
				);
				activeListControl.getBinding("items").filter(filters);
			} else {
				if (activeListControl) {
					activeListControl.getBinding("items").filter(filters);
				}
			}
			model.setProperty("/active/searchValue", "");
			model.refresh();
		} catch (error) {
			console.log("ERROR IN onActiveOppStatusSelectHandler : ", error);
		}
	}

	/**
	 * @author DARSHAN
	 * @function onActOpportunitySearchHandler
	 * @description function to handle Active Opportunity Search
	 * @param {Event} oEvent
	 */
	onActOpportunitySearchHandler(oEvent) {
		const controlId = this.control.getId();
		const model = this.getModel();
		const activeListControl = this.getActiveListControl();
		let value = oEvent.getParameter("query");
		let statusSelected = model.getProperty("/active/statusSelectedKey") || "";
		this.searchOpportunities(activeListControl, value, statusSelected);
	}

	/**
	 * @author DARSHAN
	 * @function searchOpportunities
	 * @description function to handle opportunity search
	 * @param {Object} oSource - Control
	 * @param {String} sValue
	 * @param {String} sStatus
	 */
	searchOpportunities(listControl, value, status) {
		try {
			const model = this.getModel();
			const isCvaSelected = model.getProperty("/isCvaSelected");
			let accountId = this.control.getAccountId() || null;

			let opportunityFilters = new Filter({
				filters: [
					new Filter("accountName", FilterOperator.Contains, value),
					new Filter("id", FilterOperator.Contains, value),
					new Filter("description", FilterOperator.Contains, value),
					new Filter("accountId", FilterOperator.Contains, value),
				],
				and: false,
			});
			if (status) {
				let searchFilter = opportunityFilters;
				let statusFilter = new Filter("active", FilterOperator.EQ, status);
				opportunityFilters = new Filter({
					filters: [searchFilter, statusFilter],
					and: true,
				});
			}
			if (accountId) {
				let searchFilter1 = opportunityFilters;
				let accountFilter = new Filter(
					"accountId",
					FilterOperator.EQ,
					accountId
				);
				opportunityFilters = new Filter({
					filters: [searchFilter1, accountFilter],
					and: true,
				});
			}
			if (listControl) {
				let binding = listControl.getBinding("items");
				binding.filter([opportunityFilters]);
			}
		} catch (error) {
			console.log("ERROR IN searchOpportunities : ", error);
		}
	}

	/***********ACTIVE OPPORTUNITIES ENDS HERE**********/

	/***********NON-VAT STARTS HERE**********/

	/**
	 * @author BALWANT,DARSHAN
	 * @function removeActiveOpportunity
	 * @description function to filter out the active opportunities from non-vat opportunities
	 * @param {Event} oEvent
	 */
	removeActiveOpportunity(nonVATOpportunities) {
		let data = [];
		let activeOpportunity = [...this.opportunityState.getData()?.opportunities];
		for (let i = 0; i < nonVATOpportunities.length; i++) {
			let nonVAT = nonVATOpportunities[i];
			let index = activeOpportunity.findIndex((data) => {
				return data.id === nonVAT.id;
			});
			if (index === -1) {
				data.push(nonVAT);
			}
		}
		return data;
	}

	/**
	 * @author BALWANT,DARSHAN
	 * @function setLoadMoreForNONVAT
	 * @description function to set load more button options for non-vat opportunities
	 * @param {Array} nonVATData
	 */
	setLoadMoreForNONVAT(nonVATData) {
		const model = this.getModel();
		let totalCount = model.getProperty("/nonVAT/count") ?? 0;
		totalCount = Number(totalCount);
		let loadedNONVATData = nonVATData.length;
		if (loadedNONVATData < totalCount) {
			model.setProperty("/nonVAT/loadMore", true);
		} else if (loadedNONVATData === totalCount || totalCount < 10) {
			model.setProperty("/nonVAT/loadMore", false);
		}
		model.refresh();
	}

	/**
	 * @author DARSHAN
	 * @function onLoadMoreNonVAT
	 * @description function to handle scroll loadMore for NON-VAT
	 * @param {Event} event
	 */
	async onLoadMoreNonVAT(event) {
		const model = this.getModel();
		let accountId = this.control.getAccountId() || null;
		try {
			let nonVATOpportunities = model.getProperty("/nonVAT/opportunities");
			let loadMoreParams = model.getProperty("/nonVAT/loadMoreParams") || {};
			let parameters = {
				accountId: accountId,
				opportunityId: loadMoreParams?.opportunityId || null,
				loadedRecords: nonVATOpportunities.length,
				query: loadMoreParams?.query || "",
				fetchTotalCount: false,
			};

			let prevNONVATOpportunities = [...nonVATOpportunities];
			model.setProperty("/nonVAT/busy", true);
			const data = await this.opportunityState.getNonVATOpportunities(
				parameters.accountId,
				parameters.opportunityId,
				parameters.loadedRecords,
				parameters.query,
				parameters.fetchTotalCount
			);
			if (!data.opportunities) {
				model.setProperty("/nonVAT/loadMore", false);
			}
			let formattedData = this.removeActiveOpportunity(data.opportunities);
			const concatArr = [...nonVATOpportunities, ...formattedData];
			this.setLoadMoreForNONVAT(concatArr);
			model.setProperty("/nonVAT/loaded", concatArr.length);
			model.setProperty("/nonVAT/opportunities", concatArr);

			//Setting focus to list item based on selectable display auth
			let navVatList = this.getNonVatListControl();

			setTimeout(() => {
				if (navVatList) {
					let aListItems = navVatList.getItems() || [];
					if (aListItems.length) {
						let aSortedData = prevNONVATOpportunities.filter((oList) => {
							return oList["displayAuth"];
						});
						let focusCount = aSortedData.length + 1;
						navVatList.getItems()[focusCount].focus();
					}
				}
				model.setProperty("/nonVAT/busy", false);
			}, 30);
		} catch (error) {
			model.setProperty("/nonVAT/busy", false);
			console.log("ERROR IN onLoadMoreNonVAT : ", error);
		}
		model.refresh();
	}

	/**
	 * @author DARSHAN
	 * @function onNONVATFltrRadioBtnSelect
	 * @description function to handle NON-VAT Search Radio Buttons Fitler
	 * @param {Event} event
	 */
	onNONVATFltrRadioBtnSelect(event) {
		const model = this.getModel();
		let [selectedOption] = event
			.getSource()
			?.getSelectedButton()
			?.getCustomData();
		let key = selectedOption?.getKey() ?? "DESCRIPTION";
		let value = selectedOption?.getValue() ?? "Search By Description";
		model.setProperty("/nonVAT/filterOption/searchKey", key);
		model.setProperty("/nonVAT/filterOption/searchValue", "");
		model.setProperty("/nonVAT/filterOption/placeHolder", value);
		model.refresh();
	}

	/**
	 * @author DARSHAN
	 * @function onNonVATOpportunitySearchHandler
	 * @description function to handle NON-VAT Opportunity Fitler
	 * @param {Event} event
	 */
	async onNonVATOpportunitySearchHandler(event) {
		try {
			let nonVATOpportunities = [];
			const model = this.getModel();
			let accountId = this.control.getAccountId() || null;
			let searchQuery = event.getParameter("query") || "";
			let filterOption = model.getProperty("/nonVAT/filterOption") || {};
			model.setProperty("/nonVAT/busy", true);

			let parameters = {
				accountId: accountId,
				opportunityId: null,
				loadedRecords: 0,
				query: "",
				fetchTotalCount: true,
			};

			searchQuery = searchQuery.trim();
			if (searchQuery) {
				let numberRegEx = /^[0-9]+$/;
				if (filterOption.searchKey === "OPPORTUNITY_ID") {
					if (!numberRegEx.test(searchQuery)) {
						Helper.showMessage("Please enter valid Opportunity-Id");
						model.setProperty("/nonVAT/busy", false);
						return;
					}
					parameters.opportunityId = filterOption.searchValue;
				}

				if (filterOption.searchKey === "DESCRIPTION") {
					parameters.query = filterOption.searchValue;
				}
			}

			model.setProperty("/nonVAT/opportunities", []);
			model.setProperty("/nonVAT/loadMoreParams", parameters);
			const data = await this.opportunityState.getNonVATOpportunities(
				parameters.accountId,
				parameters.opportunityId,
				parameters.loadedRecords,
				parameters.query,
				parameters.fetchTotalCount
			);

			model.setProperty("/nonVAT/count", data?.count ?? 0);
			nonVATOpportunities = data?.opportunities || [];
			nonVATOpportunities = this.removeActiveOpportunity(data.opportunities);
			this.setLoadMoreForNONVAT(nonVATOpportunities);
			model.setProperty("/nonVAT/loaded", nonVATOpportunities.length);
			model.setProperty("/nonVAT/opportunities", nonVATOpportunities);
			model.setProperty("/nonVAT/busy", false);
			model.refresh();
		} catch (error) {
			console.log("ERROR IN onNonVATOpportunitySearchHandler : ", error);
			model.setProperty("/nonVAT/busy", false);
		}
	}
	/***********NON-VAT ENDS HERE**********/
}

/**
 * Constructor for a new <code>com.melodylib.integration.controls.OpportunitySelect</code> control.
 *
 * Some class description goes here.
 * @extends Control
 *
 * @author Balwant Singh
 * @version ${version}
 *
 * @constructor
 * @public
 * @name com.melodylib.integration.controls.OpportunityInput
 */
export default class OpportunityInput extends Control {
	static metadata = {
		library: "com.melodylib.integration",
		properties: {
			/**
			 * The text to display.
			 */
			accountId: {
				type: "string",
				group: "Data",
				defaultValue: null,
			},
			opportunityId: {
				type: "string",
				defaultValue: null
			},
			selectedOpportunity: {
				type: "object",
				defaultValue: null,
			},
			type: {
				type: "string",
				defaultValue: Actions.Input,
			},
			editable: {
				type: "boolean",
				defaultValue: true,
			},
			icon: {
				type: "string",
				defaultValue: "sap-icon://edit",
			},
			_showClearIcon: {
				type: "boolean",
				defaultValue: false,
			},
			_showInfoIcon: {
				type: "boolean",
				defaultValue: false,
			},
			_showOpportunityIcon: {
				type: "boolean",
				defaultValue: false,
			},
			_showOpportunityLink: {
				type: "boolean",
				defaultValue: false,
			},
			_showBusy: {
				type: "boolean",
				defaultValue: false,
			},
			valueState: {
				type: "string",
				defaultValue: "None"
			}
		},
		events: {
			selectionChange: {
				opportunityData: {
					type: "object",
				},
			},
		},
		aggregations: {
			_input: {
				type: "sap.m.Input",
				multiple: false,
				visibility: "hidden",
			},
			_infoIcon: {
				type: "sap.ui.core.Icon",
				multiple: false,
				visibility: "hidden",
			},
			_clearIcon: {
				type: "sap.ui.core.Icon",
				multiple: false,
				visibility: "hidden",
			},
			_icon: {
				type: "sap.ui.core.Icon",
				multiple: false,
				visibility: "hidden",
			},
			_link: {
				type: "sap.m.Link",
				multiple: false,
				visibility: "hidden",
			},
		},
	};

	static renderer = OpportunitySelectRenderer;

	/**
	 * @author DARSHAN
	 * @async
	 * @function setSelectedOpportunity
	 * @description setting the selected opportunity data to input and fire the event at the application side
	 * @return {Promise<string>} The data from the URL. || {Event}{Object}
	 * @public
	 * @param {Object} value for Opportunity Data
	 */
	setSelectedOpportunity(data) {
		let model = this.getModel();
		let editable = this.getEditable();
		let opportunityData = null,
			text = "";
		const input = this.getAggregation("_input");
		const link = this.getAggregation("_link");
		let bValidObj =
			data && data instanceof Object
				? Object.keys(data).length > 0
					? true
					: false
				: false;
		if (data && bValidObj) {
			this._showBusy(true);
			opportunityData = data;
			if (opportunityData?.id) {
				text = `${opportunityData.id}`;
			}
			if (opportunityData?.description) {
				text = `${text} - ${opportunityData.description}`;
			}
		}

		//Update Input Control
		input.setValue(text);

		//Update Link Control
		link.setText(text ? text : "Select Opportunity");

		this.setProperty("selectedOpportunity", opportunityData);
		this.setProperty("opportunityId", opportunityData?.id ? opportunityData.id : null);
		model.refresh();
		if (!opportunityData || (opportunityData && !opportunityData?.accountId)) {
			this._setControlVisibility();
			this._showBusy(false);
			return;
		}

		//IF DISPLAY MODE
		if (!editable) {
			this._setControlVisibility();
			this._showBusy(false);
			return;
		}

		this._setControlVisibility();
		this._showBusy(false);
		this.fireEvent("selectionChange", {
			selectedOpportunity: data,
		});
	}
	setValueState(valueState) {
		this.setProperty("valueState", valueState);
		const input = this.getAggregation("_input");
		input.setValueState(valueState);
		input.setValueStateText('Please select opportunity');

	}
	async setOpportunityId(id) {
		const opportunityId = id ? id : null;
		// this.setProperty("opportunityId", opportunityId);
		if (opportunityId) {
			const opportunity = await this.controller.opportunityState.getOpportunityById(opportunityId);
			if (opportunity) {
				this.setSelectedOpportunity(opportunity);
			}
		} else {
			this.setSelectedOpportunity(null);
		}
	}

	/**
	 * @author BALWANT
	 * @async
	 * @function setAccountId
	 * @description function to set AccountId
	 * @public
	 * @param {Boolean} bBusy
	 */
	setAccountId(accountId) {
		this.setProperty("accountId", accountId);
	}

	/**
	 * @author DARSHAN
	 * @async
	 * @function setEditable
	 * @description function to set opportunity control editable (true || false)
	 * @public
	 * @param {String} controlMode
	 */
	setEditable(isEditable) {
		isEditable = isEditable ?? true;
		this.setProperty("editable", isEditable);
		this._setControlVisibility();
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function _showBusy
	 * @description function to set busy indicator
	 * @param {Boolean} bBusy
	 */
	_showBusy(bBusy) {
		this.setProperty("_showBusy", bBusy);
		let inputControl = this.getAggregation("_input");
		if (inputControl) {
			inputControl.setBusy(bBusy);
		}
		return this;
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function _showClearIcon
	 * @description function to set clear icon vibility
	 * @param {Boolean} bVisible
	 */
	_showClearIcon(bVisible) {
		this.setProperty("_showClearIcon", bVisible);
		let clearIcon = this.getAggregation("_clearIcon");
		if (clearIcon) {
			clearIcon.setVisible(bVisible);
		}
		return this;
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function _showInfoIcon
	 * @description function to set info icon vibility
	 * @param {Boolean} bVisible
	 */
	_showInfoIcon(bVisible) {
		this.setProperty("_showInfoIcon", bVisible);
		let infoIcon = this.getAggregation("_infoIcon");
		if (infoIcon) {
			infoIcon.setVisible(bVisible);
		}
		return this;
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function _showOpportunityIcon
	 * @description function to set opportunity icon vibility
	 * @param {Boolean} bVisible
	 */
	_showOpportunityIcon(bVisible) {
		this.setProperty("_showOpportunityIcon", bVisible);
		let opportunityIcon = this.getAggregation("_icon");
		if (opportunityIcon) {
			opportunityIcon.setVisible(bVisible);
		}
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function _showOpportunityLink
	 * @description function to set opportunity icon vibility
	 * @param {Boolean} bVisible
	 */
	_showOpportunityLink(bVisible) {
		this.setProperty("_showOpportunityLink", bVisible);
		let opportunityLink = this.getAggregation("_link");
		if (opportunityLink) {
			opportunityLink.setVisible(bVisible);
		}
	}

	init() {
		//INIT CSS FILE
		//initialisation code, in this case, ensure css is imported
		let libraryPath = jQuery.sap.getModulePath("com.melodylib.integration");
		jQuery.sap.includeStyleSheet(libraryPath + "/css/OpportunityStyle.css");

		//State
		this.opportunityState = OpportunityState.getInstance();

		this.controller = new OpportunityInputController(this);
		this.setAggregation(
			"_input",
			new sap.m.Input(this.getId() + "-input", {
				valueHelpOnly: true,
				showValueHelp: true,
				valueLiveUpdate: true,
				valueHelpRequest: this.openDialog,
			})
		);

		//CLEAR ICON
		this.setAggregation(
			"_clearIcon",
			new sap.ui.core.Icon(this.getId() + "-opportunityclearicon", {
				visible: false,
				src: "sap-icon://decline",
				press: this.onOpportunityClearButtonPress.bind(this),
			})
		);

		//INFO ICON
		this.setAggregation(
			"_infoIcon",
			new sap.ui.core.Icon(this.getId() + "-opportunityinfoicon", {
				visible: false,
				src: "sap-icon://message-information",
				press: this.onOpportunityInfoIconPress.bind(this),
			}).addStyleClass("sapUiTinyMarginBegin")
		);

		//EDIT ICON for OPPORTUNITY
		this.setAggregation(
			"_icon",
			new sap.ui.core.Icon(this.getId() + "-opportunityicon", {
				src: this.getIcon(),
				press: this.openDialog,
			})
		);

		//LINK FOR OPPORTUNITY
		this.setAggregation(
			"_link",
			new sap.m.Link(this.getId() + "-link", {
				text: "",
				press: this.openDialog,
			})
		);

		// set models
		const model = new JSONModel({
			active: {
				busy: false,
				activeOpportunityStatus: [
					{
						key: "",
						value: "All",
					},
					{
						key: "1",
						value: "Active",
					},
					{
						key: "0",
						value: "In Active",
					},
				],
				activeStatusSelectedKey: "",
				searchValue: "",
			},
			nonVAT: {
				loaded: 0,
				count: 0,
				busy: false,
				loadMore: false,
				filterOption: {
					searchValue: "",
					searchKey: "DESCRIPTION",
					placeHolder: "Search By Description",
				},
				opportunities: [],
			},
			selectedTab: "active",
		});
		this.setModel(model);

		this.setModel(
			this.controller.opportunityState.getModel(),
			"opportunityState"
		);
	}

	async openDialog(event) {
		const control = event.getSource().getParent();
		const model = control.getModel();
		let accountId = control.getAccountId() ?? null;
		const models = [
			{
				name: "opportunityState",
				model: control.getModel("opportunityState"),
			},
		];
		let fragment = {
			i18n: "com.melodylib.integration.i18n.i18n",
			controller: control.controller,
			path: "com.melodylib.integration.controls.fragments.ActiveOpportunityDialog",
			name: "_oActOpportunityDialog",
			id: `${control.getId()}_ActiveOpportunityDialog`,
			model: model,
			models: models,
		};

		if (accountId) {
			model.getProperty("/nonVAT/opportunities", []);
			model.refresh();
		}

		const openFrag = Helper.openFragment.bind(control);
		openFrag(fragment, false, control);
	}

	/**
	 * @public
	 * @author DARSHAN
	 * @async
	 * @function onOpportunityClearButtonPress
	 * @description function to handle opportunity clear button.
	 * @param {sap.ui.base.Event} oEvent object of the input
	 */
	onOpportunityClearButtonPress(event) {
		let control = event.getSource().getParent();
		control.getAggregation("_input").setValue("");
		const model = control.getModel();
		this._resetDialogProperties();
		model.setProperty("/active", {
			activeStatusSelectedKey: "",
			searchValue: "",
		});
		model.refresh();
		this.setAccountId("");
		this.setSelectedOpportunity();
		this.fireEvent("selectionChange", {
			selectedOpportunity: "",
			reset: true,
		});
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function _setControlVisibility
	 * @description function to handle icons visibility
	 */
	_setControlVisibility() {
		let bInfoIcon = false;
		let bClearIcon = false;
		let bOpportunityCtrl = false;
		let controlType = this.getType();
		let editable = this.getEditable();
		let selectedOpportunityData = this.getSelectedOpportunity() || {};
		controlType = controlType ? controlType.toUpperCase() : "";

		//Set Values
		if (editable) {
			bInfoIcon = true;
			bClearIcon = true;
			bOpportunityCtrl = true;
		} else {
			bInfoIcon = true;
			bClearIcon = false;
			bOpportunityCtrl = false;
		}

		//Check if Opportunity Data is selected
		if (
			selectedOpportunityData &&
			Object.keys(selectedOpportunityData).length
		) {
			this._showInfoIcon(bInfoIcon);
			this._showClearIcon(bClearIcon);
			//ICON
			if (controlType === Actions.Icon) {
				this._showOpportunityIcon(bOpportunityCtrl);
			}
			//LINK
			if (controlType === Actions.Link) {
				this._showOpportunityLink(true);
			}
		} else {
			this._showInfoIcon(false);
			this._showClearIcon(false);
			//ICON
			if (controlType === Actions.Icon && editable) {
				this._showOpportunityIcon(true);
			} else {
				this._showOpportunityIcon(false);
			}

			//LINK
			if (controlType === Actions.Link && editable) {
				this._showOpportunityLink(true);
			} else {
				this._showOpportunityLink(false);
			}
		}
	}

	/**
	 * @async
	 * @author DARSHAN
	 * @function onOpportunityInfoIconPress
	 * @description function to show Opportunity Info Popup.
	 * @param {sap.ui.base.Event} oEvent object of the input
	 * @public
	 */
	onOpportunityInfoIconPress(event) {
		const control = event.getSource()?.getParent();
		const model = control.getModel();
		const models = [
			{
				name: "opportunityState",
				model: control.getModel("opportunityState"),
			},
		];
		let infoBtnSource = event.getSource();

		let fragment = {
			i18n: "com.melodylib.integration.i18n.i18n",
			controller: control.controller,
			path: "com.melodylib.integration.controls.fragments.OpportunityInformation",
			name: "_oOpportunityInfoDialog",
			id: `_OpportunityInformationDialog`,
			model: model,
			models: models,
		};
		const openFrag = Helper.openFragment.bind(control);
		openFrag(fragment, true, infoBtnSource);
		let opportunityData = control.getSelectedOpportunity() || {};
		if (Object.keys(opportunityData).length) {
			model.setProperty("/selectedOpportunity", opportunityData);
			model.refresh();
		}
	}

	/**
	 * @async
	 * @private
	 * @author DARSHAN
	 * @function _resetDialogProperties
	 * @description function to show Opportunity Info Popup.
	 */
	_resetDialogProperties() {
		const model = this.getModel();
		model.setProperty("/selectedTab", "active");
		model.setProperty("/nonVAT", {
			count: 0,
			loaded: 0,
			busy: false,
			loadMore: false,
			filterOption: {
				searchValue: "",
				searchKey: "DESCRIPTION",
				placeHolder: "Search By Description",
			},
			opportunities: [],
		});
		model.setProperty("/active/searchValue", "");
		model.setProperty("/active/activeStatusSelectedKey", "");
		model.refresh();
	}
}
