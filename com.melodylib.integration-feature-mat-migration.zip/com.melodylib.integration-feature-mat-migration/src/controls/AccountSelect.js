/*!
 * ${copyright}
 */
import Filter from "sap/ui/model/Filter";
import Control from "sap/ui/core/Control";
import FilterType from "sap/ui/model/FilterType";
import Helper from "com/melodylib/core/util/Helper";
import Controller from "sap/ui/core/mvc/Controller";
import JSONModel from "sap/ui/model/json/JSONModel";
import FilterOperator from "sap/ui/model/FilterOperator";
import IndexedDB from "com/melodylib/core/db/IndexedDB";
import Actions from "com/melodylib/integration/enum/Actions";
import AccountSelectRenderer from "./AccountSelectRenderer";
import MasterDataState from "com/melodylib/core/state/MasterDataState";
import AccountState from "com/melodylib/integration/state/AccountState";
import AccountVariant from "com/melodylib/integration/classes/AccountVariant";

/**
 * Constructor for a new <code>com.melodylib.integration.controls.AccountSelect</code> control.
 *
 * Some class description goes here.
 * @extends Control
 *
 * @author Balwant Singh
 * @version ${version}
 *
 * @constructor
 * @public
 * @name com.melodylib.integration.controls.AccountSelect
 */
export default class AccountSelect extends Control {
	static metadata = {
		library: "com.melodylib.integration",
		properties: {
			selectedAccount: {
				type: "object",
				group: "Data",
				defaultValue: null,
			},

			accountId: {
				type: "string",
				defaultValue: null
			},

			type: {
				type: "string",
				defaultValue: "INPUT",
			},

			editable: {
				type: "boolean",
				defaultValue: true,
			},

			_showClearIcon: {
				type: "boolean",
				defaultValue: false,
			},
			_showInfoIcon: {
				type: "boolean",
				defaultValue: false,
			},
			_showAccountIcon: {
				type: "boolean",
				defaultValue: false,
			},
			_showAccountLink: {
				type: "boolean",
				defaultValue: false,
			},
			_showBusy: {
				type: "boolean",
				defaultValue: false,
			},
			valueState: {
				type: "string",
				defaultValue: "None"
			}
		},
		events: {
			/**
			 * Event is fired when the user selects account the control.
			 */
			selectionChange: {
				parameters: {
					selectedAccount: {
						type: "object",
					},
				},
			},
		},
		aggregations: {
			_input: {
				type: "sap.m.Input",
				multiple: false,
				visibility: "hidden",
			},

			_link: {
				type: "sap.m.Link",
				multiple: false,
				visibility: "hidden",
			},

			_clearIcon: {
				type: "sap.ui.core.Icon",
				multiple: false,
				visibility: "hidden",
			},

			_infoIcon: {
				type: "sap.ui.core.Icon",
				multiple: false,
				visibility: "hidden",
			},
		},
	};

	static renderer = AccountSelectRenderer;


	async setAccountId(id) {
		const accountId = id ? id : null;
		// this.setProperty("accountId", accountId);
		const model = this.getModel();
		model.setProperty("/searching", true);
		if (accountId) {
			const accounts = await this.controller.accountState.search(accountId);
			if (accounts.length) {
				this.setSelectedAccount(accounts[0]);
			}
		} else {
			this.setSelectedAccount(null);
		}
		model.setProperty("/searching", false);
	}

	/**
	 * @author DARSHAN
	 * @async
	 * @function setEditable
	 * @description function to set opportunity control editable (true || false)
	 * @public
	 * @param {String} controlMode
	 */
	setEditable(isEditable) {
		isEditable = isEditable ?? true;
		this.setProperty("editable", isEditable);
		this._setControlVisibility();
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function _showBusy
	 * @description function to set busy indicator
	 * @param {Boolean} bBusy
	 */
	_showBusy(bBusy) {
		this.setProperty("_showBusy", bBusy);
		let inputControl = this.getAggregation("_input");
		if (inputControl) {
			inputControl.setBusy(bBusy);
		}
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function _showClearIcon
	 * @description function to set clear icon vibility
	 * @param {Boolean} bVisible
	 */
	_showClearIcon(bVisible) {
		this.setProperty("_showClearIcon", bVisible);
		let clearIcon = this.getAggregation("_clearIcon");
		if (clearIcon) {
			clearIcon.setVisible(bVisible);
		}
		return this;
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function _showInfoIcon
	 * @description function to set info icon vibility
	 * @param {Boolean} bVisible
	 */
	_showInfoIcon(bVisible) {
		this.setProperty("_showInfoIcon", bVisible);
		let infoIcon = this.getAggregation("_infoIcon");
		if (infoIcon) {
			infoIcon.setVisible(bVisible);
		}
		return this;
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function _showAccountIcon
	 * @description function to set opportunity icon vibility
	 * @param {Boolean} bVisible
	 */
	_showAccountIcon(bVisible) {
		this.setProperty("_showAccountIcon", bVisible);
		let accountIcon = this.getAggregation("_icon");
		if (accountIcon) {
			accountIcon.setVisible(bVisible);
		}
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function _showAccountLink
	 * @description function to set opportunity icon vibility
	 * @param {Boolean} bVisible
	 */
	_showAccountLink(bVisible) {
		this.setProperty("_showAccountLink", bVisible);
		let accountLink = this.getAggregation("_link");
		if (accountLink) {
			accountLink.setVisible(bVisible);
		}
	}
	setValueState(valueState) {
		this.setProperty("valueState", valueState);
		const input = this.getAggregation("_input");
		input.setValueState(valueState);
		input.setValueStateText('Please select account');

	}

	setSelectedAccount(value) {
		let model = this.getModel();
		let editable = this.getEditable();
		let text = "";
		const input = this.getAggregation("_input");
		const link = this.getAggregation("_link");

		const selectedAccount = value ? value : null;
		this.setProperty("selectedAccount", selectedAccount);
		this.setProperty("accountId", selectedAccount?.id ? selectedAccount.id : null);
		if (selectedAccount) {
			text = `${selectedAccount.name} - ${selectedAccount.id}`;
		} else {
			this._resetModel();
		}

		//Update Input Control
		input.setValue(text);

		//Update Link Control
		link.setText(text ? text : "Select Account");

		if (!selectedAccount) {
			this._setControlVisibility();
			this._showBusy(false);
			return;
		}

		//IF DISPLAY MODE
		if (!editable) {
			this._setControlVisibility();
			this._showBusy(false);
			return;
		}

		this._setControlVisibility();
		this._showBusy(false);
		this.fireEvent("selectionChange", {
			selectedAccount: selectedAccount,
		});
	}

	_resetModel() {
		const data = {
			accounts: [],
			industries: [],
			queries: [],
			variant: new AccountVariant(),
			searching: false,
		};
		let model = this.getModel();
		if (!model) {
			model = new JSONModel(data);
			this.setModel(model);
		} else {
			model.setData(data);
		}
	}

	init() {
		this._resetModel();
		//INIT CSS FILE
		//initialisation code, in this case, ensure css is imported
		let libraryPath = jQuery.sap.getModulePath("com.melodylib.integration");
		jQuery.sap.includeStyleSheet(libraryPath + "/css/AccountStyle.css");

		this.controller = new AccountSelectController(this);
		this.setAggregation(
			"_input",
			new sap.m.Input(this.getId() + "-input", {
				valueHelpOnly: true,
				showValueHelp: true,
				valueLiveUpdate: true,
				valueHelpRequest: this.openDialog,
			})
		);

		this.setAggregation(
			"_link",
			new sap.m.Link(this.getId() + "-link", {
				text: "",
				press: this.openDialog,
			})
		);

		this.setAggregation(
			"_clearIcon",
			new sap.ui.core.Icon(this.getId() + "-clearButton", {
				src: "sap-icon://decline",
				press: this.clearSelection.bind(this),
			}).addStyleClass("sapUiTinyMarginBegin")
		);

		this.setAggregation(
			"_infoIcon",
			new sap.ui.core.Icon(this.getId() + "-infoButton", {
				src: "sap-icon://message-information",
				press: this.getInfo.bind(this),
			}).addStyleClass("sapUiTinyMarginBegin")
		);
	}

	async openDialog(event) {
		const control = event.getSource().getParent();

		const models = [
			{
				name: "accountState",
				model: control.controller.accountState.getModel(),
			},
			{
				name: "masterDataState",
				model: control.controller.masterDataState.getModel(),
			},
		];
		let fragment = {
			i18n: "com.melodylib.integration.i18n.i18n",
			controller: control.controller,
			path: "com.melodylib.integration.controls.fragments.AccountDialog",
			name: "_AccountDialog",
			id: `${control.getId()}_AccountDialog`,
			model: control.getModel(),
			models: models,
		};

		const openFrag = Helper.openFragment.bind(control);
		openFrag(fragment, false, control);

		const accountState = control.controller.accountState;
		const accountStateModel = accountState.getModel();
		const accountStateVariant = accountStateModel.getProperty("/variant");

		const model = control.getModel();
		const variant = model.getProperty("/variant");

		variant.copy(accountStateVariant);
		model.refresh();
		const query = variant.searchQuery;
		control.controller._search(query);
	}

	/**
	 * @private
	 * @author DARSHAN
	 * @function _setControlVisibility
	 * @description function to handle icons visibility
	 */
	_setControlVisibility() {
		let bInfoIcon = false;
		let bClearIcon = false;
		let bAccountCtrl = false;
		let bAccountLinkCtrl = false;
		let controlType = this.getType();
		let editable = this.getEditable();
		let selectedAccountData = this.getSelectedAccount() || {};
		controlType = controlType ? controlType.toUpperCase() : "";

		//Set Values
		if (editable) {
			bInfoIcon = true;
			bClearIcon = true;
			bAccountCtrl = true;
		} else {
			bInfoIcon = true;
			bClearIcon = false;
			bAccountCtrl = false;
		}

		//Check if Account Data is selected
		if (selectedAccountData && Object.keys(selectedAccountData).length) {
			this._showInfoIcon(bInfoIcon);
			this._showClearIcon(bClearIcon);
			//ICON
			if (controlType === Actions.Icon) {
				this._showAccountIcon(bAccountCtrl);
			}
			//LINK
			if (controlType === Actions.Link) {
				this._showAccountLink(true);
			}
		} else {
			this._showInfoIcon(false);
			this._showClearIcon(false);
			//ICON
			if (controlType === Actions.Icon && editable) {
				this._showAccountIcon(true);
			} else {
				this._showAccountIcon(false);
			}

			//LINK
			if (controlType === Actions.Link && editable) {
				this._showAccountLink(true);
			} else {
				this._showAccountLink(false);
			}
		}
	}

	clearSelection(event) {
		let control = event.getSource().getParent();
		control.getAggregation("_input").setValue("");
		const model = control.getModel();
		model.refresh();
		this.setSelectedAccount();
		this.fireEvent("selectionChange", {
			selectedAccount: "",
			reset: true,
		});
	}

	getInfo(event) {
		let infoBtnSource = event.getSource();
		const control = event.getSource()?.getParent();
		const model = control.getModel();
		const models = [
			{
				name: "accountState",
				model: control.controller.accountState.getModel(),
			},
			{
				name: "masterDataState",
				model: control.controller.masterDataState.getModel(),
			},
		];
		let fragment = {
			i18n: "com.melodylib.integration.i18n.i18n",
			controller: control.controller,
			path: "com.melodylib.integration.controls.fragments.AccountInformation",
			name: "_AccountInfoDialog",
			id: `_AccountInfoDialog`,
			model: control.getModel(),
			models: models,
		};

		const openFrag = Helper.openFragment.bind(control);
		openFrag(fragment, true, infoBtnSource);

		let accountData = control.getSelectedAccount() || {};
		if (Object.keys(accountData).length) {
			model.setProperty("/selectedAccount", accountData);
			model.refresh();
		}
	}
}

class AccountSelectController extends Controller {
	constructor(control) {
		super();
		this.control = control;
		this.accountState = AccountState.getInstance();
		this.masterDataState = MasterDataState.getInstance();
	}

	onInit() { }

	search(event) {
		const query = event.getParameter("query");
		this._search(query);
	}

	async _search(query) {
		let accounts = [];
		let industries = [];
		const model = this.control.getModel();
		model.setProperty("/searching", true);
		if (query) {
			accounts = await this.accountState.search(query);
			industries = [
				...new Set(
					accounts.map((a) => {
						return { industryKey: a.industryKey, industryName: a.industryName };
					})
				),
			];
		}
		model.setProperty("/industries", industries);
		model.setProperty("/accounts", accounts);
		this.filterTable();
		model.setProperty("/searching", false);
	}

	filterTable() {
		const model = this.control.getModel();
		const variant = model.getProperty("/variant");
		const accountsList = sap.ui.core.Fragment.byId(
			`${this.control.getId()}_AccountDialog`,
			"accountsList"
		);
		const filters = [];
		if (variant.isPlanningEntity) {
			filters.push(
				new Filter(
					"isPlanningEntity",
					FilterOperator.EQ,
					variant.isPlanningEntity
				)
			);
		}

		if (variant.globalUltimate) {
			filters.push(
				new Filter("globalUltimate", FilterOperator.EQ, variant.globalUltimate)
			);
		}

		if (variant.industryKey && variant.industryKey !== "") {
			filters.push(
				new Filter("industryKey", FilterOperator.EQ, variant.industryKey)
			);
		}

		if (variant.countryKey && variant.countryKey !== "") {
			filters.push(
				new Filter("countryKey", FilterOperator.EQ, variant.countryKey)
			);
		}

		accountsList?.getBinding("items").filter(filters, FilterType.Application);
	}

	clearFilter() {
		const model = this.control.getModel();
		const variant = model.getProperty("/variant");
		variant.clear();
		this._search("");
		model.refresh();
	}

	async closeDialog() {
		const dialog = await this.control._AccountDialog;
		if (dialog) {
			dialog.close();
			dialog.destroy();
			this.control._AccountDialog = "";
		}
	}

	selectAccount(event) {
		const listItem = event.getParameter("listItem");
		const bindingContext = listItem.getBindingContext();
		const model = bindingContext.getModel();
		const path = bindingContext.getPath();
		const account = model.getProperty(path);
		this.control.setSelectedAccount(account, true);
		this.closeDialog();
	}

	checkEmpty(value) {
		return value ? value : "Unavailable ";
	}

	/**
	 * @author DARSHAN
	 * @function getUrlConstant
	 * @description function to get url constant "0011"
	 */
	async getUrlConstant() {
		let urlConstants =
			(await IndexedDB.fnGetAllDatafromDB({
				dbName: "master-data",
				storeName: "master-data-table",
				keyName: "harmonyconstanturls",
			})) || [];
		let urlConstant =
			urlConstants.find((url) => {
				return url.id === "0052";
			}) || false;
		return urlConstant;
	}

	/**
	 * @author DARSHAN
	 * @function onNavToCRMwithCvaAccnt
	 * @description function to handle navigation in Account Info Popup
	 * @public
	 */
	async onNavToCRMwithCvaAccnt() {
		const model = this.control.getModel();
		const urlConstant = this.getUrlConstant();
		let selectedAccountData = model.getProperty("/selectedAccount");

		window.open(
			urlConstant.value + selectedAccountData.accountId + "/plan",
			"_blank"
		);
	}

	/**
	 * @author DARSHAN
	 * @function onCloseAccountInfo
	 * @description function to close the Account Info Popup
	 * @public
	 */
	async onCloseAccountInfo() {
		let dialog = await this.control._AccountInfoDialog;
		if (dialog) {
			dialog.close();
			dialog.destroy();
			this.control._AccountInfoDialog = "";
		}
	}
}
