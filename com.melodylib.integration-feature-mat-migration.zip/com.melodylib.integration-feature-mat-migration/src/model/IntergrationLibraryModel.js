sap.ui.define(["sap/ui/model/json/JSONModel"], function (JSONModel) {
	const jsonModel = new JSONModel({});
	jsonModel.setSizeLimit(99999);
	return jsonModel;
});
