sap.ui.define(["sap/ui/core/format/DateFormat"], function (DateFormat) {
	"use strict";

	return {
		getRecordDate: function (sRecordDate) {
			if (!sRecordDate) {
				return "";
			}
			const year = sRecordDate.substring(0, 4);
			const month = sRecordDate.substring(4, 6);
			const day = sRecordDate.substring(6, 8);

			return day + "/" + month + "/" + year;
		},

		getOpportunityStatus: function (StatusId) {
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let oOppStatusMasterMap = oStorage.get("pcOppStatusMasterMap");
			return oOppStatusMasterMap[StatusId].VALUE;
		},

		getOpportunityDate: function (date) {
			var dateFormat = DateFormat.getDateInstance({
				style: "medium",
			});
			if (date && date !== null && date !== "") {
				date = new Date(date);
				return dateFormat.format(date);
			} else {
				return null;
			}
		},

		fnCheckEmpty: function (value) {
			if (value && value !== "") {
				return value;
			} else {
				return "Unavailable";
			}
		},

		formatDate: function (date) {
			var dateFormat = DateFormat.getDateInstance({
				style: "medium",
			});
			if (date && date !== null && date !== "") {
				return dateFormat.format(date);
			} else {
				return null;
			}
		},

		setActivityDesc: function (sActId, sActDesc) {
			if (sActId) {
				const sTitle = sActId + " - " + sActDesc;
				return sTitle;
			} else {
				return "";
			}
		},

		setCostTypeDesc: function (sCostTypeName, sCostTypeValue) {
			if (sCostTypeName) {
				const sDescription = sCostTypeName + " (" + sCostTypeValue + ")";
				return sDescription;
			} else {
				return "";
			}
		},
	};
});
