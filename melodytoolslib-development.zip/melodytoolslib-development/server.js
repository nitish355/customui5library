const express = require("express");
const path = require("path");

const app = express();

// Serve the static files from the 'dist' directory
app.use(express.static(path.join(__dirname, "dist/resources/com/melody/lib")));

// Handle requests to specific files
app.get("/:fileName", (req, res) => {
	const fileName = req.params.fileName;
	const filePath = path.join(__dirname, "src", fileName);

	res.sendFile(filePath, (err) => {
		if (err) {
			console.error("Error loading file:", err);
			res.status(404).send("File not found");
		}
	});
});

// Start the server
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
	console.log(`Server is running at http://localhost:${PORT}`);
});
