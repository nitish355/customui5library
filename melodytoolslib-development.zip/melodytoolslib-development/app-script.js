const { exec } = require("child_process");

const configFile = process.argv[2];

if (!configFile) {
	console.error("Error: Please provide a configuration file as an argument.");
	console.log("Usage: node updateDestiService.js <configFile>");
	process.exit(1);
}

exec("cf services", (error, stdout, stderr) => {
	if (error) {
		console.error(`Error executing 'cf services': ${error.message}`);
		return;
	}

	if (stderr) {
		console.error(`Error in CF CLI output: ${stderr}`);
		return;
	}

	const destiService = "melodysuite-destination";

	const updateCommand = `cf update-service ${destiService} -c ${configFile}`;
	console.log(`Executing: ${updateCommand}`);

	exec(updateCommand, (updateError, updateStdout, updateStderr) => {
		if (updateError) {
			console.error(
				`Error updating service "${destiService}": ${updateError.message}`
			);
			return;
		}

		if (updateStderr) {
			console.error(
				`Error in CF CLI during update for "${destiService}": ${updateStderr}`
			);
			return;
		}

		console.log(`Service "${destiService}" updated successfully.`);
	});
});
