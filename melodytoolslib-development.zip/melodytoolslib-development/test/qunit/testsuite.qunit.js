sap.ui.define(function () {
	"use strict";

	return {
		name: "QUnit TestSuite for com.melody.lib",
		defaults: {
			bootCore: true,
			ui5: {
				libs: "sap.ui.core,com.melody.lib",
				theme: "sap_horizon",
				noConflict: true,
				preload: "auto"
			},
			qunit: {
				version: 2,
				reorder: false
			},
			sinon: {
				version: 4,
				qunitBridge: true,
				useFakeTimers: false
			},
			module: "./{name}.qunit",
			coverage: {
				only: ["com/melody/lib/"],
				never: ["test-resources/"]
			}
		},
		tests: {
			// test file for the Example control
			Example: {
				title: "QUnit Test for Example",
				_alternativeTitle: "QUnit tests: com.melody.lib.Example"
			}
		}
	};
});
