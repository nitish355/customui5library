sap.ui.define([
	"com/melody/lib/enum/Actions",
	"sap/ui/core/format/DateFormat",
	"com/melody/lib/util/mtr/MTRModels",
	"com/melody/lib/service/DateService",
	"com/melody/lib/util/account/Account",
], function (Actions, DateFormat, MTRModels, DateService, AccountUtil) {
	"use strict";

	return {
		createLink: function (sType, sDescription) {
			const oResourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
            if (sType === "Error" && (
                sDescription.includes("ZCATSXT(060):") || sDescription.includes("CATSXT(088):")
            )) {
                return oResourceBundle.getText("profileRequestURL");
            }
            return oResourceBundle.getText("ticketURL");
        },

        catsxtTextValidation: function (sType, sDescription) {
			const oResourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
            if (sType === "Error" && (
                sDescription.includes("ZCATSXT(060):") || sDescription.includes("CATSXT(088):")
            )) {
                return oResourceBundle.getText("msgProfileRequestText");
            }
            return oResourceBundle.getText("msgCreateTicket");
        },

        errorMessageDescription: function (sType, sDescription) {
			const oResourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
            if (sType === "Error" && (
                sDescription.includes("ZCATSXT(060):") || sDescription.includes("CATSXT(088):")
            )) {
                return oResourceBundle.getText("msgProfileError");
            }
            return sDescription;
        },

		orgRoleSelect: function (hcl1, hcl2) {
			var bHeadCountl1Match = false;
			var bHeadCountl2Match = false;
			var headcountl2 = this.UserModel.getProperty("/Headcount");
			var headcountl1 = this.UserModel.getProperty("/Headcount_L1");

			if (headcountl2 && headcountl2.indexOf(6) === 0) {
				headcountl2 = headcountl2.replace("6", "0");
				if (hcl2 && hcl2.toString() === headcountl2) {
					bHeadCountl2Match = true;
					this.UserModel.setProperty("/Headcount", headcountl2);
				}
			}

			if (headcountl1 && headcountl1.indexOf(1) === 0) {
				headcountl1 = headcountl1.replace("1", "0");
				if (hcl1 && hcl1.toString() === headcountl1) {
					bHeadCountl1Match = true;
					this.UserModel.setProperty("/Headcount_L1", headcountl1);
				}
			}

			if (bHeadCountl1Match && bHeadCountl2Match) {
				return true;
			}
			return false;
		},

		orgRegionSelect: function (regionId) {
			let RegionHC = this.UserModel.getProperty("/RegionHC");
			if (RegionHC && regionId) {
				if (RegionHC.length !== 4) {
					RegionHC = RegionHC.padStart(4, 0);
				}
				if (RegionHC === regionId) {
					return true;
				}
			}
			return false;
		},

		orgMUSelect: function (muId) {
			let MuHC = this.UserModel.getProperty("/MuHC");
			if (MuHC && muId) {
				if (MuHC.length !== 4) {
					MuHC = MuHC.padStart(4, 0);
				}
				if (MuHC === muId) {
					return true;
				}
			}
			return false;
		},

		getRecordDate: function (sRecordDate) {
			if (!sRecordDate) {
				return "";
			}
			const year = sRecordDate.substring(0, 4);
			const month = sRecordDate.substring(4, 6);
			const day = sRecordDate.substring(6, 8);

			return day + "/" + month + "/" + year;
		},

		getMtrTaskName: function (sMtrTaskID) {
			if (!sMtrTaskID) {
				return "";
			}
			const oMtrTask = this.getMtrTask(sMtrTaskID);

			if (oMtrTask) {
				return oMtrTask.MtrTaskName;
			} else {
				return "";
			}

		},

		getLocationName: function (sMtrTaskID, sLocationId) {

			if (!sMtrTaskID || !sLocationId) {
				return "NA";
			}
			const oMtrTask = this.getMtrTask(sMtrTaskID);
			if (!oMtrTask) {
				return "NA";
			}
			const aLocations = oMtrTask.MtrLocations;
			const oLocation = aLocations.find(item => item.LocationId.toString() === sLocationId.toString());
			if (!oLocation) {
				return "NA";
			}

			return oLocation.LocationName;
		},

		getType: function (sMtrTaskID, sCostTypeId, sCostTypeValue) {

			if (!sMtrTaskID || !sCostTypeId) {
				return "";
			}
			const oMtrTask = this.getMtrTask(sMtrTaskID);
			if (!oMtrTask) {
				return "";
			}
			const aCostTypes = oMtrTask.MtrCostTypes;
			const oCostType = aCostTypes.find(item => item.CostTypeId.toString() === sCostTypeId.toString());
			if (!oCostType) {
				return "";
			}

			return oCostType.CostTypeName + " : " + sCostTypeValue;
		},

		getOpportunityStatus: function (StatusId) {
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let oOppStatusMasterMap = oStorage.get("pcOppStatusMasterMap")
			return oOppStatusMasterMap[StatusId].VALUE;
		},

		getOpportunityDate: function (date) {
			var dateFormat = DateFormat.getDateInstance({
				style: "medium"
			});
			if (date && date !== null && date !== "") {
				date = new Date(date);
				return dateFormat.format(date);
			} else {
				return null;
			}
		},

		fnCheckEmpty: function (value) {
			if (value && value !== "") {
				return value;
			} else {
				return "Unavailable";
			}

		},

		formatDate: function (date) {
			var dateFormat = DateFormat.getDateInstance({
				style: "medium"
			});
			if (date && date !== null && date !== "") {
				return dateFormat.format(date);
			} else {
				return null;
			}
		},

		setActivityDesc: function (sActId, sActDesc) {
			if (sActId) {
				const sTitle = sActId + " - " + sActDesc;
				return sTitle;
			} else {
				return "";
			}
		},

		setCostTypeDesc: function (sCostTypeName, sCostTypeValue) {
			if (sCostTypeName) {
				const sDescription = sCostTypeName + " (" + sCostTypeValue + ")";
				return sDescription;
			} else {
				return "";
			}
		},

		//Function to handle check box selection in Activity Registration Table Dialog
		setCheckBoxSelection: function (aValue, validateSelection) {
			if (!aValue) {
				return false;
			}
			const aSelectedList = aValue.filter(item => item.IsSelected === true);
			if (aValue && aValue.length > 0 && aValue.length === aSelectedList.length) {
				return true;
			} else {
				return false;
			}
		},

		//function to handle actionable items (Edit/Dispay)
		setActivityInfoBtnActions: function (activityMode, value, activityId = "") {
			if (activityMode === Actions.ActivityMode.newActivity && value) {
				return true;
			}
			if (activityMode === Actions.ActivityMode.existingActivity && activityId) {
				return true;
			}
			return false;
		},

		//function to handle activity info icon items (Edit/Dispay)
		setActivityInfoIconActions: function (activityMode, activityTypeId, activityDescription) {
			if (activityMode === Actions.ActivityMode.newActivity && activityTypeId) {
				return true;
			}
			if (activityMode === Actions.ActivityMode.existingActivity && activityDescription) {
				return true;
			}
			return false;
		},

		//function to handle actionable items (Edit/Dispay)
		setEnableActivityRegisterBtn: function (activityMode, matrixEntry, selectedActivityType, associationId, validateRegisterBtn) {
			let activityModes = [Actions.ActivityMode.newActivity, Actions.ActivityMode.existingActivity];
			let activityId = ("ActvtId" in matrixEntry) ? matrixEntry.ActvtId : "";
			let activityRegistration = ("activityRegistration" in matrixEntry) ? matrixEntry.activityRegistration : {};
			let accountId = ("GlobalUltimateID" in activityRegistration) ? activityRegistration.GlobalUltimateID : "";
			let opportunityId = ("OpportunityId" in activityRegistration) ? activityRegistration.OpportunityId : "";
			if (!opportunityId) {
				opportunityId = ("OpportunityNumber" in activityRegistration) ? activityRegistration.OpportunityNumber : "";
			}
			switch (associationId) {
				case "4": //Account
					const accountValidate = [selectedActivityType, accountId];
					if (activityMode === activityModes[0] && accountValidate.every((item) => item)) {
						return true;
					}
					if (activityMode === activityModes[1]) {
						if (accountId && activityId && matrixEntry.activityDescription) {
							return true;
						}
					}
					return false;
				case "1": //Opportunity
					const opportunityValidate = [selectedActivityType, opportunityId];
					if (activityMode === activityModes[0] && opportunityValidate.every((item) => item)) {
						return true;
					}
					if (activityMode === activityModes[1]) {
						if (opportunityId && activityId && matrixEntry.activityDescription) {
							return true;
						}
					}
					return false;
				case "2": //No Association
					const noAssociation = [selectedActivityType];
					if (activityMode === activityModes[0] && noAssociation.every((item) => item)) {
						return true;
					}
					if (activityMode === activityModes[1] && activityId && matrixEntry.activityDescription) {
						return true;
					}
					return false;
				default:
					return false;
			}
		},

		//function to handle input value of activity input field
		setMatrixActivityInputValue: function (activityName, activityId) {
			if (activityName && activityId) {
				return `${activityName} - ${activityId}`;
			} else if (activityName || activityId) {
				return activityName || activityId;
			} else {
				return "";
			}
		},

		setCount: function (aSelectedActivity = [], count, validateSelection) {
			return `${count}`;

			// const aSelectedValues = aValue.filter(item => item.IsSelected);
			// return aSelectedValues.length + "/" + aValue.length;
		},

		formatDateInMatrix: function (sDate) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const oSetting = oSettingsModel.getData();
			return DateService.getInstance().formatStringDate(sDate, oSetting.DisplayDateFormat);
		},

		setAssociationsText: function (sTextType, MtrUid, matrixEntry = []) {
			if (!MtrUid || MtrUid === "") {
				return "";
			}
			const ActAsstId = (matrixEntry.ActAsstId) ? matrixEntry.ActAsstId : '';
			const matrixModel = MTRModels.getMatrixModel();
			const selectedCategory = matrixModel.getProperty("/matrixCategory");
			switch (selectedCategory) {
				case Actions.matrixCategory.activity:
					if (sTextType === "title") {
						let aAssociation = matrixModel.getProperty("/registrationTypes") || [];
						const oAssociation = aAssociation.find(item => item.ActvtAsstdID.toString() === ActAsstId.toString());
						if (oAssociation) {
							return oAssociation.name;
						} else {
							return "";
						}
					} else if (sTextType === "text") {
						let sText = "";
						if (ActAsstId.toString() === "501") { // Account
							let oAssociation = matrixEntry.accountData;
							if (oAssociation) {
								const Name = (oAssociation.AccountName) ? oAssociation.AccountName : "";
								const Id = (oAssociation.AccountId) ? oAssociation.AccountId : "";
								sText = `${Name} (${Id})`;
							}

						} else if (ActAsstId.toString() === "502") { //Opportunity
							let oAssociation = matrixEntry.opportunityData;
							if (oAssociation) {
								const Name = (oAssociation.OpportunityName) ? oAssociation.OpportunityName : "";
								const Id = (oAssociation.OpportunityId) ? oAssociation.OpportunityId : "";
								sText = `${Name} (${Id})`;
							}
						} else if (ActAsstId.toString() === "503") { // No .Association
							sText = '';
						}
						return sText;
					}
					break;
				case Actions.matrixCategory.learning:
					if (sTextType === "title") {
						return "NA";
					}
					break;
				default:
			}
		},

		getDuration: function (sDuration) {
			var d = sDuration;
			if (d === "") {
				d = "0";
			}
			return d;
		},

		getAddNoteTableFilter: function (oEntry) {
			return oEntry.WorkDuration !== "";
		},

		setCostObjectTitle: function (MtrUid) {
			let path = "";
			if ("matrixPath" in this) {
				path = this.matrixPath;
			}
			if (!MtrUid || path === "") {
				return "";
			}

			const matrixModel = MTRModels.getMatrixModel();
			const matrixEntry = matrixModel.getProperty(path);
			const selectedCategory = matrixModel.getProperty("/matrixCategory");

			switch (selectedCategory) {
				case Actions.matrixCategory.activity:

					if ("CostObjectItems" in matrixEntry) {
						const oCostObject = matrixEntry.CostObjectItems.find(item => item.key.toString() === matrixEntry.CostTypeId.toString());

						return (oCostObject) ? oCostObject.text : "";
					} else {
						return "";
					}
				case Actions.matrixCategory.learning:
					if (!matrixEntry.CostTypeId) {
						return "";
					}
					if (matrixEntry.CostTypeId === '2' && !matrixEntry.ActvtId) {
						return `SAP Cost Center`; //(${matrixEntry.CostTypeValue})
					} else {
						return "";
					}
				default:
			}

		},

		setCostObjectText: function () {
			let path = "";
			if ("matrixPath" in this) {
				path = this.matrixPath;
			}
			if (path === "") {
				return "";
			}
			const matrixModel = MTRModels.getMatrixModel();
			const matrixEntry = matrixModel.getProperty(path);
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const aManual = oSettingsModel.getProperty("/to_MANUAL") || [];
			if ("CostTypeValue" in matrixEntry) {
				let oManual = aManual.find(item => item.ManualIOID === matrixEntry.CostTypeValue);
				if (oManual) {
					return `${oManual.ManualIODesc}: (${oManual.ManualIOID})`;
				}
			}
			return "";
		},

		//Function to return task name based on TaskId
		formatTaskName: function (taskId) {
			if (!taskId) {
				return "";
			}
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			let aTasks = oSettingsModel.getProperty("/MTRTasks") || [];
			let oTask = aTasks.find(function (item) {
				return item.TaskId.toString() === taskId.toString();
			});
			if (oTask) {
				return `${oTask.TaskName}`;
			}
			return "";
		},

		//Function to set Opportunity Ctrl Data based on Association ID
		fnSetAssociationOppCtrlId: function (controlType, selectedAssociationId, matrixEntry) {
			switch (matrixEntry.ActAsstId) {
				case "502": //Opportunity
					if (selectedAssociationId === "1") {
						return matrixEntry.selectedAstOpportunityValue;
					}
					break;
				default:
			}
			return "";
		},

		//Function to set Account Ctrl Data based on Association ID
		fnSetAssociationAccCtrlId: function (controlType, selectedAssociationId, matrixEntry) {
			switch (matrixEntry.ActAsstId) {
				case "501": //Account
					if (selectedAssociationId === "4") {
						return matrixEntry.selectedAstAccountValue;
					}
					break;
				default:
			}
			return "";
		},

		setActivityTitle: function (sTextType, ActvtId, ActTypeDesc) {
			let matrixEntry;
			let activityDescription = "";
			const matrixModel = MTRModels.getMatrixModel();
			if (!activityDescription && this.matrixPath) {
				matrixEntry = matrixModel.getProperty(this.matrixPath) || false;
				if (matrixEntry && "activityDescription" in matrixEntry) {
					activityDescription = (matrixEntry.activityDescription) ? matrixEntry.activityDescription : "";
					if (activityDescription) {
						let content = activityDescription.split("-") || [];
						if (content.length) {
							content.pop();
							activityDescription = content.join(" ");
						}
					}
				}
			}

			switch (sTextType) {
				case "title":
					if (!ActvtId) {
						return "NA";
					}
					if (ActvtId && activityDescription) {
						return activityDescription;
					}
					return "";
				default:
			}
			return "";
		},

		setActivityText: function (sTextType, ActvtId) {
			switch (sTextType) {
				case "text":
					if (!ActvtId) {
						return "";
					}
					return ActvtId;
				default:
			}
			return "";
		},

		//Function to set enalbed for Learning Tab Inputs
		setCostTypeValueForLearning: function (costTypeValue, costTypeId, isOthers) {
			if (!isOthers) {
				return costTypeValue;
			}

			if (isOthers) {
				switch (costTypeId) {
					case "1": //Opportunity
						return `${"Opportunity"} - ${costTypeValue}`;
					case "2": //No Assoication //SAP Cost Center
						return `${"SAP Cost Center"} - ${costTypeValue}`;
					case "3": //ManualIO
						return `${"ManualIO"} - ${costTypeValue}`;
					case "4": //Account
						return `${"Account"} - ${costTypeValue}`;
					default:
						return `${costTypeValue}`;
				}
			}
		},

		//Function to set enalbed for Learning Tab Inputs
		setLearningEntryInputEditable: function (statusId, isOthers) {
			statusId = (statusId) ? statusId.toString() : "";
			if (statusId === "4" || isOthers) {
				return false;
			} else {
				return true;
			}
		},

		setSelectedItemCount: function (aSelectedActivity = [], validateSelection) { //Siddharth- New Addition
			return `${aSelectedActivity.length}`;
		},

		fnSetOpportunityName: function (oppId, oppName, actvtId) {
			if (oppId && oppName) {
				var oppFullName = oppName + " (" + oppId + ")";
				if (oppFullName.length > 50) {
					oppFullName = oppFullName.substring(0, 42) + "...";
				}
				return oppFullName;
			} else {
				if (actvtId) {
					const matrixModel = MTRModels.getMatrixModel();
					const matrixEntry = matrixModel.getProperty("/matrixActivityData") || [];
					if (matrixEntry && matrixEntry.length) {
						const oMatrixEntry = matrixEntry.find(item => item.ActvtId === actvtId);
						if (oMatrixEntry && !oMatrixEntry.AccountName && oMatrixEntry.ActAsstId !== "503") {
							oMatrixEntry.AccountName = 'Not Applicable';
						}
						if (oMatrixEntry && !oMatrixEntry.OpportunityName && oMatrixEntry.ActAsstId !== "503") {
							oMatrixEntry.OpportunityName = 'Not Applicable';
						}
						matrixModel.setProperty("/matrixActivityData", matrixEntry);
					}
				}
				return 'Not Applicable';
			}
		},

		fnGetHVisibility: function (activities, matrixCategory) {
			if (activities && activities.length > 0 && matrixCategory && matrixCategory === "activity") {
				return true;
			} else {
				return false;
			}
		},

		fnSetOpportunityNameTooltip: function (oppId, oppName) {
			if (oppId && oppName) {
				return oppName + " (" + oppId + ")";
			} else {
				return 'Not Applicable';
			}
		},

		//function to get action menu icon based on statusId
		getActionMenuIcon: function (itemId, actStatusId) {
			let sIcon = "sap-icon://blank";
			if (itemId === actStatusId) {
				sIcon = "sap-icon://accept";
			}
			return sIcon;
		},

		fnSetTitleForNoAssociation: function (actSetDesc) {
			if (actSetDesc) {
				return actSetDesc;
			} else {
				return 'Not Applicable';
			}
		},
		fnSetRegionName: function (region) {
			if (region) {
				var regionname = region;
				if (regionname.length > 50) {
					regionname = regionname.substring(0, 42) + "...";
				}
				return regionname;
			} else {
				return 'Not Applicable';
			}
		},
		fnSetSubRegionName: function (subRegion) {
			if (subRegion) {
				return subRegion;
			} else {
				return 'Not Applicable';
			}
		},

		fnSetISPButtonVisibility: function (actId, CostTypeValue, CostTypeId, aEntries) {
			if (!CostTypeValue || !CostTypeId) {
				return false;
			}
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const aOpportunities = oSettingsModel.getProperty("/Opportunities");
			const aManualIOs = oSettingsModel.getProperty("/to_MANUAL");
			if (CostTypeId === '1') {
				let oOpportunity = aOpportunities.find(function (item) {
					return item.OpportunityID === CostTypeValue;
				});
				if (oOpportunity && oOpportunity.IOSetting && oOpportunity.IOSetting.toUpperCase() === "YES") {
					return true;
				}
			} else if (CostTypeId === '3') {
				let oManualIO = aManualIOs.find(function (item) {
					return item.ManualIOID === CostTypeValue && item.IsVisible === true;
				});

				if (oManualIO) {
					return true;
				}
			}
			return false;

		},

		fnSetActivityName: function (ActName) {
			if (ActName) {
				if (ActName.length > 50) {
					ActName = ActName.substring(0, 42) + "...";
				}
				return ActName;
			} else {
				return 'Not Applicable';
			}
		},

		fnSetAccountName: function (accId, accName) {
			if (accId && accName) {
				var accFullName = accName + " (" + accId + ")";
				if (accFullName.length > 35) {
					accFullName = accFullName.substring(0, 32) + "...";
				}
				return accFullName;
			} else {
				return 'Not Applicable';
			}
		},

		fnSetAccountNameTooltip: function (accId, accName) {
			if (accId && accName) {
				return accName + " (" + accId + ")";
			} else {
				return 'Not Applicable';
			}
		},
		fnSetNoDataTxt: function (activities, sNoDataText) {
			const oResourcei18nModel = MTRModels.getMTRResourceModel();
			const oResourceBundle = oResourcei18nModel.getResourceBundle();
			const activityMatrixListNoDataTxt = oResourceBundle.getText("activityMatrixListNoDataTxt");
			if (activities && activities.length > 0) {
				return sNoDataText || activityMatrixListNoDataTxt;
			} else {
				return activityMatrixListNoDataTxt;
			}
		},

		setEntriesFromMTR: function(isNonMatEntry){
            if(isNonMatEntry === true){
                return false;
            }
            else {
                return true;
            }
        },
 
        setISPDataMessage: function(isNonMatEntry){
            if(isNonMatEntry === true){
                return true;
            }
            else {
                return false;
            }
        },

	};
});