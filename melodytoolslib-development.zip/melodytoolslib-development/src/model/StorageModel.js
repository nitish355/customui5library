sap.ui.define([
	"sap/ui/model/json/JSONModel"
], function (JSONModel) {
	"use strict";
	const jsonModel = new JSONModel({});
	jsonModel.setSizeLimit(9999);
	return jsonModel;
});