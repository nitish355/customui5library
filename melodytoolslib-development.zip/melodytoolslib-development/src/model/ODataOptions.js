sap.ui.define([
  "sap/ui/base/Object",
  "sap/ui/model/json/JSONModel"
], function(Object, JSONModel) {
  "use strict";
  return Object.extend("com.melody.lib.model.ODataOptions", {
    constructor: function() {
    	this.expand = "";
		this.filters = "";
		this.search = "";
		this.select = "";
		this.model = new JSONModel();
		this.model.setData(this);
    },
    getData: function() {
    	return {
    		expand: this.expand,
			filters: this.filters,
			search: this.search,
			select: this.select
    	};
    },
    getModel: function() {
      return this.model;
    }
  });
});