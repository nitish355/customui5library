sap.ui.define({
	Actvt: "ACTVT",
	Input: "INPUT",
	Button: "BUTTON",
	Icon: "ICON",
	MenuButton: "MENUBUTTON",
	CreateTimeEntryMenu: "CREATETIMEENTRYMENUITEM",
	DefaultBtnType: "Transparent",
	oModels: {
		PrerequisiteModel: "PrerequisiteModel",
		EssentialModel: "essentialModel",
		OppoVATTeamModel: "OppoVATTeamModel",
	},
	GetOpportunityUrlParam: {
		select: 'CHANGED_AT,EXPECT_END,GUID,OWNER_NAME,OWNER_EMPID,OWNER,OPPT_ID,ACCOUNT_NAME,ACCOUNT,DESCRIPTION,STATUS,REPLACED_BY,CURR_PHASE,INTERNAL_ORDER1,INTERNAL_ORDER2,EXPECT_END,EXPECTED_VALUE,INDUSTRY_MASTERCODE_TEXT,INDUSTRY_MASTERCODE,INDURSTRY_TEXT,INDUSTRY,SALES_ORG_TEXT,IS_FAVORITE,SALES_GROUP_TEXT,SALES_OFFICE_TEXT'
	},
	DisContinuedOpportunityTeamUrlParm: {
		select: "OPPT_ID,DESCRIPTION,STATUS,REPLACED_BY,ACCOUNT_NAME,REASON_CODE",
		expand: 'PartiesInvolved,Notes,Items'
	},
	OpportunityTeamUrlParm: {
		select: "EXPECT_END,SALES_ORG_TEXT,OPPT_ID,ACCOUNT_NAME,ACCOUNT,DESCRIPTION,OWNER,OWNER_NAME,STATUS,CURR_PHASE,INDUSTRY_MASTERCODE,INDUSTRY,INDUSTRY_MASTERCODE_TEXT,INDURSTRY_TEXT,INTERNAL_ORDER1,INTERNAL_ORDER2,PartiesInvolved,Items,SALES_GROUP_TEXT,SALES_OFFICE_TEXT,REPLACED_BY,SALES_GROUP_TEXT,SALES_OFFICE_TEXT,SALES_OFFICE_SHORT,PARTNER_NAME,SALES_ORG_SHORT,Notes",
		expand: 'PartiesInvolved,Notes,Items'
	},
	PartiesInvolved: "PartiesInvolved",
	SimpleAccountSearch: "simpleaccountsearch",
	AdvanceAccountSearch: "advancedaccountsearch",
	ContainsQuery: "CONTAINS_QUERY",
	AccountSrchIconTabId: "ICON_TAB_ADV_SEARCH",
	AccountSimpleSrchListId: "idSimpleSearchList",
	ZOZOPA01: "ZOZOPA01",
	oViewModes: {
		EditMode: "EDITMODE",
		DisplayMode: "DISPLAYMODE",
		CreateMode: "CREATEMODE"
	},
	oActiveOppTabKeys: {
		"active_opportunities": "active_opportunities_list",
		"nonvat_opportunity_list": "nonvat_opportunity_list"
	},
	ActivitySet: {
		select: "ActivityId,ActivityGUID,ActTypeDesc,ActivityTypeId,EndDate,ActStatus,ActStatusDesc,OpportunityId,GlobalUltimateID,ActAsstId,ParentRoleId,RoleMpngID,IsOnlyRequestor,IsSlLead,StartDate,Requestor,RequestorName,ActivityLead,ActivityLeadName,ActivityStatusDesc,ActivityStatus,ActivitySetName,ActSetRegion,ActSetSubRegion,StatusChangedAt,CvjPhaseDesc,CvjPhaseId,Archived,ActivitySetStatus,SlStatusId,IsDemoLead"
	},
	GetOpportunityNonVATListUrlParam: {
		select: "IS_FAVORITE,GUID,ACCOUNT_NAME,ACCOUNT,DEAL_TYPE,OPPT_ID,CHANGED_AT,URL,PROCESS_TYPE,PARTNER,PARTNER_NAME,IS_LEAN,BUSINESS_MODEL,DIS_CHANNEL,SOURCE,REVENUE_TYPE,HARMONY_TYPE,ERROR,HDM_MIG_STA,DESCRIPTION,EXPECTED_VALUE,DISP_AUTH,CURRENCY,MAINQUOTE,CPQ_QUOTE,CPQ_SYSTEM_ID,LICENSE_REVENUE,SERVICES_REVENUE,CLOUD_REVENUE,STATUS,OWNER_NAME,OWNER,USR_IN_SLS_TEAM,FORECAST,EXPECT_END,CLOSE_DATE_EDITABLE,CURR_PHASE,ORDER_ID,SALES_ORG,QUARTER_ID,SALES_GROUP_TEXT,SALES_OFFICE_TEXT"
	},
	ActivityMode: {
		newActivity: "New Activity",
		existingActivity: "Existing Activity"
	},
	matrixCategory: {
		activity: "activity",
		learning: "learning",
		other: "other"
	},
	LearningTaskId: ["7", "8", "10", "11"],
	matrixDefaultTime: {
		day: 24,
		hour: 8,
		week: 40
	},

	applicationType: {
		dayWeek: "DAYWEEKMTR",
		matrix: "MATRIXMTR"
	}
}, true);