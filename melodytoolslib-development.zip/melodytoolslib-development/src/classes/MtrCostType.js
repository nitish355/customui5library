sap.ui.define([
	"com/melody/lib/classes/BaseObject"
], function (BaseObject) {
	"use strict";
	var MtrCostType = BaseObject.extend("com.melody.lib.classes.MtrCostType", {
		constructor: function (oData) {
			BaseObject.call(this);
			this.setData(oData);
		},

		setData: function (oData) {
			this.CostTypeId = (oData && oData.CostTypeId) ? oData.CostTypeId : "";
			this.CostTypeName = (oData && oData.CostTypeName) ? oData.CostTypeName : "";
		}
	});
	return MtrCostType;
});