sap.ui.define([
	"com/melody/lib/classes/BaseObject"
], function (BaseObject) {
	"use strict";
	var Account = BaseObject.extend("com.melody.lib.classes.Account", {
		constructor: function (oData) {
			BaseObject.call(this);
			this.setData(oData);
		},

		setData: function (oData) {
			this.AccountId = (oData && oData.AccountId) ? oData.AccountId : "";
			this.AccountName = (oData && oData.AccountName) ? oData.AccountName : "";
			this.AccountId_Name = (oData && oData.AccountId_Name) ? oData.AccountId_Name : "";
			this.Description = (oData && oData.Description) ? oData.Description : "";
			this.Industry = (oData && oData.Industry) ? oData.Industry : "";
			this.IndustryCode = (oData && oData.IndustryCode) ? oData.IndustryCode : "";
			this.Street = (oData && oData.Street) ? oData.Street : "";
			this.City = (oData && oData.City) ? oData.City : "";
			this.Country = (oData && oData.Country) ? oData.Country : "";
			this.PlanningEntityId = (oData && oData.PlanningEntityId) ? oData.PlanningEntityId : "";
			this.PlanningEntityName = (oData && oData.PlanningEntityName) ? oData.PlanningEntityName : "";
			this.IsPlanningEntity = (oData && oData.IsPlanningEntity) ? true : false;
			this.IsGlobalUltimate = (oData && oData.IsGlobalUltimate) ? true : false;
			this.IsAdvanceSearched = (oData && oData.IsAdvanceSearched) ? true : false;
			this.IsMyAccount = (oData && oData.IsMyAccount) ? true : false;
			this.ERPID = (oData && oData.ERPID) ? oData.ERPID : "";
			this.IMS = (oData && oData.IMS) ? oData.IMS : "";
			this.ISS = (oData && oData.ISS) ? oData.ISS : "";
			this.Internal_Account_Classification = (oData && oData.IAC) ? oData.IAC : "";
			this.SEGMENT = (oData && oData.SEGMENT) ? oData.SEGMENT : "";
			this.OWNER_NAME = (oData && oData.OWNER_NAME) ? oData.OWNER_NAME : "";
			this.OWNER = (oData && oData.OWNER) ? oData.OWNER : "";
			this.STATUS_DESC = (oData && oData.STATUS_DESC) ? oData.STATUS_DESC : "";
			this.Active_Account_Status = (oData && oData.Active_Account_Status) ? oData.Active_Account_Status : "";
			this.Regional_Buying_Lifecycle = (oData && oData.Regional_Buying_Lifecycle) ? oData.Regional_Buying_Lifecycle : "";
			this.Regional_Buying_Classification = (oData && oData.Regional_Buying_Classification) ? oData.Regional_Buying_Classification : "";
		},

		setDefaultData: function () {
			return {
				accounts: [],
				resultAccounts: [],
				lastUpdatedIndex: 0,
				sPlanningEntities: false,
				sGlobalUltimate: false,
				sIndustryKey: "",
				sRegionKey: "",
				sCountryKey: "",
				sSearchQuery: "",
				variantid: "",
				simpleSrch: "",
				simpleSrchVisible: true,
				advancedSrchVisisble: false,
				oPrevStateQueryData: {},
				aPrevStateQueryIndex: 0
			};
		},
	});
	return Account;
});