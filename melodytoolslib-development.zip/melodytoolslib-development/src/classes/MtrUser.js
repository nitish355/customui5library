sap.ui.define([
	"com/melody/lib/classes/BaseObject"
], function (BaseObject) {
	"use strict";
	var MtrUser = BaseObject.extend("com.melody.lib.classes.MtrUser", {
		constructor: function (oData) {
			BaseObject.call(this);
			this.IsFirstTimeUser = true;
			this.MtrTasks = [];
			this.setData(oData);
		},

		setData: function (oData) {
			this.UserId = (oData && oData.UserId) ? oData.UserId : "";
			this.UserGuid = (oData && oData.UserGuid) ? oData.UserGuid : "";
			this.FirstName = (oData && oData.FirstName) ? oData.FirstName : "";
			this.LastName = (oData && oData.LastName) ? oData.LastName : "";
			this.Email = (oData && oData.Email) ? oData.Email : "";
			this.Status = (oData && oData.Status) ? oData.Status : "";
			this.IsUnitEdit = (oData && oData.IsUnitEdit) ? oData.IsUnitEdit : false;
			this.Durations = (oData && oData.Durations) ? oData.Durations : [];
			this.TimeSheetUnit = (oData && oData.TimeSheetUnit) ? oData.TimeSheetUnit : "H";
			this.PartnerId = (oData && oData.PartnerId) ? oData.PartnerId : "";
			this.DateFormat = (oData && oData.DateFormat) ? oData.DateFormat : "DD/MM/YYYY";
			this.TimeSheetUnit = (oData && oData.TimeSheetUnit) ? oData.TimeSheetUnit : "H";
			this.TimeSheet = (oData && oData.TimeSheet) ? oData.TimeSheet : "1";
			this.CustId = (oData && oData.CustId) ? oData.CustId : "";
			this.ActivityRecording = (oData && oData.ActivityRecording) ? oData.ActivityRecording : "0";
			this.ProfileId = (oData && oData.ProfileId) ? oData.ProfileId : "";
			this.BelongEss = (oData && oData.BelongEss) ? oData.BelongEss : "";
			this.PersonalNumber = (oData && oData.PersonalNumber) ? oData.PersonalNumber : "";
			this.CostCenter = (oData && oData.CostCenter) ? oData.CostCenter : "";
			this.IsTimeRec = (oData && oData.IsTimeRec) ? true : false;
		},
		
		setFirstTimeUserSettings: function (bValue) {
			this.IsFirstTimeUser = bValue;
			if (this.BelongEss === "1") {
				this.EssInMu = false;
			} else {
				this.EssInMu = true;
			}
		},
		
		/** 
		 * This function returns LS Service request object
		 * @public
		 * @module Settings
		 * @returns {object} LS Service LS Request
		 */
		getLSRequest: function () {
			return {
				PrdProfMapId: this.ProfileId.toString(),
				UserGuid: this.UserGuid,
				PartnerId: this.PartnerId,
				DateFormat: this.DateFormat,
				EssInMu: (this.EssInMu) ? "X" : "",
				TimeSheetUnit: this.TimeMatrics,
				TimeSheet: this.Timesheet.toString(),
				CustId: this.CustId
			};
		},
	});
	return MtrUser;
});