sap.ui.define([
	"com/melody/lib/classes/BaseObject"
], function (BaseObject) {
	"use strict";
	var Opportunity = BaseObject.extend("com.melody.lib.classes.Opportunity.Opportunity", {
		constructor: function (oData) {
			BaseObject.call(this);
			this.setData(oData);
		},

		setData: function (oData) {
			this.AccountId = (oData && oData.AccountId) ? oData.AccountId : "";
			this.AccountName = (oData && oData.AccountName) ? oData.AccountName : "";
			this.OpportunityId = (oData && oData.OpportunityId) ? oData.OpportunityId : "";
			this.OpportunityName = (oData && oData.OpportunityName) ? oData.OpportunityName : "";
			this.Description = (oData && oData.Description) ? oData.Description : "";
			this.Status = (oData && oData.Status) ? oData.Status : "";
			this.ExpectedEnd = (oData && oData.ExpectedEnd) ? oData.ExpectedEnd : "";
			this.ExpectedValue = (oData && oData.ExpectedValue) ? oData.ExpectedValue : "";
			this.Phase = (oData && oData.Phase) ? oData.Phase : "";
			this.Owner = (oData && oData.Owner) ? oData.Owner : "";
			this.OwnerName = (oData && oData.OwnerName) ? oData.OwnerName : "";
			this.Industry_MasterCode_Text = (oData && oData.Industry_MasterCode_Text) ? oData.Industry_MasterCode_Text : "";
			this.Industry = (oData && oData.Industry) ? oData.Industry : "";
			this.Industry_Text = (oData && oData.Industry_Text) ? oData.Industry_Text : "";
			this.Sales_Org_Desc = (oData && oData.Sales_Org_Desc) ? oData.Sales_Org_Desc : "";
			this.Industry_MasterCode = (oData && oData.Industry_MasterCode) ? oData.Industry_MasterCode : "";
			this.StatusDescription = (oData && oData.StatusDescription) ? oData.StatusDescription : "";
			this.Guid = (oData && "Guid" in oData) ? oData.Guid : "";
			this.ChangedAt = (oData && "ChangedAt" in oData) ? oData.ChangedAt : "";
			this.DisplayAuth = (oData && "DisplayAuth" in oData) ? oData.DisplayAuth : false;
			this.StatusSince = (oData && "STATUS_SINCE" in oData) ? oData.STATUS_SINCE : null;
			this.Favourite = (oData && "Favourite" in oData) ? oData.Favourite : false;
			this.Authorized = (oData && "Authorized" in oData) ? oData.Authorized : false;
			this.InternalOrder1 = (oData && oData.InternalOrder1) ? oData.InternalOrder1 : "";
			this.InternalOrder2 = (oData && oData.InternalOrder2) ? oData.InternalOrder2 : "";
		},

		setDefault: function () {
			return {
				"bShowOpportunityDetails": false,
				"selectedOpportunityTeam": {
					"ACCOUNT_EXECUTIVE": {},
					"PRESALES_LEAD": {},
					"PRESALES_MANAGER": [],
					"PRESALES_TEAM": [],
					"EXECUTIVE_SPONSOR": [],
					"PCSM": [],
					"SUPPORT": {},
					"RESOURCE_MANAGER": [],
					"EA_ENGAGEMENT_CSD": {},
					"EA_ENGAGEMENT_GAD": {},
					"EA_ENGAGEMENT_IAE": {},
					"EA_ENGAGEMENT_DIRECTOR": {},
					"EA_ENGAGEMENT_IVE": {},
					"REQUESTOR_MANAGER": {},
					// "EA_ENGAGEMENT_TEAM": [],
					"HSC_TEAM": [],
					"ACCOUNT_OWNER": {}
				},
				"selectedOpportunity": {
					"OPPT_ID": ""
				},
				"opptValueState": "None",
				"opptEnabled": true,
				"opportunity": [],
				"isOpptDilogBusy": false,
				"bActiveOppGrowing": false,
				"aActiveOppStatus": [{
					key: "",
					value: "All"
				}, {
					key: "1",
					value: "Active"
				}, {
					key: "0",
					value: "In Active"
				}]
			};
		}
	});
	return Opportunity;
});