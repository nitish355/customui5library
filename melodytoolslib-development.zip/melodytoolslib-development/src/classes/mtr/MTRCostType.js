sap.ui.define([
	"com/melody/lib/classes/BaseObject"
], function (BaseObject) {
	"use strict";
	var MTRCostType = BaseObject.extend("com.melody.lib.classes.mtr.MTRCostType", {
		constructor: function (oData) {
			BaseObject.call(this);
			this.setData(oData);
		},

		setData: function (oData) {
			this.CostTypeId = (oData && oData.CostTypeId) ? oData.CostTypeId : "";
			this.CostTypeName = (oData && oData.CostTypeName) ? oData.CostTypeName : "";
		}
	});
	return MTRCostType;
});