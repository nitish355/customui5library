sap.ui.define([
	"com/melody/lib/classes/mtr/BaseEntry",
	// "com/melody/lib/model/Application",
	"com/melody/lib/classes/mtr/ManualIO",
	"com/melody/lib/classes/mtr/MTRAccount",
	"com/melody/lib/util/mtr/MTRModels"
], function (BaseEntry, ManualIO, MTRAccount, MTRModels) {
	"use strict";
	var Entry = BaseEntry.extend("com.melody.lib.classes.mtr.Entry", {
		constructor: function (oData) {
			BaseEntry.call(this);
			this.setData(oData);
		},

		setData: function (oData) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			this.TaskType =	oData.TaskType;
			this.SubType = oData.SubType;
			var oMTRTask = oSettingsModel.getProperty("/MTRTasks").find(function(item) {
				return item.IspTask.toUpperCase() === oData.TaskType.toUpperCase() && 
					item.IspSubTask.toUpperCase() === oData.SubType.toUpperCase();
			});
			if(oMTRTask) {
				this.MtrTaskID = oMTRTask.MtrTaskID;
				this.MtrTaskName = oData.ActType;
				this.RecordID = oData.RecordID;
				this.Pernum = oData.Pernum;
				this.RecordDate = oData.RecDate;
				this.WorkDuration = oData.WorkHours;
				var bIsLocationAvailable = false;
				if(oMTRTask.MTRLocations.length > 0) {
					bIsLocationAvailable = true;
				}
				this.LocationId = this.setISXLocation(oData, bIsLocationAvailable);
				this.Unit = oData.Units;
				this.getCostTypeId(oData);
				this.IsInvalidEntry = false;
			} else {
				this.IsInvalidEntry = true;
			}
			
			this.IsConvertedToEntry = false;
		},
		
		setISXLocation: function (oData, bIsLocationAvailable) {
			var sLocationId = "";
			var cLocation = oData.LocationID;
			var sContactPerson = oData.ContactPerson;
	    	if(sContactPerson && sContactPerson !== "") {
	    		var iLocation = parseInt(sContactPerson[ sContactPerson.length - 1 ], 10);
	    		if(iLocation > 0) {
	    			sLocationId = iLocation.toString();
	    		} else if(bIsLocationAvailable) {
	    			sLocationId = "1";
	    		} else {
	    			sLocationId = "";
	    		}
	    	} else if(cLocation && cLocation !== "") {
	    		switch(cLocation) {
					case "O":
						sLocationId = "1";
				    	break;
					case "V":
				    	sLocationId = "2";
				    	break;
				    case ("R" || "N"):
				    	sLocationId = "3";
				    	break;
				    default:
					    if(bIsLocationAvailable) {
				    		sLocationId = "1";
				    	} else {
				    		sLocationId = "";
				    	}
				    	break;
				}
		    } else if(bIsLocationAvailable) {
	    		sLocationId = "1";
	    	} else {
	    		sLocationId = "";
	    	}
			return sLocationId;
		},
		
		getCostTypeId: function (oData) {
			switch(oData.CostCollType) {
				case "CC":
					this.CostTypeId = "2";
					this.CostTypeValue = oData.CostCollNum;
			    	break;
				case "IO":
					if((!oData.CostCollNum || oData.CostCollNum === "") && oData.IoNum && oData.IoNum !== "") {
						this.CostTypeId = "3";
						this.CostTypeValue = oData.IoNum;
						this.addManualIO(oData.IoNum);
					} else if(oData.CostCollNum && oData.CostCollNum !== "") {
						this.CostTypeId = "1";
						this.CostTypeValue = (parseInt(oData.CostCollNum, 10)).toString();
					}
			    	break;
			    default:
			    	if(oData.AccountID && oData.AccountID !== "") {
			    		this.CostTypeId = "3";
						this.CostTypeValue = oData.AccountID;
						this.addAccount(oData.AccountID, oData.Account);
			    	}
			    	break;
			}
		},
		
		addManualIO: function (IoNum) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const manualIOs = oSettingsModel.getProperty("/to_MANUAL");
			const manualIO = manualIOs.find(function (item) {
				return item.ManualIOID === IoNum;
			});
			if(!manualIO) {
				manualIO = new ManualIO({
					ManualIOID: IoNum,
					ManualIODesc: IoNum,
					Indicator: "C",
					CreatedOn: new Date()
				});
				manualIOs.push(manualIO);
			}
		},
		
		addAccount: function (AccountID, AccountDesc) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const accounts = oSettingsModel.getProperty("/to_ACCOUNT");
			const account = accounts.find(function (item) {
				return item.AccountId === AccountID;
			});
			if(!account) {
				account = new MTRAccount({
					AccountId: AccountID,
					AccountDesc: AccountDesc,
					Indicator: "C"
				});
				accounts.push(account);
			}
		}
	});
	return Entry;
});