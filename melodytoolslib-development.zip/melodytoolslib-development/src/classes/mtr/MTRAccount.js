sap.ui.define([
	"sap/ui/base/Object"
	], function(Object) {
		"use strict";
		/* @type sap.ui.base.Object */
		return Object.extend("com.melody.lib.classes.mtr.MTRAccount", {
			constructor: function(oData) {
				Object.call(this);
				this.setData(oData);
			},
			
			setData: function (oData) {
				if (oData) {
					this.AccountId = (oData.AccountId) ? oData.AccountId : "";
					this.AccountDesc = (oData.AccountDesc) ? oData.AccountDesc : "";
					this.DataFrom = (oData.DataFrom) ? oData.DataFrom : "";
					this.Indicator = (oData.Indicator) ? oData.Indicator : "";
					this.CreatedOn = (oData.CreatedOn) ? oData.CreatedOn : "";
					this.UpdatedOn = (oData.UpdatedOn) ? oData.UpdatedOn : "";
				}
			},
			
			getLSRequest: function (mParameters) {
				return {
					UserGuid: mParameters.UserGuid,
					AccountId: this.AccountId,
					AccountDesc: this.AccountDesc,
					Indicator: this.Indicator
				};
			}
		});
	});