sap.ui.define([
	"com/melody/lib/classes/mtr/BaseEntry",
	"com/melody/lib/service/DateService",
	"com/melody/lib/classes/mtr/Entry",
	"com/melody/lib/classes/mtr/Message",
	"sap/m/MessageToast",
	"com/melody/lib/util/mtr/MTRModels"
], function (BaseEntry, DateService, Entry, 
	Message, MessageToast, MTRModels) {
	"use strict";
	var Timesheet = BaseEntry.extend("com.melody.lib.model.Timesheet", {
		constructor: function (oData, isDuplicate, isExactCopy) {
			BaseEntry.call(this);
			this.dateServicesInstance = DateService.getInstance();
			this.genericDateFormat = sap.ui.core.format.DateFormat.getInstance({pattern: "yMMdd", calendarType: sap.ui.core.CalendarType.Gregorian});
			this.GUID = this.generateGUID();
			this.setData(oData, isDuplicate, isExactCopy);
			this.IsModified = false;
			this.IsISPError = false;
			this.ErrorMsg = "";
			this.setLocationIdValueState(sap.ui.core.ValueState.None);
			this.setCostTypeIdValueState(sap.ui.core.ValueState.None);
			this.setCostTypeValueState(sap.ui.core.ValueState.None);
			this.CostTypeValueStateText = "";
			this.IsLegacy = false;
			this.LocationName = "";
			this.CostTypeDisplay = "";
		},
		
		
		
		setData: function(oData, isDuplicate, isExactCopy) {
			if (oData) {
				const oSettingsModel = MTRModels.getMTRSettingsModel();
				this.TaskId = (oData.TaskId) ? oData.TaskId.toString() : "";
				this.ActvtId = (oData && oData.ActvtId) ? oData.ActvtId.toString() : "";
				this.ActvtDesc = (oData && oData.ActvtDesc) ? oData.ActvtDesc.toString() : "";
				this.TaskIdTemp = (oData.TaskId) ? oData.TaskId.toString() : "";
				this.TaskName = (oData.TaskId) ? oData.TaskName : "";
				this.LocationId = (oData.LocationId && !isDuplicate) ? oData.LocationId.toString() : "";
				this.LocationIndex = (oData.LocationId && oData.LocationId !== "" && !isDuplicate) ? parseInt(oData.LocationId, 10) - 1 : -1;
				this.CostTypeId = (oData.CostTypeId && !isDuplicate) ? oData.CostTypeId.toString() : "";
				if(oData && !isDuplicate && oData.CostTypeValue && oData.CostTypeValue !== "") {
					this.CostTypeValue = oData.CostTypeValue;
				} else if(this.CostTypeId === "2" || this.CostTypeId === 2) {
					this.CostTypeValue = oSettingsModel.getProperty("/CostCenter");
				} else if(isDuplicate) {
					var aOpportunities = oSettingsModel.getProperty("/Opportunities");
					var oDefaultOpportunities = aOpportunities.find(function(item) {
						return item.IsDefault;
					});
					if(oDefaultOpportunities) {
						this.CostTypeId = "1";
						this.CostTypeValue = oDefaultOpportunities.OpportunityID;	
					} else {
						this.CostTypeValue = "";
					}
				} else {
					this.CostTypeValue = "";
				}
				this.CostTypeValueTemp = this.CostTypeValue;
				this.StartDate = oData.StartDate;
				this.WeekNumber = oData.WeekNumber;
				this.IsCostCentre = oData.IsCostCentre;
				this.IsOpportunity = oData.IsOpportunity;
				this.IsManualIo = oData.IsManualIo;
				this.IsAccount = oData.IsAccount;
				this.IsPlaceholder = oData.IsPlaceholder;
				this.IsRemote = oData.IsRemote;
				this.ExpectedDuration = oData.ExpectedDuration;
				this.CategoryId = oData.CategoryId.toString();
				this.Locations = oData.Locations;
				this.CostTypes = oData.CostTypes;
				this.IsLegacy = (!isDuplicate) ? oData.IsLegacy : false;
				this.Entries = this.setEntries(oData, isExactCopy);
				this.IsExpanded = false;
				if(isExactCopy) {
					this.GUID = oData.GUID;
				}
				
				//this.IOStaffing = (oData && oData.IOStaffing) ? oData.IOStaffing : null;
				this.validateISX();
				this.PreviousTaskId = (oData && !isDuplicate && (oData.PreviousTaskId  || oData.PreviousTaskId === "")) ? oData.PreviousTaskId.toString() : this.TaskId;
				this.PreviousLocationId = (oData && !isDuplicate && (oData.PreviousLocationId  || oData.PreviousLocationId === "")) ? oData.PreviousLocationId.toString() : this.LocationId;
				this.PreviousCostTypeId = (oData && !isDuplicate && (oData.PreviousCostTypeId  || oData.PreviousCostTypeId === "")) ? oData.PreviousCostTypeId.toString() : this.CostTypeId;
				this.PreviousCostTypeValue = (oData && !isDuplicate && (oData.PreviousCostTypeValue  || oData.PreviousCostTypeValue === "")) ? oData.PreviousCostTypeValue : this.CostTypeValue;
			}
		},
		
		setEntries: function(oData, isExactCopy) {
			var startDate = new Date(this.StartDate.substring(0, 4) + "/" + this.StartDate.substring(4, 6) + "/" + this.StartDate.substring(
				6, 8));
			this.EndDate = this.genericDateFormat.format(new Date(startDate.getTime() + (6 * 24 * 60 * 60 * 1000)));
			return {
				Date1: (isExactCopy) ? new Entry(oData.Entries.Date1) : new Entry({ RecordDate: this.genericDateFormat.format(startDate), CostTypeId: this.CostTypeId, CostTypeValue: this.CostTypeValue, Locations: this.Locations, CostTypes: this.CostTypes, IsLegacy: this.IsLegacy }),
				Date2: (isExactCopy) ? new Entry(oData.Entries.Date2) : new Entry({ RecordDate: this.genericDateFormat.format(new Date(startDate.getTime() + (1 * 24 * 60 * 60 * 1000))), CostTypeId: this.CostTypeId, CostTypeValue: this.CostTypeValue, Locations: this.Locations, CostTypes: this.CostTypes, IsLegacy: this.IsLegacy }),
				Date3: (isExactCopy) ? new Entry(oData.Entries.Date3) : new Entry({ RecordDate: this.genericDateFormat.format(new Date(startDate.getTime() + (2 * 24 * 60 * 60 * 1000))), CostTypeId: this.CostTypeId, CostTypeValue: this.CostTypeValue, Locations: this.Locations, CostTypes: this.CostTypes, IsLegacy: this.IsLegacy }),
				Date4: (isExactCopy) ? new Entry(oData.Entries.Date4) : new Entry({ RecordDate: this.genericDateFormat.format(new Date(startDate.getTime() + (3 * 24 * 60 * 60 * 1000))), CostTypeId: this.CostTypeId, CostTypeValue: this.CostTypeValue, Locations: this.Locations, CostTypes: this.CostTypes, IsLegacy: this.IsLegacy }),
				Date5: (isExactCopy) ? new Entry(oData.Entries.Date5) : new Entry({ RecordDate: this.genericDateFormat.format(new Date(startDate.getTime() + (4 * 24 * 60 * 60 * 1000))), CostTypeId: this.CostTypeId, CostTypeValue: this.CostTypeValue, Locations: this.Locations, CostTypes: this.CostTypes, IsLegacy: this.IsLegacy }),
				Date6: (isExactCopy) ? new Entry(oData.Entries.Date6) : new Entry({ 
					RecordDate: this.genericDateFormat.format(new Date(startDate.getTime() + (5 * 24 * 60 * 60 * 1000))),
					DateType: "OFF", CostTypeId: this.CostTypeId, CostTypeValue: this.CostTypeValue,
					Locations: this.Locations, CostTypes: this.CostTypes, IsLegacy: this.IsLegacy
				}),
				Date7: (isExactCopy) ? new Entry(oData.Entries.Date7) : new Entry({ 
					RecordDate: this.genericDateFormat.format(new Date(startDate.getTime() + (6 * 24 * 60 * 60 * 1000))),
					DateType: "OFF", CostTypeId: this.CostTypeId, CostTypeValue: this.CostTypeValue, 
					Locations: this.Locations, CostTypes: this.CostTypes, IsLegacy: this.IsLegacy
				})
			};
		},
		
		checkFilledEntries: function () {
			var filledEntries = [];
			for(var entry in this.Entries) {
				if(this.Entries[entry].WorkDuration !== "" ) {
					filledEntries.push(this.Entries[entry]);
				}
			}
			return filledEntries;
		},
		
		_validate: function (allowBlank, highlightError, showMsg, isSubmit) {
			var isValid = true;
			var isDurationValid = true;
			// var oResourceBundle = oComponent.getModel("i18n").getResourceBundle();
			if(this.checkFilledEntries().length === 0 && allowBlank) {
				return true;
			} else if(this.checkFilledEntries().length === 0 && !allowBlank) {
				isDurationValid = false;
			}
			
			if(!this.TaskId || this.TaskId === "") {
				if(highlightError) {
					this.setTaskIdValueState(sap.ui.core.ValueState.Error);
				}
				isValid = false;
			} else {
				this.setTaskIdValueState(sap.ui.core.ValueState.None);
			}
			
			if(this.Locations && this.Locations.length > 0 && (!this.LocationId || this.LocationId === "")) {
				if(highlightError) {
					this.setLocationIdValueState(sap.ui.core.ValueState.Error);
				}
				isValid = false;
			} else {
				this.setLocationIdValueState(sap.ui.core.ValueState.None);
			}
			
			if(this.CostTypes && this.CostTypes.length > 0 && (!this.CostTypeId || this.CostTypeId === "")) {
				if(highlightError) {
					this.setCostTypeIdValueState(sap.ui.core.ValueState.Error);
				}
				isValid = false;
			} else {
				this.setCostTypeIdValueState(sap.ui.core.ValueState.None);
			}
			
			if(!this.CostTypeValue || this.CostTypeValue === "") {
				if(this.CostTypeId === "2" || this.CostTypeId === 2) {
					const oSettingsModel = MTRModels.getMTRSettingsModel();
					this.CostTypeValue = oSettingsModel.getProperty("/CostCenter");
				} else {
					if(highlightError) {
						this.setCostTypeValueState(sap.ui.core.ValueState.Error);
					}
					isValid = false;
				}
			} else {
				this.setCostTypeValueState(sap.ui.core.ValueState.None);
			}
			
			if(isSubmit && !this.validateISX(isSubmit)) {
				isValid = false;
			}
			
			if(!isValid && showMsg) {
				MessageToast.show("Please select mandatory fields");
			} else if(!isDurationValid && showMsg) {
				MessageToast.show("Please enter the duration and then proceed");
			}
			
			if(!isDurationValid) {
				return false;
			}
			
			return isValid;
		},
		
		validate: function (allowBlank, highlightError, showMsg, isSubmit) {
			return this._validate(allowBlank, highlightError, showMsg, isSubmit);
		},
		
		validateISX: function (isSubmit, openPopover) {
			var isValid = true;
			this.IOStaffing = null;
			if(this.CostTypeId === "1" || this.CostTypeId === 1 || this.CostTypeId === "3" || this.CostTypeId === 3) {
				isValid = this._validateISX(openPopover);
			}
			return isValid;
		},
		
		setTaskIdValueState: function (oValue) {
			this.TaskIdValueState = oValue;
		},
		
		setLocationIdValueState: function (oValue) {
			this.LocationIdValueState = oValue;
		},
		
		setCostTypeIdValueState: function (oValue) {
			this.CostTypeIdValueState = oValue;
		},
		
		setCostTypeValueState: function (oValue) {
			this.CostTypeValueState = oValue;
		},
		
		getModified: function () {
			return (this.LocationId !== this.PreviousLocationId && this.PreviousLocationId !== "") ||
				(this.CostTypeId !== this.PreviousLocationId && this.PreviousLocationId !== "") ||
				(this.CostTypeValue !== this.PreviousCostTypeValue && this.PreviousCostTypeValue !== "");
		},
		
		generateGUID: function() {
    		var s4 = (((1+Math.random())*0x10000)|0).toString(16).substring(1); 
    		return (s4 + s4 + "-" + s4 + "-4" + s4.substr(0,3) + "-" + s4 + "-" + s4 + s4 + s4).toLowerCase();
		}
	});
	
	Timesheet.prototype.duplicate = function () {
		return new Timesheet(this, false, true);
	};
	
	return Timesheet;
});