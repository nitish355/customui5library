sap.ui.define([
	"sap/ui/base/Object"
	], function(Object) {
		"use strict";
		/* @type sap.ui.base.Object */
		return Object.extend("com.melody.lib.classes.mtr.ManualIO", {
			constructor: function(oData) {
				Object.call(this);
				this.setData(oData);
			},
			
			setData: function (oData) {
				if (oData) {
					this.ManualIOID = (oData.ManualIOID) ? oData.ManualIOID : "";
					this.ManualIODesc = (oData.ManualIODesc) ? oData.ManualIODesc : "";
					this.DataFrom = (oData.DataFrom) ? oData.DataFrom : "";
					this.Indicator = (oData.Indicator) ? oData.Indicator : "";
					this.CreatedOn = (oData.CreatedOn) ? oData.CreatedOn : "";
					this.UpdatedOn = (oData.UpdatedOn) ? oData.UpdatedOn : "";
					this.IsArchive = (oData.IsArchive) ? oData.IsArchive : "";
					if(oData.IsVisible === true || oData.IsVisible === false) {
						this.IsVisible = oData.IsVisible;
					} else if(oData.IsArchive && oData.IsArchive === "X") {
						this.IsVisible = false;
					} else if(oData.IsArchive === "") {
						this.IsVisible = true;
					} else {
						this.IsVisible = false;
						this.IsDeleted = true;
					}
				}
			},
			
			getLSRequest: function (mParameters) {
				var oManualIO = {
					PrdProfMapId: mParameters.PrdProfMapId,
					UserGuid: mParameters.UserGuid,
					ManualIoId: this.ManualIOID,
					ManualDesc: this.ManualIODesc,
					Indicator: this.Indicator
				};
				if(this.IsVisible === true || this.Indicator === "C") {
					oManualIO.IsArchive = "";
				} else if(this.IsVisible === false) {
					oManualIO.IsArchive = "X";
				} 
				if(this.Indicator === "D"){
					oManualIO.IsArchive = "D";
				}
				return oManualIO;
			}
		});
	});