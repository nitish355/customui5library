sap.ui.define([
	"sap/ui/base/Object"
], function (Object) {
	"use strict";
	return Object.extend("com.melody.lib.classes.mtr.Category", {
		constructor: function (oData) {
			if (oData) {
				this.CategoryId = oData.CategoryId.toString();
				this.CategoryName = oData.CategoryName;
			}
		}
	});
});