sap.ui.define([
	"com/melody/lib/classes/mtr/BaseEntry",
	"com/melody/lib/service/DateService",
	"com/melody/lib/classes/mtr/MTRCostType",
	"com/melody/lib/classes/mtr/MTRLocation",
	"com/melody/lib/classes/mtr/Message",
	"sap/m/MessageToast",
	"com/melody/lib/util/mtr/MTRModels",
	"com/melody/lib/util/Activity",
	"com/melody/lib/util/opportunity/Opportunity",
	"com/melody/lib/service/OpportunityService",
	"com/melody/lib/model/StorageModel",
	"sap/ui/model/Filter",
], function (BaseEntry, DateService, MTRCostType,
	MTRLocation, Message, MessageToast, MTRModels, ActivityUtil, OpportunityUtil, OpportunityService, oStorageModel, Filter) {
	"use strict";
	var Entry = BaseEntry.extend("com.melody.lib.model.Entry", {
		constructor: function (oData) {
			BaseEntry.call(this);
			this.dateServicesInstance = DateService.getInstance();
			this.genericDateFormat = sap.ui.core.format.DateFormat.getInstance({
				pattern: "yMMdd",
				calendarType: sap.ui.core.CalendarType.Gregorian
			});
			this.uniqueIdTimeStamp = sap.ui.core.format.DateFormat.getInstance({
				pattern: "mmss",
				calendarType: sap.ui.core.CalendarType.Gregorian
			});
			this.IsLegacy = false;

			this.OpportunityID = "";
			this.OpportunityName = "";
			this.AccountID = "";
			this.AccountName = "";
			this.setData(oData);
		},

		setData: function (oData) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();

			this.MtrUid = (oData && oData.MtrUid) ? oData.MtrUid.toUpperCase() : this.generateGUID().toUpperCase();
			const sRecordDate = (oData && oData.RecordDate) ? oData.RecordDate : this.genericDateFormat.format(new Date());
			this.setRecordDate(sRecordDate);
			this.AddCategoryId = (oData && oData.AddCategoryId) ? oData.AddCategoryId.toString() : "";
			this.ActvtId = (oData && oData.ActvtId) ? oData.ActvtId.toString() : "";
			this.ActTypeDesc = (oData && oData.ActTypeDesc) ? oData.ActTypeDesc.toString() : "";
			this.CustomerFacing = (oData && (oData.CustomerFacing === "" || oData.CustomerFacing === false || oData.CustomerFacing === "F" )) ? false : true;
			this.TaskId = (oData && oData.TaskId) ? oData.TaskId.toString() : "";
			this.LocationId = (oData && oData.LocationId) ? oData.LocationId.toString() : "4";
			this.CostTypeId = (oData && oData.CostTypeId) ? oData.CostTypeId.toString().trim() : "";
			if (oData && oData.CostTypeValue && oData.CostTypeValue !== "") {
				this.CostTypeValue = oData.CostTypeValue;
			} else if (this.CostTypeId === "2" || this.CostTypeId === 2) {
				this.CostTypeValue = oSettingsModel.getProperty("/CostCenter");
			} else {
				this.CostTypeValue = "";
			}

			const timeMatrics = oSettingsModel.getProperty("/TimeMatrics");
			if (oData && oData.Unit) {
				if (oData.Unit === "TA") {
					this.Unit = "D";
				} else {
					this.Unit = oData.Unit;
				}
			} else {
				this.Unit = timeMatrics;
			}

			if (oData && oData.WorkDuration) {
				this.setDuration(oData.WorkDuration);
			} else {
				this.WorkDuration = "";
			}

			this.Note = (oData && oData.Note) ? oData.Note : "";

			this.StatusId = (oData && oData.StatusId) ? oData.StatusId.toString() : ""; // 1- Saved, 2 - In Queue, 3 - Failed, 4 -Submitted
			this.DataFrom = (oData && oData.DataFrom) ? oData.DataFrom.toString() : "";
			this.Indicator = (oData && oData.Indicator) ? oData.Indicator : "";

			this.TaskName = (oData && oData.TaskName) ? oData.TaskName : "";
			this.TaskCounter = (oData && oData.TaskCounter) ? oData.TaskCounter : "0";
			this.Counter = (oData && oData.Counter) ? oData.Counter : "0";
			this.IsLegacy = (oData && oData.IsLegacy) ? true : false;
			this.CostTypeName = "";
			this.ActDetails = {};
			this.isNonMatEntry = (oData && oData.isNonMatEntry ) ? oData.isNonMatEntry : false;
			this.setRestricted(oData);
			if (this.ActvtId) {
				this.setMelodyActivity(this.ActvtId);
			} else {
				this.setCostTypeName();
			}

			this.ActAsstId = this.CostTypeId ? (this.CostTypeId === "1" ? "502" : (this.CostTypeId === "4") ? "501" : "503") : "";

			const sTimeStamp = (oData && oData.CrtAtTimestamp) ? oData.CrtAtTimestamp.trim() : "";
			this.setCreationDate(sTimeStamp);

		},

		setMelodyActivity: function (sActvtId, oModel) {
			// const aActivities = await ActivityUtil.getUserActivities();
			ActivityUtil.getUserActivities().then(aActivities => {
				let oActivity = aActivities.find(item => sActvtId && parseInt(item.ActivityId, 10) === parseInt(sActvtId, 10));
				if (oActivity) {
					this.ActDetails = oActivity;
					this.ActvtId = oActivity.ActivityId;
					this.ActTypeDesc = oActivity.ActTypeDesc;
					this.ActAsstId = oActivity.ActAsstId;
					if (this.CostTypeId === "2") {
						const oSettingsModel = MTRModels.getMTRSettingsModel();
						this.CostTypeId = "2";
						this.CostTypeValue = oSettingsModel.getProperty("/CostCenter");
					} else {
						if (this.CostTypeId !== "3") {
							this.CostTypeValue = oActivity.CostTypeValue;
							if (oActivity.CostTypeName.toUpperCase() === "OPPORTUNITY") {
								this.CostTypeId = "1";
							} else if (oActivity.CostTypeName.toUpperCase() === "ACCOUNT") {
								this.CostTypeId = "4";
							} else {
								this.CostTypeId = "2";
							}
						}
					}
				}

				// await this.setCostTypeName();
				this.setCostTypeName(oModel);
			});
		},

		setCostTypeName: async function (oModel) {
			const that = this;
			const oMtrSettingsModel = sap.ui.getCore().getModel("mtrSettings");
			if (that.CostTypeId === "1") {
				const aOpportunities = oMtrSettingsModel.getProperty("/Opportunities");
				const aNONVatOppData = oMtrSettingsModel.getProperty("/aNONVatOppData") || [];
				let oSelectedOppDataForNonVat = oStorageModel.getProperty("/oSelectedOppDataForNonVat") || {};
				let oOpportunity = aOpportunities.find(item => item.OpportunityID === that.CostTypeValue);
				if (oOpportunity) {
					that.OpportunityID = that.CostTypeValue;
					that.OpportunityName = oOpportunity.OpportunityName;
					that.AccountID = oOpportunity.AccountID;
					that.AccountName = oOpportunity.AccountName;
					// return oOpportunity.OpportunityName;
					that.CostTypeName = oOpportunity.OpportunityName;
				} else {
					let sOpportunityName = "";
					//If CostType Value is of NON-VAT
					oOpportunity = aNONVatOppData.find(item => item.OpportunityId === that.CostTypeValue) || false;

					//if opp data is not found
					if (!oOpportunity && oSelectedOppDataForNonVat && Object.values(oSelectedOppDataForNonVat).length) {
						oOpportunity = (that.CostTypeValue === oSelectedOppDataForNonVat.OpportunityId) ? oSelectedOppDataForNonVat : false;
					}

					if (oOpportunity && "OpportunityName" in oOpportunity) {
						sOpportunityName = oOpportunity.OpportunityName;
					}

					if (oOpportunity) {
						that.OpportunityID = that.CostTypeValue;
						that.OpportunityName = sOpportunityName;
						that.AccountID = oOpportunity.AccountID;
						that.AccountName = oOpportunity.AccountName;
						that.CostTypeName = oOpportunity.OpportunityName;
					} else {
						//Worst-case if still opp data is not found;
						if (that.CostTypeValue) {
							let aFilters = [];
							aFilters.push(new Filter({
								path: "OPPT_ID",
								operator: sap.ui.model.FilterOperator.Contains,
								value1: that.CostTypeValue
							}));
							let aSearchFilter = new Filter({
								filters: aFilters,
								and: true
							});
							let mParameters = {
								filters: aSearchFilter,
							};
							let aResponse = await OpportunityUtil.fnSetFormatParamsForNonVATOppData(mParameters);
							if (aResponse && aResponse instanceof Array && aResponse.length) {
								oOpportunity = aResponse[0];
							}

							that.OpportunityID = that.CostTypeValue;
							that.OpportunityName = (oOpportunity && oOpportunity.hasOwnProperty("OpportunityName")) ? oOpportunity.OpportunityName :
								"Not Applicable";
							that.AccountID = (oOpportunity && oOpportunity.hasOwnProperty("AccountId")) ? oOpportunity.AccountId : "Not Applicable";
							that.AccountName = (oOpportunity && oOpportunity.hasOwnProperty("AccountName")) ? oOpportunity.AccountName : "Not Applicable";
							that.CostTypeName = (oOpportunity && oOpportunity.hasOwnProperty("OpportunityName")) ? oOpportunity.OpportunityName :
								"Not Applicable";

						} else {
							that.OpportunityID = that.CostTypeValue;
							that.OpportunityName = "Not Applicable";
							that.AccountID = "Not Applicable";
							that.AccountName = "Not Applicable";
							that.CostTypeName = "Not Applicable";
						}
					}
				}
			} else if (that.CostTypeId === "4") {
				const aAccounts = oMtrSettingsModel.getProperty("/to_ACCOUNT")
				const oAccount = aAccounts.find(item => item.AccountId === that.CostTypeValue);
				if (oAccount) {
					// return oAccount.AccountDesc;
					that.CostTypeName = oAccount.AccountDesc;
					that.OpportunityID = "";
					that.OpportunityName = "";
					that.AccountID = that.CostTypeValue;
					that.AccountName = oAccount.AccountDesc;
				} else {
					if (that.CostTypeValue) {
						const oResponse = await OpportunityService.getBusinessPartnerAttribSet(that.CostTypeValue);
						that.CostTypeName = (oResponse && oResponse.data) ? oResponse.data.PARTNER_NAME : "Not Applicable";
						that.OpportunityID = "";
						that.OpportunityName = "";
						that.AccountID = that.CostTypeValue;
						that.AccountName = (oResponse && oResponse.data) ? oResponse.data.PARTNER_NAME : "Not Applicable";
						if (oModel) {
							oModel.refresh(true);
						}
					}
				}
			}
		},

		setRestricted: function (oData) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();

			var dCurrentDate = new Date();
			var dRecordDate = this.RecordDate;
			var dStartDate = new Date(dRecordDate.substring(0, 4) + "/" + dRecordDate.substring(4, 6) + "/" + dRecordDate.substring(
				6, 8));
			var bRestrictPriorYear = oSettingsModel.getProperty("/RestrictPriorYear");
			var sCutOffDate = oSettingsModel.getProperty("/CutOffDate");
			var sGraceDate = oSettingsModel.getProperty("/GraceDate");
			if (sGraceDate) {
				var sGraceDay = Number(sGraceDate.substring(0, 2));
				var sGraceMonth = Number(sGraceDate.substring(3, 5));
				var sGraceYear = Number(sGraceDate.substring(6, 10));
			}
			var sStartYear = (sCutOffDate && sCutOffDate !== "") ? Number(sCutOffDate.substring(6, 10)) : dCurrentDate.getFullYear();
			if (oData && bRestrictPriorYear && sGraceDate) {
				if (dCurrentDate.getFullYear() === sGraceYear &&
					dCurrentDate.getMonth() + 1 === sGraceMonth && dCurrentDate.getDate() <= sGraceDay) {
					this.isRestricted = false;
				} else if (dStartDate.getFullYear() === sStartYear) {
					this.isRestricted = true;
				} else {
					this.isRestricted = false;
				}

			} else {
				this.isRestricted = false;
			}

		},

		setLocationName: function () {
			var oLocation = null;
			var that = this;
			const oSettingsModel = MTRModels.getMTRSettingsModel();

			var aMTRTasks = oSettingsModel.getProperty("/MTRTasks");
			var oTask = aMTRTasks.find(function (task) {
				return task.TaskId === that.TaskId;
			});
			if (oTask) {
				if (oTask.Locations.length > 0) {
					oLocation = oTask.Locations.find(function (item) {
						return item.LocationId === that.LocationId;
					});
				}
			}
			that.LocationName = (oLocation) ? oLocation.LocationName : "NA";
		},

		setTypeExportName: function () {
			const that = this;
			const oSettingsModel = MTRModels.getMTRSettingsModel();

			if (!this.CostTypeId || this.CostTypeId === "") {
				this.TypeExportName = "";
			}
			if (this.CostTypeId.toString() === "1") {
				var oOpportunity = oSettingsModel.getProperty("/Opportunities").find(function (o) {
					return that.CostTypeValue !== "" && parseInt(o.OpportunityID, 10) === parseInt(that.CostTypeValue, 10);
				});
				if (oOpportunity) {
					this.TypeExportName = "Opportunity: " + oOpportunity.AccountName + ": " + oOpportunity.OpportunityID + ": " + oOpportunity.OpportunityName;
				} else {
					this.TypeExportName = "Opportunity: " + that.CostTypeValue;
				}
			} else if (this.CostTypeId.toString() === "2") {
				this.TypeExportName = "Cost Center: " + oSettingsModel.getProperty("/CostCenter");
			} else if (this.CostTypeId.toString() === "3") {
				var aManualIO = oSettingsModel.getProperty("/to_MANUAL");
				var oManualIO = aManualIO.find(function (manualIO) {
					return manualIO.ManualIOID === that.CostTypeValue;
				});
				if (oManualIO) {
					this.TypeExportName = "Manual IO: " + oManualIO.ManualIOID + ": " + oManualIO.ManualIODesc;
				} else {
					this.TypeExportName = "Manual IO: " + that.CostTypeValue;
				}

			} else if (this.CostTypeId.toString() === "4") {
				var aAccount = oSettingsModel.getProperty("/to_ACCOUNT");
				var oAccount = aAccount.find(function (account) {
					return account.AccountId === that.CostTypeValue;
				});
				if (oAccount) {
					this.TypeExportName = "Account Id: " + oAccount.AccountId + ": " + oAccount.AccountDesc;
				} else {
					this.TypeExportName = "Account Id: " + that.CostTypeValue;
				}

			} else if (this.CostTypeId.toString() === "5") {
				this.TypeExportName = "Placeholder: " + this.CostTypeValue;
			}
		},

		setDuration: function (sDuration) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();

			var sTimeMatrics = oSettingsModel.getProperty("/TimeMatrics");
			var duration = parseFloat(sDuration).toFixed(1);
			if (this.Unit !== sTimeMatrics && sDuration && sDuration !== "") {
				if (this.Unit === "H") {
					if (parseFloat(sDuration) <= 4) {
						this.WorkDuration = "0.5";
						this.PreviousDuration = "0.5";
					} else {
						this.WorkDuration = "1";
						this.PreviousDuration = "1";
					}
				} else {
					if (parseFloat(sDuration) < 1) {
						this.WorkDuration = "4";
						this.PreviousDuration = "4";
					} else {
						this.WorkDuration = "8";
						this.PreviousDuration = "8";
					}
				}
				this.Unit = sTimeMatrics;
				this.OriginalDuration = duration;
			} else {
				this.WorkDuration = duration;
				this.PreviousDuration = duration;
				this.OriginalDuration = duration;
			}
		},

		setRecordDate: function (sRecordDate) {
			const that = this;
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			var sTimeMatrics = oSettingsModel.getProperty("/TimeMatrics");
			this.RecordDate = (sRecordDate) ? sRecordDate : this.genericDateFormat.format(new Date());
			this.Date = (sRecordDate) ? this.dateServicesInstance.formatStringDate(sRecordDate) : new Date();
			var weekStartDay = oSettingsModel.getProperty("/WeekStartDay");
			var isWeekend = this.getIsWeekends(weekStartDay);

			const oTargetModel = MTRModels.getTargetModel();
			var targetHours = oTargetModel.getProperty("/TargetHours");
			var sDateFormat = oSettingsModel.getProperty("/DateFormat");
			var oDateFormat = oSettingsModel.getProperty("/DateFormats") || [];
			oDateFormat = oDateFormat.find(function (d) {
				return d.ID === sDateFormat;
			});
			this.FormattedRecordDate = (oDateFormat) ? this.dateServicesInstance.formatStringDate(this.RecordDate,
				oDateFormat.Value) : this.RecordDate;
			this.FormattedLongDate = this.dateServicesInstance.formatStringDate(this.RecordDate, "EEEE, MMMM dd, y");
			if (targetHours.length > 0) {
				var oTargetHour = targetHours.find(function (item) {
					return item.Date === that.RecordDate;
				});

				if (oTargetHour) {
					this.DateType = oTargetHour.Datetype;
					var fTargetHours = parseFloat(oTargetHour.Targethours);
					if (!isNaN(fTargetHours) && fTargetHours !== 0) {
						if (sTimeMatrics === "H") {
							this.Expected = fTargetHours.toString();
						} else {
							this.Expected = "1";
						}
					} else {
						this.Expected = "0";
					}
				} else {
					this.DateType = (isWeekend) ? "OFF" : "WORK";
					if (sTimeMatrics === "H" && !isWeekend) {
						this.Expected = "8";
					} else if (sTimeMatrics !== "H" && !isWeekend) {
						this.Expected = "1";
					} else {
						this.Expected = "0";
					}
				}
			} else {
				this.DateType = (isWeekend) ? "OFF" : "WORK";
				if (sTimeMatrics === "H" && !isWeekend) {
					this.Expected = "8";
				} else if (sTimeMatrics !== "H" && !isWeekend) {
					this.Expected = "1";
				} else {
					this.Expected = "0";
				}
			}

			var dDate = new Date(this.RecordDate.substring(0, 4) + "/" + this.RecordDate.substring(4, 6) + "/" + this.RecordDate.substring(
				6, 8));
			this.StartDateOfWeek = this.dateServicesInstance.format(this.dateServicesInstance.getStartDateOfWeek(dDate), "yMMdd");

			this.IsSubmitEnabled = this.validateISPFutureDate();

		},

		getIsWeekends: function (iStartDayfOfWeek) {
			//var	iStartDayfOfWeek = parseInt(this.getStartDayOfWeek(), 10);
			var firstWeekend = 5 + iStartDayfOfWeek;
			if (firstWeekend > 6) {
				firstWeekend = firstWeekend - 7;
			}

			var secondWeekend = 6 + iStartDayfOfWeek;
			if (secondWeekend > 6) {
				secondWeekend = secondWeekend - 7;
			}

			var dRecordDate = this.dateServicesInstance.formatStringDate(this.RecordDate);
			var iRecordDay = dRecordDate.getDay();
			if (iRecordDay === firstWeekend || iRecordDay === secondWeekend) {
				return true;
			} else {
				return false;
			}
		},

		setValueState: function (sProperty, valueState) {
			this[sProperty] = valueState;
		},

		duplicate: function (sDate) {
			var dDate = this.dateServicesInstance.formatStringDate(sDate);
			var startDateOfWeek = this.dateServicesInstance.format(this.dateServicesInstance.getStartDateOfWeek(dDate, 1), "yMMdd");
			return new Entry({
				TaskId: this.TaskId,
				TaskIdTemp: this.TaskIdTemp,
				TaskIdValueState: sap.ui.core.ValueState.None,
				PreviousTaskId: this.PreviousTaskId,
				ActvtId: this.ActvtId,
				ActvtDesc: this.ActvtDesc,
				LocationId: this.LocationId,
				LocationIdValueState: sap.ui.core.ValueState.None,
				PreviousLocationId: this.PreviousLocationId,
				CostTypeId: this.CostTypeId,
				CostTypeIdValueState: sap.ui.core.ValueState.None,
				PreviousCostTypeId: this.PreviousCostTypeId,
				CostTypeValue: this.CostTypeValue,
				CostTypeValueState: sap.ui.core.ValueState.None,
				PreviousCostTypeValue: this.PreviousCostTypeValue,
				RecordDate: sDate,
				WorkDuration: this.WorkDuration,
				WorkDurationValueState: sap.ui.core.ValueState.None,
				PreviousDuration: this.PreviousDuration,
				Note: this.Note,
				PreviousNote: this.PreviousNote,
				DateType: this.DateType,
				Timestamp: "",
				Unit: this.Unit,
				StatusId: "",
				DataFrom: "",
				Indicator: "C",
				IsModified: this.IsModified,
				StartDateOfWeek: startDateOfWeek,
				SelectedCategory: this.SelectedCategory,
				SelectedCategoryTemp: this.SelectedCategoryTemp,
				IsLocation: this.IsLocation,
				IsLocationTemp: this.IsLocationTemp,
				// CostTypeIndex: this.CostTypeIndex,
				// CostTypeIndexTemp: this.CostTypeIndexTemp,
				// LocationIndex: this.LocationIndex,
				// LocationIndexTemp: this.LocationIndexTemp,
				// IsAddNoteVisible: this.IsAddNoteVisible,
				// IsDoneVisible: this.IsDoneVisible,
				// IsExpanded: this.IsExpanded,
				// ValueStateText: this.ValueStateText,
				// Locations: this.Locations,
				// CostTypes: this.copyCostTypes(),
				TaskName: this.TaskName,
				LocationName: this.LocationName,
				CostTypeName: this.CostTypeName,
				FormattedRecordDate: this.FormattedRecordDate
			});
		},

		copyCostTypes: function () {
			var costTypes = [];
			for (var i = 0; i < this.CostTypes.length; i++) {
				costTypes.push(new MTRCostType({
					CostTypeID: this.CostTypes[i].CostTypeId,
					CostTypeName: this.CostTypes[i].CostTypeName
				}));
			}
			return costTypes;
		},

		copyLocations: function () {
			var locations = [];
			for (var i = 0; i < this.Locations.length; i++) {
				locations.push(new MTRLocation({
					LocationId: this.Locations[i].LocationId,
					LocationName: this.Locations[i].LocationName
				}));
			}
			return locations;
		},

		setBlank: function () {
			this.MtrUid = this.generateGUID().toUpperCase();
			this.IspGuid = "";
			this.WorkDuration = "";
			this.PreviousDuration = "";
			this.Note = "";
			this.PreviousNote = "";
			this.StatusId = "";
			this.DataFrom = "";
			this.Indicator = "";
			this.IsModified = false;
			this.Busy = false;
		},

		blankPrevious: function () {
			this.PreviousTaskId = "";
			this.PreviousLocationId = "";
			this.PreviousCostTypeId = "";
			this.PreviousCostTypeValue = "";
			this.PreviousDuration = "";
			this.PreviousNote = "";
		},

		getCostTypeChar: function () {
			var costTypeChar;
			switch (this.CostTypeId) {
			case "1":
				costTypeChar = "O";
				break;
			case "2":
				costTypeChar = "C";
				break;
			case "3":
				costTypeChar = "M";
				break;
			case "4":
				costTypeChar = "A";
				break;
			default:
				costTypeChar = "P";
				break;
			}
			return costTypeChar;
		},

		getLocationChar: function () {
			var locationChar;
			switch (this.LocationId) {
			case "1":
				locationChar = "O";
				break;
			case "2":
				locationChar = "V";
				break;
			case "3":
				locationChar = "R";
				break;
			case "4":
				locationChar = "V";
				break;
			default:
				locationChar = "N";
				break;
			}
			return locationChar;
		},

		getISXLocationChar: function () {
			var locationChar;
			switch (this.LocationId) {
			case "1":
				locationChar = "O";
				break;
			case "2":
				locationChar = "R";
				break;
			case "3":
				locationChar = "R";
				break;
			case "4":
				locationChar = "R";
				break;
			default:
				locationChar = "";
				break;
			}
			return locationChar;
		},

		validateISXEntry: function (isAddMessageNotRequired, openPopover) {
			var isValid = true;
			this.IOStaffing = null;
			if (this.CostTypeId === "1" || this.CostTypeId === 1 || this.CostTypeId === "3" || this.CostTypeId === 3) {
				isValid = this._validateISX(openPopover);
			}
			return isValid;
		},

		getValidationError: function (sErrMsg) {
			const oResourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
			this.setValueState("WorkDurationValueState", sap.ui.core.ValueState.None);
			this.WorkDurationValueStateText = "";
			let bIOSetting = true;
			let isValidationHandled = false;
			let validationErrorMsg = "";
			if (this.CostTypeId === "1" || this.CostTypeId === 1 || this.CostTypeId === "3" || this.CostTypeId === 3) {
				var that = this;
				var sInternalOrder = "";
				// var oComponent = Application.getInstance().Component;
				// var oResourceBundle = oComponent.getModel("i18n").getResourceBundle();
				const oSettingsModel = MTRModels.getMTRSettingsModel();
				const oStaffingModel = MTRModels.getStaffingModel();
				const aStaffingRecord = oStaffingModel.getData();
				const aOpportunities = oSettingsModel.getProperty("/Opportunities");
				const oTask = oSettingsModel.getProperty("/MTRTasks").find(function (item) {
					return item.TaskId.toString() === that.TaskId.toString();
				});
				let isValidIO = false;
				const aTaskTypes = [];
				const aTaskLevels = [];
				let oCurrentStaffing;
				const aManualIOs = oSettingsModel.getProperty("/to_MANUAL");
				let oOpportunity = null;
				let oManualIO = null;
				let isOpportunity = true;
				if (this.CostTypeId === "1" || this.CostTypeId === 1) {
					oOpportunity = aOpportunities.find(function (item) {
						return item.OpportunityID === that.CostTypeValue;
					});
					if (oOpportunity && oOpportunity.AssociatedIO && oOpportunity.AssociatedIO !== "") {
						sInternalOrder = oOpportunity.AssociatedIO;
					}
					if (oOpportunity && oOpportunity.IOSetting !== "Yes") {
						bIOSetting = false;
					}
				} else if ((this.CostTypeId === "3" || this.CostTypeId === 3) && this.CostTypeValue && this.CostTypeValue !== "") {
					oManualIO = aManualIOs.find(function (item) {
						return item.ManualIOID === that.CostTypeValue;
					});
					if (oManualIO) {
						sInternalOrder = this.CostTypeValue;
					}
					isOpportunity = false;
				}
				var aAssociatedIOData = aStaffingRecord.filter(function (item) {
					return sInternalOrder !== "" && item.InternalOrder === sInternalOrder;
				});
				if (aAssociatedIOData && oTask && bIOSetting) {
					for (var i = 0; i < aAssociatedIOData.length; i++) {
						var oTaskType = aTaskTypes.find(function (item) {
							return item === aAssociatedIOData[i].TaskType;
						});
						if (!oTaskType) {
							aTaskTypes.push(aAssociatedIOData[i].TaskType);
						}
						var oTaskLevel = aTaskLevels.find(function (item) {
							return item === aAssociatedIOData[i].TaskLevel;
						});
						if (!oTaskLevel) {
							aTaskLevels.push(aAssociatedIOData[i].TaskLevel);
						}
						if (this.dateServicesInstance.validateBetweenStringDate(aAssociatedIOData[i].StartDate, aAssociatedIOData[i].EndDate, this.RecordDate) &&
							this.WorkDuration && this.WorkDuration !== "") {
							if (aAssociatedIOData[i].TaskLevel === oTask.TaskLevel &&
								aAssociatedIOData[i].TaskType === oTask.IspTask) {
								oCurrentStaffing = aAssociatedIOData[i];
								isValidIO = true;
							}
							if (!oCurrentStaffing && aAssociatedIOData[i].TaskType === "") {
								oCurrentStaffing = aAssociatedIOData[i];
								isValidIO = true;
							}
						}

					}

					if (!isValidIO) {
						isValidationHandled = true;

						/*let sDescription = "INFO SECTION \n\nSelected Opportunity " + this.CostTypeValue + " is associated with an IO " + sInternalOrder +
							" which has been assigned to the Task Type or Task Level not matching with the Task Type or Task Level assigned to the Task you have Selected. \n\n1. IO – " +
							sInternalOrder + " assigned to Task Level " + aTaskLevels.toString() + " and Task Type " + aTaskTypes.toString() +
							". \n2. Task Selected " + oTask.TaskName + " assigned to Task Level " + oTask.TaskLevel + " and Task Type " + oTask.IspTask +
							". \n\nRESOLUTION \n\nPlease reach out to your Opportunity Owner for resolution, you can save the entry for now."*/

						var sDescription = oResourceBundle.getText("ioTaskNotMatchMsgDesc", [this.CostTypeValue, sInternalOrder, aTaskLevels.toString(),
							aTaskTypes.toString(), oTask.TaskName, oTask.TaskLevel, oTask.IspTask
						]);
						var oMessage = new Message({
							Type: sap.ui.core.MessageType.Error,
							Title: "IO Task Type or Task Level not matching with Task Selected",
							Description: sDescription,
							Subtitle: ""
						});
						let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
						oMessage.addToMessages(this.MtrUid, activityId);
						this.setValueState("WorkDurationValueState", sap.ui.core.ValueState.Error);
						this.WorkDurationValueStateText = "IO Task Type or Task Level not matching with Task Selected";
						validationErrorMsg = "IO Task Type or Task Level not matching with Task Selected";
					}

					if (oCurrentStaffing) {
						var oTempWorkDur = parseFloat(this.WorkDuration);
						if (this.Unit === "H") {
							oTempWorkDur = parseFloat(this.WorkDuration) / 8;
						}
						if (this.WorkDuration && this.WorkDuration !== "" && parseFloat(oCurrentStaffing.StaffedDays) <= (parseFloat(oCurrentStaffing.RecordedDays) +
								oTempWorkDur)) {
							isValidationHandled = true;
							/*let sDescription = "INFO SECTION \n\nSelected Opportunity " + this.CostTypeValue + " is associated with an IO " +
								oCurrentStaffing.InternalOrder + " for which you have been Staffed for " + parseFloat(oCurrentStaffing.StaffedDays).toFixed(1) +
								" days. \n\n1. IO staffing for " + parseFloat(oCurrentStaffing.StaffedDays).toFixed(1) +
								" days. \n2. Already you have submitted time recording for " + parseFloat(oCurrentStaffing.RecordedDays).toFixed(1) +
								" days. \n3. " + (parseFloat(oCurrentStaffing.StaffedDays) - parseFloat(oCurrentStaffing.RecordedDays)).toFixed(1) +
								" days available for time recording \n\nRESOLUTION \n\nPlease contact Opportunity Owner to extend your staffing period. However, you can save the entry for now.";*/
							let sDescription = oResourceBundle.getText("staffedDaysLimitMsgDesc", [this.CostTypeValue, oCurrentStaffing.InternalOrder,
								parseFloat(oCurrentStaffing.StaffedDays).toFixed(1), parseFloat(oCurrentStaffing.RecordedDays).toFixed(1), (parseFloat(
									oCurrentStaffing.StaffedDays) - parseFloat(oCurrentStaffing.RecordedDays)).toFixed(1)
							]);
							oMessage = new Message({
								Type: sap.ui.core.MessageType.Error,
								Title: "You have reached the max " + parseFloat(oCurrentStaffing.StaffedDays).toFixed(1) + " days staffed on the IO.",
								Description: sDescription,
								Subtitle: ""
							});
							let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
							oMessage.addToMessages(this.MtrUid, activityId);
							this.setValueState("WorkDurationValueState", sap.ui.core.ValueState.Error);
							this.WorkDurationValueStateText = "You have reached the max " + parseFloat(oCurrentStaffing.StaffedDays).toFixed(1) +
								" days staffed on the IO.";
							validationErrorMsg = "You have reached the max " + parseFloat(oCurrentStaffing.StaffedDays).toFixed(1) +
								" days staffed on the IO.";
						}
						var calcStaffing = that.validateStaffingPeriod(oCurrentStaffing);
						if (calcStaffing.isValidationHandled) {
							isValidationHandled = true;
							validationErrorMsg = calcStaffing.msg;
						}
					}
				}
			}
			if (!isValidationHandled) {
				oMessage = new Message({
					Type: sap.ui.core.MessageType.Error,
					Title: sErrMsg,
					Description: sErrMsg,
					Subtitle: ""
				});
				let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
				oMessage.addToMessages(this.MtrUid, activityId);
				this.setValueState("WorkDurationValueState", sap.ui.core.ValueState.Error);
				this.WorkDurationValueStateText = sErrMsg;
				return sErrMsg;
			}
			return validationErrorMsg;
		},

		validateStaffingPeriod: function (oStaffingRecord, isAddMessageNotRequired) {
			var isValidationHandled = false;
			var validationErrorMsg = "";
			if (!this.dateServicesInstance.validateBetweenStringDate(oStaffingRecord.StartDate, oStaffingRecord.EndDate, this.RecordDate) &&
				this.WorkDuration && this.WorkDuration !== "") {
				if (!isAddMessageNotRequired) {
					const oSettingsModel = MTRModels.getMTRSettingsModel();
					const sDateFormat = oSettingsModel.getProperty("/DateFormat");
					const oDateFormat = oSettingsModel.getProperty("/DateFormats").find(function (d) {
						return d.ID === sDateFormat;
					});
					isValidationHandled = true;

					let sDescription = "INFO SECTION \n\nSelected Opportunity " + this.CostTypeValue +
						" is associated with an IO which has Staffing period between " + this.dateServicesInstance.formatStringDate(
							oStaffingRecord.StartDate, oDateFormat.Value) + " and " + this.dateServicesInstance.formatStringDate(oStaffingRecord.EndDate,
							oDateFormat.Value) +
						". \n\nRESOLUTION \n\nPlease submit your entry within staffing period, or submit a ticket for resolution, you can save the entry for now.";

					/*var sDescription = oResourceBundle.getText("staffingPeriodMsgDesc", [this.CostTypeValue, this.dateServicesInstance.formatStringDate(
						oStaffingRecord.StartDate, oDateFormat.Value), this.dateServicesInstance.formatStringDate(oStaffingRecord.EndDate,
						oDateFormat.Value)]);*/
					var oMessage = new Message({
						Type: sap.ui.core.MessageType.Error,
						Title: "Time entry for this IO is outside the staffing period",
						Description: sDescription,
						Subtitle: ""
					});
					let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
					oMessage.addToMessages(this.MtrUid, activityId);
					this.setValueState("WorkDurationValueState", sap.ui.core.ValueState.Error);
					this.WorkDurationValueStateText = "Time entry for this IO is outside the staffing period";
					this.setValueState("CostTypeValueState", sap.ui.core.ValueState.Error);
					validationErrorMsg = "Time entry for this IO is outside the staffing period";
				}
			}
			return {
				isValidationHandled: isValidationHandled,
				msg: validationErrorMsg
			};
		},

		padWithZeroes: function (number, length) {
			var myString = "" + number;
			while (myString.length < length) {
				myString = "0" + myString;
			}
			return myString;
		},

		getRaccobjGenrec: function (sObjnr, sObart, sCostCenter) {
			var raccobjGenrec = "";
			if (sObjnr && sObjnr !== "") {
				raccobjGenrec = sObjnr.replace(sObart, "");
				raccobjGenrec = raccobjGenrec.replace(sCostCenter, "");
				raccobjGenrec = raccobjGenrec + sCostCenter.replace("0", "/");
			}
			return raccobjGenrec;
		},

		getContactPerson: function () {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			var sAccountId = 0,
				sOppId = 0,
				sLocationId = 0,
				sActvtId = 0,
				sCustomerFacing = ((this.CustomerFacing === "" || this.CustomerFacing === false)) ? "F" : "T";
			var that = this;
			if (this.CostTypeId === "1" || this.CostTypeId === 1) {
				var aOpportunities = oSettingsModel.getProperty("/Opportunities");
				var oOpportunity = aOpportunities.find(function (item) {
					return item.OpportunityID === that.CostTypeValue;
				});
				if (oOpportunity) {
					sOppId = oOpportunity.OpportunityID;
					sAccountId = oOpportunity.AccountID;
				}
			} else if (this.CostTypeId === "4" || this.CostTypeId === 4) {
				sAccountId = this.CostTypeValue;
			}
			if (this.LocationId && this.LocationId !== "") {
				sLocationId = this.LocationId;
			}

			if (this.ActvtId && this.ActvtId !== "") {
				sActvtId = this.ActvtId;
			}

			var sUpdatedAccountId = (sAccountId && sAccountId !== "") ? this.padWithZeroes(sAccountId, 10) : this.padWithZeroes(0, 10);
			var sUpdatedOppId = (sOppId && sOppId !== "") ? this.padWithZeroes(sOppId, 9) : this.padWithZeroes(0, 9);
			if (sActvtId === 0) {
				return sUpdatedAccountId + "/" + sUpdatedOppId + "/" + sLocationId + "/" + "" + "/" + sCustomerFacing;
			} else {
				return sUpdatedAccountId + "/" + sUpdatedOppId + "/" + sLocationId + "/" + sActvtId + "/" + sCustomerFacing;
			}
		},

		getTask: function () {
			var that = this;
			var oTask = {
				TaskType: "",
				SubTaskType: ""
			};
			const oSettingsModel = MTRModels.getMTRSettingsModel();

			var oTask = oSettingsModel.getProperty("/MTRTasks").find(function (item) {
				return item.TaskId.toString() === that.TaskId.toString();
			});
			if (oTask) {
				if (oTask.EssInMu && oSettingsModel.getProperty("/BelongEss") === "1") {
					oTask.TaskType = "ADMI";
					oTask.SubTaskType = "ALLOTHR";
				} else {
					oTask.TaskType = oTask.IspTask;
					oTask.SubTaskType = oTask.IspSubTask;
				}
			}
			return oTask;
		},

		getISRequest: function (mParameters) {
			const that = this;
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const oStaffingModel = MTRModels.getStaffingModel();
			const aStaffingRecord = oStaffingModel.getData();
			const oResourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
			let timeMatrics = "H";
			if (oSettingsModel.getProperty("/TimeMatrics") === "D") {
				timeMatrics = "TA";
			}
			let isKS = true;
			let sRaccobjText = oSettingsModel.getProperty("/CostCenterName");
			let sObjnr = oSettingsModel.getProperty("/Objnr");
			let sInternalOrder = "";
			let sRaufnr = "";
			let sObart = "KS";
			if (this.CostTypeId === "1") {
				const aOpportunities = oSettingsModel.getProperty("/Opportunities");
				const oOpportunity = aOpportunities.find(function (item) {
					return item.OpportunityID === that.CostTypeValue;
				});
				if (oOpportunity) {
					sInternalOrder = oOpportunity.AssociatedIO;
				}

				if (oOpportunity && oOpportunity.IOSetting === "Yes") {
					isKS = false;
					if ((!sInternalOrder || sInternalOrder === "") && mParameters.Indicator !== "D") {
						var sDescription = oResourceBundle.getText("blankIOMsgDesc", [this.CostTypeValue]);
						var oMessage = new Message({
							Type: sap.ui.core.MessageType.Error,
							Title: oResourceBundle.getText("blankIOMsg"),
							Description: sDescription,
							Subtitle: ""
						});
						let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
						oMessage.addToMessages(this.MtrUid, activityId);
						this.setValueState("WorkDurationValueState", sap.ui.core.ValueState.Error);
						this.WorkDurationValueStateText = "IO not associated with Opportunity";
						MessageToast.show(this.WorkDurationValueStateText);
						return null;
					}
				} else if (oOpportunity && oOpportunity.IOSetting === "Error") {
					isKS = false;
					var sDescriptionProduct = oResourceBundle.getText("noCloudAndPreIOMsgDesc", [this.CostTypeValue]);
					var oMessageProduct = new Message({
						Type: sap.ui.core.MessageType.Error,
						Title: oResourceBundle.getText("noCloudAndPreIOMsg"),
						Description: sDescriptionProduct,
						Subtitle: ""
					});
					let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
					oMessageProduct.addToMessages(this.MtrUid, activityId);
					this.setValueState("WorkDurationValueState", sap.ui.core.ValueState.Error);
					this.WorkDurationValueStateText = oResourceBundle.getText("noCloudAndPreIOMsg");
					MessageToast.show(this.WorkDurationValueStateText);
					return null;

				} else if (!oOpportunity || (oOpportunity && oOpportunity.IOSetting === "")) {
					isKS = false;
					var sDescriptionNoAcc = oResourceBundle.getText("noAccessOppDesc", [this.CostTypeValue]);
					var oMessageNoAcc = new Message({
						Type: sap.ui.core.MessageType.Error,
						Title: oResourceBundle.getText("noAccessOppMsg"),
						Description: sDescriptionNoAcc,
						Subtitle: ""
					});
					let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
					oMessageNoAcc.addToMessages(this.MtrUid, activityId);
					this.setValueState("WorkDurationValueState", sap.ui.core.ValueState.Error);
					this.WorkDurationValueStateText = oResourceBundle.getText("noAccessOppMsg");
					MessageToast.show(this.WorkDurationValueStateText);
					return null;

				} else if (oOpportunity && oOpportunity.isAllowed === false) {
					isKS = false;
					if (oOpportunity && oOpportunity.REPLACED_BY) {
						var isRepOpp = aOpportunities.find(function (item) {
							return item.OpportunityID === oOpportunity.REPLACED_BY;
						});
					}
					var sDescriptionReplace = (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && isRepOpp) ? oResourceBundle.getText(
						"gracePerWithRepBy", [
							this.CostTypeValue, oOpportunity.REPLACED_BY
						]) : (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && !isRepOpp) ? oResourceBundle.getText(
						"gracePerWithRep", [
							this.CostTypeValue, oOpportunity.REPLACED_BY
						]) : oResourceBundle.getText("noGracePerDesc", [this.CostTypeValue]);
					var oMessageReplace = new Message({
						Type: sap.ui.core.MessageType.Error,
						Title: oResourceBundle.getText("noGracePerMsg"),
						Description: sDescriptionReplace,
						Subtitle: ""
					});
					let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
					oMessageReplace.addToMessages(this.MtrUid, activityId);
					this.setValueState("WorkDurationValueState", sap.ui.core.ValueState.Error);
					this.WorkDurationValueStateText = oResourceBundle.getText("noGracePerMsg");
					MessageToast.show(this.WorkDurationValueStateText);
					return null;

				} else if (oOpportunity && oOpportunity.isAllowedStat === false) {
					isKS = false;
					if (oOpportunity && oOpportunity.REPLACED_BY) {
						var isRepOpp = aOpportunities.find(function (item) {
							return item.OpportunityID === oOpportunity.REPLACED_BY;
						});
					}
					var sDescriptionStat = (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && isRepOpp) ? oResourceBundle.getText(
						"gracePerStatWithRepBy", [
							this.CostTypeValue, oOpportunity.REPLACED_BY
						]) : (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && !isRepOpp) ? oResourceBundle.getText(
						"gracePerStatWithRep", [
							this.CostTypeValue, oOpportunity.REPLACED_BY
						]) : oResourceBundle.getText("noGracePerStatDesc", [this.CostTypeValue]);
					var oMessageStat = new Message({
						Type: sap.ui.core.MessageType.Error,
						Title: oResourceBundle.getText("noGracePerStatDesc"),
						Description: sDescriptionStat,
						Subtitle: ""
					});
					let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
					oMessageStat.addToMessages(this.MtrUid, activityId);
					this.setValueState("WorkDurationValueState", sap.ui.core.ValueState.Error);
					this.WorkDurationValueStateText = oResourceBundle.getText("noGracePerStatDesc");
					MessageToast.show(this.WorkDurationValueStateText);
					return null;

				}
			} else if (this.CostTypeId === "3") {
				isKS = false;
				sInternalOrder = this.CostTypeValue;
			}

			if (!isKS && sInternalOrder && sInternalOrder !== "") {
				var oStaffingRecord = aStaffingRecord.find(function (item) {
					return item.InternalOrder !== "" && item.InternalOrder === sInternalOrder;
				});
				if (oStaffingRecord) {
					sObart = oStaffingRecord.Obart;
					sObjnr = oStaffingRecord.Objnr;
					sRaccobjText = oStaffingRecord.Description;
					sRaufnr = oStaffingRecord.Raufnr;
				}
			}

			this.Note = (this.Note && this.Note !== "") ? this.Note : this.getTask().TaskType;

			var oData = {
				"Taskcounter": this.TaskCounter,
				"Testrun": "",
				"Version": "",
				"Msgno": "P",
				"Msgtxt": "",
				"Activity": [{
					"Taskcounter": this.TaskCounter,
					"Counter": this.Counter,
					"Taskcomponent": mParameters.TaskComponent,
					"Pflag": mParameters.Indicator,
					"Pernr": mParameters.PersonalNumber,
					"Workdate": this.RecordDate,
					"Skostl": (mParameters.Indicator === "D" && mParameters.TaskComponent !== "WORKSTAT" && mParameters.TaskComponent !==
						"WDAYSST") ? mParameters.CostCenter : "",
					"Unit": timeMatrics,
					"Catsquantity": this.WorkDuration.toString(),
					"Waers": "",
					"Catsamount": "0.00",
					"Status": "",
					"Ltxa1": (this.Note && this.Note !== "" && this.Note.length > 40) ? this.Note.substring(0, 40) : this.Note,
					"Rkostl": (isKS) ? mParameters.CostCenter : "",
					"Rproj": "",
					"Raufnr": (isKS) ? "" : sRaufnr,
					"Rnplnr": "",
					"Raufpl": "",
					"Raplzl": "",
					"Vornr": "",
					"Rkdauf": "",
					"Rkdpos": "",
					"Lstnr": "",
					"Tasktype": (this.getTask().TaskType && this.getTask().TaskType !== "") ? this.getTask().TaskType : mParameters.IspTask,
					"Tasktypetext": mParameters.IspTaskdes,
					"Tasklevel": mParameters.TaskLevel,
					"Raccobj": (isKS) ? "Cost center" : "Order",
					"Raccobj_text": sRaccobjText,
					"Raccobj_genrec": (isKS) ? this.getRaccobjGenrec(sObjnr, sObart, mParameters.CostCenter) : sInternalOrder,
					"Zzsubtype": (this.getTask().SubTaskType && this.getTask().SubTaskType !== "") ? this.getTask().SubTaskType : mParameters.IspSubTask,
					"Zz_npktxt": this.getLocationChar() + this.MtrUid + "~" + this.CostTypeId + this.CostTypeValue,
					"Zz_location": this.getISXLocationChar(),
					"Zzpsptxt": "",
					"Zzcontpers": this.getContactPerson(),
					"Zz_projn": "",
					"Zzbyd": "",
					"Zcpr_guid": "",
					"Zcpr_extid": "",
					"Zcpr_objguid": "",
					"Zcpr_objgextid": "",
					"Zcpr_objtype": "",
					"Obart": sObart,
					"Objnr": sObjnr,
					"Essposting": "",
					"Tmp_key": "",
					"Trv_rkdauf": "",
					"Trv_rkdpos": "",
					"Zz_rel_obj": "",
					"Newo2c": "",
					"Msgno": "P",
					"Msgtxt": "",
					"Zzmoberrflag": ""
				}]
			};

			if (!mParameters.IsSubmit) {
				return oData;
			}
			var isISPDataValid = this.validateISXEntry(true);
			if (isISPDataValid && mParameters.IsSubmit) {
				return {
					isValid: isISPDataValid,
					data: oData
				};
			} else if (!isISPDataValid && mParameters.IsSubmit) {
				return {
					isValid: isISPDataValid,
					data: oData,
					msg: this.ErrorMsg
				};
			}
		},

		getLSRequest: function (mParameters) {
			return {
				UserGuid: mParameters.UserGuid,
				MtrUid: this.MtrUid,
				RecordDate: this.RecordDate,
				IspGuid: this.IspGuid,
				StatusId: parseInt(mParameters.StatusId, 10),
				ActivityId: parseInt(mParameters.TaskId, 10),
				ActvtId: this.ActvtId,
				ProjectType: (this.ProjectType) ? this.ProjectType : "MTR",
				LocationId: (mParameters.LocationId) ? parseInt(mParameters.LocationId, 10) : 0,
				CostTypeId: parseInt(mParameters.CostTypeId, 10),
				CostTypeValue: mParameters.CostTypeValue,
				WorkDuration: (this.WorkDuration) ? parseFloat(this.WorkDuration).toFixed(1) : "0",
				Unit: this.Unit,
				Note: this.Note,
				PrdProfMapId: mParameters.ProfileId.toString(),
				Timestamp: "",
				Errmsg: (mParameters.ErrorMsg) ? mParameters.ErrorMsg : "",
				IsArchive: "",
				Indicator: (mParameters.Indicator) ? mParameters.Indicator : this.Indicator,
				CustomerFacing: (this.CustomerFacing) ? "X" : ""
			};
		},

		compare: function (oData) {
			return (this.MtrUid === oData.MtrUid &&
				this.IspGuid === oData.IspGuid &&
				this.TaskId === oData.TaskId &&
				this.LocationId === oData.LocationId &&
				this.CostTypeId === oData.CostTypeId &&
				this.CostTypeValue === oData.CostTypeValue &&
				this.RecordDate === oData.RecordDate &&
				this.WorkDuration === oData.WorkDuration &&
				this.Note === oData.Note);
		},

		validate: function (highlightError, showMsg, isSubmit) {
			var isValid = true;

			if (isNaN(parseFloat(this.WorkDuration))) {
				if (highlightError) {
					this.setValueState("WorkDurationValueState", sap.ui.core.ValueState.Error);
				}
				isValid = false;
			} else {
				this.setValueState("WorkDurationValueState", sap.ui.core.ValueState.None);
			}

			if (!this.TaskId || this.TaskId === "") {
				if (highlightError) {
					this.setValueState("TaskIdValueState", sap.ui.core.ValueState.Error);
				}
				isValid = false;
			} else {
				this.setValueState("TaskIdValueState", sap.ui.core.ValueState.None);
			}

			if (this.Locations && this.Locations.length > 0 && (!this.LocationId || this.LocationId === "")) {
				if (highlightError) {
					this.setValueState("LocationIdValueState", sap.ui.core.ValueState.Error);
				}
				isValid = false;
			} else {
				this.setValueState("LocationIdValueState", sap.ui.core.ValueState.None);
			}

			if (this.CostTypes && this.CostTypes.length > 0 && (!this.CostTypeId || this.CostTypeId === "")) {
				if (highlightError) {
					this.setValueState("CostTypeIdValueState", sap.ui.core.ValueState.Error);
				}
				isValid = false;
			} else {
				this.setValueState("CostTypeIdValueState", sap.ui.core.ValueState.None);
			}

			if (!this.CostTypeValue || this.CostTypeValue === "") {
				if (this.CostTypeId === "2" || this.CostTypeId === 2) {
					const oSettingsModel = MTRModels.getMTRSettingsModel();
					this.CostTypeValue = oSettingsModel.getProperty("/CostCenter");
				} else {
					if (highlightError) {
						this.setValueState("CostTypeValueState", sap.ui.core.ValueState.Error);
					}
					isValid = false;
				}
			} else {
				this.setValueState("CostTypeValueState", sap.ui.core.ValueState.None);
			}

			if (isSubmit && !this.validateISXEntry()) {
				isValid = false;
			}

			if (!isValid && showMsg) {
				MessageToast.show("Please select mandatory fields");
			}

			return isValid;
		},

		getISModified: function () {
			return (this.DataFrom !== "I" || (this.DataFrom === "I" && this.Indicator !== ""));
		},

		getModified: function () {
			var isModified = false;
			if (this.Locations.length > 0) {
				if (
					this.WorkDuration !== "" &&
					(this.LocationId && this.LocationId !== "") &&
					this.CostTypes.length > 0 && this.CostTypeId && this.CostTypeId !== "" &&

					((this.WorkDuration !== this.PreviousDuration) ||
						(this.TaskId !== this.PreviousTaskId) ||
						(this.LocationId !== this.PreviousLocationId) ||
						(this.CostTypeId !== this.PreviousCostTypeId) ||
						(this.CostTypeValue !== this.PreviousCostTypeValue) ||
						(this.Note !== this.PreviousNote))) {
					isModified = true;
				}
			} else {
				if (
					this.WorkDuration !== "" &&
					this.LocationId === "" &&
					this.CostTypes.length > 0 && this.CostTypeId && this.CostTypeId !== "" &&
					((this.WorkDuration !== this.PreviousDuration) ||
						(this.TaskId !== this.PreviousTaskId) ||
						(this.LocationId !== this.PreviousLocationId) ||
						(this.CostTypeId !== this.PreviousCostTypeId) ||
						(this.CostTypeValue !== this.PreviousCostTypeValue) ||
						(this.Note !== this.PreviousNote))) {
					isModified = true;
				}
			}
			return isModified;
		},

		generateGUID: function () {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			var sPersonalNumber = oSettingsModel.getProperty("/PersonalNumber");
			return sPersonalNumber + this.uniqueIdTimeStamp.format(new Date()) + Math.floor(100 + Math.random() *
				900) + "MTR";
		},

		validateISPFutureDate: function () {
			const dCurrentDate = new Date();
			const dFutureDate = new Date(dCurrentDate.setDate(dCurrentDate.getDate() + 7));
			dFutureDate.setHours(0, 0, 0, 0);
			// const dRecordDate = new Date(this.FormattedRecordDate);
			var dRecordDate = new Date(this.RecordDate.substring(0, 4) + "/" + this.RecordDate.substring(4, 6) + "/" + this.RecordDate.substring(
				6, 8));
			if (dRecordDate >= dFutureDate) {
				return false;
			} else {
				return true;
			}
		},

		setCreationDate: function (sTimestamp) {
			let dCreatedOn = new Date();
			if (sTimestamp) {
				dCreatedOn = new Date(sTimestamp.substring(0, 4) + "/" + sTimestamp.substring(4, 6) + "/" + sTimestamp.substring(6, 8) + " " +
					sTimestamp.substring(8, 10) + ":" + sTimestamp.substring(10, 12) + ":" + sTimestamp.substring(12, 14));
				this.CreatedOn = dCreatedOn;
			}
		}

	});
	return Entry;
});