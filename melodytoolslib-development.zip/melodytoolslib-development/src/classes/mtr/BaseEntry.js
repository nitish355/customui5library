sap.ui.define([
	"com/melody/lib/classes/BaseObject",
	"com/melody/lib/classes/mtr/Message",
	"com/melody/lib/service/DateService",
	"com/melody/lib/util/mtr/MTRModels"
], function (BaseObject, Message, DateService, MTRModels) {
	"use strict";
	var BaseEntry = BaseObject.extend("com.melody.lib.classes.mtr.BaseEntry", {
		dateServicesInstance: DateService.getInstance(),
		constructor: function () {
			this.IOStaffing = null;
			this.IOStaffingList = null;
			BaseObject.call(this);
		},

		getIOStaffing: function () {
			const that = this;
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const oStaffingModel = MTRModels.getStaffingModel();
			const oResourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
			const aStaffingRecord = oStaffingModel.getData();
			const aOpportunities = oSettingsModel.getProperty("/Opportunities");
			const aManualIOs = oSettingsModel.getProperty("/to_MANUAL");
			let oOpportunity = null;
			let oManualIO = null;
			this.IOStaffing = null;
			let sInternalOrder = "";
			let isOpportunity = true;
			let isValid = false;
			if (this.CostTypeId === "1" || this.CostTypeId === 1 || this.CostTypeId === "3" || this.CostTypeId === 3) {
				if (this.CostTypeId === "1" || this.CostTypeId === 1) {
					oOpportunity = aOpportunities.find(function (item) {
						return item.OpportunityID === that.CostTypeValue;
					});
					if (oOpportunity && oOpportunity.IOSetting === "Yes" && oOpportunity.AssociatedIO && oOpportunity.AssociatedIO !== "") {
						sInternalOrder = oOpportunity.AssociatedIO;
					} else {
						return true;
					}
				} else if ((this.CostTypeId === "3" || this.CostTypeId === 3) && this.CostTypeValue && this.CostTypeValue !== "") {
					oManualIO = aManualIOs.find(function (item) {
						return item.ManualIOID === that.CostTypeValue;
					});
					if (oManualIO) {
						sInternalOrder = this.CostTypeValue;
					}
					isOpportunity = false;
				}
				const aAssociatedIOData = aStaffingRecord.filter(function (item) {
					return sInternalOrder !== "" && item.InternalOrder === sInternalOrder;
				});
				if (aAssociatedIOData) {
					const oMTRTask = oSettingsModel.getProperty("/MTRTasks").find(function (item) {
						return item.TaskId.toString() === that.TaskId.toString();
					});

					const aTaskTypes = [];
					const aTaskLevels = [];
					let oCurrentStaffing, sRecordDate, dRecordDate, dEndDate, dStartDate;
					const aStaffingData = [];
					let remainingDays;
					const sDateFormat = oSettingsModel.getProperty("/DateFormat");

					const oDateFormat = oSettingsModel.getProperty("/DateFormats").find(function (d) {
						return d.ID === sDateFormat;
					});
					if (aAssociatedIOData && oMTRTask) {
						aAssociatedIOData.sort(function (a, b) {
							const dT1 = that.dateServicesInstance.formatStringDate(a.EndDate);
							const dT2 = that.dateServicesInstance.formatStringDate(b.EndDate);
							return dT2 > dT1 ? -1 : 1;
						});
						for (let i = 0; i < aAssociatedIOData.length; i++) {

							remainingDays = (parseFloat(aAssociatedIOData[i].StaffedDays) - parseFloat(aAssociatedIOData[i].RecordedDays)) + " " +
								"Days Left";

							aStaffingData.push({
								Staffing: "Staffing " + (i + 1),
								ID: (isOpportunity) ? oOpportunity.OpportunityID : oManualIO.ManualIOID,
								Name: (isOpportunity) ? oOpportunity.OpportunityName : oManualIO.ManualIODesc,
								Owner: (isOpportunity) ? oOpportunity.OwnerName : "",
								AccountID: (isOpportunity) ? oOpportunity.AccountID : "",
								AccountName: (isOpportunity) ? oOpportunity.AccountName : "",
								InternalOrder: sInternalOrder,
								StaffedDays: aAssociatedIOData[i].StaffedDays,
								StartDate: this.dateServicesInstance.formatStringDate(aAssociatedIOData[i].StartDate, oDateFormat.Value),
								EndDate: this.dateServicesInstance.formatStringDate(aAssociatedIOData[i].EndDate, oDateFormat.Value),
								TaskType: aAssociatedIOData[i].TaskType,
								TaskLevel: aAssociatedIOData[i].TaskLevel,
								IsOpportunity: isOpportunity,
								RemainingDays: remainingDays,
								Analytics: [{
									"Staffing": oResourceBundle.getText("recordedDays"),
									"Days": parseFloat(aAssociatedIOData[i].RecordedDays)
								}, {
									"Staffing": oResourceBundle.getText("remainingDays"),
									"Days": parseFloat(aAssociatedIOData[i].StaffedDays) - parseFloat(aAssociatedIOData[i].RecordedDays)
								}]
							});
						}
						this.IOStaffingList = aStaffingData;
						for (let i = 0; i < aAssociatedIOData.length; i++) {

							remainingDays = (parseFloat(aAssociatedIOData[i].StaffedDays) - parseFloat(aAssociatedIOData[i].RecordedDays)) + " " +
								oResourceBundle.getText("dayRemaining");

							var oTaskType = aTaskTypes.find(function (item) {
								return item === aAssociatedIOData[i].TaskType;
							});
							if (!oTaskType) {
								aTaskTypes.push(aAssociatedIOData[i].TaskType);
							}
							var oTaskLevel = aTaskLevels.find(function (item) {
								return item === aAssociatedIOData[i].TaskLevel;
							});
							if (!oTaskLevel) {
								aTaskLevels.push(aAssociatedIOData[i].TaskLevel);
							}
							dStartDate = this.dateServicesInstance.formatStringDate(aAssociatedIOData[i].StartDate);
							dEndDate = this.dateServicesInstance.formatStringDate(aAssociatedIOData[i].EndDate);
							sRecordDate = this.RecordDate;
							if (!sRecordDate) {
								sRecordDate = this.StartDate;
							}

							dRecordDate = this.dateServicesInstance.formatStringDate(sRecordDate);
							if (dStartDate && dEndDate && dStartDate <= dRecordDate && dEndDate >= dRecordDate) {
								if (aAssociatedIOData[i].TaskLevel === oMTRTask.TaskLevel &&
									aAssociatedIOData[i].TaskType === oMTRTask.IspTask) {
									oCurrentStaffing = aAssociatedIOData[i];
									break;
								} else if (aAssociatedIOData[i].TaskType === "") {
									oCurrentStaffing = aAssociatedIOData[i];
									break;
								}

							} else {
								if (aAssociatedIOData[i].TaskLevel === oMTRTask.TaskLevel &&
									aAssociatedIOData[i].TaskType === oMTRTask.IspTask) {
									oCurrentStaffing = aAssociatedIOData[i];

								}
								if (!oCurrentStaffing && aAssociatedIOData[i].TaskType === "") {
									oCurrentStaffing = aAssociatedIOData[i];

								}
							}

						}
					}

					if (oCurrentStaffing) {
						sRecordDate = this.RecordDate;
						if (!sRecordDate) {
							sRecordDate = this.StartDate;
						}
						dRecordDate = this.dateServicesInstance.formatStringDate(sRecordDate);
						dStartDate = this.dateServicesInstance.formatStringDate(oCurrentStaffing.StartDate);

						dEndDate = this.dateServicesInstance.formatStringDate(oCurrentStaffing.EndDate);
						remainingDays = (parseFloat(oCurrentStaffing.StaffedDays) - parseFloat(oCurrentStaffing.RecordedDays)) + " " +
							"Days Left";
						if (dEndDate && dEndDate < dRecordDate || dStartDate > dRecordDate) {
							remainingDays = "Staffing Expired";
						}
						if ((dStartDate && dEndDate && dStartDate <= dRecordDate && dEndDate >= dRecordDate) || remainingDays === "Staffing Expired") {

							var oIOStaffing = {
								Staffing: "Staffing",
								ID: (isOpportunity) ? oOpportunity.OpportunityID : oManualIO.ManualIOID,
								Name: (isOpportunity) ? oOpportunity.OpportunityName : oManualIO.ManualIODesc,
								Owner: (isOpportunity) ? oOpportunity.OwnerName : "",
								AccountID: (isOpportunity) ? oOpportunity.AccountID : "",
								AccountName: (isOpportunity) ? oOpportunity.AccountName : "",
								InternalOrder: sInternalOrder,
								StaffedDays: oCurrentStaffing.StaffedDays,
								StartDate: this.dateServicesInstance.formatStringDate(oCurrentStaffing.StartDate, oDateFormat.Value),
								EndDate: this.dateServicesInstance.formatStringDate(oCurrentStaffing.EndDate, oDateFormat.Value),
								TaskType: oCurrentStaffing.TaskType,
								TaskLevel: oCurrentStaffing.TaskLevel,
								IsOpportunity: isOpportunity,
								RemainingDays: remainingDays,
								Analytics: [{
									"Staffing": "Recorded Days",
									"Days": parseFloat(oCurrentStaffing.RecordedDays)
								}, {
									"Staffing": "Remaining Days",
									"Days": parseFloat(oCurrentStaffing.StaffedDays) - parseFloat(oCurrentStaffing.RecordedDays)
								}]
							};
							this.IOStaffing = oIOStaffing;

						}
						isValid = true;
					}
				}
			}

			return isValid;
		},

		_validateISX: function (openPopover) {
			let isValid = false;
			const that = this;
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			let oMessage, sDescription;
			this.IOStaffing = null;
			const aOpportunities = oSettingsModel.getProperty("/Opportunities");
			const oOpportunity = aOpportunities.find(function (item) {
				return item.OpportunityID === that.CostTypeValue;
			});
			let guid = "";
			if (oOpportunity && oOpportunity.REPLACED_BY) {
				var isRepOpp = aOpportunities.find(function (item) {
					return item.OpportunityID === oOpportunity.REPLACED_BY;
				});
			}
			if (oOpportunity && oOpportunity.IOSetting === "Yes") {
				if (!oOpportunity.AssociatedIO || oOpportunity.AssociatedIO === "") {
					sDescription = "INFO SECTION	\n\nSelected Opportunity " + this.CostTypeValue +
						" is not associated with any IO as of today. Hence, you will not be able to Submit time for the same. \n\nThis could be due to any of the below reasons: \n\n1. IO has not been created for Opportunity so far. \n\n2. You have not been staffed with the associated IO. \n\nRESOLUTION\n\nPlease submit a ticket for resolution, you can save the entry for now."
						// sDescription = oResourceBundle.getText("blankIOMsgDesc", [this.CostTypeValue]);
					oMessage = new Message({
						Type: sap.ui.core.MessageType.Error,
						Title: "IO not associated with Opportunity",
						Description: sDescription,
						Subtitle: ""
					});

					if (this.GUID) {
						guid = this.GUID;
						this.setCostTypeValueState(sap.ui.core.ValueState.Error);
						this.CostTypeValueStateText = "IO not associated with Opportunity";
					} else {
						guid = this.MtrUid;
					}
					let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
					let statusId = (this.hasOwnProperty("StatusId")) ? this.StatusId : "";
					oMessage.addToMessages(guid, activityId, statusId);
					isValid = false;
				} else if (oOpportunity.AssociatedIO && oOpportunity.AssociatedIO !== "" && (!oOpportunity.StaffedDays || oOpportunity.StaffedDays ===
						"")) {
					sDescription = "INFO SECTION \n\nSelected Opportunity " + this.CostTypeValue +
						" is associated with an IO , but you are not staffed on the IO. Hence, you will not be able to Submit time for the same. \n\nThis could be due below reasons:\n1. You are not staffed on the associated IO. \n\nRESOLUTION \n\nPlease submit a ticket for resolution, you can save the entry for now."
						// sDescription = oResourceBundle.getText("userNotStaffedMsgDesc", [this.CostTypeValue]);
					oMessage = new Message({
						Type: sap.ui.core.MessageType.Error,
						Title: "User is not staffed on the IO",
						Description: sDescription,
						Subtitle: ""
					});
					if (this.GUID) {
						guid = this.GUID;
						this.setCostTypeValueState(sap.ui.core.ValueState.Error);
						this.CostTypeValueStateText = "User is not staffed on the IO";
					} else {
						guid = this.MtrUid;
					}
					let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
					let statusId = (this.hasOwnProperty("StatusId")) ? this.StatusId : "";
					oMessage.addToMessages(guid, activityId, statusId);
					isValid = false;
				} else if (oOpportunity && oOpportunity.isAllowed === false) {
					if (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && isRepOpp) {
						sDescription = "INFO SECTION \n\n You cannot book time against this Opportunity " + this.CostTypeValue +
							" as this is in Discontinued/Booked/Lost/Won status for > 90 days. \n\nRESOLUTION \n\n This Discontinued opportunity has a parallel opportunity, please book your time to the new opportunity created (" +
							oOpportunity.REPLACED_BY + "). The same is available in the Opp List."
					} else if (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && !isRepOpp) {
						sDescription = "INFO SECTION \n\n You cannot book time against this Opportunity " + this.CostTypeValue +
							" as this is in Discontinued/Booked/Lost/Won status for > 90 days. \n\nRESOLUTION \n\n This Discontinued opportunity has a parallel opportunity (" +
							oOpportunity.REPLACED_BY +
							"). \n Please reach out to Opportunity owner for staffing (if you are not already) on the 'Sales Team' of this opportunity(" +
							oOpportunity.REPLACED_BY + ")."
					} else {
						sDescription = "INFO SECTION \n\n You cannot book time against this Opportunity " + this.CostTypeValue +
							" as this is in Discontinued/Booked/Lost/Won status for > 90 days. \n\nRESOLUTION \n\n Please contact the opportunity owner to identify an alternate opportunity.";
					}
					/*sDescription = (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && isRepOpp) ? oResourceBundle.getText("gracePerWithRepBy", [this.CostTypeValue, oOpportunity.REPLACED_BY]) : 
					(oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && !isRepOpp) ? oResourceBundle.getText("gracePerWithRep", [this.CostTypeValue, oOpportunity.REPLACED_BY]) : 
					oResourceBundle.getText("noGracePerDesc", [this.CostTypeValue]);*/
					oMessage = new Message({
						Type: sap.ui.core.MessageType.Error,
						Title: "Time Recording not allowed for selected Opportunity.",
						Description: sDescription,
						Subtitle: ""
					});

					if (this.GUID) {
						guid = this.GUID;
						this.setCostTypeValueState(sap.ui.core.ValueState.Error);
						this.CostTypeValueStateText = "Time Recording not allowed for selected Opportunity.";
					} else {
						guid = this.MtrUid;
					}
					let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
					let statusId = (this.hasOwnProperty("StatusId")) ? this.StatusId : "";
					oMessage.addToMessages(guid, activityId, statusId);
					isValid = false;
				} else if (oOpportunity && oOpportunity.isAllowedStat === false) {

					if (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && isRepOpp) {
						sDescription = "INFO SECTION \n\n You cannot book time against this Opportunity " + this.CostTypeValue +
							" as this is in Discontinued status for > 90 days. \n\nRESOLUTION \n\n This Discontinued opportunity has a parallel opportunity, please book your time to the new opportunity created (" +
							oOpportunity.REPLACED_BY + "). The same is available in the Opp List."
					} else if (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && !isRepOpp) {
						sDescription = "INFO SECTION \n\n You cannot book time against this Opportunity " + this.CostTypeValue +
							" as this is in Discontinued/Booked/Lost/Won status for > 90 days. \n\nRESOLUTION \n\n This Discontinued opportunity has a parallel opportunity (" +
							oOpportunity.REPLACED_BY +
							"). \n Please reach out to Opportunity owner for staffing (if you are not already) on the 'Sales Team' of this opportunity(" +
							oOpportunity.REPLACED_BY + ")."
					} else {
						sDescription = "INFO SECTION \n\n You cannot book time against this Opportunity " + this.CostTypeValue +
							" as this is in Discontinued status for > 90 days. \n\nRESOLUTION \n\n Please contact the opportunity owner to identify an alternate opportunity."
					}

					/*sDescription = (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && isRepOpp) ? oResourceBundle.getText(
						"gracePerStatWithRepBy", [
							this.CostTypeValue, oOpportunity.REPLACED_BY
						]) : (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && !isRepOpp) ? oResourceBundle.getText(
						"gracePerStatWithRep", [
							this.CostTypeValue, oOpportunity.REPLACED_BY
						]) : oResourceBundle.getText("noGracePerStatDesc", [this.CostTypeValue]);*/
					oMessage = new Message({
						Type: sap.ui.core.MessageType.Error,
						Title: "noGracePerStatDesc",
						Description: sDescription,
						Subtitle: ""
					});

					if (this.GUID) {
						guid = this.GUID;
						this.setCostTypeValueState(sap.ui.core.ValueState.Error);
						this.CostTypeValueStateText = "noGracePerStatDesc";
					} else {
						guid = this.MtrUid;
					}
					let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
					let statusId = (this.hasOwnProperty("StatusId")) ? this.StatusId : "";
					oMessage.addToMessages(guid, activityId, statusId);
					isValid = false;
				} else {
					isValid = true;
				}
			} else if (oOpportunity && oOpportunity.IOSetting === "Error") {

				sDescription = "INFO SECTION \nThere appears to be an incomplete or missing quote/products on this opportunity " + this.CostTypeValue +
					", which is required to validate IO generation requirements.  \n\nRESOLUTION \n\nPlease contact the opportunity owner to resolve the issue..";
				oMessage = new Message({
					Type: sap.ui.core.MessageType.Error,
					Title: "Product missing for the Opportunity",
					Description: sDescription,
					Subtitle: ""
				});

				if (this.GUID) {
					guid = this.GUID;
					this.setCostTypeValueState(sap.ui.core.ValueState.Error);
					this.CostTypeValueStateText = "Product missing for the Opportunity";
				} else {
					guid = this.MtrUid;
				}
				let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
				let statusId = (this.hasOwnProperty("StatusId")) ? this.StatusId : "";
				oMessage.addToMessages(guid, activityId, statusId);
				isValid = false;

			} else if (oOpportunity && oOpportunity.IOSetting === "") {
				sDescription = "INFO SECTION \n You do not have access to Opportunity " + this.CostTypeValue +
					".  \n\nRESOLUTION \n\nPlease contact the opportunity owner or submit a ticket.";
				oMessage = new Message({
					Type: sap.ui.core.MessageType.Error,
					Title: "No Access to Opporunities.",
					Description: sDescription,
					Subtitle: ""
				});

				if (this.GUID) {
					guid = this.GUID;
					this.setCostTypeValueState(sap.ui.core.ValueState.Error);
					this.CostTypeValueStateText = "No Access to Opporunities.";
				} else {
					guid = this.MtrUid;
				}
				let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
				let statusId = (this.hasOwnProperty("StatusId")) ? this.StatusId : "";
				oMessage.addToMessages(guid, activityId, statusId);
				isValid = false;
			} else if (oOpportunity && oOpportunity.isAllowed === false) {

				if (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && isRepOpp) {
					sDescription = "INFO SECTION \n\n You cannot book time against this Opportunity " + this.CostTypeValue +
						" as this is in Discontinued/Booked/Lost/Won status for > 90 days. \n\nRESOLUTION \n\n This Discontinued opportunity has a parallel opportunity, please book your time to the new opportunity created (" +
						oOpportunity.REPLACED_BY + "). The same is available in the Opp List."
				} else if (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && !isRepOpp) {
					sDescription = "INFO SECTION \n\n You cannot book time against this Opportunity " + this.CostTypeValue +
						" as this is in Discontinued/Booked/Lost/Won status for > 90 days. \n\nRESOLUTION \n\n This Discontinued opportunity has a parallel opportunity (" +
						oOpportunity.REPLACED_BY +
						"). \n Please reach out to Opportunity owner for staffing (if you are not already) on the 'Sales Team' of this opportunity(" +
						oOpportunity.REPLACED_BY + ")."
				} else {
					sDescription = "INFO SECTION \n\n You cannot book time against this Opportunity " + this.CostTypeValue +
						" as this is in Discontinued/Booked/Lost/Won status for > 90 days. \n\nRESOLUTION \n\n Please contact the opportunity owner to identify an alternate opportunity."
				}

				/*sDescription = (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && isRepOpp) ? oResourceBundle.getText(
					"gracePerWithRepBy", [
						this.CostTypeValue, oOpportunity.REPLACED_BY
					]) : (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && !isRepOpp) ? oResourceBundle.getText("gracePerWithRep", [
					this.CostTypeValue, oOpportunity.REPLACED_BY
				]) : oResourceBundle.getText("noGracePerDesc", [this.CostTypeValue]);*/
				oMessage = new Message({
					Type: sap.ui.core.MessageType.Error,
					Title: "Time Recording not allowed for selected Opportunity.",
					Description: sDescription,
					Subtitle: ""
				});

				if (this.GUID) {
					guid = this.GUID;
					this.setCostTypeValueState(sap.ui.core.ValueState.Error);
					this.CostTypeValueStateText = "Time Recording not allowed for selected Opportunity.";
				} else {
					guid = this.MtrUid;
				}
				let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
				let statusId = (this.hasOwnProperty("StatusId")) ? this.StatusId : "";
				oMessage.addToMessages(guid, activityId, statusId);
				isValid = false;
			} else if (oOpportunity && oOpportunity.isAllowedStat === false) {

				if (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && isRepOpp) {
					sDescription = "INFO SECTION \n\n You cannot book time against this Opportunity " + this.CostTypeValue +
						" as this is in Discontinued status for > 90 days. \n\nRESOLUTION \n\n This Discontinued opportunity has a parallel opportunity, please book your time to the new opportunity created (" +
						oOpportunity.REPLACED_BY + "). The same is available in the Opp List."
				} else if (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && !isRepOpp) {
					sDescription = "INFO SECTION \n\n You cannot book time against this Opportunity " + this.CostTypeValue +
						" as this is in Discontinued/Booked/Lost/Won status for > 90 days. \n\nRESOLUTION \n\n This Discontinued opportunity has a parallel opportunity (" +
						oOpportunity.REPLACED_BY +
						"). \n Please reach out to Opportunity owner for staffing (if you are not already) on the 'Sales Team' of this opportunity(" +
						oOpportunity.REPLACED_BY + ")."
				} else {
					sDescription = "INFO SECTION \n\n You cannot book time against this Opportunity " + this.CostTypeValue +
						" as this is in Discontinued status for > 90 days. \n\nRESOLUTION \n\n Please contact the opportunity owner to identify an alternate opportunity."
				}

				/*sDescription = (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && isRepOpp) ? oResourceBundle.getText(
					"gracePerStatWithRepBy", [
						this.CostTypeValue, oOpportunity.REPLACED_BY
					]) : (oOpportunity.REPLACED_BY && oOpportunity.StatusKey === "E0002" && !isRepOpp) ? oResourceBundle.getText(
					"gracePerStatWithRep", [
						this.CostTypeValue, oOpportunity.REPLACED_BY
					]) : oResourceBundle.getText("noGracePerStatDesc", [this.CostTypeValue]);*/
				oMessage = new Message({
					Type: sap.ui.core.MessageType.Error,
					Title: "noGracePerStatDesc",
					Description: sDescription,
					Subtitle: ""
				});

				if (this.GUID) {
					guid = this.GUID;
					this.setCostTypeValueState(sap.ui.core.ValueState.Error);
					this.CostTypeValueStateText = "noGracePerStatDesc";
				} else {
					guid = this.MtrUid;
				}
				let activityId = (this.hasOwnProperty("ActvtId")) ? this.ActvtId : "";
				let statusId = (this.hasOwnProperty("StatusId")) ? this.StatusId : "";
				oMessage.addToMessages(guid, activityId, statusId);
				isValid = false;
			}
			if (((this.CostTypeId === "1" || this.CostTypeId === 1) && oOpportunity && oOpportunity.IOSetting === "Yes") ||
				this.CostTypeId === "3" || this.CostTypeId === 3) {
				isValid = isValid && this.getIOStaffing();
			}

			return isValid;
		}

	});
	return BaseEntry;
});