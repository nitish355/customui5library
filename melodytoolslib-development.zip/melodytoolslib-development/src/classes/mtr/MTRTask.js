sap.ui.define([
	"com/melody/lib/classes/BaseObject",
	"com/melody/lib/classes/MTRCostType",
	"com/melody/lib/classes/MTRLocation"
], function (BaseObject, MTRCostType, MTRLocation) {
	"use strict";
	var MTRTask = BaseObject.extend("com.melody.lib.classes.mtr.MTRTask", {
		constructor: function (oData) {
			BaseObject.call(this);
			this.setData(oData);
			this.CostTypes = [];
			this.Locations = [];
		},

		setData: function (oData) {
			if(oData) {
				this.TaskId = (oData.TaskId) ? oData.TaskId : "";
				this.TaskName = (oData.TaskName) ? oData.TaskName : "";
				
				this.TaskShortName = oData.TaskShortName;
				this.TaskDescription = oData.TaskDescription;
				this.IspSubTaskDes = oData.IspSubTaskDes;
				this.IsCostCentre = oData.IsCostCentre;
				this.IsOpportunity = oData.IsOpportunity;
				this.IsManualIo = oData.IsManualIo;
				this.IsAccount = oData.IsAccount;
				this.IsPlaceholder = oData.IsPlaceholder;
				this.CategoryId = oData.CategoryId.toString();
				this.IsRemote = oData.IsRemote;
				this.IspTask = oData.IspTask;
				this.IspTaskdes = oData.IspTaskdes;
				this.IspSubTask = oData.IspSubTask;
				this.EssInMu = (oData.EssInMu && oData.EssInMu === "X") ? true : false;
				this.TaskLevel = oData.TaskLevel;
				this.TaskCompHours = oData.TaskCompHours;
				this.TaskCompDays = oData.TaskCompDays;
				this.IsArchive = oData.IsArchive;
			}
		},
		
		setCostTypes: function(costTypes) {
			const aCostTypes = [];
			for(let i = 0; i < costTypes.length; i++) {
				const oCostType = new MTRCostType({
					CostTypeID: costTypes[i].CostTypeID,
					CostTypeName: costTypes[i].CostTypeName
				});
				aCostTypes.push(oCostType);
			}
			
			this.CostTypes = aCostTypes;
		},
		
		setLocations: function(locations) {
			const aLocations = [];
			for(let i = 0; i < locations.length; i++) {
				const oLocation = new MTRLocation({
					LocationId: locations[i].LocationId,
					LocationName: locations[i].LocationName
				});
				aLocations.push(oLocation);
			}
			
			this.Locations = aLocations;
		}
	});
	return MTRTask;
});