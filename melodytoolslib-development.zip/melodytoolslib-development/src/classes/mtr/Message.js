sap.ui.define([
	"com/melody/lib/classes/BaseObject",
	"com/melody/lib/util/mtr/MTRModels",
	"sap/m/MessageToast"
], function (BaseObject, MTRModels, MessageToast) {
	"use strict";
	/* @type sap.ui.base.Object */
	return BaseObject.extend("com.melody.lib.classes.mtr.Message", {
		constructor: function (oData) {
			BaseObject.call(this);
			this.setData(oData);
		},
		setData: function (oData) {
			if (oData) {
				this.Type = (oData.Type) ? oData.Type : "";
				this.Title = (oData.Title) ? oData.Title : "";
				this.Description = (oData.Description) ? oData.Description : "";
				this.Subtitle = (oData.Subtitle) ? oData.Subtitle : "";
			} else {
				this.Type = "";
				this.Title = "";
				this.Description = "";
				this.Subtitle = "";
			}
		},
		addToMessages: function (mtrUid, activityId, statusId) {
			var oMessageModel = MTRModels.getMessagesModel();
			let sStatusId = "";
			if (statusId) {
				sStatusId = statusId;
			} else if (!statusId && this.Type === sap.ui.core.MessageType.Error) {
				sStatusId = "3";
			}

			var oMessage = {
				type: this.Type,
				title: this.Title,
				subtitle: this.Subtitle,
				description: this.Description,
				mtrUid: mtrUid,
				activityId: activityId,
				statusId: sStatusId,
				bLink: (sStatusId) ? true : false
			};
			if (oMessage.title || (oMessage.activityId && oMessage.title)) {
				oMessageModel.getData().unshift(oMessage);
				oMessageModel.refresh(true);
			}

			/*if(this.Type === sap.ui.core.MessageType.Error) {
				MessageToast.show(this.Title);
			}*/
		}
	});
});