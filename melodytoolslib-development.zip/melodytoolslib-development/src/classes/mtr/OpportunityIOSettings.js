sap.ui.define([
	"com/melody/lib/classes/BaseObject",
	"com/melody/lib/util/mtr/MTRModels"
	], function(BaseObject, MTRModels) {
		"use strict";
		/* @type sap.ui.base.Object */
		return BaseObject.extend("com.melody.lib.classes.mtr.OpportunityIOSettings", {
			constructor: function(oData) {
				BaseObject.call(this);
				// set setOpportunityIOData method's properties to constructor
				this.setOpportunityIOData(oData);
			},
			
			getStaffing: function(sTaskType, sTaskLevel) {
				var that = this;
				var IOStaffing = null;
				var aAssociatedIOData = this.AvailableIOs.find(function(item) {
					return item.InternalOrder === that.AssociatedIO;
				});
				for(var i = 0; i < aAssociatedIOData.Staffings.length; i++) {
					if(aAssociatedIOData.Staffings[i].TaskLevel === sTaskLevel && 
						aAssociatedIOData.Staffings[i].TaskType === sTaskType) {
							IOStaffing = aAssociatedIOData.Staffings[i];
						}
				}
				return IOStaffing;
			},
			
			setOpportunityIOData: function(oData) {
				const oSettingsModel = MTRModels.getMTRSettingsModel();
				var sUpdateIOArtes = oSettingsModel.getProperty("/UpdateIOArtes");
				this.OpportunityID = (oData.OpportunityID) ? oData.OpportunityID.toString() : "";
				this.OpportunityName = (oData.OpportunityName) ? oData.OpportunityName : "";
				this.OwnerName = (oData.OwnerName) ? oData.OwnerName : "";
				this.AccountID = (oData.AccountID) ? oData.AccountID : "";
				this.AccountName = (oData.AccountName) ? oData.AccountName : "";
				if(oData.IOSetting && oData.IOSetting !== "") {
					this.IOSetting = oData.IOSetting;
				} else if(sUpdateIOArtes === "2") {
					this.IOSetting = "No";
				} else {
					this.IOSetting = "";
				}
				this.AssociatedIO = (oData.AssociatedIO) ? oData.AssociatedIO : "";
				this.AvailableIOs = (oData.AvailableIOs) ? oData.AvailableIOs : [];
				this.StaffedDays = (oData.StaffedDays) ? oData.StaffedDays : "";
				this.RecordedDays = (oData.RecordedDays) ? oData.RecordedDays : "";
				this.StatusKey = (oData.StatusKey) ? oData.StatusKey : "";
				this.Status = (oData.Status) ? oData.Status : "";
				this.IsVisible = (oData.IsVisible && (oData.IsVisible === "X" || oData.IsVisible === true)) ? true : false;
				this.IsDefault = (oData.IsDefault && (oData.IsDefault === "X" || oData.IsDefault === true)) ? true : false;
				this.CreatedOn = (oData.CreatedOn) ? oData.CreatedOn : "";
				this.CreatedTime = (oData.CreatedTime) ? oData.CreatedTime : "";
				this.UpdatedOn = (oData.UpdatedOn) ? oData.UpdatedOn : "";
				this.UpdatedTime = (oData.UpdatedTime) ? oData.UpdatedTime : "";
				this.IsArchive = (oData.IsArchive) ? true : false;
				this.LicenseRevenue = (oData.LicenseRevenue) ? oData.LicenseRevenue : "";
				this.CloudRevenue = (oData.CloudRevenue) ? oData.CloudRevenue : "";
				this.SalesOrg = (oData.SalesOrg) ? oData.SalesOrg : "";
				this.DataFrom = (oData.DataFrom) ? oData.DataFrom : "";
				this.Indicator = (oData.Indicator) ? oData.Indicator : "";
				this.StatusSince = (oData.StatusSince) ? oData.StatusSince : "";
			},
			
			validate: function () {
				const oSettingsModel = MTRModels.getMTRSettingsModel();
				var sUpdateIOArtes = oSettingsModel.getProperty("/UpdateIOArtes");
				if(sUpdateIOArtes === "1" && this.AssociatedIO !== "") {
					return {
						isValid: false,
						msg: "No IO associated with the opportunity"
					};
				} else {
					return {
						isValid: true
					};
				}
			},
			
			getLSRequest: function (mParameters) {
				return {
					UserGuid: mParameters.UserGuid,
					AccountId: this.AccountID,
					AssociatedIo: this.AssociatedIO,
					IsDefault: (this.IsDefault) ? "X" : "",
					IsVisible: (this.IsVisible) ? "X" : "",
					OpportunityId: this.OpportunityID,
					IsArchive: (this.IsArchive) ? "X" : ""
				};
			}
		});
	});