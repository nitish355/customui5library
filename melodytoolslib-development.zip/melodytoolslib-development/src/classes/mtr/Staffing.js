sap.ui.define([
	"sap/ui/base/Object",
], function (Object) {
	"use strict";
	var Staffing = Object.extend("com.melody.lib.classes.mtr.Staffing", {
		constructor: function (oData) {
			if(oData) {
				this.setData(oData);
			}
		},
		setData: function (oData) {
			this.InternalOrder = oData.Objnr_f.replace(/^0+/, "");
			this.Description = oData.Objnr_info;
			this.StaffedDays = oData.Zexpdays;
			this.RecordedDays = oData.Pdays;
			this.TaskLevel = oData.Tasklevel;
			this.TaskType = oData.Tasktype;
			this.StartDate = oData.Begda;
			this.EndDate = oData.Endda;
			this.Objnr = oData.Objnr;
			this.Obart = oData.Obart;
			this.Raufnr = oData.Raufnr;
			this.IsOpportunityIO = false;
		},
		setStaffing: function (oData) {
			this.InternalOrder = oData.InternalOrder;
			this.Description = oData.Description;
			this.StaffedDays = oData.StaffedDays;
			this.RecordedDays = oData.RecordedDays;
			this.TaskLevel = oData.TaskLevel;
			this.TaskType = oData.TaskType;
			this.StartDate = oData.StartDate;
			this.EndDate = oData.EndDate;
			this.IsOpportunityIO = oData.IsOpportunityIO;
		}
	});
	
	return Staffing;
});