sap.ui.define([
	"sap/ui/base/Object",
	"com/melody/lib/classes/mtr/MTRAccount",
	"com/melody/lib/util/mtr/MTRModels",
	"com/melody/lib/classes/mtr/ManualIO",
	"sap/ui/Device"
	// "com/melody/lib/model/Application"
], function (Object, MTRAccount, MTRModels, ManualIO, Device) {
	"use strict";
	/**
	 * Constructor for a Settings class.
	 *
	 * @class
	 * Settings class stores User Settings information
	 * @extends com.melody.lib.model.Object
	 *
	 * @public
	 * @alias com.melody.lib.model.Settings
	 */
	var Settings = Object.extend("com.melody.lib.classes.mtr.Settings", {

		/** 
		 * constructor of Settings class
		 */
		constructor: function () {
			this.Loading = true;
			this.SizeLimit = 500;
			// BaseObject.call(this);
			// ORE Data
			this.UserId = "";
			this.MatrixViewAccess = "";
			this.PersonalNumber = "";
			this.UserName = "";
			this.CompanyCode = "";
			this.CostCenter = "";
			this.BelongEss = "";
			this.Headcount = "";
			this.HeadcountId = "";
			this.MuId = "";
			this.MuName = "";
			this.ORERole = "";
			this.OreFlag = "";
			this.OrgFlag = "";
			this.RegionId = "";
			this.RegionName = "";
			this.Specialization = "";
			this.SubRegionName = "";
			this.UpdateIOArtes = "";
			this.UpdateIoArtesValue = "";
			this.ActivityRecording = "0";
			// ISP Data
			this.WeekStartDay = 1;
			this.FirstWeekendDay = 6;
			this.SecondWeekendDay = 0;
			// this.setTimeMatrics("H");

			// LS Data
			this.UserGuid = "";
			this.FirstName = "";
			this.LastName = "";
			this.Email = "";
			this.Status = "";
			this.Application = "MTR";
			this.PartnerId = "";
			this.DateFormat = "";
			this.DisplayDateFormat = "";
			this.EssInMu = true;
			if (!Device.system.desktop) {
				this.Timesheet = "1";
			} else {
				this.Timesheet = "";
			}
			this.CustId = "";
			this.CreatedOn = "";
			this.CreatedTime = "";
			this.UpdatedOn = "";
			this.UpdatedTime = "";
			this.IsArchive = "";
			this.Opportunities = [];
			this.TempOpportunities = [];
			this.AvailableManualIOs = [];
			this.to_MANUAL = [];
			this.to_ACCOUNT = [];
			this.LSOpportunities = []; // Temp Array

			// Local Flags
			this.IsFirstTimeUser = true;
			this.isOREDataCaptured = false;

			this.ProfileId = "";

			this.IsISPDown = false;
			this.RouteName = "";

			this.PilotFlag = "";

			this.IsUnitEdit = false;

			this.UserNotifEssInMu = true;

			this.UserActivities = [];
			this.IsDisontinuedOppSubmit = false;
		},

		setFirstTimeUserSettings: function (bValue) {
			this.IsFirstTimeUser = bValue;
			if (this.BelongEss === "1") {
				this.EssInMu = false;
			} else {
				this.EssInMu = true;
			}
		},

		setTimeMatrics: function (sValue) {
			this.TimeMatrics = sValue;
			if (sValue === "H") {
				const oTargetModel = sap.ui.getCore().getModel("target");
				const aTargetHours = oTargetModel.getProperty("/TargetHours");
				const oTargetHour = aTargetHours.find(function (item) {
					return item.Datetype === "WORK";
				});
				if (oTargetHour) {
					this.StdWorkDuration = oTargetHour.Targethours.toString();
				} else {
					this.StdWorkDuration = "8";
				}
			} else {
				this.StdWorkDuration = "1";
			}
		},

		/** 
		 * This function sets data
		 * @module Settings
		 * @public
		 * @param {object} oData - Settings data
		 */
		setData: function (oData) {
			this.StartDayWeek = oData.StartDayWeek;
			this.setTimeMatrics(oData.TimeMatrics);
			this.Opportunities = oData.Opportunities;
			this.TempOpportunities = oData.TempOpportunities;
			this.LSOpportunities = oData.LSOpportunities;
			this.AvailableManualIOs = oData.AvailableManualIOs;
			this.IsFirstTimeUser = oData.IsFirstTimeUser;
			this.EssInMu = oData.EssInMu;
			this.isOREDataCaptured = oData.isOREDataCaptured;
			this.UserId = oData.UserId;
			this.UserGuid = oData.UserGuid;
			this.UserName = oData.UserName;
			this.IsUnitEdit = oData.IsUnitEdit;
			this.OreFlag = oData.OreFlag;
			this.OrgFlag = oData.OrgFlag;
			this.ActivityRecording = oData.ActivityRecording;
			this.ORERole = oData.ORERole;
			this.UpdateIoArtes = oData.UpdateIoArtes;
			this.UpdateIoArtesValue = oData.UpdateIoArtesValue;
			this.CompanyCode = oData.CompanyCode;
			this.CostCenter = oData.CostCenter;
			this.BelongEss = oData.BelongEss;
			this.Headcount = oData.Headcount;
			this.HeadcountId = oData.HeadcountId;
			this.MuId = oData.MuId;
			this.MuName = oData.MuName;
			this.RegionId = oData.RegionId;
			this.RegionName = oData.RegionName;
			this.SubRegionName = oData.SubRegionName;
			this.Specialization = oData.Specialization;
			this.UpdatedTime = oData.UpdatedTime;
			this.IsArchive = oData.IsArchive;
			this.PartnerId = oData.PartnerId;
			this.DateFormat = oData.DateFormat;
			this.EssInMu = oData.EssInMu;
			/*if (this.BelongEss === "1" && this.IsFirstTimeUser) {
				this.EssInMu = false;
			} else {
				this.EssInMu = oData.EssInMu;
			}*/
			if (!Device.system.desktop) {
				this.Timesheet = "1";
			} else {
				this.Timesheet = oData.Timesheet.toString();
			}
			this.CustId = oData.CustId;
			this.CreatedOn = oData.CreatedOn;
			this.CreatedTime = oData.CreatedTime;
			this.UpdatedOn = oData.UpdatedOn;
			this.to_MANUAL = this.setManualIOs(oData.to_MANUAL);
			this.to_ACCOUNT = this.setAccounts(oData.to_ACCOUNT);
			this.ProfileId = oData.ProfileId;
			//this.setFirstTimeUserSettings(oData.IsFirstTimeUser);
		},

		/** 
		 * This function sets data coming from ORE
		 * @public
		 * @module Settings
		 * @param oData
		 */
		setOREUserDetails: function (oData) {
			this.UserId = oData.UserId;
			this.PersonalNumber = oData.PersonalNumber;
			this.UserName = oData.UserName;
			this.OreFlag = oData.OreFlag;
			this.OrgFlag = oData.OrgFlag;
			this.ORERole = oData.ORERole;
			this.ActivityRecording = oData.ActivityRecording;
			this.UpdateIOArtes = oData.UpdateIOArtes;
			this.UpdateIoArtesValue = oData.UpdateIoArtesValue;
			this.CompanyCode = oData.CompanyCode;
			this.CostCenter = oData.CostCenter;
			this.BelongEss = oData.BelongEss;
			this.Headcount = oData.Headcount;
			this.HeadcountId = oData.HeadcountId;
			this.MuId = oData.MuId;
			this.MuName = oData.MuName;
			this.RegionId = oData.RegionId;
			this.RegionName = oData.RegionName;
			this.SubRegionName = oData.SubRegionName;
			this.Specialization = oData.Specialization;
		},

		/** 
		 * This function sets data coming from LS
		 * @public
		 * @module Settings
		 * @param {object} oData
		 */
		setLSUserData: function (oData) {
			try {
				this.UpdatedTime = oData.UpdatedTime;
				this.IsArchive = oData.IsArchive;
				this.PartnerId = oData.PartnerId;
				this.DateFormat = oData.DateFormat;
				this.MatrixViewAccess = oData.MatrixViewAccess;
				const oDateFormat = this.DateFormats.find(function (d) {
					return d.ID === oData.DateFormat;
				});
				this.DisplayDateFormat = (oDateFormat) ? oDateFormat.Value.replace(/D/g, "d") : "MMM dd, y";
				this.EssInMu = oData.EssInMu;
				if (!Device.system.desktop) {
					this.Timesheet = "1";
				} else {
					this.Timesheet = oData.Timesheet.toString();
				}
				this.CustId = oData.CustId;
				this.CreatedOn = oData.CreatedOn;
				this.CreatedTime = oData.CreatedTime;
				this.UpdatedOn = oData.UpdatedOn;
				this.to_MANUAL = this.setManualIOs(oData.to_MANUAL);
				this.to_ACCOUNT = this.setAccounts(oData.to_ACCOUNT);
				this.setFirstTimeUserSettings(false);
			} catch (ex) {
				this.setFirstTimeUserSettings(true);
			}
		},

		/** 
		 * This function returns LS Service request object
		 * @public
		 * @module Settings
		 * @returns {object} LS Service LS Request
		 */
		getLSRequest: function () {
			return {
				PrdProfMapId: this.ProfileId.toString(),
				UserGuid: this.UserGuid,
				PartnerId: this.PartnerId,
				DateFormat: this.DateFormat,
				EssInMu: (this.EssInMu) ? "X" : "",
				TimeSheetUnit: this.TimeMatrics,
				TimeSheet: this.Timesheet.toString(),
				CustId: this.CustId,
				N_UserSettingToManualIO: this.getManualIOLSRequest(),
				N_UserSettingToAccount: this.getAccountLSRequest(),
				N_UserSettingToOpportunityIO: this.getOpportunityLSRequest()
			};
		},

		/** 
		 * This function returns Manual IOs request object
		 * @public
		 * @module Settings
		 * @returns {object} LS service Manual IOs request
		 */
		getManualIOLSRequest: function () {
			var manualIos = [];
			for (var i = 0; i < this.to_MANUAL.length; i++) {
				if (this.to_MANUAL[i].Indicator !== "") {
					manualIos.unshift(this.to_MANUAL[i].getLSRequest({
						UserGuid: this.UserGuid,
						PrdProfMapId: this.ProfileId.toString()
					}));
				}
			}
			return manualIos;
		},

		/** 
		 * This function returns Accounts request object
		 * @public
		 * @module Settings
		 * @returns {object} LS service Accounts request
		 */
		getAccountLSRequest: function () {
			var accounts = [];
			for (var i = 0; i < this.to_ACCOUNT.length; i++) {
				if (this.to_ACCOUNT[i].Indicator === "O") {
					continue;
				} else if (this.to_ACCOUNT[i].Indicator !== "") {
					accounts.push(this.to_ACCOUNT[i].getLSRequest({
						UserGuid: this.UserGuid
					}));
				}
			}
			return accounts;
		},

		/** 
		 * This function returns Opportunity & IO LS Request object
		 * @public
		 * @module Settings
		 * @returns {object} LS service Opportunity & IO request
		 */
		getOpportunityLSRequest: function () {
			var opportunities = [];
			for (var i = 0; i < this.Opportunities.length; i++) {
				if (!this.Opportunities[i].IsError) {
					opportunities.push(this.Opportunities[i].getLSRequest({
						UserGuid: this.UserGuid
					}));
				}

			}
			return opportunities;
		},

		/** 
		 * This function sets the Manual IOs in Settings object
		 * @public
		 * @module Settings
		 * @param {object} oData
		 * @param {string} sDataFrom
		 * @returns {Array.<com.melody.lib.model.ls.ManualIO>}
		 */
		setManualIOs: function (oData, sDataFrom) {
			var manualIOs = [];
			if (oData) {
				for (var i = 0; i < oData.length; i++) {
					var io = new ManualIO(oData[i]);
					io.DataFrom = (io.DataFrom) ? io.DataFrom : sDataFrom;
					manualIOs.unshift(io);
				}
				return manualIOs;
			} else return [];
		},

		/** 
		 * This function sets the Manual Accounts in Settings object
		 * @public
		 * @module Settings
		 * @param {object} oData
		 * @param {string} sDataFrom
		 * @returns {Array.<com.melody.lib.model.ls.Account>}
		 */
		setAccounts: function (oData, sDataFrom) {
			var accounts = [];
			if (oData) {
				for (var i = 0; i < oData.length; i++) {
					var account = new MTRAccount(oData[i]);
					account.DataFrom = (account.DataFrom) ? account.DataFrom : sDataFrom;
					accounts.push(account);
				}
				return accounts;
			} else return [];
		}
	});

	Settings.prototype.resetValidation = function () {
		this.ManualIOIDValState = "None";
		this.ManualIODesValState = "None";
		this.AccountIDValState = "None";
		this.AccountNameValState = "None";
	};

	Settings.prototype.setEditable = function (value) {
		this.editable = value;
	};

	Settings.prototype.getEditable = function () {
		return this.editable;
	};

	return Settings;
});