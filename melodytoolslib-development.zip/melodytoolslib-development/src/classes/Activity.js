sap.ui.define([
	"com/melody/lib/classes/BaseObject",
	"com/melody/lib/service/OpportunityService",
], function (BaseObject, OpportunityService) {
	"use strict";
	var Activity = BaseObject.extend("com.melody.lib.classes.Activity", {
		constructor: function (oData) {
			BaseObject.call(this);
			this.MtrTasks = [];
			this.setData(oData);
		},

		setData: function (oData) {
			this.ActivityId = (oData && oData.ActivityId && oData.ActivityId !== "") ? (parseInt(oData.ActivityId, 10)).toString() : "";
			this.ActivityTypeId = (oData && oData.ActivityTypeId) ? oData.ActivityTypeId : "";
			this.ActTypeDesc = (oData && oData.ActTypeDesc) ? oData.ActTypeDesc : "";
			//this.ActivityTypeInfo = (oData && oData.ActivityTypeInfo) ? oData.ActivityTypeInfo : "";
			this.ActAsstId = (oData && oData.ActAsstId) ? oData.ActAsstId : "";
			//this.CostTypeValue = (oData && oData.CostTypeValue) ? oData.CostTypeValue : "";
			this.Requestor = (oData && oData.Requestor) ? oData.Requestor : "";
			this.RequestorName = (oData && oData.RequestorName) ? oData.RequestorName : "";
			this.ActivityLead = (oData && oData.ActivityLead) ? oData.ActivityLead : "";
			this.ActLeadName = (oData && oData.ActLeadName) ? oData.ActLeadName : "";
			this.ActStatusDesc = (oData && oData.ActStatusDesc) ? oData.ActStatusDesc : "";
			this.RoleMpngID = (oData && oData.RoleMpngID) ? oData.RoleMpngID : "";
			this.ParentRoleId = (oData && oData.ParentRoleId) ? oData.ParentRoleId : "";
			this.ProjectType = (oData && oData.ProjectType) ? oData.ProjectType : "";
			//new mtr dialog changes
			this.CreateDate = (oData && oData.CreateDate) ? oData.CreateDate : null;
			this.StartDate = (oData && oData.StartDate) ? oData.StartDate : null;
			this.EndDate = (oData && oData.EndDate) ? oData.EndDate : null;
			this.ActStatus = (oData && oData.ActStatus) ? oData.ActStatus : "";
			this.AccountId = (oData && oData.GlobalUltimateID) ? oData.GlobalUltimateID : "";
			this.OpportunityId = (oData && oData.OpportunityId) ? oData.OpportunityId : "";
			this.AccountName = (oData && oData.AccountName) ? oData.AccountName : "";
			this.OpportunityName = (oData && oData.OpportunityName) ? oData.OpportunityName : "";
			this.IsSlLead = (oData && oData.IsSlLead) ? oData.IsSlLead : "";
			this.IsOnlyRequestor = (oData && oData.IsOnlyRequestor) ? oData.IsOnlyRequestor : "";
			this.ActSetRegion = (oData && oData.ActSetRegion) ? oData.ActSetRegion : "";
			this.ActSetSubRegion = (oData && oData.ActSetSubRegion) ? oData.ActSetSubRegion : "";
			this.ActivitySetName = (oData && oData.ActivitySetName) ? oData.ActivitySetName : "";
			this.Archived = (oData && oData.Archived) ? oData.Archived : "";
			if (oData) {
				this.ActivitySetStatus = oData.ActivitySetStatus;
			}

			this.setCostTypeValue(oData);
			// this.setOppAccntNames(oData);
		},

		setCostTypeValue: function (oData) {
			if (oData) {
				if (oData.CostTypeValue && oData.CostTypeValue !== "") {
					this.CostTypeName = oData.CostTypeName;
					this.CostTypeValue = oData.CostTypeValue;
				} else if (oData.ActAsstId.toString() === "501") {
					this.CostTypeName = "Account";
					this.CostTypeValue = oData.GlobalUltimateID;
				} else if (oData.ActAsstId.toString() === "502") {
					this.CostTypeName = "Opportunity";
					this.CostTypeValue = oData.OpportunityId;
				} else if (oData.ActAsstId.toString() === "503") {
					this.CostTypeName = "Cost Center";
					this.CostTypeValue = "";
				} else {
					this.CostTypeName = "";
					this.CostTypeValue = "";
				}
			} else {
				this.CostTypeValue = "";
			}
		},

		/*	setOppAccntNames: function (oData) {
				var that = this;
				if (oData.ActAsstId === "501") {
					this.OpportunityName = "Not Applicable";
					if (this.AccountId) {
						// AccountService.getZSBupaInfoSet(this.AccountId)
						OpportunityService.getBusinessPartnerAttribSet(this.AccountId).then(function (oResponse) {
							if (oResponse && oResponse.data) {
								// that.AccountName = oResponse[0].AccountName;
								that.AccountName = oResponse.data.PARTNER_NAME;
							} else {
								that.AccountName = "Not Applicable";
							}
						});
					} else {
						this.AccountName = "Not Applicable";
					}
				} else if (oData.ActAsstId === "502") {
					const oMtrSettingsModel = sap.ui.getCore().getModel("mtrSettings");
					const aOpportunities = oMtrSettingsModel.getProperty("/Opportunities")
					aOpportunities.filter(function (item) {
						if (item.OpportunityID === that.OpportunityId) {
							that.OpportunityName = item.OpportunityName;
							that.AccountName = item.AccountName;
						}
					});
				} else {
					this.AccountName = "Not Applicable";
					this.OpportunityName = "Not Applicable";
				}

			}*/
	});
	return Activity;
});