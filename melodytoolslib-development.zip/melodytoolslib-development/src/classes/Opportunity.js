sap.ui.define([
	"com/melody/lib/classes/BaseObject"
], function (BaseObject) {
	"use strict";
	var Opportunity = BaseObject.extend("com.melody.lib.classes.Opportunity", {
		constructor: function (oData) {
			BaseObject.call(this);
			this.setData(oData);
		},

		setData: function (oData) {
			this.AccountId = (oData && oData.AccountId) ? oData.AccountId : "";
			this.AccountName = (oData && oData.AccountName) ? oData.AccountName : "";
			this.OpportunityId = (oData && oData.OpportunityId) ? oData.OpportunityId : "";
			this.OpportunityName = (oData && oData.OpportunityName) ? oData.OpportunityName : "";
		}
	});
	return Opportunity;
});