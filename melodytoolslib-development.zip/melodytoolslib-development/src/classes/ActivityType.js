sap.ui.define([
	"com/melody/lib/classes/BaseObject"
], function (BaseObject) {
	"use strict";
	var ActivityType = BaseObject.extend("com.melody.lib.classes.ActivityType", {
		constructor: function (oData) {
			BaseObject.call(this);
			this.setData(oData);
		},

		setData: function (oData) {
			this.ActivityTypeId = (oData && oData.ActivityTypeId) ? oData.ActivityTypeId : "";
			this.ActivityTypeName = (oData && oData.ActivityTypeName) ? oData.ActivityTypeName : "";
		}
	});
	return ActivityType;
});