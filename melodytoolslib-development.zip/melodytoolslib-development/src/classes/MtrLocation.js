sap.ui.define([
	"com/melody/lib/classes/BaseObject"
], function (BaseObject) {
	"use strict";
	var MtrLocation = BaseObject.extend("com.melody.lib.classes.MtrLocation", {
		constructor: function (oData) {
			BaseObject.call(this);
			this.setData(oData);
		},

		setData: function (oData) {
			this.LocationId = (oData && oData.LocationId) ? oData.LocationId : "";
			this.LocationName = (oData && oData.LocationName) ? oData.LocationName : "";
		}
	});
	return MtrLocation;
});