sap.ui.define([
	"com/melody/lib/classes/BaseObject",
	"com/melody/lib/classes/MtrCostType",
	"com/melody/lib/classes/MtrLocation"
], function (BaseObject, MtrCostType, MtrLocation) {
	"use strict";
	var MtrTask = BaseObject.extend("com.melody.lib.classes.MtrTask", {
		constructor: function (oData) {
			BaseObject.call(this);
			this.setData(oData);
			this.MtrCostTypes = [];
			this.MtrLocations = [];
		},

		setData: function (oData) {
			this.MtrTaskID = (oData && oData.MtrTaskID) ? oData.MtrTaskID : "";
			this.MtrTaskName = (oData && oData.MtrTaskName) ? oData.MtrTaskName : "";
		},
		
		setCostTypes: function(aCostTypes) {
			const aMtrCostTypes = [];
			for(let i = 0; i < aCostTypes.length; i++) {
				const oMtrCostType = new MtrCostType({
					CostTypeID: aCostTypes[i].CostTypeID,
					CostTypeName: aCostTypes[i].CostTypeName
				});
				aMtrCostTypes.push(oMtrCostType);
			}
			
			this.MtrCostTypes = aMtrCostTypes;
		},
		
		setLocations: function(aLocations) {
			const aMtrLocations = [];
			for(let i = 0; i < aLocations.length; i++) {
				const oMtrLocation = new MtrLocation({
					LocationId: aLocations[i].LocationId,
					LocationName: aLocations[i].LocationName
				});
				aMtrLocations.push(oMtrLocation);
			}
			
			this.MtrLocations = aMtrLocations;
		}
	});
	return MtrTask;
});