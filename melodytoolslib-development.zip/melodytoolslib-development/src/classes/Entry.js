sap.ui.define([
	"com/melody/lib/classes/BaseObject"
], function (BaseObject) {
	"use strict";
	var Entry = BaseObject.extend("com.melody.lib.classes.Entry", {
		constructor: function (sPersonalNumber, oData) {
			BaseObject.call(this);
			
			this.genericDateFormat = sap.ui.core.format.DateFormat.getInstance({
				pattern: "yMMdd",
				calendarType: sap.ui.core.CalendarType.Gregorian
			});
			
			this.uniqueIdTimeStamp = sap.ui.core.format.DateFormat.getInstance({
				pattern: "mmss",
				calendarType: sap.ui.core.CalendarType.Gregorian
			});
			this.MtrUid = (oData && oData.MtrUid) ? oData.MtrUid.toUpperCase() : this.generateGUID(sPersonalNumber).toUpperCase();
			this.setData(oData);
			this.IsEdit = false;
		},

		setData: function (oData) {
			//this.RecordDate = (oData && oData.RecordDate) ? oData.RecordDate : this.genericDateFormat.format(new Date());
			if(oData && oData.RecordDate) {
				this.setRecordDate(oData.RecordDate);
			} else {
				this.setRecordDate();
			}
			
			this.MtrTaskID = (oData && oData.MtrTaskID) ? oData.MtrTaskID : "";
			this.MtrTaskName = (oData && oData.MtrTaskName) ? oData.MtrTaskName : "";
			this.LocationId = (oData && oData.LocationId) ? oData.LocationId : "";
			this.CostTypeId = (oData && oData.CostTypeId) ? oData.CostTypeId : "";
			this.CostTypeValue = (oData && oData.CostTypeValue) ? oData.CostTypeValue : "";
			this.WorkDuration = (oData && oData.WorkDuration) ? oData.WorkDuration : "0";
			this.Unit = (oData && oData.Unit) ? oData.Unit : "H";
			this.Note = (oData && oData.Note) ? oData.Note : "";
			this.ActvtId = (oData && oData.ActvtId && oData.ActvtId !== "") ? (parseInt(oData.ActvtId, 10)).toString() : "";
			this.ActivityTypeName = (oData && oData.ActivityTypeName) ? oData.ActivityTypeName : "";
			this.MtrLocations = (oData && oData.MtrLocations && oData.MtrLocations.length > 0) ? oData.MtrLocations : []; 
			this.MtrTasks = (oData && oData.MtrTasks && oData.MtrTasks.length > 0) ? oData.MtrTasks : [];
			this.StatusId = (oData && oData.StatusId) ? oData.StatusId.toString() : "";
			this.MsgText = (oData && oData.MsgText) ? oData.MsgText : "";
			this.ProjectType = (oData && oData.ProjectType) ? oData.ProjectType : "";
			this.CreatedOn = (oData && oData.CreatedOn) ? oData.CreatedOn : new Date();
		},
		
		setRecordDate: function(sRecordDate) {
			this.RecordDate = (sRecordDate) ? sRecordDate : this.genericDateFormat.format(new Date());
			this.Date = (sRecordDate) ? new Date(sRecordDate.substring(0, 4) + "/" + sRecordDate.substring(4, 6) + "/" + sRecordDate.substring(6, 8)) : new Date();
		},
		
		getLSRequest: function (mParameters) {
			return {
				UserGuid: mParameters.UserGuid,
				MtrUid: this.MtrUid,
				IspGuid: "",
				RecordDate: this.RecordDate,
				StatusId: 1,
				ActivityId: parseInt(this.MtrTaskID, 10),
				ProjectType: (this.ProjectType) ? this.ProjectType : "",
				LocationId: (this.LocationId) ? parseInt(this.LocationId, 10) : 0,
				CostTypeId: parseInt(this.CostTypeId, 10),
				CostTypeValue: this.CostTypeValue,
				WorkDuration: (this.WorkDuration) ? parseFloat(this.WorkDuration).toFixed(1) : "0",
				Unit: this.Unit,
				Note: this.Note,
				PrdProfMapId: mParameters.ProfileId.toString(),
				Timestamp: "",
				Errmsg: "",
				IsArchive: "",
				ActvtId: this.ActvtId,
				Indicator: (mParameters.Indicator) ? mParameters.Indicator : ""
			};
		},
		
		generateGUID: function (sPersonalNumber) {
			return sPersonalNumber + this.uniqueIdTimeStamp.format(new Date()) + Math.floor(100 + Math.random() *
				900) + "MTR";
		}
	});
	return Entry;
});