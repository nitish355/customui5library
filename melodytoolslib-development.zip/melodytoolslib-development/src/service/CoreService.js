sap.ui.define(
	[
		"sap/ui/base/Object",
		"com/melody/lib/enum/ODataUrl",
		"sap/ui/model/json/JSONModel",
	],
	function (UI5Object, ODataUrl, JSONModel) {
		"use strict";

		//Static Initialize global cache if it does not already exist
		if (!globalThis.SharedCache) {
			globalThis.SharedCache = {};
		}

		return UI5Object.extend("com.melody.lib.service.CoreService", {
			constructor: function () {
				this._setModels();
				this.apiRequestCache = globalThis.SharedCache;
			},
			setModel: function (model) {
				this.model = model;
			},

			_setModels: function () {
				this.models = [];

				const services = {};
				// const libraryPath = jQuery.sap.getModulePath("com/melody/lib");
				const libraryPath = ".";

				for (let i = 0; i < ODataUrl.DataSources.length; i++) {
					let sODataURL = `${libraryPath}${ODataUrl.DataSources[i].url}`;
					// let sODataURL = `${ODataUrl.DataSources[i].url}`;
					const oModel = new sap.ui.model.odata.v2.ODataModel({
						useBatch: ODataUrl.DataSources[i].useBatch,
						serviceUrl: sODataURL,
						defaultOperationMode: "Client",
						defaultBindingMode: "TwoWay",
						defaultCountMode: "None",
					});

					let oTempModel =
						sap.ui.getCore().getModel(ODataUrl.DataSources[i].name) || false;
					if (!oTempModel) {
						sap.ui.getCore().setModel(oModel, ODataUrl.DataSources[i].name);
						this.models[ODataUrl.DataSources[i].name] = oModel;
					} else {
						this.models[ODataUrl.DataSources[i].name] = oTempModel;
					}

					services[
						ODataUrl.DataSources[i].name.toUpperCase() + "_SERVICE_DOWN"
					] = false;
				}

				const oServiceModel = new JSONModel(services);
				sap.ui.getCore().setModel(oServiceModel, "services");
			},

			odata: function (url) {
				var me = this;
				var core = {
					ajax: async function (type, url, data, modelName, parameters) {
						// const duplicateCheck = ["YC_UT_AUTH_CHECK", "YC_USER_MASTER"]
						let urlKey = url;
						//Check if api ref exists in apicache and return
						if (
							!data &&
							globalThis.SharedCache &&
							Object.keys(globalThis.SharedCache).length
						) {
							if (parameters) {
								urlKey = `${urlKey}${JSON.stringify(parameters)}`;
							}
							if (globalThis.SharedCache[urlKey]) {
								return globalThis.SharedCache[urlKey];
							}
						}
						var promise = new Promise(function (resolve, reject) {
							var args = [];
							var params = {};
							args.push(url);
							if (data) {
								args.push(data);
							}
							if (parameters) {
								params = parameters;
								urlKey = `${urlKey}${JSON.stringify(parameters)}`;
							}
							params.success = function (result, response) {
								resolve({
									data: result,
									response: response,
								});
								//Delete the urlKey from apiCache
								if (globalThis.SharedCache && globalThis.SharedCache[urlKey]) {
									delete globalThis.SharedCache[urlKey];
								}
							};
							params.error = function (error) {
								reject(error);
							};
							args.push(params);
							me.models[modelName][type].apply(me.models[modelName], args);
						});

						const oServiceModel = sap.ui.getCore().getModel("services");
						try {
							await me.models[modelName].metadataLoaded(true);
							oServiceModel.getProperty(
								"/" + modelName.toUpperCase() + "_SERVICE_DOWN",
								false
							);
						} catch (e) {
							oServiceModel.getProperty(
								"/" + modelName.toUpperCase() + "_SERVICE_DOWN",
								true
							);
							throw new Error(modelName + " - METADATA_NOT_LOADED");
						}
						globalThis.SharedCache[urlKey] = promise;
						return promise;
					},
					batch: async function (batches, groupId, modelName) {
						var promise = new Promise(function (resolve, reject) {
							if (batches && batches.length > 0) {
								me.models[modelName].setDeferredGroups([groupId]);
								for (let i = 0; i < batches.length; i++) {
									const args = [];
									let batchParams = {};

									if (batches[i].url) {
										args.push(batches[i].url);
									}

									if (batches[i].data) {
										args.push(batches[i].data);
									}
									if (batches[i].parameters) {
										batchParams = batches[i].parameters;
									}

									if (groupId) {
										batchParams.groupId = groupId;
									}
									args.push(batchParams);
									me.models[modelName][batches[i].type].apply(
										me.models[modelName],
										args
									);
								}

								let params = {};

								params.success = function (result, response) {
									resolve({
										data: result,
										response: response,
									});
								};
								params.error = function (error) {
									reject(error);
								};

								if (groupId) {
									params.groupId = groupId;
								}
								me.models[modelName].submitChanges(params);
							}
						});

						const oServiceModel = sap.ui.getCore().getModel("services");
						try {
							await me.models[modelName].metadataLoaded(true);
							oServiceModel.getProperty(
								"/" + modelName.toUpperCase() + "_SERVICE_DOWN",
								false
							);
						} catch (e) {
							oServiceModel.getProperty(
								"/" + modelName.toUpperCase() + "_SERVICE_DOWN",
								true
							);
							throw new Error(modelName + " - METADATA_NOT_LOADED");
						}
						return promise;
					},
					batchCreateEntry: async function (batches, groupId, modelName) {
						var promise = new Promise(function (resolve, reject) {
							if (batches && batches.length > 0) {
								me.models[modelName].setDeferredGroups([groupId]);
								const results = [];
								let index = 0;
								for (let i = 0; i < batches.length; i++) {
									const entry = {};

									entry.success = function (result, response) {
										index += 1;
										results.push(result);
										if (index === batches.length) {
											resolve({
												results: results,
												index: index - 1,
											});
										}
									};
									entry.error = function (error) {
										index += 1;
										results.push(error);
										if (index === batches.length) {
											resolve({
												results: results,
												index: index - 1,
											});
										}
									};

									if (batches[i].data) {
										entry.properties = batches[i].data;
									}
									entry.changeSetId = "changeset " + i;

									me.models[modelName].createEntry(url, entry);
								}

								let params = {};

								params.success = function () {};
								params.error = function (error) {};

								if (groupId) {
									params.groupId = groupId;
								}
								me.models[modelName].submitChanges(params);
							}
						});

						const oServiceModel = sap.ui.getCore().getModel("services");
						try {
							await me.models[modelName].metadataLoaded(true);
							oServiceModel.getProperty(
								"/" + modelName.toUpperCase() + "_SERVICE_DOWN",
								false
							);
						} catch (e) {
							oServiceModel.getProperty(
								"/" + modelName.toUpperCase() + "_SERVICE_DOWN",
								true
							);
							throw new Error(modelName + " - METADATA_NOT_LOADED");
						}
						return promise;
						/*me.models[modelName].metadataLoaded(true).then(() => {
					    return promise;
					},
					() => {
					    throw modelName + " - METADATA_NOT_LOADED";
					});*/
					},
				};

				return {
					get: function (modelName, params) {
						return core.ajax("read", url, false, modelName, params);
					},
					post: function (modelName, data, params) {
						return core.ajax("create", url, data, modelName, params);
					},
					put: function (modelName, data, params) {
						return core.ajax("update", url, data, modelName, params);
					},
					delete: function (modelName, params) {
						return core.ajax("remove", url, false, modelName, params);
					},
					batch: function (modelName, batches, groupId) {
						return core.batch(batches, groupId, modelName);
					},
					batchCreateEntry: function (modelName, batches, groupId) {
						return core.batchCreateEntry(batches, groupId, modelName);
					},
				};
			},
			http: function (url) {
				var core = {
					ajax: function (method, url, headers, args, mimetype) {
						var promise = new Promise(function (resolve, reject) {
							var client = new XMLHttpRequest();
							var uri = url;
							if (args && method === "GET") {
								uri += "?";
								var argcount = 0;
								for (var key in args) {
									if (args.hasOwnProperty(key)) {
										if (argcount++) {
											uri += "&";
										}
										uri +=
											encodeURIComponent(key) +
											"=" +
											encodeURIComponent(args[key]);
									}
								}
							}
							if (args && (method === "POST" || method === "PUT")) {
								var data = {};
								for (var keyp in args) {
									if (args.hasOwnProperty(keyp)) {
										data[keyp] = args[keyp];
									}
								}
							}
							client.open(method, uri);
							if (method === "POST" || method === "PUT") {
								client.setRequestHeader("accept", "application/json");
								client.setRequestHeader("content-type", "application/json");
							}
							for (var keyh in headers) {
								if (headers.hasOwnProperty(keyh)) {
									client.setRequestHeader(keyh, headers[keyh]);
								}
							}
							if (data) {
								client.send(JSON.stringify(data));
							} else {
								client.send();
							}
							client.onload = function () {
								if (this.status == 200) {
									resolve(this.response);
								} else {
									reject(this.statusText);
								}
							};
							client.onerror = function () {
								reject(this.statusText);
							};
						});
						return promise;
					},
				};

				return {
					get: function (headers, args) {
						return core.ajax("GET", url, headers, args);
					},
					post: function (headers, args) {
						return core.ajax("POST", url, headers, args);
					},
					put: function (headers, args) {
						return core.ajax("PUT", url, headers, args);
					},
					delete: function (headers, args) {
						return core.ajax("DELETE", url, headers, args);
					},
				};
			},
		});
	}
);
