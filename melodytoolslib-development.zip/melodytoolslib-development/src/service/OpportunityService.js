sap.ui.define([
	"com/melody/lib/service/CoreService",
	"sap/ui/model/Sorter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"com/melody/lib/enum/ODataUrl"
], function (CoreService, Sorter, Filter, FilterOperator, ODataUrl) {
	"use strict";

	var OpportunityService = CoreService.extend("com.melody.lib.service.OpportunityService", {
		getAppValueHelps: function () {
			const aFilters = [
				new Filter("ENTITY_NAME", FilterOperator.EQ, "Opportunity")
			];
			var mParameters = {};
			mParameters.filters = (aFilters) ? aFilters : "";
			return this.odata("/AppValueHelps").get("harmony", mParameters);
		},

		getUserDetail: function () {
			return this.odata("/Yc_Md_Logedinuser").get("opportunity");
		},

		getBusinessPartners: function (search, filters) {

			const urlParameters = {};
			if (search) {
				urlParameters.search = search;
			}

			var mParameters = {};
			mParameters.urlParameters = urlParameters;
			mParameters.filters = (filters) ? filters : "";

			return this.odata("/BusinessPartners").get("harmony", mParameters);
		},

		/*getOpportunities: function(aFilters) {
			var mParameters = {};
			mParameters.filters = (aFilters) ? aFilters : "";
			
			return this.odata("/Opportunities").get("harmony", mParameters);
		},*/

		getOpportunities: function (batches) {
			const aBatches = [];
			for (let i = 0; i < batches.length; i++) {
				const mParameters = {};
				mParameters.filters = (batches[i].Filters) ? batches[i].Filters : "";
				mParameters.urlParameters = batches[i].parameters;
				aBatches.push({
					type: "read",
					url: "/Opportunities",
					parameters: mParameters
				});
			}
			return this.odata("/Opportunities").batch("harmony", aBatches, "opportunity");
		},

		getOpportunityCount: function (batches) {
			const aBatches = [];
			let mParameters = {};
			for (let i = 0; i < batches.length; i++) {
				mParameters.filters = (batches[i].Filters) ? batches[i].Filters : "";
				const urlParam = JSON.parse(JSON.stringify(batches[i].parameters));
				["$skip", "$top", "$select"].forEach(param => delete urlParam[param]);
				if (Object.keys(urlParam).length) {
					mParameters.urlParameters = urlParam;
				}
			}
			return this.odata("/Opportunities/$count").get("harmony", mParameters);
		},


		searchOpportunities: function (sUrl, mParameters) {
			return this.odata(sUrl).get("harmony", mParameters);
		},

		fnGetOpportunitiesDetails: function (sUrl, aBatches) {
			return this.odata(sUrl).batch("harmony", aBatches, "opportunity");
		},

		getUserRecords: function () {
			return this.odata("/YC_UT_USER_RECORDS").get("utility");
		},

		getBusinessPartnerAttribSet: function (AccountId) {
			return this.odata("/BusinessPartnerAttribSet('" + AccountId + "')").get("harmony");
		},

		//TODO Rename this function
		getOpportunityTeam: function (sOpportunityId, mParameters) {
			return this.odata("/Opportunities('" + sOpportunityId + "')").get("harmony", mParameters);
		},

		getOpportunityForVAT: function (sOpportunityId, mParameters) {
			return this.odata("/Opportunities").get("harmony", mParameters);
		},

		getServiceToSaveOppVAT: function (oPayload) {
			return this.odata("/YC_UT_T_OPP_TEAM_DETAIL").post("utility", oPayload);
		},

		getServiceToPostOpportunityData: function (oPayload) {
			return this.odata("/Opportunities").post("harmony", oPayload);
		},

		getServiceToUserSearch: function (oParams) {
			return this.odata("/Yc_MD_Usersearch").get("utility", oParams);
		},

		getServiceToHandleAttachments: function (oParams) {
			return this.odata("/AttachmentURL").post("harmony", oParams)
		},

		getConstants: function () {
			return this.odata("/Yc_Mac_M_Constants").get("activity");
		},

		setDisconntiunedOpportunities: function (GUID, oPayload) {
			return this.odata("/YC_UT_USER_RECORDS(guid'" + GUID + "')").post("utility", oPayload, {
				groupId: "discntOpp"
			});
		},

		getMSLExistDataBasedOnOpp: function (aFilters) {
			var oParameters = {
				filters: aFilters
			};
			return this.odata("/YC_SL_T_OPP").get("successLine", oParameters);
		},

		validateSuccessLineAvailability: function (aFilters) {
			var oParameters = {
				filters: aFilters
			};
			return this.odata("/YC_SL_T_SL_AVAILABILITYCHECK").get("successLine", oParameters);
		},

		getNonVATOpportunityList: function (mParameters) {
			let sURL = (mParameters.hasOwnProperty("count")) ? `/Opportunities${mParameters.count}` : '/Opportunities';
			return this.odata(sURL).get("harmony", mParameters);
		},
		
		updateDisconntiunedOpportunities: function (GUID, oPayload) {
			return this.odata("/YC_UT_USER_RECORDS(guid'" + GUID + "')").put("utility", oPayload, {
				groupId: "discntOpp"
			});
		},

		getDiscOppStatusAction: function () {
			const aFilters = [
				new Filter("ProjectType", FilterOperator.EQ, "ACTVT")
			];
			var mParameters = {};
			mParameters.filters = (aFilters) ? aFilters : "";
			return this.odata("/YC_UT_M_OPP_ACTION").get("utility", mParameters);
		}

	});
	return new OpportunityService();
});