sap.ui.define([
	"com/melody/lib/service/CoreService",
	"sap/ui/model/Filter"
], function (CoreService, Filter) {
	"use strict";

	var MTRService = CoreService.extend("com.melody.lib.service.MTRService", {
		getAllActivityTaskTypes: async function () {
			const oResult = await this.odata("/YC_MTR_M_INTG_MAP").get("mtr");
			return oResult.data.results;
		},

		getActivityTaskTypes: async function (activity) {
			const aFilters = [
				new Filter("ActvtTypeID", "EQ", activity.ActivityTypeId),
				new Filter("ActvtAsstdID", "EQ", activity.ActAsstId),
				// new Filter("ParentRoleId", "EQ", activity.ParentRoleId),
				new Filter("RoleMpngID", "EQ", activity.RoleMpngID),
			];
			var mParameters = {};
			mParameters.filters = (aFilters) ? aFilters : "";
			//return this.odata("/MTR_M_INTG_MAP?$filter=(ActvtTypeID eq '" + activityId + "'").get("mtr");
			const oResult = await this.odata("/YC_MTR_M_INTG_MAP").get("mtr", mParameters);
			return oResult.data.results;
		},

		getUserMtrConfig: async function (postData) {
			const oResult = await this.odata("/YC_Get_UserGuidSet").post("mtr", postData);
			return oResult.data;
		},

		getUserGuidSettings: async function (sUserGuid, mParameters) {
			const oResult = await this.odata("/YC_TRMSETTINGS('" + sUserGuid + "')").get("mtr", mParameters);
			return oResult.data;
		},

		saveSettings: async function (settings) {
			const oResult = await this.odata("/YC_User_SettingsSet").post("mtr", settings);
			return oResult.data;
		},

		getEntries: async function (sUserGuid) {
			const aFilters = [
				new Filter("UserGuid", "EQ", sUserGuid)
			];
			var mParameters = {};
			mParameters.filters = (aFilters) ? aFilters : "";
			const oResult = await this.odata("/YC_TimeSheetEntrySet").get("mtr", mParameters);
			return oResult.data.results;
		},

		/** 
		 * This function gets entry specific lookup data like Categories, Activities, Locations, CostTypes
		 * @param {object} oController
		 * @param {function} fnCallBack
		 * @returns
		 */
		getMtrMasterData: async function (sProfileId) {
			const sProjectType = "ACTVT";
			const mParameters = {
				urlParameters: "$expand=to_Activity,to_Category,to_Location,to_CostType,to_Status,to_ActivityCostTypeMap,to_ActivityLocationMap"
			};
			const oResult = await this.odata("/YC_TRM_Lookup(project_type='" + sProjectType +
				"',product_id=1,profile_id=" + parseInt(sProfileId, 10) + ")").get("mtr", mParameters);
			return oResult.data;
		},

		saveEntries: async function (postData) {
			const oResult = await this.odata("/YC_TimesheetSet").post("mtr", postData);
			return oResult.data;
		},

		getEntryLookups: async function (iPrdMapId, mParameters) {
			const sProjectType = "ACTVT";
			let sUrl = "/YC_TRM_Lookup(project_type='" + sProjectType + "',product_id=1,profile_id=" + iPrdMapId + ")";
			const oResult = await this.odata(sUrl).get("mtr", mParameters);
			return oResult.data;
		},

		getSettingLookups: async function (mParameters) {
			const oResult = await this.odata("/YC_TRM_DOMAIN_HELP").get("mtr", mParameters);
			return oResult.data.results;
		}
	});
	return new MTRService();
});