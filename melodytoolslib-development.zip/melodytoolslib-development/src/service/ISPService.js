sap.ui.define([
	"com/melody/lib/service/CoreService"
], function (CoreService) {
	"use strict";

	var ISPService = CoreService.extend("com.melody.lib.service.ISPService", {

		//Function gets ISP User Info data, useful for entries submission in ISP
		getISPUserInfo: async function () {
			const oResult = await this.odata("/Userinfo").get("isp");
			return oResult.data.results;
		},

		getISPData: async function (sUserId, sFromDate, sToDate, oOptions, sEntity) {
			const sUrl = this.fnGetISPServiceURL(sUserId, sFromDate, sToDate, sEntity);
			const oResult = await this.odata(sUrl, oOptions).get("isp");
			return oResult.data;
		},

		fnGetISPServiceURL: function (sUserId, sFromDate, sToDate, sEntity) {
			return "/Param(Pernr='" + sUserId + "',Datefrom='" + sFromDate + "',Dateto='" + sToDate + "')/" + sEntity;
		}
	});
	return new ISPService();
});