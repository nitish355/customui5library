sap.ui.define([
	"com/melody/lib/service/CoreService",
	"sap/ui/model/Sorter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"com/melody/lib/enum/ODataUrl"
], function (CoreService, Sorter, Filter, FilterOperator, ODataUrl) {
	"use strict";

	var UserService = CoreService.extend("com.melody.lib.service.UserService", {
		getUserDetail: function () {
			return this.odata("/YC_USER_MASTER").get("utility");
		},

		getRoles: function () {
			return this.odata("/YC_UT_M_ORE_ROLE").get("utility");
		},

		getRegions: function () {
			return this.odata("/YC_UT_M_ORE_HCREGION").get("utility");
		},

		getMarketUnits: function () {
			return this.odata("/YC_UT_M_ORE_HCMU").get("utility");
		},

		submitUserOrgChart: function (data) {
			return this.odata("/YC_USER_MASTER").post("utility", data);
		},

		getExceptionUserIds: function () {
			return ["I827455", "I055583", "I832848", "I822054", "I867982", "I307839", "I327255"];
		},

		getAuthCheckForNonOreUser: function (projectType) {
			return this.odata("/YC_UT_AUTH_CHECK(ProjectType='" + projectType + "')").get("utility");
		},

		//initiatives
		getInitiativeKeys: function () {
			return this.odata("/yc_ut_t_ini_ore_key").get("utility");
		}
	});
	return new UserService();
});