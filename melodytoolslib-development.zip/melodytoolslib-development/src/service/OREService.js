sap.ui.define([
	"com/melody/lib/service/CoreService",
	"com/melody/lib/enum/ODataUrl"
], function (CoreService, ODataUrl) {
	"use strict";

	var OREService = CoreService.extend("com.melody.lib.service.OREService", {
		getUserData: function (oModel) {
			return this.odata("/YC_USER_MASTER").get("oreModel");
		},

		saveOrgChartData: function (oModel, data) {
			return this.odata("/YC_USER_MASTER").post("oreModel", data);
		},

		fnGetUserNotificationList: function (oModel, data) {
			return this.odata("/YC_UT_T_USR_NOTF_SETNG").get("oreModel");
		},

		fnSaveNotificationSettings: function (oModel, data, groupId) {
			const aBatches = [];
			for (let i = 0; i < data.length; i++) {
				aBatches.push({
					type: "create",
					data: data[i],
					url: "/YC_UT_T_USR_NOTF_SETNG"
				});
			}
			return this.odata("/YC_UT_T_USR_NOTF_SETNG").batch("oreModel", aBatches, groupId);
		},

		fnGetMelodyQuickLinks: function (oModel) {
			var mParameters = {
				urlParameters: "$expand=to_params,to_child/to_params"
			};
			return this.odata("/YC_MD_T_NAVMENU").get("oreModel", mParameters);
		},

		getTimeSheetPreference: async function (sUserId) {
			let sUrl = `/YC_UT_T_USR_NOTF_SETNG(UserID='${sUserId}',FolderId='0000000003',NotifID='9',ApplicationID='MTR',ActionID='0009')`;
			const oResult = await this.odata(sUrl).get("oreModel");
			return oResult.data;
		}
	});
	return new OREService();
});