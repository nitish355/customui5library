sap.ui.define([
    "sap/ui/model/Filter", "com/melody/lib/enum/Actions", "sap/ui/model/FilterOperator", "com/melody/lib/service/CoreService",
], function (Filter, Actions, FilterOperator, CoreService) {
    "use strict";

    var ActivityService = CoreService.extend("com.melody.lib.service.ActivityService", {
        getActivityTypes: async function () {
            var mParameters = {
                filters: [new Filter("OperationStatus", "EQ", true)]
            };
            const oResult = await this.odata("/Yc_Mac_M_Activity_Type").get("activity", mParameters);
            return oResult.data.results;
        },

        getActivityTypesForMatrix: async function (aFilters) {
            var mParameters = {
                filters: aFilters
            };
            const oResult = await this.odata("/YC_ROLE_ACTVT_FORMACCESS_USER").get("activity", mParameters);
            return oResult.data.results;
        },

        getUserActivities: async function (sActivityId, aFilters = []) {
            let aActIdFilter = [];
            if (sActivityId) {
                aActIdFilter = [new Filter("ActivityId", "EQ", sActivityId)];
            }
            if (aFilters.length) {
                aActIdFilter = aActIdFilter.concat(aFilters)
            }
            let mParameters = {
                filters: (aActIdFilter.length) ? aActIdFilter : [],
                urlParameters: {
                    $select: Actions.ActivitySet.select
                }
            };

            // FOR QA and PROD UnComment Below and comment belwo line
            // const oResult = await this.odata("/YC_MAC_T_ACTVT_SET").get("activityList");

            // FOR BR3 Uncomment Below and comment above line
            const oResult = await this.odata("/YC_MAC_T_ACTVT_SET(P_IncludeTeam='')/Set").get("activityList", mParameters);
            return oResult.data.results;
        },

        getRoleBasedActivityTypes: function (aFilters) {
            var mParameters = {
                filters: aFilters
            };
            return this.odata("/YC_ROLE_ACTVT_FORMACCESS_USER").get("activity", mParameters);
        },

        getRegionMu: async function () {
            const oResult = await this.odata("/YC_MOP_REGION_MASTER").get("activity");
            return oResult.data.results;
        },

        getUserActivityRole: async function () {
            const oResult = await this.odata("/YC_ROLE_ACTVT_FRMACSS").get("activity");
            return oResult.data.results[0];
        },

        // initiatives
        getInitiativeCategory: async function () {
            const oResult = await this.odata("/yc_mac_m_init_cat").get("activity");
            return oResult.data.results;
        },

        getActivityInitiatives: async function (aFilters) {

            var mParameters = {
                filters: aFilters
            };
            const oResult = await this.odata("/yc_mac_m_init_map").get("activity", mParameters);
            return oResult.data.results;
        },

        getUserInitiatives: async function () {
            const oResult = await this.odata("/YC_MAC_T_USER_INIT(P_IncludeTeam='')/Set").get("activityList");
            return oResult.data.results;
        },

        getCVJPhaseMasterData: async function (aFilter) {
            var mParameters = {
                filters: aFilter
            };
            const oResult = await this.odata("/YC_MAC_M_CVJ_PHASE").get("activity", mParameters);
            return oResult.data.results;
        },

        fnInitializeNewActivity: async function (payload) {
            const oResult = await this.odata("/Yc_Mac_T_Act_Main").post("activity", payload);
            return oResult.data;
        },

        fnGetActivityDetails: async function (sActivityId, urlParams) {
            var aActIdFilter = [new Filter("ActivityId", "EQ", sActivityId)];
            var mParameters = {
                filters: aActIdFilter,
                urlParameters: urlParams
            };
            const oResult = await this.odata("/Yc_Mac_T_Act_Main").get("activity", mParameters);
            return oResult.data.results[0];
        },

        fnFetchActAssociations: async function (sUrl, aFilters) {
            var mParameters = {
                filters: aFilters
            };
            const oResult = await this.odata(sUrl).get("activity", mParameters);
            return oResult.data.results;
        },

        fnGetActivitySets: async function (oModel) {
            const oResult = await this.odata("/Yc_Mac_M_Actity_Set").get("activity");
            return oResult.data.results
        },

        fnGetActivitySetIdInfo: async function (payload) {
            const oResult = await this.odata("/Yc_Mac_T_ActSetUsr").post("activity", payload);
            return oResult.data;
        },

        fnGetLayoutData: async function (aFilters) {
            var mParameters = {
                filters: aFilters
            };
            const oResult = await this.odata("/YC_MAC_M_FORM_LAYOUT").get("activity", mParameters);
            return oResult.data.results;
        },

        getActStatusMaster: async function () {
            const oResult = await this.odata("/YC_MAC_M_ACT_STATUS").get("activity");
            return oResult.data.results;
        },

        getSolutionHierarchy: async function (mParameters) {
            const oResult = await this.odata("/YC_MD_SOL_HIER").get("activity", mParameters);
            return oResult.data.results;
        },

        getLevel2MasterData: async function () {
            const oResult = await this.odata("/YC_MD_SOL_M_LEVEL2").get("activity");
            return oResult.data.results;
        },

        getLandscapes: async function () {
            const oResult = await this.odata("/YC_MAC_M_LANDSCAPES").get("activity");
            return oResult.data.results;
        },

        getSolHierarchyCount: async function () {
            const oResponse = await this.odata("/YC_MD_SOL_HIER/$count").get("activity");
            return oResponse.data;
        },

        getUserActivityDays: async function () {
            const oResult = await this.odata("/YC_MAC_M_USR_ACTDAYS_CHK").get("activity");
            return oResult.data.results;
        },

        getActMenuData: async function (aFilters) {
            var mParameters = {
                filters: aFilters,
                urlParameters: {
                    "$expand": 'to_caction'
                }
            };
            const oResult = await this.odata("/YC_SL_M_ACT_PRNT_ACTION").get("activity", mParameters);
            return oResult.data.results;
        },

        updateActivityStatus: async function (oActvt) {
            const oResult = await this.odata("/Yc_Mac_T_Act_Main(guid'" + oActvt.ActivityGuid + "')").put("activity", oActvt);
            return oResult.data;
        },

        copyRapidRegData: async function (payload) {
            const oResult = await this.odata("/YC_MAC_T_FR_DRAFT").post("activity", payload);
            return oResult.data;
        },

        getActLeadData: async function (aFilters, sQuery) {
            var mParameters = {
                filters: aFilters,
                urlParameters: {
                    search: sQuery
                }
            };
            const oResult = await this.odata("/YC_MAC_M_USER_LIST").get("activity", mParameters);
            return oResult.data.results;
        },

        getRiskButtons: async function () {
            const oResult = await this.odata("/Yc_Mac_M_Risk_Asses").get("activity");
            return oResult.data.results;
        },

        getOreUsers: async function (sQuery) {
            var mParameters = {
                urlParameters: {
                    search: sQuery
                }
            };
            const oResult = await this.odata("/Yc_MD_Usersearch").get("activity", mParameters);
            return oResult.data.results;
        },

        getConstants: async function () {
            const oResult = await this.odata("/Yc_Mac_M_Constants").get("activity");
            return oResult.data.results;
        },

        getDuplicateRegistrations: async function (aFilters) {
            let mParameters = {
                filters: aFilters
            };
            const oResult = await this.odata("/YC_MAC_T_OPP_ACC").get("activity", mParameters);
            return oResult.data.results;
        },

        addUsertoOppTeam: async function (payload) {
            const oResult = await this.odata("/Yc_Mac_T_Actteam").post("activity", payload);
            return oResult.data;
        },

        postCommentToUtilityServ: async function (payload) {
            const oResult = await this.odata("/YC_MD_COMMENTS").post("utility", payload);
            return oResult.data;
        },

        postCommentToActService: async function (payload) {
            const oResult = await this.odata("/YC_MAC_T_ACTCOMMENT").post("activity", payload);
            return oResult.data;
        },

        getActDetailAddSolution: async function (activityGUID) {
            let mParameters = {
                filters: []
            };
            const oResult = await this.odata(`/Yc_Mac_T_Act_Main(guid'${activityGUID}')/to_ASol`).get("activity", mParameters);
            return oResult;
        },
    });
    return new ActivityService();
});
