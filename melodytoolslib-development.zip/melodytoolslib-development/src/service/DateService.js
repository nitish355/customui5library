sap.ui.define([
	"sap/ui/base/Object"
], function (Object) {
	"use strict";
	/* @type sap.ui.base.Object */
	var instance;
	/* @type sap.ui.base.Object */
	var DateService = Object.extend("com.melody.lib.service.DateService", {
		constructor: function () {},
		format: function (dDate, sFormat) {
			if (!sFormat || sFormat === "") {
				sFormat = "MMM dd, y";
			}
			sFormat = sFormat.replace(/D/g, "d");
			sFormat = sFormat.replace(/Y/g, "y");
			var oFormat = sap.ui.core.format.DateFormat.getInstance({
				pattern: sFormat,
				calendarType: sap.ui.core.CalendarType.Gregorian
			});
			return oFormat.format(dDate);
		},
		formatStringDate: function (sDate, sFormat) {
			if (!sDate) {
				return "";
			}
			var dDate = new Date(sDate.substring(0, 4) + "/" + sDate.substring(4, 6) + "/" + sDate.substring(6, 8));
			if (sFormat && sFormat !== "") {
				return this.format(dDate, sFormat);
			} else {
				return dDate;
			}

		},
		getTimeStamp: function (dDate) {
			var oDateFormat = sap.ui.core.format.DateFormat.getInstance({
				pattern: "yyyyMMddHHmmss",
				calendarType: sap.ui.core.CalendarType.Gregorian
			});
			return oDateFormat.format(dDate);
		},
		dateDiff: function (dStartDate, dEndDate) {
			return Math.abs(Math.round((dEndDate - dStartDate) / (1000 * 60 * 60 * 24)));
		},

		getStartDateOfWeek: function (dt, iDateIndex) {
			var dDate = dt;
			var oSettingsModel = sap.ui.getCore().getModel("mtrSettings");
			var iWeekStartDay = (oSettingsModel) ? oSettingsModel.getProperty("/WeekStartDay") : 1;
			if (!dDate) {
				dDate = new Date();
			}

			if (iDateIndex) {
				iWeekStartDay = iDateIndex;
			}

			var day = dDate.getDay();
			iWeekStartDay = parseInt(iWeekStartDay);
			if (iWeekStartDay !== day) {
				var diff = dDate.getDate() - day + (day === 0 ? -6 : iWeekStartDay); // adjust when day is sunday
				return new Date(dDate.getFullYear(), dDate.getMonth(), diff);
			}
			return dDate;
		},
		getWeek: function (dDate) {
			var onejan = new Date(dDate.getFullYear(), 0, 1);
			return Math.ceil((((dDate - onejan) / 86400000) + onejan.getDay() + 1) / 7);
		},
		weekCount: function (year, month_number, startDayOfWeek) {
			// month_number is in the range 1..12

			// Get the first day of week week day (0: Sunday, 1: Monday, ...)
			var firstDayOfWeek = startDayOfWeek || 0;

			var firstOfMonth = new Date(year, month_number - 1, 1);
			var lastOfMonth = new Date(year, month_number, 0);
			var numberOfDaysInMonth = lastOfMonth.getDate();
			var firstWeekDay = (firstOfMonth.getDay() - firstDayOfWeek + 7) % 7;

			var used = firstWeekDay + numberOfDaysInMonth;

			return Math.ceil(used / 7);
		},
		weeksBetween: function (d1, d2) {
			return Math.round((d2 - d1) / (7 * 24 * 60 * 60 * 1000));
		},
		validateBetweenStringDate: function (fromStringDate, toStringDate, checkStringDate) {
			var checkDate = instance.formatStringDate(checkStringDate);
			var fromDate = instance.formatStringDate(fromStringDate);
			var toDate = instance.formatStringDate(toStringDate);

			if (checkDate < fromDate || checkDate > toDate) {
				return false;
			} else {
				return true;
			}
		},

		/**
		 * @author Siddharth S
		 * @function dateRangeFormat
		 * @description function to to change the date formate in date range selection (Move this code in DateService.js)
		 * @param {Date} dStartDate
		 * @param {Date} dEndDate
		 */
		dateRangeFormat: function (dStartDate, dEndDate) {
			let month = dStartDate.getMonth() + 1;
			if (month < 10) {
				month = "0" + month;
			}
			let year = dStartDate.getFullYear();
			let day = dStartDate.getDate();
			if (day < 10) {
				day = "0" + day;
			}
			let value1Date = year + "-" + month + "-" + day + "T00:00:00Z";
			value1Date = new Date(value1Date);

			let toMonth = dEndDate.getMonth() + 1;
			if (toMonth < 10) {
				toMonth = "0" + toMonth;
			}
			let toYear = dEndDate.getFullYear();
			let toDay = dEndDate.getDate();
			if (toDay < 10) {
				toDay = "0" + toDay;
			}
			let value2Date = toYear + "-" + toMonth + "-" + toDay + "T23:59:00Z";
			value2Date = new Date(value2Date);

			return {
				startDate: value1Date,
				endDate: value2Date
			};
		},

		//Function to get first and last date of the month
		getStartAndEndDateOfMonth: function (date) {
			const givenDate = new Date(date);
			const firstDate = new Date(givenDate.getFullYear(), givenDate.getMonth(), 1);
			const lastDate = new Date(givenDate.getFullYear(), givenDate.getMonth() + 1, 0);
			firstDate.setHours(0, 0, 0);
			lastDate.setHours(23, 59, 59);
			return {
				firstDate: firstDate,
				lastDate: lastDate
			};
		},
	});
	return {
		/**
		 * Method to create new instance of ODataUtility.
		 * @private
		 * @returns {sap.ui.base.Object} return new instance of ODataUtility
		 */
		getInstance: function () {
			if (!instance) {
				// create new instance of ODataUtility Object
				instance = new DateService();
			}
			return instance;
		}
	};
});