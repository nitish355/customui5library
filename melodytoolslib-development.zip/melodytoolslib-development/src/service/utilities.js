sap.ui.define([
	"sap/ui/base/Object"
], function (Object) {
	"use strict";
	/* @type sap.ui.base.Object */
	var instance;
	/* @type sap.ui.base.Object */
	var utilities = Object.extend("com.melody.lib.service.utilities", {
		constructor: function () {},
		/**
		 * Convenience method for read operation of oData Service.
		 * @private
		 * @param {object} [ocomponent] the current component object
		 * @param {string} [service] the service name
		 * @param {string} [entity] the entity path
		 * @param {sap.ui.base.Object} [options] the options to filter and expand operations in service
		 * @param {function} [fnSuccess] the function which calls on success of this function
		 * @param {function} [fnError] the function which calls on getting error of this function
		 */
		read: function (oController, service, entity, options, fnSuccess, fnError) {
			try {
				var urlParameters = {};
				if (options.expand && options.expand !== "") {
					urlParameters.$expand = options.expand;
				}
				if (options.select && options.select !== "") {
					urlParameters.$select = options.select;
				}
				if (options.search && options.search !== "") {
					urlParameters.search = options.search;
				}
				var oMainServiceModel = oController.getOwnerComponent().getModel(service);
				oMainServiceModel.read(entity, {
					urlParameters: urlParameters,
					filters: options.filters,
					success: function (oData) {
						fnSuccess(oData);
					},
					error: function (oError) {
						oController.onError(oError, fnError);
					}
				});
			} catch (ex) {
				jQuery.sap.log.error(ex);
			}

		},
		/**
		 * Convenience method for create operation of oData Service.
		 * @private
		 * @param {object} [ocomponent] the current component object
		 * @param {string} [service] the service name
		 * @param {string} [entity] the entity path
		 * @param {function} [fnSuccess] the function which calls on success of this function
		 * @param {function} [fnError] the function which calls on getting error of this function
		 */
		create: function (oController, service, entity, data, fnSuccess, fnError) {
			try {
				var oMainServiceModel = oController.getOwnerComponent().getModel(service);
				oMainServiceModel.create(entity, data, {
					success: function (oData, oResponse) {
						fnSuccess(oData, oResponse);
					},
					error: function (oError) {
						oController.onError(oError, fnError);
					}
				});
			} catch (ex) {
				jQuery.sap.log.error(ex);
			}
		},

		cloneObject: function (obj) {
			var clone = {};
			for (var i in obj) {
				if (obj[i] !== null && typeof (obj[i]) === "object")
					clone[i] = this.cloneObject(obj[i]);
				else
					clone[i] = obj[i];
			}
			return clone;
		},

		groupBy: function (array, f) {
			var groups = {};
			array.forEach(function (o) {
				var group = JSON.stringify(f(o));
				groups[group] = groups[group] || [];
				groups[group].push(o);
			});
			var keys = [];
			for (var k in groups) keys.push(k);
			return keys.map(function (group) {
				return groups[group];
			});
		},

		setBusy: function (oController, bFlag) {
			var appView = oController.getOwnerComponent().getModel("appView");
			appView.setProperty("/busy", bFlag);
			appView.refresh(true);
		},

		countDecimal: function (value) {
			if (Math.floor(value) === value) return 0;
			return value.toString().split(".")[1].length || 0;
		},

		padWithZeroes: function (number, length) {
			var myString = "" + number;
			while (myString.length < length) {
				myString = "0" + myString;
			}
			return myString;
		}
	});
	return {
		/**
		 * Method to create new instance of ODataUtility.
		 * @private
		 * @returns {sap.ui.base.Object} return new instance of ODataUtility
		 */
		getInstance: function () {
			if (!instance) {
				// create new instance of ODataUtility Object
				instance = new utilities();
			}
			return instance;
		}
	};
});