sap.ui.define([
	"com/melody/lib/service/CoreService",
	"sap/ui/model/Filter",
	"sap/ui/model/json/JSONModel"
], function (CoreService, Filter, JSONModel) {
	"use strict";

	var MTRService = CoreService.extend("com.melody.lib.service.mtr.MTRService", {
		getAllActivityTaskTypes: async function () {
			const oResult = await this.odata("/YC_MTR_M_INTG_MAP").get("mtr");
			return oResult.data.results;
		},

		getActivityTaskTypes: async function (activity) {
			const aFilters = [
				new Filter("ActvtTypeID", "EQ", activity.ActivityTypeId),
				new Filter("ActvtAsstdID", "EQ", activity.ActAsstId),
				// new Filter("ParentRoleId", "EQ", activity.ParentRoleId),
				new Filter("RoleMpngID", "EQ", activity.RoleMpngID),
			];
			var mParameters = {};
			mParameters.filters = (aFilters) ? aFilters : "";
			//return this.odata("/MTR_M_INTG_MAP?$filter=(ActvtTypeID eq '" + activityId + "'").get("mtr");
			const oResult = await this.odata("/YC_MTR_M_INTG_MAP").get("mtr", mParameters);
			return oResult.data.results;
		},

		getUserMtrConfig: async function (postData, bForceUpdate) {
			let oUserMtrConfigModel = sap.ui.getCore().getModel("userMtrConfig");
			let oUserMtrConfig;
			if (oUserMtrConfigModel && oUserMtrConfigModel.getData() && !bForceUpdate) {
				oUserMtrConfig = oUserMtrConfigModel.getData();
			} else {
				const oResult = await this.odata("/YC_Get_UserGuidSet").post("mtr", postData);
				oUserMtrConfig = oResult.data
				sap.ui.getCore().setModel(new JSONModel(oUserMtrConfig),
					"userMtrConfig");
			}

			return oUserMtrConfig;
		},

		getUserGuidSettings: async function (sUserGuid, mParameters) {
			const oResult = await this.odata("/YC_TRMSETTINGS('" + sUserGuid + "')").get("mtr", mParameters);
			return oResult.data;
		},

		saveSettings: async function (settings) {
			const oResult = await this.odata("/YC_User_SettingsSet").post("mtr", settings);
			return oResult.data;
		},

		getEntries: async function (sUserGuid) {
			const aFilters = [
				new Filter("UserGuid", "EQ", sUserGuid)
			];
			var mParameters = {};
			mParameters.filters = (aFilters) ? aFilters : "";
			const oResult = await this.odata("/YC_TimeSheetEntrySet").get("mtr", mParameters);
			return oResult.data.results;
		},

		/** 
		 * This function gets entry specific lookup data like Categories, Activities, Locations, CostTypes
		 * @param {object} oController
		 * @param {function} fnCallBack
		 * @returns
		 */
		getMtrMasterData: async function (sProfileId) {
			const sProjectType = "ACTVT";
			const mParameters = {
				urlParameters: "$expand=to_Activity,to_Category,to_Location,to_CostType,to_Status,to_ActivityCostTypeMap,to_ActivityLocationMap"
			};
			const oResult = await this.odata("/YC_TRM_Lookup(project_type='" + sProjectType +
				"',product_id=1,profile_id=" + parseInt(sProfileId, 10) + ")").get("mtr", mParameters);
			return oResult.data;
		},

		saveEntries: async function (postData) {
			const oResult = await this.odata("/YC_TimesheetSet").post("mtr", postData);
			return oResult.data;
		},

		getEntryLookups: async function (iPrdMapId, mParameters) {
			const sProjectType = "ACTVT";
			let sUrl = "/YC_TRM_Lookup(project_type='" + sProjectType + "',product_id=1,profile_id=" + iPrdMapId + ")";
			const oResult = await this.odata(sUrl).get("mtr", mParameters);
			return oResult.data;
		},

		getSettingsLookups: async function () {
			try {
				const oResult = await this.odata("/YC_TRM_DOMAIN_HELP").get("mtr");
				return oResult.data.results;
			} catch (e) {
				return [];
			}
		},

		getUserSettings: async function (userGuid) {
			try {
				const mParameters = {
					urlParameters: "$expand=to_OPPORTUNITYIO,to_MANUAL,to_ACCOUNT"
				};
				const oResult = await this.odata("/YC_TRMSETTINGS('" + userGuid + "')").get("mtr", mParameters);
				return oResult.data;
			} catch (e) {
				return null;
			}
		},

		getActStatusMasterData: async function () {
			const oResult = await this.odata("/YC_TRM_M_ACT_STATUS").get("mtr");
			return oResult.data.results;
		},

		getTimeEntryActivitites: async function (aFilters = []) {
			const mParameters = {
				filters: aFilters
			};
			const oResult = await this.odata("/yc_mtr_t_actvt").get("mtr", mParameters);
			return oResult.data.results;
		},

		getMatrixTimeEntryActivitites: async function (aFilters = [], search, skip, top, ServiceCallCount) {
			const urlParameters = {};
			const mParameters = {
				filters: aFilters
			};
			if (ServiceCallCount && ServiceCallCount !== 1) { // service call is first service call when opening dialog box, click on go in filter and restor
				urlParameters.$skip = skip;
				if (top) {
					urlParameters.$top = top.toString();
				} else {
					urlParameters.$top = "50";
				}
			}
			/*if (search) {
				urlParameters.search = search;
			}*/
			mParameters.urlParameters = urlParameters;
			const oResult = await this.odata("/yc_mtr_t_actvt").get("mtr", mParameters);
			return oResult.data.results;
		},
		saveDefaultFilter: async function (oData) {
			return this.odata("/YC_UT_EXSTNG_ACT_VARIANT").post("utility", oData);
		},
		getDefaultFilter: async function () {
			return this.odata("/YC_UT_EXSTNG_ACT_VARIANT").get("utility");
		}
	});
	return new MTRService();
});