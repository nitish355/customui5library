sap.ui.define([
	"com/melody/lib/service/CoreService"
], function (CoreService) {
	"use strict";

	var ISPService = CoreService.extend("com.melody.lib.service.mtr.ISPService", {

		getStaffing: async function(personalNumber, fromDate, toDate) {
			try {
				const sUrl = "/Param(Pernr='" + personalNumber + "',Datefrom='" + fromDate + "',Dateto='" + toDate + "')/Staffing";
				return await this.odata(sUrl).get("isp");	
			} catch (e) {
				return null;
			}
			
		},
		
		getEntriesFromISP: async function(personalNumber, fromDate, toDate) {
			const sUrl = "/Param(Pernr='" + personalNumber + "',Datefrom='" + fromDate + "',Dateto='" + toDate + "')/Activity";
			const oResult = await this.odata(sUrl).get("isp");
			
			if(oResult && oResult.data.results.length > 1) {
				return oResult.data.results;
			} else {
				return [];
			}
		},
		
		getTargetHours: async function(personalNumber, fromDate, toDate) {
			try {
				const sUrl = "/Param(Pernr='" + personalNumber + "',Datefrom='" + fromDate + "',Dateto='" + toDate + "')/Targethours";
				const oResult = await this.odata(sUrl).get("isp");
				
				if(oResult && oResult.data.results.length > 1) {
					return oResult.data.results;
				} else {
					return [];
				}	
			} catch (e) {
				return [];
			}
		},

		//Function gets ISP User Info data, useful for entries submission in ISP
		getISPUserInfo: async function () {
			try {
				const oResult = await this.odata("/Userinfo").get("isp");
				if(oResult && oResult.data.results.length > 0) {
					return oResult.data.results[0];
				} else {
					return null;
				}
			} catch (e) {
				return null;
			}
		},

		getISPData: async function (sUserId, sFromDate, sToDate, oOptions, sEntity) {
			const sUrl = this.fnGetISPServiceURL(sUserId, sFromDate, sToDate, sEntity);
			const oResult = await this.odata(sUrl, oOptions).get("isp");
			return oResult.data;
		},

		fnGetISPServiceURL: function (sUserId, sFromDate, sToDate, sEntity) {
			return "/Param(Pernr='" + sUserId + "',Datefrom='" + sFromDate + "',Dateto='" + sToDate + "')/" + sEntity;
		},
		
		submitEntries: function (batches) {
			const aBatches = [];
			for (let i = 0; i < batches.length; i++) {
				// const mParameters = {};
				// mParameters.changeSetId = "changeset " + i;
				// mParameters.filters = (batches[i].Filters) ? batches[i].Filters : "";
				// mParameters.urlParameters = batches[i].parameters;
				aBatches.push({
					type: "createEntry",
					url: "/ActivityHeader",
					data: batches[i]
					// parameters: mParameters
				});
			}
			return this.odata("/ActivityHeader").batchCreateEntry("isp", aBatches, "isp");
		},
	});
	return new ISPService();
});