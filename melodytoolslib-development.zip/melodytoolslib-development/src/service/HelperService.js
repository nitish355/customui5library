sap.ui.define([
	"sap/ui/base/Object"
], function (Object) {
	"use strict";
	/* @type sap.ui.base.Object */
	var instance;
	/* @type sap.ui.base.Object */
	var HelperService = Object.extend("com.melody.lib.service.HelperService", {
		constructor: function () {},
		cloneObject: function(obj) {
		    var clone = {};
		    for(var i in obj) {
		        if(obj[i] !== null &&  typeof(obj[i]) === "object")
		            clone[i] = this.cloneObject(obj[i]);
		        else
		            clone[i] = obj[i];
		    }
		    return clone;
		},
		
		groupBy: function ( array , f ) {
			var groups = {};
			array.forEach( function( o ) {
				var group = JSON.stringify( f(o) );
				groups[group] = groups[group] || [];
				groups[group].push( o );  
			});
			var keys = [];
			for(var k in groups) keys.push(k);
			return keys.map( function( group ) {
				return groups[group]; 
			});
		},

		countDecimal: function (value) {
		    if(Math.floor(value) === value) return 0;
		    return value.toString().split(".")[1].length || 0; 
		},
		
		isDateBetween: function(date, min, max) {
			const dFromDate = new Date(Date.UTC(min.getFullYear(), min.getMonth(), min.getDate()));
			const dToDate = new Date(Date.UTC(max.getFullYear(), max.getMonth(), max.getDate()));
			const dDate = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
			return dDate.getTime() >= dFromDate.getTime() && dDate.getTime() <= dToDate.getTime();
		},
		
		getUTC: function(date) {
			if(!date) {
				return new Date(Date.UTC());
			}
			return new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
		},
		
		format: function (dDate, sFormat) {
			if (!sFormat || sFormat === "") {
				sFormat = "yMMdd";
			}
			sFormat = sFormat.replace(/D/g, "d");
			sFormat = sFormat.replace(/Y/g, "y");
			var oFormat = sap.ui.core.format.DateFormat.getInstance({
				pattern: sFormat,
				calendarType: sap.ui.core.CalendarType.Gregorian
			});
			return oFormat.format(dDate);
		},
		
		formatStringDate: function (sDate, sFormat) {
			if (!sDate) {
				return "";
			}
			
			if(typeof sDate !== "string") {
				return sDate;
			}
			
			var dDate = new Date(sDate.substring(0, 4) + "/" + sDate.substring(4, 6) + "/" + sDate.substring(6, 8));
			if (sFormat && sFormat !== "") {
				return this.format(dDate, sFormat);
			} else {
				return dDate;
			}

		}
	});
	return {
		/**
		 * Method to create new instance of HelperService.
		 * @private
		 * @returns {sap.ui.base.Object} return new instance of HelperService
		 */
		getInstance: function () {
			if (!instance) {
				// create new instance of HelperService Object
				instance = new HelperService();
			}
			return instance;
		}
	};
});