sap.ui.define(
	["sap/ui/base/Object", "com/melody/lib/model/StorageModel"],
	function (Object, oStorageModel) {
		"use strict";
		return {
			//Function to set parent application
			setApplication: async function (options) {
				let ApplicationId = oStorageModel.getProperty("/ApplicationId");
				if (!ApplicationId) {
					oStorageModel.setProperty("/ApplicationId", options.appId);
					oStorageModel.setProperty("/bUseBatch", options.bUseBatch);
				}
				var appPath = options.appId.replaceAll(".", "/");
				var appModulePath = jQuery.sap.getModulePath(appPath);
				console.log("APPLICATION MODULE PATH LIBRARY : ", appModulePath);
				oStorageModel.refresh();

				return new Promise((resolve, reject) => {
					resolve();
				});
			},

			testFunction: function (appId) {
				console.log("WORKING CROSS LIB FUNCTION CALL");
			},
		};
	}
);
