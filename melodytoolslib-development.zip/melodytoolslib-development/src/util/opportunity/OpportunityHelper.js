sap.ui.define([
	"sap/ui/model/Filter",
	"sap/ui/core/Fragment",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"com/melody/lib/enum/Actions",
	"sap/ui/model/resource/ResourceModel",
	"com/melody/lib/service/OpportunityService",
	"com/melody/lib/classes/Opportunity/Opportunity",
	"com/melody/lib/util/opportunity/DiscontinuedOpportunity",
	"com/melody/lib/util/opportunity/OpportunityDialogController",
], function (Filter, Fragment, FilterOperator, JSONModel, Actions, ResourceModel, OpportunityService, Opportunity,
	DiscontinuedOpportunity,
	OpportunityDialogController) {
	"use strict";

	return {

		fnStaticInit: function (oParentRef) {
			//self points to the parent controller
			this.opportunityCtrl = oParentRef;
		},

		//function to open Opportunity Fragment
		onOpportunityValueHelpHandler: function () {
			let self = this;
			// let controller = OpportunityDialogController.bind(this);
			if (!self._oOpportunityDialog) {
				self._oOpportunityDialog = Fragment.load({
					id: self.getId() + "_OpportunityDialog",
					name: "com.melody.lib.fragments.OpportunityDialog",
					controller: self.DialogController
				}).then(function (oDialog) {
					oDialog.setModel(self.getModel());
					self.addDependent(oDialog);
					self.DialogController.fnLoadLangModel(oDialog);
					return oDialog;
				}.bind(self));
			}
			self._oOpportunityDialog.then(function (oDialog) {
				oDialog.open();
			});
		},

		//function to open Opportunity Fragment
		onActiveOpportunityValueHelpHandler: async function () {
			if (!this._oActOpportunityDialog) {
				let oDialog = await Fragment.load({
					id: "_ActiveOpportunityDialog",
					name: "com.melody.lib.fragments.ActiveOpportunityDialog",
					controller: this.DialogController
				});
				oDialog.setModel(this.getModel());
				this.addDependent(oDialog);
				this.DialogController.fnLoadLangModel(oDialog);
				this._oActOpportunityDialog = oDialog;
				oDialog.open();
				// return new Promise((resolve) => resolve());
			}

		},

		//function to  VAT Team handle data
		fnVATTeamOppDataHandler: async function (aPcOppoList, aActOppList) {
			let oResponse;
			let aPcOppList = aPcOppoList;
			let bProceed = true;
			let self = this;
			if (aPcOppoList && aActOppList) {
				if (aPcOppoList.length || aActOppList.length) {
					let pcOppoObj = aPcOppoList[0] || {};
					let actOppoObj = aActOppList[0] || {};
					if ((!pcOppoObj.hasOwnProperty("CHANGED_AT") && !pcOppoObj.hasOwnProperty("GUID")) ||
						(!actOppoObj.hasOwnProperty("CHANGED_AT") && !actOppoObj.hasOwnProperty("GUID"))) {
						aPcOppList = await self.getOpportunities({
							ActiveOnly: false,
							LastYearCount: 6
						});
						bProceed = false;
					}
				}
			}
			oResponse = {
				"aPcOppList": aPcOppList,
				"aActOppList": aActOppList,
				"bProceed": bProceed
			}
			return oResponse;
		},

		//function to set Active Opportunities to storage
		fnSetActiveOpportunity: async function (aPcOppList, viewName) {
			const oModel = this.opportunityCtrl.getModel();
			let opptData = [];
			let aTempData;
			let prvYear = oModel.getProperty("/previousYear");
			let nextYear = oModel.getProperty("/futureFiveYear");
			aTempData = $.extend(true, [], aPcOppList);

			//For MSL Exists Sort the Opp Data for Active Opp Data from opp data
			aTempData = this.fnSortDataBasedOnKey(aTempData, "AccountName");

			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			// let aStorageActOppList = $.extend(true, [], oStorage.get("actOpportunities"));
			let aStorageActOppList = [];

			//if Active Opp Data true, then update Active Opp data with VAT Team data for MSL Exists Functionality
			if (aStorageActOppList.length) {
				for (let i = 0; i < aStorageActOppList.length; i++) {
					let oTempActOppData = aStorageActOppList[i];
					let oTempOppdata = aTempData.find((oRow) => {
						return oRow.OPPT_ID === oTempActOppData.OPPT_ID;
					});
					oTempOppdata["SlExists"] = (oTempActOppData["SlExists"] === "X") ? oTempActOppData["SlExists"] : "";
					oTempOppdata["SlId"] = (oTempActOppData["SlId"]) ? oTempActOppData["SlId"] : "";
					oTempOppdata["SlSnro"] = (oTempActOppData["SlSnro"]) ? oTempActOppData["SlSnro"] : "";;
					oTempOppdata["bAdditionalOpp"] = (oTempActOppData["bAdditionalOpp"]) ? oTempActOppData["bAdditionalOpp"] : false;
					if (oTempActOppData.hasOwnProperty("bUIMainOppChange") && oTempActOppData.bUIMainOppChange) {
						oTempOppdata["bUIMainOppChange"] = (oTempActOppData["bUIMainOppChange"]) ? oTempActOppData["bUIMainOppChange"] : false;
					}
				}
				aStorageActOppList = this.fnSortDataBasedOnKey(aStorageActOppList, "AccountName");
				return aStorageActOppList;
			}

			if (!aStorageActOppList.length) {
				let aValidationStatus = ["E0001", "E0007"];
				$.each(aTempData, function (index, value) {
					value.ExpectedEnd = (value.ExpectedEnd) ? new Date(value.ExpectedEnd) : null;
					if (value.ExpectedEnd < prvYear || value.ExpectedEnd > nextYear || aValidationStatus.indexOf(value.Status) === -1) {
						value.active = 0; // false
					} else {
						value.active = 1; // true
					}
				});
				aTempData = this.fnSetFormatActOppData(aTempData, viewName);
				oModel.setProperty("/actOpportunities", aTempData);
			}
			return aTempData;
		},

		//function to sort data 
		fnSortDataBasedOnKey: function (aDataForSort, sKey) {
			aDataForSort.sort(function (current, next) {
				return current[sKey].trim().localeCompare(next[sKey].trim());
			});
			return aDataForSort
		},

		//function to make SLExists and bAdditionalOpp as false for actopp Data
		fnSetFormatActOppData: function (aActOppdata, sViewName) {
			if (!aActOppdata.length) {
				return [];
			}
			if (!sViewName) {
				for (let i = 0; i < aActOppdata.length; i++) {
					let oTempOppData = aActOppdata[i];
					oTempOppData.SlExists = "";
					oTempOppData.bAdditionalOpp = false;
					if (oTempOppData.hasOwnProperty("bUIMainOppChange") && oTempOppData.bUIMainOppChange) {
						oTempOppData.bUIMainOppChange = false;
					}
				}
			}
			return aActOppdata;
		},

		// //function to get Dialog with ID
		fnGetDialogUsingId: function (dialogId, contentId) {
			return sap.ui.core.Fragment.byId(dialogId, contentId);
		},

		//function to load i18n for dialogs
		fnLoadResourceBundle: function (dialog) {
			let i18nModel = new ResourceModel({
				bundleName: "com.melody.lib.messagebundle"
			});
			if (dialog) {
				dialog.setModel(i18nModel, "i18n");
			}
			this.opportunityCtrl.i18nModel = i18nModel.getResourceBundle();
		},

		//function to format and set the opportunity team data based on Opportunity Selected
		fnSetFormatOpportunityTeamData: function (aResponse) {
			if (!aResponse || !aResponse.length) {
				return [];
			}
			let aOpportunityTeamData = [];
			const oOpportunityModel = this.opportunityCtrl.getModel();
			for (let i = 0; i < aResponse.length; i++) {
				let oPartiesInvolved = aResponse[i];
				if (oPartiesInvolved.USER_ID && oPartiesInvolved.EMAIL) {
					let oTeam = {
						"ROLE": (oPartiesInvolved.ROLE) ? oPartiesInvolved.ROLE : "",
						"ROLE_DESC": (oPartiesInvolved.ROLE_DESCR) ? oPartiesInvolved.ROLE_DESCR : "",
						"ID": (oPartiesInvolved.USER_ID) ? oPartiesInvolved.USER_ID : "",
						"NAME": (oPartiesInvolved.NAME) ? oPartiesInvolved.NAME : "",
						"PhoneNumber": (oPartiesInvolved.TELEPHONE_NUMBER) ? oPartiesInvolved.TELEPHONE_NUMBER : "",
						"MobileNumber": (oPartiesInvolved.MOBILE_NUMBER) ? oPartiesInvolved.MOBILE_NUMBER : "",
						"EMAIL": (oPartiesInvolved.EMAIL) ? oPartiesInvolved.EMAIL : ""
					};
					aOpportunityTeamData.push(oTeam);
				}
				if (oPartiesInvolved.ROLE === Actions.ZOZOPA01) {
					let oAccOwner = {
						"ID": oPartiesInvolved.USER_ID,
						"NAME": oPartiesInvolved.NAME,
						"EMAIL": oPartiesInvolved.EMAIL,
						"ROLE": oPartiesInvolved.ROLE,
						"ROLE_DESC": oPartiesInvolved.ROLE_DESCR
					};
					oOpportunityModel.setProperty("/selectedOpportunityTeam/ACCOUNT_OWNER", oAccOwner);
				}
			}
			return aOpportunityTeamData;
		},

		//function to open Opportunity Fragment
		onOpportunityInformationHandler: function (oControlSource) {
			let self = this;
			// let controller = OpportunityDialogController.bind(this);
			if (!self._oOpportunityInfoDialog) {
				self._oOpportunityInfoDialog = Fragment.load({
					id: "_OpportunityInformationDialog",
					name: "com.melody.lib.fragments.OpportunityInformation",
					controller: self.DialogController
				}).then(function (oDialog) {
					oDialog.setModel(self.getModel());
					self.addDependent(oDialog);
					self.DialogController.fnLoadLangModel(oDialog);
					return oDialog;
				}.bind(self));
			}
			self._oOpportunityInfoDialog.then(function (oDialog) {
				oDialog.openBy(oControlSource);
			});
		},

	};
});