sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/Filter",
	"sap/ui/core/Fragment",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"com/melody/lib/enum/Actions",
	"sap/ui/core/format/DateFormat",
	"com/melody/lib/model/formatter",
	"com/melody/lib/model/StorageModel",
	"sap/ui/model/resource/ResourceModel",
	"com/melody/lib/classes/Opportunity/CVA",
	"com/melody/lib/service/OpportunityService",
	"com/melody/lib/util/opportunity/Opportunity",
	"com/melody/lib/util/opportunity/OpportunityHelper",
	"com/melody/lib/util/opportunity/DiscontinuedOpportunity",
], function (SAPObject, Filter, Fragment, Controller, FilterOperator, JSONModel, Actions, DateFormat, formatter, oStorageModel,
	ResourceModel, CVA,
	OpportunityService,
	Opportunity,
	OpportunityHelper,
	DiscontinuedOpportunity) {
	"use strict";

	const opportunityDialogController = Controller.extend("com.melody.lib.util.opportunity.OpportunityDialogController", {
		formatter: formatter,
		//function to initial Parent this.sef ref to current this.
		constructor: function (oParentref) {
			this.opportunityCtrl = oParentref;
		},

		_searching: function (bValue) {
			const oModel = this.opportunityCtrl.getModel();
			oModel.setProperty("/Searching", bValue);
		},

		//function to close Opportunity Fragment
		handleOpportunityClose: function (oEvent) {
			oEvent.getSource().getBinding("items").filter([]);
		},

		//function to handle confirm in Opportunity/Active Opportunity Fragments
		handleOpportunityConfirm: async function (oEvent) {
			try {

				let bCvaFlag = true;
				let bNonVATOpportunity = false;
				let oSelectedOppData;
				const oModel = this.opportunityCtrl.getModel();
				let sSourceId = oEvent.getSource().getId();
				let isActNonVATOppList = (sSourceId) ? sSourceId.includes("idActOpptListNonVat") : false;
				const projectType = this.opportunityCtrl.getProjectType();
				const OpportunityUtil = this.opportunityCtrl.OpportunityUtil;
				const OpportunityHelper = this.opportunityCtrl.OpportunityHelper;
				const oSelectedItem = oEvent.getParameter("selectedItem");

				const applicationType = this.opportunityCtrl.getProperty("applicationType");
				let oUrlConstants = $.extend(true, {}, oStorageModel.getProperty("/oConstants"));
				let oActiveOppListControl;
				if (isActNonVATOppList) {
					bNonVATOpportunity = true;
					oActiveOppListControl = this.fnGetDialogUsingId("_ActiveOpportunityDialog", "idActOpptListNonVat");
				} else {
					oActiveOppListControl = this.fnGetDialogUsingId("_ActiveOpportunityDialog", "idActOpptList");
				}
				const oAccountOwnerData = $.extend(true, {}, oModel.getProperty("/selectedOpportunityTeam/ACCOUNT_OWNER"));
				if (projectType === Actions.Actvt) {
					let AccountId = oEvent.getSource().getBindingContext().getObject().AccountId;
					oSelectedOppData = oEvent.getSource().getBindingContext().getObject();
					if (oActiveOppListControl) {
						oActiveOppListControl.getBinding("items").filter([]);
					}
					this.handleActOpportunityClose();
					// if (applicationType !== Actions.applicationType.matrix) {
					this.opportunityCtrl?.setInputBusy(true);
					let {
						data
					} = await OpportunityUtil.getOpportunitiesTeam(oSelectedOppData.OpportunityId);
					let aOpportunityTeamData = OpportunityHelper.fnSetFormatOpportunityTeamData(data.PartiesInvolved.results);
					if (Object.keys(oAccountOwnerData).length) {
						oSelectedOppData.accountOwnerData = oAccountOwnerData;
					}
					oSelectedOppData.opportunityTeamData = aOpportunityTeamData;
					oSelectedOppData.InternalOrder1 = data?.INTERNAL_ORDER1;
					oSelectedOppData.InternalOrder2 = data?.INTERNAL_ORDER2;
					oSelectedOppData.SALES_ORG_TEXT = data?.SALES_ORG_TEXT
					oSelectedOppData.SALES_ORG_SHORT = data?.SALES_ORG_SHORT;
					oSelectedOppData.SALES_OFFICE_SHORT = data?.SALES_OFFICE_SHORT;
					oSelectedOppData.PARTNER_NAME = data?.PARTNER_NAME;
					oSelectedOppData.SALES_GROUP_TEXT = data?.SALES_GROUP_TEXT;
					oSelectedOppData.Notes = data?.Notes;
					oSelectedOppData.SALES_ORG_SHORT = data?.SALES_ORG_SHORT;
					oSelectedOppData.SALES_OFFICE_TEXT= data?.SALES_OFFICE_TEXT;
					
					oModel.setProperty("/selectedOpportunityTeam/SUPPORT", {});
					oModel.setProperty("/selectedOpportunityTeam/ACCOUNT_EXECUTIVE", {});
					oModel.refresh();
				} else {
					const oBindingContext = oSelectedItem.getBindingContext();
					const sPath = oBindingContext.getPath();
					oSelectedOppData = oModel.getProperty(sPath);
				}
				oModel.setProperty("/selectedOpportunity", oSelectedOppData);
				//create harmony link for selected Opportunity
				oSelectedOppData.harmonyLink = (Object.keys(oUrlConstants).length && oUrlConstants.hasOwnProperty("0184")) ? oUrlConstants["0184"]
					.field_value +
					oSelectedOppData.OpportunityId : "";
				oSelectedOppData.bNonVATOpportunity = bNonVATOpportunity;
				oSelectedOppData.IsSelected = true;
				this.opportunityCtrl.setSelectedOpportunity(oSelectedOppData);
			} catch (error) {
				console.log("ERROR IN handleOpportunityConfirm : ", error);
			}
		},

		//function to handle CVA Function
		fnSetCvaData: function (oResponse) {
			let self = this;
			let oResponseData = oResponse.data;
			const oPrerequisiteModel = this.opportunityCtrl.getModel("PrerequisiteModel");

			let oNewCVAData = new CVA(oResponseData);
			oPrerequisiteModel.setProperty("/selectedOpportunity", oNewCVAData);
			oPrerequisiteModel.refresh();
		},

		//function to close active opportunity fragment
		handleActOpportunityClose: function () {
			const oModel = this.opportunityCtrl.getModel();
			oModel.setProperty("/activeOppDialogDefaultIconTab", Actions.active_opportunities);
			oModel.setProperty("/oFilterParam", "");
			const oActiveOppListControl = this.fnGetDialogUsingId("_ActiveOpportunityDialog", "idActOpptList");
			if (oActiveOppListControl) {
				oActiveOppListControl.getBinding("items").filter([]);
			}
			this.opportunityCtrl._oActOpportunityDialog.destroy();
			this.opportunityCtrl._oActOpportunityDialog = null;
		},

		//function to trigger fnComponentTriggerChange
		fnComponentTriggerChange: function (onOppModelChange, parentController) {
			let oThisController = this;
			this.byId("pcOpportunityInput").attachChange(onOppModelChange, parentController);
			if (parentController) {
				let sViewName = parentController.getView().getViewName();
				if (sViewName && sViewName.indexOf("com.presalescentral.successline") !== -1) {
					oThisController.successLineController = parentController;
				} else {
					oThisController.successLineController = "";
				}
			} else {
				oThisController.successLineController = "";
			}
		},

		//function to handle MSL Exists button
		handleMslExistsButton: function (oEvent) {
			let oThisController = this;
			let oSouce = oEvent.getSource();
			let obindingCont = oEvent.getSource().getBindingContext().getObject();
			if (this.successLineController) {
				this.successLineController.handleMslExistsBtnForOppComponent(oEvent);
			}
		},

		//function to handle Opp Status Select
		onOppStatusSelectHandler: async function (oEvent) {
			let aFilters = [];
			const oModel = this.opportunityCtrl.getModel();
			const selectedStatusKey = oEvent.getSource().getSelectedKey();
			const oPrerequisiteModel = this.opportunityCtrl.getModel("PrerequisiteModel");
			const isCvaSelected = oModel.getProperty("/isCvaSelected");
			const oActiveOppListControl = this.fnGetDialogUsingId("_ActiveOpportunityDialog", "idActOpptList");
			const oSelectedAccountData = $.extend(true, {}, oModel.getProperty("/oSelectedAccountDetails"));
			let AccountId = (oSelectedAccountData.hasOwnProperty("AccountId")) ? oSelectedAccountData.AccountId : "";

			if (isCvaSelected && AccountId) {
				aFilters.push(new sap.ui.model.Filter("AccountId", "EQ", AccountId));
			}
			if (selectedStatusKey !== "") {
				aFilters.push(new sap.ui.model.Filter("active", "EQ", selectedStatusKey));
				oActiveOppListControl.getBinding("items").filter(aFilters);
			} else {
				oActiveOppListControl.getBinding("items").filter(aFilters);
			}
			oModel.setProperty("/oppSearchValue", "");
		},

		//function to handle Active Opportunity Search
		onActOpportunitySearchHandler: function (oEvent) {
			const oModel = this.opportunityCtrl.getModel();
			const oActiveOppListControl = this.fnGetDialogUsingId("_ActiveOpportunityDialog", "idActOpptList");
			var sValue = oEvent.getParameter("query");
			var sStatusSelected = oModel.getProperty("/oppStatusSelectedKey") || "";
			this.searchOpportunities(oActiveOppListControl, sValue, sStatusSelected);
		},

		//function to handle opportunity search
		onOpportunitySearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oOppListControl = oEvent.getSource();
			this.searchOpportunities(oOppListControl, sValue);
		},

		//function to handle opportunity search
		searchOpportunities: function (oSource, sValue, sStatus) {
			const oModel = this.opportunityCtrl.getModel();
			const oPrerequisiteModel = this.opportunityCtrl.getModel("PrerequisiteModel");
			const isCvaSelected = oModel.getProperty("/isCvaSelected");
			const oSelectedAccountData = $.extend(true, {}, oModel.getProperty("/oSelectedAccountDetails"));
			let AccountId = (oSelectedAccountData.hasOwnProperty("AccountId")) ? oSelectedAccountData.AccountId : "";

			var aFilters = new Filter({
				filters: [
					new Filter("AccountName", FilterOperator.Contains, sValue),
					new Filter("OpportunityId", FilterOperator.Contains, sValue),
					new Filter("Description", FilterOperator.Contains, sValue),
					new Filter("AccountId", FilterOperator.Contains, sValue)
				],
				and: false
			});
			if (sStatus) {
				var oSearchFilter = aFilters;
				var oStatusFilter = new Filter("active", FilterOperator.EQ, sStatus);
				aFilters = new Filter({
					filters: [oSearchFilter, oStatusFilter],
					and: true
				});
			}
			if (isCvaSelected && AccountId) {
				var oSearchFilter1 = aFilters;
				var accountFilter = new Filter("AccountId", FilterOperator.EQ, AccountId);
				aFilters = new Filter({
					filters: [oSearchFilter1, accountFilter],
					and: true
				});

			}
			var oBinding = oSource.getBinding("items");
			oBinding.filter([aFilters]);
		},

		//function to get element from fragment using id
		fnGetDialogUsingId: function (dialogId, contentId) {
			return sap.ui.core.Fragment.byId(dialogId, contentId);
		},

		//function to handle navigation in Opportunity Information Popup //TODO:check in activityForm once
		onNavToCRM: function (oEvent) {
			let opportunityId;
			const oModel = this.opportunityCtrl.getModel();
			let oConstants = $.extend(true, {}, oStorageModel.getProperty("/oConstants"));
			let selectedOpportunity = $.extend(true, {}, oModel.getProperty("/selectedOpportunity"));
			let validId = (selectedOpportunity && "OpportunityId" in selectedOpportunity && selectedOpportunity.OpportunityId) ? true : false;
			if (validId) {
				opportunityId = selectedOpportunity.OpportunityId;
			} else {
				opportunityId = this.opportunityCtrl.getProperty("opportunityId");
			}
			window.open(oConstants["0184"].field_value + opportunityId, "_blank");
		},

		//function to close Opportunity Info
		onCloseOppInfo: function () {
			this.opportunityCtrl._oOpportunityInfoDialog.then((oDialog) => {
				oDialog.destroy();
				this.opportunityCtrl._oOpportunityInfoDialog = null;
			});
		},

		//function to handle loadmore/growingFinished in Opportunity Component from SL FORM
		onHandleGrowingFinishedForActOppList: function (oEvent, bSlController) {
			let self = this;
			let iPageSize = 10;
			const MSLExistUtil = this.opportunityCtrl.MSLExistUtil;
			const isMSLExists = this.opportunityCtrl.getSettings().showMslExists;
			if (!isMSLExists) {
				return;
			}
			let bGrowing = oEvent.getSource().getGrowing();
			let sReason = oEvent.getParameter("reason");
			if (!bGrowing) {
				return;
			}
			let aListItems = oEvent.getSource().getItems() || [];
			if (sReason !== "Growing") {
				return;
			}
			if (aListItems.length && aListItems.length > iPageSize) {
				let iLastLoaded = aListItems.length - iPageSize;
				let aTempListItems = $.extend(true, [], aListItems);
				let aLastLoadedRecords = aTempListItems.splice(iLastLoaded, iPageSize);
				let aLoadedOppId = [];
				for (let i = 0; i < aLastLoadedRecords.length; i++) {
					let oTempList = aLastLoadedRecords[i];
					let oListObj;
					if (bSlController) {
						oListObj = oTempList.getBindingContext("opportunityModel").getObject();
					} else {
						oListObj = oTempList.getBindingContext().getObject();
					}
					let OPP_ID = oListObj.OpportunityId;
					aLoadedOppId.push(OPP_ID);
				}
				MSLExistUtil.fnGetSLOppDataForMSLExist(aLoadedOppId, bSlController);
			}
		},

		//function to handle MSL Exists Navigation
		handleMslExistsButton: function (oEvent) {
			let self = this;
			const MSLExistUtil = this.opportunityCtrl.MSLExistUtil;
			let oSource = oEvent.getSource();
			let obindingCont = oEvent.getSource().getBindingContext().getObject();
			MSLExistUtil.fnCheckSLAvailableForMSLExist(obindingCont, oSource, true);
		},

		//function to get status value based on status-ID
		getOpportunityStatus: function (StatusId) {
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let oOppStatusMasterMap = oStorage.get("pcOppStatusMasterMapCPI") || oStorage.get("pcOppStatusMasterMap");
			let oStatus = oOppStatusMasterMap?.[StatusId] || {};
			return ("VALUE" in oStatus) ? oStatus.VALUE : "";
		},

		//function to formate Opportunity Date
		getOpportunityDate: function (date) {
			var dateFormat = DateFormat.getDateInstance({
				style: "medium"
			});
			if (date && date !== null && date !== "") {
				if (typeof date === "string" && date.indexOf("/Date(") === 0) {
					date = parseInt(date.match(/\d+/)[0], 10);
				}
				date = new Date(date);
				return dateFormat.format(date);
			} else {
				return null;
			}
		},

		//function to check value empty
		fnCheckEmpty: function (value) {
			if (value && value !== "") {
				return value;
			} else {
				return "Unavailable";
			}
		},

		//function to handle icon tabs in active opportunities fragment
		onSelectOpportunityTab: function (oEvent) {
			let oDefaultModel = this.opportunityCtrl.getModel();
			let selectedKey = oEvent.getParameter("selectedKey");
			const OpportunityHelper = this.opportunityCtrl.OpportunityHelper;
			let bFilterNonVatAccBased = oStorageModel.getProperty("/bFilterNonVatAccBased");
			let bRemoveNonVAtAccFilter = oStorageModel.getProperty("/bRemoveNonVAtAccFilter");
			let NonVatOpportunitiesList = oDefaultModel.getProperty("/NonVatOpportunitiesList") || [];

			switch (selectedKey) {
				case Actions.oActiveOppTabKeys.active_opportunities:
					// oDefaultModel.setProperty("/oppSearchValue", "");
					break;
				case Actions.oActiveOppTabKeys.nonvat_opportunity_list:
					// oDefaultModel.setProperty("/nonvatoppsearchvalue", "");

					if (NonVatOpportunitiesList.length) {
						return;
					}
					this.fetchNonVATOppsBasedOnFilters();
					break;
				default:
			}
		},

		fetchNonVATOppsBasedOnFilters: function () {
			let oThisController = this;
			let oDefaultModel = this.opportunityCtrl.getModel();
			const OpportunityUtil = this.opportunityCtrl.OpportunityUtil;
			let bRequiredTotalCount = true;
			let aFilters = [];
			let mParameters = "";
			//If account Data is present
			let accountFilter = oThisController.fnAddAccountIdFilterToNONVat();
			if (accountFilter) {
				mParameters = {
					filters: [accountFilter],
				};
				oDefaultModel.setProperty("/oFilterParam", mParameters);
			} else {
				oDefaultModel.setProperty("/oFilterParam", "");
			}

			oDefaultModel.setProperty("/NonVatOpportunitiesList", []);
			oDefaultModel.setProperty("/isOpptNonVATListTabBusy", true);
			oDefaultModel.setProperty("/bNONVatLoadMoreBtnVisible", false);
			oDefaultModel.setProperty("/bRequiredTotalCount", bRequiredTotalCount);
			OpportunityUtil.fnFetchNONVATForCVJ(mParameters, undefined, true).then((aResults) => {
				aResults = (aResults && aResults.length) ? oThisController.fnFilterActiveOppFromNonVatOpp(aResults) : [];
				oDefaultModel.setProperty("/iNonvatLoaded", aResults.length);
				oDefaultModel.setProperty("/NonVatOpportunitiesList", aResults);
				oDefaultModel.setProperty("/isOpptNonVATListTabBusy", false);
				oDefaultModel.refresh();
			});
		},

		//function to handle NON-VAT Opportunity Fitler
		onNonVATOpportunitySearchHandler: function (oEvent) {
			let aFilters = [];
			let mParameters = "";
			let aSearchFilter = "";
			let oThisController = this;
			let isOpportunityId = false;
			let oDefaultModel = this.opportunityCtrl.getModel();
			let searchQuery = oEvent.getParameter("query") || "";
			const OpportunityUtil = this.opportunityCtrl.OpportunityUtil;
			const OpportunityHelper = this.opportunityCtrl.OpportunityHelper;
			oDefaultModel.setProperty("/isOpptNonVATListTabBusy", true);
			oDefaultModel.setProperty("/bRequiredTotalCount", true);

			//Account Based Opportunity Scenario
			let accountFilter = oThisController.fnAddAccountIdFilterToNONVat();
			if (accountFilter) {
				aFilters.push(accountFilter);
			}

			searchQuery = searchQuery.trim();
			if (searchQuery) {
				let numberRegEx = /^[0-9]+$/;
				isOpportunityId = numberRegEx.test(searchQuery);
				//Only Opportunity-ID
				if (isOpportunityId) {
					aFilters.push(new Filter({
						path: "OPPT_ID",
						// operator: sap.ui.model.FilterOperator.Contains,
						operator: sap.ui.model.FilterOperator.EQ,
						value1: searchQuery
					}));
				}
			}

			if (aFilters.length) {
				aSearchFilter = new Filter({
					filters: aFilters,
					and: true
				});
			}
			mParameters = {
				filters: aSearchFilter,
				isOppSearch: isOpportunityId,
				searchQuery: (!isOpportunityId && searchQuery) ? searchQuery : ""
			};

			oDefaultModel.setProperty("/oFilterParam", mParameters);
			oDefaultModel.setProperty("/NonVatOpportunitiesList", []);
			OpportunityUtil.fnFetchNONVATForCVJ(mParameters, undefined, true).then((aResults) => {
				aResults = (aResults && aResults instanceof Array) ? oThisController.fnFilterActiveOppFromNonVatOpp(aResults) : [];
				oDefaultModel.setProperty("/iNonvatLoaded", aResults.length);
				oDefaultModel.setProperty("/NonVatOpportunitiesList", aResults);
				oDefaultModel.setProperty("/isOpptNonVATListTabBusy", false);
				oDefaultModel.refresh();
			});
		},

		//Function to handle scroll loadMore for NON-VAT
		onLoadMoreNonVATLib: function (oEvent) {
			let oThisController = this;
			let oDefaultModel = this.opportunityCtrl.getModel();
			const OpportunityUtil = this.opportunityCtrl.OpportunityUtil;
			let oFilterParam = oDefaultModel.getProperty("/oFilterParam");
			let aNonVatOpportunitiesList = oDefaultModel.getProperty("/NonVatOpportunitiesList") || [];
			let iActualNonvatLoaded = oDefaultModel.getProperty("/iActualNonvatLoaded") || 0;
			const OpportunityHelper = this.opportunityCtrl.OpportunityHelper;
			oDefaultModel.setProperty("/isOpptNonVATListTabBusy", true);
			OpportunityUtil.fnFetchNONVATForCVJ(oFilterParam, Number(iActualNonvatLoaded), true).then((aResults) => {
				let prevNonVatData = $.extend([], true, aNonVatOpportunitiesList);
				if (aResults && !aResults.length) {
					oDefaultModel.setProperty("/bNONVatLoadMoreBtnVisible", false);
				}
				aResults = (aResults && aResults instanceof Array) ? oThisController.fnFilterActiveOppFromNonVatOpp(aResults) : [];
				if (aResults && aResults.length) {
					aNonVatOpportunitiesList = aNonVatOpportunitiesList.concat(aResults);
					oDefaultModel.setProperty("/iNonvatLoaded", aNonVatOpportunitiesList.length);
					oDefaultModel.setProperty("/NonVatOpportunitiesList", aNonVatOpportunitiesList);
				}
				//List Sorting based on display auth
				let oNavVatList = oThisController.fnGetDialogUsingId("_ActiveOpportunityDialog", "idActOpptListNonVat");
				setTimeout(() => {
					if (oNavVatList) {
						let aListItems = oNavVatList.getItems() || [];
						if (aListItems.length) {
							let aSortedData = prevNonVatData.filter((oList) => {
								// return oList.getBindingContext().getObject()["DisplayAuth"];
								return oList["DisplayAuth"];
							});
							let focusCount = aSortedData.length + 1;
							oNavVatList.getItems()[focusCount].focus();
						}
					}
				}, 30);
				oDefaultModel.setProperty("/isOpptNonVATListTabBusy", false);
				oDefaultModel.refresh();
			});
		},

		//function to filter Active Opportunties in NON-VAT Opportunity
		fnFilterActiveOppFromNonVatOpp: function (aNonVatOppData) {
			let aNonVatSegregatedData = [];
			let oDefaultModel = this.opportunityCtrl.getModel();
			const oMtrSettingsModel = sap.ui.getCore().getModel("mtrSettings");
			let aActiveOpportunity = oDefaultModel.getProperty("/Opportunities") || [];
			for (let i = 0; i < aNonVatOppData.length; i++) {
				let oNonVatOppData = aNonVatOppData[i];
				let sNonVatOpp = oNonVatOppData.OpportunityId;
				if (sNonVatOpp) {
					let index = aActiveOpportunity.findIndex((oOppData) => {
						return oOppData.OpportunityId === sNonVatOpp;
					});
					if (index === -1) {
						aNonVatSegregatedData.push(oNonVatOppData);
					}
				}
			}
			this.fnSetNONVATLoadMoreVisibilty(aNonVatSegregatedData, oDefaultModel);
			if (oMtrSettingsModel) {
				oMtrSettingsModel.setProperty("/aNONVatOppData", aNonVatSegregatedData);
				oMtrSettingsModel.refresh();
			}
			return aNonVatSegregatedData;
		},

		//function to handle NON-VAT load more visibilty
		fnSetNONVATLoadMoreVisibilty: function (aResults, oModel) {
			let oDefaultModel = this.opportunityCtrl.getModel();
			let iNonvatTotalCount = oDefaultModel.getProperty("/iNonvatTotalCount");
			let iActualNonvatLoaded = oDefaultModel.getProperty("/iActualNonvatLoaded") || 0;
			if (iActualNonvatLoaded < iNonvatTotalCount) {
				oModel.setProperty("/bNONVatLoadMoreBtnVisible", true);
			} else if (iActualNonvatLoaded === iNonvatTotalCount || iNonvatTotalCount < 10) {
				// sap.m.MessageToast.show("No Data Available");
				oModel.setProperty("/bNONVatLoadMoreBtnVisible", false);
			}
			oModel.refresh();
		},

		//Function to add account id FILTER
		fnAddAccountIdFilterToNONVat: function (AccountIdArg) {
			let oModel = this.opportunityCtrl.getModel();
			const oSelectedAccountData = $.extend(true, {}, oModel.getProperty("/oSelectedAccountDetails"));
			let AccountId = (oSelectedAccountData.hasOwnProperty("AccountId")) ? oSelectedAccountData.AccountId : "";
			//If account Data is present
			if (AccountIdArg || AccountId) {
				AccountId = AccountIdArg || AccountId;
				let aSearchFilter = new Filter({
					filters: [
						new Filter({
							path: "ACCOUNT",
							operator: sap.ui.model.FilterOperator.EQ,
							value1: AccountId
						})
					]
				});
				return aSearchFilter;
			}
			return false;
		},

		handleActOpportunitySearch: function (oEvent) {
			// this.clearStorage();
			const sValue = oEvent.getParameter("query");
			const bClearBtnPressed = oEvent.getParameter("clearButtonPressed")
			if (bClearBtnPressed || sValue) {
				this.opportunityCtrl.OpportunityUtil.searchActiveOpportunities(sValue);
			}
		},

		onQuarterFilterChange: function (oEvent) {
			// this.clearStorage();
			const sSelectedTabKey = oEvent?.getSource()?.getCustomData()?.[0]?.getKey();
			const sKey = oEvent.getSource().getSelectedKey();
			if (sKey) {
				if (sSelectedTabKey === "NON_VAT") {
					this.fetchNonVATOppsBasedOnFilters();
				} else {
					this.opportunityCtrl.OpportunityUtil.fetchFilteredActiveOpportunities();

				}
			}
		},

		onOppStausFilterChange: function (oEvent) {
			// this.clearStorage();
			const sSelectedTabKey = oEvent?.getSource()?.getCustomData()?.[0]?.getKey();
			var aSelectedKeys = oEvent.getSource().getSelectedKeys();
			if (aSelectedKeys.length) {
				if (sSelectedTabKey === "NON_VAT") {
					this.fetchNonVATOppsBasedOnFilters();
				} else {
					this.opportunityCtrl.OpportunityUtil.fetchFilteredActiveOpportunities();
				}
			}
		},

		onLoadMoreActiveOpps: function () {
			// this.clearStorage();
			this.opportunityCtrl.OpportunityUtil._loadMoreActiveOppData();
		},

		onFavouriteChange: function (oEvent) {
			// this.clearStorage();
			const sSelectedTabKey = oEvent?.getSource()?.getCustomData()?.[0]?.getKey();
			if (sSelectedTabKey === "NON_VAT") {
				this.fetchNonVATOppsBasedOnFilters();
			} else {
				this.opportunityCtrl.OpportunityUtil.fetchFilteredActiveOpportunities();
			}
		},

		

	});
	return opportunityDialogController;
});