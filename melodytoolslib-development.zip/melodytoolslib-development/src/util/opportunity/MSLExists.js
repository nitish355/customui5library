sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterType",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"com/melody/lib/enum/Actions",
	"com/melody/lib/service/OpportunityService",
	"com/melody/lib/util/opportunity/Opportunity",
], function (SAPObject, Filter, FilterType, FilterOperator, JSONModel, Actions, OpportunityService, OpportunityUtil) {
	"use strict";

	return {
		//function to initialize this.self to parent pointer "this"
		fnStaticInit: function (oParentRef) {
			//self points to the parent controller
			this.self = oParentRef;
		},

		//function to load MSL functionality 
		fnLoadMSLFunctionality: function (aOpportunityData) {
			
			let self = this;
			let aOpportunityID = [];
			const oModel = this.self.getModel();
			let oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let aActiveOpp = oStorage.get("actOpportunities") || [];
			let aPcOpp = oStorage.get("pcOpportunities") || [];
			let aActiveOppModelData = $.extend(true, [], oModel.getProperty("/actOpportunities"));
			if (aOpportunityData.length && aActiveOppModelData.length) {
				let oSLOppData = oStorage.get("SlopportunityMapData") || {};
				if (aActiveOppModelData.length) {
					aActiveOppModelData.sort(function (a, b) {
						return a.AccountName.trim().localeCompare(b.AccountName.trim());
					});
					let aTempData = aActiveOppModelData.filter(function (oActiveData) {
						return oActiveData.active === 1
					});
					oStorage.put("actOpportunities", aActiveOppModelData);
					aOpportunityID = aTempData.map((oRow) => {
						return oRow.OpportunityId;
					});
				} else {
					aOpportunityID = Object.keys(oSLOppData);
				}
				if (aOpportunityID.length) {
					//function to fetch Sl data based on Opp to check MSL Exist 
					this.fnSetFormatTenOppIdForMSLExist(aOpportunityID, false);
				}
			}
		},

		//function to splice first 10 OppIds to fetch the MSL Exist Data
		fnSetFormatTenOppIdForMSLExist: function (aOpportunityID, bSlController) {
			
			let iPageSize = 15;
			let aTempOppId = $.extend(true, [], aOpportunityID);
			if (aTempOppId.length > iPageSize) {
				let aFirstTenOppId = aTempOppId.splice(0, iPageSize);
				this.fnGetSLOppDataForMSLExist(aFirstTenOppId, bSlController);
			} else {
				this.fnGetSLOppDataForMSLExist(aTempOppId, bSlController);
			}
		},

		//function to handle fetch MSLExist data based on Oppid
		fnGetSLOppDataForMSLExist: function (aOpportunityID, bSlController) {
			if (!aOpportunityID.length) {
				return;
			}
			let self = this;
			let aFilter = [];
			for (let i = 0; i < aOpportunityID.length; i++) {
				let sOppId = aOpportunityID[i];
				aFilter.push(new Filter({
					path: "OppNo",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: sOppId
				}));
			}
			OpportunityService.getMSLExistDataBasedOnOpp(aFilter).then((oData) => {
				let aResponse = $.extend(true, [], oData.data.results);
				self.fnMapOppDataWithMSLResponse(aResponse, bSlController);
			}).catch((error) => {});
		},

		//function to map the session opp data with MSL Exist Response
		fnMapOppDataWithMSLResponse: function (aResponse, bSlController) {
			let self = this;
			const oModel = this.self.getModel();
			let oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let aActOppData = $.extend(true, [], oStorage.get("actOpportunities"));
			let aPcOppData = $.extend(true, [], oStorage.get("pcOpportunities"));
			oModel.setProperty("/isOpptDilogBusy", true);
			let aActiveOppModelData = $.extend(true, [], oModel.getProperty("/actOpportunities"));
			if (aActiveOppModelData.length) {
				
				if (aResponse.length) {
					for (let i = 0; i < aResponse.length; i++) {
						let oResponse = aResponse[i];
						let iIndex = aActiveOppModelData.findIndex((oRow) => {
							return oRow.OpportunityId === oResponse.OppNo;
						});
						if (iIndex !== -1) {
							let oCurrentData = aActiveOppModelData[iIndex];
							if (oCurrentData.hasOwnProperty("bUIMainOppChange") && oCurrentData.bUIMainOppChange) {
								aActiveOppModelData[iIndex].SlExists = "";
								aActiveOppModelData[iIndex].bAdditionalOpp = false;
							} else {
								if (oCurrentData["active"] !== 0) {
									aActiveOppModelData[iIndex].SlExists = (oResponse.SlExists === "X") ? "X" : "";
									aActiveOppModelData[iIndex].SlId = oResponse.SlId;
									aActiveOppModelData[iIndex].SlSnro = (oResponse.SlSnro) ? oResponse.SlSnro : "";
									aActiveOppModelData[iIndex].bAdditionalOpp = (oResponse.SlExists === "X" && oResponse.MainOpp) ? true : false;
								}
							}
						}
					}
					oModel.setProperty("/isOpptDilogBusy", true);
					if (bSlController) {
						//for Additional Opp in SL - Select Opportunity
						let oOppSlModel = this.getView().getModel("opportunityModel");
						oModel.setProperty("/Opportunities", aActiveOppModelData);
						oModel.setProperty("/actOpportunities", aActiveOppModelData);
						oModel.refresh();
					} else {
						
						//Opportunity Component - Select Opportunity
						oModel.setProperty("/actOpportunities", aActiveOppModelData);
						oModel.setProperty("/Opportunities", aActiveOppModelData);
						oModel.refresh();

					}
					oModel.setProperty("/isOpptDilogBusy", false);
					// oStorage.put("actOpportunities", aActiveOppModelData);
				} else {
					MessageToast.show("MSL Exists Data Not Found.");
					oModel.setProperty("/isOpptDilogBusy", false);
				}
				oModel.refresh();
			}
		},

		//function to check SL Available for MSL Exist
		fnCheckSLAvailableForMSLExist: function (oSelectedData, oSource, bSlController) {
			let self = this;
			let sOppId = oSelectedData.OpportunityId;
			let aFilters = [];
			aFilters.push(new Filter("OpportunityId", FilterOperator.EQ, sOppId));
			if (bSlController) {
				aFilters.push(new Filter("MainOpp", FilterOperator.EQ, true));
			}
			self.fnCheckforSLFromAvailabiltySerivce(aFilters, bSlController, oSelectedData, "MSLEXISTSCREATE");

		},

		//function to check availabilty logic
		fnCheckforSLFromAvailabiltySerivce: function (aFilters, bSlController, oSelectedData, sFuntionalityType) {
			
			let self = this;
			let bUserPart = false;
			let bActiveSL = false;
			OpportunityService.validateSuccessLineAvailability(aFilters).then((oData) => {
				let aResponse = oData.data.results || [];
				let aNavCheck = [];
				for (let i = 0; i < aResponse.length; i++) {
					let oTempResult = aResponse[i];
					if (!oTempResult.Archive) { //not archived
						if (oTempResult.SLStatusID === "01") { //Active SL
							if (oTempResult.SLStatusID === "01" && oTempResult.IsPartOfSl === "X") {
								bUserPart = true;
							}
							oTempResult.message = "Already an active SL exists for the same opportunity.";
							oTempResult.Active = true;
							//Only on Primary Opp
							if (!bSlController) {
								if (oTempResult.MainOpp || (!oTempResult.MainOpp && oTempResult.SlOpp)) {
									bActiveSL = true;
									aNavCheck.push(oTempResult);
								}
							} else {
								bActiveSL = true;
								aNavCheck.push(oTempResult);
							}

						}
					}
				}

				switch (sFuntionalityType) {
				case "MSLEXISTSCREATE":
					if (aNavCheck.length === 1) {
						self.fnHandleCrossNavigation(oSelectedData);
						return;
					}

					if (aNavCheck.length) {
						self.fnHandlePreExistingSLForMSLExists(aNavCheck, bUserPart, bActiveSL);
					} else {
						self.fnHandleCrossNavigation(oSelectedData);
						return;
					}
					break;
				case "MSLEXISTSDELETE":
					this.self.fireEvent("selectedItem", {
						"opportunityDataHandler": aNavCheck
					});
					return;
				default:
				}
			});
		},

		//function to open pre-existing SL for MSL Exists
		fnHandlePreExistingSLForMSLExists: function (aActiveSl, bUserPart, bActiveSL) {
			let opportuntiyDataHandler = {
				continueMessage: "Click on OK to Continue.",
				aActiveSl: aActiveSl,
				bUserPart: bUserPart,
				bUsrNotPart: bUsrNotPart,
				activeSL: bActiveSL,
				ValidationFlag: false,
				previewVisible: false
			};

			this.self.fireEvent("selectedItem", {
				"opportunityDataHandler": opportuntiyDataHandler
			});
		},

		//handle cross navigation
		fnHandleCrossNavigation: function (oData) {
			let self = this;
			// self.additionalOppDialog.close();
			if (oData && oData.hasOwnProperty("SlSnro") && oData.SlSnro !== "") {
				let oParamObj = {
					"SuccessLineID": oData.SlSnro
				};

				// window.alert(`Navigate To SL no: ${oData.SlSnro} `);

				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
				var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
					target: {
						semanticObject: "sl",
						action: "App&/SlDetail"
					},
					params: oParamObj
				})) || ""; // generate the Hash to display a Supplier
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: hash
					}
				});

			}
		},

		//function to set bUIMainOppChange to false
		fnSetFormatUiMainOppChangeFlag: function () {
			let aIndices = [];
			if (!this.oStorage) {
				this.oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			}
			let aActiveOppModelData = $.extend(true, [], this.oStorage.get("actOpportunities"));

			for (let i = 0; i < aActiveOppModelData.length; i++) {
				let oTempData = aActiveOppModelData[i];
				if (oTempData.hasOwnProperty("bUIMainOppChange") && oTempData.bUIMainOppChange) {
					aIndices.push(i);
				}
			}

			for (let i = 0; i < aIndices.length; i++) {
				let iTempIndex = aIndices[i];
				if (iTempIndex !== -1) {
					aActiveOppModelData[iTempIndex].bUIMainOppChange = false;
				}
			}
			this.oStorage.put("actOpportunities", aActiveOppModelData);
		},

		//handle updatefinished from SL controller select Opp
		onHandleUpdatedFinishedForSelectOpp: function (oEvent) {
			this.onHandleGrowingFinishedForActOppList(oEvent, true);
		},

	};
});