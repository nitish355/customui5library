sap.ui.define([
		"sap/ui/model/Filter",
		"sap/ui/core/Fragment",
		"sap/ui/model/FilterOperator",
		"sap/ui/model/json/JSONModel",
		"com/melody/lib/enum/Actions",
		"com/melody/lib/model/StorageModel",
		"com/melody/lib/service/OpportunityService"
	],
	function (Filter, Fragment, FilterOperator, JSONModel, Actions, oStorageModel, OpportunityService) {
		"use strict";
		return {

			//set this.self pointer to the parent "this" pointer 
			fnStaticInit: function (oParentRef) {
				this.self = oParentRef;
			},

			//Function to link SL to Harmony, Parallel opportunity case //TODO Testing is pending
			fnParallelOpppLinkSlToHarmony: function (discontinuedOppos) {
				let self = this;
				for (let i = 0; i < discontinuedOppos.length; i++) {
					if (discontinuedOppos[i].Type === "SuccessLine") {
						let SlId = discontinuedOppos[i].ID;
						SlId = SlId.padStart(10, "0");
						let OpportunityId = discontinuedOppos[i].NewOppId;
						OpportunityId = OpportunityId.replace(/^0+/, '');
						setTimeout(function () {
							self.fnLinkSlToHarmony(SlId, OpportunityId);
						});
					}
				}
			},

			//Function to link SL to Harmony, after an SL is created. //TODO Testing is pending
			fnLinkSlToHarmony: function (SlId, OpportunityId) {
				let slUrl = window.location.origin + window.location.pathname + "#sl-App&/SlDetail?SuccessLineID=" + SlId;
				let urlParameters = {
					MODE: "A",
					URL: slUrl,
					ARC_DOC_ID: "",
					ATTACHMENT_TYPE: "",
					OPPT_ID: OpportunityId,
					FILENAME: "Melody SuccessLine",
					DESCRIPTION: "Link to SL Application"
				};

				OpportunityService.getServiceToHandleAttachments(urlParameters).then((oResponse) => {

				}).catch((oError) => {

				});
			},

			//Automatically add activity team memeber to opportunity VAT team 10/11/2022
			//Function to set opportunity access for  activity user
			fnProvideOppoAccess: function (oNoAccessUsrs, OpportunityId, successFn, isInit) {
				let length = oNoAccessUsrs.length;
				let OppoVATTeamModel = this.self.getModel(Actions.oModels.OppoVATTeamModel);
				let oSelectedNonVATOppData = oStorageModel.getProperty("/oSelectedNonVATOppData") || {};
				let aNonVATKeys = Object.keys(oSelectedNonVATOppData);

				OppoVATTeamModel.setProperty("/NoAccessUsers", oNoAccessUsrs);
				OppoVATTeamModel.setProperty("/VATOpportunity", OpportunityId);
				OppoVATTeamModel.setProperty("/VATNoAccessUsersLength", length);
				if (isInit) {
					let oUsers = $.extend(true, [], oNoAccessUsrs);
					OppoVATTeamModel.setProperty("/InitNoAccessUsers", oUsers);
					OppoVATTeamModel.setProperty("/oTotalFnCount", 1);
				} else {
					let oTotalFnCount = OppoVATTeamModel.getProperty("/oTotalFnCount");
					oTotalFnCount = oTotalFnCount + 1;
					OppoVATTeamModel.setProperty("/oTotalFnCount", oTotalFnCount);
				}

				//Validation for NON-VAT Opp Data submit
				if (aNonVATKeys.length) {
					this.fnHandleNonVATOppSubmit(oNoAccessUsrs, OpportunityId, successFn, aNonVATKeys, oSelectedNonVATOppData);
				} else {
					this.fnFindSelectedOpportunity(oNoAccessUsrs, OpportunityId, successFn);
				}
			},

			//Function to find the selected Opportunity Data
			fnFindSelectedOpportunity: function (oNoAccessUsrs, OpportunityId, successFn) {
				let self = this;
				let selectedOpp = {};
				const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				let pcOpportunities = oStorage.get("pcOpportunities") || [];
				let OppoVATTeamModel = this.self.getModel(Actions.oModels.OppoVATTeamModel);
				if (pcOpportunities.length) {
					pcOpportunities.filter(function (obj) {
						if (obj.OPPT_ID === OpportunityId) {
							selectedOpp.GUID = obj.GUID;
							selectedOpp.OPPT_ID = obj.OPPT_ID;
							selectedOpp.CHANGED_AT = obj.CHANGED_AT;
							selectedOpp.EXPECT_END = new Date(obj.EXPECT_END);
							OppoVATTeamModel.setProperty("/OppoID", obj.OPPT_ID);
							OppoVATTeamModel.setProperty("/OppoOwner", obj.OWNER);
						}
					});
					if (Object.keys(selectedOpp).length) {
						if (!selectedOpp.CHANGED_AT || !selectedOpp.GUID) {
							this.fnGetSelOpportunityData(oNoAccessUsrs, OpportunityId, successFn);
						} else {
							OppoVATTeamModel.setProperty("/OppoLookUp", selectedOpp);
							this.fnSendActTeamUser(oNoAccessUsrs, OpportunityId, successFn, 0);
						}
					} else {
						this.fnGetSelOpportunityData(oNoAccessUsrs, OpportunityId, successFn);
					}
				} else {
					this.fnGetSelOpportunityData(oNoAccessUsrs, OpportunityId, successFn);
				}
			},

			//Function to get selected opportunity data
			fnGetSelOpportunityData: function (oNoAccessUsrs, OpportunityId, successFn) {
				let self = this;
				let OppoVATTeamModel = this.self.getModel(Actions.oModels.OppoVATTeamModel);
				let OppoLookUp = $.extend(true, {}, OppoVATTeamModel.getProperty("/OppoLookUp"));
				if (OppoLookUp[OpportunityId]) {
					this.fnSendActTeamUser(oNoAccessUsrs, OpportunityId, successFn, 0);
				} else {
					let oOppoFilter = new Filter("OPPT_ID", FilterOperator.EQ, OpportunityId);
					let oUrlParameters = {
						filters: [oOppoFilter],
						urlParameters: {
							$select: 'CHANGED_AT,EXPECT_END,GUID,OPPT_ID,OWNER_NAME,OWNER_EMPID,OWNER'
						}
					};
					OpportunityService.getOpportunityForVAT(OpportunityId, oUrlParameters).then((oResponse) => {
						let oData = oResponse.data.results[0];
						OppoLookUp[OpportunityId] = oData;
						OppoVATTeamModel.setProperty("/OppoID", oData.OPPT_ID);
						OppoVATTeamModel.setProperty("/OppoOwner", oData.OWNER);
						OppoVATTeamModel.setProperty("/OppoLookUp", oData);
						self.fnSendActTeamUser(oNoAccessUsrs, OpportunityId, successFn, 0);
					}).catch((oError) => {

					});
				}
			},

			//Function to pass UserID one by one, after opportunity data is available
			fnSendActTeamUser: function (oNoAccessUsrs, OpportunityId, successFn, index) {
				let self = this;
				let OppoVATTeamModel = this.self.getModel(Actions.oModels.OppoVATTeamModel);
				if (oNoAccessUsrs[index]) {
					if (oNoAccessUsrs[index] && !oNoAccessUsrs[index].IsDuplicate) {
						OppoVATTeamModel.setProperty("/NoAccesUserIndex", index);
						self.getActTeamUserPartnerId(oNoAccessUsrs[index], OpportunityId, successFn);
					} else {
						let length = OppoVATTeamModel.getProperty("/VATNoAccessUsersLength");
						let NoAccesUserIndex = OppoVATTeamModel.getProperty("/NoAccesUserIndex");
						NoAccesUserIndex = NoAccesUserIndex + 1;
						if (NoAccesUserIndex <= length) {
							let OpportunityId = OppoVATTeamModel.getProperty("/OppoID");
							let NoAccessUsers = OppoVATTeamModel.getProperty("/NoAccessUsers");
							OppoVATTeamModel.setProperty("/NoAccesUserIndex", NoAccesUserIndex);
							self.fnSendActTeamUser(NoAccessUsers, OpportunityId, successFn, NoAccesUserIndex);
						}
					}
				} else {
					self.fnGetUserCRMRole(OpportunityId, successFn);
				}
			},

			//Function to get BP Id of activity team user //TODO FIND SOLUTION FOR METADATA
			getActTeamUserPartnerId: function (teamMember, OpportunityId, successFn, oParams) {
				let self = this;
				// let bMetadataLoaded = !this.oOppoDataModel.isMetadataLoadingFailed();
				let OppoVATTeamModel = this.self.getModel(Actions.oModels.OppoVATTeamModel);
				let oBPUsers = $.extend(true, {}, OppoVATTeamModel.getProperty("/BPUsers"));
				if (true) {
					let userID = oParams ? oParams.OppoOwner : teamMember.ID;
					let urlParameters = {
						filters: [
							new Filter({
								path: "TYPE",
								operator: "EQ",
								value1: "E"
							})
						],
						search: userID
					};
					OpportunityService.getBusinessPartners(urlParameters.search, urlParameters.filters).then((oResponse) => {
						let oData = oResponse.data.results[0];
						if (oParams) {
							let aList = oResponse.data.results || [];
							let oUser = aList.find(function (obj) {
								return obj.PARTNER === oParams.OppoOwner;
							});
							self.fnSaveOppoVATTeamMembers(oParams.ActivityId, oParams.SlId, oParams.ResultData, oParams.successfn, oUser.USERID);
						} else {
							if (oData) {
								teamMember.NAME = oData.NAME;
								teamMember.USERID = teamMember.ID;
								teamMember.ID = oData.PARTNER;
								oBPUsers[teamMember.USERID] = oData;
								OppoVATTeamModel.setProperty("/BPUsers", oBPUsers);
								self.fnTriggerNextUserBpId(successFn);
							} else {
								//IsDuplicate property is set, for the Users who are no part of Organization.
								teamMember.IsDuplicate = true;
								oBPUsers[teamMember.USERID] = oData;
								OppoVATTeamModel.setProperty("/BPUsers", oBPUsers);
								self.fnTriggerNextUserBpId(successFn);
							}
						}
					}).catch((oError) => {

					});
				} else {
					successFn("HARMONY_SERVER_DOWN");
				}
			},

			//Function to find next User's BP ID
			fnTriggerNextUserBpId: function (successFn) {
				let self = this;
				let OppoVATTeamModel = this.self.getModel(Actions.oModels.OppoVATTeamModel);
				let OpportunityId = OppoVATTeamModel.getProperty("/OppoID");
				let length = OppoVATTeamModel.getProperty("/VATNoAccessUsersLength");
				let NoAccesUserIndex = OppoVATTeamModel.getProperty("/NoAccesUserIndex");
				NoAccesUserIndex = NoAccesUserIndex + 1;
				if (NoAccesUserIndex < length) {
					let NoAccessUsers = OppoVATTeamModel.getProperty("/NoAccessUsers");
					OppoVATTeamModel.setProperty("/NoAccesUserIndex", NoAccesUserIndex);
					self.fnSendActTeamUser(NoAccessUsers, OpportunityId, successFn, NoAccesUserIndex);
				} else {
					self.fnGetUserCRMRole(OpportunityId, successFn);
				}
			},

			//Function to get User's CRM Role ID and Desc
			fnGetUserCRMRole: function (OpportunityId, successFn) {
				let self = this;
				let aFilter = [];
				let OppoVATTeamModel = this.self.getModel(Actions.oModels.OppoVATTeamModel);
				let NoAccessUsers = $.extend(true, [], OppoVATTeamModel.getProperty("/NoAccessUsers"));
				for (let i = 0; i < NoAccessUsers.length; i++) {
					if (!NoAccessUsers[i].CRMRoleId && !NoAccessUsers[i].CRMRoleDesc && !NoAccessUsers[i].IsDuplicate) {
						aFilter.push(new Filter("ID", "EQ", NoAccessUsers[i].USERID));
					}
				}
				if (aFilter.length) {
					let oParams = {
						filters: aFilter
					};

					OpportunityService.getServiceToUserSearch(oParams).then((oResponse) => {
						let aResponse = oResponse.data.results;
						NoAccessUsers.filter(function (NoUserObj) {
							aResponse.filter(function (obj) {
								if (obj.ID === NoUserObj.USERID) {
									NoUserObj.CRMRoleId = obj.CrmRoleId;
									NoUserObj.CRMRoleDesc = obj.CrmRoleDesc;
								}
							})
						});
						OppoVATTeamModel.setProperty("/NoAccessUsers", NoAccessUsers);
						self.fnFormPartiesInvolvedPayload(OpportunityId, successFn);
					}).catch((oError) => {

					});

				} else {
					self.fnFormPartiesInvolvedPayload(OpportunityId, successFn);
				}
			},

			//Function to form payload to add activity team to opportunity team 
			fnFormPartiesInvolvedPayload: function (OpportunityId, successFn) {
				let self = this;
				let OppoVATTeamModel = this.self.getModel(Actions.oModels.OppoVATTeamModel);
				let oppoData = OppoVATTeamModel.getProperty("/OppoLookUp");
				let oUsers = OppoVATTeamModel.getProperty("/NoAccessUsers");
				let oPartiesInvolved = [];
				for (let i = 0; i < oUsers.length; i++) {
					if (!oUsers[i].IsDuplicate) {
						let obj = {
							"ADDRESS": "",
							"COUNTRY": "",
							"EMAIL": oUsers[i].EMAIL,
							"ID": oUsers[i].ID,
							"IS_EDITABLE": "",
							"MODE": "A",
							"MAINPARTNER": false,
							"NAME": oUsers[i].NAME,
							"PARTY_TYPE": "EMPLOYEE",
							"ROLE": oUsers[i].CRMRoleId,
							"ROLE_DESCR": oUsers[i].CRMRoleDesc,
							"WEBSITE": ""
						};
						oPartiesInvolved.push(obj);
					}
				}
				oppoData.PartiesInvolved = oPartiesInvolved;
				oStorageModel.setProperty("/aNonVATTeam", oPartiesInvolved);
				//clearing NON-VAT Data for the next cycle of selection
				oStorageModel.setProperty("/oSelectedNonVATOppData", {});
				OpportunityService.getServiceToPostOpportunityData(oppoData).then((oResponse) => {
					successFn();
				}).catch((oError) => {
					successFn("HARMONY_SERVER_DOWN", oError);
				});
			},

			//Function to get Opportunity Owner 
			fnGetOpportunityOwner: function (ActivityId, SlId, ResultData, successfn) {
				let OppoVATTeamModel = this.self.getModel(Actions.oModels.OppoVATTeamModel);
				let OppoOwner = OppoVATTeamModel.getProperty("/OppoOwner");
				let oTempObj = {
					SlId: SlId,
					OppoOwner: OppoOwner,
					successfn: successfn,
					ActivityId: ActivityId,
					ResultData: ResultData
				};
				if (OppoOwner) {
					this.getActTeamUserPartnerId("", "", "", oTempObj);
				} else {
					//Error message Owner BP ID is not available
				}
			},

			//Function to save VAT team addes users for email notification 
			fnSaveOppoVATTeamMembers: function (ActivityId, SlId, ResultData, successfn, OppoOwner) {
				let oTempArr = [];
				let OppoVATTeamModel = this.self.getModel(Actions.oModels.OppoVATTeamModel);
				let OppoID = OppoVATTeamModel.getProperty("/OppoID");
				let oNoAccessUsrs = OppoVATTeamModel.getProperty("/InitNoAccessUsers");
				for (let i = 0; i < oNoAccessUsrs.length; i++) {
					if (!oNoAccessUsrs[i]["IsDuplicate"]) {
						let oTempObj = {
							"SlId": SlId,
							"OppOwnerId": OppoOwner,
							"ActivityId": ActivityId,
							"OpportunityId": OppoID,
							"UserId": oNoAccessUsrs[i]["ID"],
							"UserAddedAt": new Date().toJSON().split(".")[0] + "Z"
						};
						oTempArr.push(oTempObj);
					}
				}
				let oPayload = {
					to_team: oTempArr,
					OpportunityId: OppoID
				};
				OpportunityService.getServiceToSaveOppVAT(oPayload).then((oResponse) => {
					successfn(ResultData);
				}).catch(() => {
					successfn(ResultData, true);
				});
			},

			//function to set selected Opp for VAT TEAM Submit
			fnSetSelectedOppDataForVATTeam: function (selectedOpp, obj) {
				selectedOpp.GUID = obj.Guid;
				selectedOpp.OPPT_ID = obj.OpportunityId;
				selectedOpp.CHANGED_AT = obj.ChangedAt;
				selectedOpp.EXPECT_END = new Date(obj.ExpectedEnd);
				return selectedOpp;
			},

			//function to handle NON-VAT Opportunity Submit
			fnHandleNonVATOppSubmit: function (oNoAccessUsrs, OpportunityId, successFn, aNonVATKeys, oSelectedNonVATOppData) {
				let selectedOpp = {};
				let validationCount = 0;
				let OppoVATTeamModel = this.self.getModel(Actions.oModels.OppoVATTeamModel);
				let aValidationKeys = ["Guid", "OpportunityId", "ChangedAt", "ExpectedEnd", "Owner"];
				aValidationKeys.map((keys) => {
					if (aNonVATKeys.indexOf(keys) !== -1) {
						validationCount += 1;
					}
				});
				if (validationCount === aValidationKeys.length) {
					selectedOpp = this.fnSetSelectedOppDataForVATTeam(selectedOpp, oSelectedNonVATOppData);
					OppoVATTeamModel.setProperty("/OppoID", oSelectedNonVATOppData.OpportunityId);
					OppoVATTeamModel.setProperty("/OppoOwner", oSelectedNonVATOppData.Owner);
					OppoVATTeamModel.setProperty("/OppoLookUp", selectedOpp);
					this.fnSendActTeamUser(oNoAccessUsrs, OpportunityId, successFn, 0);
				} else {
					//TO BE DISCUSSED //TODO
				}
			}
		};
	});