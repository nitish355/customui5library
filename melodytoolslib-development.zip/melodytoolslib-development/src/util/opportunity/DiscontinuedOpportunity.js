sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/json/JSONModel",
	"com/melody/lib/enum/Actions",
	"com/melody/lib/service/OpportunityService",
	"sap/ui/core/Fragment",
	"sap/m/MessageToast",
	"sap/ui/model/resource/ResourceModel",
	"com/melody/lib/util/opportunity/VATTeam"
], function (Object, JSONModel, Actions, OpportunityService, Fragment, MessageToast, ResourceModel, VATTeam) {
	"use strict";

	return {

		//function to initialize this.self to parent pointer "this"
		fnStaticInit: function (oParentRef) {
			//self points to the parent controller
			this.self = oParentRef;
		},

		//function to get Discontinued Opp
		getDiscontinuedOpp: async function (aUserActivities, fnCallback) {
			if (!Array.isArray(aUserActivities) || !aUserActivities.length) {
				return;
			}
			// Get unique Opportunity IDs
			const aOppIds = [...new Set(aUserActivities.map(opp => opp.OpportunityId).filter(Boolean))];
			if (!aOppIds.length) {
				return;
			}
			const oParameters = {
				urlParameters: {
					$select: Actions.OpportunityTeamUrlParm.select,
					$expand: Actions.OpportunityTeamUrlParm.expand
				}
			};
			try {
				const aResponses = await Promise.all(
					aOppIds.map(sOppId =>
						OpportunityService.getOpportunityTeam(sOppId, oParameters)
					)
				);
				const aResults = aResponses.map(oResult => oResult?.data).filter(oData => oData && oData.OPPT_ID);
				if (aResults.length) {
					this.getDiscontOppResults(aResults, fnCallback);
				}
			} catch (oError) {
				console.error("getDiscontinuedOpp failed:", oError);
			}
		},

		getDiscontOppResults: function (aOpp, fnCallback) {
			const oPrerequisiteModel = this.self.getModel("PrerequisiteModel");
			const aUserActivities = oPrerequisiteModel.getProperty("/UserActivities") || [];
			const mDiscontinuedOpp = aOpp
				.filter(oOpp => oOpp.STATUS === "E0002")
				.reduce((mMap, oOpp) => {
					mMap[oOpp.OPPT_ID] = oOpp;
					return mMap;
				}, {});

			const aDiscontinuedActivities = aUserActivities.reduce((aResult, oActivity) => {
				const oDiscontinuedOpp = mDiscontinuedOpp[oActivity.OpportunityId];
				if (!oDiscontinuedOpp) {
					return aResult;
				}
				const sReplacedBy = (oDiscontinuedOpp.REPLACED_BY || "").replace(/^0+/, "");
				if (sReplacedBy && oActivity.OpportunityId !== sReplacedBy) {
					aResult.push({
						...oActivity,
						NewOppId: sReplacedBy,
						AccountName: oDiscontinuedOpp.ACCOUNT_NAME,
						hasParallelOpp: true,
						selected: true
					});
				}
				else if (!sReplacedBy) {
					aResult.push({
						...oActivity,
						NewOppId: "",
						AccountName: oDiscontinuedOpp.ACCOUNT_NAME,
						hasParallelOpp: false,
						selected: false
					});
				}
				return aResult;
			}, []);

			this.setDiscontinuedOppData(aDiscontinuedActivities, fnCallback);
		},

		//function to set Discontinued Opp Data
		setDiscontinuedOppData: function (discontinuedOpp, callbackFn) {
			const oPrerequisiteModel = this.self.getModel("PrerequisiteModel");
			oPrerequisiteModel.setProperty("/DiscontOppData", discontinuedOpp);
			oPrerequisiteModel.refresh(true);
			this.fnHandleDiscontinuedOppSuccess();
		},

		//function to handle discontinued Opp Success
		fnHandleDiscontinuedOppSuccess: async function () {
			const oModel = this.self.getModel("PrerequisiteModel");
			const oMessageManager = sap.ui.getCore().getMessageManager();
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			oMessageManager?.removeAllMessages();
			const aDiscontOppData = oModel.getProperty("/DiscontOppData") || [];
			if (!aDiscontOppData.length) {
				oStorage.put("pcDiscontinuedOppInitCall", true);
				return;
			}
			// Fetch status actions
			const oResponse = await OpportunityService.getDiscOppStatusAction();
			oModel.setProperty("/DiscOppStatusAction", oResponse?.data?.results || []);

			// Lazy load dialog once
			if (!this.self.discntOppDialog) {
				const oDialog = await Fragment.load({
					id: "_DiscontinuedOppFragment",
					name: "com.melody.lib.fragments.DiscontinuedOpportunity",
					controller: this
				});

				oDialog.setModel(oModel, "PrerequisiteModel");
				const i18nModel = new ResourceModel({ bundleName: "com.melody.lib.i18n.i18n" });
				oDialog.setModel(i18nModel, "i18n");
				this.self.addDependent(oDialog);
				this.self.discntOppDialog = oDialog;
			}
			this.fnOpenDisContinuedOppotunities(true);
			oStorage.put("pcDiscontinuedOppInitCall", true);
		},

		//Function to open Dis-Continued Opportunities Pop-Up
		fnOpenDisContinuedOppotunities: function (bVal) {
			const oModel = this.self?.getModel("PrerequisiteModel");
			const oDialog = this.self?.discntOppDialog;
			// If model exists, manage state via model flag
			if (oModel) {
				const bIsOpen = oModel.getProperty("/isDiscntOppDialogOpen");
				if (bIsOpen === bVal) {
					return;
				}
				oModel.setProperty("/isDiscntOppDialogOpen", bVal);
			}
			// Open dialog if required
			if (bVal) {
				oDialog?.open();
			}
		},

		fnGetSelectedOppoDetails: function (oEvent) {
			const oSource = oEvent.getSource();
			const oContext = oSource?.getParent()?.getBindingContext("PrerequisiteModel");
			if (!oContext) {
				return;
			}
			const oModel = oContext.getModel();
			const sPath = oContext.getPath();
			const sNewOppId = oSource?.getSelectedOpportunity()?.OpportunityId || "";
			oModel.setProperty(`${sPath}/NewOppId`, sNewOppId);
			oModel.setProperty(`${sPath}/selected`, Boolean(sNewOppId));
		},

		getGroupCategory: function (oContext) {
			return {
				key: oContext.getProperty("OpportunityId"),
				text: oContext.getProperty("AccountName")
			};
		},

		getOppGroup: function (oContext) {
			const sOppId = oContext.getProperty("OpportunityId");
			const sAccountName = oContext.getProperty("AccountName");
			return {
				key: sOppId,
				text: "Discontinued Opportunity: " + sOppId + " (" + sAccountName + ")"
			};
		},

		getDiscOppGroupHeader: function (oGroup) {
			return new sap.m.GroupHeaderListItem({
				title: "Discontinued Opp: " + oGroup.text + " (" + oGroup.key + ")"
			});
		},

		//function to handle update discontinued 
		onUpdateDiscontOpp: async function () {
			const oTable = this.fnGetDialogUsingId("_DiscontinuedOppFragment", "idDiscontOppTable");
			const aSelectedPaths = oTable.getSelectedContextPaths();
			if (!aSelectedPaths.length) {
				this.self.discntOppDialog.close();
				return;
			}
			const oModel = oTable.getModel("PrerequisiteModel");
			const aPromises = [];
			const aUpdatedOpps = [];
			aSelectedPaths.forEach((sPath) => {
				const oData = oModel.getContext(sPath).getObject();
				if (!oData.NewOppId) {
					return;
				}
				const oPayload = {
					...oData,
					ActionId: oData.ActionId ? oData.ActionId : "001"
				};
				delete oPayload.AccountName;
				delete oPayload.to_slact;
				delete oPayload.__metadata;
				delete oPayload.hasParallelOpp;
				delete oPayload.selected;
				aUpdatedOpps.push(oPayload);
				aPromises.push(OpportunityService.updateDisconntiunedOpportunities(oPayload.GUID, oPayload));
			});
			if (!aPromises.length) {
				this.self.discntOppDialog.close();
				return;
			}
			try {
				await Promise.all(aPromises);
				// Link to Harmony for Parallel Opportunities
				VATTeam.fnParallelOpppLinkSlToHarmony($.extend(true, [], aUpdatedOpps));
				MessageToast.show("Updated successfully");

			} catch (oError) {
				MessageToast.show("DISCONTINUED OPP POST ERROR.");
				console.error("ERROR :", oError);
			} finally {
				this.self.discntOppDialog.close();
			}
		},

		//function to close discontinued frag
		onCancelDiscontOpp: function () {
			this.self.discntOppDialog.close();
			this.fnOpenDisContinuedOppotunities(false);
		},

		//function to get element from fragment using id
		fnGetDialogUsingId: function (dialogId, contentId) {
			return sap.ui.core.Fragment.byId(dialogId, contentId);
		}
	};
});