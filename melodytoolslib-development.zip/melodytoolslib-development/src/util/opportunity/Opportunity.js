sap.ui.define([
	"sap/ui/model/Filter",
	"sap/ui/core/Fragment",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"com/melody/lib/enum/Actions",
	"com/melody/lib/util/mtr/MTRModels",
	"com/melody/lib/model/StorageModel",
	"com/melody/lib/util/opportunity/VATTeam",
	"com/melody/lib/util/opportunity/MSLExists",
	"com/melody/lib/service/OpportunityService",
	"com/melody/lib/classes/Opportunity/Opportunity",
	"com/melody/lib/util/opportunity/OpportunityHelper",
	"com/melody/lib/util/opportunity/DiscontinuedOpportunity",
	"com/melody/lib/service/CPIService"
], function (Filter, Fragment, FilterOperator, JSONModel, Actions, MTRModels, oStorageModel, VATTeam, MSLExistUtil, OpportunityService,
	Opportunity, OpportunityHelper, DiscontinuedOpportunity, CPIService) {
	"use strict";
	return {
		fnStaticInit: async function (oParentRef) {
			//self points to the parent controller
			this.opportunityCtrl = oParentRef;
			try {
				let oOpportunityInstance = new Opportunity();
				let oDefault = oOpportunityInstance.setDefault();
				let cvaDataObj = {
					accounts: [],
					bClearIconVisible: false,
					bShowOppInfoPopup: false,
					isAccountDialogBusy: false,
				}
				this.opportunityCtrl.getModel().setProperty("/", oDefault);
				this.opportunityCtrl.getModel("PrerequisiteModel").setData(cvaDataObj, true);
				VATTeam.fnStaticInit(oParentRef);
				this.opportunityCtrl.MSLExistUtil.fnStaticInit(oParentRef);
				this.opportunityCtrl.OpportunityHelper.fnStaticInit(oParentRef);
				this.opportunityCtrl.DiscontinuedOpportunity.fnStaticInit(oParentRef);
				if (!oParentRef.DialogController) {
					oParentRef.DialogController = new com.melody.lib.util.opportunity.OpportunityDialogController(oParentRef);
					// oParentRef.DialogController = new OpportunityDialogController(oParentRef);
					oParentRef.DialogController.fnLoadLangModel = this.opportunityCtrl.OpportunityHelper.fnLoadResourceBundle;
				}
				const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				if (!oStorage.get("oConstants")) {
					this.getConstantData();
				}
				await this.getOppMasterData();
				// const oModel = this.opportunityCtrl.getModel();
				// const aActiveOpp = oStorage.get("ActiveOpportunities");
				// const aActiveOppCounts = oStorage.get("ActiveOppCountProps");
				// if (aActiveOppCounts && aActiveOpp) {
				// 	oModel.setProperty("/ActiveOppCountProps", aActiveOppCounts);
				// 	oModel.setProperty("/ActiveOpportunities", aActiveOpp);
				// 	oModel.refresh();
				// }

			} catch (oError) {

			}
		},

		//Fuction to set the visiblity of clear btn //TODO:Need to check which data
		fnSetOpportunityClearBtn: function (showClear) {
			const oPrerequisiteModel = that.getModel(Actions.oModels.PrerequisiteModel);
			oPrerequisiteModel.setProperty("/bClearIconVisible", showClear); //CLEARICONCHECK
		},

		getOppMasterData: async function () {
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let oOppStatusMap = oStorage.get("pcOppStatusMasterMapCPI") || {};
			let oOppQuarterMap = oStorage.get("pcOppQuarterMasterMapCPI") || {};
			if (!Object.keys(oOppStatusMap).length || !Object.keys(oOppQuarterMap).length) {
				await this.getAppValueHelps();
				oOppStatusMap = oStorage.get("pcOppStatusMasterMapCPI");
				oOppQuarterMap = oStorage.get("pcOppQuarterMasterMapCPI");
			}
			const oModel = this.opportunityCtrl.getModel();
			const aOppStatus = Object.values(oOppStatusMap);
			oModel.setProperty("/OppStatusMasterData", aOppStatus);
			const aDefaultStatusKeys = aOppStatus.filter(item => item.PARAM2 === "X").map(item => item.KEY);
			let authorizedStatusMap = new Map(aOppStatus.filter(item => item.PARAM1 === "X").map(item => [item.KEY, item]));
			oModel.setProperty("/OppStatusFilterKeys", aDefaultStatusKeys);
			oModel.setProperty("/NonVatOppStatusFilterKeys", aDefaultStatusKeys);
			if (this.opportunityCtrl.getApplicationType() === "MR") {
				//config opp status for MR Applicatopn
				let aMRActiveStatus = this.opportunityCtrl.getModel("appConstants").getProperty("/OpportunityStatus").filter(item => item.Operational_Status),
					oMRauthorizedStatusMap = new Map(aOppStatus.filter(item => aMRActiveStatus.filter(status => status.Value === item.KEY).length).map(item => [item.KEY, item]));
				oModel.setProperty("/AuthorizedOppStatusMap", oMRauthorizedStatusMap);
			} else if (this.opportunityCtrl.getApplicationType() === "DISC_OPP") {
				const aAuthStatusKeys = ["E0001", "E0007"];
				authorizedStatusMap = new Map(aOppStatus.filter(item => aAuthStatusKeys.includes(item.KEY)).map(item => [item.KEY, item]));
				oModel.setProperty("/AuthorizedOppStatusMap", authorizedStatusMap);
			}
			else {
				oModel.setProperty("/AuthorizedOppStatusMap", authorizedStatusMap);
			}
			oModel.setProperty("/IsFavourite", "NO");
			oModel.setProperty("/IsFavouriteNonVat", "NO");

			const aOppQuarter = Object.values(oOppQuarterMap);
			oModel.setProperty("/QuarterMasterData", aOppQuarter);
			const oDefaultQuarter = aOppQuarter.find(item => item.PARAM2 === "X");
			oModel.setProperty("/QuarterFilterId", oDefaultQuarter?.KEY);
			oModel.setProperty("/NonVatQuarterFilterId", oDefaultQuarter?.KEY);

			oModel.setProperty("/ActiveOppSearchValue", "");

		},

		getStatus: async function () {
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let oOppStatusMap = oStorage.get("pcOppStatusMasterMapCPI");
			if (!oOppStatusMap) {
				await this.getAppValueHelps();
				oOppStatusMap = oStorage.get("pcOppStatusMasterMapCPI");
			}
			const oModel = this.opportunityCtrl.getModel();
			const aOppStatus = Object.values(oOppStatusMap);
			oModel.setProperty("/OppStatusMasterData", aOppStatus);
			const aDefaultStatusKeys = aOppStatus.filter(item => item.PARAM2 === "X").map(item => item.KEY);
			const authorizedStatusMap = new Map(aOppStatus.filter(item => item.PARAM1 === "X").map(item => [item.KEY, item]));
			oModel.setProperty("/OppStatusFilterKeys", aDefaultStatusKeys);
			oModel.setProperty("/AuthorizedOppStatusMap", authorizedStatusMap);
			oModel.setProperty("/IsFavourite", "NO");
			oModel.refresh();
			return oOppStatusMap;
		},

		getPhases: async function () {
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let aOppPhases = oStorage.get("pcOppPhaseMasterMapCPI");
			if (!aOppPhases) {
				await this.getAppValueHelps();
				aOppPhases = oStorage.get("pcOppPhaseMasterMapCPI");
			}
			// return aOppPhases;
		},

		getQuarters: async function () {
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let oOppQuarterMap = oStorage.get("pcOppQuarterMasterMapCPI");
			if (!oOppQuarterMap) {
				await this.getAppValueHelps();
				oOppQuarterMap = oStorage.get("pcOppQuarterMasterMapCPI");
			}
			const oModel = this.opportunityCtrl.getModel();
			const aOppQuarter = Object.values(oOppQuarterMap);
			oModel.setProperty("/QuarterMasterData", aOppQuarter);

			const oDefaultQuarter = aOppQuarter.find(item => item.PARAM2 === "X");
			oModel.setProperty("/QuarterFilterId", oDefaultQuarter?.KEY);
			// "CURR_YEAR"
			oModel.refresh();
			// return oOppQuarterMap;
		},

		getAppValueHelps: async function () {
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			const oResult = await CPIService.getAppValueHelps();
			const aResults = oResult?.data?.results || [];
			const oStatusMasterDataMap = {},
				oPhaseMasterDataMap = {},
				oQuarterMasterDataMap = {};
			aResults.forEach(function (status) {
				switch (status.FIELD_NAME) {
					case "STATUS":
						oStatusMasterDataMap[status.KEY] = status;
						break;
					case "PHASE":
						oPhaseMasterDataMap[status.KEY] = status;
						break;
					case "QUARTER_ID":
						oQuarterMasterDataMap[status.KEY] = status;
						break;
					default:
						break;
				}
			});
			oStorage.put("pcOppStatusMasterMapCPI", oStatusMasterDataMap);
			oStorage.put("pcOppPhaseMasterMapCPI", oPhaseMasterDataMap);
			oStorage.put("pcOppQuarterMasterMapCPI", oQuarterMasterDataMap);
		},

		/*
		* Old Code
		*Commented if in case needed
		getAppValueHelps: async function () {
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			// const oResult = await OpportunityService.getAppValueHelps();
			const oResult = await CPIService.getAppValueHelps();
			const oData = oResult.data;
			const oStatusMasterDataMap = {},
				oPhaseMasterDataMap = {},
				oQuarterMasterDataMap = {};

			oData.results.forEach(function (status) {
				switch (status.FIELD_NAME) {
					case "STATUS":
						oStatusMasterDataMap[status.KEY] = status;
						break;
					case "PHASE":
						oPhaseMasterDataMap[status.KEY] = status;
						break;
					case "QUARTER_ID":
						oQuarterMasterDataMap[status.KEY] = status;
						break;
					default:
						break;
				}
			});
			oStorage.put("pcOppStatusMasterMap", oStatusMasterDataMap);
			oStorage.put("pcOppPhaseMasterMap", oPhaseMasterDataMap);
			oStorage.put("pcOppQuarterMasterMap", oQuarterMasterDataMap);
		},/*

		/*getAppValueHelps: async function () {
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let oThisController = this;
			let sFilter = "?$filter=(ENTITY_NAME eq 'OPPORTUNITY' and (FIELD_NAME eq 'STATUS' or FIELD_NAME eq 'PHASE' or FIELD_NAME eq 'QUARTER_ID'))";
			let sFinalURL = "/btp/v2/appvalues/AppValueHelps";
			sFinalURL = sFinalURL + sFilter;
			$.ajax({
				url: sFinalURL,
				method: "GET",
				async: false,
				contentType: "application/json",
				success: function (oResponse) {
					// console.log(oResponse);
					var aResults = oResponse.d.results || [];
					const oStatusMasterDataMap = {},
						oPhaseMasterDataMap = {},
						oQuarterMasterDataMap = {};
					aResults.forEach(function (status) {
						switch (status.FIELD_NAME) {
							case "STATUS":
								oStatusMasterDataMap[status.KEY] = status;
								break;
							case "PHASE":
								oPhaseMasterDataMap[status.KEY] = status;
								break;
							case "QUARTER_ID":
								oQuarterMasterDataMap[status.KEY] = status;
								break;
							default:
								break;
						}
					});
					oStorage.put("pcOppStatusMasterMap", oStatusMasterDataMap);
					oStorage.put("pcOppPhaseMasterMap", oPhaseMasterDataMap);
					oStorage.put("pcOppQuarterMasterMap", oQuarterMasterDataMap);
				},
				error: function (oError) {
					jQuery.sap.log(oError);
				}
			});
		},*/

		getUserDetail: async function () {
			const oResult = await OpportunityService.getUserDetail();
			return oResult.data.results[0];
		},

		getBusinessPartner: async function (userId) {
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let PartnerId = oStorage.get("PartnerId");
			if (PartnerId) {
				return PartnerId;
			}
			let sUserId = userId;
			if (!sUserId) {
				const oUser = await this.getUserDetail();
				sUserId = oUser.UserId;
			}
			const aFilters = [
				new Filter("TYPE", FilterOperator.EQ, "E")
			];
			const oResult = await OpportunityService.getBusinessPartners(sUserId, aFilters);
			const oData = oResult.data;
			PartnerId = oResult.data.results[0].PARTNER;
			oStorage.put("PartnerId", PartnerId);
			return PartnerId;
		},

		//function to get Opportunities count
		getOpportunitiesCount: async function (aBatches) {
			const response = await OpportunityService.getOpportunityCount(aBatches);
			let count = (response && "data" in response) ? Number(response.data) : 0;
			return count;
		},

		getOpportunities: async function (mParameters) {
			const oModel = this.opportunityCtrl.getModel();
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			const aBatches = [];
			const mtrSettings = MTRModels.getMTRSettingsModel() || false;
			let oOppStatusMasterMap = oStorage.get("pcOppStatusMasterMap") || {};
			let oOppPhaseMasterMap = oStorage.get("pcOppPhaseMasterMap") || {};
			let aLibOpportunties = oStorage.get("pcLibOpportunties") || [];
			let sPartnerId = (mParameters) ? mParameters.PartnerId : null;
			let bActiveOnly = (mParameters) ? mParameters.ActiveOnly : null;
			let iLastYearCount = (mParameters && mParameters.LastYearCount) ? parseInt(mParameters.LastYearCount, 10) : null;

			//Check for existing data
			if (aLibOpportunties.length) {
				return aLibOpportunties;
			}

			if (!sPartnerId) {
				sPartnerId = await this.getBusinessPartner();
			}

			if (!sPartnerId) {
				return [];
			}
			const oBusinessPartnerFilter = new Filter("SALES_TEAM_MEMBER", FilterOperator.EQ, sPartnerId);
			const aStatusFilters = [];
			if (bActiveOnly !== false) {
				aStatusFilters.push(new Filter({
					filters: [
						new Filter({
							path: "STATUS",
							operator: FilterOperator.EQ,
							value1: "E0007"
						}),
						new Filter({
							path: "STATUS",
							operator: FilterOperator.EQ,
							value1: "E0001"
						})
					],
					and: false
				}));
			}

			if (iLastYearCount) {
				let iCurrentYear = new Date().getFullYear();
				const aQuarterFilters = [];
				iCurrentYear = iCurrentYear - 1;
				for (let i = 1; i <= iLastYearCount; i++) {
					const oQuarterFilter = new Filter("QUARTER_ID", FilterOperator.EQ, iCurrentYear + "0");
					const aFilters = [
						new Filter({
							filters: [oBusinessPartnerFilter, oQuarterFilter, ...aStatusFilters],
							and: true
						})
					];
					aBatches.push({
						Filters: aFilters
					});
					iCurrentYear++;
				}
			} else {
				const aFilters = [
					new Filter({
						filters: [oBusinessPartnerFilter, ...aStatusFilters],
						and: true
					})
				];
				aBatches.push({
					Filters: aFilters,
					parameters: {
						$select: Actions.GetOpportunityUrlParam.select
					}
				});
			}
			let promises = [];
			let aOpptData = [];
			const batchCount = 20;
			let startIndex = 0;
			let aBatchResponses = [];
			const totalCount = await this.getOpportunitiesCount(aBatches);
			const batches = Math.ceil(totalCount / batchCount);
			for (let i = 0; i < batches; i++) {
				let skip = 0;
				aBatches[0].parameters.$top = batchCount;
				if (i !== 0) {
					skip = startIndex + batchCount;
				}
				startIndex = skip;
				aBatches[0].parameters.$skip = skip;
				promises.push(OpportunityService.getOpportunities(aBatches));
			}

			const responses = await Promise.all(promises);
			if (!responses || !responses.length) {
				return [];
			}

			aBatchResponses = responses.map((response) => {
				return response.data.__batchResponses[0];
			});

			for (let i = 0; i < aBatchResponses.length; i++) {
				if (aBatchResponses[i].data && aBatchResponses[i].data.hasOwnProperty("results")) {
					const aBatchResult = aBatchResponses[i].data.results;
					var aBatchOpportunities = aBatchResult.map(function (opp) {
						return new Opportunity({
							OpportunityId: opp.OPPT_ID,
							OpportunityName: opp.DESCRIPTION,
							Description: opp.DESCRIPTION,
							AccountId: opp.ACCOUNT,
							AccountName: opp.ACCOUNT_NAME,
							Status: opp.STATUS,
							Phase: opp.CURR_PHASE,
							ExpectedEnd: opp.EXPECT_END,
							ExpectedValue: opp.EXPECTED_VALUE,
							Owner: opp.OWNER,
							OwnerName: opp.OWNER_NAME,
							Industry_MasterCode_Text: opp.INDUSTRY_MASTERCODE_TEXT,
							Industry: opp.INDUSTRY,
							Industry_Text: opp.INDURSTRY_TEXT,
							Sales_Org_Desc: opp.SALES_ORG_TEXT,
							Industry_MasterCode: opp.INDUSTRY_MASTERCODE,
							Guid: opp.GUID,
							ChangedAt: opp.CHANGED_AT,
							StatusDescription: (Object.keys(oOppStatusMasterMap).length && opp.STATUS) ? oOppStatusMasterMap[opp.STATUS].VALUE : "",
							PhaseValue: (Object.keys(oOppPhaseMasterMap).length && opp.CURR_PHASE) ? oOppPhaseMasterMap[opp.CURR_PHASE].VALUE : "",
						})
					});
					aOpptData = aOpptData.concat(aBatchOpportunities);
				}
			}

			//TODO find better approach to ignore model object
			let aTempOpptData = aOpptData.map((opp) => {
				return {
					...opp,
					model: ""
				}
			});
			if (mtrSettings) {
				mtrSettings.setProperty("/actOpportunities", aTempOpptData);
			}
			let aActiveOppData = await this.opportunityCtrl.OpportunityHelper.fnSetActiveOpportunity(aTempOpptData);
			oStorage.put("pcLibOpportunties", aTempOpptData);
			oModel.setProperty("/actOpportunities", aActiveOppData);
			oModel.refresh();
			return aOpptData
		},

		fetchFilteredActiveOpportunities: async function () {
			let oModel = this.opportunityCtrl.getModel();
			oModel.setProperty("/ActiveOppCountProps", {
				oppData: [],
				pageSize: 10,
				loadedCount: 0,
				totalCount: 0,
				loading: false,
				hasMore: true,
				filter: "",
				countFetched: false,
				showMoreText: ""
			});
			await this._loadMoreActiveOppData();
		},

		_loadMoreActiveOppData: async function (bIsOppIdSearch, sQuery) {
			const oModel = this.opportunityCtrl.getModel();
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let sPartnerId = oStorage.get("PartnerId");
			let aOppStatusKeys = oModel.getProperty("/OppStatusFilterKeys");
			// if (!Array.isArray(aOppStatusKeys) || !aOppStatusKeys.length) {
			// 	aOppStatusKeys = ["E0001", "E0007"];
			// }
			let sQuarterId = oModel.getProperty("/QuarterFilterId") || "CURR_YEAR";
			let bIsFavourite = oModel.getProperty("/IsFavourite") === "YES";
			let oCounts = oModel.getProperty("/ActiveOppCountProps");
			let pageSize = oCounts.pageSize;
			let loadedCount = oCounts.loadedCount;
			let totalOppCount = oCounts.totalCount;
			let aPromises = [];
			let aFilters = [];
			let aOpptData = [];

			oModel.setProperty("/isOpptDilogBusy", true);
			this.opportunityCtrl?.setInputBusy(true);
			// for (let i = 0; i < aPartnerId.length; i++) {
			// let sPartnerId = aPartnerId[i].PARTNER;

			//not required for cpi service
			if (!sPartnerId) {
				sPartnerId = await this.getBusinessPartner();
			}

			let oPartnerFilter = new Filter({
				path: "SALES_TEAM_MEMBER",
				operator: "EQ",
				value1: sPartnerId,
			});
			aFilters.push(oPartnerFilter);

			let oQuarterFilter = new Filter("QUARTER_ID", FilterOperator.EQ, sQuarterId);
			aFilters.push(oQuarterFilter);

			if (aOppStatusKeys?.length) {
				let aStatusFilter = aOppStatusKeys.map((value) => {
					return new sap.ui.model.Filter({
						path: "STATUS",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: value
					});
				});

				//Combine all filters with OR condition
				let oStatusFilter = new sap.ui.model.Filter({
					filters: aStatusFilter,
					and: false
				});
				aFilters.push(oStatusFilter);
			}

			if (bIsOppIdSearch) {
				let oOppIdFilter = new Filter("OPPT_ID", FilterOperator.EQ, sQuery);
				aFilters.push(oOppIdFilter);
			}
			if (bIsFavourite) {
				let oFavouriteFilter = new Filter("IS_FAVORITE", FilterOperator.EQ, bIsFavourite);
				aFilters.push(oFavouriteFilter);
			}

			let aForeCast = ["1", "2", "3", "4", "5", "6"];
			let aForeCastFilter = aForeCast.map((value) => {
				return new Filter({
					path: "FORECAST",
					operator: FilterOperator.EQ,
					value1: value
				});
			});
			let oForeCastFilter = new sap.ui.model.Filter({
				filters: aForeCastFilter,
				and: false
			});
			aFilters.push(oForeCastFilter);

			sQuery = (sQuery && sQuery.trim()) ? sQuery : (oModel.getProperty("/ActiveOppSearchValue") || "");

			let mParams = {
				Filters: [
					new Filter({
						filters: aFilters,
						and: true,
					}),
				],
				parameters: {
					"search-focus": "ACCOUNT",
					search: sQuery,
					$skip: loadedCount,
					$top: pageSize,
					$select: Actions.GetOpportunityUrlParam.select,
				},
			};
			const aParam = ["search-focus", "search"];
			const aCounts = ["$skip", "$top"];
			if (sQuery) {
				aCounts.forEach(key => delete mParams.parameters[key]);
				if (bIsOppIdSearch) {
					aParam.forEach(key => delete mParams.parameters[key]);
				}
			} else {
				aParam.forEach(key => delete mParams.parameters[key]);
			}

			if (!oCounts.countFetched) {
				/*let response;
				if (bIsFavourite) {
					response = await OpportunityService.getOpportunityCount([mParams]);
				} else {
					response = await CPIService.getOpportunityCount([mParams]);
				}*/
				let response = await OpportunityService.getOpportunityCount([mParams]);
				totalOppCount = (response && "data" in response) ? Number(response.data) : 0;
			}
			/*if (bIsFavourite) {
				aPromises.push(OpportunityService.getOpportunities([mParams]));
			} else {
				aPromises.push(CPIService.getOpportunities([mParams]));
			}*/
			aPromises.push(OpportunityService.getOpportunities([mParams]));

			var aResponse = await Promise.all(aPromises);
			if (!aResponse || !aResponse.length) {
				return [];
			}

			let aBatchResponses = aResponse.map((response) => {
				return response.data.__batchResponses[0];
			});

			let oOppStatusMasterMap = oStorage.get("pcOppStatusMasterMapCPI") || {};
			let oOppPhaseMasterMap = oStorage.get("pcOppPhaseMasterMapCPI") || {};
			let authorizedOppStatusMap = oModel.getProperty("/AuthorizedOppStatusMap");

			for (let i = 0; i < aBatchResponses.length; i++) {
				if (aBatchResponses[i].data && aBatchResponses[i].data.hasOwnProperty("results")) {
					const aBatchResult = aBatchResponses[i].data.results;
					var aBatchOpportunities = aBatchResult.map(function (opp) {
						return new Opportunity({
							OpportunityId: opp.OPPT_ID,
							OpportunityName: opp.DESCRIPTION,
							Description: opp.DESCRIPTION,
							AccountId: opp.ACCOUNT,
							AccountName: opp.ACCOUNT_NAME,
							Status: opp.STATUS,
							Phase: opp.CURR_PHASE,
							ExpectedEnd: opp.EXPECT_END,
							ExpectedValue: opp.EXPECTED_VALUE,
							Owner: opp.OWNER,
							OwnerName: opp.OWNER_NAME,
							Industry_MasterCode_Text: opp.INDUSTRY_MASTERCODE_TEXT,
							Industry: opp.INDUSTRY,
							Industry_Text: opp.INDURSTRY_TEXT,
							Sales_Org_Desc: opp.SALES_ORG_TEXT,
							Industry_MasterCode: opp.INDUSTRY_MASTERCODE,
							Guid: opp.GUID,
							ChangedAt: opp.CHANGED_AT,
							StatusDescription: (Object.keys(oOppStatusMasterMap).length && opp.STATUS) ? oOppStatusMasterMap[opp.STATUS].VALUE : "",
							PhaseValue: (Object.keys(oOppPhaseMasterMap).length && opp.CURR_PHASE) ? oOppPhaseMasterMap[opp.CURR_PHASE].VALUE : "",
							Favourite: opp.IS_FAVORITE,
							InternalOrder1: opp.INTERNAL_ORDER1,
							InternalOrder2: opp.INTERNAL_ORDER2,
							Authorized: authorizedOppStatusMap?.has(opp.STATUS) || false,
						})
					});
					aOpptData = aOpptData.concat(aBatchOpportunities);
				}
			}

			//TODO find better approach to ignore model object
			let aOppResponseData = aOpptData.map((opp) => {
				return {
					...opp,
					model: ""
				}
			});

			const updatedOppData = oCounts.oppData.concat(aOppResponseData);
			const newCount = updatedOppData.length;
			oModel.setProperty("/ActiveOppCountProps", {
				oppData: updatedOppData,
				pageSize: 10,
				loadedCount: newCount,
				totalCount: totalOppCount,
				loading: false,
				hasMore: (newCount < totalOppCount) && !sQuery,
				filter: "",
				countFetched: true,
				showMoreText: `Show More (${newCount} / ${totalOppCount})`
			});

			oModel.setProperty("/actOpportunities", updatedOppData);
			oModel.setProperty("/ActiveOpportunities", updatedOppData);
			// oStorage.put("ActiveOpportunities", updatedOppData);
			// oStorage.put("ActiveOppCountProps", oModel.getProperty("/ActiveOppCountProps"));
			this.opportunityCtrl?.setInputBusy(false);
			oModel.setProperty("/isOpptDilogBusy", false);
			oModel.refresh();

			// this.opportunityCtrl.updateDefaultModelData(oModel.getData());
			// return updatedOppData;
			// }
		},

		searchActiveOpportunities: function (sQuery) {
			const oModel = this.opportunityCtrl.getModel();
			oModel.setProperty("/ActiveOppCountProps/oppData", []);
			oModel.setProperty("/ActiveOppCountProps/countFetched", false);
			if (sQuery.trim()) {
				let isOppId = /^\d+$/.test(sQuery);
				if (isOppId) {
					this._loadMoreActiveOppData(isOppId, sQuery);
				} else {
					this._loadMoreActiveOppData(false, sQuery);
				}
			} else {
				this._loadMoreActiveOppData(false, sQuery);
			}
		},

		//Function to search Opportunity with AccountId/AccountDesc/OppoId/OppoDesc
		searchOpportunities: async function (Parameters) {
			let sUrl = Parameters.Url;
			const mParameters = this.fnGetServiceParameters(Parameters);
			const oResult = await OpportunityService.searchOpportunities(sUrl, mParameters);
			return oResult.data.results;
		},

		//Function to get Opportunity details //TODO: check this function
		fnGetOpportunitiesDetails: async function (Parameters) {
			const aBatches = [];
			let sUrl = Parameters.Url;
			const OpportunityIds = Parameters.OpportunityIds;
			for (let i = 0; i < OpportunityIds.length; i++) {
				const mParameters = this.fnGetServiceParameters(Parameters);
				aBatches.push({
					type: "read",
					parameters: mParameters,
					url: sUrl + "('" + OpportunityIds[i] + "')"
				});
			}
			let oResult = await OpportunityService.fnGetOpportunitiesDetails(sUrl, aBatches);
			oResult = this.fnProcessBatchResponses(oResult);
			return oResult;
		},

		//Function to form service parameters
		fnGetServiceParameters: function (Parameters) {
			let urlParameters = {};
			let sSelectQuery = (Parameters) ? Parameters.Select : "";
			sSelectQuery ? urlParameters["$select"] = sSelectQuery : "";
			let sExpandEntity = (Parameters) ? Parameters.Expand : "";
			sExpandEntity ? urlParameters["$expand"] = sExpandEntity : "";
			const aFilters = Parameters["Filters"];

			var mParameters = {};
			mParameters.urlParameters = urlParameters;
			aFilters ? aFilters.length ? mParameters.filters = aFilters : "" : "";
			return mParameters;
		},

		//Function to process batch responses

		fnProcessBatchResponses: function (oResult) {
			var oData = [];
			oResult = oResult.data.__batchResponses;
			oResult.filter(function (obj) {
				oData.push(obj.data);
			});
			return oData;
		},

		//function to set prerequisites opportunity valuehelp fragment
		fnOpportunityValueHelpHandler: async function (oProjectInstance, fnOpenDialogs, callback) {
			let sName = "";
			let oFnResponse = {};
			let aMasterPcOppList = [];
			let aMasterActOppList = [];
			const oModel = this.opportunityCtrl.getModel();
			let self = this;
			let isMSLExist = oModel.getProperty("/isMSLExist");
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let aStoragePcOppList = $.extend(true, [], oStorage.get("pcOpportunities"));
			let aStorageActOppList = $.extend(true, [], oStorage.get("actOpportunities"));
			// 
			let aModelPcOppList = $.extend(true, [], oModel.getProperty("/pcOpportunities"));
			let aModelActiveOppList = $.extend(true, [], oModel.getProperty("/actOpportunities"));
			// 
			/*let aMasterPcOppList = (aStoragePcOppList.length) ? aStoragePcOppList : aModelPcOppList;
			let aMasterActOppList = (aStorageActOppList.length) ? aStorageActOppList : aModelActiveOppList;*/
			let oActiveOppListControl;
			oModel.setProperty("/oppSearchValue", "");
			oModel.setProperty("/nonvatoppsearchvalue", "");
			oModel.setProperty("/NonVatOpportunitiesList", []);
			oModel.setProperty("/activeOppDialogDefaultIconTab", Actions.active_opportunities);
			if (oProjectInstance.bOpportunity) {

				if (!aMasterPcOppList.length && !aMasterActOppList.length) {

					oFnResponse.aPcOppList = await self.getOpportunities();
					oFnResponse.aActOppList = await this.opportunityCtrl.OpportunityHelper.fnSetActiveOpportunity(oFnResponse.aPcOppList);
					//TODO:check the opening
					oActiveOppListControl = this.fnGetDialogUsingId("_ActiveOpportunityDialog", "idActOpptList");

					if (oActiveOppListControl) {
						oActiveOppListControl.setGrowing(false);
						oActiveOppListControl.setGrowingThreshold(null);
					}

					if (oProjectInstance.CvaSelected) {
						if (oProjectInstance.CvaAccountId) {
							let aFilters = [];
							let sQuery = oProjectInstance.CvaAccountId;
							if (sQuery && sQuery.length > 0) {
								let filter = new sap.ui.model.Filter("AccountId", sap.ui.model.FilterOperator.EQ, sQuery);
								aFilters.push(filter);
							}
							if (oActiveOppListControl) {
								oActiveOppListControl.getBinding("items").filter(aFilters);
							}
						}
					}
				} else {

					let oOppData = await this.opportunityCtrl.OpportunityHelper.fnVATTeamOppDataHandler(aMasterPcOppList, aMasterActOppList);
					if (!oOppData.bProceed) {
						oFnResponse.aPcOppList = oOppData.aPcOppList || aMasterPcOppList;
						oFnResponse.aActOppList = oOppData.aActOppList || aMasterActOppList;
						return oFnResponse;
					}

					if (oProjectInstance.projectType === Actions.Actvt) {
						if (!aMasterActOppList.length && aMasterPcOppList.length) {
							aMasterActOppList = await this.opportunityCtrl.OpportunityHelper.fnSetActiveOpportunity(aMasterPcOppList, sViewName);
							oStorage.put("actOpportunities", aActOppList);
						}
						if (aMasterActOppList.length) {
							aMasterActOppList = await this.opportunityCtrl.OpportunityHelper.fnSetFormatActOppData(aMasterActOppList, sViewName);
						}
						oFnResponse.aActOppList = aMasterActOppList;

						if (oProjectInstance.CvaSelected) {
							if (oProjectInstance.CvaAccountId) {
								let aFilters = [];
								let sQuery = oProjectInstance.CvaAccountId;
								if (sQuery && sQuery.length > 0) {
									let filter = new sap.ui.model.Filter("AccountId", sap.ui.model.FilterOperator.EQ, sQuery);
									aFilters.push(filter);
								}
								if (oActiveOppListControl) {
									oActiveOppListControl.getBinding("items").filter(aFilters);
								}
							}
						}
					} else {
						//TODO:check storage or model
						oModel.setProperty("/Opportunities", aModelPcOppList);
					}
				}
				return oFnResponse;
			} else {
				//Account Popup
			}
		},

		//function to get user records
		getUserRecords: async function (oParentRef) {
			const oPrerequisiteModel = this.opportunityCtrl?.getModel("PrerequisiteModel") || new sap.ui.model.json.JSONModel();
			oPrerequisiteModel.setSizeLimit(9999);
			if (oParentRef) {
				oParentRef.setModel(oPrerequisiteModel, "PrerequisiteModel");
				DiscontinuedOpportunity.fnStaticInit(oParentRef);
			}
			OpportunityService.getUserRecords().then((oResponse) => {
				let aUserActivities = $.extend(true, [], oResponse.data.results);
				oPrerequisiteModel.setProperty("/UserActivities", aUserActivities);
				DiscontinuedOpportunity.getDiscontinuedOpp(aUserActivities);
			});
		},

		//function to get OpportunitiesTeam
		getOpportunitiesTeam: async function (sOpportunityId, selectParam, filters) {
			var that = this;
			var aFilters = [];
			var sPath = "";
			if (sOpportunityId) {
				if (filters && filters.length > 0) {
					aFilters = filters;
				}

				let oParameters = {
					urlParameters: {
						$select: (selectParam) ? selectParam : Actions.OpportunityTeamUrlParm.select,
						$expand: Actions.OpportunityTeamUrlParm.expand
					},
					filters: aFilters,
				};
				let oResponse = await OpportunityService.getOpportunityTeam(sOpportunityId, oParameters);
				return oResponse;
			}
		},

		//function to get the opportunity team details
		getOpportunityTeamDetails: async function (sOpportunityId) {
			if (sOpportunityId) {
				let oResponse = this.getOpportunitiesTeam(sOpportunityId, Actions.PartiesInvolved);
			} else {
				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.error("Opportunity not found");
			}
		},

		//function to get element from fragment using id
		fnGetDialogUsingId: function (dialogId, contentId) {
			return sap.ui.core.Fragment.byId(dialogId, contentId);
		},

		//TODO check this function usecase
		//function to get the AccociatedView
		getAssociatedView: function () {
			var obj = {
				"view": this.getView(),
				"oppInput": this.getView().byId("pcOpportunityInput")
			};
			return obj;
		},

		//function to set Value Opportunity Input 
		fnSetOpportunityInput: function (oOpportunityData, bReset) {
			let oInputControl = this.opportunityCtrl.getAggregation("_input");
			const oPrerequisiteModel = this.opportunityCtrl.getModel("PrerequisiteModel");
			if (oInputControl) {
				if (bReset) {
					oInputControl.setValue("");
					oInputControl.setTooltip("");
					oPrerequisiteModel.setProperty("/bClearIconVisible", false); //CLEARICONCHECK
					oPrerequisiteModel.setProperty("/bShowOppInfoPopup", false);
				} else {
					oInputControl.setValue(sOpportunityId);
					oInputControl.setTooltip(sOpportunityId);
					oPrerequisiteModel.setProperty("/bClearIconVisible", true); //CLEARICONCHECK
					oPrerequisiteModel.setProperty("/bShowOppInfoPopup", true);
				}
			}
		},

		//function to fetch the Opportunity Details Based on Opportunity Id:
		fnFetchOpportunityData: async function (opportunityId) {
			let oResponse = await this.getOpportunitiesTeam(opportunityId);
			let oUrlConstants = $.extend(true, {}, oStorageModel.getProperty("/oConstants"));
			if (oResponse && oResponse.data.hasOwnProperty("PartiesInvolved")) {
				this.opportunityCtrl = this.opportunityCtrl.OpportunityHelper ? this.opportunityCtrl : this.opportunityCtrl.getParent();
				oResponse.data.opportunityTeamData = this.opportunityCtrl.OpportunityHelper.fnSetFormatOpportunityTeamData(oResponse.data.PartiesInvolved
					.results);
				oResponse.data.harmonyLink = (Object.keys(oUrlConstants).length && oUrlConstants.hasOwnProperty("0184")) ? oUrlConstants["0184"].field_value +
					oResponse.data.OPPT_ID : "";
				return oResponse.data;
			} else {
				return oResponse;
			}
		},

		//function to get constants
		getConstantData: function () {
			let constants = {};
			let oUrlConstants = $.extend(true, {}, oStorageModel.getProperty("/oConstants")) || {};
			if (Object.keys(oUrlConstants).length) {
				return;
			}
			OpportunityService.getConstants().then(function (result) {
				var oData = result.data.results;
				for (var index in oData) {
					constants[oData[index].const_id] = oData[index];
				}
				oStorageModel.setProperty("/oConstants", constants);
				const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				oStorage.put("oConstants", constants);
				oStorageModel.refresh();
			});
		},

		//function to set data,clear icon & info icon based on visible
		fnSetControlPropertiesBasedOnView: async function (viewMode, oOpportunityData) {
			let oFormattedOpportunityData;
			oOpportunityData = oOpportunityData || {};
			let opportunityId = ("opportunityId" in oOpportunityData) ? oOpportunityData.opportunityId : "";
			if (!opportunityId) {
				viewMode = "";
			}
			const oDefaultModel = this.opportunityCtrl.getModel();
			const oPrerequisiteModel = this.opportunityCtrl.getModel(Actions.oModels.PrerequisiteModel);
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let oOppStatusMasterMap = oStorage.get("pcOppStatusMasterMap") || {};
			let oOppPhaseMasterMap = oStorage.get("pcOppPhaseMasterMap") || {};
			if (opportunityId) {
				let oResponseData = await this.fnFetchOpportunityData(opportunityId)
				oFormattedOpportunityData = {
					Description: oResponseData.DESCRIPTION,
					OpportunityName: oResponseData.DESCRIPTION,
					OpportunityId: oResponseData.OPPT_ID,
					AccountId: oResponseData.ACCOUNT,
					AccountName: oResponseData.ACCOUNT_NAME,
					Owner: oResponseData.OWNER,
					OWNER_NAME: oResponseData.OWNER_NAME,
					StatusDescription: (Object.keys(oOppStatusMasterMap).length && oResponseData.STATUS) ? oOppStatusMasterMap[oResponseData.STATUS].VALUE : "",
					Sales_Org_Desc: oResponseData.SALES_ORG_TEXT,
					PhaseValue: (Object.keys(oOppPhaseMasterMap).length && oResponseData.CURR_PHASE) ? oOppPhaseMasterMap[oResponseData.CURR_PHASE].VALUE : "",
					Region: "", //TODO
					SubRegion: "", //TODO
					Industry: oResponseData.INDURSTRY_TEXT,
					Segment: "", //TODO
					harmonyLink: oResponseData.harmonyLink,
				};
			}
			switch (viewMode) {
				case Actions.oViewModes.CreateMode:
					this.opportunityCtrl._setControlVisibility("EDIT");
					oDefaultModel.setProperty("/selectedOpportunity", oFormattedOpportunityData);
					break;
				case Actions.oViewModes.DisplayMode:
					this.opportunityCtrl._setControlVisibility("DISPLAY");
					oDefaultModel.setProperty("/selectedOpportunity", oFormattedOpportunityData);
					break;
				case Actions.oViewModes.EditMode:
					this.opportunityCtrl._setControlVisibility("EDIT");
					oDefaultModel.setProperty("/selectedOpportunity", oFormattedOpportunityData);
					break;
				default:
					this.opportunityCtrl.setOpportunityId("");
					oDefaultModel.setProperty("/selectedOpportunity", {});
					oDefaultModel.setProperty("/isCvaSelected", false);
					oDefaultModel.setProperty("/oSelectedAccountDetails", "");
					oDefaultModel.setProperty("/bFilterNonVatAccBased", false);
					oDefaultModel.setProperty("/bRemoveNonVAtAccFilter", true);
			}

			//SAVEING OPP DATA FOR NON-VAT CASE (WORST-CASE SCENARIO)
			oStorageModel.setProperty("/oSelectedOppDataForNonVat", oFormattedOpportunityData);
			oDefaultModel.refresh();
			oPrerequisiteModel.refresh();
		},

		//Function to link SL to Harmony, Parallel opportunity case //TODO Testing is pending
		fnParallelOpppLinkSlToHarmony: function (discontinuedOppos) {
			let self = this;
			for (let i = 0; i < discontinuedOppos.length; i++) {
				if (discontinuedOppos[i].Type === "SuccessLine") {
					let SlId = discontinuedOppos[i].ID;
					SlId = SlId.padStart(10, "0");
					let OpportunityId = discontinuedOppos[i].NewOppId;
					OpportunityId = OpportunityId.replace(/^0+/, '');
					setTimeout(function () {
						self.fnLinkSlToHarmony(SlId, OpportunityId);
					});
				}
			}
		},

		//Function to link SL to Harmony, after an SL is created. //TODO Testing is pending
		fnLinkSlToHarmony: function (SlId, OpportunityId) {
			let slUrl = window.location.origin + window.location.pathname + "#sl-App&/SlDetail?SuccessLineID=" + SlId;
			let urlParameters = {
				MODE: "A",
				URL: slUrl,
				ARC_DOC_ID: "",
				ATTACHMENT_TYPE: "",
				OPPT_ID: OpportunityId,
				FILENAME: "Melody SuccessLine",
				DESCRIPTION: "Link to SL Application"
			};

			OpportunityService.getServiceToHandleAttachments(urlParameters).then((oResponse) => {

			}).catch((oError) => {

			});
		},

		//function to format filters & Params for non-vat
		fnFormatFilterParamsForNonVat: function (params, iLoadedRecords, isOppCntrl) {
			let aFilters = [];
			// const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			// let sPartnerId = oStorage.get("PartnerId") || "";
			// if (sPartnerId) {
			// let oSalesOrg = new Filter({
			// 	path: "SALES_TEAM_MEMBER",
			// 	operator: sap.ui.model.FilterOperator.EQ,
			// 	value1: sPartnerId
			// });
			// aFilters.push(oSalesOrg);
			// }
			// let oSalesOrg = new Filter({
			// 	path: "SALES_ORG",
			// 	operator: sap.ui.model.FilterOperator.EQ,
			// 	value1: "O 50002557"
			// });
			// aFilters.push(oSalesOrg);
			// let aStatus = ["E0001", "E0007", "E0003"];

			// let aStatus = ["E0001", "E0007"];
			if (isOppCntrl) {
				const oModel = this.opportunityCtrl.getModel();
				let aStatus = oModel.getProperty("/NonVatOppStatusFilterKeys");
				if (aStatus?.length) {
					let aStatusFilter = aStatus.map((value) => {
						return new Filter({
							path: "STATUS",
							operator: sap.ui.model.FilterOperator.EQ,
							value1: value
						});
					});
					aFilters = aFilters.concat(aStatusFilter);
				}
				let sQuarterId = oModel.getProperty("/NonVatQuarterFilterId") || "CURR_YEAR";
				let oQuarterFilter = new Filter("QUARTER_ID", FilterOperator.EQ, sQuarterId);
				aFilters = aFilters.concat(oQuarterFilter);

				let aForeCast = ["1", "2", "3", "4", "5", "6"];
				let aForeCastFilter = aForeCast.map((value) => {
					return new Filter({
						path: "FORECAST",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: value
					});
				});
				let oForeCastFilter = new sap.ui.model.Filter({
					filters: aForeCastFilter,
					and: false
				});
				aFilters = aFilters.concat(oForeCastFilter);

				let bIsFavourite = oModel.getProperty("/IsFavouriteNonVat") === "YES";
				if (bIsFavourite) {
					let oFavouriteFilter = new Filter("IS_FAVORITE", FilterOperator.EQ, bIsFavourite);
					aFilters.push(oFavouriteFilter);
				}

				if (!(params && "searchQuery" in params)) {
					let sSearchQuery = oModel.getProperty("/nonvatoppsearchvalue");
					if (sSearchQuery?.trim()) {
						let isOppId = /^\d+$/.test(sSearchQuery);
						if (isOppId) {
							let oOppIdFilter = new Filter("OPPT_ID", FilterOperator.EQ, sSearchQuery);
							aFilters.push(oOppIdFilter);
						}
						params = {};
						params.searchQuery = !(isOppId) ? sSearchQuery : "";
					}
				}
			}

			// let aQuater = ["CURR_QTR"];
			// let aQuaterFilter = aQuater.map((value) => {
			// 	return new Filter({
			// 		path: "QUARTER_ID",
			// 		operator: sap.ui.model.FilterOperator.NE,
			// 		value1: value
			// 	});
			// });



			/*
			*commented as part of closed opp changes: git-479
			let aQuaterFilter = this.fnGenerateQuaterId();
			//Check if it is Opportunity-ID Search for quater-id
			if (params && "isOppSearch" in params && params.isOppSearch) {
				let oAllQuater = new Filter({
					path: "QUARTER_ID",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: "99990"
				});
				aFilters.push(oAllQuater);
			} else {
				aFilters = aFilters.concat(aQuaterFilter);
			}*/


			// let oDisplayAuth = new Filter({
			// 	path: "DISP_AUTH",
			// 	operator: sap.ui.model.FilterOperator.EQ,
			// 	value1: true
			// });
			// aFilters.push(oDisplayAuth);

			let oHarmonyType = new Filter({
				path: "HARMONY_TYPE",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: "HQ"
			});
			aFilters.push(oHarmonyType);


			// let oVATFilter = new Filter("IS_VAT", FilterOperator.EQ, "X");
			// aFilters.push(oVATFilter);



			let aNewFitler = [new Filter({
				filters: aFilters,
				and: false
			})];

			if (params && params.filters) {
				aFilters = aFilters.concat(params.filters);
			}

			let urlParameters = {
				$skip: iLoadedRecords ? iLoadedRecords : 0,
				$top: 10,
				$select: Actions.GetOpportunityNonVATListUrlParam.select,
				"search-focus": "ACCOUNT",
				"search": (params && "searchQuery" in params && params.searchQuery) ? `${params.searchQuery}` : ""
			};

			return {
				filters: aFilters,
				params: urlParameters
			};
		},

		//Function to fetch NON-VAT Opportunity for CVJ
		fnFetchNONVATForCVJ: async function (params, iLoadedRecords, isOppCntrl) {
			const oDefaultModel = this.opportunityCtrl.getModel();
			let iActualNonvatLoaded = oDefaultModel.getProperty("/iActualNonvatLoaded") || 0;
			let bRequiredTotalCount = oDefaultModel.getProperty("/bRequiredTotalCount");
			if (!iLoadedRecords) {
				iActualNonvatLoaded = 0;
			}
			let oServiceData = this.fnFormatFilterParamsForNonVat(params, iLoadedRecords, isOppCntrl);

			let mParameters = {
				filters: oServiceData.filters,
				urlParameters: oServiceData.params,
			};
			try {
				if (bRequiredTotalCount) {
					let iTotalCount = await this.fnFetchTotalNonVatCount(mParameters);
					iTotalCount = iTotalCount || 0;
					oDefaultModel.setProperty("/bRequiredTotalCount", false);
					oDefaultModel.setProperty("/iNonvatTotalCount", Number(iTotalCount));
					oDefaultModel.setSizeLimit(99999);
				}
				let aResults = await this.fnFetchNonVATOppData(mParameters);
				iActualNonvatLoaded = 10 + Number(iActualNonvatLoaded);
				oDefaultModel.setProperty("/iActualNonvatLoaded", iActualNonvatLoaded);
				oDefaultModel.refresh();
				return aResults;

			} catch (error) {
				console.log("NON-VAT ERROR :", error);
			}

		},

		//function set params to fetch NON-VAT Opportunity Data
		fnSetFormatParamsForNonVATOppData: async function (params, iLoadedRecords, isOppCntrl) {
			let oServiceData = this.fnFormatFilterParamsForNonVat(params, iLoadedRecords, isOppCntrl);
			let aFilters = oServiceData.filters;
			let oParameters = oServiceData.params;

			let mParameters = {
				filters: aFilters,
				urlParameters: oParameters,
			};

			try {
				return await this.fnFetchNonVATOppData(mParameters);
			} catch (error) {
				console.log("NON-VAT ERROR :", error);
			}
		},

		//Function to generate quater ID for fetching NON-VAT Data
		fnGenerateQuaterId: function () {
			let sQuarter = "";
			let aQuarterFilter = [];
			let currentYear = new Date().getFullYear();
			currentYear = currentYear - 1;
			for (var i = 1; i <= 7; i++) {
				sQuarter = currentYear + "0";
				aQuarterFilter.push(new Filter("QUARTER_ID", FilterOperator.EQ, sQuarter));
				currentYear++;
			}
			return aQuarterFilter;
		},

		//function to fetch the total non-vat records count
		fnFetchTotalNonVatCount: async function (mParameters) {
			let oURLParam = $.extend(true, {}, mParameters);
			delete oURLParam.urlParameters["$skip"];
			delete oURLParam.urlParameters["$top"];
			delete oURLParam.urlParameters["$select"];
			oURLParam.count = "/$count";
			let count = await OpportunityService.getNonVATOpportunityList(oURLParam);
			// let count = await CPIService.getNonVATOpportunityList(oURLParam);
			count = (count && count.hasOwnProperty("data")) ? count.data : 0;
			return count;
		},

		//function to fetch NON-VAT OPPortunity Data
		fnFetchNonVATOppData: async function (mParameters) {
			try {
				let oResponse = await OpportunityService.getNonVATOpportunityList(mParameters);
				// let oResponse = await CPIService.getNonVATOpportunityList(mParameters);
				let aResult = (oResponse && "data" in oResponse && "results" in oResponse.data) ? oResponse.data.results : [];
				if (aResult.length) {
					return this.fnSetFormatOpportunityList(aResult);
				} else {
					return [];
				}
			} catch (error) {
				console.log("NON-VAT ERROR :", error);
			}

		},

		//function to format opportunityData for non-vat
		fnSetFormatOpportunityList: function (aResults) {
			const oDefaultModel = this.opportunityCtrl?.getModel?.();
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let oOppStatusMasterMap = oStorage.get("pcOppStatusMasterMap") || {};
			let oOppPhaseMasterMap = oStorage.get("pcOppPhaseMasterMap") || {};
			let authorizedOppStatusMap = oDefaultModel?.getProperty("/AuthorizedOppStatusMap") || {};
			let aOpportunityList = aResults.map((opp) => {
				let oOpportunity = new Opportunity({
					DisplayAuth: opp.DISP_AUTH,
					OpportunityId: opp.OPPT_ID,
					OpportunityName: opp.DESCRIPTION,
					Description: opp.DESCRIPTION,
					AccountId: opp.ACCOUNT,
					AccountName: opp.ACCOUNT_NAME,
					Status: opp.STATUS,
					Phase: opp.CURR_PHASE,
					ExpectedEnd: opp.EXPECT_END,
					ExpectedValue: opp.EXPECTED_VALUE,
					Guid: opp.GUID,
					Owner: opp.OWNER,
					ChangedAt: opp.CHANGED_AT,
					OwnerName: opp.OWNER_NAME,
					Industry_MasterCode_Text: opp.INDUSTRY_MASTERCODE_TEXT,
					Industry: opp.INDUSTRY,
					Industry_Text: opp.INDURSTRY_TEXT,
					Sales_Org_Desc: opp.SALES_ORG_TEXT,
					Industry_MasterCode: opp.INDUSTRY_MASTERCODE,
					StatusDescription: (Object.keys(oOppStatusMasterMap).length && opp.STATUS) ? oOppStatusMasterMap[opp.STATUS].VALUE : "",
					PhaseValue: (Object.keys(oOppPhaseMasterMap).length && opp.CURR_PHASE) ? oOppPhaseMasterMap[opp.CURR_PHASE].VALUE : "",
					Favourite: opp.IS_FAVORITE,
					InternalOrder1: opp.INTERNAL_ORDER1,
					InternalOrder2: opp.INTERNAL_ORDER2,
					Authorized: authorizedOppStatusMap?.has?.(opp.STATUS) || false
				})
				delete oOpportunity.model
				oOpportunity.active = 1;
				return oOpportunity;
			});
			return aOpportunityList;
		},

		//function to get opportunity data for opportunity control edtiables 
		getOpportunityDetailData: async function (opportunityId) {
			let oFormattedOpportunityData;
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let oOppStatusMasterMap = oStorage.get("pcOppStatusMasterMap") || {};
			let oOppPhaseMasterMap = oStorage.get("pcOppPhaseMasterMap") || {};
			if (opportunityId) {
				let oResponseData = await this.fnFetchOpportunityData(opportunityId)
				oFormattedOpportunityData = {
					ExpectedEnd: oResponseData.EXPECT_END,
					InternalOrder1: oResponseData.INTERNAL_ORDER1,
					Description: oResponseData.DESCRIPTION,
					OpportunityName: oResponseData.DESCRIPTION,
					OpportunityId: oResponseData.OPPT_ID,
					AccountId: oResponseData.ACCOUNT,
					AccountName: oResponseData.ACCOUNT_NAME,
					Owner: oResponseData.OWNER,
					OWNER_NAME: oResponseData.OWNER_NAME,
					Status: oResponseData.STATUS,
					StatusDescription: (Object.keys(oOppStatusMasterMap).length && oResponseData.STATUS) ? oOppStatusMasterMap[oResponseData.STATUS].VALUE : "",
					Sales_Org_Desc: oResponseData.SALES_ORG_TEXT,
					PhaseValue: (Object.keys(oOppPhaseMasterMap).length && oResponseData.CURR_PHASE) ? oOppPhaseMasterMap[oResponseData.CURR_PHASE].VALUE : "",
					Region: "", //TODO
					SubRegion: "", //TODO
					Industry: oResponseData.INDURSTRY_TEXT,
					Industry_MasterCode: oResponseData.INDUSTRY_MASTERCODE,
					Segment: "", //TODO
					harmonyLink: oResponseData.harmonyLink,
					opportunityTeamData: ("opportunityTeamData" in oResponseData) ? oResponseData.opportunityTeamData : [],
				};
				return oFormattedOpportunityData;
			}
			return false;
		},

		getOppTeamWithOREAccess: async function (oppId) {
			if (oppId) {
				let oOppIdFilter = new Filter("OPPT_ID", FilterOperator.EQ, oppId);
				let oResponse = await CPIService.getOppTeamWithOREAccess([oOppIdFilter])
				return oResponse?.data?.results || [];
			}
		}

	};
});