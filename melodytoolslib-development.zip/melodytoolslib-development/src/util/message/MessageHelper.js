sap.ui.define([
	"sap/ui/model/Filter",
	"sap/ui/core/Fragment",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"com/melody/lib/enum/Actions",
	"com/melody/lib/util/Algorithm",
	"com/melody/lib/util/mtr/MTRModels",
	"com/melody/lib/model/StorageModel",
	"sap/ui/model/resource/ResourceModel"
], function (Filter, Fragment, FilterOperator, JSONModel, Actions, Algorithm, MTRModels, oStorageModel, ResourceModel) {
	"use strict";

	return {

		//self points the parent "this" pointer
		fnStaticInit: function (oParentRef) {
			//self points to the parent controller
			this.self = oParentRef;
		},

		//function to open Opportunity Fragment
		onInitializeMessageDialog: async function (oSource) {
			let self = this;
			let oMessagePopoverModel = MTRModels.getMessagePopoverModel();
			if (!self._oMessageDialog) {
				self.addDependent(self._oMessageDialog);
				self._oMessageDialog = Fragment.load({
					id: "_MessageInfoPopupDialog",
					name: "com.melody.lib.fragments.MessagePopover",
					controller: self.MessageDialogControl
				}).then(function (oDialog) {
					oDialog.setModel(oMessagePopoverModel, "messagePopoverModel");
					self.addDependent(oDialog);
					self.MessageDialogControl.fnLoadLangModel(oDialog);
					return oDialog;
				}.bind(self));
			}

			self._oMessageDialog.then((oDialog) => {
				oMessagePopoverModel.setProperty("/sMsgPopoverId", oDialog.getId());
				oMessagePopoverModel.refresh();
				return oDialog.openBy(oSource);
			});
		},

		//function to get Dialog with ID
		fnGetDialogUsingId: function (dialogId, contentId) {
			return sap.ui.core.Fragment.byId(dialogId, contentId);
		},

		//function to load i18n for dialogs
		fnLoadResourceBundle: function (dialog) {
			let i18nModel = new ResourceModel({
				bundleName: "com.melody.lib.i18n.i18n"
			});
			if (dialog) {
				dialog.setModel(i18nModel, "i18n");
			}
		},

		//function to filter Empty Records
		fnRemoveEmptyRecords: function (aRecords) {
			let aFilteredData = aRecords.filter((oMessage) => {
				if (oMessage.hasOwnProperty("title") && oMessage.title && oMessage.title.trim()) {
					return true;
				}
			});
			return aFilteredData;
		},

		//function to filter Empty Records
		fnFilterRecordByActivityId: function (aRecords, activityId) {
			if (!activityId) {
				return aRecords;
			}
			let aFilteredData = aRecords.filter((oMessage) => {
				if (oMessage.hasOwnProperty("activityId")) {
					oMessage.activityId = (oMessage.activityId) ? oMessage.activityId.replace(/^0+/, '') : "";
					if (oMessage.activityId === activityId) {
						return true;
					}
				}
			});
			return aFilteredData;
		},

	};
}, true);