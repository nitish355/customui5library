sap.ui.define([
	"jquery.sap.global",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"com/melody/lib/enum/Actions",
	"com/melody/lib/util/Algorithm",
	"com/melody/lib/classes/Account",
	"com/melody/lib/util/mtr/MTRModels",
	"com/melody/lib/model/StorageModel",
	"com/melody/lib/util/message/MessageHelper",
	"com/melody/lib/util/message/MessageDialogController",
], function (jquery, MessageToast, Filter, FilterOperator, JSONModel, Actions, Algorithm, Account, MTRModels, oStorageModel,
	MessageHelper,
	MessageDialogController) {
	"use strict";

	return {
		//to initialize the this.self to the parent "this" pointer
		fnStaticInit: function (oParentRef) {
			this.self = oParentRef;
			MessageHelper.fnStaticInit(this);
			try {
				this.fnLoadMessageController(oParentRef);
			} catch (oError) {

			}
		},

		//function to load controller for MessageDialog
		fnLoadMessageController: function (oParentRef) {
			if (!oParentRef.MessageDialogControl) {
				oParentRef.MessageDialogControl = new com.melody.lib.util.message.MessageDialogController(oParentRef);
				oParentRef.MessageDialogControl.fnLoadLangModel = MessageHelper.fnLoadResourceBundle;
			}
		},

		//function to handle opening of Message Popover
		fnOpenMessagePopover: function (oButtonSrc) {
			if (!oButtonSrc) {
				MessageToast.show("MessagePopover Button Source is Invalid");
				return;
			}

			if (!this.self._oMessageDialog) {
				this.fnLoadMessageController(this.self);
				let onLoadMessagePopover = MessageHelper.onInitializeMessageDialog.bind(this.self);
				onLoadMessagePopover(oButtonSrc);
			} else {
				this.self._oMessageDialog.then((oDialog) => {
					oDialog.openBy(oButtonSrc);
				});
			}
		},

		//function to set MessageData Based on ActivitId
		fnSetFormatMessageDataBasedOnId: function (activityId) {
			let oMessageModel = MTRModels.getMessagesModel();
			let oMessagePopoverModel = MTRModels.getMessagePopoverModel();
			if (oMessageModel) {
				let aMessageData = $.extend(true, [], oMessageModel.getData());
				if (activityId) {
					aMessageData = MessageHelper.fnFilterRecordByActivityId(aMessageData, activityId);
				}
				oMessageModel.setData(aMessageData);
				oMessagePopoverModel.setProperty("/aMessageData", aMessageData);
			}
		},

		//function to navigate to myentries page based on statusId
		fnRouteToMyEntries: function (statusId, projectType) {
			let statusValue = "";
			statusId = (statusId) ? statusId.toString() : "0";
			switch (statusId) {
			case "1":
				statusValue = "savedEntries";
				break;
			case "3":
				statusValue = "failedEntries";
				break;
			case "4":
				statusValue = "submittedEntries";
				break;
			default:
				statusValue = "savedEntries";
				break;
			}

			//check for MyEntries Page in URL
			let oHashChanger = new sap.ui.core.routing.HashChanger();
			let hashValue = (oHashChanger) ? oHashChanger.getHash() : "";
			if (hashValue && (hashValue.includes("pcactivityform-app&/MyEntries") || hashValue.includes("/MyEntries"))) {
				// DO NOTHING
			} else {
				if (projectType === "ACTVT") {
					let urlParam = `?StatusId=${statusValue}`;
					let routeUrl = `#pcactivityform-app&/MyEntries${urlParam}`;
					new sap.ui.core.routing.HashChanger().replaceHash(routeUrl);
				} else {
					let oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
					var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
						target: {
							semanticObject: "pcactivityform",
							action: "app&/MyEntries"
						},
						params: {
							"StatusId": statusValue
						}
					})) || "";
					oCrossAppNavigator.toExternal({
						target: {
							shellHash: hash
						}
					});
				}
			}
		},
	};
}, true);