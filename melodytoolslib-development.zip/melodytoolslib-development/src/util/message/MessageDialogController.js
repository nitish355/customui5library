sap.ui.define([
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"sap/ui/base/ManagedObject",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"com/melody/lib/enum/Actions",
	"sap/ui/core/format/DateFormat",
	"com/melody/lib/model/formatter",
	"com/melody/lib/model/StorageModel",
	"com/melody/lib/util/mtr/MTRHelper",
	"com/melody/lib/util/mtr/MTRModels",
	"sap/ui/model/resource/ResourceModel",
	"com/melody/lib/util/message/Message",
], function (Filter, MessageToast, Fragment, ManagedObject, Controller, FilterOperator, JSONModel, Actions, DateFormat, formatter,
	oStorageModel, MTRHelper, MTRModels,
	ResourceModel, MessageUtil) {
	"use strict";

	const oMessageDialogController = Controller.extend("com.melody.lib.util.message.MessageDialogController", {
		formatter: formatter,
		//function to initial Parent this.sef ref to current this.
		constructor: function (oParentref) {
			//TODO: Need to improve
			this.self = oParentref;
		},

		//function to handle clearMessage
		onClearMessages: function (oEvent) {
			let oModel = this.self.getModel();
			let oMessageModel = MTRModels.getMessagesModel();
			let oMessagePopoverModel = MTRModels.getMessagePopoverModel();
			oMessageModel.setData([]);
			oMessagePopoverModel.setProperty("/aMessageData", []);
			oMessagePopoverModel.refresh();
		},

		//function to hande active title press
		onActiveTitlePressMessage: function (oEvent) {
			let oParams = {
				statusValue: ""
			};
			let oSelectedItem = oEvent.getParameter("item");
			let oItemObject = oSelectedItem.getBindingContext("messagePopoverModel").getObject() || {};
			let statusId = (oItemObject.hasOwnProperty("statusId")) ? oItemObject.statusId.toString() : "";
			if (!MessageUtil) {
				let oMessageUtil = com.melody.lib.util.message.Message;
				oMessageUtil.fnRouteToMyEntries(statusId);
				return;
			}
			MessageUtil.fnRouteToMyEntries(statusId);
		},

		//function to get Hash Value
		fnGetHashValue: function () {
			let oHashChanger = new sap.ui.core.routing.HashChanger();
			let hashValue = oHashChanger.getHash();
			return hashValue;
		},

		//function to get Link Access
		fnGetLinkAccess: function (value) {
			let hashValue = this.fnGetHashValue();
			if (hashValue && (hashValue.includes("pcactivityform-app&/MyEntries") || hashValue.includes("/MyEntries"))) {
				return false;
			} else {
				return value;
			}
		},

		/*
		//function to create href link for error
		createLink: function (type) {
			return "https://itsm.services.sap/sp?id=sc_cat_item&sys_id=703f22d51b3b441020c8fddacd4bcbe2&sysparm_category=e15706fc0a0a0aa7007fc21e1ab70c2&service_offering=2aa782291b244110d9c921fbbb4bcbdb&short_description=PreSales%20Tools:%20Melody%20Time%20Recording";
		}
		*/	
	});
	return oMessageDialogController;
});