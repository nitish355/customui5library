sap.ui.define([
	"com/melody/lib/service/UserService",
	"com/melody/lib/model/formatter",
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (UserService, formatter, Controller, Fragment, JSONModel, Filter, FilterOperator) {
	"use strict";
	const UserMaster = {

		authenticate: async function (projectType) {
			let oUserModel = sap.ui.getCore().getModel("userUtility");

			if (oUserModel && oUserModel.getData()) {
				this.User = oUserModel.getData();
			} else {
				this.nonOreUserData = "";
				this.User = await this._getUserDetail();
				if (!projectType) {
					projectType = "ACTVT";
				}
				this.nonOreUserData = await this._getNonOreUserAppBasedCheck(projectType);
				if (this.User) {
					//Below Code is commeneted for Non-ore Task #184
					/*if (this.User.OrgFlag.toUpperCase() === "X") {
						this._openOrgChart();
					}*/
					this.User.oNonOreData = this.nonOreUserData;
					oUserModel = new JSONModel(this.User);
					sap.ui.getCore().setModel(oUserModel, "userUtility");
				}

			}

			return this.User;
		},

		_getUserDetail: async function () {
			//const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);

			//let oUser = oStorage.get("userOreData");

			let oUser = null;

			//if (!oUser) {
			const oData = await UserService.getUserDetail();
			if (oData.data && oData.data.results && oData.data.results.length > 0 && oData.data.results[0].UserId !== "") {
				oUser = oData.data.results[0];
				//oStorage.put("userOreData", oUser);
				const sUserId = this._getExceptionUserIds().find(id => id === oUser.UserId);
				if (!sUserId) {
					this._injectWarp(oUser);
				}
			}
			//}

			return oUser;
		},

		_getNonOreUserAppBasedCheck: async function (projectType) {
			let oAuthData = null;

			const oData = await UserService.getAuthCheckForNonOreUser(projectType);
			if (oData) {
				oAuthData = oData;
			}

			return oAuthData;
		},

		_getExceptionUserIds: function () {
			return UserService.getExceptionUserIds();
		},

		_injectWarp: function (user) {
			//delete JSON_PIWIK;
			var sPubToken = "";
			var sSubSiteId = "";

			var sAppName = "";
			var sHash = window.location.hash.toLowerCase();
			var that = this;
			window.swaCustomFields = {
				custom1: "",
				custom2: "",
				custom3: "",
				custom4: "",
				custom5: ""
			};

			//check whether navigation is from SMT apps to assign subsiteId of SMT 
			if ((sHash.indexOf("#smtmassedit-app") !== -1) || (sHash.indexOf("#smtform-app") !== -1) || (sHash.indexOf("#smt-app") !== -1) || (
					sHash.indexOf("#smtadmin-app") !== -1)) {
				sAppName = "SMT";
			}
			if (sHash.indexOf("#sl-app") !== -1) {
				sAppName = "SuccessLine";
			}

			if (window.location.host.indexOf("br339jmc4c") !== -1) {
				sPubToken = "89cccf7b-6cfe-9243-8d9f-75e604e8c575";
				//sSubSiteId = "MelodyDev";
				// sSubSiteId = bFromSMT ? "SMTDev" : "MelodyDev";
				if (sAppName === "SMT") {
					sSubSiteId = "SMTDev";
				} else if (sAppName === "SuccessLine") {
					sSubSiteId = "SuccessLineDev";
				} else {
					sSubSiteId = "MelodyDev";
				}
			} else if (window.location.host.indexOf("sapitcloudt") !== -1 || window.location.host.indexOf("fiorilaunchpad-qa.sap.com") !== -1) {
				sPubToken = "4cd44f02-28e4-d347-a013-2fd77b7b5426";
				//sSubSiteId = "MelodyTest";
				// sSubSiteId = bFromSMT ? "SMTTest" : "MelodyTest";
				if (sAppName === "SMT") {
					sSubSiteId = "SMTTest";
				} else if (sAppName === "SuccessLine") {
					sSubSiteId = "SuccessLineTest";
				} else {
					sSubSiteId = "MelodyTest";
				}
			} else if (window.location.host.indexOf("fiorilaunchpad.sap.com") !== -1) {
				sPubToken = "6051b26a-7f22-384a-86e0-f7bf43fea890";
				//sSubSiteId = "Melody";
				// sSubSiteId = bFromSMT ? "SMT" : "Melody";
				if (sAppName === "SMT") {
					sSubSiteId = "SMT";
				} else if (sAppName === "SuccessLine") {
					sSubSiteId = "SuccessLineProd";
				} else {
					sSubSiteId = "Melody";
				}
			}
			window.swa = {
				pubToken: sPubToken,
				baseUrl: 'https://webanalytics.cfapps.eu10.hana.ondemand.com/tracker/',
				/*Please provide function name which will return owner info or string value of owner info*/
				owner: "",
				subSiteId: sSubSiteId,
				custom1: {
					ref: function () {
						return window.swaCustomFields.custom1;
					}
				},
				custom2: {
					ref: function () {
						return window.swaCustomFields.custom2;
					}
				},
				custom3: {
					ref: function () {
						return window.swaCustomFields.custom3;
					}
				},
				custom4: {
					ref: function () {
						return window.swaCustomFields.custom4;
					}
				},
				custom5: {
					ref: function () {
						return window.swaCustomFields.custom5;
					}
				}
			};
			window.swaCustomFields.custom1 = user.RegionName;
			window.swaCustomFields.custom2 = user.SubRegionName;
			window.swaCustomFields.custom3 = user.MuName;
			window.swaCustomFields.custom4 = user.Headcount;
			window.swaCustomFields.custom5 = user.OreFlag;

			(function () {
				var d = document,
					g = d.createElement('script'),
					s = d.getElementsByTagName('script')[0];
				g.type = 'text/javascript';
				g.defer = true;
				g.async = true;
				g.src = window.swa.baseUrl + 'js/privacy.js';
				s.parentNode.insertBefore(g, s);
				g.onload = function (script) {
					// window.swa.enable();
					setTimeout(function () {
						window.swa.enable();
					}, 2000);
				};
			})();
		},

		_openOrgChart: function () {
			const that = this;
			if (!this.OrgChartDialog) {
				this.OrgChartDialog = Fragment.load({
					name: "com.melody.lib.fragments.OrgChartDialog",
					controller: new OrgChartController(this.User)
				}).then(function (dialog) {
					return dialog;
				});
			}

			this.OrgChartDialog.then(function (dialog) {
				dialog.open();
			});
		}
	}

	const OrgChartController = Controller.extend("com.melody.lib.controller.OrgChart", {
		formatter: formatter,
		constructor: function (user) {
			Controller.call(this);
			this.UserModel = new JSONModel(user);
			this.PrevOrgData = null;
			if (user) {
				this.PrevOrgData = JSON.parse(JSON.stringify(user));
			}

			const oModel = new JSONModel({
				Roles: [],
				Regions: [],
				MarketUnits: []
			});

			this.OreModel = oModel;

			UserService.getRoles()
				.then((response) => {
					let aRoles = $.extend(true, [], response.data.results);
					if (aRoles.length) {
						aRoles.sort(function (a, b) {
							return a.Role.trim().localeCompare(b.Role.trim());
						});
					}
					oModel.setProperty("/Roles", aRoles);
				});

			UserService.getRegions()
				.then((response) => {
					oModel.setProperty("/Regions", response.data.results);
				});

			UserService.getMarketUnits()
				.then((response) => {
					oModel.setProperty("/MarketUnits", response.data.results);
				});
		},

		afterOrgChartOpen: function (oEvent) {
			console.log(oEvent);
			this.Dialog = oEvent.getSource();
			this.Dialog.setModel(this.OreModel, "oreModel");
			console.log(this.UserModel);
			this.Dialog.setModel(this.UserModel, "user");
			this.OrgWizard = sap.ui.getCore().byId("orgSettingWizard")

			this.OrgWizard.setShowNextButton(true);
			const aSteps = this.OrgWizard.getSteps();
			if (!this.UserModel.getProperty("/HeadcountId")) {
				this.OrgWizard.setCurrentStep(aSteps[0]);
			} else if (!this.UserModel.getProperty("/RegionHC")) {
				this.OrgWizard.setCurrentStep(aSteps[1]);
			} else if (!this.UserModel.getProperty("/MuHC")) {
				this.OrgWizard.setCurrentStep(aSteps[2]);
			} else {
				/*if all the data is present , set role as the current step*/
				this.OrgWizard.setCurrentStep(aSteps[0]);
			}
		},

		onOREStepActivate: function (oEvent) {
			var iStepIndex = oEvent.getParameter("index");
			var RegionHC = this.UserModel.getProperty("/RegionHC");
			if (iStepIndex == 3 && this.UserModel.getProperty("/RegionHC")) {
				var RegionHC = this.UserModel.getProperty("/RegionHC");
				var sTempRegionHC = RegionHC.padStart(4, 0);
				this._filterMUData(sTempRegionHC);
				this.OrgWizard.setShowNextButton(false);
			} else {
				this.OrgWizard.setShowNextButton(true);
			}
		},

		closeOrgChart: function () {
			var bIsValidated = this._validateOrgData();
			if (bIsValidated && ((this.UserModel.getProperty("/RegionHC") !== this.PrevOrgData.RegionHC) || (this.UserModel.getProperty(
						"/MuHC") !== this.PrevOrgData
					.MuHC) || (this.UserModel.getProperty("/HeadcountId") !== this.PrevOrgData.HeadcountId))) {
				this._showConfirmationDialog();
			} else if (bIsValidated) {
				this.Dialog.close();
			}
		},

		orgChartConfirm: async function () {
			var bIsValidated = this._validateOrgData();
			if (!bIsValidated) {
				return;
			}
			var sHeadcount = this.UserModel.getProperty("/Headcount");
			var sHeadcount_l1 = this.UserModel.getProperty("/Headcount_L1");
			var sRegionId = this.UserModel.getProperty("/RegionHC"),
				sMuId = this.UserModel.getProperty("/MuHC");

			if (sMuId.length !== 4) {
				sMuId = sMuId.padStart(4, 0);
			}

			if (sRegionId.length !== 4) {
				sRegionId = sRegionId.padStart(4, 0);
			}

			var OREData = {
				application: this.UserModel.getProperty("/appId") || "",
				Headcount: sHeadcount,
				Headcount_L1: sHeadcount_l1,
				RegionHC: sRegionId,
				MuHC: sMuId
			};

			const oData = await UserService.submitUserOrgChart(OREData);
			this.PrevOrgData.RegionHC = this.UserModel.getProperty("/RegionHC");
			this.PrevOrgData.MuHC = this.UserModel.getProperty("/MuHC");
			this.PrevOrgData.HeadcountId = this.UserModel.getProperty("/HeadcountId");
			this.UserModel.setProperty("/OrgFlag", "");
			this.closeOrgChart();
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			oStorage.put("bPcOrgValidated", true);
		},

		onOrgRoleSelect: function (oEvent) {
			var sContext = oEvent.getParameter("listItem").getBindingContextPath("oreModel");
			this.UserModel.setProperty("/Headcount_L1", this.OreModel.getProperty(sContext + "/HCL1ID"));
			this.UserModel.setProperty("/Headcount", this.OreModel.getProperty(sContext + "/HCL2ID"));
			this.UserModel.setProperty("/HeadcountId", this.OreModel.getProperty(sContext + "/Role"));
			this.OrgWizard.nextStep();
		},

		onOrgRegionSelect: function (oEvent) {
			var sContext = oEvent.getParameter("listItem").getBindingContextPath("oreModel");
			this.UserModel.setProperty("/RegionHC", this.OreModel.getProperty(sContext + "/HCRegId"));
			this.UserModel.setProperty("/RegionName", this.OreModel.getProperty(sContext + "/HCRegDesc"));
			this.UserModel.setProperty("/RegionHCName", this.OreModel.getProperty(sContext + "/HCRegDesc"));
			this.OrgWizard.nextStep();
			this._filterMUData(this.UserModel.getProperty("/RegionHC"));
		},
		onOrgMUSelect: function (oEvent) {
			var sContext = oEvent.getParameter("listItem").getBindingContextPath("oreModel");
			this.UserModel.setProperty("/MuHC", this.OreModel.getProperty(sContext + "/HCMUID"));
			this.UserModel.setProperty("/MuName", this.OreModel.getProperty(sContext + "/HCMUDesc"));
			this.UserModel.setProperty("/MuHCDesc", this.OreModel.getProperty(sContext + "/HCMUDesc"));
		},

		_filterMUData: function (sRegionId) {
			var regionFilter = [];
			regionFilter.push(new Filter("HCRegID", FilterOperator.EQ, sRegionId));
			const orgMu = this.OrgWizard.getSteps()[2].getAggregation("content")[1];
			orgMu.getBinding("items").filter(regionFilter);
		},

		_validateOrgData: function () {
			var sHeadCount = this.UserModel.getProperty("/HeadcountId"),
				sRegionId = this.UserModel.getProperty("/RegionHC"),
				sMuId = this.UserModel.getProperty("/MuHC");
			if (!sHeadCount || !sRegionId || !sMuId) {
				sap.ui.define(['sap/m/MessageToast'], function (MessageToast) {
					MessageToast.show("Confirming you role , region and market unit is mandatory.");
				});
				return false;
			}
			return true;
		},

		_showConfirmationDialog: function () {
			var that = this;
			sap.ui.define(['sap/m/MessageBox'], function (MessageBox) {
				MessageBox.confirm(
					"Do you want to save modified data.", {
						actions: ["Save", "Edit"],
						onClose: function (sAction) {
							if (sAction === "Save") {
								that.orgChartConfirm();
							}
						}
					}
				);
			});
		},
		onExit: function () {
			if (this.OrgChartDialog) {
				this.OrgChartDialog.destroy();
			}
		}
	});

	return UserMaster;
});