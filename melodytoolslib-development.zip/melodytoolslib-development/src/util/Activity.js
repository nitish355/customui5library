sap.ui.define([
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"com/melody/lib/classes/Activity",
	"com/melody/lib/classes/ActivityType",
	"com/melody/lib/service/ActivityService",
], function (Filter, FilterOperator, JSONModel, Activity, ActivityType, ActivityService) {
	"use strict";
	return {
		getActivityTypes: async function () {
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let aActivityTypes = oStorage.get("activityTypes");
			if (!aActivityTypes) {
				aActivityTypes = [];
				const aResult = await ActivityService.getActivityTypes();
				for (let i = 0; i < aResult.length; i++) {
					if (aResult[i].ActivityTypeId && aResult[i].ActivityTypeId !== "") {
						const oActivityType = new ActivityType({
							ActivityTypeId: aResult[i].ActivityTypeId,
							ActivityTypeName: aResult[i].Description
						});
						if (oActivityType.ActivityTypeName) {
							aActivityTypes.push(oActivityType);
						}
					}
				}
				oStorage.put("activityTypes", aActivityTypes);
			}
			return aActivityTypes;
		},

		getUserActivities: async function (bForceUpdate) {
			let oActivitiesModel = sap.ui.getCore().getModel("activities");
			let aActivities = [];
			if (oActivitiesModel && oActivitiesModel.getData() && !bForceUpdate) {
				aActivities = oActivitiesModel.getData();
			} else {
				const aResult = await ActivityService.getUserActivities();
				const aActivityTypes = await this.getActivityTypes();
				for (let i = 0; i < aResult.length; i++) {
					aActivities.push(new Activity(aResult[i]));
				}
				sap.ui.getCore().setModel(new JSONModel(aActivities),
					"activities");
			}

			return aActivities;
		},

		getUserActivityRole: async function () {
			let oUserActivityRoleModel = sap.ui.getCore().getModel("userActivityRole");
			let oUserActivityRole = (oUserActivityRoleModel) ? oUserActivityRoleModel.getData() : null;
			if (!oUserActivityRole) {
				oUserActivityRole = await ActivityService.getUserActivityRole();
				sap.ui.getCore().setModel(new JSONModel(oUserActivityRole), "userActivityRole");
			}
			return oUserActivityRole;
		},

		//function to get Activity Regions
		getActivityRegion: async function () {
			let aResponse = await ActivityService.getRegionMu();
			let aRegions = [];
			let regionMap = {};
			aRegions = aResponse.filter((item) => {
				regionMap[item.Region] = item;
				if (item.IsDefault === "X") {
					return item
				}
			});
			let defaultRegion = aRegions.length ? aRegions[0].Region : "";
			$.each(regionMap, function (index, item) {
				if (item.Region !== defaultRegion) {
					aRegions.push(item);
				}
			});
			return {
				masterRegions: aResponse,
				regions: aRegions
			};
		},

		//function to get Activity Set Data
		getActivitySetData: async function () {
			let aResponse = await ActivityService.fnGetActivitySets();
			return aResponse;
		},

		//function to get Activity Set Data
		createActivitySet: async function (entry) {
			let oResponse = await ActivityService.fnGetActivitySetIdInfo(entry);
			return oResponse;
		}
	};
});