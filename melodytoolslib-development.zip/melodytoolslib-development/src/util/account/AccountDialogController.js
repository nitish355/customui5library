sap.ui.define([
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"sap/ui/base/ManagedObject",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"com/melody/lib/enum/Actions",
	"sap/ui/core/format/DateFormat",
	"com/melody/lib/model/formatter",
	"com/melody/lib/model/StorageModel",
	"sap/ui/model/resource/ResourceModel",
	"com/melody/lib/util/account/Account",
	"com/melody/lib/service/AccountService",
	"com/melody/lib/util/account/AccountHelper",
], function (Filter, MessageToast, Fragment, ManagedObject, Controller, FilterOperator, JSONModel, Actions, DateFormat, formatter,
	oStorageModel,
	ResourceModel,
	Account,
	AccountService, AccountHelper) {
	"use strict";

	const oDialogController = Controller.extend("com.melody.lib.util.account.AccountDialogController", {
		formatter: formatter,
		//function to initial Parent this.sef ref to current this.
		constructor: function (oParentref, oAccountHelperRef) {
			this.accountCtrl = oParentref;
		},

		//function toget element from fragment using id
		fnGetDialogUsingId: function (dialogId, contentId) {
			return sap.ui.core.Fragment.byId(dialogId, contentId);
		},

		//function to handle pagiantion
		onPagination: function (evt) {
			if (evt.getParameter("reason") === "Filter") {
				this.IsFilter = true;
			}
		},

		//function to handle update finished
		onUpdateFinished: function (evt) {
			const iCount = evt.getParameter("actual");
			if (evt.getParameter("reason") === "Growing" || (this.IsFilter && iCount)) {
				if (this.IsFilter && iCount) {
					this.IsFilter = false;
				}
				const aFetchAdvanceSearch = [];

				if (iCount && iCount !== "") {
					const oSource = evt.getSource();
					const oModel = this.accountCtrl.getModel();
					const aItems = oSource.getAggregation("items");
					for (let i = 0; i < aItems.length; i++) {
						const oBindingContext = aItems[i].getBindingContext();
						const sPath = oBindingContext.getPath();
						const oAccount = oModel.getProperty(sPath);
						if (!oAccount.IsAdvanceSearched) {
							aFetchAdvanceSearch.push(oAccount);
						}
					}
				}

				if (aFetchAdvanceSearch.length > 0) {
					this._getAdvanceDetails(aFetchAdvanceSearch);
				} else {
					this._searching(false);
				}
			}
		},

		_searching: function (bValue) {
			const oModel = this.accountCtrl.getModel();
			oModel.setProperty("/Searching", bValue);
		},

		onSimpleSearch: function (oEvent) {

			const oThisController = this;
			const AccountUtil = this.accountCtrl.AccountUtil;
			const AccountHelper = this.accountCtrl.AccountHelper;
			const sValue = oEvent.getSource().getValue();
			const oSimpleSearchList = this.fnGetDialogUsingId("_AccountDialog", Actions.AccountSimpleSrchListId);

			if (sValue.length >= 3) {
				oThisController._searching(true);
				this.accountCtrl.filters = [
					new Filter({
						filters: [
							new Filter("AccountId", FilterOperator.Contains, sValue),
							new Filter("AccountName", FilterOperator.Contains, sValue)
						],
						and: false
					})
				];

				AccountUtil.searchAccounts(sValue)
					.then((accounts) => {
						if (accounts.length === 0) {
							oThisController._searching(false);
							return;
						}
						AccountHelper.fnSuccessSearchAccounts(sValue, accounts, true, oSimpleSearchList, Actions.SimpleAccountSearch);
						// oThisController.setSimpleSearchedAccounts(accounts);
					});
			} else if (sValue.length === 0) {
				this.accountCtrl.filters = [];
				AccountUtil.filterAccounts();
			}
		},

		setSimpleSearchedAccounts: function (accounts) {
			const oModel = this.accountCtrl.getModel();
			const AccountUtil = this.accountCtrl.AccountUtil;
			const AccountHelper = this.accountCtrl.AccountHelper;
			const aMasterSimpleSrchSAccountData = oModel.getProperty("/aMasterSimpleSrchSAccountData");
			const aNewAccounts = [];
			for (let i = 0; i < accounts.length; i++) {
				const index = aMasterSimpleSrchSAccountData.findIndex((item) => {
					return item.AccountId.trim() === accounts[i].AccountId.trim();
				});
				if (index === -1) {
					aNewAccounts.push(accounts[i]);
				}
			}
			aMasterSimpleSrchSAccountData.push(...aNewAccounts);
			oModel.setProperty("/aMasterSimpleSrchSAccountData", aMasterSimpleSrchSAccountData);
			AccountUtil.filterAccounts();
			oModel.refresh(true);
		},

		_getAdvanceDetails: function (accounts) {
			const oThisController = this;
			const AccountUtil = this.accountCtrl.AccountUtil;
			const AccountHelper = this.accountCtrl.AccountHelper;
			let aAccounts = accounts;
			if (!aAccounts || aAccounts.length === 0) {
				const oModel = this.accountCtrl.getModel();
				aAccounts = oModel.getProperty("/SearchedAccounts");
			}

			const aFilteredAccounts = aAccounts.filter((item) => {
				return !item.IsAdvanceSearched;
			});

			AccountUtil.getAdvanceDetails(aFilteredAccounts)
				.then((data) => {
					oThisController._setSearchedAccounts(data);
					oThisController._searching(false);
				});
		},

		_setSearchedAccounts: function (accounts) {
			const oModel = this.accountCtrl.getModel();
			const aSearchedAccounts = oModel.getProperty("/SearchedAccounts");
			const aNewAccounts = [];
			for (let i = 0; i < accounts.length; i++) {
				const index = aSearchedAccounts.findIndex((item) => {
					return item.AccountId.trim() === accounts[i].AccountId.trim();
				});

				if (index !== -1) {
					if (!aSearchedAccounts[index].IsAdvanceSearched) {
						aSearchedAccounts[index].setData(accounts[i]);
					}
				} else {
					aNewAccounts.push(accounts[i]);
				}
			}
			aSearchedAccounts.push(...aNewAccounts);
			oModel.refresh(true);
		},

		onPressSelectAccount: function (oEvent) {

			const oModel = this.accountCtrl.getModel();
			const oSource = oEvent.getSource();
			const oSelectedItem = oSource.getParent();

			const oBindingContext = oSelectedItem.getBindingContext();
			const sPath = oBindingContext.getPath();
			const oAccount = oModel.getProperty(sPath);
			this.onFetchAccountDetails(oEvent, Actions.SimpleAccountSearch);
			// this.accountCtrl.setSelectedAccount(oAccount);
			this.onCloseAccountSearch();
		},

		//function to close the account search dialog
		onCloseAccountSearch: function (oEvent) {
			this.accountCtrl._oAccountDialog.close();
			this.accountCtrl._oAccountDialog.destroy();
			this.accountCtrl._oAccountDialog = null;
		},

		//funciton to handle Advance search from AccountAdvancedSearch Fragment
		handleAccountSearch: async function (oEvent) {
			let sValue = "";
			let oThisController = this;
			let eventType = typeof (oEvent);
			if (eventType === "object") {
				sValue = oEvent.getSource().getValue();
			} else if (eventType === "string") {
				sValue = oEvent;
			}
			let searchQuery = sValue;
			sValue = sValue.toLowerCase();
			const AccountUtil = this.accountCtrl.AccountUtil;
			const AccountHelper = this.accountCtrl.AccountHelper;
			const OpportunityUtil = this.OpportunityUtil;
			let oAccountModel = this.accountCtrl.getModel();
			let selectedIconTabKey = oAccountModel.getProperty("/selectedIconTabKey");
			let aCvaModelMyAccountData = $.extend(true, [], oStorageModel.getProperty("/aCvaModelMyAccountData"));
			if (sValue.length >= 3) {
				AccountHelper.fnAccountSearchHandler(sValue, selectedIconTabKey, eventType);
			} else if (sValue === "") {
				if (selectedIconTabKey === Actions.SimpleAccountSearch) {
					oAccountModel.setProperty("/isMyAccountsCountVisible", false);
					oAccountModel.setProperty("/aMasterSimpleSrchSAccountData", aCvaModelMyAccountData);
					oStorageModel.setProperty("/aCvaAccountData", aCvaModelMyAccountData);
				} else {
					oThisController.onClearFilterAdvSearchAccounts();
					oAccountModel.setProperty("/aMasterAccountData", []);
					oAccountModel.setProperty("/isMyAccountsCountVisible", true);
					oAccountModel.setProperty("/sSearchQuery", "");
					AccountHelper.fnSetAccountMasterData(true);
				}
			} else {
				//TODO: Need to check
				MessageToast.show("Please enter minimum of 3 characters to search");
			}
		},

		//function to clear filter values in advanced search dialog
		onClearFilterAdvSearchAccounts: function (oEvent) {
			const AccountUtil = this.accountCtrl.AccountUtil;
			const AccountHelper = this.accountCtrl.AccountHelper;
			AccountHelper.fnClearFilterAdvSearchAccounts(oEvent);
		},

		//function to handle change event of select control from advance search fragment
		onAdvSrchFragFilterChangeHandler: function (oEvent) {
			const AccountUtil = this.accountCtrl.AccountUtil;
			const AccountHelper = this.accountCtrl.AccountHelper;
			AccountHelper.fnFilterAdvSearchAccounts(oEvent);
		},

		//function to handle IconTab Select
		onSelectAccountTab: function (oEvent) {
			let oAccountSearchModel = this.accountCtrl.getModel();
			let selectedKey = oEvent.getParameter("selectedKey");
			oAccountSearchModel.setProperty("/selectedIconTabKey", selectedKey);
			oAccountSearchModel.refresh();
		},

		//function to handle select btn from advance seach dialog
		onFetchAccountDetails: async function (oEvent, searchType) {
			let oAccount;
			let oProperty = {};
			let oSource = oEvent.getSource();
			const AccountUtil = this.accountCtrl.AccountUtil;
			const AccountHelper = this.accountCtrl.AccountHelper;
			let oModel = oSource.getBindingContext();
			let oAccountSearchModel = this.accountCtrl.getModel();
			let oSelectedAccount = oModel.getObject() || {};
			let sAccountId = oSelectedAccount.AccountId;
			const oEssentialModel = this.accountCtrl.getModel(Actions.oModels.EssentialModel);
			let oUrlConstants = $.extend(true, {}, oStorageModel.getProperty("/oConstants"));
			let aResponse = await Promise.all(AccountUtil.fnProvideBPAttributeSetSearchAccount({
				bAccountId: true,
				AccountId: sAccountId
			}));
			let data = aResponse[0].data;

			if (searchType === Actions.SimpleAccountSearch) {
				let oResponse = AccountUtil.getAccountDetailsFromBupaInfoSet("", false, true, sAccountId);
				oResponse.then((oResponseData) => {
					oAccount = AccountUtil.fnSetFormatDataAccountDetailSuccess(oSelectedAccount, oResponseData.data);
					oAccount = AccountUtil.fnSetAccountDataBPAttribSet(oAccount, data);
					if (oAccount) {
						oAccount.harmonyLink = (Object.keys(oUrlConstants).length && oUrlConstants.hasOwnProperty("0186")) ? oUrlConstants["0186"].field_value +
							oAccount.AccountId : "";
						AccountHelper.fnFetchAccountDetailHelperFunction(oAccount);
					}
					oAccountSearchModel.setProperty("/oSelectedAccountData", oAccount);
				}).catch((oError) => {
					MessageToast.show("Failed To Select Account From Search.");
				});
			} else {
				oSelectedAccount = AccountUtil.fnSetAccountDataBPAttribSet(oSelectedAccount, data);
				oSelectedAccount.harmonyLink = oUrlConstants["0186"].field_value + oSelectedAccount.AccountId;
				AccountHelper.fnFetchAccountDetailHelperFunction(oSelectedAccount);
				oAccountSearchModel.setProperty("/oSelectedAccountData", oSelectedAccount);
			}
			oStorageModel.refresh();
			oEssentialModel.refresh();
		},

		//function to handle navigation in Account Info Popup
		onNavToCRMwithCvaAccnt: function () {
			let accountId = "";
			let oAccountSearchModel = this.accountCtrl.getModel();
			let oConstants = $.extend(true, {}, oStorageModel.getProperty("/oConstants"));
			let oSelectedAccountData = $.extend(true, {}, oAccountSearchModel.getProperty("/oSelectedAccountData"));
			let validId = (oSelectedAccountData && "AccountId" in oSelectedAccountData && oSelectedAccountData.AccountId) ? true : false;
			if (validId) {
				accountId = oSelectedAccountData.AccountId
			} else {
				accountId = this.accountCtrl.getProperty("accountId");
			}

			window.open(oConstants["0186"].field_value + accountId,	"_blank");
		},

		//function to close the Account Info Popup
		onCloseAccountInfo: function () {

			this.accountCtrl._oAccountInfoDialog.then((oDialog) => {
				oDialog.close();
				oDialog.destroy();
				this.accountCtrl._oAccountInfoDialog = null;
			});
		},

		//Function to fetch Account details on Load More
		fnLoadMoreAccountInfo: async function (oEvent) {
			return;
			let oThisController = this;
			const AccountUtil = this.accountCtrl.AccountUtil;
			const AccountHelper = this.accountCtrl.AccountHelper;
			let oTable = oEvent.getSource();
			let iCount = oTable.getVisibleRowCount() + oEvent.getParameter("firstVisibleRow");
			let tblRowsLength = oTable.getBinding("rows").getLength();
			if (iCount === tblRowsLength) {
				let newLastIndex = 0;
				let newStartIndex = 0;
				let oAccountSearchModel = this.accountCtrl.getModel();
				let aAccounts = $.extend(true, [], oAccountSearchModel.getProperty("/aMasterAccountData"));
				let sSearchQuery = oAccountSearchModel.getProperty("/sSearchQuery");
				let oPrevStateQueryData = $.extend(true, {}, oAccountSearchModel.getProperty("/oPrevStateQueryData"));
				sSearchQuery = sSearchQuery.split(" ").join("");
				sSearchQuery = sSearchQuery.toLowerCase();
				if (sSearchQuery === "") {
					return;
				}
				let cvaAaccounts = $.extend(true, [], oPrevStateQueryData[sSearchQuery + "_AllAccounts"]);
				let lastUpdatedIndex = oPrevStateQueryData[sSearchQuery + "_LastUpdatedIndex"];
				if (lastUpdatedIndex < (cvaAaccounts.length - 1)) {
					newStartIndex = lastUpdatedIndex + 1;
					let totalPendingObjs = cvaAaccounts.length - lastUpdatedIndex;
					if (totalPendingObjs > 10) {
						newLastIndex = newStartIndex + 10;
					} else {
						newLastIndex = cvaAaccounts.length;
					}
					for (let i = newStartIndex; i < newLastIndex; i++) {
						let oTempObj = {
							AccountId: cvaAaccounts[i].AccountId,
							AccountName: cvaAaccounts[i].AccountName
						};
						oAccountSearchModel.setProperty("/lastUpdatedIndex", i);
						oAccountSearchModel.setProperty("/isAccountDialogBusy", true);
						oPrevStateQueryData[sSearchQuery + "_LastUpdatedIndex"] = i;
						oAccountSearchModel.setProperty("/oPrevStateQueryData", oPrevStateQueryData);
						try {
							let {
								data
							} = await AccountUtil.getAccountDetailsFromBupaInfoSet(i, false, true, sAccountId);
							let oAccountData = AccountHelper.fnHandlerGetAccountDetailSuccess(oTempObj, data);
							aAccounts.push(oAccountData);
						} catch (oError) {
							MessageToast.show("LOADMORE FAILED");
							console.log("ERROR :", oError);
						}
					}
					AccountHelper.fnCreateHashDataBasedOnAccId(aAccounts)
					oAccountSearchModel.setProperty("/aMasterAccountData", aAccounts);
					oAccountSearchModel.refresh(true);
				}
			}
		},

		//function to get status value based on status-ID
		getOpportunityStatus: function (StatusId) {
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let oOppStatusMasterMap = oStorage.get("pcOppStatusMasterMap")
			return oOppStatusMasterMap[StatusId].VALUE;
		},

		//function to formate Opportunity Date
		getOpportunityDate: function (date) {
			var dateFormat = DateFormat.getDateInstance({
				style: "medium"
			});
			if (date && date !== null && date !== "") {
				date = new Date(date);
				return dateFormat.format(date);
			} else {
				return null;
			}
		},

		//function to check value empty
		fnCheckEmpty: function (value) {
			if (value && value !== "") {
				return value;
			} else {
				return "Unavailable";
			}
		},
	});
	return oDialogController;
});