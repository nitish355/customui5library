sap.ui.define([
	"sap/ui/model/Filter",
	"sap/ui/core/Fragment",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"com/melody/lib/enum/Actions",
	"com/melody/lib/util/Algorithm",
	"com/melody/lib/classes/Account",
	"com/melody/lib/model/StorageModel",
	"sap/ui/model/resource/ResourceModel",
	"com/melody/lib/util/account/Account",
	"com/melody/lib/service/AccountService",
	"com/melody/lib/service/OpportunityService",
	"com/melody/lib/util/account/AccountDialogController",
], function (Filter, Fragment, FilterOperator, JSONModel, Actions, Algorithm, Account, oStorageModel, ResourceModel, AccountUtil,
	AccountService,
	OpportunityService,
	AccountDialogController) {
	"use strict";

	return {

		//accountCtrl points the parent "this" pointer
		fnStaticInit: function (oParentRef) {
			//accountCtrl points to the parent controller
			this.accountCtrl = oParentRef;
		},

		//function to open Opportunity Fragment
		onInitializeAccountDialog: async function (bOpenDialog) {
			let oThisController = this;
			if (!oThisController._oAccountDialog) {
				let oDialog = await Fragment.load({
					id: "_AccountDialog",
					name: "com.melody.lib.fragments.AccountDialog",
					controller: oThisController.AccountDialogController
				});
				oDialog.setModel(oThisController.getModel());
				oDialog.setModel("essentialModel", oThisController.getModel(Actions.oModels.EssentialModel));
				oThisController.addDependent(oDialog);
				oThisController.AccountDialogController.fnLoadLangModel(oDialog);
				oThisController._oAccountDialog = oDialog;
				if (bOpenDialog) {
					oDialog.open();
				}
			}
		},

		//function to get Dialog with ID
		fnGetDialogUsingId: function (dialogId, contentId) {
			return sap.ui.core.Fragment.byId(dialogId, contentId);
		},

		//function to load i18n for dialogs
		fnLoadResourceBundle: function (dialog) {
			let i18nModel = new ResourceModel({
				bundleName: "com.melody.lib.messagebundle"
			});
			if (dialog) {
				dialog.setModel(i18nModel, "i18n");
			}
		},

		fnClearFilterAdvSearchAccounts: function (oEvent) {
			const AccountUtil = this.accountCtrl.AccountUtil;
			const AccountHelper = this.accountCtrl.AccountHelper;
			let oAccountSearchModel = this.accountCtrl.getModel();
			oAccountSearchModel.setProperty("/sPlanningEntities", false);
			oAccountSearchModel.setProperty("/sGlobalUltimate", false);
			oAccountSearchModel.setProperty("/sIndustryKey", "");
			oAccountSearchModel.setProperty("/sRegionKey", "");
			oAccountSearchModel.setProperty("/sCountryKey", "");
			this.fnFilterAdvSearchAccounts(oEvent);
			oAccountSearchModel.refresh();
		},

		//funtion to handle advance search from the fragment
		fnAdvancedSearchHandler: async function (eventType, sValue, oPrevStateQueryData, oAccountModel) {

			let oThisController = this;
			let prevSavedKey;
			const AccountUtil = this.accountCtrl.AccountUtil;
			let oKeys = Object.keys(oPrevStateQueryData) || [];
			if (oKeys.length) {
				let iAccountIndex = oKeys.indexOf(sValue);
				prevSavedKey = (iAccountIndex !== -1) ? oKeys[iAccountIndex] : "";
			}

			if (prevSavedKey) {
				if (eventType === "object") {
					this.fnClearFilterAdvSearchAccounts();
				}
				oAccountModel.setProperty("/aPrevStateQueryIndex", oPrevStateQueryData[prevSavedKey]);
				let oResponse = AccountUtil.searchAccounts(sValue);
				oResponse.then((aAccounts) => {
					oThisController.fnSuccessSearchAccounts(sValue, aAccounts, true, "", Actions.AdvanceAccountSearch, Actions.ContainsQuery);
				});
			} else {
				if (eventType === "object") {
					this.fnClearFilterAdvSearchAccounts();
				}
				let oResponse = AccountUtil.searchAccounts(sValue);
				oResponse.then((aAccounts) => {
					oThisController.fnSuccessSearchAccounts(sValue, aAccounts, true, "", Actions.AdvanceAccountSearch);
				});
			}
		},

		//function to handle searchAccounts success
		fnSuccessSearchAccounts: function (searchValue, aAccountResults, bCvaFlag, oControl, searchType, sPrevQueryState) {
			let oThisController = this;
			let oAccountSearchModel = this.accountCtrl.getModel();
			let aFilter = new Filter({
				filters: [
					new Filter("AccountName", "Contains", searchValue),
					new Filter("AccountId", "Contains", searchValue)
				],
				and: false
			});

			if (bCvaFlag) {
				searchValue = searchValue.toLowerCase();
				const aFilteredData = [];
				for (let i = 0; i < aAccountResults.length; i++) {
					let oTempData = aAccountResults[i];
					let Account = oTempData.AccountId;
					let AccountName = oTempData.AccountName.toLowerCase();
					if (Account.includes(searchValue) || AccountName.includes(searchValue)) {
						aFilteredData.push(oTempData);
					}
				}
				oStorageModel.setProperty("/aCvaModelAccountData", aFilteredData);
				oThisController.fnHandleDataBasedOnSearchedType(searchValue, searchType, aFilteredData, sPrevQueryState, bCvaFlag, aAccountResults,
					oControl,
					aFilter);
			} else {
				oAccountSearchModel.setProperty("/aMasterSimpleSrchSAccountData", aAccountResults);
				oControl.getBinding("items").filter(aFilter);
				oAccountSearchModel.setProperty("/isAccountDialogBusy", false);
			}
			oAccountSearchModel.refresh();
		},

		//function to handle cva flag
		fnHandleDataBasedOnSearchedType: function (searchValue, searchType, aFilteredData, sPrevQueryState, bCvaFlag, aAccountResults, oControl,
			aFilter) {
			let oThisController = this;
			let oAccountSearchModel = this.accountCtrl.getModel();
			switch (searchType) {
			case Actions.AdvanceAccountSearch:
				oAccountSearchModel.setProperty("/aMasterAccountData", []);
				let oPrevStateQueryData = $.extend(true, {}, oAccountSearchModel.getProperty("/oPrevStateQueryData"));
				if (aFilteredData.length) {
					oThisController.fnHandleAdvancedSearchType(aFilteredData, sPrevQueryState);
				} else {
					oStorageModel.setProperty("/aCvaModelAccountData", []);
					oStorageModel.setProperty("/aCvaAccountData", []);
					oPrevStateQueryData[searchValue] = aFilteredData;
					oAccountSearchModel.setProperty("/oPrevStateQueryData", oPrevStateQueryData);
					oAccountSearchModel.refresh(true);
				}
				break;
			case Actions.SimpleAccountSearch:
				if (oStorageModel) {
					oStorageModel.setProperty("/aCvaModelAccountData", aAccountResults);
				}
				oAccountSearchModel.setProperty("/aMasterSimpleSrchSAccountData", aAccountResults);
				// oControl.getBinding("items").filter(aFilter);
				break;
			default:
				oAccountSearchModel.setProperty("/aMasterSimpleSrchSAccountData", aAccountResults);
			}
			oAccountSearchModel.setProperty("/Searching", false);
			oAccountSearchModel.setProperty("/isAccountDialogBusy", false);
		},

		//function to handle AdvancedSearchType
		fnHandleAdvancedSearchType: function (aFilteredData, sPrevQueryState) {
			let oThisController = this;
			const AccountUtil = this.accountCtrl.AccountUtil;
			let iDataLength = aFilteredData.length;
			let oAccountSearchModel = this.accountCtrl.getModel();
			let aMasterAccountData = $.extend(true, [], oAccountSearchModel.getProperty("/aMasterAccountData"));
			let oPrevStateQueryData = $.extend(true, {}, oAccountSearchModel.getProperty("/oPrevStateQueryData"));
			if (iDataLength > 100) {
				iDataLength = 100;
			}
			let aPromise = [];
			let aTrackAccountId = [];
			for (let i = 0; i < iDataLength; i++) {
				let iIndex = i;
				let oTempObj = aFilteredData[i];
				switch (sPrevQueryState) {
				case Actions.ContainsQuery:
					let aPrevStateQueryIndex = $.extend(true, [], oAccountSearchModel.getProperty("/aPrevStateQueryIndex"));
					let oSearchedObj = oThisController.fnFindSameAccountObject("AccountId", oTempObj.AccountId, aPrevStateQueryIndex);
					if (oSearchedObj) {
						if (oSearchedObj.hasOwnProperty("GlobalUltimate")) {
							aMasterAccountData.push(oSearchedObj);
						} else {
							aMasterAccountData.push(oTempObj);
							//TODO: index not required to send, confirm?
							aPromise.push(AccountUtil.getAccountDetailsFromBupaInfoSet(iIndex, "", "", oTempObj.AccountId));
						}
					} else {
						aMasterAccountData.push(oTempObj);
						//TODO: index not required to send, confirm?
						aPromise.push(AccountUtil.getAccountDetailsFromBupaInfoSet(iIndex, "", "", oTempObj.AccountId));
					}
					aTrackAccountId.push(oTempObj.AccountId);
					oAccountSearchModel.setProperty("/aMasterAccountData", aMasterAccountData);
					oAccountSearchModel.setProperty("/isAccountDialogBusy", false);
					if (iIndex + 1 === length) {
						oAccountSearchModel.setProperty("/lastUpdatedIndex", iIndex);
						oAccountSearchModel.setProperty("/oPrevStateQueryData", oPrevStateQueryData);
						oThisController.fnSetAccountMasterData();
					}
					break;
				default:
					oAccountSearchModel.setProperty("/lastUpdatedIndex", iIndex);
					aMasterAccountData.push(oTempObj);
					oAccountSearchModel.setProperty("/aMasterAccountData", aMasterAccountData)
					aTrackAccountId.push(oTempObj.AccountId);
					//TODO: index not required to send, confirm?
					aPromise.push(AccountUtil.getAccountDetailsFromBupaInfoSet(iIndex, "", "", oTempObj.AccountId));
				}
			}
			// aPromise.allSettled(aPromise)
			//TODO: Need to check this

			let oEssentialModel = this.accountCtrl.getModel(Actions.oModels.EssentialModel);
			const aCountryArr = $.extend(true, [], oEssentialModel.getProperty("/aCountryMasterData"));

			if (aPromise.length) {
				oAccountSearchModel.setProperty("/isAccountDialogBusy", true);
				Promise.all(aPromise)
					.then((aResponse) => {
						let aAccountData = [];
						for (let i = 0; i < aResponse.length; i++) {
							let oResponseData = aResponse[i].data;
							let oSelDataObj = aMasterAccountData.find((oData) => {
								//commented below condition as part of account serach issue fix
								// if (oData.AccountId === oResponseData.GlobalUltimateId) {
								// 	return true;
								// }
								//worst case if data not found
								if (oData.AccountId === oResponseData.BusinessPartnerNumber) {
									return true;
								}
							});

							if (oSelDataObj) {
								let oAccountData = oThisController.fnHandlerGetAccountDetailSuccess(oSelDataObj, oResponseData);
								const oCountry = aCountryArr.find(item => oAccountData.Country && (oAccountData.Country === item.CountryKey || oAccountData.Country ===
									item.CountryName));
								oAccountData.CountryName = (oCountry) ? oCountry.CountryName : oAccountData.Country;
								aAccountData.push(oAccountData);
							}
						}
						return aAccountData;
					}).then((aFormatedMasterAccountData) => {
						oAccountSearchModel.setProperty("/isAccountDialogBusy", false);
						oAccountSearchModel.setProperty("/aMasterAccountData", aFormatedMasterAccountData)
						oThisController.fnCreateHashDataBasedOnAccId(aFormatedMasterAccountData);
						oThisController.fnFilterAdvSearchAccounts();
					});
			}

		},

		//Function to find if an same object is present in the array already
		fnFindSameAccountObject: function (sProperty, Value, aResponseData) {
			let oSearchedObj = aResponseData.find(function (object) {
				return object[sProperty] === Value;
			});
			return oSearchedObj;
		},

		//function to handle Get Account Detail Success
		fnHandlerGetAccountDetailSuccess: function (oSelDataObj, oResponse, isMyAccounts) {
			let oThisController = this;
			let oLastAccountObj = {};
			const AccountUtil = this.accountCtrl.AccountUtil;
			let oCurrentAccObj = oSelDataObj.AccountId;
			let oAccountSearchModel = this.accountCtrl.getModel();
			let oEssentialModel = this.accountCtrl.getModel(Actions.oModels.EssentialModel);
			let lastUpdateIndex = oAccountSearchModel.getProperty("/lastUpdatedIndex");
			oSelDataObj = AccountUtil.fnSetFormatDataAccountDetailSuccess(oSelDataObj, oResponse);
			if (isMyAccounts) {
				oLastAccountObj = oAccountSearchModel.getProperty("/aMyMasterAccountData/" + lastUpdateIndex + "/AccountId");
			} else {
				oLastAccountObj = oAccountSearchModel.getProperty("/aMasterAccountData/" + lastUpdateIndex + "/AccountId");
			}
			if (oCurrentAccObj === oLastAccountObj) {
				oThisController.fnSetAccountMasterData(isMyAccounts);
				oAccountSearchModel.setProperty("/isAccountDialogBusy", false);
			}

			if (oResponse.IndustryName && oResponse.Industry) {
				let oIndustryObj = {
					Description: oResponse.IndustryName,
					IndustryId: oResponse.Industry
				};
				let aIndustryArr = $.extend(true, [], oEssentialModel.getProperty("/aIndustry"));
				let oIndustryPresent = oThisController.fnFindSameAccountObject("IndustryId", oResponse.Industry, aIndustryArr);
				if (!oIndustryPresent) {
					aIndustryArr.push(oIndustryObj);
				}
				oEssentialModel.setProperty("/aIndustry", aIndustryArr);
			}
			oEssentialModel.refresh();
			oAccountSearchModel.refresh();
			return oSelDataObj;
		},

		//Function to create Master data for local filtering of Industry, Region, Country
		fnSetAccountMasterData: function (isMyAccounts) {
			let oThisController = this,
				accounts;
			let oAccountSearchModel = this.accountCtrl.getModel();
			let lastUpdateIndex = oAccountSearchModel.getProperty("/lastUpdatedIndex");
			let aCvaAccountData = $.extend(true, [], oStorageModel.getProperty("/aCvaAccountData"));
			let aMyMasterAccountData = $.extend(true, [], oAccountSearchModel.getProperty("/aMyMasterAccountData"));
			let aMasterAccountData = $.extend(true, [], oAccountSearchModel.getProperty("/aMasterAccountData"));
			let oPrevStateQueryData = $.extend(true, {}, oAccountSearchModel.getProperty("/oPrevStateQueryData"));
			if (isMyAccounts) {
				accounts = oAccountSearchModel.getProperty("/aMyMasterAccountData");
			} else {
				accounts = oAccountSearchModel.getProperty("/aMasterAccountData");
			}
			//Below lines of code is used to store Search query and its result array data, to avoid same service calls again and again
			if (!isMyAccounts) {
				let sSearchQuery = oAccountSearchModel.getProperty("/sSearchQuery");
				sSearchQuery = sSearchQuery.split(" ").join("");
				sSearchQuery = sSearchQuery.toLowerCase();
				if (!oPrevStateQueryData[sSearchQuery]) {
					oPrevStateQueryData[sSearchQuery] = aMasterAccountData;
					oPrevStateQueryData[sSearchQuery + "_AllAccounts"] = aMasterAccountData;
					oPrevStateQueryData[sSearchQuery + "_LastUpdatedIndex"] = lastUpdateIndex;
					oAccountSearchModel.setProperty("/oPrevStateQueryData", oPrevStateQueryData);
				} else {
					oPrevStateQueryData[sSearchQuery] = aMasterAccountData;
					oAccountSearchModel.setProperty("/oPrevStateQueryData", oPrevStateQueryData);
				}
			} else {
				oAccountSearchModel.setProperty("/aMasterAccountData", aMyMasterAccountData);
			}
			oAccountSearchModel.setProperty("/isAccountDialogBusy", false);
			oAccountSearchModel.refresh(true);
			this.fnFilterAdvSearchAccounts();
		},

		//Function to filter Accounts in Advanced search
		fnFilterAdvSearchAccounts: function (oEvent) {
			let aFilter = [],
				sPlanningEntitiesKey = "",
				sGlobalUltimateKey = "";
			let oAccountSearchModel = this.accountCtrl.getModel();
			let table = this.fnGetDialogUsingId("_AccountDialog", "ACCOUNT_ADV_SEARCH_TBL");
			table.getBinding("rows").filter([]);
			let sPlanningEntities = oAccountSearchModel.getProperty("/sPlanningEntities");
			let sGlobalUltimate = oAccountSearchModel.getProperty("/sGlobalUltimate");
			let sIndustryKey = oAccountSearchModel.getProperty("/sIndustryKey");
			let sRegionKey = oAccountSearchModel.getProperty("/sRegionKey");
			let sCountryKey = oAccountSearchModel.getProperty("/sCountryKey");
			if (oEvent) {
				if (oEvent.getSource().getMetadata().getElementName() === "sap.m.CheckBox") {
					if (sPlanningEntities) {
						if (oEvent.getSource().getName() === "PLANNING_ENTITY" || sPlanningEntities) {
							sPlanningEntitiesKey = (sPlanningEntities === true) ? "true" : "false";
						}
					}
					if (sGlobalUltimate) {
						if (oEvent.getSource().getName() === "GLOBAL_ULTIMATE" || sGlobalUltimate) {
							sGlobalUltimateKey = (sGlobalUltimate === true) ? "true" : "false";
						}
					}
				} else {
					if (sPlanningEntities) {
						sPlanningEntitiesKey = (sPlanningEntities === true) ? "true" : "false";
					}
					if (sGlobalUltimate) {
						sGlobalUltimateKey = (sGlobalUltimate === true) ? "true" : "false";
					}
				}
			} else {
				if (sPlanningEntities) {
					sPlanningEntitiesKey = (sPlanningEntities === true) ? "true" : "false";
				}
				if (sGlobalUltimate) {
					sGlobalUltimateKey = (sGlobalUltimate === true) ? "true" : "false";
				}
			}
			if (sPlanningEntitiesKey) {
				aFilter.push(new sap.ui.model.Filter("IsPlanningEntity", "EQ", sPlanningEntitiesKey));
			}
			if (sGlobalUltimateKey) {
				aFilter.push(new sap.ui.model.Filter("GlobalUltimate", "EQ", sGlobalUltimateKey));
			}
			if (sIndustryKey) {
				aFilter.push(new sap.ui.model.Filter("IndustryCode", "EQ", sIndustryKey));
			}
			if (sRegionKey) {
				aFilter.push(new sap.ui.model.Filter("GlobalRegion", "EQ", sRegionKey));
			}
			if (sCountryKey) {
				aFilter.push(new sap.ui.model.Filter("Country", "EQ", sCountryKey));
			}
			table.getBinding("rows").filter(aFilter);

			let noOfRows = table.getBinding("rows").getLength();
			if (noOfRows === 0) {
				oAccountSearchModel.setProperty("/visibleRowCount", 1);
				table.setVisibleRowCountMode("Fixed");
			} else if (noOfRows > 0 && noOfRows <= 5) {
				oAccountSearchModel.setProperty("/visibleRowCount", noOfRows);
				table.setVisibleRowCountMode("Fixed");
			} else {
				table.setVisibleRowCountMode("Auto");
			}
		},

		//Function to save User's Account Search filter variant
		fnSaveAccSearchFilterVariant: async function () {
			let oThisController = this;
			let oAccountSearchModel = this.accountCtrl.getModel();
			let oEssentialModel = this.accountCtrl.getModel(Actions.oModels.EssentialModel);
			let userId = oEssentialModel.getProperty("/userId");
			let sPlanningEntities = oAccountSearchModel.getProperty("/sPlanningEntities");
			let sGlobalUltimate = oAccountSearchModel.getProperty("/sGlobalUltimate");
			let sIndustryKey = oAccountSearchModel.getProperty("/sIndustryKey");
			let sRegionKey = oAccountSearchModel.getProperty("/sRegionKey");
			let sCountryKey = oAccountSearchModel.getProperty("/sCountryKey");
			let sSearchQuery = oAccountSearchModel.getProperty("/sSearchQuery");
			let variantid = oAccountSearchModel.getProperty("/variantid");

			if (!userId) {
				let oResponse = await OpportunityService.getUserDetail();
				userId = oResponse.data.results[0].UserId;
				oEssentialModel.setProperty("/userId", userId);
			}
			if (!variantid) {
				variantid = "";
			}
			let oFilterData = {
				sPlanningEntities: sPlanningEntities,
				sGlobalUltimate: sGlobalUltimate,
				sIndustryKey: sIndustryKey,
				sRegionKey: sRegionKey,
				sCountryKey: sCountryKey,
				sSearchQuery: sSearchQuery
			};
			let oData = {
				variantid: variantid,
				variant_name: "Filter Variant",
				author: userId,
				type: "P",
				filterstring: JSON.stringify(oFilterData),
				applicationid: "ACCNT",
				operationflag: false
			};

			AccountService.setUserSrchAcctVariant(oData).then((oResponse) => {
				let {
					data
				} = oResponse
				oThisController.fnSetUserFilterVariant(data);
			}).catch((oError) => {
				sap.m.MessageBox.error("Error in saving Filter variant");
			});
		},

		//Function to update the user filter variant
		fnSetUserFilterVariant: function (oResponse) {
			var oData = "";
			if (oResponse.hasOwnProperty("results")) {
				oData = oResponse.results[0];
			} else {
				oData = oResponse;
			}
			var oAccountSearchModel = this.accountCtrl.getModel();
			if (!oData) {
				oAccountSearchModel.setProperty("/variantid", "");
				oAccountSearchModel.setProperty("/sPlanningEntities", false);
				oAccountSearchModel.setProperty("/sGlobalUltimate", false);
				oAccountSearchModel.setProperty("/sIndustryKey", "");
				oAccountSearchModel.setProperty("/sRegionKey", "");
				oAccountSearchModel.setProperty("/sCountryKey", "");
				oAccountSearchModel.setProperty("/sSearchQuery", "");
			} else {
				oAccountSearchModel.setProperty("/variantid", oData.variantid);
				if (oData.filterstring) {
					oData = JSON.parse(oData.filterstring);
				}
				oAccountSearchModel.setProperty("/sPlanningEntities", oData.sPlanningEntities);
				oAccountSearchModel.setProperty("/sGlobalUltimate", oData.sGlobalUltimate);
				oAccountSearchModel.setProperty("/sIndustryKey", oData.sIndustryKey);
				oAccountSearchModel.setProperty("/sRegionKey", oData.sRegionKey);
				oAccountSearchModel.setProperty("/sCountryKey", oData.sCountryKey);
				oAccountSearchModel.setProperty("/sSearchQuery", oData.sSearchQuery);
			}
			oAccountSearchModel.refresh();
		},

		//function to search the data in prevStateObject
		fnSearchDataInPrevStateObject: function (sValue, oPrevStateQueryData) {
			let oThisController = this;
			let AccountResult = [];
			let bValuePresent = false;
			sValue = sValue.toString().trim();
			let isId = (Number(sValue)) ? true : false;
			let oEssentialModel = this.accountCtrl.getModel(Actions.oModels.EssentialModel);
			let oAccountHashData = $.extend(true, {}, oEssentialModel.getProperty("/oAccountHashData"));
			let aKeys = Object.keys(oPrevStateQueryData);
			if (!aKeys.length) {
				return {
					bValuePresent
				};
			}

			if (isId && Object.keys(oAccountHashData).length) {
				let oAccount = Algorithm.findItem(sValue, oAccountHashData);
				if (oAccount) {
					bValuePresent = true;
					AccountResult.push(oAccount);
				}
				if (AccountResult.length) {
					return {
						bValuePresent,
						AccountResult
					};
				}
			}
			//Below logic is to find data in deeper objects from the prevQueryStateData
			AccountResult = [];
			sValue = sValue.toLowerCase();
			let isMoreWords = (sValue.split(" ").length >= 2) ? true : false;
			let sFirstWord = (isMoreWords) ? sValue.split(" ")[0] : "";
			let iSearchedKey = -1;
			if (sFirstWord) {
				iSearchedKey = aKeys.indexOf(sFirstWord);
			}
			let oQueryResult = this.fnFindDeeperInQueryData({
				bValuePresent,
				aKeys,
				iSearchedKey,
				AccountResult,
				isMoreWords,
				oPrevStateQueryData,
				sValue
			});
			return oQueryResult;
		},

		//funtion to find data deeper in all oPrevQueryStateData
		fnFindDeeperInQueryData: function (oQueryObject) {
			let oThisController = this;
			let {
				bValuePresent,
				aKeys,
				iSearchedKey,
				AccountResult,
				isMoreWords,
				oPrevStateQueryData,
				sValue
			} = oQueryObject;
			for (let i = 0; i < aKeys.length; i++) {
				let sTempKey = aKeys[i];
				let oTempResult;
				if (iSearchedKey !== -1) {
					let aTempPrevQueryData = $.extend(true, [], oPrevStateQueryData[aKeys[iSearchedKey]]);
					oTempResult = oThisController.fnFindDataInPrevQueryData(AccountResult, aTempPrevQueryData, sValue);
					if (oTempResult.bValuePresent) {
						return oTempResult;
					}
				}

				let aTempValue = $.extend(true, [], oPrevStateQueryData[sTempKey]);
				if (aTempValue.length) {
					const oTempResult = aTempValue.find((oData) => {
						let accountName = oData.AccountName;
						if (accountName) {
							accountName = accountName.toLowerCase();
						}
						if (isMoreWords && (oData.AccountId.includes(sValue) || accountName.includes(sValue))) {
							return true;
						}
					});
					if (oTempResult) {
						const iIndex = AccountResult.findIndex((oAccData) => {
							return oAccData.AccountId === oTempResult.AccountId;
						});
						if (iIndex === -1) {
							bValuePresent = true;
							AccountResult.push(oTempResult);
						}
					}
				}
			}
			return {
				bValuePresent,
				AccountResult
			};
		},

		//function to find data inside the prevQueryState Data
		fnFindDataInPrevQueryData: function (AccountResult, aQueryData, value) {
			let bValuePresent = false
			for (let i = 0; i < aQueryData.length; i++) {
				let oTempData = aQueryData[i];
				let accountName = oTempData.AccountName;
				if (accountName) {
					accountName = accountName.toLowerCase();
				}
				if (accountName.includes(value)) {
					let iIndex = AccountResult.findIndex((oAccData) => {
						return oAccData.AccountId === oTempData.AccountId;
					});
					if (iIndex === -1) {
						bValuePresent = true;
						AccountResult.push(oTempData);
					}
				}
			}
			return {
				bValuePresent: bValuePresent,
				AccountResult: AccountResult
			}
		},

		//function to handle search
		fnAccountSearchHandler: async function (sValue, selectedIconTabKey, eventType) {
			let oThisController = this;
			sValue = sValue.toLowerCase();
			const AccountUtil = this.accountCtrl.AccountUtil;
			let oAccountModel = this.accountCtrl.getModel();
			oStorageModel.setProperty("/aCvaAccountData", []);
			oStorageModel.setProperty("/isAccountDialogBusy", true);
			oAccountModel.setProperty("/aMasterAccountData", []);
			oAccountModel.setProperty("/isMyAccountsCountVisible", false);
			switch (selectedIconTabKey) {
			case Actions.AdvanceAccountSearch:
				let oPrevStateQueryData = $.extend(true, {}, oAccountModel.getProperty("/oPrevStateQueryData"));
				let sTempValue = sValue.replace(/\s+/g, '');
				if (oPrevStateQueryData[sTempValue] && oPrevStateQueryData[sTempValue] instanceof Array && oPrevStateQueryData[sTempValue].length) {
					oAccountModel.setProperty("/aMasterAccountData", oPrevStateQueryData[sTempValue]);
					oThisController.fnSetAccountMasterData();
					oAccountModel.refresh(true);
					oAccountModel.setProperty("/isAccountDialogBusy", false);
					return;
				}
				let oDataSetPresent = oThisController.fnSearchDataInPrevStateObject(sValue, oPrevStateQueryData);
				if (oDataSetPresent.bValuePresent) {
					oAccountModel.setProperty("/aMasterAccountData", oDataSetPresent.AccountResult);
					oThisController.fnSetAccountMasterData();
					oAccountModel.refresh(true);
					oAccountModel.setProperty("/isAccountDialogBusy", false);
					return;
				}
				oAccountModel.setProperty("/isAccountDialogBusy", true);
				setTimeout(function () {
					oThisController.fnAdvancedSearchHandler(eventType, sValue, oPrevStateQueryData, oAccountModel);
				}, 500);

				break;
			case Actions.SimpleAccountSearch:
				const oSimpleSearchList = oThisController.fnGetDialogUsingId("_AccountDialog", Actions.AccountSimpleSrchListId);
				let oResponse = AccountUtil.searchAccounts(sValue);
				oResponse.then((aAccounts) => {
					oThisController.fnSuccessSearchAccounts(sValue, aAccounts, true, oSimpleSearchList, Actions.SimpleAccountSearch, );
				});
				break;
			default:
			}
		},

		//function to create hash table search for accounts based on ID
		fnCreateHashDataBasedOnAccId: function (aFormattedData) {
			let oAccountModel = this.accountCtrl.getModel();
			oAccountModel.setProperty("/isMyAccountsCountVisible", true);
			let oEssentialModel = this.accountCtrl.getModel(Actions.oModels.EssentialModel);
			let oHashData = $.extend(true, {}, oEssentialModel.getProperty("/oAccountHashData"));
			for (let i = 0; i < aFormattedData.length; i++) {
				let oTempData = aFormattedData[i];
				let accountId = oTempData.AccountId;
				let accountName = oTempData.AccountName;
				if (!oHashData[accountId] && accountId) {
					oHashData[accountId] = oTempData;
				}
			}
			oEssentialModel.setProperty("/oAccountHashData", oHashData);
			oAccountModel.setProperty("/isMyAccountsCountVisible", false);
			oEssentialModel.refresh();
		},

		//Function to get User's Account Search filter variant
		fnGetAccSearchFilterVariant: function (init, variantId) {
			let oThisController = this;
			let oResponse = AccountService.getUserSrchAcctVariant();
			oResponse.then((oResponse) => {
				let {
					data
				} = oResponse
				if (data && data.hasOwnProperty("results")) {
					let oVariant = $.extend(true, {}, data.results[0]);
					oThisController.fnSetUserFilterVariant(oVariant);
				}
			});
		},

		//function to help fetchAccountDetails for Advance Search
		fnFetchAccountDetailHelperFunction: function (oAccount) {
			let oThisController = this;
			const oEssentialModel = this.accountCtrl.getModel(Actions.oModels.EssentialModel);
			this.fnSaveAccSearchFilterVariant();

			//Set the account Data to opportunity Ctrl if available
			const opportunityCtrl = this.accountCtrl.fnGetOpportunityControl();
			if (opportunityCtrl) {
				const model = opportunityCtrl.getModel();
				model.setProperty("/isCvaSelected", true);
				model.setProperty("/oSelectedAccountDetails", oAccount);
				model.setProperty("/bFilterNonVatAccBased", true);
				model.setProperty("/bRemoveNonVAtAccFilter", false);
				model.refresh();
			}

			this.fnSetOpportunityBasedOnAccount(oAccount).then((aResponse) => {
				oAccount.oOpportunityData = aResponse;
				oAccount.isSelected = true;
				oThisController.accountCtrl.setSelectedAccount(oAccount);
				oThisController.accountCtrl._oAccountDialog.close();
				oThisController.accountCtrl._oAccountDialog.destroy();
				oThisController.accountCtrl._oAccountDialog = null;
				oEssentialModel.refresh();
			});

		},

		//function to set Opportunities to selected Account Data
		fnSetOpportunityBasedOnAccount: function (oAccount) {
			let aCloneOpportunities = $.extend(true, [], oStorageModel.getProperty("/aCloneOpportunities"));
			let aFilterOpportunityData = aCloneOpportunities.filter((oOppData) => {
				return oOppData.AccountId === oAccount.AccountId;
			});
			return new Promise((resolve, reject) => {
				return resolve(aFilterOpportunityData);
			});
		},

		//function to open Account Info Fragment
		onAccountInformationHandler: function (oControlSource) {
			let oThisController = this;
			// let controller = OpportunityDialogController.bind(this);
			if (!oThisController._oAccountInfoDialog) {
				oThisController._oAccountInfoDialog = Fragment.load({
					id: "_AccountInformationDialog",
					name: "com.melody.lib.fragments.AccountInformation",
					controller: oThisController.AccountDialogController
				}).then(function (oDialog) {
					oDialog.setModel(oThisController.getModel());
					oThisController.addDependent(oDialog);
					oThisController.AccountDialogController.fnLoadLangModel(oDialog);
					return oDialog;
				}.bind(oThisController));
			}
			oThisController._oAccountInfoDialog.then(function (oDialog) {
				oDialog.openBy(oControlSource);
			});
		},

	};
}, true);