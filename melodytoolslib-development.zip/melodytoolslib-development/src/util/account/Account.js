sap.ui.define([
	"jquery.sap.global",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"com/melody/lib/enum/Actions",
	"com/melody/lib/util/Algorithm",
	"com/melody/lib/classes/Account",
	"com/melody/lib/model/StorageModel",
	"com/melody/lib/service/AccountService",
	"com/melody/lib/service/OpportunityService",
	"com/melody/lib/util/account/AccountHelper",
	"com/melody/lib/util/opportunity/Opportunity",
	"com/melody/lib/util/account/AccountDialogController",
], function (jquery, MessageToast, Filter, FilterOperator, JSONModel, Actions, Algorithm, Account, oStorageModel, AccountService,
	OpportunityService,
	AccountHelper,
	OpportunityUtil,
	AccountDialogController) {
	"use strict";

	return {
		//to initialize the this.accountCtrl to the parent "this" pointer
		fnStaticInit: function (oParentRef) {
			this.accountCtrl = oParentRef;
			this.accountCtrl.OpportunityUtil = OpportunityUtil;
			try {
				this.accountCtrl.AccountHelper.fnGetAccSearchFilterVariant(true);
				this.getConstantData();
			} catch (oError) {
				console.log("ERROR IN AccountUtil fnStaticInit : ", oError);
			}
		},

		//Fuction to set the visiblity of clear btn //TODO:Need to check which data
		fnSetAccountClearBtn: function (showClear) {
			const oEssentialModel = this.accountCtrl.getModel(Actions.oModels.EssentialModel);
			oEssentialModel.setProperty("/bClearIconVisible", showClear);
		},

		//Deprecated function TODO: Need to check
		getMyAccounts: async function () {
			const aAccounts = [];
			const oResult = JSON.parse(await AccountService.getMyAccounts());
			const aData = oResult.data;
			$.each(aData, function (index, item) {
				const oAccount = new Account({
					AccountId: item.account.id,
					AccountName: item.account.description,
					IsMyAccount: true
				});
				aAccounts.push(oAccount);
			});
			return aAccounts;
		},

		searchAccounts: async function (sValue) {
			const aAccounts = [];
			const aFilters = [
				new Filter("TYPE", FilterOperator.EQ, "A")
			];

			let oModel;
			if (this.accountCtrl) {
				oModel = this.accountCtrl.getModel();
			}

			try {
				const oResponse = await OpportunityService.getBusinessPartners(sValue.toLowerCase(), aFilters);
				let {
					data
				} = oResponse;
				let aResults = (data.hasOwnProperty("results")) ? data.results : [];
				//Create Account Data from the classes
				let aAccounts = aResults.map((data) => {
					return new Account({
						AccountId: data.PARTNER,
						AccountName: data.NAME,
						Description: "",
						AccountId_Name: data.NAME + '-' + data.PARTNER
					});
				});

				let startsWithSearch = [];
				let	oFilteredData = aAccounts;
                let others = [];
				let that = this;
				that.searhQuery = sValue;
                    oFilteredData.forEach(function(item) {
                     
                      if ( (item.AccountName).toLowerCase().startsWith((that.searhQuery).toLowerCase())) {
                        startsWithSearch.push(item);
                    } else {
                        others.push( item);
                    }

                  });
                  startsWithSearch.sort(function(a, b) {
                    return a.AccountName.localeCompare(b.AccountName);
                  });
                  others.sort(function(a, b) {
                    return a.AccountName.localeCompare(b.AccountName);
                  });
                  // Merge the two arrays
                  oFilteredData= [];
                  oFilteredData = startsWithSearch.concat(others);
				  return oFilteredData;
			} catch (oError) {
				if (oModel) {
					oModel.setProperty("/isAccountDialogBusy", false);
				}
				// MessageToast.show(`Account data for ${sValue} Not Found`);
			}
			// let aData = Algorithm.fnPerformPromiseInBatch(aPromise, 20);
		},

		getAdvanceDetails: async function (accounts) {
			const aAccounts = [];
			const aResponses = await AccountService.getAdvanceDetails(accounts);
			for (let i = 0; i < aResponses.length; i++) {
				if (aResponses[i].status === "success") {
					const oResult = JSON.parse(aResponses[i].value);
					let bGlobalUltimate = false,
						sAccount, sAccountName, sIndustryCode, sIndustry, sPlanningEntityId, sPlanningEntityName, sCountry, sCity, sStreet;
					if (oResult.globalUltimate) {
						bGlobalUltimate = true;
					}

					if (oResult.address) {
						if (oResult.address.line1) {
							sStreet = oResult.address.line1;
						}

						if (oResult.address.line2) {
							if (sStreet) {
								sStreet = sStreet + ", " + oResult.address.line2;
							} else {
								sStreet = oResult.address.line2;
							}
						}

						if (oResult.address.line3) {
							sCity = oResult.address.line3;
						}
					}

					if (oResult.masterData) {
						if (oResult.masterData.account) {
							sAccount = oResult.masterData.account.id;
							sAccountName = oResult.masterData.account.description;
						}

						if (oResult.masterData.country) {
							sCountry = oResult.masterData.country.description;
						}

						if (oResult.masterData.masterCode) {
							sIndustryCode = oResult.masterData.masterCode.id;
							sIndustry = oResult.masterData.masterCode.description;
						}

						if (oResult.masterData.planningEntity) {
							sPlanningEntityId = oResult.masterData.planningEntity.id;
							sPlanningEntityName = oResult.masterData.planningEntity.description;
						}
					}

					const oAccount = new Account({
						AccountId: sAccount,
						AccountName: sAccountName,
						Industry: sIndustry,
						IndustryCode: sIndustryCode,
						PlanningEntityId: sPlanningEntityId,
						PlanningEntityName: sPlanningEntityName,
						Country: sCountry,
						City: sCity,
						Street: sStreet,
						IsPlanningEntity: (sPlanningEntityId && sAccount && sPlanningEntityId === sAccount) ? true : false,
						IsGlobalUltimate: bGlobalUltimate,
						IsAdvanceSearched: true
					});
					aAccounts.push(oAccount);
				}
			}
			return aAccounts;
		},

		//function to get Country Master Data
		getCountryMasterData: async function () {
			let oResponse = AccountService.getCountryMasterData();
			return oResponse;
		},

		//function to handle filterAccount
		filterAccounts: function () {
			const oSimpleSearchList = this.fnGetDialogUsingId("_AccountDialog", "idSimpleSearchList");
			const aFilters = this.accountCtrl.filters;
			if (!aFilters || aFilters.length === 0) {
				aFilters.push(new Filter("IsMyAccount", FilterOperator.EQ, true));
			}
			const oBinding = oSimpleSearchList.getBinding("items");
			if (oBinding) {
				oBinding.filter(aFilters);
			}
		},

		//function to get Dialog with ID
		fnGetDialogUsingId: function (dialogId, contentId) {
			return sap.ui.core.Fragment.byId(dialogId, contentId);
		},

		//function to get account details from BUPA Info Set
		getAccountDetailsFromBupaInfoSet: async function (accountIndex, isMyAccounts, isAccountChanged, accountId) {

			let oThisController = this;
			let AccountId = "";
			let oSelDataObj = {};
			let oAccountSearchModel = this.accountCtrl.getModel();
			let aCvaAccountData = $.extend(true, [], oStorageModel.getProperty("/aCvaAccountData"));
			if (isMyAccounts) {
				oSelDataObj = oAccountSearchModel.getProperty("/aMyMasterAccountData/" + accountIndex);
			} else {
				oSelDataObj = oAccountSearchModel.getProperty("/aMasterAccountData/" + accountIndex);
			}

			AccountId = (accountId) ? accountId : oSelDataObj.AccountId;
			if (AccountId) {
				let oResponse = AccountService.getZSBupaInfoSet(AccountId);
				return oResponse;
			}
		},

		//function to set Account Name to Account Input once Opportunity is selected
		fnSetAccountNameToAccInput: function (oAccountData, bClear) {
			let oInputControl = this.accountCtrl.getAggregation("_input");
			let oAccountSearchModel = this.accountCtrl.getModel();
			const oEssentialModel = this.accountCtrl.getModel(Actions.oModels.EssentialModel);
			if (oInputControl) {
				if (bClear) {
					oInputControl.setValue("");
					oInputControl.setTooltip("");
					this.accountCtrl._setControlVisibility("CREATE");
				} else {
					oInputControl.setValue(oAccountData.AccountId + " -" + oAccountData.AccountName);
					oInputControl.setTooltip(oAccountData.AccountId + " -" + oAccountData.AccountName);
					this.accountCtrl._setControlVisibility("EDIT");
					oAccountSearchModel.setProperty("/oSelectedAccountData", oAccountData);
				}
			}
			oEssentialModel.refresh();
			oAccountSearchModel.refresh();
		},

		//function create data for account details success
		fnSetFormatDataAccountDetailSuccess: function (oSelDataObj, oResult) {
			if (!oSelDataObj) {
				return false;
			}
			let street = oResult.HouseNo ? "#" + oResult.HouseNo + ", " : "";
			street = street + oResult.Street;
			if (street) {
				street = oResult.ZipCode ? street + ", " + oResult.ZipCode : street;
			} else {
				street = oResult.ZipCode ? oResult.ZipCode : "";
			}
			oSelDataObj.GlobalUltimate = oResult.GlobalUltimateId === oSelDataObj.AccountId ? "true" : "false";
			oSelDataObj.Street = street;
			oSelDataObj.Country = oResult.Country;
			oSelDataObj.Industry = oResult.IndustryName;
			oSelDataObj.IndustryName = oResult.IndustryName;
			oSelDataObj.IndustryCode = oResult.Industry;
			oSelDataObj.IsPlanningEntity = oResult.PlanningEntityId ? "true" : "false";
			oSelDataObj.PE_ID = oResult.PlanningEntityId;
			oSelDataObj.PE_Name = oResult.PlanningEntityName;
			oSelDataObj.City = oResult.City;
			oSelDataObj.RegionCode = oResult.Region;
			oSelDataObj.GlobalRegion = oResult.Region;
			return oSelDataObj;
		},

		//function to fetch All Data of Account Based on AccountId:
		fnFetchAccountDetails: async function (accountId) {

			let oThisController = this;
			const AccountHelper = this.accountCtrl.AccountHelper;
			let oEssentialModel = this.accountCtrl.getModel(Actions.oModels.EssentialModel);
			let oAccountHashData = $.extend(true, {}, oEssentialModel.getProperty("/oAccountHashData"));
			let oUrlConstants = $.extend(true, {}, oStorageModel.getProperty("/oConstants"));
			let oAccountData = Algorithm.findItem(accountId, oAccountHashData);
			if (oAccountData) {
				oAccountData.harmonyLink = (Object.keys(oUrlConstants).length && oUrlConstants.hasOwnProperty("0186")) ? oUrlConstants["0186"].field_value +
					oAccountData.AccountId : "";
				return oAccountData;
			}
			let aResponse = await this.searchAccounts(accountId);
			oAccountData = aResponse.find((oData) => {
				return oData.AccountId === accountId;
			}) || {};
			let {
				data
			} = await AccountService.getZSBupaInfoSet(accountId);
			let aBPResponse = await Promise.all(oThisController.fnProvideBPAttributeSetSearchAccount({
				bAccountId: true,
				AccountId: accountId
			}));
			let oBPdata = aBPResponse[0].data;
			oAccountData = this.fnSetAccountDataBPAttribSet(oAccountData, oBPdata);
			let oFormatedData = this.fnSetFormatDataAccountDetailSuccess(oAccountData, data);
			oFormatedData.harmonyLink = (Object.keys(oUrlConstants).length && oUrlConstants.hasOwnProperty("0186")) ? oUrlConstants["0186"].field_value +
				oFormatedData.AccountId : "";
			if (oFormatedData) {
				//Create BP AttributeSet data for Account Data
				AccountHelper.fnCreateHashDataBasedOnAccId([oFormatedData])
			}
			return new Promise((resolve, reject) => {
				return resolve(oFormatedData);
			});
		},

		//function to set data,clear icon & info icon based on visible
		fnSetControlPropertiesBasedOnView: async function (viewMode, oAccountData) {
			let oFormattedAccountData;
			let accountId = oAccountData.accountId;
			if (!accountId) {
				viewMode = "";
			}
			const oDefaultModel = this.accountCtrl.getModel();
			let oEssentialModel = this.accountCtrl.getModel(Actions.oModels.EssentialModel);
			if (accountId) {
				let oResponseData = await this.fnFetchAccountDetails(accountId)
				oFormattedAccountData = {
					AccountId: oResponseData.AccountId,
					AccountName: oResponseData.AccountName,
					OWNER_NAME: oResponseData.OWNER_NAME,
					Active_Account_Status: oResponseData.Active_Account_Status,
					Regional_Buying_Classification: oResponseData.Regional_Buying_Classification,
					Regional_Buying_Lifecycle: oResponseData.Regional_Buying_Lifecycle,
					Industry: oResponseData.Industry,
					IAC: oResponseData.Internal_Account_Classification,
					ISS: oResponseData.ISS,
					IMS: oResponseData.IMS,
					ERPID: oResponseData.ERPID,
					harmonyLink: oResponseData.harmonyLink,
				};
			}
			switch (viewMode) {
			case Actions.oViewModes.CreateMode:
				this.accountCtrl._setControlVisibility("EDIT");
				oDefaultModel.setProperty("/oSelectedAccountData", oFormattedAccountData);
				break;
			case Actions.oViewModes.DisplayMode:
				this.accountCtrl._setControlVisibility("DISPLAY");
				oDefaultModel.setProperty("/oSelectedAccountData", oFormattedAccountData);
				break;
			case Actions.oViewModes.EditMode:
				this.accountCtrl._setControlVisibility("EDIT");
				oDefaultModel.setProperty("/oSelectedAccountData", oFormattedAccountData);
				break;
			default:
				this.accountCtrl.setAccountId("");
				oDefaultModel.setProperty("/oSelectedAccountData", {});
			}
			oDefaultModel.refresh();
			oEssentialModel.refresh();
		},

		//function to get Promise for SearchAccount
		fnProvideBPAttributeSetSearchAccount: function (oPromiseDetails) {
			let aPromise = [];
			let aResults = oPromiseDetails.aResults;
			if (oPromiseDetails.bAccountId) {
				aPromise.push(OpportunityService.getBusinessPartnerAttribSet(oPromiseDetails.AccountId));
				return aPromise;
			}

			for (let i = 0; i < aResults.length; i++) {
				let oTempData = aResults[i];
				aPromise.push(OpportunityService.getBusinessPartnerAttribSet(oTempData.PARTNER));
			}
			return aPromise;
		},

		//function to set format account with respect to BP Attribute set
		fnSetAccountDataBPAttribSet: function (oSelectedAccount, oResponseData) {
			let data = oResponseData;
			if (!oSelectedAccount.hasOwnProperty("AccountId") || !oSelectedAccount.hasOwnProperty("AccountName")) {
				oSelectedAccount.AccountId = oResponseData.PARTNER;
				oSelectedAccount.AccountName = oResponseData.PARTNER_NAME;
				oSelectedAccount.AccountId_Name = `${oResponseData.PARTNER_NAME} - ${oResponseData.PARTNER}`;
			}
			oSelectedAccount.ISS = data.GTM_ISS_DESC;
			oSelectedAccount.IAC = data.TG_ACCOUNT_DESC;
			oSelectedAccount.SEGMENT = data.SEGMENT;
			oSelectedAccount.SEGMENT_DESC = data.SEGMENT_DESC;
			oSelectedAccount.GTM_ISS = data.GTM_ISS;
			oSelectedAccount.GTM_ISS_DESC = data.GTM_ISS_DESC;
			oSelectedAccount.OWNER_NAME = data.PARENT_ACC_OWNR_NM;
			oSelectedAccount.OWNER = data.PARENT_ACC_OWNER;
			oSelectedAccount.STATUS_DESC = data.STATUS_DESC;
			oSelectedAccount.Active_Account_Status = data.STATUS_DESC;
			oSelectedAccount.Regional_Buying_Classification = data.GTM_BUY_REG_DESC;
			oSelectedAccount.Regional_Buying_Lifecycle = data.GTM_BUY_GLB_DESC;
			oSelectedAccount.IMS = data.SEGMENT_DESC;
			oSelectedAccount.ERPID = data.ERP_ID;
			oSelectedAccount.Industry = "";
			return oSelectedAccount;
		},

		//function to get constants
		getConstantData: function () {
			let constants = {};
			let oUrlConstants = $.extend(true, {}, oStorageModel.getProperty("/oConstants")) || {};
			if (Object.keys(oUrlConstants).length) {
				return;
			}
			OpportunityService.getConstants().then(function (result) {
				var oData = result.data.results;
				for (var index in oData) {
					constants[oData[index].const_id] = oData[index];
				}
				oStorageModel.setProperty("/oConstants", constants);
				oStorageModel.refresh();
			});
		},

		/**************************** NEW FUNCTIONTIONS **********************************/

		//function to fetch All Data of Account Based on AccountId:
		getAccountDetails: async function (accountId) {
			let oUrlConstants = $.extend(true, {}, oStorageModel.getProperty("/oConstants"));
			let aResponse = await this.searchAccounts(accountId) || [];
			if (!aResponse.length) {
				return new Promise((resolve, reject) => {
					return resolve({});
				});
			}
			let oAccountData = aResponse.find((oData) => {
				return oData.AccountId === accountId;
			}) || {};
			let {
				data
			} = await AccountService.getZSBupaInfoSet(accountId);
			let aBPResponse = await Promise.all(this.fnProvideBPAttributeSetSearchAccount({
				bAccountId: true,
				AccountId: accountId
			}));
			let oBPdata = aBPResponse[0].data;
			oAccountData = this.fnSetAccountDataBPAttribSet(oAccountData, oBPdata);
			let oFormatedData = this.fnSetFormatDataAccountDetailSuccess(oAccountData, data);
			oFormatedData.harmonyLink = (Object.keys(oUrlConstants).length && oUrlConstants.hasOwnProperty("0186")) ? oUrlConstants["0186"].field_value +
				oFormatedData.AccountId : "";
			return new Promise((resolve, reject) => {
				return resolve(oFormatedData);
			});
		},

	};
}, true);