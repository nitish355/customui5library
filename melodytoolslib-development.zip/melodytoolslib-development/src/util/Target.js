sap.ui.define([
	"com/melody/lib/service/ISPService",
	"com/melody/lib/service/DateService",
	"com/melody/lib/model/ODataOptions",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (ISPService, DateService, ODataOptions, JSONModel, Filter, FilterOperator) {
	"use strict";
	return {
		dateServicesInstance: DateService.getInstance(),
		getTargetHours: async function (sUserId, sFromDate, sToDate) {
			var oOptions = new ODataOptions();
			const oResult = await ISPService.getISPData(sUserId, sFromDate, sToDate, oOptions, "Targethours");
			return oResult;
		},

		getWeekends: async function (sUserId) {
			var that = this;
			var oOptions = new ODataOptions();
			var sFromDate = that.dateServicesInstance.format(new Date(new Date().getFullYear(), 0, 1), "yMMdd");
			var sToDate = that.dateServicesInstance.format(new Date(new Date().getFullYear() + 1, 0, 0), "yMMdd");
			const oResult = await ISPService.getISPData(sUserId, sFromDate, sToDate, oOptions, "Targethours");
			var firstWeekend, secondWeekend;
			var startDayOfWeek;
			var bFlag = true;
			var aSortedResults = oResult.results.sort(function (a, b) {
				var dateA = that.dateServicesInstance.formatStringDate(a.Date);
				var dateB = that.dateServicesInstance.formatStringDate(b.Date);
				return dateA - dateB;
			});
			var tempSecondWeekend;
			var count = 0;

			for (var j = 0; j < aSortedResults.length; j++) {
				if (aSortedResults[j].Datetype !== "OFF") {
					if (secondWeekend && count === 2) {
						break;
					} else {
						firstWeekend = null;
						secondWeekend = null;
						bFlag = true;
					}
				}
				if (aSortedResults[j].Datetype === "OFF" && bFlag) {
					var dWeekend = that.dateServicesInstance.formatStringDate(aSortedResults[j].Date);
					if (secondWeekend) {
						if (that.dateServicesInstance.dateDiff(dWeekend, secondWeekend) === 1) {
							firstWeekend = null;
							secondWeekend = null;
							bFlag = false;
						} else {
							break;
						}
					}
					if (firstWeekend) {
						if (that.dateServicesInstance.dateDiff(firstWeekend, dWeekend) === 1) {
							secondWeekend = dWeekend;
							if (Date.parse(secondWeekend) < Date.parse(firstWeekend)) {
								secondWeekend = firstWeekend;
							}
						}
						if (Date.parse(secondWeekend) < Date.parse(firstWeekend)) {
							firstWeekend = secondWeekend;
						}
					} else {
						firstWeekend = dWeekend;
					}
				}
				if (secondWeekend) {
					count++;
					if (count === 1) {
						tempSecondWeekend = secondWeekend;
					} else if (count === 2 && tempSecondWeekend.getDay() === secondWeekend.getDay()) {
						continue;
					} else {
						count = 0;
					}
				}
			}

			if (secondWeekend) {
				var startDateOfWeek = new Date(secondWeekend.getFullYear(), secondWeekend.getMonth(), secondWeekend.getDate() + 1);
				startDayOfWeek = startDateOfWeek.getDay();
			} else {
				startDayOfWeek = 1;
			}
			return startDayOfWeek;
		}
	};
});