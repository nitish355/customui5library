sap.ui.define([
		"com/melody/lib/model/formatter",
		"sap/ui/core/mvc/Controller",
		"sap/ui/core/Fragment",
		"sap/ui/model/json/JSONModel",
		"sap/ui/core/format/DateFormat",
		"sap/ui/core/library",
		"com/melody/lib/service/MTRService",
		"com/melody/lib/util/Activity",
		"com/melody/lib/util/UserMaster",
		"com/melody/lib/util/Opportunity",
		"com/melody/lib/classes/MtrUser",
		"com/melody/lib/classes/MtrTask",
		"com/melody/lib/classes/Entry",
		"sap/m/MessageToast",
		"sap/m/MessageBox",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		'sap/ui/export/library',
		'sap/ui/export/Spreadsheet',
		'sap/ui/core/BusyIndicator'
	],
	function (formatter, Controller, Fragment, JSONModel, DateFormat, coreLibrary, MTRService, ActivityUtil, UserMaster, OpportunityUtil,
		MtrUser, MtrTask,
		Entry, MessageToast, MessageBox, Filter, FilterOperator, exportLibrary, Spreadsheet, BusyIndicator) {
		"use strict";
		const CalendarType = coreLibrary.CalendarType;
		const DurationSuggestion = {
			Hour: [{
				key: "0.5",
				value: "0.5",
				allowedOnDay: true
			}, {
				key: "1.0",
				value: "1.0",
				allowedOnDay: true
			}, {
				key: "1.5",
				value: "1.5",
				allowedOnDay: false
			}, {
				key: "2.0",
				value: "2.0",
				allowedOnDay: false
			}, {
				key: "2.5",
				value: "2.5",
				allowedOnDay: false
			}, {
				key: "3.0",
				value: "3.0",
				allowedOnDay: false
			}, {
				key: "3.5",
				value: "3.5",
				allowedOnDay: false
			}, {
				key: "4.0",
				value: "4.0",
				allowedOnDay: false
			}, {
				key: "4.5",
				value: "4.5",
				allowedOnDay: false
			}, {
				key: "5.0",
				value: "5.0",
				allowedOnDay: false
			}, {
				key: "5.5",
				value: "5.5",
				allowedOnDay: false
			}, {
				key: "6.0",
				value: "6.0",
				allowedOnDay: false
			}, {
				key: "6.5",
				value: "6.5",
				allowedOnDay: false
			}, {
				key: "7.0",
				value: "7.0",
				allowedOnDay: false
			}, {
				key: "7.5",
				value: "7.5",
				allowedOnDay: false
			}, {
				key: "8.0",
				value: "8.0",
				allowedOnDay: false
			}],
			Day: [{
				key: "0.5",
				value: "0.5",
				allowedOnDay: true
			}, {
				key: "1.0",
				value: "1.0",
				allowedOnDay: true
			}]
		}
		const MTR = {

			loadTimeRecordingPopover: function (object, view) {
				const that = this;

				if (!this._pTimeRecordingPopover) {
					this._pTimeRecordingPopover = Fragment.load({
						id: view.getId(),
						name: "com.melody.lib.fragments.MTR.TimeRecordingPopover",
						controller: this
					}).then(function (oPopover) {
						view.addDependent(oPopover);
						//oPopover.bindElement("/ProductCollection/0");
						return oPopover;
					});
				}
				this._pTimeRecordingPopover.then(function (oPopover) {
					oPopover.openBy(object);
				});
			},

			loadTimeRecordingDialog: function (controller, bControl, model) {
				const that = this;
				let oView = null;
				let id = "";
				if (bControl) {
					id = controller.getId() + "_TimeRecordingDialog";
				} else {
					oView = controller.getView();
					id = oView.getId() + "_TimeRecordingDialog";
				}
				//if (!this.Controller) {
				let oModel = model;
				if (!oModel) {
					oModel = new JSONModel({
						SelectedDates: [],
						User: user,
						UserSetting: null,
						SelectedActivity: null,
						SelectedMtrTask: null,
						SelectedLocationId: "",
						ShowCalendar: false,
						SelectedTab: "create",
						Entries: [{
							RecordDate: "04/11/2021",
							Task: "Business Development - CF",
							Location: "Virtual",
							Activity: "Demand Generation - PreBA",
							Type: "Cost Center: 0176000711",
							WorkDuration: "8.0"
						}, {
							RecordDate: "11/11/2021",
							Task: "Business Development - CF",
							Location: "Virtual",
							Activity: "Demand Generation - PreBA",
							Type: "Cost Center: 0176000711",
							WorkDuration: "8.0"
						}, {
							RecordDate: "12/11/2021",
							Task: "Business Development - CF",
							Location: "Virtual",
							Activity: "Demand Generation - PreBA",
							Type: "Cost Center: 0176000711",
							WorkDuration: "8.0"
						}]
					});
				}

				this.Controller = (this.Controller) ? this.Controller : new TimeRecordingController();
				this.Controller.Model = oModel;
				//}

				const oMtrCalendar = sap.ui.core.Fragment.byId(this.Controller.DialogId, "calendar");

				if (!oMtrCalendar) {
					this.Controller._oTimeRecordingDialog = null;
				}

				if (!this.Controller._oTimeRecordingDialog) {
					that.Controller._oTimeRecordingDialog = Fragment.load({
						id: id,
						name: "com.melody.lib.fragments.MTR.TimeRecordingDialog",
						controller: that.Controller
					}).then(function (oDialog) {
						that.Controller.DialogId = id;
						if (bControl) {
							controller.addDependent(oDialog);
						} else {
							oView.addDependent(oDialog);
						}

						return oDialog;
					}.bind(that.Controller));

				}

				this.Controller._oTimeRecordingDialog.then(function (oDialog) {

					if (sap.ui.Device.system.desktop) { // apply compact mode if touch is not supported
						oDialog.addStyleClass("sapUiSizeCompact");
					}
					oDialog.setModel(that.Controller.Model);

					that.Controller.resetDialog();

					/*const aActivityMtrTasks = [];
					const aMtrTasks = that.Controller.Model.getProperty("/UserSetting/MtrTasks");
					const oSelectedActivity = that.Controller.Model.getProperty("/SelectedActivity");

					that.getActivityTaskTypes(oSelectedActivity)
						.then((aActivityTasks) => {
							for (let i = 0; i < aActivityTasks.length; i++) {
								const oMtrTask = aMtrTasks.find(item => item.MtrTaskID === aActivityTasks[i].MtrTaskID);
								aActivityMtrTasks.push(oMtrTask);
							}

							that.Controller.Model.setProperty("/MtrTasks", aActivityMtrTasks);
						});*/

					/*const btnDelete = sap.ui.core.Fragment.byId(that.Controller.DialogId, "btnDelete");
					btnDelete.setEnabled(false);

					that.Controller.clearSelectedDates();
					that.Controller.Model.setProperty("/SelectedTab", "create");*/
					oDialog.open();
				});
			},

			_getUserMtrSettings: async function () {
				let oUserMtrSettingsModel = sap.ui.getCore().getModel("userMtrSettings");
				//const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);

				let oUserMtrSettings = (oUserMtrSettingsModel) ? oUserMtrSettingsModel.getData() : null;

				if (!oUserMtrSettings) {
					oUserMtrSettings = await this._fetchMtrConfig();

					oUserMtrSettingsModel = new JSONModel(oUserMtrSettings);
					sap.ui.getCore().setModel(oUserMtrSettingsModel, "userMtrSettings");

					//oStorage.put("userMtrSettings", oUserMtrSettings);
				}

				return oUserMtrSettings;

			},

			_fetchMtrConfig: async function () {
				const oUser = await UserMaster.authenticate();
				const oOREData = [];
				let oData = {};

				let oMtrUser = null;

				if (oUser) {
					// transforms post data as per the service input
					for (let i in oUser) {
						if (i && i !== "__metadata" && i !== "oNonOreData" && i !== "" && oUser[i] && oUser[i] !== "") {
							var obj = {
								UserId: oUser.UserId,
								ConstantType: i,
								ConstantValue: oUser[i]
							};
							oOREData.push(obj);
						}
					}
					const postData = {
						UserId: oUser.UserId,
						ApplicationId: "MTR",
						N_UserIDToConstant: oOREData
					};
					try {
						oData = await MTRService.getUserMtrConfig(postData);
					} catch (e) {
						console.log(e);
						throw new Error("Error while fetching Time Recording Configurations");
					}
					oMtrUser = {
						UserId: oUser.UserId,
						UserGuid: oData.UserGuid,
						FirstName: oData.FirstName,
						LastName: oData.LastName,
						Email: oData.Email,
						Status: oData.Status,
						IsUnitEdit: oData.IsUnitEdit,
						ProfileId: (oData.ProfileId && oData.ProfileId !== "") ? oData.ProfileId : "1",
						TimeSheetUnit: (oData.TimeSheetUnit && oData.TimeSheetUnit !== "") ? oData.TimeSheetUnit : "H",
						ActivityRecording: oUser.ActivityRecording,
						Durations: (oData.TimeSheetUnit && oData.TimeSheetUnit !== "" && oData.TimeSheetUnit === "D") ? DurationSuggestion.Day : DurationSuggestion
							.Hour,
						CostCenter: oUser.CostCenter,
						IsTimeRec: oData.IsTimeRec
					};

					oMtrUser.PartnerId = await OpportunityUtil.getBusinessPartner(oMtrUser.UserId);

					oMtrUser.MtrTasks = await this.getMtrMasterData(oMtrUser.ProfileId);
					
					//commented this due to performance issue
					// oMtrUser.ActivityTaskTypes = await this.getAllActivityTaskTypes();
					oMtrUser.ActivityTaskTypes = []; //Assigned emtry array as we are not using this anywhere

					// console.log(oMtrUser.ActivityTaskTypes);

					oMtrUser.ActivityRole = await ActivityUtil.getUserActivityRole();
					//const aUserActivities = await ActivityUtil.getUserActivities(oMtrUser.UserId);

					/*try {
						const oResponse = await MTRService.getUserGuidSettings(oMtrUser.UserGuid);
						if(oResponse) {
							oMtrUser.setFirstTimeUserSettings(false);
						} else {
							oMtrUser.setFirstTimeUserSettings(true);
						}
					} catch(e) {
						oMtrUser.setFirstTimeUserSettings(true);
					}*/

					/*if(oMtrUser.IsFirstTimeUser) {
						const oSettingsData = await MTRService.saveSettings(oMtrUser.getLSRequest());
					}*/

				} else {
					throw new Error("User is not active in ORE");
				}

				return oMtrUser;
			},

			getMtrMasterData: async function (sProfileId) {
				const oResponse = await MTRService.getMtrMasterData(sProfileId);

				const aMtrTasks = [];

				const aTasks = oResponse.to_Activity.results;

				const aCostTypeMap = oResponse.to_ActivityCostTypeMap.results;
				const aCostTypes = oResponse.to_CostType.results;

				const aLocationMap = oResponse.to_ActivityLocationMap.results;
				const aLocations = oResponse.to_Location.results;

				for (let i = 0; i < aTasks.length; i++) {
					const oMtrTask = {
						MtrTaskID: aTasks[i].activity_id,
						MtrTaskName: aTasks[i].ActivityName,
						MtrTaskDescription: aTasks[i].ActivityDescription,
						CategoryId: aTasks[i].CategoryId.toString(),
						IsArchive: aTasks[i].IsArchive,
						MtrCostTypes: [],
						MtrLocations: []
					};

					const aFilteredCostTypes = aCostTypeMap.filter(item => item.ActivityID === oMtrTask.MtrTaskID);
					//const aMtrCostTypes = [];
					for (let j = 0; j < aFilteredCostTypes.length; j++) {
						const oCostType = aCostTypes.find(item => item.CostTypeID === aFilteredCostTypes[j].CostTypeID);
						oMtrTask.MtrCostTypes.push({
							CostTypeId: oCostType.CostTypeID,
							CostTypeName: oCostType.CostTypeName
						});
					}
					//oMtrTask.setCostTypes(aMtrCostTypes);

					const aFilteredLocations = aLocationMap.filter(item => item.ActivityID === oMtrTask.MtrTaskID);
					//const aMtrLocations = [];
					for (let j = 0; j < aFilteredLocations.length; j++) {
						const oLocation = aLocations.find(item => item.LocationId === aFilteredLocations[j].LocationID && item.LocationId.toString() !==
							"2" && item.LocationId.toString() !== "3");
						if (oLocation) {
							oMtrTask.MtrLocations.push({
								LocationId: oLocation.LocationId,
								LocationName: oLocation.LocationName
							});
						}
					}
					//oMtrTask.setLocations(aMtrLocations);
					aMtrTasks.push(oMtrTask);
				}

				return aMtrTasks;
			},

			_filterTaskData: function () {

			},

			getUserMtrSettings: async function () {
				let bIsValid = false;
				let oMtrUser = null;
				try {
					oMtrUser = await this._getUserMtrSettings();
					bIsValid = true;
				} catch (e) {
					MessageToast.show(e);
				}

				return {
					IsValid: bIsValid,
					UserSetting: oMtrUser
				}
			},

			getAllActivityTaskTypes: async function () {
				let oActivityTaskTypesModel = sap.ui.getCore().getModel("activityTaskTypes");
				let aActivityTaskTypes = [];
				if (oActivityTaskTypesModel && oActivityTaskTypesModel.getData()) {
					aActivityTaskTypes = oActivityTaskTypesModel.getData();
				} else {
					// aActivityTaskTypes = await MTRService.getAllActivityTaskTypes();
					oActivityTaskTypesModel = new JSONModel(aActivityTaskTypes);
					sap.ui.getCore().setModel(oActivityTaskTypesModel, "activityTaskTypes");
				}
				return aActivityTaskTypes;
			},

			getActivityTaskTypes: async function (activity) {
				return await MTRService.getActivityTaskTypes(activity);
			},

			getEntries: async function (sUserGuid) {
				const aEntries = [];
				//const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				//let oUserMtrSettings = oStorage.get("userMtrSettings");

				let oUserMtrSettingsData = await this.getUserMtrSettings();
				if (!oUserMtrSettingsData) {
					return [];
				}

				let oUserMtrSettings = oUserMtrSettingsData.UserSetting;

				if (!oUserMtrSettings) {
					return [];
				}

				const aResult = await MTRService.getEntries(sUserGuid);

				const aActivities = await ActivityUtil.getUserActivities();

				const aMtrTasks = oUserMtrSettings.MtrTasks;

				const aActivityTaskTypes = oUserMtrSettings.ActivityTaskTypes;

				/*that.getActivityTaskTypes(oSelectedActivity)
						.then((aActivityTasks) => {
							for (let i = 0; i < aActivityTasks.length; i++) {
								const oMtrTask = aMtrTasks.find(item => item.MtrTaskID === aActivityTasks[i].MtrTaskID);
								aActivityMtrTasks.push(oMtrTask);
							}

							that.Controller.Model.setProperty("/MtrTasks", aActivityMtrTasks);
						});*/

				for (let i = 0; i < aResult.length; i++) {
					if (aResult[i].MtrUid && aResult[i].MtrUid !== "") {

						const oActivity = aActivities.find(item => item.ActivityId === aResult[i].ActvtId);
						let sActivityTypeId = "";
						let sActTypeDesc = "";
						if (oActivity) {
							sActivityTypeId = oActivity.ActivityTypeId;
							sActTypeDesc = oActivity.ActTypeDesc;
						}
						const oMtrTask = aMtrTasks.find(item => item.MtrTaskID === aResult[i].ActivityId);
						let sAssociationId = "";

						if (aResult[i].CostTypeId === 4) {
							sAssociationId = "501";
						} else if (aResult[i].CostTypeId === 1) {
							sAssociationId = "502";
						} else if (aResult[i].CostTypeId === 2) {
							sAssociationId = "503";
						}

						/*const aFilteredActivityTaskTypes = aActivityTaskTypes.filter(item => item.MtrTaskID === aResult[i].ActivityId && item.ActvtTypeID ===
							sActivityTypeId && item.ActvtAsstdID === sAssociationId);*/

						const aFilteredActivityTaskTypes = JSON.parse(JSON.stringify(await this.filterMtrTasks(oActivity)));

						if (aFilteredActivityTaskTypes.length > 0) {
							sActTypeDesc = aFilteredActivityTaskTypes[0].ActTypeDesc;
						}

						const sTimestamp = (aResult[i].Timestamp) ? aResult[i].Timestamp.trim() : "";
						let dCreatedOn = new Date();
						if (sTimestamp && sTimestamp !== "") {
							dCreatedOn = new Date(sTimestamp.substring(0, 4) + "/" + sTimestamp.substring(4, 6) + "/" + sTimestamp.substring(6, 8) + " " +
								sTimestamp.substring(8, 10) + ":" + sTimestamp.substring(10, 12) + ":" + sTimestamp.substring(12, 14))
						}

						const oEntry = new Entry(oUserMtrSettings.PartnerId, {
							MtrUid: aResult[i].MtrUid,
							RecordDate: aResult[i].RecordDate,
							MtrTaskID: aResult[i].ActivityId,
							MtrTaskName: (oMtrTask) ? oMtrTask.MtrTaskName : "",
							LocationId: aResult[i].LocationId,
							CostTypeId: aResult[i].CostTypeId,
							CostTypeValue: aResult[i].CostTypeValue,
							WorkDuration: (aResult[i].WorkDuration) ? parseFloat(aResult[i].WorkDuration, 10).toFixed(1) : "",
							ActvtId: aResult[i].ActvtId,
							ActivityTypeName: sActTypeDesc,
							Unit: aResult[i].Unit,
							Note: aResult[i].Note,
							MtrLocations: (oMtrTask) ? oMtrTask.MtrLocations : [],
							MtrTasks: aFilteredActivityTaskTypes,
							StatusId: aResult[i].StatusId,
							MsgText: aResult[i].MsgText,
							ProjectType: aResult[i].ProjectType,
							CreatedOn: dCreatedOn
						});
						aEntries.push(oEntry);
					}
				}
				return aEntries;
			},

			filterMtrTasks: async function (oSelectedActivity) {
				const aActivityTaskTypes = await this.getAllActivityTaskTypes();

				const oUserActivityRole = await ActivityUtil.getUserActivityRole();
				if (!oSelectedActivity || !oUserActivityRole) {
					return [];
				}

				const aUserActivities = await ActivityUtil.getUserActivities();

				/*const oUserActivity = aUserActivities.find(item => {
					return item.ActivityId === oSelectedActivity.ActivityId && item.ActAsstId === oSelectedActivity.ActAsstId && item.ParentRoleId ===
						oSelectedActivity.ParentRoleId;
				});*/

				const oUserActivity = aUserActivities.find(item => {
					return item.ActivityId === oSelectedActivity.ActivityId && item.ActAsstId === oSelectedActivity.ActAsstId;
				});

				if (!oUserActivity) {
					return [];
				}

				/*let aFilteredActivityTaskTypes = aActivityTaskTypes.filter(item => item.ActvtTypeID.toString() === oSelectedActivity.ActivityTypeId
					.toString() && oSelectedActivity.ActAsstId.toString() === item.ActvtAsstdID.toString() && oSelectedActivity.ParentRoleId.toString() ===
					item.ParentRoleId.toString() && oUserActivityRole.RoleMpngID.toString() ===
						item.RoleMpngID.toString());*/

				/*let aFilteredActivityTaskTypes = aActivityTaskTypes.filter(item => item.ActvtTypeID.toString() === oSelectedActivity.ActivityTypeId
					.toString() && oSelectedActivity.ActAsstId.toString() === item.ActvtAsstdID.toString() && oUserActivityRole.ParentRoleID.toString() ===
					item.ParentRoleId.toString());*/

				let aFilteredActivityTaskTypes = aActivityTaskTypes.filter(item => item.ActvtTypeID.toString() === oSelectedActivity.ActivityTypeId
					.toString() && oSelectedActivity.ActAsstId.toString() === item.ActvtAsstdID.toString() && oSelectedActivity.ParentRoleId.toString() ===
					item.ParentRoleId.toString());

				let aUpdatedActivityTaskTypes = aFilteredActivityTaskTypes.filter(item => parseInt(item.RoleMpngID, 10) === parseInt(item.RoleMpngID,
					10));

				if (aUpdatedActivityTaskTypes.length === 0) {
					aUpdatedActivityTaskTypes = aFilteredActivityTaskTypes.filter(item => parseInt(item.RoleMpngID, 10) === parseInt(item.ParentRoleId,
						10));
				}

				/*if (aFilteredActivityTaskTypes.length === 0 && oUserActivityRole) {
					aFilteredActivityTaskTypes = aActivityTaskTypes.filter(item => item.ActvtTypeID.toString() === oSelectedActivity.ActivityTypeId
						.toString() && oSelectedActivity.ActAsstId.toString() === item.ActvtAsstdID.toString() && oUserActivityRole.RoleMpngID.toString() ===
						item.RoleMpngID.toString());
				}*/

				return aUpdatedActivityTaskTypes;
			},

			getUserGuidSettings: async function (sUserGuid, mParameters) {
				mParameters = OpportunityUtil.fnGetServiceParameters(mParameters);
				let oData = await MTRService.getUserGuidSettings(sUserGuid, mParameters);
				return {
					IsFirstTimeUser: false,
					CustId: (oData && oData.CustId) ? oData.CustId : "",
					Language: (oData && oData.Language) ? oData.Language : "",
					UserGuid: (oData && oData.UserGuid) ? oData.UserGuid : "",
					EssInMu: (oData && (oData.EssInMu === "")) ? false : true,
					Timesheet: (oData && oData.Timesheet) ? oData.Timesheet : "",
					PartnerId: (oData && oData.PartnerId) ? oData.PartnerId : "",
					CreatedOn: (oData && oData.CreatedOn) ? oData.CreatedOn : "",
					UpdatedOn: (oData && oData.UpdatedOn) ? oData.UpdatedOn : "",
					IsArchive: (oData && oData.IsArchive) ? oData.IsArchive : "",
					DateFormat: (oData && oData.DateFormat) ? oData.DateFormat : "",
					CreatedTime: (oData && oData.CreatedTime) ? oData.CreatedTime : "",
					UpdatedTime: (oData && oData.UpdatedTime) ? oData.UpdatedTime : "",
					PrdProfMapId: (oData && oData.PrdProfMapId) ? oData.PrdProfMapId : "",
					TimeSheetUnit: (oData && oData.TimeSheetUnit) ? oData.TimeSheetUnit : "",

					to_MANUAL: (oData && oData.to_MANUAL) ? oData.to_MANUAL.results : [],
					to_ACCOUNT: (oData && oData.to_ACCOUNT) ? oData.to_ACCOUNT.results : [],
					to_OPPORTUNITYIO: (oData && oData.to_OPPORTUNITYIO) ? oData.to_OPPORTUNITYIO.results : [],
				}
			},

			getEntryLookups: async function (iPrdMapId, mParameters) {
				const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				let Lookup = oStorage.get("Lookup");
				if (Lookup) {
					return Lookup;
				}
				mParameters = OpportunityUtil.fnGetServiceParameters(mParameters);
				let oData = await MTRService.getEntryLookups(iPrdMapId, mParameters);
				if (oData) {
					oData.to_Status = oData.to_Status ? oData.to_Status.results : [];
					oData.to_Activity = oData.to_Activity ? oData.to_Activity.results : [];
					oData.to_Category = oData.to_Category ? oData.to_Category.results : [];
					oData.to_CostType = oData.to_CostType ? oData.to_CostType.results : [];
					oData.to_Location = oData.to_Location ? oData.to_Location.results : [];
					oData.to_ActivityCostTypeMap = oData.to_ActivityCostTypeMap ? oData.to_ActivityCostTypeMap.results : [];
					oData.to_ActivityLocationMap = oData.to_ActivityLocationMap ? oData.to_ActivityLocationMap.results : [];
					oStorage.put("Lookup", oData);
				}
				return oData;
			},

			getSettingLookups: async function (mParameters) {
				mParameters = OpportunityUtil.fnGetServiceParameters(mParameters);
				let oData = await MTRService.getSettingLookups(mParameters);
				let dateFormats = [];
				let timesheetPrefs = [];
				if (oData) {
					timesheetPrefs = oData.filter(function (domain) {
						return domain.Type === "YDO_TIMESHEETPREF";
					});
					dateFormats = oData.filter(function (domain) {
						return domain.Type === "YDO_DATEFORMARTID";
					});
				}
				return [timesheetPrefs, dateFormats];
			}
		}

		const TimeRecordingModel = new JSONModel({
			SelectedDates: []
		});

		const TimeRecordingController = Controller.extend("com.melody.lib.controller.TimeRecording", {
			formatter: formatter,
			oFormatYyyymmdd: null,
			constructor: function () {
				this.oFormatYyyymmdd = DateFormat.getInstance({
					pattern: "MMM-dd",
					calendarType: CalendarType.Gregorian
				});
			},

			handleTaskPopoverPress: function (oEvent) {

				if (!this._oTaskPopover) {
					this._oTaskPopover = sap.ui.xmlfragment(
						"com.melody.lib.fragments.MTR.TaskPopover",
						this);
				}
				this._oTaskPopover.setModel(this.Model);
				this._oTaskPopover.openBy(oEvent.getSource());

			},

			handleTaskPopoverClose: function () {
				this._oTaskPopover.close();
			},

			onSelectTab: function (oEvent) {
				const sSelectedTab = oEvent.getParameter("key");
				if (sSelectedTab === "submitted") {
					this._goToMtr();
				}
			},

			getSearchFilters: function (query) {
				return new Filter({
					filters: [
						new Filter("MtrTaskName", FilterOperator.Contains, query),
						new Filter("ActivityTypeName", FilterOperator.Contains, query),
					],
					and: false,
				});
			},

			_goToMtr: function () {
				BusyIndicator.show(0);
				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#mtr-app&/entries/Saved"
					}
				});
			},

			handleErrorListPress: function (oEvent) {

				const sMsgText = oEvent.getSource().data("msgText");

				if (sMsgText) {
					if (!this.ErrorPopover) {
						this.ErrorPopover = sap.ui.xmlfragment(
							"com.melody.lib.fragments.MTR.EntryErrorPopover",
							this);
						//this.addDependent(this.ErrorPopover);
					}
					this.ErrorPopover.setModel(new JSONModel({
						MsgText: sMsgText
					}));
					this.ErrorPopover.openBy(oEvent.getSource());
				}
			},

			handleCloseEntryErrorPopover: function () {
				this.ErrorPopover.close();
			},

			onSearchEntries: function (oEvent) {

				const genericDateFormat = sap.ui.core.format.DateFormat.getInstance({
					pattern: "yMMdd",
					calendarType: sap.ui.core.CalendarType.Gregorian
				});

				const idSearchField = sap.ui.core.Fragment.byId(this.DialogId, "savedEntries--idSearchEntries");
				const reportFromDate = sap.ui.core.Fragment.byId(this.DialogId, "savedEntries--reportFromDate");
				const reportToDate = sap.ui.core.Fragment.byId(this.DialogId, "savedEntries--reportToDate");

				const dFromDate = reportFromDate.getDateValue();
				const dToDate = reportToDate.getDateValue();

				var sQuery = idSearchField.getValue();

				const aFilters = [];

				aFilters.push(this.getSearchFilters(sQuery));

				if (dFromDate && dToDate) {
					aFilters.push(new sap.ui.model.Filter("Date", sap.ui.model.FilterOperator.BT, dFromDate, dToDate));
				}

				const idSavedEntriesTable = sap.ui.core.Fragment.byId(this.DialogId, "savedEntries--idSavedEntriesTable");
				idSavedEntriesTable.getBinding("items").filter(new Filter({
					filters: aFilters,
					and: true,
				}), sap.ui.model.FilterType.Application);
			},

			onResetSavedEntries: function (oEvent) {
				const idSearchField = sap.ui.core.Fragment.byId(this.DialogId, "savedEntries--idSearchEntries");
				const reportFromDate = sap.ui.core.Fragment.byId(this.DialogId, "savedEntries--reportFromDate");
				const reportToDate = sap.ui.core.Fragment.byId(this.DialogId, "savedEntries--reportToDate");

				idSearchField.setValue("");
				reportFromDate.setValue("");
				reportToDate.setValue("");

				this.onSearchEntries();
			},

			getMtrTask: function (sMtrTaskID) {
				if (!sMtrTaskID) {
					return null;
				}
				//const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				//const oUserSettings = oStorage.get("userMtrSettings");
				const oUserMtrSettingsModel = sap.ui.getCore().getModel("userMtrSettings");
				const oUserSettings = (oUserMtrSettingsModel) ? oUserMtrSettingsModel.getData() : null;

				//const oUserSettings = await this.getUserMtrSettings();

				if (!oUserSettings) {
					return null;
				}

				const aMtrTasks = oUserSettings.MtrTasks;

				const oMtrTask = aMtrTasks.find(item => item.MtrTaskID.toString() === sMtrTaskID.toString());

				return oMtrTask;
			},

			handleToggleContent: function (oEvent) {
				const oDynamicSideContent = sap.ui.core.Fragment.byId(this.DialogId, "DynamicSideContent");
				oDynamicSideContent.toggle();
				this.Model.setProperty("/ShowCalendar", !this.Model.getProperty("/ShowCalendar"))
			},

			handleCalendarSelect: function (oEvent) {
				var aSelectedDates = oEvent.getParameter("selectedDates"),
					oDate,
					i;
				let sSelectedDates = "";
				if (aSelectedDates.length > 0) {
					for (i = 0; i < aSelectedDates.length; i++) {
						oDate = aSelectedDates[i].getStartDate();
						let sRegion = sap.ui.getCore().getModel("userUtility").getProperty("/RegionName");
						let todayDate = new Date();
						if (sRegion === "NA" && oDate.getFullYear() < todayDate.getFullYear()) {
							MessageToast.show("Time recording for date(s) prior to 31 Dec 2022 is restricted.");
							this.clearSelectedDates();
							return;
						}
						sSelectedDates += this.oFormatYyyymmdd.format(oDate);
						if (i < aSelectedDates.length - 1) {
							sSelectedDates += ", "
						}
						this.Model.setProperty("/SelectedDates", sSelectedDates);
					}

					const cmbDuration = sap.ui.core.Fragment.byId(this.DialogId, "cmbDuration");
					this.validateDuration(cmbDuration);

					this.Model.refresh(true);
				} else {
					this.clearSelectedDates();
				}
			},

			onChangeDuration: function (oEvent) {
				this.validateDuration(oEvent.getSource());
			},

			onSelectLocation: function (oEvent) {
				const oSource = oEvent.getSource();

				const oSelectedRadioButton = oSource.getSelectedButton();

				const sKey = oSelectedRadioButton.data("key");

				this.Model.setProperty("/SelectedLocationId", sKey);
			},

			getCalendar: function () {
				const oMtrCalendar = sap.ui.core.Fragment.byId(this.DialogId, "calendar");
				const oCalendar = oMtrCalendar.getAggregation("_calendar");
				return oCalendar;
			},

			onSaveEntries: function () {
				const that = this;
				const genericDateFormat = sap.ui.core.format.DateFormat.getInstance({
					pattern: "yMMdd",
					calendarType: sap.ui.core.CalendarType.Gregorian
				});
				const oUserSetting = this.Model.getProperty("/UserSetting");
				/*const oCalendar = sap.ui.core.Fragment.byId(this.DialogId, "calendar");*/
				const oCalendar = this.getCalendar();
				const oSelectedActivity = this.Model.getProperty("/SelectedActivity");

				const aMtrTasks = oUserSetting.MtrTasks;

				const aSelectedDates = oCalendar.getSelectedDates();

				if (aSelectedDates.length === 0) {
					MessageToast.show("Please select date(s)");
					return;
				}

				const cmbMtrTask = sap.ui.core.Fragment.byId(this.DialogId, "cmbMtrTask");
				const sMtrTaskID = cmbMtrTask.getSelectedKey();

				if (!sMtrTaskID) {
					MessageToast.show("Please select Task");
					return;
				}

				const oMtrTask = aMtrTasks.find(item => item.MtrTaskID.toString() === sMtrTaskID.toString());

				const rbgLocation = sap.ui.core.Fragment.byId(this.DialogId, "rbgLocation");
				const oSelectedRadioButton = rbgLocation.getSelectedButton();
				let sLocationId = "";
				if (oSelectedRadioButton) {
					let aRadioButtons = rbgLocation.getButtons();
					for (let i = 0; i < aRadioButtons.length; i++) {
						let oTempButton = aRadioButtons[i];
						if (oTempButton.getSelected()) {
							let oCurrentData = oTempButton.getBindingContext().getObject();
							if (oCurrentData.hasOwnProperty("LocationId")) {
								sLocationId = oCurrentData.LocationId;
							}
						}
					}
					// sLocationId = oSelectedRadioButton.data("key");
					if (!sLocationId) {
						MessageToast.show("Please select Location");
						return;
					}
				}

				const cmbDuration = sap.ui.core.Fragment.byId(this.DialogId, "cmbDuration");
				const sWorkDuration = cmbDuration.getValue();

				if (!sWorkDuration) {
					MessageToast.show("Please select Time Duration");
					return;
				}

				let sCostTypeId = "";
				let sCostTypeValue = oSelectedActivity.CostTypeValue;
				if (oSelectedActivity) {
					if (oSelectedActivity.ActAsstId === "501") {
						sCostTypeId = "4";
					} else if (oSelectedActivity.ActAsstId === "502") {
						sCostTypeId = "1";
					} else if (oSelectedActivity.ActAsstId === "503") {
						sCostTypeId = "2"
						sCostTypeValue = oUserSetting.CostCenter;
					}
				}

				if (!sCostTypeId || sCostTypeId === "") {
					MessageToast.show("Cost Type is not valid");
					return;
				}

				const sUnit = oUserSetting.TimeSheetUnit;

				const txtNotes = sap.ui.core.Fragment.byId(this.DialogId, "txtNotes");
				const sNote = txtNotes.getValue();

				const aSelectedMtrTasks = this.Model.getProperty("/MtrTasks");

				const oSelectedMtrTask = aSelectedMtrTasks.find(item => item.MtrTaskID.toString() === sMtrTaskID);

				const sPartnerId = oUserSetting.PartnerId;
				const aEntriesToAdd = [];
				const aEntriesToSave = [];
				for (let i = 0; i < aSelectedDates.length; i++) {

					const dRecordDate = aSelectedDates[i].getStartDate();
					const sRecordDate = genericDateFormat.format(dRecordDate);

					const oEntry = new Entry(sPartnerId, {
						RecordDate: sRecordDate,
						MtrTaskID: sMtrTaskID,
						MtrTaskName: (oSelectedMtrTask) ? oSelectedMtrTask.MtrTaskName : "",
						LocationId: sLocationId,
						CostTypeId: sCostTypeId,
						CostTypeValue: oSelectedActivity.CostTypeValue,
						WorkDuration: sWorkDuration,
						ActvtId: oSelectedActivity.ActivityId,
						ActivityTypeName: oSelectedActivity.ActTypeDesc,
						ProjectType: oSelectedActivity.ProjectType,
						Unit: sUnit,
						Note: sNote,
						MtrLocations: (oMtrTask) ? oMtrTask.MtrLocations : [],
						MtrTasks: this.Model.getProperty("/MtrTasks")
					});
					aEntriesToAdd.push(oEntry);
					aEntriesToSave.push(oEntry.getLSRequest({
						UserGuid: oUserSetting.UserGuid,
						ProfileId: oUserSetting.ProfileId,
					}));
				}

				/*if (aEntriesToSave.length > 0) {
					const postData = {
						UserGuid: oUserSetting.UserGuid,
						N_TimesheetDetail: aEntriesToSave
					};

					MTRService.saveEntries(postData)
						.then((result) => console.log(result));
				}*/

				this._saveEntries(aEntriesToSave)
					.then(response => {
						if (response) {
							/*const results = response.N_TimesheetDetail.results;
											for(let i = 0; i < results.length; i ++) {
												const oEntry = aEntries.find(item => item.MtrUid === results[i].MtrUid);
												
												if(oDeletedEntry) {
													oDeletedEntry.Indicator = "D";
												}
											}
							
											const aFilteredEntries = aEntries.filter(item => item.Indicator !== "D");
											that.Model.setProperty("/Entries");*/
							const aEntries = that.Model.getProperty("/Entries");
							aEntries.push(...aEntriesToAdd);
							that.Model.refresh(true);
							let sSuccessMsg = "Entry";
							if (aEntries.length > 1) {
								sSuccessMsg = "Entries"
							}
							MessageToast.show("Time " + sSuccessMsg + " saved successfully");
						}

						//const idIconTabBar = sap.ui.core.Fragment.byId(that.DialogId, "idIconTabBar");
						that.Model.setProperty("/SelectedTab", "saved");
						that.clearDialog();
						//that.handleCloseTimeRecordingDialog();
						/*if (ActivityRecording === "1") {
							MessageBox.error("The entry/ies are saved in MTR. Please review and submit them to ISP in MTR.", {
								actions: ["Go to MTR", MessageBox.Action.CLOSE],
								emphasizedAction: "Go to MTR",
								onClose: function (sAction) {
									if(sAction === "Go to MTR") {
										that._goToMtr();
									}
								}
							});
						}*/
					});
			},

			_saveEntries: async function (aEntries) {
				const oUserSetting = this.Model.getProperty("/UserSetting");
				if (aEntries.length > 0) {
					const postData = {
						UserGuid: oUserSetting.UserGuid,
						N_TimesheetDetail: aEntries
					};

					return await MTRService.saveEntries(postData);
				}
			},

			onSelectMtrTask: function (oEvent) {
				const oSelectedItem = oEvent.getParameter("selectedItem");
				const sKey = oSelectedItem.getKey();

				const aMtrTasks = this.Model.getProperty("/UserSetting/MtrTasks");

				const oMtrTask = aMtrTasks.find(item => item.MtrTaskID.toString() === sKey);

				this.Model.setProperty("/SelectedMtrTask", oMtrTask);
			},

			handleCloseTimeRecordingDialog: function () {
				/*this.clearSelectedDates();

				const cmbMtrTask = sap.ui.core.Fragment.byId(this.DialogId, "cmbMtrTask");
				cmbMtrTask.setSelectedKey(undefined);

				this.Model.setProperty("/SelectedMtrTask", null);

				const cmbDuration = sap.ui.core.Fragment.byId(this.DialogId, "cmbDuration");
				cmbDuration.setSelectedKey(undefined);

				const txtNotes = sap.ui.core.Fragment.byId(this.DialogId, "txtNotes");
				txtNotes.setValue("");*/

				this.clearDialog();

				this._oTimeRecordingDialog.then(function (oDialog) {
					oDialog.close();
				});
			},

			handleRemoveSelection: function () {
				//this.byId("calendar").removeAllSelectedDates();
				this.clearSelectedDates();
			},

			clearSelectedDates: function () {
				/*const oMtrCalendar = sap.ui.core.Fragment.byId(this.DialogId, "calendar");
				const oCalendar = oMtrCalendar.getAggregation("_calendar");*/
				const oCalendar = this.getCalendar();
				oCalendar.removeAllSelectedDates();
				this.Model.setProperty("/SelectedDates", "");
			},

			calculateDuration: function (sWorkDuration, sRecordDate, sMtrUid) {
				const aRecordDates = [];
				if (!sRecordDate) {
					const oCalendar = this.getCalendar();

					const oDateFormat = DateFormat.getInstance({
						pattern: "yMMdd",
						calendarType: CalendarType.Gregorian
					});

					var aSelectedDates = oCalendar.getSelectedDates(),
						oDate;
					if (aSelectedDates.length > 0) {
						for (let i = 0; i < aSelectedDates.length; i++) {
							oDate = aSelectedDates[i].getStartDate();
							aRecordDates.push(oDateFormat.format(oDate));
						}
					} else {
						return true;
					}
				} else {
					aRecordDates.push(sRecordDate);
				}
				const aEntries = this.Model.getProperty("/Entries");
				const aTotalDurations = [];
				let sMsg = "Time recorded is more than 24 hours for ";
				for (let i = 0; i < aRecordDates.length; i++) {
					let aFilteredByRecordDate;
					if (sMtrUid) {
						aFilteredByRecordDate = aEntries.filter(item => item.RecordDate === aRecordDates[i] && item.MtrUid !== sMtrUid);
					} else {
						aFilteredByRecordDate = aEntries.filter(item => item.RecordDate === aRecordDates[i]);
					}

					let iTotalDuration = 0;

					for (let j = 0; j < aFilteredByRecordDate.length; j++) {
						const iDuration = (aFilteredByRecordDate[j].WorkDuration && aFilteredByRecordDate[j].WorkDuration !== "") ? parseFloat(
							aFilteredByRecordDate[j].WorkDuration, 10) : 0;
						iTotalDuration += iDuration;
					}

					if (sWorkDuration && sWorkDuration !== "") {
						iTotalDuration += parseFloat(sWorkDuration, 10);
					}

					if (iTotalDuration > 24) {
						aTotalDurations.push({
							RecordDate: aRecordDates[i],
							TotalDuration: iTotalDuration
						});

						sMsg += " " + aRecordDates[i].substring(0, 4) + "/" + aRecordDates[i].substring(4, 6) + "/" + aRecordDates[i].substring(6, 8);
					}
				}

				if (aTotalDurations.length > 0) {
					MessageToast.show(sMsg);
					return false;
				} else {
					return true;
				}
			},

			handleEditTimeRecordPress: function (oEvent) {
				const that = this;
				const oSource = oEvent.getSource();
				const oBindingContext = oSource.getParent().getBindingContext();
				const oModel = oBindingContext.getModel();
				const sPath = oBindingContext.getPath();

				const oEntry = oModel.getProperty(sPath);
				oEntry.TempRecordDate = oEntry.RecordDate;
				oEntry.TempMtrTaskID = oEntry.MtrTaskID;
				oEntry.TempLocationId = oEntry.LocationId;
				oEntry.TempWorkDuration = oEntry.WorkDuration;
				oEntry.IsEdit = true;

				/*$(".cmbDurationList").each(function (index) {
					const sId = $(this).attr("data-sap-ui");
					const cmbDuration = sap.ui.getCore().byId(sId);
					cmbDuration.attachBrowserEvent("keyup", function (event) {
						that.validateDuration(this);
					})
				});*/

				oModel.refresh(true);
			},

			handleUpdateTimeRecordPress: function (oEvent) {
				const oSource = oEvent.getSource();
				const oBindingContext = oSource.getParent().getBindingContext();
				const oModel = oBindingContext.getModel();
				const sPath = oBindingContext.getPath();

				const oEntry = oModel.getProperty(sPath);

				const oUserSetting = this.Model.getProperty("/UserSetting");

				const aMtrTasks = oEntry.MtrTasks;

				const oMtrTask = aMtrTasks.find(item => item.MtrTaskID.toString() === oEntry.TempMtrTaskID.toString());

				if (oMtrTask) {
					oEntry.TempMtrTaskName = oMtrTask.MtrTaskName;
				}

				const oTempEntry = new Entry(null, {
					MtrUid: oEntry.MtrUid,
					RecordDate: oEntry.TempRecordDate,
					MtrTaskID: oEntry.TempMtrTaskID,
					MtrTaskName: oEntry.TempMtrTaskName,
					LocationId: (oEntry.MtrLocations && oEntry.MtrLocations.length > 0 && oEntry.TempLocationId) ? oEntry.TempLocationId : 0,
					CostTypeId: oEntry.CostTypeId,
					CostTypeValue: oEntry.CostTypeValue,
					WorkDuration: oEntry.TempWorkDuration,
					ActvtId: oEntry.ActvtId,
					ProjectType: oEntry.ProjectType,
					Unit: oEntry.Unit,
					Note: oEntry.Note
				});

				const cmbDuration = oSource.getParent().getParent().getCells()[5].getItems()[1];
				if (!this.validateDuration(cmbDuration, oTempEntry.RecordDate, oTempEntry.MtrUid)) {
					return;
				}

				oEntry.TempWorkDuration = parseFloat(cmbDuration.getValue(), 10).toFixed(1);
				oTempEntry.WorkDuration = parseFloat(cmbDuration.getValue(), 10).toFixed(1);

				const oEntryToUpdate = oTempEntry.getLSRequest({
					UserGuid: oUserSetting.UserGuid,
					ProfileId: oUserSetting.ProfileId,
					Indicator: "U"
				});

				this._saveEntries([oEntryToUpdate])
					.then(result => {
						oEntry.RecordDate = oEntry.TempRecordDate;
						oEntry.MtrTaskID = oEntry.TempMtrTaskID;
						oEntry.MtrTaskName = oEntry.TempMtrTaskName;
						oEntry.LocationId = oEntry.TempLocationId;
						oEntry.WorkDuration = oEntry.TempWorkDuration;
						oEntry.IsEdit = false;
						oModel.refresh(true);
					});

			},

			handleCancelTimeRecordPress: function (oEvent) {
				const oSource = oEvent.getSource();
				const oBindingContext = oSource.getParent().getBindingContext();
				const oModel = oBindingContext.getModel();
				const sPath = oBindingContext.getPath();

				const oEntry = oModel.getProperty(sPath);
				oEntry.TempRecordDate = oEntry.RecordDate;
				oEntry.TempMtrTaskID = oEntry.MtrTaskID;
				oEntry.TempLocationId = oEntry.LocationId;
				oEntry.TempWorkDuration = oEntry.WorkDuration;
				oEntry.IsEdit = false;
				oModel.refresh(true);
			},

			handleEditTimeRecordCloseButton: function (oEvent) {
				// note: We don't need to chain to the _pPopover promise, since this event-handler
				// is only called from within the loaded dialog itself.
				this._pTimeRecordingPopover.then(function (oPopover) {
					oPopover.close();
				});
			},

			onSelectEntryMtrTask: function (oEvent) {
				const oSelectedItem = oEvent.getParameter("selectedItem");
				const sSelectedKey = oSelectedItem.getKey();

				const oSource = oEvent.getSource();
				const oItem = oSource.getParent().getParent();

				const oBindingContext = oItem.getBindingContext();
				const sPath = oBindingContext.getPath();
				const oModel = oBindingContext.getModel();

				const oEntry = oModel.getProperty(sPath);

				const aMtrTasks = oModel.getProperty("/UserSetting/MtrTasks");

				const oMtrTask = aMtrTasks.find(item => item.MtrTaskID.toString() === sSelectedKey.toString());

				if (oMtrTask) {
					oEntry.MtrLocations = oMtrTask.MtrLocations;
					oEntry.TempMtrTaskName = oMtrTask.MtrTaskName;
				} else {
					oEntry.MtrLocations = [];
					oEntry.TempMtrTaskName = "";
				}
				oModel.refresh(true);
			},

			resetDialog: function () {
				this.enableDeleteButton(false);
				this.bindCombo();
				this.clearSelectedDates();
				this.Model.setProperty("/SelectedTab", "create");
			},

			bindCombo: function () {
				const that = this;
				const cmbDuration = sap.ui.core.Fragment.byId(this.DialogId, "cmbDuration");
				cmbDuration.attachBrowserEvent("keyup", function (event) {
					that.validateDuration(this);
					/*var len = this.getItems().length;
					var enteredText = this.getValue();
					var bExists = false;
					for (var i = 0; i < len; i++) {
						var itemText = this.getItems()[i].getProperty("text");
						if (itemText == enteredText || itemText.startsWith(enteredText)) {
							bExists = true;
							break;
						}
					}

					if (!bExists && enteredText && enteredText !== "" && !isNaN(enteredText)) {
						const fDuration = parseFloat(enteredText, 10);
						if (fDuration <= 24) {
							bExists = true;
							this.setValue(enteredText);
						}
					}

					if (bExists) {
						if (that.calculateDuration(enteredText)) {
							this.setValueState(sap.ui.core.ValueState.None);
						} else {
							this.setValueState(sap.ui.core.ValueState.Error);
							this.setValue("");
						}

					} else {
						this.setValueState(sap.ui.core.ValueState.Error);
						this.setValue("");
					}*/

				})
			},

			validateDuration: function (cmbDuration, sRecordDate, sMtrUid) {
				let bIsValid = false;
				const that = this;
				var len = cmbDuration.getItems().length;
				var enteredText = cmbDuration.getValue();
				var bExists = false;
				for (var i = 0; i < len; i++) {
					var itemText = cmbDuration.getItems()[i].getProperty("text");
					if (itemText == enteredText || itemText.startsWith(enteredText)) {
						bExists = true;
						break;
					}
				}

				if (!bExists && enteredText && enteredText !== "" && !isNaN(enteredText)) {
					const fDuration = parseFloat(enteredText, 10);
					if (fDuration <= 24) {
						bExists = true;
						cmbDuration.setValue(enteredText);
					}
				}

				if (bExists) {
					if (that.calculateDuration(enteredText, sRecordDate, sMtrUid)) {
						cmbDuration.setValueState(sap.ui.core.ValueState.None);
						bIsValid = true;
					} else {
						cmbDuration.setValueState(sap.ui.core.ValueState.Error);
						cmbDuration.setValue("");
						bIsValid = false;
					}

				} else {
					cmbDuration.setValueState(sap.ui.core.ValueState.Error);
					cmbDuration.setValue("");
					bIsValid = false;
				}
				return bIsValid;
			},

			enableDeleteButton: function (bEnabled) {
				const btnDelete = sap.ui.core.Fragment.byId(this.DialogId, "btnDelete");
				btnDelete.setEnabled((bEnabled) ? true : false);
			},

			clearDialog: function () {
				this.clearSelectedDates();

				const cmbMtrTask = sap.ui.core.Fragment.byId(this.DialogId, "cmbMtrTask");
				cmbMtrTask.setSelectedKey(undefined);

				this.Model.setProperty("/SelectedMtrTask", null);

				const cmbDuration = sap.ui.core.Fragment.byId(this.DialogId, "cmbDuration");
				cmbDuration.setSelectedKey(undefined);

				const txtNotes = sap.ui.core.Fragment.byId(this.DialogId, "txtNotes");
				txtNotes.setValue("");
			},

			onPressDeleteEntries: function (oEvent) {
				const that = this;
				MessageBox.confirm("Are you sure, you want to delete the entry/ies ?", {
					actions: [MessageBox.Action.YES, MessageBox.Action.NO],
					onClose: function (sAction) {
						if (sAction === MessageBox.Action.YES) {
							const oUserSetting = that.Model.getProperty("/UserSetting");

							const idSavedEntriesTable = sap.ui.core.Fragment.byId(that.DialogId, "savedEntries--idSavedEntriesTable");

							const aSelectedContexts = idSavedEntriesTable.getSelectedContexts();
							const aEntriesToDelete = [];
							for (let i = 0; i < aSelectedContexts.length; i++) {
								const oBindingContext = aSelectedContexts[i];
								const oModel = oBindingContext.getModel();
								const sPath = oBindingContext.getPath();

								const oEntry = oModel.getProperty(sPath);

								const oEntryToDelete = oEntry.getLSRequest({
									UserGuid: oUserSetting.UserGuid,
									ProfileId: oUserSetting.ProfileId,
									Indicator: "D"
								});

								aEntriesToDelete.push(oEntryToDelete);
							}

							const aEntries = that.Model.getProperty("/Entries");

							if (aEntriesToDelete.length > 0) {
								that._saveEntries(aEntriesToDelete)
									.then(response => {
										if (response) {
											const results = response.N_TimesheetDetail.results;
											for (let i = 0; i < results.length; i++) {
												const oDeletedEntry = aEntries.find(item => item.MtrUid === results[i].MtrUid);

												if (oDeletedEntry) {
													oDeletedEntry.Indicator = "D";
												}
											}

											const aFilteredEntries = aEntries.filter(item => item.Indicator !== "D");
											that.Model.setProperty("/Entries", aFilteredEntries);
											that.Model.refresh(true);
											idSavedEntriesTable.removeSelections(true);
											that.enableDeleteButton(false);
											MessageToast.show("The entry/ies deleted successfully");
										}
									});
							}
						}
					}
				});

			},

			onSelectEntries: function (oEvent) {
				const oTable = oEvent.getSource();
				const btnDelete = sap.ui.core.Fragment.byId(this.DialogId, "btnDelete");
				if (oTable.getSelectedItems().length > 0) {
					btnDelete.setEnabled(true);
				} else {
					btnDelete.setEnabled(false);
				}
			},

			createColumnConfig: function () {
				var aCols = [];

				var EdmType = exportLibrary.EdmType;

				aCols.push({
					label: 'Date',
					property: ['RecordDate'],
					type: EdmType.Date,
					inputFormat: 'yyyymmdd',
					width: 15
				});

				aCols.push({
					label: 'Task',
					type: EdmType.String,
					property: 'MtrTaskName',
					width: 40
				});

				aCols.push({
					property: 'Activity ID',
					type: EdmType.Number,
					property: 'ActvtId',
					width: 10
				});

				aCols.push({
					property: 'Activity Name',
					type: EdmType.String,
					property: 'ActivityTypeName',
					width: 40
				});

				aCols.push({
					label: 'Location',
					type: EdmType.Enumeration,
					property: 'LocationId',
					valueMap: {
						'1': 'On Site',
						'4': 'Virtual'
					},
					width: 10
				});

				aCols.push({
					label: 'Cost Type',
					type: EdmType.Enumeration,
					property: 'CostTypeId',
					valueMap: {
						'1': 'Opportunity',
						'2': 'Cost Center',
						'4': 'Account'
					},
					width: 10
				});

				aCols.push({
					label: 'Cost Type Value',
					type: EdmType.String,
					property: 'CostTypeValue',
					width: 10
				});

				aCols.push({
					label: 'Duration',
					type: EdmType.String,
					property: 'WorkDuration'
				});

				aCols.push({
					ProjectType: 'Application',
					type: EdmType.Enumeration,
					property: 'ProjectType',
					valueMap: {
						'SLINE': 'MSL',
						'ACTVT': 'MAR',
						'MTR': 'MTR'
					},
					width: 5
				});

				return aCols;
			},

			onExport: function () {
				const oTable = sap.ui.core.Fragment.byId(this.DialogId, "savedEntries--idSavedEntriesTable");
				var aCols, oRowBinding, oSettings, oSheet;

				oRowBinding = oTable.getBinding('items');
				aCols = this.createColumnConfig();

				oSettings = {
					workbook: {
						columns: aCols,
						context: {
							sheetName: 'Saved'
						},
						hierarchyLevel: 'Level'
					},
					dataSource: oRowBinding,
					fileName: 'Time Recording.xlsx',
					worker: false // We need to disable worker because we are using a MockServer as OData Service
				};

				oSheet = new Spreadsheet(oSettings);
				oSheet.build().finally(function () {
					oSheet.destroy();
				});
			},

			/*onExit: function () {
				if (this.OrgChartDialog) {
					this.OrgChartDialog.destroy();
				}
			}*/
		});

		return MTR;
	});