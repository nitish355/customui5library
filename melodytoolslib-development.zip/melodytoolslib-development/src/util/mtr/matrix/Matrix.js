sap.ui.define([
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/Sorter",
	"sap/ui/core/library",
	"sap/ui/core/Fragment",
	"sap/ui/model/FilterType",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"com/melody/lib/enum/Actions",
	"sap/ui/model/FilterOperator",
	"com/melody/lib/util/mtr/MTR",
	"com/melody/lib/util/Activity",
	"sap/ui/core/format/DateFormat",
	"com/melody/lib/model/formatter",
	"com/melody/lib/util/UserMaster",
	"com/melody/lib/classes/Activity",
	"com/melody/lib/classes/mtr/Entry",
	"com/melody/lib/service/utilities",
	"com/melody/lib/util/mtr/MTRHelper",
	"com/melody/lib/util/mtr/MTRModels",
	"com/melody/lib/classes/mtr/Message",
	"com/melody/lib/service/DateService",
	"com/melody/lib/classes/mtr/Category",
	"com/melody/lib/classes/mtr/Staffing",
	"com/melody/lib/classes/mtr/ManualIO",
	"sap/ui/model/resource/ResourceModel",
	"com/melody/lib/util/account/Account",
	"com/melody/lib/classes/mtr/Timesheet",
	"com/melody/lib/classes/mtr/ArtesEntry",
	"com/melody/lib/service/mtr/MTRService",
	"com/melody/lib/service/mtr/ISPService",
	"com/melody/lib/classes/mtr/MTRAccount",
	"com/melody/lib/classes/mtr/MTRCostType",
	"com/melody/lib/classes/mtr/MTRLocation",
	"com/melody/lib/service/ActivityService",
	"com/melody/lib/classes/mtr/matrix/Matrix",
	"com/melody/lib/service/OpportunityService",
	"com/melody/lib/classes/mtr/OpportunityIOSettings",
	"com/melody/lib/controls/RapidRegistration/RapidRegistration",
	"com/melody/lib/model/StorageModel",
	"com/melody/lib/util/opportunity/Opportunity"
], function (MessageBox, MessageToast, Filter, Sorter, coreLibrary, Fragment, FilterType, Controller, JSONModel, Actions, FilterOperator, MTRUtil,
	ActivityUtil,
	DateFormat,
	formatter,
	UserMasterUtil, Activity, Entry, Utilities, MTRHelper, MTRModels,
	Message,
	DateService, Category, Staffing,
	ManualIO, ResourceModel, AccountUtil, Timesheet, ArtesEntry, MTRService,
	ISPService, MTRAccount, MTRCostType, MTRLocation, ActivityService, Matrix, OpportunityService, OpportunityIOSettings, RapidRegistration,
	oStorageModel, OpportunityUtil) {
	"use strict";
	const CalendarType = coreLibrary.CalendarType;
	this.batchIndex = 0;

	let oMatrix = {
		init: async function (controlRef) {
			try {
				this.parentControl = controlRef;
				this.getSolutionHierarchy();
				this.matrixInit().then(() => {

				});
			} catch (error) {
				// MessageBox.show(error);
				console.log("ERROR IN Util Matrix.js Init : ", error);
			}
		},

		//Function to Fetch Model
		getModel: function (name) {
			let model = MTRModels.getMatrixModel();
			return model;
		},

		//Function to create a new entry for create case
		fnSetUpdateCreateMatrix: function (aMatrixData) {
			let matrixModel = this.getModel("matrixModel");
			let oDefaultEntry = matrixModel.getProperty("/defaultEntry") || {};
			let oWeekDates = this.fnGetWeekFirstLastDates();
			let oNewMatrixEntry = this.fnCreateEmptyMatrixEntry(oWeekDates.dFirstdate,
				oWeekDates.dLastdate)[0];
			let oFirstRowMatrixEntry = aMatrixData[0]; //To check if its empty row
			if (oFirstRowMatrixEntry.ActvtId) { //IF ACTIVITYID is true then there is no empty row
				aMatrixData.unshift(oNewMatrixEntry);
			}
			oMatrix.fnSortData();
			return {
				oNewMatrixEntry: oNewMatrixEntry,
				aMatrixData: aMatrixData
			};
		},

		//Function to check if Entry is between the date range
		checkEntryBetweenDateRange: function (entryDate, oWeekDates) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const iWeekStartDay = oSettingsModel.getProperty("/WeekStartDay");
			const dStartDateOfWeek = this.dateService.getStartDateOfWeek(entryDate, iWeekStartDay);
			const sStartDateOfWeek = this.dateService.format(dStartDateOfWeek, "yMMdd");
			const tempEntryDate = new Date(entryDate);
			const sFirstDate = this.dateService.format(oWeekDates.dFirstdate, "yMMdd");
			return sStartDateOfWeek === sFirstDate;
		},

		/**
		 * @author DARSHAN
		 * @function matrixInit
		 * @description function to handle initial load of matrix
		 */
		matrixInit: async function () {
			let matrixModel = this.getModel("matrixModel");
			this.dateService = DateService.getInstance();
			this.genericDateFormat = sap.ui.core.format.DateFormat.getInstance({
				pattern: "yMMdd",
				calendarType: sap.ui.core.CalendarType.Gregorian
			});
			//Activity Role Info
			ActivityService.getUserActivityRole().then((oActivityRole) => {
				matrixModel.setProperty("/oActivityRole", oActivityRole);
				matrixModel.refresh();
			});

			ActivityService.fnGetActivitySets().then((aResponse) => {
				matrixModel.setProperty("/NoAssociationTitle", aResponse);
			});

			//constants
			const constants = oStorageModel.getProperty("/oConstants");
			if (!constants) {
				OpportunityService.getConstants().then(function (result) {
					var oData = result.data.results;
					let constants = {};
					for (var index in oData) {
						constants[oData[index].const_id] = oData[index];
					}
					oStorageModel.setProperty("/oConstants", constants);
					oStorageModel.refresh();
				});
			}
			//Create TaskId's for Learning and Activity
			const oTaskIds = this.getEntriesTaskIds();
			matrixModel.setProperty("/aValidActivityTaskId", oTaskIds.activityTaskId);
			matrixModel.setProperty("/aValidLearningTaskId", oTaskIds.learningTaskIds);
			matrixModel.refresh();
		},

		/**
		 * @author DARSHAN
		 * @function getMTRSettingData
		 * @description function to fetch MTR Settings data
		 */
		getMTRSettingData: function () {
			const targetModel = MTRModels.getTargetModel();
			const settingsModel = MTRModels.getMTRSettingsModel();
			let iWeekStartDay = settingsModel.getProperty("/WeekStartDay");
			let costCenter = settingsModel.getProperty("/CostCenter");
			let TimeMatrics = settingsModel.getProperty("/TimeMatrics");
			const aHolidays = targetModel.getProperty("/Holidays");
			const aVacations = targetModel.getProperty("/Vacations");
			const TargetHours = targetModel.getProperty("/TargetHours");
			return {
				costCenter: costCenter,
				TimeMatrics: TimeMatrics,
				holidays: aHolidays || [],
				vacations: aVacations || [],
				targetHours: TargetHours || [],
				weekStartDayNumber: iWeekStartDay
			};
		},

		/**
		 * @author DARSHAN
		 * @function getTaskFKTaskIds
		 * @description function to fetch MTR Task-Id data
		 */
		getEntriesTaskIds: function () {
			const settingsModel = MTRModels.getMTRSettingsModel();
			const aMTRTasks = settingsModel.getProperty("/MTRTasks") || [];
			let bEssInMu = settingsModel.getProperty("/UserNotifEssInMu");
			let aTasks = aMTRTasks.filter(function (task) {
				return (bEssInMu && !task.EssInMu) || !bEssInMu;
			});
			let aLearningFilteredTask = aTasks.filter((task) => {
				return task.AddCategoryId === "5"
			});
			let aActivityFilteredTask = aTasks.filter((task) => {
				return task.AddCategoryId === "3"
			});
			let aValidActivityTaskId = aActivityFilteredTask.map(Task => Task.TaskId).filter(id => id);
			let aValidLearningTaskId = aLearningFilteredTask.map(Task => Task.TaskId).filter(id => id);
			aValidLearningTaskId.push(10);
			return {
				activityTaskId: aValidActivityTaskId,
				learningTaskIds: aValidLearningTaskId
			};
		},

		/**
		 * @author DARSHAN
		 * @function getStartAndEndDateForActivity
		 * @description function to create start and end date filter
		 * @param {Object} oWeekDates
		 */
		getStartAndEndDateForActivity: function (oWeekDates) {
			let dStartDate = new Date(oWeekDates.dLastdate);
			let startMonth = dStartDate.getMonth() + 1;
			if (startMonth < 10) {
				startMonth = "0" + startMonth;
			}
			let startDay = dStartDate.getDate();
			if (startDay < 10) {
				startDay = "0" + startDay;
			}
			let fltrStartDate = dStartDate.getFullYear() + "-" + startMonth + "-" + startDay + "T23:59:00";
			let dEndDate = new Date(oWeekDates.dFirstdate);
			let endMonth = dEndDate.getMonth() + 1;
			if (endMonth < 10) {
				endMonth = "0" + endMonth;
			}
			let endDay = dEndDate.getDate();
			if (endDay < 10) {
				endDay = "0" + endDay;
			}
			let fltrEndDate = dEndDate.getFullYear() + "-" + endMonth + "-" + endDay + "T00:00:00";
			return {
				dStartDate: new Date(fltrStartDate),
				dEndDate: new Date(fltrEndDate)
			};
		},

		/**
		 * @author DARSHAN
		 * @function fetchActivitiesBasedOnWeek
		 * @description function to fetch activities based on weeks
		 * @param {Object} event
		 */
		fetchActivitiesBasedOnWeek: async function (oWeekDates) {
			let aFilters = [];
			let oMonthDate = DateService.getInstance().getStartAndEndDateOfMonth(new Date());
			let flterDates = this.getStartAndEndDateForActivity(oWeekDates);
			let oStartDate = new Filter("StartDate", sap.ui.model.FilterOperator.LE, flterDates.dStartDate);
			aFilters.push(oStartDate);
			let oLasttDate = new Filter("EndDate", sap.ui.model.FilterOperator.GE, flterDates.dEndDate);
			aFilters.push(oLasttDate);
			let filter5 = new Filter({
				path: "ActivitySetStatus",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: ""
			});
			aFilters.push(filter5);
			let filter6 = new Filter({
				path: "ActivityTypeId",
				operator: sap.ui.model.FilterOperator.NE,
				value1: "0013"
			});
			aFilters.push(filter6);
			let filter7 = new Filter({
				path: "ActivityTypeId",
				operator: sap.ui.model.FilterOperator.NE,
				value1: "0012"
			});
			aFilters.push(filter7);
			let filter8 = new Filter({
				path: "ActivityTypeId",
				operator: sap.ui.model.FilterOperator.NE,
				value1: "0015"
			});
			aFilters.push(filter8);
			let filter16 = new Filter({
				path: "ActivityTypeId",
				operator: sap.ui.model.FilterOperator.NE,
				value1: "0124"
			});
			aFilters.push(filter16);

			return ActivityService.getUserActivities(null, aFilters);
		},

		getSolutionHierarchy: async function () {
			const oSolutionsModel = MTRModels.getSolutionHierarchyModel();
			const aSolHierarchy = oSolutionsModel.getProperty("/SolutionHierarchy");
			if (!aSolHierarchy) {
				this.fnFetchSolHierarchy(oSolutionsModel);
			}
		},

		//Function to fetch solution hierarchy in batches
		fnFetchSolHierarchy: async function (oSolutionsModel) {
			let promises = [];
			let aSolHierarchyData = [];
			let batchCount = 2000;
			let startIndex = 0;
			let aBatchResponses = [];
			const totalCount = await ActivityService.getSolHierarchyCount();
			batchCount = totalCount < batchCount ? 500 : batchCount;
			const batches = Math.ceil(totalCount / batchCount);

			for (let i = 0; i < batches; i++) {
				let skip = 0;
				if (i !== 0) {
					skip = startIndex + batchCount;
				}
				startIndex = skip;

				let batch = {
					urlParameters: {
						$top: batchCount,
						$skip: skip
					}
				};
				promises.push(ActivityService.getSolutionHierarchy(batch));
			}

			const responses = await Promise.all(promises);
			if (!responses || !responses.length) {
				responses = [];
			}
			aBatchResponses = responses.flat();

			var oMaterialMap = {};
			var aMaterialData = aBatchResponses.map(function (obj, index) {
				obj.isSelected = false;
				oMaterialMap[obj["MatId"]] = index;
				return obj;
			});
			oSolutionsModel.setProperty("/SolutionHierarchy", aMaterialData);
			oSolutionsModel.setProperty("/MaterialMap", oMaterialMap);
		},

		/**
		 * @author DARSHAN
		 * @function handleTimeRecord
		 * @description function to open matrix time entry dialog
		 * @param {Object} event
		 */
		loadMatrixTimeRecordingDialog: async function (event, parentRef) {
			try {
				this.matrixResponse = [];
				this.batchIndex = 0;
				let id = `_MatrixTimeRecordingDialog`;
				let matrixModel = this.getModel("matrixModel");
				const targetModel = MTRModels.getTargetModel();
				const settingsModel = MTRModels.getMTRSettingsModel();
				let dayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				const aMTRTasks = settingsModel.getProperty("/MTRTasks") || [];
				let aEntries = dayWeekTimesheetModel.getProperty("/Entries") || [];
				let oDefaultEntry = matrixModel.getProperty("/defaultEntry") || {};
				let bEssInMu = settingsModel.getProperty("/UserNotifEssInMu");
				let activityStartDate = ("startDate" in oDefaultEntry && oDefaultEntry.startDate) ? oDefaultEntry.startDate : new Date();
				let i18nModel = new ResourceModel({
					bundleName: "com.melody.lib.i18n.i18n"
				});
				const aValidActivityTaskId = matrixModel.getProperty("/aValidActivityTaskId") || [];
				const aValidLearningTaskId = matrixModel.getProperty("/aValidLearningTaskId") || [];
				matrixModel.setProperty("/matrixDataUpdatedWithOppAcc", false)
				//FOR MATRIX CSS - START
				let libraryPath = jQuery.sap.getModulePath("com.melody.lib");
				jQuery.sap.includeStyleSheet(libraryPath + "/controls/mtr/matrix/matrixStyle.css");
				//FOR MATRIX CSS - END

				//CLONE OF TOTAL ENTRIES
				matrixModel.setProperty("/aMasterEntries", aEntries.map((entry) => entry));

				if (this.matrixController) {
					this.matrixController.parentControl = this;
				} else {
					this.matrixController = new matrixTimeController(this);
				}

				//Temp Solution
				if (this.matrixTimeRecordingDialog) {
					this.matrixTimeRecordingDialog.destroy();
					this.matrixTimeRecordingDialog = null;
				}

				//Check for MyEntries Page
				let oHashChanger = new sap.ui.core.routing.HashChanger();
				let hashValue = oHashChanger.getHash();
				if (hashValue && (hashValue.includes("pcactivityform-app&/MyEntries") || hashValue.includes("/MyEntries"))) {
					matrixModel.setProperty("/bVisibleTimeEntry", false);
				} else {
					matrixModel.setProperty("/bVisibleTimeEntry", true);
				}

				//Create TaskId's for Learning and Activity
				const oTaskIds = this.getEntriesTaskIds();
				matrixModel.setProperty("/aValidActivityTaskId", oTaskIds.activityTaskId);
				matrixModel.setProperty("/aValidLearningTaskId", oTaskIds.learningTaskIds);

				if (!this.matrixTimeRecordingDialog) {
					this.matrixTimeRecordingDialog = Fragment.load({
						id: id,
						name: "com.melody.lib.fragments.MTR.Matrix.MatrixCreateTimeEntry",
						controller: this.matrixController
					}).then((dialog) => {
						parentRef.addDependent(dialog);
						this.oParentCtrl = parentRef;
						matrixModel.setProperty("/MatrixListDialogBusy", true);
						matrixModel.setProperty("/IsSaveBusy", false);
						matrixModel.setProperty("/IsSubmitBusy", false);
						matrixModel.setProperty("/matrixCategory", oDefaultEntry.activeTab);
						matrixModel.setProperty("/sSearchMatrixList", "");
						//Models
						dialog.setModel(i18nModel, "i18n");
						dialog.setModel(targetModel, "target");
						dialog.setModel(matrixModel, "matrixModel");
						dialog.setModel(settingsModel, "mtrSettings");
						dialog.setModel(dayWeekTimesheetModel, "dayWeekTimesheet");
						const oResourceBundle = dialog.getModel("i18n").getResourceBundle();
						matrixModel.setProperty("/sActivityMatrixListNoDataTxt", oResourceBundle.getText("activityMatrixListNoDataTxt"));
						this.matrixTimeRecordingDialog = dialog;
						dialog.open();

						this.fnSetMatrixCalenderFocus(activityStartDate);
						this.seperateEntriesBasedOnDate(activityStartDate, true).then((aMatrixData) => {
							if (oDefaultEntry.activeTab === Actions.matrixCategory.learning) {
								matrixModel.setProperty("/matrixLearningData", aMatrixData);
							} else {
								matrixModel.setProperty("/matrixActivityData", aMatrixData);
							}
							matrixModel.setProperty("/MatrixListDialogBusy", false);
							matrixModel.refresh();
						});
					});
				} else {
					this.matrixTimeRecordingDialog.open();
				}
			} catch (error) {
				console.log("ERROR IN loadMatrixTimeRecordingDialog : ", error);
			}
		},

		//Function to set Matrix Calendar focus based on activity start if available
		fnSetMatrixCalenderFocus: function (activityStartDate) {
			let currentDate = new Date();
			let actvtStart = new Date(activityStartDate);
			let oMartixCalendar = this.fnGetDialogUsingId("_MatrixTimeRecordingDialog", "MatrixCal");
			if (actvtStart.getTime() > currentDate.getDate()) {
				const oWeekData = this.fnGetWeekFirstLastDates(actvtStart);
				if (oMartixCalendar) {
					const oShortCalender = oMartixCalendar.getAggregation("_shortCalendar");
					oMartixCalendar.setStartDate(oWeekData.dFirstdate);
				}
			}
		},

		//function to get Dialog with ID
		fnGetDialogUsingId: function (dialogId, contentId) {
			return sap.ui.core.Fragment.byId(dialogId, contentId);
		},

		/**
		 * @author DARSHAN
		 * @function fnSortEntriesBasedOnDefaultEntry
		 * @description function to sort based on default Entry (Edit)
		 */
		fnSortEntriesBasedOnDefaultEntry: function (oDefaultEntry = {}, aMatrixData) {
			let isMatrixEditList = oDefaultEntry.isMatrixEditList;
			if (!isMatrixEditList) {
				return;
			}
			let aSortedData = [];
			let aGivenActivities = [];
			let aOtherActivities = [];

			for (let i = 0; i < aMatrixData.length; i++) {
				let entry = aMatrixData[i];
				//Activity
				if (oDefaultEntry.activityId) {
					if ((entry.ActvtId === oDefaultEntry.activityId && entry.CostTypeId === oDefaultEntry.costTypeId && entry.CostTypeValue ===
						oDefaultEntry.costTypeValue) || (entry.ActvtId === oDefaultEntry.activityId)) {
						aGivenActivities.push(entry);
					} else {
						aOtherActivities.push(entry);
					}
				}

				//Learning
				if (!oDefaultEntry.activityId) {
					if (entry.TaskId === oDefaultEntry.taskId && entry.CostTypeId === oDefaultEntry.costTypeId && entry.CostTypeValue ===
						oDefaultEntry.costTypeValue) {
						aGivenActivities.push(entry);
					} else {
						aOtherActivities.push(entry);
					}
				}
			}

			aSortedData = aSortedData.concat(aGivenActivities);
			aSortedData = aSortedData.concat(aOtherActivities);
			return aSortedData;
		},

		/**
		 * @author DARSHAN
		 * @function fnGetWeekFirstLastDates
		 * @description Helper function to get first date and last date of the week
		 */
		fnGetWeekFirstLastDates: function (firstdate) {
			let dFirstdate;
			const matrixModel = this.getModel("matrixModel");
			const settingsModel = MTRModels.getMTRSettingsModel();
			let iWeekStartDay = settingsModel.getProperty("/WeekStartDay"); //0 is for Sunday, 1 is for Monday etc.
			let dayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			let changedCalendarDate = matrixModel.getProperty("/changedCalendarDate");

			let oDefaultEntry = matrixModel.getProperty("/defaultEntry") || {};
			let activityStartDate = ("startDate" in oDefaultEntry && oDefaultEntry.startDate) ? oDefaultEntry.startDate : new Date();

			//If firstdate params is false then update the date with calendar's start date;
			if (!firstdate) {
				firstdate = changedCalendarDate;
			}

			if (firstdate) {
				dFirstdate = this.dateService.getStartDateOfWeek(firstdate, iWeekStartDay)
			} else {
				dFirstdate = this.dateService.getStartDateOfWeek(activityStartDate, iWeekStartDay);
			}
			dFirstdate.setHours(0, 0, 0);
			let tempFirstDate = new Date(dFirstdate);
			let dLastdate = new Date(tempFirstDate.setDate(tempFirstDate.getDate() + 6));
			dLastdate.setHours(23, 59, 59);
			return {
				dFirstdate: dFirstdate,
				dLastdate: dLastdate
			}
		},

		/**
		 * @author DARSHAN
		 * @function fnCreateEntryObject
		 * @description function to create an emptry object with Entry class reference
		 */
		fnCreateEntryObject: function () {
			const matrixModel = this.getModel("matrixModel");
			const settingsModel = MTRModels.getMTRSettingsModel();
			const learningCstCntrValue = settingsModel.getProperty("/CostCenter");
			let selectedCategory = matrixModel.getProperty("/matrixCategory") || Actions.matrixCategory.activity;
			let sDefaultRecordDate = this.genericDateFormat.format(new Date());
			let oNewEntry = new Entry({
				ActvtId: "",
				TaskId: (selectedCategory === Actions.matrixCategory.activity) ? "3" : "",
				IsLegacy: "",
				CostTypeId: (selectedCategory === Actions.matrixCategory.learning) ? "2" : "",
				CostTypeValue: (selectedCategory === Actions.matrixCategory.learning) ? learningCstCntrValue : "",
				CustomerFacing: (selectedCategory === Actions.matrixCategory.learning) ? false : "",
			});
			oNewEntry.WorkDuration = "";
			oNewEntry.setRecordDate(sDefaultRecordDate);
			return oNewEntry;
		},

		/**
		 * @author DARSHAN
		 * @function seperateEntriesBasedOnDate
		 * @description function to segregate entries data based first date (Monday) to last date (Sunday) of the week 
		 */

		seperateEntriesBasedOnDate: async function (firstdate, calculateTotalHours = false, navFromCalendar = false, searchQuery = false) {

			try {
				this.batchSize = 10;
				if (!this.batchIndex) {
					this.batchIndex = 0;
				}
				if (!this.totalBatches) {
					this.totalBatches = 0;
				}
				let aMatrixData;
				let regMatrixEntry;
				let aActivityTaskId = [];
				const oThisController = this;
				const matrixModel = this.getModel("matrixModel");
				const settingsModel = MTRModels.getMTRSettingsModel();
				let dayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				let oWeekDates = this.fnGetWeekFirstLastDates(firstdate);
				let oDefaultEntry = matrixModel.getProperty("/defaultEntry") || {};
				let aEntries = dayWeekTimesheetModel.getProperty("/Entries") || [];
				const aValidActivityTaskId = matrixModel.getProperty("/aValidActivityTaskId") || [];
				const aValidLearningTaskId = matrixModel.getProperty("/aValidLearningTaskId") || [];
				const learningCstCntrValue = settingsModel.getProperty("/CostCenter");
				let selectedCategory = matrixModel.getProperty("/matrixCategory") || Actions.matrixCategory.activity;
				matrixModel.setProperty("/matrixActivityListBusy", true);
				const allactivities =  await ActivityUtil.getUserActivities(true) ?? [];
				matrixModel.setProperty("/allActivities", allactivities);
				//Default Entry when no entries are available
				let oNewEntry = this.fnCreateEntryObject();

				//Segregate date wise
				let aEntriesBasedOnDate = aEntries.filter((entry) => {
					let taskId = (entry.TaskId) ? parseInt(entry.TaskId) : 0;
					let entryDate = this.dateService.formatStringDate(entry.RecordDate);
					let validEntry = this.checkEntryBetweenDateRange(entryDate, oWeekDates)
					if (validEntry && entry.WorkDuration) {
						//Activity Based
						if (selectedCategory === Actions.matrixCategory.activity && entry.ActvtId && aValidActivityTaskId.indexOf(taskId) !== -1) {
							return entry;
						}
						//Learning & Others
						if (selectedCategory === Actions.matrixCategory.learning && (aValidLearningTaskId.indexOf(taskId) !== -1 || !entry.ActvtId)) {
							return entry;
						}
					}
				});

				if (aEntriesBasedOnDate.length) {
					//Create Scenario
					//Learning Create case
					if (selectedCategory === Actions.matrixCategory.learning) {
						oNewEntry.TaskId = "10";
					}

					//Edit Scenraio if no entry is available for that activity (Only In case of ACTVT based application)
					if (oDefaultEntry.isMatrixEditList && oDefaultEntry.activityId && selectedCategory === Actions.matrixCategory.activity) {
						let validEntry = this.checkEntryBetweenDateRange(oDefaultEntry.startDate, oWeekDates)
						if (validEntry) {
							const aDataPresent = aEntriesBasedOnDate.filter(entry => entry.ActvtId === oDefaultEntry.activityId);
							if (!aDataPresent.length) {
								oNewEntry.ActvtId = oDefaultEntry.activityId;
								aEntriesBasedOnDate.unshift(oNewEntry);
							}
						}
					}
					aMatrixData = this.fnHelpInFormationOfMatrixData(aEntriesBasedOnDate, oWeekDates.dFirstdate, oWeekDates.dLastdate);

					//Edit Scenario
					if (oDefaultEntry.isMatrixEditList) {
						aMatrixData = this.fnSortEntriesBasedOnDefaultEntry(oDefaultEntry, aMatrixData)
					}

					//To keep first row as register always
					/*oNewEntry.ActvtId = "";
					regMatrixEntry = this.fnCreateEmptyMatrixEntry(oWeekDates.dFirstdate, oWeekDates.dLastdate, oNewEntry)[0];
					aMatrixData.unshift(regMatrixEntry);*/
					if (selectedCategory === Actions.matrixCategory.learning) {
						oNewEntry.ActvtId = "";
						regMatrixEntry = this.fnCreateEmptyMatrixEntry(oWeekDates.dFirstdate, oWeekDates.dLastdate, oNewEntry)[0];
						regMatrixEntry.visible.deleteicon = false;
						aMatrixData.unshift(regMatrixEntry);
					}
				} else {
					/****When there are no entries available***/
					//Edit Scenario (Only In case of ACTVT based Tab)
					if (oDefaultEntry.isMatrixEditList && !navFromCalendar && selectedCategory === Actions.matrixCategory.activity) {
						oNewEntry.ActvtId = oDefaultEntry.activityId;
					}

					//Learning Create case
					if (selectedCategory === Actions.matrixCategory.learning) {
						oNewEntry.TaskId = "10";
						aMatrixData = this.fnCreateEmptyMatrixEntry(oWeekDates.dFirstdate, oWeekDates.dLastdate, oNewEntry);
						//To keep first row as register always (Activity Case)
						if (oDefaultEntry.isMatrixEditList && !navFromCalendar && selectedCategory === Actions.matrixCategory.activity) {
							aMatrixData[0].isMatrixEditable = false; // TODO check this in edit case
							regMatrixEntry = this.fnCreateEntryObject();
							regMatrixEntry = this.fnCreateEmptyMatrixEntry(oWeekDates.dFirstdate, oWeekDates.dLastdate, regMatrixEntry)[0];
							aMatrixData.unshift(regMatrixEntry);
						}
					}

				}


				//Fetch Activities based on Week range
				if (selectedCategory === Actions.matrixCategory.activity) {
					if (!this.matrixResponse || this.matrixResponse.length === 0) {
						this.matrixResponse = [];
						this.fetchActivitiesBasedOnWeek(oWeekDates).then((aResponse) => {
							if (aResponse && aResponse.length) {
								this.totalBatches = Math.ceil(aResponse.length / this.batchSize);
								if (matrixModel.getProperty("/sSearchMatrixList")) {
									matrixModel.setProperty('/isloadModeVisible', false);
								}
								else {
									matrixModel.setProperty('/isloadModeVisible', true);

								}
								this.totalBatches = Math.ceil(aResponse.length / this.batchSize);
								this.weeksDates = oWeekDates;
								this.matrixData = aMatrixData;
								this.matrixResponse = aResponse;
								this.totalEntriesLoaded = 0;
								let matrixDifference = 0;
								if (this.matrixData) {
									const aResponseId = new Set(this.matrixResponse.map(obj => obj.ActivityId));
									matrixDifference = this.matrixData.filter(obj => !aResponseId.has(obj.ActvtId)).map(obj => obj.ActvtId).length
								}
								matrixModel.setProperty('/weekActivityCount', aResponse.length + matrixDifference);
								this.fnGenerateMatrixRows(false);

							} else {

								this.checkAndUpdateDraftsToMatrix(oWeekDates);
								matrixModel.setProperty('/isloadModeVisible', false);
								matrixModel.setProperty("/matrixActivityListBusy", false);
							}

						})
							.catch(function (error) {
								console.log("ERROR IN PROCESSING BATCH : ", error)
							});
					} else {
						if (this.matrixResponse.length > 10) {
							matrixModel.setProperty('/isloadModeVisible', true);

						}

						this.fnGenerateMatrixRows(false);
					}
					// this.fetchActivitiesBasedOnWeek(oWeekDates).then((aResponse) => {
					// 	if (aResponse && aResponse.length) {
					// 		this.totalBatches = Math.ceil(aResponse.length / this.batchSize);
					// 		this.weeksDates = oWeekDates;
					// 		this.matrixResponse = aResponse;
					// 		this.fnGenerateMatrixRows();
					// 	} else {
					// 		this.checkAndUpdateDraftsToMatrix(oWeekDates);
					// 		setTimeout(() => {
					// 			oThisController.fnSortData();
					// 		}, 800);

					// 		matrixModel.setProperty("/matrixActivityListBusy", false);
					// 	}
					// 	matrixModel.refresh();
					// })
					// 	.catch(function (error) {
					// 		console.log("ERROR IN PROCESSING BATCH : ", error)
					// 	});
				} else {
					matrixModel.setProperty("/matrixActivityListBusy", false);
				}

				if (calculateTotalHours) {
					//this.fnCalculateTotalHours(firstdate);
					this.fnUpdateTotalHours(firstdate, aMatrixData);
					//this.updateExpectedDailyBar(firstdate, aMatrixData);
				}
				this.fnCalculateSubTotal(aMatrixData);
				if (selectedCategory === Actions.matrixCategory.learning && aMatrixData && aMatrixData.length === 1) {
					// need to test - delete button hide in 1st blank row in learning tab.
					aMatrixData[0].visible.deleteicon = false;
				}
				//
				// oThisController.fnSortData();


				return aMatrixData;
			} catch (error) {
				console.log("ERROR IN seperateEntriesBasedOnDate : ", error);
			}
		},

		fnGenerateMatrixRows: function (searchQuery = false) {
			const matrixModel = this.getModel("matrixModel");
			matrixModel.setProperty("/matrixActivityListBusy", true);
			let aMatrixActvtData = matrixModel.getProperty("/matrixActivityData") || [];
			if (searchQuery) {
				const aMatrixResponseId = this.matrixResponse.map(item => String(item.ActivityId));
				const aUpdatedMatrixActvtData = aMatrixActvtData.filter(item => aMatrixResponseId.includes(item.ActvtId));
				const aMatrixActvtId = aMatrixActvtData.map(item => String(item.ActvtId));
				this.matrixResponse = this.matrixResponse.filter(item => !aMatrixActvtId.includes(item.ActivityId));
				aMatrixActvtData = aUpdatedMatrixActvtData;
				matrixModel.setProperty("/isloadModeVisible", false);
				this.fnCreateActivityMatrixEntry(this.matrixResponse, this.matrixResponse, this.weeksDates);
				setTimeout(function () { matrixModel.setProperty("/matrixActivityListBusy", false) }, 1000);
			}

			if (this.batchIndex < this.totalBatches) {
				let batchData = this.matrixResponse.slice(this.batchIndex * this.batchSize, (this.batchIndex + 1) * this.batchSize);
				this.totalEntriesLoaded += batchData.length;
				this.fnCreateActivityMatrixEntry(batchData, this.matrixData, this.weeksDates);
				this.batchIndex++;
				matrixModel.setProperty('/weekLoadedActivityCount', this.totalEntriesLoaded);
				if (this.totalEntriesLoaded === this.matrixResponse.length) {
					matrixModel.setProperty("/isloadModeVisible", false);
				}

			} else {

				this.checkAndUpdateDraftsToMatrix(this.weeksDates);

			}
			matrixModel.refresh(true);
			setTimeout(function () { matrixModel.setProperty("/matrixActivityListBusy", false) }, 1000);
		},


		//Function to update Total/SubTotal/ExpectedDailyBar Hours
		fnUpdateTotalHours: function (firstdate, aMatrixData) {
			this.fnCalculateTotalHours(firstdate);
			this.updateExpectedDailyBar(firstdate, aMatrixData);
			this.fnCalculateSubTotal(aMatrixData);
		},

		//Helper Function to help in creation of Matrix and CF/NCF Date when Entries are available
		fnHelpInFormationOfMatrixData: function (aEntriesBasedOnDate, dFirstdate, dLastdate) {

			try {
				let aMatrixListData = [];
				let oLocalMap = new Map();
				let aLocalMatrixStruct = [];
				let counterKey = [];
				const matrixModel = this.getModel("matrixModel");
				let selectedCategory = matrixModel.getProperty("/matrixCategory");
				const aValidActivityTaskId = matrixModel.getProperty("/aValidActivityTaskId") || [];
				const aValidLearningTaskId = matrixModel.getProperty("/aValidLearningTaskId") || [];
				const allactivities = matrixModel.getProperty("/allActivities");

				//Merge Based on (Activity-Id,ActAsstId,CostTypeValue)
				for (let i = 0; i < aEntriesBasedOnDate.length; i++) {
					let oMatchCombination;
					const matrixEntry = {};
					let entry = aEntriesBasedOnDate[i];
					entry = Object.assign(new Entry(), entry); //Clone the object along with its class
					let activityId = ("ActvtId" in entry && entry.ActvtId) ? parseInt(entry.ActvtId).toString() : "";
					let costTypeId = ("CostTypeId" in entry) ? entry.CostTypeId : "";
					let costTypeValue = ("CostTypeValue" in entry) ? entry.CostTypeValue : "";
					let locationId = ("LocationId" in entry) ? entry.LocationId : "";
					let taskId = ("TaskId" in entry) ? entry.TaskId : "";
					let iTaskId = ("TaskId" in entry && entry.TaskId) ? parseInt(entry.TaskId) : 0;
					let entryDate = this.dateService.formatStringDate(entry.RecordDate);
					let dateKey = ("RecordDate" in entry) ? new Date(entryDate).toLocaleDateString("en-GB") : "";
					let isLegacy = ("IsLegacy" in entry) ? entry.IsLegacy : "";
					let statusId = ("StatusId" in entry) ? entry.StatusId : "";
					let actAsstId = ("ActAsstId" in entry) ? entry.ActAsstId : "";
					let addCategoryId = ("AddCategoryId" in entry) ? entry.AddCategoryId : "";
					let isVisibleInMatrix = ("isVisibleInMatrix" in entry) ? entry.isVisibleInMatrix : true;
					let isNonMatEntry = ("isNonMatEntry" in entry) ? entry.isNonMatEntry : false;
					let isCustomerFacing = (entry.CustomerFacing && selectedCategory === Actions.matrixCategory.activity) ? entry.CustomerFacing :
						false;
					if ((actAsstId === "502" || actAsstId === "501") && costTypeValue) {
						costTypeValue = parseInt(entry.CostTypeValue).toString();
					}

					//Create a local structure to understand the data segregation
					const generatedDates = this.fnGenerateDatesBucket(dFirstdate, dLastdate);
					matrixEntry.ncf = JSON.parse(JSON.stringify(generatedDates));
					matrixEntry.Entries = JSON.parse(JSON.stringify(generatedDates));
					if (selectedCategory === Actions.matrixCategory.activity) {
						matrixEntry.cf = JSON.parse(JSON.stringify(generatedDates));
					}

					//Local Structure
					matrixEntry.ActAsstId = actAsstId;
					matrixEntry.CostTypeId = costTypeId;
					matrixEntry.CostTypeValue = costTypeValue;
					matrixEntry.ActvtId = activityId;
					matrixEntry.StatusId = statusId;
					matrixEntry.LocationId = locationId;
					matrixEntry.IsLegacy = isLegacy;
					matrixEntry.TaskId = taskId;
					matrixEntry.selectedCategory = selectedCategory;
					matrixEntry.isVisibleInMatrix = isVisibleInMatrix;
					matrixEntry.isNonMatEntry = isNonMatEntry;
					const findactivityforarchived = allactivities.filter(function (item) {
						return item.ActivityId === activityId;
					});
					matrixEntry.Archived = findactivityforarchived?.[0]?.Archived ?? "";




					// matrixEntry.AddCategoryId = addCategoryId;
					matrixEntry.ActivityTypeId = ("ActDetails" in entry && Object.keys(entry.ActDetails).length) ? entry.ActDetails.ActivityTypeId :
						"";

					//To check if the entry is from outside melody application (classic MTR) or Others
					if (selectedCategory === Actions.matrixCategory.learning && aValidLearningTaskId.indexOf(iTaskId) === -1 && !entry.ActvtId) {
						isCustomerFacing = false;
						matrixEntry.IsOthers = true;
						matrixEntry.TaskName = ("TaskName" in entry) ? entry.TaskName : "";
					}

					//CREATE THE COMBINATIONS
					aMatrixListData = this.compareAndGenerateMatrixEntries(entry, matrixEntry, aMatrixListData, {
						taskId: taskId,
						dateKey: dateKey,
						activityId: activityId,
						costTypeId: costTypeId,
						costTypeValue: costTypeValue,
						isCustomerFacing: isCustomerFacing
					});

				}
				if (aMatrixListData.length) {
					aMatrixListData = this.fnCreateMartixClassBasedData(aMatrixListData);
					return aMatrixListData;
				}
			} catch (error) {
				console.log("ERROR IN fnHelpInFormationOfMatrixData : ", error);
			}
		},

		//Function to compare and generate the comparison
		compareAndGenerateMatrixEntries: function (entry, matrixEntry, aMatrixListData, options = {}) {
			try {
				let oMatchCombination;
				let dateKey = options.dateKey;
				const matrixModel = this.getModel("matrixModel");
				let selectedCategory = matrixModel.getProperty("/matrixCategory");

				//Activity
				if (selectedCategory === Actions.matrixCategory.activity) {
					// comb.AddCategoryId === addCategoryId &&
					oMatchCombination = aMatrixListData.find(comb =>
						comb.ActvtId === options.activityId &&
						comb.CostTypeId === options.costTypeId &&
						comb.CostTypeValue === options.costTypeValue &&
						(!(options.isCustomerFacing ? comb.cf[dateKey].length : comb.ncf[dateKey].length))
					);
				} else {
					//Learning
					oMatchCombination = aMatrixListData.find(comb =>
						comb.TaskId === options.taskId && comb.CostTypeId === options.costTypeId && comb.CostTypeValue === options.costTypeValue &&
						(!(options.isCustomerFacing ? comb.cf[dateKey].length : comb.ncf[dateKey].length))
					);
				}

				if (!oMatchCombination) {
					oMatchCombination = matrixEntry;
					aMatrixListData.push(oMatchCombination);
				}

				if (options.isCustomerFacing) {
					if (oMatchCombination.cf[dateKey]) {
						oMatchCombination.cf[dateKey].push(entry);
					}
				} else {
					if (oMatchCombination.ncf[dateKey]) {
						entry.CustomerFacing = false;
						oMatchCombination.ncf[dateKey].push(entry);
					}
				}
				return aMatrixListData;
			} catch (error) {
				console.log("ERROR IN compareAndGenerateMatrixEntries : ", error);
			}
		},

		//Function to generate Matrix entry based on Activities
		fnCreateActivityMatrixEntry: async function (aActivityResponse, aExistingMatrixActvtData = [], oWeekDates) {
			let matrixModel = this.getModel("matrixModel");
			let selectedCategory = matrixModel.getProperty("/matrixCategory") || Actions.matrixCategory.activity;
			let aMatrixActvtData = matrixModel.getProperty("/matrixActivityData") || [];
			for (let i = 0; i < aActivityResponse.length; i++) {
				let oActivity = aActivityResponse[i];
				let iExists = aExistingMatrixActvtData.findIndex((matrixEntry) => matrixEntry.ActvtId === oActivity.ActivityId);
				if (iExists === -1) {
					let oMatrix = new Matrix();
					oMatrix = this.fnCreateEmptyMatrixEntry(oWeekDates.dFirstdate, oWeekDates.dLastdate, oMatrix)[0]
					oMatrix.fnSetActivityToMatrixValues(oActivity);
					if (oActivity.ActAsstId === "502") {
						let oOpportunity = {};
						const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
						let aStoredOpps = oStorage.get("pcActiveOpportunityTeam") || [];
						const sOppId = oActivity.OpportunityId;
						oOpportunity = aStoredOpps.find(opp => opp.OPPT_ID === sOppId);
						if (!oOpportunity) {
							const mParameters = {
								Url: "/Opportunities",
								OpportunityIds: [sOppId],
								Select: "SALES_ORG_TEXT,SALES_ORG_SHORT,OPPT_ID,ACCOUNT_NAME,ACCOUNT,DESCRIPTION,OWNER,OWNER_NAME," +
									"STATUS,CURR_PHASE,EXPECTED_VALUE,INTERNAL_ORDER1,INTERNAL_ORDER2,LICENSE_REVENUE,CLOUD_REVENUE,EXPECT_END,REPLACED_BY,STATUS_SINCE,PartiesInvolved",
								Expand: "PartiesInvolved"
							};
							let aResponse = await OpportunityUtil.fnGetOpportunitiesDetails(mParameters);
							oOpportunity = aResponse?.[0] ?? {};
							const oppExists = aStoredOpps.some(opp => opp.OPPT_ID === sOppId);
							if (!oppExists && Object.keys(oOpportunity).length) {
								aStoredOpps.push(oOpportunity);
								oStorage.put("pcActiveOpportunityTeam", aStoredOpps);
							}
						}
						oMatrix.OpportunityID = oOpportunity?.OPPT_ID || oOpportunity?.OpportunityId || "";
						oMatrix.OppStatusId = oOpportunity?.STATUS || oOpportunity?.Status || "";
						oMatrix.ExpectedEnd = oOpportunity?.EXPECT_END || oOpportunity?.ExpectedEnd || "";
						oMatrix.InternalOrder1 = oOpportunity?.INTERNAL_ORDER1 || oOpportunity?.InternalOrder1 || "";
						oMatrix.opportunityTeamData = oOpportunity?.PartiesInvolved?.results || oOpportunity?.opportunityTeamData || [];
						this.matrixController.restrictTimeEntryForClosedIO(oMatrix);
					}
					oMatrix.isMatrixEditable = false;
					// aExistingMatrixActvtData.push(oMatrix);
					aMatrixActvtData.push(oMatrix);
				}
			}
			matrixModel.setProperty("/matrixActivityData", aMatrixActvtData);
			matrixModel.refresh(true);
			// matrixModel.getProperty("/matrixActivityData", aExistingMatrixActvtData);
			// 	matrixModel.refresh();
		},

		//Function to create an Empty Matrix Data
		fnCreateEmptyMatrixEntry: function (dFirstdate, dLastdate, matrixEntry = null) {
			let entry = {};
			const generatedDates = this.fnGenerateDatesBucket(dFirstdate, dLastdate);
			let matrixModel = this.getModel("matrixModel");
			let selectedCategory = matrixModel.getProperty("/matrixCategory");
			entry.ncf = JSON.parse(JSON.stringify(generatedDates));
			if (selectedCategory === Actions.matrixCategory.activity) {
				entry.cf = JSON.parse(JSON.stringify(generatedDates));
			}
			if (matrixEntry) {
				Object.assign(entry, matrixEntry);
			}
			return this.fnCreateMartixClassBasedData([entry]);
		},

		//Function to create matrix class objects
		fnCreateMartixClassBasedData: function (aListItems) {
			try {
				let aMatrixData = [];
				let matrixModel = this.getModel("matrixModel");
				let selectedCategory = matrixModel.getProperty("/matrixCategory");
				for (let i = 0; i < aListItems.length; i++) {
					let tempEntries = [];
					let listItem = aListItems[i] || {};
					let oCFData = ("cf" in listItem) ? listItem.cf : false;
					let oNCFData = ("ncf" in listItem) ? listItem.ncf : false;
					let aDateRange = (oNCFData) ? Object.keys(oNCFData) : [];
					let matrixEntry = new Matrix(listItem);
					matrixEntry.selectedCategory = selectedCategory;
					if (oCFData && selectedCategory === Actions.matrixCategory.activity) {
						matrixEntry.customFacing = this.fnCreateFacingData(matrixEntry, oCFData, "CF");
						tempEntries = Object.values(matrixEntry.customFacing);
					}

					if (oNCFData) {
						matrixEntry.nonCustomFacing = this.fnCreateFacingData(matrixEntry, oNCFData, "NCF");
						tempEntries = tempEntries.concat(Object.values(matrixEntry.nonCustomFacing));
					}
					matrixEntry.Entries = tempEntries;
					if (selectedCategory === Actions.matrixCategory.learning) {
						matrixEntry.fnSetLearningConfig();
					}
					matrixEntry.isMatrixEditable = !matrixEntry.checkIsEntriesAvailable();
					matrixEntry.isValidForCheck = !matrixEntry.checkIsEntriesAvailable();

					//Set the date range for the current matrix Entry
					if (aDateRange.length) {
						matrixEntry.MatrixDateRange.fromDate = aDateRange[0];
						// matrixEntry.MatrixDateRange.toDate = aDateRange[aDateRange.length - 1];
						matrixEntry.MatrixDateRange.toDate = aDateRange.findLast(date => date);
					}

					aMatrixData.push(matrixEntry);
				}
				return aMatrixData;
			} catch (error) {
				console.log("ERROR IN fnCreateMartixClassBasedData : ", error);
			}
		},

		//Function to create customer facing & Non customer facing data
		fnCreateFacingData: function (matrixEntry = {}, oFacingData, type) {
			try {
				let oFacing = {};
				let count = 0;
				let matrixModel = this.getModel("matrixModel");
				let oSettingsModel = MTRModels.getMTRSettingsModel();
				let selectedCategory = matrixModel.getProperty("/matrixCategory");
				const learningCstCntrValue = oSettingsModel.getProperty("/CostCenter");
				for (let date in oFacingData) {
					let aEntry = oFacingData[date] || [];
					let key = `Date${count + 1}`;
					count += 1;
					if (aEntry.length) {
						let entry = aEntry[0];
						if (selectedCategory === Actions.matrixCategory.learning) {
							if (!entry.TaskId) {
								entry.TaskId = "10";
							}
						}
						oFacing[key] = aEntry[0];
					} else {
						const [day, month, year] = date.split('/');
						let dRecordDate = new Date(year, month - 1, day);
						let sRecordDate = this.genericDateFormat.format(dRecordDate);
						let oEntry = new Entry({
							TaskId: (selectedCategory === Actions.matrixCategory.activity) ? "3" : "10",
							ActvtId: ("ActvtId" in matrixEntry) ? matrixEntry.ActvtId : "",
							IsLegacy: ("IsLegacy" in matrixEntry) ? matrixEntry.IsLegacy : "",
							CostTypeId: ("CostTypeId" in matrixEntry) ? matrixEntry.CostTypeId : "",
							CostTypeValue: ("CostTypeValue" in matrixEntry) ? matrixEntry.CostTypeValue : "",
						});
						oEntry.WorkDuration = "";
						oEntry.setRecordDate(sRecordDate);
						if (type === "CF") {
							oEntry.CustomerFacing = true;
						} else {
							if (selectedCategory === Actions.matrixCategory.activity) {
								oEntry.TaskId = "4";
							}
							oEntry.CustomerFacing = false;
						}
						if (selectedCategory === Actions.matrixCategory.learning) {
							oEntry.TaskId = "10";
							oEntry.CostTypeId = "2";
							oEntry.CostTypeValue = learningCstCntrValue;
							oEntry.CustomerFacing = false;
						}
						oFacing[key] = oEntry;
					}
				}
				return oFacing;
			} catch (error) {
				console.log("ERROR IN fnCreateFacingData : ", error);
			}
		},

		//generate dates bucket based on firstday and lastday of the week
		fnGenerateDatesBucket: function (firstDay, lastDay) {
			const weekObject = {};
			const startDate = new Date(firstDay);
			const endDate = new Date(lastDay);
			while (startDate <= endDate) {
				const formattedDate = startDate.toLocaleDateString('en-GB');
				weekObject[formattedDate] = [];
				startDate.setDate(startDate.getDate() + 1);
			}
			return weekObject;
		},

		//Function to calculate the totalhours per matrix entry
		fnCalculateTotalHours: function (firstDate) {
			let count = 0;
			let oMatrixData = {};
			let matrixModel = this.getModel("matrixModel");
			const settingsModel = MTRModels.getMTRSettingsModel();
			let dayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			let oWeekDates = this.fnGetWeekFirstLastDates(firstDate);
			let aEntries = dayWeekTimesheetModel.getProperty("/Entries") || [];
			let selectedCategory = matrixModel.getProperty("/matrixCategory");

			let totalHours = {
				Date1: 0,
				Date2: 0,
				Date3: 0,
				Date4: 0,
				Date5: 0,
				Date6: 0,
				Date7: 0,
			};

			//Fitler out the entry date wise
			let oFormatterData = this.fnGetDateBasedEntries(firstDate);
			let aEntriesBasedOnDate = oFormatterData.aEntriesBasedOnDate;
			let oWeekDurationData = oFormatterData.oWeekDurationData;

			//Convert them to Date1.Date2..Keys
			for (let date in oWeekDurationData) {
				let aDate = oWeekDurationData[date] || [];
				let key = `Date${count + 1}`;
				if (aDate.length) {
					totalHours[key] = aDate[0].value;
				} else {
					totalHours[key] = 0;
				}
				count += 1;
			}

			matrixModel.setProperty("/totalHours", totalHours);
			matrixModel.setProperty("/totalHoursValidation", $.extend(true, {}, totalHours));
			matrixModel.refresh();
		},

		//Function to calculate SubTotalHours
		fnCalculateSubTotal: function (aMatrixData = []) {
			let subTotalHours = {
				Date1: 0,
				Date2: 0,
				Date3: 0,
				Date4: 0,
				Date5: 0,
				Date6: 0,
				Date7: 0,
			};
			let matrixModel = this.getModel("matrixModel");
			let selectedCategory = matrixModel.getProperty("/matrixCategory");

			for (let i = 0; i < aMatrixData.length; i++) {
				let oMatrix = aMatrixData[i];
				if ("customFacing" in oMatrix && Object.keys(oMatrix.customFacing).length) {
					subTotalHours = this.fnCalculateTotalHoursForEntry(oMatrix.customFacing, subTotalHours);
				}
				if ("nonCustomFacing" in oMatrix && Object.keys(oMatrix.nonCustomFacing).length) {
					subTotalHours = this.fnCalculateTotalHoursForEntry(oMatrix.nonCustomFacing, subTotalHours);
				}
			}
			matrixModel.setProperty("/subTotalHours", subTotalHours);
			matrixModel.refresh();
		},

		//Function to calculate total work duration for CF/NCF data
		fnCalculateTotalHoursForEntry: function (facingData, totalHours) {
			for (let day in facingData) {
				const entry = facingData[day];
				let value = (entry.WorkDuration) ? parseFloat(entry.WorkDuration) : 0;
				if (totalHours[day]) {
					let currentValue = parseFloat(totalHours[day]);
					value = isNaN(value) ? 0 : value;
					totalHours[day] = currentValue + value;
				} else {
					totalHours[day] = isNaN(value) ? 0 : value;
				}
			}
			return totalHours;
		},

		//Function to update Expected Hours
		updateExpectedDailyBar: async function (firstDate, aMatrixData = []) {
			let oMatrixEntry = aMatrixData[0];
			let oWeekDates = this.fnGetWeekFirstLastDates(firstDate);
			if (!oMatrixEntry) {
				let oNewEntry = this.fnCreateEntryObject();
				oMatrixEntry = this.fnCreateEmptyMatrixEntry(oWeekDates.dFirstdate, oWeekDates.dLastdate, oNewEntry)[0];
			}
			let matrixModel = this.getModel("matrixModel");
			const oTargetModel = MTRModels.getTargetModel();
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			let oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const oMTRSettings = oMatrix.getMTRSettingData();
			// let oWeekDates = this.fnGetWeekFirstLastDates(firstDate);
			let aEntries = oDayWeekTimesheetModel.getProperty("/Entries") || [];
			let selectedCategory = matrixModel.getProperty("/matrixCategory");
			firstDate = (firstDate) ? firstDate : oWeekDates.dFirstdate;
			let sRecordDate = this.genericDateFormat.format(new Date(firstDate))

			const timeMatrics = oSettingsModel.getProperty("/TimeMatrics");
			const weekStartDay = oSettingsModel.getProperty("/WeekStartDay");
			const targetHours = oTargetModel.getProperty("/TargetHours") || [];
			const oTargetHour = targetHours.find(function (item) {
				return item.Date === sRecordDate;
			}) || false;

			//Fitler out the entry date wise
			let oFormatterData = this.fnGetDateBasedEntries(firstDate) || {};
			let oWeekDurationData = oFormatterData.oWeekDurationData;
			let aEntriesBasedOnDate = oFormatterData.aEntriesBasedOnDate;

			let expectedTime = 0;
			let savedTime = 0;
			let submittedTime = 0;

			//Calcuate the Saved and Submitted entries
			for (let j = 0; j < aEntriesBasedOnDate.length; j++) {
				let entry = aEntriesBasedOnDate[j];
				let duration = parseFloat(entry.WorkDuration);
				if (isNaN(duration)) {
					duration = 0;
				}
				if (entry.DataFrom === "L") {
					savedTime += duration;
				}
				if (entry.DataFrom === "I") {
					submittedTime += duration;
				}
			}

			//Calculate Total Expected Count
			let oFacingData = oMatrixEntry ? oMatrixEntry.nonCustomFacing : {};
			for (let date in oFacingData) {
				let entry = oFacingData[date];
				// let sRecordDate = this.genericDateFormat.format(new Date())
				let sRecordDate = oMatrix.dateService.formatStringDate(entry.RecordDate);
				let expected = parseFloat(entry.Expected);
				expected = isNaN(expected) ? 0 : expected;
				if (expected) {
					expectedTime += expected;
				}
			}

			matrixModel.setProperty("/Expected", expectedTime);
			matrixModel.setProperty("/Saved", savedTime);
			matrixModel.setProperty("/Submitted", submittedTime);
			matrixModel.refresh();
		},

		//Function to get filter Date Based Entries
		fnGetDateBasedEntries: function (firstDate) {
			let matrixModel = this.getModel("matrixModel");
			const settingsModel = MTRModels.getMTRSettingsModel();
			let dayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			let oWeekDates = this.fnGetWeekFirstLastDates(firstDate);
			let aEntries = dayWeekTimesheetModel.getProperty("/Entries") || [];
			const aValidActivityTaskId = matrixModel.getProperty("/aValidActivityTaskId") || [];
			const aValidLearningTaskId = matrixModel.getProperty("/aValidLearningTaskId") || [];
			//Weeks
			const generatedDates = this.fnGenerateDatesBucket(oWeekDates.dFirstdate, oWeekDates.dLastdate);
			let oWeekData = JSON.parse(JSON.stringify(generatedDates));

			//Fitler out the entry date wise
			let aEntriesBasedOnDate = aEntries.filter((entry) => {
				let taskId = (entry.TaskId) ? parseInt(entry.TaskId) : 0;
				let entryDate = this.dateService.formatStringDate(entry.RecordDate);
				let validEntry = this.checkEntryBetweenDateRange(entryDate, oWeekDates)
				if (validEntry) {
					return entry;
				}
			});

			//Segregate Week date wise
			for (let i = 0; i < aEntriesBasedOnDate.length; i++) {
				let oTotalDuration = {
					value: 0
				};

				let entry = aEntriesBasedOnDate[i];
				let entryDate = this.dateService.formatStringDate(entry.RecordDate);
				let workDurationValue = (entry.WorkDuration && (entry.DataFrom === "L" || entry.DataFrom === "I")) ? parseFloat(entry.WorkDuration) :
					0;
				let dateKey = ("RecordDate" in entry) ? new Date(entryDate).toLocaleDateString("en-GB") : "";
				let aWeekDate = oWeekData[dateKey];
				if (aWeekDate && !aWeekDate.length) {
					oTotalDuration.value = isNaN(workDurationValue) ? 0 : workDurationValue;
					oWeekData[dateKey].push(oTotalDuration);
				} else {
					let currentValue = parseFloat(aWeekDate[0].value);
					workDurationValue = isNaN(workDurationValue) ? 0 : workDurationValue;
					oWeekData[dateKey][0].value = currentValue + workDurationValue;
				}
			}

			return {
				aEntriesBasedOnDate: aEntriesBasedOnDate || [],
				oWeekDurationData: oWeekData || {}
			};
		},

		//Function to validation date for submit
		validateDateForSubmit: function (entryStartDate) {
			const currentDate = new Date();
			const entryDate = new Date(entryStartDate);
			entryDate.setHours(0, 0, 0);
			let validTill;
			if (entryDate < currentDate) {
				validTill = new Date(currentDate);
			} else {
				validTill = new Date(entryDate);
			}
			validTill.setDate(validTill.getDate() + 6);
			validTill.setHours(0, 0, 0);

			if (entryDate > validTill) {
				return false;
			} else {
				return true;
			}
		},

		/**
		 * @author 
		 * @function checkAndUpdateDraftsToMatrix
		 * @description function to check if the draft belongs to active current calendar week
		 */
		checkAndUpdateDraftsToMatrix: function (oWeekDates) {
			const currentDate = new Date();
			const matrixModel = this.getModel("matrixModel");
			const aMatrixDrafts = matrixModel.getProperty("/aMatrixDrafts") || [];
			const aMatrixActivityData = matrixModel.getProperty("/matrixActivityData") || [];
			const oCurrentWeekData = this.fnGetWeekFirstLastDates(currentDate);
			if (!aMatrixDrafts.length) {
				return;
			}

			for (let i = 0; i < aMatrixDrafts.length; i++) {
				let matrixEntry = aMatrixDrafts[i];
				let matrixFromDate = matrixEntry.MatrixDateRange.fromDate || false;
				if (!matrixFromDate) {
					continue;
				}
				const [day, month, year] = matrixFromDate.split('/');
				let matrixWkFstDate = new Date(year, month - 1, day);
				matrixWkFstDate = this.dateService.format(matrixWkFstDate, "yMMdd");
				const calfirstWkDate = this.dateService.format(oWeekDates.dFirstdate, "yMMdd");
				const currfirstWkDate = this.dateService.format(oCurrentWeekData.dFirstdate, "yMMdd");
				const iMatrixPrstAt = aMatrixActivityData.findIndex(matEntry => matEntry.ActvtId ===
					matrixEntry.ActvtId);
				if (currfirstWkDate === calfirstWkDate && calfirstWkDate === matrixWkFstDate && iMatrixPrstAt === -1) {
					aMatrixActivityData.push(matrixEntry);
				}
			}
			matrixModel.refresh();
		},
		// Function to sort activities base on Account ,Opp nad No Association (git-193).
		fnSortData: function () {
			// const matrixModel = this.getModel("matrixModel");

			// let aMatrixActvtData = matrixModel.getProperty("/matrixActivityData") || [];
			// aMatrixActvtData.sort((a, b) => {
			// 	const associationIdA = parseInt(a.ActAsstId, 10);
			// 	const associationIdB = parseInt(b.ActAsstId, 10);
			// 	if (associationIdA !== associationIdB) {
			// 		return associationIdA - associationIdB;
			// 	}
			// 	switch (a.ActAsstId) {
			// 		case "501":
			// 			{
			// 				const numA = parseInt(a.CostTypeValue, 10);
			// 				const numB = parseInt(b.CostTypeValue, 10);
			// 				if (numA !== numB) return numA - numB;
			// 				const actvtIdA = parseInt(a.ActvtId, 10) || 9999999;
			// 				const actvtIdB = parseInt(b.ActvtId, 10) || 9999999;
			// 				return actvtIdA - actvtIdB

			// 			}
			// 		case "502":
			// 			{
			// 				const numA = parseInt(a.selectedAstOpportunityValue, 10);
			// 				const numB = parseInt(b.selectedAstOpportunityValue, 10);
			// 				if (numA !== numB) return numA - numB;

			// 				const actvtIdA = parseInt(a.ActvtId, 10) || 9999999;
			// 				const actvtIdB = parseInt(b.ActvtId, 10) || 9999999;
			// 				return actvtIdA - actvtIdB

			// 			}
			// 		case "503":
			// 			{
			// 				const title = a.activityRegistration.ActivitySetName.localeCompare(b.activityRegistration.ActivitySetName);
			// 				if (title !== 0) {
			// 					return title;
			// 				}
			// 				const actvtIdA = parseInt(a.ActvtId, 10) || 9999999;
			// 				const actvtIdB = parseInt(b.ActvtId, 10) || 9999999;
			// 				return actvtIdA - actvtIdB

			// 			}
			// 		default:
			// 			return 0;
			// 	}

			// 	const actvtIdA = parseInt(a.ActvtId, 10) || 9999999;
			// 	const actvtIdB = parseInt(b.ActvtId, 10) || 9999999;
			// 	return actvtIdA - actvtIdB
			// });
			// matrixModel.setProperty("/matrixActivityData", aMatrixActvtData);

			// matrixModel.refresh();
		}

		//********************************************* MATRIX TIME ENTRY DIALOG STARTS HERE**************************************************

		//********************************************* MATRIX TIME ENTRY DIALOG END HERE**************************************************

	};

	const matrixTimeController = Controller.extend("com.melody.lib.mtr.marix.Matrix", {
		formatter: formatter,
		constructor: function (controlRef) {
			this.DurationLimit = {};
			this.parentControl = controlRef;
			this.oFormatYyyymmdd = DateFormat.getInstance({
				pattern: "MMM-dd",
				calendarType: CalendarType.Gregorian
			});
		},


		onLoadMoreData: function (oEvent) {
			const matrixModel = this.getModel("matrixModel");
			let changedCalendarDate = matrixModel.getProperty("/changedCalendarDate") || null;
			this.parentControl.seperateEntriesBasedOnDate(changedCalendarDate);
		},

		getModel: function (name) {
			let model = MTRModels.getMatrixModel();
			return model;
		},

		//function to get element from fragment using id
		fnGetDialogUsingId: function (dialogId, contentId) {
			return sap.ui.core.Fragment.byId(dialogId, contentId);
		},

		/**
		 * @author DARSHAN
		 * @function onPressRegistration
		 * @description function to handle registration button press event
		 * @param {Object} oEvent
		 */
		onPressRegistration: function (oEvent, contextPath, bIsEditRegistrtaion) {
			try {
				let validData = true;
				let matrixModel = this.getModel("matrixModel");
				if (!contextPath) {
					let currentMatrixContext = oEvent.getSource().getBindingContext("matrixModel") ||
						false;
					if (!currentMatrixContext) {
						return;
					}

					contextPath = currentMatrixContext.getPath();
				}

				let matrixEntry = matrixModel.getProperty(contextPath);
				let registration = matrixModel.getProperty(`${contextPath}/activityRegistration`) || {};
				let selectedActivityTypeObject = matrixModel.getProperty(`${contextPath}/selectedActivityTypeData`) || {};
				let actionMode = ("activityMode" in matrixEntry && matrixEntry.activityMode === Actions.ActivityMode.newActivity) ? "CREATE" :
					"EDIT";

				let oSelectedOpportunityData = ("opportunityData" in matrixEntry) ? matrixEntry.opportunityData : false;
				let oSelectedAccountData = ("accountData" in matrixEntry) ? matrixEntry.accountData : false;

				let changedCalendarDate = matrixModel.getProperty("/changedCalendarDate");
				let oWeekDates = oMatrix.fnGetWeekFirstLastDates(changedCalendarDate);

				switch (matrixEntry.ActAsstId) {
					case "501": //Account
						let accountData = [];
						if (oSelectedAccountData && oSelectedAccountData.AccountId && Object.keys(oSelectedAccountData).length) {
							let account = {
								iss: oSelectedAccountData.ISS,
								iac: oSelectedAccountData.IAC,
								accountname: oSelectedAccountData.AccountName,
								accountid: oSelectedAccountData.AccountId,
							};
							accountData.push(account);
							registration.GlobalUltimateID = oSelectedAccountData.AccountId;
							registration.to_AAccnt = accountData;
						} else {
							validData = false;
							registration.GlobalUltimateID = "";
							registration.to_AAccnt = accountData;
						}
						registration.OpportunityId = "";
						registration.OpportunityNumber = "";
						registration.to_AOpportunity = [];
						break;
					case "502": //Opportunity
						let opportunityData = [];
						if (oSelectedOpportunityData && oSelectedOpportunityData.OpportunityId && Object.keys(oSelectedOpportunityData).length) {
							let opportunity = {
								"accountid": oSelectedOpportunityData.AccountId,
								"description": oSelectedOpportunityData.Description,
								"ACCOUNT_NAME": oSelectedOpportunityData.AccountName,
								"OPPT_ID": oSelectedOpportunityData.OpportunityId,
								"mastercodeid": oSelectedOpportunityData.Industry_MasterCode,
								"PHASE_DESC": ("PhaseValue" in oSelectedOpportunityData) ? oSelectedOpportunityData.PhaseValue : "",
								"Status": oSelectedOpportunityData.Status,
								"StatusDescription": oSelectedOpportunityData.StatusDescription,
								"SelectedOpportunity": oSelectedOpportunityData
							};
							registration.OpportunityNumber = oSelectedOpportunityData.OpportunityId;
							registration.OpportunityId = oSelectedOpportunityData.OpportunityId;
							registration.GlobalUltimateID = oSelectedOpportunityData.AccountId;
							opportunityData.push(opportunity);
							registration.to_AOpportunity = opportunityData;
						} else {
							validData = false;
							registration.OpportunityId = "";
							registration.OpportunityNumber = "";
							registration.GlobalUltimateID = "";
							registration.to_AOpportunity = opportunityData;
						}
						registration.to_AAccnt = [];
						// let RestrictTimeBooking = matrixModel.getProperty("/RestrictTimeBooking");
						if (!bIsEditRegistrtaion) {
							this.restrictTimeEntryForClosedIO({}, oSelectedOpportunityData, oEvent, oWeekDates);
						}
						break;
					case "503": //No Association
						break;
					default:
				}

				//Create Or Update the Activity Registration Payload
				this.handleActivityRegistration(actionMode, {
					registration: registration,
					currentMatrixContextPath: contextPath,
					activityType: selectedActivityTypeObject,
					activityNoAssociationData: {}
				});

				if (actionMode === "CREATE" && !validData) {
					MessageToast.show("Please select the Account/Opportunity Value and try again.");
					return;
				}
				const bProceedForRR = matrixModel.getProperty("/ProceedForRR");
				if (bIsEditRegistrtaion || (matrixEntry.ActAsstId !== "502" || bProceedForRR)) {
					oEvent.getSource().fnOpenRapidRegDialog(oEvent, oWeekDates);
				}
			} catch (error) {
				console.log("ERROR IN onPressRegistration : ", error)
			}
		},

		//checks if selected opp has closed IO and restrict time booking
		restrictTimeEntryForClosedIO: function (oMatrix, oSelectedOpp, oEvent, oWeekDates) {
			var that = this;
			let sRestrictErrorMessage = '';
			let matrixModel = this.getModel("matrixModel");
			let i18nModel = new ResourceModel({
				bundleName: "com.melody.lib.i18n.i18n"
			});
			const rb = i18nModel.getResourceBundle();

			let oUserModel = sap.ui.getCore().getModel("userUtility");
			if (Object.keys(oMatrix).length) {
				oSelectedOpp = {
					OpportunityId: oMatrix.OpportunityID,
					Status: oMatrix.OppStatusId,
					ExpectedEnd: oMatrix.ExpectedEnd,
					InternalOrder1: oMatrix.InternalOrder1,
					opportunityTeamData: oMatrix.opportunityTeamData
				};
			}
			// var oUserModel = this.getOwnerComponent().getModel("user");
			var sIoSettingFlag = oUserModel.getProperty("/UpdateIOArtes");
			var sOppId = "OPPT_ID" in oSelectedOpp ? oSelectedOpp.OPPT_ID : oSelectedOpp.OpportunityId;
			var sOppStatus = "STATUS" in oSelectedOpp ? oSelectedOpp.STATUS : oSelectedOpp.Status;
			var sOppCloseDate = "EXPECT_END" in oSelectedOpp ? oSelectedOpp.EXPECT_END : oSelectedOpp.ExpectedEnd;
			var sOppIO = "INTERNAL_ORDER1" in oSelectedOpp ? oSelectedOpp.INTERNAL_ORDER1 : oSelectedOpp.InternalOrder1;
			const sStatusText = i18nModel.getProperty("opp.status." + sOppStatus) || sOppStatus || "Unknown";
			// disc - E0002, won- E0003, booked-E0004, lost-E0005
			var aOppStatus = ["E0002", "E0004", "E0005"];
			var bRestrictTimeEntry = false;
			var bPartOfVatTeam = this.checkLoggedUserInVatTeam(oSelectedOpp.opportunityTeamData);
			// var bPartOfVatTeam = this.masterDataModel.getProperty("/isUserPartOfVatTeam");
			var bIoOpen = true;
			var bProceedForRR = true;
			var bRestrictVATTeamSave = false;
			if (aOppStatus.indexOf(sOppStatus) !== -1) {
				// sOppIO = true; // remove this
				// sIoSettingFlag = "1" // remove this
				bRestrictVATTeamSave = true;
				if (sOppIO) {
					const dOppCloseDate = new Date(sOppCloseDate);
					const dCurrentDate = new Date();
					const timeDiff = dCurrentDate.getTime() - dOppCloseDate.getTime();
					const dayDiff = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
					bIoOpen = (dayDiff < 90) ? true : false;
				}
				if (bPartOfVatTeam && sIoSettingFlag === "1") {
					if (!bIoOpen) { //IO closed case
						//Warning message when IO is closed
						bRestrictTimeEntry = true;
						oMatrix.sErrorMessageText= rb.getText("error.closedIoMsg", [
							sOppId,
							sStatusText,
							sOppIO
						]);

						sRestrictErrorMessage = rb.getText("error.closedIoMsgDesc", [
							sOppId,
							sStatusText,
							sOppIO
						]);

						oMatrix.TicketLinkHref = rb.getText("ticketURL");

						bProceedForRR = false;
						if (oEvent) {
							const oTxt = i18nModel.getProperty("closedIoWarningTxt");
							sap.m.MessageBox.warning(oTxt, {
								actions: ["Continue", "Change Opp"],
								emphasizedAction: "Continue",
								onClose: function (action) {
									if (action === "Continue") { //continue to registration
										bProceedForRR = true;
										oEvent.getSource().fnOpenRapidRegDialog(oEvent, oWeekDates);
									} else if (action === "Change Opp") {
										bProceedForRR = false;
										return;
									}
								}
							});
						}
					}
				} else if (bPartOfVatTeam && sIoSettingFlag === "2") {
					bRestrictTimeEntry = false; //user can book time

				} else if (!bPartOfVatTeam && sIoSettingFlag === "1") {
					oMatrix.sErrorMessageText= rb.getText("error.notPartOfOpp",[sOppId]);
					sRestrictErrorMessage = rb.getText("error.notPartOfOppDesc", [sOppId]);
					oMatrix.TicketLinkHref = rb.getText("ticketURL");					
					bRestrictVATTeamSave = true;
					bRestrictTimeEntry = true;
					bRestrictTimeEntry = true; //user can't book time

				} else if (!bPartOfVatTeam && sIoSettingFlag === "2") {
					oMatrix.sErrorMessageText= rb.getText("error.notPartOfOpp",[sOppId]);
					sRestrictErrorMessage = rb.getText("error.notPartOfOppDesc", [sOppId]);
					oMatrix.TicketLinkHref = rb.getText("ticketURL");	
					bRestrictVATTeamSave = true;
					bRestrictTimeEntry = true;
					bRestrictTimeEntry = true;

				}
			} else {
				if (!sOppId || !sOppStatus) {
					var sOppIdForMsg = sOppId || oMatrix.CostTypeValue || "";
        		    oMatrix.sErrorMessageText= rb.getText("error.noAccessOpp");
					sRestrictErrorMessage = rb.getText("error.noAccessOppDesc", [
						sOppIdForMsg
					]);
					oMatrix.TicketLinkHref = rb.getText("ticketURL");
					bRestrictVATTeamSave = true;
					bRestrictTimeEntry = true;
				}
			}
			if (Object.keys(oMatrix).length) {
				oMatrix.RestrictTimeBooking = bRestrictTimeEntry;
				oMatrix.sMsg = sRestrictErrorMessage;
			}
			matrixModel.setProperty("/RestrictVATTeamSave", bRestrictVATTeamSave);
			matrixModel.setProperty("/ProceedForRR", bProceedForRR);
			matrixModel.setProperty("/RestrictTimeBooking", bRestrictTimeEntry);
			matrixModel.refresh();
		},

		checkLoggedUserInVatTeam: function (aOppTeam = []) {
			let oUser = sap.ui.getCore().getModel("userUtility").getData();
			var oVatTeamUser = aOppTeam.find(function (opp) {
				const sOppUserId = opp.USER_ID || opp.ID;
				return oUser.UserId === sOppUserId && oUser.UserEmail === opp.EMAIL;
			});
			return oVatTeamUser ? true : false;
		},

		/**
		 * @author DARSHAN
		 * @function onCloseMatrixTimeRecordingDialog
		 * @description function to close matrix time entry dialog
		 * @param {Object} event
		 */
		onCloseMatrixTimeRecordingDialog: function (event) {
			let matrixModel = this.getModel("matrixModel");
			if (this.parentControl.matrixTimeRecordingDialog) {
				this.parentControl.matrixTimeRecordingDialog.close();
				this.parentControl.matrixTimeRecordingDialog.destroy();
				this.parentControl.matrixTimeRecordingDialog = null;
			}

			//In Order to fire and trigger an event from the dialog to application ex:(Activity-Form)
			if (oMatrix.oParentCtrl && typeof (oMatrix.oParentCtrl.fnTriggerUpdateEntries) === "function") {
				oMatrix.oParentCtrl.fnTriggerUpdateEntries();
			}

			matrixModel.getProperty("/defaultEntry", {
				"isMatrixEditList": false,
				"taskId": "",
				"activeTab": Actions.matrixCategory.activity,
				"activityId": "",
				"startDate": new Date(),
				"costTypeId": "",
				"costTypeValue": ""
			})
			matrixModel.setProperty("/changedCalendarDate", null);
			matrixModel.setProperty("/aMatrixDrafts", []);
			matrixModel.setProperty("/aSortColumns", [{
				key: "AccountName",
				text: "Account",
				selected: false
			}, {
				key: "OpportunityName",
				text: "Opportunity",
				selected: false
			}]);
			matrixModel.refresh();
		},

		/**
		 * @author DARSHAN
		 * @function onAfterMatrixDialogClose
		 * @description function to handle onAfter close matrix time entry dialog
		 * @param {Object} event
		 */
		onAfterMatrixDialogClose: function (event) {
			let matrixModel = this.getModel("matrixModel");
			if (this.parentControl.matrixTimeRecordingDialog) {
				this.parentControl.matrixTimeRecordingDialog.close();
				this.parentControl.matrixTimeRecordingDialog.destroy();
				this.parentControl.matrixTimeRecordingDialog = null;
			}
			matrixModel.getProperty("/defaultEntry", {
				"isMatrixEditList": false,
				"taskId": "",
				"activeTab": Actions.matrixCategory.activity,
				"activityId": "",
				"startDate": new Date(),
				"costTypeId": "",
				"costTypeValue": ""
			})
			matrixModel.setProperty("/changedCalendarDate", null);
			matrixModel.refresh();
		},

		/**
		 * @author DARSHAN, SIDDHART
		 * @function openDeleteMatrixEntryDialog
		 * @description function to open delete time entry dialog
		 * @param {Object} event
		 */
		openDeleteMatrixEntryDialog: async function (event) {
			let id = "_MatrixTimeRecordingDeleteDialog";
			let source = event.getSource().getParent();
			const matrixModel = this.getModel("matrixModel");
			let i18nModel = new ResourceModel({
				bundleName: "com.melody.lib.i18n.i18n"
			});
			const bindingContext = event.getSource().getBindingContext("matrixModel") || {};
			this.matrixPath = bindingContext.getPath() || "";
			const that = this;
			const matrixEntry = bindingContext.getObject();
			matrixEntry.Entries = this.fnCreateEntriesForNotesAndDelete(matrixEntry);
			let selectedCategory = matrixModel.getProperty("/matrixCategory");
			const aEntryWithWorkDuration = matrixEntry.Entries.filter(item => item.WorkDuration.trim() !== "");
			if (!aEntryWithWorkDuration.length) {
				const bCompact = true;
				MessageBox.confirm(
					"This action will delete the selected row from this application.", {
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					onClose: async (sAction) => {
						if (sAction === sap.m.MessageBox.Action.OK) {
							this.parentControl.batchIndex = 0;

							this.parentControl.matrixResponse = [];
							let aMatrixData = [];
							if (selectedCategory === Actions.matrixCategory.learning) {
								aMatrixData = $.extend(true, [], matrixModel.getProperty("/matrixLearningData"));
							} else {
								aMatrixData = $.extend(true, [], matrixModel.getProperty("/matrixActivityData"));
							}
							const length = this.matrixPath.split("/").length;
							const index = this.matrixPath.split("/")[length - 1];
							aMatrixData.splice(index, 1);
							//When NO Records available
							if (!aMatrixData.length) {
								aMatrixData = await oMatrix.seperateEntriesBasedOnDate(null, true)
							}
							if (selectedCategory === Actions.matrixCategory.learning) {
								matrixModel.setProperty("/matrixLearningData", []);
								matrixModel.setProperty("/matrixLearningData", aMatrixData);
							} else {
								this.fnInsertDataUsingBatch(aMatrixData);
							}
							matrixModel.refresh();
						}
					}
				});
				return;
			}

			if (this.matrixTimeRecordingDeleteDialog) {
				this.matrixTimeRecordingDeleteDialog.destroy();
				this.matrixTimeRecordingDeleteDialog = null;
			}

			if (!this.matrixTimeRecordingDeleteDialog) {
				this.matrixTimeRecordingDeleteDialog = Fragment.load({
					id: id,
					name: "com.melody.lib.fragments.MTR.Matrix.Actions.DeleteEntries",
					controller: this
				}).then((dialog) => {
					source.addDependent(dialog);
					let oMatrixEntryModel = new JSONModel(matrixEntry);
					dialog.setModel(oMatrixEntryModel);
					dialog.getModel().setProperty("/IsTableBusy", false);
					dialog.setModel(matrixModel, "matrixModel");
					dialog.setModel(i18nModel, "i18n");
					dialog.open();
					this.matrixTimeRecordingDeleteDialog = dialog;
					return dialog;
				});
			} else {
				this.matrixTimeRecordingDeleteDialog.open();
			}
		},

		/**
		 * @author SIDDHARTH
		 * @function onSelectEntriesToDelete
		 * @description function to select the entries which needs to be deployed
		 * @param {Object} event
		 */
		onSelectEntriesToDelete: function (event) {
			const oSource = event.getSource();
			let selectedContexts = oSource.getSelectedContexts();
			const matrixModel = this.getModel("matrixModel");
			matrixModel.setProperty("/TempDeleteEntrieFromMatrix", selectedContexts);
			// 
		},

		/**
		 * @author SIDDHARTH
		 * @function onDeleteMatrixEntries
		 * @description function to handle delete entries
		 * @param {Object} event
		 */
		onDeleteMatrixEntries: function () {
			const that = this;
			const matrixModel = this.getModel("matrixModel");
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const oDialog = this.matrixTimeRecordingDeleteDialog;
			const dialogModel = oDialog.getModel();
			const oResourceBundle = oDialog.getModel("i18n").getResourceBundle();
			let oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			let aEntries = oDayWeekTimesheetModel.getProperty("/Entries") || [];
			const selectedContexts = matrixModel.getProperty("/TempDeleteEntrieFromMatrix");
			const iWeekStartDay = oSettingsModel.getProperty("/WeekStartDay");
			let selectedCategory = matrixModel.getProperty("/matrixCategory");
			let dStartDate = DateService.getInstance().getStartDateOfWeek(new Date(), iWeekStartDay);
			const bCompact = true;
			let ispEntries = [];
			for (let k = 0; k < selectedContexts.length; k++) {
				let sEntryPath = selectedContexts[k].getPath();
				let oSelectedEntry = dialogModel.getProperty(sEntryPath);
				if (oSelectedEntry && oSelectedEntry.DataFrom === "I") {
					ispEntries.push(oSelectedEntry);
				}
			}
			let confirmationMsg;
			if (ispEntries.length > 0) {
				confirmationMsg = oResourceBundle.getText("ispConfirmDeleteMsg");
			} else {
				confirmationMsg = oResourceBundle.getText("lsConfirmDeleteMsg");
			}
			if (selectedContexts.length > 0) {
				MessageBox.confirm(
					confirmationMsg, {
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					onClose: (sAction) => {
						if (sAction === sap.m.MessageBox.Action.OK) {
							this.onDeleteConFirm(selectedContexts, aEntries, {
								selectedCategory: selectedCategory
							});
							// oSelectedEntriesTable.removeSelections();
						}
					}
				});
			}
		},

		/**
		 * @author SIDDHARTH
		 * @function onDeleteConFirm
		 * @description function to handle ok button of delete entries
		 * @param {Object} event
		 */
		onDeleteConFirm: async function (selectedContexts, aEntries, options) {

			const oDialog = this.matrixTimeRecordingDeleteDialog;
			const dialogModel = oDialog.getModel();
			try {
				this.parentControl.batchIndex = 0;

				this.parentControl.matrixResponse = [];
				dialogModel.setProperty("/IsTableBusy", true);
				let bRefreshData = false;
				let savedEntries = [],
					submittedEntries = [],
					pendingEntries = [];
				const oResourceBundle = oDialog.getModel("i18n").getResourceBundle();
				const matrixModel = this.getModel("matrixModel");
				const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				for (let i = 0; i < selectedContexts.length; i++) {
					const sPath = selectedContexts[i].getPath();
					const oEntry = selectedContexts[i].getObject();
					let entry = aEntries.find(item => item.MtrUid === oEntry.MtrUid);
					if (entry.DataFrom !== "") {
						entry.Indicator = "D";
						entry.Busy = true;
						if (entry.DataFrom === "L") {
							entry.Indicator = "D";
							savedEntries.push(entry);
						} else if (entry.DataFrom === "I") {
							entry.Indicator = "D";
							submittedEntries.push(entry);
						}
					} else {
						pendingEntries.push(entry);
					}
					// entry.WorkDuration = "";
				}

				if (savedEntries.length) {
					await MTRUtil.deleteSavedEntries(savedEntries);
					oDayWeekTimesheetModel.refresh(true);
					bRefreshData = true;
					MessageToast.show(oResourceBundle.getText("deleteEntriesSuccessMsg"));
				}
				if (submittedEntries.length) {
					await MTRUtil.deleteSubmittedEntries(submittedEntries);
					oDayWeekTimesheetModel.refresh(true);
					bRefreshData = true;
				}
				if (bRefreshData || pendingEntries.length) {

					if (pendingEntries.length) {
						for (let i = 0; i < pendingEntries.length; i++) {
							let entry = pendingEntries[i];
							let sMtrUid = entry.MtrUid;
							let index = aEntries.findIndex((item) => item.MtrUid === sMtrUid);
							if (index !== -1) {
								aEntries.splice(index, 1);
							}
						}
						oDayWeekTimesheetModel.setProperty("/Entries", aEntries);
						oDayWeekTimesheetModel.refresh(true);
					}

					let changedCalendarDate = matrixModel.getProperty("/changedCalendarDate");
					oMatrix.seperateEntriesBasedOnDate(changedCalendarDate, false).then((aMatrixData) => {
						oMatrix.fnUpdateTotalHours(changedCalendarDate, aMatrixData);
						if (options.selectedCategory === Actions.matrixCategory.activity) {
							matrixModel.setProperty("/matrixActivityData", aMatrixData);
						} else {
							matrixModel.setProperty("/matrixLearningData", aMatrixData);
						}
						matrixModel.setProperty("/MatrixListDialogBusy", false);
						matrixModel.refresh();
					});
					this.onCloseMatrixDeleteEntriesDialog();
				}
				dialogModel.setProperty("/IsTableBusy", false);
			} catch {
				dialogModel.setProperty("/IsTableBusy", false);
			}
		},

		/**
		 * @author DARSHAN
		 * @function onCloseMatrixDeleteEntriesDialog
		 * @description function to close delete entries notes to entries dialog
		 * @param {Object} event
		 */
		onCloseMatrixDeleteEntriesDialog: function (event) {
			const matrixModel = this.getModel("matrixModel");
			if (this.matrixTimeRecordingDeleteDialog) {
				matrixModel.setProperty("/TempDeleteEntrieFromMatrix", []);
				this.matrixTimeRecordingDeleteDialog.close();
				matrixModel.refresh();
			}
		},

		/**
		 * @author DARSHAN
		 * @function onAfterCloseAddNoteDialog
		 * @description function to handle after close delete entries notes to entries dialog
		 * @param {Object} event
		 */
		onAfterCloseDeleteEntriesDialog: function (event) {
			if (this.matrixTimeRecordingDeleteDialog) {
				this.matrixTimeRecordingDeleteDialog.destroy();
				this.matrixTimeRecordingDeleteDialog = null;
			}
		},

		/**
		 * @author DARSHAN
		 * @function fnCreateEntriesForNotesAndDelete
		 * @description function to open add notes to entries dialog
		 * @param {Object} event
		 */
		fnCreateEntriesForNotesAndDelete: function (matrixEntry) {
			let aNoteEntries = [];
			//Formation of Entries Array for Notes
			if (matrixEntry.customFacing && Object.keys(matrixEntry.customFacing).length) {
				aNoteEntries = aNoteEntries.concat(Object.values(matrixEntry.customFacing));
			}
			if (matrixEntry.nonCustomFacing && Object.keys(matrixEntry.nonCustomFacing).length) {
				aNoteEntries = aNoteEntries.concat(Object.values(matrixEntry.nonCustomFacing));
			}
			if (aNoteEntries.length) {
				aNoteEntries = aNoteEntries.filter((entry) => entry.WorkDuration);
				if (aNoteEntries && aNoteEntries.length) {
					aNoteEntries.map(function (element) {
						element.PreviousNote = JSON.parse(JSON.stringify(element.Note));
					});
				}
			}
			return aNoteEntries;
		},

		/**
		 * @author DARSHAN
		 * @function openRegisterNotesMatrixEntry
		 * @description function to open add notes to entries dialog
		 * @param {Object} event
		 */
		openRegisterNotesMatrixEntry: function (event) {
			let id = "_MatrixTimeRecordingNotesDialog";
			let source = event.getSource().getParent();
			const matrixModel = this.getModel("matrixModel");
			let i18nModel = new ResourceModel({
				bundleName: "com.melody.lib.i18n.i18n"
			});
			const bindingContext = event.getSource().getBindingContext("matrixModel") || {};
			this.matrixPath = bindingContext.getPath() || "";
			const that = this;
			const matrixEntry = bindingContext.getObject();

			matrixEntry.Entries = this.fnCreateEntriesForNotesAndDelete(matrixEntry);

			if (!this.matrixTimeRecordingNotesDialog) {
				this.matrixTimeRecordingNotesDialog = Fragment.load({
					id: id,
					name: "com.melody.lib.fragments.MTR.Matrix.Actions.AddNotes",
					controller: this
				}).then((dialog) => {
					source.addDependent(dialog);
					let oMatrixEntryModel = new JSONModel(matrixEntry);
					dialog.setModel(oMatrixEntryModel);
					dialog.setModel(matrixModel, "matrixModel");
					dialog.setModel(i18nModel, "i18n");
					this.matrixTimeRecordingNotesDialog = dialog;
					dialog.open();
					return dialog;
				});
			} else {
				this.matrixTimeRecordingNotesDialog.open();
			}
		},

		handleISPMessagePopoverPress: function (oEvent) {
			var oModel;
			var oControl = oEvent.getSource();
			const matrixModel = this.getModel("matrixModel");
			var oStaffingModel = MTRModels.getStaffingModel();
			var aStaffingRecord = oStaffingModel.getData();
			const oResourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
			var remainingDays;
			var aStaffingData = [];
			var that = this;
			var sOwnerName = "";
			var sOpportunityName = "";
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			var aOpportunities = oSettingsModel.getProperty("/Opportunities");
			var aManualIOs = oSettingsModel.getProperty("/to_MANUAL");
			var oOpportunity = null;
			var oManualIO = null;
			this.IOStaffing = null;
			var sInternalOrder = "";
			var isOpportunity = true;
			var isValid = false;
			const currentMatrixContext = oControl.getBindingContext("matrixModel") || {};
			if (!currentMatrixContext) {
				return;
			}

			let contextPath = currentMatrixContext.getPath() || "";
			let oEntry = matrixModel.getProperty(contextPath);

			if (oEntry.CostTypeId.toString() === "1") {

				oOpportunity = aOpportunities.find(function (item) {
					return item.OpportunityID === oEntry.CostTypeValue;
				});
				if (oOpportunity && oOpportunity.IOSetting === "Yes" && oOpportunity.AssociatedIO && oOpportunity.AssociatedIO !== "") {
					sInternalOrder = oOpportunity.AssociatedIO;
				}

			} else if ((oEntry.CostTypeId === "3" || oEntry.CostTypeId === 3) && oEntry.CostTypeValue && oEntry.CostTypeValue !== "") {
				oManualIO = aManualIOs.find(function (item) {
					return item.ManualIOID === oEntry.CostTypeValue;
				});
				if (oManualIO) {
					sInternalOrder = oEntry.CostTypeValue;
				}
				isOpportunity = false;
			}

			const sDateFormat = oSettingsModel.getProperty("/DateFormat");

			const oDateFormat = oSettingsModel.getProperty("/DateFormats").find(function (d) {
				return d.ID === sDateFormat;
			});

			const aAssociatedIOData = aStaffingRecord.filter(function (item) {
				return sInternalOrder && item.InternalOrder === sInternalOrder;
			});

			if (!sInternalOrder || aAssociatedIOData.length === 0) {
				let sOpportunityOrManulDesc = (isOpportunity) ? oOpportunity.OpportunityName : "";
				if (!isOpportunity && oManualIO) {
					sOpportunityOrManulDesc = oManualIO.ManualIODesc;
				}

				const sOpportunutyDetails = (oOpportunity && oOpportunity.OpportunityID) ? oOpportunity.OpportunityID : sInternalOrder;

				aStaffingData.push({
					Name: sOpportunityOrManulDesc,
					Error: true,
					ErrorMessage: (!sInternalOrder) ? "IO not associated with Opportunity" : "IO details associated with Opportunity but you are not staffed",
					MessageDescription: (!sInternalOrder) ?
						"INFO SECTION\n\nSelected Opportunity " + sOpportunutyDetails +
						" is not associated with any IO as of today. Hence, you will not be able to Submit time for the same. \n\n" +
						"This could be due to any of the below reasons: \n\n1. IO has not been created for Opportunity so far. \n\n" +
						"2. You have not been staffed with the associated IO. \n\nRESOLUTION\n\nPlease submit a ticket for resolution, you can save the entry for now." : "INFO SECTION\n\nSelected Opportunity " +
						sOpportunutyDetails +
						" is associated with an IO " + sInternalOrder +
						", but you are not staffed on the IO. Hence, you will not be able to Submit time for the same. \n\nThis could be due below reasons:\n1. You are not staffed on the associated IO. \n\nRESOLUTION \n\nPlease submit a ticket for resolution, you can save the entry for now.",
					TicketText: "Submit a ticket",
					TicketLinkHref: "https://itsm.services.sap/sp?id=sc_cat_item&sys_id=703f22d51b3b441020c8fddacd4bcbe2&sysparm_category=e15706fc0a0a0aa7007fc21e1ab70c2&service_offering=2aa782291b244110d9c921fbbb4bcbdb&short_description=PreSales%20Tools:%20Melody%20Time%20Recordingp",
					Staffing: (!sInternalOrder) ? "IO Details" : sInternalOrder,
				});
			} else {
				for (let i = 0; i < aAssociatedIOData.length; i++) {
					const sOpportunityId = (isOpportunity) ? oOpportunity.OpportunityID : "";
					if (!aAssociatedIOData[i].StaffedDays) {
						let sMessageDescription = "";
						if (aAssociatedIOData[i].IsOpportunityIO) {
							sMessageDescription = "INFO SECTION\n\nSelected Opportunity " + sOpportunityId +
								" is associated with an IO " + sInternalOrder +
								". which has been assigned to the Task Type or Task Level not matching with the Task Type or Task Level assigned to the Task you have Selected." +
								"\n\n1. IO – " + sInternalOrder +
								" assigned to Task Level and Task Type. \n\n2.Support and Enablement assigned to Task Level K1 and Task Type. \n\nRESOLUTION\n\nPlease submit a ticket for resolution, you can save the entry for now."
						} else {
							sMessageDescription = "INFO SECTION\n\nSelected Manual IO " + aAssociatedIOData[i].InternalOrder +
								". which has been assigned to the Task Type or Task Level not matching with the Task Type or Task Level assigned to the Task you have Selected." +
								"\n\n1. Manual IO – " + aAssociatedIOData[i].InternalOrder +
								" assigned to Task Level and Task Type. \n\n2.Support and Enablement assigned to Task Level K1 and Task Type. \n\nRESOLUTION\n\nPlease submit a ticket for resolution, you can save the entry for now."
						}

						aStaffingData.push({
							Name: (isOpportunity) ? oOpportunity.OpportunityName : aAssociatedIOData[i].Description,
							Error: true,
							ErrorMessage: "IO Task Type or Task Level not matching with Task Selected",
							MessageDescription: sMessageDescription,
							TicketText: "Submit a ticket",
							TicketLinkHref: "https://itsm.services.sap/sp?id=sc_cat_item&sys_id=703f22d51b3b441020c8fddacd4bcbe2&sysparm_category=e15706fc0a0a0aa7007fc21e1ab70c2&service_offering=2aa782291b244110d9c921fbbb4bcbdb&short_description=PreSales%20Tools:%20Melody%20Time%20Recordingp",
							Staffing: sInternalOrder
						});
					} else {
						remainingDays = (parseFloat(aAssociatedIOData[i].StaffedDays) - parseFloat(aAssociatedIOData[i].RecordedDays)) + " Days Left";

						aStaffingData.push({
							Error: false,
							Staffing: "Staffing " + (i + 1),
							ID: (isOpportunity) ? oOpportunity.OpportunityID : aAssociatedIOData[i].InternalOrder,
							Name: (isOpportunity) ? oOpportunity.OpportunityName : aAssociatedIOData[i].Description,
							Owner: (isOpportunity) ? oOpportunity.OwnerName : "",
							AccountID: (isOpportunity) ? oOpportunity.AccountID : "",
							AccountName: (isOpportunity) ? oOpportunity.AccountName : "",
							InternalOrder: sInternalOrder,
							StaffedDays: aAssociatedIOData[i].StaffedDays,
							StartDate: DateService.getInstance().formatStringDate(aAssociatedIOData[i].StartDate, oDateFormat.Value),
							EndDate: DateService.getInstance().formatStringDate(aAssociatedIOData[i].EndDate, oDateFormat.Value),
							TaskType: aAssociatedIOData[i].TaskType,
							TaskLevel: aAssociatedIOData[i].TaskLevel,
							IsOpportunity: isOpportunity,
							RemainingDays: remainingDays,
							Analytics: [{
								"Staffing": oResourceBundle.getText("recordedDays"),
								"Days": parseFloat(aAssociatedIOData[i].RecordedDays)
							}, {
								"Staffing": oResourceBundle.getText("remainingDays"),
								"Days": parseFloat(aAssociatedIOData[i].StaffedDays) - parseFloat(aAssociatedIOData[i].RecordedDays)
							}]
						});
					}
				}
			}

			if (!this._oISPInfoPopover) {
				this._oISPInfoPopover = sap.ui.xmlfragment("com.melody.lib.fragments.MTR.ISPMessagePopover", this);
				var oResourcei18nModel = MTRModels.getMTRResourceModel();
				this._oISPInfoPopover.setModel(oResourcei18nModel, "i18n");
				this._oISPInfoPopover.setModel(new JSONModel(aStaffingData));
			}
			this._oISPInfoPopover.openBy(oEvent.getSource());

		},


		handleISPMessagePopoverClose: function () {
			if (this._oISPInfoPopover) {
				this._oISPInfoPopover.close();
				this._oISPInfoPopover.destroy();
				this._oISPInfoPopover = null;
			}
		},

		/**
		 * @author DARSHAN
		 * @function onCloseMatrixNotesDialog
		 * @description function to close add notes to entries dialog
		 * @param {Object} event
		 */
		onCloseMatrixNotesDialog: function (event) {
			if (this.matrixTimeRecordingNotesDialog) {
				this.matrixTimeRecordingNotesDialog.close();
			}
		},

		/**
		 * @author DARSHAN
		 * @function onAfterCloseAddNoteDialog
		 * @description function to handle after close add notes to entries dialog
		 * @param {Object} event
		 */
		onAfterCloseAddNoteDialog: function (event) {
			if (this.matrixTimeRecordingNotesDialog) {
				this.matrixTimeRecordingNotesDialog.destroy();
				this.matrixTimeRecordingNotesDialog = null;
			}
		},

		/**
		 * @author DARSHAN
		 * @function onAddMatrixEntry
		 * @description function to create a copy of the entry which is selected
		 * @param {Object} event
		 */
		onAddMatrixEntry: function (event, type) {
			let matrixModel = this.getModel("matrixModel");
			let selectedCategory = matrixModel.getProperty("/matrixCategory");
			let bindingContext = event.getSource().getBindingContext("matrixModel") || {};
			let path = bindingContext.getPath() || "";
			let matrixEntry = bindingContext.getObject();
			if (path) {
				//Validation
				let selectedIndex = Number(path.split("/")[2]);
				this.handleAdditionOfMatixEntries({
					insertAt: selectedIndex + 1,
					aEntriesToBeInserted: [matrixEntry],
					view: selectedCategory,
					operationType: type,
				});
			}
			matrixModel.refresh();
		},

		/**
		 * @author DARSHAN
		 * @function onMatrixAssociationChange
		 * @description function to handle association change
		 * @param {Object} event
		 */
		onMatrixAssociationChange: function (event, refDataFrm) {
			const matrixModel = this.getModel("matrixModel");
			const value = event.getParameter("value")
			const bindingContext = event.getSource().getBindingContext("matrixModel") || {};
			const path = bindingContext.getPath() || "";
			const accountEdit = matrixModel.getProperty(`${path}/accountEdit`);
			const opportunityEdit = matrixModel.getProperty(`${path}/opportunityEdit`);
			const matrixEntry = bindingContext.getObject();
			let matrixActivityData = $.extend(true, [], matrixModel.getProperty("/matrixActivityData"));
			if (path) {
				if (matrixEntry.ActvtId) {
					matrixModel.setProperty(`${path}/selectedRegion`, "");
					// matrixModel.setProperty(`${path}/CostObjectItems`, []);
					matrixModel.setProperty(`${path}/selectedMarketUnit`, "");
					matrixModel.setProperty(`${path}/activityDescription`, "");
					matrixModel.setProperty(`${path}/actvtNoAssociationdescription`, "");
					matrixModel.setProperty(`${path}/activityRegistration/OpportunityId`, "");
					matrixModel.setProperty(`${path}/activityRegistration/GlobalUltimateID`, "");
					matrixModel.setProperty(`${path}/activityRegistration/OpportunityNumber`, "");
				}
				matrixModel.setProperty(`${path}/selectedActivityType`, "");
				// matrixModel.setProperty(`${path}/CostTypeValue`, "");
				matrixModel.setProperty(`${path}/selectedAstOpportunityValue`, "");
				matrixModel.setProperty(`${path}/selectedAstAccountValue`, "");
				matrixModel.setProperty(`${path}/CostObjectItems`, []);
				switch (value) {
					case "Account":
						matrixModel.setProperty(`${path}/CostTypeId`, "4");
						matrixModel.setProperty(`${path}/ActAsstId`, "501");
						matrixModel.setProperty(`${path}/activityNoAssociationData`, {});
						break;
					case "Opportunity":
						matrixModel.setProperty(`${path}/CostTypeId`, "1");
						matrixModel.setProperty(`${path}/ActAsstId`, "502");
						matrixModel.setProperty(`${path}/activityNoAssociationData`, {});
						break;
					case "No Association":
						matrixModel.setProperty(`${path}/CostTypeId`, "2");
						matrixModel.setProperty(`${path}/ActAsstId`, "503");
						matrixModel.setProperty(`${path}/activityNoAssociationData`, {});
						break;
					default:
						matrixModel.setProperty(`${path}/CostTypeId`, "");
						matrixModel.setProperty(`${path}/ActAsstId`, "");
						matrixModel.setProperty(`${path}/activityNoAssociationData`, {});
				}
				matrixModel.setProperty(`${path}/validateRegisterBtn`, Math.random());

				matrixEntry.updateFacingEntries();
			}
			matrixModel.refresh();
			if (value) {
				this.setExistingActivityData(false, path);
			}
		},

		/**
		 * @author DARSHAN
		 * @function matrixOpportunitySelection
		 * @description function to handle opportunity selection
		 * CostTypeValue will be updated at the time of click of Save/Submit button in the Matrix list dialog
		 * @param {Object} oEvent
		 */
		matrixOpportunitySelection: function (oEvent) {
			try {
				let bClearActvtId = false;
				let opportunityData = [];
				const matrixModel = this.getModel("matrixModel");
				let selectedOpportunity = oEvent.getParameter("opportunityData") || false;
				let currentMatrixContext = oEvent.getSource().getBindingContext("matrixModel") || false;
				if (!currentMatrixContext) {
					return;
				}
				let contextPath = currentMatrixContext.getPath();
				let matrixEntry = matrixModel.getProperty(contextPath);
				let registration = matrixModel.getProperty(`${contextPath}/activityRegistration`) || {};
				let selectedActivityTypeObject = matrixModel.getProperty(`${contextPath}/selectedActivityTypeData`) || {};
				let actionMode = ("activityMode" in matrixEntry && matrixEntry.activityMode === Actions.ActivityMode.newActivity) ? "CREATE" :
					"EDIT";

				//Since In Edit Case the activity type data will be already be present as part of activity data
				if (actionMode === "EDIT") {
					selectedActivityTypeObject = {};
				}

				//Check for change in value
				if (matrixEntry.ActvtId && matrixEntry.ActAsstId === "502" && matrixEntry.selectedAstOpportunityValue !== selectedOpportunity.OpportunityId &&
					"IsSelected" in selectedOpportunity && selectedOpportunity.IsSelected) {
					bClearActvtId = true;
					matrixModel.setProperty(`${contextPath}/activityDescription`, "");
				}

				if (selectedOpportunity && selectedOpportunity.OpportunityId && Object.keys(selectedOpportunity).length) {
					registration.OpportunityNumber = selectedOpportunity.OpportunityId;
					registration.OpportunityId = selectedOpportunity.OpportunityId;
					matrixModel.setProperty(`${contextPath}/opportunityData`, selectedOpportunity);
					if (!matrixEntry.selectedAstOpportunityValue) {
						matrixModel.setProperty(`${contextPath}/selectedAstOpportunityValue`, selectedOpportunity.OpportunityId);
					}
				} else {
					registration.OpportunityNumber = "";
					registration.OpportunityId = "";
				}

				if (matrixEntry.CostTypeId === "1") {
					matrixModel.setProperty(`${contextPath}/CostTypeValue`, selectedOpportunity.OpportunityId);
					matrixModel.setProperty(`${contextPath}/CostTypeName`, selectedOpportunity.OpportunityName);
				}

				matrixModel.setProperty(`${contextPath}/activityRegistration`, registration);
				matrixModel.setProperty(`${contextPath}/validateRegisterBtn`, selectedOpportunity.OpportunityId);
				matrixModel.setProperty(`${contextPath}/validateRegisterBtn`, Math.random());

				//Update Facing data
				matrixEntry.updateFacingEntries({
					clearActivity: bClearActvtId
				});

				matrixModel.refresh();
			} catch (error) {
				console.log("ERROR IN matrixOpportunitySelection : ", error);
			}
		},

		/**
		 * @author DARSHAN
		 * @function matrixOpportunityClearSelection
		 * @description function to handle opportunity selection
		 * @param {Object} oEvent
		 */
		matrixOpportunityClearSelection: function (oEvent) {
			try {
				let opportunityData = [];
				const matrixModel = this.getModel("matrixModel");
				let clearOpportunity = oEvent.getParameter("reset") || false;
				let currentMatrixContext = oEvent.getSource().getBindingContext("matrixModel") || false;
				if (!currentMatrixContext) {
					return;
				}
				let contextPath = currentMatrixContext.getPath();
				let matrixEntry = matrixModel.getProperty(contextPath);
				let actionMode = ("activityMode" in matrixEntry && matrixEntry.activityMode === Actions.ActivityMode.newActivity) ? "CREATE" :
					"EDIT";
				let registration = matrixModel.getProperty(`${contextPath}/activityRegistration`) || {};
				if (clearOpportunity) {
					registration.GlobalUltimateID = "";
					registration.OpportunityId = "";
					registration.OpportunityNumber = "";
					registration.to_AOpportunity = opportunityData;
				}
				registration.to_AAccnt = [];
				matrixModel.setProperty(`${contextPath}/CostTypeValue`, "");
				matrixModel.setProperty(`${contextPath}/CostTypeName`, "");
				matrixModel.setProperty(`${contextPath}/selectedAstOpportunityValue`, "");
				matrixModel.setProperty(`${contextPath}/opportunityData`, null);
				matrixModel.setProperty(`${contextPath}/activityDescription`, "");
				matrixModel.setProperty(`${contextPath}/activityRegistration`, registration);
				matrixModel.setProperty(`${contextPath}/validateRegisterBtn`, Math.random());

				//Update Facing data
				matrixEntry.updateFacingEntries();

				matrixModel.refresh();
			} catch (error) {
				console.log("ERROR IN matrixOpportunityClearSelection : ", error);
			}
		},

		/**
		 * @author DARSHAN
		 * @function matrixAccountSelection
		 * @description function to handle Account selection
		 * CostTypeValue will be updated at the time of click of Save/Submit button in the Matrix list dialog
		 * @param {Object} oEvent
		 */
		matrixAccountSelection: function (oEvent) {
			try {
				let accountData = [];
				let bClearActvtId = false;
				const matrixModel = this.getModel("matrixModel");
				let selectedAccount = oEvent.getParameter("accountData") || false;
				let currentMatrixContext = oEvent.getSource().getBindingContext("matrixModel") || false;
				if (!currentMatrixContext) {
					return;
				}
				let contextPath = currentMatrixContext.getPath();
				let matrixEntry = matrixModel.getProperty(contextPath);
				let registration = matrixModel.getProperty(`${contextPath}/activityRegistration`);
				let selectedActivityTypeObject = matrixModel.getProperty(`${contextPath}/selectedActivityTypeData`) || {};
				let actionMode = ("activityMode" in matrixEntry && matrixEntry.activityMode === Actions.ActivityMode.newActivity) ? "CREATE" :
					"EDIT";

				//Since In Edit Case the activity type data will be already be present as part of activity data
				if (actionMode === "EDIT") {
					selectedActivityTypeObject = {};
				}

				//Check for change in value (Only in case of existing Activity)
				if (matrixEntry.ActvtId && matrixEntry.ActAsstId === "501" && matrixEntry.selectedAstAccountValue !== selectedAccount.AccountId &&
					"isSelected" in selectedAccount && selectedAccount.isSelected) {
					bClearActvtId = true;
					matrixModel.setProperty(`${contextPath}/activityDescription`, "");
				}

				if (selectedAccount && selectedAccount.AccountId && Object.keys(selectedAccount).length) {
					registration.GlobalUltimateID = selectedAccount.AccountId;
					matrixModel.setProperty(`${contextPath}/accountData`, selectedAccount);
					if (!matrixEntry.selectedAstAccountValue) {
						matrixModel.setProperty(`${contextPath}/selectedAstAccountValue`, selectedAccount.AccountId);
					}
				} else {
					registration.GlobalUltimateID = "";
				}

				registration.OpportunityNumber = "";
				registration.OpportunityId = "";

				if (matrixEntry.CostTypeId === "4") {
					// matrixModel.setProperty(`${contextPath}/selectedAstAccountValue`, selectedAccount.AccountId);
					matrixModel.setProperty(`${contextPath}/CostTypeValue`, selectedAccount.AccountId);
					matrixModel.setProperty(`${contextPath}/CostTypeName`, selectedAccount.AccountName);
				}

				matrixModel.setProperty(`${contextPath}/activityRegistration`, registration);
				matrixModel.setProperty(`${contextPath}/validateRegisterBtn`, registration.GlobalUltimateID);
				matrixModel.setProperty(`${contextPath}/validateRegisterBtn`, Math.random());

				//Update Facing data
				matrixEntry.updateFacingEntries({
					clearActivity: bClearActvtId
				});

				matrixModel.refresh();
			} catch (error) {
				console.log("ERROR IN matrixAccountSelection : ", error);
			}
		},

		/**
		 * @author DARSHAN
		 * @function matrixAccountClearSelection
		 * @description function to handle Account selection
		 * @param {Object} oEvent
		 */
		matrixAccountClearSelection: function (oEvent) {
			try {
				let accountData = [];
				const matrixModel = this.getModel("matrixModel");
				let clearAccount = oEvent.getParameter("reset") || false;
				let currentMatrixContext = oEvent.getSource().getBindingContext("matrixModel") || false;
				if (!currentMatrixContext) {
					return;
				}
				let contextPath = currentMatrixContext.getPath();
				let matrixEntry = matrixModel.getProperty(contextPath);
				let registration = matrixModel.getProperty(`${contextPath}/activityRegistration`);
				if (clearAccount) {
					registration.GlobalUltimateID = "";
					registration.to_AAccnt = accountData;
				}
				registration.OpportunityId = "";
				registration.OpportunityNumber = "";
				registration.to_AOpportunity = [];
				matrixModel.setProperty(`${contextPath}/CostTypeValue`, "");
				matrixModel.setProperty(`${contextPath}/CostTypeName`, "");
				matrixModel.setProperty(`${contextPath}/selectedAstAccountValue`, "");
				matrixModel.setProperty(`${contextPath}/accountData `, null);
				matrixModel.setProperty(`${contextPath}/activityDescription`, "");
				matrixModel.setProperty(`${contextPath}/activityRegistration`, registration);
				matrixModel.setProperty(`${contextPath}/validateRegisterBtn`, Math.random());

				//Update Facing data
				matrixEntry.updateFacingEntries();

				matrixModel.refresh();
			} catch (error) {
				console.log("ERROR IN matrixAccountClearSelection : ", error);
			}
		},

		/**
		 * @author DARSHAN
		 * @function onChangeCategory
		 * @description function to handle category segmented buttons
		 * @param {Object} oEvent
		 */
		onChangeCategory: async function (oEvent) {
			this.parentControl.batchIndex = 0;

			this.parentControl.matrixResponse = [];
			let aMatrixData = [];
			const matrixModel = this.getModel("matrixModel");
			let selectedKey = oEvent.getSource().getSelectedKey();
			let oWeekDates = oMatrix.fnGetWeekFirstLastDates();
			matrixModel.setProperty("/matrixCategory", selectedKey);
			let changedCalendarDate = matrixModel.getProperty("/changedCalendarDate") || null;
			switch (selectedKey) {
				case Actions.matrixCategory.activity:
					aMatrixData = await oMatrix.seperateEntriesBasedOnDate(changedCalendarDate);
					matrixModel.setProperty("/matrixActivityData", aMatrixData);
					break;
				case Actions.matrixCategory.learning:
					aMatrixData = await oMatrix.seperateEntriesBasedOnDate(changedCalendarDate);
					matrixModel.setProperty("/matrixLearningData", aMatrixData);
					break;
				default:
			}
			//oMatrix.fnCalculateSubTotal(aMatrixData);
			matrixModel.refresh(true);
		},

		/**
		 * @author DARSHAN
		 * @function openActivityTypeInfo
		 * @description Function to show Activity Type Information on information icon
		 */
		openActivityTypeInfo: async function (oEvent, activityStartDate) {
			const matrixModel = this.getModel("matrixModel");
			let oActivityRole = matrixModel.getProperty("/oActivityRole") || {};
			let currentMatrixContext = oEvent.getSource().getBindingContext("matrixModel") || false;
			if (!currentMatrixContext) {
				return;
			}
			let contextPath = currentMatrixContext.getPath();
			let matrixEntry = matrixModel.getProperty(contextPath);
			let aEntries = matrixEntry.Entries;
			let registration = matrixModel.getProperty(`${contextPath}/activityRegistration`);
			this.getModel("matrixModel").setProperty("/selectedActivity", registration);
			this._setEntriesInfoData(aEntries);
			if (this.activityInfoPopup) {
				this.activityInfoPopup.destroy()
				this.activityInfoPopup = null;
			}
			if (!this.activityInfoPopup) {
				this.activityInfoPopup = sap.ui.xmlfragment(
					"com.melody.lib.fragments.MTR.Matrix.Actions.ActivityTypeInfo",
					this);
				this.activityInfoPopup.setModel(matrixModel, "matrixModel");
			}
			oEvent.getSource().getParent().addDependent(this.activityInfoPopup);
			this.activityInfoPopup.openBy(oEvent.getSource());
			matrixModel.refresh();
		},

		/**
		 * @author AKBAR
		 * @function onRestrictedInfoIconPress
		 * @description Function to show Restricted Error Information on information icon
		 */
		onRestrictedInfoIconPress: async function (oEvent) {
			const matrixModel = this.getModel("matrixModel");
			let currentMatrixContext = oEvent.getSource().getBindingContext("matrixModel") || false;
			if (!currentMatrixContext) {
				return;
			}
			const sMsg = matrixModel.getProperty("/sMsg") || "";
			matrixModel.setProperty("/popoverMessage", sMsg);

			if (this._messagePopover) {
				this._messagePopover.destroy()
				this._messagePopover = null;
			}
			if (!this._messagePopover) {
				this._messagePopover = sap.ui.xmlfragment(
					"com.melody.lib.fragments.MTR.Matrix.Actions.RestrictedInforErrorPopover",
					this);
				this._messagePopover.setModel(matrixModel, "matrixModel");
			}
			oEvent.getSource().getParent().addDependent(this._messagePopover);
			this._messagePopover.openBy(oEvent.getSource());
			matrixModel.refresh();
		},

		/**
		 * @author AKBAR
		 * @function onRestrictedErrorPopoverClose
		 * @description Function to Close Restricted Error Information on information icon
		 */

		onRestrictedErrorPopoverClose: function () {
			if (this._messagePopover) {
				this._messagePopover.close();
			}
		},

		_setEntriesInfoData: function (aEntries) {
			const that = this;
			let matrixModel = this.getModel("matrixModel");
			let aSavedEntries = [],
				aFailedEntries = [],
				aSubmittedEntries = [];
			aEntries.filter(function (Entry) {
				var workDuration = parseFloat(Entry.WorkDuration);
				switch (Entry.StatusId) {
					case "1":
						// aSavedEntries.push(Entry);
						aSavedEntries.push(Entry);
						break;
					case "3":
						aFailedEntries.push(Entry);
						break;
					case "4":
						aSubmittedEntries.push(Entry);
						break;
					default:
						break;
				}
			});
			matrixModel.setProperty("/CfNcfSavedEntries", "");
			matrixModel.setProperty("/CfNcfSubmittedEntries", "");
			matrixModel.setProperty("/CfNcfFailedEntries", "");
			let cfSavedWorkDuration = 0;
			let ncfSavedWorkDuration = 0;
			if (aSavedEntries.length) {
				aSavedEntries.filter(function (oEntry) {
					const workDuration = parseFloat(oEntry.WorkDuration, 10);
					const bCustomerFacing = oEntry.CustomerFacing;
					if (bCustomerFacing) {
						cfSavedWorkDuration += workDuration;
					} else {
						ncfSavedWorkDuration += workDuration;
					}
					that._formatEntryInfoDate("CfNcfSavedEntries", cfSavedWorkDuration, ncfSavedWorkDuration);
				});
			} else {
				this._formatEntryInfoDate("CfNcfSavedEntries", cfSavedWorkDuration, ncfSavedWorkDuration);
			}

			let cfSubmittedWorkDuration = 0;
			let ncfSubmittedWorkDuration = 0;
			if (aSubmittedEntries.length) {
				aSubmittedEntries.filter(function (oEntry) {
					const workDuration = parseFloat(oEntry.WorkDuration, 10);
					const bCustomerFacing = oEntry.CustomerFacing;
					if (bCustomerFacing) {
						cfSubmittedWorkDuration += workDuration;
					} else {
						ncfSubmittedWorkDuration += workDuration;
					}

					that._formatEntryInfoDate("CfNcfSubmittedEntries", cfSubmittedWorkDuration, ncfSubmittedWorkDuration);
				});
			} else {
				this._formatEntryInfoDate("CfNcfSubmittedEntries", cfSubmittedWorkDuration, ncfSubmittedWorkDuration);
			}

			let cfFailedWorkDuration = 0;
			let ncfFailedWorkDuration = 0;
			if (aFailedEntries.length) {
				aFailedEntries.filter(function (oEntry) {
					const workDuration = parseFloat(oEntry.WorkDuration, 10);
					const bCustomerFacing = oEntry.CustomerFacing;
					if (bCustomerFacing) {
						cfFailedWorkDuration += workDuration;
					} else {
						ncfFailedWorkDuration += workDuration;
					}

					that._formatEntryInfoDate("CfNcfFailedEntries", cfFailedWorkDuration, ncfFailedWorkDuration);
				});
			} else {
				this._formatEntryInfoDate("CfNcfFailedEntries", cfFailedWorkDuration, ncfFailedWorkDuration);
			}
			matrixModel.refresh();
		},

		_formatEntryInfoDate: function (cfNcfProperty, cfWorkDuration, ncfWorkDuration) {
			let matrixModel = this.getModel("matrixModel");
			const oMtrSettings = sap.ui.getCore().getModel("mtrSettings");
			const sTimeMatrics = oMtrSettings.getProperty("/TimeMatrics");
			const sTimeMatricsTxt = sTimeMatrics === "H" ? "hours" : "day";
			let sDescription = "";
			sDescription = cfWorkDuration + " " + sTimeMatricsTxt + " CF / " + ncfWorkDuration + " " + sTimeMatricsTxt +
				" NCF";
			matrixModel.setProperty("/" + cfNcfProperty, sDescription);
		},

		onCloseActivityInfoPopup: function (event) {
			if (this.activityInfoPopup) {
				this.activityInfoPopup.close();
			}
		},

		/**
		 * @author DARSHAN
		 * @function onSuccessActvtRegistration
		 * @description Function to handle success of Activity registration from Rapid Registration Custom Ctrl
		 */
		onSuccessActvtRegistration: async function (oEvent) {

			try {
				const matrixModel = this.getModel("matrixModel");
				let contextPath = oEvent.getParameter("contextPath");
				let oActivityData = oEvent.getParameter("activityData");
				let aMatrixActivityData = matrixModel.getProperty("/matrixActivityData") || [];
				let oDefaultEntry = matrixModel.getProperty("/defaultEntry") || {};
				if (!contextPath) {
					return;
				}
				let matrixEntry = matrixModel.getProperty(contextPath);

				//Set Values to the fields in the matrix list item
				oActivityData.ActTypeDesc = oActivityData.ActivityTypeDescription;
				oActivityData.ActAsstId = oActivityData.ActvtAsstdID;
				oActivityData.OpportunityId = oActivityData.OpportunityNumber;
				matrixEntry.activityRegistration = Object.assign(matrixEntry.activityRegistration, oActivityData);
				matrixEntry.activityRegistration.ActStatus = oActivityData.Status;
				matrixEntry.activityRegistration.ActStatusDesc = await this.getStatusDescription(oActivityData.Status);
				matrixEntry.setActivityMatrixValues(oActivityData);
				matrixEntry.setCostObjectItems(oActivityData.ActvtAsstdID);
				matrixEntry.selectedActivityTypeData = {};
				matrixEntry.updateFacingEntries();
				
				//Account greadout fix
				if (oActivityData.ActAsstId === "502") {
					this.restrictTimeEntryForClosedIO(matrixEntry);
				}
				matrixModel.setProperty(contextPath, matrixEntry);
				let oMatrixEntryConfig = oMatrix.fnSetUpdateCreateMatrix(aMatrixActivityData);
				oMatrixEntryConfig.aMatrixData.splice(0, 1); //mat verstion 2 change
				matrixModel.setProperty("/matrixActivityData", oMatrixEntryConfig.aMatrixData);
				// matrixModel.setProperty("/matrixActivityListBusy", true);
				matrixModel.refresh();

			} catch (error) {
				console.log("ERROR IN onSuccessActvtRegistration : ", error);
			}
		},

		//Function to update status description in act details pop over
		getStatusDescription: async function (actStatusId) {
			let sStatusDesc = "";
			let aStatus = this.getModel("matrixModel").getProperty("/ActStatus");
			if (!aStatus) {
				aStatus = await MTRService.getActStatusMasterData();
			}
			let oStatus = aStatus.find(item => item.StatusId === actStatusId);
			if (oStatus) {
				sStatusDesc = oStatus.StatusDesc;
			}
			return sStatusDesc;
		},

		/**
		 * @author DARSHAN
		 * @function onCalendarNav
		 * @description Function to handle Calendar button
		 * @param {Object} oEvent
		 */
		onCalendarNav: async function (oEvent) {
			const tableId = this.parentControl.fnGetDialogUsingId("_MatrixTimeRecordingDialog", "activityMatrixList");
			tableId.getBinding("items").filter([]);
			this.parentControl.batchIndex = 0;
			this.parentControl.matrixResponse = [];
			const matrixModel = this.getModel("matrixModel");

			matrixModel.setProperty("/sSearchMatrixList", "");
			matrixModel.setProperty("/matrixActivityData", []);
			const controlSrc = oEvent.getSource()
			let selectedCategory = matrixModel.getProperty("/matrixCategory");
			matrixModel.setProperty("/matrixActivityListBusy", true);
			const startDate = controlSrc.getAggregation("_shortCalendar").getStartDate();
			await MTRUtil.updateTimesheets(startDate);
			let aMatrixData = await oMatrix.seperateEntriesBasedOnDate(startDate, true, true);
			if (selectedCategory === Actions.matrixCategory.activity) {
				matrixModel.setProperty("/matrixActivityData", aMatrixData);

			} else {
				matrixModel.setProperty("/matrixLearningData", aMatrixData);
			}
			matrixModel.setProperty("/changedCalendarDate", startDate);
			matrixModel.refresh(true);
		},

		/**
		 * @author DARSHAN
		 * @function onBeforeCalendarNav
		 * @description Function to handle Calendar button
		 * @param {Object} oEvent
		 */
		onBeforeCalendarNav: async function (oEvent) {

			let valid = true;
			const matrixModel = this.getModel("matrixModel");
			let aMatrixData;
			let selectedCategory = matrixModel.getProperty("/matrixCategory");
			if (selectedCategory === Actions.matrixCategory.learning) {
				aMatrixData = matrixModel.getProperty("/matrixLearningData") || [];
			} else {
				aMatrixData = matrixModel.getProperty("/matrixActivityData") || [];
			}

			// let aInValid = aMatrixData.filter((matrixEntry) => {
			// 	return matrixEntry.isValidForCheck && matrixEntry
			// });

			matrixModel.setProperty("/totalHours", {
				Date1: 0,
				Date2: 0,
				Date3: 0,
				Date4: 0,
				Date5: 0,
				Date6: 0,
				Date7: 0,
			});
			matrixModel.refresh();
		},

		/**
		 * @author Siddharth S, DARSHAN
		 * @function onActivityModeMenuAction
		 * @description function to handle Menu for Activity Type (New || Existing)
		 * @param {Object} oEvent
		 */
		onActivityModeMenuAction: function (oEvent) {
			const controlSrc = oEvent.getSource();
			const matrixModel = this.getModel("matrixModel");

			const bindingContext = controlSrc.getBindingContext("matrixModel") || false;
			// const bindingContext = this.oMatrixBtnMenu.getBindingContext("matrixModel") || false;
			if (!bindingContext) {
				return;
			}
			// const MenuButton = controlSrc.getParent();
			const path = bindingContext.getPath() || "";
			let matrixEntry = matrixModel.getProperty(path);
			// const oItem = oEvent.getParameter("item");
			const oItem = oEvent.getParameter("selectedItem");
			const selecteText = oItem.getText();
			const selecteKey = oItem.getKey();
			if (bindingContext) {
				// MenuButton.setText(selecteText);
				matrixModel.setProperty(`${path}/activityMode`, selecteText);
				matrixModel.setProperty(`${path}/defaultMenuKey`, selecteKey);
				matrixModel.setProperty(`${path}/selectedActivityType`, "");
				matrixModel.setProperty(`${path}/ActvtId`, "");
				matrixModel.setProperty(`${path}/activityDescription`, "");
				matrixModel.setProperty(`${path}/selectedActivityTypeData`, {});
				matrixModel.setProperty(`${path}/validateRegisterBtn`, Math.random());
				if (matrixEntry.selectedAssociationId) {
					this.setExistingActivityData(false, path);
				}
			}
			matrixModel.refresh();
		},

		/**
		 * @author  DARSHAN
		 * @function onLearningModeMenuAction
		 * @description function to handle Menu for Learning Type (Learning || Others)
		 * @param {Object} oEvent
		 */
		onLearningModeMenuAction: function (oEvent) {
			let taskId = "";
			const controlSrc = oEvent.getSource();
			const matrixModel = this.getModel("matrixModel");
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			let costCenter = oSettingsModel.getProperty("/CostCenter");
			const bindingContext = controlSrc.getBindingContext("matrixModel") || {};
			if (!bindingContext) {
				return;
			}
			const MenuButton = controlSrc.getParent();
			const path = bindingContext.getPath() || "";
			let matrixEntry = matrixModel.getProperty(path);
			let currTaskId = matrixEntry.TaskId;
			const oItem = oEvent.getParameter("item");
			const selecteText = oItem.getText();
			if (bindingContext && MenuButton) {
				if (selecteText === "Learning") {
					taskId = "10";
				}
				if (selecteText === "Others") {
					taskId = "7";
				}
				MenuButton.setText(selecteText);
				matrixModel.setProperty(`${path}/CostTypeId`, "2");
				matrixModel.setProperty(`${path}/CostTypeName`, "");
				matrixModel.setProperty(`${path}/CostTypeValue`, costCenter);
				matrixModel.setProperty(`${path}/TaskId`, taskId);
			}
			matrixEntry.updateFacingEntries();
			matrixModel.refresh();
		},

		/**
		 * @author  DARSHAN
		 * @function onTaskIdTaskChange
		 * @description function to handle change of TaskIds (Other)
		 * @param {Object} oEvent
		 */
		onTaskIdTaskChange: function (oEvent) {
			let taskId = "";
			const controlSrc = oEvent.getSource();
			const matrixModel = this.getModel("matrixModel");
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const bindingContext = controlSrc.getBindingContext("matrixModel") || {};
			if (!bindingContext) {
				return;
			}
			const path = bindingContext.getPath() || "";
			let matrixEntry = matrixModel.getProperty(path);
			let selectedKey = controlSrc.getSelectedKey();
			const aManualIOs = oSettingsModel.getProperty("/to_MANUAL") || [];
			let costCenter = oSettingsModel.getProperty("/CostCenter");
			let oManualIO = false
			if (aManualIOs.length) {
				oManualIO = aManualIOs[0];
			}

			switch (selectedKey) {
				case "11": //Special Project
					matrixModel.setProperty(`${path}/CostTypeId`, "2");
					matrixModel.setProperty(`${path}/CostTypeName`, "");
					matrixModel.setProperty(`${path}/CostTypeValue`, costCenter);
					matrixEntry.setCostObjectItems();
					break;
				default:
					matrixModel.setProperty(`${path}/CostTypeId`, "2");
					matrixModel.setProperty(`${path}/CostTypeName`, "");
					matrixModel.setProperty(`${path}/CostTypeValue`, costCenter);
			}

			matrixModel.setProperty(`${path}/TaskId`, selectedKey);
			matrixEntry.updateFacingEntries();
			matrixModel.refresh();
		},

		/**
		 * @author Siddharth S
		 * @function onCloseAddNotes
		 * @description function to handle add notes close
		 * @param {Object} event
		 */
		onCloseAddNotes: function (event) {
			try {
				let matrixModel = this.getModel("matrixModel");
				const path = this.matrixPath || "";
				const matrixActivityData = matrixModel.getProperty(path);
				const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				let aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
				if (event) {
					const aCurrenEntries = matrixActivityData.Entries || [];
					if (aCurrenEntries && aCurrenEntries.length) {
						aCurrenEntries.map(function (element) {
							const oEntry = aEntries.find(item => item.MtrUid === element.MtrUid);
							element.Note = (element.PreviousNote) ? JSON.parse(JSON.stringify(element.PreviousNote)) : "";
						});
						matrixActivityData.Entries = aCurrenEntries;
						matrixModel.setProperty(path, matrixActivityData);
					}
				}
				if (this.matrixTimeRecordingNotesDialog) {
					this.matrixTimeRecordingNotesDialog.destroy();
					this.matrixTimeRecordingNotesDialog = null;
					oDayWeekTimesheetModel.refresh();
				}
			} catch (error) {
				console.log("ERROR IN onCloseAddNotes : ", error);
			}
		},

		/**
		 * @author Siddharth S
		 * @function onSaveNotes
		 * @description function to save notes and time to LS.
		 * @param {Object} event
		 */
		onSaveNotes: async function () {
			let matrixModel = this.getModel("matrixModel");
			const path = this.matrixPath || "";
			const matrixActivityData = matrixModel.getProperty(path);
			let selectedCategory = matrixModel.getProperty("/matrixCategory");
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			let aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
			const aCurrenEntries = matrixActivityData.Entries || [];
			let aEntriesForSave = aCurrenEntries.filter(item => item.WorkDuration && item.DataFrom !== "I" && item.Indicator && item.Indicator.toUpperCase() ===
				"U");
			let validData = true;
			if (aEntriesForSave.length) {

				validData = this.fnCheckIsEntryValid(aEntriesForSave);
				if (!validData) {
					MessageToast.show("Please check the mandatory fields and try again");
					matrixModel.setProperty("/IsSaveBusy", false);
					matrixModel.refresh(true);
					return;
				}
				await this.fnPerformSaveEntries(aEntriesForSave, selectedCategory);
			} else {
				MessageToast.show("No entries for save.");
			}
			this.onCloseAddNotes();
		},
		/**
		 * @author Siddharth S, Darshan
		 * @function onAddNoteTxtAreaChange
		 * @description function to handle add notes changes text area
		 * @param {Object} event
		 */
		onAddNoteTxtAreaChange: function (event) {
			try {

				let dateKey;
				let matrixModel = this.getModel("matrixModel");
				const path = this.matrixPath || "";
				const matrixEntry = matrixModel.getProperty(path);
				let selectedCategory = matrixModel.getProperty("/matrixCategory");
				const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				let aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
				const controlSrc = event.getSource();
				let currEntryModified = controlSrc.getBindingContext().getObject();
				if (currEntryModified) {
					currEntryModified.Note = currEntryModified.Note.trim();
					currEntryModified.Indicator = "U";
					/*let iEntryIndex = aEntries.findIndex((entry) => {
						return entry.MtrUid === currEntryModified.MtrUid;
					});
					if (iEntryIndex !== -1) {
						aEntries[iEntryIndex] = currEntryModified;
					} else {
						aEntries.push(currEntryModified)
					}*/

					//Customer Facing
					/*if (!dateKey && selectedCategory === Actions.matrixCategory.activity) {
						for (let key in matrixEntry.customFacing) {
							let entry = matrixEntry.customFacing[key];
							if (entry.MtrUid === currEntryModified.MtrUid) {
								matrixEntry.customFacing[key] = currEntryModified;
								dateKey = key;
							}
						}
					}*/

					//Non-Customer Facing
					/*	if (!dateKey) {
							for (let key in matrixEntry.nonCustomFacing) {
								let entry = matrixEntry.nonCustomFacing[key];
								if (entry.MtrUid === currEntryModified.MtrUid) {
									matrixEntry.nonCustomFacing[key] = currEntryModified;
									dateKey = key;
								}
							}
						}*/
					// matrixModel.setProperty(path, matrixEntry);
				}
				// oDayWeekTimesheetModel.setProperty("/Entries", aEntries);
				// oDayWeekTimesheetModel.refresh();
				// matrixModel.refresh();
			} catch (error) {
				console.log("ERROR IN onAddWeekNote : ", error);
			}
		},

		/**
		 * @author DARSHAN, Siddharth S
		 * @function onActivityTypeChange
		 * @description function to handle Activity-Type Change
		 * @param {Object} oEvent
		 */
		onActivityTypeChange: function (oEvent) {
			const matrixModel = this.getModel("matrixModel");
			const selectedItem = oEvent.getSource().getSelectedItem() || false;
			const selectedMatrixContext = oEvent.getSource().getBindingContext("matrixModel") || false;
			if (!selectedItem || !selectedMatrixContext) {
				return;
			}
			let matrixEntry = selectedMatrixContext.getObject()
			let actionMode = ("activityMode" in matrixEntry && matrixEntry.activityMode === Actions.ActivityMode.newActivity) ? "CREATE" :
				"EDIT";
			const selectedActTypeContext = selectedItem.getBindingContext("matrixModel");
			const selectedActivityTypeData = selectedActTypeContext.getObject();
			const matrixContextPath = selectedMatrixContext.getPath();
			const activityRegistration = matrixModel.getProperty(`${matrixContextPath}/activityRegistration`) || {
				ActivityId: ""
			};
			const activityNoAssociationData = matrixModel.getProperty(`${matrixContextPath}/activityNoAssociationData`) || {};
			matrixModel.setProperty(`${matrixContextPath}/selectedActivityTypeData`, selectedActivityTypeData);
			matrixModel.refresh();
		},

		/**
		 * @author DARSHAN
		 * @function handleAdditionOfMatixEntries
		 * @description function to add matrix entries to list on Add || OK (Existing Activity Registration Dialog) || Add Time Entry Icon
		 * @param {Object} options
		 */
		handleAdditionOfMatixEntries: async function (options = {}) {
			try {
				let oMatrixList;
				let matrixModel = this.getModel("matrixModel");
				matrixModel.setProperty("/matrixActivityListBusy", true);
				let aMatrixDrafts = matrixModel.getProperty("/aMatrixDrafts") || [];
				let aMatrixActivityData = $.extend(true, [], matrixModel.getProperty("/matrixActivityData"));
				let aMatrixLearningData = $.extend(true, [], matrixModel.getProperty("/matrixLearningData"));
				if (options && !("insertAt" in options)) {
					return;
				}
				let aInsertion = options.aEntriesToBeInserted || [];
				let oWeekDates = oMatrix.fnGetWeekFirstLastDates();

				if (!aInsertion.length) {
					return new Promise((resolve) => resolve(true));
				}

				for (let i = 0; i < aInsertion.length; i++) {
					let matrixEntry = aInsertion[i];
					let cloneMatrixEntry = new Matrix();
					cloneMatrixEntry = Object.assign(cloneMatrixEntry, matrixEntry); //Creating a copy of the class to avoid call by reference issue
					if (options.operationType === "ADDACTVT") {
						cloneMatrixEntry.ActvtId = "";
						cloneMatrixEntry.activityDescription = "";
						cloneMatrixEntry.activityMode = Actions.ActivityMode.newActivity;
						cloneMatrixEntry.defaultMenuKey = "1";
					}
					//If Entries available, Clear the entries and create an new Entry Object for the dates
					delete cloneMatrixEntry.visible;
					delete cloneMatrixEntry.MatrixDateRange;
					delete cloneMatrixEntry.customFacing;
					delete cloneMatrixEntry.nonCustomFacing;
					delete cloneMatrixEntry.isMatrixEditable;
					delete cloneMatrixEntry.isValidForCheck;
					delete cloneMatrixEntry.IsSubmittedEntriesNotPresent;
					delete cloneMatrixEntry.Entries;
					let matrixItem = oMatrix.fnCreateEmptyMatrixEntry(oWeekDates.dFirstdate, oWeekDates.dLastdate, cloneMatrixEntry)[0];
					Object.assign(matrixItem, cloneMatrixEntry);
					//Improve the Below code
					let updatedEntry = $.extend(true, {}, matrixItem);
					updatedEntry = Object.create(
						Object.getPrototypeOf(matrixItem),
						Object.getOwnPropertyDescriptors(updatedEntry)
					);
					updatedEntry.visible.deleteicon = true;
					if (updatedEntry.IsSubmittedEntriesNotPresent && updatedEntry.StatusId === "4") {
						updatedEntry.StatusId = "";
					}

					updatedEntry.getActivityTypes(updatedEntry.selectedAssociationId);

					//ADD TIME ICON functionality
					if (options.operationType === "SUBMITTEDENTRY") {
						updatedEntry.IsSubmittedEntriesNotPresent = false;
						updatedEntry.visible.addRow = true;
						updatedEntry.visible.msgStrip = true;
						updatedEntry.isMatrixEditable = false;
						updatedEntry.visible.addTimeIcon = false;
						updatedEntry.visible.registerBtn = false;
					}

					updatedEntry.validateRegisterBtn = Math.random();
					if (options.view === Actions.matrixCategory.activity) {
						aMatrixActivityData.splice(options.insertAt, 0, updatedEntry);
					} else {
						aMatrixLearningData.splice(options.insertAt, 0, updatedEntry);
					}

					//If Existing Activity Functionality update the drafts
					if (options.operationType === "EXISTINGACTVT") {
						aMatrixDrafts.push(updatedEntry);
					}

				}
				if (options.view === Actions.matrixCategory.activity) {
					//Create a new Row for Creation in Matrix list
					let aUpdatedData = aMatrixActivityData;
					if (options.operationType === "EXISTINGACTVT") {
						// let oMatrixEntryConfig = oMatrix.fnSetUpdateCreateMatrix(aMatrixActivityData);
						// aUpdatedData = oMatrixEntryConfig.aMatrixData;
						matrixModel.setProperty("/aMatrixDrafts", aMatrixDrafts);
					}
					this.fnInsertDataUsingBatch(aUpdatedData);
				} else {
					matrixModel.setProperty("/matrixLearningData", aMatrixLearningData);
				}

				matrixModel.setProperty("/matrixActivityListBusy", false);
				matrixModel.refresh(true);
				return new Promise((resolve) => resolve(true));
			} catch (error) {
				console.log("ERROR IN handleAdditionOfMatixEntries : ", error);
			}
		},

		//Function to insert the data back into the array batch by batch
		fnInsertDataUsingBatch: function (aUpdatedData) {
			const matrixModel = this.getModel("matrixModel");
			matrixModel.setProperty("/matrixActivityListBusy", true);
			if (aUpdatedData && aUpdatedData.length) {
				const batchSize = 10;
				let batchIndex = 0;
				let aInsertData = [];
				let totalBatches = Math.ceil(aUpdatedData.length / batchSize);


				// matrixModel.setProperty("/matrixActivityData", []);
				const processNextBatch = () => {
					if (batchIndex < totalBatches) {
						let batchData = aUpdatedData.slice(batchIndex * batchSize, (batchIndex + 1) * batchSize);
						let aMatrixData = matrixModel.getProperty("/matrixTempActivityData") || [];
						// let aMatrixData = matrixModel.getProperty("/matrixActivityData") || [];
						for (let i = 0; i < batchData.length; i++) {
							aInsertData.push(batchData[i]);
							aMatrixData.push(batchData[i]);
						}
						batchIndex++;
						matrixModel.setProperty("/matrixActivityData", aMatrixData);
						matrixModel.setProperty("/matrixTempActivityData", aMatrixData);
						matrixModel.setProperty("/matrixActivityListBusy", true);
						matrixModel.refresh(true);

						setTimeout(processNextBatch, 10);
						setTimeout(() => {
							oMatrix.fnSortData();
						}, 800);
					} else {
						// matrixModel.setProperty("/matrixActivityData", aInsertData);
						matrixModel.setProperty("/matrixTempActivityData", []);
						matrixModel.setProperty("/matrixActivityListBusy", false);
					}
				}
				processNextBatch();

			} else {
				matrixModel.setProperty("/matrixActivityListBusy", false);
			}
			matrixModel.refresh();
		},

		/**
		 * @author DARSHAN
		 * @function generateSPathForData
		 * @description function to generate an spath
		 */
		generateSPathForData: function (pathName, index) {
			return `/${pathName}/${index}`;
		},

		/**
		 * @author DARSHAN
		 * @function handleActivityRegistration
		 * @description function to handle Activity create scenario
		 * @param {Object} options
		 */
		handleActivityRegistration: function (actionMode, options = {}) {
			try {
				const matrixModel = this.getModel("matrixModel");
				let matrixEntry;
				let activityRegistration = ("registration" in options) ? $.extend(true, {}, options.registration) : {};
				let oUserModel = sap.ui.getCore().getModel("userUtility"); // TODO:CHECK THIS LINE (TAKEN FROM LIBRARY)
				let userData = oUserModel.getProperty("/") || {};
				let noAssociationData = ("activityNoAssociationData" in options) ? options.activityNoAssociationData : {};
				let activityType = ("activityType" in options) ? options.activityType : {};
				let currentMatrixContextPath = ("currentMatrixContextPath" in options) ? options.currentMatrixContextPath : false;
				if (currentMatrixContextPath) {
					matrixEntry = matrixModel.getProperty(currentMatrixContextPath);
				}
				switch (actionMode) {
					case "CREATE":
						if (matrixEntry && "setActivityRegistration" in matrixEntry) {
							matrixEntry.setActivityRegistration(userData, noAssociationData, activityType);
						}
						let registration = matrixEntry.activityRegistration;

						//When Existing Activity Menu changed to New Activty && Selected Opportunity Data //TODO:Need to Improve
						if (matrixEntry.selectedAssociationId === "1") {
							matrixEntry = this.fnCreateOpportunityForActvtReg(matrixEntry);
						}

						//When Existing Activity Menu changed to New Activty && Seleted Account Data //TODO:Need to Improve
						if (matrixEntry.selectedAssociationId === "4") {
							matrixEntry = this.fnCreateAccountForActvtReg(matrixEntry);
						}

						matrixEntry.activityRegistration.ActivityId = "";
						if (currentMatrixContextPath) {
							delete matrixEntry.activityRegistration.OpportunityId;
							delete matrixEntry.activityRegistration.ActivityGUID;
							matrixModel.setProperty(`${currentMatrixContextPath}/activityRegistration`, matrixEntry.activityRegistration);
						}
						break;
					case "EDIT":
						//TODO:
						delete activityRegistration.to_AAddOpp;
						delete activityRegistration.to_AAudience;
						delete activityRegistration.to_ABsnsArEngd;
						delete activityRegistration.to_ACloudEnv;
						delete activityRegistration.to_AComments;
						delete activityRegistration.to_ACrossTopic;
						delete activityRegistration.to_ADemoCntnt;
						delete activityRegistration.to_ADetType;
						delete activityRegistration.to_AFiles;
						delete activityRegistration.to_AIndustry;
						delete activityRegistration.to_AInitiative;
						delete activityRegistration.to_ALand;
						delete activityRegistration.to_AMaterial;
						delete activityRegistration.to_APhase;
						delete activityRegistration.to_ARegionMu;
						delete activityRegistration.to_ARouteMkt;
						delete activityRegistration.to_AShowroom;
						delete activityRegistration.to_ASol;
						delete activityRegistration.to_ASrvReq;
						delete activityRegistration.to_AStrategicSol;
						delete activityRegistration.to_ASuccessFactor;
						delete activityRegistration.to_ATaxonomy;
						delete activityRegistration.to_ATeam;
						if (currentMatrixContextPath) {
							matrixModel.setProperty(`${currentMatrixContextPath}/activityRegistration`, activityRegistration);
						}
						break;
					default:
				}

				matrixModel.refresh();
			} catch (error) {
				console.log("ERROR IN handleActivityRegistration : ", error);
			}
		},

		/**
		 * @author DARSHAN
		 * @function fnCreateAccountForActvtReg
		 * @description function to help creation of Account Object for Register and Registred Activity Payload
		 * @param {Object} matrixEntry
		 */
		fnCreateAccountForActvtReg: function (matrixEntry) {
			let accountData = [];
			let selectedAccount = ("accountData" in matrixEntry && typeof matrixEntry.accountData === "object") ? matrixEntry.accountData :
				false;
			if (selectedAccount && Object.keys(selectedAccount).length) {
				let account = {
					iss: selectedAccount.ISS,
					iac: selectedAccount.IAC,
					accountname: selectedAccount.AccountName,
					accountid: selectedAccount.AccountId,
				};
				accountData.push(account);
				matrixEntry.activityRegistration.to_AOpportunity = [];
				matrixEntry.activityRegistration.OpportunityNumber = "";
				matrixEntry.activityRegistration.to_AAccnt = accountData;
				matrixEntry.activityRegistration.GlobalUltimateID = selectedAccount.AccountId;
			}
			return matrixEntry;
		},

		/**
		 * @author DARSHAN
		 * @function fnCreateOpportunityForActvtReg
		 * @description function to help creation of Opportunity Object for Register and Registred Activity Payload
		 * @param {Object} matrixEntry
		 */
		fnCreateOpportunityForActvtReg: function (matrixEntry) {
			let opportunityData = [];
			let selectedOpportunity = ("opportunityData" in matrixEntry && typeof matrixEntry.opportunityData === "object") ? matrixEntry.opportunityData :
				false;
			if (selectedOpportunity && Object.keys(selectedOpportunity).length) {
				let opportunity = {
					"accountid": selectedOpportunity.AccountId,
					"description": selectedOpportunity.Description,
					"ACCOUNT_NAME": selectedOpportunity.AccountName,
					"OPPT_ID": selectedOpportunity.OpportunityId,
					"mastercodeid": selectedOpportunity.Industry_MasterCode,
					"PHASE_DESC": ("PhaseValue" in selectedOpportunity) ? selectedOpportunity.PhaseValue : "",
					"Status": selectedOpportunity.Status,
					"StatusDescription": selectedOpportunity.StatusDescription,
					"SelectedOpportunity": selectedOpportunity
				};
				opportunityData.push(opportunity);
				matrixEntry.activityRegistration.to_AAccnt = [];
				matrixEntry.activityRegistration.to_AOpportunity = opportunityData;
				matrixEntry.activityRegistration.GlobalUltimateID = selectedOpportunity.AccountId;
				matrixEntry.activityRegistration.OpportunityNumber = selectedOpportunity.OpportunityId;
			}
			return matrixEntry;
		},

		/**
		 * @author DARSHAN
		 * @function onMatrixCostTypeChange
		 * @description function to handle change of cost Type Object
		 * @param {Object} oEvent
		 */
		onMatrixCostTypeChange: function (oEvent) {
			let oThisController = this;
			const controlSrc = oEvent.getSource();
			const sSelectedKey = controlSrc.getSelectedKey();
			const matrixModel = this.getModel("matrixModel");
			const settingsModel = MTRModels.getMTRSettingsModel();
			let costCenter = settingsModel.getProperty("/CostCenter");
			const context = controlSrc.getBindingContext("matrixModel");
			const path = context.getPath();
			const matrixEntry = context.getObject();
			const aManualIOs = settingsModel.getProperty("/to_MANUAL") || [];
			let oManualIO = false
			// if (aManualIOs.length) {
			// 	oManualIO = aManualIOs[0];
			// }
			oManualIO = aManualIOs.find(item => item.IsVisible) || false;
			switch (sSelectedKey) {
				case "3": //Manual IO
					if (oManualIO && path) {
						matrixModel.setProperty(`${path}/CostTypeId`, "3");
						matrixModel.setProperty(`${path}/CostTypeName`, oManualIO.ManualIODesc);
						matrixModel.setProperty(`${path}/CostTypeValue`, oManualIO.ManualIOID);
					}
					break;
				case "1": // Opportunity
					if (path) {
						matrixModel.setProperty(`${path}/CostTypeId`, "1");
						matrixModel.setProperty(`${path}/CostTypeValue`, matrixEntry.selectedAstOpportunityValue);
						matrixModel.setProperty(`${path}/CostTypeName`, ("opportunityData" in matrixEntry) ? matrixEntry.opportunityData.OpportunityName :
							"");
					}
					break;
				case "4": // Account
					if (path) {
						matrixModel.setProperty(`${path}/CostTypeId`, "4");
						matrixModel.setProperty(`${path}/CostTypeValue`, matrixEntry.selectedAstAccountValue);
						matrixModel.setProperty(`${path}/CostTypeName`, ("accountData" in matrixEntry) ? matrixEntry.accountData.AccountName :
							"");
					}
					break;
				default: //No Association (SAP COST CENTER)
					matrixModel.setProperty(`${path}/CostTypeId`, "2");
					matrixModel.setProperty(`${path}/CostTypeName`, "");
					matrixModel.setProperty(`${path}/CostTypeValue`, costCenter);
			}
			matrixEntry.updateFacingEntries();
			matrixEntry.checkAndUpdateDayWeekEntries();
			matrixModel.refresh();
		},

		/**
		 * @author DARSHAN
		 * @function onMatrixManualIOChange
		 * @description function to handle change of ManualIO
		 * @param {Object} oEvent
		 */
		onMatrixManualIOChange: function (oEvent) {
			let oThisController = this;
			const controlSrc = oEvent.getSource();
			let value = oEvent.getParameter("value");
			const sSelectedKey = controlSrc.getSelectedKey();
			const matrixModel = this.getModel("matrixModel");
			const settingsModel = MTRModels.getMTRSettingsModel();
			const context = controlSrc.getBindingContext("matrixModel");
			const path = context.getPath();
			const matrixEntry = context.getObject();

			const aManualIOs = settingsModel.getProperty("/to_MANUAL") || [];
			if (value) {
				value = value.split(":")[0]
			}
			matrixEntry.CostTypeName = value;
			matrixEntry.updateFacingEntries();
			matrixEntry.checkAndUpdateDayWeekEntries();
			matrixModel.refresh();
		},

		/**
		 * @author DARSHAN
		 * @function onMatrixChangeDuration
		 * @description function to handle live change of Matrix list input
		 * @param {Object} oEvent
		 */
		/**onMatrixChangeDuration1: function (oEvent, refDataFrm) {
	
			try {
				let entry = {};
				let entryType = "NEW";
				let previousValue = "";
				const regex = /^(\d+(\.([05]))?|\.[05])$/;
				const controlSrc = oEvent.getSource();
				let value = oEvent.getParameter("value");
				value = (value) ? value.trim() : "";
				const IsValidNumber = regex.test(value);
				const matrixModel = this.getModel("matrixModel");
				let oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				const selectedMatrixContext = controlSrc.getBindingContext("matrixModel") || false;
				const oMTRSettingData = oMatrix.getMTRSettingData();
				if (!selectedMatrixContext) {
					return;
				}
	
				//Matrix Entry Data
				let path = selectedMatrixContext.getPath();
				let matrixEntry = matrixModel.getProperty(path);
				let sMtrUid = controlSrc.data("mtruid");
				let sDataFrom = controlSrc.data("dataFrom");
				let facingType = controlSrc.data("dateSequence").split("_")[0] || "";
				let sDateSequence = controlSrc.data("dateSequence").split("_")[1] || "";
				let totalHrsValidation = matrixModel.getProperty("/totalHoursValidation");
				const entryPath = `${path}/${facingType}/${sDateSequence}`;
	
				//Validation
				let aValiation = [facingType, sDateSequence, sMtrUid]
				if (aValiation.indexOf("") !== -1) {
					return;
				}
				//CF/NCF Data
				let facingData = matrixEntry[facingType];
				let currCellEntry = facingData[sDateSequence];
				//All Entries
				let aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
				let oEntry = aEntries.find(function (item) {
					return item.MtrUid === sMtrUid && item.StatusId !== "";
				}) || false;
				//Existing Entry
				if (oEntry) {
					entryType = "EXISTING"
					previousValue = oEntry.WorkDuration;
				}
				//New Entry
				if (!oEntry) {
					oEntry = currCellEntry;
				}
				//INPUT CHECK
				value = parseFloat(value);
				value = isNaN(value) ? 0 : value;
				if (value && IsValidNumber) {
					if (IsValidNumber) {
						this._onChangeDuration(controlSrc, value, previousValue, {
							entry: oEntry,
							matrixPath: path,
							entryType: entryType,
							refDataFrm: refDataFrm,
							controlSrc: controlSrc,
							facingType: facingType,
							columnName: sDateSequence,
							recordDate: oEntry.RecordDate
						});
					} else {
						controlSrc.setValue(previousValue);
					}
				} else {
					//If Input value is cleared or empty
					if ((!value || !IsValidNumber) && "PreviousDuration" in oEntry && "DataFrom" in oEntry && oEntry.DataFrom) {
						let duration = parseFloat(oEntry.PreviousDuration);
						duration = isNaN(duration) ? 0 : duration;
						if (duration) {
							if (duration % 1 === 0) {
								duration = duration.toFixed(1);
							} else if (duration % 1 === 0.5) {
								duration = duration.toString();
							}
							controlSrc.setValue(duration);
							return;
						}
					}
	
					//To Remove & update the entry's Work duration
					if ("PreviousDuration" in oEntry && totalHrsValidation[sDateSequence]) {
						let duration = parseFloat(oEntry.PreviousDuration);
						duration = isNaN(duration) ? 0 : duration;
						totalHrsValidation[sDateSequence] = totalHrsValidation[sDateSequence] - duration;
						matrixModel.setProperty("/totalHoursValidation", $.extend(true, {}, totalHrsValidation));
						let tempEntry = matrixModel.getProperty(entryPath);
						oEntry.PreviousDuration = 0;
						tempEntry.PreviousDuration = 0;
						tempEntry.WorkDuration = "";
						matrixModel.setProperty(entryPath, tempEntry);
						matrixModel.refresh();
						this.fnRemoveEntryFrmDayWeek(tempEntry);
					}
					controlSrc.setValue("");
				}
			} catch (error) {
				console.log("ERROR IN onMatrixChangeDuration : ", error);
			}
		},*/
		/**
		 * @author DARSHAN, SIDDHARTH
		 * @function onMatrixChangeDuration
		 * @description function to handle live change of Matrix list input
		 * @param {Object} oEvent
		 */
		onMatrixChangeDuration: function (oEvent, refDataFrm) {

			try {
				const regex = /^(\d+(\.([05]))?|\.[05])$/;
				const controlSrc = oEvent.getSource();
				let value = oEvent.getParameter("value");
				value = (value) ? value.trim() : "";
				const IsValidNumber = regex.test(value);
				const matrixModel = this.getModel("matrixModel");
				let oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				const selectedMatrixContext = controlSrc.getBindingContext("matrixModel") || false;
				const oMTRSettingData = oMatrix.getMTRSettingData();
				if (!selectedMatrixContext) {
					return;
				}

				//Matrix Entry Data
				let path = selectedMatrixContext.getPath();
				let matrixEntry = matrixModel.getProperty(path);
				let sMtrUid = controlSrc.data("mtruid");
				let sDataFrom = controlSrc.data("dataFrom");
				let facingType = controlSrc.data("dateSequence").split("_")[0] || "";
				let sDateSequence = controlSrc.data("dateSequence").split("_")[1] || "";
				let totalHrsValidation = matrixModel.getProperty("/totalHoursValidation");
				const entryPath = `${path}/${facingType}/${sDateSequence}`;
				const sSelectedOppId = (matrixEntry && matrixEntry.selectedAstOpportunityValue) ? matrixEntry.selectedAstOpportunityValue : "";
				let bIsDiscontinuedOpp = false;
				if (IsValidNumber && sSelectedOppId) {
					const tempEntry = $.extend(true, {}, matrixModel.getProperty(entryPath));
					matrixEntry = $.extend(true, {}, matrixEntry);
					matrixEntry.tempEntry = tempEntry;
					matrixEntry.SelectedPath = path;
					bIsDiscontinuedOpp = MTRUtil.fnIsDiscontinuedOpportunity(oEvent, matrixEntry, sSelectedOppId, this, refDataFrm, matrixModel);
				}
				if (!bIsDiscontinuedOpp) {
					this.fnChangeDuration(oEvent, refDataFrm);
				}

			} catch (error) {
				console.log("ERROR IN onMatrixChangeDuration : ", error);
			}
		},
		/**
		 * @author SIDDHARTH
		 * @function onMatrixChangeDuration
		 * @description function to handle live change of Matrix list input after onMatrixChangeDuration
		 * @param {Object} oEvent
		 */
		fnChangeDuration: function (oEvent, refDataFrm) {
			try {

				let entry = {};
				let entryType = "NEW";
				let previousValue = "";
				const regex = /^(\d+(\.([05]))?|\.[05])$/;
				const controlSrc = oEvent.getSource();
				let value = oEvent.getParameter("value");
				value = (value) ? value.trim() : "";
				const IsValidNumber = regex.test(value);
				const matrixModel = this.getModel("matrixModel");
				let oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				const selectedMatrixContext = controlSrc.getBindingContext("matrixModel") || false;
				const oMTRSettingData = oMatrix.getMTRSettingData();
				if (!selectedMatrixContext) {
					return;
				}

				//Matrix Entry Data
				let path = selectedMatrixContext.getPath();
				let matrixEntry = matrixModel.getProperty(path);
				let sMtrUid = controlSrc.data("mtruid");
				let sDataFrom = controlSrc.data("dataFrom");
				let facingType = controlSrc.data("dateSequence").split("_")[0] || "";
				let sDateSequence = controlSrc.data("dateSequence").split("_")[1] || "";
				let totalHrsValidation = matrixModel.getProperty("/totalHoursValidation");
				const entryPath = `${path}/${facingType}/${sDateSequence}`;

				//Validation
				let aValiation = [facingType, sDateSequence, sMtrUid]
				if (aValiation.indexOf("") !== -1) {
					return;
				}
				//CF/NCF Data
				let facingData = matrixEntry[facingType];
				let currCellEntry = facingData[sDateSequence];
				//All Entries
				let aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
				let oEntry = aEntries.find(function (item) {
					return item.MtrUid === sMtrUid && item.StatusId !== "";
				}) || false;
				//Existing Entry
				if (oEntry) {
					entryType = "EXISTING"
					previousValue = oEntry.WorkDuration;
				}
				//New Entry
				if (!oEntry) {
					oEntry = currCellEntry;
				}
				//INPUT CHECK
				value = parseFloat(value);
				value = isNaN(value) ? 0 : value;
				if (value && IsValidNumber) {
					if (IsValidNumber) {
						this._onChangeDuration(controlSrc, value, previousValue, {
							entry: oEntry,
							matrixPath: path,
							entryType: entryType,
							refDataFrm: refDataFrm,
							controlSrc: controlSrc,
							facingType: facingType,
							columnName: sDateSequence,
							recordDate: oEntry.RecordDate
						});
					} else {
						controlSrc.setValue(previousValue);
					}
				} else {
					//If Input value is cleared or empty
					if ((!value || !IsValidNumber) && "PreviousDuration" in oEntry && "DataFrom" in oEntry && oEntry.DataFrom) {
						let duration = parseFloat(oEntry.PreviousDuration);
						duration = isNaN(duration) ? 0 : duration;
						if (duration) {
							if (duration % 1 === 0) {
								duration = duration.toFixed(1);
							} else if (duration % 1 === 0.5) {
								duration = duration.toString();
							}
							controlSrc.setValue(duration);
							return;
						}
					}

					//To Remove & update the entry's Work duration
					if ("PreviousDuration" in oEntry && totalHrsValidation[sDateSequence]) {
						let duration = parseFloat(oEntry.PreviousDuration);
						duration = isNaN(duration) ? 0 : duration;
						totalHrsValidation[sDateSequence] = totalHrsValidation[sDateSequence] - duration;
						matrixModel.setProperty("/totalHoursValidation", $.extend(true, {}, totalHrsValidation));
						let tempEntry = matrixModel.getProperty(entryPath);
						oEntry.PreviousDuration = 0;
						tempEntry.PreviousDuration = 0;
						tempEntry.WorkDuration = "";
						matrixModel.setProperty(entryPath, tempEntry);
						matrixModel.refresh();
						this.fnRemoveEntryFrmDayWeek(tempEntry);
					}
					controlSrc.setValue("");
				}
			} catch (error) {
				console.log("ERROR IN fnChangeDuration : ", error);
			}
		},
		/**
		 * @author SIDDHARTH
		 * @function onMatrixChangeDuration
		 * @description function to to update discontinued opportunity with paralles opp in model and current path.
		 * @param {Object} oEvent
		 */
		updateDiscontinuedOppWithParallelOpp: async function (event, refDataFrm, oReplaceByOpp) {

			const controlSrc = event.getSource();
			let matrixModel = this.getModel("matrixModel");
			let selectedCategory = matrixModel.getProperty("/matrixCategory");
			let bindingContext = event.getSource().getBindingContext("matrixModel") || {};
			let path = bindingContext.getPath() || "";
			let matrixEntry = bindingContext.getObject();
			let sMtrUid = controlSrc.data("mtruid");
			let facingType = controlSrc.data("dateSequence").split("_")[0] || "";
			let sDateSequence = controlSrc.data("dateSequence").split("_")[1] || "";
			let facingData = matrixEntry[facingType];
			let currCellEntry = facingData[sDateSequence];
			matrixEntry.AccountID = oReplaceByOpp.AccountID;
			matrixEntry.AccountName = oReplaceByOpp.AccountName;
			matrixEntry.CostTypeValue = oReplaceByOpp.OpportunityID;
			matrixEntry.OpportunityName = oReplaceByOpp.OpportunityName;
			matrixEntry.selectedAstOpportunityValue = oReplaceByOpp.OpportunityID;
			if (matrixEntry.activityRegistration) {
				matrixEntry.activityRegistration.GlobalUltimateID = oReplaceByOpp.AccountID;
				matrixEntry.activityRegistration.OpportunityId = oReplaceByOpp.OpportunityID;
				matrixEntry.activityRegistration.GlobalUltimateID = oReplaceByOpp.AccountID;
			}
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
			let index = aEntries.findIndex(function (item) {
				return item.MtrUid === sMtrUid;
			});
			if (index !== -1) {
				aEntries[index].AccountID = oReplaceByOpp.AccountID;
				aEntries[index].AccountName = oReplaceByOpp.AccountName;
				aEntries[index].CostTypeValue = oReplaceByOpp.OpportunityID;
				aEntries[index].OpportunityID = oReplaceByOpp.OpportunityID;
				aEntries[index].OpportunityName = oReplaceByOpp.OpportunityName;
				if (aEntries[index].ActDetails) {
					aEntries[index].ActDetails.OpportunityID = oReplaceByOpp.OpportunityID;
					aEntries[index].ActDetails.AccountID = oReplaceByOpp.OpportunityID;
					aEntries[index].ActDetails.CostTypeValue = oReplaceByOpp.OpportunityID;
					aEntries[index].ActDetails.OpportunityName = oReplaceByOpp.OpportunityName;
				}
				oDayWeekTimesheetModel.setProperty("/Entries", aEntries);
				oDayWeekTimesheetModel.refresh(true);
			}
			this.fnChangeDuration(event, refDataFrm);
		},
		fnAddMatrixEntryForParallelOpp: function (event, type, oReplaceByOpp) {// Not is use as of now.
			//not in use.
			let matrixModel = this.getModel("matrixModel");
			let selectedCategory = matrixModel.getProperty("/matrixCategory");
			let bindingContext = event.getSource().getBindingContext("matrixModel") || {};
			let path = bindingContext.getPath() || "";
			let matrixEntry = bindingContext.getObject();
			let oMatrixEntry = new Matrix(matrixEntry);
			oMatrixEntry.CostTypeValue = oOpportunity.OpportunityID;
			oMatrixEntry.selectedAssociationValue = oOpportunity.OpportunityID;
			oMatrixEntry.CostTypeName = oOpportunity.OpportunityName;
			oMatrixEntry.selectedAstOpportunityValue = oOpportunity.OpportunityID;
			if (path) {
				//Validation
				let selectedIndex = Number(path.split("/")[2]);
				this.handleAdditionOfMatixEntries({
					insertAt: selectedIndex + 1,
					aEntriesToBeInserted: [oMatrixEntry],
					view: selectedCategory,
					operationType: type,
				});
			}
			matrixModel.refresh();
		},
		fnRemoveEntryFrmDayWeek: function (entry) {
			let oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			let aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
			let iEntry = aEntries.findIndex(function (item) {
				return item.MtrUid === entry.MtrUid;
			});
			if (iEntry !== -1) {
				aEntries.splice(iEntry, 1);
				oDayWeekTimesheetModel.setProperty("/Entries", aEntries);
				oDayWeekTimesheetModel.refresh(true);
			}
		},

		/** 
		 * @private
		 * @param oControl
		 * @param sValue
		 * @param sPreviousValue
		 */
		_onChangeDuration: function (oControl, enteredValue, sPreviousValue = 0, options) {
			try {
				let columnValue;
				let formattedDate = "";
				const rRegexp = /^\d+(\.\d{1,2})?$/;
				const rRegexp2 = /^\d+\.\d{0,2}$/;
				const rRegexpDuration = /^(?!0$)\d+(?:[,.][05])?$/;
				const oTimeValidation = Actions.matrixDefaultTime;
				const oMTRSettingData = oMatrix.getMTRSettingData();

				//Validations
				const optionValues = Object.values(options) || [];
				if (optionValues.indexOf("") !== -1) {
					return;
				}

				//If TimeMatrics is for days
				if (oMTRSettingData.TimeMatrics === "D" && enteredValue > 1) {
					oControl.setValue(sPreviousValue);
					return;
				}

				//MODEL
				const matrixModel = this.getModel("matrixModel");
				const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				const oSettingsModel = MTRModels.getMTRSettingsModel();

				//ENTRY DATA
				const currCellEntry = options.entry;
				let totalWDForDate = this._fetchEntriesBasedOnRecordDate(currCellEntry)
				let oCalcuatedData = this._calculateTimeInDay(options); //TODO CHECK AND REMOVE
				const totalHours = matrixModel.getProperty("/totalHours");
				let currTotalDuration = oCalcuatedData.currTotalDuration;
				let currColumnEntries = oCalcuatedData.currColumnEntries;
				let oBindingContext = oControl.getBindingContext("matrixModel");
				let oMatrixEntry = matrixModel.getProperty(options.matrixPath);
				let aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
				let totalHrsValidation = matrixModel.getProperty("/totalHoursValidation");

				//DATE DATA
				enteredValue = parseFloat(enteredValue);
				let previousEnteredValue = parseFloat(sPreviousValue);
				previousEnteredValue = isNaN(previousEnteredValue) ? "" : previousEnteredValue;
				const cellDate = oControl.data("date");
				const sDateFormat = oSettingsModel.getProperty("/DateFormat");
				const aDateFormats = oSettingsModel.getProperty("/DateFormats") || [];
				const oDateFormat = (sDateFormat) ? aDateFormats.find(function (date) {
					return date.ID === sDateFormat;
				}) || false : false;
				if (oDateFormat) {
					formattedDate = DateService.getInstance().formatStringDate(cellDate, oDateFormat.Value);
				}

				//Entred Workduartion for the current cell and current date(CF/NCF)
				totalWDForDate = parseFloat(totalWDForDate);
				totalWDForDate = isNaN(totalWDForDate) ? 0 : totalWDForDate;

				//Adjust the duration in totalHourValidation
				if (totalHrsValidation[options.columnName]) {
					let PrevValue = ("PreviousDuration" in currCellEntry) ? parseFloat(currCellEntry.PreviousDuration) : parseFloat(
						previousEnteredValue);
					PrevValue = isNaN(PrevValue) ? 0 : PrevValue;
					columnValue = parseFloat(totalHrsValidation[options.columnName]);
					if (columnValue) {
						currTotalDuration = columnValue - PrevValue;
						currTotalDuration = currTotalDuration + enteredValue;
					} else {
						currTotalDuration = columnValue;
					}
				}

				//Calculte the total work duration of a date for a week
				totalWDForDate = totalWDForDate + enteredValue;

				//HOUR CHECK
				if (oMTRSettingData.TimeMatrics === "H") {
					//CHECK IF THE CURRENT ENTERED VALUE IS NOT MORE THAN 8hours
					if (totalWDForDate > oTimeValidation.hour) {
						MessageToast.show(`You have exceeded the expected ${currCellEntry.Expected} hours limit for ${formattedDate}`, {
							duration: 3000
						});
					}

					//CHECK IF THE TOTAL DURATION AVAILABLE EXCEEDS 24hours
					if (currTotalDuration > oTimeValidation.day) {
						MessageToast.show(`Work Duration should not be more than ${oTimeValidation.day} H for ${formattedDate}`, {
							duration: 3000
						});
						oControl.setValue(previousEnteredValue);
						return;
					}
				}

				//DAY CHECK
				if (oMTRSettingData.TimeMatrics === "D") {
					//CHECK IF THE TOTAL DURATION AVAILABLE EXCEEDS 24hours
					if (currTotalDuration > 1) {
						MessageToast.show(`Work Duration should not be more than 1 D for ${formattedDate}`, {
							duration: 7000
						});
						oControl.setValue(previousEnteredValue);
						return;
					}
				}

				//Update the facing entry (Worst Case)
				oMatrixEntry.updateFacingEntries({
					addNotes: true,
					dateKey: options.columnName,
					notes: currCellEntry.Note,
					customerFacing: currCellEntry.CustomerFacing,
				}, true);

				//IF ENTRY AVAILABLE
				let iEntryIndex = aEntries.findIndex(function (item) {
					return item.MtrUid === currCellEntry.MtrUid;
				});

				//Update the previousDuration, TotalHours for validation and WorkDuration
				if (enteredValue % 1 === 0) {
					enteredValue = enteredValue.toFixed(1);
				} else if (enteredValue % 1 === 0.5) {
					enteredValue = enteredValue.toString();
				}
				options.controlSrc.setValue(enteredValue);
				currCellEntry.WorkDuration = enteredValue;
				currCellEntry.PreviousDuration = enteredValue;
				totalHrsValidation[options.columnName] = currTotalDuration;
				matrixModel.setProperty("/totalHoursValidation", $.extend(true, {}, totalHrsValidation));

				switch (options.entryType) {
					case "NEW":
						currCellEntry.Indicator = "C";
						if (iEntryIndex === -1) {
							aEntries.push(currCellEntry);
						}
						if (iEntryIndex !== -1) {
							aEntries[iEntryIndex] = currCellEntry;
						}
						this.updateTaskTypeData(currCellEntry);
						break;
					case "EXISTING":
						if (iEntryIndex !== -1) {
							currCellEntry.Indicator = "U";
							aEntries[iEntryIndex] = currCellEntry;
						}
						break;
					default:
				}

				oDayWeekTimesheetModel.setProperty("/Entries", aEntries);
				oDayWeekTimesheetModel.refresh();
				matrixModel.refresh();
			} catch (error) {
				console.log("ERROR IN _onChangeDuration : ", error);
			}
		},

		updateTaskTypeData: async function (currCellEntry) {
			let oActivity = {
				"ActivityId": currCellEntry.ActvtId,
				"ActAsstId": (currCellEntry.ActAsstId) ? currCellEntry.ActAsstId : currCellEntry.CostTypeId === "1" ?
					"502" : (currCellEntry.CostTypeId === "4") ?
						"501" : "503"
			};
			let aFilteredTasktypes = [];
			let taskTypeMap = this.getModel("matrixModel").getProperty("/TaskTypeMap") || {};
			let taskTypeProp = oActivity.ActivityId + oActivity.ActAsstId;
			if (!taskTypeMap[taskTypeProp]) {
				aFilteredTasktypes = await MTRHelper.filterMtrTasks(oActivity, true) || [];
				taskTypeMap[taskTypeProp] = aFilteredTasktypes;
				this.getModel("matrixModel").setProperty("/TaskTypeMap", taskTypeMap);
			} else {
				aFilteredTasktypes = taskTypeMap[taskTypeProp];
			}
			const sMpngAttrVal = currCellEntry.CustomerFacing ? "1" : "2";
			if (aFilteredTasktypes.length === 1) {
				const oMtrTask = aFilteredTasktypes[0];
				currCellEntry.TaskId = oMtrTask.MtrTaskID;
				currCellEntry.TaskName = oMtrTask.MtrTaskName;
			} else {
				const oMtrTask = aFilteredTasktypes.find(item => item.MpngAttrVal === sMpngAttrVal);
				if (oMtrTask) {
					currCellEntry.TaskId = oMtrTask.MtrTaskID;
					currCellEntry.TaskName = oMtrTask.MtrTaskName;
				}
			}
		},

		/**
		 * Method for calculating total duration of all entries in a day.
		 * @private
		 * @param {string} date for which entries duration nedds to calculate.
		 * @returns {number}
		 * //TODO CHECK AND REMOVE
		 */
		_calculateTimeInDay: function (options = {}) {
			let currCellEntry = options.entry;
			const matrixModel = this.getModel("matrixModel");
			let oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			let aMatrixData = matrixModel.getProperty(`/${options.refDataFrm}`) || [];
			let aColumnEntries = this.getColumndataFromMatrix(aMatrixData, options.columnName, currCellEntry.MtrUid);
			const TotalDuration = aColumnEntries.reduce((totalDuration, entry) => {
				const value = entry.WorkDuration ? parseFloat(entry.WorkDuration) : 0;
				const workDuration = (isNaN(value)) ? 0 : value;
				return totalDuration + workDuration;
			}, 0);
			return {
				currTotalDuration: TotalDuration,
				currColumnEntries: aColumnEntries
			};
		},

		//Helper Function to calculate the time duration for a new entry //TODO CHECK AND REMOVE
		getColumndataFromMatrix: function (aMatrixData = [], dateSequence, MtrUid) {
			let aColumnDateEntries = [];
			let matrixModel = this.getModel("matrixModel");
			let selectedCategory = matrixModel.getProperty("/matrixCategory");
			for (let i = 0; i < aMatrixData.length; i++) {
				let matrixEntry = aMatrixData[i];
				if (selectedCategory === Actions.matrixCategory.activity) {
					let oCFData = matrixEntry.customFacing[dateSequence];
					aColumnDateEntries.push(oCFData);
				}
				let oNCFData = matrixEntry.nonCustomFacing[dateSequence];
				aColumnDateEntries.push(oNCFData);

			}
			return aColumnDateEntries;
		},

		//Function to fetch entries based on record date to calculate the work duration (8Hours)
		_fetchEntriesBasedOnRecordDate: function (currEntry) {
			let dayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			let aEntries = dayWeekTimesheetModel.getProperty("/Entries") || [];
			let aDateWiseEntries = aEntries.filter((entry) => entry.RecordDate === currEntry.RecordDate && entry.MtrUid !== currEntry.MtrUid);
			if (aDateWiseEntries.length) {
				const TotalDuration = aDateWiseEntries.reduce((totalDuration, entry) => {
					const value = entry.WorkDuration ? parseFloat(entry.WorkDuration) : 0;
					const workDuration = (isNaN(value)) ? 0 : value;
					return totalDuration + workDuration;
				}, 0);
				return TotalDuration;
			}
			return 0;
		},

		/**
		 * @author DARSHAN
		 * @function fnCheckIsEntryValid
		 * @description function to handle validation for entry for save and submit
		 * @param {Object} oEvent
		 * Update the taskId when there is a change in ID;s from backend or DB
		 */
		fnCheckIsEntryValid: function (aEntries = [], actionType) {
			const matrixModel = this.getModel("matrixModel");
			const aValidLearningTaskId = matrixModel.getProperty("/aValidLearningTaskId") || [];
			const aValidActivityTaskId = matrixModel.getProperty("/aValidActivityTaskId") || [];
			for (let i = 0; i < aEntries.length; i++) {
				let entry = aEntries[i];
				let taskId = (entry.TaskId) ? parseInt(entry.TaskId) : 0;
				let entryDate = oMatrix.dateService.formatStringDate(entry.RecordDate);
				//Learning
				if (aValidLearningTaskId.indexOf(taskId) !== -1) {
					let aValidate = [entry.CostTypeId, entry.CostTypeValue]
					if (aValidate.indexOf("") !== -1) {
						return false;
					}
				}

				//Activity //TODO
				if (aValidLearningTaskId.indexOf(taskId) === -1) {
					let aValidate = [entry.CostTypeId, entry.CostTypeValue]
					if (aValidate.indexOf("") !== -1) {
						return false;
					}
				}
			}
			return true
		},

		/**
		 * @author DARSHAN
		 * @function onMyTimeEntries
		 * @description function to handle navigation to MyEntries Page
		 * @param {Object} oEvent
		 */
		onMyTimeEntries: function (oEvent) {
			let oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
			const hashTarget = oCrossAppNavigator.hrefForExternal({
				target: {
					shellHash: "#pcactivityform-app&/MyEntries",
					action: 'display'
				}
			});
			const url = window.location.href.split('#')[0] + hashTarget;
			sap.m.URLHelper.redirect(url, true);
			/*oCrossAppNavigator.toExternal({
				target: {
					shellHash: "#pcactivityform-app&/MyEntries"
				}
			});*/
		},

		/**
		 * @author DARSHAN
		 * @function onSaveNewEntry
		 * @description function to handle save entries
		 * @param {Object} oEvent
		 */
		onSaveNewEntry: async function (oEvent, selectedCategory) {
			try {
				let validData = true;
				let aEntriesForSave = [];
				const matrixModel = this.getModel("matrixModel");
				const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				const oSettingsModel = MTRModels.getMTRSettingsModel();
				let aEntries = oDayWeekTimesheetModel.getProperty("/Entries") || [];
				// let selectedCategory = matrixModel.getProperty("/matrixCategory");
				aEntriesForSave = aEntries.filter((entry) => {
					return entry.Indicator && entry.DataFrom !== "I" && entry.WorkDuration;
				});

				if (aEntriesForSave.length) {
					validData = this.fnCheckIsEntryValid(aEntriesForSave);
					if (!validData) {
						MessageToast.show("Please check the mandatory fields and try again");
						matrixModel.setProperty("/IsSaveBusy", false);
						matrixModel.refresh();
						return;
					}
					await this.fnPerformSaveEntries(aEntriesForSave, selectedCategory);
				} else {
					MessageToast.show("No entries for save.");
				}
			} catch (error) {
				console.log("ERROR IN onSaveNewEntry : ", error);
			}
		},

		/**
		 * @author DARSHAN
		 * @function fnPerformSaveEntries
		 * @description function to handle save and submit entries
		 * @param {Object} oEvent
		 */
		fnPerformSaveEntries: async function (aEntriesForSave, selectedCategory) {
			const matrixModel = this.getModel("matrixModel");
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			let aEntries = oDayWeekTimesheetModel.getProperty("/Entries") || [];
			let changedCalendarDate = matrixModel.getProperty("/changedCalendarDate");
			const aValidLearningTaskId = matrixModel.getProperty("/aValidLearningTaskId") || [];
			const aValidActivityTaskId = matrixModel.getProperty("/aValidActivityTaskId") || [];
			matrixModel.setProperty("/IsSaveBusy", true);
			MTRUtil.saveEntries(aEntriesForSave).then(async (aResponse) => {
				for (let i = 0; i < aResponse.length; i++) {
					let oResponse = aResponse[i];
					let iIndex = aEntries.findIndex((entry) => entry.MtrUid === oResponse.MtrUid);
					if (iIndex !== -1) {
						let entryDate = oMatrix.dateService.formatStringDate(oResponse.RecordDate);
						entryDate = oMatrix.genericDateFormat.format(entryDate);
						let taskId = (aEntries[iIndex].TaskId) ? parseInt(aEntries[iIndex].TaskId) : 0;
						// aEntries[iIndex].Indicator = oResponse.Indicator;
						aEntries[iIndex].Indicator = "";
						aEntries[iIndex].StatusId = oResponse.StatusId;
						aEntries[iIndex].WorkDuration = oResponse.WorkDuration;
						aEntries[iIndex].Note = oResponse.Note;
						aEntries[iIndex].setRecordDate(entryDate);

						//Check for Task Id: Activity
						if (aValidActivityTaskId.indexOf(taskId) !== -1) {
							aEntries[iIndex].AddCategoryId = "3";
						}

						//Check for Task Id: Learning
						if (aValidLearningTaskId.indexOf(taskId) !== -1) {
							aEntries[iIndex].AddCategoryId = "5";
						}

						//Notification Popover
						const popoverDate = oMatrix.dateService.format(oResponse.Date, "MMMM dd, yyyy");
						const popoverDesc = `${popoverDate} : ${parseFloat(oResponse.WorkDuration, 10)} hours`;
						const oMessage = new Message({
							Type: sap.ui.core.MessageType.Success,
							Title: "Entries Saved Successfully",
							Description: popoverDesc,
							Subtitle: ""
						});
						oMessage.addToMessages(oResponse.MtrUid, aEntries[iIndex].ActivityId, aEntries[iIndex].StatusId);
					}
				}

				this.onMessagePopoverPress();
				oDayWeekTimesheetModel.setProperty("/Entries", aEntries);
				oDayWeekTimesheetModel.refresh(true);
				await this.fnHelpSetMatrixDataAfterSaveSubmit(selectedCategory);
				matrixModel.setProperty("/IsSaveBusy", false);
				matrixModel.refresh();
			});
		},

		/**
		 * @author DARSHAN
		 * @function fnHelpSetMatrixDataAfterSaveSubmit
		 * @description function to set entries in model
		 */
		fnHelpSetMatrixDataAfterSaveSubmit: async function (selectedCategory) {
			this.parentControl.batchIndex = 0;
			this.parentControl.matrixResponse = [];

			const matrixModel = this.getModel("matrixModel");
			const sQurery = matrixModel.getProperty("/sSearchMatrixList");

			let changedCalendarDate = matrixModel.getProperty("/changedCalendarDate");
			let aMatrixData = await oMatrix.seperateEntriesBasedOnDate(changedCalendarDate, true);
			if (selectedCategory === Actions.matrixCategory.activity) {
				matrixModel.setProperty("/matrixActivityData", aMatrixData);
			} else {
				matrixModel.setProperty("/matrixLearningData", aMatrixData);
			}
			if (sQurery) {
				await this.onMatrixListSearch(false, sQurery);
			}
			matrixModel.refresh();
		},

		/**
		 * @author DARSHAN
		 * @function onSubmitNewEntry
		 * @description function to handle save entries
		 * @param {Object} oEvent
		 */
		onSubmitNewEntry: async function (oEvent, selectedCategory) {
			try {
				let validData = true;
				let aEntriesForSave = [];
				let aEntriesForSubmit = [];
				const matrixModel = this.getModel("matrixModel");
				const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				const oSettingsModel = MTRModels.getMTRSettingsModel();
				let aEntries = oDayWeekTimesheetModel.getProperty("/Entries") || [];

				//Separate the entries for save submit
				for (let i = 0; i < aEntries.length; i++) {
					let validForSubmit;
					let entry = aEntries[i];
					if (!entry.WorkDuration) {
						continue;
					}
					let oActivity = ("ActDetails" in entry) ? entry.ActDetails : {};
					let activityId = ("ActivityId" in oActivity) ? oActivity.ActivityId : "";
					if (activityId) {
						validForSubmit = oMatrix.validateDateForSubmit(oActivity.StartDate);
					} else {
						let entryDate = oMatrix.dateService.formatStringDate(entry.RecordDate);
						validForSubmit = oMatrix.validateDateForSubmit(entryDate);
					}

					if (entry.DataFrom !== "I" && entry.StatusId !== "2" && validForSubmit) {
						aEntriesForSubmit.push(entry);
					} else {
						aEntriesForSave.push(entry);
					}
				}

				if (aEntriesForSubmit.length || aEntriesForSave.length) {
					let aPromise = [];
					let validSubmitData = this.fnCheckIsEntryValid(aEntriesForSubmit, "SUBMIT");
					let validSaveData = this.fnCheckIsEntryValid(aEntriesForSave);
					if (!validSubmitData || !validSaveData) {
						MessageToast.show("Please check the mandatory fields and try again");
						matrixModel.setProperty("/IsSubmitBusy", false);
						matrixModel.refresh();
						return;
					}

					if (aEntriesForSave.length) {
						aPromise.push(this.fnPerformSaveEntries(aEntriesForSave, selectedCategory));
					}
					if (aEntriesForSubmit.length) {
						aPromise.push(this.fnPerformSubmitEntries(aEntriesForSubmit, selectedCategory));
					}

					if (aPromise.length) {
						await Promise.all(aPromise);
					}
				}
			} catch (error) {
				console.log("ERROR IN onSubmitNewEntry : ", error);
			}
		},

		/**
		 * @author DARSHAN
		 * @function fnPerformSubmitEntries
		 * @description function to handle submit entries
		 * @param {Object} oEvent
		 */
		fnPerformSubmitEntries: async function (aEntriesForSubmit, selectedCategory) {
			const matrixModel = this.getModel("matrixModel");
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			let aEntries = oDayWeekTimesheetModel.getProperty("/Entries") || [];
			matrixModel.setProperty("/IsSubmitBusy", true);
			MTRUtil.submitEntries(aEntriesForSubmit).then(async (aResponse) => {
				this.onMessagePopoverPress();
				oDayWeekTimesheetModel.refresh(true);
				await this.fnHelpSetMatrixDataAfterSaveSubmit(selectedCategory);
				matrixModel.setProperty("/IsSubmitBusy", false);
				matrixModel.refresh();
			});
		},

		/**
		 * @author DARSHAN
		 * @function onMessagePopoverPress
		 * @description function to handle message popover
		 * @param {Object} oEvent
		 */
		onMessagePopoverPress: function () {
			const oButton = oMatrix.fnGetDialogUsingId("_MatrixTimeRecordingDialog", "matrixMessagePopoverBtn");
			if (oButton) {
				oButton.firePress();
			}
		},

		/**
		 * @author Siddharth S
		 * @function setExistingActivityData
		 * @description function
		 * @param {Object} oEvent
		 */
		setExistingActivityData: async function (initload, path) {
			const matrixModel = this.getModel("matrixModel");
			const aAssociations = matrixModel.getProperty("/registrationTypes");
			if (path) {
				const AssociationId = matrixModel.getProperty(path + "/selectedAssociationId");
				const oAssociation = aAssociations.find(item => item.key === AssociationId);
				let aFilter = [new Filter("ActivtyTypeCatznID", "EQ", "0001"), new Filter("ActvtAsstdID", "EQ",
					oAssociation.ActvtAsstdID), new Filter("operation_status", "EQ",
						true)];
				ActivityService.getActivityTypesForMatrix(aFilter).then(function (results) {
					matrixModel.setProperty(path + "/ActTypesData", JSON.parse(JSON.stringify(results)));
					matrixModel.setProperty("/ActTypes", JSON.parse(JSON.stringify(results)));
				});
				MTRService.getActStatusMasterData().then(function (results) {
					matrixModel.setProperty("/ActStatus", results);
				});
			} else {
				const sActvtAsstdID = matrixModel.getProperty("/filterBarKey") || "";
				let aFilter = [new Filter("ActivtyTypeCatznID", "EQ", "0001"), new Filter("ActvtAsstdID", "EQ",
					sActvtAsstdID), new Filter("operation_status", "EQ",
						true)];
				await ActivityService.getActivityTypesForMatrix(aFilter).then(function (results) {
					if (results.length) {
						results.map(function (element) {
							element.ActivityTypeId = element.ActvtTypeID;
							element.ActTypeDesc = element.ActvtTypeDesc;
						});
					}
					matrixModel.setProperty("/DefaultActTypes", JSON.parse(JSON.stringify(results)));
				});
				await MTRService.getActStatusMasterData().then(function (results) {
					matrixModel.setProperty("/ActStatus", results);
				});
			}
		},

		/**
		 * @author Siddharth S
		 * @function onOpenExistingActivityValueHelpDialog
		 * @description function 
		 * @param {Object} oEvent
		 */
		onOpenExistingActivityValueHelpDialog: function (oEvent, refDataFrm) {
			const matrixModel = this.getModel("matrixModel");
			let i18nModel = new ResourceModel({
				bundleName: "com.melody.lib.i18n.i18n"
			});
			const that = this;
			/*const bindingContext = oEvent.getSource().getBindingContext("matrixModel") || {};
			this.matrixPath = bindingContext.getPath() || "";
			const that = this;
			const matrixEntry = bindingContext.getObject();
			if (!matrixEntry.selectedAssociationId) {
				MessageToast.show("Please select Association.");
				return;
			}*/

			if (!this.pExistingActivityDialog) {
				this.pExistingActivityDialog = Fragment.load({
					id: "matrixActivityRegistrationDialog",
					name: "com.melody.lib.fragments.MTR.Matrix.Actions.ExistingActivityRegistrationDialog",
					controller: this
				});
			}
			this.pExistingActivityDialog.then(function (oDialog) {
				const tableCtrlSrc = that.getTable();
				tableCtrlSrc.setBusy(true);
				that.onReset(false);
				oDialog.setModel(i18nModel, "i18n");
				oEvent.getSource().addDependent(oDialog);
				matrixModel.setProperty("/AssociationColumnFlag", true);
				that.getFilterVarient();
				// that.getFilters(true, false);
				that.getRecentselectedAct();
				oDialog.open();
			});
		},

		/**
		 * @author Siddharth S
		 * @function getAccountName
		 * @description function to call the account service in existing activity dialog to fetch account details
		 * @param {Object} element
		 */
		getAccountName: async function (element) {
			const that = this;
			const matrixModel = that.getModel("matrixModel");
			const aAccounts = matrixModel.getProperty("/aAccounts") || [];
			await OpportunityService.getBusinessPartnerAttribSet(element.AccountId).then(function (oResponse) {

				const aActivities = matrixModel.getProperty("/existingActivities") || [];
				const aMasterExistingActivities = matrixModel.getProperty("/aMasterExistingActivities") || [];

				const iIndex = aActivities.findIndex(item => item.activity_guid === element.activity_guid);
				const iIndexOfMasterData = aMasterExistingActivities.findIndex(item => item.activity_guid === element.activity_guid);
				if (oResponse && oResponse.data) {
					const oAccount = oResponse.data;
					aAccounts.push(oAccount);
					element.AccountName = (oAccount.PARTNER_NAME && oAccount.PARTNER_NAME !== "") ?
						`${oAccount.PARTNER_NAME} (${oAccount.PARTNER})` : `${oAccount.PARTNER} - NA`;
				}
				if (iIndex !== -1) {
					aActivities[iIndex].AccountName = element.AccountName;
				}
				if (iIndexOfMasterData !== -1) {
					aMasterExistingActivities[iIndexOfMasterData].AccountName = element.AccountName;
				}
				matrixModel.setProperty("/aAccounts", aAccounts);
				matrixModel.refresh();
			});
		},

		/**
		 * @author Siddharth S
		 * @function onScroll
		 * @description function to call scroll event when user will scroll the exisitng activity table.
		 * @param {Object} 
		 */
		onScrollExistingActivity: async function (oEvent) {
			const tableCtrlSrc = this.getTable();
			var iCount = tableCtrlSrc.getVisibleRowCount() + oEvent.getParameter("firstVisibleRow");
			const aLength = tableCtrlSrc.getBinding("rows").getLength();
			if (iCount === aLength) {
				setTimeout(() => {
					tableCtrlSrc.setBusy(true);
					this.getFilters(false, true);
				}, 800);
			}
		},

		/**
		 * @author Siddharth S
		 * @function getFilters
		 * @description function creates filter to fetch exisiting activity of user based on selected filtes.
		 * @param {Object} initload, isScroll
		 */
		getFilters: async function (initload, isScroll) {

			const matrixModel = this.getModel("matrixModel");
			// const matrixEntry = matrixModel.getProperty(this.matrixPath);
			let CostTypeValue = "";
			// const AssociationId = matrixEntry.selectedAssociationId;
			const aAssociations = matrixModel.getProperty("/registrationTypes");
			// const oAssociation = aAssociations.find(item => item.key === AssociationId);
			const aMatrixActivityData = matrixModel.getProperty("/matrixActivityData") || [];
			const ActivitiesInMatrixList = matrixModel.getProperty("/ActivitiesInMatrixList") || [];
			const sActvtAsstdID = matrixModel.getProperty("/filterBarKey") || "";
			let addExistingActvtFlag = true;
			/* if (oAssociation) {
			// let AssociationText = `${oAssociation.name}`;
		let aFilters = [new Filter("ActAsstId", "EQ",
				oAssociation.ActvtAsstdID)];
			
	
			if (matrixEntry.selectedAssociationId === "4") {
				CostTypeValue = matrixEntry.activityRegistration.GlobalUltimateID;
				if (CostTypeValue) {
					AssociationText = `${oAssociation.name} ${CostTypeValue}`;
					aFilters.push(new Filter("AccountId", "EQ",
						CostTypeValue))
				}
			}
	
			if (matrixEntry.selectedAssociationId === "1") {
				CostTypeValue = matrixEntry.activityRegistration.OpportunityId;
				if (CostTypeValue) {
					AssociationText = `${oAssociation.name} ${CostTypeValue}`;
					aFilters.push(new Filter("OpportunityId", "EQ",
						CostTypeValue))
				}
			}
			
			if (initload) {
				matrixModel.setProperty("/AssociationText", AssociationText);
			}*/
			let aFilters = [new Filter("ActAsstId", "EQ",
				sActvtAsstdID)];

			const sActTypesForFilter = matrixModel.getProperty("/ActTypesForFilter");
			const sActStatusForFilter = matrixModel.getProperty("/ActStatusForFilter");
			const sGlobalSearchForFilter = matrixModel.getProperty("/GlobalSearchForFilter") || "";
			let dStartOfStartDateRange = matrixModel.getProperty("/StartOfStartDateRange");
			let dEndOfStartDateRange = matrixModel.getProperty("/EndOfStartDateRange");
			let dStartOfEndDateRange = matrixModel.getProperty("/StartOfEndDateRange");
			let dEndOfEndDateRange = matrixModel.getProperty("/EndOfEndDateRange");
			let aSelctedActvtId = matrixModel.getProperty("/selectedActInFilter") || [];
			let aDateFilters = [];
			const tempActivitiesInMatrixList = [];
			if (aSelctedActvtId && aSelctedActvtId.length !== 0) {
				aSelctedActvtId.map(function (element) {
					aFilters.push(new Filter("ActivityId", FilterOperator.Contains, parseInt(element.key).toString()));
				})
			}
			if (sActTypesForFilter && sActTypesForFilter !== "") {
				addExistingActvtFlag = false;
				aFilters.push(new Filter("ActivityTypeId", FilterOperator.Contains, sActTypesForFilter.trim()));
				if (!isScroll && !initload) {
					const matrixActivity = this.getActivitiesFromMatrixList("ActivityTypeId", sActTypesForFilter.trim());
					if (matrixActivity.length) {
						tempActivitiesInMatrixList.push(...matrixActivity);
					}
				}
			}
			if (sActStatusForFilter && sActStatusForFilter !== "") {
				addExistingActvtFlag = false;
				aFilters.push(new Filter("ActStatus", FilterOperator.Contains, sActStatusForFilter));
				if (!isScroll && !initload) {
					const matrixActivity = this.getActivitiesFromMatrixList("ActStatus", sActStatusForFilter);
					if (matrixActivity.length) {
						tempActivitiesInMatrixList.push(...matrixActivity);
					}
				}
			}
			if (dStartOfStartDateRange && dEndOfStartDateRange) {
				addExistingActvtFlag = false;
				const startDateRange = DateService.getInstance().dateRangeFormat(dStartOfStartDateRange, dEndOfStartDateRange);
				aDateFilters.push(new Filter({
					path: "StartDate",
					operator: sap.ui.model.FilterOperator.GE,
					value1: startDateRange.startDate

				}));
				aDateFilters.push(new Filter({
					path: "StartDate",
					operator: sap.ui.model.FilterOperator.LE,
					value1: startDateRange.endDate
				}));
				if (!isScroll && !initload) {
					const matrixActivity = this.getActivitiesFromMatrixList("StartDateRange", dStartOfStartDateRange, dEndOfStartDateRange);
					if (matrixActivity.length) {
						tempActivitiesInMatrixList.push(...matrixActivity);
					}
				}
			}
			if (dStartOfEndDateRange && dEndOfEndDateRange) {
				addExistingActvtFlag = false;
				const endDateRange = DateService.getInstance().dateRangeFormat(dStartOfEndDateRange, dEndOfEndDateRange);
				aDateFilters.push(new Filter({
					path: "EndDate",
					operator: sap.ui.model.FilterOperator.GE,
					value1: endDateRange.startDate

				}));
				aDateFilters.push(new Filter({
					path: "EndDate",
					operator: sap.ui.model.FilterOperator.LE,
					value1: endDateRange.endDate
				}));
			}

			if (aDateFilters && aDateFilters.length) {
				aFilters.push(new Filter({
					filters: aDateFilters,
					and: true
				}));
			}
			let sSearchValue = "";
			if (sActvtAsstdID === "501") { // when Account Name is selected in search dropdawn.
				const selctions = matrixModel.getProperty("/SelectedAccountsInFilter") || [];
				if (selctions && selctions.length) {
					selctions.map(function (element) {
						aFilters.push(new Filter("AccountId", FilterOperator.Contains, element.key));
						if (!isScroll && !initload) {
							const matrixActivity = ActivitiesInMatrixList.filter(function (item) {
								return (item.AccountId === element.key);
							});
							if (matrixActivity.length) {
								tempActivitiesInMatrixList.push(...matrixActivity);
							}
						}
					});
				}

				sSearchValue = "";
			} else if (sActvtAsstdID === "502") { // when Opp Name is selected in search dropdawn.
				const selctions = matrixModel.getProperty("/SelectedOppInFilter") || [];
				if (selctions && selctions.length) {
					selctions.map(function (element) {
						aFilters.push(new Filter("OpportunityId", FilterOperator.Contains, element.key));
						if (!isScroll && !initload) {
							const matrixActivity = ActivitiesInMatrixList.filter(function (item) {
								return (item.OpportunityId === element.key);
							});
							if (matrixActivity.length) {
								tempActivitiesInMatrixList.push(...matrixActivity);
							}
						}
					});
				}
				// aFilters.push(new Filter("OpportunityId", FilterOperator.Contains, sGlobalSearchForFilter));
				sSearchValue = "";
			} else {

				aFilters.push(new Filter("ActSetDesc", FilterOperator.Contains, sGlobalSearchForFilter.trim()));
				sSearchValue = "";
			}
			if (initload && !aMatrixActivityData.length) {
				matrixModel.setProperty("/ServiceCallCount", 2);
			}
			if (aMatrixActivityData.length && (initload || (!isScroll && addExistingActvtFlag === true))
				&& !(aSelctedActvtId && aSelctedActvtId.length > 0)) {
				matrixModel.setProperty("/ServiceCallCount", 1);
				const aSelectedAssociationsActvt = aMatrixActivityData.filter(function (item) {
					return (item.activityRegistration && item.activityRegistration.ActivityId && item.ActAsstId === sActvtAsstdID);
				});
				if (aSelectedAssociationsActvt && aSelectedAssociationsActvt.length) {

					aSelectedAssociationsActvt.map(function (element) {
						aFilters.push(new Filter("ActivityId", FilterOperator.Contains, parseInt(element.activityRegistration.ActivityId).toString()));

					});

				} else {
					matrixModel.setProperty("/ServiceCallCount", 2); //Using for skip top suppose to add or not if 1 no skipt top.
				}
			}
			await this.getExistingActivity(initload, isScroll, aFilters, sGlobalSearchForFilter, tempActivitiesInMatrixList);

			// }
		},

		/**
		 * @author Siddharth S
		 * @function getExistingActivity
		 * @description function call service to fetch Exisitng activity.
		 * @param {Object} initload, isScroll
		 */
		getExistingActivity: async function (initload, isScroll, aFilters, searchFiledValue, tempActivitiesInMatrixList) {
			const tableCtrlSrc = this.getTable();
			try {
				const that = this;
				const matrixModel = this.getModel("matrixModel");
				// const matrixEntry = matrixModel.getProperty(this.matrixPath);
				const oSettingsModel = MTRModels.getMTRSettingsModel();
				const oSetting = oSettingsModel.getData();
				const aOpportunities = oSetting.Opportunities || [];
				const aAccounts = matrixModel.getProperty("/aAccounts") || []; // Account data created in getAccountname function
				const sActvtAsstdID = matrixModel.getProperty("/filterBarKey") || "";
				const aMatrixActivityData = matrixModel.getProperty("/matrixActivityData") || [];
				let newTempExistingActivities = matrixModel.getProperty("/tempExistingActivities") || [];

				const aWithDuplicateExistingActivities = matrixModel.getProperty("/aWithDuplicateExistingActivities") || [];
				let skip = aWithDuplicateExistingActivities.length;

				if (!isScroll) {
					skip = 0;
				}
				let ServiceCallCount = matrixModel.getProperty("/ServiceCallCount");
				ServiceCallCount = (ServiceCallCount) ? ServiceCallCount : 1;
				if (ServiceCallCount === 2) {
					skip = 0;
				}
				let archivedFilter = new Filter({
					path: "IsArchived",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: false
				});
				aFilters.push(archivedFilter);
				MTRService.getMatrixTimeEntryActivitites(aFilters, searchFiledValue, skip, "50", ServiceCallCount).then(async function (results) {

					let aData = [];
					let uniqueArray = [];
					let aExistingRecords = matrixModel.getProperty("/existingActivities") || [];
					// let aRecentSelectedAct = matrixModel.getProperty("/recentSelectedActivities") || [];

					if (results && results.length > 0) {
						ServiceCallCount = ServiceCallCount + 1;
						matrixModel.setProperty("/ServiceCallCount", ServiceCallCount);
						aWithDuplicateExistingActivities.push(...results);
						// console.log("After success Duplicate data- " + aWithDuplicateExistingActivities.length + skip);
						matrixModel.setProperty("/aWithDuplicateExistingActivities", aWithDuplicateExistingActivities);
						aData = $.extend(true, [], results);
						if (tempActivitiesInMatrixList.length && (!initload && !isScroll)) {
							aData.push(...tempActivitiesInMatrixList);
						}
						aData = Array.from(new Map(aData.map(item => [item.activity_guid, item])).values());
						for (let i = 0; i < aData.length; i++) {
							const element = aData[i];
							// To check Activity already present or not.
							const oDuplicateRecord = aExistingRecords.find(item => item.activity_guid === element.activity_guid);
							if (!oDuplicateRecord) {
								const iTempActVtIndex = newTempExistingActivities.findIndex(item => item.ActivityId === element.ActivityId);

								if (element.ActAsstId === "502") {
									const oMatrixData = aMatrixActivityData.find(item => item.activityRegistration && item.activityRegistration.ActivityId &&
										parseInt(item.activityRegistration.ActivityId).toString() === parseInt(element.ActivityId).toString() && parseInt(item.activityRegistration
											.OpportunityId).toString() === parseInt(element.OpportunityId).toString());
									element.IsEditable = (oMatrixData && !oMatrixData.IsRecntSelect) ? false : true;

									const oOpportunity = aOpportunities.find(item => item.OpportunityID === element.OpportunityId);
									element.OpportunityName = (oOpportunity) ? `${oOpportunity.OpportunityName} (${element.OpportunityId})` :
										`${element.OpportunityId} - NA`;
									element.AccountName = (oOpportunity) ? `${oOpportunity.AccountName} (${element.AccountId})` : `${element.AccountId} - NA`;
								} else if (element.ActAsstId === "501") {
									const oMatrixData = aMatrixActivityData.find(item => item.activityRegistration && item.activityRegistration.ActivityId &&
										parseInt(item.activityRegistration.ActivityId).toString() === parseInt(element.ActivityId).toString() && parseInt(item.activityRegistration
											.GlobalUltimateID).toString() === parseInt(element.AccountId).toString());
									element.IsEditable = (oMatrixData && !oMatrixData.IsRecntSelect) ? false : true;

									element.OpportunityName = "NA";
									const oAccountInOpportunity = aOpportunities.find(item => item.AccountID === element.AccountId);
									if (oAccountInOpportunity) {
										element.AccountName = (oAccountInOpportunity.AccountName && oAccountInOpportunity.AccountName !== "") ?
											`${oAccountInOpportunity.AccountName} (${oAccountInOpportunity.AccountID})` : `${element.AccountId} - NA`;
									} else {
										const oAccount = aAccounts.find(item => item.PARTNER === element.AccountId);
										if (oAccount) {
											element.AccountName = (oAccount.PARTNER_NAME && oAccount.PARTNER_NAME !== "") ?
												`${oAccount.PARTNER_NAME} (${oAccount.PARTNER})` : `${element.AccountId} - NA`;
										} else {
											let isOppoMetadataLoaded = OpportunityService.models.harmony.getServiceMetadata();
											if (isOppoMetadataLoaded) {
												await that.getAccountName(element); // service to fetch account based on account ID.
											}
										}
									}
								} else {
									// matrixModel.setProperty("/AssociationColumnFlag", false);
									const oMatrixData = aMatrixActivityData.find(item => item.activityRegistration && item.activityRegistration.ActivityId &&
										parseInt(item.activityRegistration.ActivityId).toString() === parseInt(element.ActivityId).toString());
									element.IsEditable = (oMatrixData && !oMatrixData.IsRecntSelect) ? false : true;

									element.OpportunityName = matrixModel.getProperty("/AssociationText");
									element.AccountName = matrixModel.getProperty("/AssociationText");
									element.ActSetDesc = (element.ActSetDesc) ? element.ActSetDesc : "NA";
								}
								const bAssociationFlag = (sActvtAsstdID && sActvtAsstdID === "503") ? false : true;
								matrixModel.setProperty("/AssociationColumnFlag", bAssociationFlag);
								element.IsSelected = (iTempActVtIndex !== -1 || !element.IsEditable) ? true : false;

								// if (!element.IsRecntSelect) {
								aExistingRecords.push(element);
								// }
							}
						}
						if (initload) {
							uniqueArray = Array.from(new Map(aData.map(item => [item.ActivityTypeId, item])).values());
							const aDefaultActTypes = matrixModel.getProperty("/DefaultActTypes") || [];
							if (uniqueArray && uniqueArray.length) {
								uniqueArray.map(function (element) {
									const oActivity = aDefaultActTypes.find(item => item.ActivityTypeId === element.ActivityTypeId);
									if (!oActivity && element.ActivityTypeId) {
										// element.ActivityTypeId = element.ActvtTypeID;
										// element.ActTypeDesc = element.ActvtTypeDesc;
										aDefaultActTypes.push(element);
									}
								});
							}
							matrixModel.setProperty("/ExistingActTypes", JSON.parse(JSON.stringify(aDefaultActTypes)));
							matrixModel.setProperty("/ActivitiesInMatrixList", $.extend(true, [], aExistingRecords));
							matrixModel.setProperty("/aWithDuplicateExistingActivities", []);
						}

					}
					matrixModel.setProperty("/tempExistingActivities", newTempExistingActivities);
					matrixModel.setProperty("/existingActivities", $.extend(true, [], aExistingRecords));
					matrixModel.setProperty("/existingActivitiesCount", aExistingRecords.length);
					let aFilteredRows = that.getFilterRows();
					matrixModel.setProperty("/aFilteredRows", aFilteredRows);
					matrixModel.setProperty(`/validateTableSelection`, Math.random());
					matrixModel.refresh();
					if (results && results.length > 0 && aFilteredRows && aFilteredRows.length <= tableCtrlSrc.getVisibleRowCount()) {
						tableCtrlSrc.setBusy(true);
						that.getFilters(false, true);
					} else if (initload && aFilteredRows && aFilteredRows.length === 0) {
						tableCtrlSrc.setBusy(true);
						that.getFilters(false, true);
					}
					that.pExistingActivityDialog.then((oDialog) => {
						oDialog.setBusy(false);
						tableCtrlSrc.setBusy(false);
					});
				});
			} catch (error) {
				console.log("ERRRO IN getExistingActivity : ", error);
				tableCtrlSrc.setBusy(false);
			}
		},
		/**
		 * @author Siddharth S
		 * @function getRecentselectedAct
		 * @description function call service to fetch 5 Recent selectetd activities from Exisitng activity.
		 * @param {Object}
		 */
		getRecentselectedAct: async function () {
			const that = this;
			const matrixModel = this.getModel("matrixModel");
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const oSetting = oSettingsModel.getData();
			const aOpportunities = oSetting.Opportunities || [];
			const aAccounts = matrixModel.getProperty("/aAccounts") || []; // Account data created in getAccountname function
			const sActvtAsstdID = matrixModel.getProperty("/filterBarKey") || "";
			const aMatrixActivityData = matrixModel.getProperty("/matrixActivityData") || [];
			let newTempExistingActivities = matrixModel.getProperty("/tempExistingActivities") || [];
			// let aFilters = [new Filter("IsRecntSelect", "EQ",
			// 	"X")];

			let aFilters = [];
			let archivedFilter = new Filter({
				path: "IsArchived",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: false
			});
			aFilters.push(archivedFilter);
			let recentFilter = new Filter({
				path: "IsRecntSelect",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: "X"
			});
			aFilters.push(recentFilter);
			MTRService.getMatrixTimeEntryActivitites(aFilters).then(async function (aData) {

				const uniqueArray = Array.from(new Map(aData.map(item => [item.activity_guid, item])).values());
				for (let i = 0; i < uniqueArray.length; i++) {
					const element = uniqueArray[i];
					// To check Activity already present or not.
					const iTempActVtIndex = newTempExistingActivities.findIndex(item => item.ActivityId === element.ActivityId);
					let isRecentlySelectedFlg = false;
					if (element.ActAsstId === "502") {
						const oMatrixData = aMatrixActivityData.find(item => item.activityRegistration && item.activityRegistration.ActivityId &&
							parseInt(item.activityRegistration.ActivityId).toString() === parseInt(element.ActivityId).toString() && parseInt(item.activityRegistration
								.OpportunityId).toString() === parseInt(element.OpportunityId).toString());
						element.IsEditable = (oMatrixData && !oMatrixData.IsRecntSelect) ? false : true;
						element.IsRecntSelect = (oMatrixData && oMatrixData.IsRecntSelect && oMatrixData.IsRecntSelect.toUpperCase() === "X") ? "X" :
							element.IsRecntSelect;
						isRecentlySelectedFlg = (oMatrixData && oMatrixData.IsRecntSelect && oMatrixData.IsRecntSelect.toUpperCase() === "X") ? true :
							false;
						const oOpportunity = aOpportunities.find(item => item.OpportunityID === element.OpportunityId);
						element.OpportunityName = (oOpportunity) ? `${oOpportunity.OpportunityName} (${element.OpportunityId})` :
							`${element.OpportunityId} - NA`;
						element.AccountName = (oOpportunity) ? `${oOpportunity.AccountName} (${element.AccountId})` : `${element.AccountId} - NA`;
						element.ActSetDesc = "NA";
					} else if (element.ActAsstId === "501") {
						const oMatrixData = aMatrixActivityData.find(item => item.activityRegistration && item.activityRegistration.ActivityId &&
							parseInt(item.activityRegistration.ActivityId).toString() === parseInt(element.ActivityId).toString() && parseInt(item.activityRegistration
								.GlobalUltimateID).toString() === parseInt(element.AccountId).toString());
						element.IsEditable = (oMatrixData && !oMatrixData.IsRecntSelect) ? false : true;
						element.IsRecntSelect = (oMatrixData && oMatrixData.IsRecntSelect && oMatrixData.IsRecntSelect.toUpperCase() === "X") ? "X" :
							element.IsRecntSelect;
						isRecentlySelectedFlg = (oMatrixData && oMatrixData.IsRecntSelect && oMatrixData.IsRecntSelect.toUpperCase() === "X") ? true :
							false;
						element.OpportunityName = "NA";
						element.ActSetDesc = "NA";
						const oAccountInOpportunity = aOpportunities.find(item => item.AccountID === element.AccountId);
						if (oAccountInOpportunity) {
							element.AccountName = (oAccountInOpportunity.AccountName && oAccountInOpportunity.AccountName !== "") ?
								`${oAccountInOpportunity.AccountName} (${oAccountInOpportunity.AccountID})` : `${element.AccountId} - NA`;
						} else {
							const oAccount = aAccounts.find(item => item.PARTNER === element.AccountId);
							if (oAccount) {
								element.AccountName = (oAccount.PARTNER_NAME && oAccount.PARTNER_NAME !== "") ?
									`${oAccount.PARTNER_NAME} (${oAccount.PARTNER})` : `${element.AccountId} - NA`;
							} else {
								let isOppoMetadataLoaded = OpportunityService.models.harmony.getServiceMetadata();
								if (isOppoMetadataLoaded) {
									await that.getAccountName(element); // service to fetch account based on account ID.
								}
							}
						}
					} else {
						// matrixModel.setProperty("/AssociationColumnFlag", false);
						const oMatrixData = aMatrixActivityData.find(item => item.activityRegistration && item.activityRegistration.ActivityId &&
							parseInt(item.activityRegistration.ActivityId).toString() === parseInt(element.ActivityId).toString());
						element.IsEditable = (oMatrixData && !oMatrixData.IsRecntSelect) ? false : true;
						element.IsRecntSelect = (oMatrixData && oMatrixData.IsRecntSelect && oMatrixData.IsRecntSelect.toUpperCase() === "X") ? "X" :
							element.IsRecntSelect;
						isRecentlySelectedFlg = (oMatrixData && oMatrixData.IsRecntSelect && oMatrixData.IsRecntSelect.toUpperCase() === "X") ? true :
							false;
						element.OpportunityName = matrixModel.getProperty("/AssociationText");
						element.AccountName = matrixModel.getProperty("/AssociationText");
						element.ActSetDesc = (element.ActSetDesc) ? element.ActSetDesc : "NA";
						element.AccountName = "NA";
						element.OpportunityName = "NA";
					}
					element.IsSelected = (iTempActVtIndex !== -1 || !element.IsEditable) ? true : false;
					/*if (isRecentlySelectedFlg) {
						newTempExistingActivities.push(JSON.parse(JSON.stringify(element)));
						element.IsSelected = true;
						element.IsEditable = true;
						matrixModel.setProperty("/tempExistingActivities", newTempExistingActivities)
					}*/

				}
				matrixModel.setProperty("/recentSelectedActivities", $.extend(true, [], uniqueArray));
				// that.getFilters(true, false);
			});
		},
		/**
		 * @author Siddharth S
		 * @function saveFilterVarient
		 * @description function call service to save filters which applied in exisitng activity dialog
		 * @param {Object}
		 */
		saveFilterVarient: async function (aFilters) {

			const oThisController = this;
			const matrixModel = this.getModel("matrixModel");
			const sVariantid = matrixModel.getProperty("/variantid");
			const sActvtAsstdID = matrixModel.getProperty("/filterBarKey") || "";
			const sActTypesForFilter = matrixModel.getProperty("/ActTypesForFilter");
			const sActStatusForFilter = matrixModel.getProperty("/ActStatusForFilter");
			const sGlobalSearchForFilter = matrixModel.getProperty("/GlobalSearchForFilter") || "";
			let dStartOfStartDateRange = matrixModel.getProperty("/StartOfStartDateRange");
			let dEndOfStartDateRange = matrixModel.getProperty("/EndOfStartDateRange");
			let dStartOfEndDateRange = matrixModel.getProperty("/StartOfEndDateRange");
			let dEndOfEndDateRange = matrixModel.getProperty("/EndOfEndDateRange");
			const aAccounts = matrixModel.getProperty("/SelectedAccountsInFilter") || [];
			const aOpp = matrixModel.getProperty("/SelectedOppInFilter") || [];
			const aAccountId = [];
			const aOppId = [];
			if (aAccounts && aAccounts.length) {
				aAccounts.map(function (element) {
					aAccountId.push(element.key);
				});
			}
			if (aOpp && aOpp.length) {
				aOpp.map(function (element) {
					aOppId.push(element.key);
				});
			}
			let oFilterData = {
				ActAsstId: sActvtAsstdID,
				ActivityTypeId: sActTypesForFilter,
				ActStatus: sActStatusForFilter,
				StartDateFrom: dStartOfStartDateRange,
				StartDateTo: dEndOfStartDateRange,
				EndDateFrom: dEndOfStartDateRange,
				EndDateTo: dEndOfEndDateRange,
				AccountId: aAccountId.toLocaleString(),
				OpportunityId: aOppId.toLocaleString(),
				ActSetDesc: sGlobalSearchForFilter,
			};
			let oUserModel = sap.ui.getCore().getModel("userUtility"); // TODO:CHECK THIS LINE (TAKEN FROM LIBRARY)
			let userData = oUserModel.getProperty("/") || {};
			let oData = {
				variantid: (sVariantid) ? sVariantid : "",
				variant_name: "Filter Variant",
				author: (userData) ? userData.UserId : "",
				type: "P",
				filterstring: JSON.stringify(oFilterData),
				applicationid: "EXMAT",
				operationflag: false
			};
			MTRService.saveDefaultFilter(oData).then((oResponse) => {
				let {
					data
				} = oResponse
				// oThisController.fnSetUserFilterVariant(data);
			}).catch((oError) => {
				sap.m.MessageBox.error("Error in saving Filter variant");
			});
		},
		/**
		 * @author Siddharth S
		 * @function getFilterVarient
		 * @description function call service to fetch filters which was applied previously in exisitng activity dialog
		 * @param {Object}
		 */
		getFilterVarient: function () {

			const oThisController = this;
			MTRService.getDefaultFilter().then((oResponse) => {
				let {
					data
				} = oResponse
				oThisController.fnSetUserFilterVariant(data);
			}).catch((oError) => {
				sap.m.MessageBox.error("Error in saving Filter variant");
			});
		},
		fnSetUserFilterVariant: async function (oResponse) {

			const matrixModel = this.getModel("matrixModel");
			let oData = "";
			if (oResponse.hasOwnProperty("results")) {
				oData = oResponse.results[0];
			} else {
				oData = oResponse;
			}
			if (!oData) {
				matrixModel.setProperty("/variantid", "");
				matrixModel.setProperty("/filterBarKey", "502");
				matrixModel.setProperty("/ActTypesForFilter", "");
				matrixModel.setProperty("/ActStatusForFilter", "");
				matrixModel.setProperty("/GlobalSearchForFilter", "");
				matrixModel.setProperty("/StartOfStartDateRange", null);
				matrixModel.setProperty("/EndOfStartDateRange", null);
				matrixModel.setProperty("/StartOfEndDateRange", null);
				matrixModel.setProperty("/EndOfEndDateRange", null);
				matrixModel.setProperty("/SelectedAccountsInFilter", []);
				matrixModel.setProperty("/SelectedOppInFilter", []);
				matrixModel.setProperty("/selectedActInFilter", []);
			} else {
				const oSettingsModel = MTRModels.getMTRSettingsModel();
				const oSetting = oSettingsModel.getData();
				const aOpportunities = oSetting.Opportunities || [];
				const aAccounts = matrixModel.getProperty("/aAccounts") || [];
				matrixModel.setProperty("/variantid", oData.variantid);
				if (oData.filterstring) {
					const oFilterData = JSON.parse(oData.filterstring);
					const ActAsstId = oFilterData.ActAsstId || "";
					matrixModel.setProperty("/filterBarKey", ActAsstId);
					const ActivityTypeId = oFilterData.ActivityTypeId || "";
					matrixModel.setProperty("/ActTypesForFilter", ActivityTypeId);
					const ActStatus = oFilterData.ActStatus || "";
					matrixModel.setProperty("/ActStatusForFilter", ActStatus);
					const ActSetDesc = oFilterData.ActSetDesc || "";
					matrixModel.setProperty("/GlobalSearchForFilter", ActSetDesc);
					const StartDateFrom = (oFilterData.StartDateFrom) ? new Date(new Date(oFilterData.StartDateFrom).setHours(0, 0, 0)) : null;
					matrixModel.setProperty("/StartOfStartDateRange", StartDateFrom);
					const StartDateTo = (oFilterData.StartDateTo) ? new Date(new Date(oFilterData.StartDateTo).setHours(0, 0, 0)) : null;

					matrixModel.setProperty("/EndOfStartDateRange", StartDateTo);
					const EndDateFrom = (oFilterData.EndDateFrom) ? new Date(new Date(oFilterData.EndDateFrom).setHours(0, 0, 0)) : null;

					matrixModel.setProperty("/StartOfEndDateRange", EndDateFrom);
					const EndDateTo = (oFilterData.EndDateTo) ? new Date(new Date(oFilterData.EndDateTo).setHours(0, 0, 0)) : null;

					matrixModel.setProperty("/EndOfEndDateRange", EndDateTo);
					let aOppId = oFilterData.OpportunityId || "";
					const aOppToken = [];
					if (aOppId) {
						aOppId = aOppId.split(",");
						aOppId.map(function (element) {
							const oOpportunity = aOpportunities.find(item => item.OpportunityID === element);
							if (oOpportunity) {
								aOppToken.push({
									key: oOpportunity.OpportunityID,
									text: oOpportunity.OpportunityName
								});
							}
						});
					}
					matrixModel.setProperty("/SelectedOppInFilter", aOppToken);
					let aAccountId = oFilterData.AccountId || "";
					const aAccToken = [];
					if (aAccountId) {
						aAccountId = aAccountId.split(",");
						aAccountId.map(async function (element) {
							const oAccountInOpportunity = aOpportunities.find(item => item.AccountID === element.AccountId);
							if (oAccountInOpportunity) {
								aAccToken.push({
									key: oAccountInOpportunity.AccountID,
									text: oAccountInOpportunity.AccountName
								});
							} else {
								const oAccount = aAccounts.find(item => item.PARTNER === element.AccountId);
								if (oAccount) {
									aAccToken.push({
										key: oAccount.PARTNER,
										text: oAccount.PARTNER_NAME
									});
								} else {
									await OpportunityService.getBusinessPartnerAttribSet(element).then(function (oResponse) {
										if (oResponse && oResponse.data) {
											const oAccount = oResponse.data;
											aAccounts.push(oAccount);
											aAccToken.push({
												key: oAccount.PARTNER,
												text: oAccount.PARTNER_NAME
											});
										}
										matrixModel.setProperty("/aAccounts", aAccounts);
									});
								}
							}
						});
					}
					matrixModel.setProperty("/SelectedAccountsInFilter", aAccToken);
				}
			}
			await this.setExistingActivityData();
			this.getFilters(true, false);
		},
		/**
		 * @author Siddharth S
		 * @function getActivitiesFromMatrixList
		 * @description function call service to fetch Exisitng activity.
		 * @param {Object} initload, isScroll
		 */
		getActivitiesFromMatrixList: function (field, searchValue1, searchValue2) {
			const matrixModel = this.getModel("matrixModel");
			const ActivitiesInMatrixList = matrixModel.getProperty("/ActivitiesInMatrixList") || [];
			let aActivities = [];
			if (field === "ActivityTypeId") {
				aActivities = ActivitiesInMatrixList.filter(function (item) {
					return (item.ActivityTypeId === searchValue1.trim());
				});
			} else if (field === "ActStatus") {
				aActivities = ActivitiesInMatrixList.filter(function (item) {
					return (item.ActStatus === searchValue1);
				});
			} else if (field === "StartDateRange") {
				aActivities = ActivitiesInMatrixList.filter(function (item) {
					const newDate = new Date(new Date(item.StartDate).setHours(0, 0, 0));
					const dStarteDate = new Date(new Date(searchValue1).setHours(0, 0, 0));
					const dEndDate = new Date(new Date(searchValue2).setHours(0, 0, 0));
					return (newDate.getTime() >= dStarteDate.getTime() && newDate.getTime() <= dEndDate.getTime());
				});
			} else if (field === "EndDateRange") {
				aActivities = ActivitiesInMatrixList.filter(function (item) {
					const newDate = new Date(new Date(item.EndDate).setHours(0, 0, 0));
					const dStarteDate = new Date(new Date(searchValue1).setHours(0, 0, 0));
					const dEndDate = new Date(new Date(searchValue2).setHours(0, 0, 0));
					return (newDate.getTime() >= dStarteDate.getTime() && newDate.getTime() <= dEndDate.getTime());
				});
			}
			return aActivities;
		},

		/**
		 * @author Siddharth S
		 * @function onReset
		 * @description function to handle reset of filters
		 * @param {Object} oEvent
		 */
		onReset: function (oEvent) {
			const matrixModel = this.getModel("matrixModel");
			matrixModel.setProperty("/ActTypesForFilter", "");
			matrixModel.setProperty("/ActStatusForFilter", "");
			matrixModel.setProperty("/StartOfStartDateRange", null);
			matrixModel.setProperty("/EndOfStartDateRange", null);
			matrixModel.setProperty("/StartOfEndDateRange", null);
			matrixModel.setProperty("/EndOfEndDateRange", null);
			matrixModel.setProperty("/GlobalSearchForFilter", "");
			matrixModel.setProperty("/existingActivities", []);
			matrixModel.setProperty("/aWithDuplicateExistingActivities", []);
			matrixModel.setProperty("/SelectedAccountsInFilter", []);
			matrixModel.setProperty("/SelectedOppInFilter", []);
			matrixModel.setProperty("/ServiceCallCount", 1);
			matrixModel.setProperty("/tempExistingActivities", []);
			matrixModel.setProperty("/ActivitiesInMatrixList", []);
			matrixModel.setProperty("/filterBarKey", "502");
			matrixModel.setProperty("/selectedActInFilter", []);
			matrixModel.setProperty("/TempSelectedActInFilter", [])
			if (oEvent) {
				this.getFilters(true);
			}
		},

		/**
		 * @author Siddharth S, DARSHAN
		 * @function onConfirmActivityRegistration
		 * @description on ok press to add data in existing activity input box from Select Existing Activity Registrations dialog
		 * @param {Object} oEvent
		 */
		onConfirmActivityRegistration: async function (event, refDataFrm) {
			try {
				// let path = this.matrixPath || "";

				const oThisController = this;
				let bAddNewRow = false;
				let bRestFirstRow = false;
				const matrixModel = this.getModel("matrixModel");
				matrixModel.setProperty("/sSearchMatrixList", "");
				//	await this.onMatrixListSearch(false, "");
				const aTempExistingActivities = matrixModel.getProperty("/tempExistingActivities") || [];
				let selectedCategory = matrixModel.getProperty("/matrixCategory");
				let aSearchBarMenu = matrixModel.getProperty("/SearchBarMenu");
				if (aTempExistingActivities && aTempExistingActivities.length) {
					let aMatrixDrafts = [];
					let newMatrixEntry = [];
					// let matrixEntry = matrixModel.getProperty(path);
					// const selectedActivity = aTempExistingActivities.find(item => item.ActivityId === matrixEntry.ActvtId);
					let isOldActivity = false;
					// if (selectedActivity) {
					// 	isOldActivity = true;
					// }
					let isSelelctedPathValueSet = false;
					for (let i = 0; i < aTempExistingActivities.length; i++) {
						const element = aTempExistingActivities[i];
						const activityId = parseInt(element.ActivityId);
						element.CostTypeValue = ("OpportunityId" in element && element.OpportunityId) ? element.OpportunityId : element.AccountId;
						element.selectedAssociationValue = ("OpportunityId" in element && element.OpportunityId) ? element.OpportunityId : element.AccountId;
						/*if (activityId === parseInt(matrixEntry.ActvtId) || !matrixEntry.activityDescription) {
							matrixEntry = this.fnSetAssociationValueToMatrix(matrixEntry, element);
							matrixEntry.CostTypeId = matrixEntry.selectedAssociationId;
							matrixEntry.updateMatrixDataFromRegTable(element);
							matrixEntry.updateFacingEntries();
							matrixEntry.checkAndUpdateDayWeekEntries();
							matrixEntry.visible.deleteicon = true;
							matrixEntry.validateRegisterBtn = Math.random(); //TO TRIGGER FORMATER
							matrixModel.setProperty(path, matrixEntry);
							aMatrixDrafts.push(matrixEntry);
							bAddNewRow = true;
						} else {*/ // New Row
						const sSelectedAssociationId = aSearchBarMenu.find(item => element.ActAsstId === item.ActvtAsstdID);
						// let oExistingMatrixEntry = $.extend(true, {}, matrixModel.getProperty(path));
						let oExistingMatrixEntry = {};
						oExistingMatrixEntry.ActvtId = "";
						let oMatrixEntry = new Matrix(oExistingMatrixEntry);
						oMatrixEntry.IsRecntSelect = "";
						oMatrixEntry.ActvtId = activityId;
						oMatrixEntry = this.fnSetAssociationValueToMatrix(oMatrixEntry, element);
						oMatrixEntry.ActTypeDesc = element.ActTypeDesc;
						oMatrixEntry.CostTypeValue = element.CostTypeValue;
						oMatrixEntry.CostTypeId = (sSelectedAssociationId) ? sSelectedAssociationId.key : ""; // matrixEntry.selectedAssociationId;
						oMatrixEntry.selectedAssociationId = (sSelectedAssociationId) ? sSelectedAssociationId.key : "" //matrixEntry.selectedAssociationId;
						oMatrixEntry.updateMatrixDataFromRegTable(element);
						oMatrixEntry.ActAsstId = element.ActAsstId;
						await oMatrixEntry.setCostTypeName();
						oMatrixEntry.selectedActivityType = oMatrixEntry.activityRegistration.ActivityTypeId;
						oMatrixEntry.validateRegisterBtn = Math.random(); //TO TRIGGER FORMATER
						newMatrixEntry.push(oMatrixEntry);
						bRestFirstRow = true;
						// }
					}
					// clear the search and reset the matrix list.

					this.onCancelExistingActivity();

					matrixModel.setProperty("/aMatrixDrafts", aMatrixDrafts); //Drafts

					// let selectedIndex = Number(path.split("/")[2]);
					let bCompleted = await this.handleAdditionOfMatixEntries({
						// insertAt: selectedIndex + 1,
						insertAt: 0,
						aEntriesToBeInserted: newMatrixEntry,
						view: selectedCategory,
						operationType: "EXISTINGACTVT"
					});

					//In-Order to keep first row as always register
					if (bCompleted && bAddNewRow && !bRestFirstRow) {
						let aMatrixActivityData = $.extend(true, [], matrixModel.getProperty("/matrixActivityData"));
						let oMatrixEntryConfig = oMatrix.fnSetUpdateCreateMatrix(aMatrixActivityData);
						if (bAddNewRow) {
							aMatrixActivityData = oMatrixEntryConfig.aMatrixData;
						} else {
							aMatrixActivityData[0] = oMatrixEntryConfig.oNewMatrixEntry;
						}
						matrixModel.setProperty("/matrixActivityData", []);
						this.fnInsertDataUsingBatch(aMatrixActivityData);
						matrixModel.refresh();
					}

					this.saveFilterVarient();
				} else { }

			} catch (error) {
				console.log("ERROR IN onConfirmActivityRegistration : ", error);
			}
		},

		//Helper Function to update Association Value
		fnSetAssociationValueToMatrix: function (matrixEntry, element) {
			//Based on ActAsstId Id set the associationValue
			switch (element.ActAsstId) {
				case "501": //Account
					matrixEntry.selectedAstAccountValue = element.selectedAssociationValue;
					break;
				case "502": //Opportunity
					matrixEntry.selectedAstOpportunityValue = element.selectedAssociationValue;
					break;
				default:
			}
			return matrixEntry;
		},

		/**
		 * @author Siddharth S
		 * @function onCancelExistingActivity
		 * @description function to 
		 * @param {Object} oEvent
		 */
		onCancelExistingActivity: function () {
			this.pExistingActivityDialog.then((oDialog) => {
				oDialog.close();
				oDialog.destroy();
				this.pExistingActivityDialog = null;
			});
		},

		/**
		 * @author Siddharth S
		 * @function onSelectActivity
		 * @description function to select single row from the activity table of Select Existing Activity Registrations dialog
		 * @param {Object} oEvent
		 */
		onSelectActivity: function (oEvent) {
			const oSource = oEvent.getSource();
			const oBinding = oSource.getBindingInfo("selected").binding;
			const oContext = oBinding.getContext();
			const matrixModel = oContext.getModel();
			const path = oContext.getPath();
			const oActivity = matrixModel.getProperty(oContext.getPath());
			const bSelected = oEvent.getParameter("selected");
			const aActivities = matrixModel.getProperty("/tempExistingActivities");
			const iIndex = aActivities.findIndex(item => item.ActivityId === oActivity.ActivityId);
			const aRecentActivities = matrixModel.getProperty("/recentSelectedActivities");
			const iMainActIndex = aRecentActivities.findIndex(item => item.ActivityId === oActivity.ActivityId);
			if (iMainActIndex !== -1) {
				aRecentActivities[iMainActIndex].IsSelected = (bSelected) ? bSelected : false;
			}
			if (bSelected) {
				aActivities.push(oActivity);
			} else if (!bSelected && iIndex !== -1) {
				aActivities.splice(iIndex, 1);
			}
			matrixModel.setProperty("/recentSelectedActivities", aRecentActivities);
			matrixModel.setProperty("/tempExistingActivities", aActivities);
			let aFilteredRows = this.getFilterRows();
			matrixModel.setProperty("/aFilteredRows", aFilteredRows);
			matrixModel.setProperty(`/validateTableSelection`, Math.random());
			matrixModel.refresh();
		},

		/**
		 * @author Siddharth S
		 * @function onSelectAllActivity
		 * @description function to select all rows from the activity table of Select Existing Activity Registrations dialog
		 * @param {Object} oEvent
		 */
		onSelectAllActivity: function (oEvent) {
			const matrixModel = this.getModel("matrixModel");
			const bSelected = oEvent.getParameter("selected");
			let aActivities = matrixModel.getProperty("/existingActivities");
			let aRecentActivities = matrixModel.getProperty("/recentSelectedActivities");
			let aTempExistingActivities = matrixModel.getProperty("/tempExistingActivities") || [];
			const tableCtrlSrc = this.getTable();
			let aFilteredRows = this.getFilterRows();
			aFilteredRows.map(function (element) {
				element.IsSelected = (!element.IsEditable) ? true : bSelected;
				const iIndex = aTempExistingActivities.findIndex(item => item.activity_guid === element.activity_guid);
				if (bSelected && iIndex === -1 && element.IsEditable) {
					aTempExistingActivities.push(element);
				} else if (!bSelected && iIndex !== -1 && element.IsEditable) {
					aTempExistingActivities.splice(iIndex, 1);
				}
				const iRecentActIndex = aRecentActivities.findIndex(item => item.IsEditable && item.activity_guid === element.activity_guid);
				if (iRecentActIndex !== -1) {
					aRecentActivities[iRecentActIndex].IsSelected = element.IsSelected;
				}
			});
			matrixModel.setProperty("/tempExistingActivities", aTempExistingActivities);
			matrixModel.setProperty("/aFilteredRows", aFilteredRows);
			matrixModel.setProperty(`/validateTableSelection`, Math.random());
			matrixModel.refresh();
		},

		onSelectAllRecentActivity: function (oEvent) {

			const matrixModel = this.getModel("matrixModel");
			const bSelected = oEvent.getParameter("selected");
			let aRecentActivities = matrixModel.getProperty("/recentSelectedActivities");
			const aExtActivities = matrixModel.getProperty("/existingActivities");
			let aTempExistingActivities = matrixModel.getProperty("/tempExistingActivities") || [];
			const tableCtrlSrc = this.getTable();
			let aFilteredRows = this.getFilterRows();
			aRecentActivities.map(function (element) {
				element.IsSelected = (!element.IsEditable) ? true : bSelected;
				const iIndex = aTempExistingActivities.findIndex(item => item.activity_guid === element.activity_guid);
				if (bSelected && iIndex === -1 && element.IsEditable) {
					aTempExistingActivities.push(element);
				} else if (!bSelected && iIndex !== -1 && element.IsEditable) {
					aTempExistingActivities.splice(iIndex, 1);
				}
				const iMainActIndex = aExtActivities.findIndex(item => item.IsEditable && item.activity_guid === element.activity_guid);
				if (iMainActIndex !== -1) {
					aExtActivities[iMainActIndex].IsSelected = element.IsSelected;
				}
			});
			matrixModel.setProperty("/existingActivities", aExtActivities);
			matrixModel.setProperty("/tempExistingActivities", aTempExistingActivities);
			matrixModel.setProperty(`/validateTableSelection`, Math.random());
			matrixModel.refresh();

		},
		/**
		 * @author Siddharth S
		 * @function onSelectRecentActivity
		 * @description function to select single row from the Recent selected activity table of Select Existing Activity Registrations dialog
		 * @param {Object} oEvent
		 */
		onSelectRecentActivity: function (oEvent) {
			const oSource = oEvent.getSource();
			const oBinding = oSource.getBindingInfo("selected").binding;
			const oContext = oBinding.getContext();
			const matrixModel = oContext.getModel();
			const path = oContext.getPath();
			const oActivity = matrixModel.getProperty(oContext.getPath());
			const bSelected = oEvent.getParameter("selected");
			const aActivities = matrixModel.getProperty("/tempExistingActivities");
			const iIndex = aActivities.findIndex(item => item.ActivityId === oActivity.ActivityId);
			const aExtActivities = matrixModel.getProperty("/existingActivities");
			const iMainActIndex = aExtActivities.findIndex(item => item.ActivityId === oActivity.ActivityId);
			if (bSelected) {
				aActivities.push(oActivity);
			} else if (!bSelected && iIndex !== -1) {
				aActivities.splice(iIndex, 1);
			}
			if (iMainActIndex !== -1) {
				aExtActivities[iMainActIndex].IsSelected = (bSelected) ? bSelected : false;
			}
			matrixModel.setProperty("/existingActivities", aExtActivities);
			matrixModel.setProperty("/tempExistingActivities", aActivities);
			matrixModel.setProperty(`/validateTableSelection`, Math.random());
			matrixModel.refresh();

		},
		/**
		 * @author Siddharth S
		 * @function onChangeStartDate
		 * @description function to change start date range in filter bar of Select Existing Activity Registrations dialog
		 * @param {Object} oEvent
		 */
		onChangeStartDate: function (oEvent) {
			const matrixModel = this.getModel("matrixModel");
			let dFrom = oEvent.getParameter("from");
			let dEnd = oEvent.getParameter("to");
			matrixModel.setProperty("/StartOfStartDateRange", dFrom);
			matrixModel.setProperty("/EndOfStartDateRange", dEnd);
			// this.onSearchActivities();
		},

		/**
		 * @author Siddharth S
		 * @function onChangeEndDate
		 * @description function to change end date range in filter bar of Select Existing Activity Registrations
		 * @param {Object} oEvent
		 */
		onChangeEndDate: function (oEvent) {
			const matrixModel = this.getModel("matrixModel");
			let dFrom = oEvent.getParameter("from");
			let dEnd = oEvent.getParameter("to");
			matrixModel.setProperty("/StartOfEndDateRange", dFrom);
			matrixModel.setProperty("/EndOfEndDateRange", dEnd);
			// this.onSearchActivities();
		},

		/**
		 * @author Siddharth S
		 * @function onSearchActivities
		 * @description function to search the data from the table of Select Existing Activity Registrations dialog
		 * @param {Object} oEvent
		 * @param {Boolean} initalLoad
		 */
		onSearchActivities: function () {
			const matrixModel = this.getModel("matrixModel");
			matrixModel.setProperty("/existingActivities", []);
			matrixModel.setProperty("/aWithDuplicateExistingActivities", []);
			matrixModel.setProperty("/ServiceCallCount", 2);
			this.getFilters(true, false, true);
		},

		/**
		 * @author Siddharth S
		 * @function getTable
		 * @description function to get the table
		 */
		getTable: function () {
			return this.fnGetDialogUsingId("matrixActivityRegistrationDialog", "existingActivityTblId") || false;
		},

		/**
		 * @author Siddharth S
		 * @function getFilterRows
		 * @description function to get Filter table data
		 */
		getFilterRows: function () {
			const tableCtrlSrc = this.getTable();
			if (!tableCtrlSrc) {
				console.log("ERROR IN LOADING TABLE");
				return;
			}
			let oBinding = tableCtrlSrc.getBinding("rows");
			let aContexts = oBinding.getContexts();
			let aFilteredRows = aContexts.map(function (oContext) {
				return oContext.getObject();
			});
			return aFilteredRows;
		},

		/**
		 * @author Siddharth S
		 * @function onRemoveSelectedActivity
		 * @description function to remove activity from selected list in exisiting activity dialog
		 * @param {Object} oEvent
		 */
		onRemoveSelectedActivity: function (oEvent) { //Siddharth- New Addition
			const type = oEvent.getParameter("type");
			if (type === "removed") {
				const removedTokens = oEvent.getParameter("removedTokens");
				const matrixModel = this.getModel("matrixModel");
				const aTempExistingActivities = matrixModel.getProperty("/tempExistingActivities") || [];
				const aExistingActivities = matrixModel.getProperty("/existingActivities") || [];
				const aRecentSelectedAct = matrixModel.getProperty("/recentSelectedActivities") || [];
				for (let i = 0; i < removedTokens.length; i++) {
					const token = removedTokens[i];
					const iIndex = aTempExistingActivities.findIndex(item => item.activity_guid === token.getKey());
					if (iIndex !== -1) {
						aTempExistingActivities.splice(iIndex, 1);
					}
					const iTableIndex = aExistingActivities.findIndex(item => item.activity_guid === token.getKey());
					if (iIndex !== -1 && iTableIndex !== -1) {
						aExistingActivities[iTableIndex].IsSelected = false;
					}
					const iRecentTableIndex = aRecentSelectedAct.findIndex(item => item.activity_guid === token.getKey());
					if (iIndex !== -1 && iRecentTableIndex !== -1) {
						aRecentSelectedAct[iRecentTableIndex].IsSelected = false;
					}
				}
				matrixModel.setProperty(`/validateTableSelection`, Math.random());
				matrixModel.refresh();
			}
		},

		/**
		 * @author Siddharth S
		 * @function onChangeSearchBarFiled
		 * @description function to select search type from drop dawn in existing activity dialog.
		 * @param {Object} oEvent
		 */
		onChangeSearchBarFiled: async function () {
			const matrixModel = this.getModel("matrixModel");
			// this.topDifference = 0;
			// matrixModel.setProperty("/GlobalSearchForFilter", "");
			matrixModel.setProperty("/AccountForFilter", []);
			matrixModel.setProperty("/SelectedAccountsInFilter", []);
			matrixModel.setProperty("/OpportunityForFilter", []);
			matrixModel.setProperty("/SelectedOppInFilter", []);
			matrixModel.setProperty("/TempSelectedActInFilter", []);
			matrixModel.setProperty("/selectedActInFilter", []);
			// matrixModel.setProperty("/existingActivities", []);
			// matrixModel.setProperty("/recentSelectedActivities", []);
			// matrixModel.setProperty("/aWithDuplicateExistingActivities", []);
			// matrixModel.setProperty("/ServiceCallCount", 2);
			// await this.setExistingActivityData();
			// this.getFilters(true, false);

		},
		/**
		 * @author Siddharth S
		 * @function onSearchAccountNameValueHelpRequest
		 * @description function to select search type from drop dawn in existing activity dialog.
		 * @param {Object} oEvent
		 */
		onSearchAccountNameValueHelpRequest: function (oEvent) {
			let sInputValue = oEvent.getSource().getValue(),
				oView = this.getView();
			const that = this;
			const matrixModel = this.getModel("matrixModel");
			let i18nModel = new ResourceModel({
				bundleName: "com.melody.lib.i18n.i18n"
			});
			if (this._pSearchAccountValueHelpDialog) {
				this._pSearchAccountValueHelpDialog.destroy();
				this._pSearchAccountValueHelpDialog = null;
			}
			if (!this._pSearchAccountValueHelpDialog) {
				this._pSearchAccountValueHelpDialog = Fragment.load({
					id: "matrixAccountFilterDialog",
					name: "com.melody.lib.fragments.MTR.Matrix.Actions.AccountFilterDialog",
					controller: this
				}).then(function (oDialog) {
					oDialog.setModel(matrixModel);
					oDialog.setModel(i18nModel, "i18n");
					return oDialog;
				});
			}
			this._pSearchAccountValueHelpDialog.then(function (oDialog) {
				const SelectedAccountsInFilter = matrixModel.getProperty("/SelectedAccountsInFilter") || [];
				const aSelection = [];
				if (SelectedAccountsInFilter.length) {
					SelectedAccountsInFilter.forEach((element) => {
						aSelection.push({
							key: element.key,
							text: element.text
						});
					});
				}
				matrixModel.setProperty("/TempSelectedAccInFilter", $.extend(true, [], aSelection));
				that.topDifference = 0;
				matrixModel.setProperty("/AccountForFilter", []);
				that._pSearchAccountValueHelpDialog = oDialog;
				// if (sInputValue) {
				// 	that.getAccountList(sInputValue);
				// }
				// Open ValueHelpDialog filtered by the input's value
				oDialog.open(sInputValue);

			});
		},
		/**
		 * @author Siddharth S
		 * @function onSearchAccountList
		 * @description function to search data from table in account select dialog in filter.
		 * @param {Object} oEvent
		 */
		onSearchAccountList: function (oEvent) {
			const sSearchValue = oEvent.getParameter("value");
			const matrixModel = this.getModel("matrixModel");
			matrixModel.setProperty("/AccountForFilter", []);
			const oDialog = this._pSearchAccountValueHelpDialog
			if (sSearchValue) {
				oDialog.setBusy(true);
				// matrixModel.setProperty("/GlobalSearchForFilter", sSearchValue);
				this.getAccountList(sSearchValue);
			} else {
				this.fnForCheckBoxSelection([], oDialog, "account");
			}
		},
		/**
		 * @author Siddharth S
		 * @function onAccSelectionChange
		 * @description function to push selected opportunity in array
		 * @param {Object} oEvent
		 */
		onAccSelectionChange: function (oEvent) {
			const bSelected = oEvent.getParameter("selected");
			const aSelectedItems = oEvent.getParameter("listItems");
			const matrixModel = this.getModel("matrixModel");
			const aTempSelectedAcc = matrixModel.getProperty("/TempSelectedAccInFilter") || [];
			if (aSelectedItems.length) {
				aSelectedItems.map(function (element) {
					const oItem = element.getBindingContext("matrixModel").getObject();
					const iIndex = aTempSelectedAcc.findIndex(item => oItem.AccountId === item.key);
					if (bSelected && iIndex === -1) {
						aTempSelectedAcc.push({
							key: oItem.AccountId,
							text: oItem.AccountName
						});
					} else if (!bSelected && iIndex !== -1) {
						aTempSelectedAcc.splice(iIndex, 1);
					}
				});
			}
			matrixModel.setProperty("/TempSelectedOppInFilter", aTempSelectedAcc);
		},
		/**
		 * @author Siddharth S
		 * @function fnForCheckBoxSelection
		 * @description function to check check box selection in account and Opp filter bar dialg.
		 * @param {Object} tokens, oDialog
		 */
		fnForCheckBoxSelection: function (tokens, oDialog, fieldName) {
			oDialog._removeSelection();
			const items = oDialog.getItems();
			const matrixModel = this.getModel("matrixModel");
			if (items && tokens && tokens.length) {
				tokens.map(function (element) {

					const oItem = items.find(function (item) {
						const Path = item.getBindingContext("matrixModel").getPath();
						const data = matrixModel.getProperty(Path);
						if (fieldName === "account") {
							return data.AccountId === element.key
						} else {
							return data.OPPT_ID === element.key
						}
					});
					if (oItem) {
						oItem.setSelected(true);
					}
				});
			}
		},
		/**
		 * @author Siddharth S
		 * @function onRemovedAccToken
		 * @description function to removed token frommulti input box and from model as well.
		 * @param {Object} oEvent
		 */
		onRemovedAccToken: function (oEvent) {
			const type = oEvent.getParameter("type");
			const matrixModel = this.getModel("matrixModel");
			if (type === "removed") {
				const tokens = matrixModel.getProperty("/SelectedAccountsInFilter");
				const removedTokens = oEvent.getParameter("removedTokens");
				if (removedTokens && removedTokens.length) {
					removedTokens.map(function (element) {
						const iIndex = tokens.findIndex(item => item.key === element.getKey());
						if (iIndex !== -1) {
							tokens.splice(iIndex, 1);
						}
					});
					// this.onSearchActivities();
				}
			}
		},

		/**
		 * @author Siddharth S
		 * @function getAccountList
		 * @description pagination of account list on scroll.
		 * @param {Object} searchValue, isSuggestion
		 */
		getAccountList: function (searchValue, isSuggestion) {
			const oDialog = this._pSearchAccountValueHelpDialog;
			const that = this;
			const matrixModel = this.getModel("matrixModel");
			// const SelectedAccountsInFilter = matrixModel.getProperty("/SelectedAccountsInFilter") || [];
			const aTempSelectedAcc = matrixModel.getProperty("/TempSelectedAccInFilter") || [];
			let AccountForFilter = matrixModel.getProperty("/AccountForFilter") || [];
			let aAccountMasterData = matrixModel.getProperty("/AccountMasterData") || [];
			const skip = (AccountForFilter && AccountForFilter.length) ? AccountForFilter.length : 0;
			// const topDiffrence = (this.topDifference) ? this.topDifference : 0;

			if (searchValue && searchValue.length >= 2) {
				let tempAcc = [];
				if (aAccountMasterData.length) {
					tempAcc = aAccountMasterData.filter(item => item.searchValue && item.searchValue.trim() === searchValue.trim());
					if (tempAcc.length) {
						matrixModel.setProperty("/AccountForFilter", tempAcc);
						if (aTempSelectedAcc && aTempSelectedAcc.length) {
							that.fnForCheckBoxSelection(aTempSelectedAcc, oDialog, "account");
						}
						oDialog.setBusy(false);
						return;
					}
				}
				AccountUtil.searchAccounts(searchValue.trim(), "matrixview", skip)
					.then((accounts) => {
						if (!isSuggestion) {
							oDialog.setBusy(false);
						}
						if (accounts.length === 0) {
							return;
						}
						// that.topDifference = accounts.length;
						AccountForFilter.push(...accounts);
						AccountForFilter = Array.from(new Map(AccountForFilter.map(item => [item.AccountId, item])).values());
						matrixModel.setProperty("/AccountForFilter", AccountForFilter);
						if (aTempSelectedAcc && aTempSelectedAcc.length) {
							that.fnForCheckBoxSelection(aTempSelectedAcc, oDialog, "account");
						}
						accounts.map(function (element) {
							element.searchValue = searchValue;
						});
						aAccountMasterData.push(...accounts);
						matrixModel.setProperty("/AccountMasterData", aAccountMasterData);
					});
			}
		},
		/**
		 * @author Siddharth S
		 * @function onConfirmAccount
		 * @description function to set selected token in account multi input box on click of select.
		 * @param {Object} oEvent
		 */
		onConfirmAccount: function (oEvent) {
			// const selectedContexts = oEvent.getParameter("selectedContexts");
			const matrixModel = this.getModel("matrixModel");
			const aTempSelectedAcc = matrixModel.getProperty("/TempSelectedAccInFilter")
			if (aTempSelectedAcc) {
				const aSelection = [];
				aTempSelectedAcc.forEach((element) => {
					// let path = context.sPath;
					aSelection.push({
						key: element.key,
						text: element.text
					});
				});
				matrixModel.setProperty("/SelectedAccountsInFilter", aSelection);
				// this.onSearchActivities();
			}
		},
		/**
		 * @author Siddharth S
		 * @function onCancelAccountListDialog
		 * @description function close account dialog.
		 * @param {Object} 
		 */
		onCancelAccountListDialog: function () {
			const matrixModel = this.getModel("matrixModel");
			matrixModel.setProperty("/AccountForFilter", []);
			this.topDifference = 0;
		},
		/**
		 * @author Siddharth S
		 * @function onSearchOppNameValueHelpRequest
		 * @description function to open Opportunity dialog box for filter
		 * @param {Object} oEvent
		 */
		onSearchOppNameValueHelpRequest: function (oEvent) {

			let sInputValue = oEvent.getSource().getValue(),
				oView = this.getView();
			const that = this;
			const matrixModel = this.getModel("matrixModel");
			const SelectedOppInFilter = matrixModel.getProperty("/SelectedOppInFilter") || [];
			let i18nModel = new ResourceModel({
				bundleName: "com.melody.lib.i18n.i18n"
			});
			if (this._pSearchOppValueHelpDialog) {
				this._pSearchOppValueHelpDialog.destroy();
				this._pSearchOppValueHelpDialog = null;
			}
			if (!this._pSearchOppValueHelpDialog) {
				this._pSearchOppValueHelpDialog = Fragment.load({
					id: "matrixOppFilterDialog",
					name: "com.melody.lib.fragments.MTR.Matrix.Actions.OpportunityFilterDialog",
					controller: this
				}).then(function (oDialog) {
					oDialog.setModel(matrixModel);
					oDialog.setModel(i18nModel, "i18n");
					return oDialog;
				});
			}
			this._pSearchOppValueHelpDialog.then(function (oDialog) {
				const aSelection = [];
				if (SelectedOppInFilter.length) {
					SelectedOppInFilter.forEach((element) => {
						aSelection.push({
							key: element.key,
							text: element.text
						});
					});
				}
				matrixModel.setProperty("/TempSelectedOppInFilter", $.extend(true, [], aSelection));
				matrixModel.setProperty("/OpportunityForFilter", []);
				that._pSearchOppValueHelpDialog = oDialog;
				// if (sInputValue) {
				that.getOppList(sInputValue);
				// }
				// Open ValueHelpDialog filtered by the input's value
				oDialog.open(sInputValue);

			});

		},
		/**
		 * @author Siddharth S
		 * @function onSearchOppList
		 * @description function to open search opportunity in opp dialog
		 * @param {Object} oEvent
		 */
		onSearchOppList: function (oEvent) {
			const oDialog = this._pSearchOppValueHelpDialog;
			oDialog.setBusy(false);
			const sSearchValue = oEvent.getParameter("value");
			const matrixModel = this.getModel("matrixModel");
			matrixModel.setProperty("/OpportunityForFilter", []);
			if (sSearchValue) {
				matrixModel.getProperty("/GlobalSearchForFilter", sSearchValue);
				this.getOppList(sSearchValue);
			} else {
				oDialog.setBusy(false);
				this.fnForCheckBoxSelection([], this._pSearchOppValueHelpDialog, "opp");
			}
		},
		/**
		 * @author Siddharth S
		 * @function onOppSelectionChange
		 * @description function to push selected opportunity in array
		 * @param {Object} oEvent
		 */
		onOppSelectionChange: function (oEvent) {
			const bSelected = oEvent.getParameter("selected");
			const aSelectedItems = oEvent.getParameter("listItems");
			const matrixModel = this.getModel("matrixModel");
			const aTempSelectedOpp = matrixModel.getProperty("/TempSelectedOppInFilter") || [];
			if (aSelectedItems.length) {
				aSelectedItems.map(function (element) {
					const oItem = element.getBindingContext("matrixModel").getObject();
					const iIndex = aTempSelectedOpp.findIndex(item => oItem.OPPT_ID === item.key);
					if (bSelected && iIndex === -1) {
						aTempSelectedOpp.push({
							key: oItem.OPPT_ID,
							text: oItem.DESCRIPTION
						});
					} else if (!bSelected && iIndex !== -1) {
						aTempSelectedOpp.splice(iIndex, 1);
					}
				});
			}
			matrixModel.setProperty("/TempSelectedOppInFilter", aTempSelectedOpp);
		},
		/**
		 * @author Siddharth S
		 * @function getOppList
		 * @description function to call the Opp service in existing activity dialog to fetch account details
		 * @param {Object} element
		 */
		getOppList: function (searchValue, isSuggestion) {
			const oDialog = this._pSearchOppValueHelpDialog;
			const that = this;
			const matrixModel = this.getModel("matrixModel");
			let OpportunityForFilter = matrixModel.getProperty("/OpportunityForFilter");
			// let aOpportunityMasterData = matrixModel.getProperty("/OpportunityMasterData") || [];
			// const SelectedOppInFilter = matrixModel.getProperty("/SelectedOppInFilter") || [];
			const aTempSelectedOpp = matrixModel.getProperty("/TempSelectedOppInFilter") || [];
			let aFilters = [];
			if (searchValue && searchValue.length >= 3) {
				// const tempOpp = [];
				// if (aOpportunityMasterData.length) {
				// 	tempOpp = aOpportunityMasterData.filter(item => item.searchValue && item.searchValue.trim() === searchValue.trim());
				// 	if (tempAcc.length) {
				// 		matrixModel.setProperty("/AccountForFilter", tempAcc);
				// 		oDialog.setBusy(false);
				// 		return;
				// 	}
				// }
				// oEvent.getSource().setBusy(true);
				let aNewFilter = [];
				let oAllQuater = new Filter({
					path: "QUARTER_ID",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: "99990"
				});
				aNewFilter.push(oAllQuater);

				aNewFilter.push(new Filter({
					path: "HARMONY_TYPE",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: "HQ"
				}));
				let aStatus = ["E0001", "E0007"]; //  In progress opp and New opp.
				let aStatusFilter = aStatus.map((value) => {
					return new Filter({
						path: "STATUS",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: value
					});
				});
				aNewFilter = aNewFilter.concat(aStatusFilter);

				let numberRegEx = /^[0-9]+$/;
				const isOpportunityId = numberRegEx.test(searchValue);
				//Only Opportunity-ID
				if (isOpportunityId) {
					aNewFilter.push(new Filter({
						path: "OPPT_ID",
						operator: sap.ui.model.FilterOperator.Contains,
						// operator: sap.ui.model.FilterOperator.EQ,
						value1: searchValue
					}));
				}
				const skip = (OpportunityForFilter && OpportunityForFilter.length) ? OpportunityForFilter.length : 0;
				let urlParameters = {
					"search-focus": "ACCOUNT",
					"search": (!isOpportunityId && searchValue) ? searchValue : "",
					"$select": "OPPT_ID,DESCRIPTION",
					$skip: skip,
					$top: 50
				};
				let oUrlParameters = {
					filters: [aNewFilter],
					urlParameters: urlParameters
				};
				OpportunityService.getOpportunityForVAT("", oUrlParameters).then((oResponse) => {
					const Opportunities = (oResponse) ? oResponse.data.results : [];
					if (!isSuggestion) {
						oDialog.setBusy(false);
					}
					if (Opportunities.length === 0) {
						return;
					}
					OpportunityForFilter.push(...Opportunities);
					OpportunityForFilter = Array.from(new Map(OpportunityForFilter.map(item => [item.OPPT_ID, item])).values());
					matrixModel.setProperty("/OpportunityForFilter", OpportunityForFilter);
					if (aTempSelectedOpp && aTempSelectedOpp.length) {
						that.fnForCheckBoxSelection(aTempSelectedOpp, this._pSearchOppValueHelpDialog, "opp");

					}
					// Opportunities.map(function (element) {
					// 	element.searchValue = searchValue;
					// });
					// aOpportunityMasterData.push(...Opportunities);
					// matrixModel.setProperty("/OpportunityMasterData", aOpportunityMasterData);
				}).catch((oError) => {
					console.log("ERROR IN Opp Service");
					if (!isSuggestion) {
						oDialog.setBusy(false);
					}
				});
			} else {

			}

		},
		/**
		 * @author Siddharth S
		 * @function onScrollOpptList
		 * @description pagination of .account scroll.
		 * @param {Object} oEvent
		 */
		onScrollOpptList: function (oEvent) {
			const reason = oEvent.getParameter("reason");
			if (reason === "Growing") {
				const oDialog = this._pSearchOppValueHelpDialog;
				const matrixModel = this.getModel("matrixModel");
				const sSearchValue = oDialog._searchField.getValue();
				if (sSearchValue) {
					oDialog.setBusy(true);
					this.getOppList(sSearchValue);
				}
			}
		},
		/**
		 * @author Siddharth S
		 * @function onConfirmOpp
		 * @description function to set selected token in opportunity multi input box on click of select.
		 * @param {Object} oEvent
		 */
		onConfirmOpp: function (oEvent) {
			const matrixModel = this.getModel("matrixModel");
			const aTempSelectedOpp = matrixModel.getProperty("/TempSelectedOppInFilter") || [];
			// const selectedContexts = oEvent.getParameter("selectedContexts");
			if (aTempSelectedOpp) {
				const aSelection = [];
				aTempSelectedOpp.forEach((element) => {
					// let path = context.sPath;
					aSelection.push({
						key: element.key,
						text: element.text
					});
				});
				matrixModel.setProperty("/SelectedOppInFilter", aSelection);
				// this.onSearchActivities();
			}
		},
		/**
		 * @author Siddharth S
		 * @function onRemovedOppToken
		 * @description function to removed token frommulti input box and from model as well.
		 * @param {Object} oEvent
		 */
		onRemovedOppToken: function (oEvent) {
			const type = oEvent.getParameter("type");
			const matrixModel = this.getModel("matrixModel");
			if (type === "removed") {
				const tokens = matrixModel.getProperty("/SelectedOppInFilter");
				const removedTokens = oEvent.getParameter("removedTokens");
				if (removedTokens && removedTokens.length) {
					removedTokens.map(function (element) {
						const iIndex = tokens.findIndex(item => item.key === element.getKey());
						if (iIndex !== -1) {
							tokens.splice(iIndex, 1);
						}
					});
					// this.onSearchActivities();
				}
			}

		},

		/**
		 * @author Nitish
		 * @function onSearchActivityId
		 * @description function to open Activity dialog box for filter
		 * @param {Object} oEvent
		 */

		onSearchActivityIdValueHelpRequest: function (oEvent) {
			let sInputValue = oEvent.getSource().getValue(),
				oView = this.getView();
			const that = this;
			const matrixModel = this.getModel("matrixModel");
			let i18nModel = new ResourceModel({
				bundleName: "com.melody.lib.i18n.i18n"
			});
			if (this._pSearchActivityIdHelpDialog) {
				this._pSearchActivityIdHelpDialog.destroy();
				this._pSearchActivityIdHelpDialog = null;
			}
			if (!this._pSearchActivityIdHelpDialog) {
				this._pSearchActivityIdHelpDialog = Fragment.load({
					id: "matrixActivityIdFilterDialog",
					name: "com.melody.lib.fragments.MTR.Matrix.Actions.ActivityIdFilterDialog",
					controller: this
				}).then(function (oDialog) {
					oDialog.setModel(matrixModel);
					oDialog.setModel(i18nModel, "i18n");

					return oDialog;
				});
			}

			this._pSearchActivityIdHelpDialog.then(function (oDialog) {
				that._pSearchActivityIdHelpDialog = oDialog;

				oDialog.open();
				that.setUserActivities();
			})
		},
		setUserActivities: async function () {
			let aActivities;
			let matrixModel = this.getModel("matrixModel");
			const sActvtAsstdID = matrixModel.getProperty("/filterBarKey") || "";
			let aFilters = [new Filter("ActAsstId", "EQ",
				sActvtAsstdID)];

			let archivedFilter = new Filter({
				path: "IsArchived",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: false
			});
			aFilters.push(archivedFilter);
			aActivities = await MTRService.getTimeEntryActivitites(aFilters);
			//Remove duplicates based on activity_guid
			aActivities = [
				...new Map(
					aActivities.map(item => [item.activity_guid, item])
				).values()
			];
			//Remove leading zeros from ActivityId
			aActivities = aActivities.map(item => ({
				...item,
				ActivityId: item.ActivityId
					? item.ActivityId.replace(/^0+/, "")
					: ""
			}));

			matrixModel.setProperty("/UserActivities", aActivities)
		},
		/**
		 * @author Nitish
		 * @function onActIdSelectionChange
		 * @description function to push selected activityId in array
		 * @param {Object} oEvent
		 */
		onActIdSelectionChange: function (oEvent) {
			const bSelected = oEvent.getParameter("selected");
			const aSelectedItems = oEvent.getParameter("listItems");
			const matrixModel = this.getModel("matrixModel");
			const aTempSelectedAct = matrixModel.getProperty("/TempSelectedActInFilter") || [];
			if (aSelectedItems.length) {
				aSelectedItems.map(function (element) {
					const oItem = element.getBindingContext("matrixModel").getObject();
					const iIndex = aTempSelectedAct.findIndex(item => oItem.ActivityId === item.key);
					if (bSelected && iIndex === -1) {
						aTempSelectedAct.push({
							key: oItem.ActivityId,
							text: oItem.ActTypeDesc
						});
					} else if (!bSelected && iIndex !== -1) {
						aTempSelectedAct.splice(iIndex, 1);
					}
				});
			}
			matrixModel.setProperty("/TempSelectedActInFilter", aTempSelectedAct);
		},
		/**
		 * @author Nitish
		 * @function onConfirmActId
		 * @description function to set selected token in activityId multi input box on click of select.
		 * @param {Object} oEvent
		 */
		onConfirmActId: function () {
			const matrixModel = this.getModel("matrixModel");
			const aTempSelectedAct = matrixModel.getProperty("/TempSelectedActInFilter") || [];

			if (aTempSelectedAct) {
				const aSelection = [];
				aTempSelectedAct.forEach((element) => {

					aSelection.push({
						key: element.key,
						text: element.text
					});
				});
				matrixModel.setProperty("/selectedActInFilter", aSelection);

			}
		},
		/**
		 * @author Nitish
		 * @function onRemovedActctId
		 * @description function to removed token from multi input box and from model as well.
		 * @param {Object} oEvent
		 */
		onRemovedActctId: function (oEvent) {
			const type = oEvent.getParameter("type");
			const matrixModel = this.getModel("matrixModel");
			const aTempSelectedAct = matrixModel.getProperty("/TempSelectedActInFilter") || [];
			if (type === "removed") {
				const tokens = matrixModel.getProperty("/selectedActInFilter");
				const removedTokens = oEvent.getParameter("removedTokens");
				if (removedTokens && removedTokens.length) {
					removedTokens.map(function (element) {
						const iIndex = tokens.findIndex(item => item.key === element.getKey());
						if (iIndex !== -1) {
							tokens.splice(iIndex, 1);
							aTempSelectedAct.splice(iIndex, 1)
						}
					});

				}
			}
		},
		onActvtIdSearch: function (oEvent) {

			const sQuery = oEvent.getParameter("value");
			const oBinding = oEvent.getSource().getBinding("items");

			if (!sQuery) {
				oBinding.filter([]);  // clear filters
				return;
			}
			const oFilters = [
				new sap.ui.model.Filter("ActivityId", sap.ui.model.FilterOperator.Contains, sQuery),
			];



			oBinding.filter(oFilters);
		},
		/**
		 * @author Siddharth S
		 * @function onSuggestTitleSelected
		 * @description function to search the Title of No Association from the table of Select Existing Activity Registrations dialog
		 * @param {Object} oEvent
		 * @param {Boolean} 
		 */
		onSuggestTitleSelected: function (oEvent) {
			const oSelectedItem = oEvent.getParameter("selectedItem");
			var sValue = (oSelectedItem) ? oSelectedItem.getText() : "";
			const matrixModel = this.getModel("matrixModel");
			if (sValue) {
				matrixModel.setProperty("/GlobalSearchForFilter", sValue);
				// this.onSearchActivities();
			}
		},

		//Mat verstion 2 changes
		openActivityActionMenu: function (oEvent) {
			const oAct = oEvent.getSource().getBindingContext("matrixModel").getObject();
			const oActivity = oAct.activityRegistration;
			this.getModel("matrixModel").setProperty("/selectedActivity", oActivity);
			var oButton = oEvent.getSource();
			this.ActivityMenuButton = oButton;
			let sActivityId = oAct.ActivityId;
			this.getMenuData(oActivity);
		},

		fnConfirmActStatusPopup: function (oEvent) {
			let source = this.ActivityMenuButton.getParent();
			let id = "_ConfirmActStatusDialog";
			if (!this.confirmActStatusPopup) {
				this.confirmActStatusPopup = sap.ui.xmlfragment(id,
					"com.melody.lib.fragments.MTR.Matrix.Actions.ConfirmActStatusPopup",
					this);
				source.addDependent(this.confirmActStatusPopup);
			}
			var StatusChangedAt = new Date();
			let datePicker = this.fnGetDialogUsingId("_ConfirmActStatusDialog", "statusChangedDatePckr");
			datePicker.setDateValue(StatusChangedAt);
			this.getModel("matrixModel").setProperty("/CurrentActStatus", this.data.Status);
			// this.getModel("matrixModel").setProperty("/selectedActivity/ActStatus", this.data.Status);
			this.confirmActStatusPopup.open();
		},

		fnCloseConfirmActStatusPopup: function () {
			this.confirmActStatusPopup.close();
		},

		getActRegStatusMasterData: function () {
			var that = this;
			var oMasterDataModel = this.getOwnerComponent().getModel("oMasterDataModel");
			this.oMasterDataModel = oMasterDataModel;
			this.getOwnerComponent().getModel("activityoData").read("/YC_MAC_M_STATUS_LIST", {
				success: function (oData) {
					oMasterDataModel.setProperty("/YC_MAC_M_STATUS_LIST", oData.results);
				},
				error: function (oEvent) {
					oMasterDataModel.setProperty("/YC_MAC_M_STATUS_LIST", []);
				}
			});
		},

		//Function to find if Customer validated button can be visible for user
		fnSetCustomerValBtnVisible: function (oSelectedObj) {
			var oMasterDataModel = this.getOwnerComponent().getModel("oMasterDataModel");
			var oStatusArr = oMasterDataModel.getProperty("/YC_MAC_M_STATUS_LIST");
			var RequestorRegHC = oSelectedObj.RequestorRegHC;
			var oSearchedObj = oStatusArr.find(function (object) {
				return ((object.RegionHc === RequestorRegHC && object.StatusId === "14") || (object.RegionHc === "*" && object.StatusId ===
					"14"));
			});
			if (oSearchedObj) {
				oMasterDataModel.setProperty("/isCustomerValVisible", true);
			} else {
				oMasterDataModel.setProperty("/isCustomerValVisible", false);
			}
			oMasterDataModel.setProperty("/ActStatusSelObj", oSelectedObj);
		},

		/**
		 * Function to make service call for the action menu 
		 *{sParam} Act guid of the selected activity  
		 */

		getMenuData: async function (oActivity) {
			let that = this;
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter({
				path: "ActGuid",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: oActivity.ActivityGUID ? oActivity.ActivityGUID : oActivity.ActivityGuid

			}));
			const aResults = await ActivityService.getActMenuData(aFilters);
			this.getModel("matrixModel").setProperty("/actionMenu", aResults);

			// let oActivityActionMenuModel = this.getView().getModel("activityActionMenuModel");
			// let oActivityData = oActivityActionMenuModel.getProperty("/selectedActivity");

			this.fnSetAdditionalMenuItems(oActivity, aResults);
			if (this.oMenuDialog) {
				this.oMenuDialog.destroy();
				this.oMenuDialog = null;
			}
			let source = this.ActivityMenuButton.getParent();
			if (!this.oMenuDialog) {
				Fragment.load({
					id: "_MatrixActivityActionMenuDialog",
					name: "com.melody.lib.fragments.MTR.Matrix.Actions.ActivityActionMenu",
					controller: this
				}).then(function (oPopover) {
					oPopover.setModel(this.getModel("matrixModel"), "matrixModel");
					this.oMenuDialog = oPopover;
					source.addDependent(this.oMenuDialog);
					this.oMenuDialog.openBy(this.ActivityMenuButton);
					// setTimeout(() => {
					// 	that.addActionMenuItem(oActivity);
					// }, 100);
				}.bind(this));
			} else {
				// setTimeout(() => {
				// 	that.addActionMenuItem(oActivity);
				// }, 100);
				this.oMenuDialog.openBy(this.ActivityMenuButton);
			}

		},
		/**
		 * Event handeler for the menu action options.
		 */
		onMenuAction: function (oEvent) {
			let sStatusId = "";
			let oItem = oEvent.getParameters("items").item;
			let oContext = oEvent.getSource().getBindingContext("matrixModel");
			let sActionId = oItem ? oItem.getKey() : oContext ? oContext.getProperty("ActionId") : "";
			let oAct = oContext.getObject().activityRegistration;
			this.data = {
				"ActivityId": oAct.ActivityId,
				"ActivityGuid": oAct.ActivityGUID ? oAct.ActivityGUID : oAct.ActivityGuid,
				"Status": ""
			};
			switch (sActionId) {
				case "00006": //Edit Register
					this.onEditRegistration(oEvent);
					break;
				case "00007":
					this.data.Status = "02";
					this.onCancelActivity(oAct);
					break;
				case "00008":
					this.data.Status = "16";
					this.fnSetActivityStatus(oAct);
					break;
				case "00009":
					this.data.Status = "17";
					this.fnSetActivityStatus(oAct);
					break;
				case "00010":
					this.data.Status = "18";
					this.fnSetActivityStatus(oAct);
					break;
				case "00012":
					this.data.Status = "12";
					this.fnConfirmActStatusPopup(oEvent);
					break;
				case "00013":
					this.data.Status = "01";
					this.fnSetActivityStatus(oAct);
					break;
				case "00011":
					this.data.Status = "14";
					this.fnConfirmActStatusPopup(oEvent);
					break;
				case "01003": //DBR
					this.handleCreateDBR(oEvent);
					break;
				case "01000": //Archieve
					this.fnSetActivityStatus(oAct, true);
					break;
				case "01001": // UnArchieve
					this.fnSetActivityStatus(oAct, false);
					break;
				case "01002": //Post Demo
					this.onPostDemoSurveyPress();
					break;
				case "00014": //Edit in full registration
					this.navToFullRegForm(oAct);
					break;
				default:
			}
		},

		navToFullRegForm: function (oActivity) {
			let constants = oStorageModel.getProperty("/oConstants");
			const sActguid = oActivity.ActivityGUID || oActivity.ActivityGuid;
			let sParam = this.data.ActivityId + "&IsRapidRegistration=true&ActGUID=" + sActguid;
			if (constants) {
				// constants["0175"]
				window.open(constants["0181"].field_value + sParam);
			}
		},

		handleCreateDBR: function () {
			var oCrossAppNavigator = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					"semanticObject": "pcdbrform",
					"action": "app"
				},
				params: {
					"ActivityID": this.data.ActivityId
				}
			})) || "";
			if (oCrossAppNavigator) {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: hash
					}
				});
			}
		},

		onEditRegistration: function (oEvent) {
			let that = this;
			let matrixModel = this.getModel("matrixModel");
			let currentMatrixContext = oEvent.getSource().getBindingContext("matrixModel") || false;
			if (!currentMatrixContext) {
				return;
			}
			let contextPath = currentMatrixContext.getPath();
			let matrixEntry = matrixModel.getProperty(contextPath);
			let registration = matrixModel.getProperty(`${contextPath}/activityRegistration`) || {};
			// if (rapidRegBtn) {
			// 	rapidRegBtn.destroy();
			// }
			let rapidRegBtn = new com.melody.lib.controls.RapidRegistration.RapidRegistration({
				text: "",
				icon: "",
				enabled: true,
				activityData: registration,
				activityContextPath: contextPath,
				activityId: matrixEntry.ActvtId,
				press: function (oEvent) {
					that.onPressRegistration(oEvent, contextPath, true);
				},
				selectedActivity: function (oEvent) {
					that.onSuccessActvtRegistration(oEvent);
				}
			});
			rapidRegBtn.firePress();
		},

		onCancelActivity: function (oActivity) {
			let that = this;
			const oResourceBundle = this.oMenuDialog.getModel("i18n").getResourceBundle();
			if (this.data.Status === "02") {
				sap.m.MessageBox.confirm(oResourceBundle.getText("confirmCancelPopup"), {
					styleClass: "sapUiSizeCompact",
					onClose: function (oAction) {
						if (oAction.toLowerCase() === "cancel") {
							return;
						} else {
							that.fnSetActivityStatus(oActivity);
						}
					}
				});
			}
		},

		fnSetActivityStatus: async function (oActivity, bArchive) {
			this.getModel("matrixModel").setProperty("/matrixActivityListBusy", true);
			if (this.confirmActStatusPopup) {
				this.fnCloseConfirmActStatusPopup("OK");
			}
			if (bArchive !== undefined) {
				oActivity.Archived = bArchive;
				this.data.Archived = bArchive
				delete this.data.Status;
			} else {
				let StatusChangedAt = oActivity.StatusChangedAt;
				let datePicker = this.fnGetDialogUsingId("_ConfirmActStatusDialog", "statusChangedDatePckr");
				if (this.data.Status === "12" || this.data.Status === "14") {
					StatusChangedAt = datePicker.getDateValue();
					oActivity.ActStatus = this.data.Status;
					this.fnCloseConfirmActStatusPopup();
				} else {
					oActivity.ActStatus = this.data.Status;
					StatusChangedAt = new Date();
				}
				if (StatusChangedAt) {
					StatusChangedAt = StatusChangedAt.toJSON().split(".")[0] + "Z";
				}
				this.data.StatusChangedAt = StatusChangedAt;
				oActivity.ActStatusDesc = await this.getStatusDescription(oActivity.ActStatus);
			}
			const aResults = await ActivityService.updateActivityStatus(this.data);
			const matrixModel = this.getModel("matrixModel");
			const matrixdata = matrixModel?.getData() ?? [];
			const findactivityforarchived = matrixdata.matrixActivityData.filter(item =>
				item.ActvtId === this.data.ActivityId
			);
			findactivityforarchived[0].Archived = this.data.Archived ?? "";
			matrixModel.refresh(true);
			matrixModel.setProperty("/matrixActivityListBusy", false);
		},

		//function to add action menu items
		fnSetAdditionalMenuItems: function (oSelectedObj, aResponse) {
			let oOptions = {
				archive: {
					enable: false,
					visible: false,
				},
				unarchive: {
					enable: false,
					visible: false,
				},
				postdemosurvey: {
					enable: false,
					visible: false,
				},
				dbr: {
					text: (oSelectedObj.DBRCount > 0) ? "DBR" : "Create DBR",
					enable: false,
					visible: false,
				},
			};
			// let oActivityActionMenuModel = this.getView().getModel("activityActionMenuModel");
			//validations
			oOptions = this.fnHandleActionMenuOptionValidation(oSelectedObj, oOptions);
			//MSL COMPLETE
			let SLStatusId = oSelectedObj.SlStatusId;
			let isArchived = oSelectedObj.Archived;
			aResponse = aResponse.map((oItem) => {
				return {
					...oItem,
					IsEnabled: (SLStatusId === "12") ? "" : oItem.IsEnabled,
					enabled: (SLStatusId === "12") ? false : true,
					Icon: (SLStatusId === "12") ? "sap-icon://locked" : oItem.Icon,
				}
			});

			let aMenuItems = [{
				ItemName: "Archive Activity",
				SortOrder: "00005",
				ActionId: "01000",
				IsEnabled: (oOptions.archive.enable) ? "X" : "",
				Icon: (SLStatusId !== "12") ? "sap-icon://attachment-zip-file" : "sap-icon://locked",
				enabled: oOptions.archive.enable,
				visible: oOptions.archive.visible
			}, {
				ItemName: "Un-Archive Activity",
				SortOrder: "00006",
				ActionId: "01001",
				IsEnabled: (oOptions.unarchive.enable) ? "X" : "",
				Icon: (SLStatusId !== "12") ? "sap-icon://attachment-zip-file" : "sap-icon://locked",
				enabled: oOptions.unarchive.enable,
				visible: oOptions.unarchive.visible
			}, {
				ItemName: "Post Demo Survey",
				SortOrder: "00007",
				ActionId: "01002",
				IsEnabled: (oOptions.postdemosurvey.enable) ? "X" : "",
				Icon: (SLStatusId !== "12") ? "sap-icon://survey" : "sap-icon://locked",
				enabled: oOptions.postdemosurvey.enable,
				visible: oOptions.postdemosurvey.visible
			}, {
				ItemName: oOptions.dbr.text,
				SortOrder: "00008",
				ActionId: "01003",
				IsEnabled: (oOptions.dbr.enable) ? "X" : "",
				Icon: (SLStatusId !== "12") ? "sap-icon://present" : "sap-icon://locked",
				enabled: oOptions.dbr.enable,
				visible: oOptions.dbr.visible
			}];

			if (isArchived) {
				aResponse = aResponse.map((oItem) => {
					return {
						...oItem,
						IsEnabled: "",
						visible: false
					};
				});
			}
			aResponse = aResponse.concat(aMenuItems);
			this.getModel("matrixModel").setProperty("/actionMenu", aResponse);
			this.getModel("matrixModel").refresh();
		},

		//function to handle Action menu option validate
		fnHandleActionMenuOptionValidation: function (oSelectedObj, oOptions) {
			//If new status. Pls add in below array for validation
			let aActivityStatus = ["12", "14", "02"];
			let aActivityDBRStatus = ["01", "16", "17", "18"];
			let aActivityPostDemoStatus = ["12", "14"];
			let aActivityPostDemoTypeId = ["0001", "0179", "0107", "0236", "0238"];

			//If new typeId. Pls add in below array for validation
			let aActivityTypeId = ["0001", "0015", "0107", "0179", "0236", "0238"];

			let SLStatusId = oSelectedObj.SlStatusId;
			let activitySetStatus = oSelectedObj.ActivitySetStatus;
			let isArchived = oSelectedObj.Archived;
			let activityStatus = oSelectedObj.ActStatus;
			let activityTypeId = oSelectedObj.ActivityTypeId;
			let activityIsdemolead = ("IsDemoLead" in oSelectedObj) ? oSelectedObj.IsDemoLead : "";

			if (SLStatusId !== '12') {
				oOptions.archive.enable = true;
				oOptions.unarchive.enable = true;
				oOptions.postdemosurvey.enable = true;
				oOptions.dbr.enable = true;
			}

			//Validation for Archieve
			if (!isArchived) {
				if (aActivityStatus.indexOf(activityStatus) !== -1) {
					oOptions.archive.visible = true;
				}
			} else {
				//UnArchive
				if (aActivityStatus.indexOf(activityStatus) !== -1) {
					oOptions.unarchive.visible = true;
				}
			}

			//validation for post demo survey
			if (!isArchived && aActivityPostDemoTypeId.indexOf(activityTypeId) !== -1 && activityIsdemolead === "X") {
				if (aActivityPostDemoStatus.indexOf(activityStatus) !== -1) {
					oOptions.postdemosurvey.visible = true;
				}
			}

			//validation for DBR
			if (!isArchived) {
				if (aActivityDBRStatus.indexOf(activityStatus) !== -1 && aActivityTypeId.indexOf(activityTypeId) !== -1) {
					oOptions.dbr.visible = true;
				}
			}

			return oOptions;
		},

		onPostDemoSurveyPress: function () {
			let constants = oStorageModel.getProperty("/oConstants");
			window.open(constants["0036"].field_value + this.data.ActivityId);
		},

		handleRegisterNewActivity: async function (event) {

			this.getModel("matrixModel").setProperty("/sSearchMatrixList", "");
			//	await this.onMatrixListSearch(false, "");
			let aMatrixData = this.getModel("matrixModel").getProperty("/matrixActivityData") || [];
			if (aMatrixData.length && aMatrixData[0].ActvtId === "") {
				return;
			}
			//Default Entry when no entries are available
			let oWeekDates = this.parentControl.fnGetWeekFirstLastDates(null);
			let oNewEntry = this.parentControl.fnCreateEntryObject();
			oNewEntry.ActvtId = "";
			let regMatrixEntry = this.parentControl.fnCreateEmptyMatrixEntry(oWeekDates.dFirstdate, oWeekDates.dLastdate, oNewEntry)[0];
			aMatrixData.unshift(regMatrixEntry);
			this.getModel("matrixModel").setProperty("/matrixActivityData", aMatrixData);
			this.getModel("matrixModel").setProperty("/matrixActivityListBusy", false);
			this.getModel("matrixModel").refresh();

		},
		/**
		 * @author Siddharth S
		 * @function onMatrixListSearch
		 * @description function to search Account name,Account ID, Opp ID and opp name from matrix list.
		 * @param {Object} oEvent, sSearchText
		 * @param {Boolean} 
		 */
		onMatrixListSearch: async function (oEvent, sSearchText) {
			const tableId = this.parentControl.fnGetDialogUsingId("_MatrixTimeRecordingDialog", "activityMatrixList");
			tableId.getBinding("items").filter([]);
			const matrixModel = this.getModel("matrixModel");
			const oMtrSettingsModel = MTRModels.getMTRSettingsModel();
			const aOpportunities = oMtrSettingsModel.getProperty("/Opportunities");
			const aNONVatOppData = oMtrSettingsModel.getProperty("/aNONVatOppData") || [];
			const aAccounts = oMtrSettingsModel.getProperty("/to_ACCOUNT")
			let changedCalendarDate = matrixModel.getProperty("/changedCalendarDate") || null;
			const oResourcei18nModel = MTRModels.getMTRResourceModel();
			const oResourceBundle = oResourcei18nModel.getResourceBundle();
			let aFilteredMatrixResponse = [];
			let oOpportunity;
			let sQuery = sSearchText || "";
			if (oEvent) {
				sQuery = oEvent.getParameter('query');
			}
			this.bMatrixDataUpdated;
			sQuery = sQuery.trim();
			matrixModel.setProperty("/matrixActivityListBusy", true);
			if (!matrixModel.getProperty("/matrixDataUpdatedWithOppAcc") && sQuery !== "" && this.parentControl.matrixResponse.length > 0) {

				for (let i = 0; i < this.parentControl.matrixResponse.length; i++) {
					aFilteredMatrixResponse = aOpportunities.find((item) => {
						return item.OpportunityID === this.parentControl.matrixResponse[i].OpportunityId;
					});
					if (aFilteredMatrixResponse) {
						this.parentControl.matrixResponse[i].OpportunityName = aFilteredMatrixResponse.OpportunityName;
						this.parentControl.matrixResponse[i].AccountName = aFilteredMatrixResponse.AccountName;
						this.parentControl.matrixResponse[i].CostTypeName = aFilteredMatrixResponse.AccountName;
					}
					else if (aNONVatOppData.length > 0) {
						aFilteredMatrixResponse = aNONVatOppData.find((item) => {
							return item.OpportunityID === this.parentControl.matrixResponse[i].OpportunityId;
						});
						if (aFilteredMatrixResponse) {
							this.parentControl.matrixResponse[i].OpportunityName = aFilteredMatrixResponse.OpportunityName;
							this.parentControl.matrixResponse[i].AccountName = aFilteredMatrixResponse.AccountName;
							this.parentControl.matrixResponse[i].CostTypeName = aFilteredMatrixResponse.AccountName;
						}
					}
					else if (this.parentControl.matrixResponse[i].OpportunityId !== "") {
						let aFilters = [];
						aFilters.push(new Filter({
							path: "OPPT_ID",
							operator: sap.ui.model.FilterOperator.Contains,
							value1: this.parentControl.matrixResponse[i].OpportunityId
						}));
						let aSearchFilter = new Filter({
							filters: aFilters,
							and: true
						});
						let mParameters = {
							filters: aSearchFilter,
						};
						let aResponse = await OpportunityUtil.fnSetFormatParamsForNonVATOppData(mParameters);
						if (aResponse && aResponse instanceof Array && aResponse.length) {
							oOpportunity = aResponse[0];
						}
						if (oOpportunity) {
							this.parentControl.matrixResponse[i].OpportunityName = (oOpportunity && oOpportunity.hasOwnProperty("OpportunityName")) ? oOpportunity.OpportunityName :
								"Not Applicable";
							this.parentControl.matrixResponse[i].AccountName = (oOpportunity && oOpportunity.hasOwnProperty("AccountName")) ? oOpportunity.AccountName : "Not Applicable";
							this.parentControl.matrixResponse[i].CostTypeName = (oOpportunity && oOpportunity.hasOwnProperty("OpportunityName")) ? oOpportunity.OpportunityName :
								"Not Applicable";
							aOpportunities.push(oOpportunity);
						}

					}
					if (!aFilteredMatrixResponse) {
						aFilteredMatrixResponse = aAccounts.find((item) => {
							return item.AccountId === this.parentControl.matrixResponse[i].GlobalUltimateID
						});
						if (aFilteredMatrixResponse) {
							this.parentControl.matrixResponse[i].AccountName = aFilteredMatrixResponse.AccountDesc;
							this.parentControl.matrixResponse[i].CostTypeName = aFilteredMatrixResponse.AccountDesc;
						}
						else if (this.parentControl.matrixResponse[i].GlobalUltimateID !== "") {
							// const oResponse = await OpportunityService.getBusinessPartnerAttribSet(this.parentControl.matrixResponse[i].GlobalUltimateID);
							// this.parentControl.matrixResponse[i].CostTypeName = (oResponse && oResponse.data) ? oResponse.data.PARTNER_NAME : "Not Applicable";
							// this.parentControl.matrixResponse[i].CostTypeName;
							// this.parentControl.matrixResponse[i].AccountName = (oResponse && oResponse.data) ? oResponse.data.PARTNER_NAME : "Not Applicable";
							// aAccounts.push(oResponse.data);
						}


					}
					this.aTempMatrixResponse = this.parentControl.matrixResponse;
					matrixModel.setProperty("/matrixDataUpdatedWithOppAcc", true)
				}
			}
			oMtrSettingsModel.refresh(true);
			this.parentControl.matrixResponse = this.aTempMatrixResponse;
			let asearchResult;
			if (this.parentControl.matrixResponse) {
				asearchResult = this.parentControl.matrixResponse.filter(item =>
					Object.values(item).some(value =>
						String(value).toLowerCase().includes(sQuery.toLowerCase())
					)
				);
			}

			matrixModel.setProperty("/matrixActivityListBusy", false);
			matrixModel.setProperty('/isloadModeVisible', false);
			if (asearchResult && asearchResult.length > 0 && sQuery) {
				this.parentControl.batchIndex = 0;
				this.parentControl.totalBatches = 0;
				this.parentControl.matrixResponse = asearchResult;
				this.parentControl.fnGenerateMatrixRows(true);
			}
			else if (!asearchResult || asearchResult.length === 0) {
				if (this.aTempMatrixResponse) {
					this.parentControl.matrixResponse = this.aTempMatrixResponse;
				}
				this.parentControl.batchIndex = 0;
			}
			let allFilter = [];
			if (sQuery && sQuery.length > 0) {
				const oFilter1 = new sap.ui.model.Filter("AccountName", sap.ui.model.FilterOperator.Contains, sQuery);
				const oFilter2 = new sap.ui.model.Filter("AccountID", sap.ui.model.FilterOperator.Contains, sQuery);
				const oFilter3 = new sap.ui.model.Filter("OpportunityName", sap.ui.model.FilterOperator.Contains, sQuery);
				const oFilter4 = new sap.ui.model.Filter("selectedAstOpportunityValue", sap.ui.model.FilterOperator.Contains, sQuery);
				const oFilter5 = new sap.ui.model.Filter("activityDescription", sap.ui.model.FilterOperator.Contains, sQuery);
				const oFilter6 = new sap.ui.model.Filter("activityRegistration/ActivitySetName", sap.ui.model.FilterOperator.Contains, sQuery);
				allFilter = new sap.ui.model.Filter([oFilter1, oFilter2, oFilter3, oFilter4, oFilter5, oFilter6], false);
			}
			else {
				let aMatrixData = [];
				matrixModel.setProperty('/isloadModeVisible', true);
				this.parentControl.batchIndex = 0;
				this.parentControl.matrixResponse = [];
				aMatrixData = await this.parentControl.seperateEntriesBasedOnDate(changedCalendarDate);
				matrixModel.setProperty("/matrixActivityData", aMatrixData);

			}
			matrixModel.refresh(true);
			const aFilters = new sap.ui.model.Filter([allFilter], true);
			tableId.getBinding("items").filter(aFilters);
			const oBinding = tableId.getBinding("items");
			const aContexts = oBinding.getContexts();
			if (!aContexts || (aContexts && !aContexts.length)) {
				matrixModel.setProperty("/sActivityMatrixListNoDataTxt", oResourceBundle.getText("noRecordFound"));


			}
			// else {
			// 	setTimeout(() => {
			// 		matrixModel.setProperty("/sActivityMatrixListNoDataTxt", oResourceBundle.getText("activityMatrixListNoDataTxt"));
			// 	}, 800);
			// }

		},
		/**
		 * @author Siddharth S
		 * @function handleMatrixListSortDialog
		 * @description function to open sorting dialog for matrix list.
		 * @param {Object}
		 * @param {Boolean} 
		 */
		handleMatrixListSortDialog: function (oEvent) {
			let id = `_SortActivityMatrixListDialog`,
				parentRef = oEvent.getSource().getParent();
			if (this.sortActivityMatrixListDialog) {
				this.sortActivityMatrixListDialog.destroy();
				this.sortActivityMatrixListDialog = null;
			}
			const that = this;
			if (!this.sortActivityMatrixListDialog) {
				this.sortActivityMatrixListDialog = Fragment.load({
					id: id,
					name: "com.melody.lib.fragments.MTR.Matrix.Actions.SortMatrixList",
					controller: this
				}).then((dialog) => {
					parentRef.addDependent(dialog);
					that.sortActivityMatrixListDialog = dialog;
					dialog.open();
					return dialog;
				});
			} else {
				this.sortActivityMatrixListDialog.open();
			}
		},
		/**
		 * @author Siddharth S
		 * @function handleMatrixListSortConfirm
		 * @description function to apply sorting in matrix list.
		 * @param {Object}
		 * @param {Boolean} 
		 */
		handleMatrixListSortConfirm: function (oEvent) {
			var oTable = this.fnGetDialogUsingId("_MatrixTimeRecordingDialog", "activityMatrixList"),
				mParams = oEvent.getParameters(),
				oBinding = oTable.getBinding("items"),
				sPath,
				bDescending,
				aSorters = [];

			sPath = mParams.sortItem.getKey();
			bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending));
			// apply the selected sort and group settings
			oBinding.sort(aSorters);
		},

		//Function to set activity set on change on Event title from Popup/Form UI
		onSuggestItemSelected: function (oEvent) {
			let oActSet = {};
			let selectedItem = oEvent.getParameter("selectedItem");
			let contextPath = oEvent.getSource().getBindingContext("matrixModel").getPath();
			let matrixModel = this.getModel("matrixModel");
			if (selectedItem) {
				oActSet = oEvent.getParameter("selectedItem").getBindingContext("matrixModel").getObject();
				if (oActSet && oActSet.Description) {
					matrixModel.setProperty(`${contextPath}/activityRegistration/ActivitySetdescription`, oActSet.Description);
					matrixModel.setProperty(`${contextPath}/activityRegistration/ActivitySetId`, oActSet.ActivitySetId);
				}
			}
		}

	});
	return oMatrix;
});