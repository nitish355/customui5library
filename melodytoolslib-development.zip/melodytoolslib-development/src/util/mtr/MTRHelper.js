sap.ui.define([
	"com/melody/lib/model/formatter",
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/format/DateFormat",
	"sap/ui/core/library",
	"com/melody/lib/service/mtr/MTRService",
	"com/melody/lib/util/mtr/MTR",
	"com/melody/lib/util/Activity",
	"com/melody/lib/util/UserMaster",
	"com/melody/lib/util/Opportunity",
	"com/melody/lib/classes/MtrUser",
	"com/melody/lib/classes/MtrTask",
	"com/melody/lib/classes/mtr/Entry",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	'sap/ui/export/library',
	'sap/ui/export/Spreadsheet',
	'sap/ui/core/BusyIndicator',
	"com/melody/lib/util/mtr/MTRModels",
	"com/melody/lib/service/DateService",
	"com/melody/lib/classes/mtr/Message",
	"com/melody/lib/util/account/Account",
	"com/melody/lib/util/opportunity/Opportunity",
	"com/melody/lib/service/OpportunityService",
],
	function (formatter, Controller, Fragment, JSONModel, DateFormat, coreLibrary, MTRService, MTRUtil, ActivityUtil, UserMaster,
		OpportunityUtil,
		MtrUser, MtrTask,
		Entry, MessageToast, MessageBox, Filter, FilterOperator,
		exportLibrary, Spreadsheet, BusyIndicator, MTRModels, DateService, Message, AccountUtil, OppUtil, OpportunityService) {
		"use strict";
		const CalendarType = coreLibrary.CalendarType;
		const DurationSuggestion = {
			Hour: [{
				key: "0.5",
				value: "0.5",
				allowedOnDay: true
			}, {
				key: "1.0",
				value: "1.0",
				allowedOnDay: true
			}, {
				key: "1.5",
				value: "1.5",
				allowedOnDay: false
			}, {
				key: "2.0",
				value: "2.0",
				allowedOnDay: false
			}, {
				key: "2.5",
				value: "2.5",
				allowedOnDay: false
			}, {
				key: "3.0",
				value: "3.0",
				allowedOnDay: false
			}, {
				key: "3.5",
				value: "3.5",
				allowedOnDay: false
			}, {
				key: "4.0",
				value: "4.0",
				allowedOnDay: false
			}, {
				key: "4.5",
				value: "4.5",
				allowedOnDay: false
			}, {
				key: "5.0",
				value: "5.0",
				allowedOnDay: false
			}, {
				key: "5.5",
				value: "5.5",
				allowedOnDay: false
			}, {
				key: "6.0",
				value: "6.0",
				allowedOnDay: false
			}, {
				key: "6.5",
				value: "6.5",
				allowedOnDay: false
			}, {
				key: "7.0",
				value: "7.0",
				allowedOnDay: false
			}, {
				key: "7.5",
				value: "7.5",
				allowedOnDay: false
			}, {
				key: "8.0",
				value: "8.0",
				allowedOnDay: false
			}],
			Day: [{
				key: "0.5",
				value: "0.5",
				allowedOnDay: true
			}, {
				key: "1.0",
				value: "1.0",
				allowedOnDay: true
			}]
		}
		const MTRHelper = {

			loadTimeRecordingPopover: function (object, view) {
				const that = this;

				if (!this._pTimeRecordingPopover) {
					this._pTimeRecordingPopover = Fragment.load({
						id: view.getId(),
						name: "com.melody.lib.fragments.MTR.TimeRecordingPopover",
						controller: this
					}).then(function (oPopover) {
						view.addDependent(oPopover);
						return oPopover;
					});
				}
				this._pTimeRecordingPopover.then(function (oPopover) {
					oPopover.openBy(object);
				});
			},

			_closeTimeRecordingDialog: function () {
				const that = this;
				const oSettingsModel = MTRModels.getMTRSettingsModel();
				this.Controller._oTimeRecordingDialog.then(function (oDialog) {
					oDialog.close();
					oSettingsModel.setProperty("/IsDisontinuedOppSubmit", false);
					that.Controller.DialogId = null;
					oDialog.destroy();
					that.Controller._oUserActivitiesDialog.destroy();
					that.Controller._oEntriesInfoPopover.destroy();
					if (MTRHelper.hasOwnProperty("oTimeEntryInstance") && typeof (MTRHelper.oTimeEntryInstance.fnTriggerUpdateEntries) === "function") {
						MTRHelper.oTimeEntryInstance.fnTriggerUpdateEntries();
					}
				});
			},

			loadTimeRecordingDialog: function (controller, bControl, model, bCloseDialog) {
				const that = this;
				if (bCloseDialog) {
					this._closeTimeRecordingDialog();
				}
				let oView = null;
				let id = "";
				if (typeof controller.fnTriggerUpdateEntries === "function") {
					MTRHelper.oTimeEntryInstance = controller;
				}
				if (bControl) {
					id = controller.getId() + "_TimeRecordingDialog";
				} else {
					oView = controller.getView();
					id = oView.getId() + "_TimeRecordingDialog";
				}
				let oModel = model;
				if (!oModel) {
					oModel = new JSONModel({
						SelectedDates: [],
						User: user,
						UserSetting: null,
						SelectedActivity: null,
						SelectedMtrTask: null,
						SelectedLocationId: "",
						ShowCalendar: false,
						SelectedTab: "create",
						Entries: [{
							RecordDate: "04/11/2021",
							Task: "Business Development - CF",
							Location: "Virtual",
							Activity: "Demand Generation - PreBA",
							Type: "Cost Center: 0176000711",
							WorkDuration: "8.0"
						}, {
							RecordDate: "11/11/2021",
							Task: "Business Development - CF",
							Location: "Virtual",
							Activity: "Demand Generation - PreBA",
							Type: "Cost Center: 0176000711",
							WorkDuration: "8.0"
						}, {
							RecordDate: "12/11/2021",
							Task: "Business Development - CF",
							Location: "Virtual",
							Activity: "Demand Generation - PreBA",
							Type: "Cost Center: 0176000711",
							WorkDuration: "8.0"
						}]
					});
				}

				this.Controller = (this.Controller) ? this.Controller : new TimeRecordingController();
				this.Controller.Model = oModel;
				const oMtrCalendar = sap.ui.core.Fragment.byId(this.Controller.DialogId, "calendar");
				if (!oMtrCalendar) {
					this.Controller._oTimeRecordingDialog = null;
				}

				if (!this.Controller._oTimeRecordingDialog) {
					that.Controller._oTimeRecordingDialog = Fragment.load({
						id: id,
						// name: "com.melody.lib.fragments.MTR.TimeRecordingDialog",
						name: "com.melody.lib.fragments.MTR.MTRDialog",
						controller: that.Controller
					}).then(function (oDialog) {
						that.Controller.DialogId = id;
						if (bControl) {
							controller.addDependent(oDialog);
						} else {
							oView.addDependent(oDialog);
						}

						return oDialog;
					}.bind(that.Controller));

				}

				this.Controller._oTimeRecordingDialog.then(function (oDialog) {
					if (sap.ui.Device.system.desktop) { // apply compact mode if touch is not supported
						oDialog.addStyleClass("sapUiSizeCompact");
					}

					//check for MyEntries Page in URL
					let oHashChanger = new sap.ui.core.routing.HashChanger();
					let hashValue = oHashChanger.getHash();
					if (hashValue && (hashValue.includes("pcactivityform-app&/MyEntries") || hashValue.includes("/MyEntries"))) {
						that.Controller.Model.setProperty("/bVisibleTimeEntry", false);
					} else {
						that.Controller.Model.setProperty("/bVisibleTimeEntry", true);
					}
					that.Controller.Model.refresh();
					oDialog.setModel(that.Controller.Model);
					// that.Controller.resetDialog();
					const oResourceModel = MTRModels.getMTRResourceModel();
					oDialog.setModel(oResourceModel, "i18n");
					const oMtrSettings = sap.ui.getCore().getModel("mtrSettings");
					oDialog.setModel(oMtrSettings, "mtrSettings");
					const oMessageModel = MTRModels.getMessagesModel();
					oDialog.setModel(oMessageModel, "messages");
					const oTargetModel = MTRModels.getTargetModel();
					oDialog.setModel(oTargetModel, "target");

					oDialog.open();

					const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
					const sTimeMatrics = oMtrSettings.getProperty("/TimeMatrics");
					that.Controller.Model.setProperty("/Durations", sTimeMatrics === "D" ? DurationSuggestion.Day : DurationSuggestion.Hour);
					const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
					that.Controller.Model.setProperty("/Entries", aEntries);
					let oNewEntry = that.Controller.Model.getProperty("/Entry");
					that.Controller.Model.setProperty("/IsOtherTab", false);
					that.Controller.Model.setProperty("/isOthersTabManualIO", false);
					that.Controller.Model.setProperty("/isSpecialTask", false);
					that.Controller.Model.setProperty("/MaxCapacityAlert", false);
					//handling edit case
					const oEntry = aEntries.find(item => item.MtrUid === that.Controller.Model.getProperty("/MtrUid"));
					if (oEntry) {
						that.Controller.Model.setProperty("/IsEdit", true);
						oEntry.TaskId = (oEntry.TaskId) ? oEntry.TaskId.toString() : "";
						const oClonedEntry = $.extend(true, {}, oEntry);
						that.Controller.Model.setProperty("/Entry", oClonedEntry);
						if (oEntry.AddCategoryId === "5") {
							that.Controller.Model.setProperty("/IsOtherTab", true);
							if (oEntry.TaskId === "11") {
								that.Controller.Model.setProperty("/isSpecialTask", true);
								if (oEntry.CostTypeId === "3") {
									that.Controller.Model.setProperty("/isOthersTabManualIO", true);
								}
							}
						}
						if (oEntry.TaskId === "10") {
							that.Controller.Model.setProperty("/IsLearning", true);
						}
						if (oEntry.CostTypeId === "3") {
							that.Controller.Model.setProperty("/isManualIO", true);
						}
					}
					const oCalendar = that.Controller.getCalendar();
					oNewEntry = that.Controller.Model.getProperty("/Entry");
					let entryDate = (oEntry) ? oEntry.Date : oNewEntry.Date;
					oCalendar.removeAllSelectedDates();
					oCalendar.addSelectedDate(new sap.ui.unified.DateRange({
						startDate: entryDate,
						endDate: entryDate
					}));
					oCalendar.setInitialFocusedDate(entryDate);
					that.Controller.Model.setProperty("/IsCustomerFacingVisible", true);
					//hide customer facing when there is no mapping
					const aMtrTasks = that.Controller.Model.getProperty("/MtrTasks");
					if (aMtrTasks && aMtrTasks.length === 1) {
						that.Controller.Model.setProperty("/IsCustomerFacingVisible", false);
					}
					if (oEntry) {
						that.Controller._filterEntries();
						const oActivity = {
							"ActivityId": oEntry.ActvtId,
							"ActAsstId": (oEntry.ActDetails && oEntry.ActDetails.ActAsstId) ? oEntry.ActDetails.ActAsstId : oEntry.CostTypeId === "1" ?
								"502" : (oEntry.CostTypeId === "4") ?
									"501" : "503"
						};
						if (oEntry.AddCategoryId === "5") {
							oActivity.ActAsstId = "";
						}
						that.Controller.Model.setProperty("/Entry/ActAsstId", oActivity.ActAsstId);
						MTRHelper.filterMtrTasks(oActivity, true).then(function (filteredTasktypes) {
							that.Controller.Model.setProperty("/MtrTasks", filteredTasktypes);
							if (filteredTasktypes.length === 1) {
								that.Controller.Model.setProperty("/IsCustomerFacingVisible", false);
							}
							that.Controller._selectMTRTask();
						});
					}
					const sActId = oNewEntry.ActvtId;
					const sActTypeDesc = oNewEntry.ActTypeDesc;
					const sCostTypeId = oNewEntry.CostTypeId;
					const sCostTypeValue = oNewEntry.CostTypeValue;
					const bIsEdit = that.Controller.Model.getProperty("/IsEdit");
					if (sActId) {
						const sTitle = sActTypeDesc + "(" + sActId + ") Entry";
						that.Controller.Model.setProperty("/DailogTitle", sTitle);
					}
					that.Controller._setCostObjectItems(sCostTypeId, sCostTypeValue);
					if (!bIsEdit && sCostTypeId) {
						that.Controller._selectMTRTask();
					}
					that.Controller._setEntriesInfoData(aEntries, oNewEntry.RecordDate);
					if (sCostTypeId === "1") {
						that.Controller.fnSetOppoInfoDetails(sCostTypeValue, "DISPLAYMODE");
						if (oNewEntry.AccountID) {
							that.Controller.fnSetAccountInfoDetails(oNewEntry.AccountID, "DISPLAYMODE");
						}
					} else if (sCostTypeId === "4") {
						that.Controller.fnSetAccountInfoDetails(sCostTypeValue, "DISPLAYMODE");
					}

					// if (!this.Controller._oUserActivitiesDialog) {
					Fragment.load({
						id: id + "_UserActivitiesDialog",
						name: "com.melody.lib.fragments.MTR.UserActivities",
						controller: that.Controller
					}).then(function (oDialog) {
						oDialog.setModel(that.Controller.Model);
						if (bControl) {
							controller.addDependent(oDialog);
						} else {
							oView.addDependent(oDialog);
						}
						that.Controller._oUserActivitiesDialog = oDialog;
						return oDialog;
					}.bind(that.Controller));
					// }
					//creating message popover
					if (!that.Controller._oMessagePopover) {
						that.Controller._oMessagePopover = Fragment.load({
							id: id + "_MessagePopOver",
							name: "com.melody.lib.fragments.MTR.MessagePopover",
							controller: that.Controller
						}).then(function (oPopover) {
							const oMessageModel = MTRModels.getMessagesModel();
							oPopover.setModel(oMessageModel, "messages");
							if (bControl) {
								controller.addDependent(oPopover);
							} else {
								oView.addDependent(oPopover);
							}
							that.Controller._oMessagePopover = oPopover;
							return oPopover;
						});
					}

					//creating existing entries popover
					// if (!that.Controller._oEntriesInfoPopover) {
					that.Controller._oEntriesInfoPopover = Fragment.load({
						id: id + "_EntriesPopOver",
						name: "com.melody.lib.fragments.MTR.EntriesInfoPopover",
						controller: that.Controller
					}).then(function (oPopover) {
						oPopover.setModel(that.Controller.Model);
						let oResourcei18nModel = MTRModels.getMTRResourceModel();
						const oMtrSettings = sap.ui.getCore().getModel("mtrSettings");
						oPopover.setModel(oMtrSettings, "mtrSettings");
						oPopover.setModel(oResourcei18nModel, "i18n");
						if (bControl) {
							controller.addDependent(oPopover);
						} else {
							oView.addDependent(oPopover);
						}
						that.Controller._oEntriesInfoPopover = oPopover;
						return oPopover;
					});
					// }

					//creating activity info popover
					// if (!that.Controller._oEntriesInfoPopover) {
					that.Controller._oActInfoPopover = Fragment.load({
						id: id + "_ActInfoPopOver",
						name: "com.melody.lib.fragments.MTR.ActInfoPopover",
						controller: that.Controller
					}).then(function (oPopover) {
						oPopover.setModel(that.Controller.Model);
						let oResourcei18nModel = MTRModels.getMTRResourceModel();
						oPopover.setModel(oResourcei18nModel, "i18n");
						if (bControl) {
							controller.addDependent(oPopover);
						} else {
							oView.addDependent(oPopover);
						}
						that.Controller._oActInfoPopover = oPopover;
						return oPopover;
					});
					// }
				});
			},

			_getUserMtrSettings: async function () {
				let oUserMtrSettingsModel = sap.ui.getCore().getModel("userMtrSettings");

				let oUserMtrSettings = (oUserMtrSettingsModel) ? oUserMtrSettingsModel.getData() : null;

				if (!oUserMtrSettings) {
					oUserMtrSettings = await this._fetchMtrConfig();

					oUserMtrSettingsModel = new JSONModel(oUserMtrSettings);
					sap.ui.getCore().setModel(oUserMtrSettingsModel, "userMtrSettings");
				}

				return oUserMtrSettings;

			},

			_fetchMtrConfig: async function () {
				const oUser = await UserMaster.authenticate();
				const oOREData = [];
				let oData = {};

				let oMtrUser = null;

				if (oUser) {
					// transforms post data as per the service input
					for (let i in oUser) {
						if (i && i !== "__metadata" && i !== "" && oUser[i] && oUser[i] !== "" && (typeof oUser[i]) === "string") {
							var obj = {
								UserId: oUser.UserId,
								ConstantType: i,
								ConstantValue: oUser[i]
							};
							oOREData.push(obj);
						}
					}
					const postData = {
						UserId: oUser.UserId,
						ApplicationId: "MTR",
						N_UserIDToConstant: oOREData
					};
					try {
						oData = await MTRService.getUserMtrConfig(postData);
					} catch (e) {
						console.log(e);
						throw new Error("Error while fetching Time Recording Configurations");
					}
					oMtrUser = {
						UserId: oUser.UserId,
						UserGuid: oData.UserGuid,
						FirstName: oData.FirstName,
						LastName: oData.LastName,
						Email: oData.Email,
						Status: oData.Status,
						IsUnitEdit: oData.IsUnitEdit,
						ProfileId: (oData.ProfileId && oData.ProfileId !== "") ? oData.ProfileId : "1",
						TimeSheetUnit: (oData.TimeSheetUnit && oData.TimeSheetUnit !== "") ? oData.TimeSheetUnit : "H",
						ActivityRecording: oUser.ActivityRecording,
						Durations: (oData.TimeSheetUnit && oData.TimeSheetUnit !== "" && oData.TimeSheetUnit === "D") ? DurationSuggestion.Day : DurationSuggestion
							.Hour,
						CostCenter: oUser.CostCenter,
						IsTimeRec: oData.IsTimeRec
					};

					oMtrUser.PartnerId = await OpportunityUtil.getBusinessPartner(oMtrUser.UserId);

					oMtrUser.MtrTasks = await this.getMtrMasterData(oMtrUser.ProfileId);
					//commented this due to performance issue
					// oMtrUser.ActivityTaskTypes = await MTRUtil.getAllActivityTaskTypes();
					oMtrUser.ActivityTaskTypes = []; //Assigned emtry array as we are not using this anywhere
					oMtrUser.ActivityRole = await ActivityUtil.getUserActivityRole();
				} else {
					throw new Error("User is not active in ORE");
				}

				return oMtrUser;
			},

			getMtrMasterData: async function (sProfileId) {
				const oResponse = await MTRService.getMtrMasterData(sProfileId);

				const aMtrTasks = [];

				const aTasks = oResponse.to_Activity.results;

				const aCostTypeMap = oResponse.to_ActivityCostTypeMap.results;
				const aCostTypes = oResponse.to_CostType.results;

				const aLocationMap = oResponse.to_ActivityLocationMap.results;
				const aLocations = oResponse.to_Location.results;

				for (let i = 0; i < aTasks.length; i++) {
					const oMtrTask = {
						MtrTaskID: aTasks[i].activity_id,
						MtrTaskName: aTasks[i].ActivityName,
						MtrTaskDescription: aTasks[i].ActivityDescription,
						CategoryId: aTasks[i].CategoryId.toString(),
						IsArchive: aTasks[i].IsArchive,
						MtrCostTypes: [],
						MtrLocations: []
					};

					const aFilteredCostTypes = aCostTypeMap.filter(item => item.ActivityID === oMtrTask.MtrTaskID);
					for (let j = 0; j < aFilteredCostTypes.length; j++) {
						const oCostType = aCostTypes.find(item => item.CostTypeID === aFilteredCostTypes[j].CostTypeID);
						oMtrTask.MtrCostTypes.push({
							CostTypeId: oCostType.CostTypeID,
							CostTypeName: oCostType.CostTypeName
						});
					}

					const aFilteredLocations = aLocationMap.filter(item => item.ActivityID === oMtrTask.MtrTaskID);
					for (let j = 0; j < aFilteredLocations.length; j++) {
						const oLocation = aLocations.find(item => item.LocationId === aFilteredLocations[j].LocationID && item.LocationId.toString() !==
							"2" && item.LocationId.toString() !== "3");
						if (oLocation) {
							oMtrTask.MtrLocations.push({
								LocationId: oLocation.LocationId,
								LocationName: oLocation.LocationName
							});
						}
					}
					aMtrTasks.push(oMtrTask);
				}

				return aMtrTasks;
			},

			_filterTaskData: function () {

			},

			getUserMtrSettings: async function () {
				let bIsValid = false;
				let oMtrUser = null;
				try {
					oMtrUser = await this._getUserMtrSettings();
					bIsValid = true;
				} catch (e) {
					MessageToast.show(e);
				}

				return {
					IsValid: bIsValid,
					UserSetting: oMtrUser
				}
			},

			/*getAllActivityTaskTypes: async function () {
				let oActivityTaskTypesModel = sap.ui.getCore().getModel("activityTaskTypes");
				let aActivityTaskTypes = [];
				if (oActivityTaskTypesModel && oActivityTaskTypesModel.getData()) {
					aActivityTaskTypes = oActivityTaskTypesModel.getData();
				} else {
					aActivityTaskTypes = await MTRService.getAllActivityTaskTypes();
					oActivityTaskTypesModel = new JSONModel(aActivityTaskTypes);
					sap.ui.getCore().setModel(oActivityTaskTypesModel, "activityTaskTypes");
				}
				return aActivityTaskTypes;
			},*/

			getActivityTaskTypes: async function (activity) {
				return await MTRService.getActivityTaskTypes(activity);
			},

			getEntries: async function (sUserGuid) {
				const aEntries = [];
				let oUserMtrSettingsData = await this.getUserMtrSettings();
				if (!oUserMtrSettingsData) {
					return [];
				}

				let oUserMtrSettings = oUserMtrSettingsData.UserSetting;

				if (!oUserMtrSettings) {
					return [];
				}

				const aResult = await MTRService.getEntries(sUserGuid);

				const aActivities = await ActivityUtil.getUserActivities();

				const aMtrTasks = oUserMtrSettings.MtrTasks;

				const aActivityTaskTypes = oUserMtrSettings.ActivityTaskTypes;

				for (let i = 0; i < aResult.length; i++) {
					if (aResult[i].MtrUid && aResult[i].MtrUid !== "") {

						const oActivity = aActivities.find(item => item.ActivityId === aResult[i].ActvtId);
						let sActivityTypeId = "";
						let sActTypeDesc = "";
						if (oActivity) {
							sActivityTypeId = oActivity.ActivityTypeId;
							sActTypeDesc = oActivity.ActTypeDesc;
						}
						const oMtrTask = aMtrTasks.find(item => item.MtrTaskID === aResult[i].ActivityId);
						let sAssociationId = "";

						if (aResult[i].CostTypeId === 4) {
							sAssociationId = "501";
						} else if (aResult[i].CostTypeId === 1) {
							sAssociationId = "502";
						} else if (aResult[i].CostTypeId === 2) {
							sAssociationId = "503";
						}

						const aFilteredActivityTaskTypes = JSON.parse(JSON.stringify(await this.filterMtrTasks(oActivity)));

						if (aFilteredActivityTaskTypes.length > 0) {
							sActTypeDesc = aFilteredActivityTaskTypes[0].ActTypeDesc;
						}

						const sTimestamp = (aResult[i].Timestamp) ? aResult[i].Timestamp.trim() : "";
						let dCreatedOn = new Date();
						if (sTimestamp && sTimestamp !== "") {
							dCreatedOn = new Date(sTimestamp.substring(0, 4) + "/" + sTimestamp.substring(4, 6) + "/" + sTimestamp.substring(6, 8) + " " +
								sTimestamp.substring(8, 10) + ":" + sTimestamp.substring(10, 12) + ":" + sTimestamp.substring(12, 14))
						}

						const oEntry = new Entry(oUserMtrSettings.PartnerId, {
							MtrUid: aResult[i].MtrUid,
							RecordDate: aResult[i].RecordDate,
							MtrTaskID: aResult[i].ActivityId,
							MtrTaskName: (oMtrTask) ? oMtrTask.MtrTaskName : "",
							LocationId: aResult[i].LocationId,
							CostTypeId: aResult[i].CostTypeId,
							CostTypeValue: aResult[i].CostTypeValue,
							WorkDuration: (aResult[i].WorkDuration) ? parseFloat(aResult[i].WorkDuration, 10).toFixed(1) : "",
							ActvtId: aResult[i].ActvtId,
							ActivityTypeName: sActTypeDesc,
							Unit: aResult[i].Unit,
							Note: aResult[i].Note,
							MtrLocations: (oMtrTask) ? oMtrTask.MtrLocations : [],
							MtrTasks: aFilteredActivityTaskTypes,
							StatusId: aResult[i].StatusId,
							MsgText: aResult[i].MsgText,
							ProjectType: aResult[i].ProjectType,
							CreatedOn: dCreatedOn
						});
						aEntries.push(oEntry);
					}
				}
				return aEntries;
			},

			filterMtrTasks: async function (oSelectedActivity, isEditTimeEntry) {

				//commented due to performance issue
				// const aActivityTaskTypes = await MTRUtil.getAllActivityTaskTypes();

				const oUserActivityRole = await ActivityUtil.getUserActivityRole();
				if (!oSelectedActivity || !oUserActivityRole) {
					return [];
				}

				const aUserActivities = await ActivityUtil.getUserActivities();

				const oUserActivity = aUserActivities.find(item => {
					return item.ActivityId === oSelectedActivity.ActivityId && item.ActAsstId === oSelectedActivity.ActAsstId;
				});

				if (!oUserActivity) {
					return [];
				}

				if (isEditTimeEntry) {
					oSelectedActivity = oUserActivity;
				}

				//To Handle SL Lead
				let sParentRoleId = oSelectedActivity["ParentRoleId"];
				if (oSelectedActivity["ParentRoleId"] === "0066" && oSelectedActivity["IsSlLead"] === "X") {
					sParentRoleId = oUserActivityRole["ParentRoleID"];
				}

				//commented due to performance issue
				/*let aFilteredActivityTaskTypes = aActivityTaskTypes.filter(item => item.ActvtTypeID.toString() === oSelectedActivity.ActivityTypeId
					.toString() && oSelectedActivity.ActAsstId.toString() === item.ActvtAsstdID.toString() && sParentRoleId.toString() ===
					item.ParentRoleId.toString());
	
				let aUpdatedActivityTaskTypes = aFilteredActivityTaskTypes.filter(item => parseInt(item.RoleMpngID, 10) === parseInt(
					oUserActivityRole.RoleMpngID, 10));*/

				const oAct = {
					"ActivityTypeId": oSelectedActivity.ActivityTypeId,
					"ActAsstId": oSelectedActivity.ActAsstId,
					// "ParentRoleId": sParentRoleId,
					"RoleMpngID": oSelectedActivity.RoleMpngID
				};
				const aActivityMappedTaskTypes = await MTRService.getActivityTaskTypes(oAct);

				return aActivityMappedTaskTypes;
			},

			getActivityTypeTaskMapping: async function (sActivityTypeId, sActAsstId) {

				if (!sActivityTypeId || sActivityTypeId === "" || !sActAsstId || sActAsstId === "") {
					return [];
				}

				//commented due to performance issue
				// const aActivityTaskTypes = await MTRUtil.getAllActivityTaskTypes();
				const oUserActivityRole = await ActivityUtil.getUserActivityRole();
				if (!oUserActivityRole) {
					return [];
				}

				/*let act = aActivityTaskTypes.filter(item => oUserActivityRole.ParentRoleID.toString() ===
					item.ParentRoleId.toString());
	
				const aUserActivities = await ActivityUtil.getUserActivities();*/

				//commented due to performance issue
				/*let aFilteredActivityTaskTypes = aActivityTaskTypes.filter(item => item.ActvtTypeID.toString() === sActivityTypeId
					.toString() && sActAsstId.toString() === item.ActvtAsstdID.toString() && oUserActivityRole.ParentRoleID.toString() ===
					item.ParentRoleId.toString());
	
				let aUpdatedActivityTaskTypes = aFilteredActivityTaskTypes.filter(item => parseInt(item.RoleMpngID, 10) === parseInt(
					oUserActivityRole.RoleMpngID,
					10));*/

				const oAct = {
					"ActivityTypeId": sActivityTypeId,
					"ActAsstId": sActAsstId,
					// "ParentRoleId": oUserActivityRole.ParentRoleID,
					"RoleMpngID": oUserActivityRole.RoleMpngID
				};
				const aActivityMappedTaskTypes = await MTRService.getActivityTaskTypes(oAct);

				return aActivityMappedTaskTypes;
			},

			getUserGuidSettings: async function (sUserGuid, mParameters) {
				mParameters = OpportunityUtil.fnGetServiceParameters(mParameters);
				let oData = await MTRService.getUserGuidSettings(sUserGuid, mParameters);
				return {
					IsFirstTimeUser: false,
					CustId: (oData && oData.CustId) ? oData.CustId : "",
					Language: (oData && oData.Language) ? oData.Language : "",
					UserGuid: (oData && oData.UserGuid) ? oData.UserGuid : "",
					EssInMu: (oData && (oData.EssInMu === "")) ? false : true,
					Timesheet: (oData && oData.Timesheet) ? oData.Timesheet : "",
					PartnerId: (oData && oData.PartnerId) ? oData.PartnerId : "",
					CreatedOn: (oData && oData.CreatedOn) ? oData.CreatedOn : "",
					UpdatedOn: (oData && oData.UpdatedOn) ? oData.UpdatedOn : "",
					IsArchive: (oData && oData.IsArchive) ? oData.IsArchive : "",
					DateFormat: (oData && oData.DateFormat) ? oData.DateFormat : "",
					CreatedTime: (oData && oData.CreatedTime) ? oData.CreatedTime : "",
					UpdatedTime: (oData && oData.UpdatedTime) ? oData.UpdatedTime : "",
					PrdProfMapId: (oData && oData.PrdProfMapId) ? oData.PrdProfMapId : "",
					TimeSheetUnit: (oData && oData.TimeSheetUnit) ? oData.TimeSheetUnit : "",

					to_MANUAL: (oData && oData.to_MANUAL) ? oData.to_MANUAL.results : [],
					to_ACCOUNT: (oData && oData.to_ACCOUNT) ? oData.to_ACCOUNT.results : [],
					to_OPPORTUNITYIO: (oData && oData.to_OPPORTUNITYIO) ? oData.to_OPPORTUNITYIO.results : [],
				}
			},

			getEntryLookups: async function (iPrdMapId, mParameters) {
				const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				let Lookup = oStorage.get("Lookup");
				if (Lookup) {
					return Lookup;
				}
				mParameters = OpportunityUtil.fnGetServiceParameters(mParameters);
				let oData = await MTRService.getEntryLookups(iPrdMapId, mParameters);
				if (oData) {
					oData.to_Status = oData.to_Status ? oData.to_Status.results : [];
					oData.to_Activity = oData.to_Activity ? oData.to_Activity.results : [];
					oData.to_Category = oData.to_Category ? oData.to_Category.results : [];
					oData.to_CostType = oData.to_CostType ? oData.to_CostType.results : [];
					oData.to_Location = oData.to_Location ? oData.to_Location.results : [];
					oData.to_ActivityCostTypeMap = oData.to_ActivityCostTypeMap ? oData.to_ActivityCostTypeMap.results : [];
					oData.to_ActivityLocationMap = oData.to_ActivityLocationMap ? oData.to_ActivityLocationMap.results : [];
					oStorage.put("Lookup", oData);
				}
				return oData;
			},

			getSettingLookups: async function (mParameters) {
				mParameters = OpportunityUtil.fnGetServiceParameters(mParameters);
				let oData = await MTRService.getSettingLookups(mParameters);
				let dateFormats = [];
				let timesheetPrefs = [];
				if (oData) {
					timesheetPrefs = oData.filter(function (domain) {
						return domain.Type === "YDO_TIMESHEETPREF";
					});
					dateFormats = oData.filter(function (domain) {
						return domain.Type === "YDO_DATEFORMARTID";
					});
				}
				return [timesheetPrefs, dateFormats];
			}
		}

		const TimeRecordingModel = new JSONModel({
			SelectedDates: []
		});

		const TimeRecordingController = Controller.extend("com.melody.lib.controller.TimeRecording", {
			formatter: formatter,
			oFormatYyyymmdd: null,
			constructor: function () {
				this.oFormatYyyymmdd = DateFormat.getInstance({
					pattern: "MMM-dd",
					calendarType: CalendarType.Gregorian
				});
			},

			handleTaskPopoverPress: function (oEvent) {

				if (!this._oTaskPopover) {
					this._oTaskPopover = sap.ui.xmlfragment(
						"com.melody.lib.fragments.MTR.TaskPopover",
						this);
				}
				this._oTaskPopover.setModel(this.Model);
				this._oTaskPopover.openBy(oEvent.getSource());

			},

			handleTaskPopoverClose: function () {
				this._oTaskPopover.close();
			},

			onSelectTab: function (oEvent) {
				const sSelectedTab = oEvent.getParameter("key");
				if (sSelectedTab === "submitted") {
					this._goToMtr();
				}
			},

			getSearchFilters: function (query) {
				return new Filter({
					filters: [
						new Filter("MtrTaskName", FilterOperator.Contains, query),
						new Filter("ActivityTypeName", FilterOperator.Contains, query),
					],
					and: false,
				});
			},

			_goToMtr: function () {
				BusyIndicator.show(0);
				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#mtr-app&/entries/Saved"
					}
				});
			},

			handleErrorListPress: function (oEvent) {

				const sMsgText = oEvent.getSource().data("msgText");

				if (sMsgText) {
					if (!this.ErrorPopover) {
						this.ErrorPopover = sap.ui.xmlfragment(
							"com.melody.lib.fragments.MTR.EntryErrorPopover",
							this);
					}
					this.ErrorPopover.setModel(new JSONModel({
						MsgText: sMsgText
					}));
					this.ErrorPopover.openBy(oEvent.getSource());
				}
			},

			handleCloseEntryErrorPopover: function () {
				this.ErrorPopover.close();
			},

			onSearchEntries: function (oEvent) {

				const genericDateFormat = sap.ui.core.format.DateFormat.getInstance({
					pattern: "yMMdd",
					calendarType: sap.ui.core.CalendarType.Gregorian
				});

				const idSearchField = sap.ui.core.Fragment.byId(this.DialogId, "savedEntries--idSearchEntries");
				const reportFromDate = sap.ui.core.Fragment.byId(this.DialogId, "savedEntries--reportFromDate");
				const reportToDate = sap.ui.core.Fragment.byId(this.DialogId, "savedEntries--reportToDate");

				const dFromDate = reportFromDate.getDateValue();
				const dToDate = reportToDate.getDateValue();

				var sQuery = idSearchField.getValue();

				const aFilters = [];

				aFilters.push(this.getSearchFilters(sQuery));

				if (dFromDate && dToDate) {
					aFilters.push(new sap.ui.model.Filter("Date", sap.ui.model.FilterOperator.BT, dFromDate, dToDate));
				}

				const idSavedEntriesTable = sap.ui.core.Fragment.byId(this.DialogId, "savedEntries--idSavedEntriesTable");
				idSavedEntriesTable.getBinding("items").filter(new Filter({
					filters: aFilters,
					and: true,
				}), sap.ui.model.FilterType.Application);
			},

			onResetSavedEntries: function (oEvent) {
				const idSearchField = sap.ui.core.Fragment.byId(this.DialogId, "savedEntries--idSearchEntries");
				const reportFromDate = sap.ui.core.Fragment.byId(this.DialogId, "savedEntries--reportFromDate");
				const reportToDate = sap.ui.core.Fragment.byId(this.DialogId, "savedEntries--reportToDate");

				idSearchField.setValue("");
				reportFromDate.setValue("");
				reportToDate.setValue("");

				this.onSearchEntries();
			},

			getMtrTask: function (sMtrTaskID) {
				if (!sMtrTaskID) {
					return null;
				}
				const oUserMtrSettingsModel = sap.ui.getCore().getModel("userMtrSettings");
				const oUserSettings = (oUserMtrSettingsModel) ? oUserMtrSettingsModel.getData() : null;

				if (!oUserSettings) {
					return null;
				}

				const aMtrTasks = oUserSettings.MtrTasks;

				const oMtrTask = aMtrTasks.find(item => item.MtrTaskID.toString() === sMtrTaskID.toString());

				return oMtrTask;
			},

			handleToggleContent: function (oEvent) {
				const oDynamicSideContent = sap.ui.core.Fragment.byId(this.DialogId, "DynamicSideContent");
				oDynamicSideContent.toggle();
				this.Model.setProperty("/ShowCalendar", !this.Model.getProperty("/ShowCalendar"))
			},

			handleCalendarSelect: function (oEvent) {
				var aSelectedDates = oEvent.getParameter("selectedDates"),
					oDate,
					i;
				let sSelectedDates = "";
				if (aSelectedDates.length > 0) {
					for (i = 0; i < aSelectedDates.length; i++) {
						oDate = aSelectedDates[i].getStartDate();
						let sRegion = sap.ui.getCore().getModel("userUtility").getProperty("/RegionName");
						let todayDate = new Date();
						if (sRegion === "NA" && oDate.getFullYear() < todayDate.getFullYear()) {
							MessageToast.show("Time recording for date(s) prior to 31 Dec 2022 is restricted.");
							this.clearSelectedDates();
							return;
						}
						sSelectedDates += this.oFormatYyyymmdd.format(oDate);
						if (i < aSelectedDates.length - 1) {
							sSelectedDates += ", "
						}
						this.Model.setProperty("/SelectedDates", sSelectedDates);
					}

					const cmbDuration = sap.ui.core.Fragment.byId(this.DialogId, "cmbDuration");
					this.validateDuration(cmbDuration);

					this.Model.refresh(true);
				} else {
					this.clearSelectedDates();
				}
			},

			onChangeDuration: function (oEvent) {
				this.validateDuration(oEvent.getSource());
			},

			onSelectLocation: function (oEvent) {
				const oSource = oEvent.getSource();

				const oSelectedRadioButton = oSource.getSelectedButton();

				const sKey = oSelectedRadioButton.data("key");

				this.Model.setProperty("/SelectedLocationId", sKey);
			},

			getCalendar: function () {
				const oMtrCalendar = sap.ui.core.Fragment.byId(this.DialogId, "calender");
				const oCalendar = oMtrCalendar.getAggregation("_calendar");
				return oCalendar;
			},

			onSaveEntries: function () {
				const that = this;
				const genericDateFormat = sap.ui.core.format.DateFormat.getInstance({
					pattern: "yMMdd",
					calendarType: sap.ui.core.CalendarType.Gregorian
				});
				const oUserSetting = this.Model.getProperty("/UserSetting");
				/*const oCalendar = sap.ui.core.Fragment.byId(this.DialogId, "calendar");*/
				const oCalendar = this.getCalendar();
				const oSelectedActivity = this.Model.getProperty("/SelectedActivity");

				const aMtrTasks = oUserSetting.MtrTasks;

				const aSelectedDates = oCalendar.getSelectedDates();

				if (aSelectedDates.length === 0) {
					MessageToast.show("Please select date(s)");
					return;
				}

				const cmbMtrTask = sap.ui.core.Fragment.byId(this.DialogId, "cmbMtrTask");
				const sMtrTaskID = cmbMtrTask.getSelectedKey();

				if (!sMtrTaskID) {
					MessageToast.show("Please select Task");
					return;
				}

				const oMtrTask = aMtrTasks.find(item => item.MtrTaskID.toString() === sMtrTaskID.toString());

				const rbgLocation = sap.ui.core.Fragment.byId(this.DialogId, "rbgLocation");
				const oSelectedRadioButton = rbgLocation.getSelectedButton();
				let sLocationId = "";
				if (oSelectedRadioButton) {
					let aRadioButtons = rbgLocation.getButtons();
					for (let i = 0; i < aRadioButtons.length; i++) {
						let oTempButton = aRadioButtons[i];
						if (oTempButton.getSelected()) {
							let oCurrentData = oTempButton.getBindingContext().getObject();
							if (oCurrentData.hasOwnProperty("LocationId")) {
								sLocationId = oCurrentData.LocationId;
							}
						}
					}
					if (!sLocationId) {
						MessageToast.show("Please select Location");
						return;
					}
				}

				const cmbDuration = sap.ui.core.Fragment.byId(this.DialogId, "cmbDuration");
				const sWorkDuration = cmbDuration.getValue();

				if (!sWorkDuration) {
					MessageToast.show("Please select Time Duration");
					return;
				}

				let sCostTypeId = "";
				let sCostTypeValue = oSelectedActivity.CostTypeValue;
				if (oSelectedActivity) {
					if (oSelectedActivity.ActAsstId === "501") {
						sCostTypeId = "4";
					} else if (oSelectedActivity.ActAsstId === "502") {
						sCostTypeId = "1";
					} else if (oSelectedActivity.ActAsstId === "503") {
						sCostTypeId = "2"
						sCostTypeValue = oUserSetting.CostCenter;
					}
				}

				if (!sCostTypeId || sCostTypeId === "") {
					MessageToast.show("Cost Type is not valid");
					return;
				}

				const sUnit = oUserSetting.TimeSheetUnit;

				const txtNotes = sap.ui.core.Fragment.byId(this.DialogId, "txtNotes");
				const sNote = txtNotes.getValue();

				const aSelectedMtrTasks = this.Model.getProperty("/MtrTasks");

				const oSelectedMtrTask = aSelectedMtrTasks.find(item => item.MtrTaskID.toString() === sMtrTaskID);

				const sPartnerId = oUserSetting.PartnerId;
				const aEntriesToAdd = [];
				const aEntriesToSave = [];
				for (let i = 0; i < aSelectedDates.length; i++) {

					const dRecordDate = aSelectedDates[i].getStartDate();
					const sRecordDate = genericDateFormat.format(dRecordDate);

					const oEntry = new Entry(sPartnerId, {
						RecordDate: sRecordDate,
						MtrTaskID: sMtrTaskID,
						MtrTaskName: (oSelectedMtrTask) ? oSelectedMtrTask.MtrTaskName : "",
						LocationId: sLocationId,
						CostTypeId: sCostTypeId,
						CostTypeValue: oSelectedActivity.CostTypeValue,
						WorkDuration: sWorkDuration,
						ActvtId: oSelectedActivity.ActivityId,
						ActivityTypeName: oSelectedActivity.ActTypeDesc,
						ProjectType: oSelectedActivity.ProjectType,
						Unit: sUnit,
						Note: sNote,
						MtrLocations: (oMtrTask) ? oMtrTask.MtrLocations : [],
						MtrTasks: this.Model.getProperty("/MtrTasks")
					});
					aEntriesToAdd.push(oEntry);
					aEntriesToSave.push(oEntry.getLSRequest({
						UserGuid: oUserSetting.UserGuid,
						ProfileId: oUserSetting.ProfileId,
					}));
				}

				this._saveEntries(aEntriesToSave)
					.then(response => {
						if (response) {
							const aEntries = that.Model.getProperty("/Entries");
							aEntries.push(...aEntriesToAdd);
							that.Model.refresh(true);
							let sSuccessMsg = "Entry";
							if (aEntries.length > 1) {
								sSuccessMsg = "Entries"
							}
							MessageToast.show("Time " + sSuccessMsg + " saved successfully");
						}

						//const idIconTabBar = sap.ui.core.Fragment.byId(that.DialogId, "idIconTabBar");
						that.Model.setProperty("/SelectedTab", "saved");
						that.clearDialog();
					});
			},

			_saveEntries: async function (aEntries) {
				const oUserSetting = this.Model.getProperty("/UserSetting");
				if (aEntries.length > 0) {
					const postData = {
						UserGuid: oUserSetting.UserGuid,
						N_TimesheetDetail: aEntries
					};

					return await MTRService.saveEntries(postData);
				}
			},

			onSelectMtrTask: function (oEvent) {
				const oSelectedItem = oEvent.getParameter("selectedItem");
				const sKey = oSelectedItem.getKey();

				const aMtrTasks = this.Model.getProperty("/UserSetting/MtrTasks");

				const oMtrTask = aMtrTasks.find(item => item.MtrTaskID.toString() === sKey);

				this.Model.setProperty("/SelectedMtrTask", oMtrTask);
			},

			handleCloseTimeRecordingDialog: function () {
				this.clearDialog();

				this._oTimeRecordingDialog.then(function (oDialog) {
					oDialog.close();
				});
			},

			handleRemoveSelection: function () {
				this.clearSelectedDates();
			},

			clearSelectedDates: function () {
				const oCalendar = this.getCalendar();
				oCalendar.removeAllSelectedDates();
				this.Model.setProperty("/SelectedDates", "");
			},

			calculateDuration: function (sWorkDuration, sRecordDate, sMtrUid) {
				const aRecordDates = [];
				if (!sRecordDate) {
					const oCalendar = this.getCalendar();

					const oDateFormat = DateFormat.getInstance({
						pattern: "yMMdd",
						calendarType: CalendarType.Gregorian
					});

					var aSelectedDates = oCalendar.getSelectedDates(),
						oDate;
					if (aSelectedDates.length > 0) {
						for (let i = 0; i < aSelectedDates.length; i++) {
							oDate = aSelectedDates[i].getStartDate();
							aRecordDates.push(oDateFormat.format(oDate));
						}
					} else {
						return true;
					}
				} else {
					aRecordDates.push(sRecordDate);
				}
				const aEntries = this.Model.getProperty("/Entries");
				const aTotalDurations = [];
				let sMsg = "Time recorded is more than 24 hours for ";
				for (let i = 0; i < aRecordDates.length; i++) {
					let aFilteredByRecordDate;
					if (sMtrUid) {
						aFilteredByRecordDate = aEntries.filter(item => item.RecordDate === aRecordDates[i] && item.MtrUid !== sMtrUid);
					} else {
						aFilteredByRecordDate = aEntries.filter(item => item.RecordDate === aRecordDates[i]);
					}

					let iTotalDuration = 0;

					for (let j = 0; j < aFilteredByRecordDate.length; j++) {
						const iDuration = (aFilteredByRecordDate[j].WorkDuration && aFilteredByRecordDate[j].WorkDuration !== "") ? parseFloat(
							aFilteredByRecordDate[j].WorkDuration, 10) : 0;
						iTotalDuration += iDuration;
					}

					if (sWorkDuration && sWorkDuration !== "") {
						iTotalDuration += parseFloat(sWorkDuration, 10);
					}

					if (iTotalDuration > 24) {
						aTotalDurations.push({
							RecordDate: aRecordDates[i],
							TotalDuration: iTotalDuration
						});

						sMsg += " " + aRecordDates[i].substring(0, 4) + "/" + aRecordDates[i].substring(4, 6) + "/" + aRecordDates[i].substring(6, 8);
					}
				}

				if (aTotalDurations.length > 0) {
					MessageToast.show(sMsg);
					return false;
				} else {
					return true;
				}
			},

			handleEditTimeRecordPress: function (oEvent) {
				const that = this;
				const oSource = oEvent.getSource();
				const oBindingContext = oSource.getParent().getBindingContext();
				const oModel = oBindingContext.getModel();
				const sPath = oBindingContext.getPath();

				const oEntry = oModel.getProperty(sPath);
				oEntry.TempRecordDate = oEntry.RecordDate;
				oEntry.TempMtrTaskID = oEntry.MtrTaskID;
				oEntry.TempLocationId = oEntry.LocationId;
				oEntry.TempWorkDuration = oEntry.WorkDuration;
				oEntry.IsEdit = true;
				oModel.refresh(true);
			},

			handleUpdateTimeRecordPress: function (oEvent) {
				const oSource = oEvent.getSource();
				const oBindingContext = oSource.getParent().getBindingContext();
				const oModel = oBindingContext.getModel();
				const sPath = oBindingContext.getPath();

				const oEntry = oModel.getProperty(sPath);

				const oUserSetting = this.Model.getProperty("/UserSetting");

				const aMtrTasks = oEntry.MtrTasks;

				const oMtrTask = aMtrTasks.find(item => item.MtrTaskID.toString() === oEntry.TempMtrTaskID.toString());

				if (oMtrTask) {
					oEntry.TempMtrTaskName = oMtrTask.MtrTaskName;
				}

				const oTempEntry = new Entry(null, {
					MtrUid: oEntry.MtrUid,
					RecordDate: oEntry.TempRecordDate,
					MtrTaskID: oEntry.TempMtrTaskID,
					MtrTaskName: oEntry.TempMtrTaskName,
					LocationId: (oEntry.MtrLocations && oEntry.MtrLocations.length > 0 && oEntry.TempLocationId) ? oEntry.TempLocationId : 0,
					CostTypeId: oEntry.CostTypeId,
					CostTypeValue: oEntry.CostTypeValue,
					WorkDuration: oEntry.TempWorkDuration,
					ActvtId: oEntry.ActvtId,
					ProjectType: oEntry.ProjectType,
					Unit: oEntry.Unit,
					Note: oEntry.Note
				});

				const cmbDuration = oSource.getParent().getParent().getCells()[5].getItems()[1];
				if (!this.validateDuration(cmbDuration, oTempEntry.RecordDate, oTempEntry.MtrUid)) {
					return;
				}

				oEntry.TempWorkDuration = parseFloat(cmbDuration.getValue(), 10).toFixed(1);
				oTempEntry.WorkDuration = parseFloat(cmbDuration.getValue(), 10).toFixed(1);

				const oEntryToUpdate = oTempEntry.getLSRequest({
					UserGuid: oUserSetting.UserGuid,
					ProfileId: oUserSetting.ProfileId,
					Indicator: "U"
				});

				this._saveEntries([oEntryToUpdate])
					.then(result => {
						oEntry.RecordDate = oEntry.TempRecordDate;
						oEntry.MtrTaskID = oEntry.TempMtrTaskID;
						oEntry.MtrTaskName = oEntry.TempMtrTaskName;
						oEntry.LocationId = oEntry.TempLocationId;
						oEntry.WorkDuration = oEntry.TempWorkDuration;
						oEntry.IsEdit = false;
						oModel.refresh(true);
					});

			},

			handleCancelTimeRecordPress: function (oEvent) {
				const oSource = oEvent.getSource();
				const oBindingContext = oSource.getParent().getBindingContext();
				const oModel = oBindingContext.getModel();
				const sPath = oBindingContext.getPath();

				const oEntry = oModel.getProperty(sPath);
				oEntry.TempRecordDate = oEntry.RecordDate;
				oEntry.TempMtrTaskID = oEntry.MtrTaskID;
				oEntry.TempLocationId = oEntry.LocationId;
				oEntry.TempWorkDuration = oEntry.WorkDuration;
				oEntry.IsEdit = false;
				oModel.refresh(true);
			},

			handleEditTimeRecordCloseButton: function (oEvent) {
				// note: We don't need to chain to the _pPopover promise, since this event-handler
				// is only called from within the loaded dialog itself.
				this._pTimeRecordingPopover.then(function (oPopover) {
					oPopover.close();
				});
			},

			onSelectEntryMtrTask: function (oEvent) {
				const oSelectedItem = oEvent.getParameter("selectedItem");
				const sSelectedKey = oSelectedItem.getKey();

				const oSource = oEvent.getSource();
				const oItem = oSource.getParent().getParent();

				const oBindingContext = oItem.getBindingContext();
				const sPath = oBindingContext.getPath();
				const oModel = oBindingContext.getModel();

				const oEntry = oModel.getProperty(sPath);

				const aMtrTasks = oModel.getProperty("/UserSetting/MtrTasks");

				const oMtrTask = aMtrTasks.find(item => item.MtrTaskID.toString() === sSelectedKey.toString());

				if (oMtrTask) {
					oEntry.MtrLocations = oMtrTask.MtrLocations;
					oEntry.TempMtrTaskName = oMtrTask.MtrTaskName;
				} else {
					oEntry.MtrLocations = [];
					oEntry.TempMtrTaskName = "";
				}
				oModel.refresh(true);
			},

			resetDialog: function () {
				this.enableDeleteButton(false);
				this.bindCombo();
				this.clearSelectedDates();
				this.Model.setProperty("/SelectedTab", "create");
			},

			bindCombo: function () {
				/*const that = this;
				const cmbDuration = sap.ui.core.Fragment.byId(this.DialogId, "cmbDuration");
				cmbDuration.attachBrowserEvent("keyup", function (event) {
					that.validateDuration(this);
				})*/
			},

			validateDuration: function (cmbDuration, sRecordDate, sMtrUid) {
				let bIsValid = false;
				const that = this;
				var len = cmbDuration.getItems().length;
				var enteredText = cmbDuration.getValue();
				var bExists = false;
				for (var i = 0; i < len; i++) {
					var itemText = cmbDuration.getItems()[i].getProperty("text");
					if (itemText == enteredText || itemText.startsWith(enteredText)) {
						bExists = true;
						break;
					}
				}

				if (!bExists && enteredText && enteredText !== "" && !isNaN(enteredText)) {
					const fDuration = parseFloat(enteredText, 10);
					if (fDuration <= 24) {
						bExists = true;
						cmbDuration.setValue(enteredText);
					}
				}

				if (bExists) {
					if (that.calculateDuration(enteredText, sRecordDate, sMtrUid)) {
						cmbDuration.setValueState(sap.ui.core.ValueState.None);
						bIsValid = true;
					} else {
						cmbDuration.setValueState(sap.ui.core.ValueState.Error);
						cmbDuration.setValue("");
						bIsValid = false;
					}

				} else {
					cmbDuration.setValueState(sap.ui.core.ValueState.Error);
					cmbDuration.setValue("");
					bIsValid = false;
				}
				return bIsValid;
			},

			enableDeleteButton: function (bEnabled) {
				// const btnDelete = sap.ui.core.Fragment.byId(this.DialogId, "btnDelete");
				// btnDelete.setEnabled((bEnabled) ? true : false);
			},

			clearDialog: function () {
				this.clearSelectedDates();

				const cmbMtrTask = sap.ui.core.Fragment.byId(this.DialogId, "cmbMtrTask");
				cmbMtrTask.setSelectedKey(undefined);

				this.Model.setProperty("/SelectedMtrTask", null);

				const cmbDuration = sap.ui.core.Fragment.byId(this.DialogId, "cmbDuration");
				cmbDuration.setSelectedKey(undefined);

				const txtNotes = sap.ui.core.Fragment.byId(this.DialogId, "txtNotes");
				txtNotes.setValue("");
			},

			onPressDeleteEntries: function (oEvent) {
				const that = this;
				MessageBox.confirm("Are you sure, you want to delete the entry/ies ?", {
					actions: [MessageBox.Action.YES, MessageBox.Action.NO],
					onClose: function (sAction) {
						if (sAction === MessageBox.Action.YES) {
							const oUserSetting = that.Model.getProperty("/UserSetting");

							const idSavedEntriesTable = sap.ui.core.Fragment.byId(that.DialogId, "savedEntries--idSavedEntriesTable");

							const aSelectedContexts = idSavedEntriesTable.getSelectedContexts();
							const aEntriesToDelete = [];
							for (let i = 0; i < aSelectedContexts.length; i++) {
								const oBindingContext = aSelectedContexts[i];
								const oModel = oBindingContext.getModel();
								const sPath = oBindingContext.getPath();

								const oEntry = oModel.getProperty(sPath);

								const oEntryToDelete = oEntry.getLSRequest({
									UserGuid: oUserSetting.UserGuid,
									ProfileId: oUserSetting.ProfileId,
									Indicator: "D"
								});

								aEntriesToDelete.push(oEntryToDelete);
							}

							const aEntries = that.Model.getProperty("/Entries");

							if (aEntriesToDelete.length > 0) {
								that._saveEntries(aEntriesToDelete)
									.then(response => {
										if (response) {
											const results = response.N_TimesheetDetail.results;
											for (let i = 0; i < results.length; i++) {
												const oDeletedEntry = aEntries.find(item => item.MtrUid === results[i].MtrUid);

												if (oDeletedEntry) {
													oDeletedEntry.Indicator = "D";
												}
											}

											const aFilteredEntries = aEntries.filter(item => item.Indicator !== "D");
											that.Model.setProperty("/Entries", aFilteredEntries);
											that.Model.refresh(true);
											idSavedEntriesTable.removeSelections(true);
											that.enableDeleteButton(false);
											MessageToast.show("The entry/ies deleted successfully");
										}
									});
							}
						}
					}
				});

			},

			onSelectEntries: function (oEvent) {
				const oTable = oEvent.getSource();
				const btnDelete = sap.ui.core.Fragment.byId(this.DialogId, "btnDelete");
				if (oTable.getSelectedItems().length > 0) {
					btnDelete.setEnabled(true);
				} else {
					btnDelete.setEnabled(false);
				}
			},

			createColumnConfig: function () {
				var aCols = [];

				var EdmType = exportLibrary.EdmType;

				aCols.push({
					label: 'Date',
					property: ['RecordDate'],
					type: EdmType.Date,
					inputFormat: 'yyyymmdd',
					width: 15
				});

				aCols.push({
					label: 'Task',
					type: EdmType.String,
					property: 'MtrTaskName',
					width: 40
				});

				aCols.push({
					property: 'Activity ID',
					type: EdmType.Number,
					property: 'ActvtId',
					width: 10
				});

				aCols.push({
					property: 'Activity Name',
					type: EdmType.String,
					property: 'ActivityTypeName',
					width: 40
				});

				aCols.push({
					label: 'Location',
					type: EdmType.Enumeration,
					property: 'LocationId',
					valueMap: {
						'1': 'On Site',
						'4': 'Virtual'
					},
					width: 10
				});

				aCols.push({
					label: 'Cost Type',
					type: EdmType.Enumeration,
					property: 'CostTypeId',
					valueMap: {
						'1': 'Opportunity',
						'2': 'Cost Center',
						'4': 'Account'
					},
					width: 10
				});

				aCols.push({
					label: 'Cost Type Value',
					type: EdmType.String,
					property: 'CostTypeValue',
					width: 10
				});

				aCols.push({
					label: 'Duration',
					type: EdmType.String,
					property: 'WorkDuration'
				});

				aCols.push({
					ProjectType: 'Application',
					type: EdmType.Enumeration,
					property: 'ProjectType',
					valueMap: {
						'SLINE': 'MSL',
						'ACTVT': 'MAR',
						'MTR': 'MTR'
					},
					width: 5
				});

				return aCols;
			},

			onExport: function () {
				const oTable = sap.ui.core.Fragment.byId(this.DialogId, "savedEntries--idSavedEntriesTable");
				var aCols, oRowBinding, oSettings, oSheet;

				oRowBinding = oTable.getBinding('items');
				aCols = this.createColumnConfig();

				oSettings = {
					workbook: {
						columns: aCols,
						context: {
							sheetName: 'Saved'
						},
						hierarchyLevel: 'Level'
					},
					dataSource: oRowBinding,
					fileName: 'Time Recording.xlsx',
					worker: false // We need to disable worker because we are using a MockServer as OData Service
				};

				oSheet = new Spreadsheet(oSettings);
				oSheet.build().finally(function () {
					oSheet.destroy();
				});
			},

			//MTR new dialog changes
			onStartDateChange: function (oEvent) {
				var that = this;
				const isEdit = this.Model.getProperty("/IsEdit");
				const oCalendar = MTRHelper.Controller.getCalendar();
				if (isEdit) {
					const oEntry = this.Model.getProperty("/Entry");
					MessageToast.show("Cannot change date in edit mode");
					oCalendar.removeAllSelectedDates();
					oCalendar.addSelectedDate(new sap.ui.unified.DateRange({
						startDate: oEntry.Date,
						endDate: oEntry.Date
					}));
					return;
				}
				const oSettingsModel = MTRModels.getMTRSettingsModel();
				const bRestrictPriorYear = oSettingsModel.getProperty("/RestrictPriorYear");
				const dCutOffDate = oSettingsModel.getProperty("/CutOffDate");
				const dStartDate = oEvent.getParameter("selectionStartDate");
				let bRestrictEntry = false;
				if (oCalendar) {
					oCalendar.addSelectedDate(new sap.ui.unified.DateRange({
						startDate: dStartDate,
						endDate: dStartDate
					}));
					oCalendar.setInitialFocusedDate(dStartDate);
				}
				if (bRestrictPriorYear && dStartDate.getFullYear() < 2023) {
					bRestrictEntry = true;
				}
				oSettingsModel.setProperty("/RestrictEntry", bRestrictEntry);
				const sSelectedDate = DateService.getInstance().format(dStartDate, "yMMdd"); // YYYYMMDD
				MTRUtil.filterEntries(sSelectedDate);
				const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				if (oDayWeekTimesheetModel) {
					const oNewEntry = that.Model.getProperty("/Entry") || oDayWeekTimesheetModel.getProperty("/NewEntry");
					// oNewEntry.WorkDuration = 0;
					oNewEntry.Date = dStartDate;
					oNewEntry.RecordDate = sSelectedDate;
					oNewEntry.FormattedLongDate = DateService.getInstance().format(dStartDate, "EEEE, MMMM dd, y");
					oNewEntry.FormattedRecordDate = DateService.getInstance().format(dStartDate, "dd/MM/YYYY");
					oNewEntry.Expected = oDayWeekTimesheetModel.getProperty("/Expected");
					oNewEntry.IsSubmitEnabled = oNewEntry.validateISPFutureDate();
					that.Model.setProperty("/Entry", oNewEntry);
					that.Model.setProperty("/Submitted", oDayWeekTimesheetModel.getProperty("/Submitted"));
					that.Model.setProperty("/Saved", oDayWeekTimesheetModel.getProperty("/Saved"));
					that.Model.setProperty("/Expected", oDayWeekTimesheetModel.getProperty("/Expected"));
					const oSelectedActivity = that.Model.getProperty("/SelectedActivity");
					if (oSelectedActivity) {
						oNewEntry.setMelodyActivity(oSelectedActivity.ActivityId);
						that.Model.refresh(true);
						that._selectMTRTask();
					}
					const isLearning = that.Model.getProperty("/IsLearning");
					if (isLearning) {
						that.Model.setProperty("/Entry/CostTypeId", "2");
						that._selectMTRTask(true);
					}
					const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
					that._setEntriesInfoData(aEntries, oNewEntry.RecordDate);
					that.Model.setProperty("/MaxCapacityAlert", false);
				}

			},

			onChangeCategory: function (oEvent) {
				const oSource = oEvent.getSource();
				const sKey = oSource.getSelectedKey();
				this.Model.setProperty("/IsOtherTab", false);
				if (sKey === "02") {
					this._selectMTRTask(true);
					this.Model.setProperty("/Entry/CostTypeId", "2");
					this.Model.setProperty("/IsLearning", true);
				} else if (sKey === "01") {
					const oActDetails = this.Model.getProperty("/Entry/ActDetails");
					if (oActDetails) {
						let sCostTypeId = this._setCostTypeId(oActDetails.ActAsstId);
						this.Model.setProperty("/Entry/CostTypeId", sCostTypeId);
						this.Model.setProperty("/Entry/TaskId", oActDetails.MtrTaskID);
						this.Model.setProperty("/Entry/TaskName", oActDetails.MtrTaskName);
					}
					this.Model.setProperty("/IsLearning", false);
				} else {
					this.Model.setProperty("/IsLearning", false);
					this.Model.setProperty("/IsOtherTab", true);
					this.Model.setProperty("/Entry/TaskId", "");
					this.Model.setProperty("/Entry/TaskName", "");
					this.Model.setProperty("/isSpecialTask", false);
					this.Model.setProperty("/isOthersTabManualIO", false);
				}
			},

			_setCostTypeId: function (sActAsstId) {
				let sCostTypeId = "";
				if (sActAsstId === "501") {
					sCostTypeId = "4";
				} else if (sActAsstId === "502") {
					sCostTypeId = "1";
				} else if (sActAsstId === "503") {
					sCostTypeId = "2"
				}
				return sCostTypeId;
			},

			openUserActivityPopup: function (oEvent) {
				this.setUserActivities();
				this._oUserActivitiesDialog.open();
			},

			onActivitySelectionPopupClose: function () {
				this._oUserActivitiesDialog.close();
				this.onResetActFilters();
			},

			onActivitySelect: function (oEvent) {
				const that = this;
				const mtrSettings = sap.ui.getCore().getModel("mtrSettings");
				const oActivity = oEvent.getSource().getBindingContext().getObject();
				if (oActivity) {
					let startDate = (oActivity.StartDate) ? oActivity.StartDate : new Date();
					this.Model.setProperty("/Entry/ActDetails", oActivity);
					this.Model.setProperty("/Entry/ActvtId", oActivity.ActivityId);
					this.Model.setProperty("/Entry/ActTypeDesc", oActivity.ActTypeDesc);
					const sActAsstId = oActivity.ActAsstId;
					let sCostTypeId = "";
					let sCostTypeName = "";
					let sCostTypeValue = "";
					if (sActAsstId === "501") {
						sCostTypeId = "4";
						sCostTypeName = oActivity.AccountName;
						sCostTypeValue = oActivity.AccountId;
					} else if (sActAsstId === "502") {
						sCostTypeId = "1";
						sCostTypeName = oActivity.OpportunityName;
						sCostTypeValue = oActivity.OpportunityId;
					} else if (sActAsstId === "503") {
						sCostTypeId = "2"
						sCostTypeValue = mtrSettings.getProperty("/CostCenter");
					}
					this.Model.setProperty("/Entry/CostTypeId", sCostTypeId);
					this.Model.setProperty("/Entry/CostTypeValue", sCostTypeValue);
					this.Model.setProperty("/Entry/CostTypeName", sCostTypeName);
					this.Model.setProperty("/Entry/TaskId", oActivity.MtrTaskID);
					this.Model.setProperty("/Entry/TaskName", oActivity.MtrTaskName);
					this.Model.setProperty("/Entry/OpportunityID", oActivity.OpportunityId);
					this.Model.setProperty("/Entry/OpportunityName", oActivity.OpportunityName);
					this.Model.setProperty("/Entry/AccountID", oActivity.AccountId);
					this.Model.setProperty("/Entry/AccountName", oActivity.AccountName);

					this._setCostObjectItems(sCostTypeId, sCostTypeValue);

					if (sCostTypeId === "1") {
						this.fnSetOppoInfoDetails(sCostTypeValue, "DISPLAYMODE");
					} else if (sCostTypeId === "4") {
						this.fnSetAccountInfoDetails(sCostTypeValue, "DISPLAYMODE");
					}
					//hide customer facing when there is no mapping
					if (oActivity.MpngAttrVal) {
						this.Model.setProperty("/IsCustomerFacingVisible", true);
					} else {
						this.Model.setProperty("/IsCustomerFacingVisible", false);
					}

					this.Model.setProperty("/isManualIO", false);
					if (new Date() >= startDate) {
						startDate = new Date();
					}
					this.Model.setProperty("/Entry/Date", startDate);
					this.Model.setProperty("/Entry/RecordDate", DateService.getInstance().format(startDate, "yMMdd"));
					this.Model.setProperty("/Entry/FormattedRecordDate", DateService.getInstance().format(startDate, "dd/MM/YYYY"));
					this.Model.setProperty("/Entry/FormattedLongDate", DateService.getInstance().format(startDate, "EEEE, MMMM dd, y"));
					this.Model.refresh(true);

					this.fnSetCalendar(startDate);
					this.onActivitySelectionPopupClose();
					const oNewEntry = this.Model.getProperty("/Entry");
					const sSelectedOppId = (oNewEntry && oNewEntry.OpportunityID) ? oNewEntry.OpportunityID : "";
					let bIsDiscontinuedOpp = false;
					const oSettingsModel = MTRModels.getMTRSettingsModel();
					oSettingsModel.setProperty("/IsDisontinuedOppSubmit", false);
					if (sSelectedOppId && oNewEntry.WorkDuration) {
						bIsDiscontinuedOpp = MTRUtil.fnIsDiscontinuedOpportunity(false, oNewEntry, sSelectedOppId, this, "dayWeekActivityData");
					}
					// that._oUserActivitiesDialog.close();
				}
			},

			//function to set calendarDate
			fnSetCalendar: function (date) {
				const oCalendar = MTRHelper.Controller.getCalendar();
				if (oCalendar) {
					oCalendar.removeAllSelectedDates();
					oCalendar.addSelectedDate(new sap.ui.unified.DateRange({
						startDate: date,
						endDate: date
					}));
					oCalendar.setInitialFocusedDate(date);
					//To Display Entries Info Popup & Hours in Calendar
					oCalendar.fireSelect();
				}
			},

			onNavigateCalendar: function (oEvent) {
				const that = this;
				const dStartDate = oEvent.getParameter("selectionStartDate");
				/*
				-Below setInitialFocusedDate is added bcz months navigation is not working
				*/
				const oCalendar = MTRHelper.Controller.getCalendar();
				if (oCalendar) {
					oCalendar.setInitialFocusedDate(dStartDate);
					oCalendar.setBusy(true);
				}
				MTRUtil.updateTimesheets(dStartDate).then(() => {
					const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
					const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
					that.Model.setProperty("/Entries", aEntries);
					oDayWeekTimesheetModel.refresh(true);
					that.Model.refresh(true);
					const oCalendar = MTRHelper.Controller.getCalendar();
					if (oCalendar) {
						oCalendar.setBusy(false);
					}
				});
			},

			//Function to update Account details to Info popover from Application to library
			fnSetAccountInfoDetails: function (accountId, viewMode) {
				let accountControl = sap.ui.core.Fragment.byId(this.DialogId, "dayWeekAccountCtrl");
				let accountControl1 = sap.ui.core.Fragment.byId(this.DialogId, "dayWeekAccountCtrl1");

				if (accountControl) {
					accountControl.setAccountId(accountId);
				}
				if (accountControl1) {
					accountControl1.setAccountId(accountId);
				}
			},

			//Function to update Opportunity details to Info popover from Application to library
			fnSetOppoInfoDetails: function (OppId, viewMode) {
				let opportunityControl = sap.ui.core.Fragment.byId(this.DialogId, "dayWeekOpportunityCtrl");
				let opportunityControl1 = sap.ui.core.Fragment.byId(this.DialogId, "dayWeekOpportunityCtrl1");
				if (opportunityControl) {
					opportunityControl.setOpportunityId(OppId);
				}
				if (opportunityControl1) {
					opportunityControl1.setOpportunityId(OppId);
				}
			},

			_setCostObjectItems: function (sCostTypeId, sCostTypValue) {
				if (sCostTypeId) {
					const sActAsstId = this.Model.getProperty("/Entry/ActAsstId");
					const isEdit = this.Model.getProperty("/IsEdit");
					const aCostObject = [];
					if (sCostTypeId !== "2" && sActAsstId !== "503") {
						sCostTypeId = isEdit ? sActAsstId === "501" ? "4" : "1" : sCostTypeId;
						const oCostObject = {
							key: sCostTypeId,
							text: sCostTypeId === "1" ? "Opportunity" : "Account"
						};
						aCostObject.push(oCostObject);
					} else {
						const oCostCenter = {
							key: "2",
							text: "SAP Cost Center"
						};
						aCostObject.push(oCostCenter);
					}
					const oManualIO = {
						key: "3",
						text: "Manual IO"
					};
					aCostObject.push(oManualIO);
					this.Model.setProperty("/CostObjectItems", aCostObject);
				}
			},

			_setEntriesInfoData: function (aEntries, sRecordDate) {
				const that = this;
				let aSavedEntries = [],
					aFailedEntries = [],
					aSubmittedEntries = [];
				aEntries.filter(function (Entry) {
					if (Entry.RecordDate === sRecordDate) {
						var workDuration = parseFloat(Entry.WorkDuration);
						switch (Entry.StatusId) {
							case "1":
								// aSavedEntries.push(Entry);
								aSavedEntries.push(Entry);
								break;
							case "3":
								aFailedEntries.push(Entry);
								break;
							case "4":
								aSubmittedEntries.push(Entry);
								break;
							default:
								break;
						}
					}
				});
				this.Model.setProperty("/CfNcfSavedEntries", "");
				this.Model.setProperty("/CfNcfSubmittedEntries", "");
				this.Model.setProperty("/CfNcfFailedEntries", "");
				this.Model.setProperty("/CfNcfSavedEntriesActInfo", "");
				this.Model.setProperty("/CfNcfSubmittedEntriesActInfo", "");
				this.Model.setProperty("/CfNcfFailedEntriesActInfo", "");
				let cfSavedWorkDuration = 0;
				let ncfSavedWorkDuration = 0;
				if (aSavedEntries.length) {
					aSavedEntries.filter(function (oEntry) {
						const workDuration = parseFloat(oEntry.WorkDuration, 10);
						const bCustomerFacing = oEntry.CustomerFacing;
						if (bCustomerFacing) {
							cfSavedWorkDuration += workDuration;
						} else {
							ncfSavedWorkDuration += workDuration;
						}
						that._formatEntryInfoDate(oEntry, "CfNcfSavedEntries", "CfNcfSavedEntriesActInfo", cfSavedWorkDuration, ncfSavedWorkDuration);
					});
				} else {
					this._formatEntryInfoDate(undefined, "CfNcfSavedEntries", "CfNcfSavedEntriesActInfo", cfSavedWorkDuration, ncfSavedWorkDuration);
				}

				let cfSubmittedWorkDuration = 0;
				let ncfSubmittedWorkDuration = 0;
				if (aSubmittedEntries.length) {
					aSubmittedEntries.filter(function (oEntry) {
						const workDuration = parseFloat(oEntry.WorkDuration, 10);
						const bCustomerFacing = oEntry.CustomerFacing;
						if (bCustomerFacing) {
							cfSubmittedWorkDuration += workDuration;
						} else {
							ncfSubmittedWorkDuration += workDuration;
						}

						that._formatEntryInfoDate(oEntry, "CfNcfSubmittedEntries", "CfNcfSubmittedEntriesActInfo", cfSubmittedWorkDuration,
							ncfSubmittedWorkDuration);
					});
				} else {
					this._formatEntryInfoDate(undefined, "CfNcfSubmittedEntries", "CfNcfSubmittedEntriesActInfo", cfSubmittedWorkDuration,
						ncfSubmittedWorkDuration);
				}

				let cfFailedWorkDuration = 0;
				let ncfFailedWorkDuration = 0;
				if (aFailedEntries.length) {
					aFailedEntries.filter(function (oEntry) {
						const workDuration = parseFloat(oEntry.WorkDuration, 10);
						const bCustomerFacing = oEntry.CustomerFacing;
						if (bCustomerFacing) {
							cfFailedWorkDuration += workDuration;
						} else {
							ncfFailedWorkDuration += workDuration;
						}

						that._formatEntryInfoDate(oEntry, "CfNcfFailedEntries", "CfNcfFailedEntriesActInfo", cfFailedWorkDuration,
							ncfFailedWorkDuration);
					});
				} else {
					this._formatEntryInfoDate(undefined, "CfNcfFailedEntries", "CfNcfFailedEntriesActInfo", cfFailedWorkDuration,
						ncfFailedWorkDuration);
				}
				this.Model.refresh(true);
			},

			_formatEntryInfoDate: function (oEntry, cfNcfProperty, cfNcfActInfoProperty, cfWorkDuration, ncfWorkDuration) {
				let sDescription = "";
				let sDescriptionActInfo = "";
				const oMtrSettings = sap.ui.getCore().getModel("mtrSettings");
				const sTimeMatrics = oMtrSettings.getProperty("/TimeMatrics");
				const sTimeMatricsTxt = sTimeMatrics === "H" ? "hours" : "day";
				if (oEntry) {
					const dDate = oEntry.Date;
					const sDate = DateService.getInstance().format(dDate, "MMMM dd");
					sDescription = sDate + " : " + cfWorkDuration + " " + sTimeMatricsTxt + " CF / " + ncfWorkDuration + " " + sTimeMatricsTxt +
						" NCF";
					sDescriptionActInfo = cfWorkDuration + " " + sTimeMatricsTxt + " CF / " + ncfWorkDuration + " " + sTimeMatricsTxt +
						" NCF";
				} else {
					sDescription = cfWorkDuration + " " + sTimeMatricsTxt + " CF / " + ncfWorkDuration + " " + sTimeMatricsTxt +
						" NCF";
					sDescriptionActInfo = cfWorkDuration + " " + sTimeMatricsTxt + " CF / " + ncfWorkDuration + " " + sTimeMatricsTxt +
						" NCF";
				}
				this.Model.setProperty("/" + cfNcfProperty, sDescription);
				this.Model.setProperty("/" + cfNcfActInfoProperty, sDescriptionActInfo);
			},

			setUserActivities: async function (activity) {
				const that = this;
				this.Model.setSizeLimit(1000);
				let aActivities = this.Model.getProperty("/UserActivities");
				let aFilters = [];
				let archivedFilter = new Filter({
					path: "IsArchived",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: false
				});
				aFilters.push(archivedFilter);
				if (!aActivities) {
					this.Model.setProperty("/IsUserActDlgBusy", true);
					aActivities = await MTRService.getTimeEntryActivitites(aFilters);
					aActivities.filter(function (actvt) {
						var that = this;
						actvt.ActivityId = parseInt(actvt.ActivityId).toString();
						if (actvt.ActAsstId === "501") {
							actvt.OpportunityName = "Not Applicable";
							if (actvt.AccountId) {
								// AccountService.getZSBupaInfoSet(this.AccountId)
								OpportunityService.getBusinessPartnerAttribSet(actvt.AccountId).then(function (oResponse) {
									if (oResponse && oResponse.data) {
										// that.AccountName = oResponse[0].AccountName;
										actvt.AccountName = oResponse.data.PARTNER_NAME;
									} else {
										actvt.AccountName = "Not Applicable";
									}
								});
							} else {
								actvt.AccountName = "Not Applicable";
							}
						} else if (actvt.ActAsstId === "502") {
							const oMtrSettingsModel = sap.ui.getCore().getModel("mtrSettings");
							const aOpportunities = oMtrSettingsModel.getProperty("/Opportunities");
							if (aOpportunities) {
								const oOpportunity = aOpportunities.find(item => item.OpportunityID === actvt.OpportunityId);
								if (oOpportunity) {
									actvt.OpportunityName = oOpportunity.OpportunityName ? oOpportunity.OpportunityName : "Not Authorized";
									actvt.AccountName = oOpportunity.AccountName ? oOpportunity.AccountName : "Not Authorized";
								} else {
									actvt.AccountName = "Not Authorized";
									actvt.OpportunityName = "Not Authorized";
								}
							}
						} else {
							actvt.AccountName = actvt.ActSetDesc ? actvt.ActSetDesc : "Not Applicable";
							actvt.OpportunityName = "Not Applicable";
						}
					});
				}
				const aActStatus = await MTRService.getActStatusMasterData();
				const aActTypes = ActivityUtil.getActivityTypes().then(function (results) {
					that.Model.setProperty("/ActTypes", results);
				});
				this.Model.setProperty("/ActStatus", aActStatus);
				this.Model.setProperty("/UserActivities", aActivities);
				this.filterUserActivities();
			},

			onStartDateRangeSelect: function (oEvent) {
				this.filterUserActivities();
			},

			onStatusChange: function (oEvent) {
				this.filterUserActivities();
			},

			onActivityTypeChange: function (oEvent) {
				this.filterUserActivities();
			},

			onActivitySearch: function (oEvent) {
				const sQuery = oEvent.getSource().getValue();
				const aSearchFilters = new Filter({
					filters: [
						new Filter("ActivityId", FilterOperator.Contains, sQuery),
						new Filter("AccountId", FilterOperator.Contains, sQuery),
						new Filter("OpportunityId", FilterOperator.Contains, sQuery),
						new Filter("OpportunityName", FilterOperator.Contains, sQuery),
						new Filter("AccountName", FilterOperator.Contains, sQuery),
						new Filter("ActSetDesc", FilterOperator.Contains, sQuery)
					],
					and: false
				});
				this.filterUserActivities(aSearchFilters);
			},

			filterUserActivities: function (searchFilter) {
				let aFilters = [];
				let aDateFilter = [];
				let aCustomerFacingFilter = [];
				const oDateRangeFilter = this._getControlById("dateRangeFilter");
				const dateFrom = oDateRangeFilter.getFrom();
				const dateTo = oDateRangeFilter.getTo();
				if (dateFrom && dateTo) {
					aDateFilter.push(new Filter("StartDate", "GE", dateFrom));
					aDateFilter.push(new Filter("EndDate", "LE", dateTo));
					aFilters.push(new Filter({
						filters: aDateFilter,
						and: true
					}));
				}
				const oStatusFilter = this._getControlById("statusFilter");
				const sStatusId = oStatusFilter.getSelectedKey();
				if (sStatusId) {
					aFilters.push(new Filter("ActStatus", "EQ", sStatusId));
				}
				const oActTypeFilter = this._getControlById("actTypeFilter");
				const sActTypeId = oActTypeFilter.getSelectedKey();
				if (sActTypeId) {
					aFilters.push(new Filter("ActivityTypeId", "EQ", sActTypeId));
				}
				if (searchFilter) {
					aFilters.push(searchFilter);
				}
				const bState = this.Model.getProperty("/Entry/CustomerFacing");
				const sMpngAttrVal = bState ? "1" : "2";
				if (sMpngAttrVal) {
					aCustomerFacingFilter.push(new Filter("MpngAttrVal", "EQ", sMpngAttrVal));
					aCustomerFacingFilter.push(new Filter("MpngAttrVal", "EQ", ""));
				}
				aFilters.push(new Filter({
					filters: aCustomerFacingFilter,
					and: false
				}));
				const aActFilters = new Filter({
					filters: aFilters,
					and: true
				});
				const oList = this._getControlById("userActList");
				oList.getBinding("items").filter([aActFilters]);
				this.Model.setProperty("/IsUserActDlgBusy", false);
			},

			onResetActFilters: function () {
				const oDateRangeFilter = this._getControlById("dateRangeFilter");
				oDateRangeFilter.setValue("");
				const oStatusFilter = this._getControlById("statusFilter");
				oStatusFilter.setSelectedKey("");
				const oActTypeFilter = this._getControlById("actTypeFilter");
				oActTypeFilter.setSelectedKey("");
				const oActSearchFilter = this._getControlById("actSearchFilter");
				oActSearchFilter.setValue("");
				this.filterUserActivities([]);
			},

			_getControlById: function (id) {
				if (id) {
					return sap.ui.core.Fragment.byId(this.DialogId + "_UserActivitiesDialog", id);
				}
			},

			onCustomerFacingChange: function (oEvent) {
				let bState = oEvent.getSource().getState();
				const isEdit = this.Model.getProperty("/IsEdit");
				const oSelectedActivity = this.Model.getProperty("/SelectedActivity");
				const sActId = this.Model.getProperty("/Entry/ActvtId");
				this.Model.setProperty("/Entry/CustomerFacing", bState);
				if (!isEdit && !oSelectedActivity) {
					this.filterUserActivities();
					const aActivities = this.Model.getProperty("/UserActivities");
					const sMpngAttrVal = bState ? "1" : "2";
					if (aActivities && aActivities.length) {
						const oActivity = aActivities.find(item => item.ActivityId === sActId && item.MpngAttrVal === sMpngAttrVal);
						if (oActivity) {
							this.Model.setProperty("/Entry/TaskId", oActivity.MtrTaskID);
							this.Model.setProperty("/Entry/TaskName", oActivity.MtrTaskName);
						}
					}
				} else {
					this._selectMTRTask();
				}
			},

			_selectMTRTask: function (isLaerning) {
				if (isLaerning) {
					const aMtrTasks = this.Model.getProperty("/MTRTasks");
					const oMtrTask = aMtrTasks.find(item => item.IsLearning === true);
					if (oMtrTask) {
						this.Model.setProperty("/Entry/TaskId", oMtrTask.TaskId);
						this.Model.setProperty("/Entry/TaskName", oMtrTask.TaskName);
					}
				} else {
					const isEdit = this.Model.getProperty("/IsEdit");
					const bState = this.Model.getProperty("/Entry/CustomerFacing");
					const sMpngAttrVal = bState ? "1" : "2";
					const aMtrTasks = this.Model.getProperty("/MtrTasks");
					if (aMtrTasks.length === 2) { //to check customer facing condition
						const oMtrTask = aMtrTasks.find(item => item.MpngAttrVal === sMpngAttrVal);
						if (oMtrTask) {
							this.Model.setProperty("/Entry/TaskId", oMtrTask.MtrTaskID);
							this.Model.setProperty("/Entry/TaskName", oMtrTask.MtrTaskName);
						}
					} else if (aMtrTasks.length === 1) {
						const oMtrTask = aMtrTasks[0];
						this.Model.setProperty("/Entry/TaskId", oMtrTask.MtrTaskID);
						this.Model.setProperty("/Entry/TaskName", oMtrTask.MtrTaskName);
					}
					/*else {
						if (!isEdit) {
							this.Model.setProperty("/Entry/ActvtId", "");
							this.Model.setProperty("/Entry/ActTypeDesc", "");
							MessageToast.show("Task type is not available for selected activity");
						}*/
				}
			},

			onCostObjectChange: function (oEvent) {
				var that = this;
				const sSelectedKey = oEvent.getSource().getSelectedKey();
				if (sSelectedKey === "3") {
					this.Model.setProperty("/isManualIO", true);
					this.Model.setProperty("/Entry/CostTypeValue", "");
				} else {
					this.Model.setProperty("/isManualIO", false);
				}
				const bIsManualIo = this.Model.getProperty("/isManualIO");
				if (!bIsManualIo) {
					const oEntry = this.Model.getProperty("/Entry");
					let sPrevCostTypeVal = oEntry.ActAsstId === "501" ? oEntry.AccountID : oEntry.OpportunityID;
					if (!sPrevCostTypeVal) {
						const aActivities = sap.ui.getCore().getModel("activities").getData();
						const oActivity = aActivities.find(item => parseInt(item.ActivityId, 10) === parseInt(oEntry.ActvtId, 10));
						sPrevCostTypeVal = oActivity.ActAsstId === "501" ? oActivity.AccountId : oActivity.OpportunityId;
					}
					this.Model.setProperty("/Entry/CostTypeValue", sPrevCostTypeVal)
					oEntry.setCostTypeName().then(() => {
						that.Model.refresh(true);
					});
					const sCostTypeId = this.Model.getProperty("/Entry/CostTypeId");
					if (sCostTypeId === "1") {
						this.fnSetOppoInfoDetails(sPrevCostTypeVal, "DISPLAYMODE");
					} else if (sCostTypeId === "4") {
						this.fnSetAccountInfoDetails(sPrevCostTypeVal, "DISPLAYMODE");
					}
				}
			},

			onCloseTimeRecordingDialog: function () {
				MTRHelper._closeTimeRecordingDialog();
			},

			// onSaveNewEntry: function (oEvent) {
			// 	const that = this;
			// 	const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			// 	const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
			// 	const oNewEntry = this.Model.getProperty("/Entry");
			// 	const oSelectedActivity = this.Model.getProperty("/SelectedActivity");
			// 	const isLearning = this.Model.getProperty("/IsLearning");
			// 	const isOthersTab = this.Model.getProperty("/IsOtherTab");
			// 	const isCFvisible = this.Model.getProperty("/IsCustomerFacingVisible");
			// 	const sTimeMatrics = oNewEntry.Unit;

			// 	const currentWorkDuration = oNewEntry.WorkDuration;
			// 	if (!parseFloat(currentWorkDuration, 10) || parseFloat(currentWorkDuration, 10) <= 0) {
			// 		MessageToast.show("Please Enter Time");
			// 		return;
			// 	}

			// 	let totalWorkDuration = 0;
			// 	aEntries.filter(function (item) {
			// 		if (item.RecordDate === oNewEntry.RecordDate) {
			// 			totalWorkDuration = totalWorkDuration + parseFloat(item.WorkDuration, 10);
			// 		}
			// 	});
			// 	let ExpectedWorkDuration = 0;
			// 	ExpectedWorkDuration = currentWorkDuration + totalWorkDuration;
			// 	if (sTimeMatrics === "H" && ExpectedWorkDuration > 24) {
			// 		MessageToast.show("Cannot book >24hours in a day");
			// 		return;
			// 	}
			// 	/*				else {
			// 						if (sTimeMatrics === "D" && ExpectedWorkDuration > 1) {
			// 							MessageToast.show("Cannot book >1day in a day");
			// 							return;
			// 						}
			// 					}
			// 	*/
			// 	if (isOthersTab && !oNewEntry.TaskId) {
			// 		MessageToast.show("Please Select Task");
			// 		return;
			// 	}

			// 	if (!isLearning) {
			// 		if (!isOthersTab) {
			// 			const sActivityId = oNewEntry.ActvtId;
			// 			if (!sActivityId) {
			// 				MessageToast.show("Please select activity");
			// 				return;
			// 			}
			// 		}

			// 		const sCostTypeId = oNewEntry.CostTypeId;
			// 		if (!sCostTypeId) {
			// 			MessageToast.show("Please select cost type");
			// 			return;
			// 		}

			// 		const sManualIo = oNewEntry.CostTypeValue;
			// 		const property = isOthersTab ? "isOthersTabManualIO" : "isManualIO";
			// 		if (this.Model.getProperty("/" + property) && !sManualIo) {
			// 			MessageToast.show("Please select Manual IO");
			// 			return;
			// 		}
			// 	}

			// 	if (isLearning || isOthersTab || !isCFvisible) {
			// 		oNewEntry.CustomerFacing = false;
			// 	}

			// 	const isEdit = this.Model.getProperty("/IsEdit");
			// 	if (isEdit) {
			// 		oNewEntry.Indicator = "U";
			// 	} else {
			// 		oNewEntry.Indicator = "I";
			// 	}
			// 	// aEntries.push(oNewEntry);
			// 	this.Model.setProperty("/IsSaveBusy", true);
			// 	MTRUtil.saveEntries([oNewEntry]).then(() => {
			// 		let index = aEntries.findIndex(function (item) {
			// 			return item.MtrUid === oNewEntry.MtrUid;
			// 		});
			// 		if (index !== -1) {
			// 			oNewEntry.Busy = false;
			// 			oNewEntry.StatusId = aEntries[index].StatusId;
			// 			if (this.Model.getProperty("/IsOtherTab")) {
			// 				oNewEntry.AddCategoryId = "5";
			// 			}
			// 			aEntries[index] = oNewEntry;
			// 		}
			// 		const oResourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
			// 		const sWorkDuration = this.Model.getProperty("/Entry/WorkDuration");
			// 		const dDate = this.Model.getProperty("/Entry/Date");
			// 		const sDate = DateService.getInstance().format(dDate, "MMMM dd");
			// 		const oMtrSettings = sap.ui.getCore().getModel("mtrSettings");
			// 		const sTimeMatrics = oMtrSettings.getProperty("/TimeMatrics");
			// 		const sTimeMatricsTxt = sTimeMatrics === "H" ? "hours" : "days";
			// 		const sDescription = sDate + " : " + parseFloat(sWorkDuration, 10) + " " + sTimeMatricsTxt;
			// 		let sActvtId = this.Model.getProperty("/Entry/ActvtId");
			// 		let statusId = this.Model.getProperty("/Entry/StatusId");
			// 		const oMessage = new Message({
			// 			Type: sap.ui.core.MessageType.Success,
			// 			Title: oResourceBundle.getText("savedSuccessfullyMsg"),
			// 			Description: sDescription,
			// 			Subtitle: ""
			// 		});
			// 		oMessage.addToMessages(oNewEntry.MtrUid, sActvtId, statusId);
			// 		this.onMessagePopoverPress();
			// 		this._filterEntries();
			// 		this._setEntriesInfoData(aEntries, oNewEntry.RecordDate);
			// 		if (!isEdit) {
			// 			this._ResetEntryData();
			// 		}

			// 		this.Model.setProperty("/IsSaveBusy", false);
			// 	});
			// },
			onSaveNewEntry: function (oEvent) {

				const that = this;
				const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
				const oNewEntry = this.Model.getProperty("/Entry");
				const oSelectedActivity = this.Model.getProperty("/SelectedActivity");
				const isLearning = this.Model.getProperty("/IsLearning");
				const isOthersTab = this.Model.getProperty("/IsOtherTab");
				const isCFvisible = this.Model.getProperty("/IsCustomerFacingVisible");
				const sTimeMatrics = oNewEntry.Unit;

				const currentWorkDuration = oNewEntry.WorkDuration;
				if (!parseFloat(currentWorkDuration, 10) || parseFloat(currentWorkDuration, 10) <= 0) {
					MessageToast.show("Please Enter Time");
					return;
				}
				this.checkDiscontinuedOpp(oEvent, oNewEntry, "save");

			},
			fnSaveNewEntry: function (oEvent) {
				const that = this;
				const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
				const oNewEntry = this.Model.getProperty("/Entry");
				const oSelectedActivity = this.Model.getProperty("/SelectedActivity");
				const isLearning = this.Model.getProperty("/IsLearning");
				const isOthersTab = this.Model.getProperty("/IsOtherTab");
				const isCFvisible = this.Model.getProperty("/IsCustomerFacingVisible");
				const sTimeMatrics = oNewEntry.Unit;

				const currentWorkDuration = oNewEntry.WorkDuration;
				if (!parseFloat(currentWorkDuration, 10) || parseFloat(currentWorkDuration, 10) <= 0) {
					MessageToast.show("Please Enter Time");
					return;
				}

				let totalWorkDuration = 0;
				aEntries.filter(function (item) {
					if (item.RecordDate === oNewEntry.RecordDate) {
						totalWorkDuration = totalWorkDuration + parseFloat(item.WorkDuration, 10);
					}
				});
				let ExpectedWorkDuration = 0;
				ExpectedWorkDuration = currentWorkDuration + totalWorkDuration;
				if (sTimeMatrics === "H" && ExpectedWorkDuration > 24) {
					MessageToast.show("Cannot book >24hours in a day");
					return;
				}
				/*				else {
									if (sTimeMatrics === "D" && ExpectedWorkDuration > 1) {
										MessageToast.show("Cannot book >1day in a day");
										return;
									}
								}
				*/
				if (isOthersTab && !oNewEntry.TaskId) {
					MessageToast.show("Please Select Task");
					return;
				}

				if (!isLearning) {
					if (!isOthersTab) {
						const sActivityId = oNewEntry.ActvtId;
						if (!sActivityId) {
							MessageToast.show("Please select activity");
							return;
						}
					}

					const sCostTypeId = oNewEntry.CostTypeId;
					if (!sCostTypeId) {
						MessageToast.show("Please select cost type");
						return;
					}

					const sManualIo = oNewEntry.CostTypeValue;
					const property = isOthersTab ? "isOthersTabManualIO" : "isManualIO";
					if (this.Model.getProperty("/" + property) && !sManualIo) {
						MessageToast.show("Please select Manual IO");
						return;
					}
				}

				if (isLearning || isOthersTab || !isCFvisible) {
					oNewEntry.CustomerFacing = false;
				}

				const isEdit = this.Model.getProperty("/IsEdit");
				if (isEdit) {
					oNewEntry.Indicator = "U";
				} else {
					oNewEntry.Indicator = "I";
				}
				// aEntries.push(oNewEntry);
				this.Model.setProperty("/IsSaveBusy", true);
				MTRUtil.saveEntries([oNewEntry]).then(() => {
					let index = aEntries.findIndex(function (item) {
						return item.MtrUid === oNewEntry.MtrUid;
					});
					if (index !== -1) {
						oNewEntry.Busy = false;
						oNewEntry.StatusId = aEntries[index].StatusId;
						if (this.Model.getProperty("/IsOtherTab")) {
							oNewEntry.AddCategoryId = "5";
						}
						aEntries[index] = oNewEntry;
					}
					const oResourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
					const sWorkDuration = this.Model.getProperty("/Entry/WorkDuration");
					const dDate = this.Model.getProperty("/Entry/Date");
					const sDate = DateService.getInstance().format(dDate, "MMMM dd");
					const oMtrSettings = sap.ui.getCore().getModel("mtrSettings");
					const sTimeMatrics = oMtrSettings.getProperty("/TimeMatrics");
					const sTimeMatricsTxt = sTimeMatrics === "H" ? "hours" : "days";
					const sDescription = sDate + " : " + parseFloat(sWorkDuration, 10) + " " + sTimeMatricsTxt;
					let sActvtId = this.Model.getProperty("/Entry/ActvtId");
					let statusId = this.Model.getProperty("/Entry/StatusId");
					const oMessage = new Message({
						Type: sap.ui.core.MessageType.Success,
						Title: oResourceBundle.getText("savedSuccessfullyMsg"),
						Description: sDescription,
						Subtitle: ""
					});
					oMessage.addToMessages(oNewEntry.MtrUid, sActvtId, statusId);
					this.onMessagePopoverPress();
					this._filterEntries();
					this._setEntriesInfoData(aEntries, oNewEntry.RecordDate);
					if (!isEdit) {
						this._ResetEntryData();
					}

					this.Model.setProperty("/IsSaveBusy", false);
				});
			},
			// onSubmitNewEntry: function (oEvent) {
			// 	const that = this;
			// 	const oNewEntry = this.Model.getProperty("/Entry");
			// 	const oSelectedActivity = this.Model.getProperty("/SelectedActivity");
			// 	const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			// 	const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
			// 	const isLearning = this.Model.getProperty("/IsLearning");
			// 	const isOthersTab = this.Model.getProperty("/IsOtherTab");
			// 	const isCFvisible = this.Model.getProperty("/IsCustomerFacingVisible");
			// 	const sTimeMatrics = oNewEntry.Unit;

			// 	const currentWorkDuration = oNewEntry.WorkDuration;
			// 	if (!parseFloat(currentWorkDuration, 10) || parseFloat(currentWorkDuration, 10) <= 0) {
			// 		MessageToast.show("Please Enter Time");
			// 		return;
			// 	}

			// 	let totalWorkDuration = 0;
			// 	aEntries.filter(function (item) {
			// 		if (item.RecordDate === oNewEntry.RecordDate) {
			// 			totalWorkDuration = totalWorkDuration + parseFloat(item.WorkDuration, 10);
			// 		}
			// 	});
			// 	let ExpectedWorkDuration = 0;
			// 	ExpectedWorkDuration = currentWorkDuration + totalWorkDuration;
			// 	if (sTimeMatrics === "H" && ExpectedWorkDuration > 24) {
			// 		MessageToast.show("Cannot book >24hours in a day");
			// 		return;
			// 	}
			// 	/*	else {
			// 			if (sTimeMatrics === "D" && ExpectedWorkDuration > 1) {
			// 				MessageToast.show("Cannot book >1day in a day");
			// 				return;
			// 			}
			// 		}*/

			// 	if (isOthersTab && !oNewEntry.TaskId) {
			// 		MessageToast.show("Please Select Task");
			// 		return;
			// 	}

			// 	if (!isLearning) {
			// 		if (!isOthersTab) {
			// 			const sActivityId = oNewEntry.ActvtId;
			// 			if (!sActivityId) {
			// 				MessageToast.show("Please select activity");
			// 				return;
			// 			}
			// 		}

			// 		const sCostTypeId = oNewEntry.CostTypeId;
			// 		if (!sCostTypeId) {
			// 			MessageToast.show("Please select cost type");
			// 			return;
			// 		}

			// 		const sManualIo = oNewEntry.CostTypeValue;
			// 		const property = isOthersTab ? "isOthersTabManualIO" : "isManualIO";
			// 		if (this.Model.getProperty("/" + property) && !sManualIo) {
			// 			MessageToast.show("Please select Manual IO");
			// 			return;
			// 		}
			// 	}

			// 	if (isLearning || isOthersTab || !isCFvisible) {
			// 		oNewEntry.CustomerFacing = false;
			// 	}

			// 	const isEdit = this.Model.getProperty("/IsEdit");
			// 	if (isEdit) {
			// 		oNewEntry.Indicator = "U";
			// 	} else {
			// 		oNewEntry.Indicator = "I";
			// 	}
			// 	this.Model.setProperty("/IsSubmitBusy", true);
			// 	oDayWeekTimesheetModel.setProperty("/ActivityId", oNewEntry.ActvtId);
			// 	oDayWeekTimesheetModel.setProperty("/EntryDate", oNewEntry.Date);
			// 	oDayWeekTimesheetModel.setProperty("/WorkDuration", oNewEntry.WorkDuration);
			// 	oDayWeekTimesheetModel.setProperty("/StatusId", oNewEntry.StatusId);
			// 	// aEntries.push(oNewEntry);
			// 	MTRUtil.submitEntries([oNewEntry]).then(() => {
			// 		let index = aEntries.findIndex(function (item) {
			// 			return item.MtrUid === oNewEntry.MtrUid;
			// 		});
			// 		if (index !== -1) {
			// 			oNewEntry.StatusId = aEntries[index].StatusId;
			// 			aEntries[index] = oNewEntry;
			// 		}
			// 		this.onMessagePopoverPress();
			// 		this._filterEntries();
			// 		this._setEntriesInfoData(aEntries, oNewEntry.RecordDate);
			// 		if (!isEdit) {
			// 			this._ResetEntryData();
			// 		}
			// 		this.Model.setProperty("/IsSubmitBusy", false);
			// 	});
			// },
			onSubmitNewEntry: function (oEvent) {
				const that = this;
				const oNewEntry = this.Model.getProperty("/Entry");
				const oSelectedActivity = this.Model.getProperty("/SelectedActivity");
				const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
				const isLearning = this.Model.getProperty("/IsLearning");
				const isOthersTab = this.Model.getProperty("/IsOtherTab");
				const isCFvisible = this.Model.getProperty("/IsCustomerFacingVisible");
				const sTimeMatrics = oNewEntry.Unit;

				const currentWorkDuration = oNewEntry.WorkDuration;
				if (!parseFloat(currentWorkDuration, 10) || parseFloat(currentWorkDuration, 10) <= 0) {
					MessageToast.show("Please Enter Time");
					return;
				}
				this.checkDiscontinuedOpp(oEvent, oNewEntry);
			},
			fnSubmitNewEntry: function (oEvent) {
				const that = this;
				const oNewEntry = this.Model.getProperty("/Entry");
				const oSelectedActivity = this.Model.getProperty("/SelectedActivity");
				const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
				const isLearning = this.Model.getProperty("/IsLearning");
				const isOthersTab = this.Model.getProperty("/IsOtherTab");
				const isCFvisible = this.Model.getProperty("/IsCustomerFacingVisible");
				const sTimeMatrics = oNewEntry.Unit;

				const currentWorkDuration = oNewEntry.WorkDuration;
				if (!parseFloat(currentWorkDuration, 10) || parseFloat(currentWorkDuration, 10) <= 0) {
					MessageToast.show("Please Enter Time");
					return;
				}

				let totalWorkDuration = 0;
				aEntries.filter(function (item) {
					if (item.RecordDate === oNewEntry.RecordDate) {
						totalWorkDuration = totalWorkDuration + parseFloat(item.WorkDuration, 10);
					}
				});
				let ExpectedWorkDuration = 0;
				ExpectedWorkDuration = currentWorkDuration + totalWorkDuration;
				if (sTimeMatrics === "H" && ExpectedWorkDuration > 24) {
					MessageToast.show("Cannot book >24hours in a day");
					return;
				}
				/*	else {
						if (sTimeMatrics === "D" && ExpectedWorkDuration > 1) {
							MessageToast.show("Cannot book >1day in a day");
							return;
						}
					}*/

				if (isOthersTab && !oNewEntry.TaskId) {
					MessageToast.show("Please Select Task");
					return;
				}

				if (!isLearning) {
					if (!isOthersTab) {
						const sActivityId = oNewEntry.ActvtId;
						if (!sActivityId) {
							MessageToast.show("Please select activity");
							return;
						}
					}

					const sCostTypeId = oNewEntry.CostTypeId;
					if (!sCostTypeId) {
						MessageToast.show("Please select cost type");
						return;
					}

					const sManualIo = oNewEntry.CostTypeValue;
					const property = isOthersTab ? "isOthersTabManualIO" : "isManualIO";
					if (this.Model.getProperty("/" + property) && !sManualIo) {
						MessageToast.show("Please select Manual IO");
						return;
					}
				}

				if (isLearning || isOthersTab || !isCFvisible) {
					oNewEntry.CustomerFacing = false;
				}

				const isEdit = this.Model.getProperty("/IsEdit");
				if (isEdit) {
					oNewEntry.Indicator = "U";
				} else {
					oNewEntry.Indicator = "I";
				}
				this.Model.setProperty("/IsSubmitBusy", true);
				oDayWeekTimesheetModel.setProperty("/ActivityId", oNewEntry.ActvtId);
				oDayWeekTimesheetModel.setProperty("/EntryDate", oNewEntry.Date);
				oDayWeekTimesheetModel.setProperty("/WorkDuration", oNewEntry.WorkDuration);
				oDayWeekTimesheetModel.setProperty("/StatusId", oNewEntry.StatusId);
				// aEntries.push(oNewEntry);
				MTRUtil.submitEntries([oNewEntry]).then(() => {
					let index = aEntries.findIndex(function (item) {
						return item.MtrUid === oNewEntry.MtrUid;
					});
					if (index !== -1) {
						oNewEntry.StatusId = aEntries[index].StatusId;
						aEntries[index] = oNewEntry;
					}
					this.onMessagePopoverPress();
					this._filterEntries();
					this._setEntriesInfoData(aEntries, oNewEntry.RecordDate);
					if (!isEdit) {
						this._ResetEntryData();
					}
					this.Model.setProperty("/IsSubmitBusy", false);
				});
			},
			checkDiscontinuedOpp: function (oEvent, oNewEntry, type) {
				const that = this;
				const oSettingsModel = MTRModels.getMTRSettingsModel();
				const oSettings = oSettingsModel.getData();
				const aOpportunities = oSettings.Opportunities || [];

				const oOpportunity = aOpportunities.find(item => item.OpportunityID === oNewEntry.OpportunityID);
				const oResourceModel = MTRModels.getMTRResourceModel().getResourceBundle();
				const oViewSettingsModel = this.oViewSettingsModel;

				if (oOpportunity && oOpportunity.StatusKey && oOpportunity.StatusKey === "E0002" && !oSettings.IsDisontinuedOppSubmit) {

					const bCompact = true;
					oOpportunity.discontinuedDate = "";
					if (oOpportunity.StatusSince) {
						oOpportunity.discontinuedDate = DateService.getInstance().format(oOpportunity.StatusSince, 'dd-MMM-yy');
					}
					/*if (oOpportunity.REPLACED_BY) {
						let ReplaceByOppID = parseInt(oOpportunity.REPLACED_BY);
						ReplaceByOppID = ReplaceByOppID.toString();
						const oReplaceByOpp = aOpportunities.find(item => item.OpportunityID === ReplaceByOppID);
						MessageBox.show(
							"The status of this opportunity is discontinued since (" + oOpportunity.discontinuedDate + ").\nHowever, there exists a parallel opportunity (" + ReplaceByOppID + ") for this. You can choose to book time on the parallel opportunity.\nDo you still want to continue to book time on this discontinued opportunity?", {
							styleClass: bCompact ? "sapUiSizeCompact" : "",
							icon: MessageBox.Icon.CONFIRM,
							actions: [MessageBox.Action.YES, MessageBox.Action.NO],
							dependentOn: parentController.getView(),
							onClose: async (sAction) => {
								if (sAction === sap.m.MessageBox.Action.YES) {
									parentController.fnChangeDuration(oEvent, refDataFrm);
	
								} else {
									await that.fnUpdateDiscontOpp(oEntry, oReplaceByOpp, refDataFrm);
									parentController.updateDiscontinuedOppWithParallelOpp(oEvent, refDataFrm, oReplaceByOpp);
	
								}
							}
						});
	
					} else {*/
					MessageBox.show(
						oResourceModel.getText("discontinuedSinceMsg1") + " (" + oOpportunity.discontinuedDate + ").\n" + oResourceModel.getText("discontinuedSinceMsg2") + "?", {
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						icon: MessageBox.Icon.CONFIRM,
						title: oResourceModel.getText("discontinuedOpportunitiesTxt"),
						actions: [MessageBox.Action.YES, MessageBox.Action.NO],
						dependentOn: that.getView(),
						onClose: (sAction) => {
							if (sAction === sap.m.MessageBox.Action.YES) {
								if (type === "save") {
									that.fnSaveNewEntry(oEvent);
								} else {
									that.fnSubmitNewEntry(oEvent);
								}
							} else {
								that.Model.setProperty("/Entry/WorkDuration", "0.0");
								MessageToast.show(oResourceModel.getText("noTimeEntriesSaveMsg"));
							}
						}
					});
				} else {
					if (type === "save") {
						that.fnSaveNewEntry(oEvent);
					} else {
						that.fnSubmitNewEntry(oEvent);
					}
				}
			},
			_ResetEntryData: function () {
				let oEntry = this.Model.getProperty("/Entry");
				const oSelectedActivity = this.Model.getProperty("/SelectedActivity");
				const dDate = oEntry.Date;
				const sTaskId = oEntry.TaskId;
				const sTaskName = oEntry.TaskName;
				const sDate = DateService.getInstance().format(dDate, "yMMdd");
				const longDate = oEntry.FormattedLongDate;
				const sCostTypeName = oEntry.CostTypeName;
				if (oSelectedActivity) {
					oEntry = new Entry({
						ActvtId: oEntry.ActvtId,
						ActTypeDesc: oEntry.ActTypeDesc,
						RecordDate: sDate,
						CostTypeId: oEntry.CostTypeId,
						CostTypeValue: oEntry.CostTypeValue,
						TaskId: sTaskId,
						TaskName: sTaskName
					});
					oEntry.CostTypeName = sCostTypeName;
				} else {
					oEntry = new Entry({
						RecordDate: sDate
					});
				}
				oEntry.FormattedLongDate = longDate;
				oEntry.RecordDate = sDate;
				const isLearning = this.Model.getProperty("/IsLearning");
				if (isLearning) {
					oEntry.CostTypeId = "2";
					oEntry.TaskId = sTaskId;
					oEntry.TaskName = sTaskName;
				}
				this.Model.setProperty("/Entry", oEntry);
				this.Model.setProperty("/isManualIO", false);
				this.Model.setProperty("/isSpecialTask", false);
				this.Model.setProperty("/isOthersTabManualIO", false);
				this.Model.refresh(true);
			},

			_filterEntries: function () {
				const that = this;
				const sSelectedDate = this.Model.getProperty("/Entry/RecordDate");
				MTRUtil.filterEntries(sSelectedDate);
				const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				if (oDayWeekTimesheetModel) {
					// that.Model.setProperty("/Entry", oDayWeekTimesheetModel.getProperty("/NewEntry"));
					that.Model.setProperty("/Submitted", oDayWeekTimesheetModel.getProperty("/Submitted"));
					that.Model.setProperty("/Saved", oDayWeekTimesheetModel.getProperty("/Saved"));
					that.Model.setProperty("/Expected", oDayWeekTimesheetModel.getProperty("/Expected"));
				}
			},

			onMyTimeEntries: function (oEvent) {
				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
				const hashTarget = oCrossAppNavigator.hrefForExternal({
					target: {
						shellHash: "#pcactivityform-app&/MyEntries",
						action: 'display'
					}
				});
				const url = window.location.href.split('#')[0] + hashTarget;
				sap.m.URLHelper.redirect(url, true);
				/*oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#pcactivityform-app&/MyEntries"
					}
				});*/
				// this.router.navTo("MyEntries", {}, false);
			},

			onMessagePopoverPress: function (oEvent) {
				const oButton = sap.ui.core.Fragment.byId(this.DialogId, "messagePopoverBtn");
				const oSource = oEvent ? oEvent.getSource() : oButton;
				if (oButton) {
					oButton.firePress();
				}
				// this._oMessagePopover.openBy(oSource);
			},

			openEntriesInfoPopover: function (oEvent) {
				const oSource = oEvent.getSource();
				this._oEntriesInfoPopover.openBy(oSource);
			},

			onCloseEntriesInfoPopover: function (oEvent) {
				this._oEntriesInfoPopover.close();
			},

			openActInfoPopover: function (oEvent) {
				const oSource = oEvent.getSource();
				this._oActInfoPopover.openBy(oSource);
			},

			closeActInfoPopover: function (oEvent) {
				this._oActInfoPopover.close();
			},

			handleDialogEscape: function () {
				MessageToast.show("Click on close button to close the dialog");
				return;
			},

			handleAfterMtrDlgOpen: function (oEvent) {
				if (MTRHelper.oTimeEntryInstance && typeof MTRHelper.oTimeEntryInstance.setBusy === "function") {
					MTRHelper.oTimeEntryInstance.setBusy(false);
				}
			},

			//others tab
			// onDurationChange: function (oEvent) {
			// 	const iValue = oEvent.getSource().getValue();
			// 	const oNewEntry = this.Model.getProperty("/Entry");
			// 	const sTimeMatrics = oNewEntry.Unit;
			// 	const isValid = iValue % 0.5 === 0;
			// 	if (sTimeMatrics === "D" && (iValue > 1 || !isValid)) {
			// 		oEvent.getSource().setValue("");
			// 		return;
			// 	}

			// 	const iExpectedHrs = (sTimeMatrics === "D" && parseInt(oNewEntry.Expected, 10) === 0) ? 1 : parseInt(oNewEntry.Expected, 10);
			// 	const bMaxCapacityAlert = this.Model.getProperty("/MaxCapacityAlert");
			// 	const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			// 	const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
			// 	const isEdit = oNewEntry.IsEdit;
			// 	const oResourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
			// 	const sUnit = sTimeMatrics === "H" ? "hours" : "days";
			// 	let totalWorkDuration = 0;
			// 	aEntries.filter(function (item) {
			// 		if (item.RecordDate === oNewEntry.RecordDate) {
			// 			totalWorkDuration = totalWorkDuration + parseFloat(item.WorkDuration, 10);
			// 		}
			// 	});
			// 	if ((totalWorkDuration + iValue) > iExpectedHrs) {
			// 		if (sTimeMatrics === "H") {
			// 			if (!bMaxCapacityAlert) {
			// 				MessageToast.show("You have already logged time entries up to your capacity hours (" + iExpectedHrs + " " + sUnit +
			// 					") for the day.");
			// 				this.Model.setProperty("/MaxCapacityAlert", true);
			// 			}
			// 		} else {
			// 			if (!isEdit) {
			// 				MessageToast.show("Cannot book >1day in a day.");
			// 				oEvent.getSource().setValue("");
			// 				return;
			// 			}
			// 		}
			// 	}
			// },
			onDurationChange: function (oEvent) {

				const iValue = oEvent.getSource().getValue();
				const oNewEntry = this.Model.getProperty("/Entry");
				const sTimeMatrics = oNewEntry.Unit;
				const isValid = iValue % 0.5 === 0;
				if (sTimeMatrics === "D" && (iValue > 1 || !isValid)) {
					oEvent.getSource().setValue("");
					return;
				}

				const sSelectedOppId = (oNewEntry && oNewEntry.OpportunityID) ? oNewEntry.OpportunityID : "";
				let bIsDiscontinuedOpp = false;
				if (sSelectedOppId) {
					bIsDiscontinuedOpp = MTRUtil.fnIsDiscontinuedOpportunity(oEvent, oNewEntry, sSelectedOppId, this, "dayWeekActivityData");
				}

				if (!bIsDiscontinuedOpp) {
					this.fnChangeDuration(oEvent, "dayWeekActivityData");
				}

			},
			// Siddharth
			fnChangeDuration: function (oEvent, refDataFrm) {
				const oNewEntry = this.Model.getProperty("/Entry");
				const iWorkDuration = (oNewEntry && oNewEntry.WorkDuration) ? oNewEntry.WorkDuration : "";
				let iValue = (oEvent) ? oEvent.getSource().getValue() : iWorkDuration;

				const sTimeMatrics = oNewEntry.Unit;
				const isValid = iValue % 0.5 === 0;
				if (sTimeMatrics === "D" && (iValue > 1 || !isValid)) {
					if (oEvent) {
						oEvent.getSource().setValue("");
					} else {
						this.Model.setProperty("/Entry/WorkDuration", "");
					}
					return;
				}

				const iExpectedHrs = (sTimeMatrics === "D" && parseInt(oNewEntry.Expected, 10) === 0) ? 1 : parseInt(oNewEntry.Expected, 10);
				const bMaxCapacityAlert = this.Model.getProperty("/MaxCapacityAlert");
				const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
				const isEdit = oNewEntry.IsEdit;
				const oResourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
				const sUnit = sTimeMatrics === "H" ? "hours" : "days";
				let totalWorkDuration = 0;
				aEntries.filter(function (item) {
					if (item.RecordDate === oNewEntry.RecordDate) {
						totalWorkDuration = totalWorkDuration + parseFloat(item.WorkDuration, 10);
					}
				});
				if ((totalWorkDuration + iValue) > iExpectedHrs) {
					if (sTimeMatrics === "H") {
						if (!bMaxCapacityAlert) {
							MessageToast.show("You have already logged time entries up to your capacity hours (" + iExpectedHrs + " " + sUnit +
								") for the day.");
							this.Model.setProperty("/MaxCapacityAlert", true);
						}
					} else {
						if (!isEdit) {
							MessageToast.show("Cannot book >1day in a day.");
							if (oEvent) {
								oEvent.getSource().setValue("");
							} else {
								this.Model.setProperty("/Entry/WorkDuration", "")
							}
							return;
						}
					}
				}
			},
			updateDiscontinuedOppWithParallelOpp: function (event, refDataFrm, oReplaceByOpp) {
				const oNewEntry = this.Model.getProperty("/Entry");
				oNewEntry.AccountID = oReplaceByOpp.AccountID;
				oNewEntry.AccountName = oReplaceByOpp.AccountName;
				oNewEntry.CostTypeValue = oReplaceByOpp.OpportunityID;
				oNewEntry.OpportunityID = oReplaceByOpp.OpportunityID;
				oNewEntry.OpportunityName = oReplaceByOpp.OpportunityName;
				oNewEntry.CostTypeName = oReplaceByOpp.OpportunityName;
				if (oNewEntry.ActDetails) {
					oNewEntry.ActDetails.AccountId = oReplaceByOpp.AccountID;
					oNewEntry.ActDetails.CostTypeValue = oReplaceByOpp.OpportunityID;
					oNewEntry.ActDetails.OpportunityId = oReplaceByOpp.OpportunityID;
					oNewEntry.ActDetails.OpportunityName = oReplaceByOpp.OpportunityName;
				}
				this.Model.setProperty("/Entry", oNewEntry);

				this.fnSetAccountInfoDetails(oReplaceByOpp.OpportunityID, "DISPLAYMODE");
				this.fnSetAccountInfoDetails(oReplaceByOpp.AccountID, "DISPLAYMODE");
				const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");

				let index = aEntries.findIndex(function (item) {
					return item.MtrUid === oNewEntry.MtrUid;
				});
				if (index !== -1) {
					aEntries[index].AccountID = oReplaceByOpp.AccountID;
					aEntries[index].AccountName = oReplaceByOpp.AccountName;
					aEntries[index].CostTypeValue = oReplaceByOpp.OpportunityID;
					aEntries[index].OpportunityID = oReplaceByOpp.OpportunityID;
					aEntries[index].OpportunityName = oReplaceByOpp.OpportunityName;
					if (aEntries[index].ActDetails) {
						aEntries[index].ActDetails.OpportunityID = oReplaceByOpp.OpportunityID;
						aEntries[index].ActDetails.AccountID = oReplaceByOpp.OpportunityID;
						aEntries[index].ActDetails.CostTypeValue = oReplaceByOpp.OpportunityID;
						aEntries[index].ActDetails.OpportunityName = oReplaceByOpp.OpportunityName;
					}
					oDayWeekTimesheetModel.setProperty("/Entries", aEntries);
					this.Model.setProperty("/Entries", aEntries);
					oDayWeekTimesheetModel.refresh(true);
					this.Model.refresh(true);
				}
				this.fnChangeDuration(event, refDataFrm);
			},
			onOthrsTabCostObjectChange: function (oEvent) {
				// const index = oEvent.getParameter("selectedIndex");
				const sSelectedKey = oEvent.getSource().getSelectedKey();
				const mtrSettings = sap.ui.getCore().getModel("mtrSettings");
				const sCostTypeValue = mtrSettings.getProperty("/CostCenter");
				if (sSelectedKey === "3") {
					this.Model.setProperty("/isOthersTabManualIO", true);
					this.Model.setProperty("/Entry/CostTypeValue", "");
					this.Model.setProperty("/Entry/CostTypeId", "3");
				} else {
					this.Model.setProperty("/isOthersTabManualIO", false);
					this.Model.setProperty("/Entry/CostTypeValue", sCostTypeValue);
					this.Model.setProperty("/Entry/CostTypeId", "2");
				}
			},

			onOthrsTabTaskChange: function (oEvent) {
				const oSelectedItem = oEvent.getParameter("selectedItem");
				if (oSelectedItem) {
					const oTask = oSelectedItem.getBindingContext("mtrSettings").getObject();
					if (oTask.TaskId === 11) {
						this.Model.setProperty("/isSpecialTask", true);
					} else {
						this.Model.setProperty("/isSpecialTask", false);
						this.Model.setProperty("/isOthersTabManualIO", false);
					}
					const mtrSettings = sap.ui.getCore().getModel("mtrSettings");
					const sCostTypeValue = mtrSettings.getProperty("/CostCenter");
					this.Model.setProperty("/Entry/TaskId", oTask.TaskId);
					this.Model.setProperty("/Entry/TaskName", oTask.TaskName);
					this.Model.setProperty("/Entry/CostTypeId", "2");
					this.Model.setProperty("/Entry/CostTypeValue", sCostTypeValue);
				}
			},

			handleISPMessagePopoverPress: function (oEvent, popupType) {
				var oModel;
				var oStaffingModel = MTRModels.getStaffingModel();
				var aStaffingRecord = oStaffingModel.getData();
				var oEntry = this.Model.getProperty("/Entry");
				const oResourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
				var remainingDays;
				var aStaffingData = [];
				var that = this;
				var oControl = oEvent.getSource();
				var sOwnerName = "";
				var sOpportunityName = "";
				const oSettingsModel = MTRModels.getMTRSettingsModel();
				var aOpportunities = oSettingsModel.getProperty("/Opportunities");
				var aManualIOs = oSettingsModel.getProperty("/to_MANUAL");
				var oOpportunity = null;
				var oManualIO = null;
				this.IOStaffing = null;
				var sInternalOrder = "";
				var isOpportunity = true;
				var isValid = false;

				if (oEntry.CostTypeId.toString() === "1") {
					oOpportunity = aOpportunities.find(function (item) {
						return item.OpportunityID === oEntry.CostTypeValue;
					});
					if (oOpportunity && oOpportunity.IOSetting === "Yes" && oOpportunity.AssociatedIO && oOpportunity.AssociatedIO !== "") {
						sInternalOrder = oOpportunity.AssociatedIO;
					}

				} else if ((oEntry.CostTypeId === "3" || oEntry.CostTypeId === 3) && oEntry.CostTypeValue && oEntry.CostTypeValue !== "") {
					oManualIO = aManualIOs.find(function (item) {
						return item.ManualIOID === oEntry.CostTypeValue;
					});
					if (oManualIO) {
						sInternalOrder = oEntry.CostTypeValue;
					}
					isOpportunity = false;
				}

				const sDateFormat = oSettingsModel.getProperty("/DateFormat");

				const oDateFormat = oSettingsModel.getProperty("/DateFormats").find(function (d) {
					return d.ID === sDateFormat;
				});
				const aAssociatedIOData = aStaffingRecord.filter(function (item) {
					return sInternalOrder && item.InternalOrder === sInternalOrder;

				});

				if (!sInternalOrder || aAssociatedIOData.length === 0) {
					let sOpportunityOrManulDesc = (isOpportunity) ? oOpportunity.OpportunityName : "";
					if (!isOpportunity && oManualIO) {
						sOpportunityOrManulDesc = oManualIO.ManualIODesc;
					}
					const oOpportunutyDetails = (oOpportunity && oOpportunity.OpportunityID) ? oOpportunity.OpportunityID : sInternalOrder;

					aStaffingData.push({
						Name: sOpportunityOrManulDesc,
						Error: true,
						ErrorMessage: (!sInternalOrder) ? "IO not associated with Opportunity" : "IO details associated with Opportunity but you are not staffed",
						MessageDescription: (!sInternalOrder) ?
							"INFO SECTION\n\nSelected Opportunity " + oOpportunutyDetails +
							" is not associated with any IO as of today. Hence, you will not be able to Submit time for the same. \n\n" +
							"This could be due to any of the below reasons: \n\n1. IO has not been created for Opportunity so far. \n\n" +
							"2. You have not been staffed with the associated IO. \n\nRESOLUTION\n\nPlease submit a ticket for resolution, you can save the entry for now." : "INFO SECTION\n\nSelected Opportunity " +
							oOpportunutyDetails +
							" is associated with an IO " + sInternalOrder +
							", but you are not staffed on the IO. Hence, you will not be able to Submit time for the same. \n\nThis could be due below reasons:\n1. You are not staffed on the associated IO. \n\nRESOLUTION \n\nPlease submit a ticket for resolution, you can save the entry for now.",
						TicketText: "Submit a ticket",
						TicketLinkHref: "https://itsm.services.sap/sp?id=sc_cat_item&sys_id=703f22d51b3b441020c8fddacd4bcbe2&sysparm_category=e15706fc0a0a0aa7007fc21e1ab70c2&service_offering=2aa782291b244110d9c921fbbb4bcbdb&short_description=PreSales%20Tools:%20Melody%20Time%20Recordingp",
						Staffing: (!sInternalOrder) ? "IO Details" : sInternalOrder,
					});
				} else {
					for (let i = 0; i < aAssociatedIOData.length; i++) {
						if (!aAssociatedIOData[i].StaffedDays) {
							let sMessageDescription = "";
							if (aAssociatedIOData[i].IsOpportunityIO) {
								sMessageDescription = "INFO SECTION\n\nSelected Opportunity " + sOpportunityId +
									" is associated with an IO " + sInternalOrder +
									". which has been assigned to the Task Type or Task Level not matching with the Task Type or Task Level assigned to the Task you have Selected." +
									"\n\n1. IO – " + sInternalOrder +
									" assigned to Task Level and Task Type. \n\n2.Support and Enablement assigned to Task Level K1 and Task Type. \n\nRESOLUTION\n\nPlease submit a ticket for resolution, you can save the entry for now."
							} else {
								sMessageDescription = "INFO SECTION\n\nSelected Manual IO " + aAssociatedIOData[i].InternalOrder +
									". which has been assigned to the Task Type or Task Level not matching with the Task Type or Task Level assigned to the Task you have Selected." +
									"\n\n1. Manual IO – " + aAssociatedIOData[i].InternalOrder +
									" assigned to Task Level and Task Type. \n\n2.Support and Enablement assigned to Task Level K1 and Task Type. \n\nRESOLUTION\n\nPlease submit a ticket for resolution, you can save the entry for now."
							}
							aStaffingData.push({
								Name: (isOpportunity) ? oOpportunity.OpportunityName : aAssociatedIOData[i].Description,
								Error: true,
								ErrorMessage: sMessageDescription,
								TicketText: "Submit a ticket",
								TicketLinkHref: "https://itsm.services.sap/sp?id=sc_cat_item&sys_id=703f22d51b3b441020c8fddacd4bcbe2&sysparm_category=e15706fc0a0a0aa7007fc21e1ab70c2&service_offering=2aa782291b244110d9c921fbbb4bcbdb&short_description=PreSales%20Tools:%20Melody%20Time%20Recordingp",
								Staffing: sInternalOrder
							});
						} else {
							remainingDays = (parseFloat(aAssociatedIOData[i].StaffedDays) - parseFloat(aAssociatedIOData[i].RecordedDays)) + " Days Left";

							aStaffingData.push({
								Error: false,
								Staffing: "Staffing " + (i + 1),
								ID: (isOpportunity) ? oOpportunity.OpportunityID : aAssociatedIOData[i].InternalOrder,
								Name: (isOpportunity) ? oOpportunity.OpportunityName : aAssociatedIOData[i].Description,
								Owner: (isOpportunity) ? oOpportunity.OwnerName : "",
								AccountID: (isOpportunity) ? oOpportunity.AccountID : "",
								AccountName: (isOpportunity) ? oOpportunity.AccountName : "",
								InternalOrder: sInternalOrder,
								StaffedDays: aAssociatedIOData[i].StaffedDays,
								StartDate: DateService.getInstance().formatStringDate(aAssociatedIOData[i].StartDate, oDateFormat.Value),
								EndDate: DateService.getInstance().formatStringDate(aAssociatedIOData[i].EndDate, oDateFormat.Value),
								TaskType: aAssociatedIOData[i].TaskType,
								TaskLevel: aAssociatedIOData[i].TaskLevel,
								IsOpportunity: isOpportunity,
								RemainingDays: remainingDays,
								Analytics: [{
									"Staffing": oResourceBundle.getText("recordedDays"),
									"Days": parseFloat(aAssociatedIOData[i].RecordedDays)
								}, {
									"Staffing": oResourceBundle.getText("remainingDays"),
									"Days": parseFloat(aAssociatedIOData[i].StaffedDays) - parseFloat(aAssociatedIOData[i].RecordedDays)
								}]
							});
						}
					}
				}

				if (!this._oISPInfoPopover) {
					this._oISPInfoPopover = sap.ui.xmlfragment("com.melody.lib.fragments.MTR.ISPMessagePopover", this);
					var oResourcei18nModel = MTRModels.getMTRResourceModel();
					this._oISPInfoPopover.setModel(oResourcei18nModel, "i18n");
					this._oISPInfoPopover.setModel(new JSONModel(aStaffingData));
				}
				this._oISPInfoPopover.openBy(oEvent.getSource());
			},


			handleISPMessagePopoverClose: function () {
				if (this._oISPInfoPopover) {
					this._oISPInfoPopover.close();
					this._oISPInfoPopover.destroy();
					this._oISPInfoPopover = null;
				}
			},

		});

		return MTRHelper;
	});