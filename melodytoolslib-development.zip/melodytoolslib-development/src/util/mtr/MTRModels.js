sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"com/melody/lib/service/DateService",
	"com/melody/lib/classes/mtr/Settings",
	"sap/ui/model/resource/ResourceModel"
], function (JSONModel, DateService, Settings, ResourceModel) {
	"use strict";
	return {
		dateServicesInstance: DateService.getInstance(),
		initModels: function () {
			this.getTargetModel();
		},
		getDurationSuggestionsModel: function () {
			const aHoursSuggestions = [{
				key: "0.5",
				value: "0.5",
				allowedOnDay: true
			}, {
				key: "1",
				value: "1",
				allowedOnDay: true
			}, {
				key: "1.5",
				value: "1.5",
				allowedOnDay: false
			}, {
				key: "2",
				value: "2",
				allowedOnDay: false
			}, {
				key: "2.5",
				value: "2.5",
				allowedOnDay: false
			}, {
				key: "3",
				value: "3",
				allowedOnDay: false
			}, {
				key: "3.5",
				value: "3.5",
				allowedOnDay: false
			}, {
				key: "4",
				value: "4",
				allowedOnDay: false
			}, {
				key: "4.5",
				value: "4.5",
				allowedOnDay: false
			}, {
				key: "5",
				value: "5",
				allowedOnDay: false
			}, {
				key: "5.5",
				value: "5.5",
				allowedOnDay: false
			}, {
				key: "6",
				value: "6",
				allowedOnDay: false
			}, {
				key: "6.5",
				value: "6.5",
				allowedOnDay: false
			}, {
				key: "7",
				value: "7",
				allowedOnDay: false
			}, {
				key: "7.5",
				value: "7.5",
				allowedOnDay: false
			}, {
				key: "8",
				value: "8",
				allowedOnDay: false
			}];

			const aDaysSuggestions = [{
				key: "0.5",
				value: "0.5",
				allowedOnDay: true
			}, {
				key: "1",
				value: "1",
				allowedOnDay: true
			}];

			let oModel = sap.ui.getCore().getModel("durationSuggestions");
			if (!oModel) {
				const oSettings = this.getMTRSettingsModel();
				if (oSettings.TimeMatrics === "H") {
					oModel = new JSONModel(aHoursSuggestions);
				} else {
					oModel = new JSONModel(aDaysSuggestions);
				}
				sap.ui.getCore().setModel(oModel, "durationSuggestions");
			}

			return oModel;
		},

		getActvityTaskTypesModel: function () {

			let oModel = sap.ui.getCore().getModel("activityTaskTypes");

			if (!oModel) {
				oModel = new JSONModel([]);
				sap.ui.getCore().setModel(oModel, "activityTaskTypes");
			}
			return oModel;
		},
		getTargetModel: function () {

			let oModel = sap.ui.getCore().getModel("target");

			if (!oModel) {
				oModel = new JSONModel({
					Holidays: [],
					Vacations: [],
					TargetHours: []
				});
				sap.ui.getCore().setModel(oModel, "target");
			}
			return oModel;
		},

		getMessagesModel: function () {

			let oModel = sap.ui.getCore().getModel("messages");

			if (!oModel) {
				oModel = new JSONModel([]);
				sap.ui.getCore().setModel(oModel, "messages");
			}
			return oModel;
		},

		getMTRSettingsModel: function () {
			let oSettingsModel = sap.ui.getCore().getModel("mtrSettings");

			if (!oSettingsModel) {
				// const oSettings = new Settings();
				const oSettings = new com.melody.lib.classes.mtr.Settings();
				oSettingsModel = new JSONModel(oSettings);
				sap.ui.getCore().setModel(oSettingsModel, "mtrSettings");
			}
			return oSettingsModel;
		},

		getDayWeekTimesheetModel: function () {

			let oModel = sap.ui.getCore().getModel("dayWeekTimesheet");

			if (!oModel) {
				oModel = new JSONModel({
					SelectedDate: this.dateServicesInstance.format(new Date(), "EEEE, MMMM dd,y"),
					NewEntry: null,
					Entries: [],
					TempEntries: []
				});
				sap.ui.getCore().setModel(oModel, "dayWeekTimesheet");
			}
			return oModel;
		},

		getMTRResourceModel: function () {
			let oModel = sap.ui.getCore().getModel("i18nMTR");

			if (!oModel) {
				oModel = new ResourceModel({
					bundleName: "com.melody.lib.i18n.i18n",
					supportedLocales: ["en", "de"],
					fallbackLocale: "en"
				});
				sap.ui.getCore().setModel(oModel, "i18nMTR");
			}
			return oModel;
		},

		getWeekTimesheetModel: function () {

			let oModel = sap.ui.getCore().getModel("weekTimesheet");

			if (!oModel) {

				const weekTimesheet = {
					Timesheets: {
						Utilized: [],
						NonUtilized: []
					},
					TimeEntries: [],
					TempTimesheets: [],
					StartDate: "",
					NewEntry: null,
					SelectedWeekDate: "",

					Expected: 40,
					Submitted: 0,
					Saved: 0,
					Date1Total: {
						Utilized: 0,
						NonUtilized: 0,
						TotalTime: 0,
						StatusTotal: "default",
						StatusUtilized: "default",
						StatusNonUtilized: "default"
					},
					Date2Total: {
						Utilized: 0,
						NonUtilized: 0,
						TotalTime: 0,
						StatusTotal: "default",
						StatusUtilized: "default",
						StatusNonUtilized: "default"

					},
					Date3Total: {
						Utilized: 0,
						NonUtilized: 0,
						TotalTime: 0,
						StatusTotal: "default",
						StatusUtilized: "default",
						StatusNonUtilized: "default"
					},
					Date4Total: {
						Utilized: 0,
						NonUtilized: 0,
						TotalTime: 0,
						StatusTotal: "default",
						StatusUtilized: "default",
						StatusNonUtilized: "default"
					},
					Date5Total: {
						Utilized: 0,
						NonUtilized: 0,
						TotalTime: 0,
						StatusTotal: "default",
						StatusUtilized: "default",
						StatusNonUtilized: "default"
					},
					Date6Total: {
						Utilized: 0,
						NonUtilized: 0,
						TotalTime: 0,
						StatusTotal: "default",
						StatusUtilized: "default",
						StatusNonUtilized: "default"
					},
					Date7Total: {
						Utilized: 0,
						StatusTotal: "default",
						StatusUtilized: "default",
						StatusNonUtilized: "default"
					}

				};

				oModel = new JSONModel(weekTimesheet);

				sap.ui.getCore().setModel(oModel, "weekTimesheet");
			}
			return oModel;
		},

		//Function to get Matrix Model
		getMatrixModel: function () {
			let oModel = sap.ui.getCore().getModel("matrixModel");
			if (!oModel) {
				const matrixModelData = {
					"matrixCategory": "activity",
					"registrationTypes": [{
						"name": "Account",
						"type": true,
						"key": "4",
						"isEnabled": true,
						"isPressed": true,
						"keyId": 0,
						"ActvtAsstdID": "501"
					}, {
						"name": "Opportunity",
						"type": false,
						"key": "1",
						"isEnabled": true,
						"isPressed": false,
						"keyId": 1,
						"ActvtAsstdID": "502"
					}, {
						"name": "No Association",
						"type": false,
						"key": "2",
						"isEnabled": true,
						"isPressed": false,
						"keyId": 2,
						"ActvtAsstdID": "503"
					}],
					"matrixLearningData": [{
						"selectedAssociation": "",
						"activityMode": "NEW",
						"activityId": ""
					}],
					"tempExistingActivities": [],
					"existingActivities": [{
						"ActTypeDesc": "",
						"StartDate": "",
						"ActStatusDesc": "",
						"IsSelected": false
					}],
					"ActTypesForFilter": "",
					"ActStatusForFilter": "",
					"StartOfStartDateRange": null,
					"EndOfStartDateRange": null,
					"StartOfEndDateRange": null,
					"EndOfEndDateRange": null,
					"totalHours": {
						Date1: 0,
						Date2: 0,
						Date3: 0,
						Date4: 0,
						Date5: 0,
						Date6: 0,
						Date7: 0,
					},
					"subTotalHours": {
						Date1: 0,
						Date2: 0,
						Date3: 0,
						Date4: 0,
						Date5: 0,
						Date6: 0,
						Date7: 0,
					},
					"activityData": {
						"activityId": "",
						"startDate": ""
					},
					"IsSaveBusy": false,
					"IsSubmitBusy": false,
					"matrixMenu": [{
						"name": "New Activity",
						"key": "1"
					}, {
						"name": "Existing Activity",
						"key": "2"
					}],
					"aMatrixDrafts": [],
					"SearchBarMenu": [{
						"name": "Account",
						"key": "4",
						"ActvtAsstdID": "501"
					}, {
						"name": "Opportunity",
						"key": "1",
						"ActvtAsstdID": "502"
					}, {
						"name": "No Association",
						"key": "2",
						"ActvtAsstdID": "503"
					}],
					"aSortColumns": [{
						key: "AccountName",
						text: "Account",
						selected: false
					}, {
						key: "OpportunityName",
						text: "Opportunity",
						selected: false
					}],
					"filterBarKey": "502",
					"sSearchMatrixList": ""
				};
				oModel = new JSONModel(matrixModelData);
				oModel.setSizeLimit(99999);
				sap.ui.getCore().setModel(oModel, "matrixModel");
			}
			return oModel;
		},

		getStaffingModel: function () {
			let oStaffingModel = sap.ui.getCore().getModel("staffing");

			if (!oStaffingModel) {
				oStaffingModel = new JSONModel([]);
				sap.ui.getCore().setModel(oStaffingModel, "staffing");
			}
			return oStaffingModel;
		},

		getMessagePopoverModel: function () {
			let oMessagePopoverModel = sap.ui.getCore().getModel("messagePopoverModel");
			if (!oMessagePopoverModel) {
				oMessagePopoverModel = new JSONModel({
					"aMessageData": [],
					"aSources": []
				});
				sap.ui.getCore().setModel(oMessagePopoverModel, "messagePopoverModel");
			}
			return oMessagePopoverModel;
		},

		getSolutionHierarchyModel: function () {
			let oSolutionsModel = sap.ui.getCore().getModel("oSolutionsModel");
			if (!oSolutionsModel) {
				oSolutionsModel = new JSONModel([]);
				oSolutionsModel.setSizeLimit(99999);
				sap.ui.getCore().setModel(oSolutionsModel, "oSolutionsModel");
			}
			return oSolutionsModel;
		}
	};
});