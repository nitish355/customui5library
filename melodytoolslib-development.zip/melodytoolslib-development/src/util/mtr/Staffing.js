sap.ui.define([
	"com/melody/lib/service/ISPService",
	"com/melody/lib/service/DateService",
	"com/melody/lib/util/mtr/MTRModels"
], function (ISPService, DateService, MTRModels) {
	"use strict";
	return {
		dateServicesInstance: DateService.getInstance(),
		fetchStaffing: async function (personalNumber) {
			var dCurrentDate = new Date(); // current date
			var dFromDate = new Date(dCurrentDate.getFullYear() - 1, 0, 1);
			var sFromDate = this.dateServicesInstance.format(dFromDate, "yMMdd");
			var dToDate = new Date(dCurrentDate.getFullYear() + 2, 0, 0);
			var sToDate = this.dateServicesInstance.format(dToDate, "yMMdd");
			const data = await ISPService.getStaffing(personalNumber, sFromDate, sToDate);
			
			const aStaffings = [];
			const oStaffingModel = MTRModels.getStaffingModel();
			for (var i = 0; i < data.data.results.length; i++) {
				var oStaffing = new Staffing(data.data.results[i]);
				aStaffings.push(oStaffing);
			}
			oStaffingModel.setData(aStaffings);
		},
		
		/*getStaffingModel: function () {
			let oStaffingModel = sap.ui.getCore().getModel("staffing");
			
			if(!oStaffingModel) {
				oStaffingModel = new JSONModel([]);
				sap.ui.getCore().setModel(oStaffingModel, "staffing");
			}
			return oStaffingModel;
		}*/
		
	};
});