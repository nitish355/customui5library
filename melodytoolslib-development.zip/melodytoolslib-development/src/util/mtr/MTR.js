sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"com/melody/lib/service/DateService",
	"com/melody/lib/util/UserMaster",
	"com/melody/lib/util/Opportunity",
	"com/melody/lib/service/mtr/MTRService",
	"com/melody/lib/service/mtr/ISPService",
	"com/melody/lib/classes/mtr/Staffing",
	"com/melody/lib/classes/mtr/Category",
	"com/melody/lib/classes/mtr/MTRCostType",
	"com/melody/lib/classes/mtr/MTRLocation",
	"com/melody/lib/classes/mtr/OpportunityIOSettings",
	"com/melody/lib/classes/mtr/MTRAccount",
	"com/melody/lib/classes/mtr/Entry",
	"com/melody/lib/classes/mtr/ArtesEntry",
	"com/melody/lib/classes/mtr/ManualIO",
	"com/melody/lib/classes/mtr/Timesheet",
	"com/melody/lib/util/mtr/MTRModels",
	"com/melody/lib/classes/mtr/Message",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/core/Fragment"
], function (JSONModel, DateService, UserMaster, OpportunityUtil,
	MTRService, ISPService, Staffing, Category,
	MTRCostType, MTRLocation, OpportunityIOSettings, MTRAccount, Entry, ArtesEntry, ManualIO,
	Timesheet, MTRModels, Message, MessageToast, MessageBox, Fragment) {
	"use strict";
	return {

		init: async function (appId) {
			try {
				const user = await UserMaster.authenticate();
				if (user) {
					const sUserId = user.UserId;
					const sOreFlag = user.OreFlag;
					if (sUserId && sOreFlag === "X") {
						MTRModels.initModels();
						const oSettingsModel = MTRModels.getMTRSettingsModel();
						const oSettings = oSettingsModel.getData();

						try {
							// set ORE Data
							oSettings.setOREUserDetails(user);
							oSettings.Application = (appId) ? appId.toUpperCase() : "";

							// fetch ISP User details and valid user is authorized in ISP
							this._fetchISPUserInfo();

							// fetch Target Hours data to calculate Weekends and Start Day of Week, 
							this._fetchWeekends();

							// this method gets IO Staffing three years record
							this._fetchStaffing(oSettings.PersonalNumber);

							// this method gets setting's lookup data from LS - Timesheet Modes and Date Formats
							this._fetchSettingsLookups();

							//set Partner ID
							const sPartnerId = await OpportunityUtil.getBusinessPartner(sUserId);
							if (sPartnerId && sPartnerId !== "") {
								oSettings.PartnerId = sPartnerId;
							}

							await this._fetchMTRSettings(user, appId);

							// oSettings.Loading = false;
							// oSettingsModel.refresh(true);
						} catch (e) {
							// oSettings.Loading = false;
							// oSettingsModel.refresh(true);
							throw e;
						}

						//notify user if the entry is more than 60days older
						const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
						const isUserNotified = oStorage.get("isUserNotified");
						if (!isUserNotified) {
							this.showUserNotification();
						}

					} else if (sOreFlag && sOreFlag === "D" || sOreFlag === "d") {
						throw new Error("ORE_DOWN");
					} else {
						throw new Error("USER_NOT_ACTIVE");
					}
				}
			} catch (error) {
				// MessageBox.show(error);
				console.log("ERROR IN MTR.js Init : ", error);
			}

		},

		_fetchISPUserInfo: async function () {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			try {
				const oISPUserInfo = await ISPService.getISPUserInfo();
				if (oISPUserInfo) {
					if (oISPUserInfo.Kostl) {
						oSettingsModel.setProperty("/CostCenter", oISPUserInfo.Kostl);
					}
					oSettingsModel.setProperty("/CostCenterName", oISPUserInfo.Kostx);
					oSettingsModel.setProperty("/Objnr", oISPUserInfo.Objnr);
					oSettingsModel.setProperty("/IsISPUser", true);
				} else {
					oSettingsModel.setProperty("/IsISPUser", false);
				}
			} catch (e) {
				oSettingsModel.setProperty("/IsISPUser", false);
			}
		},

		_fetchWeekends: async function () {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const sFromDate = DateService.getInstance().format(new Date(new Date().getFullYear(), 0, 1), "yMMdd");
			const sToDate = DateService.getInstance().format(new Date(new Date().getFullYear() + 1, 0, 0), "yMMdd");
			const results = await ISPService.getTargetHours(oSettingsModel.getProperty("/PersonalNumber"), sFromDate, sToDate);
			let firstWeekend, secondWeekend;
			let startDayOfWeek;
			let bFlag = true;

			const aSortedResults = results.sort(function (a, b) {
				var dateA = DateService.getInstance().formatStringDate(a.Date);
				var dateB = DateService.getInstance().formatStringDate(b.Date);
				return dateA - dateB;
			});
			let tempSecondWeekend;
			let count = 0;

			for (let j = 0; j < aSortedResults.length; j++) {
				if (aSortedResults[j].Datetype !== "OFF") {
					if (secondWeekend && count === 2) {
						break;
					} else {
						firstWeekend = null;
						secondWeekend = null;
						bFlag = true;
					}
				}
				if (aSortedResults[j].Datetype === "OFF" && bFlag) {
					let dWeekend = DateService.getInstance().formatStringDate(aSortedResults[j].Date);
					if (secondWeekend) {
						if (DateService.getInstance().dateDiff(dWeekend, secondWeekend) === 1) {
							firstWeekend = null;
							secondWeekend = null;
							bFlag = false;
						} else {
							break;
						}
					}
					if (firstWeekend) {
						if (DateService.getInstance().dateDiff(firstWeekend, dWeekend) === 1) {
							secondWeekend = dWeekend;
							if (Date.parse(secondWeekend) < Date.parse(firstWeekend)) {
								secondWeekend = firstWeekend;
							}
						}
						if (Date.parse(secondWeekend) < Date.parse(firstWeekend)) {
							firstWeekend = secondWeekend;
						}
					} else {
						firstWeekend = dWeekend;
					}
				}
				if (secondWeekend) {
					count++;
					if (count === 1) {
						tempSecondWeekend = secondWeekend;
					} else if (count === 2 && tempSecondWeekend.getDay() === secondWeekend.getDay()) {
						continue;
					} else {
						count = 0;
					}
				}
			}

			if (secondWeekend) {
				let startDateOfWeek = new Date(secondWeekend.getFullYear(), secondWeekend.getMonth(), secondWeekend.getDate() + 1);
				startDayOfWeek = startDateOfWeek.getDay();
			} else {
				startDayOfWeek = 1;
			}

			oSettingsModel.setProperty("/WeekStartDay", startDayOfWeek);
			return startDayOfWeek;
		},

		_fetchStaffing: async function (personalNumber) {
			var dCurrentDate = new Date(); // current date
			var dFromDate = new Date(dCurrentDate.getFullYear() - 1, 0, 1);
			var sFromDate = DateService.getInstance().format(dFromDate, "yMMdd");
			var dToDate = new Date(dCurrentDate.getFullYear() + 2, 0, 0);
			var sToDate = DateService.getInstance().format(dToDate, "yMMdd");
			const data = await ISPService.getStaffing(personalNumber, sFromDate, sToDate);

			const aStaffings = [];
			const oStaffingModel = MTRModels.getStaffingModel();
			if (data) {
				for (var i = 0; i < data.data.results.length; i++) {
					var oStaffing = new Staffing(data.data.results[i]);
					aStaffings.push(oStaffing);
				}
			}

			oStaffingModel.setData(aStaffings);
		},

		_fetchSettingsLookups: async function () {
			const results = await MTRService.getSettingsLookups();

			const oSettingsModel = MTRModels.getMTRSettingsModel();

			var aTimesheetModes = results.filter(function (domain) {
				return domain.Type === "YDO_TIMESHEETPREF";
			});

			oSettingsModel.setProperty("/TimesheetModes", aTimesheetModes);

			var aDateFormats = results.filter(function (domain) {
				return domain.Type === "YDO_DATEFORMARTID";
			});

			oSettingsModel.setProperty("/DateFormats", aDateFormats);
		},

		_fetchMTRSettings: async function (user, appId) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const oSettings = oSettingsModel.getData();
			const oOREData = [];
			for (var i in user) {
				if (i && i !== "__metadata" && i !== "" && user[i] && user[i] !== "" && (typeof user[i]) === "string") {
					var obj = {
						UserId: user.UserId,
						ConstantType: i,
						ConstantValue: user[i]
					};
					oOREData.push(obj);
				}
			}
			const postData = {
				UserId: user.UserId,
				ApplicationId: appId,
				N_UserIDToConstant: oOREData
			};

			const oData = await MTRService.getUserMtrConfig(postData);

			if (oData.PilotFlag === "X") {
				throw new Error("USER_NOT_ACTIVE");
			}

			oSettings.UserGuid = oData.UserGuid;
			oSettings.FirstName = oData.Firstname;
			oSettings.LastName = oData.Lastname;
			oSettings.Email = oData.Email;
			oSettings.Status = oData.Status;
			oSettings.OpportunityURL = oData.OpportunityURL;
			oSettings.IsUnitEdit = oData.IsUnitEdit;
			oSettings.RestrictPriorYear = oData.RestrictPriorYear;
			oSettings.CutOffDate = oData.CutOffDate;
			oSettings.GraceDate = oData.GraceDate;

			let sProfileId = "1"; // by default Profile ID is 1
			if (oData.ProfileId && oData.ProfileId !== "") {
				sProfileId = oData.ProfileId;
			}
			oSettings.ProfileId = sProfileId;
			let sTimeMatrics = "H"; // by default TimeMatrics is H(Hours)
			if (oData.TimeSheetUnit && oData.TimeSheetUnit !== "") {
				sTimeMatrics = oData.TimeSheetUnit;
			}
			oSettings.setTimeMatrics(sTimeMatrics);

			// fetch Entry Master Data (Tasks, Cost Types, Locations, Categories)
			await this._getMtrMasterData(sProfileId);
			await this._fetchUserSettings(oData.UserGuid);
		},

		_getMtrMasterData: async function (sProfileId) {
			const oResponse = await MTRService.getMtrMasterData(sProfileId);

			let aMTRTasks = [];

			const aTasks = oResponse.to_Activity.results;

			const aCostTypeMap = oResponse.to_ActivityCostTypeMap.results;
			const aCostTypes = oResponse.to_CostType.results;

			const aLocationMap = oResponse.to_ActivityLocationMap.results;
			const aLocations = oResponse.to_Location.results;

			for (let i = 0; i < aTasks.length; i++) {
				const oMTRTask = {
					TaskId: aTasks[i].activity_id,
					TaskName: aTasks[i].ActivityName,
					TaskDescription: aTasks[i].ActivityDescription,
					CategoryId: aTasks[i].CategoryId.toString(),
					AddCategoryId: aTasks[i].AddCategoryId.toString(),
					IsArchive: aTasks[i].IsArchive,
					CostTypes: [],
					Locations: [],

					TaskShortName: aTasks[i].ActivityShortName,
					IspSubTaskDes: aTasks[i].IspSubTaskDes,
					IsCostCentre: aTasks[i].IsCostCentre,
					IsOpportunity: aTasks[i].IsOpportunity,
					IsManualIo: aTasks[i].IsManualIo,
					IsAccount: aTasks[i].IsAccount,
					IsPlaceholder: aTasks[i].IsPlaceholder,
					IsRemote: aTasks[i].IsRemote,
					IspTask: aTasks[i].IspTask,
					IspTaskdes: aTasks[i].IspTaskdes,
					IspSubTask: aTasks[i].IspSubTask,
					EssInMu: (aTasks[i].EssInMu && aTasks[i].EssInMu === "X") ? true : false,
					TaskLevel: aTasks[i].TaskLevel,
					TaskCompHours: aTasks[i].TaskCompHours,
					TaskCompDays: aTasks[i].TaskCompDays,
					IsLearning: (aTasks[i].AddCategoryId && aTasks[i].AddCategoryId === 4) ? true : false
				};

				const aFilteredCostTypes = aCostTypeMap.filter(item => item.ActivityID === oMTRTask.TaskId);
				for (let j = 0; j < aFilteredCostTypes.length; j++) {
					const oCostType = aCostTypes.find(item => item.CostTypeID === aFilteredCostTypes[j].CostTypeID);
					oMTRTask.CostTypes.push({
						CostTypeId: oCostType.CostTypeID,
						CostTypeName: oCostType.CostTypeName
					});
				}

				const aFilteredLocations = aLocationMap.filter(item => item.ActivityID === oMTRTask.TaskId);
				for (let j = 0; j < aFilteredLocations.length; j++) {
					const oLocation = aLocations.find(item => item.LocationId === aFilteredLocations[j].LocationID && item.LocationId.toString() !==
						"2" && item.LocationId.toString() !== "3");
					if (oLocation) {
						oMTRTask.Locations.push({
							LocationId: oLocation.LocationId,
							LocationName: oLocation.LocationName
						});
					}
				}

				aMTRTasks.push(oMTRTask);
			}

			aMTRTasks = aMTRTasks.sort(function (a, b) {
				return a.TaskId - b.TaskId;
			});

			const aCategories = [];
			for (var j = 0; j < oResponse.to_Category.results.length; j++) {
				aCategories.push(new Category(oResponse.to_Category.results[j]));
			}

			const oSettingsModel = MTRModels.getMTRSettingsModel();
			oSettingsModel.setProperty("/Categories", aCategories);
			oSettingsModel.setProperty("/MTRTasks", aMTRTasks);
		},

		_fetchUserSettings: async function (userGuid) {
			let oData;
			if (userGuid && userGuid !== "") {
				oData = await MTRService.getUserSettings(userGuid);
			}
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const oSettings = oSettingsModel.getData();
			let aOpportunities = [];
			let bIsFirstTimeUser = true;

			let oLSUserData = {
				UpdatedTime: (oData && oData.UpdatedTime) ? oData.UpdatedTime : "",
				IsArchive: (oData && oData.IsArchive) ? oData.IsArchive : "",
				DateFormat: (oData && oData.DateFormat) ? oData.DateFormat : "",
				EssInMu: (oData && (oData.EssInMu === "")) ? false : true,
				Timesheet: (oData && oData.Timesheet && oData.Timesheet !== "") ? oData.Timesheet : "1",
				CustId: (oData && oData.CustId) ? oData.CustId : "",
				CreatedOn: (oData && oData.CreatedOn) ? oData.CreatedOn : "",
				CreatedTime: (oData && oData.CreatedTime) ? oData.CreatedTime : "",
				MatrixViewAccess: (oData && oData.MatrixViewAccess) ? oData.MatrixViewAccess : "",
				UpdatedOn: (oData && oData.UpdatedOn) ? oData.UpdatedOn : "",
				to_ACCOUNT: (oData && oData.to_ACCOUNT.results) ? oData.to_ACCOUNT.results : [],
				to_MANUAL: (oData && oData.to_MANUAL.results) ? oData.to_MANUAL.results : [],
				IsFirstTimeUser: true
			};

			if (oData) {
				bIsFirstTimeUser = false;
				oLSUserData.IsFirstTimeUser = false;
				const bEssInMu = oSettings.UserNotifEssInMu;
				const aMTRTasks = oSettings.MTRTasks.filter(function (task) {
					return (bEssInMu && !task.EssInMu) || !bEssInMu;
				});
				oSettings.MTRTasksByEssInMu = aMTRTasks;
				aOpportunities = oData.to_OPPORTUNITYIO.results;
			} else {
				bIsFirstTimeUser = true;
				const aDateFormats = oSettings.DateFormats;
				if (aDateFormats.length > 0) {
					oLSUserData.DateFormat = aDateFormats[0].ID;
				}
				oSettings.setFirstTimeUserSettings(true);
			}

			oSettings.setLSUserData(oLSUserData);

			// fetch User Opportunities from Harmony and LS 
			// await this._setMtrOpportunities(aOpportunities);
			this._setMtrOpportunities(aOpportunities);

			await this.initTimesheet();

		},

		_setMtrOpportunities: async function (opportunities) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const oSettings = oSettingsModel.getData();
			const aCRMOpportunities = await OpportunityUtil.getOpportunities();

			oSettings.TempOpportunities = [];
			oSettings.Opportunities = [];
			for (let i = 0; i < opportunities.length; i++) {
				let oOpportunity;
				if (opportunities[i].IsArchive) {
					oOpportunity = oSettings.TempOpportunities.find(function (item) {
						return item.OpportunityID === opportunities[i].OpportunityID;
					});
				} else {
					oOpportunity = oSettings.Opportunities.find(function (item) {
						return item.OpportunityID === opportunities[i].OpportunityID;
					});
				}
				if (oOpportunity) {
					oOpportunity.AssociatedIO = opportunities[i].AssociatedIO;
					oOpportunity.IsDefault = (opportunities[i].IsDefault === "X") ? true : false;
					oOpportunity.IsVisible = (opportunities[i].IsVisible === "X") ? true : false;
					oOpportunity.IsArchive = (opportunities[i].IsArchive === "X") ? true : false;
					oOpportunity.Indicator = "";
				} else {
					oOpportunity = new OpportunityIOSettings({
						OpportunityID: opportunities[i].OpportunityID,
						AccountID: opportunities[i].AccountID,
						IsVisible: (opportunities[i].IsVisible === "X") ? true : false,
						IsDefault: (opportunities[i].IsDefault === "X") ? true : false,
						CreatedOn: opportunities[i].CreatedOn,
						CreatedTime: opportunities[i].CreatedTime,
						UpdatedOn: opportunities[i].UpdatedOn,
						UpdatedTime: opportunities[i].UpdatedTime,
						IsArchive: (opportunities[i].IsArchive === "X") ? true : false,
						Indicator: ""
					});
					if (oOpportunity.IsArchive) {
						oSettings.TempOpportunities.push(oOpportunity);
					} else {
						oSettings.Opportunities.push(oOpportunity);
					}
				}
			}

			for (var i = 0; i < aCRMOpportunities.length; i++) {
				let isAvailable = false;
				for (let j = 0; j < oSettings.Opportunities.length; j++) {
					if (aCRMOpportunities[i].OpportunityId === oSettings.Opportunities[j].OpportunityID) {
						oSettings.Opportunities[j].AccountID = aCRMOpportunities[i].AccountId;
						oSettings.Opportunities[j].AccountName = aCRMOpportunities[i].AccountName;
						oSettings.Opportunities[j].OpportunityName = aCRMOpportunities[i].OpportunityName;
						oSettings.Opportunities[j].AvailableIOs = [];
						oSettings.Opportunities[j].StatusKey = aCRMOpportunities[i].Status;
						oSettings.Opportunities[j].Status = aCRMOpportunities[i].StatusDesc;
						isAvailable = true;
						break;
					}
				}
				if (!isAvailable) {
					let oOpportunity = oSettings.TempOpportunities.find(function (item) {
						return item.OpportunityID === aCRMOpportunities[i].OpportunityId;
					});
					let bIsArchive = false;
					if (oOpportunity) {
						oOpportunity.AccountID = aCRMOpportunities[i].AccountId;
						oOpportunity.AccountName = aCRMOpportunities[i].AccountName;
						oOpportunity.OpportunityName = aCRMOpportunities[i].OpportunityName;
						oOpportunity.AvailableIOs = [];
						oOpportunity.StatusKey = aCRMOpportunities[i].Status;
						oOpportunity.Status = aCRMOpportunities[i].StatusDesc;
						bIsArchive = true;
					}
					oSettings.Opportunities.push(new OpportunityIOSettings({
						OpportunityID: aCRMOpportunities[i].OpportunityId,
						OpportunityName: aCRMOpportunities[i].OpportunityName,
						AccountID: aCRMOpportunities[i].AccountId,
						AccountName: aCRMOpportunities[i].AccountName,
						IOSetting: "",
						AssociatedIO: "",
						AvailableIOs: [],
						StaffedDays: "",
						RecordedDays: "",
						StatusKey: aCRMOpportunities[i].Status,
						Status: aCRMOpportunities[i].StatusDesc,
						IsVisible: true,
						IsDefault: false,
						IsArchive: bIsArchive,
						Indicator: (bIsArchive) ? "" : "C"
					}));

				}
			}

			this.getAssociatedIOs().then(() => {
				this.updateEntriesStaffing()
			});

			//set Opportunities flag in Accounts
			this._setOppAccounts();
		},

		_setOppAccounts: function () {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			var oData = oSettingsModel.getProperty("/Opportunities");
			var accounts = oSettingsModel.getProperty("/to_ACCOUNT");
			accounts = accounts.filter(function (item) {
				return item.Indicator !== "O";
			});
			for (var i = 0; i < oData.length; i++) {
				var sameDateEntries = accounts.filter(function (item) {
					return item.AccountId === oData[i].AccountID;
				});
				if (sameDateEntries.length > 0 || oData[i].IsArchive || oData[i].IsVisible === false || oData[i].AccountID === "") {
					continue;

				} else {
					accounts.push(new MTRAccount({
						AccountId: oData[i].AccountID,
						AccountDesc: oData[i].AccountName,
						Indicator: "O"
					}));
				}
			}
			oSettingsModel.setProperty("/to_ACCOUNT", accounts);
			return;
		},

		initTimesheet: async function () {
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const dCurrentDate = new Date();
			const dFromDate = new Date(dCurrentDate.getFullYear(), dCurrentDate.getMonth() - 1, 1); // first date of last year
			const sFromDate = DateService.getInstance().format(dFromDate, "yMMdd");
			oDayWeekTimesheetModel.setProperty("/FromDate", sFromDate);
			const dToDate = new Date(dCurrentDate.getFullYear(), dCurrentDate.getMonth() + 2, 0); // last date of next to next year
			const sToDate = DateService.getInstance().format(dToDate, "yMMdd");
			oDayWeekTimesheetModel.setProperty("/ToDate", sToDate);
			this._fetchTargetHours(sFromDate, sToDate);
			await this.getEntries(sFromDate, sToDate);
		},

		getEntries: async function (fromDate, toDate, startDate) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			try {
				await this.fetchSavedEntries(),
					await this.getEntriesFromISP({
						FromDate: fromDate,
						ToDate: toDate,
						StartDate: startDate
					});

				const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
				if (aEntries.length === 0) {
					oDayWeekTimesheetModel.setProperty("/NewEntry", new Entry());
				} else {
					this.updateMelodyActivities();
				}
				this.updateEntries();
				const sSelectedDate = oDayWeekTimesheetModel.getProperty("/SelectedDate");
				const formattedSelectedDate = DateService.getInstance().format(new Date(sSelectedDate), "yMMdd");
				this.filterEntries(formattedSelectedDate);
				const aInQueueEntries = aEntries.filter(function (item) {
					return item.StatusId === "2" || item.StatusId === 2;
				});
				if (aInQueueEntries.length > 0) {
					this.submitEntries(aInQueueEntries);
				}
				oDayWeekTimesheetModel.refresh(true);
				oSettingsModel.setProperty("/Loading", false);

				/*const promises1 = [
					this.fetchSavedEntries(),
					this.getEntriesFromISP({
						FromDate: fromDate,
						ToDate: toDate,
						StartDate: startDate
					})
				];*/

				/*Promise.all(promises1).then(() => {
					const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
					const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
					if (aEntries.length === 0) {
						oDayWeekTimesheetModel.setProperty("/NewEntry", new Entry());
					} else {
						this.updateMelodyActivities();
					}
					this.updateEntries();
					const sSelectedDate = oDayWeekTimesheetModel.getProperty("/SelectedDate");
					const formattedSelectedDate = DateService.getInstance().format(new Date(sSelectedDate), "yMMdd");
					this.filterEntries(formattedSelectedDate);
					// const promises = [this.getAssociatedIOs()];

					const aInQueueEntries = aEntries.filter(function (item) {
						return item.StatusId === "2" || item.StatusId === 2;
					});
					if (aInQueueEntries.length > 0) {
						// promises.push(this.submitEntries(aInQueueEntries));
						this.submitEntries(aInQueueEntries);
					}
					oDayWeekTimesheetModel.refresh(true);
					oSettingsModel.setProperty("/Loading", false);
				});*/

				/*await this.getEntriesFromISP({
					FromDate: fromDate,
					ToDate: toDate,
					StartDate: startDate
				});*/
			} catch (e) {
				oSettingsModel.setProperty("/Loading", false);
				throw e;
			}
		},

		updateMelodyActivities: async function () {
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");

			for (let i = 0; i < aEntries.length; i++) {
				if (aEntries[i].ActvtId) {
					aEntries[i].setMelodyActivity(aEntries[i].ActvtId);
				} else {
					aEntries[i].setCostTypeName();
				}
			}
			oDayWeekTimesheetModel.refresh(true);
		},

		fetchSavedEntries: async function () {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const oSettings = oSettingsModel.getData();
			const sUserGuid = oSettingsModel.getProperty("/UserGuid");

			const aSavedEntries = await MTRService.getEntries(sUserGuid);

			const aMTRTasks = oSettings.MTRTasks;

			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();

			const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");

			for (var i = 0; i < aSavedEntries.length; i++) {
				var oEntry = aEntries.find(function (item) {
					return item.MtrUid.toUpperCase() === aSavedEntries[i].MtrUid.toUpperCase();
				});
				if (!oEntry) {
					if (aSavedEntries[i].ActivityId && aSavedEntries[i].ActivityId !== "") {
						aSavedEntries[i].TaskId = aSavedEntries[i].ActivityId;
					}
					oEntry = new Entry(aSavedEntries[i]);

					var oMTRTask = aMTRTasks.find(function (task) {
						return task.TaskId.toString() === oEntry.TaskId.toString();
					});

					if (oMTRTask) {
						if (oMTRTask.CategoryId === "1" || oMTRTask.CategoryId === "2") {
							oEntry.SelectedCategory = oMTRTask.CategoryId;
							oEntry.SelectedCategoryTemp = oMTRTask.CategoryId;
						}
						oEntry.TaskName = oMTRTask.TaskName;
						oEntry.Locations = oMTRTask.Locations;
						oEntry.CostTypes = oMTRTask.CostTypes;
						oEntry.IsModified = false;
						oEntry.WorkDurationValueState = sap.ui.core.ValueState.Information;
						oEntry.DataFrom = "L";

						if (aSavedEntries[i].MsgText && aSavedEntries[i].MsgText !== "") {
							oEntry.getValidationError(aSavedEntries[i].MsgText);
						}

						aEntries.push(oEntry);
					}
				}

				/*if (oEntry) {
					if (oEntry.ActvtId) {
						oEntry.setMelodyActivity(oEntry.ActvtId);
					} else {
						oEntry.setCostTypeName();
					}
				}*/
			}
		},

		getEntriesFromISP: async function (params) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			var sUserId = oSettingsModel.getProperty("/PersonalNumber");
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
			const aArtesEntries = oDayWeekTimesheetModel.getProperty("/ArtesEntries");
			const aEntriesToDelete = [];
			const that = this;

			const aReportEntries = [];
			let dStartDate;
			if (params.StartDate) {
				dStartDate = params.StartDate;
			} else {
				dStartDate = new Date();
			}

			const aOpportunities = oSettingsModel.getProperty("/Opportunities");
			let aResults = [];
			try {
				aResults = await ISPService.getEntriesFromISP(sUserId, params.FromDate, params.ToDate);
			} catch (e) {
				aResults = [];
			}

			const aTasks = oSettingsModel.getProperty("/MTRTasks");
			if (aResults.length > 0) {
				for (var i = 0; i < aResults.length; i++) {
					var fWorkDuration = parseFloat(aResults[i].Catsquantity);
					var oEntry = null;
					if (!isNaN(fWorkDuration) && fWorkDuration !== 0) {
						var oTask = aTasks.find(function (item) {
							return item.IspTask.toUpperCase() === aResults[i].Tasktype.toUpperCase() &&
								item.IspSubTask.toUpperCase() === aResults[i].Zzsubtype.toUpperCase();
						});
						if (oTask) {
							var networkText = aResults[i].Zz_npktxt;
							if (networkText && networkText !== "") {
								var cLocation = networkText.charAt(0).toUpperCase();
								var sMtrUid = networkText.substring(1, networkText.indexOf("~"));

								var aValues = aResults[i].Zz_npktxt.split("~");
								var sCostTypeId = "",
									sCostTypeValue = "";
								sCostTypeId = aValues[1].charAt(0);
								sCostTypeValue = aValues[1].substring(1);

								oEntry = aEntries.find(function (item) {
									return item.MtrUid.toUpperCase() === sMtrUid.toUpperCase();
								});
								/*
								oEntry = aEntries.find(function (item) {
									return item.TaskCounter === aResults[i].Taskcounter || item.Counter === aResults[i].Counter;
								});
								var oMtrEntry = aEntries.find(function (item) {
									return item.MtrUid.toUpperCase() === sMtrUid.toUpperCase();
								});
*/
								var oEntryData = {
									TaskCounter: aResults[i].Taskcounter,
									Counter: aResults[i].Counter,
									TaskId: oTask ? oTask.TaskId : "",
									LocationId: this.setISPLocation(cLocation),
									CostTypeId: sCostTypeId,
									CostTypeValue: sCostTypeValue,
									RecordDate: aResults[i].Workdate,
									WorkDuration: aResults[i].Catsquantity,
									Note: aResults[i].Ltxa1,
									Unit: this.setISPUnit(aResults[i].Unit),
									StatusId: this.setISPStatus(aResults[i].Status),
									DataFrom: "I",
									SelectedCategory: oTask ? oTask.CategoryId : "1",
									Locations: oTask ? oTask.Locations : [],
									CostTypes: oTask ? oTask.CostTypes : []
								};
								if (aResults[i].Zzcontpers && aResults[i].Zzcontpers !== "") {
									var oCostType = this.getDataByCostCenter(aResults[i]);
									oEntryData.ActvtId = (oCostType.ActvtId && oCostType.ActvtId !== "0") ? oCostType.ActvtId.toString() : "";
									oEntryData.CustomerFacing = oCostType.CustomerFacing;
								}

								//	if (!oEntry || !oMtrEntry) {
								oEntryData.MtrUid = sMtrUid;
								//	}

								/*if (!oEntry && !oMtrEntry) {
									oEntryData.MtrUid = sMtrUid;
								} else if (!oEntry && oMtrEntry) {
									oEntry = oMtrEntry;
								}*/
								if (params.Report) {
									aReportEntries.push(new Entry(oEntryData));
								} else {

									if (oEntry) {
										if ((oEntry.StatusId !== "4" || oEntry.StatusId !== 4) && oEntry.DataFrom !== "I") {
											aEntriesToDelete.push(oEntry);
										}
										oEntry.setData(oEntryData);
									} else {
										oEntry = new Entry(oEntryData);
										//instance.setDataExportFields(mParameters.oController, oEntry);
										aEntries.push(oEntry);
									}
								}

								/*	if (oMtrEntry && (oMtrEntry.StatusId === "2" || oMtrEntry.StatusId === 2)) {
										const index = aEntriesToDelete.findIndex(item => item.MtrUid.toUpperCase() === oMtrEntry.MtrUid.toUpperCase());
										if (index === -1) {
											aEntriesToDelete.push(oMtrEntry);
										}
									}

									if (oEntry) {
										if ((oEntry.StatusId !== "4" || oEntry.StatusId !== 4) && oEntry.DataFrom !== "I") {
											const index = aEntriesToDelete.findIndex(item => item.MtrUid.toUpperCase() === oEntry.MtrUid.toUpperCase());
											if (index === -1) {
												aEntriesToDelete.push(oEntry);
											}
										}
										oEntry.setData(oEntryData);
									} else {
										oEntry = new Entry(oEntryData);
										aEntries.push(oEntry);
									}*/
							}
							else {
								oEntry = aEntries.find(function (item) {
									return item.TaskCounter === aResults[i].Taskcounter || item.Counter === aResults[i].Counter;

								});

								if (!oEntry) {
									var oTimeEntry = null;
									if (oTimeEntry && !oTimeEntry.IsConvertedToEntry) {
										oTimeEntry.IsConvertedToEntry = true;
										oTimeEntry.Unit = that.setISPUnit(aResults[i].Unit),
											oEntry = new Entry(oTimeEntry);
										oEntry.TaskCounter = aResults[i].Taskcounter;
										oEntry.Counter = aResults[i].Counter;

										oEntry.SelectedCategory = oTask ? oTask.CategoryId : "1";
										oEntry.ActivityLocations = oTask ? oTask.ActivityLocations : [];
										oEntry.ActivityCostTypes = oTask ? oTask.ActivityCostTypes : [];
										oEntry.Note = aResults[i].Ltxa1;
										oEntry.DataFrom = "I";
										oEntry.StatusId = "4";
										if (aResults[i].Tasklevel === "K1") {
											oEntry.TaskId = oTask.TaskId;
										}
										else {
											oEntry.TaskId = "10";
											oEntry.ActAsstId = "503";
										}
										oEntry.isVisibleInMatrix = true;
										oEntry.isNonMatEntry = true;
										aEntries.push(oEntry);
										if (oEntry.CostTypeId === "1" && oEntry.CostTypeValue !== "") {
											var oOpp = aOpportunities.find(function (item) {
												return item.OpportunityID === oEntry.CostTypeValue;
											});
											if (!oOpp) {
												aOpportunities.push(new OpportunityIOSettings({
													OpportunityID: oEntry.CostTypeValue,
													Indicator: "C",
													IsVisible: true,
													IsDefault: false,
													IsArchive: false
												}));
											}
										}

									} else if (!oTimeEntry) {
										//	oEntry = new Entry();
										var oEntryData = {
										};
										if (aResults[i].Zzcontpers && aResults[i].Zzcontpers !== "") {
											var oCostType = that.getDataByCostCenter(aResults[i]);
											oEntryData.CostTypeId = (oCostType && oCostType.CostTypeId !== "") ? oCostType.CostTypeId : (aResults[i].Raufnr && aResults[i].Raufnr !== "") ? "5" : "2";
											oEntryData.CostTypeValue = (oCostType && oCostType.CostTypeValue !== "") ? oCostType.CostTypeValue : (aResults[i].Raufnr && aResults[i].Raufnr !== "") ? aResults[i].Raufnr : aResults[i].Rkostl;
											if (oCostType.LocationId > 0) {
												oEntryData.LocationId = oCostType.LocationId.toString();
											}
											oEntryData.CustomerFacing = oCostType.CustomerFacing;
											oEntryData.ActvtId = (oCostType && oCostType.ActvtId && oCostType.ActvtId !== "0") ? oCostType.ActvtId.toString() : "";

										} else {
											oEntryData.CostTypeId = (aResults[i].Raufnr && aResults[i].Raufnr !== "") ? "5" : "2";
											oEntryData.CostTypeDisplay = (aResults[i].Raufnr && aResults[i].Raufnr !== "") ? "Internal Order" : "Cost Center";
											oEntryData.CostTypeValue = (aResults[i].Raufnr && aResults[i].Raufnr !== "") ? aResults[i].Raufnr : aResults[i].Rkostl;
										}
										oEntryData.ActivityId = (oCostType && oCostType.ActvtId && oCostType.ActvtId !== "0") ? oCostType.ActvtId.toString() : "";
										if ((!oEntryData.LocationId || oEntryData.LocationId !== "") && aResults[i].Zz_location && aResults[i].Zz_location !== "") {
											oEntryData.LocationId = that.setISPLocation(aResults[i].Zz_location);
										}
										//	oEntryData.setRecordDate(aResults[i].Workdate);
										oEntryData.IsLegacy = true;
										oEntryData.DataFrom = "I";
										oEntryData.StatusId = "4";
										oEntryData.TaskCounter = aResults[i].Taskcounter;
										oEntryData.Counter = aResults[i].Counter;
										oEntryData.Note = aResults[i].Ltxa1;
										oEntryData.Unit = that.setISPUnit(aResults[i].Unit),
											oEntryData.SelectedCategory = oTask ? oTask.CategoryId : "1";
										oEntryData.ActivityLocations = oTask ? oTask.ActivityLocations : [];
										oEntryData.ActivityCostTypes = oTask ? oTask.ActivityCostTypes : [];
										// oEntryData.setDuration(fWorkDuration);
										if (aResults[i].Tasktype === "VACA") {
											oEntryData.isVisibleInMatrix = false;
										}
										else {
											oEntryData.isVisibleInMatrix = true;
										}

										oEntryData.isNonMatEntry = true;
										if (aResults[i].Tasklevel === "K1") {
											oEntryData.TaskId = oTask.TaskId;
										}
										else {
											oEntryData.TaskId = "10";
											oEntryData.ActAsstId = "503";
										}
										var oFormatEntry = new Entry(oEntryData)
										oFormatEntry.setRecordDate(aResults[i].Workdate);
										oFormatEntry.setDuration(fWorkDuration);
										aEntries.push(oFormatEntry);
									}
								}
							}
						}
					}
				}
				/*if (oEntry) {
					if (oEntry.ActvtId) {
						await oEntry.setMelodyActivity(oEntry.ActvtId);
					} else {
						await oEntry.setCostTypeName();
					}
				}*/
			}

			if (!params.Report) {
				if (aEntriesToDelete.length > 0) {
					await this.deleteSubmittedEntriesFromLS(aEntriesToDelete);
				}

				/*if (!params.NotGenerateTimesheet) {
					this.generateTimesheet(dStartDate);
				}*/

				/*if (aEntries.length === 0) {
					oDayWeekTimesheetModel.setProperty("/NewEntry", new Entry());
				}
				this.updateEntries();
				const sSelectedDate = oDayWeekTimesheetModel.getProperty("/SelectedDate");
				const formattedSelectedDate = DateService.getInstance().format(new Date(sSelectedDate), "yMMdd");
				this.filterEntries(formattedSelectedDate);

				const aInQueueEntries = aEntries.filter(function (item) {
					return item.StatusId === "2" || item.StatusId === 2;
				});

				if (aInQueueEntries.length > 0) {
					await this.submitEntries(aInQueueEntries);
				}

				if (aEntriesToDelete.length > 0) {
					await this.deleteSubmittedEntriesFromLS(aEntriesToDelete);
				}

				this.updateEntriesStaffing();
				if (!params.NotGenerateTimesheet) {
					this.generateTimesheet(dStartDate);
				}*/
			}

			//	const aOpportunities = oSettingsModel.getProperty("/Opportunities");
			if (aOpportunities.length > 0) {
				this.getAssociatedIOs().then(() => {
					this.updateEntriesStaffing()
				});
			}
		},

		fetchSubmittedEntries: async function (params) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const sPersonalNumber = oSettingsModel.getProperty("/PersonalNumber");

			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");

			const aEntriesToDelete = [];

			let dStartDate;
			if (params.startDate) {
				dStartDate = params.startDate;
			} else {
				dStartDate = new Date();
			}

			const aOpportunities = oSettingsModel.getProperty("/Opportunities");

			const aResults = await ISPService.getEntriesFromISP(sPersonalNumber, params.fromDate, params.toDate);

			const aTasks = oSettingsModel.getProperty("/MTRTasks");
			for (let i = 0; i < aResults.length; i++) {
				const fWorkDuration = parseFloat(aResults[i].Catsquantity);
				if (!isNaN(fWorkDuration) && fWorkDuration !== 0) {
					let oEntry = aEntries.find(function (item) {
						return item.TaskCounter === aResults[i].Taskcounter || item.Counter === aResults[i].Counter;
					});
					const oTask = aTasks.find(function (item) {
						return item.IspTask.toUpperCase() === aResults[i].Tasktype.toUpperCase() &&
							item.IspSubTask.toUpperCase() === aResults[i].Zzsubtype.toUpperCase();
					});
					if (oTask) {
						const networkText = aResults[i].Zz_npktxt;
						let sMtrUid = "",
							bIsLegacy = true;
						if (networkText && networkText !== "") {
							sMtrUid = networkText.substring(1, networkText.indexOf("~"));

							const aMtrEntry = aEntries.filter(function (item) {
								return item.MtrUid.toUpperCase() === sMtrUid.toUpperCase() && DataFrom !== "I";
							});

							if (aMtrEntry.length > 0) {
								aEntriesToDelete.push(...aMtrEntry);
							}

							bIsLegacy = false;

						}

						const oEntryData = {
							MtrUid: sMtrUid,
							TaskCounter: aResults[i].Taskcounter,
							Counter: aResults[i].Counter,
							TaskId: oTask ? oTask.TaskId : "",
							RecordDate: aResults[i].Workdate,
							WorkDuration: aResults[i].Catsquantity,
							Note: aResults[i].Ltxa1,
							Unit: this.setISPUnit(aResults[i].Unit),
							StatusId: this.setISPStatus(aResults[i].Status),
							DataFrom: "I",
							SelectedCategory: oTask ? oTask.CategoryId : "1",
							Locations: oTask ? oTask.Locations : [],
							CostTypes: oTask ? oTask.CostTypes : [],
							IsLegacy: bIsLegacy
						};

						if (aResults[i].Zzcontpers && aResults[i].Zzcontpers !== "") {
							var oCostType = this.getDataByCostCenter(aResults[i]);
							oEntryData.CostTypeId = oCostType.CostTypeId;
							oEntryData.CostTypeValue = oCostType.CostTypeValue;
							if (oCostType.LocationId > 0) {
								oEntryData.LocationId = oCostType.LocationId.toString();
							}
							oEntryData.ActvtId = (oCostType.ActvtId && oCostType.ActvtId !== "0") ? oCostType.ActvtId.toString() : "";

						} else {
							oEntryData.CostTypeId = (aResults[i].Raufnr && aResults[i].Raufnr !== "") ? "5" : "2";
							oEntryData.CostTypeDisplay = (aResults[i].Raufnr && aResults[i].Raufnr !== "") ? "Internal Order" : "Cost Center";
							oEntryData.CostTypeValue = (aResults[i].Raufnr && aResults[i].Raufnr !== "") ? aResults[i].Raufnr : aResults[
								i].Rkostl;
						}

						if ((!oEntryData.LocationId || oEntryData.LocationId !== "") && aResults[i].Zz_location && aResults[i].Zz_location !== "") {
							oEntryData.LocationId = this.setISPLocation(aResults[i].Zz_location);
						}

						if (oEntry) {
							oEntry.setData(oEntryData);
						} else {
							oEntry = new Entry(oEntryData);
						}

						oEntry.setRecordDate(oEntry.RecordDate);
						oEntry.setDuration(oEntry.WorkDuration);

						aEntries.push(oEntry);
					}
				}
			}
			if (aEntriesToDelete.length > 0) {
				await this.deleteSubmittedEntriesFromLS(aEntriesToDelete);
			}
		},

		saveAllEntries: async function () {

			const oResourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const modifiedEntries = [];
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const arrDayWeekTimesheets = oDayWeekTimesheetModel.getProperty("/Entries");
			for (var j = 0; j < arrDayWeekTimesheets.length; j++) {
				if (arrDayWeekTimesheets[j].Busy) {
					continue;
				}
				if (arrDayWeekTimesheets[j].Indicator !== "" && arrDayWeekTimesheets[j].isRestricted !== true) {
					arrDayWeekTimesheets[j].Busy = true;
					var oEntry = arrDayWeekTimesheets[j].getLSRequest({
						UserGuid: oSettingsModel.getProperty("/UserGuid"),
						TaskId: arrDayWeekTimesheets[j].TaskId,
						LocationId: arrDayWeekTimesheets[j].LocationId,
						CostTypeId: arrDayWeekTimesheets[j].CostTypeId,
						ActvtId: arrDayWeekTimesheets[j].ActvtId,
						StatusId: 1,
						CostTypeValue: arrDayWeekTimesheets[j].CostTypeValue,
						ProfileId: oSettingsModel.getProperty("/ProfileId")
					});
					modifiedEntries.push(oEntry);
				}
			}
			await this._sendToLS(modifiedEntries);
			const oMessage = new Message({
				Type: sap.ui.core.MessageType.Success,
				Title: oResourceBundle.getText("savedSuccessfullyMsg"),
				Description: "",
				Subtitle: ""
			});
			oMessage.addToMessages();
		},

		deleteSavedEntries: async function (entries) {
			const oResourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
			const aResult = await this._saveEntries(entries);
			const oMessage = new Message({
				Type: sap.ui.core.MessageType.Success,
				Title: oResourceBundle.getText("deleteEntriesSuccessMsg"),
				Description: "",
				Subtitle: ""
			});
			oMessage.addToMessages();
			MessageToast.show(oResourceBundle.getText("deleteEntriesSuccessMsg"));
			return aResult;
		},

		saveEntries: async function (entries) {
			const oResourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
			const aResult = await this._saveEntries(entries);
			MessageToast.show(oResourceBundle.getText("savedSuccessfullyMsg"));
			return aResult;
		},

		_saveEntries: async function (entries) {
			if (!entries || entries.length === 0) {
				return
			}

			const oSettingsModel = MTRModels.getMTRSettingsModel();

			// this.validateUserAuth();

			const modifiedEntries = [];
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const arrDayWeekTimesheets = oDayWeekTimesheetModel.getProperty("/Entries");

			for (let i = 0; i < entries.length; i++) {
				let entry = arrDayWeekTimesheets.find(item => item.MtrUid.toString() === entries[i].MtrUid);

				if (!entry && entries[i].Indicator === "I") {
					arrDayWeekTimesheets.push(entries[i]);
				}
				entry = entries[i];

				if (entries[i].Indicator === "D") {
					entries[i].WorkDuration = "";
				}

				if (entry && entry.Indicator !== "" && entry.isRestricted !== true) {
					entry.Busy = true;
					var oEntry = entry.getLSRequest({
						UserGuid: oSettingsModel.getProperty("/UserGuid"),
						TaskId: entry.TaskId,
						LocationId: entry.LocationId,
						CostTypeId: entry.CostTypeId,
						ActvtId: entry.ActvtId,
						StatusId: 1,
						CostTypeValue: entry.CostTypeValue,
						ProfileId: oSettingsModel.getProperty("/ProfileId")
					});
					modifiedEntries.push(oEntry);
				}
			}

			const aResult = await this._sendToLS(modifiedEntries);
			/*const oMessage = new Message({
				Type: sap.ui.core.MessageType.Success,
				Title: oResourceBundle.getText("savedSuccessfullyMsg"),
				Description: "",
				Subtitle: ""
			});
			oMessage.addToMessages();
			MessageToast.show(oResourceBundle.getText("savedSuccessfullyMsg"));*/
			return aResult;
		},

		validateUserAuth: function () {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const sActRecording = oSettingsModel.getProperty("/ActivityRecording");
			const oResourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
			if (sActRecording !== "1") {
				// MessageBox.error(oResourceBundle.getText("userNotActive"));
				throw new Error(oResourceBundle.getText("userNotActive"));
				// return;
			}
		},

		/*getEntriesFromLS: async function (sFromDate, sToDate, dStartDate, bNotGenerateTimesheet) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const oSettings = oSettingsModel.getData();
			const sUserGuid = oSettingsModel.getProperty("/UserGuid");

			const aSavedEntries = await MTRService.getEntries(sUserGuid);

			const aMTRTasks = oSettings.MTRTasks;

			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();

			const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
			const aArtesEntries = oDayWeekTimesheetModel.getProperty("/ArtesEntries");

			if (aSavedEntries.length > 0) {
				for (var i = 0; i < aSavedEntries.length; i++) {
					if (!aSavedEntries[i].RecordID || aSavedEntries[i].RecordID === "") {
						var oEntry = aEntries.find(function (item) {
							return item.MtrUid.toUpperCase() === aSavedEntries[i].MtrUid.toUpperCase();
						});
						if (!oEntry) {

							if (aSavedEntries[i].ActivityId && aSavedEntries[i].ActivityId !== "") {
								aSavedEntries[i].TaskId = aSavedEntries[i].ActivityId;
							}

							oEntry = new Entry(aSavedEntries[i]);
							var oMTRTask = aMTRTasks.find(function (task) {
								return task.TaskId.toString() === oEntry.TaskId.toString();
							});

							if (oMTRTask) {
								if (oMTRTask.CategoryId === "1") {
									oEntry.SelectedCategory = oMTRTask.CategoryId;
									oEntry.SelectedCategoryTemp = oMTRTask.CategoryId;
								} else if (oMTRTask.CategoryId === "2") {
									oEntry.SelectedCategory = oMTRTask.CategoryId;
									oEntry.SelectedCategoryTemp = oMTRTask.CategoryId;
								}

								this.setDataExportFields(oEntry);

								oEntry.TaskIdTemp = oEntry.TaskId;
								oEntry.TaskName = oMTRTask.TaskName;
								oEntry.Locations = oMTRTask.Locations;
								oEntry.CostTypes = oMTRTask.CostTypes;
								oEntry.LocationsTemp = oMTRTask.Locations;
								oEntry.CostTypesTemp = oMTRTask.CostTypes;
								oEntry.IsLocation = (oMTRTask.IsRemote === "X") ? true : false;
								oEntry.IsLocationTemp = (oMTRTask.IsRemote === "X") ? true : false;
								oEntry.LocationIndex = (oEntry && oEntry.LocationId) ? (parseInt(oEntry.LocationId, 10) - 1) : -1;
								oEntry.LocationIndexTemp = (oEntry && oEntry.LocationId) ? (parseInt(oEntry.LocationId, 10) - 1) : -1;
								oEntry.CostTypeIndex = (oEntry && oEntry.CostTypeId) ? (parseInt(oEntry.CostTypeId, 10) - 1) : -1;
								oEntry.CostTypeIndexTemp = (oEntry && oEntry.CostTypeId) ? (parseInt(oEntry.CostTypeId, 10) - 1) : -1;
								oEntry.IsAddNoteVisible = (oEntry && oEntry.Note !== "") ? true : false;
								oEntry.IsAddNoteVisibleTemp = (oEntry && oEntry.Note !== "") ? true : false;
								oEntry.IsModified = false;
								oEntry.WorkDurationValueState = sap.ui.core.ValueState.Information;
								oEntry.DataFrom = "L";

								if (aSavedEntries[i].MsgText && aSavedEntries[i].MsgText !== "") {
									oEntry.getValidationError(aSavedEntries[i].MsgText);
								}
								aEntries.push(oEntry);
							}
						}
					} else {
						var oArtesEntry = aArtesEntries.find(function (item) {
							return item.RecordID === aSavedEntries[i].RecordID;
						});
						if (oArtesEntry) {
							continue;
						}
						oArtesEntry = new ArtesEntry(aSavedEntries[i]);
						if (!oArtesEntry.IsInvalidEntry) {
							aArtesEntries.push(oArtesEntry);
						}
					}
				}
			} else {
				oDayWeekTimesheetModel.setProperty("/NewEntry", new Entry());
			}
			try {
				await this.getEntriesFromISP({
					FromDate: sFromDate,
					ToDate: sToDate,
					StartDate: dStartDate,
					NotGenerateTimesheet: bNotGenerateTimesheet
				});
			} catch (e) {
				console.log(e);
				if (e.Message === "ISP - METADATA_NOT_LOADED") {
					const aOpportunities = oSettingsModel.getProperty("/Opportunities");
					if (aOpportunities.length > 0) {
						await this.getAssociatedIOs();
					}
					await this.updateEntriesStaffing();
					if (!bNotGenerateTimesheet) {
						await this.generateTimesheet(dStartDate);
					}
				}
			}

		},*/

		_findStatus: function (oEntry, sStatusId) {

			if (oEntry.StatusId === "3") {
				sStatusId = "failed"; // Failed
			} else if (oEntry.StatusId === "1" && sStatusId !== "failed") {
				sStatusId = "save"; // Save
			} else if (oEntry.StatusId === "2" && sStatusId !== "save" && sStatusId !== "failed") {
				sStatusId = "inqueue"; // In queue
			} else if (oEntry.StatusId === "4" && sStatusId !== "save" && sStatusId !== "inqueue" && sStatusId !== "failed") {
				sStatusId = "submitted"; // Submitted
			}
			return sStatusId;

		},

		updateEntriesStaffing: function () {
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
			for (var i = 0; i < aEntries.length; i++) {
				aEntries[i].getIOStaffing();
			}
			oDayWeekTimesheetModel.refresh(true);
		},

		_fetchTargetHours: async function (fromDate, toDate) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			var sUserId = oSettingsModel.getProperty("/PersonalNumber");

			const aResults = await ISPService.getTargetHours(sUserId, fromDate, toDate);

			const oTargetModel = MTRModels.getTargetModel();

			const aHolidays = oTargetModel.getProperty("/Holidays");
			const aVacations = oTargetModel.getProperty("/Vacations");
			let firstWeekend, secondWeekend;
			let startDayOfWeek;
			let bStartDayAlreadyExist = false;
			const sTimeMatrics = oSettingsModel.getProperty("/TimeMatrics");
			const aTargetHours = oTargetModel.getProperty("/TargetHours");
			if (aTargetHours.length > 0) {
				bStartDayAlreadyExist = true;
			}
			for (var j = 0; j < aResults.length; j++) {
				var oTargetHour = aTargetHours.find(function (item) {
					return item.Date === aResults[j].Date;
				});
				if (!oTargetHour) {
					aTargetHours.push(aResults[j]);
					if (aResults[j].Datetype === "PUBL") {
						aHolidays.push(aResults[j].Date);
					} else if (aResults[j].Datetype === "ABSE") {
						aVacations.push(aResults[j].Date);
					} else if (aResults[j].Datetype === "WORK") {
						var fTargetHours = parseFloat(aResults[j].Targethours);
						if (sTimeMatrics === "H" && fTargetHours > 1) {
							oSettingsModel.setProperty("/StdWorkDuration", fTargetHours.toString());
						} else {
							oSettingsModel.setProperty("/StdWorkDuration", "1");
						}
					}
				}
			}
			oTargetModel.setProperty("/Holidays", aHolidays);
			oTargetModel.setProperty("/Vacations", aVacations);
			oTargetModel.setProperty("/TargetHours", aTargetHours);
			oTargetModel.refresh(true);
		},

		setISPLocation: function (cLocation) {
			var sLocationId = "";
			switch (cLocation) {
				case "O":
					sLocationId = "1";
					break;
				case "V":
					sLocationId = "4";
					break;
				case "R":
					sLocationId = "4";
					break;
			}

			return sLocationId;
		},

		setISPUnit: function (sUnit) {
			var sLSUnit = "";
			switch (sUnit) {
				case "H":
					sLSUnit = "H";
					break;
				default:
					sLSUnit = "D";
					break;
			}

			return sLSUnit;
		},

		setISPStatus: function (sStatus) {
			var sStatusId = "";
			switch (sStatus) {
				case "30":
					sStatusId = "4";
					break;
				case "40":
					sStatusId = "3";
					break;
			}

			return sStatusId;
		},

		getDataByCostCenter: function (oData) {
			var obj = {};
			var sContactPerson = oData.Zzcontpers;
			var Raccobj = oData.Raccobj;

			const oSettingsModel = MTRModels.getMTRSettingsModel();

			var aFields = sContactPerson.split("/");
			if (aFields.length >= 3) {
				var iAccountId = parseInt(aFields[0], 10);
				var iOpportunityId = parseInt(aFields[1], 10);
				var iLocationId = parseInt(aFields[2], 10);
				var iActvtId = (aFields[3]) ? parseInt(aFields[3], 10) : "";
				// var bCustomerFacing = (aFields[4]) ? JSON.parse(aFields[4].toLowerCase()) : true;
				var bCustomerFacing = (aFields[4] === "F" || aFields[4] === "false") ? false : true;
				if (iOpportunityId > 0) {
					obj.CostTypeId = "1";
					obj.CostTypeValue = iOpportunityId.toString();
				} else if (iAccountId > 0) {
					obj.CostTypeId = "4";
					obj.CostTypeValue = iAccountId.toString();
				} else if (Raccobj.toUpperCase() === "ORDER") {
					obj.CostTypeId = "3";
					obj.CostTypeValue = oData.Raccobj_genrec;
				} else {
					obj.CostTypeId = "2";
					obj.CostTypeValue = oSettingsModel.getProperty("/CostCenter");
				}
				obj.LocationId = iLocationId;
				obj.ActvtId = iActvtId;
				obj.CustomerFacing = bCustomerFacing;

			} else {
				obj.CostTypeId = "2";
				obj.CostTypeValue = oSettingsModel.getProperty("/CostCenter");
				obj.LocationId = 0;
			}
			return obj;
		},

		updateEntries: function () {
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			var aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
			for (var i = 0; i < aEntries.length; i++) {
				aEntries[i].setRecordDate(aEntries[i].RecordDate);
				aEntries[i].setDuration(aEntries[i].WorkDuration);
			}
			oDayWeekTimesheetModel.refresh(true);
		},

		filterEntries: function (sDate) { // YYYYMMDD
			if (!sDate) {
				return;
			}
			var tempEntries = [];
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			var aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			var bEssInMu = oSettingsModel.getProperty("/EssInMu");
			var aTasks = oSettingsModel.getProperty("/MTRTasks");
			var bIsAvailable = false;
			for (var i = 0; i < aEntries.length; i++) {
				if (aEntries[i].RecordDate === sDate) {
					var oTask = aTasks.find(function (item) {
						return aEntries[i].TaskId && item.TaskId.toString() === aEntries[i].TaskId.toString();
					});
					if (oTask && ((bEssInMu && !oTask.EssInMu) || !bEssInMu) && oTask.IsArchive !== "X") {
						var oEntry = new Entry();
						oEntry.setData(aEntries[i]);
						oEntry.getIOStaffing();
						tempEntries.push(oEntry);
						bIsAvailable = true;
					}
				}
			}

			var oBlankEntry = new Entry({
				RecordDate: sDate
			});
			oDayWeekTimesheetModel.setProperty("/NewEntry", oBlankEntry);
			this.updateExpectedDailyBar(sDate);
			oDayWeekTimesheetModel.refresh(true);
		},

		updateExpectedDailyBar: async function (sDate) {
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
			if (sDate) {
				let expected;
				const oFilterByRecordDate = aEntries.filter(function (t) {
					return t.RecordDate === sDate;
				});

				let saved = 0;
				let submitted = 0;
				for (let j = 0; j < oFilterByRecordDate.length; j++) {
					let duration = parseFloat(oFilterByRecordDate[j].WorkDuration);
					if (isNaN(duration)) {
						duration = 0;
					}
					if (oFilterByRecordDate[j].DataFrom === "L") {
						saved += duration;
					}
					if (oFilterByRecordDate[j].DataFrom === "I") {
						submitted += duration;
					}
				}
				// if (oFilterByRecordDate.length > 0) {
				// 	expected = oFilterByRecordDate[0].Expected;
				// } else {
				const oTargetModel = MTRModels.getTargetModel();
				const oSettingsModel = MTRModels.getMTRSettingsModel();
				const timeMatrics = oSettingsModel.getProperty("/TimeMatrics");
				const weekStartDay = oSettingsModel.getProperty("/WeekStartDay");
				const isWeekend = this.getIsWeekends(weekStartDay, sDate);
				const targetHours = oTargetModel.getProperty("/TargetHours");
				const oTargetHour = targetHours.find(function (item) {
					return item.Date === sDate;
				});
				if (oTargetHour) {
					expected = parseFloat(oTargetHour.Targethours).toFixed(1);
					const fTargetHours = parseFloat(oTargetHour.Targethours);
					const fBookedHours = parseFloat(oTargetHour.Bookedhours);
					if (!isNaN(fTargetHours) && fTargetHours !== 0) {
						if (timeMatrics === "H") {
							expected = fTargetHours.toString();
						} else {
							expected = "1";
						}
					} else {
						expected = "0";
					}
				} else {
					if (timeMatrics === "H" && !isWeekend) {
						expected = "8";
					} else if (timeMatrics !== "H" && !isWeekend) {
						expected = "1";
					} else {
						expected = "0";
					}
				}

				if (oTargetHour && oTargetHour.Datetype === "ABSE") {
					const fTHours = parseFloat(oTargetHour.Targethours);
					const fBHours = parseFloat(oTargetHour.Bookedhours);
					if (timeMatrics === "H") {
						if (fTHours === 0) {
							submitted = submitted + 8;
						} else {
							submitted = submitted + fBHours;
						}
					} else {
						if (fTHours === 0) {
							submitted = submitted + 1;
						} else {
							submitted = submitted + fBHours;
						}
					}
				}

				if (oTargetHour && oTargetHour.Datetype === "PUBL") {
					const fTarHours = parseFloat(oTargetHour.Targethours);
					const fBooHours = parseFloat(oTargetHour.Bookedhours);
					if (timeMatrics === "H") {
						if (fTarHours === 0) {
							submitted = submitted + 0;
						} else {
							submitted = submitted + fBooHours;
						}
					} else {
						if (fTarHours === 0) {
							submitted = submitted + 0;
						} else {
							submitted = submitted + fBooHours;
						}
					}
				}

				oDayWeekTimesheetModel.setProperty("/Expected", expected);
				oDayWeekTimesheetModel.setProperty("/Saved", saved);
				oDayWeekTimesheetModel.setProperty("/Submitted", submitted);
				oDayWeekTimesheetModel.refresh(true);
			}
		},

		getIsWeekends: function (iStartDayfOfWeek, sRecordDate) {
			var firstWeekend = 5 + iStartDayfOfWeek;
			if (firstWeekend > 6) {
				firstWeekend = firstWeekend - 7;
			}
			var secondWeekend = 6 + iStartDayfOfWeek;
			if (secondWeekend > 6) {
				secondWeekend = secondWeekend - 7;
			}
			var dRecordDate = DateService.getInstance().formatStringDate(sRecordDate);
			var iRecordDay = dRecordDate.getDay();
			if (iRecordDay === firstWeekend || iRecordDay === secondWeekend) {
				return true;
			} else {
				return false;
			}
		},

		updateTimesheets: async function (dDate, bNotGenerateTimesheet) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			let iWeekStartDay = oSettingsModel.getProperty("/WeekStartDay"); //0 is for Sunday, 1 is for Monday etc.
			let dStartDate = DateService.getInstance().getStartDateOfWeek(dDate, iWeekStartDay);

			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			let sFromDate = oDayWeekTimesheetModel.getProperty("/FromDate");
			let sToDate = oDayWeekTimesheetModel.getProperty("/ToDate");

			let dFromDate = DateService.getInstance().formatStringDate(sFromDate);
			let dToDate = DateService.getInstance().formatStringDate(sToDate);
			let dNextMonthStartDate = new Date(dStartDate.getFullYear(), dStartDate.getMonth() + 2, 0);
			let sNewFromDate, dNewFromDate, sNewToDate, dNewToDate;
			if (dStartDate < dFromDate) {
				dNewFromDate = new Date(dStartDate.getFullYear(), dStartDate.getMonth() - 2, 1);
				sNewFromDate = DateService.getInstance().format(dNewFromDate, "yMMdd");
				dNewToDate = new Date(dFromDate.getFullYear(), dFromDate.getMonth(), dFromDate.getDate() - 1);
				sNewToDate = DateService.getInstance().format(dNewToDate, "yMMdd");
				oDayWeekTimesheetModel.setProperty("/FromDate", sNewFromDate);
				this._fetchTargetHours(sNewFromDate, sNewToDate);
			} else if (dNextMonthStartDate > dToDate) {
				dNewFromDate = new Date(dToDate.getFullYear(), dToDate.getMonth(), dToDate.getDate() + 1);
				sNewFromDate = DateService.getInstance().format(dNewFromDate, "yMMdd");
				dNewToDate = new Date(dStartDate.getFullYear(), dStartDate.getMonth() + 3, 0);
				sNewToDate = DateService.getInstance().format(dNewToDate, "yMMdd");
				oDayWeekTimesheetModel.setProperty("/ToDate", sNewToDate);
				this._fetchTargetHours(sNewFromDate, sNewToDate);
			}
			if (sNewFromDate && sNewToDate) {
				// await this.getEntriesFromLS(sNewFromDate, sNewToDate, dStartDate, bNotGenerateTimesheet);
				await this.getEntries(sNewFromDate, sNewToDate, dStartDate);

			}
			return bNotGenerateTimesheet;
		},

		setDataExportFields: function (oEntry) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const sDateFormat = oSettingsModel.getProperty("/DateFormat");
			var aTasks = oSettingsModel.getProperty("/MTRTasks");
			var oTask = aTasks.find(function (task) {
				return task.TaskId === parseInt(oEntry.TaskId, 10);
			});
			var location;
			var costType;
			if (oTask) {
				if (oTask.Locations.length > 0) {
					location = oTask.Locations.find(function (item) {
						return item.LocationId === oEntry.LocationId;
					});
				}

				if (oTask.CostTypes.length > 0) {
					costType = oTask.CostTypes.find(function (item) {
						return item.CostTypeId === parseInt(oEntry.CostTypeId, 10);
					});
				}
				oEntry.TaskName = oTask.TaskName;
			}
			var oDateFormat = oSettingsModel.getProperty("/DateFormats").find(function (d) {
				return d.ID === sDateFormat;
			});
			oEntry.LocationName = (location) ? location.LocationName : "NA";
			oEntry.CostTypeName = (costType) ? costType.CostTypeName : "NA";
			oEntry.FormattedRecordDate = (oEntry && oDateFormat) ? DateService.getInstance().formatStringDate(oEntry.RecordDate,
				oDateFormat.Value) : oEntry.RecordDate;
		},

		updateTimesheetByEntries: function (onlyFilledEntries) {
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");

			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const iWeekStartDay = oSettingsModel.getProperty("/WeekStartDay"); //0 is for Sunday, 1 is for Monday etc.

			const oWeekTimesheetsModel = MTRModels.getWeekTimesheetModel();
			const aTimesheets = oWeekTimesheetsModel.getProperty("/TimeEntries");
			let startDate;
			if (aTimesheets.length > 0) {
				startDate = aTimesheets[0].StartDate;
			} else {
				let dStartDate = DateService.getInstance().getStartDateOfWeek(new Date(), iWeekStartDay);
				startDate = DateService.getInstance().format(dStartDate, "yMMdd");
			}

			for (let i = 0; i < aEntries.length; i++) {
				const dDate = DateService.getInstance().formatStringDate(aEntries[i].RecordDate);
				const dStartDateOfWeek = DateService.getInstance().getStartDateOfWeek(dDate, iWeekStartDay);
				const sStartDateOfWeek = DateService.getInstance().format(dStartDateOfWeek, "yMMdd");
				const workDuration = parseFloat(aEntries[i].WorkDuration);
				this.setDataExportFields(aEntries[i]);
				if (!isNaN(workDuration)) {
					aEntries[i].WorkDuration = workDuration.toFixed(1);
				}
				if (aTimesheets.length > 0 && aTimesheets[0].StartDate === sStartDateOfWeek) {
					const dateNumber = DateService.getInstance().dateDiff(dStartDateOfWeek, dDate) + 1;
					let lastSimilarTimesheet = null;
					let oAvailableTimesheet = null;

					for (let j = 0; j < aTimesheets.length; j++) {
						if (aTimesheets[j].TaskId === aEntries[i].TaskId) {
							if (aTimesheets[j].checkFilledEntries().length === 0) {
								oAvailableTimesheet = aTimesheets[j];
								break;
							} else if (
								aTimesheets[j].LocationId === aEntries[i].LocationId &&
								aTimesheets[j].CostTypeId === aEntries[i].CostTypeId &&
								aTimesheets[j].CostTypeValue === aEntries[i].CostTypeValue &&
								aTimesheets[j].ActvtId === aEntries[i].ActvtId &&
								aTimesheets[j].Entries["Date" + dateNumber].WorkDuration === "" &&
								aTimesheets[j].IsLegacy === aEntries[i].IsLegacy && aTimesheets[j].IsLegacy === false) {
								oAvailableTimesheet = aTimesheets[j];
								break;
							} else if (
								aTimesheets[j].LocationId === aEntries[i].LocationId &&
								aTimesheets[j].CostTypeId === aEntries[i].CostTypeId &&
								aTimesheets[j].ActvtId === aEntries[i].ActvtId &&
								aTimesheets[j].CostTypeValue === aEntries[i].CostTypeValue &&
								aTimesheets[j].Entries["Date" + dateNumber].WorkDuration === "" &&
								aTimesheets[j].IsLegacy === aEntries[i].IsLegacy && aTimesheets[j].IsLegacy === true) {
								oAvailableTimesheet = aTimesheets[j];
								break;
							} else {
								lastSimilarTimesheet = aTimesheets[j];
							}
						}
					}

					if (oAvailableTimesheet) {
						oAvailableTimesheet.TaskId = aEntries[i].TaskId;
						oAvailableTimesheet.LocationId = aEntries[i].LocationId;
						oAvailableTimesheet.LocationName = aEntries[i].LocationName;
						oAvailableTimesheet.CostTypeId = aEntries[i].CostTypeId;
						oAvailableTimesheet.CostTypeValue = aEntries[i].CostTypeValue;
						oAvailableTimesheet.ActvtId = aEntries[i].ActvtId;
						oAvailableTimesheet.CostTypeDisplay = aEntries[i].CostTypeDisplay;
						oAvailableTimesheet.CostTypeValueTemp = aEntries[i].CostTypeValue;
						oAvailableTimesheet.PreviousLocationId = aEntries[i].LocationId;
						oAvailableTimesheet.PreviousCostTypeId = aEntries[i].CostTypeId;
						oAvailableTimesheet.PreviousCostTypeValue = aEntries[i].CostTypeValue;
						oAvailableTimesheet.Entries["Date" + dateNumber] = aEntries[i];
						if (aEntries[i].IsLegacy) {
							oAvailableTimesheet.IsLegacy = true;
						}
					} else if (lastSimilarTimesheet) {
						var index = aTimesheets.findIndex(function (item) {
							return item.GUID === lastSimilarTimesheet.GUID;
						});
						oAvailableTimesheet = new Timesheet({
							TaskId: lastSimilarTimesheet.TaskId,
							TaskName: lastSimilarTimesheet.TaskName,
							ActvtId: aEntries[i].ActvtId,
							LocationId: aEntries[i].LocationId,
							LocationName: aEntries[i].LocationName,
							CostTypeId: aEntries[i].CostTypeId,
							CostTypeValue: aEntries[i].CostTypeValue,
							CostTypeValueTemp: aEntries[i].CostTypeValue,
							StartDate: lastSimilarTimesheet.StartDate,
							WeekNumber: lastSimilarTimesheet.WeekNumber,
							ExpectedDuration: lastSimilarTimesheet.ExpectedDuration,
							IsCostCentre: lastSimilarTimesheet.IsCostCentre,
							IsOpportunity: lastSimilarTimesheet.IsOpportunity,
							IsManualIo: lastSimilarTimesheet.IsManualIo,
							IsAccount: lastSimilarTimesheet.IsAccount,
							IsPlaceholder: lastSimilarTimesheet.IsPlaceholder,
							IsRemote: lastSimilarTimesheet.IsRemote,
							CategoryId: lastSimilarTimesheet.CategoryId,
							PreviousLocationId: aEntries[i].LocationId,
							PreviousCostTypeId: aEntries[i].CostTypeId,
							PreviousCostTypeValue: aEntries[i].CostTypeValue,
							Locations: lastSimilarTimesheet.Locations,
							CostTypes: lastSimilarTimesheet.CostTypes
						});
						if (aEntries[i].IsLegacy) {
							oAvailableTimesheet.IsLegacy = true;
						}
						oAvailableTimesheet.CostTypeDisplay = aEntries[i].CostTypeDisplay;
						oAvailableTimesheet.Entries["Date" + dateNumber] = aEntries[i];
						if (index !== -1) {
							aTimesheets.splice(index + 1, 0, oAvailableTimesheet);
						}
					}
				}
				if (aEntries[i].IOStaffing === null) {
					aEntries[i].getIOStaffing();
				}
			}

			for (var k = 0; k < aTimesheets.length; k++) {
				aTimesheets[k].getIOStaffing();
			}
			var filledTimesheets = [];
			var sSettingsTimesheet = oSettingsModel.getProperty("/Timesheet");
			if (sSettingsTimesheet && sSettingsTimesheet.toString() === "1") {

				for (let j = 0; j < aTimesheets.length; j++) {
					if (aTimesheets[j].checkFilledEntries().length !== 0) {
						var oTimesheet = new Timesheet(aTimesheets[j], false, true);
						filledTimesheets.push(oTimesheet);
					}
				}
				if (filledTimesheets.length === 0) {
					oWeekTimesheetsModel.setProperty("/NewEntry", this.getBlankTimesheet(startDate));
				} else {
					//oWeekTimesheetsModel.setProperty("/NewEntry", null);
					oWeekTimesheetsModel.getData().NewEntry = null;
				}
				oWeekTimesheetsModel.setProperty("/TempTimesheets", filledTimesheets);
			} else {
				oWeekTimesheetsModel.setProperty("/TempTimesheets", []);
			}
			this.updateExpectedBar();
			oDayWeekTimesheetModel.refresh(true);
			//oWeekTimesheetsModel.refresh(true);
		},

		getBlankTimesheet: function (sDate) {
			var dDate = DateService.getInstance().formatStringDate(sDate);
			var iWeekNumber = DateService.getInstance().getWeek(dDate);
			return new Timesheet({
				TaskId: "",
				TaskName: "",
				LocationId: "",
				CostTypeId: "",
				CostTypeValue: "",
				CostTypeValueTemp: "",
				StartDate: sDate,
				WeekNumber: iWeekNumber,
				ExpectedDuration: "",
				CategoryId: "1",
				Locations: [],
				CostTypes: []
			});
		},

		generateTimesheet: async function (dDate, onlyFilledEntries) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();

			let iWeekStartDay = oSettingsModel.getProperty("/WeekStartDay"); //0 is for Sunday, 1 is for Monday etc.
			let dStartDate = DateService.getInstance().getStartDateOfWeek(dDate, iWeekStartDay);
			let iWeekNumber = DateService.getInstance().getWeek(dStartDate);
			let sStartDateString = DateService.getInstance().format(dStartDate, "yMMdd");

			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();

			await this.updateTimesheets(dDate);

			const aTimesheets = [];
			const tasks = oSettingsModel.getProperty("/MTRTasks");
			tasks.sort(function (a, b) {
				var taskA = a.TaskName.toLowerCase(),
					taskB = b.TaskName.toLowerCase();
				if (taskA < taskB)
					return -1;
				if (taskA > taskB)
					return 1;
				return 0;
			});
			const aOpportunities = oSettingsModel.getProperty("/Opportunities");
			const oDefaultOpportunity = aOpportunities.find(function (item) {
				return item.IsDefault;
			});
			const bEssInMu = oSettingsModel.getProperty("/EssInMu");
			for (let j = 0; j < tasks.length; j++) {
				if (((bEssInMu && !tasks[j].EssInMu) || !bEssInMu) && tasks[j].IsArchive !== "X") {
					const oTimesheet = new Timesheet({
						TaskId: tasks[j].TaskId,
						TaskName: tasks[j].TaskName,
						LocationId: tasks[j].LocationId,
						CostTypeId: (oDefaultOpportunity) ? "1" : "",
						CostTypeValue: (oDefaultOpportunity) ? oDefaultOpportunity.OpportunityID : "",
						CostTypeValueTemp: (oDefaultOpportunity) ? oDefaultOpportunity.OpportunityID : "",
						StartDate: sStartDateString,
						WeekNumber: iWeekNumber,
						IsCostCentre: tasks[j].IsCostCentre,
						IsOpportunity: tasks[j].IsOpportunity,
						IsManualIo: tasks[j].IsManualIo,
						IsAccount: tasks[j].IsAccount,
						IsPlaceholder: tasks[j].IsPlaceholder,
						IsRemote: tasks[j].IsRemote,
						CategoryId: tasks[j].CategoryId,
						Locations: tasks[j].Locations,
						CostTypes: tasks[j].CostTypes
					});
					if (oTimesheet.CostTypes.length === 1 && (oTimesheet.CostTypes[0].CostTypeId === "2" || oTimesheet.CostTypes[
						0].CostTypeId === 2)) {
						oTimesheet.CostTypeId = "2";
						oTimesheet.CostTypeValue = oSettingsModel.getProperty("/CostCenter");
					}
					aTimesheets.push(oTimesheet);
				}
			}
			const oWeekTimesheetsModel = MTRModels.getWeekTimesheetModel();
			oWeekTimesheetsModel.setProperty("/TimeEntries", aTimesheets);
			oWeekTimesheetsModel.setProperty("/StartDate", sStartDateString);
			var stdWorkDuration = oSettingsModel.getProperty("/StdWorkDuration");
			var expected = parseFloat(stdWorkDuration) * 5;
			oWeekTimesheetsModel.setProperty("/Expected", expected);
			oWeekTimesheetsModel.refresh(true);
			oDayWeekTimesheetModel.refresh(true);
			this.updateTimesheetByEntries(onlyFilledEntries);

			return dStartDate;
		},

		deleteSubmittedEntriesFromLS: async function (aEntries) {
			const aLSEntriesToDelete = [];
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			for (let i = 0; i < aEntries.length; i++) {
				const oLSEntry = aEntries[i].getLSRequest({
					UserGuid: oSettingsModel.getProperty("/UserGuid"),
					TaskId: aEntries[i].TaskId,
					LocationId: aEntries[i].LocationId,
					CostTypeId: aEntries[i].CostTypeId,
					StatusId: 1,
					Indicator: "D",
					CostTypeValue: aEntries[i].CostTypeValue,
					ProfileId: oSettingsModel.getProperty("/ProfileId")
				});
				aLSEntriesToDelete.push(oLSEntry);
			}
			if (aLSEntriesToDelete.length > 0) {
				await this._sendToLS(aLSEntriesToDelete);
			}
		},

		submitEntries: async function (aEntries, successMsg) {
			return await this._sendToIS(aEntries, successMsg, true);
		},

		deleteSubmittedEntries: async function (aEntries, successMsg) {
			return await this._sendToIS(aEntries, successMsg, false);
		},

		_sendToIS: async function (aEntries, successMsg, isSubmit) {
			// var oDayWeekCalendar = oController.getOwnerComponent().dayWeekCalendar;
			const oSettingsModel = MTRModels.getMTRSettingsModel();

			this.validateUserAuth();

			// var oLookupModel = oController.getOwnerComponent().getModel("Lookup");
			const aEntriesSendToLS = [];
			const aEntriesToSubmit = [];

			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const arrDayWeekTimesheets = oDayWeekTimesheetModel.getProperty("/Entries");

			const oMessageModel = MTRModels.getMessagesModel();
			oMessageModel.setData([]);
			for (let j = 0; j < aEntries.length; j++) {
				let entry = arrDayWeekTimesheets.find(item => item.MtrUid.toString() === aEntries[j].MtrUid);

				if (!entry && aEntries[j].Indicator === "I") {
					arrDayWeekTimesheets.push(aEntries[j]);
				}

				/*if (aEntries[j].Indicator === "D") {
					aEntries[j].WorkDuration = "";
				}*/

				if (aEntries[j].Busy && aEntries[j].Indicator !== "D") {
					continue;
				}
				if ((aEntries[j].DataFrom !== "I" && aEntries[j].isRestricted !== true) || (aEntries[j].DataFrom === "I" && aEntries[j].Indicator !==
					"")) {
					const oTask = oSettingsModel.getProperty("/MTRTasks").find(function (item) {
						return item.TaskId.toString() === aEntries[j].TaskId.toString();
					});
					let indicator = "";
					if (aEntries[j].DataFrom !== "I") {
						indicator = "I";
					} else {
						switch (aEntries[j].Indicator) {
							case ("C" || "U"):
								indicator = "I";
								break;
							case "D":
								indicator = "D";
								break;
						}
					}
					const aOpportunities = oSettingsModel.getProperty("/Opportunities");
					let oOpportunity;
					if (aEntries[j].CostTypeId === "1" || aEntries[j].CostTypeId === 1) {
						oOpportunity = aOpportunities.find(function (item) {
							return item.OpportunityID === aEntries[j].CostTypeValue;
						});
					}
					var oEntry = null;
					if (oTask) {
						aEntries[j].Busy = true;
						if (aEntries[j].CostTypeId !== "5") {
							oEntry = aEntries[j].getISRequest({
								UserId: oSettingsModel.getProperty("/UserId"),
								PersonalNumber: oSettingsModel.getProperty("/PersonalNumber"),
								Indicator: indicator,
								CostCenter: oSettingsModel.getProperty("/CostCenter"),
								StdWorkDuration: oSettingsModel.getProperty("/StdWorkDuration"),
								IspTask: oTask.IspTask,
								IspTaskdes: oTask.IspTaskdes,
								IspSubTask: oTask.IspSubTask,
								TaskLevel: oTask.TaskLevel,
								IsSubmit: false,
								InternalOrder: (oOpportunity && (aEntries[j].CostTypeId === "1" || aEntries[j].CostTypeId === 1)) ? oOpportunity.AssociatedIO : "",
								TaskComponent: (oSettingsModel.getProperty("/TimeMatrics") === "H") ? oTask.TaskCompHours : oTask.TaskCompDays
							});
						}
						if (oEntry) {
							aEntriesToSubmit.push(oEntry);
						}
						if (isSubmit) {
							var oLSEntry = aEntries[j].getLSRequest({
								UserGuid: oSettingsModel.getProperty("/UserGuid"),
								TaskId: aEntries[j].TaskId,
								LocationId: aEntries[j].LocationId,
								CostTypeId: aEntries[j].CostTypeId,
								StatusId: (oEntry) ? 2 : 1,
								Indicator: "C",
								CostTypeValue: aEntries[j].CostTypeValue,
								ProfileId: oSettingsModel.getProperty("/ProfileId")
							});
							aEntriesSendToLS.push(oLSEntry);
						}

					}
				}
				/*else if (oDayWeekCalendar) {
					oDayWeekCalendar.setBusy(false);
					oController.setBusy(false);

				}*/
			}
			let aResult = [];
			if (aEntriesSendToLS.length > 0) {
				this._sendToLS(aEntriesSendToLS);
			}

			if (aEntriesToSubmit.length > 0) {
				aResult = await this._sendToISBatch(aEntriesToSubmit, isSubmit, successMsg);
			}
			return aResult;
		},

		_sendToLS: async function (entries, isBusy) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const postData = {
				UserGuid: oSettingsModel.getProperty("/UserGuid"),
				N_TimesheetDetail: entries
			};

			const oData = await MTRService.saveEntries(postData);
			const aResponse = [];
			const updatedEntries = oData.N_TimesheetDetail.results;
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
			const aTasks = oSettingsModel.getProperty("/MTRTasks");
			const oSelectedDate = new Date(oDayWeekTimesheetModel.getProperty("/SelectedDate"));
			const sSelectedDate = DateService.getInstance().format(oSelectedDate, "yMMdd");
			const deletedEntries = [];
			for (let i = 0; i < updatedEntries.length; i++) {
				const entryIndex = aEntries.findIndex(function (item) {
					return item.MtrUid.toUpperCase() === updatedEntries[i].MtrUid.toUpperCase();
				});
				let obj;
				if (entryIndex !== -1) {
					obj = {
						Date: aEntries[entryIndex].Date,
						RecordDate: aEntries[entryIndex].RecordDate,
						WorkDuration: aEntries[entryIndex].WorkDuration,
						Indicator: aEntries[entryIndex].Indicator,
						CustomerFacing: aEntries[entryIndex].CustomerFacing,
						Note: updatedEntries[i].Note || ""
					};

					if (updatedEntries[i].Indicator === "D" && aEntries[entryIndex].DataFrom !== "I") {
						deletedEntries.push(aEntries[entryIndex]);
					} else {
						var oTask = aTasks.find(function (task) {
							return task.TaskId.toString() === updatedEntries[i].ActivityId.toString();
						});
						if (oTask.CategoryId === "1") {
							aEntries[entryIndex].SelectedCategory = oTask.CategoryId;
							aEntries[entryIndex].SelectedCategoryTemp = oTask.CategoryId;
						} else if (oTask.CategoryId === "2") {
							aEntries[entryIndex].SelectedCategory = oTask.CategoryId;
							aEntries[entryIndex].SelectedCategoryTemp = oTask.CategoryId;
						}
						aEntries[entryIndex].TaskIdTemp = oTask.TaskId;
						aEntries[entryIndex].Locations = oTask.Locations;
						aEntries[entryIndex].CostTypes = oTask.CostTypes;
						aEntries[entryIndex].IsLocation = (oTask.IsRemote === "X") ? true : false;
						aEntries[entryIndex].IsLocationTemp = (oTask.IsRemote === "X") ? true : false;
						aEntries[entryIndex].LocationIndex = (updatedEntries[i] && updatedEntries[i].LocationId !== 0) ? (parseInt(updatedEntries[i].LocationId,
							10) - 1) : -1;
						aEntries[entryIndex].LocationIndexTemp = (updatedEntries[i] && updatedEntries[i].LocationId !== 0) ? (parseInt(updatedEntries[
							i].LocationId, 10) - 1) : -1;
						aEntries[entryIndex].CostTypeIndex = (updatedEntries[i] && updatedEntries[i].CostTypeId) ? (parseInt(updatedEntries[i].CostTypeId,
							10) - 1) : -1;
						aEntries[entryIndex].CostTypeIndexTemp = (updatedEntries[i] && updatedEntries[i].CostTypeId) ? (parseInt(updatedEntries[i].CostTypeId,
							10) - 1) : -1;
						aEntries[entryIndex].IsAddNoteVisible = (updatedEntries[i] && updatedEntries[i].Note !== "") ? true : false;
						aEntries[entryIndex].IsAddNoteVisibleTemp = (updatedEntries[i] && updatedEntries[i].Note !== "") ? true : false;
						aEntries[entryIndex].IsModified = false;
						aEntries[entryIndex].WorkDuration = parseFloat(updatedEntries[i].WorkDuration).toFixed(1);
						aEntries[entryIndex].PreviousTaskId = aEntries[entryIndex].TaskId;
						aEntries[entryIndex].ActvtId = (aEntries[entryIndex].ActvtId) ? (aEntries[entryIndex].ActvtId) : "";
						aEntries[entryIndex].ProjectType = (aEntries[entryIndex].ProjectType) ? (aEntries[entryIndex].ProjectType) : "MTR";
						aEntries[entryIndex].PreviousLocationId = aEntries[entryIndex].LocationId;
						aEntries[entryIndex].PreviousCostTypeId = aEntries[entryIndex].CostTypeId;
						aEntries[entryIndex].PreviousCostTypeValue = aEntries[entryIndex].CostTypeValue;
						aEntries[entryIndex].PreviousDuration = aEntries[entryIndex].WorkDuration;
						aEntries[entryIndex].PreviousNote = aEntries[entryIndex].Note;
						if (aEntries[entryIndex].DataFrom === "I") {
							aEntries[entryIndex].StatusId = "4";
						} else if (updatedEntries[i] && updatedEntries[i].StatusId !== "") {
							aEntries[entryIndex].StatusId = updatedEntries[i].StatusId.toString();
							aEntries[entryIndex].DataFrom = "L";
						} else {
							aEntries[entryIndex].StatusId = "1";
							aEntries[entryIndex].DataFrom = "L";
						}

						if (obj) {
							obj.StatusId = aEntries[entryIndex].StatusId;
							obj.DataFrom = aEntries[entryIndex].DataFrom;
							obj.MtrUid = aEntries[entryIndex].MtrUid;
							aResponse.push(obj);
						}

						aEntries[entryIndex].WorkDurationValueState = sap.ui.core.ValueState.Information;
						aEntries[entryIndex].Indicator = "";
						if (!isBusy || aEntries[entryIndex].StatusId === "1") {
							aEntries[entryIndex].Busy = false;
						}

						if (aEntries[entryIndex].ActvtId) {
							await aEntries[entryIndex].setMelodyActivity(aEntries[entryIndex].ActvtId);
						} else {
							await aEntries[entryIndex].setCostTypeName();
						}
					}
				}
			}
			for (let e in deletedEntries) {
				const iEntryIndex = aEntries.findIndex(function (item) {
					return item.MtrUid.toUpperCase() === deletedEntries[e].MtrUid.toUpperCase();
				});
				if (iEntryIndex !== -1) {
					aEntries.splice(iEntryIndex, 1);
				}
			}

			this.filterEntries(sSelectedDate);
			this.updateExpectedBar();
			this.updateExpectedDailyBar(sSelectedDate);

			return aResponse;

		},

		updateExpectedBar: function () {
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const oWeekTimesheetsModel = MTRModels.getWeekTimesheetModel();
			const arrTimesheets = oWeekTimesheetsModel.getProperty("/TimeEntries");
			const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
			let saved = 0;
			let submitted = 0;
			let expected = 0;
			if (arrTimesheets.length > 0) {
				const oFilterByStartDateOfWeek = aEntries.filter(function (t) {
					return t.StartDateOfWeek === arrTimesheets[0].StartDate;
				});

				for (let i = 0; i < oFilterByStartDateOfWeek.length; i++) {
					let duration = parseFloat(oFilterByStartDateOfWeek[i].WorkDuration);
					if (!isNaN(duration) && (oFilterByStartDateOfWeek[i].StatusId && oFilterByStartDateOfWeek[i].StatusId !== "" &&
						oFilterByStartDateOfWeek[i].StatusId !== "4" && oFilterByStartDateOfWeek[i].StatusId !== 4)) {
						saved += duration;
					}

					if (!isNaN(duration) && (oFilterByStartDateOfWeek[i].StatusId === "4" || oFilterByStartDateOfWeek[i].StatusId === 4)) {
						submitted += duration;
					}
				}
			}
			const aTimesheets = oWeekTimesheetsModel.getProperty("/TimeEntries");
			let aCountTime;
			if (aTimesheets.length > 0) {
				for (let e in aTimesheets[0].Entries) {
					let expectedDuration = parseFloat(aTimesheets[0].Entries[e].Expected);
					expected += expectedDuration;
					aCountTime = this._calculateTimeInMatrixDay(aTimesheets[0].Entries[e].RecordDate, "0");
					oWeekTimesheetsModel.setProperty("/" + e + "Total/TotalTime", aCountTime[0]);
					oWeekTimesheetsModel.setProperty("/" + e + "Total/StatusTotal", aCountTime[1]);
					aCountTime = this._calculateTimeInMatrixDay(aTimesheets[0].Entries[e].RecordDate, "1");
					oWeekTimesheetsModel.setProperty("/" + e + "Total/Utilized", aCountTime[0]);
					oWeekTimesheetsModel.setProperty("/" + e + "Total/StatusUtilized", aCountTime[1]);
					aCountTime = this._calculateTimeInMatrixDay(aTimesheets[0].Entries[e].RecordDate, "2");
					oWeekTimesheetsModel.setProperty("/" + e + "Total/NonUtilized", aCountTime[0]);
					oWeekTimesheetsModel.setProperty("/" + e + "Total/StatusNonUtilized", aCountTime[1]);
				}
			}

			oWeekTimesheetsModel.setProperty("/Expected", expected);
			oWeekTimesheetsModel.setProperty("/Saved", saved);
			oWeekTimesheetsModel.setProperty("/Submitted", submitted);
			oWeekTimesheetsModel.refresh(true);

		},

		_calculateTimeInMatrixDay: function (sDate, sCategory) {
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
			const aFilteredEntries = aEntries.filter(function (item) {
				return item.RecordDate === sDate;
			});
			let fDuration = 0;
			let sStatusId = "default";
			for (let i = 0; i < aFilteredEntries.length; i++) {
				let fWorkDuration = parseFloat(aFilteredEntries[i].WorkDuration);
				if (sCategory === "0") {
					if (!isNaN(fWorkDuration)) { //condition to check valid float Work Duration
						// calculating total duration in a day
						fDuration += fWorkDuration;
						sStatusId = this._findStatus(aFilteredEntries[i], sStatusId);
					}
				} else if (aFilteredEntries[i].SelectedCategory === "1" && sCategory === "1") {
					fWorkDuration = parseFloat(aFilteredEntries[i].WorkDuration);
					if (!isNaN(fWorkDuration)) { //condition to check valid float Work Duration
						// calculating total duration for utilized in a day
						fDuration += fWorkDuration;
						sStatusId = this._findStatus(aFilteredEntries[i], sStatusId);
					}
				} else if (aFilteredEntries[i].SelectedCategory === "2" && sCategory === "2") {
					fWorkDuration = parseFloat(aFilteredEntries[i].WorkDuration);
					if (!isNaN(fWorkDuration)) { //condition to check valid float Work Duration
						// calculating total duration for non utilized in a day
						fDuration += fWorkDuration;
						sStatusId = this._findStatus(aFilteredEntries[i], sStatusId);
					}
				}
			}
			return [fDuration.toFixed(1), sStatusId.toString()];
		},

		_sendToISBatch: async function (entriesToSubmit, isSubmit, successMsg) {
			// const aSubmittedEntries = [];
			const aEntriesToSubmit = entriesToSubmit;
			const aBatchResponses = await ISPService.submitEntries(aEntriesToSubmit);
			if (aBatchResponses && aBatchResponses.results) {
				let index = 0;
				let bTimeOut = false
				for (let i = 0; i < aBatchResponses.results.length; i++) {
					const data = aBatchResponses.results[i];
					if (data.Activity && (data.Activity.results.length > 0 || parseInt(data.Msgno, 10) === 9) && parseInt(data.Msgno, 10) !== 8) {
						aEntriesToSubmit[i].StatusId = 4;
						aEntriesToSubmit[i].Activity[0].Taskcounter = data.Activity.results[0].Taskcounter;
						aEntriesToSubmit[i].Activity[0].Counter = data.Activity.results[0].Counter;
					} else if (data.Activity && parseInt(data.Msgno, 10) === 8) {
						aEntriesToSubmit[i].StatusId = 3;
						aEntriesToSubmit[i].Msgtxt = data.Msgtxt;
					} else if (!data.Activity) {
						aEntriesToSubmit[i].StatusId = 2;
						aEntriesToSubmit[i].Msgtxt = data.Msgtxt;

						bTimeOut = true
					}

					/*if (data.Activity && data.Activity.results.length > 0 && parseInt(data.Msgno, 10) === 9) {
						aEntriesToSubmit[i].StatusId = 4;
						aEntriesToSubmit[i].Activity[0].Taskcounter = data.Activity.results[0].Taskcounter;
						aEntriesToSubmit[i].Activity[0].Counter = data.Activity.results[0].Counter;
					} else {
						aEntriesToSubmit[i].StatusId = 3;
						aEntriesToSubmit[i].Msgtxt = data.Msgtxt;
					}*/
				}
				if (bTimeOut) {
					MessageToast.show(
						"There is a Timeout from the ISP system while submitting Time. We have moved Submitted Time Entries to in queue status as of now, which will be resolved when the application reloads."
					);
				}
			}
			const aResult = await this._updateISStatus(aEntriesToSubmit, isSubmit, successMsg);
			return aResult;

		},

		_updateISStatus: async function (entries, isSubmit, successMsg) {
			const aResponse = [];
			let isValid = true;
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
			const aTempEntries = oDayWeekTimesheetModel.getProperty("/TempEntries");
			const oResourceBundle = MTRModels.getMTRResourceModel().getResourceBundle();
			const aLSEntriesToDelete = [];
			for (let i = 0; i < entries.length; i++) {
				let errMsg = "";
				var networkText = entries[i].Activity[0].Zz_npktxt;
				var sMtrUid = networkText.substring(1, networkText.indexOf("~"));
				if (sMtrUid !== "") {
					var oEntry = aEntries.find(function (item) {
						return item.MtrUid.toUpperCase() === sMtrUid.toUpperCase();
					});
					var oMessage;
					if (oEntry) {
						if (isSubmit) {
							var statusId, indicator;
							oEntry.StatusId = (entries[i].StatusId) ? entries[i].StatusId.toString() : "";
							oEntry.DataFrom = (entries[i].StatusId === 4) ? "I" : "L";
							oEntry.TaskCounter = (entries[i].Activity[0].Taskcounter) ? entries[i].Activity[0].Taskcounter : "";
							oEntry.Counter = (entries[i].Activity[0].Counter) ? entries[i].Activity[0].Counter : "";
							statusId = (entries[i].StatusId) ? entries[i].StatusId : "";
							indicator = (entries[i].StatusId === 4) ? "D" : "U";
							errMsg = (entries[i].StatusId === 3) ? oEntry.getValidationError(entries[i].Msgtxt) : "";
							/*if (entries[i].StatusId === 4) {
								oEntry.StatusId = "4";
								oEntry.DataFrom = "I";
								oEntry.TaskCounter = entries[i].Activity[0].Taskcounter;
								oEntry.Counter = entries[i].Activity[0].Counter;
								statusId = 4;
								indicator = "D";
							} else {
								oEntry.StatusId = "3";
								oEntry.DataFrom = "L";
								oEntry.TaskCounter = entries[i].Activity[0].Taskcounter;
								oEntry.Counter = entries[i].Activity[0].Counter;
								statusId = 3;
								indicator = "U";
								errMsg = oEntry.getValidationError(entries[i].Msgtxt);
							}*/
							if (errMsg && errMsg !== "") {
								isValid = false;
							}
							var oLSEntry = oEntry.getLSRequest({
								UserGuid: oSettingsModel.getProperty("/UserGuid"),
								TaskId: oEntry.TaskId,
								LocationId: oEntry.LocationId,
								CostTypeId: oEntry.CostTypeId,
								StatusId: statusId,
								Indicator: indicator,
								CostTypeValue: oEntry.CostTypeValue,
								ErrorMsg: errMsg,
								ProfileId: oSettingsModel.getProperty("/ProfileId")
							});
							aLSEntriesToDelete.push(oLSEntry);
						} else if (entries[i].Msgtxt && entries[i].Msgtxt !== "") {
							oMessage = new Message({
								Type: sap.ui.core.MessageType.Error,
								Title: (entries[i].Msgtxt) ? entries[i].Msgtxt : "",
								Description: "",
								Subtitle: ""
							});
							let AcivityId = (oEntry.hasOwnProperty("ActvtId")) ? oEntry.ActvtId : "";
							let statusId = (oEntry.hasOwnProperty("StatusId")) ? oEntry.StatusId : "";
							oMessage.addToMessages(oEntry.MtrUid, AcivityId, statusId);
							isValid = false;
						} else {
							var iEntryIndex = aEntries.findIndex(function (item) {
								return item.MtrUid.toUpperCase() === sMtrUid.toUpperCase();
							});
							if (iEntryIndex !== -1) {
								aEntries.splice(iEntryIndex, 1);
							}

							var iTempEntryIndex = aTempEntries.findIndex(function (item) {
								return item.MtrUid.toUpperCase() === sMtrUid.toUpperCase();
							});
							if (iTempEntryIndex !== -1) {
								aTempEntries.splice(iTempEntryIndex, 1);
							}
						}

						const obj = {
							Date: oEntry.Date,
							RecordDate: oEntry.RecordDate,
							WorkDuration: oEntry.WorkDuration,
							Indicator: oEntry.Indicator,
							StatusId: oEntry.StatusId,
							DataFrom: oEntry.DataFrom,
							ErrorMsg: errMsg,
							CustomerFacing: oEntry.CustomerFacing
						};
						aResponse.push(obj);

						if (oEntry.ActvtId) {
							oEntry.setMelodyActivity(oEntry.ActvtId);
						} else {
							oEntry.setCostTypeName();
						}
					}
				}
			}

			if (aLSEntriesToDelete.length > 0) {
				this._sendToLS(aLSEntriesToDelete);
			}

			if (isSubmit && isValid) {
				if (!successMsg) {
					successMsg = "submittedSuccessfullyMsg";
				}
				let sStatusId = oDayWeekTimesheetModel.getProperty("/StatusId");
				const sWorkDuration = oDayWeekTimesheetModel.getProperty("/WorkDuration");
				const dDate = oDayWeekTimesheetModel.getProperty("/EntryDate");
				const sDate = (dDate) ? DateService.getInstance().format(dDate, "MMMM dd") : "";
				const oMtrSettings = MTRModels.getMTRSettingsModel();
				const sTimeMatrics = oMtrSettings.getProperty("/TimeMatrics");
				const sTimeMatricsTxt = sTimeMatrics === "H" ? "hours" : "days";
				const sDescription = (sDate && sWorkDuration && sTimeMatricsTxt) ? sDate + " : " + parseFloat(sWorkDuration, 10) + " " +
					sTimeMatricsTxt : "";
				oMessage = new Message({
					Type: sap.ui.core.MessageType.Success,
					Title: oResourceBundle.getText(successMsg),
					Description: sDescription,
					Subtitle: ""
				});
				const sActId = oDayWeekTimesheetModel.getProperty("/ActivityId");
				// sStatusId = (sStatusId) ? sStatusId : "4";
				oMessage.addToMessages("", sActId, "4");
				MessageToast.show(oResourceBundle.getText(successMsg));
			} else if (!isSubmit && isValid) {
				oMessage = new Message({
					Type: sap.ui.core.MessageType.Success,
					Title: oResourceBundle.getText("deleteEntriesSuccessMsg"),
					Description: "",
					Subtitle: ""
				});
				oMessage.addToMessages();
				MessageToast.show(oResourceBundle.getText("deleteEntriesSuccessMsg"));
			}
			await this._fetchStaffing(oSettingsModel.getProperty("/PersonalNumber"));
			this.getAssociatedIOs();
			oDayWeekTimesheetModel.refresh(true);
			return aResponse;
		},

		setStaffingToManualIO: function () {
			/** @type {sap.ui.model.json.JSONModel} */
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			/** @type {Array.<com.melody.lib.model.ls.ManualIO>} */
			var aManualIOs = oSettingsModel.getProperty("/to_MANUAL");
			/** @type {sap.ui.model.json.JSONModel} */
			const oStaffingModel = MTRModels.getStaffingModel();
			/** @type {Array.<com.melody.lib.model.Staffing>} */
			var aStaffingRecord = oStaffingModel.getData();
			/** @type {Array.<com.melody.lib.model.Staffing>} */
			var aStaffingManualIos = aStaffingRecord.filter(function (item) {
				return !item.IsOpportunityIO;
			});
			// Adding IOs as Manual IO in {com.melody.lib.model.Settings}
			for (var i = 0; i < aStaffingManualIos.length; i++) {
				/** @type {com.melody.lib.model.ls.ManualIO} */
				var oManualIO = aManualIOs.find(function (item) {
					return item.ManualIOID === aStaffingManualIos[i].InternalOrder;
				});
				if (oManualIO) {
					oManualIO.IsArchive = "";
					oManualIO.IsVisible = true;
					oManualIO.Indicator = "U";
				} else {
					oManualIO = new ManualIO({
						ManualIOID: aStaffingManualIos[i].InternalOrder,
						ManualIODesc: aStaffingManualIos[i].Description,
						IsArchive: "",
						IsVisible: true,
						Indicator: "U"
					});
					aManualIOs.push(oManualIO);
				}
			}
			// Deleting Manual IOs from LS if it not exist
			for (var j = 0; j < aManualIOs.length; j++) {
				var isExist = false;
				for (var k = 0; k < aStaffingManualIos.length; k++) {
					if (aManualIOs[j].ManualIOID === aStaffingManualIos[k].InternalOrder) {
						isExist = true;
						break;
					}
				}
				if (!isExist) {
					aManualIOs[j].IsArchive = "D";
					aManualIOs[j].Indicator = "D";
				}
			}
		},

		onSaveSettings: async function (requestData) {

			const oData = await MTRService.saveSettings(requestData);
			const oSettingsModel = MTRModels.getMTRSettingsModel();

			const aManualIOs = oSettingsModel.getProperty("/to_MANUAL");
			const aAccounts = oSettingsModel.getProperty("/to_ACCOUNT");
			for (let i = 0; i < aManualIOs.length; i++) {
				aManualIOs[i].Indicator = "";
			}

			for (let j = 0; j < aAccounts.length; j++) {
				if (aAccounts[j].Indicator === "O") {
					continue;
				} else {
					aAccounts[j].Indicator = "";
				}
			}

			for (let k = 0; k < oData.N_UserSettingToAccount.results.length; k++) {
				if (oData.N_UserSettingToAccount.results[k].Indicator === "D") {
					var index = aAccounts.findIndex(function (item) {
						return item.AccountId.toUpperCase() === oData.N_UserSettingToAccount.results[k].AccountId.toUpperCase();
					});
					if (index !== -1) {
						aAccounts.splice(index, 1);
					}

					continue;
				} else {
					aAccounts.push(new MTRAccount({
						AccountId: oData.N_UserSettingToAccount.results[k].AccountId,
						AccountDesc: oData.N_UserSettingToAccount.results[k].AccountDesc,
						Indicator: ""
					}));
				}
			}
			// fnCallback();
			// var bEssInMu = oSettingsModel.getProperty("/EssInMu");
			var bEssInMu = oSettingsModel.getProperty("/UserNotifEssInMu");
			var aTasks = oSettingsModel.getProperty("/MTRTasks").filter(function (task) {
				return (bEssInMu && !task.EssInMu) || !bEssInMu;
			});
			oSettingsModel.setProperty("/to_ACCOUNT", aAccounts);
			oSettingsModel.setProperty("/MTRTasksByEssInMu", aTasks);
			this._setOppAccounts();
		},

		_afterGetAssociations: function () {
			const oSettingsModel = MTRModels.getMTRSettingsModel();

			const aOpportunities = oSettingsModel.getProperty("/Opportunities");
			aOpportunities.sort(function (a, b) {
				if (a.OpportunityName === "" || a.OpportunityName === null) {
					return 1;
				}
				if (b.OpportunityName === "" || b.OpportunityName === null) {
					return -1;
				}
				if (a.OpportunityID === b.OpportunityID) {
					return 0;
				}
				return a.OpportunityName < b.OpportunityName ? -1 : 1;
			});
			if (!oSettingsModel.getProperty("/IsFirstTimeUser")) {
				if (!oSettingsModel.getProperty("/IsISPDown")) {
					this.setStaffingToManualIO();
				}
				const oLSSettingsRequest = oSettingsModel.getData().getLSRequest();
				this.onSaveSettings(oLSSettingsRequest);
			}
		},

		isHarmonyMetadataLoaded: function (isMetadataLoading) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();

			if (isMetadataLoading) {
				oSettingsModel.setProperty("/HarmonyDown", false);
			} else {
				oSettingsModel.setProperty("/HarmonyDown", true);
			}
		},

		isISPMetadataLoaded: function (isMetadataLoading) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();

			if (isMetadataLoading) {
				oSettingsModel.setProperty("/IsISPDown", false);
			} else {
				oSettingsModel.setProperty("/IsISPDown", true);
			}
		},

		calculateGracePeriod: function (expectedEndDate) {
			if (expectedEndDate) {
				var isDate = Date.parse(expectedEndDate);
				var dExpEndDate = (isNaN(parseFloat(isDate))) ? new Date(expectedEndDate.match(/\d+/)[0] * 1) : expectedEndDate;
				var dCurrentDate = new Date();
				var tTimeDiff = dCurrentDate.getTime() - dExpEndDate.getTime();
				var sDaysLeft = Math.ceil(tTimeDiff / (1000 * 60 * 60 * 24));
				return sDaysLeft;
			} else {
				return "";
			}
		},

		setAllowed: function (grace, statusKey) {
			if (grace || statusKey) {
				if (grace > 90 && (statusKey === "E0002" || statusKey === "E0003" || statusKey === "E0004" || statusKey === "E0005")) {
					return false;
				} else {
					return true;
				}
			} else {
				return "";
			}
		},

		setAllowedStat: function (grace, statusKey) {
			if (grace || statusKey) {
				if (grace > 90 && statusKey === "E0002") {
					return false;
				} else {
					return true;
				}
			} else {
				return "";
			}
		},

		setIOSettings: function (sOpportunityID, sSalesOrg) {
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			var sUpdateIOArtes = oSettingsModel.getProperty("/UpdateIOArtes"); // fetching ORE parameter UpdateIOArtes
			/** @type {string} */
			var sCompanyCode = oSettingsModel.getProperty("/CompanyCode"); // fetching Company Code comming from ORE 
			/** @type {string} */
			var sIOSetting = "No"; // set default IO Setting = No
			if (sUpdateIOArtes === "1") { // condition for 'Default Yes'
				sIOSetting = "Yes";
			} else if (sUpdateIOArtes === "2") { // condition for 'Default No'
				sIOSetting = "No";
			} else if (sUpdateIOArtes === "3") { // condition for 'Autoset'
				if (this.isCloud(sOpportunityID) === "Error") {
					sIOSetting = "Error";
				} else {
					if (sCompanyCode === sSalesOrg) {
						sIOSetting = "No";
					} else {
						sIOSetting = "Yes";
					}
				}
			} else if (sUpdateIOArtes === "4") { // condition for 'Yes ex Cloud'
				if (this.isCloud(sOpportunityID) === "Yes") {
					sIOSetting = "No";
				} else if (this.isCloud(sOpportunityID) === "Error") {
					sIOSetting = "Error";
				} else { // else IO Setting is Yes
					sIOSetting = "Yes";
				}
			} else if (sUpdateIOArtes === "5") {
				if (sCompanyCode === sSalesOrg || this.isCloud(sOpportunityID) === "Yes") {
					sIOSetting = "No";
				} else if (this.isCloud(sOpportunityID) === "Error") {
					sIOSetting = "Error";
				} else { // else IO Setting is Yes
					sIOSetting = "Yes";
				}
			}
			return sIOSetting;
		},

		isCloud: function (sOpportunityID) {
			/** @type {boolean} */
			var bFlag = "No";
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			var aOpportunities = oSettingsModel.getProperty("/Opportunities");
			/** @type {com.melody.lib.model.ls.OpportunityIOSettings} */
			var oOpportunity = aOpportunities.find(function (item) {
				return item.OpportunityID === sOpportunityID;
			});
			// if Opportunity's License Revenue not exist and Cloud Revenue is more than zero,
			// then the Opportunity is On Cloud else On Prem
			if (oOpportunity && sOpportunityID && sOpportunityID !== "") {
				var fLicenseRevenue = parseFloat(oOpportunity.LicenseRevenue);
				var fCloudRevenue = parseFloat(oOpportunity.CloudRevenue);
				if ((isNaN(fLicenseRevenue) || fLicenseRevenue === 0) && !isNaN(fCloudRevenue) && fCloudRevenue > 0) {
					return "Yes";
				} else if ((isNaN(fLicenseRevenue) || fLicenseRevenue === 0) && !isNaN(fCloudRevenue) && fCloudRevenue === 0) {
					return "Error";
				}
			}
			return bFlag;
		},

		getAssociatedIOs: async function (selectedOpportunities) {
			const that = this;
			let bOppAccess = false;
			let index = 0;
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			if (oSettingsModel.getProperty("/HarmonyDown")) {
				this._afterGetAssociations();
			} else {
				const oStaffingModel = MTRModels.getStaffingModel();
				const aStaffingRecord = oStaffingModel.getData();

				const aOpportunities = oSettingsModel.getProperty("/Opportunities") || [];
				let aSelectedOpportunities = selectedOpportunities;
				let bSearchedOpportunities = true;
				if (!selectedOpportunities) {
					bSearchedOpportunities = false;
					aSelectedOpportunities = aOpportunities;
				}

				aSelectedOpportunities = aSelectedOpportunities.filter(item => !item.IsDetailAvailable);

				var aTempOpportunities = oSettingsModel.getProperty("/TempOpportunities");

				if (oSettingsModel.getProperty("/IsISPDown")) {
					this._afterGetAssociations();
					return;
				}

				const aOpportunityIds = aSelectedOpportunities.map(({
					OpportunityID
				}) => OpportunityID);

				if (aOpportunityIds && aOpportunityIds.length === 0) {
					this._afterGetAssociations();
					return;
				}

				// Ticket-INC6607183 - service call timeout issue when opportunites are in thousands
				let batchCount = 100;
				let aResponse = $.extend(true, [], aOpportunityIds);
				let totalRecords = aResponse.length;
				let totalBatches = Math.ceil(totalRecords / batchCount);
				let aPromise = [];
				for (let i = 0; i < totalBatches; i++) {
					let startIndex = i * batchCount;
					let endIndex = startIndex + batchCount;
					let batchCallRecords = aResponse.slice(startIndex, endIndex);
					const mParameters = {
						Url: "/Opportunities",
						OpportunityIds: batchCallRecords,
						Select: "SALES_ORG_TEXT,SALES_ORG_SHORT,OPPT_ID,ACCOUNT_NAME,ACCOUNT,DESCRIPTION,OWNER,OWNER_NAME," +
							"STATUS,CURR_PHASE,EXPECTED_VALUE,INTERNAL_ORDER1,INTERNAL_ORDER2,LICENSE_REVENUE,CLOUD_REVENUE,EXPECT_END,REPLACED_BY,STATUS_SINCE,PartiesInvolved",
						Expand: "PartiesInvolved"
					};
					aPromise.push(OpportunityUtil.fnGetOpportunitiesDetails(mParameters));
				}
				if (aPromise.length) {
					Promise.allSettled(aPromise).then((aResponse) => {
						aResponse = aResponse || [];
						let aTempResult = aResponse.map((odata) => {
							return odata["value"] || [];
						});
						let aOppResponseData = [].concat(...aTempResult);
						for (let i = 0; i < aOppResponseData.length; i++) {
							const oData = aOppResponseData[i];
							if (oData) {

								const oTempOpportunityIndex = aTempOpportunities.findIndex(function (item) {
									return item.OpportunityID === oData.OPPT_ID;
								});
								const oOpportunityIndex = aOpportunities.findIndex(function (item) {
									return item.OpportunityID === oData.OPPT_ID;
								});

								if (oTempOpportunityIndex !== -1 && bSearchedOpportunities) {
									aTempOpportunities.splice(oTempOpportunityIndex, 1);
									if (oOpportunityIndex === -1) {
										aOpportunities.push(new OpportunityIOSettings({
											OpportunityID: oData.OPPT_ID
										}));
									}
								}

								const internalOrders = [];

								const oOpportunity = aOpportunities[oOpportunityIndex];

								if (oOpportunityIndex !== -1) {
									aOpportunities[oOpportunityIndex].IsDetailAvailable = true;
									aOpportunities[oOpportunityIndex].LicenseRevenue = oData.LICENSE_REVENUE;
									aOpportunities[oOpportunityIndex].CloudRevenue = oData.CLOUD_REVENUE;
									aOpportunities[oOpportunityIndex].RevenueType = oData.REVENUE_TYPE;

									if (oData.ACCOUNT && oData.ACCOUNT !== "" && (!aOpportunities[oOpportunityIndex].AccountID || aOpportunities[
										oOpportunityIndex].AccountID ===
										"")) {
										aOpportunities[oOpportunityIndex].AccountID = oData.ACCOUNT;
									}
									if (oData.ACCOUNT_NAME && oData.ACCOUNT_NAME !== "" && (!aOpportunities[oOpportunityIndex].AccountName || aOpportunities[
										oOpportunityIndex].AccountName === "")) {
										aOpportunities[oOpportunityIndex].AccountName = oData.ACCOUNT_NAME;
									}
									if (oData.DESCRIPTION && oData.DESCRIPTION !== "" && (!aOpportunities[oOpportunityIndex].OpportunityName || aOpportunities[
										oOpportunityIndex].OpportunityName === "")) {
										aOpportunities[oOpportunityIndex].OpportunityName = oData.DESCRIPTION;
									}
									if (oData.OWNER_NAME && oData.OWNER_NAME !== "" && (!aOpportunities[oOpportunityIndex].OwnerName || aOpportunities[
										oOpportunityIndex].OwnerName === "")) {
										aOpportunities[oOpportunityIndex].OwnerName = oData.OWNER_NAME;
									}
									if (oData.STATUS && oData.STATUS !== "") {
										aOpportunities[oOpportunityIndex].StatusKey = oData.STATUS;
									}
									aOpportunities[oOpportunityIndex].GracePeriod = this.calculateGracePeriod(oData.EXPECT_END);
									aOpportunities[oOpportunityIndex].isAllowed = this.setAllowed(aOpportunities[oOpportunityIndex].GracePeriod, aOpportunities[
										oOpportunityIndex].StatusKey);
									aOpportunities[oOpportunityIndex].GracePeriodStat = "";
									aOpportunities[oOpportunityIndex].isAllowedStat = "";
									if (!aOpportunities[oOpportunityIndex].isAllowed) {
										aOpportunities[oOpportunityIndex].GracePeriodStat = this.calculateGracePeriod(oData.STATUS_SINCE);
										aOpportunities[oOpportunityIndex].isAllowedStat = this.setAllowedStat(oOpportunity.GracePeriodStat, oOpportunity.StatusKey);
									}
									aOpportunities[oOpportunityIndex].StatusSince = (oData && oData.STATUS_SINCE) ? oData.STATUS_SINCE : null;
									aOpportunities[oOpportunityIndex].REPLACED_BY = oData.REPLACED_BY;
									var aSalesOrg = oData.SALES_ORG_SHORT.split("-");
									aOpportunities[oOpportunityIndex].SalesOrg = (aSalesOrg && aSalesOrg.length > 1) ? aSalesOrg[1] : "";
									aOpportunities[oOpportunityIndex].IOSetting = this.setIOSettings(oData.OPPT_ID, oOpportunity.SalesOrg);
									if (oData.INTERNAL_ORDER1 && oData.INTERNAL_ORDER1 !== "") {
										var internalOrder1 = oData.INTERNAL_ORDER1.replace(/^0+/, '');
										var oStaffingRecord1 = aStaffingRecord.filter(function (item) {
											return item.InternalOrder !== "" && item.InternalOrder === internalOrder1;
										});
										var totalStaffedDays1 = 0;
										var totalRecordedDays1 = 0;
										var staffings1 = [];
										for (var j = 0; j < oStaffingRecord1.length > 0; j++) {
											oStaffingRecord1[j].IsOpportunityIO = true;
											var record1 = new Staffing();
											record1.setStaffing(oStaffingRecord1[j]);
											var staffedDays1 = parseFloat(oStaffingRecord1[j].StaffedDays);
											if (!isNaN(staffedDays1)) {
												totalStaffedDays1 += staffedDays1;
											}
											var recordedDays1 = parseFloat(oStaffingRecord1[j].RecordedDays);
											if (!isNaN(recordedDays1)) {
												totalRecordedDays1 += recordedDays1;
											}
											staffings1.push(record1);
										}
										internalOrders.push({
											InternalOrder: internalOrder1,
											StaffedDays: (totalStaffedDays1 !== 0) ? totalStaffedDays1.toString() : "",
											RecordedDays: (totalRecordedDays1 !== 0) ? totalRecordedDays1.toString() : "",
											Staffings: staffings1
										});
									}
									if (oData.INTERNAL_ORDER2 && oData.INTERNAL_ORDER2 !== "") {
										var internalOrder2 = oData.INTERNAL_ORDER2.replace(/^0+/, '');
										var oStaffingRecord2 = aStaffingRecord.filter(function (item) {
											return item.InternalOrder !== "" && item.InternalOrder === internalOrder2;
										});
										var totalStaffedDays2 = 0;
										var totalRecordedDays2 = 0;
										var staffings2 = [];
										for (var k = 0; k < oStaffingRecord2.length > 0; k++) {
											oStaffingRecord2[k].IsOpportunityIO = true;
											var record2 = new Staffing();
											record2.setStaffing(oStaffingRecord2[k]);
											var staffedDays2 = parseFloat(oStaffingRecord2[k].StaffedDays);
											if (!isNaN(staffedDays2)) {
												totalStaffedDays2 += staffedDays2;
											}
											var recordedDays2 = parseFloat(oStaffingRecord2[k].RecordedDays);
											if (!isNaN(recordedDays2)) {
												totalRecordedDays2 += recordedDays2;
											}
											staffings2.push(record2);
										}
										internalOrders.push({
											InternalOrder: internalOrder2,
											StaffedDays: (totalStaffedDays2 !== 0) ? totalStaffedDays2.toString() : "",
											RecordedDays: (totalRecordedDays2 !== 0) ? totalRecordedDays2.toString() : "",
											Staffings: staffings2
										});
									}
									if (internalOrders.length > 0) {
										aOpportunities[oOpportunityIndex].AssociatedIO = internalOrders[0].InternalOrder;
										aOpportunities[oOpportunityIndex].StaffedDays = internalOrders[0].StaffedDays;
										aOpportunities[oOpportunityIndex].RecordedDays = internalOrders[0].RecordedDays;
									}

									aOpportunities[oOpportunityIndex].InternalOrder1 = oData.INTERNAL_ORDER1;
									aOpportunities[oOpportunityIndex].InternalOrder2 = oData.INTERNAL_ORDER2;
									aOpportunities[oOpportunityIndex].ExpectedEnd = oData.EXPECT_END;
									aOpportunities[oOpportunityIndex].OpportunityTeam = oData.PartiesInvolved.results;
									aOpportunities[oOpportunityIndex].OppStatusId = oData.STATUS;

									if (oTempOpportunityIndex !== -1) {
										aTempOpportunities[oTempOpportunityIndex].setOpportunityIOData(aOpportunities[oOpportunityIndex]);
									}
								}
							}
						}
						that._afterGetAssociations();
						oSettingsModel.refresh(true);
					}).catch(function (error) {
						Log.error("This should never have happened:" + error);
					});
				}
			}
		},

		getAllActivityTaskTypes: async function () {
			const oActivityTaskTypesModel = MTRModels.getActvityTaskTypesModel();

			let aActivityTaskTypes = oActivityTaskTypesModel.getData();

			if (aActivityTaskTypes.length !== 0) {
				return aActivityTaskTypes;
			}

			aActivityTaskTypes = await MTRService.getAllActivityTaskTypes();
			if (!aActivityTaskTypes) {
				aActivityTaskTypes = [];
			}

			oActivityTaskTypesModel.setData(aActivityTaskTypes);

			return aActivityTaskTypes;
		},

		showUserNotification: function () {
			const that = this;
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			let isEntryToBeNotified = false;
			let aRemainingDays = [];
			aEntries.filter(function (entry) {
				const dCreateDate = entry.CreatedOn;
				if (dCreateDate) {
					const dDate = new Date();
					const daysDifference = (dDate - dCreateDate) / (1000 * 60 * 60 * 24);
					if (daysDifference > 60 && daysDifference < 90) {
						const remainingDays = 90 - daysDifference;
						aRemainingDays.push(parseInt(remainingDays));
						isEntryToBeNotified = true;
					}
				}
			});

			if (aRemainingDays.length) {
				oSettingsModel.setProperty("/RemainingDaysForDelete", Math.min.apply(null, aRemainingDays));
			}

			var oMtrController = {
				navToMyEntries: function (oEvent) {
					const sStatusId = oEvent.getSource().getCustomData()[0].getKey();
					this.fnRouteToMyEntries(sStatusId);
				},
				closeNotifyUserpopup: function () {
					that.notifyUserPopup.close()
				},
				fnRouteToMyEntries: function (statusId) {
					let statusValue = "";
					statusId = (statusId) ? statusId.toString() : "0";
					switch (statusId) {
						case "1":
							statusValue = "savedEntries";
							break;
						case "3":
							statusValue = "failedEntries";
							break;
						case "4":
							statusValue = "submittedEntries";
							break;
						default:
							statusValue = "savedEntries";
							break;
					}

					//check for MyEntries Page in URL
					let oHashChanger = new sap.ui.core.routing.HashChanger();
					let hashValue = (oHashChanger) ? oHashChanger.getHash() : "";
					if (hashValue && (hashValue.includes("pcactivityform-app&/MyEntries") || hashValue.includes("/MyEntries"))) {
						// DO NOTHING
					} else {
						let oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
						var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
							target: {
								semanticObject: "pcactivityform",
								action: "app&/MyEntries"
							},
							params: {
								"StatusId": statusValue
							}
						})) || "";
						oCrossAppNavigator.toExternal({
							target: {
								shellHash: hash
							}
						});
					}
				}

			};
			if (isEntryToBeNotified) {
				if (!this.notifyUserPopup) {
					Fragment.load({
						name: "com.melody.lib.fragments.UserNotification",
						controller: oMtrController
					}).then(function (oDialog) {
						const oMtrSettings = sap.ui.getCore().getModel("mtrSettings");
						oDialog.setModel(oMtrSettings, "mtrSettings");
						const oResourceModel = MTRModels.getMTRResourceModel();
						oDialog.setModel(oResourceModel, "i18n");
						that.notifyUserPopup = oDialog;
						that.notifyUserPopup.open();
					});
					oStorage.put("isUserNotified", true);
				}
			}
		},
		/**
		 * @author SIDDHARTH
		 * @function onMatrixChangeDuration
		 * @description function to check opprtunity is discontinued or not.
		 * @param {Object} oEvent
		 */
		fnIsDiscontinuedOpportunity: function (oEvent, oEntry, oppId, parentController, refDataFrm, model) {
			try {
				const that = this;
				const oSettingsModel = MTRModels.getMTRSettingsModel();
				const oSettings = oSettingsModel.getData();
				const aOpportunities = oSettings.Opportunities || [];
				const oOpportunity = aOpportunities.find(item => item.OpportunityID === oppId);
				const oResourceModel = MTRModels.getMTRResourceModel().getResourceBundle();
				let isDisontinuedOppSubmit = true;
				if (refDataFrm === "matrixActivityData" && oOpportunity.StatusKey === "E0002") {
					isDisontinuedOppSubmit = (oEntry && oEntry.IsDisontinuedOppSubmit) ? oEntry.IsDisontinuedOppSubmit : false;
				} else {
					isDisontinuedOppSubmit = (oSettings && oSettings.IsDisontinuedOppSubmit) ? oSettings.IsDisontinuedOppSubmit : false;
				}
				// if (refDataFrm === "matrixActivityData") { } else if (refDataFrm === "dayWeekActivityData") { } else if (refDataFrm === "activityFormData") { }
				if (oOpportunity && oOpportunity.StatusKey && oOpportunity.StatusKey === "E0002" && !isDisontinuedOppSubmit) {
					const bCompact = true;
					oOpportunity.discontinuedDate = "";
					if (oOpportunity.StatusSince) {
						oOpportunity.discontinuedDate = DateService.getInstance().format(oOpportunity.StatusSince, 'dd-MMM-yy');
					}
					/*if (oOpportunity.REPLACED_BY) {
						let ReplaceByOppID = parseInt(oOpportunity.REPLACED_BY);
						ReplaceByOppID = ReplaceByOppID.toString();
						const oReplaceByOpp = aOpportunities.find(item => item.OpportunityID === ReplaceByOppID);
						MessageBox.show(
							"The status of this opportunity is discontinued since (" + oOpportunity.discontinuedDate + ").\nHowever, there exists a parallel opportunity (" + ReplaceByOppID + ") for this. You can choose to book time on the parallel opportunity.\nDo you still want to continue to book time on this discontinued opportunity?", {
							styleClass: bCompact ? "sapUiSizeCompact" : "",
							icon: MessageBox.Icon.CONFIRM,
							actions: [MessageBox.Action.YES, MessageBox.Action.NO],
							dependentOn: parentController.getView(),
							onClose: async (sAction) => {
								if (sAction === sap.m.MessageBox.Action.YES) {
									parentController.fnChangeDuration(oEvent, refDataFrm);

								} else {
									await that.fnUpdateDiscontOpp(oEntry, oReplaceByOpp, refDataFrm);
									parentController.updateDiscontinuedOppWithParallelOpp(oEvent, refDataFrm, oReplaceByOpp);

								}
							}
						});

					} else {*/
					MessageBox.show(
						oResourceModel.getText("discontinuedSinceMsg1") + " (" + oOpportunity.discontinuedDate + ").\n" + oResourceModel.getText("discontinuedSinceMsg2") + "?", {
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						icon: MessageBox.Icon.CONFIRM,
						title: oResourceModel.getText("discontinuedOpportunitiesTxt"),
						actions: [MessageBox.Action.YES, MessageBox.Action.NO],
						dependentOn: parentController.getView(),
						onClose: (sAction) => {
							if (sAction === sap.m.MessageBox.Action.YES) {
								if (refDataFrm === "matrixActivityData") {
									model.setProperty(oEntry.SelectedPath + "/IsDisontinuedOppSubmit", true);
								} else if (refDataFrm === "dayWeekActivityData") {
									oSettingsModel.setProperty("/IsDisontinuedOppSubmit", true);
								} else if (refDataFrm === "activityFormData") {
									oSettingsModel.setProperty("/IsDisontinuedOppSubmit", true);
								}
								parentController.fnChangeDuration(oEvent, refDataFrm);
							} else {
								let sInfoMessage = oResourceModel.getText("noTimeEntriesSaveMsg");
								if (refDataFrm === "matrixActivityData") {
									sInfoMessage = oResourceModel.getText("noEntriesForDiscontinudOppMsg") + " (" + oppId + ").";
									const aOpportunities = oSettings.Opportunities || [];
									oEvent.getParameters().value = (oEntry && oEntry.tempEntry && oEntry.tempEntry.PreviousDuration) ? "" : "";
									parentController.fnChangeDuration(oEvent, refDataFrm);
								} else if (refDataFrm === "dayWeekActivityData") {
									const PreviousDuration = (oEntry && oEntry.PreviousDuration) ? "" : "";
									if (oEvent) {
										oEvent.getSource().setValue(PreviousDuration);
									} else {
										parentController.Model.setProperty("/Entry/WorkDuration", PreviousDuration)
									}
									parentController.fnChangeDuration(oEvent, refDataFrm);
								} else if (refDataFrm === "activityFormData") {
									const previousTime = (oEntry && oEntry.PrevReqEstimatedTime) ? "" : "";
									oEvent.getSource().setValue(previousTime);
									parentController.fnChangeDuration(oEvent, refDataFrm);
								}
								MessageToast.show(sInfoMessage);
							}
						}
					});
					// }
					return true;
				} else {
					return false;
				}
			} catch {
				console.log("Error")
			}
		},
		/**
		 * @author SIDDHARTH
		 * @function onMatrixChangeDuration
		 * @description function to update  discontinued opprtunity with paralled opp in backend.
		 * @param {Object} oEvent
		 */
		fnUpdateDiscontOpp: async function (oEntry, oReplaceByOpp, refDataFrm) {
			try {

				const oSettingsModel = MTRModels.getMTRSettingsModel();
				let aUserActivities = oSettingsModel.getData().UserActivities || [];
				if (!aUserActivities.length) {
					const aResults = await OpportunityUtil.getUserActivitiesFormOpp();
					if (aResults && aResults.data && aResults.data.results) {
						aUserActivities = aResults.data.results;
						oSettingsModel.setProperty("/UserActivities", aResults.data.results);
					}
				}
				let oActivity;
				if (refDataFrm === "matrixActivityData") {
					oActivity = aUserActivities.find(item => oEntry.OpportunityID === item.OpportunityId && item.ID === oEntry.ActvtId);
				} else if (refDataFrm === "dayWeekActivityData") {
					oActivity = aUserActivities.find(item => oEntry.OpportunityID === item.OpportunityId && item.ID === oEntry.ActvtId);
				} else if (refDataFrm === "activityFormData") {
					oActivity = aUserActivities.find(item => oEntry.OPPT_ID === item.OpportunityId && item.ID === oEntry.ActvtId);
				}

				oActivity.NewOppId = oReplaceByOpp.OpportunityID;
				const aResponseResults = await OpportunityUtil.updateDisconntiunedOpportunities(oActivity.GUID, oActivity);

				MessageBox.success("You can book time on the parallel opportunity (" + oReplaceByOpp.OpportunityID + "), look up in the opportunity look up screen.");

			} catch (error) {

				MessageBox.error("DISCONTINUTED OPP POST ERROR.");
			}
		}


	};
});