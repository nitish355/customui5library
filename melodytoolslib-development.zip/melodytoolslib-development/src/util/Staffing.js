sap.ui.define([
	"com/melody/lib/service/ISPService",
	"com/melody/lib/service/DateService",
	"com/melody/lib/model/ODataOptions",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (ISPService, DateService, ODataOptions, JSONModel, Filter, FilterOperator) {
	"use strict";
	return {
		dateServicesInstance: DateService.getInstance(),
		getStaffing: async function (sUserId) {
			var dCurrentDate = new Date(); // current date
			var dFromDate = new Date(dCurrentDate.getFullYear() - 1, 0, 1);
			var sFromDate = this.dateServicesInstance.format(dFromDate, "yMMdd");
			var dToDate = new Date(dCurrentDate.getFullYear() + 2, 0, 0);
			var sToDate = this.dateServicesInstance.format(dToDate, "yMMdd");
			var oOptions = new ODataOptions();
			const oResult = await ISPService.getISPData(sUserId, sFromDate, sToDate, oOptions, "Staffing");
			return oResult;
		}
	};
});