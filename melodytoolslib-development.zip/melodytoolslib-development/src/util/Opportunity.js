sap.ui.define([
	"com/melody/lib/service/OpportunityService",
	"com/melody/lib/classes/Opportunity",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (OpportunityService, Opportunity, JSONModel, Filter, FilterOperator) {
	"use strict";
	return {
		getStatus: async function () {
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let aOppStatus = oStorage.get("pcOppStatusMasterMap");
			if (!aOppStatus) {
				await this.getAppValueHelps();
				aOppStatus = oStorage.get("pcOppStatusMasterMap");
			}
			return aOppStatus;
		},

		getPhases: async function () {
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let aOppPhases = oStorage.get("pcOppPhaseMasterMap");
			if (!aOppPhases) {
				await this.getAppValueHelps();
				aOppPhases = oStorage.get("pcOppPhaseMasterMap");
			}
			return aOppPhases;
		},

		/*
		* Old Code
		* Commented For BackUp if in case needed
		getAppValueHelps: async function () {
				const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				const oResult = await OpportunityService.getAppValueHelps();
				const oData = oResult.data;
				const oStatusMasterDataMap = {},
					oPhaseMasterDataMap = {};

				oData.results.forEach(function (status) {
					switch (status.FIELD_NAME) {
					case "STATUS":
						oStatusMasterDataMap[status.KEY] = status;
						break;
					case "PHASE":
						oPhaseMasterDataMap[status.KEY] = status;
						break;
					default:
						break;
					}
				});
				oStorage.put("pcOppStatusMasterMap", oStatusMasterDataMap);
				oStorage.put("pcOppPhaseMasterMap", oPhaseMasterDataMap);
			},*/

		getAppValueHelps: async function () {
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			let oThisController = this;
			let sFilter = "?$filter=(ENTITY_NAME eq 'OPPORTUNITY' and (FIELD_NAME eq 'STATUS' or FIELD_NAME eq 'PHASE'))";
			let sFinalURL = "/btp/v2/appvalues/AppValueHelps";
			sFinalURL = sFinalURL + sFilter;
			$.ajax({
				url: sFinalURL,
				method: "GET",
				async: false,
				contentType: "application/json",
				success: function (oResponse) {
					// console.log(oResponse);
					var aResults = oResponse.d.results || [];
					const oStatusMasterDataMap = {},
						oPhaseMasterDataMap = {};
					aResults.forEach(function (status) {
						switch (status.FIELD_NAME) {
							case "STATUS":
								oStatusMasterDataMap[status.KEY] = status;
								break;
							case "PHASE":
								oPhaseMasterDataMap[status.KEY] = status;
								break;
							default:
								break;
						}
					});
					oStorage.put("pcOppStatusMasterMap", oStatusMasterDataMap);
					oStorage.put("pcOppPhaseMasterMap", oPhaseMasterDataMap);
				},
				error: function (oError) {
					jQuery.sap.log(oError);
				}
			});
		},

		getUserDetail: async function () {
			const oResult = await OpportunityService.getUserDetail();
			return oResult.data.results[0];
		},

		getBusinessPartner: async function (userId) {
			try {
				const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				let PartnerId = oStorage.get("PartnerId");
				if (PartnerId) {
					return PartnerId;
				}
				let sUserId = userId;
				if (!sUserId) {
					const oUser = await this.getUserDetail();
					sUserId = oUser.UserId;
				}
				const aFilters = [
					new Filter("TYPE", FilterOperator.EQ, "E")
				];
				const oResult = await OpportunityService.getBusinessPartners(sUserId, aFilters);
				const oData = oResult.data;
				PartnerId = oResult.data.results[0].PARTNER;
				oStorage.put("PartnerId", PartnerId);
				return PartnerId;
			} catch (e) {
				return "";
			}

		},

		//function to get Opportunities count
		getOpportunitiesCount: async function (aBatches) {
			const response = await OpportunityService.getOpportunityCount(aBatches);
			let count = (response && "data" in response) ? Number(response.data) : 0;
			return count;
		},

		getOpportunities: async function (mParameters) {
			const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			const aBatches = [];
			let sPartnerId = (mParameters) ? mParameters.PartnerId : null;
			let bActiveOnly = (mParameters) ? mParameters.ActiveOnly : null;
			let aMtrLibOpportunties = oStorage.get("pcMTRLibOpportunities") || [];
			let iLastYearCount = (mParameters && mParameters.LastYearCount) ? parseInt(mParameters.LastYearCount, 10) : null;

			if (aMtrLibOpportunties.length) {
				return aMtrLibOpportunties;
			}
			if (!sPartnerId) {
				sPartnerId = await this.getBusinessPartner();
			}
			if (!sPartnerId) {
				return [];
			}
			const oBusinessPartnerFilter = new Filter("SALES_TEAM_MEMBER", FilterOperator.EQ, sPartnerId);
			const aStatusFilters = [];
			if (bActiveOnly !== false) {
				aStatusFilters.push(new Filter({
					filters: [
						new Filter({
							path: "STATUS",
							operator: FilterOperator.EQ,
							value1: "E0007"
						}),
						new Filter({
							path: "STATUS",
							operator: FilterOperator.EQ,
							value1: "E0001"
						})
					],
					and: false
				}));
			}

			if (iLastYearCount) {
				let iCurrentYear = new Date().getFullYear();
				const aQuarterFilters = [];
				iCurrentYear = iCurrentYear - 1;
				for (let i = 1; i <= iLastYearCount; i++) {
					const oQuarterFilter = new Filter("QUARTER_ID", FilterOperator.EQ, iCurrentYear + "0");
					const aFilters = [
						new Filter({
							filters: [oBusinessPartnerFilter, oQuarterFilter, ...aStatusFilters],
							and: true
						})
					];
					aBatches.push({
						Filters: aFilters
					});
					iCurrentYear++;
				}
			} else {
				const aFilters = [
					new Filter({
						filters: [oBusinessPartnerFilter, ...aStatusFilters],
						and: true
					})
				];
				aBatches.push({
					Filters: aFilters,
					parameters: {}
				});
			}
			const batchCount = 20;
			let aOpptData = [];
			let promises = [];
			let startIndex = 0;
			let aBatchResponses = [];
			const totalCount = await this.getOpportunitiesCount(aBatches);
			const batches = Math.ceil(totalCount / batchCount);
			for (let i = 0; i < batches; i++) {
				let skip = 0;
				aBatches[0].parameters.$top = batchCount;
				if (i !== 0) {
					skip = startIndex + batchCount;
				}
				startIndex = skip;
				aBatches[0].parameters.$skip = skip;
				promises.push(OpportunityService.getOpportunities(aBatches));
			}

			const responses = await Promise.all(promises);
			if (!responses || !responses.length) {
				return [];
			}

			aBatchResponses = responses.map((response) => {
				return response.data.__batchResponses[0];
			});

			for (let i = 0; i < aBatchResponses.length; i++) {
				const aBatchResult = aBatchResponses[i].data.results;
				var aBatchOpportunities = aBatchResult.map(function (opp) {
					return new Opportunity({
						OpportunityId: opp.OPPT_ID,
						OpportunityName: opp.DESCRIPTION,
						AccountId: opp.ACCOUNT,
						AccountName: opp.ACCOUNT_NAME,
						Status: opp.STATUS,
						Phase: opp.CURR_PHASE
					})
				});
				//aOpptData = aOpptData.concat(aBatchResponses[i].data.results);
				aOpptData = aOpptData.concat(aBatchOpportunities);
			}
			/*
			 * Below line is commented bcz there is a conflict with property key in pcopportunity component
			 * Key Camel Case is different from which it is maintained in the application level & pcopportunity component
			 * once the pcopportunity component is deprecated we can uncomment the below line or use the new opportunity.js from util/opportunity folder
			 */
			// oStorage.put("pcOpportunities", aOpptData);
			let aTempOpptData = aOpptData.map((opp) => {
				return {
					...opp,
					model: ""
				}
			});
			oStorage.put("pcMTRLibOpportunities", aTempOpptData);
			return aOpptData
		},

		//Function to search Opportunity with AccountId/AccountDesc/OppoId/OppoDesc
		searchOpportunities: async function (Parameters) {
			let sUrl = Parameters.Url;
			const mParameters = this.fnGetServiceParameters(Parameters);
			const oResult = await OpportunityService.searchOpportunities(sUrl, mParameters);
			return oResult.data.results;
		},

		//Function to get Opportunity details
		fnGetOpportunitiesDetails: async function (Parameters) {
			const aBatches = [];
			let sUrl = Parameters.Url;
			const OpportunityIds = Parameters.OpportunityIds;
			for (let i = 0; i < OpportunityIds.length; i++) {
				const mParameters = this.fnGetServiceParameters(Parameters);
				aBatches.push({
					type: "read",
					parameters: mParameters,
					url: sUrl + "('" + OpportunityIds[i] + "')"
				});
			}
			let oResult = await OpportunityService.fnGetOpportunitiesDetails(sUrl, aBatches);
			oResult = this.fnProcessBatchResponses(oResult);
			return oResult;
		},

		//Function to form service parameters
		fnGetServiceParameters: function (Parameters) {
			let urlParameters = {};
			let sSelectQuery = (Parameters) ? Parameters.Select : "";
			sSelectQuery ? urlParameters["$select"] = sSelectQuery : "";
			let sExpandEntity = (Parameters) ? Parameters.Expand : "";
			sExpandEntity ? urlParameters["$expand"] = sExpandEntity : "";
			const aFilters = Parameters["Filters"];

			var mParameters = {};
			mParameters.urlParameters = urlParameters;
			aFilters ? aFilters.length ? mParameters.filters = aFilters : "" : "";
			return mParameters;
		},

		//Function to process batch responses
		fnProcessBatchResponses: function (oResult) {
			var oData = [];
			oResult = oResult.data.__batchResponses;
			oResult.filter(function (obj) {
				oData.push(obj.data);
			});
			return oData;
		},
		getUserActivitiesFormOpp: async function () {
			const aUserActivities = await OpportunityService.getUserRecords();
			return aUserActivities;
		},
		updateDisconntiunedOpportunities: async function (guid, postData) {
			const aResponseResults = await OpportunityService.updateDisconntiunedOpportunities(guid, postData);
			return aResponseResults;
		}
	};
});