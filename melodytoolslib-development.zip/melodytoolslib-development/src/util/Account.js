sap.ui.define([
	"com/melody/lib/service/AccountService",
	"com/melody/lib/service/OpportunityService",
	"com/melody/lib/classes/Account",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (AccountService, OpportunityService, Account, JSONModel, Filter, FilterOperator) {
	"use strict";
	return {
		getMyAccounts: async function () {
			const oResult = JSON.parse(await AccountService.getMyAccounts());
			const aData = oResult.data;
			const aAccounts = [];
			$.each(aData, function (index, item) {
				const oAccount = new Account({
					AccountId: item.account.id,
					AccountName: item.account.description,
					IsMyAccount: true
				});
				aAccounts.push(oAccount);
			});
			return aAccounts;
		},

		searchAccounts: async function (sValue) {
			const aFilters = [
				new Filter("TYPE", FilterOperator.EQ, "A")
			];

			const oResult = await OpportunityService.getBusinessPartners(sValue.toLowerCase(), aFilters);
			const aAccounts = [];
			$.each(oResult.data.results, function (index, item) {
				const oAccount = new Account({
					AccountId: item.PARTNER,
					AccountName: item.NAME
				});
				aAccounts.push(oAccount);
			});

			return aAccounts;
		},

		getAdvanceDetails: async function (accounts) {
			const aResponses = await AccountService.getAdvanceDetails(accounts);
			const aAccounts = [];
			for (let i = 0; i < aResponses.length; i++) {
				if (aResponses[i].status === "success") {
					const oResult = JSON.parse(aResponses[i].value);
					let bGlobalUltimate = false,
						sAccount, sAccountName, sIndustryCode, sIndustry, sPlanningEntityId, sPlanningEntityName, sCountry, sCity, sStreet;
					if (oResult.globalUltimate) {
						bGlobalUltimate = true;
					}

					if (oResult.address) {
						if (oResult.address.line1) {
							sStreet = oResult.address.line1;
						}

						if (oResult.address.line2) {
							if (sStreet) {
								sStreet = sStreet + ", " + oResult.address.line2;
							} else {
								sStreet = oResult.address.line2;
							}
						}

						if (oResult.address.line3) {
							sCity = oResult.address.line3;
						}
					}

					if (oResult.masterData) {
						if (oResult.masterData.account) {
							sAccount = oResult.masterData.account.id;
							sAccountName = oResult.masterData.account.description;
						}

						if (oResult.masterData.country) {
							sCountry = oResult.masterData.country.description;
						}

						if (oResult.masterData.masterCode) {
							sIndustryCode = oResult.masterData.masterCode.id;
							sIndustry = oResult.masterData.masterCode.description;
						}

						if (oResult.masterData.planningEntity) {
							sPlanningEntityId = oResult.masterData.planningEntity.id;
							sPlanningEntityName = oResult.masterData.planningEntity.description;
						}
					}

					const oAccount = new Account({
						AccountId: sAccount,
						AccountName: sAccountName,
						Industry: sIndustry,
						IndustryCode: sIndustryCode,
						PlanningEntityId: sPlanningEntityId,
						PlanningEntityName: sPlanningEntityName,
						Country: sCountry,
						City: sCity,
						Street: sStreet,
						IsPlanningEntity: (sPlanningEntityId && sAccount && sPlanningEntityId === sAccount) ? true : false,
						IsGlobalUltimate: bGlobalUltimate,
						IsAdvanceSearched: true
					});
					aAccounts.push(oAccount);
				}
			}
			return aAccounts;
		}
	};
});