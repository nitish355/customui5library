/*!
 * ${copyright}
 */
// Provides control com.melody.lib.Example.
sap.ui.define([
	"sap/ui/core/Control",
	"sap/ui/core/mvc/Controller",
	"./InitiativeSelectRenderer",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Fragment",
	"com/melody/lib/service/ActivityService",
	"com/melody/lib/service/UserService",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/resource/ResourceModel"

], function (Control, Controller, InitiativeSelectRenderer, JSONModel, Fragment, ActivityService, UserService, Filter, FilterOperator,
	ResourceModel) {
	"use strict";

	/**
	 * Constructor for a new Example control.
	 *
	 * @param {string} [sId] id for the new control, generated automatically if no id is given
	 * @param {object} [mSettings] initial settings for the new control
	 *
	 * @class
	 * Some class description goes here.
	 * @extends sap.ui.core.Control
	 *
	 * @author SAP SE
	 * @version 1.0.0
	 *
	 * @constructor
	 * @public
	 * @alias com.melody.lib.controls.Example
	 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
	 */

	var InitiativeSelectController = Controller.extend("com.melody.lib.controls.InitiativeSelect", {
		constructor: function (control) {
			this.control = control;
		},

		closeInitiativesDialog: function () {
			this.control.InitiativesDialog.close();
		},

		handleInitiativeSelect: function (oEvent) {
			const oInitiativeModel = this.control.getModel("InitiativeModel");
			const aSelectedInitiatives = oInitiativeModel.getProperty("/SelectedInitiatives");
			const oSource = oEvent.getSource();
			const isSelected = oSource.getSelected();
			let oInitiative = oSource.getBindingContext("InitiativeModel").getObject();
			if (isSelected) {
				if (aSelectedInitiatives) {
					aSelectedInitiatives.push(oInitiative);
				}

			} else {
				const itemIndex = aSelectedInitiatives.findIndex(function (item) {
					return item.InitiativeId === oInitiative.InitiativeId;
				});
				aSelectedInitiatives.splice(itemIndex, 1);

			}
			oInitiativeModel.setProperty("/SelectedInitiatives", aSelectedInitiatives);
			// this.control.setProperty("SelectedInitiatives", aSelectedInitiatives);
			oInitiativeModel.refresh(true);
		},

		handleTokenDelete: function (oEvent) {
			const aRemovedToken = oEvent.getParameter("removedTokens");
			if (aRemovedToken && aRemovedToken.length) {
				const sKey = oEvent.getParameter("removedTokens")[0].getKey();
				const oInitiativeModel = oEvent.getSource().getModel("InitiativeModel");
				const aInitiatives = oInitiativeModel.getProperty("/ActivityInitiatives");
				const aSelectedInitiatives = oInitiativeModel.getProperty("/SelectedInitiatives");
				aInitiatives.filter(function (item) {
					if (item.InitiativeId === sKey) {
						item.Selected = false;
					}
				});
				const index = aSelectedInitiatives.findIndex(function (item) {
					return item.InitiativeId === sKey;
				});
				aSelectedInitiatives.splice(index, 1);
				oInitiativeModel.setProperty("/SelectedInitiatives", aSelectedInitiatives);
				oInitiativeModel.refresh(true);
			}
		},

		handleInitiativesConfirm: function (oEvent) {
			this.control.InitiativesDialog.close();
			const oInitiativeModel = this.control.getModel("InitiativeModel");
			const aSelectedInitiatives = oInitiativeModel.getProperty("/SelectedInitiatives");
			this.control.setSelectedInitiatives(aSelectedInitiatives);
		},

		handleInitiativeSearch: function (oEvent) {
			const sValue = oEvent.getSource().getValue();
			if (sValue) {
				var aFilters = new Filter({
					filters: [
						new Filter("InitiativeName", "Contains", sValue),
						new Filter("InitiativeDescription", "Contains", sValue),
						new Filter("InitiativeCategoryName", "Contains", sValue)
					],
					and: false
				});
			}
			this.filterTable(aFilters);
		},

		handleCategoryChange: function (oEvent) {
			const sKey = oEvent.getSource().getSelectedKey();
			const aFilters = [];
			if (sKey !== "0000") {
				aFilters.push(new Filter({
					path: "InitiativeCategoryId",
					operator: FilterOperator.EQ,
					value1: sKey
				}));
			}
			this.filterTable(aFilters);
		},

		filterTable: function (aFilters) {
			const oTable = sap.ui.core.Fragment.byId(`${this.control.getId()}_Initiatives`, "InitiativesTbl");
			if (oTable) {
				oTable.getBinding("rows").filter(aFilters);
				const count = oTable.getBinding("rows").getCount();
				this.control.getModel("InitiativeModel").setProperty("/InitiativesCount", count);
			}
		}

	});

	var InitiativeSelect = Control.extend("com.melody.lib.controls.InitiativeSelect", {
		metadata: {
			library: "com.melody.lib",
			properties: {
				ActivityTypeId: {
					type: "string",
					defaultValue: ""
				},

				ActivityAsstnId: {
					type: "string",
					defaultValue: ""
				},

				SelectedInitiatives: {
					type: "object",
					defaultValue: []
				},

				ProjectType: {
					type: "string",
					defaultValue: ""
				},

				ActivityViewMode: {
					type: "string",
					defaultValue: ""
				},

				Visible: {
					type: "boolean",
					defaultValue: false
				},

				cacheInitiative: {
					type: "boolean",
					defaultValue: false
				}
			},
			events: {
				valueHelpRequest: {}
			},
			aggregations: {
				_input: {
					type: "sap.m.MultiInput",
					multiple: false,
					visibility: "hidden"
				},
				tokens: {
					type: "sap.m.Token",
					multiple: false,
					visibility: "hidden"
				}
			}
		},

		init: function () {
			this._initializeModel();
			this.getInitiativeOreKeys();
			// this.getInitiativeCategory();
			this.controller = new InitiativeSelectController(this);
			this.setAggregation(
				"_input",
				new sap.m.MultiInput(this.getId() + "-input", {
					width: "100%",
					editable: "{= ${InitiativeModel>/ActivityViewMode} === 'DETAIL_ACTIVITY' ? false : true}",
					placeholder: "Select Initiatives",
					visible: "{InitiativeModel>/IsInitiativeVisible}",
					valueHelpOnly: true,
					showValueHelp: true,
					valueLiveUpdate: true,
					valueHelpRequest: this.openInitiativesDialog,
					tokenUpdate: this.controller.handleTokenDelete
				})
			);

			this.setAggregation(
				"tokens",
				new sap.m.Token(this.getId() + "-token", {})
			);
		},

		setVisible: function () {
			const oInitiativeModel = this.getModel("InitiativeModel");
			const sViewMode = this.getActivityViewMode();
			const aInitiatives = this.getSelectedInitiatives();
			if (aInitiatives.length && (sViewMode === "DETAIL_ACTIVITY" || sViewMode === "EDIT_ACTIVITY")) {
				oInitiativeModel.setProperty("/IsInitiativeVisible", true);
			}
			const isVisible = oInitiativeModel.getProperty("/IsInitiativeVisible");
			this.setProperty("Visible", isVisible);
		},

		setActivityTypeId: function (sActTypeId) {
			if (sActTypeId) {
				this.setProperty("ActivityTypeId", sActTypeId);
				this.getActivityInitiatives();
			}
		},

		setActivityAsstnId: function (sActAsstnId) {
			if (sActAsstnId !== undefined) {
				if (Number.isInteger(sActAsstnId)) {
					sActAsstnId = sActAsstnId === 0 ? "501" : (sActAsstnId === 1 ? "502" : "503");
				}
				this.setProperty("ActivityAsstnId", sActAsstnId);
				this.getActivityInitiatives();
			}
		},

		setCacheInitiative: function (bValue = false) {
			this.setProperty("cacheInitiative", bValue);
		},

		setProjectType: function (sProjectType) {
			if (sProjectType) {
				this.setProperty("ProjectType", sProjectType);
				this.getActivityInitiatives();
			}
		},

		setSelectedInitiatives: function (aInitiatives) {
			if (aInitiatives) {
				const oInitiativeModel = this.getModel("InitiativeModel");
				const aTokens = [];
				if (aInitiatives.length) {
					aInitiatives.filter(function (item) {
						aTokens.push(new sap.m.Token({
							text: item.InitiativeCategoryName + ": " + item.InitiativeName,
							key: item.InitiativeId
						}));
					});
				}
				this.getAggregation("_input").setTokens(aTokens);
				oInitiativeModel.setProperty("/SelectedInitiatives", aInitiatives);
				this.setProperty("SelectedInitiatives", aInitiatives);
			}
		},

		setActivityViewMode: function (sViewMode) {
			if (sViewMode) {
				this.setProperty("ActivityViewMode", sViewMode);
				const oInitiativeModel = this.getModel("InitiativeModel");
				oInitiativeModel.setProperty("/ActivityViewMode", sViewMode);
			}
		},

		_initializeModel: function () {
			const data = {
				"IsInitiativeVisible": false,
				"ActivityInitiatives": [],
				"SelectedInitiatives": [],
				"InitiativeCategories": [],
				"SearchQuery": "",
				"CategoryFilterKey": "0000",
				"InitiativesCount": 0
			};
			this.initiativeMap = {};
			var model = this.getModel();
			if (!model) {
				model = new JSONModel(data);
				this.setModel(model, "InitiativeModel");
			} else {
				model.setData(data);
			}
		},

		openInitiativesDialog: function (event) {
			var that = this;
			const control = event.getSource().getParent();
			if (!control.InitiativesDialog) {
				Fragment.load({
					id: `${control.getId()}_Initiatives`,
					name: "com.melody.lib.fragments.InitiativeSelect",
					controller: control.controller,
				}).then(function (oDialog) {
					oDialog.setModel(control.getModel("InitiativeModel"), "InitiativeModel");
					const i18nModel = new ResourceModel({
						bundleName: "com.melody.lib.messagebundle"
					});
					oDialog.setModel(i18nModel, "i18n");
					that.addDependent(oDialog);
					if (control.getProjectType() === "ACTVT_SET") {
						oDialog.setTitle(i18nModel.getResourceBundle().getText("initiativeFilterDialogTitle"));
					}
					control.InitiativesDialog = oDialog;
					oDialog.open();
				}.bind(that));
			} else {
				control.InitiativesDialog.open();
			}
			control.setInitiativeSelected(control);
		},

		setInitiativeSelected: function (control) {
			const oInitiativeModel = control.getModel("InitiativeModel");
			const aInitiatives = oInitiativeModel.getProperty("/ActivityInitiatives");
			const prevSelectedInitiative = oInitiativeModel.getProperty("/SelectedInitiatives") || [];
			const cacheInitiative = control.getCacheInitiative() || false;
			aInitiatives.filter(function (item) {
				item.Selected = false;
			});
			const tempArr = [];
			const aSelectedInitiatives = control.getAggregation("_input").getTokens();
			aSelectedInitiatives.filter(function (token) {
				var itemIndex = aInitiatives.findIndex(function (item) {
					return item.InitiativeId === token.getKey();
				});

				if (itemIndex !== -1) {
					oInitiativeModel.setProperty("/ActivityInitiatives/" + itemIndex + "/Selected", true);
					tempArr.push(oInitiativeModel.getProperty("/ActivityInitiatives/" + itemIndex));
				}

				//#622 to store the initiatives for the new scenario in activity form edit
				if (cacheInitiative && itemIndex === -1) {
					let initiativeData = prevSelectedInitiative.find((data) => data.InitiativeId === token.getKey()) || false;
					if (initiativeData && !tempArr.some(function (item) {
							item.InitiativeId === initiativeData.InitiativeId;
						})) {
						tempArr.push(initiativeData);
					}
				}
			});
			oInitiativeModel.setProperty("/SelectedInitiatives", tempArr);
			control.controller.filterTable([]);
			oInitiativeModel.setProperty("/SearchQuery", "");
			oInitiativeModel.setProperty("/CategoryFilterKey", "0000");
			oInitiativeModel.refresh(true);
		},

		getInitiativeOreKeys: async function () {
			const aResult = await UserService.getInitiativeKeys();
			const aOreKeys = aResult.data.results;
			const oInitiativeModel = this.getModel("InitiativeModel");
			oInitiativeModel.setProperty("/InitiativeOreKeys", aOreKeys);
			const sProjectType = this.getProjectType();
			if (sProjectType === "SLINE") {
				this.getActivityInitiatives();
			}
		},

		/*getInitiativeCategory: async function () {
			const aCategories = await ActivityService.getInitiativeCategory();
			const oInitiativeModel = this.getModel("InitiativeModel");
			oInitiativeModel.setProperty("/InitiativeCategories", aCategories);
		},*/

		getActivityInitiatives: async function () {
			const oInitiativeModel = this.getModel("InitiativeModel");
			const aOreKeys = oInitiativeModel.getProperty("/InitiativeOreKeys");
			const sActTypeId = this.getActivityTypeId();
			const sActAsstnId = this.getActivityAsstnId();
			const sProjectType = this.getProjectType();
			const sViewMode = this.getActivityViewMode();
			const aActInitiatives = oInitiativeModel.getProperty("/ActivityInitiatives");
			if (this.initiativeMap[sActTypeId + sActAsstnId] && aActInitiatives.length) {
				return;
			}
			if (sProjectType === "ACTVT_SET") {
				oInitiativeModel.setProperty("/IsInitiativeVisible", true);
				const aUserInitiatives = await ActivityService.getUserInitiatives();
				oInitiativeModel.setProperty("/ActivityInitiatives", aUserInitiatives);
				oInitiativeModel.setProperty("/InitiativesCount", aUserInitiatives.length);
				this.setInitiativeCategories(aUserInitiatives);
			} else {
				if (!sActTypeId || !sActAsstnId || !(aOreKeys && aOreKeys.length)) {
					return;
				}
				const aFilters = [];
				const actTypeFilter = new Filter({
					filters: [
						new Filter({
							path: "ActTypeId",
							operator: FilterOperator.EQ,
							value1: sActTypeId
						}),
						new Filter({
							path: "ActTypeId",
							operator: FilterOperator.EQ,
							value1: "*"
						})
					],
					and: false
				});
				const actAsstnFilter = new Filter({
					path: "AsstdId",
					operator: FilterOperator.EQ,
					value1: sActAsstnId
				});

				var aOreKeyFilters = [];
				aOreKeys.filter(function (item) {
					aOreKeyFilters.push(new Filter({
						path: "OreCombKey",
						operator: FilterOperator.EQ,
						value1: item.OreCombKey
					}));
				});
				const oreKeysFilter = new Filter({
					filters: aOreKeyFilters,
					and: false
				})
				aFilters.push(new Filter({
					filters: [oreKeysFilter, actTypeFilter, actAsstnFilter],
					and: true
				}));

				const aInitiatives = await ActivityService.getActivityInitiatives(aFilters);
				oInitiativeModel.setProperty("/IsInitiativeVisible", aInitiatives.length ? true : false);
				this.initiativeMap = {};
				const sKey = aInitiatives.length ? aInitiatives[0].ActTypeId + aInitiatives[0].AsstdId : "";
				if (!this.initiativeMap.hasOwnProperty(sKey)) {
					this.initiativeMap[sKey] = aInitiatives;
				}
				const aDefaultInitiatives = [];
				aInitiatives.filter(function (item) {
					item.Selected = false;
					if (item.ActivityDefault) {
						aDefaultInitiatives.push(item);
					}
				});
				oInitiativeModel.setProperty("/ActivityInitiatives", aInitiatives);
				oInitiativeModel.setProperty("/InitiativesCount", aInitiatives.length);
				this.setInitiativeCategories(aInitiatives);
				const aSelectedInitiatives = oInitiativeModel.getProperty("/SelectedInitiatives");
				if ((sViewMode === "NEW_ACTIVITY" || sViewMode === "REG_NEW_ACT") && !aSelectedInitiatives.length) {
					this.setSelectedInitiatives(aDefaultInitiatives);
				}
			}
			oInitiativeModel.refresh(true);
			this.setVisible();
		},

		setInitiativeCategories: function (aInitiatives) {
			const oInitiativeModel = this.getModel("InitiativeModel");
			const aCategories = [];
			aInitiatives.filter(function (item) {
				if (item.InitiativeCategoryId !== "0000") {
					const obj = {
						InitiativeCategoryId: item.InitiativeCategoryId,
						InitiativeCategoryName: item.InitiativeCategoryName
					};
					aCategories.push(obj);
				}
			});
			if (aCategories.length) {
				const oJason = aCategories.map(JSON.stringify);
				const oUniqueSet = new Set(oJason);
				const aUniqueCategories = Array.from(oUniqueSet).map(JSON.parse);
				aUniqueCategories.push({
					InitiativeCategoryId: "0000",
					InitiativeCategoryName: "All"
				});
				oInitiativeModel.setProperty("/InitiativeCategories", aUniqueCategories);
			}
		}

		// renderer: InitiativeSelectRenderer;
	});
	return InitiativeSelect;
}, /* bExport= */ true);