/*!
 * ${copyright}
 */

// Provides control com.melody.lib.
sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/Control",
	"sap/ui/Device",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"com/melody/lib/util/mtr/MTR",
	"com/melody/lib/enum/Actions",
	"com/melody/lib/service/OREService",
	"com/melody/lib/controls/mtr/TimeEntry/TimeEntryMenuItem",
	"com/melody/lib/util/mtr/MTRModels",
	"com/melody/lib/util/opportunity/Opportunity"
],
	function (jQuery, Control, Device, Fragment, JSONModel, MTRUtil, Actions, OREService, TimeEntryMenuItem, MTRModels, OpportunityUtil) {
		"use strict";

		/**
		 * Constructor for a new QuickNavMenu Control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends  Control
		 *
		 * @author SAP SE
		 * @version ${version}
		 *
		 * @constructor
		 * @public
		 * @alias com.melody.lib.controls.QuickNavMenu
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */
		var oController = {
			fnQuickLinkNavigation: async function (oEvent) {
				let oSource = oEvent.getSource();
				let oModel = oEvent.getSource().getModel();
				let aMasterQuickLinksNav = $.extend(true, [], oModel.getProperty("/aMasterQuickLinksNav")) || [];
				if (oController.fnHandleTimeEntryOption(oSource)) {
					return;
				}

				var oSelectedObj = oEvent.getSource().getBindingContext().getObject();

				//Phone || Tablets
				if (this.checkHandSet() && "hadChild" in oSelectedObj && oSelectedObj.hadChild) {
					let oPopover = await sap.ui.core.Fragment.load({
						name: "com.melody.lib.fragments.QuickNavMenuPopover",
						controller: oController
					});
					oSource.addDependent(oPopover);
					let oMenuItem = aMasterQuickLinksNav.find(item => item.item_id === oSelectedObj.item_id);
					oModel.setProperty("/menuTitle", oMenuItem.item_name);
					oModel.setProperty("/ChildItems", oMenuItem.to_child.results || []);
					oPopover.setModel(oModel);
					oPopover.openBy(oSource);
					return;
				}

				var oParamObj = {};
				var externalURL = oSelectedObj.url;
				var semanticObj = oSelectedObj.semantic_obj;
				var sSemanticName = semanticObj.split("-")[0];
				var sSemanticAction = semanticObj.split(/-(.+)/)[1];
				var aParamObj = oSelectedObj.to_params.results;
				$.each(aParamObj, function (index, param) {
					oParamObj[param.description] = param.value;
				});
				if (sSemanticName) {
					var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
					var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
						target: {
							semanticObject: sSemanticName,
							action: sSemanticAction
						},
						params: oParamObj
					})) || "";
					oCrossAppNavigator.toExternal({
						target: {
							shellHash: hash
						}
					});

					let originUrl = window.location.ancestorOrigins[0] || ""; //CF BASE URL
					if (window.location.hash.split("?")[0].includes(sSemanticName) && (originUrl.indexOf("test") !== -1 || originUrl.indexOf("prod") !==
						-1)) {
						window.location.hash = hash; //updating old hash with new hash value
						// window.location.reload();
					}

				} else if (externalURL) {
					window.open(externalURL, "_blank");
				}
			},

			//Function to handle MelodyTimeEntry
			fnHandleTimeEntryOption: function (oSource) {
				let oMTRModel = sap.ui.getCore().getModel("oMTRModel");
				//Desktop || Tablet
				if (typeof oSource.getControlType === "function") { //TODO: value
					if (oSource.getControlType() === Actions.CreateTimeEntryMenu) {
						let bDontAllowSelectedActivity = true;
						oSource.openTimeRecordBox(bDontAllowSelectedActivity);
						return true;
					}
				}

				//Phone
				let oNavData = oSource.getBindingContext().getObject() || false;
				if (oNavData && "semantic_obj" in oNavData && oNavData.semantic_obj === "melody-time") {
					if (!this.oTimeEnterMenuItem) {
						this.oTimeEnterMenuItem = new TimeEntryMenuItem({
							text: oNavData.item_name,
						});
						this.oTimeEnterMenuItem.setSelectedActivity();
						this.oTimeEnterMenuItem.setEntries();
					}

					if (this.oTimeEnterMenuItem.getControlType() === Actions.CreateTimeEntryMenu) {
						let bDontAllowSelectedActivity = true;
						this.oTimeEnterMenuItem.openTimeRecordBox(bDontAllowSelectedActivity);
						return true;
					}
				}
				return false;
			},

			//function to close menuItem Popover
			onMenuItemPopoverClose: function (oEvent) {
				oEvent.getSource().getParent().close();
				oEvent.getSource().getParent().destroy();
			},

			checkHandSet: function () {
				return sap.ui.Device.system.phone || sap.ui.Device.system.tablet;
			}
		};

		var oQuickNavMenu = Control.extend("com.melody.lib.controls.QuickNavMenu", {
			metadata: {
				properties: {
					text: {
						type: "string",
						defaultValue: ""
					}
				},
				aggregations: {
					_menuButton: {
						type: "sap.m.MenuButton",
						multiple: false,
						visibility: "hidden",
						busy: true,
						busyIndicatorDelay: 0
					},
					_Button: {
						type: "sap.m.Button",
						multiple: false,
						visibility: "hidden",
						busy: true,
						busyIndicatorDelay: 0
					}
				}
			},

			setText: function (text) {
				const sText = (text) ? text : "";
				this.setProperty("text", sText);
				if (this.getAggregation("_Button")) {
					this.getAggregation("_Button").setText(sText);
				}
			},

			init: function () {
				const that = this;
				const oModel = new JSONModel({
					QuickLinksNav: []
				});
				this.setModel(oModel);

				let libraryPath = jQuery.sap.getModulePath("com.melody.lib");
				jQuery.sap.includeStyleSheet(libraryPath + "/controls/controlStyle/controlStyle.css");

				this.setAggregation("_Button", new sap.m.Button(this.getId() + "-Button", {
					text: that.getText(),
					icon: "sap-icon://dropdown",
					press: that.onOpenMenu.bind(that)
				}));
				// this.fnGetMelodyQuickLinks();
				that.fnSetControlAggregation();
				const oSettingsModel = MTRModels.getMTRSettingsModel();
				const oSettings = oSettingsModel.getData() || {};
				if (oSettings.hasOwnProperty("UserId") && !oSettings.UserId) {
					MTRUtil.init("ACTVT");
				}
				const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				const bDiscOppTriggered = oStorage.get("pcDiscontinuedOppInitCall");
				if (!bDiscOppTriggered) {
					OpportunityUtil.getUserRecords(this);
				}
			},

			//Function to open Quick Nav Options
			onOpenMenu: async function (oEvent) {
				var that = this;
				// let oButton = this.getAggregation("_Button");
				let oButton = oEvent.getSource();
				if (sap.ui.Device.system.phone) {
					let oMenu = await sap.ui.core.Fragment.load({
						id: that.getId() + "_menu",
						name: "com.melody.lib.fragments.QuickNavMenuItems",
						controller: oController
					});
					oMenu.openBy(oButton);
					oMenu.setModel(that.getModel());
					return;
				}

				//Desktop || Tablet
				if (this.oMenuItemBtn) {
					this.oMenuItemBtn.openBy(oButton);
				}

			},

			fnSetControlAggregation: async function () {
				var that = this;
				let aMenuData = that.getModel().getProperty("/QuickLinksNav") || [];
				that.fnMenuBusyIndicator(true);
				this.setText(that.getText());
				const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				//Get the Menu options from the service and load the Add Menu Items
				if (!aMenuData.length) {
					let aQuickLinksNavData = oStorage.get("aQuickLinksNavData") || [];
					if (!aQuickLinksNavData?.length) {
						let oResponse = await OREService.fnGetMelodyQuickLinks(OREService.models.oreModel);
						aQuickLinksNavData = (oResponse && "data" in oResponse) ? oResponse.data.results : [];
						oStorage.put("aQuickLinksNavData", aQuickLinksNavData);
					}
					that.getModel().setProperty("/QuickLinksNav", aQuickLinksNavData);
					that.getModel().setProperty("/aMasterQuickLinksNav", aQuickLinksNavData);
					that.getModel().refresh(true);
				}

				that.fnMenuBusyIndicator(false);
				if (sap.ui.Device.system.desktop || sap.ui.Device.system.tablet) {
					that.fnMenuBusyIndicator(true);
					sap.ui.core.Fragment.load({
						id: that.getId() + "_menu",
						name: "com.melody.lib.fragments.QuickNavMenuItems",
						controller: oController
					}).then(async function (oMenu) {
						// this.getAggregation("_menuButton").setMenu(oMenu);
						oMenu.setModel(that.getModel());
						setTimeout(() => {
							that.fnAddMenuItemToQuickNav(oMenu);
						}, 1200);
					}.bind(that));
				} else if (sap.ui.Device.system.phone) {
					this.fnFormatMenuForHandSets();
				}

			},

			//Function to format menu items for phone
			fnFormatMenuForHandSets: function () {
				let aMenuData = $.extend(true, [], this.getModel().getProperty("/QuickLinksNav"));
				aMenuData = aMenuData.map((item) => {
					if (item.to_child && "results" in item.to_child && item.to_child.results.length) {
						item.to_child.results = [];
						item.hadChild = true;
					}
					return item;
				});
				this.getModel().setProperty("/QuickLinksNav", aMenuData);
				this.getModel().refresh();
			},

			//function to handle busy indicator
			fnMenuBusyIndicator: function (bBusy) {
				if (this.getAggregation("_Button")) {
					this.getAggregation("_Button").setBusyIndicatorDelay(0);
					this.getAggregation("_Button").setBusy(bBusy);
				}
			},

			onAfterRendering: function (oEvent) { },

			//function to add create entry menu item to Quick Nav Options
			fnAddMenuItemToQuickNav: async function (oMenuControl) {
				oMenuControl.setBusy(true);
				let aQuickLinksNav = $.extend(true, [], this.getModel().getProperty("/QuickLinksNav"));
				await new Promise((resolve) => setTimeout(resolve, 1000));
				let aListItems = (oMenuControl) ? oMenuControl.getItems() : [];
				if (aListItems.length) {
					let oTimeEnterMenuItem = new TimeEntryMenuItem({
						text: "Melody Time",
						press: oController.fnQuickLinkNavigation.bind(this)
					});
					let oMTRModel = sap.ui.getCore().getModel("oMTRModel");
					oTimeEnterMenuItem.setSelectedActivity();
					oTimeEnterMenuItem.setEntries();
					this.fnInsertCstControl(aListItems, oTimeEnterMenuItem);
					this.fnMenuBusyIndicator(false);
					this.oMenuItemBtn = oMenuControl;
					this.handleUrlparameters(oTimeEnterMenuItem);
				} else {
					/*	await new Promise((resolve) => setTimeout(resolve, 700));
						console.error("MENU_ITEMS_NOT_LOADED :", aQuickLinksNav);
						this.fnAddMenuItemToQuickNav(oMenuControl);*/
				}
			},

			//Function to open time entry dialog based on url param
			handleUrlparameters: function (oTimeEnterMenuItem) {
				var sHash = window.location.hash;
				var sRoute = sHash.split("?")[0].substring(1);
				var sQuery = sHash.split("?")[1] || "";
				var isMelodyTime = sQuery.search("MelodyActivityTime") === -1 ? false : true;
				if (sRoute === "pc-app" && isMelodyTime) {
					if (oTimeEnterMenuItem.getVisible()) {
						oTimeEnterMenuItem.firePress();
					}
				}
			},

			//function to search in quicknav data
			fnSearchInQuickNavDataForMelodyTime: function (aResponse) {
				let iIndex = aResponse.findIndex((oRow) => {
					if (oRow.hasOwnProperty("IsPopUp") && oRow.hasOwnProperty("semantic_obj")) {
						if ((oRow.IsPopUp === "X" || oRow.IsPopUp) && oRow.semantic_obj === "melody-time") {
							return true;
						}
					}
				});
				return iIndex;
			},

			//function to insert custom control at a given index and remove the item based on data(Melody-Time) entry
			fnInsertCstControl: function (aListItems, oTimeEnterMenuItem) {
				let oThisController = this;
				for (let i = 0; i < aListItems.length; i++) {
					let oList = aListItems[i];
					let oListData = oList.getBindingContext().getObject() || {};
					let isPopValue = (oListData.hasOwnProperty("IsPopUp")) ? oListData.IsPopUp : "";
					if (isPopValue || isPopValue === "X") {
						isPopValue = true;
					} else {
						isPopValue = false;
					}
					let sSemanticObj = (oListData.hasOwnProperty("semantic_obj")) ? oListData.semantic_obj : "";
					let aChildItems = aListItems[i].getItems() || [];
					if (aChildItems.length && Array.isArray(aChildItems)) {
						oThisController.fnInsertCstControl(aChildItems, oTimeEnterMenuItem);
					} else {
						if (isPopValue && sSemanticObj === "melody-time") {
							oTimeEnterMenuItem.setText(oListData.item_name);
							let oParentList = oList.getParent();
							if (oParentList) {
								oParentList.removeItem(oList);
								oTimeEnterMenuItem.setStartsSection(true);
								oParentList.insertItem(oTimeEnterMenuItem, i);
							}
						}
					}
				}
			},

		});

		return oQuickNavMenu;

	}, /* bExport= */ true);