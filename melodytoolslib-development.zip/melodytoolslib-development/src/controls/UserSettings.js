/*!
 * ${copyright}
 */

// Provides control com.melody.lib.
sap.ui.define(["jquery.sap.global",
		"sap/ui/core/Control",
		"sap/ui/Device",
		"sap/m/MessageToast",
		"sap/ui/core/Fragment",
		"sap/ui/model/json/JSONModel",
		"sap/ui/model/resource/ResourceModel",
		"com/melody/lib/service/OREService",
		"com/melody/lib/util/mtr/MTRModels",
		"sap/m/MessageBox"
	],
	function (jQuery, Control, Device, MessageToast, Fragment, JSONModel, ResourceModel, OREService, MTRModels, MessageBox) {
		"use strict";

		/**
		 * Constructor for a new UserSettings Control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends  Control
		 *
		 * @author SAP SE
		 * @version ${version}
		 *
		 * @constructor
		 * @public
		 * @alias com.melody.lib.controls.UserSettings
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */
		var oDialogController = {

			//Function to get loggedIn User's notification list
			fnGetUserNotificationList: function () {
				let that = this;
				OREService.fnGetUserNotificationList(this.OreModel)
					.then((response) => {
						let data = response.data.results;
						that.oUserSettingsModel.setProperty("/UpdatedNotifList", []);
						that.oUserSettingsModel.setProperty("/NotificationList", data);
						that.oUserSettingsModel.setProperty("/isSettingBtnBusy", false);

						var oSettingsModel = MTRModels.getMTRSettingsModel();
						if (data.length) {
							var timeSheetVal = 1;
							var bUserNotifEssInMu = true;
							data.filter(function (item) {
								if (item.ActionID === "0008") {
									bUserNotifEssInMu = item.Value === "X" ? true : false;
								} else if (item.ActionID === "0009") {
									timeSheetVal = item.Value;
								}
							});
							oSettingsModel.setProperty("/UserNotifEssInMu", bUserNotifEssInMu);
							oSettingsModel.setProperty("/EssInMu", bUserNotifEssInMu);
							oSettingsModel.setProperty("/Timesheet", timeSheetVal);
							oSettingsModel.refresh();
						}
						let aSideNav = this.fnCreateNavListData(data);
						this.fnGetLoggedInUserMasterList(aSideNav);
					}, error => {
						that.oUserSettingsModel.setProperty("/UpdatedNotifList", []);
						that.oUserSettingsModel.setProperty("/NotificationList", []);
						that.oUserSettingsModel.setProperty("/isSettingBtnBusy", false);
					});
			},

			//Function to create data for side navigation list
			fnCreateNavListData: function (oData) {
				let aSideNav = [];
				oData.filter(function (item) {
					let bVal = false;
					bVal = aSideNav.find(function (element) {
						if (element["key"] === item["FolderId"]) {
							return true;
						} else {
							return false;
						}
					});
					if (!bVal) {
						aSideNav.push({
							"key": item["FolderId"],
							"text": item["FolderName"]
						});
					}
				});
				aSideNav = this.fnSortSideNavData(aSideNav);
				return aSideNav;
			},

			//Function to sort the Array based on the key
			fnSortSideNavData: function (oData) {
				return oData.sort(function (item1, item2) {
					return parseInt(item1["key"]) - parseInt(item2["key"]);
				});
			},

			fnGetLoggedInUserMasterList: function (aSideNav) {
				let oMasterList = [{
					"key": "01",
					"text": "User Settings",
					"icon": "sap-icon://user-settings",
					"subList": aSideNav
				}];
				this.oUserSettingsModel.setProperty("/MasterList", oMasterList);
				this.oUserSettingsModel.setProperty("/UpdatedNotifList", []);
			},

			//Function to toggle SideNavigation
			onCollapseExpandPress: function () {
				let oSideNavigation = this._fnGetDialogContentById("SETTINGS_SIDE_NAV"); /* @type sap.tnt.SideNavigation */
				let bExpanded = oSideNavigation.getExpanded(); /* @type bool */
				oSideNavigation.setExpanded(!bExpanded); // toggle expanded property of sideNavigation
				if (!bExpanded) {
					this._fnGetDialogContentById("SETTINGS_REG_NOTE").addStyleClass("sapUiLargeMarginBegin");
					this._fnGetDialogContentById("SETTINGS_REG_NOTE").removeStyleClass("sapMActRegNoteDescMargin");
				} else {
					this._fnGetDialogContentById("SETTINGS_REG_NOTE").addStyleClass("sapMActRegNoteDescMargin");
					this._fnGetDialogContentById("SETTINGS_REG_NOTE").removeStyleClass("sapUiLargeMarginBegin");
				}
			},

			//Function to navigate between detail pages
			handleNav: function (oEvent, target) {
				this.fnSetSideNavConfigs();
				let navCon = this._fnGetDialogContentById("SETTINGS_NAV_CON");
				if (oEvent) {
					target = oEvent.getSource().getCustomData()[0].getValue();
				}
				if (target) {
					let pageId = "";
					switch (target) {
					case "0000000001":
						pageId = "APP_NOTIF_CONFIG";
						break;
					case "0000000002":
						pageId = "APP_REGISTRATION";
						break;
					case "0000000003":
						pageId = "TIME_RECORDING";
						break;
					}
					// handle navigation in the settings dialog box with fade animation
					navCon.to(this._fnGetDialogContentById(pageId), "fade");
					this.oUserSettingsModel.setProperty("/SelectedSideNav", pageId);
				} else {
					// stays on same page within navContainer
					navCon.back();
				}
			},

			fnSetSideNavConfigs: function () {
				if (sap.ui.Device.system.desktop) {
					this.UserSettingsDialog.addStyleClass("sapUiSizeCompact");
				} else if (Device.system.tablet) {
					this.UserSettingsDialog.addStyleClass("sapUiSizeCompact");
				} else {
					this._fnGetDialogContentById("SETTINGS_SIDE_NAV").setExpanded(false);
				}
			},

			//Function to update the switch state change
			fnUpdateSwitchState: function (oEvent) {
				var that = this;
				var oUserSettingsModel = this.oUserSettingsModel;
				// var switchState = oEvent.getSource().getState();
				var oPath = oEvent.getSource().getBindingContext("oUserSettingsModel").getPath();
				var selectedObj = oUserSettingsModel.getProperty(oPath);
				var switchState = oEvent.getParameter("state");
				var oSettingsModel = MTRModels.getMTRSettingsModel();

				if (selectedObj.ActionID === "0008" && !switchState) {
					// var bCompact = !this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.confirm(this.i18nModel.getText("essCnfrmTxt"), {
						styleClass: "sapUiSizeCompact",
						actions: ["Confirm", "Cancel"],
						styleClass: "sapUiSizeCompact",
						onClose: function (sAction) {
							if (sAction === "Confirm") {
								oSettingsModel.setProperty("/UserNotifEssInMu", false);
							} else if (sAction === "Cancel") {
								switchState = !switchState;
								oEvent.getSource().setState(true);
								oSettingsModel.setProperty("/UserNotifEssInMu", true);
							}
							that.updateNotifListItems(switchState, selectedObj, oUserSettingsModel);
							oSettingsModel.refresh();
						}
					});
				} else {
					oSettingsModel.setProperty("/UserNotifEssInMu", true);
					this.updateNotifListItems(switchState, selectedObj, oUserSettingsModel);
				}
			},

			fnUpdateSegmentBtnStatus: function (oEvent) {
				var that = this;
				var oUserSettingsModel = this.oUserSettingsModel;
				var oPath = oEvent.getSource().getBindingContext("oUserSettingsModel").getPath();
				var selectedObj = oUserSettingsModel.getProperty(oPath);
				var selectedKey = oEvent.getSource().getSelectedKey();
				this.updateNotifListItems(selectedKey, selectedObj, oUserSettingsModel);
			},

			updateNotifListItems: function (switchState, selectedObj, oUserSettingsModel) {
				if (switchState) {
					selectedObj.Value = "X";
				} else {
					selectedObj.Value = "";
				}
				let index;
				let updatedNotifList = oUserSettingsModel.getProperty("/UpdatedNotifList");
				updatedNotifList.filter(function (object, i) {
					if (object.NotifID === selectedObj.NotifID) {
						index = i;
					}
				});
				if (index || index === 0) {
					updatedNotifList[index] = selectedObj;
				} else {
					updatedNotifList.push(selectedObj);
				}
				oUserSettingsModel.setProperty("/UpdatedNotifList", updatedNotifList);
				oUserSettingsModel.refresh();
			},

			// //Function to save user settings
			// onSaveUserSettings: function () {
			// 	let oCurrentPageId = this._fnGetDialogContentById("SETTINGS_NAV_CON").getCurrentPage().getId();
			// 	if (oCurrentPageId.includes("APP_NOTIF_CONFIG") || oCurrentPageId.includes("APP_REGISTRATION") || oCurrentPageId.includes(
			// 			"TIME_RECORDING")) {
			// 		this.fnSaveNotificationSettings();
			// 	}
			// },

			//Function to save user's notification settings
			fnSaveNotificationSettings: function () {
				let that = this;
				let updatedNotifList = this.oUserSettingsModel.getProperty("/UpdatedNotifList");
				if (updatedNotifList.length) {
					this._fnGetDialogContentById("APP_NOTIF_CONFIG").setBusy(true);
					OREService.fnSaveNotificationSettings(this.OreModel, updatedNotifList, jQuery.sap.uid())
						.then((response) => {
							let responseData = response.data.__batchResponses[0].__changeResponses;
							for (let i = 0; i < responseData.length; i++) {
								let statusCode = responseData[i].statusCode;
								let oUserSettingsModel = this.oUserSettingsModel;
								if (statusCode === "201") {
									let notifId = responseData[i].data.NotifID;
									let notificationList = oUserSettingsModel.getProperty("/NotificationList");
									notificationList.find((object, index) => {
										if (object.NotifID === notifId) {
											oUserSettingsModel.setProperty("/NotificationList/" + index, responseData[i].data);
										}
									});
								}
								oUserSettingsModel.refresh(true);
							}

							var oSettingsModel = MTRModels.getMTRSettingsModel();
							var bEssInMu = oSettingsModel.getProperty("/UserNotifEssInMu");
							var aTasks = oSettingsModel.getProperty("/MTRTasks") || [];
							aTasks = aTasks.filter(function (task) {
								return (bEssInMu && !task.EssInMu) || !bEssInMu;
							});
							oSettingsModel.setProperty("/MTRTasksByEssInMu", aTasks);
							oSettingsModel.refresh();

							that._fnGetDialogContentById("APP_NOTIF_CONFIG").setBusy(false);
							that.fnCloseUserSettingsDialog();
						}, error => {
							MessageToast.show(that.i18nModel.getText("NOTIF_SAVE_ERROR"));
							that._fnGetDialogContentById("APP_NOTIF_CONFIG").setBusy(false);
						});
				} else {
					MessageToast.show(that.i18nModel.getText("NOTIF_NO_CHANGES"));
				}
			},

			fnCloseUserSettingsDialog: function (oEvent) {
				let updatedNotifList = this.oUserSettingsModel.getProperty("/UpdatedNotifList");
				if (updatedNotifList.length) {
					this.fnGetUserNotificationList();
				}
				this.UserSettingsDialog.close();
			},

			_fnGetDialogContentById: function (contentId) {
				return sap.ui.core.Fragment.byId(this.UserSettingControl.getId() + "_UserSettingsDialog", contentId);
			},

			fnLoadResourceBundle: function () {
				let i18nModel = new ResourceModel({
					bundleName: "com.melody.lib.messagebundle"
				});
				this.UserSettingsDialog.setModel(i18nModel, "i18n");
				this.i18nModel = i18nModel.getResourceBundle();
			}
		};

		var oUserSettings = Control.extend("com.melody.lib.controls.UserSettings", {
			metadata: {
				properties: {
					text: {
						type: "string",
						defaultValue: ""
					},
					icon: {
						type: "sap.ui.core.URI",
						group: "Appearance",
						defaultValue: ""
					}
				},
				aggregations: {
					_button: {
						type: "sap.m.Button",
						multiple: false,
						visibility: "hidden"
					}
				}
			},

			setText: function (text) {
				var sText = (text) ? text : "";
				this.setProperty("text", sText);
				this.getAggregation("_button").setText(sText);
			},

			setIcon: function (icon) {
				var sIcon = (icon) ? icon : "";
				this.setProperty("icon", sIcon);
				this.getAggregation("_button").setIcon(sIcon);
			},

			init: function () {
				const that = this;
				const oModel = new JSONModel();
				this.setModel(oModel, "oUserSettingsModel");
				oDialogController.oUserSettingsModel = oModel;
				oModel.setProperty("/isSettingBtnBusy", true);
				this.setAggregation("_button", new sap.m.Button(this.getId() + "-button", {
					text: that.getText(),
					press: that.fnOpenUserSettingsDialog,
					// Commented below code : QA Busy Indicator issue
					// busy: "{oUserSettingsModel>/isSettingBtnBusy}"
				}));
				this.addStyleClass("userSettingsBtn");
				this.fnLoadUserProfileOptions();
				this.fnLoadUserSettingsDialog(that);
				oDialogController.fnGetUserNotificationList();
			},

			openUserSettingsFromMail: function () {
				const that = this;
				const sHash = window.location.hash;
				if (sHash.includes("IsChangeUserSettings")) {
					that.fnOpenUserSettingsDialog();
				}
			},

			fnLoadUserSettingsDialog: function (that) {
				if (!that.UserSettingsDialog) {
					Fragment.load({
						id: that.getId() + "_UserSettingsDialog",
						name: "com.melody.lib.fragments.UserSettings.Settings",
						controller: oDialogController
					}).then(function (oDialog) {
						var oSettingsModel = MTRModels.getMTRSettingsModel();
						oDialog.setModel(that.getModel("oUserSettingsModel"), "oUserSettingsModel");
						oDialog.setModel(oSettingsModel, "mtrSettings");
						that.addDependent(oDialog);
						that.UserSettingsDialog = oDialog;
						oDialogController.UserSettingControl = that;
						oDialogController.UserSettingsDialog = oDialog;
						oDialogController.fnLoadResourceBundle();
						that.openUserSettingsFromMail();
						return oDialog;
					}.bind(that));
				}
			},

			fnLoadUserProfileOptions: function () {
				let oData = [{
					"key": "SETTINGS",
					"text": "Settings",
					"icon": "sap-icon://settings"
				}];
				this.getModel("oUserSettingsModel").setProperty("/UserProfileItems", oData);

				let TimesheetModes = [{
					"key": "1",
					"text": "Matrix Calendar"
				}, {
					"key": "2",
					"text": "Day Calendar"
				}];
				this.getModel("oUserSettingsModel").setProperty("/TimesheetModes", TimesheetModes);
			},

			fnOpenUserSettingsDialog: function (oEvent) {
				oDialogController.UserSettingsDialog.open();
			}
		});

		return oUserSettings;

	}, /* bExport= */ true);