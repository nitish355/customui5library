// @ts-nocheck
sap.ui.define([
  "sap/m/ComboBox", "sap/m/ComboBoxRenderer", "sap/m/inputUtils/ListHelpers",
], function (ComboBox, ComboBoxRenderer, ListHelpers) {
  "use strict";
  return ComboBox.extend("com.melodysuite.dashboard.controls.ComboBoxExt", {

    renderer: ComboBoxRenderer,

    getDesign: function (item) {
      return item.getProperty("design");
    },

    /**
     * Maps items of <code>sap.ui.core.Item</code> type to <code>sap.m.StandardListItem</code> items.
     *
     * @param {sap.ui.core.Item} oItem The item to be matched
     * @returns {sap.m.StandardListItem | sap.m.GroupHeaderListItem | null} The matched StandardListItem
     * @private
     */
    _mapItemToListItem: function (oItem) {
      var oListItem = ListHelpers.createListItemFromCoreItem(oItem, this.getShowSecondaryValues());

      if (oItem.isA("sap.ui.core.Item")) {
        this.setSelectable(oItem, oItem.getEnabled());
      }

      if (oItem.isA("sap.ui.core.SeparatorItem")) {
        oListItem.addAriaLabelledBy(this._getGroupHeaderInvisibleText().getId());
      }
      if (this.getDesign(oItem) === "Bold") {
        oListItem.addStyleClass("sapCoreItemExtBold");
      }

      oListItem.addStyleClass(this.getRenderer().CSS_CLASS_COMBOBOXBASE + "NonInteractiveItem");
      return oListItem;
    }
  });

});
