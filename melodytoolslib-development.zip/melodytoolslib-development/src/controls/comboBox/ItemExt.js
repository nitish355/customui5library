sap.ui.define(["sap/ui/core/Item"],
  function (Item) {
    "use strict";

    return Item.extend("com.melody.lib.controls.comboBox.ItemExt", {
      metadata: {
        properties: {
          design: {
            type: "string",
            group: "data",
            defaultValue: ""
          },
          state: {
            type: "string",
            group: "data",
            defaultValue: ""
          }
        }
      },

      getDesign: function () {
        return this.getProperty("design");
      },

      getState: function () {
        return this.getProperty("state");
      }
    });
  });
