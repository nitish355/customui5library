/*!
 * ${copyright}
 */
// Provides control com.melody.lib.controls.TimeRecordButton.
sap.ui.define([
		"jquery.sap.global",
		"sap/ui/core/Control",
		"sap/ui/Device",
		"sap/ui/model/json/JSONModel",
		"com/melody/lib/util/Account",
		"com/melody/lib/enum/InputType",
		"sap/ui/core/Fragment",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"com/melody/lib/util/UserMaster",
		"com/melody/lib/util/MTR",
		"com/melody/lib/util/Activity",
		"sap/m/Button"
	],
	function (jQuery, Control, Device, JSONModel, AccountUtil, InputType, Fragment, Filter, FilterOperator, UserMaster, MTRUtil, ActivityUtil,
		Button) {
		"use strict";
		/**
		 * Constructor for a TimeRecordButton control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends sap/ui/core/Control
		 *
		 * @author SAP SE
		 * @version ${version}
		 *
		 * @constructor
		 * @private
		 * @alias com.melody.lib.controls.TimeRecordButton
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */
		let that;
		var TimeRecordButton = Button.extend("com.melody.lib.controls.mtr.TimeRecordButton", {
			metadata: {
				properties: {
					selectedActivity: {
						type: "object",
						defaultValue: null
					},

					entries: {
						type: "object",
						defaultValue: []
					}
				}
			},

			setEntries: function (aEntries) {
				this.getModel().setProperty("/Entries", aEntries);
				this.setProperty("entries", aEntries);
			},

			setSelectedActivity: function (oValue) {
				const that = this;
				const oModel = that.getModel();
				let oSelectedActivity = oValue
				if (!oSelectedActivity) {
					oSelectedActivity = null;
				}
				that.setProperty("selectedActivity", oSelectedActivity);
				oModel.setProperty("/SelectedActivity", oSelectedActivity);
				this.setBusy(true);
				that.validateActivity();
				that.setBusy(false);
			},

			openTimeRecordBox: function () {
				//const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				//let oUserMtrSettings = oStorage.get("userMtrSettings");
				const oModel = this.getModel();
				const that = this;
				MTRUtil.getUserMtrSettings().then(response => {
					const oUserMtrSettings = response.UserSetting;
					that._getMtrTasks()
						.then(aFilteredActivityTaskTypes => {
							const oSelectedActivity = that.getSelectedActivity();
							if (aFilteredActivityTaskTypes.length > 0 && oSelectedActivity) {
								const aActivityTaskTypesByRole = aFilteredActivityTaskTypes.find(item => item.RoleMpngID.toString() === oSelectedActivity.RoleMpngID
									.toString());
								if (aActivityTaskTypesByRole) {
									oSelectedActivity.ActTypeDesc = aActivityTaskTypesByRole.ActTypeDesc;
								} else {
									oSelectedActivity.ActTypeDesc = aFilteredActivityTaskTypes[0].ActTypeDesc;
								}
							}
							oModel.setData({
								UserSetting: oUserMtrSettings,
								MtrTasks: aFilteredActivityTaskTypes,
								SelectedDates: [],
								SelectedActivity: oSelectedActivity,
								SelectedMtrTask: null,
								SelectedLocationId: "",
								ShowCalendar: false,
								Entries: this.getEntries()
							});
							MTRUtil.loadTimeRecordingDialog(that, true, new JSONModel(oModel.getData()));
						});
				});

			},

			onPressTimeRecord: function (oEvent) {
				const oModel = this.getModel();
				const oUser = oModel.getProperty("/User");
				MTRUtil.loadTimeRecordingDialog(that, true, new JSONModel(oModel.getData()));
			},

			_generateModel: function () {
				let oUserMtrSettings = oStorage.get("userMtrSettings");
				const oModel = new JSONModel({
					UserSetting: oUserMtrSettings,
					MtrTasks: [],
					SelectedDates: [],
					SelectedActivity: this.getSelectedActivity(),
					SelectedMtrTask: null,
					SelectedLocationId: "",
					ShowCalendar: false,
					Entries: this.getEntries()
				});
			},

			init: function () {
				that = this;
				this.setVisible(false);
				this.setBusyIndicatorDelay(0);
				this.setBusy(true);
				const oModel = new JSONModel({
					User: null,
					UserSetting: null,
					MtrTasks: [],
					SelectedDates: [],
					SelectedActivity: null,
					SelectedMtrTask: null,
					SelectedLocationId: "",
					ShowCalendar: false,
					Entries: [{
						RecordDate: "04/11/2021",
						Task: "Business Development - CF",
						Location: "Virtual",
						Activity: "Demand Generation - PreBA",
						Type: "Cost Center: 0176000711",
						WorkDuration: "8.0"
					}, {
						RecordDate: "11/11/2021",
						Task: "Business Development - CF",
						Location: "Virtual",
						Activity: "Demand Generation - PreBA",
						Type: "Cost Center: 0176000711",
						WorkDuration: "8.0"
					}, {
						RecordDate: "12/11/2021",
						Task: "Business Development - CF",
						Location: "Virtual",
						Activity: "Demand Generation - PreBA",
						Type: "Cost Center: 0176000711",
						WorkDuration: "8.0"
					}]
				});

				this.setModel(oModel);

				this.setTooltip("Create Time Entry");

			},

			onAfterRendering: function () {
				/*setTimeout(function(){
					that.validateActivity(); 
				}, 1000);*/
			},

			validateActivity: async function () {
				const that = this;
				this.setVisible(false);
				const oModel = this.getModel();
				//const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);

				//let oUserMtrSettings = oStorage.get("userMtrSettings");
				const oUserMtrSettingsData = await MTRUtil.getUserMtrSettings();
				const oUserMtrSettings = oUserMtrSettingsData.UserSetting;
				oModel.setProperty("/UserSetting", oUserMtrSettings);

				if (!oUserMtrSettings || oUserMtrSettings.IsTimeRec) {
					//this.setEnabled(false);
					this.setVisible(false);
					return;
				}

				const oSelectedActivity = this.getSelectedActivity();

				const aUserActivities = await ActivityUtil.getUserActivities();

				const oActivity = aUserActivities.find(item => item.ActivityId && item.ActivityId !== "" && item.ActivityId === oSelectedActivity.ActivityId);

				if (oActivity && oActivity.ActivitySetStatus && oActivity.ActivitySetStatus !== "") {
					this.setVisible(false);
					this.setBusy(false);
					return;
				}

				this._getMtrTasks()
					.then(aFilteredActivityTaskTypes => {
						oModel.setProperty("/MtrTasks", aFilteredActivityTaskTypes);

						if (aFilteredActivityTaskTypes.length > 0 && oSelectedActivity.ActStatusDesc && (oSelectedActivity.ActStatusDesc.toUpperCase() ===
								"COMPLETED" ||
								oSelectedActivity.ActStatusDesc.toUpperCase() === "IN-PROCESS" || oSelectedActivity.ActStatusDesc.toUpperCase() ===
								"REGISTERED" || oSelectedActivity.ActStatusDesc.toUpperCase() === "CUSTOMER VALIDATED")) {
							that.setVisible(true);
						} else {
							that.setVisible(false);
						}
						that.setBusy(false);
					});

			},

			_getMtrTasks: async function () {
				const oSelectedActivity = this.getSelectedActivity();
				return await MTRUtil.filterMtrTasks(oSelectedActivity);
			},

			renderer: {
				render: function (oRm, oControl) {
					sap.m.ButtonRenderer.render(oRm, oControl);
				}
			}
		});

		return TimeRecordButton;
	}, /* bExport= */ true);