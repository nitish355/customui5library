sap.ui.define([
    "sap/m/Menu",
    "sap/m/MenuItem",
    "sap/ui/core/Control",
    "sap/m/BusyIndicator",
    "sap/ui/unified/MenuItem",
    "sap/ui/unified/MenuItemBase",
    "com/melody/lib/enum/Actions",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/resource/ResourceModel",
    "com/melody/lib/util/mtr/matrix/Matrix",
    "com/melody/lib/controls/mtr/TimeEntry/TimeEntryHelper",
], function (Menu, MenuItem, Control, BusyIndicator, MenuItemUnified, MenuItemBase, Actions, JSONModel, ResourceModel, MatrixUtil, TimeEntryHelper) {
    "use strict";
    let oControl;
    var TimeEntryMenuItem = MenuItem.extend("com.melody.lib.controls.mtr.TimeEntry.TimeEntryMenuItem", {
        metadata: {
            properties: {
                showBusyIndicator: {
                    type: "boolean",
                    defaultValue: true
                },
                selectedActivity: {
                    type: "object",
                    defaultValue: null
                },

                entries: {
                    type: "object",
                    defaultValue: []
                },

                mtrUid: {
                    type: "string",
                    defaultValue: ""
                },
                controlType: {
                    type: "string",
                    defaultValue: Actions.CreateTimeEntryMenu
                },
                statusId: {
                    type: "string",
                    defaultValue: ""
                }
            },
            aggregations: {
                MenuItem: {
                    type: "sap.ui.MenuItem",
                    multiple: false,
                    visibility: "hidden"
                }
            },
            events: {
                updateEntries: {
                    "updateEntries": {
                        type: "boolean"
                    }
                }
            }
        },

        setEntries: function (aEntries) {
            this.getModel().setProperty("/Entries", aEntries);
            this.setProperty("entries", aEntries);
        },

        setSelectedActivity: function (oValue) {
            const that = this;
            const oModel = that.getModel();
            let oSelectedActivity = oValue
            if (!oSelectedActivity) {
                oSelectedActivity = null;
            }
            that.setProperty("selectedActivity", oSelectedActivity);
            oModel.setProperty("/SelectedActivity", oSelectedActivity);
            this.setShowBusyIndicator(true);
            // TODO
            // if (oSelectedActivity) {
            TimeEntryHelper.validateActivity();
            // }
            this.setShowBusyIndicator(false);
        },

        openTimeRecordBox: function (bDontAllowSelectedActivity) {
            TimeEntryHelper.openTimeRecordBox(bDontAllowSelectedActivity);
        },

        onPressTimeRecord: function (oEvent) {
            TimeEntryHelper.onPressTimeRecord(oEvent);
        },

        _generateModel: function () {
            const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
            const oModel = new JSONModel({
                UserSetting: oUserMtrSettings,
                MtrTasks: [],
                SelectedDates: [],
                SelectedActivity: this.getSelectedActivity(),
                SelectedMtrTask: null,
                SelectedLocationId: "",
                ShowCalendar: false,
                Entries: this.getEntries()
            });
        },

        init: function () {
            MenuItem.prototype.init.apply(this, arguments);
            MatrixUtil.init(this);
            TimeEntryHelper.fnStaticInit(this);
            const oModel = new JSONModel();
            this.setModel(oModel);

            // if (this.getShowBusyIndicator()) {
            // this._busyIndicator = new BusyIndicator({
            // size: "1rem"
            // }).addStyleClass("myCustomBusyIndicator");

            // this.$().append(this._busyIndicator.$());
            // }
        },

        onAfterRendering: function (oEvent) { // MenuItem.prototype.onAfterRendering.apply(this, arguments);

        },

        setShowBusyIndicator: function (bValue) { // myBusyIndicator
            this.setProperty("showBusyIndicator", bValue);
        },

        // Function to fire event to application from library
        fnTriggerUpdateEntries: function () {
            this.fireEvent("updateEntries", { updateEntries: true });
        },

        // Render Function
        // renderer: {
        //     render: function (oRm, oControl) {
        //         TimeEntryMenuItemRenderer.render(oRm, oControl);
        //     }
        // }

    });

    return TimeEntryMenuItem;
});
