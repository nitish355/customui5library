sap.ui.define([
	"sap/m/Button",
	"sap/ui/Device",
	"sap/m/MessageToast",
	"sap/ui/core/Control",
	"sap/ui/model/Filter",
	"sap/ui/core/Fragment",
	"com/melody/lib/util/mtr/MTR",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"com/melody/lib/enum/Actions",
	"com/melody/lib/util/Account",
	"com/melody/lib/util/Activity",
	"sap/base/i18n/ResourceBundle",
	"com/melody/lib/enum/InputType",
	"com/melody/lib/util/UserMaster",
	"com/melody/lib/classes/mtr/Entry",
	"com/melody/lib/util/mtr/MTRHelper",
	"com/melody/lib/util/mtr/MTRModels",
	"com/melody/lib/service/OREService",
	"com/melody/lib/service/DateService",
	"sap/ui/model/resource/ResourceModel",
	"com/melody/lib/util/mtr/matrix/Matrix",
], function (Button, Device, MessageToast, Control, Filter, Fragment, MTRUtil, FilterOperator, JSONModel, Actions, Account, ActivityUtil,
	ResourceBundle, InputType,
	UserMaster, Entry, MTRHelper, MTRModels, OREService, DateService, ResourceModel, MatrixUtil) {
	"use strict";

	return {

		//oMenuItemController points the parent "this" pointer
		fnStaticInit: function (oParentRef) {
			//oMenuItemController points to the parent controller
			this.oMenuItemController = oParentRef;
		},

		//function to _SetModel
		_setModel: function (entry, filteredActivityTaskTypes) {
			const that = this;
			const oModel = this.oMenuItemController.getModel();
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
			const expected = oDayWeekTimesheetModel.getProperty("/Expected");
			const submitted = oDayWeekTimesheetModel.getProperty("/Submitted");
			const saved = oDayWeekTimesheetModel.getProperty("/Saved");

			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const aMTRTasks = oSettingsModel.getProperty("/MTRTasks");

			const oSelectedActivity = this.oMenuItemController.getSelectedActivity();
			oModel.setData({
				// UserSetting: oUserMtrSettings,
				MtrTasks: filteredActivityTaskTypes,
				SelectedDates: [],
				SelectedActivity: oSelectedActivity,
				SelectedMtrTask: null,
				SelectedLocationId: "",
				ShowCalendar: false,
				Entries: aEntries,
				i18n: this.oMenuItemController.getModel("i18n"),
				Entry: entry,
				Expected: expected,
				Submitted: submitted,
				Saved: saved,
				MTRTasks: aMTRTasks,
				MtrUid: this.oMenuItemController.getMtrUid()
			});

			return oModel;
		},

		//function to open Time RecordBox
		openTimeRecordBox: async function (bDontAllowSelectedActivity) {
			let that = this;
			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const MatrixViewAccess = oSettingsModel.getProperty("/MatrixViewAccess");
			if (MatrixViewAccess === "") {
				setTimeout(function () {
					that.validateAndLoadMatrixDialog(bDontAllowSelectedActivity);
				}, 2500);
			} else {
				this.validateAndLoadMatrixDialog(bDontAllowSelectedActivity);
			}

		},

		validateAndLoadMatrixDialog: async function (bDontAllowSelectedActivity) {
			try {
				let oMatrixEntry = {
					"isMatrixEditList": false,
					"activeTab": Actions.matrixCategory.activity,
					"taskId": "",
					"activityId": "",
					"startDate": new Date(),
					"costTypeId": "",
					"costTypeValue": ""
				};
				const oSettingsModel = MTRModels.getMTRSettingsModel();
				const sUserId = oSettingsModel.getProperty("/UserId");
				let MatrixViewAccess = oSettingsModel.getProperty("/MatrixViewAccess");
				const matrixModel = MTRModels.getMatrixModel();
				let oTimeRecordingOption = await OREService.getTimeSheetPreference(sUserId) || {};
				let sHash = window.location.hash;
				let sRoute = sHash.split("?")[0].substring(1);
				let sQuery = sHash.split("?")[1] || "";
				var isMelodyTime = sQuery.search("MelodyActivityTime") === -1 ? false : true;
				if (sRoute === "pc-app" && isMelodyTime) {
					MatrixViewAccess = "X";
					oTimeRecordingOption.Value = "1";
				}
				const isMatrixView = ("Value" in oTimeRecordingOption && oTimeRecordingOption.Value === "1" && MatrixViewAccess === "X") ? true :
					false;
				const that = this;
				if (bDontAllowSelectedActivity) {
					that.oMenuItemController.setSelectedActivity(null);
				}
				this._validate().then(isValid => {
					if (!isValid) {
						return;
					}
					if (!isMatrixView) {
						MTRUtil.filterEntries();
					}
					const oSelectedActivity = that.oMenuItemController.getSelectedActivity();

					let dDate = new Date();
					if (oSelectedActivity && oSelectedActivity.StartDate) {
						let actStartDate = new Date(oSelectedActivity.StartDate);
						if (actStartDate >= dDate) {
							dDate = (oSelectedActivity.StartDate) ? oSelectedActivity.StartDate : new Date();
						}
					}
					let sDate = DateService.getInstance().format(dDate, "yMMdd");
					let oEntry = new Entry({
						RecordDate: sDate
					});
					if (oSelectedActivity) {
						that._getMtrTasks().then(aFilteredActivityTaskTypes => {
							if (aFilteredActivityTaskTypes.length > 0 && oSelectedActivity) {
								const aActivityTaskTypesByRole = aFilteredActivityTaskTypes.find(item => item.RoleMpngID.toString() === oSelectedActivity.RoleMpngID
									.toString());
								if (aActivityTaskTypesByRole) {
									oSelectedActivity.ActTypeDesc = aActivityTaskTypesByRole.ActTypeDesc;
								} else {
									oSelectedActivity.ActTypeDesc = aFilteredActivityTaskTypes[0].ActTypeDesc;
								}
							}

							const oModel = that._setModel(oEntry, aFilteredActivityTaskTypes);
							oEntry.setMelodyActivity(oSelectedActivity.ActivityId, oModel);
							if (isMatrixView) {
								if (matrixModel) {
									oMatrixEntry.isMatrixEditList = (oSelectedActivity.ActivityId) ? true : false;
									oMatrixEntry.activityId = (oSelectedActivity.ActivityId) ? oSelectedActivity.ActivityId : "";
									oMatrixEntry.costTypeValue = (oSelectedActivity.CostTypeValue) ? oSelectedActivity.CostTypeValue : "";
									matrixModel.setProperty("/defaultEntry", oMatrixEntry);
									matrixModel.refresh();
								}
								MatrixUtil.loadMatrixTimeRecordingDialog(null, that.oMenuItemController);
							} else {
								MTRHelper.loadTimeRecordingDialog(that.oMenuItemController, true, oModel);
							}
						});
					} else {
						const oModel = that._setModel(oEntry);
						if (isMatrixView) {
							if (matrixModel) {
								const aValidActivityTaskId = MatrixUtil.getEntriesTaskIds().activityTaskId || [];
								const aValidLearningTaskId = MatrixUtil.getEntriesTaskIds().learningTaskIds || [];
								if (that.oMenuItemController.getMtrUid()) {
									oMatrixEntry = that.fnGetActivityDataForMatrix(that.oMenuItemController.getMtrUid(), "MYTIME");
									let taskId = (oMatrixEntry.taskId) ? parseInt(oMatrixEntry.taskId) : 0;
									if (aValidLearningTaskId.length && aValidLearningTaskId.indexOf(taskId) === -1 && !oMatrixEntry.activityId) {
										MessageToast.show("Please select Edit from MTR.");
										return;
									}
								}
								matrixModel.setProperty("/defaultEntry", oMatrixEntry);
								matrixModel.refresh();
							}
							MatrixUtil.loadMatrixTimeRecordingDialog(null, that.oMenuItemController);
						} else {
							MTRHelper.loadTimeRecordingDialog(that.oMenuItemController, true, oModel);
						}
					}
				});
			} catch (error) {
				console.log("ERROR in openTimeRecordBox : ", error);
			}

		},

		//Function to return activity-Id and Start Date Based MTRUID for Matrix
		fnGetActivityDataForMatrix: function (mtrUid = "", appType) {
			let defaultEntry = {
				"isMatrixEditList": false,
				"taskId": "",
				"activeTab": Actions.matrixCategory.activity,
				"activityId": "",
				"startDate": new Date(),
				"costTypeId": "",
				"costTypeValue": ""
			};
			if (!mtrUid) {
				return defaultEntry;
			}
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const aEntries = oDayWeekTimesheetModel.getProperty("/Entries") || [];
			const oEntry = aEntries.find((entry) => entry.MtrUid === mtrUid) || false;
			const genericDateFormat = sap.ui.core.format.DateFormat.getInstance({
				pattern: "yMMdd",
				calendarType: sap.ui.core.CalendarType.Gregorian
			});
			if (oEntry) {
				//Activity
				if ("ActvtId" in oEntry && oEntry.ActvtId) {
					return {
						"isMatrixEditList": true,
						"taskId": oEntry.TaskId,
						"activeTab": Actions.matrixCategory.activity,
						"activityId": oEntry.ActvtId,
						"startDate": (appType === "MYTIME") ? DateService.getInstance().formatStringDate(oEntry.RecordDate) : new Date(),
						"costTypeId": (oEntry.CostTypeId) ? oEntry.CostTypeId.toString() : "",
						"costTypeValue": oEntry.CostTypeValue
					};
				} else {
					//Learning
					return {
						"isMatrixEditList": true,
						"taskId": oEntry.TaskId,
						"activeTab": Actions.matrixCategory.learning,
						"activityId": "",
						"startDate": DateService.getInstance().formatStringDate(oEntry.RecordDate),
						"costTypeId": (oEntry.CostTypeId) ? oEntry.CostTypeId.toString() : "",
						"costTypeValue": oEntry.CostTypeValue
					};
				}
			}
			return defaultEntry;
		},

		//function to handle Press Time Record
		onPressTimeRecord: function (oEvent) {
			const oModel = this.oMenuItemController.getModel();
			const oUser = oModel.getProperty("/User");
			MTRHelper.loadTimeRecordingDialog(this.oMenuItemController, true, new JSONModel(oModel.getData()));
		},

		//function to handle _generateModel
		_generateModel: function () {
			let oUserMtrSettings = oStorage.get("userMtrSettings");
			const oModel = new JSONModel({
				UserSetting: oUserMtrSettings,
				MtrTasks: [],
				SelectedDates: [],
				SelectedActivity: this.oMenuItemController.getSelectedActivity(),
				SelectedMtrTask: null,
				SelectedLocationId: "",
				ShowCalendar: false,
				Entries: this.oMenuItemController.getEntries()
			});
		},

		//function to validate activities
		_validate: async function () {
			let bIsValid = false;
			if (!this.oMenuItemController.getVisible() && !this.oMenuItemController.getStatusId()) {
				return false;
			}
			const oModel = this.oMenuItemController.getModel();
			const oUserMtrSettingsData = await MTRHelper.getUserMtrSettings();
			const oSettingsModel = MTRModels.getMTRSettingsModel();

			const oSettings = oSettingsModel.getData();

			oModel.setProperty("/Settings", oSettings);
			if (!oSettings || oSettings.ActivityRecording !== "1") {
				bIsValid = false;
				return bIsValid;
			}

			const oSelectedActivity = this.oMenuItemController.getSelectedActivity();

			if (!oSelectedActivity && !this.oMenuItemController.getStatusId()) {
				bIsValid = true;
				return bIsValid;
			}

			if (oSelectedActivity && oSelectedActivity.hasOwnProperty("IsOnlyRequestor") && oSelectedActivity.IsOnlyRequestor === "X") {
				bIsValid = false;
				return bIsValid;
			}

			const aUserActivities = await ActivityUtil.getUserActivities();

			const oActivity = aUserActivities.find(item => item.ActivityId && item.ActivityId !== "" && oSelectedActivity && item.ActivityId ===
				oSelectedActivity.ActivityId);

			if (!oActivity || (oActivity && oActivity.ActivitySetStatus && oActivity.ActivitySetStatus !== "")) {
				bIsValid = false;
				return bIsValid;
			}
			let bVisibile = false;
			const aActivityTaskTypes = await this._getMtrTasks();
			if (aActivityTaskTypes && aActivityTaskTypes.length > 0) {
				oModel.setProperty("/MtrTasks", aActivityTaskTypes);
				let activityStatus = ("ActStatusDesc" in oSelectedActivity) ? oSelectedActivity.ActStatusDesc : "";
				activityStatus = (activityStatus) ? activityStatus.toUpperCase() : "";
				let aStatusValidations = ["COMPLETED", "IN-PROCESS", "REGISTERED", "CUSTOMER VALIDATED", "STARTED", "PROGRESSING", "VALIDATED",
					"PRESENTED", "CANCELLED"
				];
				if (activityStatus && aStatusValidations.indexOf(activityStatus) !== -1) {
					bVisibile = true;
				}
			}

			bIsValid = bVisibile;
			return bIsValid;
		},

		//function to handle validation of Activities
		validateActivity: async function () {
			const bIsValid = await this._validate();
			let sText = this.oMenuItemController.getText();
			if (bIsValid && sText === "Loading....") {
				sText = "Create Time Entry";
				this.oMenuItemController.setEnabled(true);
				this.oMenuItemController.setIcon("sap-icon://create-entry-time");
			}
			this.oMenuItemController.setText(sText);
			this.oMenuItemController.setVisible(bIsValid);
		},

		//function to get MTR Tasks
		_getMtrTasks: async function () {
			const oSelectedActivity = this.oMenuItemController.getSelectedActivity();
			return await MTRHelper.filterMtrTasks(oSelectedActivity);
		},

		//function to get savedEntries
		fnGetSavedEntries: async function (oMTRModel) {
			let response = await MTRUtil.getUserMtrSettings();
			if (response && response.UserSetting) {
				var oUserSetting = response.UserSetting;
				let oResponse = await MTRUtil.getEntries(oUserSetting.UserGuid);
				return oResponse;
			}
		},

	};
}, true);