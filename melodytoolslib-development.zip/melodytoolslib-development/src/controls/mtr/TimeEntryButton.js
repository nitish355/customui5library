/*!
 * ${copyright}
 */
// Provides control com.melody.lib.controls.TimeRecordButton.
sap.ui.define([
		"jquery.sap.global",
		"sap/ui/core/Control",
		"sap/ui/Device",
		"sap/ui/model/json/JSONModel",
		"com/melody/lib/util/Account",
		"com/melody/lib/enum/InputType",
		"sap/ui/core/Fragment",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"com/melody/lib/util/UserMaster",
		"com/melody/lib/util/mtr/MTRHelper",
		"com/melody/lib/util/Activity",
		"sap/m/Button",
		"com/melody/lib/util/mtr/MTRModels",
		"sap/ui/model/resource/ResourceModel",
		"sap/base/i18n/ResourceBundle",
		"com/melody/lib/classes/mtr/Entry",
		"com/melody/lib/service/OREService",
		"com/melody/lib/service/DateService",
		"com/melody/lib/util/mtr/MTR",
		"com/melody/lib/util/mtr/matrix/Matrix",
		"com/melody/lib/enum/Actions",
		"sap/m/MessageToast",
	],
	function (jQuery, Control, Device, JSONModel, AccountUtil, InputType, Fragment, Filter, FilterOperator, UserMaster, MTRHelper,
		ActivityUtil,
		Button, MTRModels, ResourceModel, ResourceBundle, Entry, OREService, DateService, MTRUtil, MatrixUtil, Actions, MessageToast) {
		"use strict";
		/**
		 * Constructor for a TimeRecordButton control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends sap/ui/core/Control
		 *
		 * @author SAP SE
		 * @version ${version}
		 *
		 * @constructor
		 * @private
		 * @alias com.melody.lib.controls.TimeRecordButton
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */
		let oThisController;
		var TimeRecordButton = Button.extend("com.melody.lib.controls.mtr.TimeEntryButton", {
			metadata: {
				properties: {
					selectedActivity: {
						type: "object",
						defaultValue: null
					},

					entries: {
						type: "object",
						defaultValue: []
					},

					mtrUid: {
						type: "string",
						defaultValue: ""
					},

					statusId: {
						type: "string",
						defaultValue: ""
					},
				},
				events: {
					updateEntries: {
						"updateEntries": {
							type: "boolean"
						}
					}
				},
			},

			setEntries: function (aEntries) {
				this.getModel().setProperty("/Entries", aEntries);
				this.setProperty("entries", aEntries);
			},

			setSelectedActivity: function (oValue) {
				const oThisController = this;
				const oModel = oThisController.getModel();
				let oSelectedActivity = oValue
				if (!oSelectedActivity) {
					oSelectedActivity = null;
				}
				oThisController.setProperty("selectedActivity", oSelectedActivity);
				oModel.setProperty("/SelectedActivity", oSelectedActivity);
				this.setBusy(true);
				// if (oSelectedActivity) {
				oThisController.validateActivity();
				// }
				// oThisController.setBusy(false);
			},

			_setModel: function (entry, filteredActivityTaskTypes) {
				const oThisController = this;
				const oModel = this.getModel();
				const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
				const expected = oDayWeekTimesheetModel.getProperty("/Expected");
				const submitted = oDayWeekTimesheetModel.getProperty("/Submitted");
				const saved = oDayWeekTimesheetModel.getProperty("/Saved");

				const oSettingsModel = MTRModels.getMTRSettingsModel();
				const aMTRTasks = oSettingsModel.getProperty("/MTRTasks");

				const oSelectedActivity = this.getSelectedActivity();

				oModel.setData({
					// UserSetting: oUserMtrSettings,
					MtrTasks: filteredActivityTaskTypes,
					SelectedDates: [],
					SelectedActivity: oSelectedActivity,
					SelectedMtrTask: null,
					SelectedLocationId: "",
					ShowCalendar: false,
					Entries: aEntries,
					i18n: this.getModel("i18n"),
					Entry: entry,
					Expected: expected,
					Submitted: submitted,
					Saved: saved,
					MTRTasks: aMTRTasks,
					MtrUid: oThisController.getMtrUid()
				});

				return oModel;
			},

			openTimeRecordBox: async function (oEvent) {

				try {
					let oMatrixEntry = {
						"isMatrixEditList": false,
						"activeTab": Actions.matrixCategory.activity,
						"taskId": "",
						"activityId": "",
						"startDate": new Date(),
						"costTypeId": "",
						"costTypeValue": ""
					};
					const oSettingsModel = MTRModels.getMTRSettingsModel();
					const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
					const sUserId = oSettingsModel.getProperty("/UserId");
					const MatrixViewAccess = oSettingsModel.getProperty("/MatrixViewAccess");
					const matrixModel = MTRModels.getMatrixModel();
					let oTimeRecordingOption = await OREService.getTimeSheetPreference(sUserId) || {};
					const isMatrixView = ("Value" in oTimeRecordingOption && oTimeRecordingOption.Value === "1" && MatrixViewAccess === "X") ? true :
						false;
					this.setBusy(true);
					const oThisController = this;
					this._validate().then(isValid => {
						if (!isMatrixView) {
							MTRUtil.filterEntries();
						}
						const oSelectedActivity = oThisController.getSelectedActivity();

						let dDate = new Date();
						if (oSelectedActivity && oSelectedActivity.StartDate) {
							let actStartDate = new Date(oSelectedActivity.StartDate);
							if (actStartDate >= dDate) {
								dDate = (oSelectedActivity.StartDate) ? oSelectedActivity.StartDate : new Date();
							}
						}
						let sDate = DateService.getInstance().format(dDate, "yMMdd");
						let oEntry = new Entry({
							RecordDate: sDate
						});
						if (oSelectedActivity) {
							oThisController._getMtrTasks().then(aFilteredActivityTaskTypes => {
								if (aFilteredActivityTaskTypes.length > 0 && oSelectedActivity) {
									const aActivityTaskTypesByRole = aFilteredActivityTaskTypes.find(item => item.RoleMpngID.toString() ===
										oSelectedActivity.RoleMpngID
										.toString());
									if (aActivityTaskTypesByRole) {
										oSelectedActivity.ActTypeDesc = aActivityTaskTypesByRole.ActTypeDesc;
									} else {
										oSelectedActivity.ActTypeDesc = aFilteredActivityTaskTypes[0].ActTypeDesc;
									}
								}

								const oModel = oThisController._setModel(oEntry, aFilteredActivityTaskTypes);
								oEntry.setMelodyActivity(oSelectedActivity.ActivityId, oModel);
								if (isMatrixView) {
									oThisController.setBusy(false);
									if (matrixModel) {
										oMatrixEntry.isMatrixEditList = (oSelectedActivity.ActivityId) ? true : false;
										oMatrixEntry.activityId = (oSelectedActivity.ActivityId) ? oSelectedActivity.ActivityId : "";
										oMatrixEntry.costTypeValue = (oSelectedActivity.CostTypeValue) ? oSelectedActivity.CostTypeValue : "";
										matrixModel.setProperty("/defaultEntry", oMatrixEntry);
										matrixModel.refresh();
									}
									MatrixUtil.loadMatrixTimeRecordingDialog(null, oThisController);
								} else {
									MTRHelper.loadTimeRecordingDialog(oThisController, true, oModel);
								}
							});
						} else {
							const oModel = oThisController._setModel(oEntry);
							if (isMatrixView) {
								oThisController.setBusy(false);
								if (matrixModel) {
									const aValidActivityTaskId = MatrixUtil.getEntriesTaskIds().activityTaskId || [];
									const aValidLearningTaskId = MatrixUtil.getEntriesTaskIds().learningTaskIds || [];
									if (oThisController.getMtrUid()) {
										oMatrixEntry = oThisController.fnGetActivityDataForMatrix(oThisController.getMtrUid(), "MYTIME");
										let taskId = (oMatrixEntry.taskId) ? parseInt(oMatrixEntry.taskId) : 0;
										if (aValidLearningTaskId.length && aValidLearningTaskId.indexOf(taskId) === -1 && !oMatrixEntry.activityId) {
											MessageToast.show("Please select Edit from MTR.");
											return;
										}
									}
									matrixModel.setProperty("/defaultEntry", oMatrixEntry);
									matrixModel.refresh();
								}
								MatrixUtil.loadMatrixTimeRecordingDialog(null, oThisController);
							} else {
								MTRHelper.loadTimeRecordingDialog(oThisController, true, oModel);
							}
						}

					});
				} catch (error) {
					console.log("ERROR IN openTimeRecordBox : ", error)
				}
			},

			//Function to return activity-Id and Start Date Based MTRUID for Matrix
			fnGetActivityDataForMatrix: function (mtrUid = "", appType) {
				let defaultEntry = {
					"isMatrixEditList": false,
					"taskId": "",
					"activeTab": Actions.matrixCategory.activity,
					"activityId": "",
					"startDate": new Date(),
					"costTypeId": "",
					"costTypeValue": ""
				};
				if (!mtrUid) {
					return defaultEntry;
				}
				const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				const aEntries = oDayWeekTimesheetModel.getProperty("/Entries") || [];
				const oEntry = aEntries.find((entry) => entry.MtrUid === mtrUid) || false;
				const genericDateFormat = sap.ui.core.format.DateFormat.getInstance({
					pattern: "yMMdd",
					calendarType: sap.ui.core.CalendarType.Gregorian
				});
				if (oEntry) {
					//Activity
					if ("ActvtId" in oEntry && oEntry.ActvtId) {
						return {
							"isMatrixEditList": true,
							"taskId": oEntry.TaskId,
							"activeTab": Actions.matrixCategory.activity,
							"activityId": oEntry.ActvtId,
							"startDate": (appType === "MYTIME") ? DateService.getInstance().formatStringDate(oEntry.RecordDate) : new Date(),
							"costTypeId": (oEntry.CostTypeId) ? oEntry.CostTypeId.toString() : "",
							"costTypeValue": oEntry.CostTypeValue
						};
					} else {
						//Learning
						return {
							"isMatrixEditList": true,
							"taskId": oEntry.TaskId,
							"activeTab": Actions.matrixCategory.learning,
							"activityId": "",
							"startDate": DateService.getInstance().formatStringDate(oEntry.RecordDate),
							"costTypeId": (oEntry.CostTypeId) ? oEntry.CostTypeId.toString() : "",
							"costTypeValue": oEntry.CostTypeValue
						};
					}
				}
				return defaultEntry;
			},

			onPressTimeRecord: function (oEvent) {
				const oModel = this.getModel();
				const oUser = oModel.getProperty("/User");
				MTRHelper.loadTimeRecordingDialog(oThisController, true, new JSONModel(oModel.getData()));
			},

			_generateModel: function () {
				let oUserMtrSettings = oStorage.get("userMtrSettings");
				const oModel = new JSONModel({
					UserSetting: oUserMtrSettings,
					MtrTasks: [],
					SelectedDates: [],
					SelectedActivity: this.getSelectedActivity(),
					SelectedMtrTask: null,
					SelectedLocationId: "",
					ShowCalendar: false,
					Entries: this.getEntries()
				});
			},

			init: function () {
				// oThisController = this;
				// this.setVisible(false);
				this.setBusyIndicatorDelay(0);
				this.setBusy(true);

				// set i18n model on view
				var i18nModel = new ResourceModel({
					bundleName: "com.melody.lib.i18n.i18n"
				});
				this.setModel(i18nModel, "i18n");

				MatrixUtil.init(this);

				const oModel = new JSONModel({
					User: null,
					UserSetting: null,
					MtrTasks: [],
					SelectedDates: [],
					SelectedActivity: null,
					SelectedMtrTask: null,
					SelectedLocationId: "",
					ShowCalendar: false,
					Entries: [{
						RecordDate: "04/11/2021",
						Task: "Business Development - CF",
						Location: "Virtual",
						Activity: "Demand Generation - PreBA",
						Type: "Cost Center: 0176000711",
						WorkDuration: "8.0"
					}, {
						RecordDate: "11/11/2021",
						Task: "Business Development - CF",
						Location: "Virtual",
						Activity: "Demand Generation - PreBA",
						Type: "Cost Center: 0176000711",
						WorkDuration: "8.0"
					}, {
						RecordDate: "12/11/2021",
						Task: "Business Development - CF",
						Location: "Virtual",
						Activity: "Demand Generation - PreBA",
						Type: "Cost Center: 0176000711",
						WorkDuration: "8.0"
					}]
				});

				this.setModel(oModel);

				this.setTooltip("Create Time Entry");

			},

			onAfterRendering: function () {},

			_validate: async function () {
				let bIsValid = false;
				if (!this.getVisible() && !this.getStatusId()) {
					return false;
				}
				const oModel = this.getModel();
				const oUserMtrSettingsData = await MTRHelper.getUserMtrSettings();
				const oSettingsModel = MTRModels.getMTRSettingsModel();

				const oSettings = oSettingsModel.getData();

				oModel.setProperty("/Settings", oSettings);

				if (!oSettings || oSettings.ActivityRecording !== "1") {
					bIsValid = false;
					return bIsValid;
				}

				const oSelectedActivity = this.getSelectedActivity();

				if (!oSelectedActivity && !this.getStatusId()) {
					bIsValid = true;
					return bIsValid;
				}

				if (oSelectedActivity && oSelectedActivity.hasOwnProperty("IsOnlyRequestor") && oSelectedActivity.IsOnlyRequestor === "X") {
					bIsValid = false;
					return bIsValid;
				}

				const aUserActivities = await ActivityUtil.getUserActivities();

				const oActivity = aUserActivities.find(item => item.ActivityId && item.ActivityId !== "" && oSelectedActivity && item.ActivityId ===
					oSelectedActivity.ActivityId);

				if (!oActivity || (oActivity && oActivity.ActivitySetStatus && oActivity.ActivitySetStatus !== "")) {
					bIsValid = false;
					return bIsValid;
				}
				let bVisibile = false;
				const aActivityTaskTypes = await this._getMtrTasks();
				if (aActivityTaskTypes && aActivityTaskTypes.length > 0) {
					oModel.setProperty("/MtrTasks", aActivityTaskTypes);
					let activityStatus = ("ActStatusDesc" in oSelectedActivity) ? oSelectedActivity.ActStatusDesc : "";
					activityStatus = (activityStatus) ? activityStatus.toUpperCase() : "";
					let aStatusValidations = ["COMPLETED", "IN-PROCESS", "REGISTERED", "CUSTOMER VALIDATED", "STARTED", "PROGRESSING", "VALIDATED",
						"PRESENTED", "CANCELLED"
					];
					if (activityStatus && aStatusValidations.indexOf(activityStatus) !== -1) {
						bVisibile = true;
					}
				}

				bIsValid = bVisibile;
				return bIsValid;
			},

			validateActivity: async function () {
				const bIsValid = await this._validate();
				this.setVisible(bIsValid);
				this.setBusy(false);
			},

			_getMtrTasks: async function () {
				const oSelectedActivity = this.getSelectedActivity();
				return await MTRHelper.filterMtrTasks(oSelectedActivity);
			},

			fnTriggerUpdateEntries: function () {
				this.fireEvent("updateEntries", {
					updateEntries: true
				});
			},

			renderer: {
				render: function (oRm, oControl) {
					sap.m.ButtonRenderer.render(oRm, oControl);
				}
			}
		});

		return TimeRecordButton;
	}, /* bExport= */ true);