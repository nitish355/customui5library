/*!
 * ${copyright}
 */

// Provides control com.melody.lib.
sap.ui.define(["jquery.sap.global",
	"sap/ui/Device",
	"sap/ui/core/Control",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"com/melody/lib/enum/Actions",
	"com/melody/lib/enum/InputType",
	"com/melody/lib/model/StorageModel",
	"com/melody/lib/util/account/Account",
	"com/melody/lib/util/opportunity/VATTeam",
	"com/melody/lib/util/opportunity/MSLExists",
	"com/melody/lib/util/opportunity/Opportunity",
	"com/melody/lib/util/opportunity/OpportunityHelper",
	"com/melody/lib/util/opportunity/DiscontinuedOpportunity",
	"com/melody/lib/util/opportunity/OpportunityDialogController",
],
	function (jQuery, Device, Control, MessageToast, Fragment, JSONModel, Actions, InputType, oStorageModel, AccountUtil, VATTeamUtil,
		MSLExistUtil,
		OpportunityUtil,
		OpportunityHelper,
		DiscontinuedOpportunity,
		OpportunityDialogController) {
		"use strict";

		/**
		 * Constructor for a new OpportunityControlRenderer Control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends  Control
		 *
		 * @author SAP SE
		 * @version ${version}
		 *
		 * @constructor
		 * @public
		 * @alias com.melody.lib.controls.OpportunityControlRenderer
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */

		let that;
		var oOpportunityControl = Control.extend("com.melody.lib.controls.OpportunityControl", {
			metadata: {
				properties: {
					selectedOpportunity: {
						type: "object",
						defaultValue: null
					},
					opportunityId: {
						type: "string",
						defaultValue: null
					},
					accountCtrlId: {
						type: "string",
						defaultValue: null
					},
					opportunity: {
						type: "boolean",
						defaultValue: true
					},
					projectType: {
						type: "string",
						defaultValue: null
					},
					editable: {
						type: "boolean",
						defaultValue: true
					},
					controlType: {
						type: "string",
						defaultValue: Actions.Input
					},
					icon: {
						type: "string",
						defaultValue: null
					},
					showMSLExist: {
						type: "boolean",
						defaultValue: false
					},
					_showClearIcon: {
						type: "boolean",
						defaultValue: false,
					},
					_showInfoIcon: {
						type: "boolean",
						defaultValue: false,
					},
					executeOnChangeId: {
						type: "boolean",
						defaultValue: false,
					},
					applicationType: {
						type: "string",
						defaultValue: "ACTVT"
					},
					placeholder: {
						type: "string",
						defaultValue: ""
					}
				},
				events: {
					valueHelpRequest: {},
					selectedItem: {
						"opportunityData": {
							type: "object"
						},
						"opportunityDataHandler": {
							type: "object"
						}
					},
					clearSelectedItem: {
						"reset": {
							type: "boolean"
						}
					}
				},
				aggregations: {
					_input: {
						type: "sap.m.Input",
						multiple: false,
						visibility: "hidden"
					},
					_button: {
						type: "sap.m.Button",
						multiple: false,
						visibility: "hidden"
					},
					_opportunityinfobutton: {
						type: "sap.ui.core.Icon",
						multiple: false,
						visibility: "hidden"
					},
					_clearIcon: {
						type: "sap.ui.core.Icon",
						multiple: false,
						visibility: "hidden"
					},
					_icon: {
						type: "sap.ui.core.Icon",
						multiple: false,
						visibility: "hidden"
					}
				}
			},

			/**
			 * @private
			 * @author DARSHAN
			 * @function setEditable
			 * @description function to set editable to opportunity fields
			 * @param {Boolean} bVisible
			 */
			setEditable: function (bEditable = false) {
				this.setProperty("editable", bEditable);
				let inputContrl = this.getAggregation("_input");
				let selectedOpportunity = this.getProperty("selectedOpportunity") || {};
				let controlOpportunityId = "OpportunityId" in selectedOpportunity ? selectedOpportunity.OpportunityId : "";
				//TO Handle toggle between editable true or false
				if (controlOpportunityId && bEditable) {
					this._setControlVisibility("EDIT");
				}
				if (inputContrl) {
					inputContrl.setEditable(bEditable);
				}
			},

			setPlaceholder: function (sValue) {
				this.setProperty("placeholder", sValue, true);
				const oInput = this.getAggregation("_input");
				if (oInput) {
					oInput.setPlaceholder(sValue || "");
				}
			},

			/**
			 * @private
			 * @author DARSHAN
			 * @function executeOnChangeId
			 * @description function to decide fire event
			 * @param {Boolean} bFire
			 * This case is needed in MTR Matrix list view
			 */
			setExecuteOnChangeId: function (bEditable = false) {
				this.setProperty("executeOnChangeId", bEditable);
			},

			/**
			 * @public
			 * @author DARSHAN
			 * @function setApplicationType
			 * @description function to set application Type
			 * @param {Boolean} bVisible
			 * This has be improvised during new implementation or in BAS Library
			 */
			setApplicationType: function (type) {
				this.setProperty("applicationType", type);
			},

			/**
			 * @private
			 * @author DARSHAN
			 * @function setOpportunityId
			 * @description function to set editable to opportunity fields
			 * @param {String} opportunityId
			 * Need to Improve this
			 */
			setOpportunityId: function (opportunityId) {
				// setTimeout(function (opportunityId) {
				if (opportunityId === null) {
					return;
				}
				this.setProperty("opportunityId", opportunityId);
				if (!opportunityId) {
					this.setSelectedOpportunity();
					return;
				}
				const editable = this.getProperty("editable");
				let controlType = this.getProperty("controlType");
				let applicationType = this.getProperty("applicationType");
				controlType = (controlType) ? controlType.toUpperCase() : "";
				let selectedOpportunity = this.getProperty("selectedOpportunity") || {};

				//Matrix view
				if (applicationType === Actions.applicationType.matrix && controlType === Actions.Icon) {
					return;
				}

				if (opportunityId) {
					this.setBusy(true);
					this.setInputBusy(true);
					const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
					let aLibOpportunties = oStorage.get("pcLibOpportunties") || [];
					if (aLibOpportunties.length) {
						let oOpportunityData = aLibOpportunties.find((item) => {
							return item.OpportunityId === opportunityId
						}) || false;

						if (oOpportunityData) {
							let execute = this.getProperty("executeOnChangeId") || false;
							this.setSelectedOpportunity(oOpportunityData, execute);
							this.setInputBusy(false);
							this.setBusy(false);
						} else {
							if (editable) {
								this._fnHelpToFetchOpportunityData(opportunityId);
							}
						}
					} else {
						if (editable) {
							this._fnHelpToFetchOpportunityData(opportunityId);
						}
					}
					this.setBusy(false);
					this.setInputBusy(false);
				}
				// }.bind(this, opportunityId), 0);
			},

			//Function to help fetching opportunity data
			_fnHelpToFetchOpportunityData: function (opportunityId) {
				this.OpportunityUtil.getOpportunityDetailData(opportunityId).then((opportunityData) => {
					let execute = this.getProperty("executeOnChangeId") || false;
					this.setSelectedOpportunity(opportunityData, execute);
					this.setInputBusy(false);
					this.setBusy(false);
				}).catch((error) => {
					this.setInputBusy(false);
					this.setBusy(false);
					console.log("ERROR IN OPPORTUNITY CONTROL :", error);
				});
			},

			/**
			 * @private
			 * @author DARSHAN
			 * @function setInputBusy
			 * @description function to set input control busy
			 * @param {Boolean} bVisible
			 */
			setInputBusy: function (bBusy) {
				let inputContrl = this.getAggregation("_input");
				if (inputContrl) {
					inputContrl.setBusy(bBusy);
				}
			},

			/**
			 * @private
			 * @author DARSHAN
			 * @function _showClearIcon
			 * @description function to set clear icon vibility
			 * @param {Boolean} bVisible
			 */
			_showClearIcon: function (bVisible) {
				this.setProperty("_showClearIcon", bVisible);
				let clearIcon = this.getAggregation("_clearIcon");
				if (clearIcon) {
					clearIcon.setVisible(bVisible);
				}
				return this;
			},

			/**
			 * @private
			 * @author DARSHAN
			 * @function _showInfoIcon
			 * @description function to set info icon vibility
			 * @param {Boolean} bVisible
			 */
			_showInfoIcon: function (bVisible) {
				this.setProperty("_showInfoIcon", bVisible);
				let infoIcon = this.getAggregation("_opportunityinfobutton");
				if (infoIcon) {
					infoIcon.setVisible(bVisible);
				}
				return this;
			},

			/**
			 * @private
			 * @author BALWANT, DARSHAN
			 * @function setSelectedOpportunity
			 * @description function to set opportunity and account info 
			 * @param {Object} oValue
			 * @param {Boolean} executeEvent
			 */
			setSelectedOpportunity: async function (oValue = {}, executeEvent = true) {
				let oOpportunity = null,
					sOpportunityId = "",
					sOpportunityName = "";
				let oInputControl = this.getAggregation("_input");
				let bControlEdtiable = this.getEditable();
				let validId = (oValue && "OpportunityId" in oValue && oValue.OpportunityId) ? true : false;
				this.setInputBusy(true);
				if (oValue && Object.keys(oValue).length && validId) {
					oOpportunity = oValue;
					if (oOpportunity.OpportunityId) {
						sOpportunityId = oOpportunity.OpportunityId;
					}
					if (oOpportunity.OpportunityName) {
						sOpportunityName = oOpportunity.OpportunityName;
					}
				}

				if (oOpportunity) {
					if (oInputControl) {
						oInputControl.setValue(sOpportunityId + "-" + sOpportunityName);
						oInputControl.setTooltip(sOpportunityId + "-" + sOpportunityName);
					}
					if (sOpportunityId) {
						this.setProperty("opportunityId", sOpportunityId);
					}
				} else {
					if (oInputControl) {
						oInputControl.setValue("");
						oInputControl.setTooltip();
					}
					this._setControlVisibility("CREATE");
				}

				this.setProperty("selectedOpportunity", oOpportunity);

				if (bControlEdtiable && oOpportunity) {
					this._setControlVisibility("EDIT");
				}

				if (!oOpportunity) {
					this.setInputBusy(false);
					return;
				}

				const oAccountCtrl = this.fnGetAccountControl();
				if (oAccountCtrl) {
					AccountUtil.getAccountDetails(oValue.AccountId).then((oResponse) => {
						this.setInputBusy(false);
						//Check if account control is bounded with Opportunity control
						oAccountCtrl.AccountUtil.fnSetAccountNameToAccInput(oResponse, false);
						oValue.accountsData = oResponse;
						delete oValue.accountsData.model;
						if ("bNonVATOpportunity" in oValue && oValue.bNonVATOpportunity) {
							oStorageModel.setProperty("/oSelectedNonVATOppData", oValue);
						} else {
							oStorageModel.setProperty("/oSelectedNonVATOppData", {});
						}
						oStorageModel.refresh();
						if (bControlEdtiable && executeEvent) {
							this.fireEvent("selectedItem", {
								opportunityData: oValue
							});
						}
					}).catch((oError) => {
						console.log("ACCOUNT_SET: ", oError);
						MessageToast.show("Error");
						this.fireEvent("selectedItem", {
							opportunityData: oValue
						});
					});
				} else {
					this.setInputBusy(false);
					if (bControlEdtiable && executeEvent) {
						this.fireEvent("selectedItem", {
							opportunityData: oValue
						});
					}
				}

			},

			init: function () {
				that = this;
				this.setAggregation("_input", new sap.m.Input(this.getId() + "-input", {
					valueHelpOnly: true,
					showValueHelp: true,
					valueLiveUpdate: true,
					busyIndicatorDelay: 0,
					valueHelpRequest: this.onOpportunityValueFunction
				}));

				this.setAggregation("_clearIcon", new sap.ui.core.Icon(this.getId() + "-opportunityclearicon", {
					visible: false,
					tooltip: "Remove",
					press: this.onOpportunityClearButtonPress.bind(this)
				}));

				this.setAggregation("_opportunityinfobutton", new sap.ui.core.Icon(this.getId() + "-opportunityinfobtn", {
					visible: false,
					press: this.onOpportunityInfoButtonPress.bind(this)
				}));
				this.setAggregation("_button", new sap.m.Button(this.getId() + "-opportunitybtn", {
					text: "",
					press: this.onOpportunityButtonPress.bind(this)
				}));

				this.setAggregation("_icon", new sap.ui.core.Icon(this.getId() + "-opportunityicon", {
					press: this.onOpportunityButtonPress.bind(this)
				}));

				const oModel = new JSONModel({
					Opportunities: [],
					Searching: false
				});
				const oPrerequisiteModel = new JSONModel();
				const oOppoVATTeamModel = new JSONModel();
				oModel.setSizeLimit(99999);
				this.setModel(oModel);
				this.setModel(oPrerequisiteModel, Actions.oModels.PrerequisiteModel);
				this.setModel(oOppoVATTeamModel, Actions.oModels.OppoVATTeamModel);

				//BOUND UITILITY FILES TO CONTROL
				this.fnBoundUtilFiles();

				//TODO: To set the parent "this" keyword to opportunity util
				OpportunityUtil.fnStaticInit(that);

				this.getGeneratedYears();
				this.getDefaultOpportunities();
				this.getDiscontinuedOppUpdate();
			},

			//function to fetch default Opportunities
			getDefaultOpportunities: async function () {
				const oModel = that.getModel();
				let aCloneOpportunities = oStorageModel.getProperty("/aCloneOpportunities") || [];
				if (aCloneOpportunities.length) {
					return;
				}
				// OpportunityUtil.getOpportunities()
				// 	.then((data) => {
				// 		oStorageModel.setProperty("/aCloneOpportunities", data);
				// 		//MSL Exists Functionality
				// 		if (that.getShowMSLExist()) {
				// 			that.MSLExistUtil.fnLoadMSLFunctionality(data);
				// 		} else {
				// 			oModel.setProperty("/Opportunities", data);
				// 		}
				// 		oModel.setProperty("/isMSLExist", that.getShowMSLExist());
				// 		oModel.setProperty("/bActiveOppGrowing", that.getShowMSLExist());
				// 		oStorageModel.refresh();
				// 		oModel.refresh();
				// 	});

				// OpportunityUtil.getOppMasterData().then((data) => {
				// 	OpportunityUtil.fetchFilteredActiveOpportunities();
				// 	oModel.refresh();
				// });
			},

			//function to generate Previous and Future year
			getGeneratedYears: async function () {
				const oModel = that.getModel();
				let currentDate = new Date();
				let sYear = currentDate.getFullYear(),
					sMonthPluseOne = currentDate.getMonth() + 1,
					sMonth = sMonthPluseOne < 10 ? "0" + sMonthPluseOne : sMonthPluseOne,
					sDay = currentDate.getDate() < 10 ? "0" + currentDate.getDate() : currentDate.getDate();
				let previousYear = new Date((sYear - 1) + "-" + sMonth + "-" + sDay + "T00:00:00Z");
				let futureFiveYear = new Date((sYear + 5) + "-" + sMonth + "-" + sDay + "T23:59:00Z");
				oModel.setProperty("/previousYear", previousYear);
				oModel.setProperty("/futureFiveYear", futureFiveYear);
				oModel.refresh();
			},

			//function to get Discontinued Opp
			getDiscontinuedOppUpdate: async function () {
				const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				let bPcDiscontinuedOppUpdated = oStorage.get("pcDiscontinuedOppUpdated");
				let bPcDiscontinuedOppInitCall = oStorage.get("pcDiscontinuedOppInitCall");
				//TODO:Uncomment Once done with discontinued Opp
				// OpportunityUtil.getUserRecords();
			},

			onAfterRendering: function () { },

			//function to handle opportunity input value help
			onOpportunityValueFunction: async function (oEvent) {

				const oSource = oEvent.getSource().getParent();
				const oModel = oSource.getModel();
				const isCvaSelected = oModel.getProperty("/isCvaSelected");
				const oSelectedAccountData = $.extend(true, {}, oModel.getProperty("/oSelectedAccountDetails"));

				//BOUND REQUERIED FILE
				let fnSetBoundFiles = oSource.fnBoundUtilFiles.bind(oSource)
				fnSetBoundFiles();

				//CHECK FRAGMENT CONTROLLER HAS BEEN INITILIZED TO OPPORTUNITY CONTROL AND UPDATE THE SELF
				oSource.fnCreateDialogController(oSource);

				let oProjectInstance = {
					bOpportunity: oSource.getOpportunity(),
					projectType: oSource.getProjectType(),
					CvaSelected: (isCvaSelected) ? isCvaSelected : false,
					CvaAccountId: (Object.keys(oSelectedAccountData).length) ? oSelectedAccountData.AccountId : "",
					previousYear: oSource.previousYear,
					futureFiveYear: oSource.futureFiveYear,
				};

				let openOpportunityFrag = (oProjectInstance.projectType === Actions.Actvt) ? OpportunityHelper.onActiveOpportunityValueHelpHandler.bind(
					oSource) : OpportunityHelper.onOpportunityValueHelpHandler.bind(oSource);
				oModel.setProperty("/isOpptDilogBusy", true);
				oModel.setProperty("/activeOppDialogDefaultIconTab", Actions.active_opportunities);
				OpportunityUtil.opportunityCtrl = this.OpportunityHelper ? this : this.getParent();
				await OpportunityUtil.getOppMasterData(this);
				await OpportunityUtil.fetchFilteredActiveOpportunities(this);
				await openOpportunityFrag();

				let fnOppPrerequisites = OpportunityUtil.fnOpportunityValueHelpHandler(oProjectInstance);
				fnOppPrerequisites.then((oResponseData) => {
					if (oProjectInstance.bOpportunity) {
						oModel.setProperty("/Opportunities", []);
						if (oProjectInstance.projectType === Actions.Actvt) {
							if (oResponseData && oResponseData.hasOwnProperty("aActOppList")) {
								oModel.setProperty("/Opportunities", oResponseData.aActOppList);
							}
						}

						if (oProjectInstance.projectType !== Actions.Actvt) {
							if (oResponseData && oResponseData.hasOwnProperty("aPcOppList")) {
								oModel.setProperty("/Opportunities", oResponseData.aPcOppList);
							}
						}
					}
					oModel.setProperty("/isOpptDilogBusy", false);
					oModel.refresh();
				}).catch((oError) => {
					oModel.setProperty("/isOpptDilogBusy", false);
					oModel.refresh();
				});
			},

			updateDefaultModelData: function (oData) {
				this.getModel().setProperty("/", oData);
			},

			//function to handle opportunity button
			onOpportunityButtonPress: async function (oEvent) {
				this.onOpportunityValueFunction(oEvent);
			},

			//function to handle opportunity button
			fnCreateDialogController: async function (oSource) {
				if (oSource.DialogController) {
					oSource.DialogController.opportunityCtrl = oSource;
				} else {
					oSource.DialogController = new OpportunityDialogController(oSource);
					oSource.DialogController.opportunityCtrl = oSource;
					oSource.DialogController.fnLoadLangModel = oSource.OpportunityHelper.fnLoadResourceBundle;
				}
			},

			//function to handle opportunity clear button
			onOpportunityClearButtonPress: async function (oEvent) {

				let oInfoIconSource = oEvent.getSource();
				const oOpportunityCtrl = oInfoIconSource.getParent();
				oOpportunityCtrl.setOpportunityId("");
				// oOpportunityCtrl.setSelectedOpportunity(null);
				const oAccountCtrl = this.fnGetAccountControl();
				// if (oAccountCtrl) {
				// 	oAccountCtrl.AccountUtil.fnSetAccountNameToAccInput("", true);
				// }
				const oModel = oOpportunityCtrl.getModel();
				oModel.setProperty("/selectedOpportunity", {});
				oModel.setProperty("/NonVatOpportunitiesList", []);
				oStorageModel.setProperty("/bFilterNonVatAccBased", false);
				oStorageModel.setProperty("/oAppBasedOpportunityData", {
					isOpportunityDataLoaded: false
				});
				oOpportunityCtrl._setControlVisibility("CREATE");
				oModel.refresh();
				this.fireEvent("clearSelectedItem", {
					reset: true
				});
			},

			//function to show Opportunity Info Popup
			onOpportunityInfoButtonPress: function (oEvent) {
				let oInfoIconSource = oEvent.getSource();
				const oOpportunityCtrl = oInfoIconSource.getParent();
				let opportunityId = oOpportunityCtrl.getProperty("opportunityId");
				// let opportunityId = "300462537";

				//CHECK FRAGMENT CONTROLLER HAS BEEN INITILIZED TO OPPORTUNITY CONTROL AND UPDATE THE SELF
				oOpportunityCtrl.fnCreateDialogController(oOpportunityCtrl);

				const oModel = oOpportunityCtrl.getModel();
				oModel.setProperty("/infoPopoverBusy", true);

				let selectedOpportunity = oOpportunityCtrl.getProperty("selectedOpportunity") || {};
				let validId = (selectedOpportunity && "OpportunityId" in selectedOpportunity && selectedOpportunity.OpportunityId) ? true : false;

				//In Case Of Matrix Existing Activity, selectedOpportunity will be empty
				const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				let aLibOpportunties = oStorage.get("pcLibOpportunties") || [];
				if (!validId) {
					let opportunityData = aLibOpportunties.find((item) => {
						return item.OpportunityId === opportunityId
					}) || false;
					if (opportunityData) {
						oModel.setProperty("/selectedOpportunity", opportunityData);
						oModel.setProperty("/infoPopoverBusy", false);
					} else {
						oOpportunityCtrl.OpportunityUtil.getOpportunityDetailData(opportunityId).then((resposneData) => {
							oModel.setProperty("/selectedOpportunity", resposneData);
							oModel.setProperty("/infoPopoverBusy", false);
							oModel.refresh();
						});
					}
				} else {
					oModel.setProperty("/selectedOpportunity", selectedOpportunity);
					oModel.setProperty("/infoPopoverBusy", false);
				}

				oModel.refresh();
				let fnOpportunityInfo = OpportunityHelper.onOpportunityInformationHandler.bind(oOpportunityCtrl);
				fnOpportunityInfo(oInfoIconSource);
			},

			//function to get all the Opportunity settings
			getSettings: function () {
				return {
					showMslExists: that.getShowMSLExist(),
				}
			},

			//function to handle icons visibility
			_setControlVisibility: function (mode) {
				let clearIcon = false;
				let infoIcon = false;
				switch (mode) {
					case "DISPLAY":
						clearIcon = false;
						infoIcon = true;
						break;
					case "CREATE":
						clearIcon = false;
						infoIcon = false;
						break;
					default:
						clearIcon = true;
						infoIcon = true;
				}
				this._showClearIcon(clearIcon);
				this._showInfoIcon(infoIcon);
			},

			/**
			 * @author DARSHAN
			 * @function
			 * @purpose Function to bound util files to controls.
			 * NOTE: Always call this function using .bind()
			 */
			fnBoundUtilFiles: function () {
				this.VATTeam = Object.create(VATTeamUtil);
				this.MSLExistUtil = Object.create(MSLExistUtil);
				this.OpportunityUtil = Object.create(OpportunityUtil);
				this.OpportunityHelper = Object.create(OpportunityHelper);
				this.DiscontinuedOpportunity = Object.create(DiscontinuedOpportunity);

				//CREATE A SELF REF WHICH POITNS TO THE CONTROL FROM THE UTIL FILES
				this.VATTeam.opportunityCtrl = this;
				this.MSLExistUtil.opportunityCtrl = this;
				this.OpportunityUtil.opportunityCtrl = this;
				this.OpportunityHelper.opportunityCtrl = this;
				this.DiscontinuedOpportunity.opportunityCtrl = this;
			},

			//Function to return the Account Control Source
			fnGetAccountControl: function () {
				let oControl;
				const regex = /_[a-zA-Z][^_]*\d_/;
				let sOpportunityCtrlId = this.getId();
				let sAccountCtrlId = this.getAccountCtrlId();
				if (!sAccountCtrlId) {
					return false;
				}
				let tempAccountCtrlId = sAccountCtrlId.match(regex);
				let tempOpportunityCtrlId = sOpportunityCtrlId.match(regex);
				if (tempOpportunityCtrlId && tempAccountCtrlId) {
					tempAccountCtrlId = tempAccountCtrlId[0];
					sAccountCtrlId = sOpportunityCtrlId.replace(regex, tempAccountCtrlId);
					oControl = sap.ui.getCore().byId(sAccountCtrlId);
				}
				return oControl || false;
			}

		});

		return oOpportunityControl;

	}, /* bExport= */ true);