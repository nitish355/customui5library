sap.ui.define({
	NotStarted: "NotStarted",
	InProgress: "InProgress",
	Completed: "Completed"
}, true);