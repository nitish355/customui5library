sap.ui.define({
	Planned: "Planned",
	Recommended: "Recommended",
	Registered: "Registered",
	Completed: "Completed",
	Archieved: "Archieved",
	Required: "Required",
	Not_Applicable: "Not Applicable",
	Customer_Validated: "Customer Validated",
	Started: "Started",
	Presented: "Presented",
	Progressing: "Progressing",
	Validated: "Validated",
}, true);