sap.ui.define({
	NotStarted: "NotStarted",
	InProgress: "InProgress",
	Completed: "Completed",
	Outcome: "Outcome",
	Unachieved:"Unachieved",
	Achieved:"Achieved",
	Completed_Unachieved:"Complete / Unachieved",
	Incompleted_Unachieved:"Incomplete / Unachieved",
	Completed_Achieved:"Complete / Achieved",
	Incompleted_Achieved:"Incomplete / Achieved"
}, true);
