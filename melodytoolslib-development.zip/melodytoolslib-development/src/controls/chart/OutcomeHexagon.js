sap.ui.define([
	"sap/ui/core/Control"
], function (Control) {
	"use strict";

	var OutcomeHexagon = Control.extend("com.melody.lib.controls.chart.OutcomeHexagon", {
		// the control API:
		metadata: {
			properties: {
				color: {
					type: "string",
					defaultValue: "#D08014"
				},
				strokeColor: {
					type: "string",
					defaultValue: "white"
				},
				width: {
					type: "sap.ui.core.CSSSize"
				},
				completedStatus: {
					type: "boolean",
					defaultValue: false
				},
				achieved: {
					type: "boolean",
					defaultValue: false
				}
			},

			aggregations: {
				/**
				 * Svg
				 */
				_svg: {
					type: "sap.ui.core.HTML",
					multiple: false,
					visibility: "hidden"
				}
			},

			associations: {},

			events: {}
		},

		init: function () {
			this.setAggregation("_svg", new sap.ui.core.HTML(this.getId() + "-svg", {
				preferDOM: false
			}));
		},

		_setSvg: function () {
			let content = "";
			let bAchieved = this.getAchieved();
			let bCompletedStatus = this.getCompletedStatus();
			let mainColor = this.getColor();
			let strokeColor = this.getStrokeColor();
			if(bCompletedStatus){
				if(bAchieved){
					content="<svg viewBox='2.584 0 33.403 38.571' fill='none' xmlns='http://www.w3.org/2000/svg'>"+
					"<path d='M17 0L31.722 8.5V25.5L17 34L2.278 25.5V8.5L17 0Z' stroke='white' stroke-width='2.5' fill='" + mainColor +"'/>"+
					"<path d='M17 24.48V32.3' stroke='" + strokeColor +"' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'/>"+
					"<path d='M17 2.04V10.2' stroke='" + strokeColor +"' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'/>"+
					"<path cx='49.5' cy='50.5' r='20.5' stroke='" + strokeColor +"' stroke-width='2.5' stroke-linecap='round' d='M23.8 17.17A6.97 6.97 0 0 1 16.83 24.14A6.97 6.97 0 0 1 9.86 17.17A6.97 6.97 0 0 1 23.8 17.17z'/>"+
					"</svg>";
				}else{
				content="<svg  viewBox='2.584 0 33.403 38.571' fill='none' xmlns='http://www.w3.org/2000/svg'>"+
					"<path d='M19.286 0L35.987 9.643V28.929L19.286 38.571L2.584 28.929V9.643L19.286 0Z' stroke='white' stroke-width='2.5' fill='" + mainColor +"'/>"+
					"<path d='M19.286 27.771V36.643' stroke='" + strokeColor +"' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'/>"+
					"<path d='M19.286 2.314V11.571' stroke='" + strokeColor +"' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'/>"+
					"<path cx='49.5' cy='50.5' r='20.5' stroke='" + strokeColor +"' stroke-width='2.5' stroke-linecap='round' d='M27 19.479A7.907 7.907 0 0 1 19.093 27.386A7.907 7.907 0 0 1 11.186 19.479A7.907 7.907 0 0 1 27 19.479z'/>"+
					"<path cx='49.5' cy='50.5' r='20.5' fill='" + strokeColor +"' d='M27 19.479A7.907 7.907 0 0 1 19.093 27.386A7.907 7.907 0 0 1 11.186 19.479A7.907 7.907 0 0 1 27 19.479z'/>"+
					"</svg>";
				}
			}else{
				if(bAchieved){
					content="<svg  viewBox='2.584 0 33.403 38.571' fill='none' xmlns='http://www.w3.org/2000/svg'>"+
					"<path d='M2.958 8.893L17 0.785L31.042 8.893V25.107L17 33.215L2.958 25.107V8.893Z' fill='" + strokeColor +"' stroke='" + mainColor +"' stroke-width='2.5'/>"+
					"<path d='M17 24.48V32.3' stroke='" + mainColor +"' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'/>"+
					"<path d='M17 2.04V10.2' stroke='" + mainColor +"' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'/>"+
					"<path cx='49.5' cy='50.5' r='20.5' fill='" + mainColor +"' stroke='" + mainColor +"' stroke-width='2' stroke-linecap='round' d='M23.8 17.17A6.97 6.97 0 0 1 16.83 24.14A6.97 6.97 0 0 1 9.86 17.17A6.97 6.97 0 0 1 23.8 17.17z'/>"+
					"</svg>";
				}else{
					content="<svg viewBox='0 0 28 31.818' fill='none' xmlns='http://www.w3.org/2000/svg'>"+
					"<path d='M0.859 8.322L14 0.735L27.141 8.322V23.496L14 31.083L0.859 23.496V8.322Z' fill='" + strokeColor +"' stroke='" + mainColor + "' stroke-width='2.5'/>"+
					"<path d='M14 22.909V30.227' stroke='" + mainColor +"' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'/>"+
					"<path d='M14 1.909V9.545' stroke='" + mainColor +"' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'/>"+
				"<path cx='43.5' cy='50.5' r='20.5' stroke='" + mainColor +	"' stroke-width='2.5' stroke-linecap='round' d='M20.364 16.068A6.523 6.523 0 0 1 13.841 22.591A6.523 6.523 0 0 1 7.318 16.068A6.523 6.523 0 0 1 20.364 16.068z'/>"+
					"</svg>"
				}
			}
			this.getAggregation("_svg").setContent(content);
		},

		onAfterRendering: function () {
			this._setSvg();
		},

		renderer: {

			render: function (oRm, oControl) {

				oRm.write("<div");
				oRm.writeControlData(oControl);

				oRm.addClass("melodyOutcomeHexagon");
				oRm.writeClasses();

				oRm.addStyle("width", oControl.getWidth());
				oRm.writeStyles();
				oRm.write(">");
				oRm.renderControl(oControl.getAggregation("_svg"));
				oRm.write("</div>");
			}
		}
	});

	return OutcomeHexagon;

});