sap.ui.define([
    "sap/ui/core/Control"
], function(Control) {
    "use strict";
 
    var Hexagon = Control.extend("com.melody.lib.controls.chart.Hexagon", {
        // the control API:
        metadata : {
            properties : {
            	color           	: {type : "string", defaultValue: "#D08014"},
            	strokeColor			: {type : "string", defaultValue: "white"},
            	width           	: {type : "sap.ui.core.CSSSize"}
            },
                            
            aggregations : {},
                            
            associations: {},
                            
            events : {}
        },

 
        init : function() {},
                        
        onAfterRendering: function () {},
                        
        renderer : {
 
            render : function(oRm, oControl) {
 
                oRm.write("<div");
                oRm.writeControlData(oControl);
 
                oRm.addClass("melodyHexagon");
                oRm.writeClasses();
                                
                oRm.addStyle("width", oControl.getWidth());
                oRm.writeStyles();
 
                oRm.write(">");
                     
            	oRm.write("<svg fill='none' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 27.1 31'>");
            		oRm.write("<g transform='translate(0 0)'>");
            			oRm.write("<polygon points='14 0, 27 8, 27 23, 14 31, 0 23, 0 8' fill='" + oControl.getStrokeColor() + "' stroke-width='0' />");
            			oRm.write("<polygon points='14 3.2, 24.4 9.6, 24.4 21.5, 14 28, 2.6 21.5, 2.6 9.6' fill='" + oControl.getColor() + "' stroke-width='0' />");
            		oRm.write("</g>");
            	oRm.write("</svg>");
                oRm.write("</div>");
            }
        }
    });
    
    return Hexagon;
 
});