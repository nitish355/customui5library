sap.ui.define([
	"sap/ui/core/Control"
], function (Control) {
	"use strict";

	var RadialChart = Control.extend("com.melody.lib.controls.chart.RadialChart", {
		// the control API:
		metadata: {
			properties: {
				color: {
					type: "string",
					defaultValue: "#D08014"
				},
				started: {
					type: "boolean",
					defaultValue: false
				},
				percent: {
					type: "float",
					defaultValue: 0
				},
				width: {
					type: "sap.ui.core.CSSSize"
				},
				title: {
					type: "string",
					defaultValue: ""
				},
				titleFontSize: {
					type: "sap.ui.core.CSSSize",
					defaultValue: "14px"
				},
				level: {
					type: "sap.ui.core.TitleLevel",
					defaultValue: "Auto"
				}
			},

			aggregations: {
				/**
				 * Chart
				 */
				_chart: {
					type: "sap.ui.core.HTML",
					multiple: false,
					visibility: "hidden"
				},

				/**
				 * Title
				 */
				_title: {
					type: "sap.m.Title",
					multiple: false,
					visibility: "hidden"
				},
			},

			associations: {},

			events: {}
		},

		init: function () {
			//initialisation code, in this case, ensure css is imported
			var libraryPath = jQuery.sap.getModulePath("com.melody.lib"); //get the server location of the ui library
			jQuery.sap.includeStyleSheet(libraryPath + "/controls/chart/chart.css"); //specify the css path relative from the ui folder

			this.setAggregation("_chart", new sap.ui.core.HTML(this.getId() + "-chart", {
				preferDOM: false
			}).addStyleClass("melodyRadialChartTitle"));
			this._setChart();
			this.setAggregation("_title", new sap.m.Title(this.getId() + "-title", {
				text: this.getTitle(),
				level: this.getLevel(),
				titleStyle: this.getLevel()
			}).addStyleClass("melodyRadialChartTitle"));
		},

		setTitle: function (sValue) {
			this.setProperty("title", sValue);
			this.getAggregation("_title").setText(sValue);
		},

		setLevel: function (sValue) {
			this.setProperty("level", sValue);
			this.getAggregation("_title").setLevel(sValue);
			this.getAggregation("_title").setTitleStyle(sValue);
		},

		setColor: function (sValue) {
			this.setProperty("color", sValue);
			if (jQuery.sap.byId(this.getId() + "-title") && jQuery.sap.byId(this.getId() + "-title").length > 0) {
				jQuery.sap.byId(this.getId() + "-title").css({
					"color": sValue
				});
			}
			this._setChart();

		},

		onAfterRendering: function () {
			jQuery.sap.byId(this.getId() + "-title").css({
				"color": this.getColor()
			});
		},

		setPercent: function (fValue) {
			let fPercent = parseFloat(fValue, 10);
			if (isNaN(fPercent)) {
				fPercent = 0;
			}
			this.setProperty("percent", fPercent);
			this._setChart();
			//$("#" + this.getId()).find(".melodyRadialChartInnerContent").html(this._generateInnerContent());
		},
		
		_setChart: function() {
			this.getAggregation("_chart").setContent("<svg fill='none' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 54 54'>" +
					"<g transform='translate(1 1)' class='melodyRadialChart'>" +
					"<circle cx='26' cy='26' r='26' transform='rotate(0 26 26)' fill='white' stroke='" + this.getColor() +
					"' stroke-width='2' />" +
					"<g class='melodyRadialChartInnerContent'>" + this._generateInnerContent() + "</g></g></svg>");
		},

		_generateInnerContent: function () {
			const bStarted = this.getStarted();
			let sInnerContent = "";
			if (bStarted) {

				const radius = 22;
				const circumference = radius * 2 * Math.PI;

				let percent = (this.getPercent()) ? this.getPercent() : 0;
				const offset = circumference - percent / 100 * circumference;
				
				sInnerContent = "<circle class='melodyRadialChartProgressRing' cx='26' cy='26' r='" + radius + "'style='stroke-dasharray:" +
					circumference + " " + circumference + ";stroke-dashoffset:" + offset +
					";' transform='rotate(90 26 26)' fill='transparent' stroke='" + this.getColor() + "' stroke-width='10' />";
				sInnerContent +=
					"<text class='micro-chart-pointer-text' x='26' y='28' alignment-baseline='middle' font-size='12' font-weight='bold' stroke-width='0' stroke='white' text-anchor='middle' fill='" +
					this.getColor() + "'>" + percent + "%" + "</text>";

			} else {
				sInnerContent = "<g transform='translate(17 16)'>";
				sInnerContent +=
					"<path d='M18 9C18 16 9 22 9 22C9 22 0 16 0 9C3.55683e-08 6.61305 0.948211 4.32387 2.63604 2.63604C4.32387 0.948211 6.61305 0 9 0C11.3869 0 13.6761 0.948211 15.364 2.63604C17.0518 4.32387 18 6.61305 18 9Z' fill='" +
					this.getColor() + "' />";
				sInnerContent +=
					"<path d='M9 12C10.6569 12 12 10.6569 12 9C12 7.34315 10.6569 6 9 6C7.34315 6 6 7.34315 6 9C6 10.6569 7.34315 12 9 12Z' fill='white' stroke='white' stroke-width='1.68379' stroke-linecap='round' stroke-linejoin='round' />"
				sInnerContent += "</g>";
			}

			return sInnerContent;
		},

		renderer: {

			render: function (oRm, oControl) {
				oRm.write("<div");
				oRm.writeControlData(oControl);
				oRm.addClass("melodyRadialChartContainer");
				oRm.writeClasses();
				oRm.writeStyles();
				oRm.write(">");
				oRm.write("<div style='width: " + oControl.getWidth() + ";display: flex;align-items: center;'>");
				//oRm.writeControlData(oControl);

				//oRm.addClass("melodyRadialChart");
				//oRm.writeClasses();

				//oRm.addStyle("width", oControl.getWidth());

				//oRm.write(">");
				oRm.renderControl(oControl.getAggregation("_chart"));
				/*oRm.write("<svg fill='none' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 52 52'>");
				oRm.write("<g transform='translate(0 0)' class='melodyRadialChart'>");
				oRm.write("<circle cx='26' cy='26' r='25' transform='rotate(0 26 26)' fill='white' stroke='" + oControl.getColor() +
					"' stroke-width='2' />");
				oRm.write("<g class='melodyRadialChartInnerContent'>");
				oRm.write(oControl._generateInnerContent());
				oRm.write("</g>");
				oRm.write("</g>");
				oRm.write("</svg>");*/
				oRm.write("</div>");
				/*oRm.write("<span style='letter-spacing:0.8px; font-size:" + oControl.getTitleFontSize() + "; font-weight:bold; color:" + oControl.getColor() +
					";' class='melodyRadialChartTitle'>" + oControl.getTitle() + "</span>");*/
				oRm.renderControl(oControl.getAggregation("_title"));
				oRm.write("</div>");
			}
		}
	});

	return RadialChart;

});