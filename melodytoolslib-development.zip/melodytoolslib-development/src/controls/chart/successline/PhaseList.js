sap.ui.define(["sap/ui/core/Control"], function (Control) {
	"use strict";
	return Control.extend("com.melody.lib.controls.chart.successline.PhaseList", {
		"metadata": {
			properties: {},
			events: {
				/**
				 * Event is fired when the user selects phase.
				 */
				select: {}
			},
			aggregations: {
				items: {
					type: "com.melody.lib.controls.chart.successline.PhaseListItem",
					multiple: true,
					singularName: "item"
				}
			}
		},
		init: function () {
			//initialisation code, in this case, ensure css is imported
			var libraryPath = jQuery.sap.getModulePath("com.melody.lib.controls.chart.successline"); //get the server location of the ui library
			jQuery.sap.includeStyleSheet(libraryPath + "/PhaseNavigation.css"); //specify the css path relative from the ui folder
		},
		renderer: function (oRm, oControl) {
			oRm.write("<div");
			oRm.writeControlData(oControl);
			oRm.addClass("sidebar");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<ul");
			oRm.write(">");
			$.each(oControl.getItems(), function (key, value) {
				oRm.renderControl(value);
			});
			oRm.write("</ul>");
			oRm.write("</div>");
		},
		onAfterRendering: function (evt) {}
	});
});