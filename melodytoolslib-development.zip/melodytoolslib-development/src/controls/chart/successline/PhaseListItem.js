sap.ui.define(["sap/ui/core/Control"], function (Control) {
	"use strict";
	return Control.extend("com.melody.lib.controls.chart.successline.PhaseListItem", {
		metadata: {
			properties: {
				identifier: "string",
				title: "string",
				abbreviation: "string",
				color: "string"
			},
			events: {
				/**
				 * Event is fired when the user selects phase.
				 */
				select: {
					parameters: {
						phaseId: {
							type: "string"
						}
					}
				}
			}
		},
		init: function () {},
		renderer: function (oRm, oControl) {
			oRm.write("<li class='phaseItem' style='color:" + oControl.getColor() + "'");
			oRm.writeControlData(oControl);
			oRm.write(">");
			oRm.renderControl(new sap.ui.core.HTML({
				// the static content as a long string literal
				content: '<div class="phaseItemInner"><span title="' + oControl.getTitle() + '"><span class="phase">' + oControl.getAbbreviation() + '</span><span class="phase-name">' + oControl.getTitle() +
					'</span></span></div>',
				preferDOM: false,

				// use the afterRendering event for 2 purposes
				afterRendering: function (oEvent) {
					if (!oEvent.getParameters()["isPreservedDOM"]) {
						var $DomRef = oEvent.getSource().$();
						$DomRef.on("click", function () {
							oControl.fireEvent("select", {
								phaseId: oControl.getIdentifier()
							});
						}.bind(this));
						
						$DomRef.on("mouseenter", function () {
							$(this).parent().css({ "background-color": oControl.getColor(), "color": "#FFFFFF", "border-radius": "5px" });
						});
						
						$DomRef.on("mouseleave", function () {
							$(this).parent().css({ "color": oControl.getColor(), "background-color": "transparent", "border-radius": "0" });
						});
					}
				}.bind(this)
			}));
			oRm.write("</li>");
		},
		onAfterRendering: function (evt) {},

		setIdentifier: function (sValue) {
			this.setProperty("identifier", sValue, true);
			return this;
		},

		setAbbreviation: function (sValue) {
			this.setProperty("abbreviation", sValue, true);
			return this;
		},

		setTitle: function (sValue) {
			this.setProperty("title", sValue, true);
			return this;
		},

		setColor: function (sValue) {
			this.setProperty("color", sValue.toLowerCase(), true);
			return this;
		}
	});
});