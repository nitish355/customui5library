sap.ui.define([
	"sap/ui/core/Control",
	"com/melody/lib/controls/chart/enum/PhaseStatus",
	"com/melody/lib/controls/chart/enum/ActivityStatus",
	"com/melody/lib/controls/chart/enum/ServiceStatus",
	"com/melody/lib/controls/chart/libs/SvgZoom",
	"sap/ui/core/Fragment",
	"com/melody/lib/controls/chart/successline/PhaseList",
	"com/melody/lib/controls/chart/successline/PhaseListItem",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/mvc/Controller"
], function (Control, PhaseStatus, ActivityStatus, ServiceStatus, SvgZoomJS, Fragment, PhaseList, PhaseListItem, JSONModel, Controller) {
	"use strict";

	var SuccessLineChart = Control.extend("com.melody.lib.controls.chart.SuccessLineChart", {
		// the control API:
		metadata: {
			properties: {
				data: {
					type: "object",
					defaultValue: null
				},

				expanded: {
					type: "boolean",
					defaultValue: true
				},

				autoHideCompletedPhases: {
					type: "boolean",
					defaultValue: false
				},

				showPhaseMenu: {
					type: "boolean",
					defaultValue: true
				},

				showKey: {
					type: "boolean",
					defaultValue: true
				},

				showTodaysDate: {
					type: "boolean",
					defaultValue: true
				},

				showActivityStatus: {
					type: "boolean",
					defaultValue: true
				},

				showDataLines: {
					type: "boolean",
					defaultValue: true
				},
				showSubTitlesOnly: {
					type: "boolean",
					defaultValue: false
				}
			},

			aggregations: {
				/**
				 * Chart
				 */
				_chart: {
					type: "sap.ui.core.HTML",
					multiple: false,
					visibility: "hidden"
				},

				/**
				 * Phases
				 */
				_setting: {
					type: "sap.m.Button",
					multiple: false,
					visibility: "hidden"
				},

				/**
				 * Phases
				 */
				_phaseList: {
					type: "com.melody.lib.controls.chart.successline.PhaseList",
					multiple: false,
					visibility: "hidden"
				},

				/**
				 * Key
				 */
				_key: {
					type: "sap.m.List",
					multiple: false,
					visibility: "hidden"
				},

				/**
				 * Activity Status
				 */
				_activityStatus: {
					type: "sap.m.List",
					multiple: false,
					visibility: "hidden"
				}
			},

			associations: {},

			events: {
				select: {
					parameters: {
						type: {
							type: "string"
						},
						activityId: {
							type: "string"
						},
						serviceId: {
							type: "string"
						},
						phaseId: {
							type: "string"
						},
						touchpointId: {
							type: "string"
						}
					}
				},

				expand: {
					parameters: {
						serviceId: {
							type: "string"
						},
						phaseId: {
							type: "string"
						},
						touchpointId: {
							type: "string"
						},
						expanded: {
							type: "boolean"
						}
					}
				},

				toggleActivityStatus: {
					parameters: {
						state: {
							type: "boolean"
						}
					}
				},

				toggleSubTitles: {
					parameters: {
						state: {
							type: "boolean"
						}
					}
				},

				toggleDataLines: {
					parameters: {
						state: {
							type: "boolean"
						}
					}
				},

				toggleExpandAll: {
					parameters: {
						expanded: {
							type: "boolean"
						}
					}
				},

				toggleAutoHideCompletedPhases: {
					parameters: {
						phases: {
							type: "object",
						},
						expanded: {
							type: "boolean"
						}
					}
				},

				openDetail: {
					parameters: {
						element: {
							type: "object"
						},
						activityId: {
							type: "string"
						}
					}
				},

				saveSettings: {
					parameters: {
						settings: {
							type: "object"
						}
					}
				},
				openToolstip: {
					element: {
						type: "object"
					},
					activitySubtitle: {
						type: "string"
					},
					eventType: {
						type: "string"
					}
				}
			}
		},

		scrollTargetAdjusted: function (element) {
			let $parentContainerPosition = $(".successLineChartContainer")[0].getBoundingClientRect();
			let $sectionElement = $(".sapFDynamicPageContentWrapper")[0];
			let headerOffset = $parentContainerPosition.y;
			let elementPosition = element.getBoundingClientRect().top;
			let offsetPosition = elementPosition + window.pageYOffset - headerOffset;
			if ($sectionElement) {
				$sectionElement.scrollTo({
					top: offsetPosition,
					behavior: "smooth"
				});
			}
		},

		init: function () {
			const that = this;
			//initialisation code, in this case, ensure css is imported
			var libraryPath = jQuery.sap.getModulePath("com.melody.lib"); //get the server location of the ui library
			jQuery.sap.includeStyleSheet(libraryPath + "/controls/chart/chart.css"); //specify the css path relative from the ui folder

			var oItemTemplate = new PhaseListItem({
				title: "{slChartPhaseList>title}",
				abbreviation: "{slChartPhaseList>abbreviation}",
				identifier: "{slChartPhaseList>id}",
				color: "{slChartPhaseList>color}",
				tooltip: "{slChartPhaseList>title}",
				select: function (oEvent) {
					const sPhaseId = oEvent.getParameter("phaseId");
					var element = document.querySelector("[data-phase='slChartPhase" + sPhaseId + "']");
					// element.scrollIntoView();
					that.scrollTargetAdjusted(element);
				}
			});

			const oPhaseList = new PhaseList(this.getId() + "-phaseList", {
				items: {
					path: "slChartPhaseList>/phases",
					template: oItemTemplate
				}
			});

			this.setAggregation("_phaseList", oPhaseList.addStyleClass("slChartPhaseList"));

			this.getAggregation("_phaseList").setModel(new JSONModel(this.getData()), "slChartPhaseList");

			this.setAggregation("_setting", new sap.m.Button(this.getId() + "-setting", {
				icon: "sap-icon://menu2",
				type: "Transparent",
				tooltip: "Presentation View Settings",
				press: function (oEvent) {
					that.openPresentationViewSettingsPopover(oEvent);
				}
			}).addStyleClass("slChartSettingButton"));
			let color = "#286EB4";
			this.setAggregation("_key", new sap.m.List(this.getId() + "-key", {
				width: "10rem",
				items: [
					new sap.m.CustomListItem({
						content: [
							new sap.m.FlexBox({
								alignItems: "Start",
								justifyContent: "Start",
								items: [
									new sap.ui.core.HTML({
										content: '<svg class="phaseLegendIcon" width="25" height="25" viewBox="0 0 45 45">' +
											'<g transform="scale(0.9)">' +
											'<g transform="translate(5 5)">' +
											'<circle cx="18" cy="18" r="18" transform="rotate(0 26 26)" fill="white" stroke="' + color +
											'" stroke-width="6" />' +
											'<g>' +
											"<g transform='translate(10 9) scale(0.9)'>" +
											"<path d='M18 9C18 16 9 22 9 22C9 22 0 16 0 9C3.55683e-08 6.61305 0.948211 4.32387 2.63604 2.63604C4.32387 0.948211 6.61305 0 9 0C11.3869 0 13.6761 0.948211 15.364 2.63604C17.0518 4.32387 18 6.61305 18 9Z' fill='" +
											color + "' />" +
											"<path d='M9 12C10.6569 12 12 10.6569 12 9C12 7.34315 10.6569 6 9 6C7.34315 6 6 7.34315 6 9C6 10.6569 7.34315 12 9 12Z' fill='white' stroke='white' stroke-width='1.68379' stroke-linecap='round' stroke-linejoin='round' />" +
											"</g>" +
											'</g>' +
											'</g></g>' +
											"</svg>"
									}),
									new sap.m.Text({
										text: "Phase"
									}).addStyleClass("legendTitle phaseLegendTitle")
								]
							})
						]
					}),
					new sap.m.CustomListItem({
						content: [
							new sap.m.FlexBox({
								alignItems: "Start",
								justifyContent: "Start",
								items: [
									new sap.ui.core.HTML({
										content: '<svg class="serviceLegendIcon" width="25" height="25" viewBox="0 0 27 31">' +
											'<polygon transform="scale(0.9)" class="service" points="14 0, 27 8, 27 23, 14 31, 0 23, 0 8" stroke="white" fill="' +
											color +
											'" stroke-width="2" />' +
											"</svg>"
									}),
									new sap.m.Text({
										text: "Sub-phase"
									}).addStyleClass("legendTitle serviceLegendTitle")
								]
							})
						]
					}),
					new sap.m.CustomListItem({
						content: [
							new sap.m.FlexBox({
								alignItems: "Start",
								justifyContent: "Start",
								items: [
									new sap.ui.core.HTML({
										content: '<svg width="23" height="23" viewBox="2.5840001106262207 0 33.40299987792969 38.57099914550781" fill="none" xmlns="http://www.w3.org/2000/svg">' +
											'<path d="M19.286 0L35.987 9.643V28.929L19.286 38.571L2.584 28.929V9.643L19.286 0Z" fill="' + color + '"/>' +
											'<path d="M19.286 27.771V36.643" stroke="white" stroke-width="1.5428571428571425" stroke-linecap="round" stroke-linejoin="round"/>' +
											'<path d="M19.286 2.314V11.571" stroke="white" stroke-width="1.5428571428571425" stroke-linecap="round" stroke-linejoin="round"/>' +
											'<path cx="49.5" cy="50.5" r="20.5" stroke="white" stroke-width="1.5428571428571425" stroke-linecap="round" d="M27 19.479A7.907 7.907 0 0 1 19.093 27.386A7.907 7.907 0 0 1 11.186 19.479A7.907 7.907 0 0 1 27 19.479z"/>' +
											'<path cx="49.5" cy="50.5" r="20.5" fill="white" d="M27 19.479A7.907 7.907 0 0 1 19.093 27.386A7.907 7.907 0 0 1 11.186 19.479A7.907 7.907 0 0 1 27 19.479z"/>' +
											"</svg>"
									}),
									new sap.m.Text({
										text: ServiceStatus.Completed_Unachieved
									}).addStyleClass("legendTitle serviceOutcomeTitle")
								]
							})
						]
					}),
					new sap.m.CustomListItem({
						content: [
							new sap.m.FlexBox({
								alignItems: "Start",
								justifyContent: "Start",
								items: [
									new sap.ui.core.HTML({
										content: '<svg width="22" height="22" viewBox="0.859000027179718 0.7350000143051147 26.282001495361328 30.347999572753906" fill="none" xmlns="http://www.w3.org/2000/svg">' +
											'<path d="M0.859 8.322L14 0.735L27.141 8.322V23.496L14 31.083L0.859 23.496V8.322Z" fill="white" stroke="' +
											color +
											'" stroke-width="1.2727272727272727"/>' +
											'<path d="M14 22.909V30.227" stroke="' +
											color +
											'" stroke-width="1.2727272727272727" stroke-linecap="round" stroke-linejoin="round"/><path d="M14 1.909V9.545" stroke="' +
											color +
											'" stroke-width="1.2727272727272727" stroke-linecap="round" stroke-linejoin="round"/>' +
											'<path cx="43.5" cy="50.5" r="20.5" stroke="' +
											color +
											'" stroke-width="1.2727272727272727" stroke-linecap="round" d="M20.364 16.068A6.523 6.523 0 0 1 13.841 22.591A6.523 6.523 0 0 1 7.318 16.068A6.523 6.523 0 0 1 20.364 16.068z"/>' +
											"</svg>"
									}),
									new sap.m.Text({
										text: ServiceStatus.Incompleted_Unachieved
									}).addStyleClass("legendTitle serviceOutcomeTitle")
								]
							})
						]
					}),
					new sap.m.CustomListItem({
						content: [
							new sap.m.FlexBox({
								alignItems: "Start",
								justifyContent: "Start",
								items: [
									new sap.ui.core.HTML({
										content: '<svg width="22" height="22" viewBox="2.2779998779296875 0 29.444000244140625 34" fill="none" xmlns="http://www.w3.org/2000/svg">' +
											'<path d="M17 0L31.722 8.5V25.5L17 34L2.278 25.5V8.5L17 0Z" fill="' +
											color +
											'"/>' +
											'<path d="M17 24.48V32.3" stroke="white" stroke-width="1.36" stroke-linecap="round" stroke-linejoin="round"/>' +
											'<path d="M17 2.04V10.2" stroke="white" stroke-width="1.36" stroke-linecap="round" stroke-linejoin="round"/>' +
											'<path cx="49.5" cy="50.5" r="20.5" stroke="white" stroke-width="1.36" stroke-linecap="round" d="M23.8 17.17A6.97 6.97 0 0 1 16.83 24.14A6.97 6.97 0 0 1 9.86 17.17A6.97 6.97 0 0 1 23.8 17.17z"/>' +
											"</svg>"
									}),
									new sap.m.Text({
										text: ServiceStatus.Completed_Achieved
									}).addStyleClass("legendTitle serviceOutcomeTitle")
								]
							})
						]
					}),
					new sap.m.CustomListItem({
						content: [
							new sap.m.FlexBox({
								alignItems: "Start",
								justifyContent: "Start",
								items: [
									new sap.ui.core.HTML({
										content: '<svg width="22" height="22" viewBox="2.9580001831054688 0.7849999666213989 28.083999633789062 32.43000030517578" fill="none" xmlns="http://www.w3.org/2000/svg">' +
											'<path d="M2.958 8.893L17 0.785L31.042 8.893V25.107L17 33.215L2.958 25.107V8.893Z" fill="white" stroke="' +
											color +
											'" stroke-width="1.36"/>' +
											'<path d="M17 24.48V32.3" stroke="' +
											color +
											'" stroke-width="1.36" stroke-linecap="round" stroke-linejoin="round"/>' +
											'<path d="M17 2.04V10.2" stroke="' +
											color +
											'" stroke-width="1.36" stroke-linecap="round" stroke-linejoin="round"/>' +
											'<path cx="49.5" cy="50.5" r="20.5" fill="' +
											color +
											'" stroke="' +
											color +
											'" stroke-width="1.36" stroke-linecap="round" d="M23.8 17.17A6.97 6.97 0 0 1 16.83 24.14A6.97 6.97 0 0 1 9.86 17.17A6.97 6.97 0 0 1 23.8 17.17z"/>' +
											"</svg>"
									}),
									new sap.m.Text({
										text: ServiceStatus.Incompleted_Achieved
									}).addStyleClass("legendTitle serviceOutcomeTitle")
								]
							})
						]
					}),
					new sap.m.CustomListItem({
						content: [
							new sap.m.FlexBox({
								alignItems: "Start",
								justifyContent: "Start",
								items: [
									new sap.ui.core.HTML({
										content: '<svg class="activityLegendIcon" width="25" height="25" viewBox="0 0 20 20">' +
											'<circle cx="10" cy="13.5" r="10" transform="rotate(90 10 10) scale(0.8)" fill="' + color +
											'" stroke="white" stroke-width="2" />' +
											"</svg>"
									}),
									new sap.m.Text({
										text: "Activity"
									}).addStyleClass("legendTitle activityLegendTitle")
								]
							}).addStyleClass("separator")
						]
					}),

					new sap.m.CustomListItem({
						content: [
							new sap.m.FlexBox({
								alignItems: "Start",
								justifyContent: "Start",
								items: [
									new sap.ui.core.HTML({
										content: '<svg width="20" height="20" viewBox="0 0 13.6 13.6" fill="none" xmlns="http://www.w3.org/2000/svg">' +
											'<path fill-rule="evenodd" clip-rule="evenodd" d="M6.878 13.277C10.413 13.277 13.277 10.413 13.277 6.878C13.277 3.345 10.413 0.48 6.878 0.48C3.345 0.48 0.48 3.345 0.48 6.878C0.48 10.413 3.345 13.277 6.878 13.277ZM10.643 3.881C10.955 4.194 10.955 4.7 10.643 5.013L5.845 9.811C5.532 10.124 5.025 10.124 4.713 9.811L3.114 8.212C2.801 7.899 2.801 7.393 3.114 7.081C3.425 6.768 3.933 6.768 4.245 7.081L5.279 8.115L9.512 3.881C9.825 3.569 10.331 3.569 10.643 3.881Z" fill="' +
											color +
											'"/>' +
											"</svg>"
									}),
									new sap.m.Text({
										text: ServiceStatus.Achieved
									}).addStyleClass("legendTitle serviceLegendTitle")
								]
							})
						]
					}),
					new sap.m.CustomListItem({
						content: [
							new sap.m.FlexBox({
								alignItems: "Start",
								justifyContent: "Start",
								items: [
									new sap.ui.core.Icon({
										src: "sap-icon://lightbulb",
										color: color
									}).addStyleClass("recommendedLegendIcon"),
									new sap.m.Text({
										text: "Recommended"
									}).addStyleClass("legendTitle recommendedLegendTitle")
								]
							})
						]
					}),
					new sap.m.CustomListItem({
						content: [
							new sap.m.FlexBox({
								alignItems: "Start",
								justifyContent: "Start",
								items: [
									new sap.ui.core.Icon({
										src: "sap-icon://thumb-up",
										color: color
									}).addStyleClass("plannedLegendIcon"),
									new sap.m.Text({
										text: "Planned"
									}).addStyleClass("legendTitle plannedLegendTitle")
								]
							})
						]
					}),

					new sap.m.CustomListItem({
						content: [
							new sap.m.FlexBox({
								alignItems: "Start",
								justifyContent: "Start",
								items: [
									new sap.ui.core.Icon({
										src: "sap-icon://thumb-down",
										color: color
									}).addStyleClass("plannedLegendIcon"),
									new sap.m.Text({
										text: "Not Applicable"
									}).addStyleClass("legendTitle plannedLegendTitle")
								]
							})
						]
					}),

					new sap.m.CustomListItem({
						content: [
							new sap.m.FlexBox({
								alignItems: "Start",
								justifyContent: "Start",
								items: [
									new sap.ui.core.Icon({
										src: "sap-icon://favorite",
										color: color
									}).addStyleClass("requiredLegendIcon"),
									new sap.m.Text({
										text: "Required"
									}).addStyleClass("legendTitle requiredLegendTitle")
								]
							})
						]
					}),

					new sap.m.CustomListItem({
						content: [
							new sap.m.FlexBox({
								alignItems: "Start",
								justifyContent: "Start",
								items: [
									new sap.ui.core.Icon({
										src: "sap-icon://add-activity-2",
										color: color
									}).addStyleClass("registeredLegendIcon"),
									new sap.m.Text({
										text: "Registered"
									}).addStyleClass("legendTitle registeredLegendTitle")
								]
							})
						]
					}),
					new sap.m.CustomListItem({
						content: [
							new sap.m.FlexBox({
								alignItems: "Start",
								justifyContent: "Start",
								items: [
									new sap.ui.core.Icon({
										src: "sap-icon://accept",
										color: color
									}).addStyleClass("acceptIcon"),
									new sap.m.Text({
										text: "Started"
									}).addStyleClass("legendTitle acceptLegendTitle")
								]
							})
						]
					}),
					new sap.m.CustomListItem({
						content: [
							new sap.m.FlexBox({
								alignItems: "Start",
								justifyContent: "Start",
								items: [
									new sap.ui.core.Icon({
										src: "sap-icon://accept",
										color: color
									}).addStyleClass("acceptIcon"),
									new sap.m.Text({
										text: "Presented"
									}).addStyleClass("legendTitle acceptLegendTitle")
								]
							})
						]
					}),
					new sap.m.CustomListItem({
						content: [
							new sap.m.FlexBox({
								alignItems: "Start",
								justifyContent: "Start",
								items: [
									new sap.ui.core.Icon({
										src: "sap-icon://accept",
										color: color
									}).addStyleClass("acceptIcon"),
									new sap.m.Text({
										text: "Progressing"
									}).addStyleClass("legendTitle acceptLegendTitle")
								]
							})
						]
					}),
					new sap.m.CustomListItem({
						content: [
							new sap.m.FlexBox({
								alignItems: "Start",
								justifyContent: "Start",
								items: [
									new sap.ui.core.Icon({
										src: "sap-icon://flag",
										color: color
									}).addStyleClass("acceptIcon"),
									new sap.m.Text({
										text: "Validated"
									}).addStyleClass("legendTitle acceptLegendTitle")
								]
							})
						]
					}),
					new sap.m.CustomListItem({
						content: [
							new sap.m.FlexBox({
								alignItems: "Start",
								justifyContent: "Start",
								items: [
									new sap.ui.core.Icon({
										src: "sap-icon://flag-2",
										color: color
									}).addStyleClass("completedLegendIcon"),
									new sap.m.Text({
										text: "Completed"
									}).addStyleClass("legendTitle completedLegendTitle")
								]
							}).addStyleClass("separator")
						]
					}),
					new sap.m.CustomListItem({
						content: [
							new sap.m.FlexBox({
								alignItems: "Start",
								justifyContent: "Start",
								items: [
									new sap.ui.core.HTML({
										content: '<svg class="completedTimelineLegendIcon" width="25" height="25" viewBox="0 0 25 25">' +
											'<g transform="translate(6 3) scale(0.8)"><polygon points="18,0 18,18 0,9" fill="' + color + '" />' +
											'<line x1="-7" y1="9" x2="18" y2="9" stroke-width="3" stroke="' + color + '" /></g>' +
											"</svg>"
									}),
									new sap.m.Text({
										text: "Completed"
									}).addStyleClass("legendTitle completedTimelineLegendTitle")
								]
							})
						]
					}),
					new sap.m.CustomListItem({
						content: [
							new sap.m.FlexBox({
								alignItems: "Start",
								justifyContent: "Start",
								items: [
									new sap.ui.core.HTML({
										content: '<svg class="unCompletedTimelineLegendIcon" width="25" height="25" viewBox="0 0 25 25">' +
											'<g transform="translate(6 3) scale(0.8)"><polygon points="18,0 18,18 0,9" fill="' + color + '" />' +
											'<line x1="-10" y1="9" x2="18" y2="9" stroke-width="3" stroke-dasharray="7,3" stroke="' + color + '" /></g>' +
											"</svg>"
									}),
									new sap.m.Text({
										text: "Uncompleted"
									}).addStyleClass("legendTitle unCompletedTimelineLegendTitle")
								]
							})
						]
					})
				]
			}).addStyleClass("slChartKey sapUiContentPadding"));

			this.setAggregation("_chart", new sap.ui.core.HTML(this.getId() + "-chart", {
				preferDOM: false
			}).addStyleClass("slChartContainer"));
			this._setChart();

			$(document).off("click", ".phase");
			$(document).on("click", ".phase", function () {
				const $phaseWrapper = $(this).parent();
				const $services = $phaseWrapper.children(".services");
				let bCollapse = false;
				if ($services.attr('class') === 'services show') { // hide
					bCollapse = true;
				}
				// that.expandCollapsePhase($(this), bCollapse);

				that._collapseExpandPhase($(this), bCollapse, false, true);

				const phaseId = $(this).parent().attr("data-phase-value");

				that.fireEvent("expand", {
					phaseId: phaseId,
					serviceId: "",
					touchpointId: "",
					expanded: !bCollapse
				});
			});

			$(document).off("click", ".service");
			$(document).on("click", ".service", function () {
				let bCollapse = false;
				var $activities = $(this).parent().children(".activities");
				if ($activities.attr('class') === 'activities show') {
					bCollapse = true;
				}
				that.expandCollapseService($(this), bCollapse);

				const phaseId = $(this).parent().parent().attr("data-phase-value");
				const serviceId = $(this).parent().parent().attr("data-service-value");
				const touchpointId = $(this).parent().parent().attr("data-service-tpointid");

				that.fireEvent("expand", {
					phaseId: phaseId,
					serviceId: serviceId,
					touchpointId: touchpointId,
					expanded: !bCollapse
				});
			});

			$(document).off("click", ".phaseTitle");
			$(document).on("click", ".phaseTitle", function (e) {
				e.stopImmediatePropagation();

				const $phaseWrapper = $(this).parent().parent().parent();
				let bSelected = false;
				const id = $phaseWrapper.attr("id");
				if ($phaseWrapper.attr("data-selected") === "true") {
					bSelected = false;
				} else {
					bSelected = true;
				}

				that._selectElement(id, bSelected, "PHASE");
			});

			$(document).off("click", ".serviceTitle")
			$(document).on("click", ".serviceTitle", function (e) {
				e.stopImmediatePropagation();

				const $serviceWrapper = $(this).parent().parent().parent();
				let bSelected = false;
				const id = $serviceWrapper.attr("id");
				if ($serviceWrapper.attr("data-selected") === "true") {
					bSelected = false;
				} else {
					bSelected = true;
				}

				that._selectElement(id, bSelected, "SERVICE");
			});

			$(document).off("click", ".timelineDate")
			$(document).on("click", ".timelineDate", function () {
				const id = $(this).attr("data-activityid");
				let bSelected = false;
				if ($(this).attr("data-selected") === "true") {
					bSelected = false;
				} else {
					bSelected = true;
				}

				that._selectElement(id, bSelected, "ACTIVITY");
			});

			$(document).off("click", ".slChartActivity");
			$(document).on("click", ".slChartActivity", function () {
				const id = $(this).attr("id");
				let bSelected = false;
				if ($(this).attr("data-selected") === "false") {
					bSelected = true;
				} else {
					bSelected = false;
				}

				that._selectElement(id, bSelected, "ACTIVITY");
			});

			$(document).off("click", ".slChartActivityDetailButton");
			$(document).on("click", ".slChartActivityDetailButton", function (e) {

				e.stopImmediatePropagation();

				const id = $(this).attr("id");
				let bSelected = false;
				let iRotateAngle = 0;

				that._resetActivityDetail();

				if ($(this).attr("class") === "slChartActivityDetailButton expanded") {
					iRotateAngle = 0;
					jQuery(this).attr("class", "slChartActivityDetailButton");
				} else {
					iRotateAngle = 180;
					jQuery(this).attr("class", "slChartActivityDetailButton expanded");

				}
				const translate = that.getTransformValue($(this)[0].getAttribute("transform"), "translate");
				$(this).attr("transform", "translate(" + translate.x + " " + translate.y + ") rotate(" + iRotateAngle + " 11 11)");
				let $activity = jQuery("#" + jQuery(this).parent().attr("data-activityid"));
				that.fireEvent("openDetail", {
					element: $(this)[0],
					activityId: $activity.attr("data-activity-value"),
					type: $activity.attr("data-activity-type")
				});
			});
			$(document).off("mouseenter", ".slChartActivity");
			$(document).on("mouseenter", ".slChartActivity", function (e) {
				let sTargetName = e.relatedTarget.tagName;
				var id = $(this).attr("id");
				var $activity = jQuery("#" + jQuery(this).parent().attr("data-activityid"));
				if (sTargetName === "svg") {
					that.fireEvent("openToolstip", {
						element: $(this)[0],
						activitySubtitle: jQuery("#" + id).attr("data-activity-subtitle-value"),
						eventType: "mouseenter"
					});
				}
			});
			$(document).off("mouseleave", ".slChartActivity");
			$(document).on("mouseleave", ".slChartActivity", function (e) {
				let sTargetName = e.relatedTarget.tagName;
				var id = $(this).attr("id");
				var $activity = jQuery("#" + jQuery(this).parent().attr("data-activityid"));
				if (sTargetName === "svg" || sTargetName === "DIV") {
					that.fireEvent("openToolstip", {
						element: $(this)[0],
						activitySubtitle: jQuery("#" + id).attr("data-activity-subtitle-value"),
						eventType: "mouseleave"
					});
				}
			});

		},

		_resetActivityDetail: function () {
			const that = this;
			jQuery(".slChartActivityDetailButton").attr("class", "slChartActivityDetailButton");

			jQuery(".slChartActivityDetailButton").each(function () {
				const activityDetailButtonTranslate = that.getTransformValue($(this).attr("transform"), "translate");
				$(this).attr("transform", "translate(" + activityDetailButtonTranslate.x + " " + activityDetailButtonTranslate.y +
					") rotate(0 11 11)");
			});
		},

		_openActivityDetailPopover: function (oSource, oActivity) {
			if (!this._pActivityDetailPopover) {
				this._pActivityDetailPopover = Fragment.load({
					name: "com.melody.lib.controls.chart.fragments.ActivityDetailPopover",
					controller: this
				}).then(function (oPopover) {
					this.addDependent(oPopover);
					return oPopover;
				});
			}
			this._pActivityDetailPopover.then(function (oPopover) {
				if (sap.ui.Device.system.desktop) { // apply compact mode if touch is not supported
					oPopover.addStyleClass("sapUiSizeCompact");
				}
				oPopover.openBy(oSource);
			});
		},

		expandCollapsePhase: function ($element, bCollapse, excluedUpdateStatus) {
			const that = this;
			var isExpand = true;
			let bSelected = false;
			var $phaseWrapper = $element.parent();

			const id = $phaseWrapper.attr("id");
			var $services = $phaseWrapper.children(".services");
			var $phaseHorizontal = $services.parent().children(".lines").children(".phaseHorizontal");
			var $phaseVertical = $services.parent().children(".lines").children(".phaseVertical");

			let isTowardsLeft = false;

			if ($phaseWrapper[0].classList.contains('towardsLeft')) {
				isTowardsLeft = true;
			}

			if (bCollapse) {
				let $horizontal = $services.parent().find(".horizontal");
				let $vertical = $services.parent().find(".vertical");
				$services.attr("class", "services");
				$horizontal.attr("y", 40);
				$horizontal.attr("transform", "rotate(-180 " + ((isTowardsLeft) ? "0" : "121") + " 40)");
				$vertical.attr("width", 40);
				isExpand = false;
				$phaseHorizontal.show();
				$phaseVertical.attr("width", 40);
				$phaseHorizontal.attr("y", 40);
				$phaseHorizontal.attr("transform", "rotate(-180 " + ((isTowardsLeft) ? "0" : "121") + " 40)");

				// jQuery(".timelineDate[data-phaseId='" + $phaseWrapper.attr("id") + "']").hide();
				jQuery(".timelineDate[data-phaseId='" + $phaseWrapper.attr("id") + "']").attr("data-visible", "false");
			} else { // show
				$services.attr("class", "services show");

				var $serviceWrapers = $services.children(".service-wrapper");
				$serviceWrapers.each(function () {
					var $activities = $(this).find(".activities");

					if ($activities.attr('class') === 'activities show') { // hide
						var $serviceDetails = $(this).find(".service-details");
						var $serviceVerticalLine = $(this).find(".vertical");
						var $serviceHorizontalLine = $(this).find(".horizontal");
						var height = parseInt($serviceDetails[0].getBoundingClientRect().height, 10) + 32;
						if ($activities.find(".slChartActivity").length === 0) {
							height = 100;
						}
						$serviceHorizontalLine.attr("y", height);
						$serviceHorizontalLine.attr("transform", "rotate(-180 " + ((isTowardsLeft) ? "0" : "121") + " " + height + ")");
						$serviceVerticalLine.attr("width", height);
						//jQuery(".timelineDate[data-serviceId='" + $(this).attr("id") + "']").show();
						jQuery(".timelineDate[data-serviceId='" + $(this).attr("id") + "']").attr("data-visible", "true");
					} else {
						let $horizontal = $(this).find(".horizontal");
						let $vertical = $(this).find(".vertical");
						$horizontal.attr("y", 80);
						$horizontal.attr("transform", "rotate(-180 " + ((isTowardsLeft) ? "0" : "121") + " 80)");
						$vertical.attr("width", 80);
						jQuery(".timelineDate[data-serviceId='" + $(this).attr("id") + "']").attr("data-visible", "false");
						// jQuery(".timelineDate[data-serviceId='" + $(this).attr("id") + "']").hide();
					}

				});

				$phaseHorizontal.hide();
				$phaseVertical.attr("width", 15);

			}
			var $nextPhases = $element.parent().nextAll(".phase-wrapper");
			that.updateNextPhasesPosition($nextPhases);

			that.setTimelineHeight();
			if (that.chartLoaded) {
				if (!excluedUpdateStatus) {
					that._updateStatus();
				}
			}
			if ($phaseWrapper.attr("class") === "phase-wrapper selected") {
				bSelected = false;
			} else {
				bSelected = true;
			}

			const data = that.getData();
			const phaseId = $phaseWrapper.attr("data-phase-value");
			const phase = data.phases.find(p => p.id === phaseId);

			if (phase) {
				phase.collapsed = bCollapse;
				if (bCollapse) {
					for (let i = 0; i < phase.services.length; i++) {
						phase.services[i].collapsed = true;
					}
				}

			}

		},

		expandCollapseService: function ($element, bCollapse, excluedUpdateStatus) {
			const that = this;
			var $phaseWrapper = $element.parent().parent().parent().parent();
			var $activities = $element.parent().children(".activities");
			if ($activities.length === 0 || $activities.find(".slChartActivity").length === 0) {
				return;
			}
			var $horizontal = $element.parent().parent().find(".horizontal");
			var $vertical = $element.parent().parent().find(".vertical");
			var $phaseHorizontal = $element.parent().parent().parent().children(".lines").children(".phaseHorizontal");
			$phaseHorizontal.hide();

			let isTowardsLeft = false;

			if ($phaseWrapper[0].classList.contains('towardsLeft')) {
				isTowardsLeft = true;
			}

			if (bCollapse) {
				$activities.attr("class", "activities");
				$activities.attr("transform", "translate(14 0)");
				$horizontal.attr("y", 70);
				$horizontal.attr("transform", "rotate(-180 " + ((isTowardsLeft) ? "0" : "121") + " 70)");
				$vertical.attr("width", 70);
				// jQuery(".timelineDate[data-serviceId='" + $element.parent().parent().attr("id") + "']").hide();
				jQuery(".timelineDate[data-serviceId='" + $element.parent().parent().attr("id") + "']").attr("data-visible", "false");
			} else { // show
				$activities.attr("class", "activities show");
				$activities.attr("transform", "translate(14 52)");
				$horizontal.attr("y", 315);
				$horizontal.attr("transform", "rotate(-180 " + ((isTowardsLeft) ? "0" : "121") + " 315)");
				$vertical.attr("width", 315);

				var $serviceWrapers = $activities.parent().parent();
				$serviceWrapers.each(function () {
					var $serviceDetails = $(this).find(".service-details");
					var $serviceVerticalLine = $(this).find(".vertical");
					var $serviceHorizontalLine = $(this).find(".horizontal");
					let height = parseInt($serviceDetails[0].getBoundingClientRect().height, 10) + 32;
					if (isTowardsLeft) {
						height = parseInt($serviceDetails[0].getBoundingClientRect().height, 10) + 34
					}
					$serviceHorizontalLine.attr("y", height);
					$serviceHorizontalLine.attr("transform", "rotate(-180 " + ((isTowardsLeft) ? "0" : "121") + " " + height + ")");
					$serviceVerticalLine.attr("width", height);
				});
				// jQuery(".timelineDate[data-serviceId='" + $element.parent().parent().attr("id") + "']").show();
				jQuery(".timelineDate[data-serviceId='" + $element.parent().parent().attr("id") + "']").attr("data-visible", "true");
			}

			var $nextServices = $element.parent().parent().nextAll(".service-wrapper");
			that.updateNextServicesPosition($nextServices);

			var $nextPhases = $element.parent().parent().parent().parent().nextAll(".phase-wrapper");
			that.updateNextPhasesPosition($nextPhases, $horizontal);

			const data = that.getData();
			const phaseId = $element.parent().parent().attr("data-phase-value");
			const phase = data.phases.find(p => p.id === phaseId);
			if (phase) {
				const serviceId = $element.parent().parent().attr("data-service-value");
				const service = phase.services.find(s => s.id === serviceId);
				if (service) {
					service.collapsed = bCollapse;
				}
			}

			that.setTimelineHeight();
			if (that.chartLoaded) {
				if (!excluedUpdateStatus) {
					that._updateStatus();
				}
			}
		},

		_collapseExpandPhase: function ($element, bCollapse, excluedUpdateStatus, onlyCollapseService) {
			const that = this;
			const $services = $element.parent().find(".service");

			if (!onlyCollapseService || bCollapse) {
				$services.each(function () {
					that.expandCollapseService($(this), bCollapse);
				});
			}

			that.expandCollapsePhase($element, bCollapse, excluedUpdateStatus);
		},

		openPresentationViewSettingsPopover: function (oEvent) {
			const oSource = oEvent.getSource();
			const that = this;
			this.Controller = (this.Controller) ? this.Controller : new SLChartController(this);
			if (!this.Controller._pPresentationViewSettingsPopover) {
				this.Controller._pPresentationViewSettingsPopover = Fragment.load({
					name: "com.melody.lib.controls.chart.fragments.PresentationViewSettingsPopover",
					controller: this.Controller
				}).then(function (oPopover) {
					return oPopover;
				});
			}
			this.Controller._pPresentationViewSettingsPopover.then(function (oPopover) {
				if (sap.ui.Device.system.desktop) { // apply compact mode if touch is not supported
					oPopover.addStyleClass("sapUiSizeCompact");
				}

				let oModel = oPopover.getModel();
				if (!oModel) {
					oModel = new JSONModel();
					oPopover.setModel(oModel);
				}

				oModel.setData(that.getSettings());

				oPopover.openBy(oSource);
			});
		},

		getSettings: function () {
			return {
				expanded: this.getExpanded(),
				autoHideCompletedPhases: this.getAutoHideCompletedPhases(),
				showPhaseMenu: this.getShowPhaseMenu(),
				showKey: this.getShowKey(),
				showTodaysDate: this.getShowTodaysDate(),
				showActivityStatus: this.getShowActivityStatus(),
				showDataLines: this.getShowDataLines(),
				showSubTitlesOnly: this.getShowSubTitlesOnly()
			}
		},

		handleBeforeCloseActivityDetailPopover: function () {
			this._resetActivityDetail();
		},

		handleCloseButton: function (oEvent) {
			this._pActivityDetailPopover.then(function (oPopover) {
				oPopover.close();
			});
		},

		_selectElement: function (id, selected, type, skipEvent) {
			let phaseId = "",
				serviceId = "",
				touchpointId = "",
				activityId = "";
			if (selected) {
				if (type.toUpperCase() === "PHASE") {
					jQuery(".phase-wrapper").attr("data-selected", "false");
					jQuery("#" + id).attr("data-selected", "true");

					jQuery(".service-wrapper").attr("data-selected", "false");

					jQuery(".slChartActivity").attr("data-selected", "false");
					jQuery(".timelineDates").children().attr("data-selected", "");

					phaseId = jQuery("#" + id).attr("data-phase-value");

				} else if (type.toUpperCase() === "SERVICE") {
					jQuery(".phase-wrapper").attr("data-selected", "false");

					jQuery(".service-wrapper").attr("data-selected", "false");
					jQuery("#" + id).attr("data-selected", "true");

					jQuery(".slChartActivity").attr("data-selected", "false");
					jQuery(".timelineDates").children().attr("data-selected", "");

					phaseId = jQuery("#" + id).attr("data-phase-value");
					serviceId = jQuery("#" + id).attr("data-service-value");
					touchpointId = jQuery("#" + id).attr("data-service-tpointid");

				} else if (type.toUpperCase() === "ACTIVITY") {
					jQuery(".phase-wrapper").attr("data-selected", "false");

					jQuery(".service-wrapper").attr("data-selected", "false");

					jQuery(".phase-wrapper .slChartActivity").attr("data-selected", "false");
					jQuery("#" + id).attr("data-selected", "true");

					jQuery(".timelineDates").children().attr("data-selected", "false");
					jQuery(".timelineDates").find(".timelineDate[data-activity='" + id + "Timeline'").attr("data-selected", "true");

					phaseId = jQuery("#" + id).attr("data-phase-value");
					serviceId = jQuery("#" + id).attr("data-service-value");
					activityId = jQuery("#" + id).attr("data-activity-value");
					touchpointId = jQuery("#" + id).attr("data-service-tpointid");
				}

				if (!skipEvent) {
					this.fireEvent("select", {
						type: type.toUpperCase(),
						phaseId: phaseId,
						serviceId: serviceId,
						activityId: activityId,
						touchpointId: touchpointId
					});
				}

			} else {
				jQuery(".phase-wrapper").attr("data-selected", "false");

				jQuery(".service-wrapper").attr("data-selected", "false");

				jQuery(".slChartActivity").attr("data-selected", "false");
				jQuery(".timelineDates").children().attr("data-selected", "");
			}

			const data = this.getData();

			if (phaseId !== "") {
				for (let i = 0; i < data.phases.length; i++) {
					const phase = data.phases[i];
					if (phase.id === phaseId) {
						if (serviceId !== "") {
							phase.selected = false;
						} else {
							phase.selected = selected;
						}
					} else {
						phase.selected = false;
					}

					for (let j = 0; j < phase.services.length; j++) {
						const service = phase.services[j];
						if (service.id === serviceId) {
							if (activityId !== "") {
								service.selected = false;
							} else {
								service.selected = selected;
							}
						} else {
							service.selected = false;
						}

						for (let k = 0; k < service.activities.length; k++) {
							const activity = service.activities[k];
							if (activity.id === activityId) {
								activity.selected = selected;
							} else {
								activity.selected = false;
							}
						}
					}
				}
				/*const phase = data.phases.find(p => {
					if (p.id === phaseId) {
						return true;
					} else {
						p.selected = false;
						return false;
					}
				});
				if (phase) {
					if (serviceId !== "") {
						phase.selected = false;
						const service = phase.services.find(s => {
							if (s.id === serviceId) {
								return true;
							} else {
								s.selected = false;
								return false;
							}
						});
						if (service) {
							if (activityId !== "") {
								service.selected = false;
								const activity = service.activities.find(a => {
									if (a.id === activityId) {

									} else {
										a.selected = false;
										return false;
									}
								});
								if (activity) {
									activity.selected = selected;
								}
							} else {
								service.selected = selected;
							}
						}
					} else {
						phase.selected = selected;
					}
				}*/
			}
		},

		updateNextServicesPosition: function ($nextServices) {
			const chart = this;
			$nextServices.each(function () {
				var x = 0;
				var y = 0;
				var $prevServices = $(this).prevAll(".service-wrapper");
				var $phaseWrapper = $(this).parent().parent();
				let isTowardsLeft = false;
				if ($phaseWrapper.hasClass("towardsLeft")) {
					isTowardsLeft = true;
				}
				if ($prevServices.length > 0) {
					var $refrenceElement = $prevServices[0];
					var refTransformValue = chart.getTransformValue($refrenceElement.getAttribute("transform"), "translate");
					var activities = $refrenceElement.querySelector('.activities');

					if (activities.classList.contains('show')) {
						const $prevServiceLines = $refrenceElement.querySelector('.service-lines');

						const aSlChartActivities = $(activities).find(".slChartActivity")
						var lastActivity = aSlChartActivities[aSlChartActivities.length - 1];

						y = parseInt(refTransformValue.y, 10) + parseInt($refrenceElement.getBoundingClientRect().height, 10) - 27;

						$(this).attr("transform", "translate(18 " + (y) + ")");

					} else {
						if (isTowardsLeft) {
							$(this).attr("transform", "translate(18 " + (parseInt(refTransformValue.y,
								10) + 56) + ")");
						} else {
							$(this).attr("transform", "translate(18 " + (parseInt(refTransformValue.y,
								10) + 56) + ")");
						}
					}

				}

			});
		},

		updateNextPhasesPosition: function ($nextPhases) {
			const chart = this;
			$nextPhases.each(function () {
				var x = 0;
				var y = 0;
				var $prevPhases = $(this).prevAll(".phase-wrapper");
				let isLeft = false;
				if ($(this).hasClass("left")) {
					isLeft = true;
				}
				if ($prevPhases.length > 0) {
					var $refrenceElement = $prevPhases[0];
					var refTransformValue = chart.getTransformValue($refrenceElement.getAttribute("transform"), "translate");
					var services = $refrenceElement.querySelector('.services');

					if (services.classList.contains('show')) {
						var $serviceWrapers = $(services).children(".service-wrapper");
						if ($serviceWrapers.length > 0) {
							var lastServiceWrapper = $serviceWrapers[$serviceWrapers.length - 1];
							var serviceTransformValue = chart.getTransformValue(lastServiceWrapper.getAttribute("transform"), "translate");

							var verticalLine = lastServiceWrapper.querySelector('.vertical');

							var horizontalLine = lastServiceWrapper.querySelector('.horizontal');

							if (isLeft) {
								x = parseFloat(refTransformValue.x, 10) + parseFloat(serviceTransformValue.x, 10) - 17 - parseFloat(horizontalLine.getAttribute(
									"width"), 10);
							} else {
								x = parseFloat(refTransformValue.x, 10) + parseFloat(serviceTransformValue.x, 10) + 17 + parseFloat(horizontalLine.getAttribute(
									"width"), 10) - 36;
							}

							y = parseFloat(refTransformValue.y, 10) + parseFloat(serviceTransformValue.y, 10) + 15 + parseFloat(verticalLine.getAttribute(
								"width"), 10) - 36;

							$(this).attr("transform", "translate(" + (x) + " " + (y) + ")");
						}

					} else {
						if (isLeft) {
							$(this).attr("transform", "translate(" + (parseFloat(refTransformValue.x, 10) - 126) + " " + (parseFloat(refTransformValue.y,
								10) + 56) + ")");
						} else {
							$(this).attr("transform", "translate(" + (parseFloat(refTransformValue.x, 10) + 126) + " " + (parseFloat(refTransformValue.y,
								10) + 56) + ")");
						}
					}

				}

			});
		},

		setTimelineHeight: function () {
			var timelineHeight = parseInt($(".phases")[0].getBoundingClientRect().height, 10);
			$(".timeline").find(".timeline-bar").attr("height", timelineHeight);
		},

		getTransformValue: function (transform, type) {

			var transformValue = "";
			var transformValueSplit = [];

			let iSearchIndex = -1,
				iStartIndex = -1,
				iEndIndex = -1;

			if (type && type !== "" && type.toUpperCase() === "TRANSLATE") {
				iSearchIndex = transform.indexOf("translate(");
				iStartIndex = transform.indexOf("(", iSearchIndex);
				iEndIndex = transform.indexOf(")", iSearchIndex);
			}

			if (transform && transform !== "") {
				transformValue = transform.substring(iStartIndex + 1, iEndIndex).trim();
				transformValueSplit = transformValue.split(" ");

				if (type && type !== "" && type.toUpperCase() === "TRANSLATE") {
					if (transformValueSplit.length === 2) {
						return {
							x: transformValueSplit[0],
							y: transformValueSplit[1]
						}
					}
				}
			}

		},

		updateChart: function () {
			this._setChart();
		},

		clearSelection: function () {
			this._setChart(true);
		},

		_setChart: function (bClearSelection) {
			const that = this;
			this.completedPhases = [];
			this.collapsedPhases = [];
			this.collapsedServices = [];
			this.selectedElement = null;
			let phaseBarContent = '<div></div>';

			let content = '<svg id="' + this.getId() +
				'-slChart" class="slChart" viewBox="0 0 1200 3500" fill="none" xmlns="http://www.w3.org/2000/svg">' +
				'<g transform="translate(60 0)">' +
				'<g class="timeline" transform="translate(0 62)">' +
				'<rect class="timeline-bar" x="0.5" y="0.5" width="15" height="3500" rx="7.5" fill="#FAFAFA" stroke="#74777A" />' +
				'<g class="timelineDates" transform="translate(0 0)"></g>' +
				'</g>' +
				'<g transform="translate(250 0)" class="phases">';

			const data = this.getData() || {};

			if (Object.keys(data).length && Object.values(data).indexOf("") === -1) {
				let phaseX = 35,
					phaseY = 56;
				let moveRight = true,
					breakpoint = 3,
					moveRightChanged = false;
				let aPhases = $.extend(true, [], data.phases);
				if (aPhases.length) {
					for (let i = 0; i < data.phases.length; i++) {

						if (data.phases[i].collapsed) {
							this.collapsedPhases.push('slChartPhase' + (i + 1));
						}

						let iCompletedActivitiesCount = 0,
							iTotalActivities = 0;
						let rightText = moveRight;

						if (moveRightChanged) {
							rightText = !moveRight;
						}

						let phaseLineX = 121;
						if (!moveRight) {
							phaseLineX = 0;
						}
						let lines = '<g class="lines" transform="translate(35 56)">' +
							'<rect class="phaseHorizontal line" x="' + phaseLineX +
							'" y="315" width="126" height="5.99999" rx="2.99999" transform="rotate(-180 ' + phaseLineX + ' 315)" fill="' +
							data.phases[i].color + '" />' +
							'<rect class="phaseVertical line" x="0" y="0" width="15" height="5.99999" rx="2.99999" transform="rotate(90 0 0)" fill="' +
							data
							.phases[i].color + '" />' +
							'</g>';

						content += '<g id="slChartPhase' + (i + 1) + '" data-phase="slChartPhase' + data.phases[i].id + '" data-phase-value="' + data.phases[
								i].id + '" class="phase-wrapper ' + ((
								rightText) ? '' : 'left') + ' ' + ((moveRight) ? '' :
								'towardsLeft') + '" transform="translate(' + phaseX + ' ' + phaseY + ')">' +
							lines;

						if (data.phases[i].selected) {
							this.selectedElement = {
								id: 'slChartPhase' + (i + 1),
								type: "PHASE"
							}
						}

						if (bClearSelection) {
							data.phases[i].selected = false;
						}

						content += '<g class="services show">';
						let serviceX = 18,
							serviceY = 56;
						if (data.phases[i].services && data.phases[i].services.length > 0) {
							for (let j = 0; j < data.phases[i].services.length; j++) {

								if (data.phases[i].services[j].collapsed) {
									this.collapsedServices.push('slChartPhase' + (i + 1) + 'Service' + (j + 1));
								}

								let iServiceActivitiesCount = 0;
								let lineHeight = 0;

								if (data.phases[i].services[j].selected) {
									this.selectedElement = {
										id: 'slChartPhase' + (i + 1) + 'Service' + (j + 1),
										type: "SERVICE"
									}
								}

								if (bClearSelection) {
									data.phases[i].services[j].selected = false;
								}

								let activities = '<g class="activities show" transform="translate(14 52)">';
								// loop to add activities
								let activityY = 0;
								if (data.phases[i].services[j].activities && data.phases[i].services[j].activities.length > 0) {
									for (let k = 0; k < data.phases[i].services[j].activities.length; k++) {
										const selectedActivity = data.phases[i].services[j].activities[k];
										if (data.phases[i].services[j].active && selectedActivity.active) {
											iTotalActivities += 1;
										}
										let aValidations = [ActivityStatus.Validated, ActivityStatus.Completed, ActivityStatus.Customer_Validated];
										if ((aValidations.indexOf(selectedActivity.status) !== -1) &&
											(data.phases[i].services[j].active && selectedActivity.active)) {
											iCompletedActivitiesCount += 1;
											iServiceActivitiesCount += 1;
										}

										let titleY = 5;
										let sShortSubtxt = '';
										let sSubtitle = "";
										let bShowSubTitleOnly = that.getShowSubTitlesOnly();
										if (selectedActivity.subTitle) {
											sSubtitle = selectedActivity.subTitle;
											sSubtitle = sSubtitle.replaceAll('"', ' ');
											var iSubMaxLen = sSubtitle.length;
											if (iSubMaxLen < 65) {
												sShortSubtxt = sSubtitle;
											} else {
												sShortSubtxt = sSubtitle.slice(0, 65) + "....";
											}
										}

										if (!selectedActivity.subTitle || selectedActivity.subTitle === "") {
											bShowSubTitleOnly = false;
											titleY = 11;
										}

										activities += '<g id="slChartPhase' + (i + 1) + 'Service' + (j + 1) + 'Activity' + (k + 1) +
											'" class="slChartActivity" data-phase-value="' + data.phases[i].id + '" data-service-value="' + data.phases[i].services[j].id +
											'"data-service-tpointid="' + data.phases[i].services[j].touchpointId + '" data-activity-type="' + selectedActivity.type +
											'" data-activity-value="' + selectedActivity.id + '" data-activity-subtitle-value= "' + sSubtitle +
											'" transform="translate(0 ' + activityY + ')">' + this._getActivity(
												selectedActivity.status, data.phases[i].color, data.phases[i].services[j].active && selectedActivity.active) +
											'<g transform="translate(21 -10)">' + '<g class="activityContent">' + "<text x='0' y='" + titleY +
											"' alignment-baseline='middle' font-size='10' stroke-width='0' stroke='white' fill='" + data.phases[i].color +
											"'><tspan style='display:" + (bShowSubTitleOnly ? "none" : "block") + "'>" +
											selectedActivity.title + "</tspan></text>" +
											"<text x='0' y='16' alignment-baseline='middle' font-size='10' font-style='italic' stroke-width='0' stroke='white' fill='" +
											data.phases[i].color + "'><tspan style='cursor : pointer'>" +
											sShortSubtxt + "</tspan></text>" +
											'</g>' +
											'</g>' +
											'</g>';
										if (k < data.phases[i].services[j].activities.length - 1) {
											activityY += 42;
										}

										if (selectedActivity.selected) {
											this.selectedElement = {
												id: 'slChartPhase' + (i + 1) + 'Service' + (j + 1) + 'Activity' + (k + 1),
												type: "ACTIVITY"
											}
										}

										if (bClearSelection) {
											selectedActivity.selected = false;
										}
									}
								}

								activityY += 100;

								activities += '</g>';
								let serviceLineX = 121;
								if (!moveRight) {
									serviceLineX = 0;
								}

								// same line code starts here
								let serviceLines = '<g class="service-lines" transform="translate(17 15)">' +

									'<rect class="vertical line" x="0" y="0" width="' + activityY +
									'" height="5.99999" rx="2.99999" transform="rotate(90 0 0)" fill="' + data.phases[
										i].color + '" />';

								if (j === data.phases[i].services.length - 1) {
									serviceLines += '<rect class="horizontal line" x="' + serviceLineX + '" y="' + activityY +
										'" width="126" height="5.99999" rx="2.99999" transform="rotate(-180 ' + serviceLineX + ' ' + activityY + ')" fill="' +
										data.phases[i].color + '" />';
								}
								serviceLines += '</g>';

								// same line code ends here

								let rightServiceText;

								if (!moveRight && j > 0) {
									rightServiceText = false;
								} else {
									rightServiceText = true;
								}

								// same line code starts here		
								content += '<g id="slChartPhase' + (i + 1) + 'Service' + (j + 1) + '" data-phase-value="' + data.phases[i].id +
									'" data-service-value="' + data.phases[i].services[j].id + '" data-service-tpointid="' + data.phases[i].services[j].touchpointId +
									'" class="service-wrapper" transform="translate(18 ' +
									serviceY + ')">' +
									'<g transform="translate(7 3)">' +
									'<g class="serviceContent">' +
									'<text x="35" y="26" text-anchor="start" class="serviceTitle" alignment-baseline="middle" font-size="12" stroke-width="0" stroke="white" fill="' +
									data.phases[i].color + '">' + data.phases[
										i].services[j].title + '</text>' +
									'</g>' +
									'</g>' +
									serviceLines;
								// same line code ends here

								content += '<g class="service-details" transform="translate(0 10)">' +
									this._getService((!data.phases[i].services[j].activities || data.phases[i].services[j].activities.length ===
										iServiceActivitiesCount), data.phases[i].color, data.phases[i].services[j].serviceType, data.phases[i].services[j].achieved) +
									activities;

								content += '</g></g>';
								if (data.phases[i].services.length === j + 1) {
									phaseY += 35 + activityY;
								} else {
									phaseY += activityY - 14;
								}

								serviceY += activityY - 14;

							}
						} else {
							this.completedPhases.push('slChartPhase' + (i + 1));
						}
						content += '</g>';

						let percent = 0;

						if (data.phases[i].percent && data.phases[i].percent !== "") {
							percent = data.phases[i].percent;
						} else if (iTotalActivities > 0) {
							percent = Math.round((iCompletedActivitiesCount / iTotalActivities) * 100);
						}

						/*if (iTotalActivities > 0) {
							percent = ((iCompletedActivitiesCount / iTotalActivities) * 100).toPrecision(3);
						}*/

						if (parseFloat(percent, 10) === 100) {
							this.completedPhases.push('slChartPhase' + (i + 1));
						}

						let phaseRing = '<g class="phase progress-ring">' +
							'<g transform="translate(5 6)" class="melodyRadialChart">' +
							'<circle cx="26" cy="26" r="26" transform="rotate(0 26 26)" fill="white" stroke="' + data.phases[i].color +
							'" stroke-width="2" />' +
							'<g class="melodyRadialChartInnerContent">' +
							this._getPhase(percent, data.phases[i].color) +
							'</g>' +
							'<text x="' + ((rightText) ? '65' : '-15') + '" y="28" class="phaseTitle" letter-spacing="0.8" text-anchor="' + ((rightText) ?
								'start' : 'end') +
							'" alignment-baseline="middle" font-size="14" font-weight="bold" stroke-width="0" stroke="white" fill="' +
							data.phases[i].color + '">' + data.phases[i].title + '</text>' +
							'</g></g>';

						content += phaseRing;

						content += '</g>';

						// same line code starts here
						if (moveRight) {
							phaseX += 125;
						} else {
							phaseX -= 125;
						}
						// same line code ends here

						if (i + 1 === data.phases.length) {

							let isSlCompleted = false;

							if (this.completedPhases.length === data.phases.length) {
								isSlCompleted = true;
							}

							content += '<g class="phase-wrapper ' + ((
									moveRight) ? '' : 'left') + ' ' + ((moveRight) ? '' :
									'towardsLeft') + '" transform="translate(' + phaseX + ' ' + phaseY + ')">' +
								'<g>' +
								"<g transform='translate(5 6)' class='melodyRadialChart'>" +
								"<circle cx='26' cy='26' r='26' transform='rotate(0 26 26)' fill='white' stroke='" + data.phases[i].color +
								"' stroke-width='2' />" +
								"<g class='melodyRadialChartInnerContent'>" +
								"<circle cx='26' cy='26' r='21' transform='rotate(0 26 26)' fill='" + ((isSlCompleted) ? data.phases[i].color : "white") +
								"' stroke='white' stroke-width='0' />" +
								'<g transform="translate(16 13)">' +
								'<path d="M0.375002 0.687504H2.0625V27.6875H0.375002V0.687504ZM16.5645 2.42774C17.0566 2.42774 17.4609 2.39258 17.7773 2.32227C18.1289 2.25196 18.4277 2.14649 18.6738 2.00586C18.9551 1.86524 19.2363 1.68946 19.5176 1.47852C19.834 1.26758 20.2031 1.00391 20.625 0.687504V13.291C20.1328 13.7832 19.6055 14.2227 19.043 14.6094C18.5508 14.9258 18.0059 15.2246 17.4082 15.5059C16.8105 15.752 16.1953 15.875 15.5625 15.875C15.3867 15.875 14.9824 15.7871 14.3496 15.6113L10.1309 14.4512C9.46289 14.2754 9.02344 14.1875 8.8125 14.1875C7.79297 14.1875 6.89649 14.3281 6.12305 14.6094C5.34961 14.8555 4.5586 15.2773 3.75 15.875V4.00977C4.10156 3.41211 4.5586 2.86719 5.12109 2.375C5.61328 1.95313 6.19336 1.56641 6.86133 1.21485C7.56445 0.863285 8.4082 0.687504 9.39258 0.687504C9.63867 0.687504 10.1133 0.775394 10.8164 0.951175C11.5195 1.12696 12.2578 1.33789 13.0313 1.58399C13.8398 1.79493 14.5781 1.98828 15.2461 2.16407C15.9141 2.33985 16.3535 2.42774 16.5645 2.42774Z" fill="' +
								((isSlCompleted) ? "white" : data.phases[i].color) + '"/>' +
								'</g>' +
								"</g>" +
								"</g>" +
								"</g>" +
								"</g>";
						}

						if ((i + 1) % breakpoint === 0) {
							moveRight = !moveRight;
							moveRightChanged = true;
						} else {
							moveRightChanged = false;
						}
					}
				}
			}

			content += '</g>' +
				'</g>';
			content += '</svg>';
			this.getAggregation("_chart").setContent(content);

			setTimeout(function () {

				for (let i = 0; i < that.collapsedServices.length; i++) {
					const $collapsedServiceWrapper = jQuery("#" + that.getId() + "-slChart").find("#" + that.collapsedServices[i]);
					const $refernceElement = $collapsedServiceWrapper.find(".service");
					that.expandCollapseService($refernceElement, true, true);
				}

				for (let i = 0; i < that.collapsedPhases.length; i++) {
					const $collapsedPhaseWrapper = jQuery("#" + that.getId() + "-slChart").find("#" + that.collapsedPhases[i]);
					const $refernceElement = $collapsedPhaseWrapper.find(".phase");
					// that.expandCollapsePhase($refernceElement, true, true);
					that._collapseExpandPhase($refernceElement, true, true, true);
				}

				that._updateStatus(bClearSelection);

				that.chartLoaded = true;
				// that._setPan();
			}, 100);

		},

		_setPan: function () {
			const svgId = this.getId() + "-slChart";
			var svgZoom = new SvgZoom('#' + svgId, {
				mouseWheel: true,
				zoomSpeed: 0.1,
				maxZoom: Number.POSITIVE_INFINITY,
				minZoom: 0.5,
				initZoom: 1,
				center: false,
				viewClass: 'svgzoom-view',
				zoomSelector: '',
				dragCursorStyle: 'move',
				onZoomed: $.noop
			});

		},

		_updateStatus: function (bClearSelection) {
			if (jQuery(".slChart").length === 0) {
				return;
			}
			const aTimelines = [];
			const dateFormat = sap.ui.core.format.DateFormat.getInstance({
				pattern: "dd/MM/y",
				calendarType: sap.ui.core.CalendarType.Gregorian
			});

			let order = 0;

			const aActivityStatus = [];

			const data = this.getData() || {};
			const svgId = this.getId() + "-slChart";
			if (Object.keys(data).length && Object.values(data).indexOf("") === -1) {
				let aPhases = $.extend(true, [], data.phases);
				if (aPhases.length) {
					for (let i = 0; i < data.phases.length; i++) {
						if (i === 0) {
							const $timeline = jQuery("#" + svgId).find(".timeline");

							const $startDate = jQuery("#" + this.getId() + "-slChart").find(".timelineStartDate");
							let sStartDate = "";
							if (data && data.startDate) {
								sStartDate = dateFormat.format(data.startDate);
							}

						}
						const $phase = jQuery('#slChartPhase' + (i + 1));
						const $phaseContainer = $phase.parent();
						if (!$phaseContainer[0]) {
							continue;
						}
						const phaseContainerTransformValue = this.getTransformValue($phaseContainer[0].getAttribute("transform"), "translate");
						const phaseTransformValue = this.getTransformValue($phase[0].getAttribute("transform"), "translate");

						if (data.phases[i].services && data.phases[i].services.length > 0) {
							for (let j = 0; j < data.phases[i].services.length; j++) {

								const selectedServices = data.phases[i].services[j];

								const $service = jQuery('#slChartPhase' + (i + 1) + 'Service' + (j + 1));
								const $serviceContainer = $service.parent();
								const serviceTransformValue = this.getTransformValue($service[0].getAttribute("transform"), "translate");
								// const serviceContainerTransformValue = this.getTransformValue($serviceContainer[0].getAttribute("transform"), "translate");

								if ($service && $service.length > 0) {

									const bShowActivityStatus = this.getShowActivityStatus();

									var width = parseInt($service[0].querySelector(".serviceContent").getBoundingClientRect().width, 10) + 40;

									if (sap.ui.Device.system.tablet) {
										if (sap.ui.Device.orientation.portrait) {
											width = parseInt($service[0].querySelector(".serviceContent").getBoundingClientRect().width, 10) + 100;
										} else {
											width = parseInt($service[0].querySelector(".serviceContent").getBoundingClientRect().width, 10) + 50;
										}
									}

									let content = '<g class="serviceStatus" style="display: ' + ((bShowActivityStatus) ? "block" : "none") +
										';" transform="translate(' + width + ' 17)">' +
										this._getServiceStatusIcon(selectedServices.achieved, data.phases[i].color) +
										'</g>';
									if ($service.find(".serviceStatus").length > 0) {
										content = this._getServiceStatusIcon(selectedServices.achieved, data.phases[i].color);
										$service[0].querySelector(".serviceStatus").innnerHTML += content;
										$service.find(".serviceStatus").css("display", (bShowActivityStatus) ? "block" : "none");
									} else {
										$service[0].querySelector(".serviceContent").parentNode.innerHTML += content;
									}
								}

								if (data.phases[i].services[j].activities && data.phases[i].services[j].activities.length > 0) {
									for (let k = 0; k < data.phases[i].services[j].activities.length; k++) {
										order += 1;
										const selectedActivity = data.phases[i].services[j].activities[k];
										let id = '#slChartPhase' + (i + 1) + 'Service' + (j + 1) + 'Activity' + (k + 1);
										let $activity = jQuery(id);

										aActivityStatus.push({
											id: id,
											status: selectedActivity.status,
											color: data.phases[i].color
										});

										const $activityContainer = $activity.parent();
										const activityContainerTransformValue = this.getTransformValue($activityContainer[0].getAttribute("transform"), "translate");
										const activityTransformValue = this.getTransformValue($activity[0].getAttribute("transform"), "translate");

										if ($activity && $activity.length > 0) {

											const bShowActivityStatus = this.getShowActivityStatus();

											var width = parseInt($activity[0].querySelector(".activityContent").getBoundingClientRect().width, 10) + 10;

											if (sap.ui.Device.system.tablet) {
												if (sap.ui.Device.orientation.portrait) {
													width = parseInt($activity[0].querySelector(".activityContent").getBoundingClientRect().width, 10) + 100;
												} else {
													width = parseInt($activity[0].querySelector(".activityContent").getBoundingClientRect().width, 10) + 50;
												}
											}

											let content = '<g class="activityStatus" style="display: ' + ((bShowActivityStatus) ? "block" : "none") +
												';" transform="translate(' + width + ' 2)">' +
												this._getActivityStatusIcon(selectedActivity.status, data.phases[i].color) +
												'</g>';
											if ($activity.find(".activityStatus").length > 0) {
												content = this._getActivityStatusIcon(selectedActivity.status, data.phases[i].color);
												$activity[0].querySelector(".activityStatus").innnerHTML += content;
												$activity.find(".activityStatus").css("display", (bShowActivityStatus) ? "block" : "none");
											} else {
												$activity[0].querySelector(".activityContent").parentNode.innerHTML += content;
											}

											let aValidationStatusLines = [ActivityStatus.Completed, ActivityStatus.Registered, ActivityStatus.Customer_Validated,
												ActivityStatus.Validated,
												ActivityStatus.Started, ActivityStatus.Presented, ActivityStatus.Progressing
											];
											if (aValidationStatusLines.indexOf(selectedActivity.status) !== -1) {
												let x = parseFloat(phaseContainerTransformValue.x, 10) + parseFloat(phaseTransformValue.x, 10) +
													parseFloat(serviceTransformValue.x, 10) - 18;
												let y = parseFloat(phaseTransformValue.y, 10) + parseFloat(serviceTransformValue.y, 10) + parseFloat(
													activityContainerTransformValue.y, 10) + parseFloat(activityTransformValue.y, 10) - 60;

												const oTimeline = {
													activity: 'slChartPhase' + (i + 1) + 'Service' + (j + 1) + 'Activity' + (k + 1),
													date: (selectedActivity.date) ? selectedActivity.date : null,
													color: data.phases[i].color,
													status: selectedActivity.status,
													x1: 0,
													y1: y,
													x2: x,
													y2: y,
													order: order,
													phaseId: 'slChartPhase' + (i + 1),
													serviceId: 'slChartPhase' + (i + 1) + 'Service' + (j + 1),
													visible: ($phase.find(".services")[0].classList.contains('show') && $service.find(".activities")[0].classList.contains(
														'show'))
												}
												aTimelines.push(oTimeline);

											}
										}
									}
								}
							}
						} else {
							const $phaseRing = $phase.find(".phase");
							// this.expandCollapsePhase($phaseRing, true, true);
							this._collapseExpandPhase($phaseRing, true, true, true);
						}
					}
				}
			}

			const $svg = jQuery("#" + this.getId() + "-slChart");
			const $phases = jQuery("#" + this.getId() + "-slChart").find(".phases");
			let endDateY;
			if ($phases && $phases.length > 0) {

				const lastPhase = $phases.find(".phase-wrapper").last();

				const lastPhaseTransform = this.getTransformValue(lastPhase[0].getAttribute("transform"), "translate");

				const phasesHeight = parseInt(lastPhaseTransform.y, 10) + parseInt(lastPhase[0].getBoundingClientRect().height, 10) + 56;
				$svg.attr("viewBox", "0 0 1200 " + phasesHeight);
				jQuery("#" + this.getId() + "-slChart").find(".timeline-bar").attr("height", lastPhaseTransform.y);

				const $timeline = $svg.find(".timeline");

				let sEndDate = "";
				if (data && data.endDate) {
					sEndDate = dateFormat.format(data.endDate);
				}
				endDateY = lastPhaseTransform.y;

			}

			this._updateTimeline(aTimelines, 21, endDateY, bClearSelection);
		},

		_updateTimeline: function (timelineData, startDateY, endDateY, bClearSelection) {
			let iLastVisible = -1;
			let endDateYPosition = parseInt(endDateY, 10) - 20;
			let startDateYPosition = parseInt(startDateY, 10) - 9;
			let iLastY = endDateYPosition;
			const todaysTimeline = {
				generated: false,
				todaysActivity: false,
				x: 0,
				y: 0
			};
			let bend = 120;
			const dateFormat = sap.ui.core.format.DateFormat.getInstance({
				pattern: "dd/MM/y",
				calendarType: sap.ui.core.CalendarType.Gregorian
			});

			let activityY = 0;

			const data = this.getData();
			const endDate = (data) ? data.endDate : null;
			const sEndDate = (endDate) ? dateFormat.format(endDate) : "";

			const startDate = (data) ? data.startDate : null;
			const sStartDate = (startDate) ? dateFormat.format(startDate) : "";
			const $startDate = jQuery("#" + this.getId() + "-slChart").find(".timelineStartDate");
			let timelineStartDateContent = '<g transform="translate(12 12)"><polygon points="18,0 18,18 0,9" fill="green" /></g>' +
				'<line x1="0" y1="21" x2="15" y2="21" stroke-width="3" stroke="green" />' +
				'<rect x="30" y="' + (12 + 6) + '" width="117" height="6" fill="#F7F7F7" stroke-width="0"/>';
			let firstStartDateNodeXvalue = 0;
			// let firstStartDateNodeYvalue = 14;
			let firstStartDateNodeYvalue = 0;

			timelineStartDateContent += '<text x="32.5" y="' + (12 + 13) +
				'" class="timeline-date" font-size="12" fill="#000000">' + sStartDate + ': SL Start</text>'

			let actualEndDate = endDate;
			const dTodaysDate = new Date();

			const sTodaysDate = dateFormat.format(dTodaysDate);

			const sortedTimelineData = timelineData.slice().sort(function (x, y) {
				var n = x.date - y.date;
				if (n !== 0) {
					return n;
				}

				return x.count - y.count;
			});

			for (let i = 0; i < sortedTimelineData.length; i++) {
				let bShowDate = true;
				const $timelinePhase = jQuery("#" + sortedTimelineData[i].phaseId);
				const $timelineService = jQuery("#" + sortedTimelineData[i].serviceId);
				if (($timelinePhase && $timelinePhase.find(".services").length > 0 && !$timelinePhase.find(".services")[0].classList.contains(
						'show')) ||
					$timelineService && $timelineService.find(".activities").length > 0 && !$timelineService.find(".activities")[0].classList.contains(
						'show')) {
					continue;
				}

				if (i === 0) {
					activityY = sortedTimelineData[i].y1;
				}

				const activityId = sortedTimelineData[i].activity + "Timeline";

				const $activityTimeline = jQuery("[data-activity='" + activityId + "']");
				let sDate = "";
				if (sortedTimelineData[i].date) {
					sDate = dateFormat.format(sortedTimelineData[i].date);
				}

				const similarCreatedTimeline = sortedTimelineData.filter(item => (item.date && item.date !== "" && dateFormat.format(item.date) ===
					sDate && item.created));

				const similarFirstTimeline = similarCreatedTimeline.find(item => item.isFirst);

				let activityTimelineWidth = sortedTimelineData[i].x2 + 8;
				let activityDetailX = (((activityTimelineWidth - 4) * 3) / 4);

				if ((bend + 15) >= activityDetailX) {
					bend = 125;
				}

				let strokeDashArray = "0";
				let aValidationStatus = [ActivityStatus.Registered, ActivityStatus.Started, ActivityStatus.Presented, ActivityStatus.Progressing];
				if (aValidationStatus.indexOf(sortedTimelineData[i].status) !== -1) {
					strokeDashArray = "10, 5";
				}

				let x1 = sortedTimelineData[i].x1,
					x2 = sortedTimelineData[i].x2,
					y1 = sortedTimelineData[i].y1,
					y2 = sortedTimelineData[i].y2;
				let bendLine = 0;
				let isBend = false;
				if (similarFirstTimeline) {
					x1 = similarFirstTimeline.x1;
					y1 = similarFirstTimeline.y1;
					//y1 = activityY;

					bend += 6;
					bendLine = bend
				} else {

					let oTempFirstDate = new Date(sortedTimelineData[i].date);
					let oTempStartDate = new Date(startDate);
					if (oTempFirstDate.getTime() < oTempStartDate.getTime()) {
						bShowDate = false;
						// firstStartDateNodeYvalue = startDateYPosition + 10;
						// activityY = startDateYPosition;
						activityY = 0;
						// startDateYPosition = activityY + 42;
						if (!isBend) {
							bend += 5;
							bendLine = bend;
						}
					} else {
						if (i > 0) {
							bShowDate = true;
							if ((iLastVisible !== -1) && sortedTimelineData[iLastVisible].y1 >= sortedTimelineData[i].y2) {
								activityY = sortedTimelineData[iLastVisible].y1 + 42;
								bend += 6;
								bendLine = bend;
								isBend = true;
							} else {
								activityY = sortedTimelineData[i].y2;
							}

						}
						if (endDate && (new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate(), 0, 0, 0, 0) <
								new Date(sortedTimelineData[i].date.getFullYear(), sortedTimelineData[i].date.getMonth(), sortedTimelineData[i].date.getDate(),
									0, 0, 0, 0))) {
							const timeLineY2 = parseInt(endDateYPosition, 10);
							if (timeLineY2 > activityY) {
								endDateYPosition = activityY;
								activityY += 42;
								if (!isBend) {
									bend += 6;
									bendLine = bend;
								}
							}
							actualEndDate = sortedTimelineData[i].date;
						} else if (sEndDate === sDate) {
							endDateYPosition = activityY
						}

						sortedTimelineData[i].isFirst = true;
					}

				}

				if (sStartDate === sDate) {
					activityY = startDateYPosition;
					if (!isBend) {
						bend += 6;
						bendLine = bend;
					}
				}

				y1 = activityY;

				if (sortedTimelineData[i].visible) {
					let activityTimelineContent = '<g transform="translate(' + sortedTimelineData[i].x2 + ' ' + sortedTimelineData[i].y1 +
						')"><polygon points="18,0 18,18 0,9" fill="' + sortedTimelineData[i].color + '" /></g>';
					sortedTimelineData[i].x1 = x1;
					sortedTimelineData[i].y1 = y1;
					activityTimelineContent += '<path d="M ' + x1 + ' ' + (y1 + 9) + ' L ' + (bendLine) + ' ' + (y1 +
							9) + ' L ' + (bendLine) + ' ' +
						(y2 + 9) + ' L ' + activityTimelineWidth + ' ' + (y2 + 9) +
						'" data-x1="' + x1 + '" data-y1="' + (y1 + 9) + '" data-x2="' + activityTimelineWidth + '" data-y2="' + (
							y2 + 9) + '" stroke="' + sortedTimelineData[i].color +
						'" stroke-width="3" stroke-dasharray="' + strokeDashArray + '" data-date="' + sortedTimelineData[i].date + '" />';
					if (bShowDate) {
						activityTimelineContent += '<rect x="30" y="' + (y1 + 6) + '" width="70" height="6" fill="#F7F7F7" stroke-width="0"/>' +
							'<text x="32.5" y="' + (y1 + 13) + '" class="timeline-date" font-size="12" fill="' +
							sortedTimelineData[
								i]
							.color +
							'" data-value="' + sortedTimelineData[i].date + '">' + sDate + '</text>';
					}

					activityTimelineContent += '<g class="slChartActivityDetailButton" transform="translate(' + (((activityTimelineWidth - 4) * 3) /
							4) +
						' ' + (y2 - 2) +
						')"><rect x="0" y="0" width="22" height="22" rx="2.99999" fill="white" stroke="' + sortedTimelineData[i].color +
						'" stroke-width="1.8"/>' +
						'<g class="slChartActivityDetailButtonIcon" transform="translate(-190 -111)"><path d="M200.824 124.791C200.941 124.908 201.049 124.908 201.146 124.791L205.834 120.104C205.932 120.006 206.049 119.957 206.186 119.957C206.303 119.957 206.41 120.006 206.508 120.104C206.605 120.201 206.654 120.309 206.654 120.426C206.654 120.562 206.605 120.68 206.508 120.777L201.645 125.611C201.469 125.787 201.254 125.875 201 125.875C200.746 125.875 200.521 125.787 200.326 125.611L195.492 120.777C195.395 120.68 195.346 120.572 195.346 120.455C195.346 120.338 195.395 120.23 195.492 120.133C195.727 119.898 195.951 119.898 196.166 120.133L200.824 124.791Z" fill="' +
						sortedTimelineData[i].color + '"/></g>' +
						'</g>';

					if ($activityTimeline.length > 0) {
						$activityTimeline[0].innerHTML = activityTimelineContent;
					} else {
						activityTimelineContent = '<g class="timelineDate" data-phaseId="' + sortedTimelineData[i].phaseId + '" data-serviceId="' +
							sortedTimelineData[i].serviceId + '" data-activityId="' + sortedTimelineData[i].activity + '" data-date="' + sDate +
							'" data-activity="' + activityId + '" transform="translate(0 0)">' +
							activityTimelineContent + '</g>';

						jQuery(".timelineDates")[0].innerHTML += activityTimelineContent;
					}
				}

				const bShowDataLines = this.getShowDataLines();

				// jQuery("#" + this.getId() + "-slChart").find(".timelineDates").css("display", (bShowDataLines) ? "block" : "none");
				jQuery("#" + this.getId() + "-slChart").find(".timelineDates").attr("data-visible", (bShowDataLines) ? "true" : "false");

				if (!todaysTimeline.generated) {
					if (sDate === sTodaysDate) {
						todaysTimeline.x = sortedTimelineData[i].x1;
						todaysTimeline.y = sortedTimelineData[i].y1;
						todaysTimeline.generated = true;
						todaysTimeline.todaysActivity = true;
						todaysTimeline.phaseId = sortedTimelineData[i].phaseId;
						todaysTimeline.serviceId = sortedTimelineData[i].serviceId;
					} else if (!todaysTimeline.todaysActivity && new Date(sortedTimelineData[i].date.getFullYear(), sortedTimelineData[i].date.getMonth(),
							sortedTimelineData[i].date.getDate(),
							0, 0, 0, 0) >
						new Date(dTodaysDate.getFullYear(), dTodaysDate.getMonth(), dTodaysDate.getDate(), 0, 0, 0, 0)) {
						todaysTimeline.x = sortedTimelineData[i].x1;
						todaysTimeline.y = parseInt(sortedTimelineData[i].y1, 10) - 20;
						todaysTimeline.generated = true;
						todaysTimeline.todaysActivity = false;
						todaysTimeline.phaseId = sortedTimelineData[i].phaseId;
						todaysTimeline.serviceId = sortedTimelineData[i].serviceId;

						const today = new Date(dTodaysDate.getFullYear(), dTodaysDate.getMonth(), dTodaysDate.getDate(), 0, 0, 0, 0);
						const end = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate(), 0, 0, 0, 0);
						const activityDate = new Date(sortedTimelineData[i].date.getFullYear(), sortedTimelineData[i].date.getMonth(),
							sortedTimelineData[i].date.getDate(),
							0, 0, 0, 0);

						if (end && activityDate && end < activityDate && today < end) {
							todaysTimeline.y = parseInt(endDateYPosition, 10) - 20;
						}
						/*else {
							todaysTimeline.y = parseInt(sortedTimelineData[i].y1, 10) - 20;
						}*/
					}
				}

				sortedTimelineData[i].created = true;

				if (sortedTimelineData[i].visible) {
					iLastVisible = i;
				}

				if (parseInt(iLastY, 10) < parseInt(sortedTimelineData[i].y1, 10)) {
					iLastY = parseInt(sortedTimelineData[i].y1, 10);
				}

				if (todaysTimeline && parseInt(iLastY, 10) < parseInt(todaysTimeline.y, 10)) {
					iLastY = parseInt(todaysTimeline.y, 10);
				}
			}

			if ($startDate.length === 0) {
				timelineStartDateContent = '<g class="timelineStartDate" transform="translate(' + firstStartDateNodeXvalue + ', ' +
					firstStartDateNodeYvalue + ')">' +
					timelineStartDateContent + '</g>';
				jQuery("#" + this.getId() + "-slChart").find(".timeline")[0].innerHTML += timelineStartDateContent;
			} else {
				$startDate[0].innerHTML = timelineStartDateContent;
			}

			if (!todaysTimeline.generated) {
				if (endDate && (new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate(), 0, 0, 0, 0) >
						new Date(dTodaysDate.getFullYear(), dTodaysDate.getMonth(), dTodaysDate.getDate(), 0, 0, 0, 0))) {
					if (sortedTimelineData.length > 0) {
						const maxIndex = sortedTimelineData.length - 1;
						todaysTimeline.y = parseInt(sortedTimelineData[maxIndex].y1, 10) + 20;
						todaysTimeline.phaseId = sortedTimelineData[maxIndex].phaseId;
						todaysTimeline.serviceId = sortedTimelineData[maxIndex].serviceId;
					} else {
						todaysTimeline.y = 41;
						todaysTimeline.phaseId = "";
						todaysTimeline.serviceId = "";
					}

					todaysTimeline.x = 0;

					todaysTimeline.generated = true;
					todaysTimeline.todaysActivity = false;

				}
			}

			if (todaysTimeline.generated) {

				const $phase = jQuery("#" + todaysTimeline.phaseId);
				const $service = jQuery("#" + todaysTimeline.serviceId);
				if ($phase && $phase.find(".services").length > 0 && !$phase.find(".services")[0].classList.contains('show')) {
					const translate = this.getTransformValue($phase[0].getAttribute("transform"), "translate");
					todaysTimeline.y = parseInt(translate.y, 10) - 20;
					todaysTimeline.collapsed = true;
				} else if ($service && $service.find(".activities").length > 0 && !$service.find(".activities")[0].classList.contains('show')) {
					const translate = this.getTransformValue($phase[0].getAttribute("transform"), "translate");
					const serviceTranslate = this.getTransformValue($service[0].getAttribute("transform"), "translate");
					todaysTimeline.y = parseInt(translate.y, 10) + parseInt(serviceTranslate.y, 10) - 40;
					todaysTimeline.collapsed = true;
				}

				const bShowTodaysDate = this.getShowTodaysDate();

				let todaysTimelineContent = '<g transform="translate(12 ' + todaysTimeline.y +
					')"><polygon points="18,0 18,18 0,9" fill="#0A6ED1" /></g>' +
					'<line x1="' + todaysTimeline.x + '" y1="' + (todaysTimeline.y + 9) + '" x2="15" y2="' + (
						todaysTimeline.y + 9) + '" stroke-width="3" stroke="#0A6ED1" />';

				//if (!todaysTimeline.todaysActivity || todaysTimeline.collapsed) {
				todaysTimelineContent += '<text style="display:' + ((bShowTodaysDate) ? "block" : "none") + ';" x="32.5" y="' + (todaysTimeline.y +
						13) +
					'" class="timeline-date" font-size="12" fill="#000000">' + dateFormat.format(new Date()) + '</text>'
					//}

				const $todaysDate = jQuery("#" + this.getId() + "-slChart").find(".todaysDate");

				/*if ($todaysDate.length === 0) {
					todaysTimelineContent = '<g class="todaysDate" style="display:' + ((bShowTodaysDate) ? "block" : "none") + ';">' +
						todaysTimelineContent + '</g>';
					jQuery("#" + this.getId() + "-slChart").find(".timeline")[0].innerHTML += todaysTimelineContent;
				} else {
					$todaysDate[0].innerHTML = todaysTimelineContent;
					$todaysDate.css("display", (bShowTodaysDate) ? "block" : "none");
				}*/

				if ($todaysDate.length === 0) {
					todaysTimelineContent = '<g class="todaysDate">' +
						todaysTimelineContent + '</g>';
					jQuery("#" + this.getId() + "-slChart").find(".timeline")[0].innerHTML += todaysTimelineContent;
				} else {
					$todaysDate[0].innerHTML = todaysTimelineContent;
					// $todaysDate.css("display", (bShowTodaysDate) ? "block" : "none");
				}

			}

			let timelineEndDateContent = '<g transform="translate(12 ' + endDateYPosition +
				')"><polygon points="18,0 18,18 0,9" fill="red" /></g>' +
				'<line x1="0" y1="' + (endDateYPosition + 9) + '" x2="15" y2="' + (
					endDateYPosition + 9) + '" stroke-width="3" stroke="red" />' +
				'<rect x="30" y="' + (endDateYPosition + 6) + '" width="117" height="6" fill="#F7F7F7" stroke-width="0"/>';

			timelineEndDateContent += '<text x="32.5" y="' + (endDateYPosition + 13) +
				'" class="timeline-date" font-size="12" fill="#000000">' + dateFormat.format(endDate) + ': Est. Close</text>'

			const $endDate = jQuery("#" + this.getId() + "-slChart").find(".timelineEndDate");

			if ($endDate.length === 0) {
				timelineEndDateContent = '<g class="timelineEndDate">' +
					timelineEndDateContent + '</g>';
				jQuery("#" + this.getId() + "-slChart").find(".timeline")[0].innerHTML += timelineEndDateContent;
			} else {
				$endDate[0].innerHTML = timelineEndDateContent;
			}

			if (sortedTimelineData.length > 0) {
				jQuery("#" + this.getId() + "-slChart").attr("viewBox", "0 0 1200 " + (parseInt(iLastY, 10) + 106));
				jQuery("#" + this.getId() + "-slChart").find(".timeline-bar").attr("height", parseInt(iLastY, 10) + 40);
			}

			if (this.selectedElement) {
				this._selectElement(this.selectedElement.id, !bClearSelection, this.selectedElement.type, true);
			}

		},

		_getPhase: function (percent, color) {
			let content = "";
			if (!percent || parseFloat(percent, 10) === 0) {
				content = "<g transform='translate(17 17)'>" +
					"<path d='M18 9C18 16 9 22 9 22C9 22 0 16 0 9C3.55683e-08 6.61305 0.948211 4.32387 2.63604 2.63604C4.32387 0.948211 6.61305 0 9 0C11.3869 0 13.6761 0.948211 15.364 2.63604C17.0518 4.32387 18 6.61305 18 9Z' fill='" +
					color + "' />" +
					"<path d='M9 12C10.6569 12 12 10.6569 12 9C12 7.34315 10.6569 6 9 6C7.34315 6 6 7.34315 6 9C6 10.6569 7.34315 12 9 12Z' fill='white' stroke='white' stroke-width='1.68379' stroke-linecap='round' stroke-linejoin='round' />" +
					"</g>";
			} else {
				const radius = 22;
				const circumference = radius * 2 * Math.PI;

				let percentValue = (percent) ? percent : 0;
				const offset = circumference - percentValue / 100 * circumference;

				content = "<circle class='melodyRadialChartProgressRing' cx='26' cy='26' r='" + radius + "' style='stroke-dasharray:" +
					circumference + " " + circumference + ";stroke-dashoffset:" + offset +
					";' transform='rotate(90 26 26)' fill='transparent' stroke='" + color + "' stroke-width='10' />";
				content +=
					"<text class='micro-chart-pointer-text' x='26' y='28' alignment-baseline='middle' font-size='11' font-weight='bold' stroke-width='0' stroke='white' text-anchor='middle' fill='" +
					color + "'>" + percentValue + "%" + "</text>";
			}

			return content;
		},

		_getService: function (completed, color, sServiceType, bAchieved) {
			let content = "";
			if (ServiceStatus.Outcome === sServiceType) {
				if (completed) {
					if (bAchieved) {
						content =
							'<g class="service" transform="translate(0 -5)">' +
							'<svg  width="28" height="38.571" viewBox="1 0 32 34" fill="none" xmlns="http://www.w3.org/2000/svg">' +
							'<path d="M17 0L31.722 8.5V25.5L17 34L2.278 25.5V8.5L17 0Z" stroke="white" stroke-width="2" fill="' + color + '"/>' +
							'<path d="M17 24.48V32.3" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>' +
							'<path d="M17 2.04V10.2" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>' +
							'<path cx="49.5" cy="50.5" r="20.5" stroke="white" stroke-width="2" stroke-linecap="round" d="M23.8 17.17A6.97 6.97 0 0 1 16.83 24.14A6.97 6.97 0 0 1 9.86 17.17A6.97 6.97 0 0 1 23.8 17.17z"/>' +
							'</svg>' +
							'</g>';
					} else {
						content =
							'<g class="service" transform="translate(0 -5)">' +
							'<svg  width="28" height="38.571" viewBox="2 0 35.345 38.571" fill="none" xmlns="http://www.w3.org/2000/svg">' +
							'<path d="M19.286 0L35.987 9.643V28.929L19.286 38.571L2.584 28.929V9.643L19.286 0Z" stroke="white" stroke-width="2" fill="' +
							color + '"/>' +
							'<path d="M19.286 27.771V36.643" stroke="white" stroke-width="1.5428571428571425" stroke-linecap="round" stroke-linejoin="round"/>' +
							'<path d="M19.286 2.314V11.571" stroke="white" stroke-width="1.5428571428571425" stroke-linecap="round" stroke-linejoin="round"/>' +
							'<path cx="49.5" cy="50.5" r="20.5" stroke="white" stroke-width="1.5428571428571425" stroke-linecap="round" d="M27 19.479A7.907 7.907 0 0 1 19.093 27.386A7.907 7.907 0 0 1 11.186 19.479A7.907 7.907 0 0 1 27 19.479z"/>' +
							'<path cx="49.5" cy="50.5" r="20.5" fill="white" d="M27 19.479A7.907 7.907 0 0 1 19.093 27.386A7.907 7.907 0 0 1 11.186 19.479A7.907 7.907 0 0 1 27 19.479z"/>' +
							'</svg>' +
							'</g>';
					}
				} else {
					if (bAchieved) {
						content =
							'<g class="service" transform="translate(-2 0)">' +
							'<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">' +
							'<path d="M2.784 8.369L16 0.739L29.216 8.369V23.631L16 31.26L2.784 23.631V8.369Z" fill="white" stroke="' + color +
							'" stroke-width="2"/>' +
							'<path d="M16 23.04V30.4" stroke="' + color + '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>' +
							'<path d="M16 1.92V9.6" stroke="' + color + '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>' +
							'<path cx="49.5" cy="50.5" r="20.5" fill="' + color + '"  stroke="' + color +
							'" stroke-linecap="round" d="M22.4 16.16A6.56 6.56 0 0 1 15.84 22.72A6.56 6.56 0 0 1 9.28 16.16A6.56 6.56 0 0 1 22.4 16.16z"/>' +
							'</svg>' +
							'</g>';
					} else {
						content =
							'<g class="service" transform="translate(0 -5)">' +
							'<svg  width="28" height="38.571" viewBox="0 0 28 31.818" fill="none" xmlns="http://www.w3.org/2000/svg">' +
							'<path d="M0.859 8.322L14 0.735L27.141 8.322V23.496L14 31.083L0.859 23.496V8.322Z" fill="white" stroke="' + color +
							'" stroke-width="2"/>' +
							'<path d="M14 22.909V30.227" stroke="' + color +
							'" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>' +
							'<path d="M14 1.909V9.545" stroke="' + color +
							'" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>' +
							'<path cx="43.5" cy="50.5" r="20.5" stroke="' + color +
							'" stroke-width="2" stroke-linecap="round" d="M20.364 16.068A6.523 6.523 0 0 1 13.841 22.591A6.523 6.523 0 0 1 7.318 16.068A6.523 6.523 0 0 1 20.364 16.068z"/>' +
							'</svg>' +
							'</g>';
					}
				}
			} else {
				if (completed) {
					content = '<polygon class="service" points="14 0, 27 8, 27 23, 14 31, 0 23, 0 8" stroke="white" fill="' + color +
						'" stroke-width="2" />'
				} else {
					content = '<polygon class="service" points="14 0, 27 8, 27 23, 14 31, 0 23, 0 8" fill="white" stroke="' + color +
						'" stroke-width="2" />'
				}
			}
			return content;
		},

		_getServiceStatusIcon: function (bAchieved, color) {
			let content;
			if (bAchieved) {
				content =
					'<g transform="translate(0 0)"><path fill-rule="evenodd" clip-rule="evenodd" d="M8.59822 16.5963C13.0155 16.5963 16.5963 13.0155 16.5963 8.59822C16.5963 4.18098 13.0155 0.600098 8.59822 0.600098C4.18098 0.600098 0.600098 4.18098 0.600098 8.59822C0.600098 13.0155 4.18098 16.5963 8.59822 16.5963ZM13.3039 4.85165C13.6943 5.24209 13.6943 5.8751 13.3039 6.26553L7.30532 12.2641C6.91488 12.6546 6.28187 12.6546 5.89144 12.2641L3.89191 10.2646C3.50147 9.87416 3.50147 9.24115 3.89191 8.85071C4.28234 8.46028 4.91535 8.46028 5.30579 8.85071L6.59838 10.1433L11.89 4.85165C12.2805 4.46122 12.9135 4.46122 13.3039 4.85165Z" fill="' +
					color +
					'"/></g>' +
					'<text x="20" y="8.5" alignment-baseline="middle" font-size="10" stroke-width="0" stroke="white" fill="' +
					color + '"> ' + ServiceStatus.Achieved + '</text>';
			} else {
				content = '';
			}
			return content;
		},

		_getActivity: function (status, color, active) {
			let content = "";
			let aValidatedStatus = [ActivityStatus.Completed, ActivityStatus.Customer_Validated, ActivityStatus.Validated];
			if ((aValidatedStatus.indexOf(status) !== -1) && active) {
				content = '<circle cx="0" cy="0" r="10" transform="rotate(90 0 0)" fill="' + color +
					'" stroke="white" stroke-width="2" />'
			} else {
				content = '<circle cx="0" cy="0" r="10" transform="rotate(90 0 0)" stroke="' + color +
					'" fill="white" stroke-width="2" />'
			}
			return content;
		},

		_getActivityStatusIcon: function (status, color) {
			let content;
			switch (status) {
			case ActivityStatus.Completed:
				content =
					'<g transform="translate(-5 -4)">' +
					'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 90 90" width="50" height="50">' +
					'<path stroke-width="2" fill="' +
					color +
					'" d="M27.021 6.612c-1.823 0 -3.629 0.367 -5.376 0.723 -1.736 0.353 -3.375 0.687 -5.017 0.687 -1.275 0 -2.409 -0.209 -3.465 -0.638a0.909 0.909 0 0 0 -0.303 -0.059c-0.013 -0.001 -0.023 -0.007 -0.035 -0.007 -0.011 0 -0.019 0.005 -0.03 0.006a0.897 0.897 0 0 0 -0.303 0.061c-0.017 0.007 -0.032 0.017 -0.05 0.025 -0.041 0.018 -0.082 0.034 -0.12 0.06 -0.038 0.025 -0.069 0.059 -0.103 0.089 -0.013 0.013 -0.029 0.023 -0.041 0.036a0.903 0.903 0 0 0 -0.167 0.248c-0.009 0.02 -0.015 0.04 -0.023 0.06 -0.037 0.1 -0.063 0.204 -0.063 0.313v27a0.9 0.9 0 0 0 1.8 0V21.655c0.913 0.24 1.869 0.368 2.904 0.368 1.823 0 3.629 -0.367 5.376 -0.723 1.736 -0.353 3.375 -0.687 5.017 -0.687 1.275 0 2.408 0.209 3.464 0.638a0.901 0.901 0 0 0 1.239 -0.834V8.216a0.9 0.9 0 0 0 -0.561 -0.833c-1.275 -0.519 -2.631 -0.77 -4.144 -0.77zm2.904 12.559a11.336 11.336 0 0 0 -2.903 -0.357c-1.823 0 -3.629 0.367 -5.376 0.723 -1.735 0.354 -3.375 0.687 -5.017 0.687 -1.053 0 -2.009 -0.142 -2.904 -0.433V9.464c0.911 0.239 1.871 0.357 2.904 0.357 1.823 0 3.629 -0.367 5.376 -0.723 1.736 -0.354 3.375 -0.687 5.017 -0.687 1.052 0 2.009 0.142 2.904 0.433v10.328z"/></g>' +
					+'</svg>' +
					'<text x="18" y="8.5" alignment-baseline="middle" font-size="10" stroke-width="0" stroke="white" fill="' +
					color + '">' + status + '</text>';
				break;
			case ActivityStatus.Planned:
				content =
					'<g transform="translate(0 -2)"><path xmlns="http://www.w3.org/2000/svg" fill-rule="evenodd" clip-rule="evenodd" d="M10.6583 3.06707L10.6412 3.15888L9.84616 6.67783H13.0002C13.8838 6.67783 14.6069 7.38094 14.6633 8.26982L14.6668 8.38186V8.74166C14.6668 9.05911 14.6049 9.37282 14.4851 9.66458L14.4205 9.80855L12.4117 13.9161C11.9117 14.9386 10.7767 15.4493 9.70966 15.1505L9.58688 15.1124L6.68393 14.1231C6.30476 13.9939 6.04019 13.6477 6.00433 13.2466L6.00016 13.1531V8.06227C6.00016 8.01038 6.00182 7.95859 6.00511 7.907L6.01083 7.84271L6.00474 7.79871L6.00016 7.70025C6.00016 7.46774 6.07607 7.25336 6.20394 7.0816L6.21216 7.07112L6.23654 7.01599L6.3076 6.87866L8.79859 2.42172C9.3544 1.42723 10.8181 1.97991 10.6583 3.06707ZM4.66683 7.23521V14.5685H1.3335V7.23521H4.66683Z" fill="' +
					color + '"/></g>' +
					'<text x="20" y="8.5" alignment-baseline="middle" font-size="10" stroke-width="0" stroke="white" fill="' +
					color + '">' + status + '</text>';
				break;
			case ActivityStatus.Registered:
				content =
					'<g transform="translate(0 -3)"><path d="M13.3335 3.33333H15.0002C15.4422 3.33333 15.8661 3.50893 16.1787 3.82149C16.4912 4.13405 16.6668 4.55797 16.6668 5V16.6667C16.6668 17.1087 16.4912 17.5326 16.1787 17.8452C15.8661 18.1577 15.4422 18.3333 15.0002 18.3333H5.00016C4.55814 18.3333 4.13421 18.1577 3.82165 17.8452C3.50909 17.5326 3.3335 17.1087 3.3335 16.6667V5C3.3335 4.55797 3.50909 4.13405 3.82165 3.82149C4.13421 3.50893 4.55814 3.33333 5.00016 3.33333H6.66683" stroke="' +
					color +
					'" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M12.4998 1.66667H7.49984C7.0396 1.66667 6.6665 2.03976 6.6665 2.5V4.16667C6.6665 4.6269 7.0396 5 7.49984 5H12.4998C12.9601 5 13.3332 4.6269 13.3332 4.16667V2.5C13.3332 2.03976 12.9601 1.66667 12.4998 1.66667Z" stroke="' +
					color + '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></g>' +
					'<text x="23" y="8.5" alignment-baseline="middle" font-size="10" stroke-width="0" stroke="white" fill="' +
					color + '">' + status + '</text>';
				break;
			case ActivityStatus.Recommended:
				content =
					'<g transform="translate(0 -2)"><path fill-rule="evenodd" clip-rule="evenodd" d="M3.3335 15.71C3.3335 15.1577 3.78121 14.71 4.3335 14.71H7.66683C8.21911 14.71 8.66683 15.1577 8.66683 15.71C8.66683 16.2622 8.21911 16.71 7.66683 16.71H4.3335C3.78121 16.71 3.3335 16.2622 3.3335 15.71Z" fill="' +
					color +
					'"/><path fill-rule="evenodd" clip-rule="evenodd" d="M0 6C0 2.68629 2.68629 0 6 0C9.31371 0 12 2.68629 12 6C12 7.68006 11.2614 8.73268 10.6641 9.58386C10.6323 9.62921 10.6008 9.67399 10.5699 9.71826C9.97778 10.567 9.49915 11.3152 9.49858 12.669C9.49834 13.2179 9.05572 13.664 8.50684 13.6686L3.50928 13.7099C3.24269 13.7121 2.98626 13.6077 2.79695 13.42C2.60763 13.2323 2.5011 12.9768 2.50102 12.7102C2.5006 11.3325 2.01884 10.5723 1.42844 9.72118C1.39596 9.67435 1.36287 9.62695 1.32934 9.57892C0.734304 8.72655 0 7.67469 0 6ZM6 2C3.79086 2 2 3.79086 2 6C2 7.03727 2.40903 7.6265 3.02339 8.51152C3.03939 8.53457 3.05553 8.55783 3.07181 8.58129C3.61234 9.36057 4.22593 10.2921 4.43051 11.7022L7.56846 11.6763C7.77293 10.2742 8.38965 9.34794 8.9297 8.57389C8.94358 8.55399 8.95736 8.53425 8.97104 8.51465C9.58793 7.63097 10 7.04068 10 6C10 3.79086 8.20914 2 6 2Z" fill="' +
					color + '"/></g>' +
					'<text x="18" y="8.5" alignment-baseline="middle" font-size="10" stroke-width="0" stroke="white" fill="' +
					color + '">' + status + '</text>';
				break;
			case ActivityStatus.Required:
				content = '<g transform="translate(0 -2) scale(0.08)">' +
					'<polygon points="100,10 40,198 190,78 10,78 160,198" style="fill:' + color + ';stroke-width:0;fill-rule:nonzero;"/>' +
					'</g>' +
					'<text x="18" y="8.5" alignment-baseline="middle" font-size="10" stroke-width="0" stroke="white" fill="' +
					color + '">' + status + '</text>';
				break;
			case ActivityStatus.Validated:
				content =
					'<g transform="translate(0 0)"><path d="M9.53674e-07 1.78814e-06H1V16H9.53674e-07V1.78814e-06ZM9.59375 1.03125C9.88542 1.03125 10.125 1.01042 10.3125 0.968752C10.5208 0.927085 10.6979 0.864585 10.8437 0.781252C11.0104 0.697918 11.1771 0.593752 11.3437 0.468752C11.5312 0.343752 11.75 0.187502 12 1.78814e-06V7.46875C11.7083 7.76042 11.3958 8.02083 11.0625 8.25C10.7708 8.4375 10.4479 8.61458 10.0937 8.78125C9.73958 8.92708 9.375 9 9 9C8.89583 9 8.65625 8.94792 8.28125 8.84375L5.78125 8.15625C5.38542 8.05208 5.125 8 5 8C4.39583 8 3.86458 8.08333 3.40625 8.25C2.94792 8.39583 2.47917 8.64583 2 9V1.96875C2.20833 1.61458 2.47917 1.29167 2.8125 1C3.10417 0.750002 3.44792 0.520835 3.84375 0.312502C4.26042 0.104168 4.76042 1.78814e-06 5.34375 1.78814e-06C5.48958 1.78814e-06 5.77083 0.0520851 6.1875 0.156252C6.60417 0.260418 7.04167 0.385418 7.5 0.531252C7.97917 0.656252 8.41667 0.770835 8.8125 0.875002C9.20833 0.979168 9.46875 1.03125 9.59375 1.03125Z" fill="' +
					color + '"></path></g>' +
					'<text x="18" y="8.5" alignment-baseline="middle" font-size="10" stroke-width="0" stroke="white" fill="' +
					color + '">' + status + '</text>';
				break;
			case ActivityStatus.Not_Applicable:
				content =
					'<g transform="translate(15 17) matrix(-1,0,0,-1,0,0)"><path xmlns="http://www.w3.org/2000/svg" fill-rule="evenodd" clip-rule="evenodd" d="M10.6583 3.06707L10.6412 3.15888L9.84616 6.67783H13.0002C13.8838 6.67783 14.6069 7.38094 14.6633 8.26982L14.6668 8.38186V8.74166C14.6668 9.05911 14.6049 9.37282 14.4851 9.66458L14.4205 9.80855L12.4117 13.9161C11.9117 14.9386 10.7767 15.4493 9.70966 15.1505L9.58688 15.1124L6.68393 14.1231C6.30476 13.9939 6.04019 13.6477 6.00433 13.2466L6.00016 13.1531V8.06227C6.00016 8.01038 6.00182 7.95859 6.00511 7.907L6.01083 7.84271L6.00474 7.79871L6.00016 7.70025C6.00016 7.46774 6.07607 7.25336 6.20394 7.0816L6.21216 7.07112L6.23654 7.01599L6.3076 6.87866L8.79859 2.42172C9.3544 1.42723 10.8181 1.97991 10.6583 3.06707ZM4.66683 7.23521V14.5685H1.3335V7.23521H4.66683Z" fill="' +
					color + '"/></g>' + '<text x="20" y="8.5" alignment-baseline="middle" font-size="10" stroke-width="0" stroke="white" fill="' +
					color + '">' + status + '</text>';
				break;
			case ActivityStatus.Started:
			case ActivityStatus.Presented:
			case ActivityStatus.Progressing:
				content =
					'<g transform="translate(-10 -15) matrix(-1,0,0,-1,0,0) rotate(180)"><path d="M22.477 6.739a1.125 1.125 0 0 0 -0.773 0.341L10.125 18.659l-3.705 -3.705a1.125 1.125 0 1 0 -1.591 1.591l4.5 4.5a1.125 1.125 0 0 0 1.591 0l12.375 -12.375a1.125 1.125 0 0 0 -0.818 -1.932z" fill="' +
					color + '"/></g>' + '<text x="17" y="2.5" alignment-baseline="middle" font-size="10" stroke-width="0" stroke="white" fill="' +
					color + '">' + status + '</text>';
				break;
			default:
				content = '';
			}
			return content;
		},

		setData: function (oData) {
			this.setProperty("data", oData);
			this._setChart();

			const oModel = this.getAggregation("_phaseList").getModel("slChartPhaseList");
			oModel.setData(oData);
			oModel.refresh(true);
		},

		setExpanded: function (bExpanded) {
			const that = this;
			this.setProperty("expanded", bExpanded);
			setTimeout(function () {
				that._setExpanded(bExpanded);
			}, 50);
		},

		_setExpanded: function (bExpanded) {
			const that = this;
			const $phases = jQuery("#" + this.getId() + "-slChart").find(".phase");

			const data = this.getData();

			for (let i = 0; i < data.phases.length; i++) {
				data.phases[i].collapsed = !bExpanded;
				for (let j = 0; j < data.phases[i].services.length; j++) {
					data.phases[i].services[j].collapsed = !bExpanded;
				}
			}

			$phases.each(function () {
				that._collapseExpandPhase($(this), !bExpanded);
			});
		},

		setAutoHideCompletedPhases: function (bValue) {
			const that = this;
			this.setProperty("autoHideCompletedPhases", bValue);
			setTimeout(function () {

				const data = that.getData();

				const aPhaseIds = [];

				let bCollapsed = false;
				if (that.completedPhases && that.completedPhases.length > 0) {
					for (let i = 0; i < that.completedPhases.length; i++) {
						const $completedPhaseWrapper = jQuery("#" + that.getId() + "-slChart").find("#" + that.completedPhases[
							i]);
						const $refernceElement = $completedPhaseWrapper.find(".phase");
						if (bValue) {
							bCollapsed = true;
						} else if (that.getExpanded()) {
							bCollapsed = false;
						}

						const phaseId = $refernceElement.parent().attr("data-phase-value");
						aPhaseIds.push(phaseId);
						const phase = data.phases.find(p => p.id === phaseId);
						/*if(phase) {
							phase.collapsed = bCollapsed;
							for(let i = 0; i < phase.services.length; i++) {
								phase.services[i].collapsed = bCollapsed;
							}
						}*/
						if (phase && (bCollapsed || (!bCollapsed && phase.collapsed))) {
							that._collapseExpandPhase($refernceElement, true);
							phase.collapsed = bCollapsed;
							for (let i = 0; i < phase.services.length; i++) {
								phase.services[i].collapsed = bCollapsed;
							}
						}

					}
				}
				//that._updateStatus();
				that.updateChart();

				that.fireEvent("toggleAutoHideCompletedPhases", {
					phases: aPhaseIds,
					expanded: !bCollapsed
				});
			}, 50);
		},

		setShowPhaseMenu: function (bValue) {

			this.setProperty("showPhaseMenu", bValue);

			const oPhaseList = this.getAggregation("_phaseList");
			if (bValue) {
				oPhaseList.setVisible(true);
			} else {
				oPhaseList.setVisible(false);
			}

			//this.refreshStatus();
			this.updateChart();
		},

		setShowKey: function (bValue) {

			this.setProperty("showKey", bValue);

			const oKey = this.getAggregation("_key");
			if (bValue) {
				oKey.setVisible(true);
			} else {
				oKey.setVisible(false);
			}

			//this.refreshStatus();
			this.updateChart();
		},

		setShowTodaysDate: function (bValue) {

			this.setProperty("showTodaysDate", bValue);

			//this.refreshStatus();
			this.updateChart();
		},

		setShowActivityStatus: function (bValue) {

			this.setProperty("showActivityStatus", bValue);
			this.updateChart();
			//this.refreshStatus();
		},

		setShowDataLines: function (bValue) {

			this.setProperty("showDataLines", bValue);
			this.updateChart();
			//this.refreshStatus();
		},

		setShowSubTitleOnly: function (bValue) {
			if (bValue) {
				this.setProperty("showSubTitlesOnly", bValue);
			} else {
				this.setProperty("showSubTitlesOnly", bValue);
			}
			this.updateChart();

		},

		refreshStatus: function () {
			if (this.chartLoaded) {
				const that = this;
				setTimeout(function () {
					that._updateStatus();
				}, 50);
			}
		},

		onExit: function () {
			$(document).off("click", ".phase");

			$(document).off("click", ".service");

			$(document).off("click", ".phaseTitle");

			$(document).off("click", ".serviceTitle");

			$(document).off("click", ".timelineDate");

			$(document).off("click", ".slChartActivity");

			$(document).off("click", ".slChartActivityDetailButton");
		},

		onAfterRendering: function () {},

		renderer: {

			render: function (oRm, oControl) {
				var libraryPath = jQuery.sap.getModulePath("com.melody.lib"); //get the server location of the ui library
				jQuery.sap.includeStyleSheet(libraryPath + "/controls/chart/chart.css"); //specify the css path relative from the ui folder
				/*oRm.write("<div style='background: url(" + libraryPath +
					"/controls/chart/images/map.png); background-repeat: no-repeat; background-size: cover;'");*/
				oRm.write("<div style='background: url(" + libraryPath +
					"/controls/chart/images/MSL_MapImage.svg); background-repeat: no-repeat; background-size: cover;'");
				oRm.writeControlData(oControl);
				oRm.addClass("successLineChartContainer");
				oRm.writeClasses();
				oRm.write(">");
				oRm.write("<div class='slChartHeader'>");
				oRm.write("<div class='slChartHeaderItem sapUiTinyMarginBegin'>");
				oRm.renderControl(oControl.getAggregation("_setting"));
				oRm.renderControl(oControl.getAggregation("_phaseList"));

				oRm.write("</div>");
				oRm.write("</div>");
				oRm.write("<div class=''>");
				oRm.renderControl(oControl.getAggregation("_key"));
				oRm.renderControl(oControl.getAggregation("_chart"));
				oRm.write("</div>");
				oRm.write("</div>");
			}
		}
	});

	const SLChartController = Controller.extend("com.melody.lib.controls.chart.SLChartController", {
		constructor: function (oControl) {
			this._control = oControl;
		},

		getControl: function () {
			return this._control;
		},

		onChangeDataLinesVisibility: function (oEvent) {
			const bState = oEvent.getParameter("state");

			this.getControl().setShowDataLines(bState);
			this.getControl().fireEvent("toggleDataLines", {
				state: bState
			});
		},

		onChangePhasesMenuVisibility: function (oEvent) {
			const bState = oEvent.getParameter("state");
			this.getControl().setShowPhaseMenu(bState);
		},

		onChangeKeyVisibility: function (oEvent) {
			const bState = oEvent.getParameter("state");
			this.getControl().setShowKey(bState);
		},

		onChangeActivityStatusVisibility: function (oEvent) {
			const bState = oEvent.getParameter("state");
			this.getControl().setShowActivityStatus(bState);

			this.getControl().fireEvent("toggleActivityStatus", {
				state: bState
			});
		},

		onChangeCollapseExpandVisibility: function (oEvent) {
			const that = this;
			const bState = oEvent.getParameter("state");
			this.getControl().setExpanded(bState);

			this.getControl().fireEvent("toggleExpandAll", {
				expanded: bState
			});
		},

		onChangeAutoHideCompletedPhases: function (oEvent) {
			const that = this;
			const bState = oEvent.getParameter("state");
			this.getControl().setAutoHideCompletedPhases(bState);
		},

		onChangeTodaysDateVisibility: function (oEvent) {
			const bState = oEvent.getParameter("state");
			this.getControl().setShowTodaysDate(bState);
		},

		onChangeShowSubTitleOnly: function (oEvent) {
			const bState = oEvent.getParameter("state");
			this.getControl().setShowSubTitleOnly(bState);
			this.getControl().fireEvent("toggleSubTitles", {
				state: bState
			});
		},

		handleSaveSetttings: function (oEvent) {
			this.getControl().fireEvent("saveSettings", {
				settings: this.getControl().getSettings()
			});
			this._pPresentationViewSettingsPopover.then(function (oPopover) {
				oPopover.close();
			});
		},
		/**
		 ** Getting the value of subbtitle tooggle option
		 */
		getShowSubTitlesOnly: function () {
			this.getProperty("showSubTitlesOnly");
		},
	});

	return SuccessLineChart;

});