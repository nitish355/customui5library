/*!
 * ${copyright}
 */

// Provides control com.melody.lib.
sap.ui.define([
    "sap/m/MessageBox",
    "sap/m/MessageToast",
    "sap/ui/core/Control",
    "sap/ui/model/Filter",
    "sap/ui/core/Fragment",
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "com/melody/lib/util/Activity",
    "com/melody/lib/util/account/Account",
    "sap/ui/model/resource/ResourceModel",
    "com/melody/lib/service/ActivityService",
    "com/melody/lib/util/opportunity/Opportunity",
    "com/melody/lib/service/OpportunityService",
    "sap/ui/core/format/DateFormat",
    "com/melody/lib/util/opportunity/VATTeam"
], function (MessageBox, MessageToast, Control, Filter, Fragment, Controller, JSONModel, ActivityUtil, AccountUtil, ResourceModel, ActivityService, OpportunityUtil, OpportunityService, DateFormat, VATTeam) {
    "use strict";

    /**
     * Constructor for a new RapidRegistration Control.
     *
     * @param {string} [sId] id for the new control, generated automatically if no id is given
     * @param {object} [mSettings] initial settings for the new control
     *
     * @class
     * Some class description goes here.
     * @extends  Control
     *
     * @author SAP SE
     * @version ${version}
     *
     * @constructor
     * @public
     * @alias com.melody.lib.controls.RapidRegistration
     * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
     */

    var oDialogController = {

        fnLoadRapidRegDialog: function (oEvent, oWeekDates) {
            const oSource = oEvent.getSource();
            if (oSource.RapidRegDialog) {
                oSource.RapidRegDialog.destroy();
                oSource.RapidRegDialog = null;
            }
            // Including rapidregistration css file
            const libraryPath = jQuery.sap.getModulePath("com.melody.lib");
            jQuery.sap.includeStyleSheet(libraryPath + "/controls/RapidRegistration/rapidRegistration.css");

            if (!oSource.RapidRegDialog) {
                Fragment.load({
                    controller: this,
                    id: oSource.getId() + "_RapidRegistrationDialog",
                    name: "com.melody.lib.fragments.RapidRegistration.RapidRegistrationDialog"
                }).then(async (oDialog) => {
                    const activityData = oSource.getProperty("activityData") || {};
                    this.fnInitRegDialogModels(oDialog);
                    this.RapidRegUIModel.setProperty("/OldSolutionWarningMsg", "");
                    this.RapidRegUIModel.setProperty("/oldSolutionWarningIcon", false);
                    this.RapidRegUIModel.setProperty("/isRapidRegDialogBusy", true);
                    this.RapidRegUIModel.setProperty("/WeekStartDate", oWeekDates["dFirstdate"]);
                    this.RapidRegUIModel.setProperty("/WeekEndDate", oWeekDates["dLastdate"]);
                    this.RapidRegUIModel.setProperty("/FEndDate", oWeekDates["dFirstdate"]);
                    this.RapidRegUIModel.setProperty("/WeekDates", oWeekDates);
                    oSource.addDependent(oDialog);
                    oSource.RapidRegDialog = oDialog;
                    this.RapidRegDialog = oDialog;
                    this.RapidRegDialogId = oSource.getId() + "_RapidRegistrationDialog";

                    // If Not Melody Request
                    if (!activityData["IsMelodyRequest"]) {
                        // Check for duplicate Activity
                        this.getDuplicateRegistrationInfo(activityData);
                    }

                    // await this.fnInitControlData();
                    this.fnBindRapidRegActData(oEvent);
                    return oDialog;
                });
            }
        },

        fnInitControlData: async function () {
            await this.getRegionMasterData();
        },

        // Function to load Region Master data
        getRegionMasterData: async function () {
            let oResponse = await ActivityUtil.getActivityRegion();
            if (oResponse) {
                this.RapidRegUIModel.setProperty("/aRegions", oResponse["regions"]);
                this.RapidRegUIModel.setProperty("/aMasterRegions", oResponse["masterRegions"]);
                let defaultRegion = {};
                if (oResponse["regions"]) {
                    defaultRegion = oResponse["regions"].find(function (item) {
                        return item["IsDefault"] === "X";
                    });
                    if (!defaultRegion) {
                        defaultRegion = {
                            Region: "",
                            SubRegion: "",
                            ProfitCenter: ""
                        };
                    }
                }
                this.RapidRegUIModel.setProperty("/DefaultRegionSet", {
                    Region: defaultRegion["Region"],
                    SubRegion: defaultRegion["SubRegion"],
                    ProfitCenter: defaultRegion["ProfitCenter"]
                });
            }
        },

        // Function to create Market Unit dataset on change of Region
        onRegionChange: function (oEvent) {
            let aMarketUnit = [];
            const RapidRegUIModel = this.RapidRegUIModel;
            let sKey = typeof oEvent === "object" ? oEvent.getParameters()["value"] : oEvent;
            let aRegion = RapidRegUIModel.getProperty("/aMasterRegions") || [];
            aMarketUnit = aRegion.map((item) => {
                if (item.Region === sKey) {
                    return item;
                }
            }).filter((item) => item);
            RapidRegUIModel.setProperty("/aMarketUnits", aMarketUnit);
            if (typeof oEvent === "object") {
                this.RapidRegDataModel.setProperty("/SubRegion", "");
            }
            RapidRegUIModel.refresh();
        },

        // Function to create Activity set on change of MarkeyUnit
        onMarketUnitChange: async function (oEvent) {
            const oSource = oEvent.getSource();
            let bindingContext = oSource.getSelectedItem().getBindingContext("RapidRegUIModel");
            let sPath = bindingContext.getPath();
            let contextObj = this.RapidRegUIModel.getProperty(sPath);
            this.fnCreateActivitySet(contextObj);
        },

        // Function to create Activity set
        fnCreateActivitySet: async function (contextObj) {
            let ActSetTitle = this.RapidRegDataModel.getProperty("/ActivitySetdescription");
            let oResponse = await ActivityUtil.createActivitySet({ Description: ActSetTitle, ProfitCenter: contextObj["ProfitCenter"] });

            this.RapidRegDataModel.setProperty("/Region", contextObj["Region"]);
            this.RapidRegDataModel.setProperty("/SubRegion", contextObj["SubRegion"]);
            this.RapidRegDataModel.setProperty("/ActivitySetId", oResponse["ActSetId"]);
            this.RapidRegDataModel.setProperty("/ActivitySetdescription", oResponse["Description"]);
        },

        // Function to close RapidRegistration dialog
        fnCloseRapidRegDialog: function () {
            this.RapidRegDialog.close();
            this.RapidRegDataModel.setData();
            this.RapidRegUIModel.setProperty("/StartDateValueState", "None");
            this.RapidRegUIModel.setProperty("/EndDateValueState", "None");
            this.RapidRegUIModel.setProperty("/CVJPhaseValueState", "None");
            if (this.RapidRegDialog) {
                this.RapidRegDialog.destroy();
                this.RapidRegDialog = null;
            }
        },

        // Function to initialize RapidRegistration dialog models
        fnInitRegDialogModels: function (oDialog) {
            const i18nModel = new ResourceModel({ bundleName: "com.melody.lib.i18n.i18n" });
            oDialog.setModel(i18nModel, "i18n");
            this.i18nModel = i18nModel;

            const RapidRegDataModel = new JSONModel();
            oDialog.setModel(RapidRegDataModel, "RapidRegDataModel");
            this.RapidRegDataModel = RapidRegDataModel;

            const RapidRegUIModel = new JSONModel();
            oDialog.setModel(RapidRegUIModel, "RapidRegUIModel");
            this.RapidRegUIModel = RapidRegUIModel;

            if (!this.oSolutionsModel) { // const oSolutionsModel = new JSONModel();
                this.oSolutionsModel = sap.ui.getCore().getModel("oSolutionsModel");
            }
            oDialog.setModel(this.oSolutionsModel, "oSolutionsModel");

            if (!this.opportunityModel) {
                this.opportunityModel = new JSONModel();
            }
            oDialog.setModel(this.opportunityModel, "opportunityModel");

            if (!this.oUserModel) {
                this.oUserModel = new JSONModel();
            }
            oDialog.setModel(this.oUserModel, "UserModel");
        },

        // Function to get CVJ phase master data
        getCVJPhaseMaster: async function (ActivityTypeId, RoleMpngID) {
            var aFilter = [];
            if (ActivityTypeId) {
                aFilter.push(new Filter("Acttypeid", "EQ", ActivityTypeId));
            }
            if (RoleMpngID) {
                aFilter.push(new Filter("RoleMpngID", "EQ", RoleMpngID));
            }
            let CVJPhaseMaster = await ActivityService.getCVJPhaseMasterData(aFilter);
            this.RapidRegUIModel.setProperty("/YC_MAC_M_CVJ_PHASE", CVJPhaseMaster);
            this.fnSetCVJPhaseDefaultKey();
        },

        // Function to find the default CVJ Phase selected key
        fnSetCVJPhaseDefaultKey: function () {
            const CVJPhaseMaster = this.RapidRegUIModel.getProperty("/YC_MAC_M_CVJ_PHASE") || [];
            let defaultCvjId = "";
            let defaultCvjDesc = "";
            if (CVJPhaseMaster && CVJPhaseMaster.length === 1) {
                defaultCvjId = CVJPhaseMaster[0].CvjPhaseId;
            } else {
                CVJPhaseMaster.filter(function (item) {
                    if (item.DefaultCVJ === "X") {
                        defaultCvjId = item.CvjPhaseId;
                        defaultCvjDesc = item.CvjPhaseDesc;
                    }
                });
            }
            this.RapidRegDataModel.setProperty("/CvjPhaseId", defaultCvjId);
            this.RapidRegDataModel.setProperty("/CvjPhaseDesc", defaultCvjDesc);
        },

        // Function to open Assest/Docs link popover
        fnOpenAttachDocsPopover: function (oEvent) {
            let that = this;
            var newLink = {
                "DocumentType": "0001",
                "Status": "X",
                "Url": "",
                "ProjectType": "ACTVT",
                "FileId": "",
                "FileName": "",
                "IsAddBtnVisible": true,
                "IsDelBtnVisible": false
            };
            let ActCreateStatus = this.RapidRegUIModel.getProperty("/ActCreateStatus");
            if (!this.RapidRegUIModel.getProperty("/to_AFiles") && (ActCreateStatus === "NEW_ACTIVITY")) {
                this.RapidRegUIModel.setProperty("/to_AFiles", [newLink]);
            } else {
                let aFiles = [newLink];
                let to_AFiles = this.RapidRegDataModel.getProperty("/to_AFiles");
                if (Array.isArray(to_AFiles)) {
                    aFiles = aFiles.concat(to_AFiles);
                }
                this.RapidRegUIModel.setProperty("/to_AFiles", aFiles);
            }

            if (that.EditAssestDocsPopover) {
                that.EditAssestDocsPopover.destroy();
                that.EditAssestDocsPopover = null;
            }

            if (!that.EditAssestDocsPopover) {
                Fragment.load({
                    id: this.RapidRegDialog.getId() + "_EditAssestDocsPopover",
                    name: "com.melody.lib.fragments.RapidRegistration.EditAssestDocsPopover",
                    controller: this
                }).then(function (oDialog) {
                    oDialog.setModel(that.i18nModel, "i18n");
                    oDialog.setModel(that.RapidRegUIModel, "RapidRegUIModel");
                    oDialog.setModel(that.RapidRegDataModel, "RapidRegDataModel");
                    that.RapidRegDialog.getParent().addDependent(oDialog);
                    that.EditAssestDocsPopover = oDialog;
                    that.EditAssestDocsPopover.open();
                    return oDialog;
                }.bind(that));
            } else {
                this.EditAssestDocsPopover.open();
            }
        },

        // Function to validate if user's input is a valid URL
        fnValidateAssetDocLink: function (oEvent) {
            var oSource = oEvent.getSource();
            var oValue = oSource.getValue();
            var sPath = oSource.getBindingContext("RapidRegUIModel").getPath();
            if (oValue) {
                var regexQuery = /^((([A-Za-z]{3,9}:(?:\/\/)?)(?:[\-;:&=\+\$,\w]+@)?[A-Za-z0-9\.\-]+|(?:www\.|[\-;:&=\+\$,\w]+@)[A-Za-z0-9\.\-]+)((?:\/[\+~%\/\.\w\-_]*)?\??(?:[\-\+=&;%@\.\w_]*)#?(?:[\.\!\/\\\w]*))?)/g;
                if (!regexQuery.test(oValue)) {
                    this.RapidRegUIModel.setProperty(sPath + "/UrlState", "Error");
                } else {
                    this.RapidRegUIModel.setProperty(sPath + "/UrlState", "None");
                }
            } else {
                this.RapidRegUIModel.setProperty(sPath + "/UrlState", "None");
            }
        },

        // Function to validate and Add Filename and URL in Assest/Docs link popover
        addNewAssetDocLink: function (oEvent, oData) {
            if (oEvent) {
                var oSource = oEvent.getSource();
                var sPath = oSource.getBindingContext("RapidRegUIModel").getPath();
                oData = this.RapidRegUIModel.getProperty(sPath);
            }
            if (oData.FileName && oData.Url && oData.UrlState !== "Error") {
                var oNewLink = {
                    "DocumentType": "0001",
                    "Status": "X",
                    "Url": "",
                    "ProjectType": "ACTVT",
                    "FileId": "",
                    "FileName": "",
                    "IsAddBtnVisible": true,
                    "IsDelBtnVisible": false
                };
                oData.IsAddBtnVisible = false;
                oData.IsDelBtnVisible = true;
                var to_AFiles = this.RapidRegUIModel.getProperty("/to_AFiles");
                var oArray = [oNewLink];
                oArray = oArray.concat(to_AFiles);
                this.RapidRegUIModel.setProperty("/to_AFiles", oArray);
                this.dataChange = true;
            } else if (!oData.FileName && oData.Url) {
                MessageToast.show("Please enter Display name");
            } else if (oData.FileName && (!oData.Url || oData.UrlState === "Error")) {
                MessageToast.show("Please enter valid URL");
            } else {
                MessageToast.show("Please enter Display name and URL");
            }
        },

        // Function to Delete Filename and URL in Assest/Docs link popover
        deleteNewAssetDocLink: function (oEvent) {
            var oSource = oEvent.getSource();
            var to_AFiles = this.RapidRegUIModel.getProperty("/to_AFiles");
            var sPath = oSource.getBindingContext("RapidRegUIModel").getPath();
            var index = parseInt(sPath.split("/")[2], 10);
            to_AFiles.splice(index, 1);
            this.RapidRegUIModel.setProperty("/to_AFiles", to_AFiles);
        },

        fnSetUpdatedLinksToDefaultModel: function () {
            var to_AFiles = this.RapidRegUIModel.getProperty("/to_AFiles");
            if (to_AFiles[0].FileName && to_AFiles[0].Url) {
                this.addNewAssetDocLink("", to_AFiles[0]);
            }
            var bVal = this.fnValidateMissingDocNameLinks();
            if (bVal) {
                to_AFiles = this.RapidRegUIModel.getProperty("/to_AFiles");
                to_AFiles = $.extend(true, [], to_AFiles);
                to_AFiles.splice(0, 1);
                this.RapidRegDataModel.setProperty("/to_AFiles", to_AFiles);
                this.EditAssestDocsPopover.close();
            } else {
                MessageToast.show("Please fill in missing/valid entries");
            }
        },

        // Function to validate if any Doc link or Doc name is missing in any rows
        fnValidateMissingDocNameLinks: function () {
            var SuccessCount = 0,
                ErrorCount = 0;
            var to_AFiles = this.RapidRegUIModel.getProperty("/to_AFiles");
            to_AFiles.filter(function (File, index) {
                if (index === 0) {
                    if (File.UrlState === "Error") {
                        ErrorCount = ErrorCount + 1;
                    } else {
                        SuccessCount = SuccessCount + 1;
                    }
                    return;
                }
                if (File.UrlState === "Error") {
                    ErrorCount = ErrorCount + 1;
                } else if (File.FileName && File.Url) {
                    File.UrlState = "None";
                    File.FileNameState = "None";
                    SuccessCount = SuccessCount + 1;
                } else if (!File.FileName && File.Url) {
                    File.UrlState = "None";
                    File.FileNameState = "Error";
                    ErrorCount = ErrorCount + 1;
                } else if (File.FileName && !File.Url) {
                    File.UrlState = "Error";
                    File.FileNameState = "None";
                    ErrorCount = ErrorCount + 1;
                } else if (!File.FileName && !File.Url) {
                    File.UrlState = "Error";
                    File.FileNameState = "Error";
                    ErrorCount = ErrorCount + 1;
                }
            });
            this.RapidRegUIModel.setProperty("/to_AFiles", to_AFiles);
            if (to_AFiles.length === SuccessCount) {
                return true;
            } else {
                return false;
            }
        },

        // Function to close Assest/Docs link popover
        fnCloseEditAssestDocsPopover: function () {
            var to_AFiles = this.RapidRegDataModel.getProperty("/to_AFiles");
            to_AFiles = $.extend(true, [], to_AFiles);
            var oNewLink = {
                "DocumentType": "0001",
                "Status": "X",
                "Url": "",
                "ProjectType": "ACTVT",
                "FileId": "",
                "FileName": "",
                "IsAddBtnVisible": true,
                "IsDelBtnVisible": false
            };
            var oArray = [oNewLink];
            oArray = oArray.concat(to_AFiles);
            this.RapidRegUIModel.setProperty("/to_AFiles", oArray);
            if (this.EditAssestDocsPopover) {
                this.EditAssestDocsPopover.close();
            }
        },

        // Formatter function
        fnFormatAssetDocsHeader: function (Array) {
            let headerStr = "Asset and Documents links";
            if (Array && Array.length) {
                headerStr = headerStr + " (" + Array.length + ")";
            }
            return headerStr;
        },

        // Function to navigate external links
        fnToNavigateExtLinks: function (oEvent) {
            let RapidRegUIModel = this.RapidRegUIModel;
            let sPath = oEvent.getSource().getBindingContext("RapidRegUIModel").getPath();
            let contextObj = this.RapidRegUIModel.getProperty(sPath);
            let sUrl = contextObj["Url"];
            if (sUrl) {
                if (!sUrl.match(/^[a-zA-Z]+:\/\//)) {
                    sUrl = 'https://' + sUrl;
                }
                window.open(sUrl, "_blank");
            }
        },

        // Function to createData for CrossApp navigation
        navToFullRegistration: function (oEvent) {
            let oParam = {};
            let RapidRegDataModel = this.RapidRegDataModel;
            let ActivityId = RapidRegDataModel.getProperty("/ActivityId");
            if (!ActivityId) {
                oParam = {
                    "IsRapidRegistration": true,
                    "ActivityTypeID": RapidRegDataModel.getProperty("/ActivityTypeId"),
                    "ActGUID": RapidRegDataModel.getProperty("/ActivityGuid"),
                    "RoleID": RapidRegDataModel.getProperty("/RoleMpngID"),
                    "ActvtAsstdID": RapidRegDataModel.getProperty("/ActvtAsstdID"),
                    "ChildFrmLayoutId": RapidRegDataModel.getProperty("/ChildFrmLayoutId")
                };
                if (RapidRegDataModel.getProperty("/GlobalUltimateID")) {
                    oParam["GlobalUltimateID"] = RapidRegDataModel.getProperty("/GlobalUltimateID");
                }
                if (RapidRegDataModel.getProperty("/OpportunityNumber")) {
                    oParam["OpportunityNumber"] = RapidRegDataModel.getProperty("/OpportunityNumber");
                }
                if (RapidRegDataModel.getProperty("/ActivitySetId")) {
                    oParam["ActivitySetId"] = RapidRegDataModel.getProperty("/ActivitySetId");
                }
            } else {
                oParam = {
                    "ActivityDetail": true,
                    "ActivityID": parseInt(ActivityId)
                };
            }
            this.fnCrossAppNavigation(oParam, "pcactivityform");
        },

        // Function to  do CrossApp navigation
        fnCrossAppNavigation: function (oParam, semanticObject) {
            let parentUrl = location.ancestorOrigins[0] + "/site";
            let oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
            let hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                target: {
                    semanticObject: semanticObject, // "pcactivityform",
                    action: "app"
                },
                params: oParam
            })) || "";
            let sUrl = parentUrl + hash;
            window.open(sUrl, "_blank");
            // Commented as part of CFLP
            // oCrossAppNavigator.toExternal({
            // target: {
            // shellHash: hash
            // }
            // });
        },

        // Function to create and set Full form navigation link in Rapid Registration dialog
        fnFormatSetFullRegLink: function (ActivityID) {
            let sParams = "";
            let RapidRegDataModel = this.RapidRegDataModel;
            // let sUrl = window.location.search + `#pcactivityform-app`;
            let sUrl = `#pcactivityform-app`;
            let ActivityGuid = RapidRegDataModel.getProperty("/ActivityGuid");
            if (!ActivityID) {
                let ActivityTypeId = RapidRegDataModel.getProperty("/ActivityTypeId");
                let RoleMpngID = RapidRegDataModel.getProperty("/RoleMpngID");
                let ActvtAsstdID = RapidRegDataModel.getProperty("/ActvtAsstdID");
                let ChildFrmLayoutId = RapidRegDataModel.getProperty("/ChildFrmLayoutId");
                let GlobalUltimateID = RapidRegDataModel.getProperty("/GlobalUltimateID");
                let OpportunityNumber = RapidRegDataModel.getProperty("/OpportunityNumber");
                let ActivitySetId = RapidRegDataModel.getProperty("/ActivitySetId");
                sParams = `IsRapidRegistration=true&ActivityTypeID=${ActivityTypeId}&ActGUID=${ActivityGuid}&RoleID=${RoleMpngID}&ActvtAsstdID=${ActvtAsstdID}&ChildFrmLayoutId=${ChildFrmLayoutId}`;
                sParams = GlobalUltimateID ? `${sParams}&GlobalUltimateID=${GlobalUltimateID}` : `${sParams}`;
                sParams = OpportunityNumber ? `${sParams}&OpportunityNumber=${OpportunityNumber}` : `${sParams}`;
                sParams = ActivitySetId ? `${sParams}&ActivitySetId=${ActivitySetId}` : `${sParams}`;
            } else {
                sParams = `IsRapidRegistration=true&ActivityID=${ActivityID}`;
            } sUrl = `${sUrl}?${sParams}`
            this.RapidRegUIModel.setProperty("/FullRegistrationLink", sUrl);
        },

        navToFullRegistrationForm: async function (oEvent) {
            let oRapidRegData = this.RapidRegDataModel.getData();
            let oRapidRegPayloadData = structuredClone(oRapidRegData);
            var demoEnvCheckbox = sap.ui.core.Fragment.byId(this.RapidRegDialogId, "demoEnvironmentCheckBox");
            if (demoEnvCheckbox) {
                oRapidRegPayloadData.DemoEnvironmentCheckBox = demoEnvCheckbox.getSelected();
            }
            if (oRapidRegPayloadData) {
                let oPayloadData = {
                    "ActivityGuid": oRapidRegPayloadData.ActivityGuid,
                    "DraftJson": JSON.stringify(oRapidRegPayloadData)
                };
                await ActivityService.copyRapidRegData(oPayloadData);
            }
            // const obj = JSON.parse(jsonString);
            this.RapidRegDialog.close();
            let sUrl = this.RapidRegUIModel.getProperty("/FullRegistrationLink");
            if (oRapidRegPayloadData.ActivityId) {
                sUrl += "&ActGUID=" + oRapidRegPayloadData.ActivityGuid;
            }
            sap.m.URLHelper.redirect(sUrl, true);
        },
        // Event triggered on start date change
        onHandleStartDateChange: function (oEvent) {
            var startDate = oEvent.getSource().getDateValue();
            startDate.setHours(9, 0, 0);
            oEvent.getSource().setValue(startDate);
            oEvent.getSource().setDateValue(startDate);
            this.RapidRegDataModel.setProperty("/StartDate", startDate);
            this.RapidRegUIModel.setProperty("/StartDateValueState", "None");
            this.fnToRestrictStartDate(startDate);
            startDate = this.RapidRegDataModel.getProperty("/StartDate");
            var endDate = this.RapidRegDataModel.getProperty("/EndDate");
            if (startDate.getTime() > endDate.getTime()) {
                endDate = new Date(startDate);
                endDate.setHours(17, 0, 0);
                this.RapidRegDataModel.setProperty("/EndDate", endDate);
            }

            if (this.RapidRegDataModel.getProperty("/ActivityId")) {
                this.RapidRegUIModel.setProperty("/FEndDate", null);
            } else {
                this.RapidRegUIModel.setProperty("/FEndDate", startDate);
            }
            this.RapidRegDataModel.refresh();
        },

        // Common function for 'restriction on strat date' via start Date and End Date
        fnToRestrictStartDate: function (startDate) {
            var currentDate = this.RapidRegUIModel.getProperty("/WeekDates/dFirstdate");
            var restrictDate = new Date(this.RapidRegUIModel.getProperty("/DateRestriction"));
            restrictDate.setHours(0, 0, 0);
            var dateOfRestrictDate = restrictDate.getDate();
            var sMsg;
            var ActivityTypeId = this.RapidRegUIModel.getProperty("/ActivityTypeId");
            if (ActivityTypeId) {
                if (currentDate.getDate() >= dateOfRestrictDate) {
                    if (startDate.getFullYear() >= currentDate.getFullYear()) {
                        this.fnToGetDaysPrior(startDate, currentDate);
                    } else {
                        sMsg = "Can register only in current year!";
                        MessageToast.show(sMsg);
                        this.fnToSetStartAndEndDate(startDate, currentDate);
                    }
                } else {
                    if (startDate.getFullYear() >= (currentDate.getFullYear() - 1) || startDate.getFullYear() === currentDate.getFullYear()) {
                        this.fnToGetDaysPrior(startDate, currentDate);
                    } else {
                        sMsg = "Select year from the previous year!"
                        MessageToast.show(sMsg);
                        this.fnToSetStartAndEndDate(startDate, currentDate);
                    }
                }
            } else {
                sMsg = "Please select 'Activity Type'!";
                MessageToast.show(sMsg);
            }
        },

        // C5350613 - function to check if start date is prior to 90/60 days
        fnToGetDaysPrior: function (startDate, currentDate) {
            var currentDateUTC = Date.UTC(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate());
            var startDateUTC = Date.UTC(startDate.getFullYear(), startDate.getMonth(), startDate.getDate());
            var currentToStartDifference = Math.floor((currentDateUTC - startDateUTC) / (1000 * 60 * 60 * 24));
            var daysDifference = this.RapidRegUIModel.getProperty("/DaysRestriction");
            daysDifference = (daysDifference) ? parseInt(daysDifference) : "";
            var sMsg;
            if (currentToStartDifference <= daysDifference || daysDifference === 0) {
                startDate.setHours(9, 0, 0);
                this.RapidRegDataModel.setProperty("/StartDate", startDate);
            } else {
                sMsg = `Can not register activity prior to more than ${daysDifference} days!`;
                MessageToast.show(sMsg);
                this.fnToSetStartAndEndDate(startDate, currentDate);
            }
        },

        // C5350613 - function to set start and end dates if validations fail
        fnToSetStartAndEndDate: function (startDate, currentDate) {
            startDate = new Date(currentDate.getTime());
            startDate.setHours(9, 0, 0);
            this.RapidRegDataModel.setProperty("/StartDate", startDate);
        },

        // Event triggered on end date change
        onHandleEndDateChange: function (oEvent) {

            var toDate = oEvent.getSource().getDateValue();
            toDate.setHours(17, 0, 0);
            oEvent.getSource().setValue(toDate)
            oEvent.getSource().setDateValue(toDate);
            this.RapidRegDataModel.setProperty("/EndDate", toDate);
            this.RapidRegUIModel.setProperty("/EndDateValueState", "None");

            var fromDate = this.RapidRegDataModel.getProperty("/StartDate");
            const activityData = this.RapidRegDataModel.getData();
            if (toDate.getTime() < fromDate.getTime()) {
                var oDate = new Date(toDate);
                oDate.setDate(toDate.getDate(), toDate.getMonth(), toDate.getFullYear());
                oDate.setHours(9, 0, 0);
                this.RapidRegDataModel.setProperty("/StartDate", oDate);
            }
            this.RapidRegDataModel.refresh();

            //If its not Melody Request
            if (!this.RapidRegDataModel.getProperty("/IsMelodyRequest")) {
                this.getDuplicateRegistrationInfo(activityData, toDate);
            }

            // var OppoId = this.oViewSettingsModel.getProperty("/OPPT_ID");
            // var associateType = this.oRegModel.getProperty("/associateType");
            // if (OppoId && OppoId !== "" && associateType === 1) {
            // this._getDuplicateRegData();
            // }
        },

        // Event triggered on CVJ phase change
        onHandleCVJPhaseChange: function (oEvent) {
            let cvjPhaseDesc = oEvent.getParameter("value");
            this.RapidRegDataModel.setProperty("/CvjPhaseDesc", cvjPhaseDesc);
            if (oEvent.getSource().getSelectedKey()) {
                this.RapidRegUIModel.setProperty("/CVJPhaseValueState", "None");
            } else {
                this.RapidRegUIModel.setProperty("/CVJPhaseValueState", "Error");
            }
        },

        // Function to save new/update activity
        fnMandateFields: function () {
            var madatoryFiledCount = this.fnValidateMandatoryFields();
            if (!madatoryFiledCount) {
                let RapidRegDataModel = this.RapidRegDataModel;
                let ActivityData = RapidRegDataModel.getData();
                let ActivityGuid = ActivityData["ActivityGuid"];

                let aFiles = [];
                if (ActivityData["to_AFiles"] && ActivityData["to_AFiles"].length) {
                    ActivityData["to_AFiles"].filter((oFile) => {
                        delete oFile.UrlState;
                        delete oFile.FileNameState;
                        delete oFile.IsAddBtnVisible;
                        delete oFile.IsDelBtnVisible;
                        oFile.ActivityGuid = ActivityGuid;
                    });
                    aFiles = ActivityData["to_AFiles"];
                }

                let aInitiatives = [];
                if (ActivityData["to_AInitiative"] && ActivityData["to_AInitiative"].length) {
                    ActivityData["to_AInitiative"].filter((item) => {
                        aInitiatives.push({ "ActivityGuid": ActivityGuid, "InitiativeId": item.InitiativeId });
                    });
                }

                var aTaxonomy = ActivityData.to_ATaxonomy;
                aTaxonomy.filter(function (item) {
                    item.ActivityGuid = ActivityGuid;
                    delete item.LevelId;
                    delete item.LevelDesc;
                });

                var aMaterial = ActivityData.to_AMaterial;
                aMaterial.filter(function (item) {
                    item.ActivityGuid = ActivityGuid;
                    delete item.LevelId;
                    delete item.LevelDesc;
                });

                var aAddOpp = [];
                var aAddOppSelections = ActivityData.to_AAddOpp;
                if (aAddOppSelections.length) {
                    aAddOppSelections.filter(function (object) {
                        var opptObj = {
                            "OpportunityNo": object.OpportunityNo,
                            "ActivityGuid": ActivityGuid
                        };
                        aAddOpp.push(opptObj);
                    });
                }
                let aLandcsapes = [];
                if (ActivityData["to_ALand"] && ActivityData["to_ALand"].length) {
                    ActivityData["to_ALand"].filter((item) => {
                        delete item.SelectionCat;
                        delete item.prevSelected;
                        delete item.selected;
                        delete item.__metadata;
                        item.ActivityGuid = ActivityGuid;
                    });
                    aLandcsapes = ActivityData["to_ALand"];
                }

                let aTeam = [];
                if (ActivityData["to_ATeam"] && ActivityData["to_ATeam"].length) {
                    ActivityData["to_ATeam"].filter((item) => {
                        const oUser = {
                            "EMAIL": item.EMAIL,
                            "ID": item.ID,
                            "NAME": item.NAME,
                            "ROLE": item.ROLE
                        };
                        aTeam.push(oUser);
                    });
                }

                let oData = $.extend(true, {}, ActivityData);
                oData["EndDate"] = oData["EndDate"].toJSON().split(".")[0] + "Z";
                oData["StartDate"] = oData["StartDate"].toJSON().split(".")[0] + "Z";
                oData["CreateDate"] = oData["CreateDate"].toJSON().split(".")[0] + "Z";
                oData["DryRunDate"] = oData["DryRunDate"] ? (oData["DryRunDate"].toJSON().split(".")[0] + "Z") : null;
                oData["StatusChangedAt"] = oData["StatusChangedAt"] ? (oData["StatusChangedAt"].toJSON().split(".")[0] + "Z") : null;
                oData["to_AInitiative"] = aInitiatives;
                oData["to_AFiles"] = aFiles;
                oData["to_AAddOpp"] = aAddOpp;
                oData["to_ALand"] = aLandcsapes;
                oData["to_ATeam"] = aTeam;

                this.RapidRegUIModel.setProperty("/isRapidRegDialogBusy", true);
                this.fnGetFindOppActUsers(oData);
                // VAT Team
                // this.fnRegisterActivity(oData);
            } else {
                if (madatoryFiledCount === 1 && this.RapidRegUIModel.getProperty("/LandscapeValueState") === "Error") {
                    MessageToast.show("Please Select the Checkbox or Landscapes to proceed");
                } else {
                    MessageToast.show("Please fill all mandatory fields.");
                }
            }
        },

        // Functon to validate the mandatory fields
        fnValidateMandatoryFields: function () {
            let valueStateCount = 0;
            let RapidRegUIModel = this.RapidRegUIModel;
            let RapidRegDataModel = this.RapidRegDataModel;
            let ActivityData = RapidRegDataModel.getData();
            let SelectedLayout = RapidRegUIModel.getProperty("/SelectedLayout") || {};

            if (SelectedLayout["StartDate"]["Visible"] && SelectedLayout["StartDate"]["Required"]) {
                if (!ActivityData["StartDate"]) {
                    valueStateCount++;
                    RapidRegUIModel.setProperty("/StartDateValueState", "Error");
                } else {
                    RapidRegUIModel.setProperty("/StartDateValueState", "None");
                }
            }

            if (SelectedLayout["EndDate"]["Visible"] && SelectedLayout["EndDate"]["Required"]) {
                if (!ActivityData["EndDate"]) {
                    valueStateCount++;
                    RapidRegUIModel.setProperty("/EndDateValueState", "Error");
                } else {
                    RapidRegUIModel.setProperty("/EndDateValueState", "None");
                }
            }

            if (SelectedLayout["CVJPhase"]["Visible"] && SelectedLayout["CVJPhase"]["Required"]) {
                if (!ActivityData["CvjPhaseId"]) {
                    valueStateCount++;
                    RapidRegUIModel.setProperty("/CVJPhaseValueState", "Error");
                } else {
                    RapidRegUIModel.setProperty("/CVJPhaseValueState", "None");
                }
            }

            if (ActivityData["ActvtAsstdID"] === "503") { // ActivitySetId
                if (!ActivityData["Region"]) {
                    valueStateCount++;
                    RapidRegUIModel.setProperty("/RegionValueState", "Error");
                } else {
                    RapidRegUIModel.setProperty("/RegionValueState", "None");
                }
                if (!ActivityData["SubRegion"]) {
                    valueStateCount++;
                    RapidRegUIModel.setProperty("/SubRegionValueState", "Error");
                } else {
                    RapidRegUIModel.setProperty("/SubRegionValueState", "None");
                }
            }

            if (SelectedLayout["AdditionalSolutions"]["Visible"]) {
                if (!ActivityData["to_ATaxonomy"].length) {
                    valueStateCount++;
                    RapidRegUIModel.setProperty("/SolutionValueState", "Error");
                } else {
                    RapidRegUIModel.setProperty("/SolutionValueState", "None");
                }
            }

            if (ActivityData["FormLayoutId"] === "00001" || ActivityData["FormLayoutId"] === "00024") {
                var demoEnvCheckbox = sap.ui.core.Fragment.byId(this.RapidRegDialogId, "demoEnvironmentCheckBox");
                if (!(demoEnvCheckbox.getSelected() || ActivityData["to_ALand"].length)) {
                    valueStateCount++;
                    RapidRegUIModel.setProperty("/LandscapeValueState", "Error");
                } else {
                    RapidRegUIModel.setProperty("/LandscapeValueState", "None");
                }
            }

            if (SelectedLayout["ActivityRisk"]["Visible"]) {
                const sRiskId = RapidRegDataModel.getProperty("/RiskAssessId");
                const sRiskComment = RapidRegDataModel.getProperty("/RiskComment");
                if ((sRiskId === "01" || sRiskId === "02") && !sRiskComment.trim()) {
                    valueStateCount++;
                    RapidRegUIModel.setProperty("/RiskCommentValueState", "Error");
                } else {
                    RapidRegUIModel.setProperty("/RiskCommentValueState", "None");
                }
            }

            return valueStateCount;
        },

        // Fuction to initialize Activity Create/Update data on custom control press event
        fnBindRapidRegActData: async function (oEvent) {
            const oSource = oEvent.getSource();
            const ActivityId = oSource.getActivityId();
            const ActivityData = oSource.getActivityData() || {};
            const ActivityTypeId = ActivityData["ActivityTypeId"];
            this.RapidRegUIModel.setProperty("/isActSaveEnabled", true);
            this.RapidRegUIModel.setProperty("/IsMelodyRequest", ActivityData?.IsMelodyRequest || false);

            if (ActivityData["ActvtAsstdID"] === "503" || ActivityData["ActAsstId"] === "503") {
                await this.fnInitControlData();
            }

            if (ActivityId && "ActivityId" in ActivityData) {
                this.fnFetchActivityDetails(ActivityId, ActivityData);
                this.fnFormatSetFullRegLink(ActivityId);
            } else {
                this.fnInitializeNewActivity(ActivityData);
                //Solution Hierarchy Create Case
                if (ActivityData["ActvtAsstdID"] === "502" || ActivityData["ActAsstId"] === "502") {
                    this.getOppMaterials(ActivityData["OpportunityNumber"], ActivityData);
                }
            }
            this.RapidRegUIModel.setProperty("/ActCreateStatus", ActivityId ? "EDIT_ACTIVITY" : "NEW_ACTIVITY");
            this.RapidRegUIModel.setProperty("/ActivityTypeId", ActivityTypeId);
            this.getCVJPhaseMaster(ActivityTypeId, ActivityData["RoleMpngID"]);
            this.getStatusMaster();
            this.getLandscapes();
            this.getLevel2MasterData();
            this.getRiskButtons();
            this.getActivityDays();
            this.getConstants();
            this.fnGetBindingContext(oEvent);

            // Navigate to Activity form incase of Demo form, as its an exisitng functionality in SL
            /*	if (this.fnValidateIfDemoForm(ActivityData)) {
                if (ActivityId) {
                    this.navToFullRegistration(ActivityId);
                }
            } else {
                this.RapidRegDialog.open();
            }*/
            this.RapidRegDialog.open();
        },

        // Function to get the binding context of the button
        fnGetBindingContext: function (oEvent) {
            let btnSource = oEvent.getSource();
            let controlSource = btnSource || false;
            if (controlSource && controlSource.getBindingInfo("activityData")) {
                let aActivityPathInfo = (controlSource) ? controlSource.getBindingInfo("activityData").parts : [];
                if (aActivityPathInfo.length) {
                    let oInfo = aActivityPathInfo[0];
                    let contextObject = (oInfo.model) ? btnSource.getBindingContext(oInfo.model) : btnSource.getBindingContext();
                    let path = (contextObject) ? contextObject.getPath() : "";
                    this.RapidRegUIModel.setProperty("/contextPath", path);
                    this.controlSource = controlSource;
                }
            } else {
                this.RapidRegUIModel.setProperty("/contextPath", controlSource.getActivityContextPath());
                this.controlSource = controlSource;
            }
        },

        // Function to fetch Activity details based on Activity ID: EDIT CASE
        fnFetchActivityDetails: async function (ActivityId, selectedBtnActData) {
            let ActivityData = await ActivityService.fnGetActivityDetails(parseInt(ActivityId));
            this.fnFetchActAssociations(ActivityData, selectedBtnActData);
            //Solution Hierarchy Edit Case
            if (ActivityData["ActvtAsstdID"] === "502" || ActivityData["ActAsstId"] === "502") {
                this.getOppMaterials(ActivityData["OpportunityNumber"], ActivityData);
            }
        },

        // Function to fetch Activity's assocaitions: EDIT CASE
        fnFetchActAssociations: async function (ActivityData, selectedBtnActData) {
            let that = this;
            let aFilter = [new Filter("ActivityGuid", "EQ", ActivityData["ActivityGuid"])];
            let aFiles = await ActivityService.fnFetchActAssociations("/YC_MAC_T_FILE_CONTENT", aFilter);
            let aInitiatives = await ActivityService.fnFetchActAssociations("/yc_mac_t_act_init", aFilter);
            let aAddOpps = await ActivityService.fnFetchActAssociations("/YC_MAC_T_ADD_OPP", aFilter);
            let aLandscapes = await ActivityService.fnFetchActAssociations("/Yc_Mac_T_Landscapes", aFilter);
            let aMaterial = await ActivityService.fnFetchActAssociations("/YC_MAC_T_SOL_MTRL", aFilter);
            let aTaxonomy = await ActivityService.fnFetchActAssociations("/YC_MAC_T_SOL_TXNMY", aFilter);
            let aSolutions = await ActivityService.fnFetchActAssociations("/Yc_Mac_T_Solution", aFilter);
            let aTeam = await ActivityService.fnFetchActAssociations("/Yc_Mac_T_Actteam", aFilter);

            this.RapidRegUIModel.setProperty("/isActSaveEnabled", true);

            ActivityData["to_AFiles"] = aFiles;
            ActivityData["to_AInitiative"] = aInitiatives;
            ActivityData["to_AAddOpp"] = aAddOpps;
            ActivityData["to_ALand"] = aLandscapes;
            ActivityData["to_AMaterial"] = aMaterial;
            ActivityData["to_ATaxonomy"] = aTaxonomy;
            ActivityData["to_ASol"] = aSolutions;
            ActivityData["to_ATeam"] = aTeam;

            this.selectedTeamMap = {};
            if (aTeam.length) {
                aTeam.forEach(user => this.selectedTeamMap[user.ID] = user);
            }
            this.oUserModel.setProperty("/SelectedTeam", aTeam);

            this.landscapeMap = {};
            if (aLandscapes.length) {
                aLandscapes.filter(function (obj, index) {
                    that.landscapeMap[obj.LandsId] = obj;
                });
                let aLandscapeMaster = this.RapidRegUIModel.getProperty("/landscape");
                if (aLandscapeMaster) {
                    aLandscapeMaster.forEach(item => {
                        if (that.landscapeMap.hasOwnProperty(item.LandsId) && item.SelectionCat === "Master") {
                            item.selected = true;
                            item.prevSelected = true;
                        } else {
                            item.selected = false;
                            item.prevSelected = false;
                        }
                    });
                    aLandscapeMaster = this.fnFormatFlatToTreeData(aLandscapeMaster, "SelectionCat");
                    aLandscapeMaster = this.fnRestructureTreeData(aLandscapeMaster, "SelectionCat", "landscape");
                    this.RapidRegUIModel.setProperty("/landscape", aLandscapeMaster);
                }
            }

            // making the checkbox to checked if landscapes are already there
            if (ActivityData["FormLayoutId"] === "00001" && !aLandscapes.length) {
                var demoEnvCheckbox = sap.ui.core.Fragment.byId(this.RapidRegDialogId, "demoEnvironmentCheckBox");
                demoEnvCheckbox.setSelected(true);
            }

            this.setSolHierarchyDataInEdit(ActivityData, aMaterial, aTaxonomy);

            if (ActivityData["ActvtAsstdID"] === "501" || ActivityData["ActvtAsstdID"] === "502") {
                ActivityData = await this.fnFetchActivityAccOppoData(ActivityData);
            }

            ActivityData = this.fnFormatActivityData(ActivityData);
            this.fnSetRapidRegDialogData(ActivityData, true);

            //Check for old solution hirarchy 
            if ("ActivityId" in ActivityData && ActivityData.ActivityId) {
                this.getActDetailAddSolution(ActivityData);
            }

            if (ActivityData["ActvtAsstdID"] === "503") {
                this.onRegionChange(ActivityData["Region"]);
            }
        },

        // Function to fetch Account and Opportunity details: EDIT CASE
        fnFetchActivityAccOppoData: async function (ActivityData) {
            let isOppoMetadataLoaded = OpportunityService.models.harmony.getServiceMetadata();
            this.RapidRegUIModel.setProperty("/isOppoMetadataLoaded", isOppoMetadataLoaded ? true : false);
            if (isOppoMetadataLoaded) {
                if (ActivityData["ActvtAsstdID"] === "501" && ActivityData["GlobalUltimateID"]) {
                    let oAccData = await AccountUtil.getAccountDetails(ActivityData["GlobalUltimateID"]);
                    let to_AAccnt = [{
                        iss: oAccData["ISS"],
                        iac: oAccData["IAC"],
                        accountname: oAccData["AccountName"],
                        accountid: oAccData["AccountId"]
                    }];
                    ActivityData["to_AAccnt"] = to_AAccnt;
                }
                if (ActivityData["ActvtAsstdID"] === "502" && ActivityData["OpportunityNumber"]) {
                    let oOppoData = await OpportunityUtil.getOpportunitiesTeam(ActivityData["OpportunityNumber"]);
                    oOppoData = oOppoData["data"];
                    let to_AOpportunity = [{
                        "ACCOUNT_NAME": oOppoData["ACCOUNT_NAME"],
                        "OPPT_ID": oOppoData["OPPT_ID"],
                        "accountid": oOppoData["ACCOUNT"],
                        "PHASE_DESC": "",
                        "mastercodeid": "",
                        "Status": oOppoData["STATUS"],
                        "SelectedOpportunity": oOppoData
                    }];
                    ActivityData["to_AOpportunity"] = to_AOpportunity;
                }
                this.RapidRegUIModel.setProperty("/isActSaveEnabled", true);
            } else {
                this.RapidRegUIModel.setProperty("/isActSaveEnabled", false);
            }
            return ActivityData;
        },

        // Function to Initialize Activity data based on Activity TypeID: CREATE CASE
        fnInitializeNewActivity: async function (pActivityData) {
            let ActivityData = await ActivityService.fnInitializeNewActivity({});
            this.fnFormatCreateUIData(ActivityData, pActivityData);
        },

        // Function to format create payload: CREATE CASE
        fnFormatCreateUIData: function (ActivityData, pActivityData) {
            let aKeys = Object.keys(pActivityData);
            if (aKeys) {
                for (let i = 0; i < aKeys.length; i++) {
                    ActivityData[aKeys[i]] = pActivityData[aKeys[i]]
                }
            }
            this.fnSetRapidRegDialogData(ActivityData);
            this.fnFormatSetFullRegLink();

            // Navigate to Activity form incase of Demo form, as its an exisitng functionality in SL
            // if (this.fnValidateIfDemoForm(ActivityData)) {
            // this.navToFullRegistration();
            // }
        },

        // Function to check if its Demo form
        fnValidateIfDemoForm: function (ActivityData) {
            return (ActivityData["FormLayoutId"] === "00001" || ActivityData["FormLayoutId"] === "00024") ? true : false;
        },

        // Function to format Activity data for UI binding
        fnFormatActivityData: function (ActivityData) {
            ActivityData["EndDate"] = ActivityData["EndDate"] ? new Date(ActivityData["EndDate"]) : null;
            ActivityData["StartDate"] = ActivityData["StartDate"] ? new Date(ActivityData["StartDate"]) : new Date();
            ActivityData["DryRunDate"] = ActivityData["DryRunDate"] ? new Date(ActivityData["DryRunDate"]) : null;
            ActivityData["StatusChangedAt"] = ActivityData["StatusChangedAt"] ? new Date(ActivityData["StatusChangedAt"]) : new Date();

            if (ActivityData["to_AFiles"]) {
                ActivityData.to_AFiles.filter((file) => {
                    file["IsAddBtnVisible"] = false;
                    file["IsDelBtnVisible"] = true;
                });
            }
            return ActivityData;
        },

        // Function to set Activity data for RapidRegistration dialog
        fnSetRapidRegDialogData: function (ActivityData) {
            if (ActivityData["ChildFrmLayoutId"]) {
                this.fnGetLayoutVisibility(ActivityData["ChildFrmLayoutId"]);
            }
            if (ActivityData["ActivityId"]) {
                this.RapidRegUIModel.setProperty("/WeekStartDate", null);
                this.RapidRegUIModel.setProperty("/WeekEndDate", null);
                this.RapidRegUIModel.setProperty("/FEndDate", null);
            } else {
                let WeekStartDate = this.RapidRegUIModel.getProperty("/WeekStartDate");
                if (WeekStartDate) {
                    ActivityData.StartDate = WeekStartDate;
                    ActivityData.EndDate = WeekStartDate;
                }
            }

            this.RapidRegDataModel.setProperty("/", ActivityData);
            if (!ActivityData["ActivityId"]) {
                this.setDefaultDataToModel();
                this.fnSetCVJPhaseDefaultKey();
            }
            this.fetchOpportunitiesTeam();
            const oLeadUser = {
                Name: this.RapidRegDataModel.getProperty("/ActivityLeadName") || "",
                EmailId: this.RapidRegDataModel.getProperty("/ActivityLeadEmailId") || "",
                UserId: this.RapidRegDataModel.getProperty("/ActivityLead") || ""
            };
            this._setLeadUserData(oLeadUser);
            this.RapidRegUIModel.setProperty("/InitialStatus", ActivityData.Status);
            if (ActivityData["ActAsstId"] === "503" || ActivityData["ActvtAsstdID"] === "503") {
                let DefaultRegionSet = this.RapidRegUIModel.getProperty("/DefaultRegionSet");
                this.onRegionChange(DefaultRegionSet["Region"]);
                if (!ActivityData["ActivityId"]) {
                    this.RapidRegDataModel.setProperty("/Region", DefaultRegionSet["Region"]);
                    this.RapidRegDataModel.setProperty("/SubRegion", DefaultRegionSet["SubRegion"]);
                }
                this.RapidRegUIModel.setProperty("/TempActSetdescription", ActivityData["ActivitySetdescription"]);
            }

            setTimeout(() => {
                this.RapidRegUIModel.setProperty("/isRapidRegDialogBusy", false);
            }, 500);
        },

        // Function Create/Update Activity
        fnRegisterActivity: async function (ActivityData) {
            let sMessage;
            const oRapidRegCtrl = this.controlSource;
            const contextPath = this.RapidRegUIModel.getProperty("/contextPath");
            try {
                sMessage = (ActivityData.ActivityId) ? "Activity Updated with Activity ID:" : "Activity Registered with Activity ID:";
                if (ActivityData["ActvtAsstdID"] === "503") {
                    let TempActSetDesc = this.RapidRegUIModel.getProperty("/TempActSetdescription");
                    let ActivitySetdescription = this.RapidRegDataModel.getProperty("/ActivitySetdescription");
                    let bVal = TempActSetDesc === ActivitySetdescription ? false : true;
                    if (bVal || !this.RapidRegDataModel.getProperty("/ActivitySetId")) { // Validates for NoAssociation case, when ActivitySetId is empty
                        let Region = this.RapidRegDataModel.getProperty("/Region");
                        let SubRegion = this.RapidRegDataModel.getProperty("/SubRegion");
                        let MarketUnits = this.RapidRegUIModel.getProperty("/aMarketUnits");
                        let SelectedPC = MarketUnits.find(function (item) {
                            return item["SubRegion"] === SubRegion;
                        });
                        // let DefaultRegionSet = this.RapidRegUIModel.getProperty("/DefaultRegionSet");
                        await this.fnCreateActivitySet({ Region: Region, SubRegion: SubRegion, ProfitCenter: SelectedPC["ProfitCenter"] });
                        ActivityData["Region"] = Region;
                        ActivityData["SubRegion"] = SubRegion;
                        ActivityData["ActivitySetId"] = this.RapidRegDataModel.getProperty("/ActivitySetId");
                        ActivityData["ActivitySetdescription"] = this.RapidRegDataModel.getProperty("/ActivitySetdescription");
                    }
                }

                if ("to_AOpportunity" in ActivityData && ActivityData.to_AOpportunity.length) {
                    const oOpportunity = ActivityData.to_AOpportunity[0];
                    // saving opp status and description - git:479
                    if (!ActivityData.ActivityId) {
                        ActivityData.OppStatusId = oOpportunity.Status;
                        ActivityData.OppStatusDesc = oOpportunity.StatusDescription || this.formatStatus(oOpportunity.Status);
                    }
                    delete oOpportunity["Status"];
                    delete oOpportunity["StatusDescription"];
                    delete oOpportunity["SelectedOpportunity"];
                    if ("description" in oOpportunity) {
                        delete oOpportunity["description"];
                    }
                }

                let oData = await ActivityService.fnInitializeNewActivity(ActivityData);
                this.RapidRegUIModel.setProperty("/isRapidRegDialogBusy", false);
                sMessage = sMessage + ` ${oData.ActivityId
                    }`;
                MessageToast.show(sMessage);
                oRapidRegCtrl.fireEvent("selectedActivity", {
                    "activityData": oData,
                    "contextPath": contextPath
                });
                if (oData["ActvtAsstdID"] === "502" && this.IsVATAccessSericeTriggered) {
                    var successfn = function (oResponse, isError) {
                        if (isError) {
                            MessageToast.show("Unable to update Opportunity team members to Melody");
                        }
                    };
                    VATTeam.fnGetOpportunityOwner(oData.ActivityId, "", oData, successfn);
                }
                this.RapidRegDialog.close();

            } catch (error) {
                sMessage = (ActivityData.ActivityId) ? `Error in Updating Activity ID: ${ActivityData.ActivityId
                    }` : "Error in Registering Activity";
                MessageBox.error(sMessage);
                console.log("ERROR : ", error);
            }
        },

        // Function integrate formlayout layout service
        fnGetLayoutVisibility: async function (childFormLayoutID) {

            let aLayoutFields = {};
            let aFilter = [new Filter("FormLayoutID", "EQ", childFormLayoutID)];
            let oData = await ActivityService.fnGetLayoutData(aFilter);
            if (oData && oData.length) {
                aLayoutFields = JSON.parse(oData[0].FormLayoutString).Fields;
            }
            this.RapidRegUIModel.setProperty("/SelectedLayout", aLayoutFields);
        },

        // Function to display Activity Information in popover
        fnShowActivityInfo: function (oEvent) {
            let oSource = oEvent.getSource();
            if (!this.ActivityInfoPopover) {
                Fragment.load({
                    id: this.RapidRegDialog.getId() + "_ActivityInfoPopover",
                    name: "com.melody.lib.fragments.RapidRegistration.ActivityInfo",
                    controller: this
                }).then(function (oPopover) {
                    oPopover.setModel(this.RapidRegUIModel, "RapidRegUIModel");
                    oPopover.setModel(this.RapidRegDataModel, "RapidRegDataModel");
                    this.RapidRegDialog.getParent().addDependent(oPopover);
                    this.ActivityInfoPopover = oPopover;
                    this.ActivityInfoPopover.openBy(oSource);
                    return oPopover;
                }.bind(this));
            } else {
                this.ActivityInfoPopover.setModel(this.RapidRegDataModel, "RapidRegDataModel");
                this.ActivityInfoPopover.openBy(oSource);
            }
        },

        // Function to display Association desc in Info Popover
        fnReturnAssociationDesc: function (ActvtAsstdID) {
            let str = "";
            switch (ActvtAsstdID) {
                case "501": str = "Account";
                    break;
                case "502": str = "Opportunity";
                    break;
                case "503": str = "No Association";
                    break;
            }
            return str;
        },

        // update to rapid registration 217
        getStatusMaster: async function () {
            const statusMaster = await ActivityService.getActStatusMaster();
            this.RapidRegUIModel.setProperty("/RapidRegActStatus", statusMaster);
        },

        getLevel2MasterData: async function () {
            let aResults = await ActivityService.getLevel2MasterData();
            if (aResults?.length) {
                aResults.sort(function (a, b) {
                    return a.L2Desc.localeCompare(b.L2Desc);
                });
            }
            this.oSolutionsModel.setProperty("/Level2Data", aResults);
            this.oSolutionsModel.setProperty("/Level2Key", aResults.length ? aResults[0].L2Id : "");
            this.oSolutionsModel.setProperty("/TempLevel2Key", aResults.length ? aResults[0].L2Id : "");
            const aMaterialData = this.oSolutionsModel.getProperty("/SolutionHierarchy");
            if (aMaterialData) {
                var sSelectedLevel = this.oSolutionsModel.getProperty("/Level2Key");
                this._convertToTree(this, aMaterialData, sSelectedLevel, false);
            }
        },

        getOppMaterials: async function (OppoId, ActivityData) {
            let oOppoData = await OpportunityUtil.getOpportunitiesTeam(OppoId);
            if (oOppoData) {
                this.fnFormOpportunityMaterials(oOppoData.data);
                var activityId = ActivityData.ActivityId
                if(activityId === ""){
                    this.fnSetDefaultOppoSoutions(ActivityData);
                }
               
            }
        },

        getSolutionHierarchy: async function () {
            const aResults = await ActivityService.getSolutionHierarchy();
            var oMaterialMap = {};
            var aMaterialData = aResults.map(function (obj, index) {
                obj.isSelected = false;
                oMaterialMap[obj["MatId"]] = index;
                return obj;
            });
            this.oSolutionsModel.setProperty("/SolutionHierarchy", aMaterialData);
            this.oSolutionsModel.setProperty("/MaterialMap", oMaterialMap);
            var sSelectedLevel = this.oSolutionsModel.getProperty("/Level2Key");
            this._convertToTree(this, aMaterialData, sSelectedLevel, false);
            // this.fnSetSelectedSolutions();
        },

        getLandscapes: async function () {
            const aResults = await ActivityService.getLandscapes();
            this.RapidRegUIModel.setProperty("/landscape", aResults);
            if (this.oLandscapeDialog) {
                this.oLandscapeDialog = undefined;
            }
        },

        getRiskButtons: async function () {
            const aResults = await ActivityService.getRiskButtons();
            this.RapidRegUIModel.setProperty("/RiskButtons", aResults);
        },

        getConstants: async function () {
            const aResults = await ActivityService.getConstants();
            const oConstantsMap = aResults ? new Map(aResults.map(item => [item.const_id, item])) : new Map();
            this.RapidRegUIModel.setProperty("/oConstantsMap", oConstantsMap);
        },

        // function to get restrict date and Days restriction
        getActivityDays: async function () {
            const aResults = await ActivityService.getUserActivityDays();
            this.RapidRegUIModel.setProperty("/activityDaysData", aResults);
            this.fnHandleDaysDateRestriction(aResults);
        },

        // function to set the Days & Date Restriction
        fnHandleDaysDateRestriction: function (aDateInfo) {
            let that = this;
            aDateInfo.forEach((dateObject) => {
                var sActType = dateObject.ActivityType;
                var sActivityTypeId = that.RapidRegUIModel.getProperty("/ActivityTypeId");
                if (sActivityTypeId === sActType) {
                    that.RapidRegUIModel.setProperty("/DaysRestriction", dateObject.DaysRestriction);
                    that.RapidRegUIModel.setProperty("/DateRestriction", dateObject.DateRestriction);
                }
            });
        },

        _convertToTree: function (oController, aMaterialData, sSelectedLevel, isOpp) {

            var L4Map = {},
                L5Map = {},
                L3Map = {};
            var aLevelsTree = [];
            for (var i = 0; i < aMaterialData.length; i++) {
                var level2Index = aLevelsTree.findIndex(function (item) {
                    return item.LevelId === aMaterialData[i]["L2Id"];
                });
                if (aMaterialData[i]["L2Id"]) {
                    if (level2Index === -1) {
                        aLevelsTree.push({
                            LevelId: aMaterialData[i]["L2Id"],
                            LevelDesc: aMaterialData[i]["L2Desc"],
                            L2Id: aMaterialData[i]["L2Id"],
                            L2Desc: aMaterialData[i]["L2Desc"],
                            L3Id: aMaterialData[i]["L3Id"],
                            L3Desc: aMaterialData[i]["L3Desc"],
                            L4Id: aMaterialData[i]["L4Id"],
                            L4Desc: aMaterialData[i]["L4Desc"],
                            L5Id: aMaterialData[i]["L5Id"],
                            L5Desc: aMaterialData[i]["L5Desc"],
                            MatId: aMaterialData[i]["MatId"],
                            LevelCount: 2,
                            isVisible: false,
                            isSelected: false,
                            Levels: []
                        });
                        level2Index = aLevelsTree.length - 1;
                    }
                    var aLevel3 = aLevelsTree[level2Index].Levels;
                }
                if (aLevel3) {
                    var level3Index = aLevel3.findIndex(function (item) {
                        return item.LevelId === aMaterialData[i]["L3Id"];
                    });
                }
                if (aMaterialData[i]["L3Id"]) {
                    if (level3Index === -1) {
                        aLevel3.push({
                            LevelId: aMaterialData[i]["L3Id"],
                            LevelDesc: aMaterialData[i]["L3Desc"],
                            L2Id: aMaterialData[i]["L2Id"],
                            L2Desc: aMaterialData[i]["L2Desc"],
                            L3Id: aMaterialData[i]["L3Id"],
                            L3Desc: aMaterialData[i]["L3Desc"],
                            L4Id: aMaterialData[i]["L4Id"],
                            L4Desc: aMaterialData[i]["L4Desc"],
                            L5Id: aMaterialData[i]["L5Id"],
                            L5Desc: aMaterialData[i]["L5Desc"],
                            MatId: aMaterialData[i]["MatId"],
                            LevelCount: 3,
                            isVisible: true,
                            isSelected: false,
                            Levels: []
                        });
                        level3Index = aLevel3.length - 1;
                        // new code for L3 selection starts
                        var l3Id = aMaterialData[i].L3Id;

                        if (!L3Map[l3Id]) {
                            L3Map[l3Id] = {
                                l3: {
                                    LevelId: l3Id,
                                    LevelDesc: aMaterialData[i].L3Desc,
                                    L2Id: aMaterialData[i].L2Id,
                                    L2Desc: aMaterialData[i].L2Desc,
                                    L3Id: l3Id,
                                    L3Desc: aMaterialData[i].L3Desc,
                                    LevelCount: 3,
                                    isVisible: true,
                                    isSelected: false,
                                    Levels: []
                                },
                                l4s: []
                            };
                        }

                        //end

                    }
                    var aLevel4 = aLevel3[level3Index].Levels;
                }
                if (aLevel4) {
                    var level4Index = aLevel4.findIndex(function (item) {
                        return item.LevelId === aMaterialData[i]["L4Id"];
                    });
                }
                if (aMaterialData[i]["L4Id"]) {
                    if (level4Index === -1) {
                        aLevel4.push({
                            LevelId: aMaterialData[i]["L4Id"],
                            LevelDesc: aMaterialData[i]["L4Desc"],
                            L2Id: aMaterialData[i]["L2Id"],
                            L2Desc: aMaterialData[i]["L2Desc"],
                            L3Id: aMaterialData[i]["L3Id"],
                            L3Desc: aMaterialData[i]["L3Desc"],
                            L4Id: aMaterialData[i]["L4Id"],
                            L4Desc: aMaterialData[i]["L4Desc"],
                            L5Id: aMaterialData[i]["L5Id"],
                            L5Desc: aMaterialData[i]["L5Desc"],
                            MatId: aMaterialData[i]["MatId"],
                            LevelCount: 4,
                            isVisible: true,
                            isSelected: false,
                            isOpportunity: false,
                            ValueState: "None",
                            Levels: []

                        });
                        level4Index = aLevel4.length - 1;
                        var l3Id = aMaterialData[i]["L3Id"];
                        L3Map[l3Id].l4s.push({
                            LevelId: aMaterialData[i]["L4Id"],
                            LevelDesc: aMaterialData[i]["L4Desc"],
                            L2Id: aMaterialData[i]["L2Id"],
                            L2Desc: aMaterialData[i]["L2Desc"],
                            L3Id: aMaterialData[i]["L3Id"],
                            L3Desc: aMaterialData[i]["L3Desc"],
                            L4Id: aMaterialData[i]["L4Id"],
                            L4Desc: aMaterialData[i]["L4Desc"],
                            L5Id: aMaterialData[i]["L5Id"],
                            L5Desc: aMaterialData[i]["L5Desc"],
                            MatId: aMaterialData[i]["MatId"],
                            LevelCount: 4,
                            isVisible: true,
                            isSelected: false,
                            isOpportunity: false,
                            ValueState: "None",
                            Levels: []
                        });
                    }
                    var aLevel5 = aLevel4[level4Index].Levels;
                }
                if (aLevel5) {
                    var level5Index = aLevel5.findIndex(function (item) {
                        return item.LevelId === aMaterialData[i]["L5Id"];
                    });
                }
                if (aMaterialData[i]["L5Id"]) {
                    if (level5Index === -1) {
                        var obj = {
                            LevelId: aMaterialData[i]["L5Id"],
                            LevelDesc: aMaterialData[i]["L5Desc"],
                            L2Id: aMaterialData[i]["L2Id"],
                            L2Desc: aMaterialData[i]["L2Desc"],
                            L3Id: aMaterialData[i]["L3Id"],
                            L3Desc: aMaterialData[i]["L3Desc"],
                            L4Id: aMaterialData[i]["L4Id"],
                            L4Desc: aMaterialData[i]["L4Desc"],
                            L5Id: aMaterialData[i]["L5Id"],
                            L5Desc: aMaterialData[i]["L5Desc"],
                            MatId: aMaterialData[i]["MatId"],
                            LevelCount: 5,
                            isVisible: true,
                            isSelected: false,
                            isOpportunity: false,
                            ValueState: "None",
                            Levels: [],
                            RadioBtnGrpName: aMaterialData[i]["L5Id"]
                        };
                        aLevel5.push(obj);
                        level5Index = aLevel5.length - 1;
                        L5Map[aMaterialData[i]["L5Id"]] = aLevel4[level4Index];
                        L4Map[aMaterialData[i]["L4Id"]] = aLevel5;
                    }
                }
            }
            oController.oSolutionsModel.setProperty("/LevelsHierarchy", aLevelsTree);
            oController.L2Map = {};
            aLevelsTree.filter(function (l2) {
                oController.L2Map[l2.L2Id] = l2;
            });
            if (isOpp) {
                oController.oSolutionsModel.setProperty("/OppLevelsHierarchy", aLevelsTree);
            } else {
                // var oLevelData = this.fnJoinAllLevelsData(aLevelsTree);
                oController.oSolutionsModel.setProperty("/SelectedLevelHierarchy", aLevelsTree);
            }
            oController.oSolutionsModel.setProperty("/L4Map", L4Map);
            oController.oSolutionsModel.setProperty("/L5Map", L5Map);
            oController.oSolutionsModel.setProperty("/L3Map", L3Map);

        },

        setSolHierarchyDataInEdit: function (ActivityData, aMaterials, aTaxonomy) {
            var aMatTempArr = [];
            var SelLvlHierarchy = this.oSolutionsModel.getProperty("/SelectedLevelHierarchy") || [];
            var tempMatHierarchyContext = {};
            for (var i = 0; i < aTaxonomy.length; i++) {
                if (!aTaxonomy[i].isParent) {
                    var oProperty = "L" + aTaxonomy[i].LevelCount + "Id";
                    var oDesc = aTaxonomy[i][oProperty];
                    tempMatHierarchyContext[oDesc] = this.fnBuildHierarchyPath(aTaxonomy[i]);
                }
            }

            var contextMap = tempMatHierarchyContext || {};
            aMaterials.filter(function (item) {
                if (item.Active === "X") {
                    item.LevelId = item.MatId;
                    //    item.LevelDesc = item.MatDesc;
                    var hierarchyText = "";
                    Object.keys(contextMap).some(function (key) {
                        if (item.L3Id === key || item.L4Id === key || item.L5Id === key) {
                            hierarchyText = contextMap[key];
                            return true;
                        }
                    });
                    item.LevelDesc = "Material Name" + " - " + hierarchyText + " > " + item.MatDesc;
                    aMatTempArr.push(item);
                }
            });
            this.oSolutionsModel.setProperty("/to_AMaterial", aMatTempArr);
            var aLevelTempArr = [];
            if (aTaxonomy.length) {
                this.oSolutionsModel.setProperty("/Level2Key", aTaxonomy[0].L2Id);
                aTaxonomy.filter(function (item) {
                    if (item.Active === "X") {
                        var sLevelId = 'L' + item.LevelCount + 'Id';
                        var sLevelDesc = 'L' + item.LevelCount + 'Desc';
                        item.LevelId = item[sLevelId];
                        item.LevelDesc = item[sLevelDesc];
                        aLevelTempArr.push(item);
                    }
                });
            }
            this._updateSolutionHierarchy(aTaxonomy, SelLvlHierarchy)
            this.oSolutionsModel.setProperty("/to_ATaxonomy", aLevelTempArr);
            var oPayload = this.fnGetSolMatPayload(aLevelTempArr, aMatTempArr);
            ActivityData["to_ATaxonomy"] = oPayload[0];
            ActivityData["to_AMaterial"] = oPayload[1];
            var oSolutionsModel = this.oSolutionsModel;
            var to_ATaxonomy = oSolutionsModel.getProperty("/to_ATaxonomy");
            var L4Map = oSolutionsModel.getProperty("/L4Map");
            to_ATaxonomy = this.fnGetL4sChildobject(to_ATaxonomy, L4Map);
            to_ATaxonomy = this.fnGetL5sParentobject(to_ATaxonomy);
            to_ATaxonomy = this.fnGetL4sParentobject_L3(to_ATaxonomy);
            //to_ATaxonomy = this.fnGetL3sChildobject(to_ATaxonomy, this.oSolutionsModel.getProperty("/L3Map"));

            oSolutionsModel.setProperty("/to_ATaxonomy", to_ATaxonomy);
            var to_AMaterial = oSolutionsModel.getProperty("/to_AMaterial");
            var SolTokens = to_ATaxonomy.concat(to_AMaterial);
            var displayTokens = this.fnGetDisplayTokens(SolTokens);
            oSolutionsModel.setProperty("/DisplayTokens", displayTokens);
            oSolutionsModel.setProperty("/SolTokens", displayTokens);
            oSolutionsModel.setProperty("/oSolTempArr", $.extend(true, [], to_ATaxonomy));
            oSolutionsModel.setProperty("/oMatTempArr", $.extend(true, [], to_AMaterial));
            var OpportunityMaterials = oSolutionsModel.getProperty("/OpportunityMaterials");
            if (OpportunityMaterials) {
                this.fnFormOpportunityMaterials(OpportunityMaterials);
                this.fnFormOppoSolTempArr(to_ATaxonomy, OpportunityMaterials);
            }
            this.oSolutionsModel.refresh();
        },

        fnJoinAllLevelsData: function (aLevelsTree) {
            var oLevelData = [];
            var oKeys = Object.keys(aLevelsTree);
            for (var i = 0; i < oKeys.length; i++) {
                var cLevels = aLevelsTree[oKeys[i]].Levels;
                oLevelData = oLevelData.concat(cLevels);
            }
            return oLevelData;
        },

        // Function to update L4's child array to its parent object
        fnGetL4sChildobject: function (to_ATaxonomy, L4Map) {
            for (var i = 0; i < to_ATaxonomy.length; i++) {
                var levelId = to_ATaxonomy[i].L4Id;
                to_ATaxonomy[i].Levels = L4Map[levelId] ? L4Map[levelId] : [];
            }
            return to_ATaxonomy;
        },

        // Function to find L5's parent object for the checkbox to be selected in EDIT mode
        fnGetL5sParentobject: function (to_ATaxonomy) {
            var that = this;
            var L5Map = this.oSolutionsModel.getProperty("/L5Map");
            for (var i = 0; i < to_ATaxonomy.length; i++) {
                var tmpObj = to_ATaxonomy[i];
                var levelCount = tmpObj.LevelCount;
                if (levelCount === 5) {
                    var L4Obj = L5Map[tmpObj["L5Id"]];
                    var bVal = that.fnFindObjInArray(L4Obj, to_ATaxonomy);
                    if (!bVal) {
                        L4Obj.isParent = true;
                        L4Obj.ValueState = "Information";
                        to_ATaxonomy.push(L4Obj);
                    }
                }
            }
            return to_ATaxonomy;
        },

        fnGetL4sParentobject_L3: function (to_ATaxonomy) {
            var L4Map = this.oSolutionsModel.getProperty("/L4Map");
            var L3Map = this.oSolutionsModel.getProperty("/L3Map");

            for (var i = 0; i < to_ATaxonomy.length; i++) {
                var tmpObj = to_ATaxonomy[i];

                if (tmpObj.LevelCount === 4) {
                    // get parent L3 using L4Id
                    var l3Obj = L3Map[tmpObj.L3Id]?.l3;
                    if (!l3Obj) {
                        continue;
                    }

                    var exists = this.fnFindObjInArray(l3Obj, to_ATaxonomy);
                    if (!exists) {
                        l3Obj.isParent = true;
                        l3Obj.ValueState = "Information";
                        to_ATaxonomy.push(l3Obj);
                    }
                }
            }
            return to_ATaxonomy;
        },

        fnGetL3sChildobject: function (to_ATaxonomy, L3Map) {
            for (var i = 0; i < to_ATaxonomy.length; i++) {
                var obj = to_ATaxonomy[i];

                if (obj.LevelCount === 3) {
                    var l3Id = obj.L3Id;
                    obj.Levels = L3Map[l3Id]?.l4s || [];
                }
            }
            return to_ATaxonomy;
        },



        // Function to get display tokens
        fnGetDisplayTokens: function (oSolTempArr) {
            var oTempArr = [];
            oSolTempArr.filter(function (tempObj) {
                if (!tempObj.isParent) {
                    var oTokenObj = $.extend(true, {}, tempObj);
                    if (oTokenObj.LevelCount === 3) {
                        oTokenObj.LevelDesc = oTokenObj.L2Desc + " > " + oTokenObj.LevelDesc;
                    } else if (oTokenObj.LevelCount === 4) {
                        oTokenObj.LevelDesc = oTokenObj.L2Desc + " > " + oTokenObj.L3Desc + " " + " > " + oTokenObj.LevelDesc
                    } else if (oTokenObj.LevelCount === 5) {
                        oTokenObj.LevelDesc = oTokenObj.L2Desc + " > " + oTokenObj.L3Desc + " > " + oTokenObj.L4Desc + " > " + oTokenObj.LevelDesc
                    }
                    oTempArr.push(oTokenObj);
                }
            });
            return oTempArr;
        },

        // Function to form opportunity's material data for Solution Hierarchy
        // Needs to be reviewed
        fnFormOpportunityMaterials: function (oResponse) {
            var oTempArr = [];
            var oSolutionsModel = this.oSolutionsModel;
            var aOppoMaterials = oResponse.Items.results;
            var MaterialMap = oSolutionsModel.getProperty("/MaterialMap");
            if (MaterialMap) {
                aOppoMaterials.filter(function (oMatObj) {
                    if (MaterialMap[oMatObj.PRODUCT_ID] >= 0) {
                        var sIndex = MaterialMap[oMatObj.PRODUCT_ID];
                        var oTempObj = oSolutionsModel.getProperty("/SolutionHierarchy/" + sIndex);
                        oSolutionsModel.setProperty("/SolutionHierarchy/" + sIndex + "/isOpportunity", true);
                        oTempArr.push(oTempObj);
                    }
                });
                if (oTempArr.length === 0) {
                    oTempArr = ["E"];
                }
                oSolutionsModel.setProperty("/OppoMaterials", oTempArr);
            } else {
                var that = this;
                if (that.materialReadCount === undefined) {
                    that.materialReadCount = 0;
                }
                if (oResponse) {
                    that.oppoMaterials = oResponse;
                }
                setTimeout(function () {
                    that.materialReadCount += 1;
                    that.fnFormOpportunityMaterials(that.oppoMaterials);
                }, 1000);
            }
        },

        // Function to form OppSolTempArr objects during Edit case
        fnFormOppoSolTempArr: function (to_ATaxonomy) {
            var OppSolTempArr = [];
            var oSolutionsModel = this.oSolutionsModel;
            var OppoMaterials = oSolutionsModel.getProperty("/OppoMaterials") || [];
            OppoMaterials.filter(function (OppMaterial) {
                to_ATaxonomy.find(function (obj, index) {
                    var levelId = "L" + obj.LevelCount + "Id";
                    if (obj[levelId] === OppMaterial[levelId]) {
                        OppSolTempArr.push(obj);
                    }
                });
            });
            oSolutionsModel.setProperty("/OppSolArr", OppSolTempArr);
            oSolutionsModel.setProperty("/OppSolTempArr", OppSolTempArr);
        },

        // Additional opportunity changes
        openAdditionalOpptDialog: function () {
            var that = this;
            var oppoList = this.opportunityModel ? this.opportunityModel.getProperty("/opportunity") : [];
            if (this.additionalOppDialog) {
                this.additionalOppDialog.destroy();
                this.additionalOppDialog = null;
            }
            if (!this.additionalOppDialog) {
                this.opportunityModel.setProperty("/isOpptDilogBusy", true);
                this.additionalOppDialog = sap.ui.xmlfragment(this.RapidRegDialog.getId() + "_AddOppDialog", "com.melody.lib.fragments.RapidRegistration.RapidRegAdditionalOpportunities", this);
                this.RapidRegDialog.getParent().addDependent(this.additionalOppDialog);
                this.additionalOppDialog.setModel(this.i18nModel, "i18n");
                this.additionalOppDialog.setModel(this.opportunityModel, "opportunityModel");
                this.AddOppDialogId = this.RapidRegDialog.getId() + "_AddOppDialog";
                this.fnGetAddOppoList();
                this.opportunityModel.setProperty("/isOpptDilogBusy", false);
                var oppoList = this.opportunityModel.getProperty("/opportunity");
                if (oppoList) {
                    oppoList.filter(function (obj) {
                        obj.addOppPrevSelect = false;
                        obj.addOppSelected = false;
                    });
                }
                this.opportunityModel.setProperty("/opportunity", oppoList);
            }
            // var sRegisteredActId = this.RapidRegDataModel.getProperty("/ActivityId");
            // if (sRegisteredActId) {
            var oSavedOppoList = this.RapidRegDataModel.getProperty("/to_AAddOpp");
            if (oSavedOppoList.length) {
                oSavedOppoList.filter(function (savedOppObj) {
                    var sOppoId = savedOppObj.OpportunityNo;
                    oppoList.filter(function (obj) {
                        if (obj.OpportunityId === sOppoId) {
                            obj.addOppPrevSelect = true;
                            obj.addOppSelected = true;
                        }
                    });
                });
            }
            this.opportunityModel.setProperty("/opportunity", oppoList);
            // }
            this.opportunityModel.refresh(true);
            this.additionalOppDialog.open();

            var addOppStatus = sap.ui.core.Fragment.byId(this.AddOppDialogId, "addOpptStatusSel");
            addOppStatus.setSelectedKey("");
            var OppoId = this.RapidRegDataModel.getProperty("/OpportunityNumber");

            var addOppList = sap.ui.core.Fragment.byId(this.AddOppDialogId, "rapidRegAddOpptList");
            if (OppoId) {
                addOppList.getBinding("items").filter([new Filter("OpportunityId", "NE", OppoId)]);
            }
        },

        // Function to get additional opportunities
        fnGetAddOppoList: async function () {
            var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
            var oppoList = [];
            if (!oStorage.get("pcLibOpportunties")) {
                await OpportunityUtil.getOpportunities();
            }
            oppoList = oStorage.get("pcLibOpportunties");
            oppoList = $.extend(true, [], oppoList);
            this.opportunityModel.setProperty("/opportunity", oppoList);
        },

        handleAdditionalOpptSelect: function (oEvent) {
            var that = this;
            var oSource = oEvent.getSource();
            var oppoModel = oSource.getModel("opportunityModel");
            var sPath = oSource.getBindingContext("opportunityModel").getPath();
            if (!oppoModel.getProperty(sPath + "/addOppSelected")) {
                oppoModel.setProperty(sPath + "/addOppSelected", true);
                oSource.setText("Deselect");
            } else {
                oppoModel.setProperty(sPath + "/addOppSelected", false);
                oSource.setText("Select");
            } oppoModel.refresh();
        },

        handleAdditionalOpptConfirm: function (oEvent) {
            this.fnUpdateAddOppFields();
            this.additionalOppDialog.close();
        },

        // function to update add opportunities fields properties on select and deselect
        fnUpdateAddOppFields: function () {
            var oTempArr = [];
            var aOppoList = this.opportunityModel.getProperty("/opportunity");
            aOppoList.filter(function (obj) {
                if (obj.addOppSelected) {
                    obj.addOppPrevSelect = true;
                    var opptObj = {};
                    opptObj.OpportunityNo = obj.OpportunityId;
                    opptObj.AccountID = obj.AccountId;
                    oTempArr.push(opptObj);
                } else {
                    obj.addOppPrevSelect = false;
                }
            });
            this.RapidRegDataModel.setProperty("/to_AAddOpp", oTempArr);
            this.opportunityModel.refresh();
        },

        handleAddOppDialogCancel: function (oEvent) {
            this.additionalOppDialog.close();
        },

        // Function triggered when deleted tokens from suggestion list
        updateAddOppTokens: function (oEvent) {
            var aRemovedToken = oEvent.getParameter("removedTokens");
            if (aRemovedToken && aRemovedToken.length) {
                var sKey = oEvent.getParameter("removedTokens")[0].getKey();
                // var oppoModel = this.parentView.getModel("opportunityModel");
                var aOppoList = this.opportunityModel.getProperty("/opportunity");
                var aSelectedAddOpp = this.RapidRegDataModel.getProperty("/to_AAddOpp");
                if (aOppoList) {
                    aOppoList.filter(function (obj) {
                        if (sKey === obj.OpportunityId) {
                            obj.addOppSelected = false;
                            obj.addOppPrevSelect = false;
                        }
                    });
                    this.opportunityModel.setProperty("/opportunity", aOppoList);
                }
                var index = aSelectedAddOpp.findIndex(function (item) {
                    return item.OpportunityNo === sKey;
                });
                aSelectedAddOpp.splice(index, 1);
                this.RapidRegDataModel.setProperty("/to_AAddOpp", aSelectedAddOpp);
                this.opportunityModel.refresh(true);
            }
        },

        handleAddOppStatusSelect: function (oEvent) {
            var aFilters = [];
            var sOppId = this.RapidRegDataModel.getProperty("/OpportunityNumber");
            var sSelectedStatus = oEvent.getParameter("selectedItem").getKey();

            var addOppList = sap.ui.core.Fragment.byId(this.AddOppDialogId, "rapidRegAddOpptList");
            var oListItem = addOppList.getBinding("items");
            if (sSelectedStatus === "0") {
                aFilters.push(new Filter("active", "EQ", sSelectedStatus));
            }
            if (sOppId) {
                aFilters.push(new Filter("OpportunityId", "NE", sOppId));
            }
            oListItem.filter(aFilters);

            var addOppSearch = sap.ui.core.Fragment.byId(this.AddOppDialogId, "OpptSearchMulti");
            addOppSearch.setValue("");
            this.fnUpdateAddOppFields();
        },

        onOpptSearch: function (oEvent) {
            let aOpportunityId = [];
            var sOppId = this.RapidRegDataModel.getProperty("/OpportunityNumber");

            var addOppStatus = sap.ui.core.Fragment.byId(this.AddOppDialogId, "addOpptStatusSel");
            let sStatus = addOppStatus.getSelectedKey();
            let sValue = oEvent.getParameter("query");
            let aFilters = new Filter({
                filters: [
                    new Filter("ACCOUNT_NAME", "Contains", sValue),
                    new Filter("OPPT_ID", "Contains", sValue),
                    new Filter("DESCRIPTION", "Contains", sValue),
                    new Filter("ACCOUNT", "Contains", sValue)
                ],
                and: false
            });

            if (sOppId) {
                let oSearchFilter1 = aFilters;
                let oppFilter = new Filter("OPPT_ID", "NE", sOppId);
                aFilters = new Filter({
                    filters: [
                        oSearchFilter1, oppFilter
                    ],
                    and: true
                });
            }
            if (sStatus) {
                let oSearchFilter = aFilters;
                let oStatusFilter = new Filter("active", "EQ", sStatus);
                aFilters = new Filter({
                    filters: [
                        oSearchFilter, oStatusFilter
                    ],
                    and: true
                });
            }

            var oList = sap.ui.core.Fragment.byId(this.AddOppDialogId, "rapidRegAddOpptList");
            let oBinding = oList.getBinding("items");
            oBinding.filter([aFilters]);
        },

        // Solution hierarchy changes
        // Function to open Solution Hierarchy popup
        openSolutionHierarchy: function (oEvent) {
            var oSolViewType = oEvent.getSource().getCustomData()[0].getKey();
            if (this.solHierarchyDlg) {
                this.solHierarchyDlg.destroy();
                this.solHierarchyDlg = undefined;
            }
            if (!this.solHierarchyDlg) {
                this.solHierarchyDlg = sap.ui.xmlfragment(this.RapidRegDialog.getId() + "_SolutionHierarchyDialog", "com.melody.lib.fragments.RapidRegistration.SolutionHierarchy", this);
                this.RapidRegDialog.getParent().addDependent(this.solHierarchyDlg);
                this.solHierarchyDlg.setModel(this.i18nModel, "i18n");
                this.solHierarchyDlg.setModel(this.oSolutionsModel, "oSolutionsModel");
                this.SolHierarchyDialogId = this.RapidRegDialog.getId() + "_SolutionHierarchyDialog";
            }
            var solTree = sap.ui.core.Fragment.byId(this.SolHierarchyDialogId, "idSolutionTree");
            solTree.collapseAll();
            this.fnFireSolHierarchyCbs();

            var to_ATaxonomy = $.extend(true, [], this.oSolutionsModel.getProperty("/to_ATaxonomy"));
            var to_AMaterial = $.extend(true, [], this.oSolutionsModel.getProperty("/to_AMaterial"));
            this.oSolutionsModel.setProperty("/oSolTempArr", to_ATaxonomy);
            this.oSolutionsModel.setProperty("/oMatTempArr", to_AMaterial);
            this.fnSetSolutionViewMode(oSolViewType);
            this.solHierarchyDlg.open();
        },

        setDefaultDataToModel: function () {
            var oSolutionsModel = this.oSolutionsModel;
            const RapidRegUIModel = this.RapidRegUIModel;
            var RapidRegDataModel = this.RapidRegDataModel;
            const oUserModel = this.oUserModel;
            this.landscapeMap = {};
            this.selectedTeamMap = {};
            this.oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);

            RapidRegDataModel.setProperty("/to_ALand", []);
            RapidRegDataModel.setProperty("/to_AInitiative", []);
            RapidRegDataModel.setProperty("/to_AAddOpp", []);
            RapidRegDataModel.setProperty("/to_ATeam", []);
            RapidRegDataModel.setProperty("/to_AFiles", []);
            RapidRegDataModel.setProperty("/to_ASol", []);
            RapidRegDataModel.setProperty("/to_AMaterial", []);
            RapidRegDataModel.setProperty("/to_ATaxonomy", []);
            RapidRegDataModel.setProperty("/Status", "01");
            RapidRegDataModel.setProperty("/DryRunDate", null);
            RapidRegUIModel.setProperty("/OldSolutionWarningMsg", "");
            RapidRegUIModel.setProperty("/oldSolutionWarningIcon", false);

            oSolutionsModel.setProperty("/to_ASol", []);
            oSolutionsModel.setProperty("/to_AMaterial", []);
            oSolutionsModel.setProperty("/to_ATaxonomy", []);
            oSolutionsModel.setProperty("/SolTokens", []);
            oSolutionsModel.setProperty("/DisplayTokens", []);
            oSolutionsModel.setProperty("/oSolTempArr", []);
            oSolutionsModel.setProperty("/oMatTempArr", []);

            oUserModel.setProperty("/SelectedTeam", []);
            oUserModel.setProperty("/PresaleActLeadUsers", []);

            oSolutionsModel.refresh();
            RapidRegDataModel.refresh();
        },

        getControlById: function (fragment, controlId) {
            if (fragment && controlId) {
                return sap.ui.core.Fragment.byId(this.RapidRegDialog.getId() + fragment, controlId);
            }
        },

        // Function to set solutions checkbox true on expand on tree items
        fnFireSolHierarchyCbs: function () {
            var that = this;
            var oSolutionTree = sap.ui.core.Fragment.byId(this.SolHierarchyDialogId, "idSolutionTree");
            oSolutionTree.getItems().filter(function (l3Obj) {
                l3Obj.getContent().filter(function (obj) {
                    var oChkBox = obj.getItems()[1];
                    var sPath = oChkBox.getBindingContext("oSolutionsModel").getPath();
                    var oSelectedObj = that.oSolutionsModel.getProperty(sPath);
                    if (oSelectedObj.isSelected && (oSelectedObj.LevelCount === 4 || oSelectedObj.LevelCount === 5 || oSelectedObj.LevelCount === 3)) {
                        oChkBox.setSelected(true);
                    }

                })
            });
        },

        // Function to initialize view settings of Solutions hierarchy popup
        fnSetSolutionViewMode: function (oSolViewType) {
            var isMatTblVisible = false;
            var isOppoTabVisible = false;
            var isDisplayMatSelected = false;
            var MatTblSelectMode = "SingleSelectLeft";
            if (oSolViewType === "SOL_MULTI_SELECT") {
                isMatTblVisible = false;
                MatTblSelectMode = "MultiSelect";
            }
            var oAssociationType = this.RapidRegDataModel.getProperty("/ActvtAsstdID");
            if (oAssociationType === "501" || oAssociationType === "503") {
                isOppoTabVisible = false;
            } else {
                isOppoTabVisible = true;
            }
            this.oSolutionsModel.setProperty("/isSolTabVisible", true);
            this.oSolutionsModel.setProperty("/isLevel2DrpDwnVisible", true);
            this.oSolutionsModel.setProperty("/isMatTblVisible", isMatTblVisible);
            this.oSolutionsModel.setProperty("/MatTblSelectMode", MatTblSelectMode);
            this.oSolutionsModel.setProperty("/isOppoTabVisible", isOppoTabVisible);
            this.oSolutionsModel.setProperty("/ITBSelectedKey", "SOLUTION_HIERARCHY");
            this.oSolutionsModel.setProperty("/isDisplayMatSelected", isDisplayMatSelected);

            this.fnShowMaterialInfoTbl("", isMatTblVisible);
            //this.fnHandleLevel2Change();
            this.fnSetSelectedSolMatData();
            this.oSolutionsModel.refresh(true);
        },

        fnShowMaterialInfoTbl: function (oEvent, bVal) {
            var solHierarchyGrid = sap.ui.core.Fragment.byId(this.SolHierarchyDialogId, "solHierarchyGrid");
            var levelDropDwnGrid = sap.ui.core.Fragment.byId(this.SolHierarchyDialogId, "levelDropDwnGrid");
            if (oEvent !== "") {
                bVal = oEvent.getSource().getSelected();
            }
            if (bVal) {
                this.solHierarchyDlg.setContentWidth("70%");
                solHierarchyGrid.setDefaultSpan("XL6 L6 M6 S12");
                if (this.oSolutionsModel.getProperty("/ITBSelectedKey") === "SOLUTION_HIERARCHY") {
                    levelDropDwnGrid.setDefaultSpan("XL6 L4 M12 S12");
                }
            } else {
                this.solHierarchyDlg.setContentWidth("43%");
                solHierarchyGrid.setDefaultSpan("XL12 L12 M12 S12");
                if (this.oSolutionsModel.getProperty("/ITBSelectedKey") === "SOLUTION_HIERARCHY") {
                    levelDropDwnGrid.setDefaultSpan("XL6 L6 M12 S12");
                }
            }
            this.oSolutionsModel.setProperty("/isMatTblVisible", bVal);
            this.fnSetSelectedSolMatData();
            this.oSolutionsModel.refresh();
        },

        // Function to close Solution hierarchy popup
        
        closeSolutionHierarchy: function (oEvent) {

            //  RESTORE SAVED STATE ONLY
            var to_ATaxonomy = this.oSolutionsModel.getProperty("/to_ATaxonomy") || [];
            var to_AMaterial = this.oSolutionsModel.getProperty("/to_AMaterial") || [];

            // Combine saved solutions + materials
            var SolTokens = to_ATaxonomy.concat(to_AMaterial);

            // Display only real tokens
            SolTokens = this.fnGetDisplayTokens(SolTokens);

            //  RESET tokens to SAVED state
            this.oSolutionsModel.setProperty("/SolTokens", SolTokens);
            this.oSolutionsModel.setProperty("/DisplayTokens", SolTokens);

            // RESET temp arrays back to saved state
            this.oSolutionsModel.setProperty("/oSolTempArr", to_ATaxonomy);
            this.oSolutionsModel.setProperty("/oMatTempArr", to_AMaterial);
            this.oSolutionsModel.setProperty("/OppSolTempArr",
                this.oSolutionsModel.getProperty("/OppSolArr")
            );

            //  DO NOT update RapidReg model on Cancel
            //  DO NOT generate payload
            //  DO NOT merge DisplayTokens

            if (oEvent) {
                this.solHierarchyDlg.close();
            }
        },


        // Function to update the selected tokens on click of OK
        fnSetSelectedSolutions: function () {
            var oSolTempArr = this.oSolutionsModel.getProperty("/oSolTempArr") || [];
            var oMatTempArr = this.oSolutionsModel.getProperty("/oMatTempArr") || [];
            var SolTokens = this.oSolutionsModel.getProperty("/DisplayTokens") || [];
            var MatTblSelectMode = this.oSolutionsModel.getProperty("/MatTblSelectMode");
            if (MatTblSelectMode === "MultiSelect") {
                this.oSolutionsModel.setProperty("/SolTokens", SolTokens);
            } else {
                var oDesc = "";
                if (oMatTempArr.length) {
                    if (oMatTempArr[0].LevelDesc) {
                        oDesc = oMatTempArr[0].LevelDesc;
                    } else {
                        oDesc = oMatTempArr[0].MatDesc;
                    }
                } else {
                    if (oSolTempArr.length) {
                        oDesc = oSolTempArr[0].LevelDesc;
                    }
                }
                this.oSolutionsModel.setProperty("/SolutionDesc", oDesc);
            }
            var oPayload = this.fnGetSolMatPayload(oSolTempArr, oMatTempArr);
            this.oSolutionsModel.setProperty("/to_ATaxonomy", oSolTempArr);
            this.oSolutionsModel.setProperty("/to_AMaterial", oMatTempArr);
            this.RapidRegDataModel.setProperty("/to_ATaxonomy", oPayload[0]);
            this.RapidRegDataModel.setProperty("/to_AMaterial", oPayload[1]);
            var OppSolArr = this.oSolutionsModel.getProperty("/OppSolTempArr");
            this.oSolutionsModel.setProperty("/OppSolArr", OppSolArr);
            if (this.solHierarchyDlg) {
                this.solHierarchyDlg.close();
            }
            // if (oSolTempArr.length > 0) {
            // this.parentView.byId("additionalSolutions").setValueState("None");
            // }
            this.oSolutionsModel.refresh();
        },

        // Function to get payload of selected Solution and Materials
        fnGetSolMatPayload: function (oSolTempArr, oMatTempArr) {
            var aSolTempArr = [];
            var aMatTempArr = [];
            var ActivityGuid = this.RapidRegDataModel.getProperty("/ActivityGuid");
            oSolTempArr.filter(function (solObj) {
                if (solObj.isParent) {
                    return;
                }
                var oSolTempObj = {};
                var length = solObj.LevelCount;
                oSolTempObj.L2Id = solObj.L2Id;
                oSolTempObj.L2Desc = solObj.L2Desc;
                oSolTempObj.L3Id = solObj.L3Id;
                oSolTempObj.L3Desc = solObj.L3Desc;
                for (var i = length; i >= 4; i--) {
                    var oId = "L" + i + "Id";
                    var oDesc = "L" + i + "Desc";
                    oSolTempObj[oId] = solObj[oId];
                    oSolTempObj[oDesc] = solObj[oDesc];
                }
                oSolTempObj.LevelCount = solObj.LevelCount;
                oSolTempObj.ActivityGuid = ActivityGuid;
                aSolTempArr.push(oSolTempObj);
            });
            oMatTempArr.filter(function (matObj) {
                var oMatTempObj = {};
                oMatTempObj.MatId = matObj.MatId;
                oMatTempObj.MatDesc = matObj.MatDesc;
                oMatTempObj.SolYear = matObj.SolYear;
                oMatTempObj.ActivityGuid = ActivityGuid;
                aMatTempArr.push(oMatTempObj);
            });
            this.dataChange = true;
            return [aSolTempArr, aMatTempArr];
        },

        fnHandleLevel2Change: function () {
            let solDialogId = this.RapidRegDialog.getId() + "_SolutionHierarchyDialog";
            var oSolTreeCntrl = sap.ui.core.Fragment.byId(solDialogId, "idSolutionTree");
            var level2Id = this.oSolutionsModel.getProperty("/Level2Key");
            var filter = [new Filter("L2Id", "EQ", level2Id)];
            oSolTreeCntrl.getBinding("items").filter(filter);
        },

        // Function to get selected objs on Checkbox/RadioBtn selection change
        fnSetCheckRadioBtnSelected: function (oEvent) {
            var oSource = oEvent.getSource();
            if (!oSource.getVisible()) {
                return;
            }
            // var oSolutionsModel = this.parentView.getModel("oSolutionsModel");
            var oSolTempArr = this.oSolutionsModel.getProperty("/oSolTempArr");
            var oMatTempArr = this.oSolutionsModel.getProperty("/oMatTempArr");
            var OppSolTempArr = this.oSolutionsModel.getProperty("/OppSolTempArr");
            OppSolTempArr = OppSolTempArr === undefined ? [] : OppSolTempArr;
            var sPath = oSource.getBindingContext("oSolutionsModel").getPath();
            var MatTblSelectMode = this.oSolutionsModel.getProperty("/MatTblSelectMode");
            var object = this.oSolutionsModel.getProperty(sPath);
            var levelCount = object.LevelCount;
            var L5Map = this.oSolutionsModel.getProperty("/L5Map");
            var l4TempObj = $.extend(true, {}, L5Map[object["L5Id"]]);
            if (MatTblSelectMode === "MultiSelect") {
                switch (levelCount) {
                    case 4:
                        var l4Data = this.fnCheckL4SolutionObjects(object, oSolTempArr, oMatTempArr, OppSolTempArr, oSource.getSelected());
                        oSolTempArr = l4Data[0];
                        oMatTempArr = l4Data[1];
                        OppSolTempArr = l4Data[2];
                        break;
                    case 5:
                        var l5Data = this.fnMultiCheckL5SolObjects(object, oSolTempArr, oMatTempArr, OppSolTempArr, oSource.getSelected());
                        oSolTempArr = l5Data[0];
                        oMatTempArr = l5Data[1];
                        OppSolTempArr = l5Data[2];
                        break;

                    case 3:
                        var l3Data = this.fnMultiCheckL3SolObj3cts(object, oSolTempArr, oMatTempArr, OppSolTempArr, oSource.getSelected());
                        oSolTempArr = l3Data[0];
                        oMatTempArr = l3Data[1];
                        OppSolTempArr = l3Data[2];
                        break;

                }
                var solArr = $.extend(true, [], oSolTempArr);
                var SolTokens = solArr.concat(oMatTempArr);
                var displayTokens = this.fnGetDisplayTokens(SolTokens);
                this.oSolutionsModel.setProperty("/DisplayTokens", displayTokens);

            } else {
                oSolTempArr = [];
                OppSolTempArr = [];
                var tempObj = $.extend(true, {}, object);
                oSolTempArr.push(tempObj);
                switch (levelCount) {
                    case 5: oSolTempArr = this.fnUpdateSolutionTempArr(l4TempObj, oSolTempArr, true, false);
                        break;
                }
                var oMaterialTable = sap.ui.core.Fragment.byId(this.SolHierarchyDialogId, "idMaterailMTbl");
                oMaterialTable.removeSelections();
                this.oSolutionsModel.setProperty("/oMatTempArr", []);
                this.oSolutionsModel.setProperty("/DisplayTokens", oSolTempArr);
                var isOppoTabVisible = this.oSolutionsModel.getProperty("/isOppoTabVisible");
                if (isOppoTabVisible) {
                    var OppoMaterials = this.oSolutionsModel.getProperty("/OppoMaterials");
                    var bVal = this.fnFindOppObjInArray(object, OppoMaterials, false);
                    if (bVal) {
                        OppSolTempArr = this.fnUpdateSolutionTempArr(tempObj, OppSolTempArr, false);
                    }
                }
            }
            this.oSolutionsModel.setProperty("/oSolTempArr", oSolTempArr);
            this.oSolutionsModel.setProperty("/OppSolTempArr", OppSolTempArr);
            this.fnSetSelectedSolMatData();
            this.oSolutionsModel.refresh(true);
        },

        // Function to  check/uncheck Checkboxes or delete tokens on L4 objects and its corresponding L5 objects
   fnCheckL4SolutionObjects: function (object, oSolTempArr, oMatTempArr, OppSolTempArr, isSelected, isTokenDelete) { // var oSolutionsModel = this.parentView.getModel("oSolutionsModel");
            var isOppoTabVisible = this.oSolutionsModel.getProperty("/isOppoTabVisible");
            if (isSelected === false) {
                var aL4Levels = object.Levels;
                for (var i = 0; i < aL4Levels.length; i++) {
                    var index = this.fnFindObjInArray(aL4Levels[i], oSolTempArr);
                    if (index >= 0) {
                        aL4Levels[i].isSelected = false;
                        oSolTempArr = this.fnUpdateSolutionTempArr(aL4Levels[i], oSolTempArr, false);
                        oMatTempArr = this.fnRemoveSolMaterials("L5Id", aL4Levels[i], oMatTempArr);
                        if (isOppoTabVisible) {
                            OppSolTempArr = this.fnUpdateSolutionTempArr(aL4Levels[i], OppSolTempArr, false);
                        }
                    }
                }
                object.isSelected = !object.isSelected;
                oMatTempArr = this.fnRemoveSolMaterials("L4Id", object, oMatTempArr);
            }
            oSolTempArr = this.fnUpdateSolutionTempArr(object, oSolTempArr, false);
            // if(isSelected === true){
            //      oSolTempArr = this.fnHandleL3Selection(object, oSolTempArr);
            // }

            // ===== L3 UPDATE (SAME AS L4 PATTERN) =====
            var L3Map = this.oSolutionsModel.getProperty("/L3Map");
            var l3TempObj = $.extend(true, {}, L3Map[object.L3Id].l3);

            var aL4s = L3Map[object.L3Id].l4s;

            // check if ANY L4 still selected
            var isL3Visible = aL4s.some(function (l4) {
                return this.fnFindObjInArray(l4, oSolTempArr) !== undefined;
            }.bind(this));
            if(!isL3Visible && isTokenDelete){
                 //oSolTempArr = this.fnUpdateSolutionTempArr(l3TempObj,  oSolTempArr,true ,isL3Visible)
                  oSolTempArr = this.fnUpdateSolutionTempArr(l3TempObj, oSolTempArr, true);
            }
            else {
                 oSolTempArr = this.fnUpdateSolutionTempArr(l3TempObj, oSolTempArr, true);
            }

               if(isSelected ===false && !isL3Visible ){
                oSolTempArr = this.fnUpdateSolutionTempArr(l3TempObj, oSolTempArr, true,true);
               }
          



            if (isSelected === false) {
                var aL3Levels = l3TempObj.Levels;
                for (var i = 0; i < aL3Levels.length; i++) {
                    var index = this.fnFindObjInArray(aL3Levels[i], oSolTempArr);
                    if (index >= 0) {
                        aL3Levels[i].isSelected = false;
                        oSolTempArr = this.fnUpdateSolutionTempArr(aL3Levels[i], oSolTempArr, false);
                        oMatTempArr = this.fnRemoveSolMaterials("L4Id", aL3Levels[i], oMatTempArr);
                        if (isOppoTabVisible) {
                            OppSolTempArr = this.fnUpdateSolutionTempArr(aL3Levels[i], OppSolTempArr, false);
                        }
                    }
                }
                l3TempObj.isSelected = !l3TempObj.isSelected;
                oMatTempArr = this.fnRemoveSolMaterials("L3Id", l3TempObj, oMatTempArr);
            }



            if (isOppoTabVisible) {
                var OppoMaterials = this.oSolutionsModel.getProperty("/OppoMaterials");
                var bVal = this.fnFindOppObjInArray(object, OppoMaterials, false);
                if (bVal) {
                    OppSolTempArr = this.fnUpdateSolutionTempArr(object, OppSolTempArr, false);
                }
            }
            if(!isL3Visible && isTokenDelete){
                 var l4Data = this.fnMultiCheckL3SolObj3cts(l3TempObj, oSolTempArr, oMatTempArr, OppSolTempArr, true, isTokenDelete);
                oSolTempArr = l4Data[0];
                oMatTempArr = l4Data[1];
                OppSolTempArr = l4Data[2];
                l3TempObj.isSelected = false;
            }
            return [oSolTempArr, oMatTempArr, OppSolTempArr];
        },


        // Function to delete Solution/Material tokens from Dialog and Form Multi input field
        // Below function triggers from 2 fields and fires event 4 times
        fnDeleteSolMatTokens: function (oEvent) {
            var index,
                sPath,
                fldType;
            var oSource = oEvent.getSource();
            if (oSource.getBindingContext("oSolutionsModel")) {
                sPath = oSource.getBindingContext("oSolutionsModel").getPath();
            } else {
                var oToken = oEvent.getParameter("removedTokens")[0];
                sPath = oToken.getBindingContext("oSolutionsModel").getPath();
            }
            if (oSource.getCustomData()[0]) {
                fldType = oSource.getCustomData()[0].getKey();
            }
            var deletedObj = this.oSolutionsModel.getProperty(sPath);
            var oSolTempArr = this.oSolutionsModel.getProperty("/oSolTempArr");
            var oMatTempArr = this.oSolutionsModel.getProperty("/oMatTempArr");
            var OppSolTempArr = this.oSolutionsModel.getProperty("/OppSolTempArr");
            if (!deletedObj.LevelCount) {
                index = this.fnFindObjInArray(deletedObj, oMatTempArr, true);
                oMatTempArr.splice(index, 1);
            } else {
                var levelCount = deletedObj.LevelCount;
                if (levelCount === 4) {
                    var l4Data = this.fnCheckL4SolutionObjects(deletedObj, oSolTempArr, oMatTempArr, OppSolTempArr, false, true);
                    oSolTempArr = l4Data[0];
                    oMatTempArr = l4Data[1];
                    OppSolTempArr = l4Data[2];
                } else if (levelCount === 5) {
                    var l5Data = this.fnMultiCheckL5SolObjects(deletedObj, oSolTempArr, oMatTempArr, OppSolTempArr, false, true);
                    oSolTempArr = l5Data[0];
                    oMatTempArr = l5Data[1];
                    OppSolTempArr = l5Data[2];
                } else if (levelCount === 3) {
                    var l3Data = this.fnMultiCheckL3SolObj3cts(deletedObj, oSolTempArr, oMatTempArr, OppSolTempArr, false, true);
                    oSolTempArr = l3Data[0];
                    oMatTempArr = l3Data[1];
                    OppSolTempArr = l3Data[2];
                }
            }
            var SolTokens = oSolTempArr.concat(oMatTempArr);
            var displayTokens = this.fnGetDisplayTokens(SolTokens);
            this.oSolutionsModel.setProperty("/DisplayTokens", displayTokens);
            if (fldType === "SOL_MULTI_SELECT") {
                var oPayload = this.fnGetSolMatPayload(oSolTempArr, oMatTempArr);
                this.oSolutionsModel.setProperty("/to_ATaxonomy", oSolTempArr);
                this.oSolutionsModel.setProperty("/to_AMaterial", oMatTempArr);
                this.RapidRegDataModel.setProperty("/to_ATaxonomy", oPayload[0]);
                this.RapidRegDataModel.setProperty("/to_AMaterial", oPayload[1]);
                this.oSolutionsModel.setProperty("/SolTokens", displayTokens);
                // if (oSolTempArr.length > 0) {
                // this.parentView.byId("additionalSolutions").setValueState("None");
                // }
            } else {
                this.oSolutionsModel.setProperty("/oSolTempArr", oSolTempArr);
                this.oSolutionsModel.setProperty("/oMatTempArr", oMatTempArr);
            }
            this.fnSetSelectedSolMatData();
            this.fnUpdateSolOnDeleteTokens(deletedObj);
            this.oSolutionsModel.refresh(true);
        },

        // Function to update isSelected property on delete of solution token
        fnUpdateSolOnDeleteTokens: function (deleteToken) {
            var aTaxonomy = this.oSolutionsModel.getProperty("/to_ATaxonomy");

            var aL2 = this.oSolutionsModel.getProperty("/SelectedLevelHierarchy");

            aL2.forEach(function (l2Obj) {

                l2Obj.Levels.forEach(function (l3Obj) {

                    // ---- DELETE L3 ----
                    if (deleteToken.LevelCount === 3 &&
                        l3Obj.L3Id === deleteToken.LevelId) {

                        l3Obj.isSelected = false;

                        // unselect all L4 + L5
                        l3Obj.Levels.forEach(function (l4Obj) {
                            l4Obj.isSelected = false;
                            l4Obj.Levels.forEach(function (l5Obj) {
                                l5Obj.isSelected = false;
                            });
                        });

                        return;
                    }

                    l3Obj.Levels.forEach(function (l4Obj) {

                        // ---- DELETE L4 ----
                        if (deleteToken.LevelCount === 4 &&
                            l4Obj.L4Id === deleteToken.LevelId) {

                            l4Obj.isSelected = false;

                            // unselect all L5 under it
                            l4Obj.Levels.forEach(function (l5Obj) {
                                l5Obj.isSelected = false;
                            });

                            return;
                        }

                        l4Obj.Levels.forEach(function (l5Obj) {

                            // ---- DELETE L5 ----
                            if (deleteToken.LevelCount === 5 &&
                                l5Obj.L5Id === deleteToken.LevelId) {

                                l5Obj.isSelected = false;
                            }
                        });

                        // ---- After L5 delete → check L4 ----
                        var hasSelectedL5 = l4Obj.Levels.some(function (l5) {
                            return l5.isSelected === true;
                        });

                        if (!hasSelectedL5) {
                            l4Obj.isSelected = false;
                        }
                    });

                    // ---- After L4 delete → check L3 ----
                    var hasSelectedL4 = l3Obj.Levels.some(function (l4) {
                        return l4.isSelected === true;
                    });

                    if (!hasSelectedL4) {
                        l3Obj.isSelected = false;
                    }
                });
            });
            this._updateSolutionHierarchy(aTaxonomy, aL2);
            this.oSolutionsModel.setProperty("/SelectedLevelHierarchy", aL2);
            this.oSolutionsModel.refresh(true);
        },


        // Function to push/remove selected/deselectd solutions
        fnUpdateSolutionTempArr: function (object, oSolTempArr, isParent, isL4Visible) {
            var tempObj = $.extend(true, {}, object);
            var index = this.fnFindObjInArray(tempObj, oSolTempArr);
            if (index === undefined) {
                tempObj.isParent = isParent;
                tempObj.ValueState = isParent ? "Information" : "None";
                oSolTempArr.push(tempObj);
            } else {
                if (!isParent) {
                    oSolTempArr[index].ValueState = "None";
                    oSolTempArr.splice(index, 1);
                } else if (isParent && isL4Visible) {
                    oSolTempArr[index].isParent = false;
                    oSolTempArr[index].isSelected = true;
                    oSolTempArr[index].ValueState = "None";
                } else if (isParent && !isL4Visible) {
                    oSolTempArr[index].isParent = true;
                    oSolTempArr[index].ValueState = "Information";
                }
            }
            return oSolTempArr;
        },

        // Function to  check/uncheck Checkboxes or delete tokens on L5 objects and its parent L4 objects
        fnMultiCheckL5SolObjects: function (object, oSolTempArr, oMatTempArr, OppSolTempArr, isSelected, isTokenDelete) {
            var isL4Visible = false;
            // var oSolutionsModel = this.parentView.getModel("oSolutionsModel");
            var L5Map = this.oSolutionsModel.getProperty("/L5Map");
            var isOppoTabVisible = this.oSolutionsModel.getProperty("/isOppoTabVisible");
            var l4TempObj = $.extend(true, {}, L5Map[object["L5Id"]]);
            if (isTokenDelete) {
                object.isSelected = isSelected;
            } 
             oSolTempArr = this.fnUpdateSolutionTempArr(object, oSolTempArr, false);
            if (isSelected === false) {
                object.isSelected = false;
                oMatTempArr = this.fnRemoveSolMaterials("L5Id", object, oMatTempArr);
                isL4Visible = this.fnGetAllL4sL5Objs(object, oSolTempArr);
            }
            oSolTempArr = this.fnUpdateSolutionTempArr(l4TempObj, oSolTempArr, true, isL4Visible);
            // if (isSelected === true) {
            //     var L3Map = this.oSolutionsModel.getProperty("/L3Map");
            //     var l3Obj = L3Map[l4TempObj.L3Id].l3;
            //     var aL4s = L3Map[l4TempObj.L3Id].l4s;
            //     var isL3Visible = aL4s.some(function (l4) {
            //         return this.fnFindObjInArray(l4, oSolTempArr) !== undefined;
            //     }.bind(this));
            //     oSolTempArr = this.fnUpdateSolutionTempArr(
            //         l3Obj,
            //         oSolTempArr,
            //         true,
            //         isL3Visible
            //     );
            // }
            // ===== L3 HANDLING (same pattern as L4) =====
            var L3Map = this.oSolutionsModel.getProperty("/L3Map");

            // get L3 object from L4
            var l3TempObj = $.extend(true, {}, L3Map[l4TempObj.L3Id].l3);

            // check if ANY L4 under this L3 is still selected
            var aL4s = L3Map[l4TempObj.L3Id].l4s;

            var isL3Visible = aL4s.some(function (l4) {
                return this.fnFindObjInArray(l4, oSolTempArr) === undefined;
            }.bind(this));
            //var isL3Visible = !isAnyL4Effective;
            // update L3 same way as L4


                oSolTempArr = this.fnUpdateSolutionTempArr(
                    l3TempObj,
                    oSolTempArr,
                    true,
                    false
                );


            if (isOppoTabVisible) {
                var OppoMaterials = this.oSolutionsModel.getProperty("/OppoMaterials");
                var bVal = this.fnFindOppObjInArray(object, OppoMaterials, false);
                if (bVal) {
                    OppSolTempArr = this.fnUpdateSolutionTempArr(object, OppSolTempArr, false);
                    OppSolTempArr = this.fnUpdateSolutionTempArr(l4TempObj, OppSolTempArr, true, isL4Visible);
                }
            }
            // Below code is executed when last L5 token is deleted and its corresponding L4 will be deleted
            // In case of Checkbox selection, when L5 is unchecked, L4 will still be present.
            if (isTokenDelete && isL4Visible) {
                var l4Data = this.fnCheckL4SolutionObjects(l4TempObj, oSolTempArr, oMatTempArr, OppSolTempArr, true, isTokenDelete);
                oSolTempArr = l4Data[0];
                oMatTempArr = l4Data[1];
                OppSolTempArr = l4Data[2];
                l3TempObj.isSelected = false;
            }
            return [oSolTempArr, oMatTempArr, OppSolTempArr];
        },

        // Function to find if soltempArr l5 objs are unselected for L4
        // gets executed when L5 gets unchecked, and if its L4 should be shown in display tokens
        fnGetAllL4sL5Objs: function (l5TempObj, oSolTempArr) {
            var iCount = 0;
            var bVal = false;
            // var this.oSolutionsModel = this.parentView.getModel("oSolutionsModel");
            var L4Map = this.oSolutionsModel.getProperty("/L4Map");
            var oL4Array = L4Map[l5TempObj["L4Id"]];
            for (var i = 0; i < oL4Array.length; i++) {
                var index = this.fnFindObjInArray(oL4Array[i], oSolTempArr);
                if (index >= 0) {
                    iCount += 1;
                }
            }
            if (iCount === 0) {
                bVal = true;
            }
            return bVal;
        },

        fnMultiCheckL3SolObj3cts: function (object, oSolTempArr, oMatTempArr, OppSolTempArr, isSelected) {
            var isOppoTabVisible = this.oSolutionsModel.getProperty("/isOppoTabVisible");
            //  if(isSelected === false){
            //     var aL4Levels = object.Levels;
            //     for (var i = 0; i < aL4Levels.length; i++) {
            //         var index = this.fnFindObjInArray(aL4Levels[i], oSolTempArr);
            //         if (index >= 0) {
            //             aL4Levels[i].isSelected = false;
            //             oSolTempArr = this.fnUpdateSolutionTempArr(aL4Levels[i], oSolTempArr, false);
            //             oMatTempArr = this.fnRemoveSolMaterials("L4Id", aL4Levels[i], oMatTempArr);
            //             if (isOppoTabVisible) {
            //                 OppSolTempArr = this.fnUpdateSolutionTempArr(aL4Levels[i], OppSolTempArr, false);
            //             }
            //         }
            //     }
            //     object.isSelected = !object.isSelected;
            //     oMatTempArr = this.fnRemoveSolMaterials("L3Id", object, oMatTempArr);

            //  }
            if (isSelected === false) {
                var aL4Levels = object.Levels || [];

                for (var i = 0; i < aL4Levels.length; i++) {

                    var l4Obj = aL4Levels[i];

                    // ---- REMOVE ALL L5 UNDER THIS L4 ----
                    var aL5Levels = l4Obj.Levels || [];
                    for (var j = 0; j < aL5Levels.length; j++) {

                        var l5Index = this.fnFindObjInArray(aL5Levels[j], oSolTempArr);
                        if (l5Index >= 0) {
                            aL5Levels[j].isSelected = false;
                            oSolTempArr = this.fnUpdateSolutionTempArr(aL5Levels[j], oSolTempArr, false);
                            oMatTempArr = this.fnRemoveSolMaterials("L5Id", aL5Levels[j], oMatTempArr);

                            if (isOppoTabVisible) {
                                OppSolTempArr = this.fnUpdateSolutionTempArr(aL5Levels[j], OppSolTempArr, false);
                            }
                        }
                    }

                    // ---- REMOVE L4 ITSELF ----
                    var l4Index = this.fnFindObjInArray(l4Obj, oSolTempArr);
                    if (l4Index >= 0) {
                        l4Obj.isSelected = false;
                        oSolTempArr = this.fnUpdateSolutionTempArr(l4Obj, oSolTempArr, false);
                        oMatTempArr = this.fnRemoveSolMaterials("L4Id", l4Obj, oMatTempArr);

                        if (isOppoTabVisible) {
                            OppSolTempArr = this.fnUpdateSolutionTempArr(l4Obj, OppSolTempArr, false);
                        }
                    }
                }

                // ---- REMOVE L3 ITSELF ----
                object.isSelected = false;
                oMatTempArr = this.fnRemoveSolMaterials("L3Id", object, oMatTempArr);
            }


            oSolTempArr = this.fnUpdateSolutionTempArr(object, oSolTempArr, false);
            if (isOppoTabVisible) {
                var OppoMaterials = this.oSolutionsModel.getProperty("/OppoMaterials");
                var bVal = this.fnFindOppObjInArray(object, OppoMaterials, false);
                if (bVal) {
                    OppSolTempArr = this.fnUpdateSolutionTempArr(object, OppSolTempArr, false);
                }
            }
            return [oSolTempArr, oMatTempArr, OppSolTempArr];

        },
        fnHandleL3Selection: function (l4Obj, oSolTempArr) {


            var L3Map = this.oSolutionsModel.getProperty("/L3Map");
            var l3Obj = L3Map[l4Obj.L3Id].l3;

            // all L4s under this L3
            //var aL4s = L3Map[l4Obj.L3Id];
            var aL4s = L3Map[l4Obj.L3Id].l4s;

            // check if ANY L4 is selected
            var isL3Visible = aL4s.some(function (l4) {
                return this.fnFindObjInArray(l4, oSolTempArr) !== undefined;
            }.bind(this));

            // get L3 object reference
            // var l3Obj = aL4s[0];
            var l3TempObj = $.extend(true, {}, l3Obj);

            // update L3 in temp array
            oSolTempArr = this.fnUpdateSolutionTempArr(
                l3TempObj,
                oSolTempArr,
                true,
                false
            );

            return oSolTempArr;
        },


        // Function to find if an object already exists in array
        fnFindOppObjInArray: function (object, Array) {
            var bVal = false;
            if (Array) {
                Array.find(function (obj, index) {
                    if (obj["L2Id"] === object["L2Id"]) {
                        if (obj["L3Id"] === object["L3Id"]) {
                            if (obj["L4Id"] === object["L4Id"]) {
                                bVal = true;
                            }
                        }
                    }
                });
            }
            return bVal;
        },

        // Function to find if an object already exists in array
        fnFindObjInArray: function (object, Array, isMaterial) {
            var sIndex;
            Array.find(function (obj, index) {
                if (isMaterial) {
                    if (obj.MatId === object.MatId) {
                        sIndex = index;
                    }
                } else {
                    var levelId = "L" + obj.LevelCount + "Id";
                    if (obj.LevelCount === object.LevelCount && obj[levelId] === object[levelId]) {
                        sIndex = index;
                    }
                }
            });
            return sIndex;
        },

        // Function to un-check materials when a solution is unchecked
        fnRemoveSolMaterials: function (levelId, oSolutionObj, oMatTempArr) {
            var length = oMatTempArr.length - 1;
            for (var i = length; i >= 0; i--) {
                var oMatObj = oMatTempArr[i];
                if (oMatObj[levelId] === oSolutionObj[levelId]) {
                    oMatTempArr.splice(i, 1);
                }
            }
            return oMatTempArr;
        },

        // Function to set selected solution's material data to table
        fnSetSelectedSolMatData: function (isOpportunity) {
            var that = this;
            this._matHierarchyContext = {};
            var aFilters = [];
            var matTblFilter = new Filter({ filters: aFilters });
            // var oSolutionsModel = this.parentView.getModel("oSolutionsModel");
            if (this.oSolutionsModel.getProperty("/isMatTblVisible")) {
                var ITBSelectedKey = this.oSolutionsModel.getProperty("/ITBSelectedKey");
                this.oSolutionsModel.setProperty("/isGridLayBusy", true);
                setTimeout(function () {
                    var oMaterialTree = sap.ui.core.Fragment.byId(that.SolHierarchyDialogId, "idMaterailMTbl");
                    if (ITBSelectedKey === "FROM_OPPORTUNITY") {
                        var OppSolTempArr = that.oSolutionsModel.getProperty("/OppSolTempArr");
                        OppSolTempArr = OppSolTempArr ? OppSolTempArr : [];
                        for (var i = 0; i < OppSolTempArr.length; i++) { // if (!OppSolTempArr[i].isParent) {
                            var sProperty = "L" + OppSolTempArr[i].LevelCount + "Id";
                            var sDesc = OppSolTempArr[i][sProperty];
                            var oLevelFilter = new Filter({
                                filters: [
                                    new Filter("isOpportunity", "EQ", true),
                                    new Filter(sProperty, "EQ", sDesc)
                                ],
                                and: true
                            });
                            aFilters.push(oLevelFilter);
                            // }
                        }
                    } else {
                        var oSolTempArr = that.oSolutionsModel.getProperty("/oSolTempArr");
                        for (var i = 0; i < oSolTempArr.length; i++) {
                            if (!oSolTempArr[i].isParent) {
                                var oProperty = "L" + oSolTempArr[i].LevelCount + "Id";
                                var oDesc = oSolTempArr[i][oProperty];
                                this._matHierarchyContext[oDesc] = this.fnBuildHierarchyPath(oSolTempArr[i]);
                                var filter = new Filter(oProperty, "EQ", oDesc);
                                aFilters.push(filter);
                            }
                        }
                    } matTblFilter = new Filter({ filters: aFilters, and: false });
                    if (aFilters.length === 0) {
                        that.oSolutionsModel.setProperty("/Materials", []);
                    } else {
                        var SolutionHierarchy = that.oSolutionsModel.getProperty("/SolutionHierarchy");
                        that.oSolutionsModel.setProperty("/Materials", SolutionHierarchy);
                        oMaterialTree.getBinding("items").filter(matTblFilter);
                    } that.oSolutionsModel.setProperty("/isGridLayBusy", false);
                }.bind(this), 1000);
            }
        },
        fnBuildHierarchyPath: function (node) {
            var hierarchy = "";

            if (node.LevelCount === 3) hierarchy = hierarchy + node.L2Desc + " > " + node.L3Desc
            if (node.LevelCount === 4) hierarchy = hierarchy + node.L2Desc + " > " + node.L3Desc + " > " + node.L4Desc
            if (node.LevelCount === 5) hierarchy = hierarchy + node.L2Desc + " > " + node.L3Desc + " > " + node.L4Desc + " > " + node.L5Desc

            return hierarchy;
        },


        // Function to get selected objs on Checkbox/RadioBtn selection change from material table
        fnSetTblCheckRadioBtnSelected: function (oEvent) {
            var oSource = oEvent.getSource();
            var contextMap = this._matHierarchyContext || {};
            if (!oSource.getVisible()) {
                return;
            }
            // var oSolutionsModel = this.parentView.getModel("oSolutionsModel");
            var oSolTempArr = this.oSolutionsModel.getProperty("/oSolTempArr");
            var oMatTempArr = this.oSolutionsModel.getProperty("/oMatTempArr");
            var MatTblSelectMode = this.oSolutionsModel.getProperty("/MatTblSelectMode");
            var sPath = oSource.getBindingContext("oSolutionsModel").getPath();
            var object = this.oSolutionsModel.getProperty(sPath);
            var hierarchyText = "";
            Object.keys(contextMap).some(function (key) {
                if (object.L3Id === key || object.L4Id === key || object.L5Id === key) {
                    hierarchyText = contextMap[key];
                    return true;
                }
            });
            var tempObj = $.extend(true, {}, object);
            if (MatTblSelectMode === "MultiSelect") {
                var sIndex = this.fnFindObjInArray(tempObj, oMatTempArr, true);
                if (sIndex === undefined) {
                    tempObj.LevelId = tempObj.MatId;
                    tempObj.LevelDesc = "Material Name" + " - " + hierarchyText + " > " + tempObj.MatDesc;
                    oMatTempArr.push(tempObj);
                } else {
                    oMatTempArr.splice(sIndex, 1);
                }
                var matArr = $.extend(true, [], oMatTempArr);
                var SolTokens = oSolTempArr.concat(matArr);
                var displayTokens = this.fnGetDisplayTokens(SolTokens);
                this.oSolutionsModel.setProperty("/oMatTempArr", oMatTempArr);
                this.oSolutionsModel.setProperty("/DisplayTokens", displayTokens);
            } else {
                oMatTempArr = [];
                tempObj.LevelId = tempObj.MatId;
                tempObj.LevelDesc = "Material Name" + " - " + tempObj.MatDesc;
                oMatTempArr.push(tempObj);
                this.oSolutionsModel.setProperty("/DisplayTokens", oMatTempArr);
                this.oSolutionsModel.setProperty("/oMatTempArr", oMatTempArr);
            }
        },

        // Landscape changes
        addLandscapes: function () {
            // if (this.oLandscapeDialog) {
            // this.oLandscapeDialog.destroy();
            // this.oLandscapeDialog = undefined;
            // }
            if (!this.oLandscapeDialog) {
                this.oLandscapeDialog = sap.ui.xmlfragment(this.RapidRegDialog.getId() + "_LandscapeDialog", "com.melody.lib.fragments.RapidRegistration.addLandscape", this);
                this.RapidRegDialog.getParent().addDependent(this.oLandscapeDialog);
                this.oLandscapeDialog.setModel(this.i18nModel, "i18n");
                this.oLandscapeDialog.setModel(this.RapidRegUIModel, "RapidRegUIModel");
                this.oLandscapeDialog.setModel(this.RapidRegDataModel, "RapidRegDataModel");
                this.LandscapeDialogId = this.RapidRegDialog.getId() + "_LandscapeDialog";
                this.setLandscapeSelected(false);
            } else {
                this.setLandscapeSelected(true);
            }
            this.oLandscapeDialog.open();
        },

        setLandscapeSelected: function (isDialogLoaded) {
            var that = this;
            var data = this.RapidRegUIModel.getProperty("/landscape");
            var oLTypeMap = {};
            for (var i in data) {
                if (!oLTypeMap.hasOwnProperty(data[i].Ltype) && data[i].LTypeDescription !== "") {
                    oLTypeMap[data[i].Ltype] = data[i].LTypeDescription;
                }
                if (that.landscapeMap.hasOwnProperty(data[i].LandsId) && data[i].SelectionCat === "Master") {
                    data[i].selected = true;
                    data[i].prevSelected = true;
                } else {
                    data[i].selected = false;
                    data[i].prevSelected = false;
                }
            }
            this.RapidRegUIModel.setProperty("/LTypeMap", oLTypeMap);
            this.RapidRegUIModel.setProperty("/landscape", data);
            var activityId = this.RapidRegDataModel.getProperty("/ActivityId");
            if (!isDialogLoaded && !activityId) {
                this.RapidRegUIModel.setProperty("/isLandscapeExpanded", true);
                data = that.fnFormatFlatToTreeData(data, "SelectionCat");
                data = that.fnRestructureTreeData(data, "SelectionCat", "landscape");
                this.RapidRegUIModel.setProperty("/LTypeMap", oLTypeMap);
                this.RapidRegUIModel.setProperty("/landscape", data);
                var landscapeTable = sap.ui.core.Fragment.byId(this.LandscapeDialogId, "idLandscapeTable");
                if (landscapeTable) {
                    landscapeTable.setBusy(false);
                }
                that.fnDemoEnvExpandCollapseAll("", "landscape", "landscapeSearchField", true);
                that.fnSetSAPDemoECSelectAll("landscape", "isLandscapeSelectAll");
                that.fnSetTreeTableVisibleRowCount("idLandscapeTable", "landscapeRowCount");
                this.RapidRegUIModel.setProperty("/TblSortedOption", "SelectionCat");
            }
            var landscapeSearch = sap.ui.core.Fragment.byId(this.LandscapeDialogId, "landscapeSearchField");
            if (landscapeSearch) {
                landscapeSearch.setValue();
                landscapeSearch.fireLiveChange();
            }
            var landscapes = this.RapidRegDataModel.getProperty("/to_ALand") ? this.RapidRegDataModel.getProperty("/to_ALand") : [];
            this.RapidRegUIModel.setProperty("/landscapeCount", landscapes.length);
            this.RapidRegDataModel.setProperty("/to_ALand", structuredClone(landscapes));
            this.RapidRegUIModel.refresh();
            this.RapidRegDataModel.refresh();
        },

        // Function to format flat to tree structure data
        fnFormatFlatToTreeData: function (oData, property, removeRecentSelections) {
            return oData.reduce(function (acc, obj) {
                var key = obj[property];
                if (!acc[key]) {
                    acc[key] = [];
                }
                // Add object to list for given key's value
                if ((removeRecentSelections && obj.SelectionCat !== "Recent Selection") || !removeRecentSelections)
                    acc[key].push(obj);



                return acc;
            }, {});
        },

        // Function to group data in tree structure
        fnRestructureTreeData: function (oData, oFieldProperty, oArrayProperty) {
            var oTempArr = [];
            var oKeys = Object.keys(oData);
            for (var i = 0; i < oKeys.length; i++) {
                var oTempObj = {};
                oTempObj["isParent"] = true;
                oTempObj["isExpanded"] = true;
                oTempObj[oFieldProperty] = oKeys[i];
                oTempObj[oArrayProperty] = oData[oKeys[i]];
                oTempArr.push(oTempObj);
            }
            return oTempArr;
        },

        onCloseLandscapeDialog: function (oEvent) {
            this.oLandscapeDialog.close();
            this.fnSelectAllLandscape("", true);
        },

        // Function to select all SAP Demo EC rows
        fnSelectAllLandscape: function (oEvent, isCancel, deletedObj) {
            this.fnDemoEnvSelectAll(oEvent, isCancel, deletedObj, "landscape", "isLandscapeSelectAll");
        },

        // Common function to select all items in SAPDemoEC and Landscape array
        fnDemoEnvSelectAll: function (oEvent, isCancel, deletedObj, treeBindingPath, selectAllPath) {
            if (oEvent) {
                var bVal = oEvent.getSource().getSelected();
            }
            var sapDemoEc = this.RapidRegUIModel.getProperty("/" + treeBindingPath);
            sapDemoEc.filter(function (parentObj) {
                parentObj[treeBindingPath].filter(function (childObj) {
                    if (isCancel) {
                        childObj.selected = childObj.prevSelected;
                    } else if (deletedObj) {
                        if (childObj.LandsId === deletedObj.LandsId && childObj.LandDescription === deletedObj.LandDescription) {
                            childObj.selected = false;
                            childObj.prevSelected = false;
                        }
                    } else {
                        childObj.selected = bVal;
                    }
                });
            });
            this.RapidRegUIModel.setProperty("/" + treeBindingPath, sapDemoEc);
            this.fnSetSAPDemoECSelectAll(treeBindingPath, selectAllPath);
        },

        fnSetTreeTableVisibleRowCount: function () {
            var landscapeTable = sap.ui.core.Fragment.byId(this.LandscapeDialogId, "idLandscapeTable");
            var oBindings = landscapeTable.getBinding("rows");
            oBindings.attachFilter(function (evt) {
                var oSource = evt.getSource();
                var length = oSource.getLength();
                if (length) {
                    var RapidRegUIModel = oSource.getModel("RapidRegUIModel");
                    RapidRegUIModel.setProperty("/landscapeRowCount", length);
                    RapidRegUIModel.refresh();
                }
            });
        },

        fnSingleSelectLandscape: function (oEvent) {
            this.fnSingleSelectDemoEnv(oEvent, "landscape", "isLandscapeSelectAll");
        },

        fnSingleSelectDemoEnv: function (oEvent, bindingProperty, selectAllPath) {
            var oSoure = oEvent.getSource();
            var bVal = oSoure.getSelected();
            var sPath = oSoure.getBindingContext("RapidRegUIModel").getPath();
            var object = this.RapidRegUIModel.getProperty(sPath);
            var oArray = this.RapidRegUIModel.getProperty("/" + bindingProperty);
            var bLandScapeExists = false;
            oArray.filter(function (parentObj) {
                parentObj[bindingProperty].filter(function (childObj) {
                    if (childObj.LandsId === object.LandsId && childObj.LandDescription === object.LandDescription && childObj.LandscapeId === object.LandscapeId) {
                        childObj.selected = bVal;
                    }
                    if (childObj.LandsId === object.LandsId && childObj.LandDescription === object.LandDescription && childObj.selected) {
                        bLandScapeExists = true;
                    }
                });
            });
            this.RapidRegUIModel.setProperty("/" + bindingProperty, oArray);
            this.fnSetSAPDemoECSelectAll(bindingProperty, selectAllPath);
            var landscapes = this.RapidRegDataModel.getProperty("/to_ALand");
            var landscapesMap = {};
            landscapes.forEach(each => landscapesMap[each['LandsId']] = each);
            if (bVal && !landscapesMap[object['LandsId']]) {
                landscapes.push(object)
            } else if (!bVal && !bLandScapeExists) {
                landscapes = landscapes.filter(each => each.LandsId !== object.LandsId)
            }
            this.RapidRegDataModel.setProperty("/to_ALand", landscapes);
            this.RapidRegUIModel.setProperty("/landscapeCount", landscapes.length);
        },

        // Common function to set Select All button selected in SAPDemoEC and Landscape
        fnSetSAPDemoECSelectAll: function (treeBindingPath, selectAllPath) {
            var totalObjCount = 0;
            var objSelectedCount = 0;
            var sapDemoEc = this.RapidRegUIModel.getProperty("/" + treeBindingPath);
            sapDemoEc.filter(function (parentObj) {
                totalObjCount = totalObjCount + parentObj[treeBindingPath].length;
                parentObj[treeBindingPath].filter(function (childObj) {
                    if (childObj.selected) {
                        objSelectedCount++;
                    }
                });
            });
            if (totalObjCount === objSelectedCount) {
                this.RapidRegUIModel.setProperty("/" + selectAllPath, true);
            } else {
                this.RapidRegUIModel.setProperty("/" + selectAllPath, false);
            }
        },

        // Common function to search tree table in SAPDemoEC and Landscape
        fnSearchDemoEvTbl: function (oEvent, oTable) {
            var aFilter = [];
            var searchString = oEvent.getSource().getValue();
            if (searchString !== "") {
                var filter1 = new Filter({
                    filters: [
                        new Filter("LandDescription", "Contains", searchString),
                        new Filter("LTypeDescription", "Contains", searchString),
                        new Filter("Location", "Contains", searchString),
                        new Filter("Product", "Contains", searchString)
                    ],
                    and: false
                });
                aFilter.push(filter1)
            }
            oTable.getBinding("rows").filter(aFilter);
        },

        // Common function to expand/collapse all rows in tree table in SAPDemoEC and Landscape
        fnDemoEnvExpandCollapseAll: function (oEvent, bindingProperty, searchFldId, isTblExpanded) {
            if (oEvent) {
                var oSource = oEvent.getSource();
                searchFldId = oSource.getCustomData()[0].getValue();
                bindingProperty = oSource.getCustomData()[0].getKey();
                var isExpandedProp = oSource.getCustomData()[1].getKey();
                var oTreeTable = oSource.getCustomData()[1].getValue();
                isTblExpanded = this.RapidRegUIModel.getProperty("/" + isExpandedProp);
            }
            this.fnUpdateDemoEnvExpandedObj(isTblExpanded, bindingProperty);
            this.fnSetTblRowsCount(bindingProperty, searchFldId);
            if (oTreeTable) {
                var oSortItem = this.RapidRegUIModel.getProperty("/TblSortedOption");
                this.fnFilterDemoLandscapeTbl(oSortItem, oTreeTable);
            }
            var landscapeSearch = sap.ui.core.Fragment.byId(this.LandscapeDialogId, searchFldId);
            if (landscapeSearch && landscapeSearch.getValue()) {
                landscapeSearch.fireLiveChange();
            }
        },

        // Common function to update visible row count in tree table in SAPDemoEC and Landscape
        fnSetTblRowsCount: function (bindingProperty, searchFldId) {
            this.fnGetExpandedRowsLength("", bindingProperty, "landscapeRowCount", "isLandscapeExpanded", "idLandscapeTable");
        },

        // Common function to get visible row count in tree table in SAPDemoEC and Landscape
        fnGetExpandedRowsLength: function (oEvent, bindingProperty, visibleRowCount, isAllRowsExpanded, treeTableId) {
            var oLength = 0;
            var expandedLen = 0;
            var collapsedLen = 0;
            var searchFldId = "";
            if (oEvent) {
                var oParameters = oEvent.getParameters();
                var isExpanded = oParameters.expanded;
                var sPath = oParameters.rowContext.getPath();
                this.RapidRegUIModel.setProperty(sPath + "/isExpanded", isExpanded);
                bindingProperty = sPath.split("/")[1];
                treeTableId = "idLandscapeTable";
                searchFldId = "landscapeSearchField";
                visibleRowCount = "landscapeRowCount";
                isAllRowsExpanded = "isLandscapeExpanded";
            }
            var oData = this.RapidRegUIModel.getProperty("/" + bindingProperty);
            oData.filter(function (objHeirarchy1) {
                oLength = oLength + 1;
                if (objHeirarchy1.isExpanded) {
                    expandedLen = expandedLen + 1;
                    var sapDemoEc = objHeirarchy1[bindingProperty];
                    if (sapDemoEc) {
                        oLength = oLength + sapDemoEc.length;
                    }
                } else {
                    collapsedLen = collapsedLen + 1;
                }
            });
            this.RapidRegUIModel.setProperty("/" + visibleRowCount, oLength);
            var landscapeTable = sap.ui.core.Fragment.byId(this.LandscapeDialogId, treeTableId);
            if (oData.length === expandedLen) {
                if (landscapeTable) {
                    landscapeTable.expandToLevel(1);
                }
                this.RapidRegUIModel.setProperty("/" + isAllRowsExpanded, false);
            } else if (oData.length === collapsedLen) {
                if (landscapeTable) {
                    landscapeTable.collapseAll();
                }
                this.RapidRegUIModel.setProperty("/" + isAllRowsExpanded, true);
            }
            var landscapeSearch = sap.ui.core.Fragment.byId(this.LandscapeDialogId, searchFldId);
            if (landscapeSearch) {
                landscapeSearch.fireLiveChange();
            }
        },

        // Common function to update selected property in tree table in SAPDemoEC and Landscape
        fnUpdateDemoEnvExpandedObj: function (isExpanded, bindingProperty) {
            var oData = this.RapidRegUIModel.getProperty("/" + bindingProperty);
            if (oData) {
                oData.filter(function (objHeirarchy1) {
                    objHeirarchy1.isExpanded = isExpanded;
                });
            }
            this.RapidRegUIModel.setProperty("/" + bindingProperty, oData);
            this.RapidRegUIModel.refresh(true);
        },

        // Common function to delete SAP Demo or Landscape
        fnDeleteLandscape: function (oEvent,) {
            var oSource = oEvent.getSource();
            var bindingProperty = oSource.getCustomData()[0].getKey();
            var selectAllProperty = oSource.getCustomData()[0].getValue();
            var sapDemoEc = this.RapidRegUIModel.getProperty("/" + bindingProperty);
            var to_ALand = this.RapidRegDataModel.getProperty("/to_ALand");
            var sPath = oEvent.getParameter("removedTokens")[0].getBindingContext("RapidRegDataModel").getPath();
            var oDeletedObj = this.RapidRegDataModel.getProperty(sPath);
            this.fnSelectAllSapDemoEc("", "", oDeletedObj, bindingProperty, selectAllProperty);
            var index = sPath.split("/")[2];
            to_ALand.splice(index, 1);
            this.RapidRegDataModel.setProperty("/to_ALand", to_ALand);
        },

        // Function to select all SAP Demo EC rows
        fnSelectAllSapDemoEc: function (oEvent, isCancel, deletedObj, bindingProp, isSelectAllProp) {
            this.fnDemoEnvSelectAll(oEvent, isCancel, deletedObj, bindingProp, isSelectAllProp);
        },

        onDeleteLandscape: function (oEvent, landscape) {
            var oSource = oEvent.getSource();
            var bindingProperty = oSource.getCustomData()[0].getKey();
            var selectAllProperty = oSource.getCustomData()[0].getValue();
            var sapDemoEc = this.RapidRegUIModel.getProperty("/" + bindingProperty);
            var to_ALand = this.RapidRegDataModel.getProperty("/to_ALand");
            var sPath = oEvent.getParameter("removedTokens")[0].getBindingContext('RapidRegDataModel').getPath()
            var oDeletedObj = this.RapidRegDataModel.getProperty(sPath);
            this.fnSelectAllSapDemoEc("", "", oDeletedObj, bindingProperty, selectAllProperty);
            var index = sPath.split("/")[2];
            to_ALand.splice(index, 1);
            this.RapidRegDataModel.setProperty("/to_ALand", to_ALand);
            this.RapidRegUIModel.setProperty("/landscapeCount", to_ALand.length)
        },

        // Common funtion to open sort options from SAP Demo EC and Landscape
        fnOpenDemoEnvSortOptions: function (oEvent) {
            if (!this.oDemoEnvSortMenu) {
                this.oDemoEnvSortMenu = sap.ui.xmlfragment(this.RapidRegDialog.getId() + "_LandscapeSortMenu", "com.melody.lib.fragments.RapidRegistration.DemoEnvSortOptions", this);
                this.RapidRegDialog.getParent().addDependent(this.oDemoEnvSortMenu);
            }
            this.oDemoEnvSortMenu.openBy(oEvent.getSource());
        },

        // Common function to sort the tree table in SAP Demo EC and Landscape
        fnDemoEnvSortMenuAction: function (oEvent) {
            var oTableId = "";
            var oSelectAll = "";
            var oSearchField = "";
            var oParentBinding = "";
            if (this.oLandscapeDialog) { // if (this.oLandscapeDialog.isOpen()) {
                oParentBinding = "landscape";
                oTableId = "idLandscapeTable";
                oSelectAll = "isLandscapeSelectAll";
                oSearchField = "landscapeSearchField";
                // }
            }
            if (oEvent) {
                var oSortItem = oEvent.getParameters().item.getCustomData()[0].getKey();
            } else {
                var oSortItem = "LTypeDescription";
            }
            var oData = this.RapidRegUIModel.getProperty("/" + oParentBinding);
            oData = this.fnConvertTreeToFlatStruc(oData, oParentBinding);
            oData = [
                ...new Map(oData.map(item => [
                    `${item.LandsId
                    }-${item.SelectionCat
                    }`,
                    item
                ])).values() // remove duplicates
            ];
            var recentSelections = oData.filter(each => each.SelectionCat === "Recent Selection")
            oData = this.fnFormatFlatToTreeData(oData, oSortItem, true);
            oData = this.fnRestructureTreeData(oData, "SelectionCat", oParentBinding);
            oData.sort((a, b) => (a.SelectionCat > b.SelectionCat) ? 1 : ((b.SelectionCat > a.SelectionCat) ? -1 : 0));
            oData.unshift({ SelectionCat: "Recent Selection", isExpanded: true, isParent: true, landscape: recentSelections });
            this.RapidRegUIModel.setProperty("/" + oParentBinding, oData);
            this.fnDemoEnvExpandCollapseAll("", oParentBinding, oSearchField, true);
            this.fnSetSAPDemoECSelectAll(oParentBinding, oSelectAll);
            this.fnFilterDemoLandscapeTbl(oSortItem, oTableId);
            this.RapidRegUIModel.setProperty("/TblSortedOption", oSortItem);
            var landscapeSearch = sap.ui.core.Fragment.byId(this.LandscapeDialogId, oSearchField);
            landscapeSearch.fireLiveChange();
        },

        // Common functoion called for both SAP Demo and Landscape dialog
        fnAfterOpenDemoLandscapeDialog: function (oEvent) {
            this.fnDemoEnvSortMenuAction();
        },

        // Function to search Landscape table by description
        fnSearchLandscape: function (oEvent) {
            var oTable = sap.ui.core.Fragment.byId(this.LandscapeDialogId, "idLandscapeTable");
            this.fnSearchDemoEvTbl(oEvent, oTable);
        },

        // Common function to filter tree table in SAP Demo EC and Landscape data
        fnFilterDemoLandscapeTbl: function (oSortItem, oTableId) {
            var oTable = sap.ui.core.Fragment.byId(this.LandscapeDialogId, oTableId);
            if (!oSortItem) {
                return;
            } else if (oSortItem === "LTypeDescription") {
                var oFilter1 = new Filter("LTypeDescription", "NE", "");
                oTable.getBinding("rows").filter([oFilter1]);
            } else {
                oTable.getBinding("rows").filter([]);
            }
        },

        // Common function to convert tree to flat data structure
        fnConvertTreeToFlatStruc: function (oData, oParentBinding) {
            var oTempArr = [];
            if (oData) {
                oData.filter(function (object) {
                    var oChildArr = object[oParentBinding];
                    if (oChildArr) {
                        oTempArr = oTempArr.concat(oChildArr);
                    }
                });
            }
            return oTempArr.length > 0 ? oTempArr : oData;
        },

        // Common function to form to_ALand dataset from Landscape
        fnSetSelectedLandscapes: function () {
            this.onDemoEcLandscapeSelect("landscape");
        },

        // Common function to form to_ALand dataset from SAP Demo EC and Landscape
        onDemoEcLandscapeSelect: function (bindingProperty) {
            var that = this;
            this.dataChange = true;
            var oTemparr = this.RapidRegDataModel.getProperty("/to_ALand");
            var sapDemoEc = this.RapidRegUIModel.getProperty("/" + bindingProperty);
            var ActivityGuid = this.RapidRegDataModel.getProperty("/ActivityGuid");
            sapDemoEc.filter(function (parentObj) {
                parentObj[bindingProperty].filter(function (childObj) {
                    var index = that.fnCheckDuplicateDemoLandscapes(childObj, oTemparr);
                    if (index >= 0 && childObj.selected) { } else if (index >= 0 && !childObj.selected) {
                        oTemparr.splice(index, 1);
                        childObj.prevSelected = childObj.selected;
                    } else {
                        if (childObj.selected) {
                            if (childObj.LandscapeId === "00000") {
                                var indicies = that.fnFindSameArrayObject(childObj, bindingProperty);
                                if (indicies.length > 0) {
                                    var oArray = that.RapidRegUIModel.getProperty("/" + bindingProperty);
                                    oArray[indicies[0]][bindingProperty][indicies[1]].selected = true;
                                }
                                childObj.selected = false;
                            } else {
                                var oTempObj = {
                                    "ActivityGuid": ActivityGuid,
                                    "LandsId": childObj.LandsId,
                                    "LandDescription": childObj.LandDescription,
                                    "Location": childObj.Location,
                                    "Ltype": childObj.Ltype,
                                    "Product": childObj.Product,
                                    "LTypeDescription": childObj.LTypeDescription,
                                    "OperationStatus": childObj.OperationStatus,
                                    "LandscapeId": childObj.LandscapeId
                                };
                                oTemparr.push(oTempObj);
                                childObj.prevSelected = childObj.selected;
                            }
                        }
                    }
                });
            });
            if (oTemparr && oTemparr.length) {
                var demoEnvCheckbox = sap.ui.core.Fragment.byId(this.RapidRegDialogId, "demoEnvironmentCheckBox");
                demoEnvCheckbox.setSelected(false);
            }
            oTemparr.forEach(each => each.ActivityGuid = ActivityGuid);
            this.RapidRegDataModel.setProperty("/to_ALand", oTemparr);
            if (this.oLandscapeDialog) {
                this.oLandscapeDialog.close();
            }
        },

        // Function to find if duplicate object is present in the array
        fnCheckDuplicateDemoLandscapes: function (object, Array) {
            var index;
            Array.find(function (obj, i) {
                if (obj.LandsId === object.LandsId && obj.LandDescription === object.LandDescription && obj.LandscapeId === object.LandscapeId) {
                    index = i;
                }
            });
            return index;
        },

        // Function to find RecentSel obj in other array.
        fnFindSameArrayObject: function (childObj, bindingProperty) {
            var pIndex,
                cIndex;
            var oArray = this.RapidRegUIModel.getProperty("/" + bindingProperty);
            oArray.filter(function (pObject, pI) {
                pObject[bindingProperty].find(function (cObject, cI) {
                    if (childObj.LandsId === cObject.LandsId && childObj.LandDescription === cObject.LandDescription && childObj.LandscapeId !== cObject.LandscapeId) {
                        pIndex = pI;
                        cIndex = cI;
                    }
                });
            });
            return [pIndex, cIndex];
        },

        onSelectLandScapesCheckBox: function (oEvent) { // oEvent.getSource().setValueState("None");
            let landscapes = this.RapidRegDataModel.getProperty("/to_ALand");
            if (landscapes.length !== 0) {
                oEvent.getSource().setSelected(false);
                MessageToast.show("Demo environment(s) have already been selected.")
            }
        },

        handleRapidRegStatusChange: function (oEvent) {
            var sKey = oEvent.getSource().getSelectedKey();
            let oActvt = this.RapidRegDataModel.getData();
            if (sKey === "12" || sKey === "14") {
                this.onCompletionDateEdit(oActvt, undefined, sKey, false);
            }
            if (!sKey) {
                this.RapidRegDataModel.setProperty("/Status", "01");
            }
        },

        onCompletionDateEdit: function (oActv, oSource, key, isEdit) {
            let message,
                message2;
            if (key === '12') {
                message = "Completed";
                message2 = "Completion Date";
            } else {
                message = "Validated";
                message2 = "Validation Date";
            }

            this.RapidRegUIModel.setProperty("/MessageStatus", message);
            this.RapidRegUIModel.setProperty("/MessageStatusDesc", message2);

            if (!oActv.ActivityId || !oActv.StatusChangedAt) {
                this.RapidRegDataModel.setProperty("/StatusChangedAt", new Date());
            }
            this.RapidRegUIModel.setProperty("/InitialCompDate", oActv.StatusChangedAt);
            if (this.confirmActvtActions) {
                this.confirmActvtActions.destroy();
                this.confirmActvtActions = undefined;
            }
            // if (!this.confirmActvtActions) {
            this.confirmActvtActions = sap.ui.xmlfragment(this.RapidRegDialog.getId() + "_ConfirmStatuDialog", "com.melody.lib.fragments.RapidRegistration.ConfirmActivityAction", this);
            this.RapidRegDialog.getParent().addDependent(this.confirmActvtActions);
            this.confirmActvtActions.setModel(this.i18nModel, "i18n");
            this.confirmActvtActions.setModel(this.RapidRegDataModel, "RapidRegDataModel");
            this.confirmActvtActions.setModel(this.RapidRegUIModel, "RapidRegUIModel");
            // }
            this.confirmActvtActions.open();

        },

        /**
     * @memberOf com.presalescentral.successline.view.SlDetail
     * event triggered in cancel button press of Confirm activity action
     */
        handleCancelConfirmActvtAction: function () {
            let initialDate = this.RapidRegUIModel.getProperty("/InitialCompDate");
            let initialStatus = this.RapidRegUIModel.getProperty("/InitialStatus");
            this.RapidRegDataModel.setProperty("/StatusChangedAt", initialDate);
            this.RapidRegDataModel.setProperty("/Status", (initialStatus === '') ? "01" : initialStatus);
            this.confirmActvtActions.close();
        },
        /**
     * @memberOf com.presalescentral.successline.view.SlDetail
     * event triggered in OK button press of Confirm activity action
     */
        handleOkConfirmActvtAction: function () {
            let initialDate = this.RapidRegUIModel.getProperty("/InitialCompDate");
            let compDate = this.RapidRegDataModel.getProperty("/StatusChangedAt");
            if (compDate === null) {
                compDate = initialDate;
            }
            this.RapidRegDataModel.setProperty("/StatusChangedAt", compDate);
            this.confirmActvtActions.close();
        },

        showLandscapesInfoPopover: function (oEvent) {
            var oButton = oEvent.getSource();
            if (!this.landscapeInfoPopover) {
                this.landscapeInfoPopover = sap.ui.xmlfragment(this.RapidRegDialog.getId() + "_LandscapeInfoPopover", "com.melody.lib.fragments.RapidRegistration.LandcsapeInfoPopover", this);
                this.RapidRegDialog.getParent().addDependent(this.landscapeInfoPopover);
                this.landscapeInfoPopover.setModel(this.i18nModel, "i18n");
            }
            this.landscapeInfoPopover.openBy(oButton);
        },

        // Formatter functions - #217
        // Set Solutions Tree control's checkbox visibility
        formatSolTreeCheckBox: function (MatTblSelectMode, isCheckBoxVisible) {
            var bVal = false;
            if (MatTblSelectMode === "MultiSelect") {
                bVal = isCheckBoxVisible;
            }
            return bVal;
        },

        // Set Solutions Tree control's radiobutton visibility
        formatSolTreeRadioBtn: function (MatTblSelectMode, isRadioBtnVisible) {
            var bVal = false;
            if (MatTblSelectMode === "SingleSelectLeft") {
                bVal = isRadioBtnVisible;
            }
            return bVal;
        },

        // Function to set Checkbox and Radiobutton set set selected from Tree
       fnSetSolCBRBSelected: function (LevelId, L3Id, L4Id, L5Id, LevelCount, isParent) {
            var that = this;
            var bVal = false;
            var oSolTempArr = this.oSolutionsModel.getProperty("/oSolTempArr");
            if (oSolTempArr) {
                oSolTempArr.filter(function (obj, index) {
                    if (obj.L4Id === L4Id && obj.LevelCount === 4 && obj.LevelId === LevelId) {
                        bVal = true;
                        if (that.oSolutionsModel.getProperty("/MatTblSelectMode") === "SingleSelectLeft") {
                            if (obj.ValueState === "Information") {
                                bVal = false;
                            }
                        }
                    }
                    if (obj.L5Id === L5Id && obj.LevelCount === 5 && obj.LevelId === LevelId) {
                        bVal = true;
                    }

                    if (obj.L3Id === L3Id && obj.LevelCount === 3 && obj.LevelId === LevelId) {
                        bVal = true;
                    }


                    // if (
                    //     obj.L3Id === L3Id &&
                    //     (obj.LevelCount === 4 || obj.LevelCount === 5) &&
                    //     obj.LevelId === LevelId
                    // ) {
                    //     bVal = true;
                    //     return true;
                    // }
                });
            }
            return bVal;
        },

        // Function to set Checkbox and Radiobutton set set selected from Table
        fnSetMatCBRBSelected: function (MatId) {
            var bVal = false;
            var oMatTempArr = this.oSolutionsModel.getProperty("/oMatTempArr");
            if (oMatTempArr) {
                oMatTempArr.filter(function (obj, index) {
                    if (obj.MatId === MatId) {
                        bVal = true;
                    }
                });
            }
            return bVal;
        },

        // Function to set valuestate for L4's radiobutton, if L5 is selected
        formatSolTreeRadioBtnValState: function (LevelId, L4Id) {
            var valueState = "None";
            var oSolTempArr = this.oSolutionsModel.getProperty("/oSolTempArr");
            if (oSolTempArr) {
                oSolTempArr.filter(function (obj, index) {
                    if (obj.L4Id === L4Id && obj.LevelCount === 4 && obj.LevelId === LevelId) {
                        valueState = obj.ValueState;
                    }
                });
            }
            return valueState;
        },

        handleRapidRegAddOppSelectbuttonTxt: function (sOppId) {
            var bAddOppSelectFlag = false;
            if (sOppId) {
                var addOpptMultiInput = sap.ui.core.Fragment.byId(this.RapidRegDialogId, "rapidRegAddOpptMultiInput");
                var tokens = addOpptMultiInput.getTokens();
                $.each(tokens, function (index, token) {
                    if (parseInt(token.getText(), 10) === parseInt(sOppId, 10)) {
                        bAddOppSelectFlag = true;
                    }
                });
            }
            if (bAddOppSelectFlag) {
                return "Deselect";
            } else {
                return "Select";
            }
        },

        handleRapidRegAddOppToggleBtnPressed: function (sOppId) {
            var bAddOppSelectFlag = false;
            if (sOppId) {
                var addOpptMultiInput = sap.ui.core.Fragment.byId(this.RapidRegDialogId, "rapidRegAddOpptMultiInput");
                var tokens = addOpptMultiInput.getTokens();
                $.each(tokens, function (index, token) {
                    if (parseInt(token.getText(), 10) === parseInt(sOppId, 10)) {
                        bAddOppSelectFlag = true;
                    }
                });
            }
            if (bAddOppSelectFlag) {
                return bAddOppSelectFlag;
            }
        },

        formatAddOppDate: function (date) {
            var dateFormat = DateFormat.getDateInstance({ style: "medium" });
            if (date && date !== null && date !== "") {
                return dateFormat.format(new Date(date));
            } else {
                return null;
            }
        },

        formatStatus: function (StatusId) {
            const oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
            let aOppStatus = oStorage.get("pcOppStatusMasterMapCPI") || oStorage.get("pcOppStatusMasterMap");
            return aOppStatus?.[StatusId]?.VALUE || "";
        },

        // START: Include previously excluded registration fields in the reg dialog #634
        onToggleMoreFields: function () {
            const oMoreBox = sap.ui.core.Fragment.byId(this.RapidRegDialogId, "moreFieldsBox");
            const oButton = sap.ui.core.Fragment.byId(this.RapidRegDialogId, "toggleMoreBtn");
            const bShow = !oMoreBox.hasStyleClass("moreFieldsVisible");
            if (bShow) {
                oMoreBox.setVisible(true);
                this.RapidRegDialog.setContentWidth("60%");
                oMoreBox.removeStyleClass("moreFieldsHidden");
                oMoreBox.addStyleClass("moreFieldsVisible");
                // Optional:Trigger child staggered animations
                setTimeout(() => {
                    const aFields = oMoreBox.$().find(".staggered-fade-in");
                    aFields.each((index, element) => {
                        $(element).css("animation", "none");
                        element.offsetHeight;
                        $(element).css("animation", "");
                    });
                }, 50);
                oButton.setText("<< Less fields");
            } else {
                oMoreBox.removeStyleClass("moreFieldsVisible");
                oMoreBox.addStyleClass("moreFieldsHidden");
                oButton.setText("More fields >>");
                // Wait for animation to complete before hiding element
                setTimeout(() => {
                    this.RapidRegDialog.setContentWidth("34%")
                    oMoreBox.setVisible(false);
                    oMoreBox.removeStyleClass("moreFieldsHidden"); // cleanup
                }, 200);
            }
        },

        // Activity Risk
        fnFormatActRiskBtnType: function (RiskAssessmentId) {
            const typeMap = {
                "01": sap.m.ButtonType.Reject,
                "02": sap.m.ButtonType.Attention,
                "03": sap.m.ButtonType.Accept
            };
            return typeMap[RiskAssessmentId] || sap.m.ButtonType.Transparent;
        },

        // Function to set toggle between Risk Assement Toggle button
        fnSetRiskAssesmenBtn: function (selectedRAId, currentRAId) {
            return selectedRAId === currentRAId;
        },

        toInteger: function (str) {
            return str ? parseInt(str, 10) : undefined;
        },

        onSelectRiskAssesment: function (oEvent) {
            const oSource = oEvent?.getSource();
            if (oSource?.getPressed()) {
                const sSelectedKey = oSource.getBindingContext("RapidRegUIModel")?.getProperty("ra_id");
                if (sSelectedKey) {
                    this.RapidRegDataModel.setProperty("/RiskAssessId", sSelectedKey);
                }
            }
        },

        openRiskInfoPopover: function (oEvent) {
            const oSource = oEvent?.getSource();
            if (!this.oRiskInfoPopover) {
                const sFragmentId = this.RapidRegDialog?.getId?.() + "_RiskCommentInfoPopover";
                this.oRiskInfoPopover = sap.ui.xmlfragment(sFragmentId, "com.melody.lib.fragments.RapidRegistration.RiskInfoPopover", this);
                this.RapidRegDialog?.getParent()?.addDependent?.(this.oRiskInfoPopover);
                this.oRiskInfoPopover.setModel(this.i18nModel, "i18n");
                this.oRiskInfoPopover.setModel(this.RapidRegUIModel, "RapidRegUIModel");
                var sUrl = this.RapidRegUIModel.getProperty("/oConstantsMap")?.get("0108")?.field_value || "";
                let riskInfoSupportTxt = this.i18nModel.getProperty("riskInfoSupportTxt");
                riskInfoSupportTxt = riskInfoSupportTxt.replace("{{url}}", sUrl);
                this.RapidRegUIModel.setProperty("/RiskInfoSupportTxt", riskInfoSupportTxt);
            }
            this.oRiskInfoPopover.openBy(oSource);
        },

        closeRiskInfoPopover: function () {
            this.oRiskInfoPopover.close();
        },

        openRiskCommentInfoPopover: function (oEvent) {
            const oSource = oEvent?.getSource();
            if (!this.oRiskCommentInfoPopover) {
                const sFragmentId = this.RapidRegDialog?.getId() + "_RiskCommentInfoPopover";
                this.oRiskCommentInfoPopover = sap.ui.xmlfragment(sFragmentId, "com.melody.lib.fragments.RapidRegistration.RiskCommentsInfo", this);
                this.RapidRegDialog?.getParent?.()?.addDependent?.(this.oRiskCommentInfoPopover);
                this.oRiskCommentInfoPopover.setModel(this.i18nModel, "i18n");
            }
            this.oRiskCommentInfoPopover.openBy(oSource);
        },

        closeRiskCommentInfoPopover: function () {
            this.oRiskCommentInfoPopover.close();
        },

        // Activity Lead
        openActivityLeadDialog: function () {
            const dialogId = this.RapidRegDialog?.getId();
            if (!this.oActLeadDialog) {
                const fragmentId = `${dialogId}_ActLeadDialog`;
                this.oActLeadDialog = sap.ui.xmlfragment(fragmentId, "com.melody.lib.fragments.RapidRegistration.ActivityLead", this);
                this.RapidRegDialog.getParent().addDependent(this.oActLeadDialog);
                this.oActLeadDialog.setModel(this.i18nModel, "i18n");
                this.oActLeadDialog.setModel(this.RapidRegUIModel, "RapidRegUIModel");
                this.oActLeadDialog.setModel(this.RapidRegDataModel, "RapidRegDataModel");
                this.oActLeadDialog.setModel(this.oUserModel, "UserModel");
                this.ActLeadDialogId = fragmentId;
            }
            this.resetActLeadData();
            this.oActLeadDialog.open();
        },

        closeActivityLeadDialog: function () {
            this.oActLeadDialog.close();
        },

        resetActLeadData: function () {
            const fragmentById = (id) => sap.ui.core.Fragment.byId(this.ActLeadDialogId, id);
            const actLeadITB = fragmentById("ITB_LEAD_USER_SELECT");
            const leadUserListCrm = fragmentById("Lead_UserListSingle_CRM");
            const sActvtAsstdId = this.RapidRegDataModel.getProperty("/ActvtAsstdID");
            const itbItems = actLeadITB?.getItems();
            const firstItem = itbItems?.[0];

            if (sActvtAsstdId === "502") {
                firstItem?.setVisible(true);
                actLeadITB?.setSelectedKey("OPPORTUNITY_LEAD");
                leadUserListCrm?.getBinding("items")?.filter([]);
            } else {
                firstItem?.setVisible(false);
            }
            this.oUserModel.setProperty("/OreActLeadUsers", []);
            this.onITBSelectLeadUser();
        },

        onITBSelectLeadUser: function (oEvent) {
            const getById = (id) => sap.ui.core.Fragment.byId(this.ActLeadDialogId, id);

            const actLeadITB = getById("ITB_LEAD_USER_SELECT");
            const crmLeadSearchBox = getById("crm_leadSearchSingle_opp");
            const oreLeadSearchBox = getById("crm_leadSearchSingle_ore");
            const crmLeadUserList = getById("Lead_UserListSingle_CRM");
            const oreLeadUserList = getById("Lead_UserListSingle_ORE");

            const selectedKey = actLeadITB?.getSelectedKey();
            const isFromOppTab = selectedKey === "OPPORTUNITY_LEAD";

            crmLeadSearchBox?.setVisible(isFromOppTab).setValue("");
            oreLeadSearchBox?.setVisible(!isFromOppTab).setValue("");

            crmLeadUserList?.setVisible(isFromOppTab);
            oreLeadUserList?.setVisible(!isFromOppTab);
        },

        onCRMSearchLeadUser: function (oEvent) {
            const sQuery = oEvent?.getParameter("query")?.trim();
            if (!sQuery || sQuery.length <= 2) {
                MessageToast.show(this.i18nModel.getProperty("userSearchLength"));
                return;
            }
            const aFilter = new Filter({
                filters: [
                    new Filter("Name", "Contains", sQuery), new Filter("UserId", "Contains", sQuery), new Filter("EmailId", "Contains", sQuery)
                ], and: false
            });
            const leadUserList = sap.ui.core.Fragment.byId(this.ActLeadDialogId, "Lead_UserListSingle_CRM");
            leadUserList?.getBinding("items").filter(aFilter);
        }, onOreSearchLeadUser: function (oEvent) {
            const sQuery = oEvent?.getSource().getValue().trim();
            if (!sQuery || sQuery.length <= 2) {
                this.oUserModel.setProperty("/OreActLeadUsers", []);
                MessageToast.show(this.i18nModel.getProperty("userSearchLength"));
                return;
            }
            this.getFilteredActLeadData([], sQuery, false);
        }, getFilteredActLeadData: async function (aOppTeamKeys = [], sQuery = "", isOppTeam = false) {
            const aFilters = [];
            const aMultiFilter = [];
            const sRolempngId = this.RapidRegDataModel.getProperty("/RoleMpngID");
            if (sRolempngId) {
                aFilters.push(new Filter("RolempngId", "EQ", sRolempngId));
            }
            if (Array.isArray(aOppTeamKeys) && aOppTeamKeys.length > 0) {
                aOppTeamKeys.forEach(userId => {
                    aMultiFilter.push(new Filter("UserId", "EQ", userId));
                })

                if (aMultiFilter.length > 0) {
                    aFilters.push(new Filter({ filters: aMultiFilter, and: false }));
                }



            }
            try {
                const aResults = await ActivityService.getActLeadData(aFilters, sQuery);
                const propertyPath = isOppTeam ? "/PresaleActLeadUsers" : "/OreActLeadUsers";
                this.oUserModel.setProperty(propertyPath, aResults);
            } catch (error) {
                console.error("Failed to fetch Activity Lead Data:", error);
            }
        },

        handleLeadUserSelect: function (oEvent) {
            const oSelectedLead = oEvent?.getSource()?.getBindingContext("UserModel")?.getObject();
            this._setLeadUserData(oSelectedLead);
            this.oActLeadDialog.close();
        },

        _setLeadUserData: function (oSelectedLead) {
            const oUserUtilityModel = sap.ui.getCore().getModel("userUtility");
            const oLeadUser = {
                NAME: oSelectedLead?.Name || oUserUtilityModel?.getProperty("/UserName") || "",
                EMAIL: oSelectedLead?.EmailId || oUserUtilityModel?.getProperty("/UserEmail") || "",
                ID: oSelectedLead?.UserId || oUserUtilityModel?.getProperty("/UserId") || ""
            };
            this.RapidRegDataModel.setProperty("/ActivityLeadName", oLeadUser.NAME);
            this.RapidRegDataModel.setProperty("/ActivityLeadEmailId", oLeadUser.EMAIL);
            this.RapidRegDataModel.setProperty("/ActivityLead", oLeadUser.ID);
            this.oUserModel.setProperty("/SelectedLead", oLeadUser);
        },

        // Activity Team
        openActivityTeamDialog: async function () {
            const dialogId = this.RapidRegDialog?.getId();
            if (!this.oActTeamDialog && dialogId) {
                const fragmentId = `${dialogId}_ActTeamDialog`;
                this.oActTeamDialog = sap.ui.xmlfragment(fragmentId, "com.melody.lib.fragments.RapidRegistration.ActivityTeam", this);
                this.RapidRegDialog.getParent()?.addDependent(this.oActTeamDialog);
                this.oActTeamDialog.setModel(this.i18nModel, "i18n");
                this.oActTeamDialog.setModel(this.RapidRegUIModel, "RapidRegUIModel");
                this.oActTeamDialog.setModel(this.RapidRegDataModel, "RapidRegDataModel");
                this.oActTeamDialog.setModel(this.oUserModel, "UserModel");
                this.ActTeamDialogId = fragmentId;
            }
            this.resetActTeamData();
            this.oActTeamDialog.open();
        },

        fetchOpportunitiesTeam: async function () {
            const sOppId = this.RapidRegDataModel.getProperty("/OpportunityNumber");
            if (!sOppId) {
                return;
            }
            try {
                // const oOppData = await OpportunityUtil.getOpportunitiesTeam(sOppId);
                let aOREOppTeam = await OpportunityUtil.getOppTeamWithOREAccess(sOppId);
                // const aOppTeam = oOppData?.data?.PartiesInvolved?.results ?? [];
                const aTeam = aOREOppTeam.filter(user => user.USER_ID && user.EMAIL).map(user => ({
                    ROLE: user.ROLE,
                    ROLE_DESC: user.ROLE_DESCR,
                    ID: user.USER_ID,
                    NAME: user.NAME,
                    PhoneNumber: user.TELEPHONE_NUMBER,
                    MobileNumber: user.MOBILE_NUMBER,
                    EMAIL: user.EMAIL,
                    checked: false
                }));

                this.oUserModel.setProperty("/PresalesTeam", aTeam);

                if (aTeam.length) {
                    const aOppTeamKeys = aTeam.map(user => user.ID);
                    this.getFilteredActLeadData(aOppTeamKeys, "", true);
                }
            } catch (error) {
                console.error("Error fetching opportunity team details:", error);
            }
        },

        resetActTeamData: function () {
            const getById = (id) => sap.ui.core.Fragment.byId(this.ActTeamDialogId, id);
            const actTeamITB = getById("ITB_USER_SELECT");
            const userListCrm = getById("UserListMulti_CRM");
            const userListSap = getById("UserListMulti_SAP");
            actTeamITB?.setSelectedKey("OPPORTUNITY");
            userListCrm?.removeSelections();
            userListSap?.removeSelections();
            this.onCrmUserSearch();
            this.oUserModel.setProperty("/OreUsers", []);
            // const aSelectedUsers = this.oUserModel.getProperty("/SelectedTeam") || [];
            const aOppTeam = this.oUserModel.getProperty("/PresalesTeam") || [];
            aOppTeam.forEach(user => {
                if (this.selectedTeamMap.hasOwnProperty(user.ID)) {
                    user.checked = true;
                } else {
                    user.checked = false;
                }
            });
            this.oUserModel.refresh();
            this.onActTeamITBSelect();
        },

        onActTeamITBSelect: function (oEvent) {
            const getById = (id) => sap.ui.core.Fragment.byId(this.ActTeamDialogId, id);
            const selectedKey = getById("ITB_USER_SELECT")?.getSelectedKey();
            const crmUserSearchBox = getById("crm_userSearchMulti_oppo");
            const oreUserSearchBox = getById("crm_userSearchMulti_sap");
            const crmUserList = getById("UserListMulti_CRM");
            const oreUserList = getById("UserListMulti_SAP");
            const isFromOppTab = selectedKey === "OPPORTUNITY";

            crmUserSearchBox?.setVisible(isFromOppTab)?.setValue?.("");
            oreUserSearchBox?.setVisible(!isFromOppTab)?.setValue?.("");
            crmUserList?.setVisible(isFromOppTab);
            oreUserList?.setVisible(!isFromOppTab);
        },

        onCrmUserSearch: function (oEvent) {
            const sQuery = oEvent?.getParameter("query").trim() || "";
            const oList = sap.ui.core.Fragment.byId(this.ActTeamDialogId, "UserListMulti_CRM");
            const oBinding = oList?.getBinding("items");

            if (!oBinding)
                return;



            if (sQuery.length > 0) {
                const aFilter = new Filter({
                    filters: [
                        new Filter("NAME", "Contains", sQuery),
                        new Filter("ID", "Contains", sQuery)
                    ],
                    and: false
                });
                oBinding.filter(aFilter);
            } else {
                oBinding.filter([]);
            }
        },

        onOreUserSearch: async function (oEvent) {
            const sQuery = oEvent?.getParameter("query");
            this.handleUserSearch(sQuery, "UserListMulti_SAP");
        },

        handleUserSearch: async function (sQuery, sListId) {
            if (!sQuery || sQuery.length <= 2) {
                MessageToast.show(this.i18nModel.getProperty("userSearchLength"));
                return;
            }
            try {
                const aResults = await ActivityService.getOreUsers(sQuery);
                this.oUserModel.setProperty("/OreUsers", aResults);
                const oList = sap.ui.core.Fragment.byId(this.ActTeamDialogId, sListId);
                if (oList) {
                    oList.removeSelections();
                    const oItemsBinding = oList.getBinding("items");
                    oItemsBinding?.refresh();
                }
            } catch (error) {
                console.error("Error fetching Ore Users:", error);
            }
        },

        handleTeamSelection: function (oEvent) {
            const oListItem = oEvent.getParameter("listItem");
            const bSelected = oEvent.getParameter("selected");
            const oBindingContext = oListItem?.getBindingContext("UserModel");

            if (!oBindingContext) return;

            const oSelectedUser = oBindingContext.getObject();

            if (bSelected) {
                if (!this.selectedTeamMap.hasOwnProperty(oSelectedUser.ID)) {
                    oSelectedUser.ROLE = "ZOZOSOAD";
                    this.selectedTeamMap[oSelectedUser.ID] = oSelectedUser;
                } else {
                    MessageToast.show(`${oSelectedUser.NAME} already present.`);
                }
            } else {
                delete this.selectedTeamMap[oSelectedUser.ID];
            }
        },

        handleCRMUserSelectMulti: function (oEvent) {
            const aSelectedUsers = Object.values(this.selectedTeamMap);
            this.oUserModel.setProperty("/SelectedTeam", aSelectedUsers);
            this.RapidRegDataModel.setProperty("/to_ATeam", aSelectedUsers);
            if (this.oActTeamDialog?.isOpen()) {
                this.handleClosedOppTeamSelection(aSelectedUsers);
                this.oActTeamDialog.close();
            }
        },

        handleClosedOppTeamSelection: function (aSelectedUsers) {
            //Activity Registration for “Closed” Opportunities
            var that = this;
            const associationType = this.RapidRegDataModel.getProperty("/ActvtAsstdID");
            const oSelectedOpp = this.RapidRegDataModel.getProperty("/to_AOpportunity")?.[0]?.SelectedOpportunity || {};
            const sOppId = this.RapidRegDataModel.getProperty("/OpportunityNumber");
            var sOppStatus = oSelectedOpp.Status;
            var aOppStatus = ["E0002", "E0004", "E0005"];
            var aOppTeam = oSelectedOpp.opportunityTeamData || [];
            let isNonVATUser = aSelectedUsers.some(user =>
                !aOppTeam.some(opp => opp.ID === user.ID)
            );
            if (aSelectedUsers.length && isNonVATUser && (aOppStatus.indexOf(sOppStatus) !== -1 || (associationType === 1 && !sOppId))) {
                this.RapidRegUIModel.setProperty("/RestrictVATTeamSave", true);
                //block vat team saving
                setTimeout(function () {
                    const discOppAddTeamWarningTxt = that.i18nModel.getProperty("discOppAddTeamWarningTxt");
                    sap.m.MessageBox.warning(discOppAddTeamWarningTxt);
                }, 1000);
            }

        },

        onTeamTokenUpdate: function (oEvent) {
            let aRemovedTokens = oEvent?.getParameter("removedTokens") || [];
            if (aRemovedTokens.length > 0) {
                let sRemovedTokenKey = aRemovedTokens[0].getKey();
                if (sRemovedTokenKey && this.selectedTeamMap.hasOwnProperty(sRemovedTokenKey)) {
                    delete this.selectedTeamMap[sRemovedTokenKey];
                }
                this.handleCRMUserSelectMulti();
            }
        },

        closeActivityTeamDialog: function () {
            const aSelectedUsers = this.oUserModel.getProperty("/SelectedTeam") || [];
            this.selectedTeamMap = {};
            aSelectedUsers.forEach(user => {
                if (user?.ID) {
                    this.selectedTeamMap[user.ID] = user;
                }
            });
            this.oActTeamDialog.close();
        },

        // Function to find the team members who don't have opportunity access
        fnGetFindOppActUsers: function (oActPayload) {
            const sAssociateType = this.RapidRegDataModel.getProperty("/ActvtAsstdID");
            const matrixModel = sap.ui.getCore().getModel("matrixModel");
            let bRestrictVATTeamsave = this.RapidRegUIModel.getProperty("/RestrictVATTeamSave");
            if (bRestrictVATTeamsave === undefined) {
                bRestrictVATTeamsave = matrixModel?.getProperty("/RestrictVATTeamSave");
            }
            if (sAssociateType !== "502" || bRestrictVATTeamsave) {
                this._proceedToSaveActivity(false, oActPayload);
                return;
            }
            const sActivityMode = this.RapidRegUIModel.getProperty("/ActCreateStatus");
            const oLeadUser = this.oUserModel.getProperty("/SelectedLead");
            const aPresalesTeam = this.oUserModel.getProperty("/SelectedTeam") || [];
            const aOppTeam = this.oUserModel.getProperty("/PresalesTeam") || [];
            const sOppId = this.RapidRegDataModel.getProperty("/OpportunityNumber");
            const aActTeam = [
                oLeadUser,
                ...aPresalesTeam
            ].filter(Boolean); // remove nulls

            if (!aActTeam.length) {
                this._proceedToSaveActivity(false, oActPayload);
                return;
            }

            const aNoAccessUsers = aActTeam.filter(({ ID: id1, EMAIL: email1 }) => !aOppTeam.some(({ ID: id2, EMAIL: email2 }) => id2?.toLowerCase() === id1?.toLowerCase() && email1?.toLowerCase() === email2?.toLowerCase()));

            if (!aNoAccessUsers.length) {
                this._proceedToSaveActivity(false, oActPayload);
                return;
            }

            const tempArr = [];
            aNoAccessUsers.forEach(user => {
                if (this.fnFindSameUserObject(user, tempArr)) {
                    user.IsDuplicate = true;
                }
                tempArr.push(user);
            });

            const userModel = sap.ui.getCore().getModel("userUtility");
            const sUserId = userModel?.getProperty("/UserId") || "";
            const sUserEmail = userModel?.getProperty("/UserEmail") || "";

            this.resetUserOppoList = aNoAccessUsers.some(user => user.ID === sUserId && user.EMAIL === sUserEmail);

            const oOppoDataModel = sap.ui.getCore().getModel("opportunity");
            const bMetadataLoaded = !(oOppoDataModel?.isMetadataLoadingFailed() ?? true);

            const successCallback = (UIErrorCode, oResponse) => {
                let msg = "";
                if (UIErrorCode === "HARMONY_SERVER_DOWN" || UIErrorCode === "SERVICE_LIMIT_REACHED" || oResponse) {
                    if (UIErrorCode === "SERVICE_LIMIT_REACHED") {
                        msg = "Unable to reach the service to update VAT team members. Do you still want to create Activity?";
                    } else {
                        msg = `Harmony server is unavailable, users cannot be added to Opportunity team. Do you still want to ${sActivityMode === "EDIT_ACTIVITY" ? "save" : "create"
                            } the Activity?`;
                    }

                    if (oResponse?.responseText) {
                        try {
                            const response = JSON.parse(oResponse.responseText);
                            if (response?.error?.code === "Z_CROSS_REPORTING/009") {
                                msg = "You do not have access to this Opportunity. Do you still want to " + (
                                    sActivityMode === "EDIT_ACTIVITY" ? "save" : "create"
                                ) + " the Activity?";
                            } else {
                                msg = oResponse.responseText;
                            }
                        } catch {
                            msg = oResponse.responseText;
                        }

                        if (!msg.endsWith("?")) {
                            msg += sActivityMode === "EDIT_ACTIVITY" ? " Do you still want to save the Activity?" : " Do you still want to create Activity?";
                        }
                    }

                    this.fnRemoveNewlyAddedUsers(msg, oActPayload);
                } else {
                    this._proceedToSaveActivity(this.resetUserOppoList, oActPayload);
                }
            };

            if (bMetadataLoaded) {
                this.IsVATAccessSericeTriggered = true;
                const clonedUsers = jQuery.extend(true, [], tempArr);
                VATTeam.fnProvideOppoAccess(clonedUsers, sOppId, successCallback, true);
            } else {
                this.IsVATAccessSericeTriggered = false;
                this._proceedToSaveActivity(this.resetUserOppoList, oActPayload);
            }
        },

        _proceedToSaveActivity: function (resetUserOppoList, oActPayload) { // this.IsVATAccessSericeTriggered = false;
            if (resetUserOppoList) {
                this.oStorage.put("pcOpportunities", "");
                this.oStorage.put("actOpportunities", "");
            }
            this.fnRemoveCRMRoleProperty();
            this.fnRegisterActivity(oActPayload);
        },

        // Function to find if an same object is present in the array already
        fnFindSameUserObject: function (rObject, oArray) {
            return oArray?.find(obj => obj.ID === rObject.ID && obj.EMAIL === rObject.EMAIL);
        },

        // Function to remove newly added team users, when the harmony server is down,[Oppo VAT team]
        fnRemoveNewlyAddedUsers: function (errorMsg, oActPayload) {
            sap.m.MessageBox.confirm(errorMsg, {
                onClose: (action) => {
                    if (action.toLowerCase() !== "cancel") {
                        this.fnRemoveCRMRoleProperty();
                        this.fnRegisterActivity(oActPayload);
                    }
                }
            });
        },

        // Function to remove CRM Role and Desc field on Success/Error of adding users to VAT team, before activity save
        fnRemoveCRMRoleProperty: function () {
            const teamMembers = this.oUserModel.getProperty("/SelectedTeam") || [];
            const leadUser = this.oUserModel.getProperty("/SelectedLead") || {};
            const propsToRemove = ["CRMRoleId", "CRMRoleDesc", "IsDuplicate"];

            teamMembers.forEach(user => this.fnRemoveObjectProperty(user, ...propsToRemove));
            this.fnRemoveObjectProperty(leadUser, ...propsToRemove);
        },

        // Function to delete specified properties from an object
        fnRemoveObjectProperty: function (object, ...properties) {
            if (!object || typeof object !== 'object')
                return object;

            properties.forEach(prop => delete object[prop]);
            return object;
        },
        // END: Include previously excluded registration fields in the reg dialog #634


        // *********************** Duplicate Activity Registration Opp Based Starts Here **************************************

        /**
         * @function getDuplicateRegistrationInfo 
         * @description function to handle duplicate registration check during create activity in Rapid Registration
         * @author DARSHAN 
         */
        getDuplicateRegistrationInfo: function (activityData, endDate) {

            try {
                //Mandatory check
                if ("ActvtAsstdID" in activityData && !activityData.ActivityId && activityData.ActvtAsstdID === "502") {
                    const duplicateRegData = {
                        accountName: activityData?.to_AOpportunity[0]?.ACCOUNT_NAME || "",
                        oppDescription: activityData?.to_AOpportunity[0]?.description || "",
                        activityTypeDescription: activityData?.ActivityTypeDescription || ""
                    };
                    let oppId = this.RapidRegDataModel.getProperty("/OpportunityNumber") || activityData?.OpportunityNumber || "";
                    let activeWeekDate = this.RapidRegUIModel.getProperty("/WeekDates");
                    let weekendDate = this.RapidRegUIModel.getProperty("/WeekEndDate");
                    const ActivityTypeId = this.RapidRegUIModel.getProperty("/ActivityTypeId") || activityData?.ActivityTypeId || "";
                    const actWeekDate = (endDate) ? endDate : activeWeekDate?.dFirstdate || false;
                    if (actWeekDate && oppId && ActivityTypeId) {
                        const dateOffset = (24 * 60 * 60 * 1000) * 5;
                        const currentDate = new Date(actWeekDate);
                        const currentDate2 = new Date(actWeekDate);
                        const subtTime = currentDate.setTime(currentDate.getTime() - dateOffset);
                        const fromDate = new Date(subtTime);
                        const Addtime = currentDate2.setTime(currentDate2.getTime() + dateOffset);
                        const toDate = new Date(Addtime);
                        const filter = new Filter({
                            filters: [
                                new Filter(
                                    { path: "OpportunityNumber", operator: "EQ", value1: oppId }
                                ),
                                new Filter(
                                    { path: "EndDate", operator: "BT", value1: fromDate, value2: toDate }
                                ),
                                new Filter(
                                    { path: "ActivityTypeId", operator: "EQ", value1: ActivityTypeId }
                                )
                            ],
                            and: true
                        });
                        ActivityService.getDuplicateRegistrations([filter]).then((result = []) => {

                            if (!result.length) {
                                return;
                            }

                            this.loadFragments("duplicateRegDialog", "DuplicateRegistration");
                            this.RapidRegUIModel.setProperty("/duplicateRegData", duplicateRegData);
                            this.RapidRegUIModel.setProperty("/duplicateRegItems", result);
                            this.duplicateRegDialog.open();
                        });
                    }
                }
            } catch (error) {
                console.log("ERROR IN getDuplicateRegistrationInfo :", error)
            }
        },

        //function to perform date formating
        formatDate: function (date) {
            var dateFormat = DateFormat.getDateInstance({ style: "medium" });
            if (date && date !== null && date !== "") {
                if (typeof date === "string") {
                    date = new Date(date);
                }
                return dateFormat.format(date);
            } else {
                return null;
            }
        },

        /**
         * @function handleDuplicateRegDialogClose 
         * @description function to handle duplicate registration cancle button
         * @author DARSHAN 
         */
        handleDuplicateRegDialogClose: function (event) {

            if (this.duplicateRegDialog) {
                this.duplicateRegDialog.close();
                this.duplicateRegDialog.destroy();
                this.duplicateRegDialog = null;
            }

        },

        /**
         * @function handleDemoJustificationRegDialogClose 
         * @description function to handle duplicate registration cancle button
         * @author DARSHAN 
         */
        handleDemoJustificationRegDialogClose: function (event) {
            if (this.demoJustificationRegDialog) {
                this.demoJustificationRegDialog.close();
                this.demoJustificationRegDialog.destroy();
                this.demoJustificationRegDialog = null;
            }

        },

        /**
       * @function handleDuplicateRegAddMe 
       * @description function to handle duplicate registration Add Me button
       * @author DARSHAN 
       */
        handleDuplicateRegAddMe: function (event) {
            try {
                this.RapidRegUIModel.setProperty("/isDuplicateRegDialogBusy", true);
                const duplicateRegItems = this.RapidRegUIModel.getProperty("/duplicateRegItems") || [];
                const userUtilityModel = sap.ui.getCore().getModel("userUtility");
                const btnSource = event.getSource();
                const bindingContext = btnSource?.getBindingContext("RapidRegUIModel") || {};
                const sPath = bindingContext?.getPath() || "";
                if (!sPath) {
                    return;
                }
                const userInfo = {
                    name: userUtilityModel?.getProperty("/UserName") || "",
                    email: userUtilityModel?.getProperty("/UserEmail") || "",
                    id: userUtilityModel?.getProperty("/UserId") || ""
                };
                const index = sPath.split("/")[2];
                const userData = {
                    "ID": userInfo.id,
                    "EMAIL": userInfo.email,
                    "ROLE": "ZOZOSOAD", //Maintained as per activity-form
                    "NAME": userInfo.name,
                    "ActivityGuid": duplicateRegItems[index].ActivityGuid
                };
                this.RapidRegUIModel.setProperty("/duplicateRegData/selectedActvtId", duplicateRegItems[index].ActivityId);
                this.addUsertoOppTeam(userData);
            } catch (error) {
                console.log("ERROR IN handleDuplicateRegAddMe : ", error);
            }
        },

        /**
         * @function handleDuplicateRegPress 
         * @description function to handle Continue with New Registration button
         * @author DARSHAN 
         */
        handleDuplicateRegPress: function (event) {
            this.loadFragments("demoJustificationRegDialog", "DemoJustification");
            this.demoJustificationRegDialog.open();
        },

        /**
         * @function onHandleAddmeInsteadBtn 
         * @description function to handle Add Me Instead button
         * @author DARSHAN 
         */
        onHandleAddmeInsteadBtn: function (event) {
            this.RapidRegUIModel.setProperty("/duplicateRegData/demoJustificationText", "");
            this.RapidRegUIModel.setProperty("/duplicateRegData/demoJustificationTxtValState", "None");
            this.handleDemoJustificationRegDialogClose();
        },

        /**
         * @function onHandleSubmitJustification 
         * @description function to handle Submit Justification button
         * @author DARSHAN 
         */
        onHandleSubmitJustification: function (event) {
            try {
                const justifyComment = this.RapidRegUIModel.getProperty("/duplicateRegData/demoJustificationText");
                if (justifyComment) {
                    const userUtilityModel = sap.ui.getCore().getModel("userUtility");
                    const userInfo = {
                        name: userUtilityModel?.getProperty("/UserName") || "",
                        email: userUtilityModel?.getProperty("/UserEmail") || "",
                        id: userUtilityModel?.getProperty("/UserId") || ""
                    };
                    this.RapidRegUIModel.setProperty("/isJustDialogBusy", true);
                    this.handleDuplicateRegDialogClose();
                    var data = {
                        "ProjectType": "ACT_JUSTF", //Maintained as per implementation in activity-form
                        "CreatedBy": userInfo.id,
                        "CreateUserName": userInfo.name,
                        "CommentDesc": justifyComment
                    };
                    this.postCommentToUtilityServ(data);
                } else {
                    this.RapidRegUIModel.setProperty("/duplicateRegData/demoJustificationTxtValState", "Error");
                }
            } catch (error) {
                console.log("ERROR IN onHandleSubmitJustification : ", error);
            }
        },

        /**
         * @function postCommentToUtilityServ 
         * @description function to post comments to utility servce
         * @author DARSHAN 
         */
        postCommentToUtilityServ: async function (payload) {
            const result = await ActivityService.postCommentToUtilityServ(payload);
            const ActivityGuid = this.RapidRegDataModel.getProperty("/ActivityGuid") || "";
            const ActCommentPayload = {
                "ActivityGuid": ActivityGuid,
                "CommentGuid": result.CommentGuid
            };
            ActivityService.postCommentToActService(ActCommentPayload).then((result) => {
                this.handleDemoJustificationRegDialogClose();
                MessageToast.show("Post commented successfully");
                this.RapidRegUIModel.setProperty("/isJustDialogBusy", false);
                this.resetDuplicateRegData();
            });
        },

        /**
         * @function onHandleJustificationLiveChange 
         * @description function to handle justification input live change
         * @author DARSHAN 
         */
        onHandleJustificationLiveChange: function (event) {
            const value = event.getParameter("value") || "";
            if (value) {
                this.RapidRegUIModel.setProperty("/duplicateRegData/demoJustificationText", value);
                this.RapidRegUIModel.setProperty("/duplicateRegData/demoJustificationTxtValState", "None");
            } else {
                this.RapidRegUIModel.setProperty("/duplicateRegData/demoJustificationTxtValState", "Error");
            }
        },


        /**
         * @function addUsertoOppTeam 
         * @description function to handle Submit Justification button
         * @author DARSHAN 
         */
        addUsertoOppTeam: function (oPayload) {
            ActivityService.addUsertoOppTeam(oPayload).then((result) => {
                this.RapidRegUIModel.setProperty("/isDuplicateRegDialogBusy", false);
                this.handleDuplicateRegDialogClose()
                this.loadFragments("userAdditionRegDialog", "UserAdditionMessage");
                this.userAdditionRegDialog.open();
            });
        },

        /**
         * @function loadFragments 
         * @description function to load fragments
         * @author DARSHAN 
         */
        loadFragments: function (variableName, fragmentName) {
            if (this[variableName]) {
                this[variableName].destroy();
                this[variableName] = null;
            }

            this[variableName] = sap.ui.xmlfragment(`com.melody.lib.fragments.RapidRegistration.${fragmentName}`, this);
            this.RapidRegDialog.getParent()?.addDependent(this[variableName]);
            this[variableName].setModel(this.RapidRegUIModel, "RapidRegUIModel");
            this[variableName].setModel(this.RapidRegDataModel, "RapidRegDataModel");
        },


        /**
         * @function onHandleActivityIdBtn
         * @description function to handle Activity Button Press
         * @author DARSHAN 
         */
        onHandleActivityIdBtn: function (event, activityId = "") {
            if (event) {
                this.onHandleCloseUserAddition();
            }
            const actvtId = (activityId) ? activityId : parseInt(event.getSource().getText());
            this.onPerformCrossAppNavigation(actvtId);
            this.resetDuplicateRegData();
        },


        /**
         * @function onPerformCrossAppNavigation
         * @description function to perform cross app navigation to activity-form based on activity-Id
         * @author DARSHAN 
         */
        onPerformCrossAppNavigation: function (actvtId) {
            const params = {
                ActivityID: actvtId,
            };
            const oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
            const sSemanticObject = "pcactivityform";
            const sSemanticAction = "app";
            const hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                target: {
                    semanticObject: sSemanticObject,
                    action: sSemanticAction
                },
                params: params
            })) || "";
            oCrossAppNavigator.toExternal({
                target: {
                    shellHash: hash
                }
            });
        },

        /**
         * @function onHandleCloseUserAddition
         * @description function to handle closing of user addition dialog
         * @author DARSHAN 
         */
        onHandleCloseUserAddition: function (event = "") {
            if (this.userAdditionRegDialog) {
                this.userAdditionRegDialog.close();
                this.userAdditionRegDialog.destroy();
                this.userAdditionRegDialog = null;
            }

            //If event called
            if (event) {
                const activityId = this.RapidRegUIModel.getProperty("/duplicateRegData/selectedActvtId") || "";
                this.onPerformCrossAppNavigation(activityId);
                this.resetDuplicateRegData();
            }
        },

        /**
         * @function onDialogEscapeHandler
         * @description function to escape handler for dialog
         * @author DARSHAN 
         */
        onDialogEscapeHandler: function (event) {
            event.reject();
        },

        /**
         * @function resetDuplicateRegData
         * @description function to reset all the duplicate registration data
         * @author DARSHAN 
         */
        resetDuplicateRegData: function (event) {
            this.RapidRegUIModel.setProperty("/duplicateRegData", {});
        },

        // *********************** Duplicate Activity Registration Opp Based Ends Here ****************************************

        //Function to select Solution/Opportunity tabs in ITB
        fnSelectSolOppoITBFilter: function (oEvent) {
            var oSolutionsModel = this.oSolutionsModel;
            var oITBFilter = oEvent.getSource().getSelectedKey();
            let solDialogId = this.RapidRegDialog.getId() + "_SolutionHierarchyDialog";
            let levelDropDwnGrid = sap.ui.core.Fragment.byId(solDialogId, "levelDropDwnGrid");
            switch (oITBFilter) {
                case "SOLUTION_HIERARCHY":
                    //this.fnHandleLevel2Change();
                    let solDialogId = this.RapidRegDialog.getId() + "_SolutionHierarchyDialog";
                    var oSolTreeCntrl = sap.ui.core.Fragment.byId(solDialogId, "idSolutionTree");
                    oSolTreeCntrl.getBinding("items").filter([]);
                    this.fnSetSelectedSolMatData();
                    oSolutionsModel.setProperty("/isLevel2DrpDwnVisible", true);
                    oSolutionsModel.setProperty("/ITBSelectedKey", "SOLUTION_HIERARCHY");
                    levelDropDwnGrid.setDefaultSpan("XL6 L6 M12 S12");
                    break;
                case "FROM_OPPORTUNITY":
                    this.fnFilterOppSolHierachyTab();
                    oSolutionsModel.setProperty("/isLevel2DrpDwnVisible", false);
                    oSolutionsModel.setProperty("/ITBSelectedKey", "FROM_OPPORTUNITY");
                    levelDropDwnGrid.setDefaultSpan("XL12 L12 M12 S12");
                    break;
            }
            oSolutionsModel.setProperty("/isDisplayMatSelected", false);
            this.fnShowMaterialInfoTbl("", false);
        },

        //Function to filter Solution Hierarchy tree control
        fnFilterOppSolHierachyTab: function () {
            var aFilters = [];
            var oSolutionsModel = this.oSolutionsModel;
            let solDialogId = this.RapidRegDialog.getId() + "_SolutionHierarchyDialog";
            var oSolTreeCntrl = sap.ui.core.Fragment.byId(solDialogId, "idSolutionTree");
            var OppoMaterials = oSolutionsModel.getProperty("/OppoMaterials");
            if (!OppoMaterials) {
                OppoMaterials = [{
                    "L3Id": "",
                    "L4Id": "",
                    "L5Id": ""
                }];
            }
            for (var i = 0; i < OppoMaterials.length; i++) {
                var oppObj = OppoMaterials[i];
                for (var j = 3; j < 6; j++) {
                    var lId = "L" + j + "Id";
                    var lVal = oppObj[lId];
                    var filter = new Filter(lId, "EQ", lVal);
                    aFilters.push(filter);
                }
            }
            oSolTreeCntrl.getBinding("items").filter(aFilters);
        },

        fnShowMaterialInfoTbl: function (oEvent, bVal) {
            if (oEvent !== "") {
                bVal = oEvent.getSource().getSelected();
            }
            let solDialogId = this.RapidRegDialog.getId() + "_SolutionHierarchyDialog";
            let solHierarchyGrid = sap.ui.core.Fragment.byId(solDialogId, "solHierarchyGrid");
            let levelDropDwnGrid = sap.ui.core.Fragment.byId(solDialogId, "levelDropDwnGrid");

            var oSolTreeCntrl = sap.ui.core.Fragment.byId(this.SolHierarchyDialogId, "idSolutionTree");
            if (bVal) {
                this.solHierarchyDlg.setContentWidth("70%");
                solHierarchyGrid.setDefaultSpan("XL6 L6 M6 S12");
                if (this.oSolutionsModel.getProperty("/ITBSelectedKey") === "SOLUTION_HIERARCHY") {
                    levelDropDwnGrid.setDefaultSpan("XL6 L4 M12 S12");
                }
            } else {
                this.solHierarchyDlg.setContentWidth("43%");
                solHierarchyGrid.setDefaultSpan("XL12 L12 M12 S12");
                if (this.oSolutionsModel.getProperty("/ITBSelectedKey") === "SOLUTION_HIERARCHY") {
                    levelDropDwnGrid.setDefaultSpan("XL6 L6 M12 S12");
                }
            }
            this.oSolutionsModel.setProperty("/isMatTblVisible", bVal);
            this.fnSetSelectedSolMatData();
            this.oSolutionsModel.refresh();
        },
        //function to search solution areas in solution area value help dialog in rapid registration
        onSearchSolutions: function (oEvent) {
            let sQuery = "";
            if (oEvent) {
                sQuery = oEvent.getSource().getValue().trim();
            }
            var solTree = sap.ui.core.Fragment.byId(this.SolHierarchyDialogId, "idSolutionTree");
            const allFilter = [];
            if (sQuery && sQuery.length > 0) {
                const oFilter1 = new sap.ui.model.Filter("LevelDesc", sap.ui.model.FilterOperator.Contains, sQuery);
                allFilter.push(oFilter1);
            }
            solTree.getBinding("items").filter(allFilter);
            if (sQuery) {
                solTree.expandToLevel(sQuery ? 99 : 0);
            } else {
                solTree.collapseAll();
            }
        },


        //Function to set solutions for a selected opportunity
        fnSetDefaultOppoSoutions: function (ActivityData) {

            var oTempArr = [];
            var oSelectedSolutions = {};
            var oSolutionsModel = this.oSolutionsModel;
            var to_ATaxonomy = oSolutionsModel.getProperty("/OppoMaterials") || [];           
            var SelLvlHierarchy = oSolutionsModel.getProperty("/SelectedLevelHierarchy") || [];
            if (!to_ATaxonomy || to_ATaxonomy[0] === 'E' || ActivityData.FormLayoutId === "") {
                to_ATaxonomy = [];
            } else if ("FormLayoutId" in ActivityData && ActivityData.FormLayoutId === "00001") {
                // to_ATaxonomy.filter(function (obj) {
                //     obj.LevelCount = obj.L5Id ? 5 : 4;
                //     obj.LevelId = obj.L5Id ? obj.L5Id : L4Id;
                //     obj.LevelDesc = obj.L5Desc ? obj.L5Desc : L4Desc;
                // });
                to_ATaxonomy.forEach(function (obj) {
                    if (obj.L5Id) {
                        obj.LevelCount = 5;
                        obj.LevelId = obj.L5Id;
                        obj.LevelDesc = obj.L5Desc;
                    } else if (obj.L4Id) {
                        obj.LevelCount = 4;
                        obj.LevelId = obj.L4Id;
                        obj.LevelDesc = obj.L4Desc;
                    } else if (obj.L3Id) {
                        obj.LevelCount = 3;
                        obj.LevelId = obj.L3Id;
                        obj.LevelDesc = obj.L3Desc;
                    }
                });



                to_ATaxonomy = to_ATaxonomy.reduce((unique, o) => {
                    if (!unique.some(obj => obj.LevelId === o.LevelId)) {
                        unique.push(o);
                    }
                    return unique;
                }, []);
                oSolutionsModel.setProperty("/OppoMaterials", to_ATaxonomy);
                // to_ATaxonomy.filter(function (obj) {
                //     SelLvlHierarchy.find(function (l3Obj, l3Index) {
                //         l3Obj.Levels.find(function (l4Obj, l4Index) {
                //             var bVal = false;
                //             if (l4Obj["LevelCount"] === obj["LevelCount"]) {
                //                 if (l4Obj["L4Id"] === obj["LevelId"]) {
                //                     l4Obj.isSelected = true;
                //                     l4Obj.isParent = true;
                //                     oTempArr.push(l4Obj);
                //                 } else {
                //                     l4Obj.isSelected = false;
                //                 }
                //             } else {
                //                 l4Obj.Levels.find(function (l5Obj, l5Index) {
                //                     if (l5Obj["LevelCount"] === obj["LevelCount"] && l5Obj["L5Id"] === obj["LevelId"]) {
                //                         l5Obj.isSelected = true;
                //                         bVal = true;
                //                         oTempArr.push(l5Obj);
                //                     } else {
                //                         l5Obj.isSelected = false;
                //                     }
                //                 })
                //                 l4Obj.isSelected = bVal;
                //                 if (bVal) {
                //                     l4Obj.isParent = true;
                //                     oTempArr.push(l4Obj);
                //                 }
                //             }
                //         })
                //     });
                // })




                oSelectedSolutions = this._updateDefaultSolutionHierarchy(to_ATaxonomy, SelLvlHierarchy)


            }
            oSolutionsModel.setProperty("/oSolTempArr", oSelectedSolutions.oTempArr ?? []);
            oSolutionsModel.setProperty("/SelectedLevelHierarchy", SelLvlHierarchy);
            const tempDisplayTokens = oSolutionsModel.getProperty("/DisplayTokens");
            var displayTokens = this.fnGetDisplayTokens(to_ATaxonomy);
            if (tempDisplayTokens?.length) {
                tempDisplayTokens.forEach(item => {
                    const exists = displayTokens.some(
                        token => token.LevelId === item.LevelId
                    );

                    if (!exists) {
                        displayTokens.push(item);
                    }
                });
            }
            oSolutionsModel.setProperty("/SolTokens", displayTokens);
            oSolutionsModel.setProperty("/DisplayTokens", displayTokens);
            oSolutionsModel.setProperty("/to_ATaxonomy", to_ATaxonomy);
            this.fnSetSelectedSolutions();
            this.fnFormOppoSolTempArr(to_ATaxonomy);
            oSolutionsModel.refresh(true);
        },

      _updateDefaultSolutionHierarchy: function (aTaxonomy, SelSolLvlHierarchy) {
    var oTempArr = [];

    aTaxonomy.forEach(function (obj) {
        SelSolLvlHierarchy.forEach(function (l2Obj) {

            // L3 DEFAULT
            if (obj.LevelCount === 3) {
                l2Obj.Levels.forEach(function (l3Obj) {
                    if (l3Obj.L3Id === obj.LevelId) {
                        l3Obj.isSelected = true;
                        l3Obj.isParent = false; // token
                        oTempArr.push(l3Obj);

                        l2Obj.isSelected = true;
                        l2Obj.isParent = true;
                        oTempArr.push(l2Obj);
                    }
                });
            }

            // L4 DEFAULT
            if (obj.LevelCount === 4) {
                l2Obj.Levels.forEach(function (l3Obj) {
                    l3Obj.Levels.forEach(function (l4Obj) {
                        if (l4Obj.L4Id === obj.LevelId) {
                            l4Obj.isSelected = true;
                            l4Obj.isParent = false; // token
                            oTempArr.push(l4Obj);

                            l3Obj.isSelected = true;
                            l3Obj.isParent = true;
                            oTempArr.push(l3Obj);

                            l2Obj.isSelected = true;
                            l2Obj.isParent = true;
                            oTempArr.push(l2Obj);
                        }
                    });
                });
            }

            //  L5 DEFAULT
            if (obj.LevelCount === 5) {
                l2Obj.Levels.forEach(function (l3Obj) {
                    l3Obj.Levels.forEach(function (l4Obj) {
                        l4Obj.Levels.forEach(function (l5Obj) {
                            if (l5Obj.L5Id === obj.LevelId) {
                                // L5 token
                                l5Obj.isSelected = true;
                                l5Obj.isParent = false;
                                oTempArr.push(l5Obj);

                                // parents only
                                l4Obj.isSelected = true;
                                l4Obj.isParent = true;
                                oTempArr.push(l4Obj);

                                l3Obj.isSelected = true;
                                l3Obj.isParent = true;
                                oTempArr.push(l3Obj);

                                l2Obj.isSelected = true;
                                l2Obj.isParent = true;
                                oTempArr.push(l2Obj);
                            }
                        });
                    });
                });
            }
        });
    });

    return {
        SelSolLvlHierarchy,
        oTempArr
    };
},




        //function to update Selected Solution Hierarchy on Edit/Default Solutions

        _updateSolutionHierarchy: function (aTaxonomy, SelSolLvlHierarchy) {
            var oTempArr = [];
            aTaxonomy.forEach(function (obj) {
                SelSolLvlHierarchy.forEach(function (l2Obj) {
                    let l2Matched = false;

                    // L2 match
                    if (obj.LevelCount === 2 && l2Obj.L2Id === obj.LevelId) {
                        l2Obj.isSelected = true;
                        l2Obj.isParent = true;
                        l2Matched = true;
                        oTempArr.push(l2Obj);
                    }

                    l2Obj.Levels.forEach(function (l3Obj) {
                        let l3Matched = false;

                        // L3 match
                        if (obj.LevelCount === 3 && l3Obj.L3Id === obj.LevelId) {
                            l3Obj.isSelected = true;
                            l3Obj.isParent = true;
                            l3Matched = true;
                            l2Matched = true;
                            oTempArr.push(l3Obj);
                        }

                        l3Obj.Levels.forEach(function (l4Obj) {
                            let l4Matched = false;

                            // L4 match
                            if (obj.LevelCount === 4 && l4Obj.L4Id === obj.LevelId) {
                                l4Obj.isSelected = true;
                                l4Obj.isParent = true;
                                l4Matched = true;
                                l3Matched = true;
                                l2Matched = true;
                                oTempArr.push(l4Obj);
                            }

                            // 🔥 ONLY touch L5 when LevelCount === 5
                            if (obj.LevelCount === 5) {
                                l4Obj.Levels.forEach(function (l5Obj) {
                                    if (l5Obj.L5Id === obj.LevelId) {
                                        l5Obj.isSelected = true;
                                        l4Matched = true;
                                        l3Matched = true;
                                        l2Matched = true;
                                        oTempArr.push(l5Obj);
                                    }
                                });
                            }

                            if (l4Matched) {
                                l4Obj.isSelected = true;
                                l4Obj.isParent = true;
                                oTempArr.push(l4Obj);
                            }
                        });

                        if (l3Matched) {
                            l3Obj.isSelected = true;
                            l3Obj.isParent = true;
                            oTempArr.push(l3Obj);
                        }
                    });

                    if (l2Matched) {
                        l2Obj.isSelected = true;
                        l2Obj.isParent = true;
                        oTempArr.push(l2Obj);
                    }
                });
            });
            return {
                SelSolLvlHierarchy,
                oTempArr
            };
        },

        //Function to handle warning icon press of solution hirarchy field
        onDisplayOldSolMsg: function (oEvent) {
            const btnSource = oEvent.getSource();
            const dialogId = this.RapidRegDialog?.getId();
            this.loadFragments("oldSolutionMsgPopover", "inactiveSolMsg");
            this["oldSolutionMsgPopover"].openBy(btnSource);
        },

        //Function to fetch solution hirarchy details during Edit case
        getActDetailAddSolution: async function (ActivityData) {
            let activeSol = [];
            let sInactiveMsg = "";
            const RapidRegUIModel = this.RapidRegUIModel;
            const oSolutionsModel = this.oSolutionsModel;
            let isSolutionFieldVisible = RapidRegUIModel.getProperty("/SelectedLayout/AdditionalSolutions/Visible") ?? "TRY_AGAIN";
            if (!("ActivityGuid" in ActivityData && ActivityData["ActivityGuid"])) {
                RapidRegUIModel.setProperty("/OldSolutionWarningMsg", sInactiveMsg);
                RapidRegUIModel.setProperty("/oldSolutionWarningIcon", false);
                return;
            }

            //Check for the solution hirarchy field visiblity
            if (typeof isSolutionFieldVisible === "string" && isSolutionFieldVisible === "TRY_AGAIN") {
                setTimeout(() => {
                    this.getActDetailAddSolution(ActivityData);
                }, 500);
                return;
            }
            const { data } = await ActivityService.getActDetailAddSolution(ActivityData["ActivityGuid"]);
            let solutionData = data.results || [];

            let aOldSolution = [];
            solutionData.filter(function (item, index, array) {
                if (!item.OperationStatus) {
                    aOldSolution.push(item.SolutionDesc);
                } else {
                    activeSol.push(item);
                }
            });
            // oSolutionsModel.setProperty("/to_ASol", activeSol);
            RapidRegUIModel.setProperty("/to_ASol", activeSol);

            if (isSolutionFieldVisible) {
                const tempLevel2Key = this.oSolutionsModel.getProperty("/TempLevel2Key") || "";
                if (aOldSolution.length) {
                    if (aOldSolution.length) {
                        sInactiveMsg = aOldSolution.join(", ") + "  are inactive now.";
                    } else {
                        sInactiveMsg = aOldSolution.join(", ") + "  is inactive now.";
                    }
                    //If the Level2Id is old then set the new Level2Id. //TODO Verify this fix
                    this.oSolutionsModel.setProperty("/Level2Key", tempLevel2Key);
                    RapidRegUIModel.setProperty("/aOldSol", aOldSolution);
                    RapidRegUIModel.setProperty("/OldSolutionWarningMsg", sInactiveMsg);
                    RapidRegUIModel.setProperty("/oldSolutionWarningIcon", true);
                } else {
                    RapidRegUIModel.setProperty("/aOldSol", []);
                    RapidRegUIModel.setProperty("/OldSolutionWarningMsg", sInactiveMsg);
                    RapidRegUIModel.setProperty("/oldSolutionWarningIcon", false);
                }
            } else {
                RapidRegUIModel.setProperty("/aOldSol", []);
                RapidRegUIModel.setProperty("/OldSolutionWarningMsg", sInactiveMsg);
                RapidRegUIModel.setProperty("/oldSolutionWarningIcon", false);
            }
        },
    };

    var oRapidRegistration = Control.extend("com.melody.lib.controls.RapidRegistration.RapidRegistration", {
        oDialogController: oDialogController,
        metadata: {
            properties: {
                text: {
                    type: "string",
                    defaultValue: ""
                },
                icon: {
                    type: "sap.ui.core.URI",
                    group: "Appearance",
                    defaultValue: ""
                },
                type: {
                    type: "sap.m.ButtonType",
                    group: "Appearance",
                    defaultValue: "Default"
                },
                activityId: {
                    type: "string",
                    defaultValue: ""
                },
                activityData: {
                    type: "object",
                    defaultValue: null
                },
                enabled: {
                    type: "boolean",
                    defaultValue: true
                },
                activityContextPath: {
                    type: "string",
                    defaultValue: ""
                },
                tooltip: {
                    type: "string",
                    defaultValue: ""
                }
            },
            events: {
                selectedActivity: {
                    "contextPath": {
                        type: "string"
                    },
                    "activityData": {
                        type: "object"
                    }
                },
                press: {}
            },
            aggregations: {
                _button: {
                    type: "sap.m.Button",
                    multiple: false,
                    visibility: "hidden"
                }
            }
        },

        setText: function (text) {
            var sText = (text) ? text : "";
            this.setProperty("text", sText);
            this.getAggregation("_button").setText(sText);
        },

        setIcon: function (icon) {
            var sIcon = (icon) ? icon : "";
            this.setProperty("icon", sIcon);
            this.getAggregation("_button").setIcon(sIcon);
        },

        setType: function (type) {
            var sType = (type) ? type : "";
            this.setProperty("type", sType);
            this.getAggregation("_button").setType(sType);
        },

        setActivityId: function (activityId) {
            this.setProperty("activityId", activityId ? activityId : "");
        },

        setActivityId: function (activityId) {
            this.setProperty("activityId", activityId ? activityId : "");
        },

        setEnabled: function (enabled) {
            this.setProperty("enabled", enabled ? true : false);
        },

        setTooltip: function (text) {
            var sText = (text) ? text : "";
            this.setProperty("tooltip", sText);
            this.getAggregation("_button").setTooltip(sText);
        },

        init: function () {
            const that = this;
            let oButton = new sap.m.Button(this.getId() + "-button", {
                text: that.getText(),
                press: that._RegistrationBtnPress.bind(this)
            });
            this.setAggregation("_button", oButton);
        },

        _RegistrationBtnPress: function (oEvent) {
            this.firePress({ source: this, event: oEvent });
        },

        fnOpenRapidRegDialog: function (oEvent, oWeekDates) {
            oDialogController.fnLoadRapidRegDialog(oEvent, oWeekDates);
        }

    });

    return oRapidRegistration;

},
    /* bExport= */
    true);
