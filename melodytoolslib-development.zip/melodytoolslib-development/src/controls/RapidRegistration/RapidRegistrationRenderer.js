/*!
 * ${copyright}
 */

sap.ui.define(['jquery.sap.global'],

	function (jQuery) {
		"use strict";

		/**
		 * RapidRegistration renderer.
		 * @namespace
		 */
		var RapidRegistrationRenderer = {};

		/**
		 * Renders the HTML for the given control, using the provided
		 * {@link sap.ui.core.RenderManager}.
		 *
		 * @param {sap.ui.core.RenderManager} oRm
		 *            the RenderManager that can be used for writing to
		 *            the Render-Output-Buffer
		 * @param Control oControl
		 *            the control to be rendered
		 */
		RapidRegistrationRenderer.render = function (oRm, oControl) {
			oRm.write("<div");
			oRm.writeClasses(oControl);
			oRm.writeControlData(oControl);
			oRm.write(">");
			oRm.renderControl(oControl.getAggregation("_button"));
			oRm.write("</div>");
		};

		return RapidRegistrationRenderer;

	}, /* bExport= */ true);