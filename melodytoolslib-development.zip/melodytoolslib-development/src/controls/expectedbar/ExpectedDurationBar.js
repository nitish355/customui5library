/*!
 * ${copyright}
 */
// Provides control com.melody.lib.controls.ExpectedDurationBar.
sap.ui.define(["jquery.sap.global", "sap/ui/core/Control", "com/melody/lib/util/mtr/MTRModels"],
	function (jQuery, Control, MTRModels) {
		"use strict";
		/**
		 * Constructor for a ExpectedDurationBar control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends sap.ui.core.Control
		 *
		 * @author SAP SE
		 * @version ${version}
		 *
		 * @constructor
		 * @private
		 * @alias mtr.ext.controls.Example
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */
		var ExpectedDurationBar = Control.extend("com.melody.lib.controls.expectedbar.ExpectedDurationBar", {
			metadata: {
				properties: {
					/**
					 * width
					 */
					width: {
                        type: "sap.ui.core.CSSSize",
                        defaultValue: "100%"
                    },
                    
                    /**
					 * height
					 */
                    height: {
                        type: "sap.ui.core.CSSSize",
                        defaultValue: "auto"
                    },
                    
                    /**
					 * height
					 */
                    expected: {
                        defaultValue: 0
                    },
                    
                    /**
					 * height
					 */
                    submitted: {
                        defaultValue: 0
                    },
                    
                    /**
					 * height
					 */
                    saved: {
                        defaultValue: 0
                    },
                    
                    /**
					 * unit
					 */
                    unit: {
                        type: "string",
                        defaultValue: "H"
                    }
				},
				
				aggregations: {
					_statusIndicator: {
						type: "sap.m.HBox",
						multiple: false,
						visibility: "hidden"
					}
				},
				
				events: {
					/**
					 * Event is fired when the user clicks on the control.
					 */
					press: {}

				}
			},
			
			countDecimal: function (value) {
			    if(isNaN(value) || Math.floor(value) === value) return 0;
			    return value.toString().split(".")[1].length || 0; 
			},
			
			setUnit: function (sValue) {
				var oResourceBundle = this.getModel("i18n").getResourceBundle();
				this.setProperty("unit", sValue);
				var sUnit = (sValue === "H") ? oResourceBundle.getText("expectedBarHoursUnit") : oResourceBundle.getText("expectedBarDaysUnit");
				this.getAggregation("_statusIndicator").getAggregation("items")[0].getAggregation("items")[0].setText(oResourceBundle.getText("capacityexpectedBarLbl") + " " + sUnit);
			},
			_getUnitName: function () {
				return (this.getUnit() === "H") ? "hrs" : "days";
			},
			setExpected: function (fValue) {
				this.setProperty("expected", fValue);
				var expected = parseFloat(fValue);
				let timeMatrix = this.getUnit();
				if (timeMatrix === "H") {
					expected = isNaN(expected) ? 8 : expected;
				} else if (timeMatrix === "D") {
					expected = isNaN(expected) ? 1 : expected;
				} else {
					expected = 0;
				}
				if (typeof (expected) === "number") {
					var counts = this.countDecimal(expected);
					if (counts > 0) {
						expected = expected.toFixed(1);
					}
				} else {
					expected = 0;
				}
				this.getAggregation("_statusIndicator").getAggregation("items")[0].getAggregation("items")[1].setText(expected);
			},
			setSubmitted: function (fValue) {
				this.setProperty("submitted", fValue);
				var submitted = parseFloat(fValue);
				if(typeof(submitted) === "number") {
					var counts = this.countDecimal(submitted);
					if(counts > 0) {
						submitted = submitted.toFixed(1);
					}
				} else {
					submitted = 0;
				}
				this._setMissing();
				this.getAggregation("_statusIndicator").getAggregation("items")[1].getAggregation("items")[1].getAggregation("items")[0].setText(submitted + " (G)");
			},
			setSaved: function (fValue) {
				this.setProperty("saved", fValue);
				var saved = parseFloat(fValue);
				if(typeof(saved) === "number") {
					var counts = this.countDecimal(saved);
					if(counts > 0) {
						saved = saved.toFixed(1);
					}
				} else {
					saved = 0;
				}
				this._setMissing();
				this.getAggregation("_statusIndicator").getAggregation("items")[1].getAggregation("items")[1].getAggregation("items")[1].setText(saved);
			},
			_setMissing: function () {
				var expected = parseFloat(this.getExpected());
				var saved = parseFloat(this.getSaved());
				var submitted = parseFloat(this.getSubmitted());
				var total = submitted + saved;
				var missing = expected - submitted - saved;
				
				if(total < expected) {
					total = expected;
				} else {
					missing = 0;
				}
				var submittedPercent = (submitted !== 0) ? (submitted/total) * 100 : 0;
				var savedPercent = (saved !== 0) ? (saved/total) * 100 : 0;
				var missingPercent = (missing !== 0) ? (100 - submittedPercent - savedPercent) : 0;
				
				jQuery.sap.byId(this.getId() + "-submitted").parent().css({"width": submittedPercent + "%", "min-width": ((submittedPercent <= 0) ? "0px" : "45px"), "display": ((submittedPercent <= 0) ? "none" : "block")});
				jQuery.sap.byId(this.getId() + "-saved").parent().css({"width": savedPercent + "%", "min-width": ((savedPercent <= 0) ? "0px" : "45px"), "display": ((savedPercent <= 0) ? "none" : "block")});
				jQuery.sap.byId(this.getId() + "-missing").parent().css({"width": missingPercent + "%", "min-width": ((missingPercent <= 0) ? "0px" : "45px"), "display": ((missingPercent <= 0) ? "none" : "block")});
				
				if(typeof(missing) === "number") {
					var counts = this.countDecimal(missing);
					if(counts > 0) {
						missing = missing.toFixed(1);
					}
				} else {
					missing = 0;
				}				
				this.getAggregation("_statusIndicator").getAggregation("items")[1].getAggregation("items")[1].getAggregation("items")[2].setText(missing);
			},
			init: function () {
				//initialisation code, in this case, ensure css is imported
				var libraryPath = jQuery.sap.getModulePath("com.melody.lib"); //get the server location of the ui library
				jQuery.sap.includeStyleSheet(libraryPath + "/controls/expectedbar/activityProgressBar.css"); //specify the css path relative from the ui folder
				
				//Set i18n Model
				const oResourceModel = MTRModels.getMTRResourceModel();
				this.setModel(oResourceModel, "i18n");
				
				const oSettingsModel = MTRModels.getMTRSettingsModel();
				const sTimeMatrics = oSettingsModel.getProperty("/TimeMatrics");
				const sExpectedLbl = (sTimeMatrics && sTimeMatrics === "D") ? "Capacity Days" : "Capacity Hrs";
				this.setAggregation("_statusIndicator", new sap.m.HBox({
					fitContainer: true,
					alignItems: "Stretch",
					items: [
						new sap.m.VBox({
							alignItems: "Center",
							fitContainer: true,
							items: [
								new sap.m.Text({
									text: sExpectedLbl
								}).addStyleClass("expectedHrsLbl"),
								new sap.m.Text({
									text: this.getExpected()
								}).addStyleClass("extectedHrsVal")
							]
						}).addStyleClass("expectedHrsContainer")
						.setLayoutData(new sap.m.FlexItemData ({
						    growFactor: 3
						})),				
						new sap.m.VBox({
							fitContainer: true,
							items: [
								new sap.m.HBox({
									alignItems: "Center",
									justifyContent: "Start",
									items: [
										new sap.m.Text({
											text: "{i18n>expectedBarSubmittedLbl}"
										}).addStyleClass("statusIndicatorLegend legendSubmitted"),
										new sap.m.Text({
											text: "{i18n>expectedBarSavedLbl}"
										}).addStyleClass("statusIndicatorLegend legendSaved"),
										new sap.m.Text({
											text: "Available"
										}).addStyleClass("statusIndicatorLegend legendMissing")
									]
								}).addStyleClass("statusIndicatorLegendBox"),
								new sap.m.HBox({
									alignItems: "Center",
									justifyContent: "Center",
									items: [
										new sap.m.Text(this.getId() + "-submitted", {
											text: this.getSubmitted()
										}).addStyleClass("submittedStatusIndicator")
										.setLayoutData(new sap.m.FlexItemData ({
										    growFactor: 2
										})),
										new sap.m.Text(this.getId() + "-saved", {
											text: this.getSaved()
										}).addStyleClass("savedStatusIndicator")
										.setLayoutData(new sap.m.FlexItemData ({
										    growFactor: 2
										})),
										new sap.m.Text(this.getId() + "-missing", {
											text: "0"
										}).addStyleClass("missingStatusIndicator")
										.setLayoutData(new sap.m.FlexItemData ({
										    growFactor: 8
										}))
									]
								}).addStyleClass("statusIndicatorValue")
							]
						}).addStyleClass("statusIndicatorContainer")
						.setLayoutData(new sap.m.FlexItemData ({
						    growFactor: 9
						}))
					]	
				}).addStyleClass("statusBar"));
			},
			onAfterRendering: function () {
				this._setMissing();
			}
		});
		return ExpectedDurationBar;
	}, /* bExport= */ true);