/*!
 * ${copyright}
 */

sap.ui.define(["jquery.sap.global"],

	function ( /*jQuery*/ ) {
		"use strict";

		/**
		 * ExpectedDurationBar renderer.
		 * @namespace
		 */
		var ExpectedDurationBarRenderer = {};

		/**
		 * Renders the HTML for the given control, using the provided
		 * {@link sap.ui.core.RenderManager}.
		 *
		 * @param {sap.ui.core.RenderManager} oRm
		 *            the RenderManager that can be used for writing to
		 *            the Render-Output-Buffer
		 * @param {sap.ui.core.Control} oControl
		 *            the control to be rendered
		 */
		ExpectedDurationBarRenderer.render = function (oRm, oControl) {

			//first up, render a div for the ExpectedDurationBar
			oRm.write("<div");
			
			oRm.addClass("expectedTimeBar");

			//add this controls style class (plus any additional ones the developer has specified)
			oRm.writeClasses(oControl);

			//render width & height & background properties
            oRm.write(" style=\"width: " + oControl.getWidth()
                            + "; height: " + oControl.getHeight()
                            + "\"");

			//next, render the control information, this handles your sId (you must do this for your control to be properly tracked by ui5).
			oRm.writeControlData(oControl);
			oRm.write(">");

			oRm.renderControl(oControl.getAggregation("_statusIndicator"));
			
			//and obviously, close off our div
			oRm.write("</div>");

		};

		return ExpectedDurationBarRenderer;

	}, /* bExport= */ true);