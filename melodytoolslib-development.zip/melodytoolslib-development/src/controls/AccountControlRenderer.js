/*!
 * ${copyright}
 */

sap.ui.define(["jquery.sap.global", "com/melody/lib/enum/Actions"],

	function (jQuery, Actions) {
		"use strict";

		/**
		 * AccountInput renderer.
		 * @namespace
		 */
		var AccountControlRenderer = {};

		/**
		 * Renders the HTML for the given control, using the provided
		 * {@link sap.ui.core.RenderManager}.
		 *
		 * @param {sap.ui.core.RenderManager} oRm
		 *            the RenderManager that can be used for writing to
		 *            the Render-Output-Buffer
		 * @param Control oControl
		 *            the control to be rendered
		 */
		AccountControlRenderer.render = function (oRm, oControl) {

			let sControlType = oControl.getControlType();
			sControlType = sControlType.toUpperCase();
			let bEdtiable = oControl.getEditable();
			let accountId = oControl.getAccountId();
			let controlIcon = oControl.getIcon() || "sap-icon://edit";

			oRm.write("<div");

			//add this controls style class (plus any additional ones the developer has specified)
			oRm.addClass("accountInputContainer");
			oRm.writeClasses(oControl);

			//	oRm.write(" style=\"width: " + oControl.getWidth() + ";\"");

			//next, render the control information, this handles your sId (you must do this for your control to be properly tracked by ui5).
			oRm.writeControlData(oControl);
			oRm.writeAttribute("data-ctrlAccountId", accountId);
			oRm.write(">");

			//render controls based on controlType
			switch (sControlType) {
			case Actions.Button:
				if (bEdtiable) {
					oRm.renderControl(oControl.getAggregation("_button"));
					oControl.getAggregation("_button").setIcon(controlIcon);
				}
				break;
			case Actions.Icon:
				if (bEdtiable) {
					oRm.renderControl(oControl.getAggregation("_icon"));
					oControl.getAggregation("_icon").setSrc(controlIcon);
				}
				break;
			case Actions.Input:
				oControl.getAggregation("_input").setWidth("96%")
				oRm.renderControl(oControl.getAggregation("_input"));
				break;
			default:

			}

			oControl.getAggregation("_clearIcon").setSrc("sap-icon://decline");
			oControl.getAggregation("_accountinfobutton").setSrc("sap-icon://message-information");
			oControl.getAggregation("_accountinfobutton").addStyleClass("sapUiTinyMarginBegin");

			if (!bEdtiable) {
				oControl.getAggregation("_accountinfobutton").setVisible(true);
				oRm.renderControl(oControl.getAggregation("_accountinfobutton"));
			} else {
				oRm.renderControl(oControl.getAggregation("_clearIcon"));
				oRm.renderControl(oControl.getAggregation("_accountinfobutton"));
			}
			oRm.write("</div>");
		};

		return AccountControlRenderer;

	}, /* bExport= */ true);