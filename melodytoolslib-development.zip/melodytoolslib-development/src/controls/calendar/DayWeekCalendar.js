/*!
 * ${copyright}
 */
// Provides control com.melody.lib.controls.calendar.DayWeekCalendar.
sap.ui.define([
		"jquery.sap.global",
		"com/melody/lib/controls/calendar/types/CalendarMode",
		"sap/ui/core/Control",
		"sap/ui/unified/Calendar",
		"sap/ui/Device",
		"sap/ui/unified/CalendarDateInterval",
		"com/melody/lib/service/DateService",
		"sap/ui/unified/DateRange"
	],
	function (jQuery, CalendarMode, Control, Calendar, Device, CalendarDateInterval, DateService, DateRange) {
		"use strict";
		/**
		 * Constructor for a new DayWeekCalendar control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends sap.ui.core.Control
		 *
		 * @author SAP SE
		 * @version ${version}
		 *
		 * @constructor
		 * @private
		 * @alias mtr.ext.calendar.DayWeekCalendar
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */
		var DayWeekCalendar = Control.extend("com.melody.lib.controls.calendar.DayWeekCalendar", {
			metadata: {
				properties: {

					/**
					 * width
					 */
					width: {
						type: "sap.ui.core.CSSSize",
						defaultValue: "100%"
					},

					/**
					 * isWeekly
					 */
					isWeekly: {
						type: "boolean",
						defaultValue: false
					},

					/**
					 * isWeekly
					 */
					mode: {
						type: "com.melody.lib.controls.calendar.types.CalendarMode",
						defaultValue: CalendarMode.Daily
					},

					/**
					 * singleSelection
					 */
					singleSelection: {
						type: "boolean",
						defaultValue: true
					},

					/**
					 * selectedDate
					 */
					selectedDate: {
						type: "object",
						defaultValue: false
					},

					/**
					 * selectedDates
					 */
					selectedDates: {
						type: "object",
						defaultValue: false
					},

					copyPeriod: {
						type: "string",
						defaultValue: ""
					},

					/**
					 * entries
					 */
					entries: {
						type: "object",
						defaultValue: []
					},

					/**
					 * startDayOfWeek
					 */
					startDayOfWeek: {
						defaultValue: 1
					},

					/**
					 * unit
					 */
					unit: {
						type: "string",
						defaultValue: "H"
					},

					/**
					 * holidays
					 */
					holidays: {
						type: "object",
						defaultValue: []
					},

					/**
					 * vacations
					 */
					vacations: {
						type: "object",
						defaultValue: []
					}
				},
				events: {
					/**
					 * Event is fired when the user clicks on the control.
					 */
					press: {},

					select: {
						parameters: {
							selectionStartDate: {
								type: "object"
							},
							selectionEndDate: {
								type: "object"
							}
						}
					},
					navigate: {
						parameters: {
							selectionStartDate: {
								type: "object"
							},
							selectionEndDate: {
								type: "object"
							}
						}
					},
					changeMode: {
						parameters: {
							mode: {
								type: "com.melody.lib.controls.calendar.types.CalendarMode"
							}
						}
					}

				},

				aggregations: {
					/**
					 * Calendar control for desktop view
					 */
					_calendar: {
						type: "sap.ui.unified.Calendar",
						multiple: false,
						visibility: "hidden"
					},

					/**
					 * Event is fired when the user clicks on the control.
					 */
					_legendBox: {
						type: "sap.m.FlexBox",
						multiple: false,
						visibility: "hidden"
					},

					/**
					 * Event is fired when the user clicks on the control.
					 */
					_copyFrom: {
						type: "sap.m.FormattedText",
						multiple: false,
						visibility: "hidden"
					},

					/**
					 * Tokens for Copy functionality
					 */
					_selections: {
						type: "sap.m.Tokenizer",
						multiple: false,
						visibility: "hidden"
					}
				}
			},

			setHolidays: function (aHolidays) {
				var calendar = this.getAggregation("_calendar");
				for (var i = 0; i < aHolidays.length; i++) {
					var dHoliday = this.dateServicesInstance.formatStringDate(aHolidays[i]);
					var holiday = new sap.ui.unified.DateTypeRange({
						startDate: dHoliday,
						type: "Type01",
						color: "#537581",
						tooltip: "{i18n>dayWeekCalHolidayTooltip}"
					});
					calendar.addSpecialDate(holiday);
					//@Author - C5241040-Start 28 Feb 20
					calendar.addStyleClass("vacationColors");
					//@Author - C5241040-End
				}
			},

			setVacations: function (aVacations) {
				var calendar = this.getAggregation("_calendar");
				for (var i = 0; i < aVacations.length; i++) {
					var dHoliday = this.dateServicesInstance.formatStringDate(aVacations[i]);
					var holiday = new sap.ui.unified.DateTypeRange({
						startDate: dHoliday,
						type: "Type01",
						color: "#537581",
						tooltip: "{i18n>dayWeekCalVacationTooltip}"
					});
					calendar.addSpecialDate(holiday);
					//@Author - C5241040-Start 28 Feb 20
					calendar.addStyleClass("vacationColors");
					//@Author - C5241040-End
				}
			},

			getWeekends: function () {
				var iStartDayfOfWeek = parseInt(this.getStartDayOfWeek(), 10);
				var firstWeekend = 5 + iStartDayfOfWeek;
				if (firstWeekend > 6) {
					firstWeekend = firstWeekend - 7;
				}

				var secondWeekend = 6 + iStartDayfOfWeek;
				if (secondWeekend > 6) {
					secondWeekend = secondWeekend - 7;
				}

				return [firstWeekend, secondWeekend];
			},

			setStartDayOfWeek: function (fValue) {
				this.setProperty("startDayOfWeek", fValue);
			},

			_getStartDateOfWeek: function () {
				var d = new Date();
				var day = d.getDay(),
					diff = d.getDate() - day + (day === 0 ? -6 : parseInt(this.getStartDayOfWeek(), 10));
				return new Date(d.setDate(diff));
			},

			modeChangeTriggered: false,

			dateServicesInstance: DateService.getInstance(),

			init: function () {
				var that = this;
				that.setBusyIndicatorDelay(0);

				//initialisation code, in this case, ensure css is imported
				var libraryPath = jQuery.sap.getModulePath("com.melody.lib"); //get the server location of the ui library
				jQuery.sap.includeStyleSheet(libraryPath + "/controls/calendar/mtrCalendar.css"); //specify the css path relative from the ui folder
				var cal = Calendar;
				if (!Device.system.desktop) {
					cal = CalendarDateInterval;
				}

				//initializion calendar
				this.setAggregation("_calendar", new cal(that.getId() + "-dayWeekCalendar", {
					specialDates: [],
					showWeekNumbers: false,
					select: function (oEvent) {
						that._select();
						/*		that.setBusy(true);
								//var oCalendar = oEvent.getSource();
								var oCalendar = that.getAggregation("_calendar");
								var aSelectedDates = oCalendar.getSelectedDates();
								if (!this.getSingleSelection()) {
									var calendarDateFormat = sap.ui.core.format.DateFormat.getInstance({
										pattern: "EEE, MMM d, y",
										calendarType: sap.ui.core.CalendarType.Gregorian
									});

									var oDate;
									var aDates = [];
									that.getAggregation("_selections").removeAllTokens();
									if (aSelectedDates.length > 0) {
										for (var i = 0; i < aSelectedDates.length; i++) {
											oDate = aSelectedDates[i].getStartDate();
											var token = new sap.m.Token({
												text: calendarDateFormat.format(oDate),
												delete: function (event) {
													that._deleteSelection(that, event);
												}
											});
											token.data("date", oDate);
											that.getAggregation("_selections").addToken(token);
										}
										that.setSelectedDates(aDates);
									}
								}
								if (that.getMode() === CalendarMode.Daily || (!Device.system.desktop && !this.getSingleSelection())) {
									if (aSelectedDates.length > 0) {
										that.fireEvent("select", {
											selectionStartDate: aSelectedDates[0].getProperty("startDate"),
											selectionEndDate: aSelectedDates[0].getProperty("endDate")
										});
									} else {
										that.fireEvent("select", {
											selectionStartDate: null,
											selectionEndDate: null
										});
									}
								}
								that.setBusy(false);*/
					},
					startDateChange: function () {
						//	var oCalendar = oEvent.getSource();
						var oCalendar = that.getAggregation("_calendar");
						var startDate = oCalendar.getStartDate();

						if (that.getSingleSelection()) {
							var aEntries = that.getEntries();
							that.setEntries(aEntries);
							var dateSelector = "sapUiCalMonthView";
							if (!Device.system.desktop) {
								dateSelector = "sapUiCalRow";
							}
							var selectedWeekHighlighter = $("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent ." + dateSelector + " .selectedWeek");
							var selector = selectedWeekHighlighter.attr("data-selector-id");
							var weekStartDate = new Date($("#" + that.getId() + "-dayWeekCalendar " + selector).attr("aria-label"));
							if (weekStartDate.getMonth() === startDate.getMonth()) {
								selectedWeekHighlighter.show();
								$("#" + that.getId() + "-dayWeekCalendar " + selector).addClass("weekSelected");
								$("#" + that.getId() + "-dayWeekCalendar " + selector).nextUntil(".sapUiCalFirstWDay").addClass("weekSelected");
							} else {
								selectedWeekHighlighter.hide();
								$("#" + that.getId() + "-dayWeekCalendar " + selector).removeClass("weekSelected");
								$("#" + that.getId() + "-dayWeekCalendar " + selector).nextUntil(".sapUiCalFirstWDay").removeClass("weekSelected");
							}

							if (!Device.system.desktop && that.getSingleSelection()) {
								var entries = that.getEntries();
								that.setEntries(entries);
							}

							//if (that.getMode() === CalendarMode.Weekly && that.getSingleSelection() && !Device.system.desktop) {
							var sStartDate = that.dateServicesInstance.format(startDate, "yMMdd");

							var endDate = new Date(startDate.getTime() + (6 * 24 * 60 * 60 * 1000));
							var endDateString = that.genericDateFormat.format(endDate);
							if (that.getMode() === CalendarMode.Weekly && that.getSingleSelection()) {
								dateSelector = "sapUiCalRow";
								var elementId = $("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent ." + dateSelector +
									"  .sapUiCalItem[data-sap-day='" + sStartDate + "']").attr("id");
								that._setSelectedWeekHighlighter(elementId, that, sStartDate, endDateString);
							}
							//var weekStartDate = new Date($("#" + selector).attr("aria-label"));
							//if (that.getMode() === CalendarMode.Daily) {
							if (!Device.system.desktop && that.getMode() === CalendarMode.Weekly) {
								that.fireEvent("select", {
									selectionStartDate: startDate,
									selectionEndDate: endDate
								});
							} else {
								that.fireEvent("navigate", {
									selectionStartDate: startDate,
									selectionEndDate: endDate
								});
							}
							if (that.getMode() === CalendarMode.Weekly && that.getSingleSelection()) {
								that._setMode();
							}
						}
					},
					singleSelection: that.getSingleSelection()
				}).setIntervalSelection(false));

				if (!Device.system.desktop) {
					this.getAggregation("_calendar").setShowWeekNumbers(false)
						.addStyleClass("dayWeekCalendar");
				} else {
					this.getAggregation("_calendar")
						.setIntervalSelection(false).addStyleClass("shortCalendar");
				}

				//initializion legend
				this.setAggregation("_legendBox", new sap.m.FlexBox({
					renderType: "List",
					justifyContent: "Center",
					alignItems: "Center",
					visible: that.getSingleSelection(),
					items: [
						new sap.m.Link({
							text: "{i18n>dayWeekCalTodayLegend}",
							press: function (evt) {
								var oCalendar = that.getAggregation("_calendar");
								
									oCalendar.removeAllSelectedDates();
									oCalendar.focusDate(new Date());
									oCalendar.addSelectedDate(new DateRange({
										startDate: new Date()
									}));
								if (that.getMode() === CalendarMode.Weekly) {
									//var oComponent = Application.getInstance().Component;
									//var oDayWeekTimesheetModel = oComponent.getModel("DayWeekTimesheet");
									//oDayWeekTimesheetModel.setProperty("/SelectedDate", that.dateServicesInstance.format(new Date(), "EEEE, MMMM dd,y"));
									that.getAggregation("_calendar").removeAllSelectedDates();
									that._setMode();
									that.fireEvent("changeMode", {
										mode: that.getMode()
									});
								} else {
									setTimeout(function () {
										that._select();
									}, 500);
								}
							}
						}).addStyleClass("legend legendLink"),
						new sap.m.Text({
							text: "{i18n>dayWeekCalSelectedWeekLegend}",
							visible: that.getMode() !== CalendarMode.Daily
						}).addStyleClass("legend legendSelected"),
						new sap.m.Text({
							text: "{i18n>dayWeekCalSelectedDayLegend}",
							visible: that.getMode() === CalendarMode.Daily
						}).addStyleClass("legend legendSelectedDay"),
						new sap.m.Text({
							text: "{i18n>dayWeekCalWeekendLegend}"
						}).addStyleClass("legend legendWeekend"),
						/*new sap.m.Text({
							text: "{i18n>dayWeekCalHolidayLegend}"
						}).addStyleClass("legend legendHoliday")*/
					]
				}).addStyleClass("legendBox"));

				this.setAggregation("_copyFrom", new sap.m.FormattedText({
					htmlText: "",
					visible: !that.getSingleSelection()
				}).addStyleClass("copyFrom"));

				//initializion selections
				this.setAggregation("_selections", new sap.m.Tokenizer({
					tokens: that.getSelectedDates(),
					visible: !that.getSingleSelection()
				}));
			},

			_select: function () {
				var that = this;
				that.setBusy(true);
				//var oCalendar = oEvent.getSource();
				var oCalendar = that.getAggregation("_calendar");
				var aSelectedDates = oCalendar.getSelectedDates();
				if (!this.getSingleSelection()) {
					var calendarDateFormat = sap.ui.core.format.DateFormat.getInstance({
						pattern: "EEE, MMM d, y",
						calendarType: sap.ui.core.CalendarType.Gregorian
					});

					var oDate;
					var aDates = [];
					that.getAggregation("_selections").removeAllTokens();
					if (aSelectedDates.length > 0) {
						for (var i = 0; i < aSelectedDates.length; i++) {
							oDate = aSelectedDates[i].getStartDate();
							var token = new sap.m.Token({
								text: calendarDateFormat.format(oDate),
								delete: function (event) {
									that._deleteSelection(that, event);
								}
							});
							token.data("date", oDate);
							that.getAggregation("_selections").addToken(token);
						}
						that.setSelectedDates(aDates);
					}
				}
				if (that.getMode() === CalendarMode.Daily || (!Device.system.desktop && !this.getSingleSelection())) {
					if (aSelectedDates.length > 0) {
						that.fireEvent("select", {
							selectionStartDate: aSelectedDates[0].getProperty("startDate"),
							selectionEndDate: aSelectedDates[0].getProperty("endDate")
						});
					} else {
						that.fireEvent("select", {
							selectionStartDate: null,
							selectionEndDate: null
						});
					}
				}
				that.setBusy(false);

			},
			genericDateFormat: sap.ui.core.format.DateFormat.getInstance({
				pattern: "yMMdd",
				calendarType: sap.ui.core.CalendarType.Gregorian
			}),

			groupBy: function (array, f) {
				var groups = {};
				array.forEach(function (o) {
					var group = JSON.stringify(f(o));
					groups[group] = groups[group] || [];
					groups[group].push(o);
				});
				var keys = [];
				for (var k in groups) keys.push(k);
				return keys.map(function (group) {
					return groups[group];
				});
			},

			setUnit: function (sValue) {
				this.setProperty("unit", sValue);
				if (this.getSingleSelection()) {
					var entries = this.getEntries();
					this.setEntries(entries);
				}
			},

			setEntries: function (aEntries) {
				/*var that = this;

				var oComponent = Application.getInstance().Component;
				var oSettingsModel = oComponent.getModel("Settings");
				var bEssInMu = true;
				var oLookupModel = oComponent.getModel("Lookup");
				var aActivities = oLookupModel.getData().Activities;
				if (that.getSingleSelection()) {
					var dateSelector = "sapUiCalMonthView";
					if (!Device.system.desktop) {
						dateSelector = "sapUiCalRow";
					}
					var oResourceBundle = this.getModel("i18n").getResourceBundle();
					var unit = (this.getUnit() === "H") ? " " + oResourceBundle.getText("dayWeekCalHoursUnit") : oResourceBundle.getText(
						"dayWeekCalDayUnit");
					var unitHr = (this.getUnit() === "H") ? " " + oResourceBundle.getText("dayWeekCalHourUnit") : oResourceBundle.getText(
						"dayWeekCalDayUnit");
					$("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent ." + dateSelector + "  .sapUiCalItem .calDuartion").text(
						'');

					this.setProperty("entries", aEntries);
					if (aEntries && aEntries.length > 0) {
						var groupedEntriesByDate = this.groupBy(aEntries, function (item) {
							return [item.RecordDate];
						});
						for (var item in groupedEntriesByDate) {
							var totalWorkDuration = 0;
							var statusId = "";
							for (var i = 0; i < groupedEntriesByDate[item].length; i++) {
								var workDuration = 0;
								if (groupedEntriesByDate[item][i].DataFrom && groupedEntriesByDate[item][i].DataFrom !== "") {
									workDuration = parseFloat(groupedEntriesByDate[item][i].WorkDuration);
									if (!isNaN(workDuration)) {
										var oActivity = aActivities.find(function (entry) {
											return entry.ActivityId === groupedEntriesByDate[item][i].ActivityId;
										});
										if (oActivity && ((bEssInMu && !oActivity.EssInMu) || !bEssInMu) && oActivity.IsArchive !== "X") {
											totalWorkDuration += parseFloat(groupedEntriesByDate[item][i].WorkDuration);
											if (groupedEntriesByDate[item][i].StatusId && groupedEntriesByDate[item][i].StatusId !== "") {
												if (groupedEntriesByDate[item][i].StatusId === "3") {
													statusId = "3"; // Failed
												} else if (groupedEntriesByDate[item][i].StatusId === "1" && statusId !== "3") {
													statusId = "1"; // Save
												} else if (groupedEntriesByDate[item][i].StatusId === "2" && statusId !== "1" && statusId !== "3") {
													statusId = "2"; // In queue
												} else if (groupedEntriesByDate[item][i].StatusId === "4" && statusId !== "1" && statusId !== "2" && statusId !== "3") {
													statusId = "4"; // Submitted
												}
											}
										}
									}
								}
							}

							var counts = this.countDecimal(totalWorkDuration);
							if (counts > 0) {
								totalWorkDuration = totalWorkDuration.toFixed(1);
							}
							var totalDurationString = "";
							if (totalWorkDuration !== 0) {
								if (totalWorkDuration > 1) {
									totalDurationString += totalWorkDuration + unit;
								} else {
									totalDurationString += totalWorkDuration + unitHr;
								}
							}

							var calDuration = $("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent ." + dateSelector +
								"  .sapUiCalItem[data-sap-day='" + groupedEntriesByDate[item][0].RecordDate + "'] .calDuartion");
							if (calDuration.length === 0) {
								$("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent ." + dateSelector + "  .sapUiCalItem[data-sap-day='" +
									groupedEntriesByDate[item][0].RecordDate + "']").append("<span class='calDuartion' data-statusid='" + statusId + "'>" +
									totalDurationString + "</span>");
							} else {
								calDuration.text(totalDurationString);
								calDuration.attr("data-statusid", statusId);
							}
						}
					} else {
						$("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent ." + dateSelector + " .sapUiCalItem .calDuartion").text(
							'');
					}
				}*/
			},

			countDecimal: function (value) {
				if (Math.floor(value) === value) return 0;
				return value.toString().split(".")[1].length || 0;
			},

			setSelectedDate: function (copyStartDate) {
				var that = this;
				var oResourceBundle = this.getModel("i18n").getResourceBundle();
				if (!this.getSingleSelection()) {
					var calendarDateFormat = sap.ui.core.format.DateFormat.getInstance({
						pattern: "EEE, MMM d, y",
						calendarType: sap.ui.core.CalendarType.Gregorian
					});

					var htmlText = "<p>" + oResourceBundle.getText("dayModeCopyMsg") + "</p>";
					htmlText += "<p>";
					if (that.getMode() === CalendarMode.Weekly) {
						var copyEndDate = new Date(copyStartDate.getTime() + (6 * 24 * 60 * 60 * 1000));
						var onejan = new Date(copyStartDate.getFullYear(), 0, 1);
						var weekNumber = Math.ceil((((copyStartDate - onejan) / 86400000) + onejan.getDay() + 1) / 7);
						htmlText += "<strong>" + oResourceBundle.getText("dayWeekCalWeekStr") + " " + weekNumber + ": " + calendarDateFormat.format(
							copyStartDate) + " - " + calendarDateFormat.format(copyEndDate) + "</strong>";
					} else {
						htmlText += "<strong>" + calendarDateFormat.format(copyStartDate) + "</strong>";
					}
					htmlText += " " + oResourceBundle.getText("dayWeekCalToStr") + "</p>";
					//return htmlText;
					that.getAggregation("_copyFrom").setHtmlText(htmlText);
				}
				this.setProperty("selectedDate", copyStartDate);
			},

			_getPreviousMonday: function () {
				var d = new Date();
				var day = d.getDay(),
					diff = d.getDate() - day + (day === 0 ? -6 : 1);
				return new Date(d.setDate(diff));
			},

			_deleteSelection: function (that, oEvent) {
				//var that = this;
				var oDate = oEvent.getSource().data("date");
				var oCal = that.getAggregation("_calendar");
				var aSelectedDates = oCal.getSelectedDates();
				if (that.getMode() === CalendarMode.Weekly) {
					var oDate1 = new Date(oDate.getTime() + (1 * 24 * 60 * 60 * 1000));
					var oDate2 = new Date(oDate.getTime() + (2 * 24 * 60 * 60 * 1000));
					var oDate3 = new Date(oDate.getTime() + (3 * 24 * 60 * 60 * 1000));
					var oDate4 = new Date(oDate.getTime() + (4 * 24 * 60 * 60 * 1000));
					var oDate5 = new Date(oDate.getTime() + (5 * 24 * 60 * 60 * 1000));
					var oDate6 = new Date(oDate.getTime() + (6 * 24 * 60 * 60 * 1000));
					for (var i = 0; i < aSelectedDates.length; i++) {
						if (oDate === aSelectedDates[i].getStartDate() ||
							oDate1 === aSelectedDates[i].getStartDate() ||
							oDate2 === aSelectedDates[i].getStartDate() ||
							oDate3 === aSelectedDates[i].getStartDate() ||
							oDate4 === aSelectedDates[i].getStartDate() ||
							oDate5 === aSelectedDates[i].getStartDate() ||
							oDate6 === aSelectedDates[i].getStartDate()) {
							oCal.removeSelectedDate(aSelectedDates[i]);
						}
					}
					//that.modeChangeTriggered = false;
					that._setMode();
				} else if (that.getMode() === CalendarMode.Daily) {
					for (var j = 0; j < aSelectedDates.length; j++) {
						if (oDate === aSelectedDates[j].getStartDate()) {
							oCal.removeSelectedDate(aSelectedDates[j]);
						}
					}
				}
			},

			setSingleSelection: function (bValue) {
				this.setProperty("singleSelection", (bValue || bValue === "true"));
				var calendar = this.getAggregation("_calendar");
				calendar.setSingleSelection(bValue);
				this.getAggregation("_legendBox").setVisible(bValue);
				this.getAggregation("_selections").setVisible(!bValue);
				this.getAggregation("_copyFrom").setVisible(!bValue);
				if (bValue) {
					calendar.removeStyleClass("copyCalendar");
				} else {
					calendar.addStyleClass("copyCalendar");
				}
			},

			onAfterRendering: function () {
				var that = this;
				that.setBusy(true);
				//if I need to do any post render actions, it will happen here
				if (sap.ui.core.Control.prototype.onAfterRendering) {
					sap.ui.core.Control.prototype.onAfterRendering.apply(this, arguments); //run the super class's method first
				}
				if (!Device.system.desktop) {
					this.getAggregation("_calendar").setShowWeekNumbers(false)
						.setStartDate(that._getStartDateOfWeek());
				} else {
					this.getAggregation("_calendar").setProperty("firstDayOfWeek", parseInt(this.getStartDayOfWeek(), 10));
				}
				this.getAggregation("_calendar").setNonWorkingDays(this.getWeekends());

				that._setMode();
			},

			sanitize: function (input) {
				if (!input) {
					return "";
				}
				return input
					.replace(/&/g, "&amp;")
					.replace(/</g, "&lt;")
					.replace(/>/g, "&gt;")
					.replace(/\"/g, "&quot;")
					.replace(/\'/g, "&#39;")
					.replace(/\//g, "&#x2F;");
			},

			_setMode: function () {
				var that = this;
				that.setBusy(true);
				//var oComponent = Application.getInstance().Component;
				//var oDayWeekTimesheetModel = oComponent.getModel("DayWeekTimesheet");
				//var sSelectedDate = oDayWeekTimesheetModel.getProperty("/SelectedDate");
				var sSelectedDate;
				var dSelectedDate = new Date();
				var _handleClickWeekHighlighter = function (event) {
					var genericDateFormat = sap.ui.core.format.DateFormat.getInstance({
						pattern: "yMMdd",
						calendarType: sap.ui.core.CalendarType.Gregorian
					});

					var calendarDateFormat = sap.ui.core.format.DateFormat.getInstance({
						pattern: "MMM dd, y",
						calendarType: sap.ui.core.CalendarType.Gregorian
					});
					var selector = (jQuery(this).attr("data-selector-id")) ? jQuery.sap.encodeHTML(jQuery(this).attr("data-selector-id")) : "";
					var startDateString = (jQuery("#" + selector).attr("data-sap-day")) ? jQuery.sap.encodeHTML(jQuery("#" + selector).attr(
						"data-sap-day")) : "";
					var startDate = new Date(startDateString.substring(0, 4) + "/" + startDateString.substring(4, 6) + "/" + startDateString.substring(
						6, 8));
					var endDate = new Date(startDate.getTime() + (6 * 24 * 60 * 60 * 1000));
					var endDateString = genericDateFormat.format(endDate);
					if (!that.getSingleSelection()) {
						var oCal = that.getAggregation("_calendar");
						var aSelectedDates = oCal.getSelectedDates();
						if (that.getMode() === CalendarMode.Weekly) {
							var isSelected = false;
							for (var i = 0; i < aSelectedDates.length; i++) {
								if (genericDateFormat.format(aSelectedDates[i].getStartDate()) === startDateString) {
									isSelected = true;
									break;
								}
							}
							if (isSelected) {
								var oDate1 = new Date(startDate.getTime() + (1 * 24 * 60 * 60 * 1000));
								var oDate2 = new Date(startDate.getTime() + (2 * 24 * 60 * 60 * 1000));
								var oDate3 = new Date(startDate.getTime() + (3 * 24 * 60 * 60 * 1000));
								var oDate4 = new Date(startDate.getTime() + (4 * 24 * 60 * 60 * 1000));
								var oDate5 = new Date(startDate.getTime() + (5 * 24 * 60 * 60 * 1000));
								var oDate6 = new Date(startDate.getTime() + (6 * 24 * 60 * 60 * 1000));
								for (var j = 0; j < aSelectedDates.length; j++) {
									var selectedDateString = genericDateFormat.format(aSelectedDates[j].getStartDate());
									if (startDateString === selectedDateString ||
										genericDateFormat.format(oDate1) === selectedDateString ||
										genericDateFormat.format(oDate2) === selectedDateString ||
										genericDateFormat.format(oDate3) === selectedDateString ||
										genericDateFormat.format(oDate4) === selectedDateString ||
										genericDateFormat.format(oDate5) === selectedDateString ||
										genericDateFormat.format(oDate6) === selectedDateString) {
										oCal.removeSelectedDate(aSelectedDates[j]);
									}
								}
								var tokens = that.getAggregation("_selections").getTokens();
								for (var t in tokens) {
									if (genericDateFormat.format(tokens[t].data("date")) === startDateString) {
										that.getAggregation("_selections").removeToken(tokens[t]);
									}
								}
							} else {
								var selectedDateRange = new sap.ui.unified.DateRange({
									startDate: startDate,
									endDate: endDate
								});
								that.getAggregation("_calendar").addSelectedDate(selectedDateRange);
								var p = $(this).position();
								var sDataWeekNum = (jQuery("#" + selector).attr("data-week-num")) ? jQuery.sap.encodeHTML(jQuery("#" + selector).attr(
									"data-week-num")) : "";
								var selectedWeek = "<div style='top:" + p.top + "px; display: block;' data-week-num='" + sDataWeekNum +
									"' data-display-week-num='" + $("#" + selector).parent()[0].getElementsByClassName(
										"sapUiCalWeekNum")[0].innerHTML +
									"' class='selectedWeek' data-start-date='" + startDateString + "' data-end-date='" + endDateString + "'></div>";
								/*eslint-disable sap-no-dom-insertion*/
								jQuery("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent .sapUiCalMonthView").append(selectedWeek);
								/*eslint-enable sap-no-dom-insertion*/
								var oResourceBundle = that.getModel("i18n").getResourceBundle();
								var tokenText = oResourceBundle.getText("dayWeekCalTokenStr") + " " + $("#" + selector).parent()[0].getElementsByClassName(
									"sapUiCalWeekNum")[0].innerHTML + ": " + calendarDateFormat.format(startDate) + " - " + calendarDateFormat.format(endDate);
								var token = new sap.m.Token({
									text: tokenText,
									delete: function (oEvent) {
										that._deleteSelection(that, oEvent);
									}
								});
								token.data("date", startDate);
								that.getAggregation("_selections").addToken(token);
							}
							that._setMode();
							that.fireEvent("select", {
								selectionStartDate: startDate,
								selectionEndDate: endDate
							});
						}
					} else {
						that._setSelectedWeekHighlighter(selector, that, startDateString, endDateString);
						var weekStartDate = new Date($("#" + selector).attr("aria-label"));
						that.fireEvent("select", {
							selectionStartDate: weekStartDate,
							selectionEndDate: new Date(weekStartDate.getTime() + (6 * 24 * 60 * 60 * 1000))
						});
					}
				};
				if (sSelectedDate) {
					dSelectedDate = new Date(sSelectedDate);
				} else {
					dSelectedDate = new Date();
				}
				setTimeout(function () {
					var oResourceBundle = that.getModel("i18n").getResourceBundle();
					if (that.getMode() === CalendarMode.Weekly) {
						if (Device.system.desktop) {
							that.getAggregation("_calendar").addStyleClass("week");
							that.getAggregation("_calendar").setShowWeekNumbers(true);
							var calendar = jQuery.sap.byId(that.getId() + "-dayWeekCalendar")[0];
							var firstHeaderElement = calendar.querySelectorAll('.sapUiCalContent .sapUiCalMonthView div[role="row"] .sapUiCalFirstWDay');
							var sFirstHeaderElementText = (firstHeaderElement[0].innerText) ? jQuery.sap.encodeHTML(firstHeaderElement[0].innerText) : "";
							if (jQuery(firstHeaderElement).has("span.weekLabel").length === 0) {
								firstHeaderElement[0].innerHTML = "<span id='" + that.getId() + "-weekLabel" +
									"' class='weekLabel'>" + oResourceBundle.getText("calWeekModeFirstHeader") + "</span><span class='val'>" +
									sFirstHeaderElementText +
									"</span>";
							}
							if ($("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent .sapUiCalMonthView").has(".weekHighlighter").length === 0) {
								var nodes = "<div class='weekHighlighter'></div><div class='selectedWeek'></div>";
								/*eslint-disable sap-no-dom-insertion*/
								$("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent .sapUiCalMonthView").append(nodes);
								/*eslint-enable sap-no-dom-insertion*/
							}
							$("#" + that.getId() + "-dayWeekCalendar .sapUiCalFirstWDay:last").addClass("lastCalItem");
							$("#" + that.getId() + "-dayWeekCalendar .sapUiCalFirstWDay:last").nextAll(".sapUiCalItem").addClass("lastCalItem");
							$("#" + that.getId() + "-dayWeekCalendar").off("mouseenter", ".sapUiCalMonthView div.sapUiCalItem", this._handleMouseEnterWeeklyItem);
							$(document).off("mouseleave", "#" + that.getId() + "-dayWeekCalendar", this._handleMouseLeaveWeeklyItem);
							$("#" + that.getId() + "-dayWeekCalendar").off("click", ".weekHighlighter");
							$("#" + that.getId() + "-dayWeekCalendar").on("mouseenter", ".sapUiCalMonthView div.sapUiCalItem", {
								calObj: that
							}, that._handleMouseEnterWeeklyItem);
							$(document).on("mouseleave", "#" + that.getId() + "-dayWeekCalendar", {
								calObj: that
							}, that._handleMouseLeaveWeeklyItem);
							$("#" + that.getId() + "-dayWeekCalendar").on("click", ".weekHighlighter", _handleClickWeekHighlighter);
						}
					}
					if (that.getSingleSelection()) {
						var aEntries = that.getEntries();
						that.setEntries(aEntries);
					}
					if (that.getMode() === CalendarMode.Weekly && that.getSingleSelection()) {
						var startDateString = that.genericDateFormat.format(dSelectedDate);
						var endDate = new Date(dSelectedDate.getTime() + (6 * 24 * 60 * 60 * 1000));
						var endDateString = that.genericDateFormat.format(endDate);
						var dStartDate = that.dateServicesInstance.getStartDateOfWeek(dSelectedDate, 1);
						var sStartDate = that.dateServicesInstance.format(dStartDate, "yMMdd");
						var dateSelector = "sapUiCalMonthView";
						if (!Device.system.desktop) {
							dateSelector = "sapUiCalRow";
						}
						var elementId = $("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent ." + dateSelector +
							"  .sapUiCalItem[data-sap-day='" + sStartDate + "']").attr("id");
						that._setSelectedWeekHighlighter(elementId, that, startDateString, endDateString);
					}
					that.setBusy(false);
				}, 4000);
				$("#" + that.getId() + "-dayWeekCalendar .weekHighlighter").hide();
				$("#" + that.getId() + "-dayWeekCalendar .selectedWeek").hide();
				$("#" + that.getId() + "-dayWeekCalendar .sapUiCalMonthView .sapUiCalItem").removeClass("lastCalItem");
				if (that.getMode() === CalendarMode.Weekly) {
					if (!Device.system.desktop && that.getSingleSelection()) {
						$(".selectedWeek").show();
					}
				} else {
					that.getAggregation("_calendar").removeStyleClass("week");
					that.getAggregation("_calendar").setShowWeekNumbers(false);
					$("#" + that.getId() + "-dayWeekCalendar").off("mouseenter", ".sapUiCalMonthView div.sapUiCalItem", this._handleMouseEnterWeeklyItem);
					$(document).off("mouseleave", "#" + that.getId() + "-dayWeekCalendar", this._handleMouseLeaveWeeklyItem);
					$("#" + that.getId() + "-dayWeekCalendar").off("click", ".weekHighlighter");
				}
				if (this.getSingleSelection() && this.getMode() === CalendarMode.Daily) {
					var selectedDateRange = new sap.ui.unified.DateRange({
						startDate: dSelectedDate,
						endDate: dSelectedDate
					});
					that.getAggregation("_calendar").insertSelectedDate(selectedDateRange);
				}
			},

			_handleMouseEnterWeeklyItem: function (event) {
				var that = event.data.calObj;
				var p = $(this).position();
				$("#" + that.getId() + "-dayWeekCalendar .weekHighlighter").show();
				var firstElement, firstElementId;
				if ($(this).hasClass("sapUiCalFirstWDay")) {
					firstElement = $(this);
					firstElementId = firstElement[0].getAttribute("id");
				} else {
					firstElement = $(this).prevAll(".sapUiCalFirstWDay:first");
					firstElementId = firstElement[0].getAttribute("id");
				}
				$("#" + that.getId() + "-dayWeekCalendar .weekHighlighter").attr("data-selector-id", firstElementId);
				$("#" + that.getId() + "-dayWeekCalendar .weekHighlighter").css({
					top: p.top
				});
			},

			_handleMouseLeaveWeeklyItem: function (event) {
				var that = event.data.calObj;
				$("#" + that.getId() + "-dayWeekCalendar .weekHighlighter").hide();
				$("#" + that.getId() + "-dayWeekCalendar .weekHighlighter").attr("data-selector-id", "");
			},

			_setSelectedWeekHighlighter: function (element, that, startDateString, endDateString) {
				var dateSelector = "sapUiCalMonthView";
				var firstDateSelector = "sapUiCalFirstWDay";
				if (!Device.system.desktop) {
					dateSelector = "sapUiCalRow";
					firstDateSelector = "sapUiCalWDay1";
				}
				var p = $("#" + element).position();
				if (p) {
					$("#" + that.getId() + "-dayWeekCalendar .selectedWeek").remove();
					var sDataWeekNum = (jQuery("#" + element).attr("data-week-num")) ? jQuery.sap.encodeHTML(jQuery("#" + element).attr(
						"data-week-num")) : "";
					var selectedWeek = "<div style='top:" + p.top + "px; display: block;' data-selector-id='" + element + "' data-week-num='" +
						sDataWeekNum +
						"' class='selectedWeek' data-start-date='" + startDateString + "' data-end-date='" + endDateString + "'></div>";
					/*eslint-disable sap-no-dom-insertion*/
					$("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent ." + dateSelector).append(selectedWeek);
					/*eslint-enable sap-no-dom-insertion*/
					$("#" + that.getId() + "-dayWeekCalendar .sapUiCalContent ." + dateSelector + "  .sapUiCalItem").removeClass(
						"weekSelected");
					$("#" + element).addClass("weekSelected");
					$("#" + element).nextUntil("." + firstDateSelector).addClass("weekSelected");
					if (!Device.system.desktop && that.getSingleSelection()) {
						$(".selectedWeek").show();
					}
				}
			}
		});
		return DayWeekCalendar;
	}, /* bExport= */ true);