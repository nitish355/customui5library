sap.ui.define({
  Daily: "Daily",
  Weekly: "Weekly"
}, true);