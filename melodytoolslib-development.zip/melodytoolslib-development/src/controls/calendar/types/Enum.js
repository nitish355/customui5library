sap.ui.define({
  DayWeek: "1",
  Matrix: "2"
}, true);