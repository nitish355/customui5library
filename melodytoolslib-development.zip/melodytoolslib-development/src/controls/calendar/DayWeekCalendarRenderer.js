/*!
 * ${copyright}
 */

sap.ui.define(["jquery.sap.global"],

	function ( /*jQuery*/ ) {
		"use strict";

		/**
		 * DayWeekCalendar renderer.
		 * @namespace
		 */
		var DayWeekCalendarRenderer = {};

		/**
		 * Renders the HTML for the given control, using the provided
		 * {@link sap.ui.core.RenderManager}.
		 *
		 * @param {sap.ui.core.RenderManager} oRm
		 *            the RenderManager that can be used for writing to
		 *            the Render-Output-Buffer
		 * @param {sap.ui.core.Control} oControl
		 *            the control to be rendered
		 */
		DayWeekCalendarRenderer.render = function (oRm, oControl) {

			//first up, render a div for the DayWeekCalendar
			oRm.write("<div");

			//add this controls style class (plus any additional ones the developer has specified)
			oRm.addClass("darwinCalendar");
			oRm.writeClasses(oControl);

			oRm.write(" style=\"width: " + oControl.getWidth() + "; position: relative" + "\"");

			//next, render the control information, this handles your sId (you must do this for your control to be properly tracked by ui5).
			oRm.writeControlData(oControl);
			oRm.write(">");

			oRm.renderControl(oControl.getAggregation("_calendar"));
			/*oRm.renderControl(oControl.getAggregation("_shortCalendar"));*/
			
			oRm.renderControl(oControl.getAggregation("_legendBox"));
			//oRm.renderControl(oControl.getAggregation("_copyText"));
			oRm.renderControl(oControl.getAggregation("_copyFrom"));
			oRm.renderControl(oControl.getAggregation("_selections"));
			
			//and obviously, close off our div
			oRm.write("</div>");
		};

		return DayWeekCalendarRenderer;

	}, /* bExport= */ true);