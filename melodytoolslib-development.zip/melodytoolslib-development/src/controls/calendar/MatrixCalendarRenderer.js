/*!
 * ${copyright}
 */

sap.ui.define(["jquery.sap.global"],

	function ( /*jQuery*/ ) {
		"use strict";

		/**
		 * MatrixCalendar renderer.
		 * @namespace
		 */
		var MatrixCalendarRenderer = {};

		/**
		 * Renders the HTML for the given control, using the provided
		 * {@link sap.ui.core.RenderManager}.
		 *
		 * @param {sap.ui.core.RenderManager} oRm
		 *            the RenderManager that can be used for writing to
		 *            the Render-Output-Buffer
		 * @param {sap.ui.core.Control} oControl
		 *            the control to be rendered
		 */
		MatrixCalendarRenderer.render = function (oRm, oControl) {
			oRm.write("<div");

			//add this controls style class (plus any additional ones the developer has specified)
			oRm.addClass("matrixCalendarContainer");
			oRm.writeClasses(oControl);

			oRm.write(" style=\"width: " + oControl.getWidth() + "; position: relative" + "\"");

			//next, render the control information, this handles your sId (you must do this for your control to be properly tracked by ui5).
			oRm.writeControlData(oControl);
			oRm.write(">");
			oRm.openStart("div", oControl);
			oRm.class("calendarContainer");
			oRm.openEnd();
			oRm.openStart("div", oControl);
			oRm.class("calendarInnerContainer");
			oRm.openEnd();
			oRm.renderControl(oControl.getAggregation("_navCalendar"));
			oRm.renderControl(oControl.getAggregation("_shortCalendar"));
			oControl.getAggregation("_shortCalendar").setStartDate(oControl._getStartDateOfWeek()).setNonWorkingDays(oControl.getWeekends());
			oRm.renderControl(oControl.getAggregation("_datePicker"));
			oRm.close("div");
			oRm.renderControl(oControl.getAggregation("_legends"));
			oRm.close("div");
			//and obviously, close off our div
			oRm.write("</div>");
		};

		return MatrixCalendarRenderer;

	}, /* bExport= */ true);