/*!
 * ${copyright}
 */
// Provides control com.melody.lib.controls.calendar.MtrCalendar.
sap.ui.define([
		"jquery.sap.global",
		"com/melody/lib/controls/calendar/types/CalendarMode",
		"sap/ui/core/Control",
		"sap/ui/unified/Calendar",
		"sap/ui/Device",
		"sap/ui/unified/CalendarDateInterval",
		"com/melody/lib/service/DateService",
		"sap/ui/unified/DateRange"
	],
	function (jQuery, CalendarMode, Control, Calendar, Device, CalendarDateInterval, DateService, DateRange) {
		"use strict";
		/**
		 * Constructor for a new MtrCalendar control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends sap.ui.core.Control
		 *
		 * @author SAP SE
		 * @version ${version}
		 *
		 * @constructor
		 * @private
		 * @alias mtr.ext.calendar.MtrCalendar
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */
		var MtrCalendar = Control.extend("com.melody.lib.controls.calendar.MtrCalendar", {
			metadata: {
				properties: {
					/**
					 * width
					 */
					width: {
						type: "sap.ui.core.CSSSize",
						defaultValue: "100%"
					}
				},
				events: {
					select: {
						parameters: {
							selectedDates: {
								type: "sap.ui.unified.DateRange",
								multiple: true
							}
						}
					}
				},

				aggregations: {
					/**
					 * Calendar control for desktop view
					 */
					_calendar: {
						type: "sap.ui.unified.Calendar",
						multiple: false,
						visibility: "hidden"
					},

					/**
					 * Event is fired when the user clicks on the control.
					 */
					_legendBox: {
						type: "sap.m.FlexBox",
						multiple: false,
						visibility: "hidden"
					}
				}
			},
			
			init: function () {
				var that = this;
				that.setBusyIndicatorDelay(0);

				//initialisation code, in this case, ensure css is imported
				var libraryPath = jQuery.sap.getModulePath("com.melody.lib"); //get the server location of the ui library
				jQuery.sap.includeStyleSheet(libraryPath + "/controls/calendar/calendar.css"); //specify the css path relative from the ui folder
				var cal = Calendar;
				if (!Device.system.desktop) {
					cal = CalendarDateInterval;
				}

				//initializion calendar
				this.setAggregation("_calendar", new Calendar(that.getId() + "-mtrCalendar", {
					showWeekNumbers: false,
					firstDayOfWeek: 1,
					singleSelection: false,
					select: function (oEvent) {
						const oCalendar = oEvent.getSource();
						const aSelectedDates = oCalendar.getSelectedDates()
						that.fireEvent("select", {
							selectedDates: aSelectedDates
						});
					}
				}).setIntervalSelection(false).addStyleClass("darwinCalendar"));

				//initializion legend
				this.setAggregation("_legendBox", new sap.m.FlexBox({
					renderType: "List",
					justifyContent: "Center",
					alignItems: "Center",
					items: [
						new sap.m.Text({
							text: "Today"
						}).addStyleClass("legend"),
						new sap.m.Text({
							text: "Selected Day"
						}).addStyleClass("legend legendSelectedDay"),
						new sap.m.Text({
							text: "Weekend"
						}).addStyleClass("legend legendWeekend")
					]
				}).addStyleClass("legendBox"));
			},
			
			onAfterRendering: function () {
				
			}
		});
		return MtrCalendar;
	}, /* bExport= */ true);