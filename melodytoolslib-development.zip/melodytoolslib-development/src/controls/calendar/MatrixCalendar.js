/*!
 * ${copyright}
 */
// Provides control com.presalescentral.mtr.controls.calendar.MatrixCalendar.
sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/Control",
	"sap/ui/unified/Calendar",
	"sap/ui/unified/CalendarDateInterval",
	"com/melody/lib/service/DateService",
	"sap/ui/model/json/JSONModel",
	"com/melody/lib/util/mtr/MTRModels",
	"sap/ui/core/mvc/Controller",
	"sap/ui/unified/DateRange",
	"com/melody/lib/util/mtr/MTR",
	"sap/ui/core/Fragment"
	],
function (jQuery, Control, Calendar, CalendarDateInterval, DateService, JSONModel, MTRModels, Controller, DateRange, MTRUtil, Fragment) {
	"use strict";
	/**
	 * Constructor for a new MatrixCalendar control.
	 *
	 * @param {string} [sId] id for the new control, generated automatically if no id is given
	 * @param {object} [mSettings] initial settings for the new control
	 *
	 * @class
	 * Some class description goes here.
	 * @extends sap.ui.core.Control
	 *
	 * @author SAP SE
	 * @version ${version}
	 *
	 * @constructor
	 * @private
	 * @alias mtr.controls.mtrcontrols.controls.calendar.DayWeekCalendar
	 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
	 */
	var that;
	const MatrixCalendarController = Controller.extend("com.melody.lib.controls.mtr.MelodyDatePickerController", {
		constructor: function (control) {
			this.control = control;
		},
		
		onNavigateCalendar: function (oEvent) {
			const thisController = this;
			const dStartDate = oEvent.getParameter("selectionStartDate");
			/*
			-Below setInitialFocusedDate is added bcz months navigation is not working
			*/
			const oCalendar = oEvent.getSource().getAggregation("_calendar");
			if (oCalendar) {
				oCalendar.setInitialFocusedDate(dStartDate);
				oCalendar.setBusy(true);
			}
			MTRUtil.updateTimesheets(dStartDate).then(() => {
				const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
				const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
				thisController.control.Model.setProperty("/Entries", aEntries);
				oDayWeekTimesheetModel.refresh(true);
				thisController.control.Model.refresh(true);
				// const oCalendar = MTRHelper.Controller.getCalendar();
				if (oCalendar) {
					oCalendar.setBusy(false);
				}
			});

		},
		
		_selectWeek: function (startDate, calendar) {
			var endDate = new Date(startDate.getTime() + (6 * 24 * 60 * 60 * 1000));
			calendar.removeAllSelectedDates();
			
			calendar.addSelectedDate(new DateRange({
				startDate: startDate,
				endDate: endDate
			}));
			calendar.focusDate(startDate);
		},

		onSelect: function (oEvent) {
			const core = sap.ui.getCore();
			const oSource = oEvent.getSource();
			var oCalendar = oSource.getAggregation("_calendar");
			const dDate = oEvent.getParameter("selectionStartDate");
			const dMatrixSelectedStartDate = this.control._getStartDateOfWeek();
			let dFirstDate = null;
			if (dDate) {
				dFirstDate = this.control._getFirstDayOfWeek(dDate);
			}
			if (dFirstDate && dMatrixSelectedStartDate !== dFirstDate) {
				oSource.setStartDate(DateService.getInstance().format(dFirstDate, "EEEE, MMMM dd,y"));
				this.control._onWeekChange(dFirstDate);
				this._selectWeek(dFirstDate, oCalendar);
			}
			setTimeout(function () {
				core._pMelodyDatePickerPopover.close();
			}, 100);
		}
	});
	var MatrixCalendar = Control.extend("com.melody.lib.controls.calendar.MatrixCalendar", {
		metadata: {
			properties: {

				/**
				 * width
				 */
				width: {
					type: "sap.ui.core.CSSSize",
					defaultValue: "100%"
				},

				/**
				 * isValidTimesheet
				 */
				valid: {
					type: "boolean",
					defaultValue: true
				},

				/**
				 * startDayOfWeek
				 */
				startDayOfWeek: {
					defaultValue: 1
				},

				/**
				 * holidays
				 */
				holidays: {
					type: "object",
					defaultValue: []
				},

				/**
				 * vacations
				 */
				vacations: {
					type: "object",
					defaultValue: []
				}
			},
			events: {
				/**
				 * Event is fired when the user clicks on the control.
				 */
				press: {},

				/**
				 * Event is fired when the user clicks on the previous button.
				 */
				calendarNav: {},

				/**
				 * Event is fired when the user clicks on the previous button.
				 */
				beforeCalendarNav: {}
			},

			aggregations: {
				/**
				 * Calendar control
				 */
				_shortCalendar: {
					type: "sap.ui.unified.CalendarDateInterval",
					multiple: false,
					visibility: "hidden"
				},

				/**
				 * controls to navigate to previous and next calendar weeks
				 */
				_navCalendar: {
					type: "sap.m.FlexBox",
					multiple: false,
					visibility: "hidden"
				},

				/**
				 * Custom Legend Box
				 */
				_legends: {
					type: "sap.m.FlexBox",
					multiple: false,
					visibility: "hidden"
				},

				/**
				 * Date picker
				 */
				_datePicker: {
					type: "sap.m.DatePicker",
					multiple: false,
					visibility: "hidden"
				}
			}
		},

		dateServicesInstance: DateService.getInstance(),
		
		
		
		_setModel: function () {
			// const oModel = this.getModel();
			const oDayWeekTimesheetModel = MTRModels.getDayWeekTimesheetModel();
			const aEntries = oDayWeekTimesheetModel.getProperty("/Entries");
			// const expected = oDayWeekTimesheetModel.getProperty("/Expected");
			// const submitted = oDayWeekTimesheetModel.getProperty("/Submitted");
			// const saved = oDayWeekTimesheetModel.getProperty("/Saved");

			const oSettingsModel = MTRModels.getMTRSettingsModel();
			const aMTRTasks = oSettingsModel.getProperty("/MTRTasks");

			// const oSelectedActivity = this.getSelectedActivity();

			const oModel = new JSONModel({
				Entries: aEntries,
				MTRTasks: aMTRTasks
			});
			
			this.Model = oModel;
		},

		init: function () {
			that = this;
			that.setBusyIndicatorDelay(0);
			this.controller = new MatrixCalendarController(this);
			this._setModel();
			//initialisation code, in this case, ensure css is imported
			var libraryPath = jQuery.sap.getModulePath("com.melody.lib"); //get the server location of the ui library
			jQuery.sap.includeStyleSheet(libraryPath + "/controls/calendar/matrixCalendar.css"); //specify the css path relative from the ui folder
			jQuery.sap.includeStyleSheet(libraryPath + "/controls/calendar/matrixCreateEntry.css"); //specify the css path relative from the ui folder

			//initializion short calendar for mobile
			this.setAggregation("_shortCalendar", new CalendarDateInterval(that.getId() + "-shortCalendar", {
				showWeekNumbers: false,
				showDayNamesLine: false,
				specialDates: [],
				startDate: that._getStartDateOfWeek()
			}).addStyleClass("matrixDialogCalendar"));

			this.getAggregation("_shortCalendar").detachSelect(function () {
				return;
			});

			/*this.setAggregation("_datePicker", new sap.m.DatePicker({
				dateValue: that._getStartDateOfWeek(),
				hideInput: true,
				change: function (oEvent) {
					const oDatePicker = oEvent.getSource();
					const dDate = oDatePicker.getDateValue();
					const dMatrixSelectedStartDate = that._getStartDateOfWeek();
					let dFirstDate = null;
					if (dDate) {
						dFirstDate = that._getFirstDayOfWeek(dDate);
					}
					if (dFirstDate && dMatrixSelectedStartDate !== dFirstDate) {
						that._onWeekChange(dFirstDate);
					}
				}
			}));*/

			this.setAggregation("_navCalendar", new sap.m.FlexBox(that.getId() + "-navCalendar", {
				alignItems: "Center",
				justifyContent: "Center",
				items: [
					new sap.m.Button({
						text: "{i18n>matrixCalPreviousBtnTxt}",
						type: "Emphasized",
						press: that.onWeekChange
					}).data("isNext", false).addStyleClass("matrixPrevBt sapUiTinyMarginBeginEnd"),
					new sap.m.VBox({
						items: [
							new sap.m.Text({
								text: "{i18n>matrixCalHeaderLbl}"
							}).addStyleClass("currentWeek"),
							new sap.m.HBox({
								items: [
									new sap.m.Text(that.getId() + "-navCalendar-startDate", {
										text: that._getDate(that.getAggregation("_shortCalendar").getStartDate(), 0, true, true),
										wrapping: false
									}),
									new sap.m.Text({
										text: "-"
									}),
									new sap.m.Text(that.getId() + "-navCalendar-endDate", {
										text: that._getDate(that.getAggregation("_shortCalendar").getStartDate(), 6, true, true),
										wrapping: false
									}),
									new sap.ui.core.Icon({
										src: "sap-icon://appointment",
										press: function (event) {
											const core = sap.ui.getCore();
											
											if (core._pMelodyDatePickerPopover) {
												core._pMelodyDatePickerPopover.destroy();
												core._pMelodyDatePickerPopover = null;
											}
											
											// if (!core._pMelodyDatePickerPopover) {
												Fragment.load({
													id: "MelodyDatePickerPopover",
													name: "com.melody.lib.fragments.MTR.MelodyDatePickerPopover",
													controller: that.controller
												}).then(function(popover){
													core._pMelodyDatePickerPopover = popover;
													core._pMelodyDatePickerPopover.setModel(that.Model);
													core._pMelodyDatePickerPopover.openBy(event.getSource());
												   
													const oCalendar = sap.ui.core.Fragment.byId("MelodyDatePickerPopover", "melodyDatePicker").getAggregation("_calendar");
													oCalendar.setSingleSelection(false);
													const startDate = that._getStartDateOfWeek();
													that.controller._selectWeek(startDate, oCalendar);
												});
												/*core._pMelodyDatePickerPopover = sap.ui.xmlfragment("MelodyDatePickerPopover",
													"com.melody.lib.fragments.MTR.MelodyDatePickerPopover",
													that.controller);*/
											// } else {
												// core._pMelodyDatePickerPopover.setModel(that.Model);
												// core._pMelodyDatePickerPopover.openBy(event.getSource());
											// }
											
											/*setTimeout(function () {
												core._pMelodyDatePickerPopover.openBy(event.getSource());
											}, 1000);*/
											// setTimeout(function () {
												/*const oCalendar = sap.ui.core.Fragment.byId("MelodyDatePickerPopover", "melodyDatePicker").getAggregation("_calendar");
												oCalendar.setSingleSelection(false);
												const startDate = that._getStartDateOfWeek();
												that.controller._selectWeek(startDate, oCalendar);*/
											// }, 1000);
											
											
											
											// core._pMelodyDatePickerPopover.openBy(event.getSource());
											
										}
									}).addStyleClass("sapUiTinyMarginBegin")
								]
							})
						]
					}).addStyleClass("matrixPeriod"),
					new sap.m.Button({
						text: "{i18n>matrixCalNextBtnTxt}",
						type: "Emphasized",
						press: that.onWeekChange
					}).data("isNext", true).addStyleClass("matrixNextBt sapUiTinyMarginBeginEnd")
				]
			}).addStyleClass("matrixDialogCalendarHeader"));

			//initializion calendar navigation for mobile
			/*this.setAggregation("_navCalendar", new sap.m.HBox(that.getId() + "-navCalendar", {
				items: [
					new sap.m.Button({
						text: "{i18n>matrixCalPreviousBtnTxt}",
						type:"Emphasized",
						press: that.onWeekChange,
					}).data("isNext", false).addStyleClass("matrixPrevBt"),
					new sap.m.VBox({
						items: [
							new sap.m.Text({
								text: "{i18n>matrixCalHeaderLbl}"
							}).addStyleClass("currentWeek"),
							new sap.m.HBox({
								items: [
									new sap.m.Text(that.getId() + "-navCalendar-startDate", {
										text: that._getDate(that.getAggregation("_shortCalendar").getStartDate(), 0, true, true),
										wrapping: false
									}),
									new sap.m.Text({
										text: "-"
									}),
									new sap.m.Text(that.getId() + "-navCalendar-endDate", {
										text: that._getDate(that.getAggregation("_shortCalendar").getStartDate(), 6, true, true),
										wrapping: false
									}),
									new sap.m.DatePicker({
										dateValue: that._getStartDateOfWeek(),
										change: function (oEvent) {
											var oDatePicker = oEvent.getSource();
											var dDate = oDatePicker.getDateValue();
											var dMatrixSelectedStartDate = that._getStartDateOfWeek();
											var dFirstDate = null;
											if (dDate) {
												dFirstDate = that._getFirstDayOfWeek(dDate);
											}
											if (dFirstDate && dMatrixSelectedStartDate !== dFirstDate) {
												that._onWeekChange(dFirstDate);
											}
										}
									}).addStyleClass("matrixDatePicker")
								]
							})
						]
					}).addStyleClass("matrixPeriod"),
					new sap.m.Button({
						text: "{i18n>matrixCalNextBtnTxt}",
						type:"Emphasized",
						press: that.onWeekChange
					}).data("isNext", true).addStyleClass("matrixNextBt")
				]
			}).addStyleClass("matrixDialogCalendarHeader"));*/

			//initializion matrix calendar legends
			this.setAggregation("_legends", new sap.m.FlexBox(that.getId() + "-legends", {
				direction: "Column",
				alignItems: "Start",
				justifyContent: "Center",
				items: [
					new sap.m.Link({
						text: "{i18n>matrixCalTodayLegendTxt}",
						press: function () {
							var dDate = new Date();
							var dMatrixSelectedStartDate = that._getStartDateOfWeek();
							var dFirstDate = null;
							if (dDate) {
								dFirstDate = that._getFirstDayOfWeek(dDate);
							}
							if (dFirstDate && dMatrixSelectedStartDate !== dFirstDate) {
								that._onWeekChange(dFirstDate);
							}
						}
					}).addStyleClass("matrixLegend matrixTodayLegend matrixLegendLink"),
					new sap.m.Text({
						text: "{i18n>matrixCalHolidayLegendTxt}"
					}).addStyleClass("matrixLegend matrixHolidayLegend"),
					new sap.m.Text({
						text: "{i18n>matrixCalWeekendLegendTxt}"
					}).addStyleClass("matrixLegend matrixWeekendLegend")
				]
			}).addStyleClass("matrixDialogCalendarLegends"));

			/*this.setAggregation("_legends", new sap.m.VBox(that.getId() + "-legends", {
				items: [
					new sap.m.Link({
						text: "{i18n>matrixCalTodayLegendTxt}",
						press: function (oEvent) {
							var dDate = new Date();
							var dMatrixSelectedStartDate = that._getStartDateOfWeek();
							var dFirstDate = null;
							if (dDate) {
								dFirstDate = that._getFirstDayOfWeek(dDate);
							}
							if (dFirstDate && dMatrixSelectedStartDate !== dFirstDate) {
								that._onWeekChange(dFirstDate);
							}
						}
					}).addStyleClass("matrixLegend matrixTodayLegend matrixLegendLink"),
					new sap.m.Text({
						text: "{i18n>matrixCalHolidayLegendTxt}"
					}).addStyleClass("matrixLegend matrixHolidayLegend"),
					new sap.m.Text({
						text: "{i18n>matrixCalWeekendLegendTxt}"
					}).addStyleClass("matrixLegend matrixWeekendLegend")
				]
			}).addStyleClass("matrixCalendarLegends"));*/
			const core = sap.ui.getCore();
			if (core._pMelodyDatePickerPopover) {
				const oCalendar = sap.ui.core.Fragment.byId("MelodyDatePickerPopover", "melodyDatePicker").getAggregation("_calendar");
				oCalendar.setInitialFocusedDate(new Date());
			}
		},

		_getDate: function (date, days, isNext, returnFormatted) {
			var calendarDateFormat = sap.ui.core.format.DateFormat.getInstance({
				pattern: "MMMM dd, yyyy",
				calendarType: sap.ui.core.CalendarType.Gregorian
			});
			var dt;
			if (isNext) {
				dt = new Date(date.getTime() + (days * 24 * 60 * 60 * 1000));

			} else {
				dt = new Date(date.getTime() - (days * 24 * 60 * 60 * 1000));
			}

			dt = this.adjustDateForDST(dt);

			if (returnFormatted) {
				return calendarDateFormat.format(dt);
			} else {
				return dt;
			}
		},

		setValid: function (bValue) {
			this.setProperty("valid", bValue);
		},

		setHolidays: function (aHolidays) {
			var calendar = this.getAggregation("_shortCalendar");
			for (var i = 0; i < aHolidays.length; i++) {
				var dHoliday = this.dateServicesInstance.formatStringDate(aHolidays[i]);
				var holiday = new sap.ui.unified.DateTypeRange({
					startDate: dHoliday,
					type: "Type01",
					color: "#537581",
					tooltip: "{i18n>matrixCalHolidayTooltip}"
				});
				calendar.addSpecialDate(holiday);
			}
			this._setCalendarSettings();
		},

		setVacations: function (aVacations) {
			var calendar = this.getAggregation("_shortCalendar");
			for (var i = 0; i < aVacations.length; i++) {
				var dHoliday = this.dateServicesInstance.formatStringDate(aVacations[i]);
				var holiday = new sap.ui.unified.DateTypeRange({
					startDate: dHoliday,
					type: "Type02",
					color: "#537581",
					tooltip: "{i18n>matrixCalVacationTooltip}"
				});
				calendar.addSpecialDate(holiday);
			}
			this._setCalendarSettings();
		},

		onWeekChange: function (oEvent) {
			var isNext = oEvent.getSource().data("isNext");
			var currentStartDate = that.getAggregation("_shortCalendar").getStartDate();
			var nextStartDate = that._getDate(currentStartDate, 7, isNext, false);
			that._onWeekChange(nextStartDate);
		},

		_onWeekChange: function (nextStartDate, isNext) {

			that.fireBeforeCalendarNav();

			if (that.getValid()) {
				that.getAggregation("_shortCalendar").setStartDate(nextStartDate);
				jQuery.sap.byId(that.getId() + "-navCalendar-startDate")[0].innerText = that._getDate(that.getAggregation("_shortCalendar").getStartDate(),
					0, true, true);
				jQuery.sap.byId(that.getId() + "-navCalendar-endDate")[0].innerText = that._getDate(that.getAggregation("_shortCalendar").getStartDate(),
					6, true, true);
				var currentStartDateOfWeek = that.dateServicesInstance.getStartDateOfWeek(new Date());
				if (currentStartDateOfWeek.getFullYear() === nextStartDate.getFullYear() &&
					currentStartDateOfWeek.getMonth() === nextStartDate.getMonth() &&
					currentStartDateOfWeek.getDate() === nextStartDate.getDate()) {
					that.getAggregation("_navCalendar").getAggregation("items")[1].getAggregation("items")[0].setText("CURRENT WEEK");
				} else {
					var weekNumber = that.dateServicesInstance.getWeek(nextStartDate);
					that.getAggregation("_navCalendar").getAggregation("items")[1].getAggregation("items")[0].setText("WEEK" + " " + weekNumber);
				}
				that._setCalendarSettings();
				that.fireCalendarNav();
			}
		},

		getWeekends: function () {
			var iStartDayfOfWeek = parseInt(this.getStartDayOfWeek(), 10);
			var firstWeekend = 5 + iStartDayfOfWeek;
			if (firstWeekend > 6) {
				firstWeekend = firstWeekend - 7;
			}
			var secondWeekend = 6 + iStartDayfOfWeek;
			if (secondWeekend > 6) {
				secondWeekend = secondWeekend - 7;
			}
			return [firstWeekend, secondWeekend];
		},

		setStartDayOfWeek: function (fValue) {
			this.setProperty("startDayOfWeek", fValue);
			this.getAggregation("_shortCalendar").setStartDate(that._getStartDateOfWeek());
			this.getAggregation("_navCalendar").getAggregation("items")[1].getAggregation("items")[1].getAggregation("items")[0].setText(that._getDate(
				that.getAggregation("_shortCalendar").getStartDate(), 0, true, true));
			this.getAggregation("_navCalendar").getAggregation("items")[1].getAggregation("items")[1].getAggregation("items")[2].setText(that._getDate(
				that.getAggregation("_shortCalendar").getStartDate(), 6, true, true));
			this._setCalendarSettings();
		},

		setStartDate: function (dDate) {
			this.getAggregation("_shortCalendar").setStartDate(dDate);
			this.getAggregation("_navCalendar").getAggregation("items")[1].getAggregation("items")[1].getAggregation("items")[0].setText(that._getDate(
				that.getAggregation("_shortCalendar").getStartDate(), 0, true, true));
			this.getAggregation("_navCalendar").getAggregation("items")[1].getAggregation("items")[1].getAggregation("items")[2].setText(that._getDate(
				that.getAggregation("_shortCalendar").getStartDate(), 6, true, true));
			this._setCalendarSettings(dDate);
			this._setCalendarWeekText(dDate);
		},

		_getStartDateOfWeek: function () {
			var cal = this.getAggregation("_shortCalendar");
			var d;
			if (cal) {
				d = cal.getStartDate();
			} else {
				d = new Date();
			}
			return this._getFirstDayOfWeek(d);
		},

		_getFirstDayOfWeek: function (d) {
			return this.dateServicesInstance.getStartDateOfWeek(d);
			/*var day = d.getDay(),
			  diff = d.getDate() - day + (day === 0 ? -6 : parseInt(this.dateServicesInstance.getStartDateOfWeek(), 10));
			return new Date(d.setDate(diff));*/
		},

		onAfterRendering: function () {
			this._setCalendarSettings();
		},

		_setCalendarSettings: function () {
			setTimeout(function () {
				var oResourceBundle = that.getModel("i18n").getResourceBundle();
				var todayElement = $("#" + that.getId() + "-shortCalendar--Month0").find(".sapUiCalItem.sapUiCalItemNow");
				if (todayElement.has("span.dateLabel").length === 0) {
					todayElement.append("<span class='dateLabel todayLabel'>" + oResourceBundle.getText("matrixCalTodayLbl") + "</span>");
				}
				if (todayElement.hasClass("sapUiCalItemType01") || todayElement.hasClass("sapUiCalItemType02")) {
					todayElement.find(".dateLabel").text(todayElement.attr("title"));
				}

				var holidayElement = $("#" + that.getId() + "-shortCalendar--Month0").find(".sapUiCalItem.sapUiCalItemType01");
				var vacationElement = $("#" + that.getId() + "-shortCalendar--Month0").find(".sapUiCalItem.sapUiCalItemType02");
				if (holidayElement.has("span.dateLabel").length === 0) {
					holidayElement.append("<span class='dateLabel'>" + holidayElement.attr("title") + "</span>");
				}
				if (vacationElement.has("span.dateLabel").length === 0) {
					vacationElement.append("<span class='dateLabel'>" + vacationElement.attr("title") + "</span>");
				}
			}, 1000);
		},

		_setCalendarWeekText: function (startDate) {
			var currentStartDateOfWeek = that.dateServicesInstance.getStartDateOfWeek(new Date());
			if (currentStartDateOfWeek.getFullYear() === startDate.getFullYear() &&
				currentStartDateOfWeek.getMonth() === startDate.getMonth() &&
				currentStartDateOfWeek.getDate() === startDate.getDate()) {
				that.getAggregation("_navCalendar").getAggregation("items")[1].getAggregation("items")[0].setText("CURRENT WEEK");
			} else {
				var weekNumber = that.dateServicesInstance.getWeek(startDate);
				that.getAggregation("_navCalendar").getAggregation("items")[1].getAggregation("items")[0].setText("WEEK" + " " + weekNumber);
			}
		},

		adjustDateForDST: function (date = new Date()) {
			const year = date.getFullYear();
			// Get the offsets for January (non-DST in most regions) and July (DST in most regions)
			const janOffset = new Date(year, 0, 1).getTimezoneOffset(); // January 1st
			const julOffset = new Date(year, 6, 1).getTimezoneOffset(); // July 1st

			// Determine the larger offset (standard time) and the smaller offset (DST time)
			const standardOffset = Math.max(janOffset, julOffset);
			const dstOffset = Math.min(janOffset, julOffset);

			// Current offset
			//const currentOffset = date.getTimezoneOffset();
			// Adjust the date if DST is active
			//if (currentOffset === dstOffset) {
			// DST is active, adjust time to standard offset
			const adjustment = (standardOffset - dstOffset) * 60000; // in milliseconds
			return new Date(date.getTime() + adjustment); // Adjusted to standard time
			//}

			// If not in DST, return the original date
			//	return date;
		}
	});
	return MatrixCalendar;
}, /* bExport= */ true);