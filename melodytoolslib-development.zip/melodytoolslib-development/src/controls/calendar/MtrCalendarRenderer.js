/*!
 * ${copyright}
 */

sap.ui.define(["jquery.sap.global"],

	function ( /*jQuery*/ ) {
		"use strict";

		/**
		 * DayWeekCalendar renderer.
		 * @namespace
		 */
		var MtrCalendarRenderer = {};

		/**
		 * Renders the HTML for the given control, using the provided
		 * {@link sap.ui.core.RenderManager}.
		 *
		 * @param {sap.ui.core.RenderManager} oRm
		 *            the RenderManager that can be used for writing to
		 *            the Render-Output-Buffer
		 * @param {sap.ui.core.Control} oControl
		 *            the control to be rendered
		 */
		MtrCalendarRenderer.render = function (oRm, oControl) {

			//first up, render a div for the DayWeekCalendar
			oRm.write("<div");

			oRm.writeClasses(oControl);

			oRm.write(" style=\"width: " + oControl.getWidth() + "; position: relative" + "\"");

			//next, render the control information, this handles your sId (you must do this for your control to be properly tracked by ui5).
			oRm.writeControlData(oControl);
			oRm.write(">");

			oRm.renderControl(oControl.getAggregation("_calendar"));
			
			oRm.renderControl(oControl.getAggregation("_legendBox"));
			
			//and obviously, close off our div
			oRm.write("</div>");
		};

		return MtrCalendarRenderer;

	}, /* bExport= */ true);