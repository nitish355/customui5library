/*!
 * ${copyright}
 */

sap.ui.define(['jquery.sap.global'],

	function (jQuery) {
		"use strict";

		/**
		 * UserSettings renderer.
		 * @namespace
		 */
		var UserSettingsRenderer = {};

		/**
		 * Renders the HTML for the given control, using the provided
		 * {@link sap.ui.core.RenderManager}.
		 *
		 * @param {sap.ui.core.RenderManager} oRm
		 *            the RenderManager that can be used for writing to
		 *            the Render-Output-Buffer
		 * @param Control oControl
		 *            the control to be rendered
		 */
		UserSettingsRenderer.render = function (oRm, oControl) {
			oRm.write("<div");
			//add this controls style class (plus any additional ones the developer has specified)
			oRm.writeClasses(oControl);
			//next, render the control information, this handles your sId (you must do this for your control to be properly tracked by ui5).
			oRm.writeControlData(oControl);
			oRm.write(">");
			oRm.renderControl(oControl.getAggregation("_button"));
			oRm.write("</div>");
		};

		return UserSettingsRenderer;

	}, /* bExport= */ true);