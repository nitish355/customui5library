/*!
 * ${copyright}
 */

// Provides control com.melody.lib.
sap.ui.define(["jquery.sap.global",
		"sap/ui/Device",
		"sap/ui/core/Control",
		"sap/m/MessageToast",
		"sap/ui/model/Filter",
		"sap/ui/core/Fragment",
		"sap/ui/model/FilterOperator",
		"sap/ui/model/json/JSONModel",
		"com/melody/lib/enum/Actions",
		"com/melody/lib/enum/InputType",
		"com/melody/lib/model/StorageModel",
		"com/melody/lib/util/account/Account",
		"com/melody/lib/util/account/AccountHelper",
		"com/melody/lib/util/opportunity/Opportunity",
		"com/melody/lib/util/account/AccountDialogController"
	],
	function (jQuery, Device, Control, MessageToast, Filter, Fragment, FilterOperator, JSONModel, Actions, InputType, oStorageModel,
		AccountUtil,
		AccountHelper,
		OpportunityUtil, AccountDialogController) {
		"use strict";

		/**
		 * Constructor for a new AccountControl Control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends  Control
		 *
		 * @author SAP SE
		 * @version ${version}
		 *
		 * @constructor
		 * @public
		 * @alias com.melody.lib.controls.AccountControl
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */
		let that;
		var oAccountControl = Control.extend("com.melody.lib.controls.AccountControl", {
			metadata: {
				properties: {
					selectedAccount: {
						type: "object",
						defaultValue: null
					},
					opportunityCtrlId: {
						type: "string",
						defaultValue: null
					},
					accountId: {
						type: "string",
						defaultValue: null
					},
					projectType: {
						type: "string",
						defaultValue: null
					},
					controlType: {
						type: "string",
						defaultValue: Actions.Input
					},
					icon: {
						type: "string",
						defaultValue: null
					},
					editable: {
						type: "boolean",
						defaultValue: true
					},
					_showClearIcon: {
						type: "boolean",
						defaultValue: false,
					},
					_showInfoIcon: {
						type: "boolean",
						defaultValue: false,
					},
					executeOnChangeId: {
						type: "boolean",
						defaultValue: false,
					},
					applicationType: {
						type: "string",
						defaultValue: "ACTVT"
					}
				},
				events: {
					valueHelpRequest: {},
					selectedItem: {
						"accountData": {
							type: "object"
						}
					},
					clearSelectedItem: {
						"reset": {
							type: "boolean"
						}
					}
				},
				aggregations: {
					_input: {
						type: "sap.m.Input",
						multiple: false,
						visibility: "hidden"
					},
					_button: {
						type: "sap.m.Button",
						multiple: false,
						visibility: "hidden"
					},
					_accountinfobutton: {
						type: "sap.ui.core.Icon",
						multiple: false,
						visibility: "hidden"
					},
					_clearIcon: {
						type: "sap.ui.core.Icon",
						multiple: false,
						visibility: "hidden"
					},
					_icon: {
						type: "sap.ui.core.Icon",
						multiple: false,
						visibility: "hidden"
					}
				}
			},

			/**
			 * @private
			 * @author DARSHAN
			 * @function setEditable
			 * @description function to set editable to Account fields
			 * @param {Boolean} bVisible
			 */
			setEditable: function (bEditable = false) {
				this.setProperty("editable", bEditable);
				let oSelectedAccount = this.getProperty("selectedAccount") || {};
				let inputContrl = this.getAggregation("_input");
				if (inputContrl) {
					inputContrl.setEditable(bEditable);
				}
				if ("AccountId" in oSelectedAccount && oSelectedAccount.AccountId && bEditable) {
					this._setControlVisibility("EDIT");
				}
			},

			/**
			 * @private
			 * @author DARSHAN
			 * @function executeOnChangeId
			 * @description function to decide fire event
			 * @param {Boolean} bFire
			 * This case is needed in MTR Matrix list view
			 */
			setExecuteOnChangeId: function (bEditable = false) {
				this.setProperty("executeOnChangeId", bEditable);
			},

			/**
			 * @private
			 * @author DARSHAN
			 * @function setOpportunityId
			 * @description function to set editable to Account fields
			 * @param {String} accountId
			 * Need to Improve this
			 */
			setAccountId: async function (accountId) {
				const controlId = this.getId();
				let controlSrc = this;
				try {
					const domRef = controlSrc.getDomRef();
					controlSrc.setProperty("accountId", accountId);
					if (!accountId) {
						controlSrc.setSelectedAccount();
						return;
					}
					const editable = controlSrc.getProperty("editable");
					let controlType = controlSrc.getProperty("controlType");
					let applicationType = controlSrc.getProperty("applicationType");
					controlType = (controlType) ? controlType.toUpperCase() : "";
					let selectedAccount = controlSrc.getProperty("selectedAccount") || {};

					//Matrix view
					if (applicationType === Actions.applicationType.matrix && controlType === Actions.Icon) {
						return;
					}

					if (accountId) {
						controlSrc.setBusy(true);
						controlSrc.setInputBusy(true);
						let accountData = await controlSrc.AccountUtil.getAccountDetails(accountId);
						let execute = controlSrc.getProperty("executeOnChangeId") || false;
						controlSrc.setSelectedAccount(accountData, execute);
						controlSrc.setInputBusy(false);
						controlSrc.setBusy(false);
					}
				} catch (error) {
					controlSrc.setInputBusy(false);
					controlSrc.setBusy(false);
					console.log("ERROR IN ACCOUNT CONTROL :", error);
				}
			},

			/**
			 * @public
			 * @author DARSHAN
			 * @function setApplicationType
			 * @description function to set application Type
			 * @param {Boolean} bVisible
			 * This has be improvised during new implementation or in BAS Library
			 */
			setApplicationType: function (type) {
				this.setProperty("applicationType", type);
			},

			/**
			 * @private
			 * @author DARSHAN
			 * @function setInputBusy
			 * @description function to set input control busy
			 * @param {Boolean} bVisible
			 */
			setInputBusy: function (bBusy) {
				let inputContrl = this.getAggregation("_input");
				if (inputContrl) {
					inputContrl.setBusy(bBusy);
				}
			},

			/**
			 * @private
			 * @author DARSHAN
			 * @function _showClearIcon
			 * @description function to set clear icon vibility
			 * @param {Boolean} bVisible
			 */
			_showClearIcon(bVisible) {
				this.setProperty("_showClearIcon", bVisible);
				let clearIcon = this.getAggregation("_clearIcon");
				if (clearIcon) {
					clearIcon.setVisible(bVisible);
				}
				return this;
			},

			/**
			 * @private
			 * @author DARSHAN
			 * @function _showInfoIcon
			 * @description function to set info icon vibility
			 * @param {Boolean} bVisible
			 */
			_showInfoIcon(bVisible) {
				this.setProperty("_showInfoIcon", bVisible);
				let infoIcon = this.getAggregation("_accountinfobutton");
				if (infoIcon) {
					infoIcon.setVisible(bVisible);
				}
				return this;
			},

			//function to set account data to control
			setSelectedAccount: function (oValue = {}, executeEvent = true) {
				let oAccount = null,
					sAccountId = "",
					sAccountName = "";
				let bControlEdtiable = this.getEditable();
				const accountId = this.getProperty("accountId");
				const inputControl = this.getAggregation("_input");
				if (oValue && Object.keys(oValue).length) {
					oAccount = oValue;
					if (oAccount.AccountId) {
						sAccountId = oAccount.AccountId;
					}
					if (oAccount.AccountName) {
						sAccountName = oAccount.AccountName;
					}
				}

				if (oAccount) {
					if (inputControl) {
						inputControl.setValue(sAccountId + "-" + sAccountName);
						inputControl.setTooltip(sAccountId + "-" + sAccountName);
					}
					if (sAccountId) {
						this.setProperty("accountId", sAccountId);
					}
				} else {
					if (inputControl) {
						inputControl.setValue("");
						inputControl.setTooltip("");
					}
					this._setControlVisibility("CREATE");
				}
				this.setProperty("selectedAccount", oAccount);

				if (bControlEdtiable && oAccount) {
					this._setControlVisibility("EDIT");
				}

				if (!oAccount) {
					return;
				}
				if (bControlEdtiable && executeEvent) {
					this.fireEvent("selectedItem", {
						accountData: oAccount
					});
				}
			},

			init: function () {
				that = this;
				this.setAggregation("_input", new sap.m.Input(this.getId() + "-input", {
					valueHelpOnly: true,
					showValueHelp: true,
					valueLiveUpdate: true,
					valueHelpRequest: this.onAccountValueHelp.bind(this),
					liveChange: this.onAccountSearchChange
				}));

				this.setAggregation("_button", new sap.m.Button(this.getId() + "-accountbtn", {
					text: "",
					press: this.onAccountButtonPress.bind(this)
				}));

				this.setAggregation("_accountinfobutton", new sap.ui.core.Icon(this.getId() + "-accountinfobtn", {
					visible: false,
					press: this.onAccountInfoButtonPress.bind(this)
				}));

				this.setAggregation("_clearIcon", new sap.ui.core.Icon(this.getId() + "-accountclearicon", {
					visible: false,
					tooltip: "Remove",
					press: this.onAccountClearButtonPress.bind(this)
				}));

				this.setAggregation("_icon", new sap.ui.core.Icon(this.getId() + "-accounticon", {
					press: this.onAccountButtonPress.bind(this)
				}));

				const oModel = new JSONModel({
					Accounts: [],
					SearchedAccounts: [],
					Searching: false
				});

				const oEssentialModel = new JSONModel({
					aIndustry: [],
					aRegion: [],
					aCountryMasterData: [],
					bClearIconVisible: false,
					bShowAccountInfoPopup: false,
				});
				oEssentialModel.setSizeLimit(9999);
				this.setModel(oModel);
				this.setModel(oEssentialModel, Actions.oModels.EssentialModel);

				//BOUND FILES
				this.fnBoundUtilFiles();

				AccountUtil.fnStaticInit(this);
			},

			onBeforeRendering: function () {

			},

			//TODO:Need to improve
			filters: [],

			_getMyAccounts: function () {
				AccountUtil.getMyAccounts()
					.then((accounts) => {
						let oPrerequisiteModel = that.getModel(Actions.oModels.PrerequisiteModel)
						if (!aMyAccounts.length) {

						}
					}).catch((oError) => {
						console.log("GET_MY_ACCOUNTS: ", oError);
						MessageToast.show("Error");
					});
			},

			onAfterRendering: function () {
				that.OpportunityUtil = OpportunityUtil;
			},

			onAccountValueHelp: async function (oEvent) {
				const accountCtrl = oEvent.getSource().getParent();
				let oAccountSearchModel = accountCtrl.getModel();

				//BOUND REQUERIED FILE
				let fnSetBoundFiles = accountCtrl.fnBoundUtilFiles.bind(accountCtrl)
				fnSetBoundFiles();

				//SET DIALOG CONTROLLER
				accountCtrl.fnSetDialogController(accountCtrl);

				let sSearchQuery = oAccountSearchModel.getProperty("/sSearchQuery");
				const oEssentialModel = accountCtrl.getModel(Actions.oModels.EssentialModel);
				let aCountryMasterData = $.extend(true, [], oEssentialModel.getProperty("/aCountryMasterData"));
				let fnOpenAccountSearchDialog = AccountHelper.onInitializeAccountDialog.bind(accountCtrl);
				await fnOpenAccountSearchDialog(true);
				const oResponse = await AccountUtil.getCountryMasterData();
				let sAccountQuery = oStorageModel.getProperty("/sAccountSearchQuery");
				const aTempCountryMasterData = oResponse.data.results || [];
				if (!aCountryMasterData.length) {
					oEssentialModel.setProperty("/aCountryMasterData", aTempCountryMasterData);
				}
				oAccountSearchModel.setProperty("/selectedIconTabKey", Actions.AdvanceAccountSearch);

				if (sSearchQuery) {
					let eventType = "string";
					accountCtrl.AccountHelper.fnAccountSearchHandler(sSearchQuery, Actions.AdvanceAccountSearch, eventType);
				}
				oEssentialModel.refresh();
			},

			onAccountSearchChange: function (oEvent) {

			},

			//Function to initialize the Dialog controller for Account Control
			fnSetDialogController: function (accountCtrl) {
				if (!accountCtrl.AccountDialogController) {
					accountCtrl.AccountDialogController = new AccountDialogController(accountCtrl);
				} else {
					accountCtrl.AccountDialogController.accountCtrl = accountCtrl;
				}
				accountCtrl.AccountDialogController.fnLoadLangModel = accountCtrl.AccountHelper.fnLoadResourceBundle;
			},

			//function to handle button or icon press
			onAccountButtonPress: function (oEvent) {
				this.onAccountValueHelp(oEvent);
			},

			//function to handle clear button
			onAccountClearButtonPress: function (oEvent) {
				let oAccCtrlSource = oEvent.getSource().getParent();
				let oDefaultModel = oAccCtrlSource.getModel();

				const oOpportunityCtrl = oAccCtrlSource.fnGetOpportunityControl();
				//Reset Opportunity Control Data
				if (oOpportunityCtrl) {
					const oOppDefaultModel = oOpportunityCtrl.getModel() || false;
					if (oOppDefaultModel) {
						oOppDefaultModel.setProperty("/isCvaSelected", false);
						oOppDefaultModel.setProperty("/oSelectedAccountDetails", "");
						oOppDefaultModel.setProperty("/bFilterNonVatAccBased", false);
						oOppDefaultModel.setProperty("/bRemoveNonVAtAccFilter", true);
						oOpportunityCtrl.getAggregation("_input").setValue("");
						oOpportunityCtrl.getAggregation("_input").setTooltip("");
						oOpportunityCtrl._setControlVisibility("CREATE");
						oOppDefaultModel.refresh();
					}
				}

				oAccCtrlSource.setAccountId("");
				// oAccCtrlSource.setSelectedAccount(null);
				oAccCtrlSource._setControlVisibility("CREATE");
				oDefaultModel.refresh();

				const oEssentialModel = oAccCtrlSource.getModel(Actions.oModels.EssentialModel);
				oStorageModel.setProperty("/aCvaAccountData", []);
				oStorageModel.setProperty("/aCvaModelAccountData", []);
				oStorageModel.setProperty("/aCvaModelMyAccountData", []);
				oStorageModel.setProperty("/oAppBasedAccountData", {
					isAccountDataLoaded: false
				});

				oStorageModel.refresh();
				oEssentialModel.refresh();
				this.fireEvent("clearSelectedItem", {
					reset: true
				});
			},

			//function to handle Account Info Button
			onAccountInfoButtonPress: function (oEvent) {
				let oControlSource = oEvent.getSource();
				let oParentCtrlSrc = oEvent.getSource().getParent();
				let accountId = oParentCtrlSrc.getProperty("accountId");

				//SET DIALOG CONTROLLER
				oParentCtrlSrc.fnSetDialogController(oParentCtrlSrc);

				let oModel = oParentCtrlSrc.getModel();
				oModel.setProperty("/infoPopoverBusy", true);
				let selectedAccount = oParentCtrlSrc.getProperty("selectedAccount");
				let validId = (selectedAccount && "AccountId" in selectedAccount && selectedAccount.AccountId) ? true : false;

				//In Case Of Matrix Existing Activity, selectedAccount will be empty
				if (!validId && accountId) {
					this.AccountUtil.getAccountDetails(accountId).then((accountData) => {
						this.setProperty("selectedAccount", accountData);
						oModel.setProperty("/oSelectedAccountData", accountData);
						oModel.setProperty("/infoPopoverBusy", false);
						oModel.refresh();
					});
				} else {
					oModel.setProperty("/oSelectedAccountData", selectedAccount);
					oModel.setProperty("/infoPopoverBusy", false);
				}
				oModel.refresh();
				let fnOpenAccountInfo = AccountHelper.onAccountInformationHandler.bind(oParentCtrlSrc);
				fnOpenAccountInfo(oControlSource);
			},

			//function to handle icons visibility
			_setControlVisibility: function (mode) {
				let clearIcon = false;
				let infoIcon = false;
				switch (mode) {
				case "DISPLAY":
					clearIcon = false;
					infoIcon = true;
					break;
				case "CREATE":
					clearIcon = false;
					infoIcon = false;
					break;
				default:
					clearIcon = true;
					infoIcon = true;
				}
				this._showClearIcon(clearIcon);
				this._showInfoIcon(infoIcon);
			},

			/**
			 * @author DARSHAN
			 * @function
			 * @purpose Function to bound util files to controls.
			 * NOTE: Always call this function using .bind()
			 */
			fnBoundUtilFiles: function () {
				this.AccountUtil = Object.create(AccountUtil);
				this.AccountHelper = Object.create(AccountHelper);
				this.AccountHelper.fnStaticInit(this);

				//CREATE A SELF REF WHICH POITNS TO THE CONTROL FROM THE UTIL FILES
				this.AccountUtil.accountCtrl = this;
				this.AccountHelper.accountCtrl = this;
			},

			//Function to return the opportunityControl Source
			fnGetOpportunityControl: function () {
				let oControl;
				const regex = /_[a-zA-Z][^_]*\d_/;
				let sAccountCtrlId = this.getId();
				let sOpportunityCtrlId = this.getOpportunityCtrlId();
				if (!sOpportunityCtrlId) {
					return false;
				}
				let tempAccountCtrlId = sAccountCtrlId.match(regex);
				let tempOpportunityCtrlId = sOpportunityCtrlId.match(regex);
				if (tempOpportunityCtrlId && tempAccountCtrlId) {
					tempOpportunityCtrlId = tempOpportunityCtrlId[0];
					// sOpportunityCtrlId = sAccountCtrlId.replace(regex, tempOpportunityCtrlId);
					sOpportunityCtrlId = sAccountCtrlId.replace(tempAccountCtrlId, tempOpportunityCtrlId);
					oControl = sap.ui.getCore().byId(sOpportunityCtrlId);
				}
				return oControl || false;
			}

		});

		return oAccountControl;
	}, /* bExport= */ true);