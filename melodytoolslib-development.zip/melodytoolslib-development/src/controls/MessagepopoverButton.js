/*!
 * ${copyright}
 */
// Provides control com.melody.lib.controls.TimeRecordButton.
sap.ui.define([
		"sap/m/Button",
		"sap/ui/Device",
		"sap/ui/core/Control",
		"sap/ui/core/Fragment",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"sap/ui/model/json/JSONModel",
		"com/melody/lib/util/mtr/MTRModels",
		"com/melody/lib/util/message/Message",
		"com/melody/lib/util/message/MessageHelper",
	],
	function (Button, Device, Control, Fragment, Filter, FilterOperator, JSONModel, MTRModels, MessageUtil, MessageHelper) {
		"use strict";
		/**
		 * Constructor for a TimeRecordButton control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends sap/ui/core/Control
		 *
		 * @author SAP SE
		 * @version ${version}
		 *
		 * @constructor
		 * @private
		 * @alias com.melody.lib.controls.TimeRecordButton
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */
		let oController;
		var MessagepopoverButton = Button.extend("com.melody.lib.controls.MessagepopoverButton", {
			metadata: {
				properties: {
					activityId: {
						type: "string",
						defaultValue: null
					}
				}
			},

			init: function () {
				this.addStyleClass("sapMessagePopoverCustomBtn");
				oController = this;
				this.setType("Emphasized");
				this.setIcon("sap-icon://alert");
				let oMessageModel = MTRModels.getMessagesModel();
				this.setModel(oMessageModel, "messages");
				MessageUtil.fnStaticInit(this);
				let fnTextFormatter = this.fnFormatterFunctionForText.bind(this);
				this.bindProperty("text", {
					path: 'messages>/',
					formatter: fnTextFormatter
				});

				let fnBooleanFormatter = this.fnFormatterFunctionForBoolean.bind(this);
				this.bindProperty("enabled", {
					path: 'messages>/',
					formatter: fnBooleanFormatter
				});
				let oButtonPress = oController.onPressMessagePopoverBtn.bind(this);
				this.attachPress(function (oEvent) {
					oButtonPress(oEvent);
				});
			},

			//formatter function for Text
			fnFormatterFunctionForText: async function (value) {
				let oThis = this;
				oThis.setBusy(true);
				await new Promise((resolve) => setTimeout(resolve, 1000));
				let oMessagePopoverModel = MTRModels.getMessagePopoverModel();
				value = (value) ? value : [];
				let activityId = oThis.getActivityId();
				if (activityId) {
					value = value.filter((oMessage) => {
						if (oMessage.hasOwnProperty("activityId")) {
							oMessage.activityId = (oMessage.activityId) ? oMessage.activityId.replace(/^0+/, '') : "";
							if (oMessage.activityId === activityId) {
								return true;
							}
						}
					});
					oThis.setBusy(false);
					return value.length;
				}
				oThis.setBusy(false);
				return value.length;
			},

			//formatter function for Boolean
			fnFormatterFunctionForBoolean: async function (value) {
				let oThis = this;
				oThis.setBusy(true);
				await new Promise((resolve) => setTimeout(resolve, 1000));
				let oMessagePopoverModel = MTRModels.getMessagePopoverModel();
				value = (value) ? value : [];
				let activityId = oThis.getActivityId();
				if (activityId) {
					value = value.filter((oMessage) => {
						if (oMessage.hasOwnProperty("activityId")) {
							oMessage.activityId = (oMessage.activityId) ? oMessage.activityId.replace(/^0+/, '') : "";
							if (oMessage.activityId === activityId) {
								return true;
							}
						}
					});
					oThis.setBusy(false);
					return (value.length) ? true : false;
				}
				oThis.setBusy(false);
				return (value.length) ? true : false;
			},

			//function to handle Press Event
			onPressMessagePopoverBtn: function (oEvent) {
				let oModel = this.getModel();
				let activityId = oEvent.getSource().getActivityId();
				let oMessageModel = MTRModels.getMessagesModel();
				let oMessagePopoverModel = MTRModels.getMessagePopoverModel();
				let sOpenedDialog = oMessagePopoverModel.getProperty("/sMsgPopoverId");
				let oOpenedPreviousDialog = sap.ui.getCore().byId(sOpenedDialog);
				if (oOpenedPreviousDialog) {
					let bOpened = (typeof oOpenedPreviousDialog.isOpen === "function") ? oOpenedPreviousDialog.isOpen() : false;
					if(bOpened){
						oOpenedPreviousDialog.close();
					}
				}
				if (oMessageModel) {
					let aMessageData = $.extend(true, [], oMessageModel.getData());
					if (activityId) {
						aMessageData = MessageHelper.fnFilterRecordByActivityId(aMessageData, activityId);
					}
					oMessagePopoverModel.setProperty("/aMessageData", aMessageData);
				}
				let onLoadMessagePopover = MessageHelper.onInitializeMessageDialog.bind(this);
				const oSource = oEvent ? oEvent.getSource() : null;
				if (oSource) {
					onLoadMessagePopover(oSource);
				}
			},

			onAfterRendering: function () {

			},

			renderer: {
				render: function (oRm, oControl) {
					sap.m.ButtonRenderer.render(oRm, oControl);
				}
			}
		});

		return MessagepopoverButton;
	}, /* bExport= */ true);