/*!
 * ${copyright}
 */

/**
 * Initialization Code and shared classes of library com.melody.lib.
 */
sap.ui.define(["sap/ui/core/library"], // library dependency
	function () {

		"use strict";

		/**
		 * 
		 *
		 * @namespace
		 * @name com.melody.lib
		 * @author SAP SE
		 * @version 1.0.0
		 * @public
		 */

		// delegate further initialization of this library to the Core
		sap.ui.getCore().initLibrary({
			name: "com.melody.lib",
			version: "1.0.0",
			dependencies: ["sap.ui.core"],
			types: [],
			interfaces: [],
			controls: [
				"com.melody.lib.controls.AccountInput",
				"com.melody.lib.controls.AccountControl",
				"com.melody.lib.controls.OpportunityInput",
				"com.melody.lib.controls.OpportunityControl",
				"com.melody.lib.controls.QuickNavMenu",
				"com.melody.lib.controls.UserSettings",
				"com.melody.lib.controls.mtr.TimeRecordButton",
				"com.melody.lib.controls.calendar.DayWeekCalendar",
				"com.melody.lib.controls.calendar.MtrCalendar",
				"com.melody.lib.controls.chart.RadialChart",
				"com.melody.lib.controls.chart.Hexagon",
				"com.melody.lib.controls.chart.OutcomeHexagon",
				"com.melody.lib.controls.chart.SuccessLineChart",
				"com.melody.lib.controls.mtr.calendar.Calendar",
			],
			elements: [
				"com.melody.lib.enum.InputType",
				"com.melody.lib.enum.ODataUrl",
				"com.melody.lib.util.UserSettings",
				"com.melody.lib.util.ORE",
				"com.melody.lib.util.Account",
				"com.melody.lib.util.account.Account",
				"com.melody.lib.util.account.AccountHelper",
				"com.melody.lib.util.account.AccountDialogController",
				"com.melody.lib.util.Opportunity",
				"com.melody.lib.util.opportunity.Opportunity",
				"com.melody.lib.util.opportunity.OpportunityHelper",
				"com.melody.lib.util.opportunity.DiscontinuedOpportunity",
				"com.melody.lib.util.opportunity.OpportunityDialogController",
				"com.melody.lib.util.UserMaster",
				"com.melody.lib.util.Algorithm",
				"com.melody.lib.util.Activity",
				"com.melody.lib.util.MTR",
				"com.melody.lib.util.mtr.MTR",
				"com.melody.lib.util.mtr.Staffing",
				"com.melody.lib.util.mtr.MTRModels"
			]
		});

		/* eslint-disable */
		return com.melody.lib;
		/* eslint-enable */

	}, /* bExport= */ false);