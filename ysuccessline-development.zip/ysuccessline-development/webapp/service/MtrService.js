sap.ui.define([
	"com/presalescentral/successline/service/CoreService",
	"sap/ui/model/Sorter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (CoreService, Sorter, Filter, FilterOperator) {
	"use strict";

	var MtrService = CoreService.extend("com.presalescentral.successline.service.MtrService", {
	

		getTimeEntryDefaultValues: function (aFilters) {
			var mParameters = {
				filters: aFilters
			};
			return this.odata("/YC_ActTypeDefMpngSet").get(mParameters);
		}
		
	});
	return new MtrService();
});