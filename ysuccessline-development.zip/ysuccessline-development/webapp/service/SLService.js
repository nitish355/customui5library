sap.ui.define([
	"com/presalescentral/successline/service/CoreService",
	"sap/ui/model/Sorter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (CoreService, Sorter, Filter, FilterOperator) {
	"use strict";

	var SLService = CoreService.extend("com.presalescentral.successline.service.SLService", {
		getMasterData: function (sEntity, sFiltersProperty, sFilterValue) {
			var oParameters = {};
			if (sFiltersProperty && sFilterValue) {
				let aFilters = [];
				oParameters = {
					filters: aFilters
				};
				let filterManger1 = new Filter({
					path: sFiltersProperty,
					operator: sap.ui.model.FilterOperator.EQ,
					value1: sFilterValue
				});
				aFilters.push(filterManger1);
			}
			return this.odata("/" + sEntity).get(oParameters);
		},
		getLeadMasterData: function (sEntity, isManager, teams) {
			let aMultiFilter = [];
			let aFilters = [];
			let selectFilter = "LeadId,LeadName,SlLead,SlLeadName";
			if (isManager) {
				let filterManger1 = new Filter({
					path: "ManagerView",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: "X"
				});
				aFilters.push(filterManger1);
				$.each(teams, function (idx, token) {
					aMultiFilter.push(new Filter("TeamFilter", FilterOperator.EQ, token.userid));
				});
				if (aMultiFilter.length > 0) {
					aFilters.push(new Filter({
						filters: aMultiFilter,
						and: false
					}));
				}
			}

			var oParameters = {
				filters: aFilters,
				urlParameters: {
					$select: selectFilter
				}
			};
			return this.odata("/" + sEntity).get(oParameters);
		},

		getRoleBasedActivitySufix: function (SlSnro, associateType) {
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter({
				path: "SlSnro",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: SlSnro
			}));
			aFilters.push(new sap.ui.model.Filter({
				path: "AsstdId",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: associateType
			}));
			aFilters.push(new sap.ui.model.Filter({
				path: "RoleMpngID",
				operator: sap.ui.model.FilterOperator.NE,
				value1: '007'
			}));
			var oParameters = {
				filters: aFilters
			};
			return this.odata("/YC_SL_T_ACT_ROLE_SUFX").get(oParameters);
		},
		getSLDetailData: function (SlSnro) {
			var oParameters = {
				filters: [new sap.ui.model.Filter({
					path: "SlSnro",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: SlSnro
				})],
				urlParameters: {
					"$expand": "to_slphase,to_sltouchpoint,to_slactivity,to_slteam,to_slstorylink,to_slcomment,to_sloppact,to_slopp,to_slattach"
				}
			};
			return this.odata("/YC_SL_T_SLDETAIL").get(oParameters);
		},
		getSLDetailWrapper: function (oActvt, isIndpndntActvt) {
			var aFilters = [];
			var sPath = isIndpndntActvt ? "/YC_SL_T_OPP_ACTWRPR" : "/YC_SL_T_WRAPPER";
			var sExpand = isIndpndntActvt ? "to_team" :
				"to_wrplink,to_wrpdoc,to_wrpcntct,to_actrole,to_team,to_ADetType,to_AInitiative,to_AAddOpp,to_AFiles,to_ASol,to_AMaterial,to_ATaxonomy,to_ALand";
			if (isIndpndntActvt) {
				aFilters.push(new sap.ui.model.Filter({
					path: "ActGuid",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oActvt.ActGuid
				}));
				sPath = "/YC_SL_T_OPP_ACTWRPR";
				sExpand = "to_team,to_wrpdoc";
			} else {
				aFilters.push(new sap.ui.model.Filter({
					path: "SlId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oActvt.SlId
				}));
				aFilters.push(new sap.ui.model.Filter({
					path: "SlSnro",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oActvt.SlSnro
				}));
				aFilters.push(new sap.ui.model.Filter({
					path: "PhaseId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oActvt.PhaseId
				}));
				aFilters.push(new sap.ui.model.Filter({
					path: "TpointId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oActvt.TpointId
				}));
				aFilters.push(new sap.ui.model.Filter({
					path: "ActGuid",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oActvt.ActGuid
				}));
				aFilters.push(new sap.ui.model.Filter({
					path: "ActivityId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: oActvt.ActivityId
				}));
				sPath = "/YC_SL_T_WRAPPER";
				sExpand =
					"to_wrplink,to_wrpdoc,to_wrpcntct,to_actrole,to_team,to_ADetType,to_AInitiative,to_AAddOpp,to_AFiles,to_ASol,to_AMaterial,to_ATaxonomy,to_ALand";
			}
			var oParameters = {
				filters: aFilters,
				urlParameters: {
					"$expand": sExpand
				}
			};
			return this.odata(sPath).get(oParameters);
		},
		updateSL: function (oArchive) {
			let sUrl = "/YC_SL_T_SLDETAIL(TempId='" + oArchive.TempId + "',SlSnro='" + oArchive.SlSnro + "',SlId=guid'" + oArchive.SlId +
				"')";
			return this.odata(sUrl).put(oArchive);
		},
		getRoles: function () {
			return this.odata("/YC_SL_ROLE_ACTVT").get();

		},
		getRoleBasedActvtTypes: function (aFilter) {
			var oParameters = {
				filters: aFilter
			};
			return this.odata("/YC_SL_M_ACT_TYPE_LIST").get(oParameters);
		},
		getDefaultRole: function () {
			return this.odata("/YC_SL_ROLE_ACTVT_FRMACSS").get();
		},
		onDisableTP: function (oTp, oParam) {
			var sObjectPath = this.model.createKey("YC_SL_T_TOUCHPOINT", {
				SlId: oTp.SlId,
				SlSnro: oTp.SlSnro,
				TempId: oTp.TempId,
				PhaseId: oTp.PhaseId,
				TpointId: oTp.TpointId,
				Weight: oTp.Weight,
				TchpointGuid: oTp.TchpointGuid
			});
			return this.odata("/" + sObjectPath).put(oParam);
		},
		postActivity: function (oActvt) {
			return this.odata("/YC_SL_T_ACTIVITIES").post(oActvt);
		},
		getWrapperDetails: function (actvtId, actGuid) {
			var aFilter = new Filter({
				filters: [new Filter("ActivityId", FilterOperator.EQ, actvtId),
					new Filter("ActGuid", FilterOperator.EQ, actGuid)
				],
				bAnd: true
			});
			var oParameters = {
				filters: [aFilter],
				urlParameters: {
					"$expand": "to_actrole,to_wrpcntct,to_wrpdoc,to_wrplink,to_team,to_ADetType,to_AInitiative,to_AAddOpp,to_AFiles,to_ASol,to_AMaterial,to_ATaxonomy,to_ALand"
				}
			};
			return this.odata("/YC_SL_T_WRAPPER").get(oParameters);
		},
		updateWrapperData: function (oParam) {
			let sUrl = "/YC_SL_T_WRAPPER(ActGuid=guid'" + oParam.ActGuid + "',SlSnro='" + oParam.SlSnro + "',SlId=guid'" + oParam.SlId +
				"',PhaseId='" + oParam.PhaseId + "',ActivityId='" + oParam.ActivityId + "',TpointId='" + oParam.TpointId + "',Weight='" + oParam.Weight +
				"')";
			return this.odata(sUrl).put(oParam);

		},
		getActivity: function (obj) {
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter({
				path: "ActGuid",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: obj.ActGuid

			}));
			/*aFilters.push(new sap.ui.model.Filter({
			path: "ActivityId",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: obj.ActivityId
				
			}));*/
			var oParameters = {
				filters: aFilters,
				urlParameters: {
					"$expand": "to_paction/to_caction"
				}
			};
			return this.odata("/YC_SL_T_ACTIVITIES").get(oParameters);
		},
		deleteActivity: function (oActvt) {
			var sUrl = "/YC_SL_T_ACTIVITIES(SlId=guid'" + oActvt.SlId + "',SlSnro='" + oActvt.SlSnro + "',TempId='" + oActvt.TempId +
				"',PhaseId='" + oActvt.PhaseId + "',TpointId='" + oActvt.TpointId + "',tchpoint_guid=guid'" + oActvt.TchpointGuid +
				"',ActivityId='" + oActvt.ActivityId + "',Weight='" + oActvt.Weight + "',ActGuid=guid'" + oActvt.ActGuid + "')";
			return this.odata(sUrl).delete();
		},
		updateActivity: function (status, oActvt) {
			var sUrl = "/YC_SL_T_ACTIVITIES(SlId=guid'" + oActvt.SlId + "',SlSnro='" + oActvt.SlSnro + "',TempId='" + oActvt.TempId +
				"',PhaseId='" + oActvt.PhaseId + "',TpointId='" + oActvt.TpointId + "',tchpoint_guid=guid'" + oActvt.tchpoint_guid +
				"',ActivityId='" + oActvt.ActivityId + "',Weight='" + oActvt.Weight + "',ActGuid=guid'" + oActvt.ActGuid + "')";
			if (status) {
				oActvt.StatusId = status;
			}
			return this.odata(sUrl).put(oActvt);
		},
		onReorderActvts: function (aActvts) {
			var that = this;
			var aPromises = [];
			this.newArr = [];
			$.each(aActvts, function (index, actvt) {
				var obj = {
					"ActGuid": actvt.ActGuid,
					"TempId": actvt.TempId,
					"PhaseId": actvt.PhaseId,
					"TpointId": actvt.TpointId,
					"ActivityId": actvt.ActivityId,
					"Weight": actvt.Weight,
					"StatusId": actvt.StatusId,
					"IsGlobal": actvt.IsGlobal,
					"RegMandatory": actvt.RegMandatory,
					"RegisteredActId": actvt.RegisteredActId,
					//"IconId": actvt.IconId,
					"Active": true,
					"RoleMpngID": actvt.RoleMpngID,
					"Source": actvt.source,
					"ActLead": actvt.ActLeadId,
					"TchpointGuid": actvt.TchpointGuid
				};
				that.newArr.push(obj);
			});
			this.newArr.forEach(function (element) {
				var sUrl = "/YC_SL_T_ACTREORDER(ActGuid=guid'" + element.ActGuid + "',TempId='" +
					element.TempId + "',PhaseId='" + element.PhaseId +
					"',TpointId='" + element.TpointId +
					"',ActivityId='" + element.ActivityId + "',Weight='" + element.Weight + "')";
				aPromises.push(that.odata(sUrl).put(element));
			});
			return Promise.all(aPromises);
		},
		postComment: function (oComment) {
			return this.odata("/YC_SL_T_COMMENTS").post(oComment);
		},
		updateComment: function (oComment) {
			return this.odata("/YC_SL_T_COMMENTS").post(oComment);
		},
		deleteComment: function (oComment) {
			return this.odata("/YC_SL_T_COMMENTS(SlId=guid'" + oComment.SlId + "',SlSnro='" + oComment.SlSnro + "',CommentGuid=guid'" +
				oComment.CommentGuid +
				"')").delete(oComment);
		},
		getOpptProfitCenterData: function (oppId) {
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter({
				path: "OPPT_ID",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: oppId
			}));
			var oParameters = {
				filters: aFilters
			};
			return this.odata("/YI_MOP_OPPORTUNITY").get(oParameters);

		},
		validateSuccessLineAvailability: function (aFilters) {
			var oParameters = {
				filters: aFilters
			};
			return this.odata("/YC_SL_T_SL_AVAILABILITYCHECK").get(oParameters);
		},
		getUsers: function (query) {
			var oParameters = {
				urlParameters: {
					search: query
				}
			};
			return this.odata("/YC_SL_USERSEARCH").get(oParameters);
		},
		getVariants: function (aFilters) {
			var oParameters = {
				filters: aFilters
			};
			return this.odata("/YC_SL_VARIANT").get(oParameters);
		},
		createVariant: function (oParam) {
			return this.odata("/YC_SL_MANAGE_VARIANTS").post(oParam);
		},
		createNewSuccessLine: function (oEntry) {
			return this.odata("/YC_SL_T_CREATESL").post(oEntry);
		},
		getCreatedSuccessLine: function (SlNo) {
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter({
				path: "SlNo",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: SlNo
			}));
			var oParameters = {
				filters: aFilters,
				urlParameters: {
					"$expand": "to_acc,to_link,to_opp,to_team,to_addopp"
				}
			};
			return this.odata("/YC_SL_T_CREATESL").get(oParameters);
		},
		getSlListData: function (aFilters) {
			var oParameters = {
				filters: aFilters,
				urlParameters: {
					$inlinecount: "allpages",
					$expand: "toTeam,to_Outcomes"
				}
			};
			return this.odata("/YC_SL_T_SLLISTSet").get(oParameters);

		},
		getSlListDataCount: function (aFilters) {
			var oParameters = {
				filters: aFilters,
				urlParameters: {
					$inlinecount: "allpages"
				}
			};
			return this.odata("/YC_SL_T_SLLISTSet").get(oParameters);

		},
		getContributorsTeam: function (sSlid) {
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter({
				path: "SlNo",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: sSlid
			}));
			var oParameters = {
				filters: aFilters,
				urlParameters: {
					"$expand": "toTeam"
				}
			};
			return this.odata("/YC_SL_T_SLLISTSet").get(oParameters);

		},
		deleteVariant: function (sEntity) {
			return this.odata(sEntity).delete();
		},
		manageVaraints: function (oEntry) {
			let that = this;
			let aPromises = [];
			oEntry.forEach(function (element) {
				var sUrl = "/YC_SL_MANAGE_VARIANTS('" + element.variantid + "')";
				aPromises.push(that.odata(sUrl).put(element));
			});
			return Promise.all(aPromises);
		},
		subscribeNotification: function (oNotify) {
			return this.odata("/YC_SL_T_SUBSCRIPTION").post(oNotify);
		},
		getTemplatePreview: function (TempId) {
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter({
				path: "TempId",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: TempId
			}));
			var oParameters = {
				filters: aFilters,
				urlParameters: {
					"$expand": "to_tphase,to_ttpnt,to_tact"
				}
			};
			return this.odata("/YC_SL_M_TEMP_HIER_DET").get(oParameters);
		},
		updateAttachments: function (aAttchmnt) {
			var that = this;
			var aPromises = [];
			this.newArr = [];
			$.each(aAttchmnt, function (index, attchmnt) {
				var obj = {
					"Active": attchmnt.Active,
					"Link": attchmnt.Link,
					"LinkId": attchmnt.LinkId,
					"LinkTitle": attchmnt.LinkTitle,
					"LinkType": attchmnt.LinkType,
					"SlSnro": attchmnt.SlSnro,
					"SlId": attchmnt.SlId,
					"Status": attchmnt.Status
				};
				that.newArr.push(obj);
			});
			this.newArr.forEach(function (element) {
				var sUrl = "/YC_SL_T_STORYLINK";
				aPromises.push(that.odata(sUrl).post(element));
			});
			return Promise.all(aPromises);

		},
		updateWrpDescription: function (oParam) {
			let sUrl = "/YC_SL_T_WRAPPER(ActGuid=guid'" + oParam.ActGuid + "',SlSnro='" + oParam.SlSnro + "',SlId=guid'" + oParam.SlId +
				"',PhaseId='" + oParam.PhaseId + "',ActivityId='" + oParam.ActivityId + "',TpointId='" + oParam.TpointId + "',Weight='" + oParam.Weight +
				"')";
			return this.odata(sUrl).put(oParam);

		},
		updateWrprAttachments: function (aAttchmnt) {
			var that = this;
			var aPromises = [];
			this.newArr = [];
			$.each(aAttchmnt, function (index, attchmnt) {
				var obj = {
					"ActGuid": attchmnt.ActGuid,
					"ActivityId": attchmnt.ActivityId,
					"LinkTypeDesc": attchmnt.LinkTypeDesc,
					"LinkTypeId": attchmnt.LinkTypeId,
					"PhaseId": attchmnt.PhaseId,
					"TpointId": attchmnt.TpointId,
					"Active": attchmnt.Active,
					"Link": attchmnt.Link,
					"LinkId": attchmnt.LinkId,
					"LinkTitle": attchmnt.LinkTitle,
					"SlSnro": attchmnt.SlSnro,
					"SlId": attchmnt.SlId,
					"Status": attchmnt.Status
				};
				that.newArr.push(obj);
			});
			this.newArr.forEach(function (element) {
				var sUrl = "/YC_SL_T_WRPDOCUMENT";
				aPromises.push(that.odata(sUrl).post(element));
			});
			return Promise.all(aPromises);

		},
		getTemplateTitle: function (TempId) {
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter({
				path: "TempId",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: TempId
			}));
			var oParameters = {
				filters: aFilters
			};
			return this.odata("/YC_SL_T_CUSTOM_TEMP").get(oParameters);
		},
		getRapidRegMethods: function (acttypeid) {
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter({
				path: "acttypeid",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: acttypeid
			}));
			var oParameters = {
				filters: aFilters
			};
			return this.odata("/YC_SL_M_ACT_METHOD").get(oParameters);
		},
		postRapidRegistration: function (oEntry) {
			if (!oEntry) {
				oEntry = {};
			}
			return this.odata("/YC_SL_T_ACT_REGN").post(oEntry);
		},
		getRapidRegistration: function (sRegActivityId) {
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter({
				path: "ActivityId",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: sRegActivityId
			}));
			var oParameters = {
				filters: aFilters,
			};
			return this.odata("/YC_SL_T_ACT_REGN").get(oParameters);
		},
		getFromSource: function (sRolempngId, sSlSnro, sRegionId, sTeam, query, sActvtTypeId, sActvtAsstID) {
			var aFilters = [];
			let aMultiFilter = [];
			aFilters.push(new sap.ui.model.Filter({
				path: "RolempngId",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: sRolempngId
			}));
			if (sSlSnro) {
				aFilters.push(new sap.ui.model.Filter({
					path: "SlSnro",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: sSlSnro
				}));
			}
			if (sRegionId) {
				aFilters.push(new sap.ui.model.Filter({
					path: "GroupLevel1",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: sRegionId
				}));
			}
			if (sTeam) {
				$.each(sTeam, function (idx, token) {
					aMultiFilter.push(new Filter("UserId", FilterOperator.EQ, token.USER_ID));
				});
				if (aMultiFilter.length > 0) {
					aFilters.push(new Filter({
						filters: aMultiFilter,
						and: false
					}));
				}
			}
			if (sActvtTypeId) {
				aFilters.push(new sap.ui.model.Filter({
					path: "ActTypeId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: sActvtTypeId
				}));
			}
			if (sActvtAsstID) {
				aFilters.push(new sap.ui.model.Filter({
					path: "ActvtAsstID",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: sActvtAsstID
				}));
			}
			var oParameters = {
				urlParameters: {
					search: query,
					skip: 0,
					top: 100
				},
				filters: aFilters,
			};
			return this.odata("/YC_SL_M_USER_LIST").get(oParameters);
		},

		getSources: function (aFilter) {
			var oParameters = {
				filters: aFilter
			};
			return this.odata("/YC_SL_M_SOURCE_LIST").get(oParameters);
		},
		getPlanItemsSearch: function (SlSnro, sQuery) {
			var oParameters = {
				filters: [new sap.ui.model.Filter({
					path: "SlSnro",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: SlSnro
				})],
				urlParameters: {
					search: sQuery
				}
			};
			return this.odata("/YC_SL_T_PLAN_ITEM").get(oParameters);
		},
		moveServicetoPhase: function (prevPhaseId, prevWeight, sObj, SlSnro, SlId, TempId, prevTchpointGuid) {
			var TpointId = sObj.TpointId;
			var sObjectPath = this.model.createKey("YC_SL_T_TCHPNT_REORDER", {
				SlId: SlId,
				SlSnro: SlSnro,
				TempId: TempId,
				PhaseId: prevPhaseId,
				TpointId: TpointId,
				Weight: prevWeight
			});
			var oParam = {
				"PhaseId": sObj.PhaseId,
				"TpointId": sObj.TpointId,
				"Weight": sObj.Weight,
				"StatusId": ' ',
				"Active": sObj.Active,
				"SlId": SlId,
				"SlSnro": SlSnro,
				"TempId": TempId,
				"TchpointGuid": sObj.TchpointGuid
			};
			return this.odata("/" + sObjectPath).put(oParam);
		},
		moveActivitytoService: function (prevPhaseId, prevWeight, prevTpointId, element, SlSnro, SlId, TempId, prevTchpointGuid) {
			var sUrl = "/YC_SL_T_ACTREORDER(ActGuid=guid'" + element.ActGuid + "',TempId='" +
				element.TempId + "',PhaseId='" + prevPhaseId +
				"',TpointId='" + prevTpointId + "',TchpointGuid=guid'" + prevTchpointGuid +
				"',ActivityId='" + element.ActivityId + "',Weight='" + prevWeight + "')";

			var oParam = {
				"ActGuid": element.ActGuid,
				"TempId": TempId,
				"PhaseId": element.PhaseId,
				"TpointId": element.TpointId,
				"ActivityId": element.ActivityId,
				"Weight": element.Weight,
				"RoleMpngID": element.RoleMpngID,
				"IsGlobal": element.IsGlobal,
				"RegMandatory": element.RegMandatory,
				"RegisteredActId": element.RegisteredActId,
				"StatusId": element.StatusId,
				"ActLead": element.ActLeadId,
				"Source": element.source,
				"Active": element.Active,
				"TchpointGuid": element.TchpointGuid,
				"accountname": element.accountname,
				"iss": element.iss,
				"iac": element.iac,
				"industry": element.industry,
				"OppDescription": element.OppDescription
			};
			return this.odata(sUrl).put(oParam);
		},
		getPresentationSettings: function () {
			var oParameters = {
				urlParameters: {
					"$expand": "to_psetng"
				}
			};
			return this.odata("/YC_SL_T_USER_SETNG").get(oParameters);
		},
		updatePresentationSettings: function (data) {
			return this.odata("/YC_SL_T_USER_SETNG").post(data);
		},
		getRapidRegTypes: function (acttypeid) {
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter({
				path: "ActTypeId",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: acttypeid
			}));
			var oParameters = {
				filters: aFilters
			};
			return this.odata("/YC_SL_M_ACTIVITY_DET_TYPE").get(oParameters);
		},
		getTemplateActivitySufix: function (sTempId, associateType) {
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter({
				path: "TempId",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: sTempId
			}));
			aFilters.push(new sap.ui.model.Filter({
				path: "AsstdId",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: associateType
			}));
			var oParameters = {
				filters: aFilters
			};
			return this.odata("/YC_SL_M_ACT_ROLE_SUFX").get(oParameters);
		},

		getServices: function () {
			return this.odata("/YC_SL_M_SERVICE_LIST").get();
		},
		postService: function (oParam) {
			return this.odata("/YC_SL_T_TOUCHPOINT").post(oParam);
		},
		deleteService: function (oService) {
			var sUrl = "/YC_SL_T_TOUCHPOINT(SlId=guid'" + oService.SlId + "',SlSnro='" + oService.SlSnro + "',TempId='" + oService.TempId +
				"',PhaseId='" + oService.PhaseId + "',TpointId='" + oService.TpointId + "',TchpointGuid=guid'" + oService.TchpointGuid +
				"',Weight='" + oService.Weight + "')";
			return this.odata(sUrl).delete();
		},

		getSOAttachments: function (oServiceData) {
			let sUrl = "/YC_SL_T_TOUCHPOINT(SlId=guid'" + oServiceData.SlId + "',SlSnro='" + oServiceData.SlSnro + "',TempId='" + oServiceData.TempId +
				"',PhaseId='" + oServiceData.PhaseId + "',TpointId='" + oServiceData.TpointId + "',Weight='" + oServiceData.Weight +
				"',TchpointGuid=guid'" + oServiceData.TchpointGuid + "')";
			let oParameters = {
				urlParameters: {
					"$expand": "to_TpLinks,to_SrvStatus,to_TpResourc"
				}
			};
			return this.odata(sUrl).get(oParameters);
		},

		updateSOAttachments: function (aAttchmnt) {
			let that = this;
			let aPromises = [];
			this.newArr = [];
			$.each(aAttchmnt, function (index, attchmnt) {
				let obj = {
					"TchpointGuid": attchmnt.TchpointGuid,
					"LinkTypeId": attchmnt.LinkTypeId,
					"LinkId": attchmnt.LinkId,
					"LinkTitle": attchmnt.LinkTitle,
					"Link": attchmnt.Link,
					"LinkTypeDesc": attchmnt.LinkTypeDesc,
					"TpLinkActive": attchmnt.TpLinkActive
				};
				that.newArr.push(obj);
			});
			this.newArr.forEach(function (element) {
				var sUrl = "/YC_SL_T_TPNT_LINKS";
				aPromises.push(that.odata(sUrl).post(element));
			});
			return Promise.all(aPromises);

		},

		updateSOTouchPointData: function (oServiceData) {
			let sURL = "/YC_SL_T_TOUCHPOINT(SlId=guid'" + oServiceData.SlId + "',SlSnro='" + oServiceData.SlSnro + "',TempId='" + oServiceData.TempId +
				"',PhaseId='" + oServiceData.PhaseId + "',TpointId='" + oServiceData.TpointId + "',Weight='" + oServiceData.Weight +
				"',TchpointGuid=guid'" +
				oServiceData.TchpointGuid + "')";
			return this.odata(sURL).put(oServiceData);
		},

		getServiceOutcomeAchieved: function (serviceTypeId, SlSnro) {
			let aFilters = [];
			let sURL = "/YC_SL_T_TOUCHPOINT";

			aFilters.push(new sap.ui.model.Filter({
				path: "ServiceTypeID",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: serviceTypeId
			}));

			aFilters.push(new sap.ui.model.Filter({
				path: "SlSnro",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: SlSnro
			}));

			let oParameters = {
				filters: aFilters
			};
			return this.odata(sURL).get(oParameters);
		},

		copySuccessLine: function (oEntry) {
			return this.odata("/YC_SL_T_COPYSL").post(oEntry);
		},

		getMSLExistDataBasedOnOpp: function (aFilters) {
			var oParameters = {
				filters: aFilters
			};
			return this.odata("/YC_SL_T_OPP").get(oParameters);
		},

		updateAttachmentHandover: function (oAttachemnt) {
			var sUrl = "/YC_SL_T_ALL_ATTACH(SlId=guid'" + oAttachemnt.SlId + "')";
			var oParam = {
				"SlId": oAttachemnt.SlId,
				"SlSnro": oAttachemnt.SlSnro,
				"PhaseId": oAttachemnt.PhaseId,
				"TpointId": oAttachemnt.TpointId,
				"ActivityId": oAttachemnt.ActivityId,
				"TchpointGuid": oAttachemnt.TchpointGuid,
				"ActGuid": oAttachemnt.ActGuid,
				"weight": oAttachemnt.weight,
				"LinkTypeId": oAttachemnt.LinkTypeId,
				"LinkId": oAttachemnt.LinkId,
				"LinkTitle": oAttachemnt.LinkTitle,
				"Link": oAttachemnt.Link,
				"Active": oAttachemnt.Active,
				"LinkTypeDesc": oAttachemnt.LinkTypeDesc,
				"AttachCat": oAttachemnt.AttachCat,
				"Handover": oAttachemnt.Handover
			};
			return this.odata(sUrl).put(oParam);
		},

		//Funtion to get overlapping activities
		getDuplicateRegistrations: function (aFilters) {
			let oParameters = {
				filters: aFilters
			};
			return this.odata("/YC_SL_T_OPP_ACC").get(oParameters);
		},

		//Function to add user to Activity for overlapping activity
		fnAddUsertoOppTeam: function (data) {
			return this.odata("/YC_SL_T_ACT_TEAM").post(data);
		},

		//Function to update overlapping activities justification comments
		fnPostCommentToSLService: function (oPayload) {
			return this.odata("/YC_SL_T_ACT_JUSTIF_COMMENT").post(oPayload);
		},

		getTimeEntryDefaultValues: function (oModel, aFilters) {
			var mParameters = {
				filters: aFilters
			};
			return this.odata("/YC_ActTypeDefMpngSet").get(mParameters);
		},

		getCVJPhaseMaster: function (aFilters) {
			var mParameters = {
				filters: aFilters
			};
			return this.odata("/YC_MAC_M_CVJ_PHASE").get(mParameters);
		},

		getLevel2MasterData: function () {
			return this.odata("/YC_MD_SOL_M_LEVEL2").get();
		},

		getSolutionHierarchy: function () {
			return this.odata("/YC_MD_SOL_HIER").get();
		},

		getDemoLandScapes: function () {
			return this.odata("/YC_MAC_M_LANDSCAPES").get();
		},

		getLayoutData: function (aFilters) {
			var mParameters = {
				filters: aFilters
			};
			return this.odata("/YC_MAC_M_FORM_LAYOUT").get(mParameters);
		},
		
		copyRapidRegData: async function (payload) {
			return this.odata("/YC_SL_T_FR_DRAFT").post(payload);
		}

	});
	return new SLService();
});