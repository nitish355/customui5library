sap.ui.define([
	"com/presalescentral/successline/service/CoreService",
	"sap/ui/model/Sorter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (CoreService, Sorter, Filter, FilterOperator) {
	"use strict";

	var UtilityService = CoreService.extend("com.presalescentral.successline.service.UtilityService", {

		getUserData: function () {
			return this.odata("/YC_USER_MASTER").get();
		},
		getMyTeamData: function () {
			return this.odata("/YC_UT_MGR_TEAM_LIST").get();
		},
		getQuickLinksData: function () {
			var oParameters = {
				urlParameters: {
					"$expand": 'to_params,to_child/to_params'
				}
			};
			return this.odata("/YC_MD_T_NAVMENU").get(oParameters);
		},
		getAuth: function (projectType) {
			var defaultProject = "SLINE";
			if (projectType) {
				defaultProject = projectType;
			}
			return this.odata("/YC_UT_AUTH_CHECK(ProjectType='" + defaultProject + "')").get();
		},
		getCommentsCount: function (sSlId, sProjectType) {
			var oParameters = {
				filters: [new sap.ui.model.Filter({
						path: "Id",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sSlId
					}),
					new sap.ui.model.Filter({
						path: "ProjectType",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sProjectType
					})
				]
			};
			return this.odata("/YC_UT_T_USER_TRACK").get(oParameters);
		},

		deepClone: function (obj, hash = new WeakMap()) {
			var that = this;
			// Do not try to clone primitives or functions
			if (Object(obj) !== obj || obj instanceof Function) return obj;
			if (hash.has(obj)) return hash.get(obj); // Cyclic reference
			try { // Try to run constructor (without arguments, as we don't know them)
				var result = new obj.constructor();
			} catch (e) { // Constructor failed, create object without running the constructor
				result = Object.create(Object.getPrototypeOf(obj));
			}
			// Optional: support for some standard constructors (extend as desired)
			if (obj instanceof Map)
				Array.from(obj, ([key, val]) => result.set(that.deepClone(key, hash),
					that.deepClone(val, hash)));
			else if (obj instanceof Set)
				Array.from(obj, (key) => result.add(that.deepClone(key, hash)));
			// Register in hash
			hash.set(obj, result);
			// Clone and assign enumerable own properties recursively
			return Object.assign(result, ...Object.keys(obj).map(
				key => ({
					[key]: that.deepClone(obj[key], hash)
				})));
		},
		
		//Function to post justification comments to Utility service
		fnPostCommentToUtilityServ: function (oPayload) {
			return this.odata("/YC_MD_COMMENTS").post(oPayload);
		}
	});
	return new UtilityService();
});