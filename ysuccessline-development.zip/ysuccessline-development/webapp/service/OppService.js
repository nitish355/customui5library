sap.ui.define([
	"com/presalescentral/successline/service/CoreService",
	"sap/ui/model/Sorter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/base/Log"
], function (CoreService, Sorter, Filter, FilterOperator, Log) {
	"use strict";

	var oppService = CoreService.extend("com.presalescentral.successline.service.OppService", {
		getTeamOpportunityData: function (aUserIds) {
			var that = this;
			var aPromises = [];
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter({
				path: "TYPE",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: "E"
			}));
			aUserIds.forEach(function (element) {
				var oParameters = {
					urlParameters: {
						search: element.userid,
						select: 'PARTNER'
					},
					filters: [new sap.ui.model.Filter({
						filters: aFilters,
						and: true
					})]
				};
				aPromises.push(
					that.odata("/BusinessPartners").get(oParameters)
				);

			});
			return Promise.all(aPromises);
		},

		//Production issue fix for 10K+ Opportunity Data
		//function to fetch Opportunities based on users data
		getOpportunities: function getOpportunities(responce) {
			var that = this;
			var aPromises = [];
			let userCount = 2;
			let aResponse = $.extend(true, [], responce);
			let totalRecords = aResponse.length;
			let totalUsers = Math.ceil(totalRecords / userCount);
			let aPromise = [];
			for (let i = 0; i < totalUsers; i++) {
				var oParameters;
				let startIndex = i * userCount;
				let endIndex = startIndex + userCount;
				let batchCallRecords = aResponse.slice(startIndex, endIndex);
				let aPartnerFilter = [];
				var statusFilter = new Filter({
					filters: [new Filter({
						path: 'STATUS',
						operator: FilterOperator.EQ,
						value1: "E0001"
					}), new Filter({
						path: 'STATUS',
						operator: FilterOperator.EQ,
						value1: "E0007"
					})],
					bAnd: false
				});
				batchCallRecords.forEach(function (element) {
					let aPartner = element.data.results || [];
					let sPartner = (aPartner.length) ? aPartner[0].PARTNER : "";
					if (sPartner) {
						let partnerIdFilter = new Filter({
							path: "SALES_TEAM_MEMBER",
							operator: sap.ui.model.FilterOperator.EQ,
							value1: sPartner
						});
						aPartnerFilter.push(partnerIdFilter);
					}
				});

				if (!aPartnerFilter.length) {
					continue;
				}
				oParameters = {
					filters: [new Filter({
						filters: [new Filter({
							filters: aPartnerFilter,
							bAnd: false
						}), statusFilter],
						bAnd: true
					})],
					urlParameters: {
						$select: 'SALES_ORG_TEXT,OPPT_ID,ACCOUNT_NAME,ACCOUNT,DESCRIPTION,OWNER,OWNER_NAME,STATUS,CURR_PHASE,INTERNAL_ORDER1,INTERNAL_ORDER2,EXPECT_END,EXPECTED_VALUE,INDUSTRY_MASTERCODE_TEXT,INDUSTRY,INDURSTRY_TEXT,PartiesInvolved',
					}
				};
				aPromises.push(that.odata("/Opportunities").get(oParameters));
			}
			return Promise.all(aPromises);
		},

		getOppMasterData: function () {
			var oParameters = {
				filters: [
					new Filter({
						path: "ENTITY_NAME",
						operator: "EQ",
						value1: "Opportunity"
					})
				]
			};
			return this.odata("/AppValueHelps").get(oParameters);
		},
		getAccountDetails: function (AccountId) {
			return this.odata("/BusinessPartnerAttribSet('" + AccountId + "')").get();
		},
		getSLListAccountDetails: function (aAccountIDMap) {
			var that = this;
			var aPromises = [];
			aAccountIDMap.forEach(function (value) {
				aPromises.push(
					that.odata("/BusinessPartnerAttribSet('" + value + "')").get()
				);
			});
			return Promise.all(aPromises);
		},
		_getOpportunitiesTeam: function (sOpportunityId, selectParam, onTeamSuccessFn, filters, onError) {
			var aFilters = [];
			var sPath = "";
			if (sOpportunityId) {
				try {
					sPath = this.model.createKey("/Opportunities", {
						OPPT_ID: sOpportunityId
					});
				} catch (err) {
					sPath = "/Opportunities('" + sOpportunityId + "')";
					Log.info(err);
				}
				if (filters && filters.length > 0) {
					aFilters = filters;
				}
				var oParam = {
					urlParameters: {
						$select: selectParam,
						$expand: 'PartiesInvolved,Notes,Items'
					},
					filters: aFilters

				};
				return this.odata(sPath).get(oParam);
			}
		}

	});
	return new oppService();
});