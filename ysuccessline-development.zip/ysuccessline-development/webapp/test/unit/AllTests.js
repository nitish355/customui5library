sap.ui.define([
	"com/presalescentral/successline/test/unit/controller/SlList.controller"
], function () {
	"use strict";
});