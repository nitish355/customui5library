/*global QUnit*/

sap.ui.define([
	"com/presalescentral/successline/controller/SlList.controller"
], function (Controller) {
	"use strict";

	QUnit.module("SlList Controller");

	QUnit.test("I should test the SlList controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});