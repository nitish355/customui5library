// eslint-disable-next-line sap-no-global-define
window.suite = function () {
	"use strict";
	/* eslint-disable new-cap */
	var oSuite = new parent.jsUnitTestSuite(),
		sContextPath = location.pathname.substring(0, location.pathname.lastIndexOf("/") + 1);

	oSuite.addTestPage(sContextPath + "unit/UnitTests.qunit.html");
	oSuite.addTestPage(sContextPath + "integration/OpaTests.qunit.html");

	return oSuite;
};