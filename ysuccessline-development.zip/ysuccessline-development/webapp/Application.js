sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/json/JSONModel",
	"com/presalescentral/successline/service/OppService",
	"com/presalescentral/successline/service/SLService",
	"com/presalescentral/successline/service/UtilityService",
	"com/presalescentral/successline/service/MtrService",
	"sap/base/Log",
	"sap/ui/util/Storage"
], function (Object, JSONModel, OppService, SLService, UtilityService, MtrService, Log, Storage) {
	"use strict";
	/* @type sap.ui.base.Object */
	let instance;
	/* @type sap.ui.base.Object */
	const Application = Object.extend("com.presalescentral.ore.Application", {
		constructor: function () {
			if (!this.sloStorage) {
				this.sloStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			}
			if (!this.constStorage) {
				this.constStorage = new Storage(Storage.Type.session);
			}

		},

		init: function (oComponent) {
			this.Component = oComponent;
			this._initModels();
			OppService.setModel(this.Component.getModel("int_pg_opportunityoDataModel"));
			SLService.setModel(this.Component.getModel("successlineModel"));
			UtilityService.setModel(this.Component.getModel("utilityModel"));
			MtrService.setModel(this.Component.getModel("mtrODataModel"));
			UtilityService.getAuth()
				.then(({
					data
				}) => {
					if (data) {
						if (data.AuthFlg === 'X') { // Region Valiadation
							let oAppSettingModel = this.Component.getModel("appSettings");
							if (data.EditAuth !== "X") { // Non-Ore check
								//To Make Sure Not to Edit any fields in the UI
								let isNonOreUser = true;
								let isSlEditForm = false;
								let isSlEditDetail = false;
								let isSlCreateForm = false;
								if (document.location.hasOwnProperty("hash")) {
									isSlCreateForm = (document.location.hash.indexOf("SlForm") !== -1) ? true : false;
									isSlEditForm = (document.location.hash.indexOf("?SlNo=") !== -1) ? true : false;
									isSlEditDetail = (document.location.hash.indexOf("SuccessLineID") !== -1) ? true : false;
								}

								if (isNonOreUser && isSlCreateForm && !isSlEditForm) {
									this.Component.getRouter().getTargets().display("NonOreUserNotAuthorized", {
										fromTarget: "SlList"
									});
									return;
								}

								oAppSettingModel.setProperty("/isNonOreUser", isNonOreUser);
								oAppSettingModel.setProperty("/isSlCreateForm", isSlCreateForm);
								oAppSettingModel.setProperty("/isSlEditForm", isSlEditForm);
								oAppSettingModel.setProperty("/isSlEditDetail", isSlEditDetail);
							} else {
								oAppSettingModel.setProperty("/isNonOreUser", false);
								oAppSettingModel.setProperty("/isSlEditForm", false);
								oAppSettingModel.setProperty("/isSlEditDetail", false);
							}
							oAppSettingModel.refresh();
							this.loadMasterData();
							if (!this.constStorage.get("ConstantsMapData")) {
								this.loadMasterDataConstants();
							}
							if (!this.sloStorage.get("pcOppStatusMasterMap") || !this.sloStorage.get("pcOppPhaseMasterMap")) {
								//	this.sloStorage.clear();
								this.loadOpportunityMasterData();
							} else {
								var oPhaseMasterDataMap = {};
								var oStatusMasterDataMap = {};
								oPhaseMasterDataMap = this.sloStorage.get("pcOppPhaseMasterMap");
								oStatusMasterDataMap = this.sloStorage.get("pcOppStatusMasterMap");
								var oModel = this.Component.getModel("opportunityData");
								oModel.setProperty("/oppPhaseMasterData", oPhaseMasterDataMap);
								oModel.setProperty("/oppStatusMasterData", oStatusMasterDataMap);
							}
						} else {
							this.Component.getRouter().getTargets().display("notAuthorized", {
								fromTarget: "SlList"
							});
						}
					}
				});

			//	this.loadMasterData();
		},

		_initModels: function () {

			// set the model to the view
			this.Component.setModel(new JSONModel({
				isAppBusy: false,
				isTableBusy: true,
				isActvtListBusy: false,
				isItemBusy: false
			}), "appSettings");

			// set the model to the view
			this.Component.setModel(new JSONModel([]), "masterData");

		},
		loadMasterDataConstants: function () {
			var that = this;
			if (!this.constStorage.get("ConstantsMapData")) {
				SLService.getMasterData("YC_SL_M_CONSTANTS")
					.then(({
						data
					}) => {
						that.fnMasterDataSuccess("constants", data.results);
					})
					.catch(function (error) {
						Log.error("This should never have happened:" + error);
					});
			}
		},
		loadOpportunityMasterData: function () {
			let that = this;
			OppService.getOppMasterData()
				.then(({
					data
				}) => {
					that.fnMasterOppDataSuccess(data.results);
				})
				.catch(function (error) {
					Log.error("This should never have happened:" + error);
				});
		},

		loadMasterData: function () {
			var that = this;
			var oAppSettingsModel = this.Component.getModel("appSettings");
			oAppSettingsModel.setProperty("/isAppBusy", true);

			Promise.allSettled = function (promises) {
				let mappedPromises = promises.map((p) => {
					return p
						.then((value) => {
							return {
								status: 'fulfilled',
								value,
							};
						})
						.catch((reason) => {
							return {
								status: 'rejected',
								reason,
							};
						});
				});
				return Promise.all(mappedPromises);
			};

			const serviceModelsPromises = [
				this.Component.getModel("successlineModel").metadataLoaded(),
				//	this.Component.getModel("int_pg_opportunityoDataModel").metadataLoaded(),
				this.Component.getModel("utilityModel").metadataLoaded()
			];

			Promise.allSettled(serviceModelsPromises)
				.then(() => {
					const promises = [
						SLService.getMasterData("YC_SL_M_TEMPLATES")
						.then(({
							data
						}) => {
							that.fnMasterDataSuccess("templates", data.results);
						}),
						/*SLService.getMasterData("YC_SL_M_CONSTANTS")
						.then(({
							data
						}) => {
							that.fnMasterDataSuccess("constants", data.results);
						}),*/
						SLService.getLeadMasterData("YC_SL_T_SLLISTSet")
						.then(({
							data
						}) => {
							this.aLeadMap = [];
							this.aSlLeadMap = [];
							this.aLeadData = [];
							this.aSlLeadData = [];
							for (var i in data.results) {
								if (!that.aLeadMap[data.results[i].LeadId]) {
									that.aLeadMap[data.results[i].LeadId] = {
										"LeadName": data.results[i].LeadName,
										"LeadId": data.results[i].LeadId
									};
									that.aLeadData.push(that.aLeadMap[data.results[i].LeadId]);
								}
								if (data.results[i].SlLead !== "") {
									if (!that.aSlLeadMap[data.results[i].SlLead]) {
										that.aSlLeadMap[data.results[i].SlLead] = {
											"SlLeadName": data.results[i].SlLeadName,
											"SlLead": data.results[i].SlLead
										};
										that.aSlLeadData.push(that.aSlLeadMap[data.results[i].SlLead]);
									}

								}
							}

							that.fnMasterDataSuccess("LeadData", this.aLeadData);
							that.fnMasterDataSuccess("SlLeadData", this.aSlLeadData);
						}),
						SLService.getMasterData("YC_SL_M_CREATE_SERVICE")
						.then(({
							data
						}) => {
							that.fnMasterDataSuccess("CreateService", data.results);
						}),
						SLService.getMasterData("YC_SL_M_HCREGION")
						.then(({
							data
						}) => {
							that.fnMasterDataSuccess("ActivityHeadCountRegion", data.results);
						}),
						SLService.getMasterData("YC_SL_M_SOURCE_LIST", "SourceType", "ACT_LEAD")
						.then(({
							data
						}) => {
							that.fnMasterDataSuccess("ActivitySourceList", data.results);
						}),
						SLService.getMasterData("YC_SL_M_MSL_STATUS")
						.then(({
							data
						}) => {
							that.fnMasterDataSuccess("ActivityStatus", data.results);
						}),
						//Role based service integration
						SLService.getMasterData("YC_SL_ROLE_ACTVT")
						.then(({
							data
						}) => {
							that.fnMasterDataSuccess("SLRoles", data.results);
						}),
						//Risk masterdata
						SLService.getMasterData("YC_SL_M_ACT_RISK")
						.then(({
							data
						}) => {
							that.fnMasterDataSuccess("Risk", data.results);
						}),
						//Restrict Historical Activity Registration (Joe) #273
						SLService.getMasterData("YC_SL_M_USR_ACTDAYS_CHK")
						.then(({
							data
						}) => {
							that.fnMasterDataSuccess("SLRestrictions", data.results);
						}),
						//Method masterdata
						SLService.getMasterData("YC_SL_M_ACT_METHOD")
						.then(({
							data
						}) => {
							that.fnMasterDataSuccess("RapidRegMethods", data.results);
						}),
						//Type Masterdata
						SLService.getMasterData("YC_SL_M_ACTIVITY_DET_TYPE")
						.then(({
							data
						}) => {
							that.fnMasterDataSuccess("RapidRegTypes", data.results);
						}),
						//MSL Risk Master Data
						SLService.getMasterData("YC_SL_M_RISK")
						.then(({
							data
						}) => {
							that.fnMasterDataSuccess("MSLRisk", data.results);
						}),
						SLService.getMasterData("YC_MAC_M_ACT_STATUS")
						.then(({
							data
						}) => {
							that.fnMasterDataSuccess("RapidRegActStatus", data.results);
						}),
						SLService.getMasterData("YC_MAC_M_LANDSCAPES")
						.then(({
							data
						}) => {
							that.fnMasterDataSuccess("landscape", data.results);
						}),
						SLService.getMasterData("YC_MD_SOL_M_LEVEL2")
						.then(({
							data
						}) => {
							that.Component.getModel("SlDetailModel").setProperty("/Level2Key", data.results.length ? data.results[0].L2Id : "");
							that.fnMasterDataSuccess("Level2Data", data.results);
						}),

						SLService.getMasterData("YC_MD_SOL_HIER")
						.then(({
							data
						}) => {
							var oData = data.results;
							var oMaterialMap = {};
							var aMaterialData = oData.map(function (obj, index) {
								obj.isSelected = false;
								oMaterialMap[obj["MatId"]] = index;
								return obj;
							});
							that.Component.getModel("oSolutionsModel").setProperty("/SolutionHierarchy", aMaterialData);
							that.Component.getModel("oSolutionsModel").setProperty("/MaterialMap", oMaterialMap);
							// that.fnMasterDataSuccess("SolutionHierarchy", data.results);
						})

					];

					Promise.allSettled(promises)
						.then(() => {
							that.Component.getModel("appSettings").setProperty("/isAppBusy", false);
							that.Component.getRouter().initialize();
						})
						.catch(function (error) {
							Log.error("This should never have happened:" + error);
						});
				})
				.catch(function (error) {
					Log.error("This should never have happened:" + error);
				});
		},
		fnMasterOppDataSuccess: function (aResults) {
			var oStatusMasterDataMap = {},
				oPhaseMasterDataMap = {};
			aResults.filter(function (value) {
				if (value.FIELD_NAME === "STATUS") {
					oStatusMasterDataMap[value.KEY] = value;
					return true;
				}
				if (value.FIELD_NAME === "PHASE") {
					oPhaseMasterDataMap[value.KEY] = value;
				} else {
					return false;
				}
			});
			var oModel = this.Component.getModel("opportunityData");
			oModel.setProperty("/oppPhaseMasterData", oPhaseMasterDataMap);
			oModel.setProperty("/oppStatusMasterData", oStatusMasterDataMap);
			this.sloStorage.put("pcOppStatusMasterMap", oStatusMasterDataMap);
			this.sloStorage.put("pcOppPhaseMasterMap", oPhaseMasterDataMap);

		},
		fnMasterDataSuccess: function (sPropertyName, aResults) {
			const that = this;
			var oModel = this.Component.getModel("masterData");
			oModel.setProperty("/" + sPropertyName, aResults);
			if (sPropertyName === "constants") {
				//const Constants = this.Component.getModel("masterData").getProperty("/constants");
				this.ConstantsMap = {};
				if (aResults && aResults.length > 0) {
					$.each(aResults, function (index, constant) {
						that.ConstantsMap[constant.const_id] = constant;
					});
				}
				this.constStorage.put("ConstantsMapData", that.ConstantsMap);
			}
			/*if(sPropertyName === "user"){
				this.Component.getModel("user").setData(aResults[0]);
			}*/
		}

	});
	return {
		/**
		 * Method to create new instance of Application.
		 * @private
		 * @returns {sap.ui.base.Object} return new instance of Application
		 */
		getInstance: function () {
			if (!instance) {
				// create new instance of Application Object
				instance = new Application();
			}
			return instance;
		}
	};
});