sap.ui.define(["sap/ui/core/format/DateFormat"], function (DateFormat) {
	"use strict";
	let Formatter = {
		setAvatarSrc: function (value) {
			if (value !== "") {
				return this.ConstantsMap["0070"].field_value + value;
			} else {
				return "";
			}
		},
		oppDescription: function (oppId) {

			if (oppId) {
				if (this.getOwnerComponent().getModel("opportunityData").getObject("/opportunityMapData/" + oppId)) {
					return this.getOwnerComponent().getModel("opportunityData").getObject("/opportunityMapData/" + oppId).DESCRIPTION;
				} else {
					return "NA";
				}
			}
		},
		phaseDescription: function (oppId) {

			if (oppId) {

				let oppData = this.getOwnerComponent().getModel("opportunityData").getObject("/opportunityMapData/" + oppId);
				if (oppData) {
					return this.getOwnerComponent().getModel("opportunityData").getObject("/oppPhaseMasterData/" + oppData.CURR_PHASE).VALUE;
				} else {
					return "";
				}
			}
		},
		statusDescription: function (oppId) {

			if (oppId) {

				let oppData = this.getOwnerComponent().getModel("opportunityData").getObject("/opportunityMapData/" + oppId);
				if (oppData) {
					return this.getOwnerComponent().getModel("opportunityData").getObject("/oppStatusMasterData/" + oppData.STATUS).VALUE;
				} else {
					return "";
				}
			}
		},
		oppIcon: function (oppId) {
			if (oppId) {
				if (this.getOwnerComponent().getModel("opportunityData").getObject("/opportunityMapData/" + oppId)) {
					return "";
				} else {
					return "sap-icon://alert";
				}
			}
		},
		persoVisiblity: function (selected) {
			if (!this.getModel("variant").getObject("/" + selected + "/visible")) {
				return false;
			} else {
				return this.getModel("variant").getObject("/" + selected + "/visible");
			}
		},
		visiblity: function (visible) {
			if (visible) {
				return true;
			} else {
				return false;
			}
		},
		formatActvtWeight: function (weight) {
			return parseInt(weight);

		},
		defaultCompletionValue: function (val) {
			if (!val) {
				return "5,60";
			}
		},
		formatAccountDetails: function (value) {
			if (value && value !== "") {
				return value;
			} else {
				return "Unavailable";
			}

		},
		formatActvityActions: function (regActId, regMandtry, statusId) {
			if (regActId === "" && !regMandtry) {
				return "Register Activity";
			} else if (regActId === "" && regMandtry) {
				return "Register Activity *";
			} else if (regActId !== "" && statusId !== "2") {
				return "Registered";
			} else if (regActId !== "" && statusId === "2") {
				return "Reopen";
			}
		},
		formatActvtActionIcon: function (regActId, regMandtry, statusId) {
			if (regActId === "") {
				return "sap-icon://add-document";
			} else if (regActId !== "" && statusId !== "2") {
				return "sap-icon://activity-2";
			} else {
				return "";
			}

		},
		setActRegCustomData: function (regActId, regMandtry, statusId) {
			if (regActId === "") {
				return "REG_ACT";
			} else if (regActId !== "" && statusId !== "2") {
				return "REG";
			} else if (regActId !== "" && statusId === "2") {
				return "RE_OPEN";
			}

		},
		formatActvtRemove: function (regActId, regMandtry, statusId) {
			if ((regActId === "" || (regActId !== "" && statusId === "2")) && !regMandtry) {
				return "Remove";
			} else if ((regActId === "" || (regActId !== "" && statusId === "2")) && regMandtry) {
				return "Required";
			} else {
				return "Cancel Registration";
			}
		},

		formatActvtRemoveIcon: function (regActId, regMandtry, statusId) {
			if ((regActId === "" || (regActId !== "" && statusId === "2")) && !regMandtry) {
				return "sap-icon://decline";
			} else if ((regActId === "" || (regActId !== "" && statusId === "2")) && regMandtry) {
				return "";
			} else {
				return "sap-icon://decline";
			}
		},
		setCustomData: function (regActId, regMandtry, statusId) {
			if ((regActId === "" || (regActId !== "" && statusId === "2")) && !regMandtry) {
				return "REMOVE";
			} else if ((regActId === "" || (regActId !== "" && statusId === "2")) && regMandtry) {
				return "";
			} else {
				return "CANCEL";
			}
		},
		handleDisableReq: function (bIsAuthorized, sArchive, sActive, regActId, regMandtry, statusId) {
			if (bIsAuthorized) {
				if ((sArchive === "01" && sActive) && !((regActId === "" || (regActId !== "" && statusId === "2")) && regMandtry)) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		},

		formatOppStatus: function (sOppId) {
			const oppData = this.getOwnerComponent().getModel("opportunityData").getProperty("/opportunityMapData");
			var colorCode = 'None';
			if (oppData && oppData[sOppId]) {
				if (oppData[sOppId].STATUS) {
					switch (oppData[sOppId].STATUS) {
						case 'E0001':
							colorCode = 'Indication07';
							break;
						case 'E0002':
							colorCode = 'Indication06';
							break;
						case 'E0003':
							colorCode = 'Success';
							break;
						case 'E0004':
							colorCode = 'None';
							break;
						case 'E0005':
							colorCode = 'Error';
							break;
						case 'E0007':
							colorCode = 'Indication06';
							break;
						case 'E0014':
							colorCode = 'None';
							break;
					}
				}
			}
			return colorCode;
		},
		setOppStatusText: function (sOppId) {
			const oppData = this.getOwnerComponent().getModel("opportunityData").getProperty("/opportunityMapData");
			if (oppData && oppData[sOppId]) {
				return this.getOwnerComponent().getModel("opportunityData").getProperty("/oppStatusMasterData")[oppData[sOppId].STATUS].VALUE;
			} else {
				return "NA";
			}

		},
		setOppStatusTextTooltip: function (sOppId) {
			const oppData = this.getOwnerComponent().getModel("opportunityData").getProperty("/opportunityMapData");
			if (oppData && oppData[sOppId]) {
				return this.getOwnerComponent().getModel("opportunityData").getProperty("/oppStatusMasterData")[oppData[sOppId].STATUS].VALUE;
			} else {
				return "Not Applicable";
			}

		},
		formatWarningIcon: function (sOppId) {
			const oppData = this.getOwnerComponent().getModel("opportunityData").getProperty("/opportunityMapData");
			if (sOppId) {
				if (oppData && oppData[sOppId]) {
					return false;
				} else {
					return true;
				}
			} else {
				return false;
			}

		},
		setOppValue: function (sOppId, sValue) {
			const oppData = this.getOwnerComponent().getModel("opportunityData").getProperty("/opportunityMapData");
			if (sOppId) {
				if (oppData && oppData[sOppId]) {
					return sValue;
				} else {
					return "";
				}
			} else {
				return "Not Applicable";
			}

		},
		setOppValueVisible: function (sOppId, sValue) {
			const oppData = this.getOwnerComponent().getModel("opportunityData").getProperty("/opportunityMapData");
			if (sOppId) {
				if (oppData && oppData[sOppId]) {
					return true;
				} else {
					return false;
				}
			} else {
				return true;
			}

		},

		formatOppDetails: function (value) {
			if (value) {
				return value;
			} else {
				return "Not Applicable";
			}
		},
		formatOppDetailsCommentVisible: function (value) {
			if (value) {
				return true;
			} else {
				return false;
			}
		},
		formatOppDetailsCommentHide: function (value) {
			if (value) {
				return false;
			} else {
				return true;
			}
		},
		setContrbtrTooltip: function (aSlTeam) {
			let aMgrTeam = this.getOwnerComponent().getModel("masterData").getProperty("/myTeamData");
			let aContrbtrTeam = this.Formatter._getContributers(aSlTeam, aMgrTeam);
			if (aContrbtrTeam.length === 1) {
				return aContrbtrTeam[0].Fullname;
			}
		},
		setContrbtrCount: function (aSlTeam) {
			let aMgrTeam = this.getOwnerComponent().getModel("masterData").getProperty("/myTeamData");
			let aContrbtrTeam = this.Formatter._getContributers(aSlTeam, aMgrTeam);
			if (aContrbtrTeam.length === 1) {
				if (aContrbtrTeam[0].Fullname.length > 12) {
					aContrbtrTeam[0].FullnameChanged = aContrbtrTeam[0].Fullname.slice(0, 12) + "..";
				} else {
					aContrbtrTeam[0].FullnameChanged = aContrbtrTeam[0].Fullname;
				}
				return aContrbtrTeam[0].FullnameChanged;
			} else {
				return aContrbtrTeam.length;
			}
		},
		_getContributers: function (aSlTeam, aMgrTeam) {
			var aContrbtrTeam = [];
			$.each(aMgrTeam, function (index, team) {
				aSlTeam.filter((item) => {
					if (item.Userid === team.userid) {
						aContrbtrTeam.push(item);
					}
				});
			});
			return aContrbtrTeam;

		},
		setContributerIcon: function (aSlTeam) {
			let aMgrTeam = this.getOwnerComponent().getModel("masterData").getProperty("/myTeamData");
			let aContrbtrTeam = this.Formatter._getContributers(aSlTeam, aMgrTeam);
			if (aContrbtrTeam.length === 1) {
				return "";
			} else {
				return "sap-icon://personnel-view";
			}

		},
		formatRecomendedRoles: function (aRoles) {
			let sRoles = "";
			if (aRoles && aRoles.length > 0) {
				$.each(aRoles, function (index, role) {
					if (sRoles === "") {
						sRoles = role.RoleDesc;
					} else {
						sRoles = sRoles + " , " + role.RoleDesc;
					}
				});
				return sRoles;
			} else {
				return "Not Available";
			}

		},
		formatGraphImageSrc: function (sVal) {
			var sRootPath = jQuery.sap.getModulePath("com.presalescentral.successline");
			return sRootPath + "/images/graph_background_378_3234.png";
		},

		formatOppDesc: function (sOppDesc) {
			if (sOppDesc) {
				if (sOppDesc.length && sOppDesc.length > 20) {
					let sShortDesc = sOppDesc.slice(0, 18) + "...";
					return sShortDesc;
				}
				return sOppDesc;
			} else {
				return "Not Authorized";
			}

		},
		formatAccntDesc: function (sAccntDesc) {
			if (sAccntDesc) {
				if (sAccntDesc.length && sAccntDesc.length > 20) {
					let sShortDesc = sAccntDesc.slice(0, 18) + "...";
					return sShortDesc;
				}
				return sAccntDesc;
			} else {
				return "Not Authorized";
			}

		},
		// formatOppAccntDes: function (sOppId) {
		// 	if (sOppId) {
		// 		let sOppDesc = this.getModel().getProperty("/SelectedOpportunity/DESCRIPTION");
		// 		if (sOppDesc && sOppDesc !== '') {
		// 			if (sOppDesc.length && sOppDesc.length > 20) {
		// 				let sShortNotes = sOppDesc.slice(0, 20) + "...";
		// 				return sShortNotes;
		// 			}
		// 			return sOppDesc;
		// 		} else {
		// 			return "Not Applicable";
		// 		}
		// 	} else {
		// 		let sAccntName = this.getModel().getProperty("/SelectedOpportunity/ACCOUNT_NAME");
		// 		if (sAccntName && sAccntName !== '') {
		// 			return sAccntName;
		// 		} else {
		// 			return "Not Applicable";
		// 		}

		// 	}
		// },
		formatOppAccntTooltip: function (sOppId) {
			if (sOppId) {
				let sOppDesc = this.getComponent().getModel("SlDetailModel").getProperty("/SelectedOpportunity/DESCRIPTION");
				if (sOppDesc && sOppDesc !== '') {
					return sOppDesc;
				} else {
					return "Not Applicable";
				}
			} else {
				let sAccntName = this.getComponent().getModel("SlDetailModel").getProperty("/SelectedOpportunity/ACCOUNT_NAME");
				if (sAccntName && sAccntName !== '') {
					return sAccntName;
				} else {
					return "Not Applicable";
				}

			}
		},
		formatNotes: function (sNotes) {
			if (sNotes) {
				let sLength = sNotes.length;
				if (sLength && sLength > 50) {
					let sShortNotes = sNotes.slice(0, 50) + "...";
					return sShortNotes;
				} else {
					return sNotes;
				}
			}
		},
		formatTemplateName: function (sTempName) {
			if (sTempName) {
				let sLength = sTempName.length;
				if (sLength && sLength > 25) {
					let sShortNotes = sTempName.slice(0, 25) + "...";
					return sShortNotes;
				} else {
					return sTempName;
				}
			}
		},
		formatCreatorName: function (sTempName) {
			if (sTempName) {
				let sLength = sTempName.length;
				if (sLength && sLength > 10) {
					let sShortNotes = sTempName.slice(0, 8) + "...";
					return sShortNotes;
				} else {
					return sTempName;
				}
			}
		},
		formatRiskTooltip: function (sRisk) {
			if (sRisk === "Success") {
				return "Green Risk";
			} else if (sRisk === "Error") {
				return "Red Risk";

			} else if (sRisk === "Warning") {
				return "Yellow Risk";

			} else {
				return "None";
			}

		},
		formatStoryLink: function (sLink, sDisplayName) {
			let StoryLink = "";
			if (sDisplayName) {
				StoryLink = sDisplayName;
			} else {
				StoryLink = sLink;
			}
			if (StoryLink) {
				if (StoryLink.length && StoryLink.length > 30) {
					let sShortLink = StoryLink.slice(0, 20) + "...";
					return sShortLink;
				}
			}
			return StoryLink;
		},
		formatStoryLinkTooltip: function (sLink, sDisplayName) {
			if (sDisplayName) {
				return sDisplayName;
			} else {
				return sLink;
			}
		},
		formatTouchpointLinkLength: function (slink) {
			// let slink = link.replace(/[^a-zA-Z0-9]/g, '');
			if (slink) {
				if (slink.length && slink.length > 60) {
					let sShortDesc = slink.slice(0, 60) + "...";
					return sShortDesc;
				}
				return slink;
			}

		},
		setCommentsAvatarSrc: function (value) {
			if (value && value !== "") {
				return this.ConstantsMap["0070"].field_value + value;
			} else {
				return "sap-icon://person-placeholder";
			}
		},
		formatArrowLink: function (slink) {
			if (slink) {
				if (slink.length && slink.length > 20) {
					let sShortDesc = slink.slice(0, 17) + "...";
					return sShortDesc;
				}
				return slink;
			}

		},
		formatSubTitleText: function (text) {
			if (text) {
				if (text.length && text.length > 20) {
					let sShortDesc = text.slice(0, 15) + "...";
					return sShortDesc;
				} else {

					return text;
				}
			} else if (text === "") {
				let i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				let sSubText = i18nModel.getText("txtsub");
				return sSubText;
			}
		},
		formatTextForSubtitle: function (text) {
			if (text) {
				return text;
			} else if (text === "") {
				let i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				let sSubText = i18nModel.getText("txtsub");
				return sSubText;
			}
		},
		formatTitleText: function (text) {
			if (text) {
				if (text.length && text.length > 75) {
					let sShortDesc = text.slice(0, 60) + "...";
					return sShortDesc;
				}
				return text;
			}
		},
		formatActLeadText: function (text) {
			if (text) {
				if (text.length && text.length >= 12) {
					let sShortDesc = text.split(" ")[0];
					/*if (sShortDesc && sShortDesc.length > 13) {
						sShortDesc = sShortDesc.slice(0, 10) + "...";
					}*/
					return sShortDesc;
				}
				return text;
			}
		},
		formatActLeadTableText: function (text) {
			if (text) {
				if (text.length && text.length >= 12) {
					let sShortDesc = text.split(" ")[0];
					/*if (sShortDesc && sShortDesc.length > 13) {
						sShortDesc = sShortDesc.slice(0, 10) + "...";
					}*/
					return sShortDesc;
				}
				return text;
			}
		},
		formatPhaseColor: function (text, color) {
			if (color) {
				return text;
			} else {
				return text;
			}
		},

		formatServiceText: function (sSource, sSubTitle) {
			if (sSource) {
				let sLength = sSource.length;
				if (sLength && sLength > 30) {
					let sShortNotes = sSource.slice(0, 20) + "...";
					return sShortNotes;
				} else {
					return sSource;
				}
			}
		},

		formatServiceSourceText: function (sSource, sSubTitle) {
			if (sSource) {
				let sLength = sSource.length;
				if (sLength && sLength > 20) {
					let sShortNotes = sSource.slice(0, 15) + "...";
					return sShortNotes;
				} else {
					return sSource;
				}
			}
		},

		formatDate: function (date) {
			if (date !== "" & date !== undefined & date != null) {
				if (date === "Invalid Date") {
					return "";
				} else {

					date = new Date(date);
					var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						format: "yMMMdd",
						style: "short"
					});
					return dateFormat.format(date);
				}
			} else {
				return "";
			}
		},
		formatDateTime: function (date) {
			if (date !== "" & date !== undefined & date != null) {
				if (date === "Invalid Date") {
					return "";
				} else {

					date = new Date(date);
					var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						format: "yMMMddHHmm",
						style: "short"
					});
					return dateFormat.format(date);
				}
			} else {
				return "";
			}
		},
		formatIssText: function (sIss) {
			if (sIss) {
				if (sIss.length && sIss.length > 15) {
					let sShortDesc = sIss.slice(0, 11) + "...";
					return sShortDesc;
				}
				return sIss;
			} else {
				return "Not Applicable";
			}

		},
		openStoryLink: function (url) {
			if (url) {
				if (!url.match(/^[a-zA-Z]+:\/\//)) {
					url = 'https://' + url;
				}
			}
			return url;
		},
		setSwitchText: function (operationStatus) {
			if (operationStatus === "X" || operationStatus) {
				return "Enabled";
			} else {
				return "Disabled";
			}
		},
		formatStatusIcon: function (statusId) {
			var value = "sap-icon://lightbulb";
			switch (statusId) {
				case '01':
					value = 'sap-icon://activity-2';
					break;
				case '02':
					value = 'sap-icon://cancel';
					break;
				case '10':
					value = 'sap-icon://lightbulb';
					break;
				case '11':
					value = 'sap-icon://thumb-up';
					break;
				case '12':
					value = 'sap-icon://accept';
					break;
				case '13':
					value = 'sap-icon://favorite';
					break;
				case '14':
					value = 'sap-icon://sys-enter';
					break;
				case '15':
					value = 'sap-icon://thumb-down';
					break;
				case '16':
					value = 'sap-icon://accept';
					break;
				case '17':
					value = 'sap-icon://accept';
					break;
				case '18':
					value = 'sap-icon://accept';
					break;
			}
			return value;
		},

		formatStatusText: function (statusId, compDate) {
			var value = " Recommended";
			var date = null;
			if (compDate) {
				date = this.Formatter.formatDate(compDate);
			}
			switch (statusId) {
				case '01':
					value = " Registered";
					break;
				case '02':
					value = " Cancelled";
					break;
				case '10':
					value = " Recommended";
					break;
				case '11':
					value = " Planned";
					break;
				case '12':
					if (date) {
						value = " Completed: " + date + "";
					} else {
						value = " Completed";
					}

					break;
				case '13':
					value = " Required";
					break;
				case '14':
					if (date) {
						value = " Validated: " + date + "";
					} else {
						value = " Validated";
					}
					break;
				case '15':
					value = "Not Applicable";
					break;
				case '16':
					value = " Started";
					break;
				case '17':
					value = " Progressing";
					break;
				case '18':
					value = " Presented";
					break;
			}
			return value;
		},

		formatServiceOutcomeStatusIcon: function (statusId, outcomeAchievedToggle = "") {
			var value = "";
			if (statusId === "01" && outcomeAchievedToggle === "X") {
				value = "sap-icon://sys-enter-2";
			}
			if (!outcomeAchievedToggle) {
				value = "sap-icon://sys-enter-2";
			}
			return value;
		},

		formatServiceOutcomeStatusText: function (statusId) {
			var value = "";
			switch (statusId) {
				case "01":
					value = "Achieved";
					break;
			}
			return value;
		},
		formatCancelTxt: function (i18nTxt, date, user, ParallelSlSnro) {
			if (date) {
				return this._oResourceBundle.getText("xmsg.cancelledActivityPopup", [this.Formatter.formatDate(date), user]);
			}
		},
		formatParallelMsl: function (StatusId, ParallelSlSnro) {
			if (StatusId === "02" && ParallelSlSnro !== "") {
				return true;
			} else {
				return false;
			}
		},
		formatNonParallelMsl: function (StatusId, ParallelSlSnro) {
			if (StatusId === "02" && ParallelSlSnro !== "") {
				return false;
			} else if (StatusId === "02" && ParallelSlSnro === "") {
				return true;
			} else {
				return false;
			}
		},
		formatCancelParallelMslTxt: function (i18nTxt, date, user, ParallelSlSnro) {
			if (date) {
				//return "Canceled on " +  this.Formatter.formatDate(date) + " by " + user +". Discontinued opportunity.";
				return this._oResourceBundle.getText("xmsg.cancelledMslParaelActivityPopup", [this.Formatter.formatDate(date), user]);
			}
		},
		formatParallelMslEditAction: function (isAuthorized, Archive, ParallelSlSnro) {
			if (isAuthorized && !Archive && ParallelSlSnro === "") {
				return true;
			} else {
				return false;
			}
		},

		formattooltip: function (arg1, arg2, arg3, arg4) {
			var sDate = "";
			if (arg2) {
				var month = arg2.getMonth() + 1;
				sDate = arg2.getDate() + "/" + month + "/" + arg2.getFullYear();
			}
			return arg1 + " " + sDate + " " + arg3 + " " + arg4;
		},
		formatReopen: function (currentUser, slLead, isArchived) {
			if (currentUser === slLead && !isArchived) {
				return true;
			} else {
				return false;
			}
		},
		formatLinkMslLinkVisi: function (currentUser, slLead, isArchived, ParallelSlSnro) {
			if (currentUser && slLead && ParallelSlSnro) {
				return true;
			} else {
				return false;
			}
		},
		formatSwitchArchive: function (isAuthorized, StatusId, SLCompletion, archived) {
			if (StatusId === '02' || parseInt(SLCompletion) === 100 || StatusId === '12') {
				if (isAuthorized) {
					return true;
				}
			} else if (archived === true) {
				if (isAuthorized) {
					return true;
				}
			} else {
				return false;
			}
		},
		formatTeamLength: function (results) {
			if (results && results.length > 0) {
				var str = results.length;
				return str.toString();
			} else {
				return "0";
			}
		},
		formatActivitySourceList: function (opp, key) {
			if (!opp && key === '002') { //From opportunity
				return false;
			} else if (opp && key === '001') {
				return true;
			} else {
				return true;
			}
		},
		formatSourceText: function (sSource, sSubTitle) {
			if (sSource) {
				let sLength = sSource.length;
				if (sLength && sLength > 30) {
					let sShortNotes = sSource.slice(0, 25) + "...";
					return sShortNotes;
				} else {
					return sSource;
				}
			}
		},
		formatSLLeadAuth: function (ActLead, UserId, SlLead, regAccess) {
			if (ActLead !== "" && ActLead !== null) {
				if (UserId === SlLead || regAccess) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		formatMethodDesc: function (MethodId) {
			var Desc = "";
			switch (MethodId) {
				case 'D':
					Desc = 'At SAP Office';
					break;
				case 'O':
					Desc = 'Onsite Customer';
					break;
				case 'R':
					Desc = 'Onsite and Virtual';
					break;
				case 'V':
					Desc = 'Virtual';
					break;
			}
			return Desc;
		},
		formatLinkUrl: function (url) {
			if (url) {
				if (!url.match(/^[a-zA-Z]+:\/\//)) {
					url = 'https://' + url;
				}
			}
			return url;
		},
		formatRegAccess: function (flag) {
			if (flag) {
				return true;
			} else {
				return false;
			}
		},

		getInitials: function (name) {
			if (!name) {
				return "";
			}
			let parts = name.split(" ");
			let initials = "";
			for (var i = 0; i < parts.length; i++) {
				if (parts[i].length > 0 && parts[i] !== "") {
					initials += parts[i][0];
				}
			}
			if (initials.length > 2) {
				initials = initials.charAt(0) + initials.charAt(initials.length - 1);
			}
			return initials;
		},

		//Additional Opportunities #89
		handleAddOppSelectbuttonTxt: function (sOppId) {
			this.initializeAddOppList();
			var bAddOppSelectFlag = false;
			if (sOppId) {
				var tokens = this.getView().byId("slAdditionalOpptMultiInput").getTokens();
				$.each(tokens, function (index, token) {
					if (parseInt(token.getText()) === parseInt(sOppId)) {
						bAddOppSelectFlag = true;
					}
				});
			}
			if (bAddOppSelectFlag) {
				return "Deselect";
			} else {
				return "Select";
			}
		},

		handleAddOppToggleBtnPressed: function (sOppId) {
			var bAddOppSelectFlag = false;
			if (sOppId) {
				var tokens = this.getView().byId("slAdditionalOpptMultiInput").getTokens();
				$.each(tokens, function (index, token) {
					if (parseInt(token.getText()) === parseInt(sOppId)) {
						bAddOppSelectFlag = true;
					}
				});
			}
			if (bAddOppSelectFlag) {
				return bAddOppSelectFlag;
			}
		},

		formatAddOppDate: function (date) {
			var dateFormat = DateFormat.getDateInstance({
				style: "medium"
			});
			if (date && date !== null && date !== "") {
				return dateFormat.format(new Date(date));
			} else {
				return null;
			}
		},

		formatStatus: function (StatusId) {
			return this.oStorage.get("pcOppStatusMasterMap")[StatusId].VALUE;
		},

		formatPrimaryOppoHeader: function (OpportunityId, isMainOpp) {
			if (isMainOpp) {
				return OpportunityId + " (Primary)";
			} else {
				return OpportunityId;
			}
		},
		formatDisplaySubtitle: function (isIndependent, SubTitle, EnabledRoles) {
			if (isIndependent === undefined && SubTitle !== undefined && EnabledRoles !== undefined) {
				return true;
			} else if (isIndependent !== undefined && SubTitle !== undefined && EnabledRoles !== undefined) {
				let phaseId = this.getView().getModel("slDefaultModel").getData().ActivityDetails.PhaseId;
				if (phaseId === "") {
					return false;
				} else {
					return true;
				}
			}
		},
		removeLeadingComma: function (sRoles) {
			if (!sRoles) return "";

			return sRoles.replace(/^,\s*/, ""); 
		},
		formatSubTitleInputText: function (text) {
			if (text) {
				return text;
			} else if (text === "") {
				let i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				let sSubText = i18nModel.getText("txtsub");
				return sSubText;
			}
		},
		formatHtmlString: function (text) {
			if (text) {
				return text.replace(/(<([^>]+)>)/ig, '');

			}
		},
		formatSubTitlePresetationText: function (text) {
			if (text) {
				if (text.length && text.length > 40) {
					let sShortDesc = text.slice(0, 40) + "...";
					return sShortDesc;
				} else {

					return text;
				}
			} else if (text === "") {
				let i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				let sSubText = i18nModel.getText("txtsub");
				return sSubText;
			}
		},

		setRiskInfoTextWithLink: function () {
			var sUrl = this.ConstantsMap["0123"].field_value;
			return "<p>If this is a technical issue with a demo, please <a href=\"" + sUrl +
				"\"\">create a ticket</a> if you have not already.If possible, give the Support team 24 hours to address the ticket before marking the demo as red.If a ticket exists, please include the number in the Risk Comments section.Describe the specific issue(s) that are placing this event at risk.</p>";
		},

		//function to get action menu icon based on statusId
		getActionMenuIcon: function (itemId, activityStatusId) {
			let sIcon = "sap-icon://blank";
			if (itemId === activityStatusId) {
				sIcon = "sap-icon://accept";
			}
			return sIcon;
		},

		//function to set Active for Object Status
		fnSetActiveForStatusId: function (statusId) {
			let aStatusValidations = ["01", "12", "14", "16", "17", "18"];
			if (statusId && aStatusValidations.indexOf(statusId) !== -1) {
				return true;
			} else {
				return false;
			}
		},

		//Solution hierarchy changes
		//Set Solutions Tree control's checkbox visibility
		formatSolTreeCheckBox: function (MatTblSelectMode, isCheckBoxVisible) {
			var bVal = false;
			if (MatTblSelectMode === "MultiSelect") {
				bVal = isCheckBoxVisible;
			}
			return bVal;
		},

		//Set Solutions Tree control's radiobutton visibility
		formatSolTreeRadioBtn: function (MatTblSelectMode, isRadioBtnVisible) {
			var bVal = false;
			if (MatTblSelectMode === "SingleSelectLeft") {
				bVal = isRadioBtnVisible;
			}
			return bVal;
		},

		//Function to set Checkbox and Radiobutton set set selected from Tree
		fnSetSolCBRBSelected: function (LevelId, L4Id, L5Id, LevelCount, isParent) {
			var bVal = false;
			var oSolutionsModel = this.parentController.oSolutionsModel;
			var oSolTempArr = oSolutionsModel.getProperty("/oSolTempArr");
			if (oSolTempArr) {
				oSolTempArr.filter(function (obj, index) {
					if (obj.L4Id === L4Id && obj.LevelCount === 4 && obj.LevelId === LevelId) {
						bVal = true;
						if (oSolutionsModel.getProperty("/MatTblSelectMode") === "SingleSelectLeft") {
							if (obj.ValueState === "Information") {
								bVal = false;
							}
						}
					}
					if (obj.L5Id === L5Id && obj.LevelCount === 5 && obj.LevelId === LevelId) {
						bVal = true;
					}
				});
			}
			return bVal;
		},

		//Function to set Checkbox and Radiobutton set set selected from Table
		fnSetMatCBRBSelected: function (MatId) {
			var bVal = false;
			var oMatTempArr = this.parentController.oSolutionsModel.getProperty("/oMatTempArr");
			if (oMatTempArr) {
				oMatTempArr.filter(function (obj, index) {
					if (obj.MatId === MatId) {
						bVal = true;
					}
				});
			}
			return bVal;
		},

		//Function to set valuestate for L4's radiobutton, if L5 is selected
		formatSolTreeRadioBtnValState: function (LevelId, L4Id) {
			var valueState = "None";
			var oSolTempArr = this.parentController.oSolutionsModel.getProperty("/oSolTempArr");
			if (oSolTempArr) {
				oSolTempArr.filter(function (obj, index) {
					if (obj.L4Id === L4Id && obj.LevelCount === 4 && obj.LevelId === LevelId) {
						valueState = obj.ValueState;
					}
				});
			}
			return valueState;
		},

		handleRapidRegAddOppSelectbuttonTxt: function (sOppId) {
			var bAddOppSelectFlag = false;
			if (sOppId) {
				var tokens = this.parentView.byId("rapidRegAddOpptMultiInput").getTokens();
				$.each(tokens, function (index, token) {
					if (parseInt(token.getText(), 10) === parseInt(sOppId, 10)) {
						bAddOppSelectFlag = true;
					}
				});
			}
			if (bAddOppSelectFlag) {
				return "Deselect";
			} else {
				return "Select";
			}
		},
		handleRapidRegAddOppToggleBtnPressed: function (sOppId) {
			var bAddOppSelectFlag = false;
			if (sOppId) {
				var tokens = this.parentView.byId("rapidRegAddOpptMultiInput").getTokens();
				$.each(tokens, function (index, token) {
					if (parseInt(token.getText(), 10) === parseInt(sOppId, 10)) {
						bAddOppSelectFlag = true;
					}
				});
			}
			if (bAddOppSelectFlag) {
				return bAddOppSelectFlag;
			}
		},

		//function to return touchpoint status based on statusId
		getTouchPointStatusDesc: function (statusId = "", statusDescription = "", outcomeAchievedToggle = "") {
			if (statusId === "01" && outcomeAchievedToggle === "X") {
				return "Achieved";
			} else if (!outcomeAchievedToggle) {
				return statusDescription;
			}
			return "";
		},

		getActivityCompletionTxt: function (statusId, isArchived) {
			let completionTxt = "Activity is marked as " + (statusId === "12" ? "Completed." : "Validated.");
			if (isArchived) {
				return completionTxt + " Archived.";
			} else {
				return completionTxt;
			}
		}
	};
	return Formatter;
},
	true);