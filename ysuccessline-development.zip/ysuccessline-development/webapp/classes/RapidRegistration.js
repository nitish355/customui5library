sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/Device",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterType",
	"sap/ui/model/FilterOperator",
	"com/presalescentral/successline/service/SLService",
	"com/presalescentral/successline/model/Formatter",
	"com/presalescentral/successline/controller/BaseController",
	"com/melody/lib/classes/Activity",
	"com/presalescentral/successline/service/UtilityService",
	"com/melody/lib/util/mtr/MTRModels",
	"com/melody/lib/util/Activity",
	"com/melody/lib/classes/mtr/Entry",
	"com/melody/lib/util/mtr/MTR",
], function (RapidRegObject, Device, MessageToast, JSONModel, ResourceModel, Filter, FilterType, FilterOperator, SLService, Formatter,
	BaseController, MtrActivity, UtilityService, MTRModels, ActivityUtil, Entry, MTRUtil) {
	"use strict";
	return RapidRegObject.extend("com.presalescentral.successline.classes.RapidRegistration", {
		Formatter: Formatter,
		constructor: function (parentController) {
			this.parentController = parentController;
			this.parentView = parentController.getView();
			this.slModel = this.parentController.getOwnerComponent().getModel("successlineModel");
			this.appModel = this.parentController.getOwnerComponent().getModel("appSettings");
			this.alluserModel = this.parentController.getOwnerComponent().getModel("alluserModel");
			this.slModel.setUseBatch(true);
			this.oMTRModel = this.parentController.getOwnerComponent().getModel("oMTRModel");
		},

		fnOpenRapidRegDialog: function (key, oActv, oSource, sCustomerAction) {
			let that = this;
			this.parentView.setModel(new JSONModel([]), "userSearch");
			this.selectedTeam = {};
			this.landscapeMap = {};
			let acttypeid = oActv.ActivityId;
			let formlayoutId = ("frmlayout_id" in oActv) ? oActv.frmlayout_id : "";
			//Restrict Historical Activity Registration (Joe) #273
			let oActType;
			let aDateInfo = this.parentController.getView().getModel("masterData").getProperty("/SLRestrictions");
			aDateInfo.forEach((dateObject) => {
				oActType = dateObject.ActivityType;
				if (acttypeid === oActType) {
					that.parentView.getModel("masterData").setProperty("/slDaysRestriction", dateObject.DaysRestriction);
					that.parentView.getModel("masterData").setProperty("/slDateRestriction", dateObject.DateRestriction);
				}
			});
			that.parentView.getModel("SlDetailModel").setProperty("/RapidRegActivity", oActv);
			that.parentView.getModel("SlDetailModel").setProperty("/RapidRegActivityStatus", key);
			that.parentView.getModel("SlDetailModel").setProperty("/RapidRegActTypeId", acttypeid);
			let userId = that.parentView.getModel("user").getProperty("/UserId");
			let userName = that.parentView.getModel("user").getProperty("/UserName");
			let ActvtLead = oActv.ActLeadId;
			let ActvtLeadName = oActv.ActLead;
			if (ActvtLead && ActvtLeadName) {
				that.parentView.getModel("SlDetailModel").setProperty("/SlActvtLeadName", ActvtLeadName);
				that.parentView.getModel("SlDetailModel").setProperty("/SlActvtLead", ActvtLead);
			} else {
				that.parentView.getModel("SlDetailModel").setProperty("/SlActvtLeadName", userName);
				that.parentView.getModel("SlDetailModel").setProperty("/SlActvtLead", userId);
			}
			this.initializeModelData();
			let wrapper = oActv.to_slwrapper;
			let wrapperStartDate, wrapperEndDate, wrapperMethodId, wrapperTypeId;
			let currentDate = new Date();
			var createMode = oActv.RegisteredActId ? "EDIT_ACTIVITY" : "NEW_ACTIVITY";
			that.parentView.getModel("SlDetailModel").setProperty("/CreateMode", createMode); // RegisteredActId
			if (wrapper) {
				if (oActv.to_slwrapper.results) {
					if (oActv.to_slwrapper.results[0].StartAt && oActv.to_slwrapper.results[0].EndAt) {
						wrapperStartDate = new Date(oActv.to_slwrapper.results[0].StartAt);
						wrapperEndDate = new Date(oActv.to_slwrapper.results[0].EndAt);
					}
					if (oActv.to_slwrapper.results[0].MethodId) {
						wrapperMethodId = oActv.to_slwrapper.results[0].MethodId;
					}
					if (oActv.to_slwrapper.results[0].to_team.results) {
						that.parentView.getModel("SlDetailModel").setProperty("/RapidRegActivityTeamMembers", oActv.to_slwrapper.results[0].to_team.results);
						that.parentView.getModel("SlDetailModel").refresh(true);
					}
					if (oActv.to_slwrapper.results[0].to_ADetType.results) {
						if (oActv.to_slwrapper.results[0].to_ADetType.results.length > 0) {
							wrapperTypeId = oActv.to_slwrapper.results[0].to_ADetType.results;
							that.parentView.getModel("SlDetailModel").setProperty("/RapidRegSelectedTypeDetails", wrapperTypeId);
							that.parentView.getModel("SlDetailModel").setProperty("/SelectedRapidRegType", wrapperTypeId[0].TypeId);
						}

					}
					if (oActv.to_slwrapper.results[0].Notes) {
						that.parentView.getModel("slDefaultModel").setProperty("/ActivityDetails/to_slwrapper/results/0/Notes", oActv.to_slwrapper.results[
							0].Notes);
					}

					var dryRunDate = oActv.to_slwrapper.results[0].DryRunDate;
					that.parentView.getModel("SlDetailModel").setProperty("/DryRunDate", dryRunDate ? new Date(dryRunDate) : null);

					that.parentView.getModel("SlDetailModel").setProperty("/RapidRegActivity/StatusId", oActv.to_slwrapper.results[0].Status);

					//Initiatives
					var aSelectedInitiatives = oActv.to_slwrapper.results[0].to_AInitiative.results;
					if (aSelectedInitiatives && aSelectedInitiatives.length) {
						that.parentView.getModel("SlDetailModel").setProperty("/to_AInitiative", aSelectedInitiatives);
					}
					//Landscapes edit
					var aSelectedLandscapes = oActv.to_slwrapper.results[0].to_ALand.results;
					if (aSelectedLandscapes && aSelectedLandscapes.length) {
						this.parentView.getModel("SlDetailModel").setProperty("/to_ALand", aSelectedLandscapes);
					}
					aSelectedLandscapes.filter(function (obj, index) {
						that.landscapeMap[obj.LandsId] = obj;
					});
					if (formlayoutId === "00001" && !aSelectedLandscapes.length) {
						that.parentView.getModel("SlDetailModel").setProperty("/DemoEnvCheckBoxSelected", true);
						// that.parentView.byId("demoEnvironmentCheckBox").setSelected(true);
					}

					//Asset documents and linke
					var aFiles = oActv.to_slwrapper.results[0].to_AFiles.results;
					that.parentView.getModel("SlDetailModel").setProperty("/to_AFiles", (aFiles && aFiles.length) ? aFiles : []);

					//setting additional opportunities in edit case
					var aAddOpps = oActv.to_slwrapper.results[0].to_AAddOpp.results;
					that.parentView.getModel("SlDetailModel").setProperty("/to_addopp", (aAddOpps && aAddOpps.length) ? aAddOpps : []);

					//cvj phase
					var cvjPhaseId = oActv.to_slwrapper.results[0].CvjPhaseId;
					that.parentView.getModel("SlDetailModel").setProperty("/CvjPhaseId", cvjPhaseId);

					//setting material data in edit
					var aMaterials = oActv.to_slwrapper.results[0].to_AMaterial.results;
					var aMatTempArr = [];
					aMaterials.filter(function (item) {
						if (item.Active === "X") {
							item.LevelId = item.MatId;
							item.LevelDesc = item.MatDesc;
							aMatTempArr.push(item);
						}
					});
					// that.parentView.getModel("SlDetailModel").setProperty("/to_AMaterial", (aMatTempArr && aMatTempArr.length) ? aMatTempArr : []);
					that.parentView.getModel("oSolutionsModel").setProperty("/to_AMaterial", (aMatTempArr && aMatTempArr.length) ? aMatTempArr : []);

					//setting level data in edit
					var aLevelTempArr = [];
					var aTaxonomy = oActv.to_slwrapper.results[0].to_ATaxonomy.results;
					if (aTaxonomy.length) {
						that.parentView.getModel("SlDetailModel").setProperty("/Level2Key", aTaxonomy[0].L2Id);
						aTaxonomy.filter(function (item) {
							if (item.Active === "X") {
								var sLevelId = 'L' + item.LevelCount + 'Id';
								var sLevelDesc = 'L' + item.LevelCount + 'Desc';
								item.LevelId = item[sLevelId];
								item.LevelDesc = item[sLevelDesc];
								aLevelTempArr.push(item);
							}
						});
					}
					// that.parentView.getModel("SlDetailModel").setProperty("/to_ATaxonomy", (aLevelTempArr && aLevelTempArr.length) ? aLevelTempArr : []);
					that.parentView.getModel("oSolutionsModel").setProperty("/to_ATaxonomy", (aLevelTempArr && aLevelTempArr.length) ? aLevelTempArr : []);

					var oPayload = this.fnGetSolMatPayload(aLevelTempArr, aMatTempArr);
					this.parentView.getModel("SlDetailModel").setProperty("/to_ATaxonomy", oPayload[0]);
					this.parentView.getModel("SlDetailModel").setProperty("/to_AMaterial", oPayload[1]);
					//Below lines of code is to form oppo materials array, so it can be selected in popup
					// var isEditMode = oController.SlDetailModel.getProperty("/isEditMode");
					// if (isEditMode) {
					var oSolutionsModel = that.parentView.getModel("oSolutionsModel");
					var to_ATaxonomy = oSolutionsModel.getProperty("/to_ATaxonomy");
					var L4Map = oSolutionsModel.getProperty("/L4Map");
					to_ATaxonomy = this.parentController.fnGetL4sChildobject(to_ATaxonomy, L4Map);
					to_ATaxonomy = this.parentController.fnGetL5sParentobject(to_ATaxonomy);
					oSolutionsModel.setProperty("/to_ATaxonomy", to_ATaxonomy);
					var to_AMaterial = oSolutionsModel.getProperty("/to_AMaterial");
					var SolTokens = to_ATaxonomy.concat(to_AMaterial);
					var displayTokens = this.parentController.fnGetDisplayTokens(SolTokens);
					oSolutionsModel.setProperty("/DisplayTokens", displayTokens);
					oSolutionsModel.setProperty("/SolTokens", displayTokens);
					oSolutionsModel.setProperty("/oSolTempArr", $.extend(true, [], to_ATaxonomy));
					oSolutionsModel.setProperty("/oMatTempArr", $.extend(true, [], to_AMaterial));
					var OpportunityMaterials = oSolutionsModel.getProperty("/OpportunityMaterials");
					if (OpportunityMaterials) {
						this.parentController.fnFormOpportunityMaterials(OpportunityMaterials);
						this.parentController.fnFormOppoSolTempArr(to_ATaxonomy, OpportunityMaterials);
					}
					// }
				}
			}

			if (wrapperStartDate && wrapperEndDate) {
				that.parentView.getModel("SlDetailModel").setProperty("/RapidRegStartDate", wrapperStartDate);
				that.parentView.getModel("SlDetailModel").setProperty("/RapidRegEndDate", wrapperEndDate);
			} else {
				that.parentView.getModel("SlDetailModel").setProperty("/RapidRegStartDate", currentDate);
				that.parentView.getModel("SlDetailModel").setProperty("/RapidRegEndDate", currentDate);
			}
			that.parentView.getModel("SlDetailModel").setProperty("/RapidRegEditable", true);
			if (wrapperMethodId) {
				that.parentView.getModel("SlDetailModel").setProperty("/SelectedRapidRegMethod", wrapperMethodId);
			} else {
				that.parentView.getModel("SlDetailModel").setProperty("/SelectedRapidRegMethod", "V");
			}
			that.parentView.getModel("SlDetailModel").refresh(true);
			let actvTeamMembers = that.parentView.getModel("SlDetailModel").getProperty("/RapidRegActivityTeamMembers");
			let SlId = this.parentView.getModel("slDefaultModel").getProperty("/SuccessLine/SlId");
			if (actvTeamMembers) {
				for (var i = 0; i < actvTeamMembers.length; i++) {
					if (!this.selectedTeam.hasOwnProperty(actvTeamMembers[i].ID)) {
						let team = {
							"SlId": SlId,
							"Role": "ZOZOSOAD",
							"UserId": actvTeamMembers[i].ID,
							"FullName": actvTeamMembers[i].NAME,
							"PhoneNumber": actvTeamMembers[i].PhoneNumber,
							"MobileNumber": actvTeamMembers[i].MobileNumber,
							"EmailId": actvTeamMembers[i].EMAIL,
							"checked": true
						};
						this.selectedTeam[actvTeamMembers[i].ID] = team;
					}
				}
				that.alluserModel.setData(this.selectedTeam);
				that.alluserModel.refresh(true);
			}
			if (sCustomerAction === "CustomerAction") {
				let aTypeMasterData = that.parentView.getModel("masterData").getProperty("/RapidRegTypes");
				let aActDetTypes = [];
				if (aTypeMasterData.length) {
					aTypeMasterData.filter(function (type) {
						if (type.ActTypeId === acttypeid && type.OperationStatus) {
							aActDetTypes.push(type);
						}
					});
				}
				that.parentView.getModel("SlDetailModel").setProperty("/RapidRegTypes", aActDetTypes);
				if (!that.customerActionRapidRegDialog) {
					that.customerActionRapidRegDialog = sap.ui.xmlfragment(that.parentView.getId(),
						"com.presalescentral.successline.fragments.CustomerAction",
						that);
					that.parentView.addDependent(that.customerActionRapidRegDialog);
				}
				that.customerActionRapidRegDialog.openBy(oSource);
			} else {
				let aMethodMasterData = that.parentView.getModel("masterData").getProperty("/RapidRegMethods");
				let aActMethods = [];
				if (aMethodMasterData.length) {
					aMethodMasterData.filter(function (method) {
						if (method.acttypeid === acttypeid && method.operation_status) {
							aActMethods.push(method);
						}
					});
				}
				that.parentView.getModel("SlDetailModel").setProperty("/RapidRegMethods", aActMethods);
				if (formlayoutId) {
					that.parentView.getModel("slDefaultModel").setProperty("/ActivityDetails/frmlayout_id", formlayoutId);
				}

				if (!that.rapidRegDialog) {
					that.rapidRegDialog = sap.ui.xmlfragment(that.parentView.getId(),
						"com.presalescentral.successline.fragments.RapidRegistrationForm",
						that);
					that.parentView.addDependent(that.rapidRegDialog);
				}
				that.rapidRegDialog.openBy(oSource);
			}
			this.getDuplicateRegData();
		},

		initializeModelData: function () {
			var oMasterDataModel = this.parentView.getModel("masterData");
			var oSlDetailModel = this.parentView.getModel("SlDetailModel");
			var oSolutionsModel = this.parentView.getModel("oSolutionsModel");
			this.landscapeMap = {};

			oMasterDataModel.setProperty("/to_ALand", []);

			oSlDetailModel.setProperty("/RapidRegActivityTeamMembers", {});
			oSlDetailModel.setProperty("/to_AInitiative", []);
			oSlDetailModel.setProperty("/to_addopp", []);
			oSlDetailModel.setProperty("/to_ALand", []);
			oSlDetailModel.setProperty("/to_AFiles", []);
			oSlDetailModel.setProperty("/to_ASol", []);
			oSlDetailModel.setProperty("/to_AMaterial", []);
			oSlDetailModel.setProperty("/to_ATaxonomy", []);
			oSlDetailModel.setProperty("/RapidRegActivity/StatusId", "01");
			oSlDetailModel.setProperty("/CvjPhaseId", "");
			oSlDetailModel.setProperty("/DryRunDate", null);
			oSlDetailModel.setProperty("/DemoEnvCheckBoxSelected", false);

			oSolutionsModel.setProperty("/to_ASol", []);
			oSolutionsModel.setProperty("/to_AMaterial", []);
			oSolutionsModel.setProperty("/to_ATaxonomy", []);
			oSolutionsModel.setProperty("/SolTokens", []);
			oSolutionsModel.setProperty("/DisplayTokens", []);
			oSolutionsModel.setProperty("/oSolTempArr", []);
			oSolutionsModel.setProperty("/oMatTempArr", []);

			oSolutionsModel.refresh();
			oSlDetailModel.refresh();
			oMasterDataModel.refresh();

		},

		onValueHelpActivityLead: function (oEvent) {
			//Open Activity Lead Fragment
			let that = this;
			let oSource = oEvent.getSource();
			let oActv = that.parentView.getModel("SlDetailModel").getProperty("/RapidRegActivity");
			that.parentView.getModel("SlDetailModel").setProperty("/selectedActvt", oActv);
			//	that.parentController.onActivityLeadEdit(oActv);
			let SlSnro = that.parentView.getModel("slDefaultModel").getProperty("/SuccessLine/SlSnro");
			that.parentView.getModel("masterData").setProperty("/selectedSourceId", "001");
			let SlLeadRegionId = that.parentView.getModel("slDefaultModel").getProperty("/SuccessLine/SlLeadRegionId");
			that.parentView.getModel("masterData").setProperty("/selectedRegion", SlLeadRegionId);

			SLService.getFromSource(oActv.RoleMpngID, SlSnro, SlLeadRegionId, undefined, "", oActv.ActivityId, oActv.ActvtAsstdID).then((oData) => {
				that.parentView.getModel("slDefaultModel").setProperty("/SuccessLine/ActivityLeadList", oData.data.results);
				if (!that.sActvtLeadDialog) {
					that.sActvtLeadDialog = sap.ui.xmlfragment(that.parentView.getId(),
						"com.presalescentral.successline.fragments.ActivityLead",
						that);
					that.parentView.addDependent(that.sActvtLeadDialog);
				}
				let currentUser = that.parentView.getModel("user").getProperty("/UserId");
				let slLead = that.parentView.getModel("slDefaultModel").getProperty("/SuccessLine/SlLead");
				if (currentUser === slLead) {
					that.parentView.getModel("slDefaultModel").setProperty("/SuccessLine/selfAsignLead", false);

				} else {
					that.parentView.getModel("slDefaultModel").setProperty("/SuccessLine/selfAsignLead", true);
				}
				that.sActvtLeadDialog.openBy(oSource);
			});

		},
		onCloseActivityLeadDialog: function () {
			this.sActvtLeadDialog.close();
		},
		onSearchUser: function (oEvent) {
			let that = this;
			let query = oEvent.getParameter("query");
			SLService.getUsers(query).then((oData) => {
				that._handleLeadSearch(oData.data);
			});
		},

		_handleLeadSearch: function (oResponse) {
			let that = this;
			that.parentView.getModel("leadSearch").setData(oResponse.results);
			that.parentView.byId("LeadUserList").removeSelections();
			var oItems = that.parentView.byId("LeadUserList").getBinding('items');
			oItems.refresh();
		},

		handleLeadUserSelect: function (oEvent) {
			let oLead = oEvent.getParameter("listItem").getBindingContext("leadSearch").getObject();
			this.parentView.getModel("SlDetailModel").setProperty("/SlActvtLead", oLead.Id);
			this.parentView.getModel("SlDetailModel").setProperty("/SlActvtLeadName", oLead.Name);
			this.onCloseSLLeadDialog();

		},

		onCloseSLLeadDialog: function () {
			this.parentView.byId("userSearchSingle").setValue("");
			this.parentView.byId("LeadUserList").removeSelections();
			this.parentView.byId("LeadUserList").removeAllItems();
			this.parentView.byId("LeadUserList").refreshItems();
			this.parentView.getModel("SlDetailModel").setProperty("/RapidRegEditable", true);
			this.leadSearchDialog.close();
		},

		refreshRapidReg: function () {
			let that = this;
			let userId = that.parentView.getModel("user").getProperty("/UserId");
			let userName = that.parentView.getModel("user").getProperty("/UserName");
			that.parentView.getModel("SlDetailModel").setProperty("/SlActvtLeadName", userName);
			that.parentView.getModel("SlDetailModel").setProperty("/SlActvtLead", userId);
			let currentDate = new Date();
			that.parentView.getModel("SlDetailModel").setProperty("/RapidRegStartDate", currentDate);
			that.parentView.getModel("SlDetailModel").setProperty("/RapidRegEndDate", currentDate);
			that.selectedTeam = {};
			that.alluserModel.setData(that.selectedTeam);
			that.parentView.getModel("SlDetailModel").setProperty("/SelectedRapidRegMethod", "V");
			that.parentView.getModel("SlDetailModel").refresh(true);
		},

		onCancelRapidReg: function () {
			this.refreshRapidReg();
			this.appModel.setProperty("/isAppBusy", false);
			this.rapidRegDialog.close();
			this.parentView.getModel("slDefaultModel").setProperty("/SuccessLine/Menu", true);
			this.parentView.getModel("slDefaultModel").refresh(true);
			let sRiskDesc = this.parentView.getModel("slDefaultModel").getProperty("/ActivityDetails/RiskDesc");
			setTimeout(() => {
				$(".riskCmntTxt").css("border-left", "10px solid" + " " + sRiskDesc.toLowerCase());
			}, 100);
		},

		handleUserSearchMulti: function (oEvent) {
			let that = this;
			var oSource = oEvent.getSource();
			let opportunity = that.parentView.getModel("SlDetailModel").getProperty("/OpportunityId");
			if (opportunity) {
				that.parentView.getModel("formModel").setProperty("/selectedIndex", 0);
			} else {
				that.parentView.getModel("formModel").setProperty("/selectedIndex", 1);
			}
			if (!that.userSearchMultiDialog) {
				that.userSearchMultiDialog = sap.ui.xmlfragment(that.parentView.getId(),
					"com.presalescentral.successline.fragments.UserSearch",
					that);
				that.parentView.addDependent(that.userSearchMultiDialog);
			}
			that.userSearchMultiDialog.openBy(oSource);
		},

		onSearchMultiUserSAP: function (oEvent) {
			let query = oEvent.getParameter("query");
			if (query !== "")
				this.onSearch(query);
		},
		onSearchMultiUser: function (oEvent) {
			let aFilter = [];
			let query = oEvent.getParameter("query");
			if (query) {
				aFilter.push(new Filter("FullName", FilterOperator.Contains, query));
			}
			let oList = this.parentView.byId("UserListMulti");
			let oBinding = oList.getBinding("items");
			oBinding.filter(aFilter);
		},
		onSearch: function (query) {
			let that = this;
			SLService.getUsers(query).then((oData) => {
				that._handleUserSearch(oData.data);
			});
			/*var oParameters = {
				urlParameters: {
					search: query
				}
			};
				this.slModel.read("/YC_SL_USERSEARCH", oParameters, {
				success: function (oData) {
					that._handleLeadSearch(oData.data);
				},
				error: function (oResponse) {
					
				}
			});*/
		},
		_handleUserSearch: function (oData) {
			this.parentView.getModel("userSearch").setData(oData.results);
			let data = this.parentView.getModel("userSearch").getData();
			for (let i = 0; i < data.length; i++) {
				data[i].checked = false;
			}
			this.parentView.byId("UserListMultiSAP").getBinding("items").refresh();
		},
		handleTeamSelect: function (oEvent) {
			let selectedUser;
			selectedUser = oEvent.getParameter("listItem").getBindingContext("formModel").getObject();
			if (oEvent.getParameter("selected")) {
				if (!this.selectedTeam.hasOwnProperty(selectedUser.UserId)) {
					selectedUser.Role = "ZOZOSOAD";
					this.selectedTeam[selectedUser.UserId] = selectedUser;
				} else {
					MessageToast.show(selectedUser.FullName + " Already present.");
				}
			} else {
				delete this.selectedTeam[selectedUser.UserId];
			}
		},

		onTokenUpdate: function (oEvent) {
			let removedtokens = oEvent.getParameters().removedTokens.length;
			if (removedtokens > 0) {
				let removedTokenKey = oEvent.getParameters().removedTokens[0].getKey();
				let i = removedTokenKey;
				delete this.selectedTeam[i];
			}
		},

		handleTeamSelectSAP: function (oEvent) {
			let SlId = this.parentView.getModel("slDefaultModel").getProperty("/SuccessLine/SlId");
			let selectedUser;
			let bindingContext = oEvent.getParameter("listItem").getBindingContext("userSearch");
			selectedUser = bindingContext.getObject();
			if (oEvent.getParameter("selected")) {
				if (!this.selectedTeam.hasOwnProperty(selectedUser.Id)) {
					let team = {
						"SlId": SlId,
						"Role": "ZOZOSOAD",
						"UserId": selectedUser.Id,
						"FullName": selectedUser.Name,
						"PhoneNumber": selectedUser.PhoneNo,
						"MobileNumber": selectedUser.PhoneNo,
						"EmailId": selectedUser.Email,
						"checked": true,
						"CRMRoleId": selectedUser.CrmRoleId,
						"CRMRoleDesc": selectedUser.CrmRoleDesc
					};
					this.selectedTeam[selectedUser.Id] = team;
				} else {
					MessageToast.show(selectedUser.Name + " Already present.");
				}
			} else {
				delete this.selectedTeam[selectedUser.Id];
			}
		},

		handleUserSelectMulti: function () {
			this.alluserModel.setData(this.selectedTeam);
			this.onCloseUserSelectDialog();
		},
		onCloseUserSelectDialog: function () {
			this.parentView.byId("userSearchMulti").setValue("");
			this.parentView.byId("userSearchMultiSAP").setValue("");
			this.parentView.byId("UserListMulti").removeSelections();
			this.parentView.byId("UserListMultiSAP").removeSelections();
			//Update list
			let query = "";
			let aFilter = [];
			aFilter.push(new Filter("FullName", FilterOperator.Contains, query));
			let aSAPFilter = [];
			aSAPFilter.push(new Filter("Name", FilterOperator.Contains, query));
			let oList = this.parentView.byId("UserListMulti");
			let oSAPList = this.parentView.byId("UserListMultiSAP");
			let oBinding = oList.getBinding("items");
			let oSAPBinding = oSAPList.getBinding("items");
			oBinding.filter(aFilter);
			oSAPBinding.filter(aSAPFilter);
			this.parentView.byId("UserListMultiSAP").removeAllItems();
			this.parentView.byId("idIconTabBarNoIcons").setSelectedKey("info");
			this.alluserModel.refresh(true);
			this.userSearchMultiDialog.close();
		},
		handleFullRegistration: async function (oEvent) {
			let oModel = this.parentView.getModel("SlDetailModel");
			let ActivityTypeId = oModel.getProperty("/RapidRegActivity/ActivityId");
			let SLActGUID = oModel.getProperty("/RapidRegActivity/ActGuid");
			let roleID = this.parentView.getModel("slDefaultModel").getProperty("/SuccessLine/ActivityRole");
			let sActLead = oModel.getProperty("/RapidRegActivity/ActLeadId");
			let bSlLeadAccess = this.parentView.getModel("slDefaultModel").getProperty("/bSlLeadAccess");
			let RegisteredActId = oModel.getProperty("/RapidRegActivity/RegisteredActId");
			//URGENT BUG: MSL lead unable to register activities #143
			let sRegAccess = oModel.getProperty("/RapidRegActivity/RegistrationAccess");
			if (sActLead) {
				roleID = oModel.getProperty("/RapidRegActivity/RoleMpngID");
			} else if (!sRegAccess && bSlLeadAccess) {
				roleID = "067";
			}
			const oRapidRegPayloadData = {
				"ActivityGuid": SLActGUID,
				"ActivityId": RegisteredActId ? (parseInt(RegisteredActId, 10)).toString() : "",
				"ActivitySetId": "",
				"ActivitySetStatus": "",
				"ActivitySetdescription": "",
				"ActivityTypeDescription": "",
				"ActivityTypeId": ActivityTypeId,
				"ActvtAsstdID": "",
				"ActvtStatus": "",
				"Archived": false,
				"Authorized": "",
				"CanceledBy": "",
				"CanceledByName": "",
				"CancledOn": "",
				"ChildFrmLayoutId": "",
				"CreateDate": "",
				"CvjPhaseDesc": "",
				"CvjPhaseId": oModel.getProperty("/CvjPhaseId"),
				"DryRunDate": oModel.getProperty("/DryRunDate"),
				"EndDate": oModel.getProperty("/RapidRegEndDate"),
				"FormLayoutId": oModel.getProperty("/RapidRegActivity/frmlayout_id"),
				"GlobalUltimateID": this.parentView.getModel("slDefaultModel").getProperty("/SuccessLine/AccountId"),
				"OpportunityNumber": oModel.getProperty("/OpportunityId"),
				"RoleMpngID": roleID,
				"SLActGUID": SLActGUID,
				"SlSnro": oModel.getProperty("/RapidRegActivity/SlSnro"),
				"SlStatusId": "",
				"StartDate": oModel.getProperty("/RapidRegStartDate"),
				"Status": oModel.getProperty("/RapidRegActivity/StatusId"),
				"StatusChangedAt": oModel.getProperty("/RapidRegActivity/CompDate"),
				"to_AAccnt": [],
				"to_AAddOpp": oModel.getProperty("/to_addopp"),
				"to_AFiles": oModel.getProperty("/to_AFiles"),
				"to_AInitiative": oModel.getProperty("/to_AInitiative"),
				"to_ALand": oModel.getProperty("/to_ALand"),
				"to_AMaterial": oModel.getProperty("/to_AMaterial"),
				"to_AOpportunity": [],
				"to_ASol": oModel.getProperty("/to_ASol"),
				"to_ATaxonomy": oModel.getProperty("/to_ATaxonomy"),
			};
			var demoEnvCheckbox = this.parentView.byId("demoEnvironmentCheckBox");
			if (demoEnvCheckbox) {
				oRapidRegPayloadData.DemoEnvironmentCheckBox = demoEnvCheckbox.getSelected();
			}
			if (oRapidRegPayloadData) {
				let oPayloadData = {
					"ActivityGuid": SLActGUID,
					"DraftJson": JSON.stringify(oRapidRegPayloadData)
				};
				await SLService.copyRapidRegData(oPayloadData);
			}
			this.parentView.getModel("slDefaultModel").setProperty("/SuccessLine/Menu", true);
			this.rapidRegDialog.close();
			// let oParam = {};
			let sParams = "";
			if (RegisteredActId === "") {
				// oParam = {
				// 	"ActivityTypeID": ActivityTypeId,
				// 	"SlGuid": SLActGUID,
				// 	"RoleID": roleID
				// };
				// this.parentController.navigatetoActivityForm(oParam);
				sParams = `ActivityTypeID=${ActivityTypeId}&SlGuid=${SLActGUID}&RoleID=${roleID}`;
			} else {
				// oParam = {
				// 	"ActivityID": parseInt(RegisteredActId)
				// };
				// this.parentController.navigatetoActivityForm(oParam);
				sParams = `IsRapidRegistration=true&ActivityID=${parseInt(RegisteredActId)}&ActGUID=${SLActGUID}`;
			}

			let sUrl = `#pcactivityform-app`;
			sUrl = `${sUrl}?${sParams}`;
			sap.m.URLHelper.redirect(sUrl, true);
		},

		navigatetoActivityForm: function (oParam) {
			let oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
			let hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "pcactivityform",
					action: "app"
				},
				params: oParam
			})) || ""; // generate the Hash to display a Supplier
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		},

		onSaveRapidReg: function (oEvent, sCustomerAction) {
			let that = this;
			let oModel = this.parentView.getModel("SlDetailModel");
			that.parentView.getModel("SlDetailModel").setProperty("/RapidRegEditable", false);
			let ActivityGuid, ActivityLead, StartDate, EndDate, RiskAssessId, cvjPhaseId;
			let selectedUsers = [];
			ActivityLead = oModel.getProperty("/SlActvtLead");
			StartDate = oModel.getProperty("/RapidRegStartDate");
			EndDate = oModel.getProperty("/RapidRegEndDate");
			cvjPhaseId = oModel.getProperty("/CvjPhaseId");
			let aTeam = [];
			for (let user in that.selectedTeam) {
				selectedUsers.push(that.selectedTeam[user]);
			}
			if (selectedUsers.length > 0) {
				selectedUsers.forEach(function (Saveteam) {
					let team = {
						"ActivityGuid": ActivityGuid,
						"ID": Saveteam.UserId,
						"ROLE": Saveteam.Role,
						"NAME": Saveteam.FullName,
						"EMAIL": Saveteam.EmailId,
						"MobileNumber": Saveteam.MobileNumber,
						"PhoneNumber": Saveteam.PhoneNumber
					};
					aTeam.push(team);
				});
			}
			var aSolutions = this.parentView.getModel("SlDetailModel").getProperty("/to_ATaxonomy");
			var formLayoutId = this.parentView.getModel("masterData").getProperty("/FormLayoutId");
			var isLandscapeVisible = (formLayoutId === "00001" || formLayoutId === "00024") ? true : false;
			var isSolutionsVisible = this.parentView.getModel("masterData").getProperty("/SelectedLayout/AdditionalSolutions/Visible");
			var isCvjPhaseVisible = this.parentView.getModel("masterData").getProperty("/SelectedLayout/CVJPhase/Visible");
			var demoEnvCheckbox = this.parentView.byId("demoEnvironmentCheckBox");
			var aLandscape = this.parentView.getModel("SlDetailModel").getProperty("/to_ALand");
			if (!StartDate || !EndDate || (isSolutionsVisible && !aSolutions.length) || (isCvjPhaseVisible && !cvjPhaseId)) {
				MessageToast.show("Please fill all the mandatory details to proceed.");
				that.parentView.getModel("SlDetailModel").setProperty("/RapidRegEditable", true);
				return;
			} else if (isLandscapeVisible && !(demoEnvCheckbox.getSelected() || aLandscape.length)) {
				MessageToast.show("Please Select the Checkbox or Landscapes to proceed");
				that.parentView.getModel("SlDetailModel").setProperty("/RapidRegEditable", true);
				return;
			}
			this.SlActivitySaveObj = {
				aTeam: aTeam,
				sCustomerAction: sCustomerAction
			};
			this.fnGetFindOppActUsers(oEvent);
		},

		//Function to save activity after adding users to VAT team
		fnSaveActRapidReg: function (isSuccess) {
			let that = this;
			let ActivityGuid, RiskAssessId;
			let oModel = this.parentView.getModel("SlDetailModel");
			//If there is RegisteredActId, then directly send the payload (no need make an empty payload call)
			let SlActivitySaveObj = that.SlActivitySaveObj;
			let RegisteredActId = that.parentView.getModel("SlDetailModel").getProperty("/RapidRegActivity/RegisteredActId");
			if (RegisteredActId) {
				RegisteredActId = parseInt(RegisteredActId);
				that.appModel.setProperty("/isAppBusy", true);
				SLService.getRapidRegistration(RegisteredActId).then((oResponse) => {
					let oActvtObj = oResponse.data.results[0];
					ActivityGuid = oResponse.data.results[0].ActivityGuid;
					that._saveRapidReg(false, SlActivitySaveObj.sCustomerAction, SlActivitySaveObj.aTeam, oActvtObj.ActivityGuid, undefined,
						RegisteredActId, oActvtObj);
				});
			} else {
				that.appModel.setProperty("/isAppBusy", true);
				let oActTypeId = {
					"ActivityTypeId": oModel.getProperty("/RapidRegActivity/ActivityId")
				};
				SLService.postRapidRegistration(oActTypeId).then((oResponse) => {
					//var data = oResponse.data;
					ActivityGuid = oResponse.data.ActivityGuid;
					RiskAssessId = oResponse.data.RiskAssessId;
					that._saveRapidReg(false, SlActivitySaveObj.sCustomerAction, SlActivitySaveObj.aTeam, ActivityGuid, RiskAssessId);
				});
			}
		},

		_saveRapidReg: function (isEditRisk, sCustomerAction, aTeam, sActivityGuid, sRiskAssessId, sRegisteredActId, oActvtObj) {
			let that = this;
			let oModel = this.parentView.getModel("SlDetailModel");
			if (isEditRisk) {
				oModel = this.parentView.getModel("slDefaultModel");
			}
			let ActivityGuid, ActivityId, SlId, SlSnro, ActivityLead, GlobalUltimateID, StartDate, EndDate, Method, Requestor,
				OpportunityNumber, ActvtAsstdID, RiskAssessId, ActivityTypeId, SLActGUID;
			ActivityLead = isEditRisk ? oModel.getProperty("/ActivityDetails/ActivityLeadId") : oModel.getProperty("/SlActvtLead");
			StartDate = isEditRisk ? oModel.getProperty("/ActivityDetails/StartDate") : oModel.getProperty("/RapidRegStartDate");
			EndDate = isEditRisk ? oModel.getProperty("/ActivityDetails/EndDate") : oModel.getProperty("/RapidRegEndDate");
			let ActLead = isEditRisk ? oModel.getProperty("/ActivityDetails/ActLead") : oModel.getProperty("/SlActvtLeadName");
			ActivityGuid = sActivityGuid;
			if (sRiskAssessId) {
				RiskAssessId = sRiskAssessId;
			} else {
				RiskAssessId = isEditRisk ? oModel.getProperty("/ActivityDetails/RiskId") : oModel.getProperty("/RapidRegActivity/RiskId");
			}
			let RegisteredActId = " ";
			if (sRegisteredActId) {
				RegisteredActId = isEditRisk ? oModel.getProperty("/ActivityDetails/RegisteredActId") : sRegisteredActId;
			}
			ActivityId = isEditRisk ? oModel.getProperty("/ActivityDetails/ActivityId") : oModel.getProperty("/RapidRegActivity/ActivityId");
			Requestor = that.parentView.getModel("user").getProperty("/UserId");
			Method = isEditRisk ? oModel.getProperty("/ActivityDetails/to_slwrapper/results/0/MethodId") : oModel.getProperty(
				"/SelectedRapidRegMethod");
			OpportunityNumber = that.parentView.getModel("slDefaultModel").getProperty("/SuccessLine/OpportunityId");
			GlobalUltimateID = that.parentView.getModel("slDefaultModel").getProperty("/SuccessLine/AccountId");
			SlSnro = that.parentView.getModel("slDefaultModel").getProperty("/SuccessLine/SlSnro");
			SlId = that.parentView.getModel("slDefaultModel").getProperty("/SuccessLine/SlId");
			ActivityTypeId = isEditRisk ? oModel.getProperty("/ActivityDetails/ActivityId") : oModel.getProperty("/RapidRegActivity/ActivityId");
			SLActGUID = isEditRisk ? oModel.getProperty("/ActivityDetails/ActGuid") : oModel.getProperty("/RapidRegActivity/ActGuid");
			let RoleMpngID = isEditRisk ? oModel.getProperty("/ActivityDetails/RoleMpngID") : oModel.getProperty("/RapidRegActivity/RoleMpngID");
			let roleID = this.parentView.getModel("slDefaultModel").getProperty("/SuccessLine/ActivityRole");
			let sRegAccess = isEditRisk ? oModel.getProperty("/ActivityDetails/RegistrationAccess") : oModel.getProperty(
				"/RapidRegActivity/RegistrationAccess");
			let bSlLeadAccess = this.parentView.getModel("slDefaultModel").getProperty("/bSlLeadAccess");
			//URGENT BUG: MSL lead unable to register activities #143
			if (RoleMpngID === "") {
				if (!sRegAccess && bSlLeadAccess) {
					RoleMpngID = "067";
				} else {
					RoleMpngID = roleID;
				}
			}
			let frmlayout_id = isEditRisk ? oModel.getProperty("/ActivityDetails/frmlayout_id") : oModel.getProperty(
				"/RapidRegActivity/frmlayout_id");
			if (StartDate !== null) {
				StartDate = new Date(StartDate);
				var startyear = StartDate.getFullYear();
				var startmonth = StartDate.getMonth();
				var startday = StartDate.getDate();
				var value2Date = startyear + "-" + startmonth + "-" + startday + "T00:00:00";
				//	StartDate = value2Date;
				StartDate = new Date(startyear, startmonth, startday, "09", "00", "00", "0");
			}
			if (EndDate !== null) {
				EndDate = new Date(EndDate);
				var year = EndDate.getFullYear();
				var month = EndDate.getMonth();
				var day = EndDate.getDate();
				var value1Date = year + "-" + month + "-" + day + "T00:00:00";
				//EndDate = value1Date;
				EndDate = new Date(year, month, day, "17", "00", "00", "0");
			}
			if (StartDate > EndDate) {
				let msg = "Start date cannot be greater than end date";
				MessageToast.show(msg, {
					duration: 2000
				});
				that.parentView.getModel("SlDetailModel").setProperty("/RapidRegEditable", true);
				that.appModel.setProperty("/isAppBusy", false);
				return;
			}
			if (OpportunityNumber) {
				ActvtAsstdID = "502";
			} else {
				ActvtAsstdID = "501";
			}
			let oDetailModel = this.parentView.getModel("SlDetailModel");
			let oppData = {
				"OPPT_ID": OpportunityNumber,
				"DESCRIPTION": oDetailModel.getProperty("/SelectedOpportunity/opportunity/DESCRIPTION"),
				"profitcenter": "",
				"region": "",
				"sub_region": "",
				"gtm_iss": "",
				"GTM_ISS_DESC": "",
				"mastercodeid": oDetailModel.getProperty("/SelectedOpportunity/opportunity/INDUSTRY_MASTERCODE"),
				"MASTERCODE_DESC": oDetailModel.getProperty("/SelectedOpportunity/opportunity/INDUSTRY_MASTERCODE_TEXT"),
				"accountid": "",
				"ACCOUNT_NAME": oDetailModel.getProperty("/SelectedOpportunity/ACCOUNT_NAME"),
				"process_type": "",
				"PRECESS_TYPE_DESC": "",
				"dist_channel": "",
				"DIST_CHANNEL_DESC": "",
				"OPP_LEAD": "",
				"OPP_LEAD_NAME": "",
				"OWNER": oDetailModel.getProperty("/SelectedOpportunity/opportunity/OWNER"),
				"OWNER_NAME": oDetailModel.getProperty("/SelectedOpportunity/opportunity/OWNER_NAME"),
				"EXPECTED_VALUE": "",
				"currency": "",
				"SALES_ORG": "",
				"SALES_ORG_DESC": "",
				"CURR_PHASE": oDetailModel.getProperty("/SelectedOpportunity/opportunity/CURR_PHASE"),
				"PHASE_DESC": "",
				"STATUS": oDetailModel.getProperty("/SelectedOpportunity/opportunity/STATUS"),
				"STATUS_DESC": "",
				"net_new_deal": ""
			};
			let accData = {
				"accountid": GlobalUltimateID,
				"accountname": oDetailModel.getProperty("/SelectedOpportunity/ACCOUNT_NAME"),
				"iss": oDetailModel.getProperty("/SelectedOpportunity/ISS"),
				"iac": oDetailModel.getProperty("/SelectedOpportunity/Internal_Account_Classification"),
				"industry": oDetailModel.getProperty("/SelectedOpportunity/INDUSTRY"),
				"ActAccountStatus": oDetailModel.getProperty("/SelectedOpportunity/Active_Account_Status"),
				"RegBuyClass": oDetailModel.getProperty("/SelectedOpportunity/Regional_Buying_Classification"),
				"RegBuyLifeCycle": oDetailModel.getProperty("/SelectedOpportunity/Regional_Buying_Lifecycle"),
				"IMS": oDetailModel.getProperty("/SelectedOpportunity/IMS"),
				"ERPID": oDetailModel.getProperty("/SelectedOpportunity/ERPID"),
				"AccountOwner": oDetailModel.getProperty("/SelectedOpportunity/OWNER")
			};
			let opp = [],
				acc = [];
			opp.push(oppData);
			acc.push(accData);
			let type = [];
			if (sCustomerAction === "CustomerAction") {
				let slCreationDate = that.parentView.getModel("slDefaultModel").getProperty("/SuccessLine/CreatedAt");
				StartDate = slCreationDate;
				Method = "";
				let sType = {
					"ActivityGuid": ActivityGuid,
					"TypeId": "",
					"Description": "",
					"OperationStatus": false
				};
				let selectedTypeId = that.parentView.getModel("SlDetailModel").getProperty("/SelectedRapidRegType");
				let RapidRegTypes = that.parentView.getModel("SlDetailModel").getProperty("/RapidRegTypes");
				RapidRegTypes.filter((item) => {
					if (item.TypeId === selectedTypeId) {
						sType.TypeId = item.TypeId;
						sType.Description = item.Description;
						sType.OperationStatus = item.OperationStatus;
					}
				});
				type.push(sType);
				that.updateNotes();
			}
			aTeam.filter(function (obj) {
				obj.ActivityGuid = ActivityGuid;
			});
			//Initiatives
			var aInitiatives = [];
			var aSelections = this.parentView.byId("slInitiativeSelect").getSelectedInitiatives();
			aSelections.filter(function (item) {
				var oInitiative = {
					"ActivityGuid": ActivityGuid,
					"InitiativeId": item.InitiativeId
				};
				aInitiatives.push(oInitiative);
			});

			//Landscapes
			var aLandscapeSelections = this.parentView.getModel("SlDetailModel").getProperty("/to_ALand");
			aLandscapeSelections.filter(function (item) {
				item.ActivityGuid = ActivityGuid;
			});

			var aTaxonomy = this.parentView.getModel("SlDetailModel").getProperty("/to_ATaxonomy");
			aTaxonomy.filter(function (item) {
				item.ActivityGuid = ActivityGuid;
				delete item.LevelId;
				delete item.LevelDesc;
			});

			var aMaterial = this.parentView.getModel("SlDetailModel").getProperty("/to_AMaterial");
			aMaterial.filter(function (item) {
				item.ActivityGuid = ActivityGuid;
				delete item.LevelId;
				delete item.LevelDesc;
			});

			//Assets and document links
			var aFiles = this.parentView.getModel("SlDetailModel").getProperty("/to_AFiles");
			aFiles.filter(function (oFile) {
				delete oFile.UrlState;
				delete oFile.FileNameState;
				delete oFile.IsAddBtnVisible;
				delete oFile.IsDelBtnVisible;
			});

			//additional opportunities save
			var aAddOpp = [];
			var aAddOppSelections = this.parentView.getModel("SlDetailModel").getProperty("/to_addopp");
			if (aAddOppSelections.length) {
				aAddOppSelections.filter(function (object) {
					var opptObj = {
						"OpportunityNo": object.OpportunityNo,
						"ActivityGuid": ActivityGuid
					};
					aAddOpp.push(opptObj);
				});
			}

			let oEntry = {
				"ActivityGuid": ActivityGuid,
				"ActivityId": RegisteredActId ? RegisteredActId.toString() : RegisteredActId,
				"ActivityLead": ActivityLead,
				"StartDate": StartDate,
				"EndDate": EndDate,
				// "MethodId": Method,
				"OpportunityNumber": OpportunityNumber,
				"GlobalUltimateID": GlobalUltimateID,
				"SlSnro": SlSnro,
				"SLActGUID": SLActGUID,
				"Requestor": Requestor,
				"RiskAssessId": RiskAssessId,
				"RoleMpngID": RoleMpngID,
				"ActvtAsstdID": ActvtAsstdID,
				"ActivityTypeId": ActivityTypeId,
				"FormLayoutId": frmlayout_id,
				"Status": this.parentView.getModel("SlDetailModel").getProperty("/RapidRegActivity/StatusId"),
				"CvjPhaseId": this.parentView.getModel("SlDetailModel").getProperty("/CvjPhaseId"),
				"DryRunDate": this.parentView.getModel("SlDetailModel").getProperty("/DryRunDate"),
				"StatusChangedAt": this.parentView.getModel("SlDetailModel").getProperty("/RapidRegActivity/CompDate"),
				"to_ATeam": aTeam,
				"to_AAccnt": acc,
				"to_AOpportunity": opp,
				"to_ADetType": isEditRisk ? oModel.getProperty("/ActivityDetails/to_slwrapper/results/0/to_ADetType/results") : type,
				"to_AInitiative": aInitiatives,
				"to_ALand": aLandscapeSelections,
				"to_AAddOpp": aAddOpp,
				"to_AFiles": aFiles,
				"to_ASol": [],
				"to_AMaterial": aMaterial,
				"to_ATaxonomy": aTaxonomy
			};

			if (oActvtObj) {
				oEntry.AccountExecutive = oActvtObj.AccountExecutive;
				oEntry.AccountExecutiveEmailId = oActvtObj.AccountExecutiveEmailId;
				oEntry.AccountExecutiveName = oActvtObj.AccountExecutiveName;
				oEntry.ActivityLeadEmailId = oActvtObj.ActivityLeadEmailId;
				oEntry.ActivityLeadName = oActvtObj.ActivityLeadName;
				oEntry.ActivitySetId = oActvtObj.ActivitySetId;
				oEntry.ActivitySetdescription = oActvtObj.ActivitySetdescription;
				oEntry.ActivitySupport = oActvtObj.ActivitySupport;
				oEntry.ActivityTypeDescription = oActvtObj.ActivityTypeDescription;
				oEntry.ActvtName = oActvtObj.ActvtName;
				oEntry.ActvtRegion = oActvtObj.ActvtRegion;
				oEntry.Archived = oActvtObj.Archived;
				oEntry.Authorized = oActvtObj.Authorized;
				oEntry.BPSMEAlign = oActvtObj.BPSMEAlign;
				oEntry.CanceledBy = oActvtObj.CanceledBy;
				oEntry.CanceledByName = oActvtObj.CanceledByName;
				oEntry.CancledOn = oActvtObj.CancledOn;
				oEntry.CntryID = oActvtObj.CntryID;
				oEntry.ConsPS = oActvtObj.ConsPS;
				oEntry.CreateDate = oActvtObj.CreateDate;
				oEntry.CurrentSize = oActvtObj.CurrentSize;
				oEntry.DcId = oActvtObj.DcId;
				oEntry.DealType = oActvtObj.DealType;
				oEntry.DeliveryTeamId = oActvtObj.DeliveryTeamId;
				oEntry.Description = oActvtObj.Description;
				oEntry.DiscoveryCompleted = oActvtObj.DiscoveryCompleted;
				// oEntry.DryRunDate = oActvtObj.DryRunDate;
				oEntry.EngLevel = oActvtObj.EngLevel;
				oEntry.ExistingClient = oActvtObj.ExistingClient;
				oEntry.HostTypeId = oActvtObj.HostTypeId;
				oEntry.ImpactID = oActvtObj.ImpactID;
				oEntry.IncrPipeline = oActvtObj.IncrPipeline;
				oEntry.Industry = oActvtObj.Industry;
				oEntry.LastChangedAt = new Date(oActvtObj.LastChangedAt);
				oEntry.MainSolutionId = oActvtObj.MainSolutionId;
				oEntry.MeetingInvitees = oActvtObj.MeetingInvitees;
				oEntry.NmbrOfAttnds = oActvtObj.NmbrOfAttnds;
				oEntry.ProjectId = oActvtObj.ProjectId;
				oEntry.RecommendedSize = oActvtObj.RecommendedSize;
				oEntry.Region = oActvtObj.Region;
				oEntry.RequestedDelivery = oActvtObj.RequestedDelivery;
				oEntry.RequestorName = oActvtObj.RequestorName;
				oEntry.RiskColorCode = oActvtObj.RiskColorCode;
				oEntry.RiskComment = oActvtObj.RiskComment ? oActvtObj.RiskComment : oModel.getProperty(
					"/ActivityDetails/to_slwrapper/results/0/RiskComment");
				oEntry.SalesLobId = oActvtObj.SalesLobId;
				oEntry.ScopeId = oActvtObj.ScopeId;
				oEntry.SlName = oActvtObj.SlName;
				// oEntry.Status = oActvtObj.Status;
				oEntry.SubRegion = oActvtObj.SubRegion;
				oEntry.SuppChainOfSuccId = oActvtObj.SuppChainOfSuccId;
				oEntry.SurveyRecpt = oActvtObj.SurveyRecpt;
				oEntry.SurveyRecptName = oActvtObj.SurveyRecptName;
				oEntry.TargetValue = oActvtObj.TargetValue;
				oEntry.TopDealFlag = oActvtObj.TopDealFlag;
				oEntry.UseCaseId = oActvtObj.UseCaseId;
				oEntry.VirtualStudioId = oActvtObj.VirtualStudioId;
				oEntry.expiredActivity = oActvtObj.expiredActivity;
			}
			that.parentView.getModel("SlDetailModel").setProperty("/sTeamActivityGuid", sActivityGuid);
			that.isEditRisk = isEditRisk;
			SLService.postRapidRegistration(oEntry).then((oData) => {
				let OpportunityId = that.parentView.getModel("slDefaultModel").getProperty("/SuccessLine/OpportunityId");
				if (OpportunityId && that.IsVATAccessSericeTriggered) {
					var successfn = function (oResponse, isError) {
						that.fnSetSlRapidRegData(oResponse);
						that.fnTriggerTimeEntry(oData);
						if (isError) {
							MessageToast.show("Unable to update Opportunity team members to Melody");
						}
					};
					let SlSnro = oData.data.SlSnro;
					let ActivityId = oData.data.ActivityId;
					that.parentController.opportunityComponentInstance._oOpportunityHelper.fnGetOpportunityOwner(ActivityId, SlSnro, oData,
						successfn);
					that.parentController._getOppTeam();
				} else {
					that.fnSetSlRapidRegData(oData);
					that.fnTriggerTimeEntry(oData);
				}
			});
		},

		//Function to set dat after rapid registration activity save
		fnSetSlRapidRegData: function (oData) {
			var that = this;
			that.appModel.setProperty("/isRiskBusy", false);
			let oDefaultModel = that.parentView.getModel("slDefaultModel");
			// let sActivityId = oData.ActivityId || oData.data.ActivityId;
			if (that.isEditRisk) {
				let sRiskDesc = "";
				let sRiskColor = "";
				if (oData.data.RiskAssessId === "01") {
					sRiskDesc = "Red";
					sRiskColor = "#FF0000";
				} else if (oData.data.RiskAssessId === "02") {
					sRiskDesc = "Yellow";
					sRiskColor = "#FFFF00";
				} else {
					sRiskDesc = "Green";
					sRiskColor = "#215E21";
				}
				oDefaultModel.setProperty("/ActivityDetails/RiskDesc", sRiskDesc);
				oDefaultModel.setProperty("/ActivityDetails/RiskColor", sRiskColor);
				oDefaultModel.setProperty("/ActivityDetails/isRiskEditable", false);
				that.parentController.oStoreCurrentActvt.RiskId = oData.data.RiskAssessId;
				that.parentController.oStoreRiskCmnt.RiskComment = oData.data.RiskComment;
				oDefaultModel.setProperty("/SuccessLine/Risk", oData.data.SlRisk);
				let oTable = that.parentController.byId("actvtRegTbl");
				setTimeout(() => {
					$(".riskCmntTxt").css("border-left", "10px solid" + " " + sRiskDesc.toLowerCase());
				}, 100);
				let rowIndex = oTable.getSelectedIndex();
				let oAggregation = oTable.getRows()[rowIndex].getAggregation("_settings");
				if (oAggregation) {
					sRiskColor = (oData.data.RiskAssessId === "03" ? "" : sRiskColor);
					oAggregation.setColor(sRiskColor);
				}
				MessageToast.show("Risk Updated successfully", {
					duration: 2000
				});
			} else {
				// MessageToast.show("Activity " + sActivityId + " Registered successfully", {
				// 	duration: 2000
				// });
				let oActv = that.parentView.getModel("SlDetailModel").getProperty("/RapidRegActivity");
				let key = that.parentView.getModel("SlDetailModel").getProperty("/RapidRegActivityStatus");
				that.appModel.setProperty("/isAppBusy", false);
				let selectData = this.selectedTeam;
				let oRecivedData = oData || oData.data;
				this.parentView.getModel("slRapidTempModel").setProperty("/selectedTeam", selectData);
				that.parentView.getModel("SlDetailModel").setProperty("/RegistrationActvtVisible", true);
				that.parentView.getModel("slDefaultModel").refresh();
				that.parentView.getModel("SlDetailModel").refresh();
				that.parentView.getModel("activityMenuModel").refresh();
				that.getActivity(oRecivedData, oActv, false);
				// disablled the complete refresh of the application by comenting the below line of code
				//	that.parentController.getActivity(key, oActv, false);
				if (that.SlActivitySaveObj?.sCustomerAction === "CustomerAction") {
					that.onCancelCustomerActionRapidReg();
					return;
				} else {
					that.refreshRapidReg();
					// that.rapidRegDialog.close();
					return;
				}
			}
		},

		/**
		 *Function to fetch the current registered activity data
		 * @{param} Parameters carry the data recived from the post call made for registration, Activity details, and flag for registartion or completion
		 */
		getActivity: function (key, obj, bCompleted) {
			let that = this;
			let data;
			let registeredData = key;
			if (!obj) {
				obj = { "ActGuid": key.SLActGUID};
			}
			SLService.getActivity(obj).then((sData) => {
				data = sData.data.results[0];
				that.getSelectActivity(data, registeredData, bCompleted);
			});
		},
		/**
		 * Function to update the local method and to avoid the get call for all the services.
		 * @Params oData, oRecivedData, bCompActvt these parameters caary the nesaary data that are required to be updated
		 * This function also takes cares of recusrsive call to update the data.
		 */
		getSelectActivity: function (oData, oRecivedData, bCompActvt) {
			let that = this;
			let oSlDetailModel = this.parentView.getModel("SlDetailModel");
			let selectedTeam = this.parentView.getModel("slRapidTempModel").getProperty("/selectedTeam");
			let oModelSl = this.parentView.getModel("slDefaultModel");
			let oActivityDetail = oModelSl.getData().ActivityDetails;
			let oUserModel = this.parentView.getModel("user").getData();
			let defaultModelPhases = oModelSl.getData().SuccessLineHierarchy.Phases;
			let defaultModelSlPhases = oModelSl.getData().PhaseDetails;
			let oPresentationDetail = oModelSl.getData().presentationData;
			let aMethodDetails = oSlDetailModel.getData().RapidRegMethods;
			let oActivityMenu = this.parentView.getModel("activityMenuModel").getData().oAct;
			let aActivities;
			if (sap.ui.getCore().getModel("activities")) {
				aActivities = sap.ui.getCore().getModel("activities").getData();
			}
			let oto_slwrapper;
			let sTeamActvtGuid = oSlDetailModel.getProperty("/sTeamActivityGuid");
			let oDataRegis = oRecivedData;
			let sMaxPresenatioData;
			let aTeamMember = [];
			let attachmentTabPhases = oModelSl.getData().AttachmentHierarchy.Phases;
			let oSuccessLineAct = oModelSl.getProperty("/SuccessLine/Activities");

			if (selectedTeam !== "" && selectedTeam !== undefined) {
				for (let user in selectedTeam) {
					let obj = {};
					let fName;
					let lName;
					let aName;
					obj.ID = selectedTeam[user].UserId;
					obj.EMAIL = selectedTeam[user].EmailId;
					obj.NAME = selectedTeam[user].FullName;
					obj.ActivityGuid = sTeamActvtGuid;
					obj.ROLE = selectedTeam[user].Role;
					obj.PhoneNumber = selectedTeam[user].PhoneNumber;
					aName = obj.NAME.split(" ");
					fName = aName[0];
					lName = aName[aName.length - 1];
					obj.NAME_FIRST = fName;
					obj.NAME_LAST = lName;
					aTeamMember.push(obj);
				}
			}
			oModelSl.getData().SuccessLine.Menu = true;
			if (bCompActvt === false) {
				if (oData.RiskDesc) {
					this.setRiskColor(oData.RiskDesc, oData.RiskColor);
				}
				if (oActivityDetail.CompDate && oActivityDetail.CompDate !== "") {
					if (oActivityDetail.CompDate.toDateString() === oData.CompDate.toDateString()) {
						sMaxPresenatioData = oData.CompDate;
					}
				} else {
					sMaxPresenatioData = oData.EndDate;
				}

				oto_slwrapper = oActivityDetail.to_slwrapper;
				oto_slwrapper.results[0].MethodId = oDataRegis.MethodId !== undefined ? oDataRegis.MethodId : "";
				oActivityDetail.EndDate = oData.EndDate !== undefined ? oData.EndDate : "";
				oto_slwrapper.results[0].EndAt = oData.EndDate !== undefined ? oData.EndDate : "";
				oto_slwrapper.results[0].StartAt = oData.StartDate !== undefined ? oData.StartDate : "";
				oto_slwrapper.results[0].RegActId = oData.RegisteredActId !== undefined ? oData.RegisteredActId : "";
				oto_slwrapper.results[0].to_team.results = aTeamMember;
				for (let sObj in oData) {
					oActivityDetail[sObj] = oData[sObj];
				};
				oActivityDetail.to_slwrapper = oto_slwrapper;
				this.parentController.setRiskColor(oActivityDetail.RiskDesc, 0);
				if (oActivityDetail.MtrActivity !== null) {
					oActivityDetail.MtrActivity.ActivityId = oData.RegisteredActId;
					oActivityDetail.MtrActivity.ActivityLead = oData.ActLeadId;
					oActivityDetail.MtrActivity.ActStatusDesc = oData.StatusDescription;
					oActivityDetail.MtrActivity.RoleMpngID = oData.RoleMpngID;
					oActivityDetail.MtrActivity.ActLeadName = oData.ActLead;
					oActivityDetail.MtrActivity.Requestor = oData.Requestor;
					oActivityDetail.MtrActivity.ParentRoleId = oData.ParentRoleId;
				} else if (oActivityDetail.MtrActivity === null) {
					var oMtr = {
						ActAsstId: oActivityDetail.ActvtAsstdID,
						ActLeadName: oData.ActLead,
						ActStatusDesc: oData.StatusDescription,
						ActTypeDesc: oActivityDetail.ActivityTypeInfo,
						ActivityId: oData.RegisteredActId,
						ActivityLead: oData.ActLeadId,
						ActivitySetStatus: "",
						ActivityTypeId: oActivityDetail.ActivityId,
						CostTypeName: oActivityDetail.CostTypeName,
						CostTypeValue: oActivityDetail.CostTypeValue,
						MtrTasks: [],
						ParentRoleId: oData.ParentRoleId,
						ProjectType: "",
						Requestor: oData.Requestor,
						RequestorName: "",
						RoleMpngID: oData.RoleMpngID
					};
					oModelSl.setProperty("/ActivityDetails/MtrActivity", oMtr);
				}
				if (oActivityMenu !== undefined) {
					oActivityMenu.ActLead = oData.ActLead;
					oActivityMenu.ActLeadAbrv = oData.ActLeadAbrv;
					oActivityMenu.ActLeadId = oData.ActLeadId;
					oActivityMenu.ActRegCount = oData.ActRegCount;
					oActivityMenu.ActivityLeadId = oData.ActivityLeadId;
					oActivityMenu.IsTeam = oData.IsTeam;
					oActivityMenu.ParentRoleId = oData.ParentRoleId;
					oActivityMenu.RegisteredActId = oData.RegisteredActId;
					oActivityMenu.Requestor = oData.Requestor;
					oActivityMenu.RequestorRegHC = oData.RequestorRegHC;
					oActivityMenu.RiskColor = oData.RiskColor;
					oActivityMenu.RiskDesc = oData.RiskDesc;
					oActivityMenu.RiskId = oData.RiskId;
					oActivityMenu.RoleMpngID = oData.RoleMpngID;
					oActivityMenu.StatusDescription = oData.StatusDescription;
					oActivityMenu.StatusId = oData.StatusId;
					oActivityMenu.Title = oData.ActvtTypeDesc;
					oActivityMenu.TotalActCount = oData.TotalActCount;
				}
				let aActivitiesNewId = (parseInt(oData.RegisteredActId, 10)).toString();
				if (aActivities) {
					let currentUser = that.parentView.getModel("user").getProperty("/UserId");
					let slLead = oModelSl.getProperty("/SuccessLine/SlLead");
					let sSlLeadAccess = "";
					if (currentUser === slLead) {
						sSlLeadAccess = "X";
					}
					aActivities.forEach((activt) => {
						if (activt.ActivityId !== aActivitiesNewId) {
							aActivities.push(oActivityDetail.MtrActivity);
						}
					});
					aActivities.forEach((activt) => {
						if (activt.ActivityId === oData.RegisteredActId) {
							activt.IsSlLead = sSlLeadAccess;
							activt.ActivityId = aActivitiesNewId;

						}
					});
				}
				if (aMethodDetails !== undefined) {
					aMethodDetails.forEach((method) => {
						if (method.methodid === oDataRegis.MethodId) {
							oActivityDetail.to_slwrapper.results[0].MethodDesc = method.description;
						}
					});
				}
				if (oActivityMenu) {
					if (oActivityDetail.ActGuid === oActivityMenu.ActGuid) {
						oActivityMenu.IsTeam = oActivityDetail.IsTeam;
						oActivityMenu.RegisteredActId = oData.RegisteredActId;
						if (oUserModel.UserId === oData.ActLeadId) {
							oActivityDetail.IsTeam = "X";
						} else if (aTeamMember.length) {
							aTeamMember.forEach((team) => {
								if (team.ID === oUserModel.UserId) {
									oActivityDetail.IsTeam = "X";
								}
							});
						}
					}
				}
			} else {
				oActivityDetail.CompDate = oData.CompDate !== undefined ? oData.CompDate : "";
				oActivityDetail.StatusDescription = oData.StatusDescription !== undefined ? oData.StatusDescription : "";
				oActivityDetail.StatusId = oData.StatusId !== undefined ? oData.StatusId : "";
			}
			let iteRateArray = function (aData) {
				aData.forEach((item) => {
					if (item.touchpointId === oData.TpointId) {
						if (item.activities !== undefined && Array.isArray(item.activities)) {
							item.activities.forEach((act) => {
								if (bCompActvt === false) {
									if (act.id === oDataRegis.SLActGUID) {
										act.status = oData.StatusDescription;
										act.date = sMaxPresenatioData;
										act.title = oData.ActvtTypeDesc;
									}
								} else {
									if (act.id === oDataRegis.ActGuid) {
										act.status = oData.StatusDescription;
										if (act.date !== oData.CompDate && oData.CompDate !== null) {
											if (oData.CompDate !== undefined && oData.CompDate !== "" && oData.CompDate !== null) {
												act.date = oData.CompDate;
											}
										}
									}
								}
							});
						}
					}
				});
			};
			let recurs = function (data) {
				data.forEach((item) => {
					if (item.TpointId === oData.TpointId) {
						if (item.ActGuid === oData.ActGuid && item.results === undefined) {
							item.StatusId = oData.StatusId;
							item.StatusDescription = oData.StatusDescription;
							if (bCompActvt === false) {
								item.RegisteredActId = oData.RegisteredActId;
								item.ActLeadId = oData.ActLeadId;
								item.ActLead = oData.ActLead;
								item.ActLeadAbrv = oData.ActLeadAbrv;
								item.RoleMpngID = oData.RoleMpngID;
								item.Title = oData.ActvtTypeDesc;
								if (oData.RiskDesc === "Green") {
									item.RiskColor = "";
								}
							}
						} else if (item.results !== undefined && Array.isArray(item.results)) {
							recurs(item.results);
						}
					}
				});
			};
			let oPresentationPhase;
			oPresentationDetail.phases.forEach((item) => {
				if (item.id === oData.PhaseId) {
					oPresentationPhase = item;
					iteRateArray(item.services);
				}
			});
			defaultModelPhases.forEach((item) => {
				if (item.PhaseId === oData.PhaseId) {
					recurs(item.results);
				}
			});
			if (defaultModelSlPhases.PhaseId === oData.PhaseId) {
				let results = defaultModelSlPhases.results;
				results.forEach((item) => {
					if (item.TpointId === oData.TpointId) {
						item.IsPlanned = "";
						item.IsRegistered = "X";
					}
				});
			}
			//setting phase completion when activity gets completed
			let oPhase = {};
			defaultModelPhases.forEach((item) => {
				if (item.PhaseId === oData.PhaseId) {
					oPhase = item;
					return;
				}
			});
			this.setPresetationCompletion(oPresentationPhase, oModelSl, oData);
			//setting phase completion when activity gets completed
			this.setPhaseCompletion(oPhase, oModelSl);
			this.parentController._setSlCompletion(oSuccessLineAct);
			//setting service completion when activity gets completed
			this.setServiceCompletion(defaultModelPhases, oData.PhaseId, oData.TpointId);
			// new attachment tab #173
			//updating status of activity in attachment tab
			attachmentTabPhases.forEach((item) => {
				if (item.PhaseId === oData.PhaseId) {
					recurs(item.results);
				}
			});
			let oAttachmentPhase = {};
			attachmentTabPhases.forEach((item) => {
				if (item.PhaseId === oData.PhaseId) {
					oAttachmentPhase = item;
					return;
				}
			});
			this.setPhaseCompletion(oAttachmentPhase, oModelSl);
			this.setServiceCompletion(attachmentTabPhases, oData.PhaseId, oData.TpointId);
			//new attachment tab #173
			this.parentView.getModel("slDefaultModel").refresh(true);
			this.parentView.getModel("SlDetailModel").setProperty("/RegistrationActvtVisible", true);
			this.parentView.getModel("SlDetailModel").refresh();
			sap.ui.getCore().getModel("activities").refresh();
			this.parentView.getModel("activityMenuModel").refresh();
			this.parentController._getActivityWrapper(false);
			this.appModel.setProperty("/isAppBusy", false);
		},
		onSourceChange: function (oEvent, sNullRegion) {
			this.parentController.onSourceChange(oEvent, sNullRegion);
		},
		handleActivityLeadConfirm: function (oEvent) {
			let fromRapigReg = true;
			this.parentController.handleActivityLeadConfirm(oEvent, fromRapigReg);
			let vatWarningOppId = this.parentView.getModel("SlDetailModel").getProperty("/vatWarningOppId");
			//	if(!vatWarningOppId  || vatWarningOppId === ""){
			this.sActvtLeadDialog.close();
			//	}
		},
		onOKVATWarning: function () {
			this.parentController.onOKVATWarning();
		},
		onOpportunityLinkPress: function (opp) {
			window.open(this.ConstantsMap["0183"].field_value + opp, "_blank");

		},
		onCancelCustomerActionRapidReg: function () {
			this.parentView.getModel("SlDetailModel").setProperty("/SelectedRapidRegType", "29");
			this.refreshRapidReg();
			this.customerActionRapidRegDialog.close();
			this.parentView.getModel("slDefaultModel").setProperty("/SuccessLine/Menu", true);
			this.parentView.getModel("slDefaultModel").refresh(true);
		},
		updateNotes: function () {
			let that = this;
			const oWrapper = that.parentView.getModel("slDefaultModel").getProperty("/ActivityDetails/to_slwrapper/results/0");
			that.oNotes = {
				"ActGuid": oWrapper.ActGuid,
				"SlId": oWrapper.SlId,
				"SlSnro": oWrapper.SlSnro,
				"PhaseId": oWrapper.PhaseId,
				"TpointId": oWrapper.TpointId,
				"ActivityId": oWrapper.ActivityId,
				"ActivityTitle": oWrapper.ActivityTitle,
				"WrpDescription": oWrapper.WrpDescription,
				"DaysToPrepare": oWrapper.DaysToPrepare,
				"DaysToExecute": oWrapper.DaysToExecute,
				"Deliverables": oWrapper.Deliverables,
				"Outcomes": oWrapper.Outcomes,
				"activity_id": oWrapper.activity_id,
				"Notes": oWrapper.Notes,
				"Registered": oWrapper.Registered,
				"Weight": oWrapper.Weight,
				"SubTitle": oWrapper.SubTitle
			};
			SLService.updateWrapperData(that.oNotes).then((oData) => {

			});
		},

		//C5350613 - function to check if start date is prior to 90 days
		fnToGetDaysPrior: function (startDate, currentDate) {
			var that = this;
			var currentDateUTC = Date.UTC(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate());
			var startDateUTC = Date.UTC(startDate.getFullYear(), startDate.getMonth(), startDate.getDate());
			var currentToStartDifference = Math.floor((currentDateUTC - startDateUTC) / (1000 * 60 * 60 * 24));
			var daysDifference = that.parentController.getView().getModel("masterData").getProperty("/slDaysRestriction");
			daysDifference = parseInt(daysDifference);
			var formLayoutId = that.parentView.getModel("slDefaultModel").getProperty("/ActivityDetails/frmlayout_id");
			var sMsg, endDate;

			if (currentToStartDifference <= daysDifference || daysDifference === 0) {
				if (formLayoutId !== "00001" && formLayoutId !== "00024") {
					startDate.setHours(9, 0, 0);
					endDate = that.parentView.getModel("SlDetailModel").getProperty("/RapidRegEndDate");
				}
				that.parentView.getModel("SlDetailModel").setProperty("/RapidRegStartDate", startDate);
				if (startDate > endDate) {
					this.fnToSetEndDate(startDate, endDate, formLayoutId);
				}
			} else {
				sMsg = `Can not register activity prior to more than ${daysDifference} days!`;
				MessageToast.show(sMsg);
				this.fnToSetStartAndEndDate(startDate, currentDate);
			}
		},

		//Common function for 'restriction on strat date' via start Date and End Date
		fnToRestrictStartDate: function (startDate) {
			var currentDate = new Date();
			var restrictDate = this.parentController.getView().getModel("masterData").getProperty("/slDateRestriction");
			restrictDate.setHours(0, 0, 0);
			var dateOfRestrictDate = restrictDate.getDate();
			var sMsg;

			if (currentDate.getDate() >= dateOfRestrictDate) {
				if (startDate.getFullYear() >= currentDate.getFullYear()) {
					this.fnToGetDaysPrior(startDate, currentDate);
				} else {
					sMsg = "Can register only in current year!";
					MessageToast.show(sMsg);
					this.fnToSetStartAndEndDate(startDate, currentDate);
				}
			} else {
				if (startDate.getFullYear() >= (currentDate.getFullYear() - 1) || startDate.getFullYear() === currentDate.getFullYear()) {
					this.fnToGetDaysPrior(startDate, currentDate);
				} else {
					sMsg = "Select year from the previous year!";
					MessageToast.show(sMsg);
					this.fnToSetStartAndEndDate(startDate, currentDate);
				}
			}
		},
		//C5350613 - Function to handle start date Change for Rapid Registration with
		//Date Validations:    with Restrict Historical Activity registration - #273
		handleStartDateChange: function (oEvent) {
			var that = this;
			that.dateChange = true;
			var startDate = oEvent.getSource().getDateValue();
			that.fnToRestrictStartDate(startDate);

		},

		//C5350613 - function to set start date and end date if validations fails
		fnToSetStartAndEndDate: function (startDate, currentDate) {
			startDate = new Date(currentDate.getTime());
			this.parentView.getModel("SlDetailModel").setProperty("/RapidRegStartDate", startDate);
			this.parentView.getModel("SlDetailModel").setProperty("/RapidRegEndDate", startDate);
		},

		//C5350613- function to set End Date if start date is greater than end date
		fnToSetEndDate: function (startDate, endDate, formLayoutId) {
			var regEndDate;
			endDate = new Date(startDate.getTime());
			regEndDate = this.parentView.getModel("SlDetailModel").getProperty("/RapidRegEndDate");
			if (formLayoutId !== "00001" && formLayoutId !== "00024") {
				this.parentView.getModel("SlDetailModel").setProperty("/RapidRegEndDate", endDate);
			} else {
				startDate = this.parentView.getModel("SlDetailModel").getProperty("/RapidRegStartDate");
				if (regEndDate === null) {
					endDate = new Date(startDate);
					endDate.setHours(17, 0, 0);
				} else {
					var endTimeHrs = regEndDate.getHours();
					var endTimeMins = regEndDate.getMinutes();
					var startTimeHrs = startDate.getHours();
					var startTimeMins = startDate.getMinutes();
					var toDate = this.parentView.getModel("SlDetailModel").getProperty("/RapidRegEndDate");
					if (startDate > toDate) {
						endDate.setHours(toDate.getHours(), toDate.getMinutes(), toDate.getSeconds());
						if ((startTimeHrs > endTimeHrs) || (startTimeMins > endTimeMins)) {
							endDate.setHours(startDate.getHours(), startDate.getMinutes(), startDate.getSeconds());
						}
					} else {
						endDate = new Date(startDate);
						endDate.setHours(17, 0, 0);
					}
				}
				this.parentView.getModel("SlDetailModel").setProperty("/RapidRegStartDate", startDate);
				this.parentView.getModel("SlDetailModel").setProperty("/RapidRegEndDate", startDate);
			}
		},

		//C5350613 - function to handle end date changes
		handleEndDateChange: function (oEvent) {
			var formLayoutId = this.parentView.getModel("slDefaultModel").getProperty("/ActivityDetails/frmlayout_id");
			this.dataChange = true;
			var fromDate = this.parentView.getModel("SlDetailModel").getProperty("/RapidRegStartDate");
			var toDate = oEvent.getSource().getDateValue();
			if (formLayoutId !== "00001" && formLayoutId !== "00024") {
				toDate.setHours(17, 0, 0);
			}
			this.parentView.getModel("SlDetailModel").setProperty("/RapidRegEndDate", toDate);
			if (toDate < fromDate) {
				if (formLayoutId !== "00001" && formLayoutId !== "00024") {
					fromDate = new Date(toDate.getTime());
					this.parentView.getModel("SlDetailModel").setProperty("/RapidRegStartDate", fromDate);
					var startDate = this.parentView.getModel("SlDetailModel").getProperty("/RapidRegStartDate");
					this.fnToRestrictStartDate(startDate);
				}
			}
			if (formLayoutId !== "00001" && formLayoutId !== "00024") {
				this.getDuplicateRegData();
			}
		},

		/**
		 *Function to set the phase completion percentage locally.
		 */

		setPhaseCompletion: function (oPhase, oModelSl) {
			let aPhaseServices = oPhase.results;
			let aPhaseActvts = [];
			let aPhaseCompletedActvts = [];
			let phaseCompletion = 0;
			aPhaseServices.filter(function (service) {
				if (service.Active) {
					if (service.results.length) {
						service.results.filter(function (actvt) {
							if (actvt.StatusId === "12" || actvt.StatusId === "14") {
								aPhaseCompletedActvts.push(actvt);
							}
							if (actvt.Type !== "LINK") {
								if (actvt.StatusId !== "15") {
									aPhaseActvts.push(actvt);
								}
							}
						});
					}
				}
			});
			if (aPhaseActvts.length && aPhaseCompletedActvts.length) {
				phaseCompletion = aPhaseCompletedActvts.length / aPhaseActvts.length * 100;
			}

			oPhase.PhaseCompletion = Math.round(phaseCompletion);
			oModelSl.setProperty("/PhaseDetails/PhaseCompletion", Math.round(phaseCompletion));
			let oSuccessLine = oModelSl.getProperty("/SuccessLine");
			let aPhases = oSuccessLine.Phases;
			aPhases.filter((item) => {
				if (oPhase.PhaseId === item.PhaseId) {
					item.PhaseCompletion = Math.round(phaseCompletion);
				}
			});
		},

		setServiceCompletion: function (aPhases, sPhaseId, sTpointId) {
			aPhases.forEach((item) => {
				if (item.PhaseId === sPhaseId) {
					let aPhaseServices = item.results;
					aPhaseServices.forEach((service) => {
						if (service.TpointId === sTpointId) {
							let aTpActvts = service.results;
							let aValidActvts = [];
							let aTpCompletedActvts = [];
							aTpActvts.forEach((actvt) => {
								if (actvt.StatusId === "12" || actvt.StatusId === "14") {
									aTpCompletedActvts.push(actvt);
								}
								if (actvt.Type !== "LINK") {
									if (actvt.StatusId !== "15") {
										aValidActvts.push(actvt);
									}
								}
							});
							let tpCompletion = 0;
							tpCompletion = aTpCompletedActvts.length / aValidActvts.length * 100;
							service.TPointCompletion = Math.round(tpCompletion);
						}
					});
				}
			});
		},
		/**
		 *Function to set the presentation completion perecentage locally 
		 */
		setPresetationCompletion: function (phase, oModel, oData) {
			let sPhaseId = phase.id;
			let aActiities = [];
			let aCompact = [];
			let iPresentationCompPer;
			let services = phase.services;
			let aValidation = ["Completed", "Customer Validated", "Validated"];
			services.forEach((act) => {
				act.activities.forEach((actvt) => {
					if (actvt.status !== "Not Applicable") {
						aActiities.push(actvt);
					}
				});
			});
			aActiities.forEach((item) => {
				if (aValidation.indexOf(item.status) !== -1) {
					aCompact.push(item);
				}
			});
			if (aActiities.length && aCompact.length) {
				iPresentationCompPer = aCompact.length / aActiities.length * 100;
			}
			let oPhase = oModel.getData().presentationData.phases;
			oPhase.forEach((aphase) => {
				if (aphase.id === sPhaseId) {
					aphase.percent = Math.round(iPresentationCompPer);
				}
			});
			oModel.refresh();
		},
		/**
		 * setting the risk color for local model update;
		 */
		setRiskColor(sRiskDesc, sRiskColor) {
			if (sRiskDesc === "Red") {
				sRiskColor = "#FF0000";
			} else if (sRiskDesc === "Yellow") {
				sRiskColor = "#FFFF00";
			} else {
				sRiskColor = "#215E21";
			}
			return sRiskColor;
		},

		//Function to get Lead's CRM id and desc
		fnGetSlActivityLeadRole: function (SlActLead) {
			var that = this;
			SLService.getUsers(SlActLead).then((oData) => {
				var data = {};
				var resultData = oData.data.results;
				resultData.filter(function (obj) {
					if (obj.Id === SlActLead) {
						data = obj;
					}
				});
				that.slActLead = {
					CRMRoleDesc: data.CrmRoleDesc,
					CRMRoleId: data.CrmRoleId,
					EMAIL: data.Email,
					ID: data.Id,
					NAME: data.Name
				};
				that.fnGetFindOppActUsers();
			});
		},

		//Automatically add activity team memeber to opportunity VAT team 10/11/2022 
		//Function to find the team members who don't have opportunity access
		fnGetFindOppActUsers: function () {
			var that = this;
			this.IsVATAccessSericeTriggered = false;
			let oSldefaultModel = this.parentView.getModel("slDefaultModel");
			var oSlDetailModel = that.parentView.getModel("SlDetailModel").getData();

			var sOpportunity = oSlDetailModel.OpportunityId;
			var formModel = that.parentView.getModel("formModel");
			that.appModel.setProperty("/isRiskBusy", true);
			if (sOpportunity !== "") {
				var oOppoTeam = formModel.getProperty("/SelectTeam");
				var opportunityModel = that.parentView.getModel("opportunityModel");
				var opportunityId = sOpportunity;
				let oActTeam = [];
				if (oOppoTeam === null) { //If the Harmony team data is Null, then pasing an empty array.
					oOppoTeam = [];
				}
				if (this.slActLead) {
					oActTeam.push(this.slActLead);
				} else {
					this.fnGetSlActivityLeadRole(oSlDetailModel.SlActvtLead);
					return;
				}
				for (let user in this.selectedTeam) {
					let obj = {
						ID: this.selectedTeam[user]["UserId"],
						EMAIL: this.selectedTeam[user]["EmailId"],
						NAME: this.selectedTeam[user]["FullName"],
						CRMRoleId: this.selectedTeam[user]["CRMRoleId"],
						CRMRoleDesc: this.selectedTeam[user]["CRMRoleDesc"]
					};
					oActTeam.push(obj);
				}
				if (oActTeam.length) {
					var oNoAccessUsrs = oActTeam.filter(({
						ID: id1,
						EMAIL: email1
					}) => !oOppoTeam.some(({
						UserId: id2,
						EmailId: email2
					}) =>
						id2.toLowerCase() === id1.toLowerCase() && email1.toLowerCase() === email2.toLowerCase()));
					if (oNoAccessUsrs.length) {
						var oTempArr = [];
						oNoAccessUsrs.filter(function (object) {
							if (that.parentController.fnFindSameAccountObject(object, oTempArr)) {
								object.IsDuplicate = true;
							}
							oTempArr.push(object);
						});
						var successfn = function (UIErrorCode, oResponse) {
							that.appModel.setProperty("/isAppBusy", true);
							if (UIErrorCode === "HARMONY_SERVER_DOWN" || UIErrorCode === "SERVICE_LIMIT_REACHED") {
								var oMsg = "Harmony server is unavailable, users cannot be added to Opportunity team. Do you still want to create activity?";
								if (UIErrorCode === "SERVICE_LIMIT_REACHED") {
									oMsg = "Unable to reach the service to update VAT team members. Do you still want to create Activity?";
								}
								if (oResponse) {
									var code = JSON.parse(oResponse.responseText).error.code;
									if (code === "Z_CROSS_REPORTING/009") {
										oMsg = "You do not have access to this Opportunity. Do you still want to save the Activity?";
									}
								}
								that.fnRemoveNewlyAddedUsers(UIErrorCode, oMsg);
							} else {
								that.fnRemoveCRMRoleProperty();
								that.fnSaveActRapidReg(true);
							}
						};
						var oArray = jQuery.extend(true, [], oTempArr);
						var oOppoDataModel = that.parentController.opportunityComponentInstance.getModel("oppServerModel");
						var bMetadataLoaded = oOppoDataModel.isMetadataLoadingFailed();
						if (!bMetadataLoaded) {
							this.IsVATAccessSericeTriggered = true;
							that.parentController.opportunityComponentInstance._oOpportunityHelper.fnProvideOppoAccess(oArray, opportunityId, successfn,
								true);
						} else {
							that.fnRemoveCRMRoleProperty();
							that.fnSaveActRapidReg();
						}
					} else {
						that.fnRemoveCRMRoleProperty();
						that.fnSaveActRapidReg();
					}
				} else {
					that.fnRemoveCRMRoleProperty();
					that.fnSaveActRapidReg();
				}
			} else {
				that.fnRemoveCRMRoleProperty();
				that.fnSaveActRapidReg();
			}
		},

		//Function to remove newly added team users, when the harmony server is down,[Oppo VAT team]
		fnRemoveNewlyAddedUsers: function (Error, ErrorMsg) {
			var that = this;
			sap.m.MessageBox.confirm(ErrorMsg, {
				onClose: function (oAction) {
					if (oAction.toLowerCase() === "cancel") {
						//that._oApplicationProperties.setProperty("/isAppBusy", false);
					} else {
						that.fnRemoveCRMRoleProperty();
						that.fnSaveActRapidReg();
					}
				}
			});
		},

		//Function to remove CRM Role and Desc field on Success/Error of adding users to VAT team, before activity save
		fnRemoveCRMRoleProperty: function () {
			var prop1 = "CRMRoleId";
			var prop2 = "CRMRoleDesc";
			var prop3 = "IsDuplicate";
			var oKeys = Object.keys(this.selectedTeam);
			for (var i = 0; i < oKeys.length; i++) {
				var obj = this.selectedTeam[oKeys[i]];
				this.fnRemoveObjectProperty(prop1, prop2, prop3, obj);
			}
		},

		//Function to delete an object's property
		fnRemoveObjectProperty: function (property1, property2, property3, object) {
			delete object[property1];
			delete object[property2];
			delete object[property3];
			return object;
		},

		//Function to show message box when harmony server is down
		fnShowUserOppoConfrmBox: function (oEvent) {
			this.oUserSelectEvent = jQuery.extend(true, {}, oEvent);
			let oSlDetailModel = this.parentView.getModel("SlDetailModel");
			let sOpportunity = oSlDetailModel.getProperty("/OpportunityId");
			var oppoComponent = this.parentView.getController().opportunityComponentInstance;
			var oOppoDataModel = oppoComponent.getModel("oppServerModel");
			var bMetadataLoaded = oOppoDataModel.isMetadataLoadingFailed();
			if (oEvent.getSource().getCustomData().length) {
				this.oTeamSelectedField = oEvent.getSource().getCustomData()[0].getKey();
			}
			if (sOpportunity) {
				if (!bMetadataLoaded) {
					this.fnPassSetActTeamUser();
				} else {
					var that = this;
					sap.m.MessageBox.confirm(
						"Since Harmony server is unavailable, users cannot be added to Opportunity team. Do you wish to continue", {
						onClose: function (oAction) {
							if (oAction.toLowerCase() === "cancel") {
								if (that.oTeamSelectedField === "RAPID_ACT_LEAD") {
									that.sActvtLeadDialog.close();
								} else if (that.oTeamSelectedField === "SL_TEAM") {
									this.onCloseUserSelectDialog();
								}
							} else {
								that.fnPassSetActTeamUser();
							}
						}
					});
				}
			} else {
				this.fnPassSetActTeamUser();
			}
		},

		//Function to trigger selected team user function if harmony is down
		fnPassSetActTeamUser: function () {
			if (this.oTeamSelectedField === "RAPID_ACT_LEAD") {
				this.handleActivityLeadConfirm(this.oUserSelectEvent);
			} else if (this.oTeamSelectedField === "SL_TEAM") {
				this.handleUserSelectMulti(this.oUserSelectEvent);
			}
		},

		//Overlapping activities #381
		//Function to get duplicate registrations for a selected activity
		getDuplicateRegData: function () {
			var oSlDetailModel = this.parentView.getModel("SlDetailModel");
			var slDefaultModel = this.parentView.getModel("slDefaultModel");
			var sOpportunity = oSlDetailModel.getProperty("/OpportunityId");
			var endDate = oSlDetailModel.getProperty("/RapidRegEndDate");
			var sActivityType = oSlDetailModel.getProperty("/RapidRegActTypeId");
			var formLayoutId = slDefaultModel.getProperty("/ActivityDetails/frmlayout_id");
			var isEditMode = true;
			//isEditMode = this._oApplicationProperties.getProperty("/isEditMode");

			if (endDate && endDate !== null && formLayoutId && isEditMode) {
				var dateOffset = (24 * 60 * 60 * 1000) * 5;
				var myDate = new Date(endDate);
				var myDate1 = new Date(endDate);
				var subtTime = myDate.setTime(myDate.getTime() - dateOffset);
				var fromDate = new Date(subtTime);
				var Addtime = myDate1.setTime(myDate1.getTime() + dateOffset);
				var toDate = new Date(Addtime);
				var filter = new Filter({
					filters: [
						new Filter({
							path: "OpportunityNumber",
							operator: "EQ",
							value1: sOpportunity
						}),
						new Filter({
							path: "EndDate",
							operator: "BT",
							value1: fromDate,
							value2: toDate
						}),
						new Filter({
							path: "ActivityTypeId",
							operator: "EQ",
							value1: sActivityType
						})
					],
					and: true
				});
				this.getDuplicateRegistrations([filter]);
			}
		},

		//Function to duplicate registrations list 
		getDuplicateRegistrations: function (aFilter) {
			let that = this;
			SLService.getDuplicateRegistrations(aFilter).then(function (result) {
				var data = result.data.results;
				if (data.length > 0) {
					if (!that.duplicateDemoDialog) {
						var oView = that.parentController.getView();
						that.duplicateDemoDialog = sap.ui.xmlfragment(oView.getId(),
							"com.presalescentral.successline.fragments.DuplicateActRegistrationsList",
							that);
						oView.addDependent(that.duplicateDemoDialog);
					}
					that.duplicateDemoDialog.open();
					that.fnInitJustificationDialog();
				}
				let duplicateRegModel = that.parentController.Component.getModel("duplicateRegModel");
				duplicateRegModel.setProperty("/duplicateRegistrationData", data);
			});
		},

		//Function to initialize justification dialog
		fnInitJustificationDialog: function () {
			if (!this.demoJustificationDialog) {
				var oView = this.parentController.getView();
				this.demoJustificationDialog = sap.ui.xmlfragment(oView.getId(),
					"com.presalescentral.successline.fragments.DuplicateActJustificationDialog",
					this);
				oView.addDependent(this.demoJustificationDialog);
			}
		},

		//Function to close Demo justification popup
		fnHandleNewRegistrationPress: function (oEvent) {
			this.demoJustificationDialog.open();
		},

		//Function to validate Duplicate registration
		fnAddUserDuplicateRegAct: function (oEvent) {
			var that = this;
			var oOppoModel = this.parentView.getModel("opportunityModel");
			var oSlDetailModel = this.parentView.getModel("SlDetailModel");
			var userModel = this.parentController.Component.getModel("user");
			var SLActGUID = oSlDetailModel.getProperty("/RapidRegActivity/ActGuid");
			var duplicateRegModel = this.parentController.Component.getModel("duplicateRegModel");
			var aDuplicateRegs = duplicateRegModel.getProperty("/duplicateRegistrationData");
			duplicateRegModel.setProperty("/isDialogBusy", true);
			var oOppoData = oOppoModel.getProperty("/selectedOpportunity");

			var userModelData = userModel.getData();
			var aIndex = oEvent.getParameter("id").split("-");
			var sIndex = aIndex[aIndex.length - 1];
			var userData = {
				"ID": userModelData["UserId"],
				"EMAIL": userModelData["UserEmail"],
				"ROLE": "ZOZOSOAD",
				"NAME": userModelData["UserName"],
				"ActivityGuid": aDuplicateRegs[sIndex]["ActivityGuid"],
				"SlActGuid": SLActGUID,
				"accountname": oOppoData["ACCOUNT_NAME"],
				"iss": oOppoData["ISS"],
				"iac": oOppoData["Internal_Account_Classification"],
				"industry": oOppoData["INDUSTRY"],
				"OppDescription": oOppoData["DESCRIPTION"]
			};
			duplicateRegModel.setProperty("/selectedActvtId", aDuplicateRegs[sIndex]["ActivityId"]);

			SLService.fnAddUsertoOppTeam(userData).then(function (oData) {
				duplicateRegModel.setProperty("/isDialogBusy", false);
				that.duplicateDemoDialog.close();
				if (!that.userAdditionDialog) {
					var oView = that.parentController.getView();
					that.userAdditionDialog = sap.ui.xmlfragment(oView.getId(),
						"com.presalescentral.successline.fragments.userAdditionMessage",
						that);
					oView.addDependent(that.userAdditionDialog);
				}
				that.userAdditionDialog.open();
				that.parentController.refreshSL();
			});
		},

		//Function to submit justification
		fnSubmitJustification: function (oEvent) {
			var oController = this.parentController;
			let duplicateRegModel = oController.Component.getModel("duplicateRegModel");
			let justifyComm = duplicateRegModel.getProperty("/justificationComments");
			if (justifyComm && justifyComm !== "") {
				duplicateRegModel.setProperty("/isJustDialogBusy", true);
				this.duplicateDemoDialog.close();
				var oUserModel = oController.Component.getModel("user");
				var data = {
					"ProjectType": "ACT_JUSTF",
					"CreatedBy": oUserModel.getProperty("/UserId"),
					"CreateUserName": oUserModel.getProperty("/UserName"),
					"CommentDesc": justifyComm
				};
				this.fnPostCommentToUtilityServ(data);
			} else {
				duplicateRegModel.setProperty("/justificationValState", "Error");
			}
		},

		//Function to post justification comments to Utility service
		fnPostCommentToUtilityServ: function (oPayload) {
			let that = this;
			UtilityService.fnPostCommentToUtilityServ(oPayload).then(function (result) {
				var oData = result.data;
				that.fnPostCommentToSLService(oData);
			});
		},

		//Function to post comments to SL service
		fnPostCommentToSLService: function (oUtilData) {
			var that = this;
			var SlDetailModel = this.parentView.getModel("SlDetailModel");
			var ActivityGuid = SlDetailModel.getProperty("/RapidRegActivity/ActGuid");
			var oPayload = {
				"ActivityGuid": ActivityGuid,
				"CommentGuid": oUtilData.CommentGuid
			};

			SLService.fnPostCommentToSLService(oPayload).then(function (result) {
				that.fnInitJustificationDialog();
				that.demoJustificationDialog.close();
				var oController = that.parentController;
				var duplicateRegModel = oController.Component.getModel("duplicateRegModel");
				MessageToast.show(oController._oResourceBundle.getText("commentPosted"));
				duplicateRegModel.setProperty("/isJustDialogBusy", false);
				duplicateRegModel.setProperty("/justificationComments", "");
				duplicateRegModel.setProperty("/justificationValState", "");
				//that.onCancelRapidReg();
			});
		},

		//Function to set value state onlive change in dupRegCheck
		onJustificationLiveChange: function (oEvent) {
			oEvent.getSource().setValueState("None");
		},

		//Function to close the justification dialog: Overlapping astivities
		fnOnAddmeInsteadPress: function () {
			var oController = this.parentController;
			var duplicateRegModel = oController.Component.getModel("duplicateRegModel");
			this.demoJustificationDialog.close();
			this.duplicateDemoDialog.open();
			duplicateRegModel.setProperty("/justificationComments", "");
			duplicateRegModel.setProperty("/justificationValState", "");
		},

		//Function to navigate user on ActivityID click during Activity Overlapping case
		onActivityIdPress: function (oEvent) {
			this.userAdditionDialog.close();
			var actvtId = parseInt(oEvent.getSource().getText(), 10);
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "pcactivityform",
					action: "app"
				},
				params: {
					"ActivityID": actvtId
				}
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
			this.fnClearOverlapActivityID();
		},

		//Function to show user added successfully during Activity Overlapping case
		onCloseUserAddition: function () {
			this.userAdditionDialog.close();
			this.fnClearOverlapActivityID();
		},

		//Function to clear overlapped activity ID
		fnClearOverlapActivityID: function () {
			var oController = this.parentController;
			var duplicateRegModel = oController.Component.getModel("duplicateRegModel");
			duplicateRegModel.setProperty("/selectedActvtId", "");
		},

		//saving default time entries

		//Function to trigger user time entry
		fnTriggerTimeEntry: function (oResultData) {
			var sDefaultValuesState = this.oMTRModel.getProperty("/sDefaultValuesState");
			// sDefaultValuesState="";
			if (sDefaultValuesState === "SUCCESS") {
				this.fnDoTimeEntry(oResultData);
			} else if (sDefaultValuesState === "ERROR" || sDefaultValuesState === undefined) {
				return;
			} else {
				setTimeout(() => {
					this.fnTriggerTimeEntry(oResultData);
				}, 1000);
			}
		},

		//Function to form Saved/Failed enteries during SubmitEntry case
		fnGetSaveFailedEntries: function (aUserEntries) {
			var that = this;
			var filterEnteries = [];
			if (!aUserEntries) {
				aUserEntries = this.fnGetUserEntries();
			}
			var ActivityId = this.oMTRModel.getProperty("/SavedActivityID");
			if (!ActivityId) {
				ActivityId = this.oMTRModel.getProperty("/ActivityId");
			}
			if (ActivityId === "") {
				return filterEnteries;
			}

			aUserEntries.filter(function (Entry) {
				if (Entry["ActvtId"] === ActivityId && (Entry["StatusId"] === "3" || Entry["StatusId"] === "1")) {
					var object = $.extend(true, {}, Entry);
					object["Indicator"] = "I";
					filterEnteries.push(object);
				}
			});
			return filterEnteries;
		},
		//Function to get User's Saved/Failed/Submitted entries
		fnGetUserEntries: function () {
			var aUserEntries = [];
			var dayWeekTimesheet = MTRModels.getDayWeekTimesheetModel();
			if (dayWeekTimesheet) {
				aUserEntries = dayWeekTimesheet.getProperty("/Entries");
			}
			return aUserEntries;
		},

		//Function to validate for user time entry
		fnDoTimeEntry: async function (oResponseObject) {
			var aEntries;
			var oActivityData = oResponseObject;
			var ActivityId = oActivityData["ActivityId"];
			this.oMTRModel.setProperty("/ResponseObject", oResponseObject);
			this.oMTRModel.setProperty("/SavedActivityID", ActivityId);
			aEntries = await this.fnFormatGetUserTimeEntries(false, true);

			if (aEntries["isMTRTasks"]) {
				this.fnSaveSubmitEntries(aEntries["aEntries"]);
			}
		},

		//Function to format and get User entries
		fnFormatGetUserTimeEntries: async function (bOpenDialog, bReturnObject) {
			var aNewEntries = [],
				aMTRTasks = [];
			this.oMTRModel.setProperty("/aToSaveEntries", []);
			this.oMTRModel.setProperty("/aToSubmitEntries", []);
			this.oMTRModel.setProperty("/isShowEntriesBeforeSubmit", false);
			aMTRTasks = this.oMTRModel.getProperty("/aMTRTasks");
			var oData = this.fnOpenActivitySaveDialogMTRtasks(aMTRTasks, bOpenDialog, bReturnObject);
			if (bReturnObject) {
				return oData;
			}
		},

		//Function to open Activity Save Confirmation Dialog
		fnOpenActivitySaveDialogMTRtasks: function (aMTRTasks, bOpenDialog, bReturnObject) {
			var aNewEntries = [],
				filteredMTRTask,
				customerFacingTask, nonCustomerFacingTask,
				isMTRTasks = false;

			var aUserEntries = this.fnGetUserEntries();
			aUserEntries = this.fnSortUserEntriesArray(aUserEntries);

			var EstimatedTime = this.oMTRModel.getProperty("/EstimatedTime");
			EstimatedTime = parseFloat(EstimatedTime);
			var NCFEstimatedTime = this.oMTRModel.getProperty("/NCFEstimatedTime");
			NCFEstimatedTime = parseFloat(NCFEstimatedTime);
			var CustomerFacing = this.oMTRModel.getProperty("/IsCustomerFacing");

			if (aMTRTasks.length) {
				isMTRTasks = true;
				if (aMTRTasks.length === 2) {
					var AlterCustomerFacing = this.oMTRModel.getProperty("/AlterCustomerFacing");
					if (CustomerFacing) {
						customerFacingTask = this.fnGetCustomerFacingMTRTasks(aMTRTasks, CustomerFacing);
						nonCustomerFacingTask = this.fnGetCustomerFacingMTRTasks(aMTRTasks, !CustomerFacing);
						aNewEntries = this.fnCreateTimeEntries(aUserEntries, customerFacingTask, EstimatedTime, true);
						var NCFEntries = this.fnCreateTimeEntries(aUserEntries, nonCustomerFacingTask, NCFEstimatedTime, false, aNewEntries);
						aNewEntries = aNewEntries.concat(NCFEntries);
					} else if (AlterCustomerFacing) {
						customerFacingTask = this.fnGetCustomerFacingMTRTasks(aMTRTasks, AlterCustomerFacing);
						nonCustomerFacingTask = this.fnGetCustomerFacingMTRTasks(aMTRTasks, !AlterCustomerFacing);
						var NCFEntries = this.fnCreateTimeEntries(aUserEntries, nonCustomerFacingTask, NCFEstimatedTime, false);
						aNewEntries = this.fnCreateTimeEntries(aUserEntries, customerFacingTask, EstimatedTime, true, NCFEntries);
						NCFEntries = NCFEntries.concat(aNewEntries);
						aNewEntries = NCFEntries;
					}
				} else if (aMTRTasks.length === 1) {
					filteredMTRTask = aMTRTasks[0];
					aNewEntries = this.fnCreateTimeEntries(aUserEntries, filteredMTRTask, NCFEstimatedTime, CustomerFacing);
				}
			}

			var oSplitEntries = this.validateISPFutureDate(aNewEntries);
			this.oMTRModel.setProperty("/IsActSaveEntries", true);
			var isSaveEntry = this.oMTRModel.getProperty("/IsActSaveEntries");
			if (oSplitEntries["aToSaveEntries"].length && !isSaveEntry) {
				let aToSaveEntries = this.fnPerformConcatEntries(oSplitEntries["aToSaveEntries"]);
				let aToSubmitEntries = this.fnPerformConcatEntries(oSplitEntries["aToSubmitEntries"]);
				this.oMTRModel.setProperty("/isShowEntriesBeforeSubmit", true);
				this.oMTRModel.setProperty("/aToDisplaySaveEntries", aToSaveEntries);
				this.oMTRModel.setProperty("/aToDisplaySubmitEntries", aToSubmitEntries);
				this.oMTRModel.setProperty("/aToSaveEntries", oSplitEntries["aToSaveEntries"]);
				this.oMTRModel.setProperty("/aToSubmitEntries", oSplitEntries["aToSubmitEntries"]);
			} else {
				this.oMTRModel.setProperty("/isShowEntriesBeforeSubmit", false);
			}

			if (bOpenDialog) {
				this.fnOpenActSaveConfirmationDialog();
				var ActSaveProcessSteps = this.oMTRModel.getProperty("/ActSaveProcessSteps");
				if (!ActSaveProcessSteps) {
					ActSaveProcessSteps = this.fnGetActSaveProcessSteps();
				}

				ActSaveProcessSteps.filter(function (obj) {
					if (obj["ProcessID"] === "SAVE_ENTRIES") {
						obj["IsVisible"] = this.oMTRModel.getProperty("/showSaveEntryValidationMsg");
					}
				});
				ActSaveProcessSteps.filter(function (obj) {
					if (obj["ProcessID"] === "SUBMIT_ENTRIES") {
						obj["IsVisible"] = this.oMTRModel.getProperty("/showSubmitEntryValidationMsg");
					}
				});

				var saveFailedEntries = this.fnGetSaveFailedEntries();
				if (saveFailedEntries.length) {
					ActSaveProcessSteps.filter(function (obj) {
						if (obj["ProcessID"] === "SUBMIT_ENTRIES") {
							obj["IsVisible"] = true;
						}
					});
				}

				this.oMTRModel.setProperty("/ActSaveProcessSteps", ActSaveProcessSteps);
			}

			if (bReturnObject) {
				return {
					aEntries: aNewEntries,
					isMTRTasks: isMTRTasks
				};
			}
		},
		//Function to sort Array based on date object
		fnSortUserEntriesArray: function (aEntries) {
			return aEntries.sort((entry1, entry2) => entry1.Date.getTime() - entry2.Date.getTime());
		},

		//Function to get next date for new Entry
		fnGetNewEntryDate: function (EntryDate) {
			var oDate = new Date(EntryDate);
			oDate.setDate(EntryDate.getDate() + 1);
			return oDate;
		},

		//Function perform concat for the entries array
		fnPerformConcatEntries: function (aEntriesArray) {
			if (aEntriesArray && !aEntriesArray.length) {
				return aEntriesArray;
			}
			aEntriesArray = this.fnSortUserEntriesArray(aEntriesArray);
			aEntriesArray = this.fnConcatBasedOnRecordDate(aEntriesArray);
			return aEntriesArray;
		},

		//Function to create CF/NCF Entry based on RecordDate
		fnConcatBasedOnRecordDate: function (aEntries) {
			let oRecordDates = {};
			let aTotalEntries = [];
			for (let i = 0; i < aEntries.length; i++) {
				let oEntry = aEntries[i];
				let entryDate = oEntry.Date;
				let TimeMatrics = oEntry.Unit;
				let RecordDate = oEntry.RecordDate;
				let WorkDuration = (oEntry.WorkDuration) ? Number(oEntry.WorkDuration) : 0;
				let oNewEntry = {
					entryDate: entryDate,
					cfWorkDuration: 0,
					ncfWorkDuration: 0,
					cfTimeMatrics: TimeMatrics,
					ncfTimeMatrics: TimeMatrics,
					RecordDate: RecordDate
				};
				if (!oRecordDates[RecordDate]) {
					oRecordDates[RecordDate] = 1;
					if (oEntry.CustomerFacing) {
						oNewEntry.cfWorkDuration = WorkDuration;
					} else {
						oNewEntry.ncfWorkDuration = WorkDuration;
					}
					aTotalEntries.push(oNewEntry);
				} else {
					if (oRecordDates[RecordDate] >= 1) {
						let indxEntry = aTotalEntries.findIndex((entry) => {
							return entry.RecordDate === RecordDate;
						});

						//If entry alreay present;
						if (indxEntry !== -1) {
							if (oEntry.CustomerFacing) {
								aTotalEntries[indxEntry].cfWorkDuration += WorkDuration;
							} else {
								aTotalEntries[indxEntry].ncfWorkDuration += WorkDuration;
							}
							oRecordDates[RecordDate] += 1;
						} else {
							//Worst case scenario
							oRecordDates[RecordDate] = 1;
							if (oEntry.CustomerFacing) {
								oNewEntry.cfWorkDuration = WorkDuration;
							} else {
								oNewEntry.ncfWorkDuration = WorkDuration;
							}
							aTotalEntries.push(oNewEntry);
						}
					}
				}
			}
			return aTotalEntries;
		},

		//Function to validate and separate Submitted and Saved entries if more than 7 days
		//7 is hardcoded as per said validation for the number of days
		validateISPFutureDate: function (aEntries) {
			var iNoOfDays = 7;
			var aEntriesToBeSaved = [];
			var aEntriesToBeSubmitted = [];
			var actStrtDate = this.oMTRModel.getProperty("/ResponseObject/StartDate");
			var startDate = new Date(actStrtDate);
			startDate.setHours(0, 0, 0, 0);
			var endDate = this.fnGetTargetEndDate(iNoOfDays, startDate);
			aEntries.filter(function (entry) {
				var entryDate = entry["Date"];
				if (entryDate >= startDate && entryDate < endDate) {
					aEntriesToBeSubmitted.push(entry);
				} else {
					aEntriesToBeSaved.push(entry);
				}
			});

			this.oMTRModel.setProperty("/showSaveEntryValidationMsg", false);
			this.oMTRModel.setProperty("/showSubmitEntryValidationMsg", false);
			if (aEntriesToBeSaved.length > 0) {
				this.oMTRModel.setProperty("/showSaveEntryValidationMsg", true);
			}
			if (aEntriesToBeSubmitted.length > 0) {
				this.oMTRModel.setProperty("/showSubmitEntryValidationMsg", true);
			}
			return {
				aToSubmitEntries: aEntriesToBeSubmitted,
				aToSaveEntries: aEntriesToBeSaved
			};
		},

		//Function to returns a end date based on number of days from start date
		fnGetTargetEndDate: function (iNoOfDays, dStartDate) {
			return new Date(new Date(dStartDate).getTime() + (iNoOfDays * 24 * 60 * 60 * 1000));
		},

		//Function to create new time entries
		fnCreateTimeEntries: function (aUserEntries, MTRTask, EstimatedTime, customerFacing, aPrevEntries) {
			var aEntries = [];
			var StdWorkDuration = this.fnGetWorkDuration();
			var oActStartDate = this.oMTRModel.getProperty("/ResponseObject/StartDate");
			var oNextDate = new Date(oActStartDate);
			if (aPrevEntries && aPrevEntries.length) {
				var length = aPrevEntries.length - 1;
				oNextDate = new Date(aPrevEntries[length]["Date"]);
				aUserEntries = aUserEntries.concat(aPrevEntries);
			}

			while (EstimatedTime != 0) {
				var strDate = this.fnConvertDateObjToString(oNextDate);
				var selDateEntriesArray = this.getActStartDateEntries(strDate, aUserEntries);
				var selDateWorkDuration = this.fnCalculateWorkDuration(selDateEntriesArray);
				if (selDateWorkDuration >= StdWorkDuration) {
					oNextDate = this.fnGetNewEntryDate(oNextDate);
				} else if (selDateWorkDuration < StdWorkDuration) {
					var oRecordDateEntry = this.fnValidateRecordDateEntry(strDate);
					if (oRecordDateEntry["isValidDate"] && oRecordDateEntry["targetHrs"] > 0) {
						StdWorkDuration = oRecordDateEntry["targetHrs"];
						var oTempObj = this.fnCalculateEstimateTime(StdWorkDuration, selDateWorkDuration, EstimatedTime, MTRTask, oNextDate, aEntries,
							customerFacing);
						oNextDate = oTempObj["oNextDate"];
						aEntries = oTempObj["aEntries"];
						EstimatedTime = oTempObj["EstimatedTime"];
					} else if (oRecordDateEntry["isValidDate"] && oRecordDateEntry["targetHrs"] === 0) {
						oNextDate = this.fnGetNewEntryDate(oNextDate);
					} else if (!oRecordDateEntry["isValidDate"] && oRecordDateEntry["targetHrs"] === 0) {
						var WeekDayIndices = this.fnGetWeekDayIndex(oNextDate);
						if ((WeekDayIndices["DayIndex"] === WeekDayIndices["Sunday"]) || (WeekDayIndices["DayIndex"] === WeekDayIndices["Saturday"])) {
							oNextDate = this.fnGetNewEntryDate(oNextDate);
						} else {
							var oTempObj = this.fnCalculateEstimateTime(StdWorkDuration, selDateWorkDuration, EstimatedTime, MTRTask, oNextDate, aEntries,
								customerFacing);
							oNextDate = oTempObj["oNextDate"];
							aEntries = oTempObj["aEntries"];
							EstimatedTime = oTempObj["EstimatedTime"];
						}
					}
				}
			}
			return aEntries;
		},

		//Function to get selected Date's weekdays indices
		fnGetWeekDayIndex: function (oDate) {
			var dayIndex = oDate.getDay();
			var mtrSettings = sap.ui.getCore().getModel("mtrSettings");
			var SundayIndex = mtrSettings.getProperty("/SecondWeekendDay");
			var WeekStartDay = mtrSettings.getProperty("/WeekStartDay");
			var SaturdayIndex = mtrSettings.getProperty("/FirstWeekendDay");
			return {
				DayIndex: dayIndex,
				Sunday: SundayIndex,
				Saturday: SaturdayIndex,
				WeekStartDay: WeekStartDay
			};
		},

		//Function to calculate estimated time and then creat new entries
		fnCalculateEstimateTime: function (StdWorkDuration, selDateWorkDuration, EstimatedTime, MTRTask, oNextDate, aEntries, bCustomerFacing) {
			var selDateRemainingHrs = StdWorkDuration - selDateWorkDuration;
			if (EstimatedTime > selDateRemainingHrs) {
				EstimatedTime = EstimatedTime - selDateRemainingHrs;
			} else {
				selDateRemainingHrs = EstimatedTime;
				EstimatedTime = 0;
			}
			var newEntry = this.fnGetNewEntryObj(MTRTask, oNextDate, selDateRemainingHrs, bCustomerFacing);
			aEntries.push(newEntry);
			if (EstimatedTime) {
				oNextDate = this.fnGetNewEntryDate(oNextDate);
			}
			return {
				oNextDate: oNextDate,
				aEntries: aEntries,
				EstimatedTime: EstimatedTime
			};
		},

		//Function to create a new Entry Object
		fnGetNewEntryObj: function (MTRTask, RecordDate, WorkDuration, bCustomerFacing) {
			var oResponseObj = this.oMTRModel.getProperty("/ResponseObject");
			var CostTypeId = oResponseObj.ActvtAsstdID;
			if (CostTypeId === "501") {
				CostTypeId = "4";
			} else if (CostTypeId === "502") {
				CostTypeId = "1";
			} else if (CostTypeId === "503") {
				CostTypeId = "2";
			}
			var CostTypeValue = CostTypeId === "1" ? oResponseObj.OpportunityNumber : oResponseObj.GlobalUltimateID;

			var object = {
				ActvtId: oResponseObj["ActivityId"],
				ActTypeDesc: oResponseObj["ActivityTypeDescription"],
				Indicator: "I",
				TaskId: MTRTask["MtrTaskID"],
				TaskName: MTRTask["MtrTaskName"],
				WorkDuration: WorkDuration.toString(),
				RecordDate: this.fnConvertDateObjToString(RecordDate),
				CostTypeId: CostTypeId,
				CostTypeValue: CostTypeValue,
				CustomerFacing: bCustomerFacing //this.oViewSettingsModel.getProperty("/IsCustomerFacing")
			};
			var oEntry = new Entry(object);
			oEntry.setMelodyActivity(oResponseObj["ActivityId"]);
			return oEntry;
		},

		//Function to check if the record date is available for Time Entry, based on User's calendar profile
		fnValidateRecordDateEntry: function (sRecordDate) {
			var isRecordAvailObj = {
				isValidDate: false,
				targetHrs: 0
			};
			var TargetModel = sap.ui.getCore().getModel("target");
			var aCalendarDays = TargetModel.getProperty("/TargetHours");
			var oCalendarDay = aCalendarDays.find(function (CalendarDay) {
				return CalendarDay["Date"] === sRecordDate;
			});

			if (oCalendarDay) {
				var sTargetHrs = oCalendarDay["Datetype"] === "WORK" ? oCalendarDay["Targethours"] : 0;
				var sTimeMatrics = sap.ui.getCore().getModel("mtrSettings").getProperty("/TimeMatrics");
				sTargetHrs = parseFloat(sTargetHrs);
				if (sTimeMatrics === "D") {
					if (sTargetHrs !== 0 && sTargetHrs < 4) {
						sTargetHrs = 0.5;
					} else if (sTargetHrs !== 0 && sTargetHrs >= 4) {
						sTargetHrs = 1;
					}
				}
				isRecordAvailObj = {
					isValidDate: true,
					targetHrs: sTargetHrs
				};
			}
			return isRecordAvailObj;
		},

		//Function to get Standard Work Duration
		fnGetWorkDuration: function () {
			var mtrSettings = sap.ui.getCore().getModel("mtrSettings");
			var StdWorkDuration = mtrSettings.getProperty("/StdWorkDuration");
			StdWorkDuration = parseFloat(StdWorkDuration);
			return StdWorkDuration;
		},

		//Function to calculate the total work duration for a selected date
		fnCalculateWorkDuration: function (aEntries) {
			var totalWorkDuration = 0;
			aEntries.filter(function (oEntry) {
				totalWorkDuration = totalWorkDuration + parseFloat(oEntry.WorkDuration);
			});
			return totalWorkDuration;
		},

		//Function to convert Javascript Date objec to string format for comparison
		fnConvertDateObjToString: function (ActStartDate) {
			var date = new Date(ActStartDate),
				month = '' + (date.getMonth() + 1),
				day = '' + date.getDate(),
				year = date.getFullYear();

			if (month.length < 2)
				month = '0' + month;
			if (day.length < 2)
				day = '0' + day;

			return [year, month, day].join('');
		},

		//Function to get Entries that are present on Activity Start Date
		getActStartDateEntries: function (startDate, sUserEntries) {
			var aStrtEntries = [];
			sUserEntries.find(function (oEntry) {
				if (oEntry["RecordDate"] === startDate) {
					aStrtEntries.push(oEntry);
				}
			});
			return aStrtEntries;
		},

		//Function to get MTR task based in Customer facing:True/False
		fnGetCustomerFacingMTRTasks: function (aMTRTasks, IsCustomerFacing) {
			IsCustomerFacing = IsCustomerFacing ? "1" : "2";
			var filteredMTRTask = aMTRTasks.find(function (oMTRTask) {
				var sMpngAttr = oMTRTask["MpngAttr"];
				if (sMpngAttr === "1") {
					return oMTRTask["MpngAttrVal"] === IsCustomerFacing;
				}
			});
			return filteredMTRTask;
		},

		//Function to get selected activity from UserActivities list
		getActivityFromUserActivities: function (sActivityId, aUserActivities) {
			var oSelActivity = aUserActivities.find(function (oActivity) {
				return oActivity["ActivityId"] === sActivityId;
			});
			return oSelActivity;
		},

		//Function to Save/Submit entries:
		fnSaveSubmitEntries: async function (aEntries) {
			var oResult = [];
			var EstimatedTime = this.oMTRModel.getProperty("/EstimatedTime");
			EstimatedTime = parseFloat(EstimatedTime);
			var NCFEstimatedTime = this.oMTRModel.getProperty("/NCFEstimatedTime");
			NCFEstimatedTime = parseFloat(NCFEstimatedTime);
			var oResponseObject = this.oMTRModel.getProperty("/ResponseObject");
			if (this.oMTRModel.getProperty("/IsActSaveEntries")) {
				if (EstimatedTime || NCFEstimatedTime) {
					await MTRUtil.saveEntries(aEntries);
				}
			}
		},

		//Additional opportunity changes
		openAdditionalOpptDialog: function () {
			let that = this;
			var oppoModel = this.parentView.getModel("opportunityModel");
			var oppoList = oppoModel.getProperty("/opportunity");
			if (!this.additionalOppDialog) {
				oppoModel.setProperty("/isOpptDilogBusy", true);
				this.additionalOppDialog = sap.ui.xmlfragment(this.parentView.getId(),
					"com.presalescentral.successline.fragments.RapidRegAdditionalOpportunities", this);
				this.parentView.addDependent(this.additionalOppDialog);
				this.fnGetAddOppoList();
				var oppoList = oppoModel.getProperty("/opportunity");
				if (oppoList) {
					oppoList.filter(function (obj) {
						obj.addOppPrevSelect = false;
						obj.addOppSelected = false;
					});
				}
				oppoModel.setProperty("/opportunity", oppoList);
			}
			var sRegisteredActId = this.parentView.getModel("SlDetailModel").getProperty("/RapidRegActivity/RegisteredActId");
			if (sRegisteredActId) {
				var oSavedOppoList = this.parentView.getModel("SlDetailModel").getProperty("/to_addopp");
				if (oSavedOppoList.length) {
					oSavedOppoList.filter(function (savedOppObj) {
						var sOppoId = savedOppObj.OpportunityNo;
						oppoList.filter(function (obj) {
							if (obj.OPPT_ID === sOppoId) {
								obj.addOppPrevSelect = true;
								obj.addOppSelected = true;
							}
						});
					});
				}
				oppoModel.setProperty("/opportunity", oppoList);
			}
			oppoModel.refresh(true);
			this.additionalOppDialog.open();
			this.parentView.byId("addOpptStatusSel").setSelectedKey("");

			if (!this.parentController.oStorage.get("actOpportunities") && !this.parentController.oStorage.get("pcOpportunities")) { } else {
				var OppoId = this.parentView.getModel("SlDetailModel").getProperty("/OpportunityId");
				if (OppoId) {
					this.parentView.byId("rapidRegAddOpptList").getBinding("items").filter([new Filter("OPPT_ID", "NE", OppoId)]);
				}
			}
		},

		//Function to get additional opportunities
		fnGetAddOppoList: function () {
			var oStorage = this.parentController.oStorage;
			if (!oStorage.get("actOpportunities") && !oStorage.get("pcOpportunities")) {
				let userId = this.parentView.getModel("user").getProperty("/UserId");
				this.parentController.opportunityComponentInstance._oOpportunityHelper._getBusinessPartner(userId);
			} else {
				var oppoList = [];
				if (oStorage.get("actOpportunities")) {
					oppoList = oStorage.get("actOpportunities");
				} else if (!oStorage.get("actOpportunities") && oStorage.get("pcOpportunities")) {
					oppoList = oStorage.get("pcOpportunities");
				}
				oppoList = $.extend(true, [], oppoList);
				this.parentView.getModel("opportunityModel").setProperty("/opportunity", oppoList);
			}
		},

		handleAdditionalOpptSelect: function (oEvent) {
			var that = this;
			var oSource = oEvent.getSource();
			var oppoModel = oSource.getModel("opportunityModel");
			var sPath = oSource.getBindingContext("opportunityModel").getPath();
			if (!oppoModel.getProperty(sPath + "/addOppSelected")) {
				oppoModel.setProperty(sPath + "/addOppSelected", true);
				oSource.setText("Deselect");
			} else {
				oppoModel.setProperty(sPath + "/addOppSelected", false);
				oSource.setText("Select");
			}
			oppoModel.refresh();
		},

		handleAdditionalOpptConfirm: function (oEvent) {
			this.fnUpdateAddOppFields();
			this.additionalOppDialog.close();
		},

		//function to update add opportunities fields properties on select and deselect
		fnUpdateAddOppFields: function () {
			var oTempArr = [];
			var oppoModel = this.parentView.getModel("opportunityModel");
			var aOppoList = oppoModel.getProperty("/opportunity");
			aOppoList.filter(function (obj) {
				if (obj.addOppSelected) {
					obj.addOppPrevSelect = true;
					var opptObj = {};
					opptObj.OpportunityNo = obj.OPPT_ID;
					opptObj.AccountID = obj.ACCOUNT;
					oTempArr.push(opptObj);
				} else {
					obj.addOppPrevSelect = false;
				}
			});
			this.parentView.getModel("SlDetailModel").setProperty("/to_addopp", oTempArr);
			oppoModel.refresh();
		},

		handleAddOppDialogCancel: function (oEvent) {
			this.additionalOppDialog.close();
		},

		//Function triggered when deleted tokens from suggestion list
		updateAddOppTokens: function (oEvent) {
			var aRemovedToken = oEvent.getParameter("removedTokens");
			if (aRemovedToken && aRemovedToken.length) {
				var sKey = oEvent.getParameter("removedTokens")[0].getKey();
				var oppoModel = this.parentView.getModel("opportunityModel");
				var aOppoList = oppoModel.getProperty("/opportunity");
				var aSelectedAddOpp = this.parentView.getModel("SlDetailModel").getProperty("/to_addopp");
				aOppoList.filter(function (obj) {
					if (sKey === obj.OPPT_ID) {
						obj.addOppSelected = false;
						obj.addOppPrevSelect = false;
					}
				});
				oppoModel.setProperty("/opportunity", aOppoList);
				var index = aSelectedAddOpp.findIndex(function (item) {
					return item.OpportunityNo === sKey;
				});
				aSelectedAddOpp.splice(index, 1);
				this.parentView.getModel("SlDetailModel").setProperty("/to_addopp", aSelectedAddOpp);
				oppoModel.refresh(true);
			}
		},

		handleAddOppStatusSelect: function (oEvent) {
			var aFilters = [];
			var opportunityModel = this.parentView.getModel("opportunityModel");
			var sOppId = opportunityModel.getProperty("/selectedOpportunity/OPPT_ID");
			var accountId = opportunityModel.getProperty("/selectedOpportunity/accountid");
			// var formModel = this.getView().getModel("formModel");
			// var isAccount = formModel.getProperty("/selectedIndex") ? true : false;
			var sSelectedStatus = oEvent.getParameter("selectedItem").getKey();
			var oListItem = this.parentView.byId("rapidRegAddOpptList").getBinding("items");
			if (sSelectedStatus !== "") {
				aFilters.push(new Filter("active", "EQ", sSelectedStatus));
			}
			// if (isAccount) {
			// 	if (accountId) {
			// 		aFilters.push(new Filter("ACCOUNT", "EQ", accountId));
			// 	}
			// } else {
			if (sOppId) {
				aFilters.push(new Filter("OPPT_ID", "NE", sOppId));
			}
			// }

			this.parentView.byId("rapidRegAddOpptList").getBinding("items").filter(aFilters);
			this.parentView.byId("OpptSearchMulti").setValue("");
			// this.fnHandleActOppFilterChange(oListItem, true);
			this.fnUpdateAddOppFields();
		},

		onOpptSearch: function (oEvent) {
			let aOpportunityId = [];
			var opportunityModel = this.parentView.getModel("opportunityModel");
			let sOppId = opportunityModel.getProperty("/selectedOpportunity/OPPT_ID");
			let sStatus = this.parentView.byId("AddOpptStatusSel").getSelectedKey();
			let sValue = oEvent.getParameter("query");
			let aFilters = new Filter({
				filters: [
					new Filter("ACCOUNT_NAME", "Contains", sValue),
					new Filter("OPPT_ID", "Contains", sValue),
					new Filter("DESCRIPTION", "Contains", sValue),
					new Filter("ACCOUNT", "Contains", sValue)
				],
				and: false
			});

			if (sOppId) {
				let oSearchFilter1 = aFilters;
				let oppFilter = new Filter("OPPT_ID", "NE", sOppId);
				aFilters = new Filter({
					filters: [oSearchFilter1, oppFilter],
					and: true
				});
			}
			if (sStatus) {
				let oSearchFilter = aFilters;
				let oStatusFilter = new Filter("active", "EQ", sStatus);
				aFilters = new Filter({
					filters: [oSearchFilter, oStatusFilter],
					and: true
				});
			}
			let oList = this.parentView.byId("rapidRegAddOpptList");
			let oBinding = oList.getBinding("items");
			oBinding.filter([aFilters]);
			// if (sValue) {
			// 	this.fnHandleActOppFilterChange(oBinding, true);
			// }
		},

		//Solution hierarchy changes
		//Function to open Solution Hierarchy popup
		openSolutionHierarchy: function (oEvent) {
			var oSolutionsModel = this.parentView.getModel("oSolutionsModel");
			var oSolViewType = oEvent.getSource().getCustomData()[0].getKey();
			if (!this.solHierarchyDlg) {
				this.solHierarchyDlg = sap.ui.xmlfragment(this.parentView.getId(),
					"com.presalescentral.successline.fragments.SolutionHierarchy", this);
				this.parentView.addDependent(this.solHierarchyDlg);
				// UtilHelper.fnDisableDatePicker([this.byId("idSolHierMultiInput")]);
			}
			this.parentView.byId("idSolutionTree").collapseAll();
			this.fnFireSolHierarchyCbs();

			var to_ATaxonomy = $.extend(true, [], oSolutionsModel.getProperty("/to_ATaxonomy"));
			var to_AMaterial = $.extend(true, [], oSolutionsModel.getProperty("/to_AMaterial"));
			oSolutionsModel.setProperty("/oSolTempArr", to_ATaxonomy);
			oSolutionsModel.setProperty("/oMatTempArr", to_AMaterial);
			this.fnSetSolutionViewMode(oSolViewType);
			this.solHierarchyDlg.open();
		},

		//Function to set solutions checkbox true on expand on tree items
		fnFireSolHierarchyCbs: function () {
			var oSolutionsModel = this.parentView.getModel("oSolutionsModel");
			var oSolutionTree = this.parentView.byId("idSolutionTree");
			oSolutionTree.getItems().filter(function (l3Obj) {
				l3Obj.getContent().filter(function (obj) {
					var oChkBox = obj.getItems()[1];
					var sPath = oChkBox.getBindingContext("oSolutionsModel").getPath();
					var oSelectedObj = oSolutionsModel.getProperty(sPath);
					if (oSelectedObj.isSelected && (oSelectedObj.LevelCount === 4 || oSelectedObj.LevelCount === 5)) {
						oChkBox.setSelected(true);
					}
				})
			});
		},

		//Function to initialize view settings of Solutions hierarchy popup
		fnSetSolutionViewMode: function (oSolViewType) {
			var isMatTblVisible = false;
			var isOppoTabVisible = false;
			var isDisplayMatSelected = false;
			var MatTblSelectMode = "SingleSelectLeft";
			var oSolutionsModel = this.parentView.getModel("oSolutionsModel");
			if (oSolViewType === "SOL_MULTI_SELECT") {
				isMatTblVisible = false;
				MatTblSelectMode = "MultiSelect";
			}
			// var oAssociationType = this.oRegModel.getProperty("/associateType");
			var oAssociationType = this.parentController.SlDetailModel.getProperty("/RapidRegActivity/ActvtAsstdID");
			if (oAssociationType === "501" || oAssociationType === "503") {
				isOppoTabVisible = false;
			} else {
				isOppoTabVisible = true;
			}
			oSolutionsModel.setProperty("/isSolTabVisible", true);
			oSolutionsModel.setProperty("/isLevel2DrpDwnVisible", true);
			oSolutionsModel.setProperty("/isMatTblVisible", isMatTblVisible);
			oSolutionsModel.setProperty("/MatTblSelectMode", MatTblSelectMode);
			oSolutionsModel.setProperty("/isOppoTabVisible", isOppoTabVisible);
			oSolutionsModel.setProperty("/ITBSelectedKey", "SOLUTION_HIERARCHY");
			oSolutionsModel.setProperty("/isDisplayMatSelected", isDisplayMatSelected);
			this.fnShowMaterialInfoTbl("", isMatTblVisible);
			this.fnHandleLevel2Change();
			this.fnSetSelectedSolMatData();
			oSolutionsModel.refresh(true);
		},

		fnShowMaterialInfoTbl: function (oEvent, bVal) {
			var oSolutionsModel = this.parentView.getModel("oSolutionsModel");
			if (oEvent !== "") {
				bVal = oEvent.getSource().getSelected();
			}
			if (bVal) {
				this.solHierarchyDlg.setContentWidth("70%");
				this.parentView.byId("solHierarchyGrid").setDefaultSpan("XL6 L6 M6 S12");
				if (oSolutionsModel.getProperty("/ITBSelectedKey") === "SOLUTION_HIERARCHY") {
					this.parentView.byId("levelDropDwnGrid").setDefaultSpan("XL6 L4 M12 S12");
				}
			} else {
				this.solHierarchyDlg.setContentWidth("43%");
				this.parentView.byId("solHierarchyGrid").setDefaultSpan("XL12 L12 M12 S12");
				if (oSolutionsModel.getProperty("/ITBSelectedKey") === "SOLUTION_HIERARCHY") {
					this.parentView.byId("levelDropDwnGrid").setDefaultSpan("XL6 L6 M12 S12");
				}
			}
			oSolutionsModel.setProperty("/isMatTblVisible", bVal);
			this.fnSetSelectedSolMatData();
			oSolutionsModel.refresh();
		},

		//Function to close Solution hierarchy popup
		closeSolutionHierarchy: function (oEvent) {
			var oSolutionsModel = this.parentView.getModel("oSolutionsModel");
			var OppSolArr = oSolutionsModel.getProperty("/OppSolArr");
			var to_ATaxonomy = oSolutionsModel.getProperty("/to_ATaxonomy");
			var to_AMaterial = oSolutionsModel.getProperty("/to_AMaterial");
			var SolTokens = to_ATaxonomy.concat(to_AMaterial);
			SolTokens = this.parentController.fnGetDisplayTokens(SolTokens);
			oSolutionsModel.setProperty("/SolTokens", SolTokens);
			oSolutionsModel.setProperty("/DisplayTokens", SolTokens);
			oSolutionsModel.setProperty("/oSolTempArr", []);
			oSolutionsModel.setProperty("/oMatTempArr", []);
			oSolutionsModel.setProperty("/OppSolTempArr", OppSolArr);
			var oPayload = this.fnGetSolMatPayload(to_ATaxonomy, to_AMaterial);
			this.parentView.getModel("SlDetailModel").setProperty("/to_ATaxonomy", oPayload[0]);
			this.parentView.getModel("SlDetailModel").setProperty("/to_AMaterial", oPayload[1]);
			if (oEvent) {
				this.solHierarchyDlg.close();
			}
		},

		//Function to update the selected tokens on click of OK
		fnSetSelectedSolutions: function () {
			var oSolutionsModel = this.parentView.getModel("oSolutionsModel");
			var oSolTempArr = oSolutionsModel.getProperty("/oSolTempArr");
			var oMatTempArr = oSolutionsModel.getProperty("/oMatTempArr");
			var SolTokens = oSolutionsModel.getProperty("/DisplayTokens");
			var MatTblSelectMode = oSolutionsModel.getProperty("/MatTblSelectMode");
			if (MatTblSelectMode === "MultiSelect") {
				oSolutionsModel.setProperty("/SolTokens", SolTokens);
			} else {
				var oDesc = "";
				if (oMatTempArr.length) {
					if (oMatTempArr[0].LevelDesc) {
						oDesc = oMatTempArr[0].LevelDesc;
					} else {
						oDesc = oMatTempArr[0].MatDesc;
					}
				} else {
					if (oSolTempArr.length) {
						oDesc = oSolTempArr[0].LevelDesc;
					}
				}
				oSolutionsModel.setProperty("/SolutionDesc", oDesc);
			}
			var oPayload = this.fnGetSolMatPayload(oSolTempArr, oMatTempArr);
			oSolutionsModel.setProperty("/to_ATaxonomy", oSolTempArr);
			oSolutionsModel.setProperty("/to_AMaterial", oMatTempArr);
			this.parentView.getModel("SlDetailModel").setProperty("/to_ATaxonomy", oPayload[0]);
			this.parentView.getModel("SlDetailModel").setProperty("/to_AMaterial", oPayload[1]);
			var OppSolArr = oSolutionsModel.getProperty("/OppSolTempArr");
			oSolutionsModel.setProperty("/OppSolArr", OppSolArr);
			if (this.solHierarchyDlg) {
				this.solHierarchyDlg.close();
			}
			if (oSolTempArr.length > 0) {
				this.parentView.byId("additionalSolutions").setValueState("None");
			}
			oSolutionsModel.refresh();
		},

		//Function to get payload of selected Solution and Materials
		fnGetSolMatPayload: function (oSolTempArr, oMatTempArr) {
			var aSolTempArr = [];
			var aMatTempArr = [];
			var ActivityGuid = this.parentController.SlDetailModel.getProperty("/RapidRegActivity/ActGuid");
			oSolTempArr.filter(function (solObj) {
				if (solObj.isParent) {
					return;
				}
				var oSolTempObj = {};
				var length = solObj.LevelCount;
				oSolTempObj.L2Id = solObj.L2Id;
				oSolTempObj.L2Desc = solObj.L2Desc;
				oSolTempObj.L3Id = solObj.L3Id;
				oSolTempObj.L3Desc = solObj.L3Desc;
				for (var i = length; i >= 4; i--) {
					var oId = "L" + i + "Id";
					var oDesc = "L" + i + "Desc";
					oSolTempObj[oId] = solObj[oId];
					oSolTempObj[oDesc] = solObj[oDesc];
				}
				oSolTempObj.LevelCount = solObj.LevelCount;
				oSolTempObj.ActivityGuid = ActivityGuid;
				aSolTempArr.push(oSolTempObj);
			});
			oMatTempArr.filter(function (matObj) {
				var oMatTempObj = {};
				oMatTempObj.MatId = matObj.MatId;
				oMatTempObj.MatDesc = matObj.MatDesc;
				oMatTempObj.SolYear = matObj.SolYear;
				oMatTempObj.ActivityGuid = ActivityGuid;
				aMatTempArr.push(oMatTempObj);
			});
			this.dataChange = true;
			return [aSolTempArr, aMatTempArr];
		},

		fnHandleLevel2Change: function () {
			var oSolTree = this.parentView.byId("idSolutionTree");
			var level2Id = this.parentView.getModel("SlDetailModel").getProperty("/Level2Key");
			var oFilter = [new Filter("L2Id", "EQ", level2Id)];
			oSolTree.getBinding("items").filter(oFilter);
		},

		//Function to get selected objs on Checkbox/RadioBtn selection change
		fnSetCheckRadioBtnSelected: function (oEvent) {
			var oSource = oEvent.getSource();
			if (!oSource.getVisible()) {
				return;
			}
			var oSolutionsModel = this.parentView.getModel("oSolutionsModel");
			var oSolTempArr = oSolutionsModel.getProperty("/oSolTempArr");
			var oMatTempArr = oSolutionsModel.getProperty("/oMatTempArr");
			var OppSolTempArr = oSolutionsModel.getProperty("/OppSolTempArr");
			var sPath = oSource.getBindingContext("oSolutionsModel").getPath();
			var MatTblSelectMode = oSolutionsModel.getProperty("/MatTblSelectMode");
			var object = oSolutionsModel.getProperty(sPath);
			var levelCount = object.LevelCount;
			var L5Map = oSolutionsModel.getProperty("/L5Map");
			var l4TempObj = $.extend(true, {}, L5Map[object["L5Id"]]);
			if (MatTblSelectMode === "MultiSelect") {
				switch (levelCount) {
					case 4:
						var l4Data = this.fnCheckL4SolutionObjects(object, oSolTempArr, oMatTempArr, OppSolTempArr, oSource.getSelected());
						oSolTempArr = l4Data[0];
						oMatTempArr = l4Data[1];
						OppSolTempArr = l4Data[2];
						break;
					case 5:
						var l5Data = this.fnMultiCheckL5SolObjects(object, oSolTempArr, oMatTempArr, OppSolTempArr, oSource.getSelected());
						oSolTempArr = l5Data[0];
						oMatTempArr = l5Data[1];
						OppSolTempArr = l5Data[2];
						break;
				}
				var solArr = $.extend(true, [], oSolTempArr);
				var SolTokens = solArr.concat(oMatTempArr);
				var displayTokens = this.parentController.fnGetDisplayTokens(SolTokens);
				oSolutionsModel.setProperty("/DisplayTokens", displayTokens);
			} else {
				oSolTempArr = [];
				OppSolTempArr = [];
				var tempObj = $.extend(true, {}, object);
				oSolTempArr.push(tempObj);
				switch (levelCount) {
					case 5:
						oSolTempArr = this.fnUpdateSolutionTempArr(l4TempObj, oSolTempArr, true, false);
						break;
				}
				this.byId("idMaterailMTbl").removeSelections();
				oSolutionsModel.setProperty("/oMatTempArr", []);
				oSolutionsModel.setProperty("/DisplayTokens", oSolTempArr);
				var isOppoTabVisible = oSolutionsModel.getProperty("/isOppoTabVisible");
				if (isOppoTabVisible) {
					var OppoMaterials = oSolutionsModel.getProperty("/OppoMaterials");
					var bVal = this.fnFindOppObjInArray(object, OppoMaterials, false);
					if (bVal) {
						OppSolTempArr = this.fnUpdateSolutionTempArr(tempObj, OppSolTempArr, false);
					}
				}
			}
			oSolutionsModel.setProperty("/oSolTempArr", oSolTempArr);
			oSolutionsModel.setProperty("/OppSolTempArr", OppSolTempArr);
			this.fnSetSelectedSolMatData();
			oSolutionsModel.refresh(true);
		},

		//Function to  check/uncheck Checkboxes or delete tokens on L4 objects and its corresponding L5 objects
		fnCheckL4SolutionObjects: function (object, oSolTempArr, oMatTempArr, OppSolTempArr, isSelected, isTokenDelete) {
			var oSolutionsModel = this.parentView.getModel("oSolutionsModel");
			var isOppoTabVisible = oSolutionsModel.getProperty("/isOppoTabVisible");
			if (isSelected === false) {
				var aL4Levels = object.Levels;
				for (var i = 0; i < aL4Levels.length; i++) {
					var index = this.fnFindObjInArray(aL4Levels[i], oSolTempArr);
					if (index >= 0) {
						aL4Levels[i].isSelected = false;
						oSolTempArr = this.fnUpdateSolutionTempArr(aL4Levels[i], oSolTempArr, false);
						oMatTempArr = this.fnRemoveSolMaterials("L5Id", aL4Levels[i], oMatTempArr);
						if (isOppoTabVisible) {
							OppSolTempArr = this.fnUpdateSolutionTempArr(aL4Levels[i], OppSolTempArr, false);
						}
					}
				}
				object.isSelected = !object.isSelected;
				oMatTempArr = this.fnRemoveSolMaterials("L4Id", object, oMatTempArr);
			}
			oSolTempArr = this.fnUpdateSolutionTempArr(object, oSolTempArr, false);
			if (isOppoTabVisible) {
				var OppoMaterials = oSolutionsModel.getProperty("/OppoMaterials");
				var bVal = this.fnFindOppObjInArray(object, OppoMaterials, false);
				if (bVal) {
					OppSolTempArr = this.fnUpdateSolutionTempArr(object, OppSolTempArr, false);
				}
			}
			return [oSolTempArr, oMatTempArr, OppSolTempArr];
		},

		//Function to delete Solution/Material tokens from Dialog and Form Multi input field 
		//Below function triggers from 2 fields and fires event 4 times
		fnDeleteSolMatTokens: function (oEvent) {
			var index, sPath, fldType;
			var oSource = oEvent.getSource();
			var oSolutionsModel = this.parentView.getModel("oSolutionsModel");
			var oSlDetailModel = this.parentView.getModel("SlDetailModel");
			if (oSource.getBindingContext("oSolutionsModel")) {
				sPath = oSource.getBindingContext("oSolutionsModel").getPath();
			} else {
				var oToken = oEvent.getParameter("removedTokens")[0];
				sPath = oToken.getBindingContext("oSolutionsModel").getPath();
			}
			if (oSource.getCustomData()[0]) {
				fldType = oSource.getCustomData()[0].getKey();
			}
			var deletedObj = oSolutionsModel.getProperty(sPath);
			var oSolTempArr = oSolutionsModel.getProperty("/oSolTempArr");
			var oMatTempArr = oSolutionsModel.getProperty("/oMatTempArr");
			var OppSolTempArr = oSolutionsModel.getProperty("/OppSolTempArr");
			if (!deletedObj.LevelCount) {
				index = this.fnFindObjInArray(deletedObj, oMatTempArr, true);
				oMatTempArr.splice(index, 1);
			} else {
				var levelCount = deletedObj.LevelCount;
				if (levelCount === 4) {
					var l4Data = this.fnCheckL4SolutionObjects(deletedObj, oSolTempArr, oMatTempArr, OppSolTempArr, false, true);
					oSolTempArr = l4Data[0];
					oMatTempArr = l4Data[1];
					OppSolTempArr = l4Data[2];
				} else if (levelCount === 5) {
					var l5Data = this.fnMultiCheckL5SolObjects(deletedObj, oSolTempArr, oMatTempArr, OppSolTempArr, false, true);
					oSolTempArr = l5Data[0];
					oMatTempArr = l5Data[1];
					OppSolTempArr = l5Data[2];
				}
			}
			var SolTokens = oSolTempArr.concat(oMatTempArr);
			var displayTokens = this.parentController.fnGetDisplayTokens(SolTokens);
			oSolutionsModel.setProperty("/DisplayTokens", displayTokens);
			if (fldType === "SOL_MULTI_SELECT") {
				var oPayload = this.fnGetSolMatPayload(oSolTempArr, oMatTempArr);
				oSolutionsModel.setProperty("/to_ATaxonomy", oSolTempArr);
				oSolutionsModel.setProperty("/to_AMaterial", oMatTempArr);
				oSlDetailModel.setProperty("/to_ATaxonomy", oPayload[0]);
				oSlDetailModel.setProperty("/to_AMaterial", oPayload[1]);
				oSolutionsModel.setProperty("/SolTokens", displayTokens);
				if (oSolTempArr.length > 0) {
					this.parentView.byId("additionalSolutions").setValueState("None");
				}
			} else {
				oSolutionsModel.setProperty("/oSolTempArr", oSolTempArr);
				oSolutionsModel.setProperty("/oMatTempArr", oMatTempArr);
			}
			this.fnSetSelectedSolMatData();
			this.fnUpdateSolOnDeleteTokens(deletedObj);
			oSolutionsModel.refresh(true);
		},

		//Function to update isSelected property on delete of solution token
		fnUpdateSolOnDeleteTokens: function (deleteToken) {
			var oSolutionsModel = this.parentView.getModel("oSolutionsModel");
			var SelLvlHierarchy = oSolutionsModel.getProperty("/SelectedLevelHierarchy");
			SelLvlHierarchy.find(function (l3Obj, l3Index) {
				l3Obj.Levels.find(function (l4Obj, l4Index) {
					var bVal = true;
					if (l4Obj["LevelCount"] === deleteToken["LevelCount"]) {
						if (l4Obj["L4Id"] === deleteToken["LevelId"]) {
							l4Obj.isSelected = false;
						}
					} else {
						l4Obj.Levels.find(function (l5Obj, l5Index) {
							if (l5Obj["LevelCount"] === deleteToken["LevelCount"] && l5Obj["L5Id"] === deleteToken["LevelId"]) {
								l5Obj.isSelected = false;
								bVal = false;
							}
						})
						if (!bVal) {
							l4Obj.isSelected = false;
						}
					}
				})
			});
			oSolutionsModel.setProperty("/SelectedLevelHierarchy", SelLvlHierarchy);
			oSolutionsModel.refresh(true);
		},

		//Function to push/remove selected/deselectd solutions
		fnUpdateSolutionTempArr: function (object, oSolTempArr, isParent, isL4Visible) {
			var tempObj = $.extend(true, {}, object);
			var index = this.fnFindObjInArray(tempObj, oSolTempArr);
			if (index === undefined) {
				tempObj.isParent = isParent;
				tempObj.ValueState = isParent ? "Information" : "None";
				oSolTempArr.push(tempObj);
			} else {
				if (!isParent) {
					oSolTempArr[index].ValueState = "None";
					oSolTempArr.splice(index, 1);
				} else if (isParent && isL4Visible) {
					oSolTempArr[index].isParent = false;
					oSolTempArr[index].isSelected = true;
					oSolTempArr[index].ValueState = "None";
				} else if (isParent && !isL4Visible) {
					oSolTempArr[index].isParent = true;
					oSolTempArr[index].ValueState = "Information";
				}
			}
			return oSolTempArr;
		},

		//Function to  check/uncheck Checkboxes or delete tokens on L5 objects and its parent L4 objects
		fnMultiCheckL5SolObjects: function (object, oSolTempArr, oMatTempArr, OppSolTempArr, isSelected, isTokenDelete) {
			var isL4Visible = false;
			var oSolutionsModel = this.parentView.getModel("oSolutionsModel");
			var L5Map = oSolutionsModel.getProperty("/L5Map");
			var isOppoTabVisible = oSolutionsModel.getProperty("/isOppoTabVisible");
			var l4TempObj = $.extend(true, {}, L5Map[object["L5Id"]]);
			if (isTokenDelete) {
				object.isSelected = isSelected;
			} else {
				object.isSelected = !object.isSelected;
			}
			oSolTempArr = this.fnUpdateSolutionTempArr(object, oSolTempArr, false);
			if (isSelected === false) {

				oMatTempArr = this.fnRemoveSolMaterials("L5Id", object, oMatTempArr);
				isL4Visible = this.fnGetAllL4sL5Objs(object, oSolTempArr);
			}
			oSolTempArr = this.fnUpdateSolutionTempArr(l4TempObj, oSolTempArr, true, isL4Visible);
			if (isOppoTabVisible) {
				var OppoMaterials = oSolutionsModel.getProperty("/OppoMaterials");
				var bVal = this.fnFindOppObjInArray(object, OppoMaterials, false);
				if (bVal) {
					OppSolTempArr = this.fnUpdateSolutionTempArr(object, OppSolTempArr, false);
					OppSolTempArr = this.fnUpdateSolutionTempArr(l4TempObj, OppSolTempArr, true, isL4Visible);
				}
			}
			//Below code is executed when last L5 token is deleted and its corresponding L4 will be deleted
			//In case of Checkbox selection, when L5 is unchecked, L4 will still be present.
			if (isTokenDelete && isL4Visible) {
				var l4Data = this.fnCheckL4SolutionObjects(l4TempObj, oSolTempArr, oMatTempArr, OppSolTempArr, true);
				oSolTempArr = l4Data[0];
				oMatTempArr = l4Data[1];
				OppSolTempArr = l4Data[2];
			}
			return [oSolTempArr, oMatTempArr, OppSolTempArr];
		},

		//Function to find if soltempArr l5 objs are unselected for L4
		//gets executed when L5 gets unchecked, and if its L4 should be shown in display tokens
		fnGetAllL4sL5Objs: function (l5TempObj, oSolTempArr) {
			var iCount = 0;
			var bVal = false;
			var oSolutionsModel = this.parentView.getModel("oSolutionsModel");
			var L4Map = oSolutionsModel.getProperty("/L4Map");
			var oL4Array = L4Map[l5TempObj["L4Id"]];
			for (var i = 0; i < oL4Array.length; i++) {
				var index = this.fnFindObjInArray(oL4Array[i], oSolTempArr);
				if (index >= 0) {
					iCount += 1;
				}
			}
			if (iCount === 0) {
				bVal = true;
			}
			return bVal;
		},

		//Function to find if an object already exists in array
		fnFindOppObjInArray: function (object, Array) {
			var bVal = false;
			if (Array) {
				Array.find(function (obj, index) {
					if (obj["L2Id"] === object["L2Id"]) {
						if (obj["L3Id"] === object["L3Id"]) {
							if (obj["L4Id"] === object["L4Id"]) {
								bVal = true;
							}
						}
					}
				});
			}
			return bVal;
		},

		//Function to find if an object already exists in array
		fnFindObjInArray: function (object, Array, isMaterial) {
			var sIndex;
			Array.find(function (obj, index) {
				if (isMaterial) {
					if (obj.MatId === object.MatId) {
						sIndex = index;
					}
				} else {
					var levelId = "L" + obj.LevelCount + "Id";
					if (obj.LevelCount === object.LevelCount && obj[levelId] === object[levelId]) {
						sIndex = index;
					}
				}
			});
			return sIndex;
		},

		//Function to un-check materials when a solution is unchecked
		fnRemoveSolMaterials: function (levelId, oSolutionObj, oMatTempArr) {
			var length = oMatTempArr.length - 1;
			for (var i = length; i >= 0; i--) {
				var oMatObj = oMatTempArr[i];
				if (oMatObj[levelId] === oSolutionObj[levelId]) {
					oMatTempArr.splice(i, 1);
				}
			}
			return oMatTempArr;
		},

		//Function to set selected solution's material data to table
		fnSetSelectedSolMatData: function (isOpportunity) {
			var that = this;
			var aFilters = [];
			var matTblFilter = new Filter({
				filters: aFilters
			});
			var oSolutionsModel = this.parentView.getModel("oSolutionsModel");
			if (oSolutionsModel.getProperty("/isMatTblVisible")) {
				var ITBSelectedKey = oSolutionsModel.getProperty("/ITBSelectedKey");
				oSolutionsModel.setProperty("/isGridLayBusy", true);
				setTimeout(function () {
					var oMaterialTree = that.parentView.byId("idMaterailMTbl");
					if (ITBSelectedKey === "FROM_OPPORTUNITY") {
						var OppSolTempArr = oSolutionsModel.getProperty("/OppSolTempArr");
						for (var i = 0; i < OppSolTempArr.length; i++) {
							//if (!OppSolTempArr[i].isParent) {
							var sProperty = "L" + OppSolTempArr[i].LevelCount + "Id";
							var sDesc = OppSolTempArr[i][sProperty];
							var oLevelFilter = new Filter({
								filters: [new Filter("isOpportunity", "EQ", true), new Filter(sProperty, "EQ", sDesc)],
								and: true
							});
							aFilters.push(oLevelFilter);
							//}
						}
					} else {
						var oSolTempArr = oSolutionsModel.getProperty("/oSolTempArr");
						for (var i = 0; i < oSolTempArr.length; i++) {
							if (!oSolTempArr[i].isParent) {
								var oProperty = "L" + oSolTempArr[i].LevelCount + "Id";
								var oDesc = oSolTempArr[i][oProperty];
								var filter = new Filter(oProperty, "EQ", oDesc);
								aFilters.push(filter);
							}
						}
					}
					matTblFilter = new Filter({
						filters: aFilters,
						and: false
					});
					if (aFilters.length === 0) {
						oSolutionsModel.setProperty("/Materials", []);
					} else {
						var SolutionHierarchy = oSolutionsModel.getProperty("/SolutionHierarchy");
						oSolutionsModel.setProperty("/Materials", SolutionHierarchy);
						oMaterialTree.getBinding("items").filter(matTblFilter);
					}
					oSolutionsModel.setProperty("/isGridLayBusy", false);
				}, 1000);
			}
		},

		//Function to get selected objs on Checkbox/RadioBtn selection change from material table
		fnSetTblCheckRadioBtnSelected: function (oEvent) {
			var oSource = oEvent.getSource();
			if (!oSource.getVisible()) {
				return;
			}
			var oSolutionsModel = this.parentView.getModel("oSolutionsModel");
			var oSolTempArr = oSolutionsModel.getProperty("/oSolTempArr");
			var oMatTempArr = oSolutionsModel.getProperty("/oMatTempArr");
			var MatTblSelectMode = oSolutionsModel.getProperty("/MatTblSelectMode");
			var sPath = oSource.getBindingContext("oSolutionsModel").getPath();
			var object = oSolutionsModel.getProperty(sPath);
			var tempObj = $.extend(true, {}, object);
			if (MatTblSelectMode === "MultiSelect") {
				var sIndex = this.fnFindObjInArray(tempObj, oMatTempArr, true);
				if (sIndex === undefined) {
					tempObj.LevelId = tempObj.MatId;
					tempObj.LevelDesc = tempObj.MatDesc;
					oMatTempArr.push(tempObj);
				} else {
					oMatTempArr.splice(sIndex, 1);
				}
				var matArr = $.extend(true, [], oMatTempArr);
				var SolTokens = oSolTempArr.concat(matArr);
				var displayTokens = this.parentController.fnGetDisplayTokens(SolTokens);
				oSolutionsModel.setProperty("/oMatTempArr", oMatTempArr);
				oSolutionsModel.setProperty("/DisplayTokens", displayTokens);
			} else {
				oMatTempArr = [];
				tempObj.LevelId = tempObj.MatId;
				tempObj.LevelDesc = tempObj.MatDesc;
				oMatTempArr.push(tempObj);
				oSolutionsModel.setProperty("/DisplayTokens", oMatTempArr);
				oSolutionsModel.setProperty("/oMatTempArr", oMatTempArr);
			}
		},

		//Asset and document links changes
		//Function to open Assest/Docs link popover
		fnOpenAttachDocsPopover: function (oEvent) {
			var oSlDetailModel = this.parentView.getModel("SlDetailModel");
			var isEditMode = oSlDetailModel.getProperty("/isEditMode");
			var oMasterDataModel = this.parentView.getModel("masterData");
			var newLink = {
				"DocumentType": "0001",
				"Status": "X",
				"Url": "",
				"ProjectType": "ACTVT",
				"FileId": "",
				"FileName": "",
				"IsAddBtnVisible": true,
				"IsDelBtnVisible": false
			};
			if (!isEditMode && !oMasterDataModel.getProperty("/to_AFiles")) {
				oMasterDataModel.setProperty("/to_AFiles", [newLink]);
				oSlDetailModel.setProperty("/to_AFiles", []);
			} else {
				this.fnCloseEditAssestDocsPopover();
			}
			if (!this.EditAssestDocsPopover) {
				this.EditAssestDocsPopover = sap.ui.xmlfragment(this.parentView.getId(),
					"com.presalescentral.successline.fragments.EditAssestDocsPopover", this);
				this.parentView.addDependent(this.EditAssestDocsPopover);
			}
			this.EditAssestDocsPopover.open();
		},

		//Function to Delete Filename and URL in Assest/Docs link popover
		deleteNewAssetDocLink: function (oEvent) {
			var oSource = oEvent.getSource();
			var oMasterDataModel = this.parentView.getModel("masterData");
			var to_AFiles = oMasterDataModel.getProperty("/to_AFiles");
			var sPath = oSource.getBindingContext("masterData").getPath();
			var index = parseInt(sPath.split("/")[2], 10);
			to_AFiles.splice(index, 1);
			oMasterDataModel.setProperty("/to_AFiles", to_AFiles);
		},

		//Function to validate and Add Filename and URL in Assest/Docs link popover
		addNewAssetDocLink: function (oEvent, oData) {
			var oMasterDataModel = this.parentView.getModel("masterData");
			if (oEvent) {
				var oSource = oEvent.getSource();
				var sPath = oSource.getBindingContext("masterData").getPath();
				oData = oMasterDataModel.getProperty(sPath);
			}
			if (oData.FileName && oData.Url && oData.UrlState !== "Error") {
				var oNewLink = {
					"DocumentType": "0001",
					"Status": "X",
					"Url": "",
					"ProjectType": "ACTVT",
					"FileId": "",
					"FileName": "",
					"IsAddBtnVisible": true,
					"IsDelBtnVisible": false
				};
				oData.IsAddBtnVisible = false;
				oData.IsDelBtnVisible = true;
				var to_AFiles = oMasterDataModel.getProperty("/to_AFiles");
				var oArray = [oNewLink];
				oArray = oArray.concat(to_AFiles);
				oMasterDataModel.setProperty("/to_AFiles", oArray);
				this.dataChange = true;
			} else if (!oData.FileName && oData.Url) {
				sap.m.MessageToast.show("Please enter Display name");
			} else if (oData.FileName && (!oData.Url || oData.UrlState === "Error")) {
				sap.m.MessageToast.show("Please enter valid URL");
			} else {
				sap.m.MessageToast.show("Please enter Display name and URL");
			}
		},

		//Functio to close Assest/Docs link popover
		fnCloseEditAssestDocsPopover: function () {
			var to_AFiles = this.parentView.getModel("SlDetailModel").getProperty("/to_AFiles");
			to_AFiles = $.extend(true, [], to_AFiles);
			var oNewLink = {
				"DocumentType": "0001",
				"Status": "X",
				"Url": "",
				"ProjectType": "ACTVT",
				"FileId": "",
				"FileName": "",
				"IsAddBtnVisible": true,
				"IsDelBtnVisible": false
			};
			var oArray = [oNewLink];
			oArray = oArray.concat(to_AFiles);
			this.parentView.getModel("masterData").setProperty("/to_AFiles", oArray);
			if (this.EditAssestDocsPopover) {
				this.EditAssestDocsPopover.close();
			}
		},

		fnSetUpdatedLinksToDefaultModel: function () {
			var oMasterDataModel = this.parentView.getModel("masterData");
			var to_AFiles = oMasterDataModel.getProperty("/to_AFiles");
			if (to_AFiles[0].FileName && to_AFiles[0].Url) {
				this.addNewAssetDocLink("", to_AFiles[0]);
			}
			var bVal = this.fnValidateMissingDocNameLinks();
			if (bVal) {
				to_AFiles = oMasterDataModel.getProperty("/to_AFiles");
				to_AFiles = $.extend(true, [], to_AFiles);
				to_AFiles.splice(0, 1);
				this.parentView.getModel("SlDetailModel").setProperty("/to_AFiles", to_AFiles);
				this.EditAssestDocsPopover.close();
			} else {
				MessageToast.show("Please fill in missing/valid entries");
			}
		},

		//Function to validate if any Doc link or Doc name is missing in any rows
		fnValidateMissingDocNameLinks: function () {
			var SuccessCount = 0,
				ErrorCount = 0;
			var oMasterDataModel = this.parentView.getModel("masterData");
			var to_AFiles = oMasterDataModel.getProperty("/to_AFiles");
			to_AFiles.filter(function (File, index) {
				if (index === 0) {
					if (File.UrlState === "Error") {
						ErrorCount = ErrorCount + 1;
					} else {
						SuccessCount = SuccessCount + 1;
					}
					return;
				}
				if (File.UrlState === "Error") {
					ErrorCount = ErrorCount + 1;
				} else if (File.FileName && File.Url) {
					File.UrlState = "None";
					File.FileNameState = "None";
					SuccessCount = SuccessCount + 1;
				} else if (!File.FileName && File.Url) {
					File.UrlState = "None";
					File.FileNameState = "Error";
					ErrorCount = ErrorCount + 1;
				} else if (File.FileName && !File.Url) {
					File.UrlState = "Error";
					File.FileNameState = "None";
					ErrorCount = ErrorCount + 1;
				} else if (!File.FileName && !File.Url) {
					File.UrlState = "Error";
					File.FileNameState = "Error";
					ErrorCount = ErrorCount + 1;
				}
			});
			oMasterDataModel.setProperty("/to_AFiles", to_AFiles);
			if (to_AFiles.length === SuccessCount) {
				return true;
			} else {
				return false;
			}
		},

		//Function to validate if user's input is a valid URL 
		fnValidateAssetDocLink: function (oEvent) {
			var oSource = oEvent.getSource();
			var oValue = oSource.getValue();
			var sPath = oSource.getBindingContext("masterData").getPath();
			var oMasterDataModel = this.parentView.getModel("masterData");
			if (oValue) {
				var regexQuery =
					/^((([A-Za-z]{3,9}:(?:\/\/)?)(?:[\-;:&=\+\$,\w]+@)?[A-Za-z0-9\.\-]+|(?:www\.|[\-;:&=\+\$,\w]+@)[A-Za-z0-9\.\-]+)((?:\/[\+~%\/\.\w\-_]*)?\??(?:[\-\+=&;%@\.\w_]*)#?(?:[\.\!\/\\\w]*))?)/g;
				if (!regexQuery.test(oValue)) {
					oMasterDataModel.setProperty(sPath + "/UrlState", "Error");
				} else {
					oMasterDataModel.setProperty(sPath + "/UrlState", "None");
				}
			} else {
				oMasterDataModel.setProperty(sPath + "/UrlState", "None");
			}
		},

		onLinkNameLiveChange: function (oEvent) {
			oEvent.getSource().setValueState("None");
		},

		//Landscape changes
		addLandscapes: function () {
			if (!this.oLandscapeDialog) {
				this.oLandscapeDialog = sap.ui.xmlfragment(this.parentView.getId(),
					"com.presalescentral.successline.fragments.addLandscape", this);
				this.parentView.addDependent(this.oLandscapeDialog);
				this.setLandscapeSelected(false);
			} else {
				this.setLandscapeSelected(true);
			}
			this.oLandscapeDialog.open();
		},

		setLandscapeSelected: function (isDialogLoaded) {
			var that = this;
			var oMasterDataModel = this.parentView.getModel("masterData");
			var oSlDetailModel = this.parentView.getModel("SlDetailModel");
			var isEditMode = oSlDetailModel.getProperty("/isEditMode");
			var data = oMasterDataModel.getProperty("/landscape");
			var oLTypeMap = {};
			for (var i in data) {
				if (!oLTypeMap.hasOwnProperty(data[i].Ltype) && data[i].LTypeDescription !== "") {
					oLTypeMap[data[i].Ltype] = data[i].LTypeDescription;
				}
				if (that.landscapeMap.hasOwnProperty(data[i].LandsId) && data[i].SelectionCat === "Master") {
					data[i].selected = true;
					data[i].prevSelected = true;
				} else {
					data[i].selected = false;
					data[i].prevSelected = false;
				}
			}
			oMasterDataModel.setProperty("/LTypeMap", oLTypeMap);
			oMasterDataModel.setProperty("/landscape", data);
			if (!isDialogLoaded) {
				oMasterDataModel.setProperty("/isLandscapeExpanded", true);
				data = that.fnFormatFlatToTreeData(data, "SelectionCat");
				data = that.fnRestructureTreeData(data, "SelectionCat", "landscape");
				oMasterDataModel.setProperty("/LTypeMap", oLTypeMap);
				oMasterDataModel.setProperty("/landscape", data);
				// that.fnDemoEnvSortMenuAction();
				if (that.parentView.byId("idLandscapeTable")) {
					that.parentView.byId("idLandscapeTable").setBusy(false);
				}
				that.fnDemoEnvExpandCollapseAll("", "landscape", "landscapeSearchField", true);
				that.fnSetSAPDemoECSelectAll("landscape", "isLandscapeSelectAll");
				that.fnSetTreeTableVisibleRowCount("idLandscapeTable", "landscapeRowCount");
				oMasterDataModel.setProperty("/TblSortedOption", "SelectionCat");
			}
			this.parentView.byId("landscapeSearchField").setValue();
			this.parentView.byId("landscapeSearchField").fireLiveChange();
			var landscapes = oSlDetailModel.getProperty("/to_ALand") ? oSlDetailModel.getProperty("/to_ALand") : [];
			oMasterDataModel.setProperty("/landscapeCount", landscapes.length);
			oMasterDataModel.setProperty("/to_ALand", structuredClone(landscapes));
			oMasterDataModel.refresh();

		},

		//Function to format flat to tree structure data
		fnFormatFlatToTreeData: function (oData, property, removeRecentSelections) {
			return oData.reduce(function (acc, obj) {
				var key = obj[property];
				if (!acc[key]) {
					acc[key] = [];
				}
				// Add object to list for given key's value
				if ((removeRecentSelections && obj.SelectionCat !== "Recent Selection") || !removeRecentSelections)
					acc[key].push(obj);
				return acc;
			}, {});
		},

		//Function to group data in tree structure
		fnRestructureTreeData: function (oData, oFieldProperty, oArrayProperty) {
			var oTempArr = [];
			var oKeys = Object.keys(oData);
			for (var i = 0; i < oKeys.length; i++) {
				var oTempObj = {};
				oTempObj["isParent"] = true;
				oTempObj["isExpanded"] = true;
				oTempObj[oFieldProperty] = oKeys[i];
				oTempObj[oArrayProperty] = oData[oKeys[i]];
				oTempArr.push(oTempObj);
			}
			return oTempArr;
		},

		onCloseLandscapeDialog: function (oEvent) {
			this.oLandscapeDialog.close();
			this.fnSelectAllLandscape("", true);
		},

		//Function to select all SAP Demo EC rows
		fnSelectAllLandscape: function (oEvent, isCancel, deletedObj) {
			this.fnDemoEnvSelectAll(oEvent, isCancel, deletedObj, "landscape", "isLandscapeSelectAll");
		},

		//Common function to select all items in SAPDemoEC and Landscape array
		fnDemoEnvSelectAll: function (oEvent, isCancel, deletedObj, treeBindingPath, selectAllPath) {
			if (oEvent) {
				var bVal = oEvent.getSource().getSelected();
			}
			var oMasterDataModel = this.parentView.getModel("masterData");
			var sapDemoEc = oMasterDataModel.getProperty("/" + treeBindingPath);
			sapDemoEc.filter(function (parentObj) {
				parentObj[treeBindingPath].filter(function (childObj) {
					if (isCancel) {
						childObj.selected = childObj.prevSelected;
					} else if (deletedObj) {
						if (childObj.LandsId === deletedObj.LandsId && childObj.LandDescription === deletedObj.LandDescription) {
							childObj.selected = false;
							childObj.prevSelected = false;
						}
					} else {
						childObj.selected = bVal;
					}
				});
			});
			oMasterDataModel.setProperty("/" + treeBindingPath, sapDemoEc);
			this.fnSetSAPDemoECSelectAll(treeBindingPath, selectAllPath);
		},

		fnSetTreeTableVisibleRowCount: function () {
			var oBindings = this.parentView.byId("idLandscapeTable").getBinding("rows");
			oBindings.attachFilter(function (evt) {
				var oSource = evt.getSource();
				var length = oSource.getLength();
				if (length) {
					var masterDataModel = oSource.getModel("masterData");
					masterDataModel.setProperty("/landscapeRowCount", length);
					masterDataModel.refresh();
				}
			});
		},

		fnSingleSelectLandscape: function (oEvent) {
			this.fnSingleSelectDemoEnv(oEvent, "landscape", "isLandscapeSelectAll");
		},

		fnSingleSelectDemoEnv: function (oEvent, bindingProperty, selectAllPath) {
			var oSoure = oEvent.getSource();
			var bVal = oSoure.getSelected();
			// var masterDataModel = this.masterDataModel;
			var oMasterDataModel = this.parentView.getModel("masterData");
			var sPath = oSoure.getBindingContext("masterData").getPath();
			var object = oMasterDataModel.getProperty(sPath);
			var oArray = oMasterDataModel.getProperty("/" + bindingProperty);
			var bLandScapeExists = false;
			oArray.filter(function (parentObj) {
				parentObj[bindingProperty].filter(function (childObj) {
					if (childObj.LandsId === object.LandsId && childObj.LandDescription === object.LandDescription && childObj.LandscapeId ===
						object.LandscapeId) {
						childObj.selected = bVal;
					}
					if (childObj.LandsId === object.LandsId && childObj.LandDescription === object.LandDescription && childObj.selected) {
						bLandScapeExists = true;
					}
				});
			});
			oMasterDataModel.setProperty("/" + bindingProperty, oArray);
			this.fnSetSAPDemoECSelectAll(bindingProperty, selectAllPath);
			var landscapes = oMasterDataModel.getProperty("/to_ALand");
			var landscapesMap = {};
			landscapes.forEach(each => landscapesMap[each['LandsId']] = each);
			if (bVal && !landscapesMap[object['LandsId']]) {
				landscapes.push(object)
			} else if (!bVal && !bLandScapeExists) {
				landscapes = landscapes.filter(each => each.LandsId !== object.LandsId)
			}
			oMasterDataModel.setProperty("/to_ALand", landscapes);
			oMasterDataModel.setProperty("/landscapeCount", landscapes.length);
		},

		//Common function to set Select All button selected in SAPDemoEC and Landscape
		fnSetSAPDemoECSelectAll: function (treeBindingPath, selectAllPath) {
			var totalObjCount = 0;
			var objSelectedCount = 0;
			var oMasterDataModel = this.parentView.getModel("masterData");
			var sapDemoEc = oMasterDataModel.getProperty("/" + treeBindingPath);
			sapDemoEc.filter(function (parentObj) {
				totalObjCount = totalObjCount + parentObj[treeBindingPath].length;
				parentObj[treeBindingPath].filter(function (childObj) {
					if (childObj.selected) {
						objSelectedCount++;
					}
				});
			});
			if (totalObjCount === objSelectedCount) {
				oMasterDataModel.setProperty("/" + selectAllPath, true);
			} else {
				oMasterDataModel.setProperty("/" + selectAllPath, false);
			}
		},

		//Common function to search tree table in SAPDemoEC and Landscape
		fnSearchDemoEvTbl: function (oEvent, oTable) {
			var aFilter = [];
			var searchString = oEvent.getSource().getValue();
			if (searchString !== "") {
				var filter1 = new Filter({
					filters: [
						new Filter("LandDescription", "Contains", searchString),
						new Filter("LTypeDescription", "Contains", searchString),
						new Filter("Location", "Contains", searchString),
						new Filter("Product", "Contains", searchString)
					],
					and: false
				});
				aFilter.push(filter1)
			}
			oTable.getBinding("rows").filter(aFilter);
		},

		//Common function to expand/collapse all rows in tree table in SAPDemoEC and Landscape
		fnDemoEnvExpandCollapseAll: function (oEvent, bindingProperty, searchFldId, isTblExpanded) {
			var oMasterDataModel = this.parentView.getModel("masterData");
			if (oEvent) {
				var oSource = oEvent.getSource();
				searchFldId = oSource.getCustomData()[0].getValue();
				bindingProperty = oSource.getCustomData()[0].getKey();
				var isExpandedProp = oSource.getCustomData()[1].getKey();
				var oTreeTable = oSource.getCustomData()[1].getValue();
				isTblExpanded = oMasterDataModel.getProperty("/" + isExpandedProp);
			}
			this.fnUpdateDemoEnvExpandedObj(isTblExpanded, bindingProperty);
			this.fnSetTblRowsCount(bindingProperty, searchFldId);
			if (oTreeTable) {
				var oSortItem = oMasterDataModel.getProperty("/TblSortedOption");
				this.fnFilterDemoLandscapeTbl(oSortItem, oTreeTable);
			}
			if (searchFldId && this.parentView.byId(searchFldId)) {
				if (this.parentView.byId(searchFldId).getValue()) {
					this.parentView.byId(searchFldId).fireLiveChange();
				}
			}
		},

		//Common function to update visible row count in tree table in SAPDemoEC and Landscape
		fnSetTblRowsCount: function (bindingProperty, searchFldId) {
			this.fnGetExpandedRowsLength("", bindingProperty, "landscapeRowCount", "isLandscapeExpanded", "idLandscapeTable");
		},

		//Common function to get visible row count in tree table in SAPDemoEC and Landscape
		fnGetExpandedRowsLength: function (oEvent, bindingProperty, visibleRowCount, isAllRowsExpanded, treeTableId) {
			var oLength = 0;
			var expandedLen = 0;
			var collapsedLen = 0;
			var searchFldId = "";
			var masterDataModel = this.parentView.getModel("masterData");
			if (oEvent) {
				var oParameters = oEvent.getParameters();
				var isExpanded = oParameters.expanded;
				var sPath = oParameters.rowContext.getPath();
				masterDataModel.setProperty(sPath + "/isExpanded", isExpanded);
				bindingProperty = sPath.split("/")[1];

				treeTableId = "idLandscapeTable";
				searchFldId = "landscapeSearchField";
				visibleRowCount = "landscapeRowCount";
				isAllRowsExpanded = "isLandscapeExpanded";
			}
			var oData = masterDataModel.getProperty("/" + bindingProperty);
			oData.filter(function (objHeirarchy1) {
				oLength = oLength + 1;
				if (objHeirarchy1.isExpanded) {
					expandedLen = expandedLen + 1;
					var sapDemoEc = objHeirarchy1[bindingProperty];
					if (sapDemoEc) {
						oLength = oLength + sapDemoEc.length;
					}
				} else {
					collapsedLen = collapsedLen + 1;
				}
			});
			masterDataModel.setProperty("/" + visibleRowCount, oLength);
			if (oData.length === expandedLen) {
				if (this.parentView.byId(treeTableId)) {
					this.parentView.byId(treeTableId).expandToLevel(1);
				}
				masterDataModel.setProperty("/" + isAllRowsExpanded, false);
			} else if (oData.length === collapsedLen) {
				if (this.parentView.byId(treeTableId)) {
					this.parentView.byId(treeTableId).collapseAll();
				}
				masterDataModel.setProperty("/" + isAllRowsExpanded, true);
			}
			if (this.parentView.byId(searchFldId)) {
				this.parentView.byId(searchFldId).fireLiveChange();
			}
		},

		//Common function to update selected property in tree table in SAPDemoEC and Landscape
		fnUpdateDemoEnvExpandedObj: function (isExpanded, bindingProperty) {
			var oData = this.parentView.getModel("masterData").getProperty("/" + bindingProperty);
			if (oData) {
				oData.filter(function (objHeirarchy1) {
					objHeirarchy1.isExpanded = isExpanded;
				});
			}
			this.parentView.getModel("masterData").setProperty("/" + bindingProperty, oData);
		},

		//Common function to delete SAP Demo or Landscape
		fnDeleteLandscape: function (oEvent,) {
			var oSource = oEvent.getSource();
			var oMasterDataModel = this.parentView.getModel("masterData");
			var oSlDetailModel = this.parentView.getModel("SlDetailModel");
			// var defaultModel = this.defaultModel;
			// var masterDataModel = this.masterDataModel;
			var bindingProperty = oSource.getCustomData()[0].getKey();
			var selectAllProperty = oSource.getCustomData()[0].getValue();
			var sapDemoEc = oMasterDataModel.getProperty("/" + bindingProperty);
			var to_ALand = oSlDetailModel.getProperty("/to_ALand");
			if (oSlDetailModel.getProperty("/Authorized") !== "") {
				// var sPath = oSource.getBindingContextPath("default");
				var sPath = oEvent.getParameter("removedTokens")[0].getBindingContext('SlDetailModel').getPath();
				var oDeletedObj = oSlDetailModel.getProperty(sPath);
				this.fnSelectAllSapDemoEc("", "", oDeletedObj, bindingProperty, selectAllProperty);
				var index = sPath.split("/")[2];
				to_ALand.splice(index, 1);
			}
			oSlDetailModel.setProperty("/to_ALand", to_ALand);
			// this.fnSetCustomCardDeleteIcon(bindingProperty);
		},

		//Function to select all SAP Demo EC rows
		fnSelectAllSapDemoEc: function (oEvent, isCancel, deletedObj, bindingProp, isSelectAllProp) {
			this.fnDemoEnvSelectAll(oEvent, isCancel, deletedObj, bindingProp, isSelectAllProp);
		},

		//Common function to select all items in SAPDemoEC and Landscape array
		fnDemoEnvSelectAll: function (oEvent, isCancel, deletedObj, treeBindingPath, selectAllPath) {
			if (oEvent) {
				this.dataChange = true;
				var bVal = oEvent.getSource().getSelected();
			}
			var masterDataModel = this.parentView.getModel("masterData");
			// var oMasterDataModel = this.parentView.getModel("masterData");
			var sapDemoEc = masterDataModel.getProperty("/" + treeBindingPath);
			sapDemoEc.filter(function (parentObj) {
				parentObj[treeBindingPath].filter(function (childObj) {
					if (isCancel) {
						childObj.selected = childObj.prevSelected;
					} else if (deletedObj) {
						if (childObj.LandsId === deletedObj.LandsId && childObj.LandDescription === deletedObj.LandDescription) {
							childObj.selected = false;
							childObj.prevSelected = false;
						}
					} else {
						childObj.selected = bVal;
					}
				});
			});
			masterDataModel.setProperty("/" + treeBindingPath, sapDemoEc);
			this.fnSetSAPDemoECSelectAll(treeBindingPath, selectAllPath);
		},

		onDeleteLandscape: function (oEvent, landscape) {
			var oSource = oEvent.getSource();
			// var defaultModel = this.defaultModel;
			// var masterDataModel = this.masterDataModel;
			var oMasterDataModel = this.parentView.getModel("masterData");
			var oSlDetailModel = this.parentView.getModel("SlDetailModel");
			var bindingProperty = oSource.getCustomData()[0].getKey();
			var selectAllProperty = oSource.getCustomData()[0].getValue();
			var sapDemoEc = oMasterDataModel.getProperty("/" + bindingProperty);
			var to_ALand = oMasterDataModel.getProperty("/to_ALand");
			// if (defaultModel.getProperty("/Authorized") !== "") {
			// var sPath = oSource.getBindingContextPath("default");
			var sPath = oEvent.getParameter("removedTokens")[0].getBindingContext('masterData').getPath()
			var oDeletedObj = oMasterDataModel.getProperty(sPath);
			this.fnSelectAllSapDemoEc("", "", oDeletedObj, bindingProperty, selectAllProperty);
			var index = sPath.split("/")[2];
			to_ALand.splice(index, 1);
			// }
			oMasterDataModel.setProperty("/to_ALand", to_ALand);
			oMasterDataModel.setProperty("/landscapeCount", to_ALand.length)
			// this.fnSetCustomCardDeleteIcon(bindingProperty);
		},

		//Common funtion to open sort options from SAP Demo EC and Landscape
		fnOpenDemoEnvSortOptions: function (oEvent) {
			if (!this.oDemoEnvSortMenu) {
				this.oDemoEnvSortMenu = sap.ui.xmlfragment(this.parentView.getId(),
					"com.presalescentral.successline.fragments.DemoEnvSortOptions", this);
				this.parentView.addDependent(this.oDemoEnvSortMenu);
			}
			this.oDemoEnvSortMenu.openBy(oEvent.getSource());
		},

		//Common function to sort the tree table in SAP Demo EC and Landscape
		fnDemoEnvSortMenuAction: function (oEvent) {
			var oTableId = "";
			var oSelectAll = "";
			var oSearchField = "";
			var oParentBinding = "";
			var oMasterDataModel = this.parentView.getModel("masterData");
			if (this.oLandscapeDialog) {
				// if (this.oLandscapeDialog.isOpen()) {
				oParentBinding = "landscape";
				oTableId = "idLandscapeTable";
				oSelectAll = "isLandscapeSelectAll";
				oSearchField = "landscapeSearchField";
				// }
			}
			if (oEvent) {
				var oSortItem = oEvent.getParameters().item.getCustomData()[0].getKey();
			} else {
				var oSortItem = "LTypeDescription";
			}
			var oData = oMasterDataModel.getProperty("/" + oParentBinding);
			oData = this.fnConvertTreeToFlatStruc(oData, oParentBinding);
			oData = [
				...new Map(oData.map(item => [`${item.LandsId}-${item.SelectionCat}`, item])).values() // remove duplicates
			];
			var recentSelections = oData.filter(each => each.SelectionCat === "Recent Selection")
			oData = this.parentController.fnFormatFlatToTreeData(oData, oSortItem, true);
			oData = this.parentController.fnRestructureTreeData(oData, "SelectionCat", oParentBinding);
			oData.sort((a, b) => (a.SelectionCat > b.SelectionCat) ? 1 : ((b.SelectionCat > a.SelectionCat) ? -1 : 0));
			oData.unshift({
				SelectionCat: "Recent Selection",
				isExpanded: true,
				isParent: true,
				landscape: recentSelections
			});
			oMasterDataModel.setProperty("/" + oParentBinding, oData);
			this.fnDemoEnvExpandCollapseAll("", oParentBinding, oSearchField, true);
			this.fnSetSAPDemoECSelectAll(oParentBinding, oSelectAll);
			this.fnFilterDemoLandscapeTbl(oSortItem, oTableId);
			oMasterDataModel.setProperty("/TblSortedOption", oSortItem);
			this.parentView.byId(oSearchField).fireLiveChange();
		},

		//Common functoion called for both SAP Demo and Landscape dialog
		fnAfterOpenDemoLandscapeDialog: function (oEvent) {
			this.fnDemoEnvSortMenuAction();
		},

		//Function to search Landscape table by description
		fnSearchLandscape: function (oEvent) {
			var oTable = this.parentView.byId("idLandscapeTable");
			this.fnSearchDemoEvTbl(oEvent, oTable);
		},

		//Common function to filter tree table in SAP Demo EC and Landscape data
		fnFilterDemoLandscapeTbl: function (oSortItem, oTableId) {
			if (!oSortItem) {
				return;
			} else if (oSortItem === "LTypeDescription") {
				var oFilter1 = new Filter("LTypeDescription", "NE", "");
				this.parentView.byId(oTableId).getBinding("rows").filter([oFilter1]);
			} else {
				this.parentView.byId(oTableId).getBinding("rows").filter([]);
			}
		},

		//Common function to convert tree to flat data structure
		fnConvertTreeToFlatStruc: function (oData, oParentBinding) {
			var oTempArr = [];
			if (oData) {
				oData.filter(function (object) {
					var oChildArr = object[oParentBinding];
					oTempArr = oTempArr.concat(oChildArr);
				});
			}
			return oTempArr;
		},

		//Common function to form to_ALand dataset from Landscape
		fnSetSelectedLandscapes: function () {
			this.onDemoEcLandscapeSelect("landscape");
		},

		//Common function to form to_ALand dataset from SAP Demo EC and Landscape
		onDemoEcLandscapeSelect: function (bindingProperty) {
			var that = this;
			this.dataChange = true;
			var masterDataModel = this.parentView.getModel("masterData");
			var oSlDetailModel = this.parentView.getModel("SlDetailModel");
			var oTemparr = oSlDetailModel.getProperty("/to_ALand");
			var sapDemoEc = masterDataModel.getProperty("/" + bindingProperty);
			var ActivityGuid = oSlDetailModel.getProperty("/ActivityGuid");
			sapDemoEc.filter(function (parentObj) {
				parentObj[bindingProperty].filter(function (childObj) {
					var index = that.fnCheckDuplicateDemoLandscapes(childObj, oTemparr);
					if (index >= 0 && childObj.selected) {

					} else if (index >= 0 && !childObj.selected) {
						oTemparr.splice(index, 1);
						childObj.prevSelected = childObj.selected;
					} else {
						if (childObj.selected) {
							if (childObj.LandscapeId === "00000") {
								var indicies = that.fnFindSameArrayObject(childObj, bindingProperty);
								if (indicies.length > 0) {
									var oArray = masterDataModel.getProperty("/" + bindingProperty);
									oArray[indicies[0]][bindingProperty][indicies[1]].selected = true;
								}
								childObj.selected = false;
							} else {
								var oTempObj = {
									"ActivityGuid": ActivityGuid,
									"LandsId": childObj.LandsId,
									"LandDescription": childObj.LandDescription,
									"Location": childObj.Location,
									"Ltype": childObj.Ltype,
									"Product": childObj.Product,
									"LTypeDescription": childObj.LTypeDescription,
									"OperationStatus": childObj.OperationStatus,
									"LandscapeId": childObj.LandscapeId
								};
								oTemparr.push(oTempObj);
								childObj.prevSelected = childObj.selected;
							}
						}
					}
				});
			});
			if (oTemparr && oTemparr.length) {
				oSlDetailModel.setProperty("/DemoEnvCheckBoxSelected", false);
				// this.parentView.byId("demoEnvironmentCheckBox").setSelected(false);
			}
			oTemparr.forEach(each => each.ActivityGuid = ActivityGuid);
			oSlDetailModel.setProperty("/to_ALand", oTemparr);
			if (this.oLandscapeDialog) {
				this.oLandscapeDialog.close();
			}
		},

		//Function to find if duplicate object is present in the array
		fnCheckDuplicateDemoLandscapes: function (object, Array) {
			var index;
			Array.find(function (obj, i) {
				if (obj.LandsId === object.LandsId && obj.LandDescription === object.LandDescription && obj.LandscapeId === object.LandscapeId) {
					index = i;
				}
			});
			return index;
		},

		//Function to find RecentSel obj in other array.
		fnFindSameArrayObject: function (childObj, bindingProperty) {
			var pIndex, cIndex;
			var oArray = this.parentView.getModel("masterData").getProperty("/" + bindingProperty);
			oArray.filter(function (pObject, pI) {
				pObject[bindingProperty].find(function (cObject, cI) {
					if (childObj.LandsId === cObject.LandsId && childObj.LandDescription === cObject.LandDescription && childObj.LandscapeId !==
						cObject.LandscapeId) {
						pIndex = pI;
						cIndex = cI;
					}
				});
			});
			return [pIndex, cIndex];
		},

		handleRapidRegStatusChange: function (oEvent) {
			var sKey = oEvent.getSource().getSelectedKey();
			var oActvt = this.parentView.getModel("SlDetailModel").getProperty("/RapidRegActivity");
			if (sKey === "12" || sKey === "14") {
				this.parentController.onCompletionDateEdit(oActvt, undefined, "12", false);
			}
			if (!sKey) {
				this.parentView.getModel("SlDetailModel").setProperty("/RapidRegActivity/StatusId", "01");
			}

		},

		showLandscapesInfoPopover: function (oEvent) {
			var oButton = oEvent.getSource();
			if (!this.landscapeInfoPopover) {
				this.landscapeInfoPopover = sap.ui.xmlfragment(this.parentView.getId(),
					"com.presalescentral.successline.fragments.LandcsapeInfoPopover",
					this);
				this.parentView.addDependent(this.landscapeInfoPopover);
			}
			this.landscapeInfoPopover.openBy(oButton);
		},

		onSelectLandScapesCheckBox: function (oEvent) {
			// oEvent.getSource().setValueState("None");
			let landscapes = this.parentView.getModel("SlDetailModel").getProperty("/to_ALand");
			if (landscapes.length !== 0) {
				oEvent.getSource().setSelected(false);
				MessageToast.show("Demo environment(s) have already been selected.")
			}
		},

	});
});