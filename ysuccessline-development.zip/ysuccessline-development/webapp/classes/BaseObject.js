sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/json/JSONModel",
	"com/presalescentral/successline/Application"
], function (Object, JSONModel, Application) {
	"use strict";
	return Object.extend("com.presalescentral.successline.classes.BaseObject", {
		constructor: function () {
			this.model = new JSONModel();
			this.model.setData(this);
			this.Application = Application.getInstance();
			this.Component = this.Application.Component;
		},
		getModel: function () {
			return this.model;
		}
	});
});