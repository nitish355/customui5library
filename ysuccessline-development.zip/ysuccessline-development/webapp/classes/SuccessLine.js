sap.ui.define([
	"com/presalescentral/successline/classes/BaseObject",
	"com/presalescentral/successline/classes/Phase",
	"com/presalescentral/successline/classes/TouchPoint",
	"com/presalescentral/successline/classes/TPLine",
	"com/presalescentral/successline/classes/TPStatus",
	"com/melody/lib/util/Activity",
	"com/melody/lib/classes/Activity"
], function (BaseObject, Phase, TouchPoint, TPLine, TPStatus, ActivityUtil, MtrActivity) {
	"use strict";
	var SuccessLine = BaseObject.extend("com.presalescentral.successline.classes.SuccessLine", {
		constructor: function (oData) {
			BaseObject.call(this);
			this.setData(oData);
		},

		setData: function (oData) {
			this.SlId = (oData && oData.SlId) ? oData.SlId : "";
			this.SlSnro = (oData && oData.SlSnro) ? oData.SlSnro : "";
			this.Name = (oData && oData.Name) ? oData.Name : "";
			this.SlCompletion = (oData && oData.SlCompletion) ? oData.SlCompletion : "";
			this.OpportunityId = (oData && oData.OpportunityId) ? oData.OpportunityId : "";
			this.OppComment = (oData && oData.OppComment) ? oData.OppComment : "";
			this.AccountId = (oData && oData.AccountId) ? oData.AccountId : "";
			this.StatusId = (oData && oData.StatusId) ? oData.StatusId : "";
			this.StatusDescription = (oData && oData.StatusDescription) ? oData.StatusDescription : "";
			this.Archive = (oData && oData.Archive) ? oData.Archive : false;
			this.CreatedAt = (oData && oData.CreatedAt) ? oData.CreatedAt : "";
			this.CreatedBy = (oData && oData.CreatedBy) ? oData.CreatedBy : "";
			this.CreatorName = (oData && oData.CreatorName) ? oData.CreatorName : "";
			this.LastChangedAt = (oData && oData.LastChangedAt) ? oData.LastChangedAt : "";
			this.LastChangedBy = (oData && oData.LastChangedBy) ? oData.LastChangedBy : "";
			this.Story = (oData && oData.Story) ? oData.Story : "";
			this.TempId = (oData && oData.TempId) ? oData.TempId : "";
			this.TempTitle = (oData && oData.TempTitle) ? oData.TempTitle : "";
			this.TemDescription = (oData && oData.TemDescription) ? oData.TemDescription : "";
			this.TotalActCount = (oData && oData.TotalActCount) ? oData.TotalActCount : 0;
			this.EstCloseDt = (oData && oData.EstCloseDt) ? oData.EstCloseDt : "";
			this.ActRegCount = (oData && oData.ActRegCount) ? oData.ActRegCount : 0;
			this.Risk = (oData && oData.Risk) ? oData.Risk : "None";
			this.Notify = (oData && oData.Notify) ? oData.Notify : false;
			this.SlLeadName = (oData && oData.SlLeadName) ? oData.SlLeadName : "";
			this.SlLead = (oData && oData.SlLead) ? oData.SlLead : "";
			this.SlLeadEmail = (oData && oData.SlLeadEmail) ? oData.SlLeadEmail : "";
			this.SlLeadMobile = (oData && oData.SlLeadMobile) ? oData.SlLeadMobile : "";
			this.CancelledAt = (oData && oData.CancelledAt) ? oData.CancelledAt : "";
			this.CancelledByName = (oData && oData.CancelledByName) ? oData.CancelledByName : "";
			this.CancelledById = (oData && oData.CancelledById) ? oData.CancelledById : "";
			this.SLExpiredFlag = (oData && oData.SLExpiredFlag) ? oData.SLExpiredFlag : "";
			this.SlLeadRegionId = (oData && oData.SlLeadRegionId) ? oData.SlLeadRegionId : "";
			this.SlLeadRegion = (oData && oData.SlLeadRegion) ? oData.SlLeadRegion : "";
			this.TeamCount = 0;
			this.Region = "";
			this.isRoleFilterChanged = false;
			this.TpDetailVisibility = false;
			this.isEditNotes = true;
			this.isDataRecieved = false;
			this.isAuthorized = false;
			this.StartDate = (oData && oData.StartDate) ? oData.StartDate : "";
			this.OREConfigID = (oData && oData.OREConfigID) ? oData.OREConfigID : "";
			this.selfAsignLead = false;
			this.ParallelSlSnro = (oData && oData.ParallelSlSnro) ? oData.ParallelSlSnro : "";
		},

		setDocs: function (docs) {
			this.Documents = docs;
		},
		setStoryLinks: function (links) {
			this.StoryLinks = links;
			let aAttchmnts = [];
			let aStoryLinks = [];
			links.filter((item) => {
				if (item.LinkType === 6) {
					aAttchmnts.push(item);
				} else if (item.LinkType === 3) {
					aStoryLinks.push(item);
				}

			});
			aAttchmnts.filter((item, index) => {
				item.Status = "";
				item.AddRemove = "";
				if (index === aAttchmnts.length - 1) {
					item.Status = "X";
					item.AddRemove = "X";
				}
			});

			this.Component.getModel("SlDetailModel").setProperty("/SlAttachments", aAttchmnts);
			this.Component.getModel("SlDetailModel").setProperty("/StoryLinks", aStoryLinks);
			this.DisplayStoryLinks = aAttchmnts;
			// this.Component.getModel("SlDetailModel").setProperty("/DisplayStoryLinks", aAttchmnts);
		},
		setSlTeam: function (team) {
			this.Team = team;
		},
		setSlActivities: function (actvts) {
			for (let i = 0; i < actvts.length; i++) {
				actvts[i].PhaseName = actvts[i].PhaseAbv + "-" + actvts[i].PhaseTitle;
				actvts[i].isDescriptionEditable = false;
				actvts[i].isOutcomesEditale = false;
				actvts[i].isNoteEditable = false;
				actvts[i].isRiskEditable = false;
				actvts[i].RegistrationAccess = false;
				actvts[i].selected = false;
				actvts[i].SLStatus = (this.StatusId) ? this.StatusId : "";

				if (this.OpportunityId) {
					actvts[i].ActvtAsstdID = "502";
					actvts[i].CostTypeValue = this.OpportunityId;
					actvts[i].CostTypeName = "Opportunity";
				} else {
					actvts[i].ActvtAsstdID = "501";
					actvts[i].CostTypeValue = this.AccountId;
					actvts[i].CostTypeName = "Account";
				}

				let sActivityId = actvts[i].RegisteredActId;
				if (sActivityId) {
					sActivityId = (parseInt(actvts[i].RegisteredActId, 10)).toString();
				}
				actvts[i].MtrActivity = new MtrActivity({
					ActivityId: sActivityId,
					ActivityTypeId: actvts[i].ActivityId,
					ActTypeDesc: actvts[i].Title,
					ActAsstId: actvts[i].ActvtAsstdID,
					ActStatusDesc: actvts[i].StatusDescription,
					RoleMpngID: actvts[i].RoleMpngID,
					CostTypeValue: actvts[i].CostTypeValue,
					CostTypeName: actvts[i].CostTypeName,
					ActivityLead: actvts[i].ActLeadId,
					ActLeadName: actvts[i].ActLead,
					ParentRoleId: actvts[i].ParentRoleId,
					ProjectType: "SLINE",
					ActivitySetStatus: (actvts[i].archived) ? "ARCHIVED" : ""
				});

			}
			this.Activities = actvts;
		},
		setComments: function (comments) {
			this.Comments = comments;
		},

		setPhases: function (phases) {
			const aPhases = [];
			const aStatuses = [];
			for (let i = 0; i < phases.length; i++) {
				aPhases.push(new Phase(phases[i]));
				aPhases[i].PhaseName = phases[i].PhaseAbv + "-" + phases[i].PhaseTitle;

				aStatuses.push(new TPStatus({
					Key: phases[i].PhaseId,
					ContentColor: phases[i].ColorName,
					HeaderContentColor: phases[i].ColorName,
					BorderColor: phases[i].ColorName,
					SelectedBackgroundColor: phases[i].ColorName,
					SelectedBorderColor: phases[i].ColorName,
					SelectedContentColor: "black",
					HoverBorderColor: phases[i].ColorName,
					HoverContentColor: "white",
					HoverBackgroundColor: phases[i].ColorName,
					LegendColor: phases[i].ColorName,
					BorderWidth: "5px"
				}));
			}
			aPhases.sort((a, b) => parseFloat(a.PhaseWeight) - parseFloat(b.PhaseWeight));
			this.Phases = aPhases;

			aStatuses.push(new TPStatus({
				Key: "disabled",
				ContentColor: "grey",
				HeaderContentColor: "grey",
				BorderColor: "grey",
				SelectedBackgroundColor: "white",
				SelectedBorderColor: "grey",
				SelectedContentColor: "grey",
				HoverBorderColor: "grey",
				HoverContentColor: "grey",
				HoverBackgroundColor: "white",
				LegendColor: "grey",
				BorderWidth: "1px"
			}));

			this.Statuses = aStatuses;
		},

		setTouchPoints: function (touchpoints) {
			const activities = this.Activities;
			const aTouchPoints = [],
				aTPLines = [];
			for (let i = 0; i < touchpoints.length; i++) {
				const oTouchPoint = new TouchPoint((i + 1).toString(), touchpoints[i]);
				const aActivities = activities.filter((item) => {
					return (item.TpointId === oTouchPoint.TpointId && item.PhaseId === oTouchPoint.PhaseId && item.tchpoint_guid === oTouchPoint.TchpointGuid);
				});
				const oPhase = this.Phases.find((phase) => {
					return phase.PhaseId === oTouchPoint.PhaseId;
				});
				if (oPhase) {
					oTouchPoint.setColor(oPhase.ColorName);
					oTouchPoint.setPhaseName(oPhase.PhaseName);
					oPhase.results.push(oTouchPoint);
				}
				oTouchPoint.setActivities(aActivities);
				aTouchPoints.push(oTouchPoint);
			}

			aTouchPoints.sort((a, b) => parseFloat(a.Weight) - parseFloat(b.Weight));
			for (let i = 0; i < aTouchPoints.length - 1; i++) {
				const oTPLine = new TPLine();
				oTPLine.From = aTouchPoints[i].Id;
				oTPLine.setPhase(aTouchPoints[i].PhaseId);
				if (i < aTouchPoints.length - 1) {
					oTPLine.To = aTouchPoints[i + 1].Id;
				}
				aTPLines.push(oTPLine);
			}
			this.TouchPoints = aTouchPoints;
			this.TPLines = aTPLines;
		},

		clone: function () {
			const oSuccessLine = new SuccessLine(this);
			oSuccessLine.ActiveActvts = JSON.parse(JSON.stringify(this.ActiveActvts));
			oSuccessLine.Activities = JSON.parse(JSON.stringify(this.Activities));
			oSuccessLine.ActivityTypes = JSON.parse(JSON.stringify(this.ActivityTypes));
			oSuccessLine.Comments = JSON.parse(JSON.stringify(this.Comments));
			oSuccessLine.ContributerCount = this.ContributerCount;
			oSuccessLine.Contributors = JSON.parse(JSON.stringify(this.Contributors));
			oSuccessLine.DefaultRole = this.DefaultRole;
			oSuccessLine.DisplayStoryLinks = JSON.parse(JSON.stringify(this.DisplayStoryLinks));
			const oPhaseData = this.clonePhases();
			oSuccessLine.Phases = oPhaseData.Phases;
			oSuccessLine.Statuses = oPhaseData.Statuses;
			const oTouchPointData = this.cloneTouchPoints();
			oSuccessLine.TouchPoints = oTouchPointData.TouchPoints;
			oSuccessLine.TPLines = oTouchPointData.TPLines;
			oSuccessLine.StoryLinks = JSON.parse(JSON.stringify(this.StoryLinks));
			oSuccessLine.Role = this.Role;
			oSuccessLine.Roles = JSON.parse(JSON.stringify(this.Roles));
			oSuccessLine.SlCompletion = this.SlCompletion;
			oSuccessLine.Team = JSON.parse(JSON.stringify(this.Team));
			oSuccessLine.TeamCount = this.TeamCount;
			oSuccessLine.TpDetailVisibility = this.TpDetailVisibility;
			oSuccessLine.isEditNotes = this.isEditNotes;
			oSuccessLine.isDataRecieved = this.isDataRecieved;
			oSuccessLine.isAuthorized = this.isAuthorized;
			oSuccessLine.Region = this.Region;
			oSuccessLine.FilteredActTypes = JSON.parse(JSON.stringify(this.FilteredActTypes));
			oSuccessLine.Sources = JSON.parse(JSON.stringify(this.Sources));
			oSuccessLine.Source = this.Source;
			return oSuccessLine;
		},

		clonePhases: function () {
			const aPhases = [];
			const aStatuses = [];
			for (let i = 0; i < this.Phases.length; i++) {
				const oPhase = this.Phases[i].clone();
				aPhases.push(oPhase);

				aStatuses.push(new TPStatus({
					Key: this.Phases[i].PhaseId,
					ContentColor: this.Phases[i].ColorName,
					HeaderContentColor: this.Phases[i].ColorName,
					BorderColor: this.Phases[i].ColorName,
					SelectedBackgroundColor: this.Phases[i].ColorName,
					SelectedBorderColor: this.Phases[i].ColorName,
					SelectedContentColor: "black",
					HoverBorderColor: this.Phases[i].ColorName,
					HoverContentColor: "white",
					HoverBackgroundColor: this.Phases[i].ColorName,
					LegendColor: this.Phases[i].ColorName,
					BorderWidth: "5px"
				}));
			}
			aPhases.sort((a, b) => parseFloat(a.PhaseWeight) - parseFloat(b.PhaseWeight));

			aStatuses.push(new TPStatus({
				Key: "disabled",
				ContentColor: "grey",
				HeaderContentColor: "grey",
				BorderColor: "grey",
				SelectedBackgroundColor: "white",
				SelectedBorderColor: "grey",
				SelectedContentColor: "grey",
				HoverBorderColor: "grey",
				HoverContentColor: "grey",
				HoverBackgroundColor: "white",
				LegendColor: "grey",
				BorderWidth: "1px"
			}));

			return {
				Phases: aPhases,
				Statuses: aStatuses
			};
		},

		cloneTouchPoints: function () {
			const aTouchPoints = [],
				aTPLines = [];
			for (let i = 0; i < this.TouchPoints.length; i++) {
				const oTouchPoint = this.TouchPoints[i].clone();
				aTouchPoints.push(oTouchPoint);
				const oPhase = this.Phases.find((phase) => {
					return phase.PhaseId === oTouchPoint.PhaseId;
				});
				if (oPhase) {
					oPhase.results.push(oTouchPoint);
				}
			}

			aTouchPoints.sort((a, b) => parseFloat(a.Weight) - parseFloat(b.Weight));

			for (let i = 0; i < this.TPLines.length; i++) {
				const oTPLine = new TPLine(this.TPLines[i]);
				oTPLine.setPhase(this.TPLines[i].PhaseId);
				aTPLines.push(oTPLine);
			}

			return {
				TouchPoints: aTouchPoints,
				TPLines: aTPLines
			};
		},
		generateActivitiesTree: function () {
			const aPhases = [];
			for (let i = 0; i < this.Phases.length; i++) {
				const oPhase = {
					PhaseName: this.Phases[i].PhaseName,
					Title: this.Phases[i].PhaseName,
					PhaseId: this.Phases[i].PhaseId,
					Weight: this.Phases[i].PhaseWeight,
					PhaseCompletion: parseInt(this.Phases[i].PhaseCompletion),
					ColorName: this.Phases[i].ColorName,
					ActCount: parseInt(this.Phases[i].ActCount),
					PlanActCount: parseInt(this.Phases[i].PlanActCount),
					RegActCount: parseInt(this.Phases[i].RegActCount),
					CompActCount: parseInt(this.Phases[i].CompActCount),
					Level: 'PHASE',
					collapsed: this.Phases[i].collapsed,
					selected: this.Phases[i].selected,
					isIndependent: false
				};

				const aTouchPoints = [];
				for (let j = 0; j < this.Phases[i].results.length; j++) {
					const oCurrentTouchPoint = this.Phases[i].results[j];
					//	if (oCurrentTouchPoint.Active) {

					const oTouchPoint = {
						PhaseName: oCurrentTouchPoint.PhaseName,
						Title: oCurrentTouchPoint.TpointTitle,
						TpointTitle: oCurrentTouchPoint.TpointTitle,
						PhaseId: oCurrentTouchPoint.PhaseId,
						Weight: oCurrentTouchPoint.Weight,
						IconUrl: oCurrentTouchPoint.IconUrl,
						IconColor: oCurrentTouchPoint.IconColor,
						TpointId: oCurrentTouchPoint.TpointId,
						Active: oCurrentTouchPoint.Active,
						ColorName: oCurrentTouchPoint.ColorName,
						TPointCompletion: parseInt(oCurrentTouchPoint.TPointCompletion),
						Level: 'SERVICE',
						collapsed: oCurrentTouchPoint.collapsed,
						selected: oCurrentTouchPoint.selected,
						serviceType: (oCurrentTouchPoint.ServiceTypeDesc === "Outcome Service") ? "Outcome" : null,
						achieved: oCurrentTouchPoint.StatusId === "01" ? true : false,
						TchpointGuid: oCurrentTouchPoint.TchpointGuid,
						achievedStatusId: oCurrentTouchPoint.StatusId,
						SrvStatusDesc: oCurrentTouchPoint.SrvStatusDesc,
						IsAchivedAt: oCurrentTouchPoint.IsAchivedAt,
						IsOutcomeToggle: ('IsOutcomeToggle' in oCurrentTouchPoint) ? oCurrentTouchPoint.IsOutcomeToggle : ""
					};

					const aActivities = [];
					for (let k = 0; k < oCurrentTouchPoint.results.length; k++) {
						const oCurrentActivity = oCurrentTouchPoint.results[k];
						if (oCurrentActivity.RiskDesc === "Green") {
							oCurrentActivity.RiskColor = "";
						}
						if (!oCurrentActivity.Active) {
							oCurrentActivity.RiskColor = "Grey";
						}

						const oActivity = {
							PhaseName: oCurrentActivity.PhaseName,
							Title: oCurrentActivity.Title,
							PhaseId: oCurrentActivity.PhaseId,
							Weight: oCurrentActivity.Weight,
							IconUrl: oCurrentActivity.IconUrl,
							IconColor: oCurrentActivity.IconColor,
							TpointId: oCurrentActivity.TpointId,
							ActivityId: oCurrentActivity.ActivityId,
							StatusId: oCurrentActivity.StatusId,
							StatusDescription: oCurrentActivity.StatusDescription,
							RegisteredActId: oCurrentActivity.RegisteredActId,
							RegMandatory: oCurrentActivity.RegMandatory,
							SLStatus: this.StatusId,
							SLisAuthorized: this.isAuthorized,
							ActGuid: oCurrentActivity.ActGuid,
							TempId: oCurrentActivity.TempId,
							IsGlobal: oCurrentActivity.IsGlobal,
							Active: oCurrentTouchPoint.Active,
							RoleMpngID: oCurrentActivity.RoleMpngID,
							SlId: this.SlId,
							SlSnro: this.SlSnro,
							ActivityLeadId: oCurrentActivity.ActivityLeadId,
							RegistrationAccess: oCurrentActivity.RegistrationAccess,
							frmlayout_id: oCurrentActivity.frmlayout_id,
							ChildFrmLayoutId: oCurrentActivity.ChildFrmLayoutId,
							ActLeadId: oCurrentActivity.ActLeadId,
							ActLead: oCurrentActivity.ActLead,
							ActRegCount: oCurrentActivity.ActRegCount,
							TotalActCount: oCurrentActivity.TotalActCount,
							UserRole: oCurrentActivity.UserRole,
							note: oCurrentActivity.note,
							source: oCurrentActivity.source,
							PhaseTitle: oCurrentActivity.PhaseTitle,
							PhaseAbv: oCurrentActivity.PhaseAbv,
							SubTitle: oCurrentActivity.SubTitle,
							ParentRoleId: oCurrentActivity.ParentRoleId,
							Level: 'ACTIVITY',
							ActLeadAbrv: oCurrentActivity.ActLeadAbrv,
							RiskColor: oCurrentActivity.RiskColor,
							RiskDesc: oCurrentActivity.RiskDesc,
							RiskId: oCurrentActivity.RiskId,
							selected: oCurrentActivity.selected,
							TchpointGuid: oCurrentActivity.tchpoint_guid,
							isIndependent: false,
							RequestorRegHC: oCurrentActivity.RequestorRegHC,
							Requestor: oCurrentActivity.Requestor,
							CompDate: oCurrentActivity.CompDate,
							ActvtAsstdID: oCurrentActivity.ActvtAsstdID,
							IsTeam: oCurrentActivity.IsTeam
						};

						aActivities.push(oActivity);

					}
					aActivities.sort(function (a, b) {
						var W1 = a.Weight;
						var W2 = b.Weight;
						if (W1 < W2) {
							return -1;
						}
						if (W1 > W2) {
							return 1;
						}
						return 0;
					});

					oTouchPoint.results = aActivities;

					aTouchPoints.push(oTouchPoint);
					//}
				}
				aTouchPoints.sort(function (a, b) {
					var SW1 = a.Weight;
					var SW2 = b.Weight;
					if (SW1 < SW2) {
						return -1;
					}
					if (SW1 > SW2) {
						return 1;
					}
					return 0;
				});
				oPhase.results = aTouchPoints;

				aPhases.push(oPhase);
			}

			return aPhases;
		},

		getStatusText: function (sCompletion) {
			if (sCompletion === 0) {
				return "NotStarted";
			} else if (sCompletion === 100) {
				return "Completed";
			} else {
				return "InProgress";
			}
		},
		presentationChart: function () {
			const aPhases = [];
			// sort phase by weight
			//	this.Phases.sort((a, b) => { return parseInt(a.Weight) - parseInt(b.Weight); });
			const sortedPhases = this.Phases.sort((a, b) => {
				return parseInt(a.Weight, 10) - parseInt(a.Weight, 10);
			});
			for (let i = 0; i < sortedPhases.length; i++) {
				const oPhase = {
					id: sortedPhases[i].PhaseId,
					abbreviation: sortedPhases[i].PhaseAbv,
					title: sortedPhases[i].PhaseName,
					color: sortedPhases[i].ColorName,
					collapsed: sortedPhases[i].collapsed,
					selected: sortedPhases[i].selected,
					percent: parseInt(sortedPhases[i].PhaseCompletion)
				};
				const aTouchPoints = [];
				const sortedServices = sortedPhases[i].results.sort((a, b) => {
					return parseInt(a.Weight) - parseInt(b.Weight);
				});

				for (let j = 0; j < sortedServices.length; j++) {
					const oCurrentTouchPoint = sortedServices[j];
					//	if (oCurrentTouchPoint.Active) {

					const oTouchPoint = {
						id: oCurrentTouchPoint.TchpointGuid,
						title: oCurrentTouchPoint.TpointTitle,
						collapsed: oCurrentTouchPoint.collapsed,
						selected: oCurrentTouchPoint.selected,

						active: oCurrentTouchPoint.Active,
						serviceType: (oCurrentTouchPoint.ServiceTypeDesc === "Outcome Service") ? "Outcome" : null,
						achieved: oCurrentTouchPoint.StatusId === "01" ? true : false,
						touchpointId: oCurrentTouchPoint.TpointId

					};

					const aActivities = [];
					const sortedActivities = oCurrentTouchPoint.results.sort((a, b) => {
						return parseInt(a.Weight) - parseInt(b.Weight);
					});
					for (let k = 0; k < sortedActivities.length; k++) {
						const oCurrentActivity = sortedActivities[k];
						let sDate = new Date();
						let sCompDate = new Date();
						if (oCurrentActivity.StartDate !== null) {
							sDate = oCurrentActivity.StartDate;
						}
						if (oCurrentActivity.CompDate !== null) {
							sCompDate = oCurrentActivity.CompDate;
						}
						const oActivity = {
							id: oCurrentActivity.ActGuid,
							title: oCurrentActivity.Title,
							subTitle: oCurrentActivity.SubTitle,
							status: this._getStatusText(oCurrentActivity.StatusId, oCurrentActivity.archived),
							date: sCompDate,
							type: oCurrentActivity.ActivityId,
							selected: oCurrentActivity.selected,
							active: oCurrentTouchPoint.Active,
							touchpointId: oCurrentActivity.TpointId

						};

						aActivities.push(oActivity);

					}

					oTouchPoint.activities = aActivities;

					aTouchPoints.push(oTouchPoint);
					//}
				}

				oPhase.services = aTouchPoints;

				aPhases.push(oPhase);
			}
			let presentationData = {
				startDate: this.StartDate,
				endDate: this.EstCloseDt,
				phases: aPhases
			};
			return presentationData;

		},
		_getStatusText: function (statusId, isArchived) {
			if (isArchived) {
				return "Archieved";
			}
			switch (statusId) {
				case '01': //Registered
					return 'Registered';
				case '02': //Cancelled
					return 'Cancelled';
				case '10': //Recommended
					return 'Recommended';
				case '11': //Planned
					return 'Planned';
				case '12': //Completed
					return 'Completed';
				case '13': //Required
					return 'Required';
				case '14': //Customer Validated
					return 'Validated';
				case '15': //Not Applicable
					return 'Not Applicable';
				case '16': //Started
					return 'Started';
				case '17': //Progressing
					return 'Progressing';
				case '18': //Presented
					return 'Presented';
				default: //Recommended
					return 'Recommended';
			}
		},
		setSlOppActvts: function (aOppActvts) {
			this.OppActvts = aOppActvts;
		},

		setAttachments: function (attachments) {
			this.Attachments = attachments;
		}

	});
	return SuccessLine;
});