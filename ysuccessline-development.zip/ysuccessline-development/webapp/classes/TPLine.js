sap.ui.define([
	"com/presalescentral/successline/classes/BaseObject",
	"sap/suite/ui/commons/networkgraph/LineArrowPosition"
], function (BaseObject, LineArrowPosition) {
	"use strict";
	var TPLine = BaseObject.extend("com.presalescentral.successline.classes.TPLine", {
		constructor: function (sId, oData) {
			BaseObject.call(this);
			this.setData(oData);
		},
		setData: function (oData) {
			this.From = (oData && oData.From) ? oData.From : "";
			if (oData && oData.To) {
				this.To = oData.To;
			}
			//this.To = (oData && oData.To) ? oData.To : "";
			this.ArrowPosition = (oData && oData.ArrowPosition) ? oData.ArrowPosition : LineArrowPosition.Middle;
		},
		setPhase: function (sPhaseId) {
			this.PhaseId = (sPhaseId) ? sPhaseId : "";
		}
	});
	return TPLine;
});