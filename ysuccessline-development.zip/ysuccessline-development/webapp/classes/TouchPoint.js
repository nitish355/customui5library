sap.ui.define([
	"com/presalescentral/successline/classes/BaseObject"
], function (BaseObject) {
	"use strict";
	var TouchPoint = BaseObject.extend("com.presalescentral.successline.classes.TouchPoint", {
		constructor: function (sId, oData) {
			BaseObject.call(this);
			this.setData(sId, oData);
		},

		setData: function (sId, oData) {
			this.Id = (sId) ? sId : "";
			this.TpointId = (oData && oData.TpointId) ? oData.TpointId : "";
			this.TpointTitle = (oData && oData.TpointTitle) ? oData.TpointTitle : "";
			this.SlId = (oData && oData.SlId) ? oData.SlId : "";
			this.SlSnro = (oData && oData.SlSnro) ? oData.SlSnro : "";
			this.PhaseId = (oData && oData.PhaseId) ? oData.PhaseId : "";
			this.PhaseTitle = (oData && oData.PhaseTitle) ? oData.PhaseTitle : "";
			this.Weight = (oData && oData.Weight) ? oData.Weight :
				(oData && oData.TchpointWt) ? oData.TchpointWt : "";
			this.Description = (oData && oData.Description) ? oData.Description : "";
			this.TempId = (oData && oData.TempId) ? oData.TempId : "";
			this.Active = (oData && oData.Active) ? oData.Active : false;
			this.IconUrl = (oData && oData.IconUrl) ? oData.IconUrl : "";
			this.StatusId = (oData && oData.StatusId) ? oData.StatusId : "";
			this.StatusDescription = (oData && oData.StatusDescription) ? oData.StatusDescription : "";
			this.StatusIcon = (oData && oData.StatusIcon) ? oData.StatusIcon : "";
			this.TpActvtCount = 0;
			this.isTpSelected = false;
			this.TchpointId = (oData && oData.TchpointId) ? oData.TchpointId : "";
			this.TchpointWt = (oData && oData.TchpointWt) ? oData.TchpointWt : "";
			this.Title = (oData && oData.Title) ? oData.Title : "";
			this.TPointCompletion = (oData && oData.TPointCompletion) ? parseInt(oData.TPointCompletion) : 0;
			this.collapsed = false;
			this.selected = false;
			this.TchpointGuid = (oData && oData.TchpointGuid) ? oData.TchpointGuid : "";
			this.IsAchivedAt = (oData && oData.IsAchivedAt) ? oData.IsAchivedAt : null;
			this.IsAchivedBy = (oData && oData.IsAchivedBy) ? oData.IsAchivedBy : "";
			this.IsCompleted = (oData && oData.IsCompleted) ? oData.IsCompleted : "";
			this.IsPlanned = (oData && oData.IsPlanned) ? oData.IsPlanned : "";
			this.IsRegistered = (oData && oData.IsRegistered) ? oData.IsRegistered : "";
			this.IsOutcomeToggle = (oData && "IsOutcomeToggle" in oData) ? oData.IsOutcomeToggle : "";
			this.IsRequired = (oData && oData.IsRequired) ? oData.IsRequired : "";
			this.SrvStatusChangedAt = (oData && oData.SrvStatusChangedAt) ? oData.SrvStatusChangedAt : "";
			this.SrvStatusChangedBy = (oData && oData.SrvStatusChangedBy) ? oData.SrvStatusChangedBy : "";
			this.ServiceTypeDesc = (oData && oData.ServiceTypeDesc) ? oData.ServiceTypeDesc : "";
			this.ServiceTypeID = (oData && oData.ServiceTypeID) ? oData.ServiceTypeID : "";
			this.Source = (oData && oData.Source) ? oData.Source : "";
			this.TchpntNotes = (oData && oData.TchpntNotes) ? oData.TchpntNotes : "";
			this.SrvStatusId = (oData && oData.SrvStatusId) ? oData.SrvStatusId : "";
			this.SrvStatusDesc = (oData && oData.SrvStatusDesc) ? oData.SrvStatusDesc : "";

		},
		setActivities: function (activities) {
			this.Activities = activities;
			this.TpActvtCount = activities.length;
			this.results = activities;
			/*Services that contain Required activities cannot be disabled
			  Github: https://github.wdf.sap.corp/PresalesTools/ysuccessline/issues/29*/
			this.enableTpService = true;
			this.EnabledRoles = "";
			for (let i = 0; i < this.TpActvtCount; i++) {
				if (activities[i].RegMandatory) {
					this.enableTpService = false;
					return;
				}
			}

		},
		setColor: function (sColor) {
			this.ColorName = (sColor) ? sColor.toLowerCase() : "";
		},
		setPhaseName: function (sPhaseName) {
			this.PhaseName = (sPhaseName) ? sPhaseName : "";
		},
		clone: function () {
			const oTouchPoint = new TouchPoint(this.Id, this);
			oTouchPoint.Activities = JSON.parse(JSON.stringify(this.Activities));
			oTouchPoint.setColor(this.ColorName);
			oTouchPoint.setPhaseName(this.PhaseName);
			oTouchPoint.TpActvtCount = this.TpActvtCount;
			oTouchPoint.setActivities(this.Activities);
			oTouchPoint.isTpSelected = this.isTpSelected;
			return oTouchPoint;
		}

	});
	return TouchPoint;
});