sap.ui.define([
	"com/presalescentral/successline/classes/BaseObject",
	"com/presalescentral/successline/classes/TouchPoint"
], function (BaseObject, TouchPoint) {
	"use strict";
	var Phase = BaseObject.extend("com.presalescentral.successline.classes.Phase", {
		constructor: function (oData) {
			BaseObject.call(this);
			this.setData(oData);
		},

		setData: function (oData) {
			this.SlId = (oData && oData.SlId) ? oData.SlId : "";
			this.SlSnro = (oData && oData.SlSnro) ? oData.SlSnro : "";
			this.PhaseId = (oData && oData.PhaseId) ? oData.PhaseId : "";
			this.PhaseTitle = (oData && oData.PhaseTitle) ? oData.PhaseTitle : "0";
			this.PhaseWeight = (oData && oData.PhaseWeight) ? oData.PhaseWeight : "";
			this.PhaseAbv = (oData && oData.PhaseAbv) ? oData.PhaseAbv : "";
			this.Description = (oData && oData.Description) ? oData.Description : "";
			this.ColorName = (oData && oData.ColorName) ? oData.ColorName.toLowerCase() : "";
			this.TempId = (oData && oData.TempId) ? oData.TempId : "";
			this.TouchPointCount = 0;
			this.PhaseTouchPoints = [];
			//this.PhaseWt = (oData && oData.PhaseWt) ? oData.PhaseWt : "";
			this.Title = (oData && oData.Title) ? oData.Title : "";
			this.IconUrl = (oData && oData.IconUrl) ? oData.IconUrl : "";
			this.Weight = (oData && oData.PhaseWeight) ? oData.PhaseWeight :
			(oData && oData.PhaseWt) ? oData.PhaseWt : "" ;
			this.PhaseCompletion = (oData && oData.PhaseCompletion) ? parseInt(oData.PhaseCompletion) : 0;
			// this.ActCount = (oData && oData.ActCount) ? parseInt(oData.ActCount) : 0;
			this.ActCount = (oData && oData.ActCount) ?  parseInt(oData.ActCount)  : 100;
			this.PlanActCount = (oData && oData.PlanActCount) ? parseInt(oData.PlanActCount) : 0;
			this.RegActCount = (oData && oData.RegActCount) ? parseInt(oData.RegActCount) : 0;
			this.CompActCount = (oData && oData.CompActCount) ? parseInt(oData.CompActCount): 0;
			this.results = [];
			this.collapsed = false;
			this.selected = false;
		},
		setPhaseName: function (sPhaseName) {
			this.PhaseName = (sPhaseName) ? sPhaseName : "";
		},

		clone: function () {
			const oPhase = new Phase(this);
			oPhase.setPhaseName(this.PhaseName);
			oPhase.PhaseTouchPoints = this.cloneTouchPoints();
			oPhase.TouchPointCount = oPhase.PhaseTouchPoints.length;

			return oPhase;
		},

		cloneTouchPoints: function () {
			const aTouchPoints = [];
			for (let i = 0; i < this.PhaseTouchPoints.length; i++) {
				const oTouchPoint = this.PhaseTouchPoints[i].clone();
				aTouchPoints.push(oTouchPoint);
			}

			return aTouchPoints;
		}

	});
	return Phase;
});