sap.ui.define([
	"com/presalescentral/successline/classes/BaseObject"
], function (BaseObject, OREFilterItem) {
	"use strict";
	var TPStatus = BaseObject.extend("com.presalescentral.successline.classes.TPStatus", {
		constructor: function (oData) {
			BaseObject.call(this);
			this.setData(oData);
		},

		setData: function (oData) {
			this.Key = (oData && oData.Key) ? oData.Key : "";
			this.ContentColor = (oData && oData.ContentColor) ? oData.ContentColor : "";
			this.HeaderContentColor = (oData && oData.HeaderContentColor) ? oData.HeaderContentColor : "";
			this.BorderColor = (oData && oData.BorderColor) ? oData.BorderColor : "";
			this.SelectedBackgroundColor = (oData && oData.SelectedBackgroundColor) ? oData.SelectedBackgroundColor : "";
			this.SelectedBorderColor = (oData && oData.SelectedBorderColor) ? oData.SelectedBorderColor : "";
			this.SelectedContentColor = (oData && oData.SelectedContentColor) ? oData.SelectedContentColor : "";
			this.HoverBorderColor = (oData && oData.HoverBorderColor) ? oData.HoverBorderColor : "";
			this.HoverContentColor = (oData && oData.HoverContentColor) ? oData.HoverContentColor : "";
			this.HoverBackgroundColor = (oData && oData.HoverBackgroundColor) ? oData.HoverBackgroundColor : "";
			this.LegendColor = (oData && oData.LegendColor) ? oData.LegendColor : "";
			this.BorderWidth = (oData && oData.BorderWidth) ? oData.BorderWidth : "5px";
		}
	});
	return TPStatus;
});