sap.ui.define([
	"com/presalescentral/successline/classes/BaseObject",
	"com/presalescentral/successline/classes/Phase",
	"com/presalescentral/successline/classes/TouchPoint"
], function (BaseObject, Phase, TouchPoint) {
	"use strict";
	var Template = BaseObject.extend("com.presalescentral.successline.classes.Template", {
		constructor: function (oData) {
			BaseObject.call(this);
			this.setData(oData);
		},

		setData: function (oData) {
			this.Description = (oData && oData.Description) ? oData.Description : "";
			this.OREConfigID = (oData && oData.OREConfigID) ? oData.OREConfigID : "";
			this.TempId = (oData && oData.TempId) ? oData.TempId : "";
			this.TempTypeId = (oData && oData.TempTypeId) ? oData.TempTypeId : "0";
			this.Title = (oData && oData.Title) ? oData.Title : "";
			this.IconUrl = (oData && oData.IconUrl) ? oData.IconUrl : "";
		},
		setPhases: function (phases) {
			const aPhases = [];
			for (let i = 0; i < phases.length; i++) {
				aPhases.push(new Phase(phases[i]));
				aPhases[i].PhaseName = phases[i].PhaseAbv + "-" + phases[i].PhaseTitle;
				
				
			}
			aPhases.sort((a, b) => parseFloat(a.PhaseWeight) - parseFloat(b.PhaseWeight));
			this.results = aPhases;
			this.Phases = aPhases;
			
			
		},
		setTouchPoints: function (touchpoints, activities) {
			const aTouchPoints = [];
			for (let i = 0; i < touchpoints.length; i++) {
				const oTouchPoint = new TouchPoint((i + 1).toString(), touchpoints[i]);
				const aActivities = activities.filter((item) => {
					return (item.TchpointId === oTouchPoint.TchpointId && item.PhaseId === oTouchPoint.PhaseId);
				});
				const oPhase = this.Phases.find((phase) => {
					return phase.PhaseId === oTouchPoint.PhaseId;
				});
				if (oPhase) {
					//oTouchPoint.setColor(oPhase.ColorName);
					oTouchPoint.setPhaseName(oPhase.PhaseName);
					oPhase.results.push(oTouchPoint);
				}
				oTouchPoint.setActivities(aActivities);
				aTouchPoints.push(oTouchPoint);
			}

			aTouchPoints.sort((a, b) => parseFloat(a.Weight) - parseFloat(b.Weight));

			

			this.TouchPoints = aTouchPoints;
			
		}

	});
	return Template;
});