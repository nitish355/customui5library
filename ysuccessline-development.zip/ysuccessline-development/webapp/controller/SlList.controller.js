sap.ui.define([
	"com/presalescentral/successline/controller/BaseController",
	"com/presalescentral/successline/service/OppService",
	"sap/ui/model/json/JSONModel",
	"com/presalescentral/successline/service/SLService",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/ui/model/Sorter",
	"sap/ui/util/Storage",
	"sap/base/Log"
], function (BaseController, OppService, JSONModel, SLService, Filter, FilterOperator, MessageBox, MessageToast, Dialog, Button, Sorter,
	Storage, Log) {
	"use strict";

	return BaseController.extend("com.presalescentral.successline.controller.SlList", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		onInit: function () {
			this.iSelectedVariant = "";
			this.variants = new JSONModel();
			this.getView().setModel(this.variants, "variants");
			this.slovariantStrage = new Storage(Storage.Type.session);
			this.slosavedVariantObj = new Storage(Storage.Type.session);
			this._variantModel = this.getOwnerComponent().getModel("variant");
			this.getRouter().getRoute("SlList").attachPatternMatched(this._onVariantMatched, this);
			this.getOwnerComponent().getRouter().getRoute("slvariant").attachPatternMatched(this._onVariantMatched, this);
			this.mGroupFunctions = {
				AccountName: function (oContext) {
					var name = oContext.getProperty("AccountName");
					if (!name) {
						name = "NA";
					}
					return {
						key: name,
						text: "Account Name: " + name
					};
				},
				LeadName: function (oContext) {
					var name = oContext.getProperty("LeadName");
					if (!name) {
						name = "NA";
					}
					return {
						key: name,
						text: "Lead Name: " + name
					};
				},
				OpportunityName: function (oContext) {
					var name = oContext.getProperty("OpportunityName");
					if (!name) {
						name = "NA";
					}
					return {
						key: name,
						text: "Opportunity Name: " + name
					};
				},
				Opporutnityid: function (oContext) {
					var name = oContext.getProperty("Opporutnityid");
					if (!name) {
						name = "NA";
					}
					return {
						key: name,
						text: "Opportunity ID: " + name
					};
				},
				OpportunityPhase: function (oContext) {
					var name = oContext.getProperty("OpportunityPhase");
					if (!name) {
						name = "NA";
					}
					return {
						key: name,
						text: "Opportunity Phase: " + name
					};
				}
			};
			let personalizationData = this.getOwnerComponent().getModel("PersonalizationModel").getData();
			this.persdatacopy = JSON.parse(JSON.stringify(personalizationData));

			this.constants = {};
			/*let data = this.getOwnerComponent().getModel("masterData").getProperty("/constants");
			for (let index in data) {
				this.constants[data[index].const_id] = data[index];
			}
			let oConstantsMap = "";*/
			this.constStorage = new Storage(Storage.Type.session);
			this.constants = this.constStorage.get('ConstantsMapData');
			this.myTeamData = {};
			this.slManagerTeamStorage = new Storage(Storage.Type.session);
			this.myTeamData = this.slManagerTeamStorage.get('SlManagerTeamData');
			this.getOwnerComponent().getModel("masterData").setProperty("/myTeamData", this.myTeamData);
			this.getView().setModel(new JSONModel([]), "dataChanged");
			this.initView();
		},
		/**
		 * Called to load varaints.
		 * * @param filter - Passes default varaint
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		_loadVariants: function (filter) {
			if (!filter) {
				filter = [];
			}

			let that = this;
			that.getView().setModel(new JSONModel([]), "variantModel");
			that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
			SLService.getVariants(filter).then((oData) => {
				that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
				that._successVaraint(oData.data);
			});
		},
		/**
		 * Called to load varaints and set default variant. Private method of _loadVariants
		 * * @param oData - Passes default varaint data
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		_successVaraint: function (oData) {
			if (!oData.results.length) {
				this._displayErrorMsg("Failed to fetch variant data.");
				return;
			}
			this.getView().getModel("variants").setData(oData.results);
			let oVariant = oData.results[0];
			if (oVariant.executeonselect !== "X") {
				this.bInitialLoad = false;
			}
			this._setVariantData(oVariant);
		},

		/**
		 * Called to set default or selected varaint. Private method of _successVaraint and _getDefaultVariant.
		 * * @param oVariant - Passes varaint data, bInitialLoad - flag to determine to execute on select
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		_setVariantData: function (oVariant, bInitialLoad) {
			this.iSelectedVariant = parseInt(oVariant.variantid);
			this.getView().byId("variantButton").setText(oVariant.variant_name);
			this.getView().byId("variantButton").data("variantid", oVariant.variantid);
			this.variantId = oVariant.variantid;
			this.variantIncludeTeam = oVariant.includeteam;
			this.variantViewName = oVariant.view_name;
			this.variantEditFlag = oVariant.Editable;
			let oGlobalString = JSON.parse(oVariant.FilterString);
			let aGlobalFilterKeys = Object.keys(JSON.parse(oVariant.FilterString));
			this.getView().getModel("slListModel").setProperty("/ViewName", (this.variantId === "1000000020") ? "My Team's SuccessLines" :
				"My SuccessLines");

			let oVariantFilter,
				str = [];
			let sessionStorageVariantId = this.slovariantStrage.get("SLsessionStorageVariantID");
			if (this.iSelectedVariant !== sessionStorageVariantId) {
				this.slovariantStrage.put('SLsessionStorageVariantModel', null);
			}
			if (this.slovariantStrage.get("SLsessionStorageVariantModel")) {
				oVariantFilter = this.slovariantStrage.get('SLsessionStorageVariantModel');
				this.slovariantStrage.put('SLsessionStorageVariantModel', null);
			} else {
				if (typeof (oVariant.FilterString) === "string") {
					oVariant.FilterString = oVariant.FilterString.replace(/'/g, '"');
					oVariantFilter = JSON.parse(oVariant.FilterString);
				} else if (typeof (oVariant.FilterString) === "object") {
					oVariantFilter = oVariant.FilterString;
				}
			}
			//if there is an issue with date , uncomment this
			if (oVariantFilter.createdat.value1 && oVariantFilter.createdat.value2) {
				if (oVariantFilter.createdat.value1.toString().split("-").length <= 1) {
					oVariantFilter.createdat.value1 = new Date(parseInt(oVariantFilter.createdat.value1));
					oVariantFilter.createdat.value2 = new Date(parseInt(oVariantFilter.createdat.value2));
				} else {
					oVariantFilter.createdat.value1 = new Date(oVariantFilter.createdat.value1);
					oVariantFilter.createdat.value2 = new Date(oVariantFilter.createdat.value2);
				}
			} else {
				oVariantFilter.createdat.value1 = null;
				oVariantFilter.createdat.value2 = null;
			}
			if (oVariantFilter.estclosedate.value1 && oVariantFilter.estclosedate.value2) {
				if (oVariantFilter.estclosedate.value1.toString().split("-").length <= 1) {
					oVariantFilter.estclosedate.value1 = new Date(parseInt(oVariantFilter.estclosedate.value1));
					oVariantFilter.estclosedate.value2 = new Date(parseInt(oVariantFilter.estclosedate.value2));
				} else {
					oVariantFilter.estclosedate.value1 = new Date(oVariantFilter.estclosedate.value1);
					oVariantFilter.estclosedate.value2 = new Date(oVariantFilter.estclosedate.value2);
				}
			} else {
				oVariantFilter.estclosedate.value1 = null;
				oVariantFilter.estclosedate.value2 = null;
			}
			if (oVariantFilter.slcompletion.value1 === 0 && oVariantFilter.slcompletion.value2 === 100) {
				this.byId("slCompletionId").setValue(0);
				this.byId("slCompletionId").setValue2(100);
				oVariantFilter.slcompletion.value1 = this.byId("slCompletionId").getValue();
				oVariantFilter.slcompletion.value2 = this.byId("slCompletionId").getValue2();

			} else {
				oVariantFilter.slcompletion.value1 = parseFloat(oVariantFilter.slcompletion.value1);
				oVariantFilter.slcompletion.value2 = parseFloat(oVariantFilter.slcompletion.value2);
				this.byId("slCompletionId").setValue(oVariantFilter.slcompletion.value1);
				this.byId("slCompletionId").setValue2(oVariantFilter.slcompletion.value2);
			}
			if (oVariantFilter.myteammembers.value1) {
				if (oVariantFilter.myteammembers.value1 !== []) {
					this.byId("multiTeamId").setSelectedKeys(oVariantFilter.myteammembers.value1);
				}
			}
			if (oVariantFilter.sort === undefined) {
				var sort = {};
				sort.sortby = "CreateDat";
				sort.sortorderdesc = false;
				this.getView().getModel("variant").setProperty("/sort", sort);
				oVariantFilter.sort = sort;
			}
			if (oVariantFilter.group === undefined) {
				var group = {};
				group.groupby = null;
				group.grouporderdesc = false;
				this.getView().getModel("variant").setProperty("/group", group);
				oVariantFilter.group = group;
			}

			this.getView().getModel("variant").setData(oVariantFilter);

			if (oVariantFilter.archivedStatus === undefined) {
				var aArchivedStatus = {};
				aArchivedStatus.key = "00";
				aArchivedStatus.value1 = "ActivitySetStatus";
				this.getView().getModel("variant").setProperty("/archivedStatus", aArchivedStatus);
			} else {
				if (this.getView().getModel("variant").getData().archivedStatus.key !== "01") {
					this.getView().getModel("variant").setProperty("/archivedStatus/key", "00");
				}
			}

			if (str.length > 0) {
				this.byId("expandendContent").setText("Filtered By (" + str.length + "): " + str.join(", "));
				this.byId("snappedContent").setText("Filtered By (" + str.length + "): " + str.join(", "));
			} else {
				this.byId("expandendContent").setText("Filtered By: None");
				this.byId("snappedContent").setText("Filtered By: None");
			}
			var slListTable = this.byId("slListTable");
			if (this.bInitialLoad || oVariant.executeonselect === "X") {
				slListTable.setNoDataText("No data matches the filter criteria");
				this.getOwnerComponent().getModel("successlineModel").metadataLoaded().then(this.delayFilter());
			} else {
				this.getView().getModel("slListModel").setProperty("/slData", []);
				slListTable.setNoDataText("Click on 'Go' button to fetch records.");
				this.getOwnerComponent().getModel("appSettings").setProperty("/isTableBusy", false);
			}
			this.getOwnerComponent().getModel("variant").refresh();
		},

		/**
		 * Fetches the list of SL's based on filters 
		 * * @param oEvent - Passes filters and fetches SL's in the list
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		performTableFilter: function (oEvent) {
			this.getOwnerComponent().getModel("appSettings").setProperty("/isTableBusy", true);
			this.getView().getModel("slListModel").setProperty("/slData", []);
			let flag = true;
			let aFilters = [];
			let str = [];
			let aMultiFilter = [];
			let adate = [];
			let countFilters = [];
			let isManager = this.getView().getModel("variants").getData()[0].includeteam;
			let teamMemberFlag = true;
			let personalizationData = this.getView().getModel("PersonalizationModel").getData();
			let oVariantsData = this.getView().getModel("variants").getData()[0];
			let oVariantData = JSON.parse(oVariantsData.FilterString);
			//		let that = this;
			var slListTable = this.byId("slListTable");
			slListTable.setNoDataText("No data matches the filter criteria");
			if (isManager) {
				let filterManger1 = new Filter({
					path: "ManagerView",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: "X"
				});
				aFilters.push(filterManger1);
				countFilters.push(filterManger1);

				for (let i in personalizationData) {
					if (personalizationData[i].key === "myteammembers") {
						personalizationData[i].visible = true;
					}
				}
			} else {
				for (let j in personalizationData) {
					if (personalizationData[j].key === "myteammembers") {
						personalizationData[j].visible = false;
					}
				}
			}
			//set visibility based on variant for outcome
			if (Object.keys(oVariantData).indexOf("achieved") !== -1) {
				for (let k in personalizationData) {
					if (personalizationData[k].key === "achieved") {
						personalizationData[k].visible = true;
					}
				}
			} else {
				for (let l in personalizationData) {
					if (personalizationData[l].key === "achieved") {
						personalizationData[l].visible = false;
					}
				}
			}
			let aSelectionset = oEvent.getParameters().selectionSet;
			$.each(aSelectionset, function (index, value) {
				if (value.getValue() || (value.getMetadata().getElementName() === "sap.m.ComboBox" && value.getSelectedKey()) || (value.getMetadata()
						.getElementName() === "sap.m.MultiComboBox" && value.getSelectedKeys().length !== 0) || (value.getMetadata()
						.getElementName() === "sap.m.MultiInput" && value.getTokens().length > 0)) {
					if (value.getMetadata().getElementName() === "sap.m.RangeSlider") {
						str.push(value.getParent().getContent()[0].getText());
					} else {
						str.push(value.getLabels()[0].getText());
					}
					if (value.getMetadata().getElementName() !== "sap.m.RangeSlider") {
						if (value.getValueState() === "Error") {
							flag = false;
						}
					}
					if (flag && value.getMetadata().getElementName() === "sap.m.DateRangeSelection") {

						let month = value.getFrom().getMonth() + 1;
						if (month < 10) {
							month = "0" + month;
						}
						let year = value.getFrom().getFullYear();
						let day = value.getFrom().getDate();
						if (day < 10) {
							day = "0" + day;
						}
						let value1Date = year + "-" + month + "-" + day + "T00:00:00Z";
						value1Date = new Date(value1Date);
						let dateFrom = new Filter({
							path: value.getCustomData()[0].getValue(),
							operator: sap.ui.model.FilterOperator.GE,
							value1: value1Date
						});
						adate.push(dateFrom);
						let toMonth = value.getTo().getMonth() + 1;
						if (toMonth < 10) {
							toMonth = "0" + toMonth;
						}
						let toYear = value.getTo().getFullYear();
						let toDay = value.getTo().getDate();
						if (toDay < 10) {
							toDay = "0" + toDay;
						}
						let value2Date = toYear + "-" + toMonth + "-" + toDay + "T23:59:00Z";
						value2Date = new Date(value2Date);
						let dateTo = new Filter({
							path: value.getCustomData()[0].getValue(),
							operator: sap.ui.model.FilterOperator.LE,
							value1: value2Date
						});
						adate.push(dateTo);
						aFilters.push(new Filter({
							filters: adate,
							and: true
						}));
						countFilters.push(new Filter({
							filters: adate,
							and: true
						}));
						adate = [];
					} else if (value.getMetadata().getElementName() === "sap.m.ComboBox") {
						if (value.getSelectedKey()) {
							let filter2 = new Filter({
								path: value.getCustomData()[0].getValue(),
								operator: sap.ui.model.FilterOperator.EQ,
								value1: value.getSelectedKey()
							});
							aFilters.push(filter2);
							countFilters.push(filter2);

						}
					} else if (value.getMetadata().getElementName() === "sap.m.MultiComboBox") {
						if (value.getSelectedKeys()) {
							teamMemberFlag = false;
							let teamTokens = value.getSelectedKeys();

							$.each(teamTokens, function (idx, token) {

								aMultiFilter.push(new Filter(value.getCustomData()[0].getValue(), FilterOperator.EQ, token));
							});
							if (aMultiFilter.length > 0) {
								aFilters.push(new Filter({
									filters: aMultiFilter,
									and: false
								}));
								countFilters.push(new Filter({
									filters: aMultiFilter,
									and: false
								}));
								aMultiFilter = [];
							}
						}
					} else if (value.getMetadata().getElementName() === "sap.m.MultiInput") {
						let tokens = value.getTokens();

						$.each(tokens, function (idx, token) {
							aMultiFilter.push(new Filter(value.getCustomData()[0].getValue(), FilterOperator.EQ, token.getKey()));
						});
						aMultiFilter = [];
					} else if (value.getMetadata().getElementName() === "sap.m.RangeSlider") {
						let value1 = this.getValue();
						let value2 = this.getValue2();
						let filter5 = new Filter({
							path: value.getCustomData()[0].getValue(),
							operator: sap.ui.model.FilterOperator.BT,
							value1: value1,
							value2: value2
						});
						aFilters.push(filter5);
						countFilters.push(filter5);
					} else {
						let filter4 = new Filter({
							path: value.getCustomData()[0].getValue(),
							operator: sap.ui.model.FilterOperator.Contains,
							value1: value.getValue()
						});
						aFilters.push(filter4);
						countFilters.push(filter4);
					}
				}
			});
			if (this.getView().getModel("variant").getData().archivedStatus.key !== "01") {
				this.getView().getModel("variant").setProperty("/archivedStatus/key", "");
			}

			if (this.getView().getModel("variant").getData().archivedStatus.key === "01") {
				var filterarchive1 = new Filter({
					path: "Archive",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: true
				});
				var filterarchive2 = new Filter({
					path: "Archive",
					operator: sap.ui.model.FilterOperator.NE,
					value1: true
				});
				aFilters.push(filterarchive1);
				countFilters.push(filterarchive2);
			} else {
				var filterarchive12 = new Filter({
					path: "Archive",
					operator: sap.ui.model.FilterOperator.NE,
					value1: true
				});
				var filterarchive4 = new Filter({
					path: "Archive",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: true
				});
				aFilters.push(filterarchive12);
				countFilters.push(filterarchive4);
			}
			//Filter for Outcome Variants
			if (Object.keys(oVariantData).indexOf("achieved") !== -1) {
				let filterOutcome = new Filter({
					path: "OutcomeCount",
					operator: sap.ui.model.FilterOperator.GT,
					value1: 0
				});
				aFilters.push(filterOutcome);
				countFilters.push(filterOutcome);
			}
			if (isManager && teamMemberFlag) {
				let teamTokens = this.getView().getModel("masterData").getData().myTeamData;
				let sPath = "TeamFilter";
				$.each(teamTokens, function (idx, token) {

					aMultiFilter.push(new Filter(sPath, FilterOperator.EQ, token.userid));
				});
				if (aMultiFilter.length > 0) {
					aFilters.push(new Filter({
						filters: aMultiFilter,
						and: false
					}));
					countFilters.push(new Filter({
						filters: aMultiFilter,
						and: false
					}));
					aMultiFilter = [];
				}
			}
			if (flag) {
				if (str.length > 0) {
					this.byId("expandendContent").setText("Filtered By (" + str.length + "): " + str.join(", "));
					this.byId("snappedContent").setText("Filtered By (" + str.length + "): " + str.join(", "));
				} else {
					this.byId("expandendContent").setText("Filtered By: None");
					this.byId("snappedContent").setText("Filtered By: None");
				}
				this.callCount(countFilters);
				this.callSL(aFilters);

			} else {
				//	MessageToast.show("Invalid Filters");
				this.byId("expandendContent").setText("Invalid Filters");
				this.byId("snappedContent").setText("Invalid Filters");
				this.getOwnerComponent().getModel("appSettings").setProperty("/isTableBusy", false);
				this.getOwnerComponent().getModel("busy").setProperty("/isAppBusy", false);
			}

		},
		/**
		 * Delay call to fetch team data from master service and fetch SL's based on Manager or Not Manager
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		delayFilter: function () {
			let that = this;
			let viewId = this.getView().getId();
			jQuery.sap.delayedCall(300, this, function () {
				if (this.getOwnerComponent().getModel("masterData").getData().myTeamData) {
					let isManager = this.getView().getModel("variants").getData()[0].includeteam;
					let teamDataset = this.getOwnerComponent().getModel("masterData").getData().myTeamData;
					if (isManager) {
						SLService.getLeadMasterData("YC_SL_T_SLLISTSet", isManager, teamDataset).then((data) => {
							let aLeadMap = [];
							let aLeadData = [];
							for (let i in data.data.results) {
								if (!aLeadMap[data.data.results[i].LeadId]) {
									aLeadMap[data.data.results[i].LeadId] = {
										"LeadName": data.data.results[i].LeadName,
										"LeadId": data.data.results[i].LeadId
									};
									aLeadData.push(aLeadMap[data.data.results[i].LeadId]);
								}
							}

							that.getOwnerComponent().getModel("masterData").setProperty("/LeadData", aLeadData);
						});
					}
					sap.ui.getCore().byId(viewId.split("-")[0] + "--" + "filterbar-btnGo").firePress();
				} else {
					this.delayFilter();
				}
			});
		},
		/**
		 * Fetches the count of Active SL's
		 * @param aFilters - Filters passed
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		callCount: function (aFilters) {
			let that = this;
			SLService.getSlListData(aFilters).then((oData) => {
				let count = " (" + oData.data.__count + ") ";
				if (that.getOwnerComponent().getModel("variant").getData().archivedStatus.key === "01") {
					that.getOwnerComponent().getModel("variant").setProperty("/currentcount", count);
				} else {

					that.getOwnerComponent().getModel("variant").setProperty("/archivedcount", count);
				}

			});
		},
		/**
		 * Sort and Group based on variant filter
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		sortandGroup: function () {
			let variantFilter = this.getOwnerComponent().getModel("variant").getData();
			let sortby = variantFilter.sort.sortby;
			let sortorderdesc = variantFilter.sort.sortorderdesc;
			let groupby = variantFilter.group.groupby;
			let grouporderdesc = variantFilter.group.grouporderdesc;
			var aSorters = [];
			var oBinding = this.getView().byId("slListTable").getBinding("items");
			var vGroup;
			if (groupby === null) {
				vGroup = this.mGroupFunctions["None"];
			} else {
				vGroup = this.mGroupFunctions[groupby];
				aSorters.push(new Sorter(groupby, grouporderdesc, vGroup));
			}
			aSorters.push(new Sorter(sortby, sortorderdesc, vGroup));
			oBinding.sort(aSorters);
		},

		/**
		 * Fetches SL's based on search. Locally filters the data. Function called when Go button is pressed
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		triggerTableFilter: function () {
			//this.byId("filterbar-btnGo").firePress();
			let sQuery = this.byId("globalSearch").getValue().trim();
			let oSlTable = this.byId("slListTable");
			let aFilter = [];
			if (sQuery) {
				aFilter.push(new Filter("AccountName", FilterOperator.Contains, sQuery));
				aFilter.push(new Filter("SlName", FilterOperator.Contains, sQuery));
				aFilter.push(new Filter("Opporutnityid", FilterOperator.Contains, sQuery));
				aFilter.push(new Filter("OpportunityName", FilterOperator.Contains, sQuery));
				aFilter.push(new Filter("OpportunityPhase", FilterOperator.Contains, sQuery));
				aFilter.push(new Filter("OpportunityStatus", FilterOperator.Contains, sQuery));
				aFilter.push(new Filter("LeadName", FilterOperator.Contains, sQuery));
				aFilter.push(new Filter("SlCompletion", FilterOperator.Contains, sQuery));
			}
			let temp = [];
			if (aFilter.length > 0) {
				temp.push(new Filter({
					filters: aFilter,
					and: false
				}));
			}
			oSlTable.getBinding("items").filter(temp);
			this.sortandGroup();

		},

		/**
		 * Fetches SL's based on filter and get active count of SL's. Private function of performTableFilter.
		 * @param aFilters - Filters passed for fetching SL's
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		callSL: function (aFilters) {
			let that = this;
			that.getOwnerComponent().getModel("appSettings").setProperty("/isTableBusy", true);
			SLService.getSlListData(aFilters).then((oData) => {
				that.getOwnerComponent().getModel("appSettings").setProperty("/isTableBusy", true);
				let count = " (" + oData.data.__count + ") ";
				if (that.getOwnerComponent().getModel("variant").getData().archivedStatus.key === "01") {
					that.getOwnerComponent().getModel("variant").setProperty("/archivedcount", count);
				} else {

					that.getOwnerComponent().getModel("variant").setProperty("/currentcount", count);
				}
				let aResults = oData.data.results;
				if (aResults.length > 0 && !this.getOwnerComponent().getModel("int_pg_opportunityoDataModel").isMetadataLoadingFailed()) {

					that.aAccountIDs = [];
					$.each(aResults, function (index, value) {
						if (!that.aAccountIDs[value.AccountId]) {
							if (value.AccountId !== "") {
								that.aAccountIDs[value.AccountId] = value.AccountId;

							}
						}
					}.bind(that));
					if (that.aAccountIDs.length > 0) {
						jQuery.sap.delayedCall(300, this, function () {
							this.callingAccountDetails(that.aAccountIDs, aResults);
						});

					}

				} else {

					jQuery.sap.delayedCall(300, this, function () {
						that.getOwnerComponent().getModel("slListModel").setProperty("/slData", oData.data.results);
						this.getOwnerComponent().getModel("appSettings").setProperty("/isTableBusy", false);
						if (!this.harmonyServiceCheck()) {
							MessageToast.show("Opportunity data unavailable!  Reason: Harmony server down or Unauthorized access!");
						}
					});

				}
				this.triggerTableFilter();
			});

		},
		/**
		 * Fetches SL's account information. Private function of callSL.
		 * @param aAccountIDs - Account ID's passed to fetch account information, aResults - data from SL's fetched
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		callingAccountDetails: function (aAccountIDs, aResults) {
			let that = this;
			that.aResultset = aResults;
			that.aAccountIDMap = [];
			that.getOwnerComponent().getModel("appSettings").setProperty("/isTableBusy", true);
			OppService.getSLListAccountDetails(aAccountIDs).then((oData) => {
				that.getOwnerComponent().getModel("appSettings").setProperty("/isTableBusy", true);
				for (var i in oData) {
					if (oData[i].data) {
						that.aAccountIDMap[oData[i].data.PARTNER] = oData[i].data;
					}
				}
				for (var j in that.aResultset) {
					if (that.aAccountIDMap[that.aResultset[j].AccountId]) {
						that.aResultset[j].AccountName = that.aAccountIDMap[that.aResultset[j].AccountId].PARTNER_NAME;
					}
					if (that.getOwnerComponent().getModel("opportunityData").getData().opportunityMapData) {
						if (that.getOwnerComponent().getModel("opportunityData").getData().opportunityMapData[that.aResultset[j].Opporutnityid]) {
							let oOpportunityData = that.getOwnerComponent().getModel("opportunityData").getData().opportunityMapData[that.aResultset[
								j].Opporutnityid];
							that.aResultset[j].OpportunityName = oOpportunityData.DESCRIPTION;
							that.aResultset[j].OpportunityPhase = that.getOwnerComponent().getModel("opportunityData").getData().oppPhaseMasterData[
								oOpportunityData.CURR_PHASE].VALUE;
							that.aResultset[j].OpportunityStatus = that.getOwnerComponent().getModel("opportunityData").getData().oppStatusMasterData[
								oOpportunityData.STATUS].VALUE;
						}
					}
				}
				that.getOwnerComponent().getModel("slListModel").setProperty("/slData", that.aResultset);
				that.getOwnerComponent().getModel("appSettings").setProperty("/isTableBusy", false);

			});
		},

		/**
		 * Validation check for date ranges start date and end date.
		 * @param oEvent - fetches the source control which triggered change
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		handleStartDateChange: function (oEvent) {
			let bValid = oEvent.getParameter("valid");
			let oDRS = oEvent.getSource();
			if (!oEvent.getSource().getValue()) {
				oDRS.setValueState("None");
			} else {
				if (bValid && oEvent.getParameter("to") && oEvent.getParameter("from")) {
					oDRS.setValueState("None");
				} else {
					oDRS.setValueState("Error");
					oDRS.setValueStateText("Please Provide Date Range");
				}
			}
		},
		/**
		 * Message box to display error. Private method of _successVaraint.
		 * @param sMsg - Custom message is passed
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		_displayErrorMsg: function (sMsg) {
			MessageBox.error(sMsg);
		},

		/**
		 * Fetches Varaint ID from url parameter, get default varaint. Private function of onInit.
		 * @param oEvent - Fetches the varaint id from routing
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		_onVariantMatched: function (oEvent) {
			let oArgs = oEvent.getParameter("arguments");
			let component = this.getOwnerComponent();
			let urlParameters = this.readFlpURLParameter(oArgs);
			if (urlParameters.hasOwnProperty("variantId") && Array.isArray(urlParameters.variantId) && urlParameters.variantId.length) {
				this.variantId = urlParameters.variantId[0];
			} else if (urlParameters.hasOwnProperty("variantId") && urlParameters.variantId) {
				this.variantId = urlParameters.variantId;
			} else {
				this.variantId = "";
			}
			this.getOwnerComponent().getModel("successlineModel").metadataLoaded().then(this._getDefaultVariant.bind(this));
		},

		//Function to read CF FLP Parameters
		readFlpURLParameter: function (oArgs) {
			let urlParameter = oArgs["?OptionalQueryString"] || {};
			if (sap.ushell.Container) {
				const parsedURLData =
					sap.ushell.Container.getService("URLParsing").parseShellHash(
						window.location.hash
					) || {};
				const params = parsedURLData["params"] || {};
				delete params["sap-app-origin-hint"];
				delete params["sap-ui-app-id-hint"];
				if (!Object.keys(params).length) {
					let appSpecificRoute = parsedURLData.appSpecificRoute || "";
					if (appSpecificRoute) {
						const urlParameter = Object.fromEntries(
							new URLSearchParams(appSpecificRoute.split("?")[1])
						);
						Object.keys(urlParameter).forEach((key) => {
							urlParameter[key] = [urlParameter[key]];
						});
						return urlParameter;
					}
				} else {
					return params;
				}
			}
			return urlParameter;
		},

		/**
		 * Gets varaint information from session storage or saved varaint and sets the varaint to view.
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		_getDefaultVariant: function () {
			let that = this;
			let savedVaraint;
			let savedVarObj = [];
			if (this.slosavedVariantObj.get("SLsessionStorageVariantObject")) {
				savedVarObj.push(this.slosavedVariantObj.get('SLsessionStorageVariantObject'));
				savedVaraint = this.slosavedVariantObj.get('SLsessionStorageVariantObject');
				this.slosavedVariantObj.put("SLsessionStorageVariantObject", null);
			}
			if (!savedVaraint) {
				this.bInitialLoad = true;
				let aFilter = [];
				if (this.variantId) {
					aFilter.push(new sap.ui.model.Filter({
						path: "variantid",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: this.variantId
					}));

				} else {
					aFilter.push(new sap.ui.model.Filter({
						path: "defaultVariant",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: "X"
					}));
				}
				this._loadVariants(aFilter);
			} else {
				this.getView().getModel("variants").setData(savedVarObj);
				if (savedVaraint.executeonselect !== "X") {
					this.bInitialLoad = false;
				}
				this._setVariantData(savedVaraint);
			}

		},

		/**
		 * Routes to Detail page
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		navToDetail: function (oEvent, flag) {
			this.slovariantStrage.put("SLsessionStorageVariantModel", this.getView().getModel("variant").getData());
			this.slovariantStrage.put("SLsessionStorageVariantID", this.iSelectedVariant);
			this.getRouter().navTo("SlDetail");

		},

		/**
		 * Routes to Form page
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		navToForm: function () {
			if (!this.harmonyServiceCheck()) {
				MessageToast.show("Opportunity data unavailable!  Reason: Harmony server down or Unauthorized access!");
			} else {
				this.slovariantStrage.put("SLsessionStorageVariantModel", this.getView().getModel("variant").getData());
				this.slovariantStrage.put("SLsessionStorageVariantID", this.iSelectedVariant);
				this.getRouter().navTo("SlForm");
			}
		},
		/**
		 * Called when the variant list dropdown is pressed. Displays the list of varaints for the user
		 * @param oEvent - gets the pressed button to open the varaint fragment.
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		displayVariants: function (oEvent) {
			if (!this._variantFmt) {
				this._variantFmt = sap.ui.xmlfragment("com.presalescentral.successline.fragments.Variant", this);
			}
			var oButton = oEvent.getSource();
			this.getView().addDependent(this._variantFmt);

			//sap.ui.getCore().byId("variantList").setBusy(false);
			sap.ui.getCore().byId("variantList").getBinding("items").attachDataReceived(function dataRecived() {
				sap.ui.getCore().byId("variantList").setBusy(false);
			});
			sap.ui.getCore().byId("variantList").setSelectedKey(this.variantId);
			if (this.variantEditFlag === "X") {
				sap.ui.getCore().byId("variantSave").setEnabled(true);
			} else {
				sap.ui.getCore().byId("variantSave").setEnabled(false);
			}
			this._variantFmt.openBy(oButton);

		},
		/**
		 * Called when Manage varaint button is pressed. Opens a fragment displaying a list of variants for user to share, set as default, execute on select.
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		handleManagePress: function () {
			if (!this.manageVariant) {
				this.manageVariant = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.ManageVariant",
					this);
				this.getView().addDependent(this.manageVariant);
			}
			this.manageVariant.open();
		},
		/**
		 * Called when save button is pressed. Opens create varaint fragment.
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		handleSavePress: function () {
			var variantObj = sap.ui.getCore().byId("variantList").getSelectedItem().getBindingContext("successlineModel").getObject();

			this.variants.setData(variantObj);
			if (!this._newVariantFmt) {
				this._newVariantFmt = sap.ui.xmlfragment("com.presalescentral.successline.fragments.CreateVariant", this);
			}

			this.getView().addDependent(this._newVariantFmt);
			this._newVariantFmt.open();
			sap.ui.getCore().byId("createVariant").setValueState("None");
		},
		/**
		 * Checks if execute on select, shared or default is checked. Private function of handleCreatePress.
		 * @param id - Passes execute on select or shared or default string
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		isCheckBoxSelected: function (id) {
			if (this.byId(id)) {
				return (this.byId(id).getSelected()) ? "X" : "";
			} else {
				return (sap.ui.getCore().byId(id).getSelected()) ? "X" : "";
			}

		},
		/**
		 * Creates a new varaint. Called when Save As variant Ok button is pressed.
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		handleCreatePress: function () {
			var newVariant;
			if (sap.ui.getCore().byId("createVariant")) {
				newVariant = sap.ui.getCore().byId("createVariant").getValue();
			} else {
				newVariant = this.byId("createVariant").getValue();
			}

			if (newVariant.trim() !== "") {
				//	this.getOwnerComponent().getModel("busy").setProperty("/isAppBusy", true);
				var that = this;
				var varientData = this.getOwnerComponent().getModel("variant").getData();
				this.variantmodelchange = new JSONModel(varientData, "variantchange");
				let value1 = this.byId("slCompletionId").getValue();
				let value2 = this.byId("slCompletionId").getValue2();
				var slCompletionvalue1, slCompletionvalue2;
				if (value1 > value2) {
					slCompletionvalue1 = this.byId("slCompletionId").getValue2();
					slCompletionvalue2 = this.byId("slCompletionId").getValue();
				} else {
					slCompletionvalue1 = this.byId("slCompletionId").getValue();
					slCompletionvalue2 = this.byId("slCompletionId").getValue2();
				}

				var slTeams = this.byId("multiTeamId").getSelectedKeys();
				this.variantmodelchange.setProperty("/myteammembers/value1", slTeams);
				this.variantmodelchange.setProperty("/slcompletion/value1", slCompletionvalue1);
				this.variantmodelchange.setProperty("/slcompletion/value2", slCompletionvalue2);
				if (this.variantmodelchange.getData().createdat.value1 && this.variantmodelchange.getData().createdat.value2) {
					this.variantmodelchange.setProperty("/createdat/value1", this.variantmodelchange.getData()
						.createdat.value1);
					this.variantmodelchange.setProperty("/createdat/value2", this.variantmodelchange.getData()
						.createdat.value2);
				}
				if (this.variantmodelchange.getData().estclosedate.value1 && this.variantmodelchange.getData().estclosedate.value1) {
					this.variantmodelchange.setProperty("/estclosedate/value1", this.variantmodelchange.getData()
						.estclosedate.value1);
					this.variantmodelchange.setProperty("/estclosedate/value2", this.variantmodelchange.getData()
						.estclosedate.value2);
				}

				var defaultVariant = this.isCheckBoxSelected("default");
				var shareVariant = this.isCheckBoxSelected("share");
				shareVariant = (shareVariant === "X") ? "S" : "P";
				var executeOnSelect = this.isCheckBoxSelected("executeOnSelect");
				var oEntry = {};
				if (this.variants.getData().variantid) {
					oEntry.variantid = this.variants.getData().variantid;
					oEntry.author = this.variants.getData().author;
					this.getView().byId("variantButton").setText(newVariant);
				} else {
					oEntry.variantid = "";
				}
				oEntry.applicationid = "SLREP";
				oEntry.variant_name = newVariant;
				oEntry.Favourite = "X";
				oEntry.type = shareVariant;
				oEntry.defaultVariant = defaultVariant;
				oEntry.executeonselect = executeOnSelect;
				//	oEntry.includeteam = (this.variantIncludeTeam === true) ? "X" : "";
				oEntry.includeteam = this.variantIncludeTeam;
				oEntry.view_name = this.variantViewName;
				oEntry.filterstring = JSON.stringify(this.variantmodelchange.getData());

				that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
				SLService.createVariant(oEntry).then((oData) => {
					that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
					that.getView().getModel("successlineModel").refresh();
					that._newVariantFmt.close();
				});
			} else {

				if (sap.ui.getCore().byId("createVariant")) {
					sap.ui.getCore().byId("createVariant").setValueState("Error");
				} else {
					this.byId("createVariant").setValueState("Error");
				}
				// this._newVariantFmt.close();
			}
		},
		/**
		 * Changes the error value state to none when user interacts
		 * @param oEvent - gets the source control
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		onCreateVariantChange: function (oEvent) {
			if (oEvent) {
				oEvent.getSource().setValueState("None");
			}

		},

		/**
		 * Opens create variant fragment and clears the validation state of the user input field
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		handleSaveAsPress: function () {

			this.variants.setData([]);
			if (!this._newVariantFmt) {
				this._newVariantFmt = sap.ui.xmlfragment(this.getView().getId(), "com.presalescentral.successline.fragments.CreateVariant", this);
			}

			this.getView().addDependent(this._newVariantFmt);
			this._newVariantFmt.open();
			this.getView().byId("createVariant").setValueState("None");

		},
		/**
		 * Closes the create variant fragment
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		handleCreateVariantCancel: function () {
			this._newVariantFmt.close();
		},
		/**
		 * Closes the manage variant fragment 
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		handleManageVariantCancel: function () {
			this.getView().getModel("dataChanged").setProperty("/dataChanged", true);
			this.manageVariant.close();
		},
		/**
		 * Called when a varaint is selected from the list and routes to List page with variant id 
		 * @param oEvent - gets the selected variant object
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		variantSelect: function (oEvent) {
			let varObj = oEvent.getParameter("item").getBindingContext("successlineModel").getObject();
			this.slosavedVariantObj.put('SLsessionStorageVariantObject', varObj);

			this.getOwnerComponent().getRouter().navTo("slvariant", {
				OptionalQueryString: {
					variantId: oEvent.getParameter("item").getBindingContext("successlineModel").getObject().variantid
				}
			}, false);
			this._variantFmt.close();
			if (oEvent.getParameter("item").getBindingContext("successlineModel").getObject().Editable === "X") {
				sap.ui.getCore().byId("variantSave").setEnabled(true);
			} else {
				sap.ui.getCore().byId("variantSave").setEnabled(false);
			}
		},

		/**
		 * Called when updating variants default, shared, add, change of variant name, execute on select values from manage variant fragment
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		handleManageVariantPress: function (oEvent) {
			var that = this;
			let dataSet = [];
			var tableId;
			let oModel = this.getView().getModel("dataChanged");
			let changed = this.getView().getModel("dataChanged").getProperty("/dataChanged");
			if (changed) {

				if (sap.ui.getCore().byId("variantManageTable")) {
					tableId = sap.ui.getCore().byId("variantManageTable");
				} else {
					tableId = this.byId("variantManageTable");
				}
				var tableItems = tableId.getItems();
				this.getView().getModel("successlineModel").setDeferredGroups(["manageVariantCategory"]);
				for (var i in tableItems) {

					tableItems[i].getBindingContext("successlineModel").getObject();
					var oEntry = {};
					oEntry.Editable = tableItems[i].getBindingContext("successlineModel").getObject().Editable;
					if (tableItems[i].getCells()[0].getSelected() || tableItems[i].getCells()[3].getSelected()) {
						oEntry.Favourite = "X";
					} else {
						oEntry.Favourite = "";
					}
					oEntry.applicationid = tableItems[i].getBindingContext("successlineModel").getObject().applicationid;
					oEntry.author = tableItems[i].getBindingContext("successlineModel").getObject().author;
					if (tableItems[i].getCells()[3].getSelected()) {
						oEntry.defaultVariant = "X";
					} else {
						oEntry.defaultVariant = "";
					}
					if (tableItems[i].getCells()[4].getSelected()) {
						oEntry.executeonselect = "X";
					} else {
						oEntry.executeonselect = "";
					}
					oEntry.filterstring = tableItems[i].getBindingContext("successlineModel").getObject().filterstring;
					oEntry.name_first = tableItems[i].getBindingContext("successlineModel").getObject().name_first;
					oEntry.name_last = tableItems[i].getBindingContext("successlineModel").getObject().name_last;
					oEntry.psuser = tableItems[i].getBindingContext("successlineModel").getObject().psuser;
					oEntry.seuser = tableItems[i].getBindingContext("successlineModel").getObject().seuser;
					oEntry.type = tableItems[i].getBindingContext("successlineModel").getObject().type;
					oEntry.variant_name = tableItems[i].getBindingContext("successlineModel").getObject().variant_name;
					oEntry.variantid = tableItems[i].getBindingContext("successlineModel").getObject().variantid;
					oEntry.view_name = tableItems[i].getBindingContext("successlineModel").getObject().view_name;

					dataSet.push(oEntry);

				}
				that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
				SLService.manageVaraints(dataSet).then((oData) => {
					that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
					MessageToast.show("Variant Updated Successfully");
				});

				this.getView().getModel("successlineModel").refresh();

				oModel.setProperty("/dataChanged", false);
				this.manageVariant.close();
			} else {
				oModel.setProperty("/dataChanged", false);
				//MessageToast.show("No changes made");
				this.manageVariant.close();
			}
		},
		onManageVariantDataChange: function () {
			let oModel = this.getView().getModel("dataChanged");
			oModel.setProperty("/dataChanged", true);
		},
		/**
		 * Called when delete variant is pressed in manage variant fragment
		 * @param oEvent - fetches the variant object path
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		handleVariantDelete: function (oEvent) {
			var that = this;
			let oModel = this.getView().getModel("dataChanged");
			oModel.setProperty("/dataChanged", true);
			that.deleteVariantPath = oEvent.getSource().getParent().getBindingContext("successlineModel").sPath;
			var dialog = new Dialog({
				title: 'Delete',
				type: 'Message',
				content: new sap.m.Text({
					text: 'Are you sure you want to Delete?'
				}),
				beginButton: new Button({
					text: 'Delete',
					press: jQuery.proxy(function (oEvent) {

						that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
						SLService.deleteVariant(this.deleteVariantPath).then((oData) => {
							that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
							MessageToast.show("Variant Deleted Successfully.");
						});
						dialog.close();
					}, this)
				}),
				endButton: new Button({
					text: 'Cancel',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});

			dialog.open();
		},
		/**
		 * Called when archived button is pressed. Fetches all the archived SL's and displays in the table.
		 * @param oEvent - fetches the selected key to pass to varaint filter string
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		handleArchived: function (oEvent) {
			var selectedKey = oEvent.getSource().getSelectedKey();
			var aArchivedStatus = {};
			aArchivedStatus.key = selectedKey;
			aArchivedStatus.value1 = selectedKey;
			this.getView().getModel("variant").setProperty("/archivedStatus", aArchivedStatus);
			this.delayFilter();
		},
		/**
		 * Navigates to Detail page
		 * @param oEvent - fetches the Successline No. to pass as parameter to router
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		handleNavToSlDetail: function (oEvent) {

			this.slovariantStrage.put("SLsessionStorageVariantModel", this.getView().getModel("variant").getData());
			this.slovariantStrage.put("SLsessionStorageVariantID", this.iSelectedVariant);
			this.getOwnerComponent().getRouter().navTo("SlDetail", {
				OptionalQueryString: {
					SuccessLineID: oEvent.getSource().getBindingContext("slListModel").getObject().SlNo
				}
			}, false);
		},
		/**
		 * Opens Personalization fragment 
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		onPersonalizationDialog: function () {
			if (!this.oPersonalizationDialog) {
				this.oPersonalizationDialog = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.PersonalizationDialog", this);
				this.getView().addDependent(this.oPersonalizationDialog, this);
			}

			this.getOwnerComponent().getModel("PersonalizationModel").setData(this.persdatacopy);

			let personalizationData = this.getView().getModel("PersonalizationModel").getData();
			let isManager = this.getView().getModel("variants").getData()[0].includeteam;
			let oVariantsData = this.getView().getModel("variants").getData()[0];
			let oVariantData = JSON.parse(oVariantsData.FilterString);
			if (isManager) {
				for (let i in personalizationData) {
					if (personalizationData[i].key === "myteammembers") {
						personalizationData[i].visible = true;
					}
				}
			} else {
				for (let j in personalizationData) {
					if (personalizationData[j].key === "myteammembers") {
						personalizationData[j].visible = false;
					}
				}
			}
			//set visibility based on variant for outcome
			if (Object.keys(oVariantData).indexOf("achieved") !== -1) {
				for (let k in personalizationData) {
					if (personalizationData[k].key === "achieved") {
						personalizationData[k].visible = true;
					}
				}
			} else {
				for (let l in personalizationData) {
					if (personalizationData[l].key === "achieved") {
						personalizationData[l].visible = false;
					}
				}
			}
			this.getOwnerComponent().getModel("PersonalizationModel").refresh(true);
			this.oPersonalizationDialog.open();

			// sap.git.usage.Reporting.addEvent(this.getOwnerComponent(), "Table personalization settings");
		},
		/**
		 * Closes Personalization fragment 
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		onPersonalizationDialogClose: function () {
			this.oPersonalizationDialog.close();

		},
		/**
		 * Local search in Personalization fragment 
		 * @param oEvent - Gets the user entered search key
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		onPersonalizationDialogSearch: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			var oColumnList = sap.ui.getCore().byId(this.createId("personalizationList"));
			oColumnList.getBinding("items").filter([new Filter(
				"name",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

		},
		/**
		 * Handles sorting based on user selection in personalization fragment
		 * @param oEvent - Gets the sort order
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		onPersonalizationDialogSort: function (oEvent) {
			var sortOrder = oEvent.getParameters().key;
			var bAsc = (sortOrder === "asc") ? false : true;
			this.oPersonalizationDialog.getContent()[0].getBinding("items").sort([new Sorter({
				path: "name",
				descending: bAsc
			})]);
		},
		/**
		 * Handles field visiblity based on variant in personalization fragment
		 * @param evt - Gets the field/column key
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		onFieldVisibility: function (evt) {
			let sColumnKey = evt.getParameter("listItem").getBindingContext("PersonalizationModel").getProperty("key"),
				oFilterField = this.getOwnerComponent().getModel("variant").getObject("/" + sColumnKey);

			//	if (iSelectedListLength < 7) {
			if (!oFilterField) {
				var oVariant = {
					"key": sColumnKey,
					"visible": false
				};
				this.getOwnerComponent().getModel("variant").getData()[sColumnKey] = oVariant;
			}
			if (evt.getParameter("selected")) {
				this.getOwnerComponent().getModel("variant").setProperty("/" + sColumnKey + "/visible", true);
			} else {
				if (sColumnKey === "createdat" || sColumnKey === "estclosedate") {
					this.getOwnerComponent().getModel("variant").setProperty("/" + sColumnKey + "/value1", null);
					this.getOwnerComponent().getModel("variant").setProperty("/" + sColumnKey + "/value2", null);
				} else {
					this.getOwnerComponent().getModel("variant").setProperty("/" + sColumnKey + "/value1", "");
				}
				this.getOwnerComponent().getModel("variant").setProperty("/" + sColumnKey + "/visible", false);
			}

		},
		/**
		 * Clears the filters in the list page
		 * @param oEvent - Gets the filters in the page
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		clearFilter: function (oEvent) {
			this.byId("expandendContent").setText("Not Filtered");
			this.byId("snappedContent").setText("Not Filtered");
			this.byId("globalSearch").setValue("");
			this.getOwnerComponent().getModel("variant").setProperty("/globalsearch/value1", "");
			this.getOwnerComponent().getModel("variant").setProperty("/leadname/value1", "");
			this.getOwnerComponent().getModel("variant").setProperty("/createdat/value1", null);
			this.getOwnerComponent().getModel("variant").setProperty("/createdat/value2", null);
			this.getOwnerComponent().getModel("variant").setProperty("/estclosedate/value1", null);
			this.getOwnerComponent().getModel("variant").setProperty("/estclosedate/value2", null);
			this.getOwnerComponent().getModel("variant").setProperty("/myteammembers/value1", "");
			this.getOwnerComponent().getModel("variant").setProperty("/slcompletion/value1", "0");
			this.getOwnerComponent().getModel("variant").setProperty("/slcompletion/value2", "100");
			this.byId("slCompletionId").setValue(0);
			this.byId("slCompletionId").setValue2(100);
			var selectionset = oEvent.getParameters().selectionSet;
			$.each(selectionset, function (index, value) {
				if (value.getMetadata().getElementName() === "sap.m.ComboBox") {
					value.setSelectedKey("");
				} else {
					value.setValue("");
				}
				if (value.getMetadata().getElementName() === "sap.m.MultiComboBox") {
					value.removeAllSelectedItems();
				}

			});
			this.delayFilter();
		},

		/**
		 * Opens the sorting and grouping fragment
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		onSortingDialog: function () {
			if (!this.sortingDialog) {
				this.sortingDialog = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.SortingGrouping", this);
				this.getView().addDependent(this.sortingDialog, this);
			}
			this.sortingDialog.open();
			let sortGroupDialog = this.getView().byId("sortGroupDialog");
			if (sortGroupDialog) {
				let variantFilter = this.getOwnerComponent().getModel("variant").getData();
				let sortby = variantFilter.sort.sortby;
				//let sortorderdesc = variantFilter.sort.sortorderdesc;
				let groupby = variantFilter.group.groupby;
				//let grouporderdesc = variantFilter.group.grouporderdesc;
				sortGroupDialog.setSelectedGroupItem(groupby);
				sortGroupDialog.setSelectedSortItem(sortby);
			}

		},
		/**
		 * Called when Ok is pressed in sorting and grouping fragment
		 * @param oEvent - Passed all the parameters for sorting and grouping
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		handleSortTableConfirm: function (oEvent) {
			var mParams = oEvent.getParameters();
			var oBinding = this.getView().byId("slListTable").getBinding("items");
			this.handleSortConfirm(oEvent, mParams, oBinding, "sortSlListTable");

		},
		/**
		 * Handles sorting and grouping of the SL's based on selected parameters from sorting and grouping fragment. Private function of handleSortTableConfirm
		 * @param oEvent - Passed all the parameters for sorting and grouping
		 * @param mParams - fetches group item and sort item
		 * @param oBinding - list of SL's to be sorted
		 * @param sortString- string value of called function
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		handleSortConfirm: function (oEvent, mParams, oBinding, sortString) {
			// apply sorter to binding
			// (grouping comes before sorting).
			var sPath;
			var bDescending;
			var vGroup;
			var aSorters = [];
			//Save variant data
			let variantFilter = this.getOwnerComponent().getModel("variant").getData();
			if (sortString === "sortEngagement") {
				aSorters.push(new Sorter("GlobalUltimateID", true, this.opportunityGrouper));
			}
			if (mParams.groupItem) {
				sPath = mParams.groupItem.getKey();
				bDescending = mParams.groupDescending;
				vGroup = this.mGroupFunctions[sPath];
				aSorters.push(new Sorter(sPath, bDescending, vGroup));
				variantFilter.group.groupby = sPath;
				variantFilter.group.grouporderdesc = bDescending;
			} else {
				vGroup = this.mGroupFunctions["None"];
				variantFilter.group.groupby = null;
			}
			if (mParams.sortItem) {
				sPath = mParams.sortItem.getKey();
				bDescending = mParams.sortDescending;
				aSorters.push(new Sorter(sPath, bDescending, vGroup));
				variantFilter.sort.sortby = sPath;
				variantFilter.sort.sortorderdesc = bDescending;
			}
			oBinding.sort(aSorters);
		},
		/**
		 * Called when team selection is changed
		 * @param oEvent - to fetch changed iteam and state
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		handleMyTeamSelectionChange: function (oEvent) {
			var changedItem = oEvent.getParameter("changedItem");
			var isSelected = oEvent.getParameter("selected");
			var state = "Selected";
			if (!isSelected) {
				state = "Deselected";
			}
			let oVariantFilter = this.getView().getModel("variant").getData();
			var slTeams = this.byId("multiTeamId").getSelectedKeys();
			oVariantFilter.myteammembers.value1 = slTeams;
		},
		/**
		 * Opens the contributor team fragment when there's more than one contributor.
		 * @param oEvent - to get the count of countributors
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		handleContbtrTeamPopup: function (oEvent) {
			if (parseInt(oEvent.getSource().getText()) !== 0) {
				let aSlTeam = oEvent.getSource().getBindingContext("slListModel").getProperty("toTeam/results");
				let aMgrTeam = this.getOwnerComponent().getModel("masterData").getProperty("/myTeamData");
				var aContrbtrTeam = [];
				$.each(aMgrTeam, function (index, team) {
					aSlTeam.filter((item) => {
						if (item.Userid === team.userid) {
							aContrbtrTeam.push(item);
						}
					});
				});
				this.getOwnerComponent().getModel("slListModel").setProperty("/Contributers", aContrbtrTeam);

				if (!this.contrbtrTeam) {
					this.contrbtrTeam = sap.ui.xmlfragment(this.getView().getId(),
						"com.presalescentral.successline.fragments.ListContrbtrTeam",
						this);
					this.getView().addDependent(this.contrbtrTeam);
				}
				this.contrbtrTeam.openBy(oEvent.getSource());
			}

		},
		/**
		 * Closes the contributor team fragment.
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		onCloseCntrbtrTeam: function () {
			this.contrbtrTeam.close();
		},
		/**
		 * shows user details in new tab
		 * @param oEvent - Get's the user's userid
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		viewUserDetails: function (oEvent) {
			const sUserId = oEvent.getSource().getBindingContext("slListModel").getProperty("Userid");
			window.open(this.constants["0071"].field_value + sUserId);
		},
		/**
		 * Called when email icon is pressed. Triggers native clients email with the contact's email address
		 * @param oEvent - Get's the contact email address from selected list
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		handleSendMailClick: function (oEvent) {
			sap.m.URLHelper.triggerEmail(oEvent.getSource().getBindingContext("slListModel").getProperty("Emailid"));
		},
		/**
		 * Called when Mobile icon is pressed. Triggers native clients call with the contact's mobile number
		 * @param oEvent - Get's the contact mobile number from selected list
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		handleCallPress: function (oEvent) {
			sap.m.URLHelper.triggerTel(oEvent.getSource().getBindingContext("slListModel").getProperty("Mobilenumber"));
		},
		/**
		 * Called when Mobile icon is pressed. Triggers native clients call with the contact's mobile number
		 * @param oEvent - Get's the contact mobile number from selected list
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		handleMobilePress: function (oEvent) {
			sap.m.URLHelper.triggerTel(oEvent.getSource().getBindingContext().getProperty("Mobilenumber"));
		},
		/**
		 * Called when Telephone icon is pressed. Triggers native clients call with the contact's phone number
		 * @param oEvent - Get's the contact phone number from selected list
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		handleTelPress: function (oEvent) {
			sap.m.URLHelper.triggerTel(oEvent.getSource().getBindingContext().getProperty("Phonenumber"));
		},
		/**
		 * Called when Completion range is changed to set the varaint filter for completion.
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		onSlCompletionChange: function (oEvent) {
			let oVariantFilter = this.getView().getModel("variant").getData();
			if (Object.keys(oVariantFilter).length !== 0) {
				let value1 = this.byId("slCompletionId").getValue();
				let value2 = this.byId("slCompletionId").getValue2();
				if (value1 > value2) {
					oVariantFilter.slcompletion.value1 = this.byId("slCompletionId").getValue2();
					oVariantFilter.slcompletion.value2 = this.byId("slCompletionId").getValue();
					this.byId("slCompletionId").setValue(value2);
					this.byId("slCompletionId").setValue2(value1);
				} else {
					oVariantFilter.slcompletion.value1 = this.byId("slCompletionId").getValue();
					oVariantFilter.slcompletion.value2 = this.byId("slCompletionId").getValue2();
				}
			}

		},
		/**
		 * Updates SL's in the table when search is empty.
		 * @param oEvent - gets the value from serach field
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		liveChangeTableFilter: function (oEvent) {
			if (oEvent.getSource().getValue() === "") {
				let viewId = this.getView().getId();
				sap.ui.getCore().byId(viewId.split("-")[0] + "--" + "filterbar-btnGo").firePress();
			}
		},
		/**
		 * Opens opportunity warning fragment
		 * @param oEvent - opens the fragment in the control
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		handleOpportunityWarning: function (oEvent) {
			if (!this.oppWarningFrgmt) {
				this.oppWarningFrgmt = sap.ui.xmlfragment("com.presalescentral.successline.fragments.OpportunityWarning", this);
				this.oView.addDependent(this.oppWarningFrgmt);
			}
			this.oppWarningFrgmt.openBy(oEvent.getSource());
		},
		/**
		 * Closes opportunity warning fragment
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		onCloseOppWarning: function () {
			this.oppWarningFrgmt.close();
		},
		/**
		 * Navigates to harmony site for Account link selected.
		 * @param oEvent - fetched Account ID
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		navToCRMAccnt: function (oEvent) {
			let sAccountId = oEvent.getSource().getBindingContext("slListModel").getProperty("AccountId");
			if (sAccountId) {
				window.open(this.constants["0185"].field_value + sAccountId, "_blank");
			}
		},
		/**
		 * Navigates to harmony site for Opportunit link selected.
		 * @param oEvent - fetched Opportunity ID
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		navToCRMOpp: function (oEvent) {
			let sOppId = oEvent.getSource().getBindingContext("slListModel").getProperty("Opporutnityid");
			if (sOppId) {
				window.open(this.constants["0183"].field_value + sOppId, "_blank");
			}
		},

		/**
		 * Handles create request dropdown change for IT Direct and Translation to navigate to respective pages.
		 * @param oEvent - gets the selected key
		 * @memberOf com.presalescentral.successline.view.SlList
		 */
		handleCreateService: function (oEvent) {
			// "https://fiorilaunchpad-wfd7746b4.dispatcher.int.sap.hana.ondemand.com/sites#pctranslationform-app"
			let sSelectedKey = oEvent.getSource().getSelectedKey();
			if (sSelectedKey === "0002") {
				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
				var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
					target: {
						semanticObject: "pctranslationform",
						action: "app"
					}
				})) || ""; // generate the Hash to display a Supplier
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: hash
					}
				});
			} else {
				window.open(this.constants["0075"].field_value);
			}

		},

		openOutcomeStatusPopover: function (oEvent) {
			if (!this.outcomeStatusPopover) {
				this.outcomeStatusPopover = sap.ui.xmlfragment("com.presalescentral.successline.fragments.OutcomeStatus", this);
				this.getView().addDependent(this.outcomeStatusPopover);
			}
			let aData = oEvent.getSource().getBindingContext("slListModel").getObject().to_Outcomes.results;
			this.getOwnerComponent().getModel("slListModel").setProperty("/OutcomeStatus", aData);
			this.outcomeStatusPopover.openBy(oEvent.getSource());
		},

		openOutcomeAchievedPopover: function (oEvent) {
			if (!this.outcomeAchievedPopover) {
				this.outcomeAchievedPopover = sap.ui.xmlfragment("com.presalescentral.successline.fragments.OutcomeAchieved", this);
				this.getView().addDependent(this.outcomeAchievedPopover);
			}
			let aData = oEvent.getSource().getBindingContext("slListModel").getObject().to_Outcomes.results;
			this.getOwnerComponent().getModel("slListModel").setProperty("/OutcomeAchieved", aData);
			this.outcomeAchievedPopover.openBy(oEvent.getSource());
		}

	});

});