sap.ui.define([
	"com/presalescentral/successline/controller/BaseController",
	"com/presalescentral/successline/service/OppService",
	"com/presalescentral/successline/service/SLService",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/BindingMode",
	"sap/ui/core/message/Message",
	"sap/m/MessageToast",
	"sap/ui/core/library",
	"sap/ui/core/Element",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterType",
	"sap/ui/model/FilterOperator",
	"sap/m/Token",
	"sap/m/MessageBox",
	"sap/ui/model/SimpleType",
	"sap/ui/model/ValidateException",
	"sap/ui/core/routing/History",
	"sap/base/Log",
	"sap/ui/util/Storage",
	"com/presalescentral/successline/classes/SuccessLine",
	"com/presalescentral/successline/classes/Template",
	"com/melody/lib/util/opportunity/Opportunity"
], function (BaseController, OppService, SLService, JSONModel, BindingMode, Message, MessageToast, library, Element, Filter, FilterType,
	FilterOperator, Token, MessageBox, SimpleType, ValidateException, History, Log, Storage, SuccessLine, Template, OpportunityUtil) {
	"use strict";
	// shortcut for sap.ui.core.ValueState
	let ValueState = library.ValueState;

	// shortcut for sap.ui.core.MessageType
	let MessageType = library.MessageType;

	return BaseController.extend("com.presalescentral.successline.controller.SlForm", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onInit: function () {
			let that = this;
			this.View = this.getView();
			this.initView();
			this._emptyFormModel();
			// set message model
			let oMessageManager;
			oMessageManager = sap.ui.getCore().getMessageManager();
			this.View.setModel(oMessageManager.getMessageModel(), "messageModel");
			oMessageManager.registerObject(this.getView(), true);
			this._oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			let oRouter = this.getRouter();
			oRouter.getRoute("SlForm").attachPatternMatched(this._onRouteMatched, this);
			this.ConstantsMap = {};
			this.constStorage = new Storage(Storage.Type.session);
			this.ConstantsMap = this.constStorage.get('ConstantsMapData');
			this._setConstants();
			this.getView().getModel("formModel").setProperty("/previewVisible", false);
			var oData = {
				Status: sap.ui.core.IndicationColor.Indication06
			};
			var oModel = new JSONModel(oData);
			this.getView().setModel(oModel, "colors");
			this.oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
		},

		/**
		 * Called to set constants. Private function of onInit function.
		 * Used for fetching navigation liknks to Harmony
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		_setConstants: function () {
			this.constStorage = new Storage(Storage.Type.session);
			this.constants = this.constStorage.get('ConstantsMapData');
		},

		/**
		 * Called to validate link. Private function of onSave function.
		 * Used for validation check of url when story document link is entered by user.
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		_validURL: function (str) {
			var pattern = /^(http[s]?:\/\/){0,1}(www\.){0,1}[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,5}[\.]{0,1}/;
			return !!pattern.test(str);
		},

		/**
		 * Called when a controller is instantiated. Private function of onInit function.
		 * Creates an empty form model to set empty form and set default selections like the Opportunity radio button selected by default, opportunity templates are loaded by default and information icon is hidden.
		 * * @param selectedIndex - selected radio button for opportunity or account
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		_emptyFormModel: function (selectedIndex) {
			if (!selectedIndex) {
				selectedIndex = 0;
			}
			let oModel;
			oModel = new JSONModel({
				SelectOpportunity: "",
				AccountName: "",
				Region: "",
				MarketUnit: "",
				Industry: "",
				SuccessLineName: "",
				StartDate: null,
				EstimatedCloseDate: null,
				Template: "",
				TemplateInfo: "",
				OpportunitiesComments: "",
				Story: "",
				StoryDocumentLink: "",
				SelectTeam: null,
				ValidationFlag: false,
				SlId: "00000000-0000-0000-0000-000000000000",
				SlNo: "",
				Links: null,
				to_acc: null,
				to_opp: null,
				selectedIndex: selectedIndex,
				SLStatus: "01",
				editable: true,
				AccountID: "",
				LinkTitle: "",
				dataChanged: false,
				previewVisible: false,
				OREConfigID: "",
				TemplatePreview: new Template(),
				SlLead: "",
				SlLeadName: "",
				isSLLeadCurrentUser: false,
				CurrentUser: "",
				to_addopp: [],
				isCopySL: false,
				isSlTeam: true,
				isSlAttachments: true,
				isDisabledService: true,
				RefSlNo: " ",
				newCopy: false,
				TempUpdFlag: "",
				MainTempId: "",
				TempVer: "",
				MainTempVer: "",
				RiskId: "",
				RiskComment: ""
			});
			oModel.setDefaultBindingMode(BindingMode.TwoWay);
			this.View.setModel(oModel, "formModel");
			this.View.setModel(new JSONModel([]), "userSearch");
			this.View.setModel(new JSONModel([]), "leadSearch");
			this.View.setModel(new JSONModel([]), "alluserModel");
			this.View.setModel(new JSONModel([]), "preExistingSuccessLineModel");
			this.selectedTeam = {};
			this.byId("oppInfo").setVisible(false);
			this.getView().getModel("formModel").setProperty("/previewVisible", false);
			let templatedata = this.getOwnerComponent().getModel("masterData").getProperty("/templates");
			var arr = [];
			for (var i = 0; i < templatedata.length; i++) {
				if (this.RapidOutcome) {
					if (templatedata[i].IsRapidOutcome === "X" && templatedata[i].TempTypeId === "0001" && templatedata[i].Active) {
						arr.push(templatedata[i]);
					}
				} else {
					if (templatedata[i].TempTypeId === "0001") {
						arr.push(templatedata[i]);
					}
				}
			}
			this.getView().getModel("formModel").setProperty("/templateData", arr);

			var templateId = this.getView().byId("templateid");
			templateId.setValue("");
			templateId.setSelectedKey("");

			if (this.RapidOutcome && arr.length && selectedIndex === 0) {
				this.setRapidOutcomeTemplate(arr);
			}

			let user = this.getOwnerComponent().getModel("user").getData();
			let currentuser = user.UserId;
			let currentUserName = user.UserName;
			this.getView().getModel("formModel").setProperty("/SlLead", currentuser);
			this.getView().getModel("formModel").setProperty("/SlLeadName", currentUserName);
			this.getView().getModel("formModel").setProperty("/CurrentUser", currentuser);
			this.SLLeadEmail = user.UserEmail;
			var theme = sap.ui.getCore().getConfiguration().getTheme();
			if (theme === "sap_horizon") {
				this.getView().getModel("formModel").setProperty("/AccountName", "Select Opportunity/Account");
			}
		},

		setRapidOutcomeTemplate: function (arr) {
			let tempTypeId = 0;
			let imaxTempTypeId = 0;
			if (arr.length > 1) {
				for (let i = 0; i < arr.length; i++) {
					for (let j = 1; j < arr.length; j++) {
						if (Number(arr[i].TempTypeId) < Number(arr[j].TempTypeId)) {
							imaxTempTypeId = arr[i];
						}
					}
				}
			} else if (arr.length === 1) {
				imaxTempTypeId = arr[0];
			}
			//set the template with the rapidoutcome default template	
			var templateId = this.getView().byId("templateid");
			templateId.setValue(imaxTempTypeId.TempTitle);
			templateId.setSelectedKey(imaxTempTypeId.TempId);
			templateId.fireChange();
		},

		/**
		 * Called when the navigation menu SL-List is clicked.
		 * Navigated to the SuccessLine List page.
		 * * @memberOf com.presalescentral.successline.view.SlForm
		 */
		navToList: function () {
			this.onClearPress();
			this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").setValue("");
			this.getView().getModel("opportunityModel").setProperty("/opptValueState", "None");
			this.getRouter().navTo("SlList");
		},

		/**
		 * Called when the navigation menu Detail is clicked.
		 * Navigated to the SuccessLine Detail page.
		 * * @memberOf com.presalescentral.successline.view.SlForm
		 */
		navToDetail: function () {
			this.onClearPress();
			this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").setValue("");
			this.getView().getModel("opportunityModel").setProperty("/opptValueState", "None");
			this.getRouter().navTo("SlDetail");
		},

		//function to handle Non-ore navigation
		fnSetNonOreNavigation: function () {
			//Non-ore Auth
			let oAppSettingModel = this.getView().getModel("appSettings");
			let isNonOreUser = oAppSettingModel.getProperty("/isNonOreUser");
			let isSlEditForm = oAppSettingModel.getProperty("/isSlEditForm");
			let isSlCreateForm = oAppSettingModel.getProperty("/isSlCreateForm");
			let isSlEditDetail = oAppSettingModel.getProperty("/isSlEditDetail");

			if (document.location.hasOwnProperty("hash")) {
				isSlCreateForm = (document.location.hash.indexOf("SlForm") !== -1) ? true : false;
				isSlEditForm = (document.location.hash.indexOf("?SlNo=") !== -1) ? true : false;
				isSlEditDetail = (document.location.hash.indexOf("SuccessLineID") !== -1) ? true : false;
			}

			if (isNonOreUser && isSlCreateForm && !isSlEditForm) {
				this.getRouter().getTargets().display("NonOreUserNotAuthorized", {
					fromTarget: "SlList"
				});
				return;
			}
		},

		/**
		 * Called when routing changes
		 * Routes to Form page in Create and Edit mode based on arguments passed.
		 * @param oEvent - To obtain the SuccessLine ID passed.
		 * * @memberOf com.presalescentral.successline.view.SlForm
		 */
		_onRouteMatched: function (oEvent) {
			let oThisController = this;
			this._emptyFormModel();
			this.onClearPress();
			let oArgs;
			oArgs = oEvent.getParameter("arguments");
			this.RapidOutcome = false;

			//Non-ore Auth
			this.fnSetNonOreNavigation();

			if (oArgs["?OptionalQueryString"] && oArgs["?OptionalQueryString"].SlNo) {
				let SlNo = oEvent.getParameter("arguments")["?OptionalQueryString"].SlNo;
				if (SlNo !== undefined) {
					this.createMode = "EDIT";
					this.View.getModel("formModel").setProperty("/SlNo", SlNo);
					this.getOwnerComponent().getModel("successlineModel").metadataLoaded().then(this.delayCall(SlNo));
				}
			} else {
				if (!this.harmonyServiceCheck()) {
					this.getRouter().navTo("SlServiceDown");
					return;
				}
				if (this.opportunityComponentInstance) {
					this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").setValue("");
					this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").setEditable(true);
					this.getView().getModel("opportunityModel").setProperty("/opptValueState", "None");
					this.getView().getModel("activityTypeModel").setProperty("/isOpportunity", true);
					this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/OPPT_ID", "");
					this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/AccountId_Name", "");
					this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/accountid", "");
					oThisController.fnInitializeMslExitsFunctionality();
				}
				if (oArgs["?OptionalQueryString"] && oArgs["?OptionalQueryString"].RapidOutcome) {
					let RapidOutcome = oEvent.getParameter("arguments")["?OptionalQueryString"].RapidOutcome;
					if (RapidOutcome !== undefined && RapidOutcome === 'create') {
						this.RapidOutcome = true;
					}
				}
			}
			sap.ui.getCore().getMessageManager().removeAllMessages();
			if (this.getView().getModel("opportunityModel")) {
				this.getView().getModel("opportunityModel").setProperty("/opptValueState", "None");
			}
			this._emptyFormModel();
			var opportunityModel = this.getView().getModel("opportunityModel");
			if (opportunityModel) {
				if (opportunityModel.getProperty("/opportunity")) {
					var oppoList = opportunityModel.getProperty("/opportunity");
					oppoList.filter(function (obj) {
						obj.addOppPrevSelect = false;
						obj.addOppSelected = false;
					});
				}
			}
			this.OppDataInit = true;
			this.getOwnerComponent().getModel("masterData").setProperty("/AddOppCopy", []);
		},

		/**
		 * Called for fetching existing SL data. Private function of _onRouteMatched.
		 * Delay call is used to assure current user's opportunity data is available in the model.
		 * @param SlNo - Successline No is passed as argument to fetch SL details in form and display them.
		 * * @memberOf com.presalescentral.successline.view.SlForm
		 */
		delayCall: function (SlNo) {
			jQuery.sap.delayedCall(300, this, function () {
				if (!this.harmonyServiceCheck()) {
					this.fnInitializeMslExitsFunctionality();
					this.getSuccessLine(SlNo);
					return;
				}
				if (this.getOwnerComponent().getModel("opportunityData").getData().opportunityMapData !== undefined) {
					this.fnInitializeMslExitsFunctionality();
					this.getSuccessLine(SlNo);
				} else {
					this.delayCall(SlNo);
				}

			});
		},

		/**
		 * Called for fetching existing SL data.
		 * Delay call is used to assure current user's opportunity data is available in the model.
		 * @param SlNo - Successline No is passed as argument to fetch SL details in form and display them.
		 * * @memberOf com.presalescentral.successline.view.SlForm
		 */
		getSuccessLine: function (SlNo) {
			let that = this;
			that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
			SLService.getCreatedSuccessLine(SlNo).then((oData) => {
				that._successGetSl(oData.data.results);
			});
		},
		/**
		 * Called for fetching existing SL data. Private function of getSuccessLine
		 * Maps fetched SL data to form. Handles Display and Edit mode. Checks for Archived and Unauthorized access.
		 * @param oData - Data fetched for selected SL No.
		 * * @memberOf com.presalescentral.successline.view.SlForm
		 */
		_successGetSl: function (oData) {
			let that = this;
			that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
			let oForm = this.View.getModel("formModel");
			let oAppSettingModel = that.getOwnerComponent().getModel("appSettings");
			let isNonOreUser = oAppSettingModel.getProperty("/isNonOreUser");
			let user = this.getOwnerComponent().getModel("user").getData();
			let currentuser = user.UserId;
			let MU = user.MuName;
			oForm.setProperty("/SlNo", oData[0].SlNo);
			oForm.setProperty("/SlId", oData[0].SlId);
			oForm.setProperty("/SLStatus", oData[0].SLStatus);
			oForm.setProperty("/SuccessLineName", oData[0].Name);
			oForm.setProperty("/StartDate", oData[0].StartDate);
			oForm.setProperty("/EstimatedCloseDate", oData[0].EstCloseDate);
			oForm.setProperty("/Template", oData[0].TempTitle);
			oForm.setProperty("/TempId", oData[0].TempId);
			oForm.setProperty("/TemplateInfo", oData[0].TempDesc);
			oForm.setProperty("/MainTempId", oData[0].MainTempId);
			oForm.setProperty("/TempVer", oData[0].TempVer);
			oForm.setProperty("/MainTempVer", oData[0].MainTempVer);
			oForm.setProperty("/OREConfigID", oData[0].OREConfigID);
			oForm.setProperty("/OpportunitiesComments", oData[0].OppComments);
			oForm.setProperty("/Story", oData[0].Story);
			oForm.setProperty("/MarketUnit", MU !== "" ? MU : "Currently Unavailable");
			oForm.setProperty("/AccountID", oData[0].AccountId);
			oForm.setProperty("/OpportunityId", oData[0].OpportunityId);
			oForm.setProperty("/TempOpportunityId", oData[0].OpportunityId);
			oForm.setProperty("/to_acc", oData[0].to_acc.results);
			oForm.setProperty("/to_opp", oData[0].to_opp.results);
			oForm.setProperty("/SlLead", oData[0].SlLead);
			oForm.setProperty("/SlLeadName", oData[0].SlLeadName);
			oForm.setProperty("/CurrentUser", currentuser);
			oForm.setProperty("/IsArchive", oData[0].IsArchive);
			let slCompleted = parseInt(oData[0].SlCompletion);
			oForm.setProperty("/SlCompletion", slCompleted);
			oForm.setProperty("/RefSlNo", oData[0].RefSlNo);
			oForm.setProperty("/TempUpdFlag", oData[0].TempUpdFlag);
			//If the Risk Id is "", set it default (03)
			if (oData[0].RiskId === "") {
				oData[0].RiskId = "03";
				oForm.setProperty("/RiskId", oData[0].RiskId);
			} else {
				oForm.setProperty("/RiskId", oData[0].RiskId);
			}
			oForm.setProperty("/RiskComment", oData[0].RiskComment);
			if (oData[0].SlLead === currentuser) {
				oForm.setProperty("/isSLLeadCurrentUser", true);
			} else {
				oForm.setProperty("/isSLLeadCurrentUser", false);
			}

			let links = oData[0].to_link.results;
			oForm.setProperty("/Links", links);
			let storyLink = this.byId("storyDocumentLink");
			if (links.length > 0) {
				for (let i = 0; i < links.length; i++) {
					if (links[i].LinkType === 3) {
						storyLink.setValue(links[i].Link);
						oForm.setProperty("/LinkTitle", links[i].LinkTitle);
					}
				}
			}
			let teams = oData[0].to_team.results;
			for (let i = 0; i < teams.length; i++) {
				if (!this.selectedTeam.hasOwnProperty(teams[i].UserId)) {
					this.selectedTeam[teams[i].UserId] = teams[i];
				}
			}
			this.getView().getModel("alluserModel").setData(this.selectedTeam);
			this.bCopSlLeadID = oData[0].SlLead;
			this.bCopSlLeadName = oData[0].SlLeadName;
			this.bCopySelectedteam = jQuery.extend(true, {}, this.selectedTeam);
			if (this.selectedTeam[currentuser] || oData[0].Creator === currentuser || oData[0].SlLead === currentuser) {
				oForm.setProperty("/editable", true);
				this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").setEditable(true);
			} else {
				oForm.setProperty("/editable", false);
				this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").setEditable(false);
			}

			//If the logged in user is a Non-ore user then disable all the fields
			if (isNonOreUser) {
				oForm.setProperty("/editable", false);
				this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").setEditable(false)
			}

			let editable = oForm.getProperty("/editable");
			if (oData[0].Creator === currentuser || oData[0].SlLead === currentuser) {
				oForm.setProperty("/isCopySL", true);
			} else {
				oForm.setProperty("/isCopySL", false);
			}
			if (!this.harmonyServiceCheck()) {
				if (oData[0].OpportunityId) {

					oForm.setProperty("/selectedIndex", 0);
					this.byId("oppLabel").setText("Select Opportunity");
					oForm.setProperty("/AccountName", "Currently Unavailable");
					this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").setValue(oData[0].OpportunityId);

				} else if (oData[0].AccountId) {
					oForm.setProperty("/selectedIndex", 1);
					this.byId("oppLabel").setText("Select Account");
					oForm.setProperty("/AccountName", "Currently Unavailable");
					this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").setValue(oData[0].AccountId);

				}
			}

			OppService.getAccountDetails(oData[0].AccountId).then((response) => {
				let statusdata = this.getView().getModel("opportunityData").getData().oppStatusMasterData;
				let phasedata = this.getView().getModel("opportunityData").getData().oppPhaseMasterData;
				let status = response.data.STATUS;
				let StatusDes = "Not Authorized";
				let PhasesDes = "Not Authorized";
				let sEstimatedCloseDate = this.getView().getModel("formModel").getProperty("/sUpdatedClosedDate");
				if (sEstimatedCloseDate === "" || sEstimatedCloseDate === undefined) {
					sEstimatedCloseDate = this.getView().getModel("formModel").getData().EstimatedCloseDate;
				}
				if (statusdata[status]) {
					StatusDes = statusdata[status].VALUE;
				}
				this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/ACCOUNT_NAME", response.data.PARENT_NAME ?
					response.data.PARENT_NAME : "Unavailable");
				this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/STATUS_DESC", StatusDes);
				this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/SEGMENT", response.data.SEGMENT);
				this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/OWNER_NAME", response.data.PARENT_ACC_OWNR_NM);
				this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/Active_Account_Status", response.data.STATUS_DESC);
				this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/Regional_Buying_Classification", response.data.GTM_BUY_REG_DESC);
				this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/Regional_Buying_Lifecycle", response.data.GTM_BUY_GLB_DESC);
				this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/Internal_Account_Classification", response.data.TG_ACCOUNT_DESC);
				this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/ISS", response.data.GTM_ISS_DESC);
				this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/IMS", response.data.SEGMENT_DESC);
				this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/ERPID", response.data.ERP_ID);
				this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/EstimatedCloseDate", sEstimatedCloseDate);

				var AccountID = that.getView().getModel("formModel").getProperty("/AccountID");
				this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/accountid", AccountID);

				if (oData[0].to_acc.results.length === 0) {
					let accstruct = {
						"accountname": response.data.PARENT_NAME,
						"accountid": oData[0].AccountId,
						"industry": "NA",
						"iss": response.data.GTM_ISS_DESC,
						"iac": response.data.TG_ACCOUNT_DESC
					};
					oForm.getData().to_acc.push(accstruct);
				}

				if (oData[0].OpportunityId) {
					oForm.setProperty("/OpportunityId", oData[0].OpportunityId);
					this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").setValue(oData[0].OpportunityId);
					that.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/OPPT_ID", oData[0].OpportunityId);
					let data = that.getOwnerComponent().getModel("opportunityData").getData().opportunityMapData[oData[0].OpportunityId];
					const dateFormat = sap.ui.core.format.DateFormat.getInstance({
						pattern: "dd/MM/y",
						calendarType: sap.ui.core.CalendarType.Gregorian
					});
					if (data) {
						let statusLcl = data.STATUS;
						let statusDesc = "Not Authorized";
						if (statusdata[statusLcl]) {
							statusDesc = statusdata[statusLcl].VALUE;
						}
						let phase = data.CURR_PHASE;
						if (phasedata[phase]) {
							PhasesDes = phasedata[phase].VALUE;
						}

						that.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/DESCRIPTION", data.DESCRIPTION);
						that.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/ACCOUNT_NAME", data.ACCOUNT_NAME);
						that.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/OWNER_NAME", data.OWNER_NAME);
						that.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/STATUS_DESC", statusDesc);
						that.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/SALES_ORG_DESC", data.SALES_ORG_TEXT);
						that.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/PHASE_DESC", PhasesDes);
						that.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/CURR_PHASE", phase);
						that.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/OPP_EXPECT_END", dateFormat.format(new Date(
							data.EXPECT_END)));
						oForm.setProperty("/AccountName", data.ACCOUNT_NAME !== "" ? data.ACCOUNT_NAME :
							"Currently Unavailable");
						oForm.setProperty("/EstimatedCloseDate", sEstimatedCloseDate);
						oForm.setProperty("/Industry", data.INDUSTRY_MASTERCODE_TEXT !== "" ? data.INDUSTRY_MASTERCODE_TEXT :
							"Currently Unavailable");
						that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
						SLService.getOpptProfitCenterData(oData[0].OpportunityId).then((regionData) => {
							that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
							if (regionData.data.results.length > 0) {
								oForm.setProperty("/Region", regionData.data.results[0].region !== "" ? regionData.data.results[0].region :
									"Currently Unavailable");
								oForm.setProperty("/SubRegion", regionData.data.results[0].sub_region !== "" ? regionData.data.results[0].sub_region :
									"Currently Unavailable");
							}
						});
						this._getOpportunityData(oData[0].OpportunityId);
						if (oData[0].to_opp.results.length === 0) {
							let oppstruct = {
								"OPPT_ID": oData[0].OpportunityId,
								"DESCRIPTION": data.DESCRIPTION
							};
							oForm.getData().to_opp.push(oppstruct);
						}

					} else {
						oForm.setProperty("/AccountName", "Not Authorized");
						oForm.setProperty("/Industry", "Not Authorized");
						oForm.setProperty("/Region", "Not Authorized");
						oForm.setProperty("/SubRegion", "Not Authorized");
						oForm.setProperty("/MarketUnit", "Not Authorized");
						oForm.setProperty("/OpportunitiesComments", "Not Authorized");
						that.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/OPP_EXPECT_END", "Not Authorized");
						var struct = {};
						struct.OPPT_ID = oData[0].OpportunityId;
						struct.DESCRIPTION = "Not Authorized";
						oForm.getData().to_opp.push(struct);
						that.View.getModel("formModel").setProperty("/SelectTeam", []);
					}
					this.getView().getModel("activityTypeModel").setProperty("/isOpportunity", true);
					oForm.setProperty("/selectedIndex", 0);
					this.byId("oppLabel").setText("Select Opportunity");
					this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").setValue(oData[0].OpportunityId);
				} else if (oData[0].AccountId) {
					oForm.setProperty("/AccountName", response.data.PARENT_NAME !== "" ? response.data.PARENT_NAME :
						"Currently Unavailable");
					this.getView().getModel("activityTypeModel").setProperty("/isOpportunity", false);
					oForm.setProperty("/selectedIndex", 1);
					this.byId("oppLabel").setText("Select Account");
					this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").setValue(oData[0].AccountId);
					that.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/AccountId_Name", oData[0].AccountId);
					oForm.setProperty("/Region", "Currently Unavailable");
					oForm.setProperty("/MarketUnit", "Currently Unavailable");
					oForm.setProperty("/Industry", "Currently Unavailable");
					oForm.setProperty("/OpportunitiesComments", "Currently Unavailable");
				}
			});
			//show info help on Edit mode
			that.byId("oppInfo").setVisible(true);
			that.getView().getModel("formModel").setProperty("/previewVisible", false);
			if (oData[0].SLStatus === "02" || oData[0].Archive) {
				oForm.setProperty("/editable", false);
				this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").setEditable(false);
			}
			// setting template title if it is inactive
			var templateId = that.getView().byId("templateid");
			if (templateId.getSelectedKey() && !templateId.getValue()) {
				templateId.setValue(oData[0].TempTitle);
			}

			var to_addopp = oData[0].to_addopp.results;
			to_addopp.filter(function (obj) {
				obj.AccountID = oData[0].AccountId;
			});
			oForm.setProperty("/to_addopp", oData[0].to_addopp.results);
		},

		/**
		 * Called when routing changes with SuccessLine ID.
		 * Check if the SuccessLine ID id valid, If not show Not found page.
		 * @param oEvent - To obtain the SuccessLine ID passed.
		 * * @memberOf com.presalescentral.successline.view.SlForm
		 */
		_onBindingChange: function (oEvent) {
			// No data for the binding
			if (!this.getView().getBindingContext()) {
				this.getRouter().getTargets().display("notFound");
			}
		},

		/**
		 * called when the opportunity component gets loaded
		 * @param oEvent - To obtain the opportunity component instance.
		 * * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onOpportunityComponentLoaded: function (oEvent) {
			let oThisController = this;
			this._emptyFormModel();
			this.opportunityComponentInstance = oEvent.getSource().getComponentInstance();
			this.opportunityComponentInstance.getModel("oppServerModel").attachMetadataLoaded(this.getOpportunityData, this);
			this.opportunityComponentInstance.getModel("oppServerModel").attachMetadataFailed(function (oEvt) {
				let oParams = oEvt.getParameters();
				Log.info(oParams.response);
				if (this.opportunityComponentInstance.getModel("oppServerModel").oMetadata.bFailed && !this.sloStorage.get("showHarmonyError")) {
					MessageToast.show(this._oResourceBundle.getText("xmsg.haronyNoAuthorization"), {
						duration: 9000,
						width: "30em"
					});
					this.sloStorage.put("showHarmonyError", true);
				}
			}, this);
			let oOpportunityModel = this.opportunityComponentInstance.getModel("opportunityModel");
			this.opportunityComponentInstance.getRootControl().getController().fnComponentTriggerChange(this.onOppModelChange, this);
			this.View.setModel(this.opportunityComponentInstance.getModel("activityTypeModel"), "activityTypeModel");
			this.View.getModel("activityTypeModel").setProperty("/projectType", "ACTVT");
			this.View.getModel("activityTypeModel").setProperty("/isSuccessLine", true);
			this.getView().getModel("activityTypeModel").setProperty("/isOpportunity", true);
			this.View.setModel(oOpportunityModel, "opportunityModel");
			this.aOpportunityTeam = oOpportunityModel.getProperty("/selectedOpportunityTeam");

			//TO Fetch MSL Exists Data Based on ActOpportunity loaded
			oThisController.fnInitializeMslExitsFunctionality();
		},

		//function to intialize MSL Exits Functionality
		fnInitializeMslExitsFunctionality: function () {
			let oThisController = this;
			if (!this.oStorage.get("actOpportunities") && !this.oStorage.get("pcOpportunities")) {
				let username = this.getView().getModel("user").getProperty("/UserId");
				this.opportunityComponentInstance._oOpportunityHelper._getBusinessPartner(username, oThisController.fnLoadMSLFunctionality.bind(
					this));
				// $.when(this.fnDefferredForOpp()).then(() => {
				// 	oThisController.fnLoadMSLFunctionality(800);
				// });
			} else {
				oThisController.fnSetFormatUiMainOppChangeFlag();
				oThisController.fnLoadMSLFunctionality(0);
			}
		},

		/**
		 * called when the opportunity input gets changed. Checks for Pre-existing SL.
		 * * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onOppModelChange: function () {
			var that = this;
			let selectedOpportunity = that.getView().getModel("opportunityModel").getProperty("/selectedOpportunity");
			let statusData = that.getOwnerComponent().getModel("opportunityData").getData().oppStatusMasterData;
			let phaseData = that.getOwnerComponent().getModel("opportunityData").getData().oppPhaseMasterData;
			selectedOpportunity.STATUS_DESC = "Not Authorized";
			selectedOpportunity.PHASE_DESC = "Not Authorized";
			if (selectedOpportunity.STATUS) {
				if (statusData[selectedOpportunity.STATUS]) {
					selectedOpportunity.STATUS_DESC = statusData[selectedOpportunity.STATUS].VALUE;
				}
			}
			if (selectedOpportunity.CURR_PHASE) {
				if (phaseData[selectedOpportunity.CURR_PHASE]) {
					selectedOpportunity.PHASE_DESC = phaseData[selectedOpportunity.CURR_PHASE].VALUE;
				}
			}
			this.getView().getModel("opportunityModel").setProperty("/opptValueState", "None");
			let selectTeamId = that.byId("selectTeam");
			selectTeamId.setValueState("None");
			//this._validateSLAvailable();
			this.onContinueNewSL();
			let aAddOpp = this.getView().getModel("formModel").getProperty("/to_addopp");
			var isEditable = this.getView().getModel("formModel").getProperty("/editable");
			let sIndex;

			var oForm = this.View.getModel("formModel");
			oForm.setProperty("/bChangedAdditionalOpp", false);
			var isAccount = oForm.getProperty("/selectedIndex");
			const dateFormat = sap.ui.core.format.DateFormat.getInstance({
				pattern: "dd/MM/y",
				calendarType: sap.ui.core.CalendarType.Gregorian
			});
			if (isAccount === 0) {
				if (selectedOpportunity.OPP_EXPECT_END) {
					that.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/OPP_EXPECT_END", dateFormat.format(new Date(
						selectedOpportunity.EXPECT_END)));
				}
				if (oForm.getProperty("/EstimatedCloseDate") === null) {
					this.View.byId("estimatedCloseDate").setDateValue(new Date(selectedOpportunity.EXPECT_END));
				} else {
					this.View.byId("estimatedCloseDate").setDateValue(new Date(selectedOpportunity.EXPECT_END));
				}

				//updating the actOpp data and Opportunity data in primary fragment
				let isCopy = oForm.getProperty("/newCopy");
				if (!isCopy) {
					let sPreviousOppData = oForm.getProperty("/TempOpportunityId");
					this.fnUpdateMSLDataStorage(sPreviousOppData, true);
				}
			}
			if (isEditable && aAddOpp.length && isAccount === 0) {
				aAddOpp.filter(function (item, index) {
					if (item.Opportunityno === selectedOpportunity.OPPT_ID) {
						sIndex = index;
					}
				});
				if (sIndex >= 0) {
					aAddOpp.splice(sIndex, 1);
				}
			} else if (isAccount === 1) {
				var length = aAddOpp.length - 1;
				var sAccountId = selectedOpportunity.accountid;
				for (var i = length; i >= 0; i--) {
					if (aAddOpp[i].AccountID !== sAccountId) {
						aAddOpp.splice(i, 1);
					}
				}
				this.fnDeSelectAddOppos(aAddOpp, sAccountId);
			}
			this.getView().getModel("formModel").setProperty("/to_addopp", aAddOpp);
		},

		//function to update MSL update in actOpp session storage
		fnUpdateMSLDataStorage: function (OPP_ID, bMainOpp) {
			if (!OPP_ID) {
				return;
			}
			if (!this.oStorage) {
				this.oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			}
			let aActOppData = $.extend(true, [], this.oStorage.get("actOpportunities"));
			let oOppCompModel = this.opportunityComponentInstance.getModel("opportunityModel");
			let aOppCompData = $.extend(true, [], oOppCompModel.getProperty("/opportunity"));
			let aUpdatedSessionOppData = this.fnFindIndexAndUpdateForOppData(aActOppData, "OPPT_ID", OPP_ID, bMainOpp);
			let aUpdatedOppComData = this.fnFindIndexAndUpdateForOppData(aOppCompData, "OPPT_ID", OPP_ID, bMainOpp);

			//Session Storage
			if (aUpdatedSessionOppData.length) {
				this.oStorage.put("actOpportunities", aUpdatedSessionOppData);
			}

			//Primary Opp Data
			if (aUpdatedOppComData.length) {
				oOppCompModel.setProperty("/opportunity", aUpdatedOppComData);
				oOppCompModel.refresh();
			}
		},

		//function to find index and return the  index value
		fnFindIndexAndUpdateForOppData: function (aOppArray, key, value, bMainOpp) {
			let iIndex = -1;
			if (aOppArray.length) {
				iIndex = aOppArray.findIndex((oRow) => {
					return oRow[key] === value;
				});

				if (iIndex !== -1) {
					let oOppData = $.extend(true, {}, aOppArray[iIndex]);
					if (bMainOpp) {
						oOppData.bUIMainOppChange = true;
					}
					if (oOppData && oOppData.hasOwnProperty("SlExists")) {
						if (oOppData.SlExists === "X") {
							oOppData.SlExists = "";
							if (oOppData.bAdditionalOpp) {
								oOppData.bAdditionalOpp = false;
							}
						}
					}
					aOppArray[iIndex] = oOppData;
					return aOppArray;
				}
			}
			return [];
		},

		//Function to de-select Additional Opporunities for a selected Account
		fnDeSelectAddOppos: function (aAddOpp, sAccountId) {
			var oOppoPopUpList = this.getView().byId("slAdditionalOpptList");
			if (oOppoPopUpList) {
				var oOppoPopUpItems = oOppoPopUpList.getItems();
				var OpportunityModel = this.getView().getModel("opportunityModel");
				oOppoPopUpItems.filter(function (item, index) {
					var path = item.getBindingContextPath();
					var selectedTeam = OpportunityModel.getProperty(path);
					if (selectedTeam.ACCOUNT !== sAccountId) {
						item.getContent()[0].getItems()[0].firePress();
						item.getContent()[0].getItems()[0].setText("Select");
						OpportunityModel.setProperty(path + "/addOppSelected", false);
					}
				});
			}
		},

		/**
		 * Fetches Opportunity Data
		 * @param oppId - Passing Opportunity ID to fetch Opportunity Data
		 * * @memberOf com.presalescentral.successline.view.SlForm
		 */
		_getOpportunityData: function (oppId) {
			let that = this;
			let oForm = this.getView().getModel("formModel");
			let SlId = oForm.getProperty("/SlId");
			that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
			let successFn = async function (oResponse) {
				sap.ui.getCore().getMessageManager().removeAllMessages();
				that.View.getModel("formModel").setProperty("/Industry", oResponse.INDUSTRY_MASTERCODE_TEXT !== "" ? oResponse.INDUSTRY_MASTERCODE_TEXT :
					"Currently Unavailable");
				let aOREOppTeam = await OpportunityUtil.getOppTeamWithOREAccess(oResponse.OPPT_ID);
				that.View.getModel("formModel").setProperty("/SelectedUsers", aOREOppTeam);
				that.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/SALES_ORG_DESC", oResponse.SALES_ORG_TEXT);
				that.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/OWNER_NAME", oResponse.OWNER_NAME);
				let selectedUser = that.View.getModel("formModel").getProperty("/SelectedUsers");
				let arr = [];
				for (var i = 0; i < selectedUser.length; i++) {
					if (selectedUser[i].USER_ID && selectedUser[i].EMAIL) {
						selectedUser[i].checked = true;
						let team = {
							"SlId": SlId,
							"Role": selectedUser[i].ROLE,
							"UserId": selectedUser[i].USER_ID,
							"FullName": selectedUser[i].NAME,
							"PhoneNumber": selectedUser[i].TELEPHONE_NUMBER,
							"MobileNumber": selectedUser[i].MOBILE_NUMBER,
							"EmailId": selectedUser[i].EMAIL,
							"checked": false
						};
						arr.push(team);
					}
				}
				that.View.getModel("formModel").setProperty("/SelectTeam", arr);
				that.View.getModel("formModel").setProperty("/OpportunitiesComments", "Currently Unavailable");
				if (oResponse.Notes.results.length > 0) {
					for (let i = 0; i < oResponse.Notes.results.length; i++) {
						if (oResponse.Notes.results[i].TDID === "ZO17") {
							that.View.getModel("formModel").setProperty("/OpportunitiesComments", oResponse.Notes.results[i].CONC_LINES !== "" ?
								oResponse
									.Notes.results[i].CONC_LINES :
								"Currently Unavailable");
						}
					}
				}
				that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
			};
			that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
			that.opportunityComponentInstance._oOpportunityHelper._getOpportunitiesTeam(oppId,
				"SALES_ORG_TEXT,OPPT_ID,ACCOUNT_NAME,ACCOUNT,DESCRIPTION,OWNER,OWNER_NAME,STATUS,CURR_PHASE,INDUSTRY_MASTERCODE,INDUSTRY,INDUSTRY_MASTERCODE_TEXT,INDURSTRY_TEXT,PartiesInvolved,Notes",
				successFn);
		},
		/**
		 * Called when opportunity/account is selected/changed. Private function of onOppModelChange function.
		 * Checks if SL exists for selected opportunity/account. If an SL exists with the selected Opportunity/account, a message is displayed. If an SL does not exist for selected Opportunity/Account, then realted details like Industry, MU are fecthed.
		 * * @param oData - If SL preexists, the paramter returns the contact information and details of preexisting SL.
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		_successlineAvailable: function (oData, isAddOpp, oSource, oppoModel) {
			let that = this;
			let message = "";
			let continueMessage = "Click on OK to Continue.";
			let activeSL = false;
			let selectedIndex = that.getView().getModel("formModel").getProperty("/selectedIndex");
			let aActiveSl = [];
			let bUserPart = false;
			let oFormModel = that.getView().getModel("formModel");
			let aTemplateData = this.getView().getModel("formModel").getProperty("/templateData");
			let oPreExistingSuccessLineModel = that.getView().getModel("preExistingSuccessLineModel");
			if (oData.data.results.length > 0 && selectedIndex === 0) {
				for (var i = 0; i < oData.data.results.length; i++) {
					let oTempResult = oData.data.results[i];
					if (!oTempResult.Archive) { //not archived
						if (oTempResult.SLStatusID === "01") { //Active SL
							if (oTempResult.MainOpp || (!oTempResult.MainOpp && oTempResult.SlOpp)) {
								message = "Already an active SL exists for the same opportunity";
								oData.data.results[i].message = message;
								activeSL = true;
								oData.data.results[i].Active = true;
								aActiveSl.push(oData.data.results[i]);
							}
						} else { //Cancelled SL
							message = "Already a cancelled SL exists for the same opportunity, \nPlease reopen #SL number " + oData.data.results[i].SlSnro +
								" and continue with same.";
							oData.data.results[i].message = message;
							oData.data.results[i].Active = true;
						}
					} else {
						oData.data.results[i].Active = false;
						message = "Already an archived SL is created for the same opportunity, \nPlease unarchive #SL number " + oData.data.results[i].SlSnro +
							" and continue with same.";
						oData.data.results[i].message = message;
					}
					let user = this.getOwnerComponent().getModel("user").getData();
					let currentUserId = user.UserId;
					let currentUserName = user.UserName;
					if (!oData.data.results[i].Archive) {
						if (oData.data.results[i].SLStatusID === "01" && oTempResult.IsPartOfSl === "X") {
							bUserPart = true;
						}
					}
				}

				/*
				 * Edit Scenario's
				 * With respsect to the selection of Additional Opportunities
				 * Only In case of Opportunities manipulated from UI for both session storage and Opp model data
				 * After data manipulation, we need to ignore the current SL data from the response after filter.
				 */
				if (isAddOpp && aActiveSl.length === 1) {
					let oActiveSL = $.extend(true, [], aActiveSl[0]);
					let sCurrentSL = oFormModel.getProperty("/SlNo");
					if (oActiveSL.SlSnro === sCurrentSL) {
						activeSL = false;
					}
				}

				if (activeSL) {
					that.getView().getModel("preExistingSuccessLineModel").setData(aActiveSl);
					//Validate User part of the pre-existing SuccessLine
					if (bUserPart) {
						oPreExistingSuccessLineModel.setProperty("/bUsrPart", true);
						oPreExistingSuccessLineModel.setProperty("/bUsrNotPart", false);
					} else {
						oPreExistingSuccessLineModel.setProperty("/bUsrPart", false);
						oPreExistingSuccessLineModel.setProperty("/bUsrNotPart", true);
					}
					that.getView().getModel("preExistingSuccessLineModel").setProperty("/activeSL", activeSL);
					that.getView().getModel("preExistingSuccessLineModel").setProperty("/continueMessage", continueMessage);
					that.getView().getModel("formModel").setProperty("/ValidationFlag", false);
					//Clear Opp/Account related data only
					if (!isAddOpp) {
						that.byId("oppInfo").setVisible(false);
						let name = that.getView().getModel("formModel").getProperty("/AccountName");
						that.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/AccountId_Name", name);
						that.getView().getModel("formModel").setProperty("/AccountName", name);
					}
					that.getView().getModel("formModel").setProperty("/previewVisible", false);
					sap.ui.getCore().getMessageManager().removeAllMessages();
					that._preExistingSuccessLine();
					if (oSource) {
						oSource.setPressed(false);
					}
				} else {
					if (isAddOpp) {
						var sPath = oSource.getBindingContext("opportunityModel").getPath();
						oppoModel.setProperty(sPath + "/addOppSelected", true);
						oSource.setText("Deselect");
						return;
					}
					this.onContinueNewSL();
				}
			} else {
				this.onContinueNewSL();
			}
		},
		/**
		 * Called when the close button is pressed for PreExistingSuccessLine fragment.
		 * Closes PreExistingSuccessLine fragment.
		 * * @memberOf com.presalescentral.successline.fragments.PreExistingSuccessLine
		 */
		onClosePreExistingSL: function () {
			let that = this;
			let prevAcc;
			prevAcc = that.getView().getModel("formModel").getProperty("/OpportunityId");
			that.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/OPPT_ID", prevAcc);
			//that.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/AccountId_Name", "");
			//that.getView().getModel("formModel").setProperty("/AccountName", "");
			//that.View.getModel("formModel").setProperty("/OpportunitiesComments", "");
			//that.View.getModel("formModel").setProperty("/EstimatedCloseDate", null);
			sap.ui.getCore().getMessageManager().removeAllMessages();
			this.preExistingDialog.close();
		},
		onContinueNewSL: function () {
			let that = this;
			let unavailable = "Currently Unavailable";
			let selectedOpportunity = that.getView().getModel("opportunityModel").getProperty("/selectedOpportunity");
			let oppId = that.View.getModel("opportunityModel").getProperty("/selectedOpportunity/OPPT_ID");
			this.dataChanged();
			this.byId("oppInfo").setVisible(true);
			//this .byId("templateinfo").setVisible(true);
			this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").setValueState(ValueState.None);
			that.View.getModel("formModel").setProperty("/AccountName", selectedOpportunity.ACCOUNT_NAME !== "" ? selectedOpportunity.ACCOUNT_NAME :
				"Currently Unavailable");
			if (selectedOpportunity.EXPECT_END) {
				let date = new Date(selectedOpportunity.EXPECT_END);
				that.View.getModel("formModel").setProperty("/EstimatedCloseDate", date);
			}
			//Rapid Outcomes
			if (this.RapidOutcome) {
				let slname = "";
				let slStory = "";
				let templatedata = this.getOwnerComponent().getModel("masterData").getProperty("/templates");
				var arr = [];
				for (var i = 0; i < templatedata.length; i++) {
					if (oppId && oppId !== "") {
						if (templatedata[i].IsRapidOutcome === "X" && templatedata[i].TempTypeId === "0001" && templatedata[i].Active) {
							arr.push(templatedata[i]);
						}
					} else {
						if (templatedata[i].IsRapidOutcome === "X" && templatedata[i].TempTypeId === "0002") {
							arr.push(templatedata[i]);
						}
					}
				}
				that.getView().getModel("formModel").setProperty("/templateData", arr);
				if (this.RapidOutcome && arr.length) {
					this.setRapidOutcomeTemplate(arr);
				}
				if (oppId && oppId !== "") {
					slname = "Outcome Tracking for Opportunity " + oppId;
					slStory = "This SuccessLine is designed to track Outcomes on Opportunity " + oppId;

				} else {
					slname = "Outcome Tracking for Account " + selectedOpportunity.accountid;
					slStory = "This SuccessLine is designed to track Outcomes on Account " + selectedOpportunity.accountid;
				}
				that.View.getModel("formModel").setProperty("/Story", slStory);
				that.View.getModel("formModel").setProperty("/StartDate", new Date());
				that.View.getModel("formModel").setProperty("/SuccessLineName", slname);
			}

			if (oppId && oppId !== "") {
				that.View.getModel("formModel").setProperty("/OpportunityId", oppId);
				that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
				SLService.getOpptProfitCenterData(oppId).then((regionData) => {
					that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
					if (regionData.data.results.length > 0) {
						that.View.getModel("formModel").setProperty("/Region", regionData.data.results[0].region !== "" ? regionData.data.results[0]
							.region :
							"Currently Unavailable");
					} else {
						that.View.getModel("formModel").setProperty("/Region", "Currently Unavailable");
					}

					sap.ui.getCore().getMessageManager().removeAllMessages();
				});
				that._getOpportunityData(oppId);
				if (that.View.getModel("user")) {
					let MU = that.View.getModel("user").getProperty("/MuName");
					that.View.getModel("formModel").setProperty("/MarketUnit", MU !== "" ? MU : "Currently Unavailable");
				} else {
					that.View.getModel("formModel").setProperty("/MarketUnit", unavailable);
				}
			} else {
				that.View.getModel("formModel").setProperty("/MarketUnit", unavailable);
				that.View.getModel("formModel").setProperty("/Industry", unavailable);
				that.View.getModel("formModel").setProperty("/Region", unavailable);
				that.View.getModel("formModel").setProperty("/SubRegion", unavailable);
				that.View.getModel("formModel").setProperty("/OpportunitiesComments", unavailable);
			}
			if (this.preExistingDialog) {
				this.preExistingDialog.close();
			}
		},
		/**
		 * Called when radio button to select opportunity or account changes.
		 * Changes the label based on the slected radiobutton.
		 * @param oEvent - To obtain the selected radio button index.
		 * * @memberOf com.presalescentral.successline.view.SlForm
		 */

		onOpportunityRBchange: function (oEvent) {
			let selectedRB = oEvent.getParameter("selectedIndex");
			let templatedata = this.getOwnerComponent().getModel("masterData").getProperty("/templates");
			var arr = [];
			let that = this;
			that.getView().getModel("formModel").setProperty("/ValidationFlag", true);
			sap.ui.getCore().getMessageManager().removeAllMessages();
			this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").setValue("");
			this.getView().getModel("opportunityModel").setProperty("/opptValueState", "None");
			let selectTeamId = that.byId("selectTeam");
			selectTeamId.setValueState("None");
			that._emptyFormModel(selectedRB);
			this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/OPPT_ID", "");
			this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/AccountId_Name", "");
			this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/accountid", "");
			if (selectedRB === 1) {
				this.getView().getModel("activityTypeModel").setProperty("/isOpportunity", false);
				for (var i = 0; i < templatedata.length; i++) {
					if (this.RapidOutcome) {
						if (templatedata[i].IsRapidOutcome === "X" && templatedata[i].TempTypeId === "0002") {
							arr.push(templatedata[i]);
						}
					} else {
						if (templatedata[i].TempTypeId === "0002") {
							arr.push(templatedata[i]);
						}
					}
				}
				this.getView().getModel("formModel").setProperty("/templateData", arr);

			} else {
				this.getView().getModel("activityTypeModel").setProperty("/isOpportunity", true);
				for (var i = 0; i < templatedata.length; i++) {
					if (this.RapidOutcome) {
						if (templatedata[i].IsRapidOutcome === "X" && templatedata[i].TempTypeId === "0001") {
							arr.push(templatedata[i]);
						}
					} else {
						if (templatedata[i].TempTypeId === "0001") {
							arr.push(templatedata[i]);
						}
					}
				}
				this.getView().getModel("formModel").setProperty("/templateData", arr);

			}
			// if (this.RapidOutcome) {
			// 	this.setRapidOutcomeTemplate(arr);
			// }

		},
		/**
		 * Called when Select Team value help is pressed.
		 * Opens the user search fragment to select users from opportunity team or SAP 
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */

		handleUserSearchMulti: function (oEvent) {
			var oSource = oEvent.getSource();
			if (!this.userSearchMultiDialog) {
				this.userSearchMultiDialog = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.UserSearch",
					this);
				this.getView().addDependent(this.userSearchMultiDialog);
			}
			this.userSearchMultiDialog.openBy(oSource);
		},

		/**
		 * Called when Select Team tokens are changed
		 * Handles deleting the user from select team 
		 * @param oEvent - Fetch the removed/added tokens
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onTokenUpdate: function (oEvent) {
			let removedtokens = oEvent.getParameters().removedTokens.length;
			if (removedtokens > 0) {
				let removedTokenKey = oEvent.getParameters().removedTokens[0].getKey();
				let i = removedTokenKey;
				delete this.selectedTeam[i];
			}
			this.dataChanged();
		},

		/**
		 * Called when Select Team list for opportunity is selected/unselected.
		 * Handles selection of user list from Opportunity teams.
		 * *@param oEvent - To obtain the selected/unselected users
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		handleTeamSelect: function (oEvent) {
			let selectedUser;
			selectedUser = oEvent.getParameter("listItem").getBindingContext("formModel").getObject();
			if (oEvent.getParameter("selected")) {
				if (!this.selectedTeam.hasOwnProperty(selectedUser.UserId)) {
					selectedUser.Role = selectedUser.Role || "ZOZOSOAD";
					this.selectedTeam[selectedUser.UserId] = selectedUser;
				} else {
					MessageToast.show(selectedUser.FullName + " Already present.");
				}
			} else {
				delete this.selectedTeam[selectedUser.UserId];
			}
			this.byId("selectTeam").setValueState("None");
			this.dataChanged();
		},

		/**
		 * Called when Select Team list for SAP users is selected/unselected.
		 * Handles selection of user list from SAP users.
		 * *@param oEvent - To obtain the selected/unselected users
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		handleTeamSelectSAP: function (oEvent) {
			let oForm = this.getView().getModel("formModel");
			let SlId = oForm.getProperty("/SlId");
			let selectedUser;
			let bindingContext = oEvent.getParameter("listItem").getBindingContext("userSearch");
			selectedUser = bindingContext.getObject();
			if (oEvent.getParameter("selected")) {
				if (!this.selectedTeam.hasOwnProperty(selectedUser.Id)) {
					let team = {
						"SlId": SlId,
						"Role": selectedUser.CrmRoleId || "ZOZOSOAD",
						"UserId": selectedUser.Id,
						"FullName": selectedUser.Name,
						"PhoneNumber": selectedUser.PhoneNo,
						"MobileNumber": selectedUser.PhoneNo,
						"EmailId": selectedUser.Email,
						"checked": true,
						"CRMRoleId": selectedUser.CrmRoleId,
						"CRMRoleDesc": selectedUser.CrmRoleDesc
					};
					this.selectedTeam[selectedUser.Id] = team;
				} else {
					MessageToast.show(selectedUser.Name + " Already present.");
				}
			} else {
				delete this.selectedTeam[selectedUser.Id];
			}
			this.byId("selectTeam").setValueState("None");
			this.dataChanged();
			this.getView().getModel("alluserModel").setData(this.selectedTeam);
			this.getView().getModel("alluserModel").refresh(true);
		},

		/**
		 * Called when user serach fragment is closed by clicking Cancel
		 * Handles clearing search fields and removing selections from the user lists and closes the fragment.
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onCloseUserSelectDialog: function () {
			this.byId("userSearchMulti").setValue("");
			this.byId("userSearchMultiSAP").setValue("");
			this.byId("UserListMulti").removeSelections();
			this.byId("UserListMultiSAP").removeSelections();
			//Update list
			let query = "";
			let aFilter = [];
			aFilter.push(new Filter("FullName", FilterOperator.Contains, query));
			let aSAPFilter = [];
			aSAPFilter.push(new Filter("Name", FilterOperator.Contains, query));
			let oList = this.getView().byId("UserListMulti");
			let oSAPList = this.getView().byId("UserListMultiSAP");
			let oBinding = oList.getBinding("items");
			let oSAPBinding = oSAPList.getBinding("items");
			oBinding.filter(aFilter);
			oSAPBinding.filter(aSAPFilter);
			this.byId("UserListMultiSAP").removeAllItems();
			this.byId("idIconTabBarNoIcons").setSelectedKey("info");
			this.getView().getModel("alluserModel").refresh(true);
			this.userSearchMultiDialog.close();
		},

		/**
		 * Called when user serach fragment is closed by clicking Ok
		 * Sets selected users to select team and calls function to clear user list and close fragment.
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		handleUserSelectMulti: function () {
			this.getView().getModel("alluserModel").setData(this.selectedTeam);
			this.onCloseUserSelectDialog();
		},

		/**
		 * Called when template is selected
		 * Sets the selected teamplate
		 * @param oEvent - To obtain the selected template.
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */

		onTemplateSelection: function (oEvent) {
			let that = this;
			let bItemPressed = (oEvent.getParameters().itemPressed) ? oEvent.getParameters().itemPressed : false;
			let oForm = this.getView().getModel("formModel");
			let key = oEvent.getSource().getSelectedItem().getKey();
			let template = oEvent.getSource().getSelectedItem().getText();
			let tempDesc = oEvent.getSource().getSelectedItem().getBindingContext("formModel").getObject().TempDesc;
			let oreConfig = oEvent.getSource().getSelectedItem().getBindingContext("formModel").getObject().OREConfigID;
			oForm.setProperty("/TemplateInfo", tempDesc);
			oForm.setProperty("/Template", template);
			oForm.setProperty("/TempId", key);
			oForm.setProperty("/MainTempId", oEvent.getSource().getSelectedItem().getBindingContext("formModel").getObject().MainTempId);
			oForm.setProperty("/TempVer", oEvent.getSource().getSelectedItem().getBindingContext("formModel").getObject().TempVer);
			oForm.setProperty("/MainTempVer", oEvent.getSource().getSelectedItem().getBindingContext("formModel").getObject().MainTempVer);
			oForm.setProperty("/OREConfigID", oreConfig);
			oEvent.getSource().setValueState("None");
			this.dataChanged();
			this.getView().getModel("formModel").setProperty("/previewVisible", true);
			this._getDefaultRole();
			this._getActivitySuffix(key);
			SLService.getTemplatePreview(key).then((oData) => {
				const oTemplate = new Template(oData.data.results[0]);
				let aTempActvts = oData.data.results[0].to_tact.results;
				let aActvtSuffix = that.getView().getModel("formModel").getProperty("/ActvtSuffix");
				let sDefaultRole = that.getView().getModel("formModel").getProperty("/DefaultRole");
				$.each(aTempActvts, function (index, actvt) {
					actvt.Weight = actvt.ActivityWt;
					aActvtSuffix.filter((item) => {
						if (actvt.role_id === "") { //All Role
							if (item.ActivityId === actvt.ActivityId && item.RoleMpngID === sDefaultRole) {
								//	actvt.Title = item.ActivityTypeDesc;
								actvt.role_id = item.RoleMpngID; //Change for Activity Role
							}
						}
						//commented for BUG: Role designations should not be made in the Preview area when creating a MSL #137
						/*	else {
								if (item.ActivityId === actvt.ActivityId && item.RoleMpngID === actvt.role_id) {
									actvt.Title = item.ActivityTypeDesc;
								}
							}*/
					});
				});
				if (oData.data.results[0].to_tphase) {
					oTemplate.setPhases(oData.data.results[0].to_tphase.results);
					if (oData.data.results[0].to_ttpnt) {
						oTemplate.setTouchPoints(oData.data.results[0].to_ttpnt.results,
							oData.data.results[0].to_tact.results ? oData.data.results[0].to_tact.results : []
						);
					}
					that.getView().getModel("formModel").setProperty("/TemplatePreview", oTemplate);
					let rows = that.getView().byId("TreeTableBasic").getRows();
					if (bItemPressed) {
						rows[3]._setFocus(true);
					}
				}
			});

		},

		/**
		 * Called when the save button is pressed.
		 * Checks for required fields and saves the newly created successline.
		 * * @memberOf com.presalescentral.successline.view.SlForm
		 */

		onSave: function () {

			let that = this;
			let selectedOpportunity = this.getView().getModel("opportunityModel").getProperty("/selectedOpportunity");
			let oForm = this.getView().getModel("formModel");
			let changed = oForm.getProperty("/dataChanged");
			let oSaveSl = {};
			let to_opp = {};
			let oppRBSelected = this.getView().getModel("activityTypeModel").getProperty("/isOpportunity");
			let SlId, SlNo;
			let year, month, day, value1Date;
			let startyear, startmonth, startday, value2Date;
			let to_oppdata = oForm.getProperty("/to_opp");
			let date = oForm.getProperty("/EstimatedCloseDate");
			let startdate = oForm.getProperty("/StartDate");
			let to_acc = oForm.getProperty("/to_acc");
			let industrydata = oForm.getProperty("/Industry");
			let accountName = oForm.getProperty("/AccountName");
			let sRiskId = oForm.getProperty("/RiskId");
			let sRiskComment = oForm.getProperty("/RiskComment");
			sap.ui.getCore().getMessageManager().removeAllMessages();
			oForm.setProperty("/ValidationFlag", true);
			SlId = oForm.getProperty("/SlId");
			SlNo = oForm.getProperty("/SlNo");

			oSaveSl.SlId = SlId;
			oSaveSl.SlNo = SlNo;
			oSaveSl.SLStatus = oForm.getProperty("/SLStatus");
			oSaveSl.to_opp = [];

			if (oppRBSelected) {
				if (selectedOpportunity.OPPT_ID) {
					oSaveSl.OpportunityId = selectedOpportunity.OPPT_ID;
					if (selectedOpportunity.accountid) {
						oSaveSl.AccountId = selectedOpportunity.accountid;
					} else {
						oSaveSl.AccountId = oForm.getProperty("/AccountID");
					}
					to_opp = {
						"OPPT_ID": selectedOpportunity.OPPT_ID,
						"DESCRIPTION": selectedOpportunity.DESCRIPTION
					};
					oSaveSl.to_opp.push(to_opp);

				} else {
					oSaveSl.OpportunityId = this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").getValue();
					oSaveSl.AccountId = oForm.getProperty("/AccountID");
				}

				if (to_oppdata !== null) {
					for (var i = 0; i < oSaveSl.to_opp.length; i++) {
						for (var j = 0; j < to_oppdata.length; j++) {
							if (oSaveSl.to_opp[i].OPPT_ID === to_oppdata[j].OPPT_ID) {
								oSaveSl.to_opp[i].DESCRIPTION = to_oppdata[j].DESCRIPTION ? to_oppdata[j].DESCRIPTION : oSaveSl.to_opp[i].DESCRIPTION;
							}
						}

					}
				}

			} else {
				if (selectedOpportunity.accountid) {
					oSaveSl.AccountId = selectedOpportunity.accountid;
				} else {
					oSaveSl.AccountId = this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").getValue();
				}

			}
			oSaveSl.Name = oForm.getProperty("/SuccessLineName");

			if (date !== null) {
				date = new Date(date);
				year = date.getFullYear();
				month = date.getMonth() + 1;
				day = date.getDate();
				value1Date = year + "-" + month + "-" + day + "T00:00:00";
				oSaveSl.EstCloseDate = value1Date;
			}

			if (startdate !== null) {
				startdate = new Date(startdate);
				startyear = startdate.getFullYear();
				startmonth = startdate.getMonth() + 1;
				startday = startdate.getDate();
				value2Date = startyear + "-" + startmonth + "-" + startday + "T00:00:00";
				oSaveSl.StartDate = value2Date;
			}

			if (startdate && date) {
				if (startdate > date) {
					let msg = "Start date cannot be greater than Estimated close date";
					this.handleRequiredField("/StartDate", "formModel", msg);
				}
			}
			oSaveSl.TempTitle = oForm.getProperty("/Template");
			oSaveSl.TempId = oForm.getProperty("/TempId");
			oSaveSl.MainTempId = oForm.getProperty("/MainTempId");
			oSaveSl.TempVer = oForm.getProperty("/TempVer");
			oSaveSl.MainTempVer = oForm.getProperty("/MainTempVer");
			oSaveSl.OREConfigID = oForm.getProperty("/OREConfigID");
			oSaveSl.OppComments = oForm.getProperty("/OpportunitiesComments");
			oSaveSl.Story = oForm.getProperty("/Story");

			oSaveSl.to_acc = [];
			let acc = {
				"accountname": accountName,
				"accountid": oSaveSl.AccountId,
				"industry": industrydata,
				"iss": selectedOpportunity.ISS,
				"iac": selectedOpportunity.Internal_Account_Classification
			};
			oSaveSl.to_acc.push(acc);
			if (to_acc !== null) {
				for (var i = 0; i < oSaveSl.to_acc.length; i++) {
					for (var j = 0; j < to_acc.length; j++) {
						if (oSaveSl.to_acc[i].accountname === to_acc[j].accountname) {
							oSaveSl.to_acc[i].accountid = to_acc[j].accountid;
							oSaveSl.to_acc[i].industry = to_acc[j].industry;
							oSaveSl.to_acc[i].iss = to_acc[j].iss;
							oSaveSl.to_acc[i].iac = to_acc[j].iac;
						}
					}
				}
			}

			oSaveSl.to_link = [];
			let links = this.byId("storyDocumentLink").getValue();
			let validateLink = true;
			let link = {};
			let LinkTitle = oForm.getProperty("/LinkTitle");
			LinkTitle = LinkTitle.trim();
			//Risk validation
			if (sRiskId === "01" || sRiskId === "02") {
				let msg = this._oResourceBundle.getText("xtit.riskComent");
				if (sRiskComment === "" || sRiskComment.trim() === "") {
					this.handleRequiredField("/RiskComment", "formModel", msg);
				} else {
					oSaveSl.RiskId = sRiskId;
					oSaveSl.RiskComment = sRiskComment;
				}
			} else {
				oSaveSl.RiskId = sRiskId;
				oSaveSl.RiskComment = sRiskComment;
			}

			if (links !== "") {
				validateLink = this._validURL(links);
				if (LinkTitle === "") {
					this.handleRequiredField("/LinkTitle");
				}
			} else {
				if (LinkTitle !== "") {
					this.handleRequiredField("/StoryDocumentLink");
				}
			}
			if (!validateLink) {
				this.byId("storyDocumentLink").setValueState("Error");
				this.byId("storyDocumentLink").setValueStateText("Please enter valid url");
				this.handleRequiredField("/StoryDocumentLink");
			}

			if (links !== "") {
				link = {
					"SlId": SlId,
					"LinkId": "",
					"LinkType": null,
					"Link": links,
					"LinkTitle": LinkTitle
				};
			}
			oSaveSl.to_link.push(link);
			let linksProperty = oForm.getProperty("/Links");
			if (linksProperty !== null) {
				for (var i = 0; i < oSaveSl.to_link.length; i++) {
					for (var j = 0; j < linksProperty.length; j++) {
						if (oSaveSl.to_link[i].Link === linksProperty[j].Link) {
							oSaveSl.to_link[i].LinkId = linksProperty[j].LinkId;
							oSaveSl.to_link[i].LinkType = linksProperty[j].LinkType;
							oSaveSl.to_link[i].SlSnro = linksProperty[j].SlSnro;
							oSaveSl.to_link[i].LinkTitle = LinkTitle;
						}
					}

				}
			}
			let selectedUsers = [];
			for (let user in this.selectedTeam) {
				selectedUsers.push(this.selectedTeam[user]);
			}
			if (selectedUsers.length > 0) {
				selectedUsers.forEach(function (Saveteam) {
					delete Saveteam.checked;
				});
			}
			oSaveSl.to_addopp = oForm.getProperty("/to_addopp");
			if (oSaveSl.to_addopp.length) {
				oSaveSl.to_addopp.filter(function (object) {
					delete object.AccountID;
				});
			}
			oSaveSl.to_team = selectedUsers;
			oSaveSl.SlLead = oForm.getProperty("/SlLead");
			oSaveSl.SlLeadName = oForm.getProperty("/SlLeadName");
			//oSaveSl.to_addopp = oForm.getProperty("/to_addopp");
			this._checkRequiredFields();

			let createFlag = oForm.getProperty("/ValidationFlag");
			if (createFlag) {
				if (!changed) {
					MessageToast.show(this._oResourceBundle.getText("xmsg.nodatachange"), {
						duration: 2000
					});
					return;
				}
				oForm.setProperty("/slFormData", oSaveSl);
				this.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
				this.fnGetFindOppActUsers(oSaveSl);
			}
		},

		//Function to save SL after mandatory fields validation, and add VAT team
		fnSaveSLForm: function (ErrorType) {
			let that = this;
			let oForm = this.getView().getModel("formModel");
			let opportunityModel = this.getView().getModel("opportunityModel");
			let isCopy = oForm.getProperty("/newCopy");
			let oSaveSl = oForm.getProperty("/slFormData") || {};
			if (!isCopy) {
				that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
				SLService.createNewSuccessLine(oSaveSl).then((oData) => {
					var slData = oData.data;
					oForm.setProperty("/sUpdatedClosedDate", slData.EstCloseDate);
					if (slData.OpportunityId && !ErrorType) {
						if (that.createMode !== "EDIT") {
							that.opportunityComponentInstance._oOpportunityHelper.fnLinkSlToHarmony(slData.SlNo, slData.OpportunityId);
						}
						if (that.IsVATAccessSericeTriggered) {
							var successfn = function (oResponse, isError) {
								if (isError) {
									MessageToast.show("Unable to update Opportunity team members to Melody");
								}
								that._successlineCreated(oResponse);
							};
							that.opportunityComponentInstance._oOpportunityHelper.fnGetOpportunityOwner("", slData.SlNo, slData, successfn);
						} else {
							that._successlineCreated(slData);
						}
					} else {
						that._successlineCreated(slData);
					}
					that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
				}).catch((oError)=>{
					let errorObj = oError.responseText;
					let messageText=JSON.parse(errorObj)?.error?.message?.value ?? "Error Occurred!! Please contact the administrator";
					MessageBox.error(messageText);
					that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);

				});
			} else {
				let selectedUsers = [];
				for (let user in this.selectedTeam) {
					selectedUsers.push(this.selectedTeam[user]);
				}
				if (selectedUsers.length > 0) {
					selectedUsers.forEach(function (Saveteam) {
						delete Saveteam.checked;
					});
				}
				oSaveSl.RefSlNo = oForm.getProperty("/RefSlNo");
				let isTeam = oForm.getProperty("/isSlTeam");
				let isAttachment = oForm.getProperty("/isSlAttachments");
				let isDisabledService = oForm.getProperty("/isDisabledService");
				if (selectedUsers.length > 0) {
					selectedUsers.forEach(function (Saveteam) {
						Saveteam.SlId = "00000000-0000-0000-0000-000000000000";
						Saveteam.SlSnro = "";
					});
				}
				oSaveSl.to_attr = [{
					SlNo: '',
					AttributeId: '0001',
					Attribute: 'Team',
					Enabled: (isTeam === true) ? 'X' : ''
				}, {
					SlNo: '',
					AttributeId: '0002',
					Attribute: 'Attachments',
					Enabled: (isAttachment === true) ? 'X' : ''
				}, {
					SlNo: '',
					AttributeId: '0003',
					Attribute: 'Disabled services',
					Enabled: (isDisabledService === true) ? 'X' : ''

				}];
				that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
				SLService.copySuccessLine(oSaveSl).then((oData) => {
					that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
					that._successlineCreated(oData.data);
				}).catch((oError)=>{
					let errorObj = oError.responseText;
					let messageText=JSON.parse(errorObj)?.error?.message?.value ?? "Error Occurred!! Please contact the administrator";
					MessageBox.error(messageText);
					that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);

				});;
			}
		},

		/**
		 * Called when SL is created. Private function of onSave function.
		 * Displays message SL created successfully.
		 * * @param data - Created SL data.
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */

		_successlineCreated: function (data) {
			let that = this;
			let oForm = this.getView().getModel("formModel");
			let opportunityModel = this.getView().getModel("opportunityModel");
			let SlId = oForm.getProperty("/SlId");
			let opportunityData = opportunityModel.getProperty("/opportunity");
			let oppIndex = opportunityData?.findIndex((oItem) => oItem.OPPT_ID === data.OpportunityId);
			let msg;
			if (SlId !== "00000000-0000-0000-0000-000000000000") {
				msg = "SuccessLine updated successfully";
				if (data.StatusId == "02" && oppIndex >= 0) {
					opportunityModel.setProperty(`/opportunity/${oppIndex}/SlExists`, '');
				} else if (data.StatusId == "01" && oppIndex >= 0) {
					opportunityModel.setProperty(`/opportunity/${oppIndex}/SlExists`, 'X');
				}
			} else {
				msg = "New SuccessLine " + data.SlNo + " created successfully";
				if (oppIndex >= 0) {
					opportunityModel.setProperty(`/opportunity/${oppIndex}/SlExists`, 'X');
					opportunityModel.setProperty(`/opportunity/${oppIndex}/SlSnro`, data.SlNo);
					opportunityModel.setProperty(`/opportunity/${oppIndex}/SlId`, data.SlId);
				}
			}
			this.oStorage.put("actOpportunities", opportunityModel.getProperty("/opportunity"));
			this.onClearPress();
			this.getView().getModel("activityTypeModel").setProperty("/isOpportunity", true);
			this._emptyFormModel();
			this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").setValue("");
			this.fnSetFormatUiMainOppChangeFlag();
			MessageBox.success(msg, {
				actions: [MessageBox.Action.OK],
				emphasizedAction: MessageBox.Action.OK,
				onClose: function (sAction) {
					//  that.navToList();
					that.navtoSLList(data.SlNo);
				}
			});
		},

		navtoSLList: function (SlNo) {
			this.getOwnerComponent().getRouter().navTo("SlDetail", {
				OptionalQueryString: {
					SuccessLineID: SlNo
				}
			}, false);
		},

		/**
		 * Called when the save button is pressed for preexisting SuccessLine.
		 * Opens PreExistingSuccessLine fragment.
		 * * @memberOf com.presalescentral.successline.view.SlForm
		 */
		_preExistingSuccessLine: function () {
			if (!this.preExistingDialog) {
				this.preExistingDialog = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.PreExistingSuccessLine",
					this);
				this.getView().addDependent(this.preExistingDialog);
			}
			this.preExistingDialog.open();
		},

		/**
		 * Called when the save button is pressed. Private function of onSave function.
		 * Checks for required fields.
		 * * @memberOf com.presalescentral.successline.view.SlForm
		 */
		_checkRequiredFields: function () {
			let oForm = this.getView().getModel("formModel");
			let accountName = oForm.getProperty("/AccountName").trim();
			let opportunity = this.getView().getModel("opportunityModel").getProperty("/selectedOpportunity/OPPT_ID");
			let accname = this.getView().getModel("opportunityModel").getProperty("/selectedOpportunity/AccountId_Name");
			let account = this.getView().getModel("opportunityModel").getProperty("/selectedOpportunity/accountid");
			if (account) {
				oForm.setProperty("/AccountID", account);
			}
			if (opportunity) {
				oForm.setProperty("/OpportunityId", opportunity);
			}
			let oppid = oForm.getProperty("/OpportunityId");
			let accid = oForm.getProperty("/AccountID");
			if (oppid === "" && accid === "" || oppid === undefined && accid === undefined || oppid === "" && accid === undefined || oppid ===
				undefined && accid === "") {

				this.getView().getModel("opportunityModel").setProperty("/opptValueState", "Error");
				this.handleRequiredField("/", "opportunityModel");

			}
			let successlineName = oForm.getProperty("/SuccessLineName").trim();
			if (!successlineName)
				this.handleRequiredField("/SuccessLineName");
			let estimatedCloseDate = oForm.getProperty("/EstimatedCloseDate");
			if (!estimatedCloseDate)
				this.handleRequiredField("/EstimatedCloseDate");
			let startDate = oForm.getProperty("/StartDate");
			if (!startDate)
				this.handleRequiredField("/StartDate");
			let template = oForm.getProperty("/Template");
			if (!template)
				this.handleRequiredField("/Template");
			// let story = oForm.getProperty("/Story").trim();
			// if (!story)
			// 	this.handleRequiredField("/Story");
			let sllead = oForm.getProperty("/SlLead");
			if (sllead) {
				sllead = sllead.trim();
			}
			if (!sllead)
				this.handleRequiredField("/SlLead");

			let messageMngrBtn = this.getView().byId("messageMngrBtn");
			if (this.View.getModel("messageModel")?.getData()?.length > 0) {
				messageMngrBtn?.setVisible(true);
			} else {
				messageMngrBtn?.setVisible(false);
			}
		},
		/**
		 * Called when the save button is pressed. Private function of _checkRequiredFields function.
		 * Checks for required fields and handles message manager. 
		 * @param target - Field being validated, modelName - Model related to the field validated, msg - custom message for validation error
		 * * @memberOf com.presalescentral.successline.view.SlForm
		 */
		handleRequiredField: function (target, modelName, msg) {
			let model;
			if (modelName === "alluserModel") {
				model = this.getView().getModel("alluserModel");
			} else if (modelName === "opportunityModel") {
				model = this.getView().getModel("opportunityModel");
			} else {
				model = this.getView().getModel("formModel");
			}
			if (!msg) {
				msg = "Please enter the mandatory field";
			}
			this.getView().getModel("formModel").setProperty("/ValidationFlag", false);
			let sTarget = target;
			let oMessage = new Message({
				message: msg,
				type: MessageType.Error,
				target: sTarget,
				processor: model
			});
			if (oMessage.target === "/") {
				if (modelName === "opportunityModel") {
					oMessage.setAdditionalText("Select Opportunity or Account");
				} else {
					oMessage.setAdditionalText("Select Team");
				}
			} else if (oMessage.target === "/StoryDocumentLink") {
				oMessage.setMessage("Please enter a valid url");
			} else if (oMessage.target === "/AccountName") {
				oMessage.setAdditionalText("Select Opportunity or Account");
			} else if (oMessage.target === "/Template") {
				oMessage.setAdditionalText("Template");
			}
			sap.ui.getCore().getMessageManager().addMessages(oMessage);
		},

		/**
		 * Called when error mesaage icon is pressed.
		 * Opens MessagePopover fragment.
		 * * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onMessagePopoverPress: function (oEvent) {
			this._getMessagePopover().openBy(oEvent.getSource());
		},

		/**
		 * Called when error mesaage icon is pressed. Private function of onMessagePopoverPress function.
		 * Opens MessagePopover fragment.
		 * * @memberOf com.presalescentral.successline.view.SlForm
		 */
		_getMessagePopover: function () {
			// create popover lazily (singleton)
			if (!this._oMessagePopover) {
				this._oMessagePopover = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.MessagePopover",
					this);
				this.getView().addDependent(this._oMessagePopover);
			}
			return this._oMessagePopover;
		},

		/**
		 * Called when validation link is clicked in MessagePopover fragment
		 * Navigates to the respective field to focus on the error field.
		 * @param - Fetches the selected error field
		 * * @memberOf com.presalescentral.successline.fragments.MessagePopover
		 */
		activeTitlePress: function (oEvent) {
			let oItem = oEvent.getParameter("item"),
				oPage = this.getView().byId("formPage"),
				oMessage = oItem.getBindingContext("messageModel").getObject(),
				oControl = Element.registry.get(oMessage.getControlId());

			if (oControl) {
				oPage.scrollToElement(oControl.getDomRef(), 200, [0, -100]);
				setTimeout(function () {
					oControl.focus();
				}, 300);
			}
		},

		/**
		 * Return Form Title and Subtitle
		 * @param sControlId - FGets the Control Id
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		getGroupName: function (sControlId) {
			// the group name is generated based on the current layout
			// and is specific for each use case
			let oControl = Element.registry.get(sControlId);
			if (oControl) {
				let sFormSubtitle = oControl.getParent().getParent().getTitle().getText(),
					sFormTitle = oControl.getParent().getParent().getParent().getTitle();

				return sFormTitle + ", " + sFormSubtitle;
			}
		},
		/**
		 * 
		 * * @memberOf com.presalescentral.successline.view.SlForm
		 */

		isPositionable: function (sControlId) {
			// Such a hook can be used by the application to determine if a control can be found/reached on the page and navigated to.
			return sControlId ? true : true;
		},
		/**
		 * Called when Clear button is pressed.
		 * Clears the Form values and removes all validation errors.
		 * * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onClearPress: function () {
			this.getView().getModel("formModel").setProperty("/ValidationFlag", true);
			sap.ui.getCore().getMessageManager().removeAllMessages();
			let selectTeamId = this.byId("selectTeam");
			selectTeamId.setValueState("None");
			this.byId("successlineName").setValueState("None");
			this.byId("startDate").setValueState("None");
			this.byId("estimatedCloseDate").setValueState("None");
			this.byId("templateid").setValueState("None");
			this.byId("opportunitiesComments").setValueState("None");
			this.byId("story").setValueState("None");
		},
		/**
		 * Called when Cancel button is pressed.
		 * * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onCancel: function (oEvent) {
			let that = this;
			if (!this.actCancelPopup) {
				this.actCancelPopup = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.CancelPopup",
					this);
				this.getView().addDependent(this.actCancelPopup);
			}
			this.actCancelPopup.openBy(oEvent.getSource());

		},
		/**
		 * Called when ok is pressed
		 * Clears data and navigates back 
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onClickOk: function () {
			let that = this;
			let oFormModel = this.getView().getModel("formModel");
			oFormModel.setProperty("/ValidationFlag", true);
			oFormModel.setProperty("/RiskId", "");
			oFormModel.setProperty("/RiskComment", "");
			sap.ui.getCore().getMessageManager().removeAllMessages();
			this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").setValue("");
			that.getView().getModel("activityTypeModel").setProperty("/isOpportunity", true);
			that._emptyFormModel();
			let selectTeamId = that.byId("selectTeam");
			selectTeamId.setValueState("None");
			//that.navToList();
			that.getView().getModel("opportunityModel").setProperty("/opptValueState", "None");
			that.onNavBack();

		},
		/**
		 * Opens client email with email address and subject. Called when contact owner button pressed.
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		handleContactOwner: function (OwnerEmail, Name) {
			let email = OwnerEmail;
			let subject = Name;
			sap.m.URLHelper.triggerEmail(email, subject);
		},

		/**
		 *Called on search for user for SAP users.
		 * @param oEvent - Passes the searched user 
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onSearchMultiUserSAP: function (oEvent) {
			let query = oEvent.getParameter("query");
			if (query !== "")
				this.onSearch(query);
		},

		/**
		 *Called on search for user for Opportunity team users.
		 *  @param oEvent - Passes the searched user 
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onSearchMultiUser: function (oEvent) {
			let aFilter = [];
			let query = oEvent.getParameter("query");
			if (query) {
				aFilter.push(new Filter("FullName", FilterOperator.Contains, query));
			}
			let oList = this.getView().byId("UserListMulti");
			let oBinding = oList.getBinding("items");
			oBinding.filter(aFilter);
		},

		/**
		 *Called on search for user for SAP user. Calls service to fetch user from large pool of users.
		 *  @param oEvent - Passes the searched user 
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onSearch: function (query) {
			let that = this;
			SLService.getUsers(query).then((oData) => {
				that._handleUserSearch(oData.data);
			});
		},
		/**
		 *Returns data on search for user for SAP user. Calls service to fetch user from large pool of users.
		 *  @param oData - Returns list/ single user for searched users.
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		_handleUserSearch: function (oData) {
			this.getView().getModel("userSearch").setData(oData.results);
			let data = this.getView().getModel("userSearch").getData();
			for (let i = 0; i < data.length; i++) {
				data[i].checked = false;
			}
			this.byId("UserListMultiSAP").getBinding("items").refresh();
		},
		/**
		 * Opens opportunity or Account information when info icon is pressed.
		 *  @param oEvent - Fetches selected opportunity/account.
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		handleOpenOppInfoPress: function (oEvent) {
			if (this.getView().getModel("activityTypeModel").getProperty("/isOpportunity")) {
				this.fnOpenOppInfoPress(oEvent);
			} else {
				this.fnOpenAccountInfo(oEvent);
			}
		},

		/**
		 * Opens opportunity fragment
		 *  @param oEvent - Fetches the icon selected
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		fnOpenOppInfoPress: function (oEvent) {
			if (!this.oppInfoPopup) {
				this.oppInfoPopup = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.OpportunityInfo", this);
				this.getView().addDependent(this.oppInfoPopup);
			}
			this.oppInfoPopup.openBy(oEvent.getSource());
		},
		/**
		 * Opens Account fragment
		 *  @param oEvent - Fetches the icon selected
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		fnOpenAccountInfo: function (oEvent) {
			if (!this.accountInfoPopup) {
				this.accountInfoPopup = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.AccountInfo", this);
				this.getView().addDependent(this.accountInfoPopup);
			}
			this.accountInfoPopup.openBy(oEvent.getSource());
			this.byId("idSLDetAddOppo").setVisible(false);
		},

		/**
		 * Opens harmony application in new tab
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		navToCRMwithCvaAccnt: function () {
			window.open(this.constants["0185"].field_value + this.opportunityComponentInstance.getRootControl().getController().getView().byId(
				"pcOpportunityInput").getValue(), "_blank");
		},
		/**
		 * Opens harmony application in new tab
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		navToCRM: function () {
			window.open(this.constants["0183"].field_value + this.opportunityComponentInstance.getRootControl().getController().getView().byId(
				"pcOpportunityInput").getValue(),
				"_blank");
		},
		/**
		 * Navigates back to previpus view. If there's no history, then navigates back to Melody Dashboard.
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onNavBack: function () {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oCrossAppNavigator = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService("CrossApplicationNavigation");
				if (oCrossAppNavigator) {
					oCrossAppNavigator.backToPreviousApp();
				}
			}
		},
		/**
		 * Closes the information fragment for Account
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onCloseAccountInfo: function () {
			this.accountInfoPopup.close();
		},
		/**
		 * Closes the information fragment for Opportunity
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onCloseOppInfo: function () {
			this.oppInfoPopup.close();
		},
		/**
		 * Handles template selection restriction based on opportunity or account type
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		templateVisibility: function (isOpp, type) {
			if (isOpp === 0 && type === "0001") {
				return true;
			} else if (isOpp === 1 && type === "0002") {
				return true;
			} else {
				return false;
			}
		},

		/**
		 * Removes validation value state on change event for successline name
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onSlNameLivechange: function (oEvent) {
			this.handleLivechange(oEvent);
		},
		/**
		 * Removes validation value state on change event for story
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onStoryLivechange: function (oEvent) {
			// this.handleLivechange(oEvent);
			this.dataChanged();
		},
		/**
		 * Removes validation value state on change event for opportunity comments
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onOppCommLivechange: function (oEvent) {
			this.handleLivechange(oEvent);
		},
		/**
		 * Removes validation value state on change event for estimated close date
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onCloseDateChange: function (oEvent) {
			this.handleLivechange(oEvent);
		},
		/**
		 * Removes validation value state on change event for start date
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onStartDatechange: function (oEvent) {
			this.handleLivechange(oEvent);
		},
		/**
		 * Removes validation value state on change event
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		handleLivechange: function (oEvent) {
			this.dataChanged();
			let sValue = oEvent.getParameter("value");
			if (sValue && sValue !== "") {
				oEvent.getSource().setValueState("None");
			} else {
				oEvent.getSource().setValueState("Error");
			}
		},
		/**
		 * Removes validation value state on change event for story document link
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onStoryLinkLiveChange: function () {
			this.dataChanged();
		},
		onLinkTitleLiveChange: function () {
			this.dataChanged();
		},
		/**
		 * Removes validation value state on change event for select team
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onTeamChange: function () {
			this.dataChanged();
		},
		/**
		 * Removes validation value state on change event for delete user from select team
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onDeleteToken: function () {
			this.dataChanged();
		},
		/**
		 * Flag for data change to remove value state of validation.
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		dataChanged: function () {
			let oForm = this.View.getModel("formModel");
			oForm.setProperty("/dataChanged", true);
		},
		onValueHelpRequestSLLead: function () {
			if (!this.leadSearchDialog) {
				this.leadSearchDialog = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.LeadSearch",
					this);
				this.getView().addDependent(this.leadSearchDialog);
			}
			this.leadSearchDialog.open();
		},
		handleSLLeadSelect: function () {
			this.onCloseSLLeadDialog();
		},
		onCloseSLLeadDialog: function () {
			this.byId("userSearchSingle").setValue("");
			this.byId("LeadUserList").removeSelections();
			// this.byId("LeadUserList").removeAllItems();
			this.getView().getModel("leadSearch").setData([]);
			this.byId("LeadUserList").refreshItems();
			this.leadSearchDialog.close();
		},
		onSearchUser: function (oEvent) {
			let that = this;
			let query = oEvent.getParameter("query");
			SLService.getUsers(query).then((oData) => {
				that._handleLeadSearch(oData.data);
			});
		},
		_handleLeadSearch: function (oResponse) {
			let that = this;
			that.getView().getModel("leadSearch").setData(oResponse.results);
			that.byId("LeadUserList").removeSelections();
			var oItems = that.byId("LeadUserList").getBinding('items');
			oItems.refresh();
		},
		handleLeadUserSelect: function (oEvent) {
			this.dataChanged();
			let oLead = oEvent.getSource().getBindingContext("leadSearch").getObject();
			this.getView().getModel("formModel").setProperty("/SlLead", oLead.Id);
			this.getView().getModel("formModel").setProperty("/SlLeadName", oLead.Name);
			this.SLLeadEmail = oLead.Email;
			this.SLLeadCRMRole = oLead.CrmRoleId;
			this.SLLeadCRMRoleDesc = oLead.CrmRoleDesc;
			this.onCloseSLLeadDialog();
		},
		_checkActiveSLAvailable: function (oData) {
			let that = this;
			let message = "";
			let continueMessage = " ";
			let bUserPart = false;
			let activeSL = false;
			let activeSLarr = [];
			let oFormModel = that.getView().getModel("formModel");
			let sCurrentSL = oFormModel.getProperty("/SlNo");
			let selectedIndex = that.getView().getModel("formModel").getProperty("/selectedIndex");
			let oPreExistingSuccessLineModel = that.getView().getModel("preExistingSuccessLineModel");
			if (oData.data.results.length > 0 && selectedIndex === 0) {
				for (var i = 0; i < oData.data.results.length; i++) {
					let oTempResult = oData.data.results[i];
					if (oData.data.results[i].SLStatusID === "01" && oData.data.results[i].Archive === false) { //any atcive SL's
						if (oTempResult.MainOpp || (!oTempResult.MainOpp && oTempResult.SlOpp)) {
							message = "Already an active SL exists for the same opportunity.";
							oData.data.results[i].message = message;
							activeSL = true;
							oData.data.results[i].Active = true;
							activeSLarr.push(oData.data.results[i]);
						}
					}
					if (oData.data.results[i].SLStatusID === "01" && oData.data.results[i].Archive === false) {
						if (oData.data.results[i].IsPartOfSl === "X") {
							bUserPart = true;
						}
					}
				}
				if (activeSL) {
					let aActiveSLExceptCurrentSL = activeSLarr.filter((oRow) => {
						return oRow.SlSnro !== sCurrentSL;
					});
					if (!aActiveSLExceptCurrentSL.length) {
						activeSL = false;
					}
				}
				if (activeSL) {
					that.getView().getModel("preExistingSuccessLineModel").setData(activeSLarr);
					if (bUserPart) {
						that.getView().getModel("preExistingSuccessLineModel").setProperty("/bUsrPart", true);
						that.getView().getModel("preExistingSuccessLineModel").setProperty("/bUsrNotPart", false);
					} else {
						that.getView().getModel("preExistingSuccessLineModel").setProperty("/bUsrPart", false);
						that.getView().getModel("preExistingSuccessLineModel").setProperty("/bUsrNotPart", true);
					}
					that.getView().getModel("preExistingSuccessLineModel").setProperty("/activeSL", activeSL);
					that.getView().getModel("preExistingSuccessLineModel").setProperty("/continueMessage", continueMessage);
					that.getView().getModel("formModel").setProperty("/ValidationFlag", false);
					that._preExistingSuccessLine();
				} else {
					var status = "01";
					that._confirmCancelReopenSL(status);
				}
			} else {
				that._confirmCancelReopenSL(status);
			}
		},
		_validateSLAvailable: function (status) {
			let that = this;
			let Opportunity = that.getView().getModel("activityTypeModel").getProperty("/isOpportunity");
			let selectedOpportunity = that.getView().getModel("opportunityModel").getProperty("/selectedOpportunity");
			let filterBy, searchID;
			that.getView().setModel(new JSONModel([]), "preExistingSuccessLineModel");
			if (Opportunity) {
				filterBy = "OpportunityId";
				searchID = selectedOpportunity.OPPT_ID;
			} else {
				filterBy = "AccountId";
				searchID = selectedOpportunity.accountid;
			}
			let aFilter = [new Filter(filterBy, FilterOperator.EQ, searchID)];
			//Check for Preexisting SuccessLine
			that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
			SLService.validateSuccessLineAvailability(aFilter).then((oData) => {
				that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
				if (status === "01") {
					that._checkActiveSLAvailable(oData);
				} else {
					that._successlineAvailable(oData);
				}
			});

		},
		_confirmCancelReopenSL: function (status) {
			let that = this;
			let SLStatus = that.getView().getModel("formModel").getProperty("/SLStatus");
			var message = "";
			let oSlArchive = {
				"SlSnro": this.getView().getModel("formModel").getProperty("/SlNo"),
				"SlId": this.getView().getModel("formModel").getProperty("/SlId"),
				"TempId": this.getView().getModel("formModel").getProperty("/TempId"),
				"StatusId": status
			};
			var data = {
				"SlNo": this.getView().getModel("formModel").getProperty("/SlNo"),
				"OpportunityId": this.getView().getModel("formModel").getProperty("/OpportunityId"),
				"StatusId": status
			};
			switch (status) {
				case "02":
					message =
						"When cancelling a SuccessLine, all associated registered activities will also be canceled. Are you sure you want to cancel this SuccessLine?";
					break;
				case "12":
					message = "Are you sure you want to mark successline as completed? ";
					break;
				default:
					message = "Are you sure you want to reopen successline? ";
			}
			if (status === "01" && SLStatus === "12") {
				message = "Are you sure you want to make successline In-progress? ";
			}
			MessageBox.confirm(message, {
				onClose: function (sAction) {
					if (sAction === 'OK') {
						SLService.updateSL(oSlArchive).then((oData) => {
							that._successlineCreated(data);
						});
					}
				}
			});
		},
		
		onCancelReopenSL: function (status) {
			let that = this;
			let Opportunity = that.getView().getModel("activityTypeModel").getProperty("/isOpportunity");
			if (status === '01') { //Reopen SL 
				if (Opportunity) {
					that._validateSLAvailable(status);
				} else {
					that._confirmCancelReopenSL(status);
				}
			} else { //Cancel SL 
				that._confirmCancelReopenSL(status);
			}
		},
		//function to handle MSL Mark As Complete:
		onMSLMarkComplete: function (status) {
			this._confirmCancelReopenSL(status);
		},

		//commented because now there is only one type which is opportunity
		/*getAssociateType: function () {
			var associateType = 0;
			if (this.getView().getModel("activityTypeModel").getProperty("/isOpportunity")) {
				associateType = 0;
			} else {
				associateType = 1;
			}
			if (associateType === 0) {
				associateType = 502;
			} else
				if (associateType === 1) {
					associateType = 501;
				}
			return associateType;
		},*/

		//template activity suffix
		_getDefaultRole: function () {
			var that = this;
			SLService.getDefaultRole().then((oResponse) => {
				let data = oResponse.data.results[0];
				if (data) {
					let activityRole = data.RoleMpngID;
					that.getView().getModel("formModel").setProperty("/DefaultRole", activityRole);
				}
			});
		},

		//template activity suffix
		_getActivitySuffix: function (sTempId) {
			var that = this;
			// var associateType = 0;
			// associateType = this.getAssociateType();
			var associateType = 502;
			SLService.getTemplateActivitySufix(sTempId, associateType).then((result) => {
				var aActvts = result.data.results;
				that.getView().getModel("formModel").setProperty("/ActvtSuffix", aActvts);
			});
		},

		//Additional Opportunities #89
		openAdditionalOpptDialog: function () {
			let oThisController = this;
			if (!this.additionalOppDialog) {
				this.getView().getModel("opportunityModel").setProperty("/isOpptDilogBusy", true);
				this.additionalOppDialog = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.addAdditionalOpportunities", this);
				this.getView().addDependent(this.additionalOppDialog);

				if (!this.oStorage.get("actOpportunities") && !this.oStorage.get("pcOpportunities")) {
					this.opportunityComponentInstance._oOpportunityHelper._getBusinessPartner(this.getView().getModel("user").getProperty(
						"/UserId"));
				} else {
					this.getView().getModel("opportunityModel").setProperty("/opportunity", this.oStorage.get("actOpportunities"));
					// this.getView().getModel("opportunityModel").setProperty("/opportunity", this.oStorage.get("actOpportunities") || this.oStorage.get(
					// 	"pcOpportunities"));
				}
				this.getView().getModel("opportunityModel").setProperty("/isOpptDilogBusy", false);

				//Only in Activity Create Mode, and below flags are used to understand the state of Additional Opps selected
				var formModel = this.getModel("formModel");
				var Slid = formModel.getProperty("/SlId");
				var isEditable = formModel.getProperty("/editable");
				if (isEditable && Slid !== "00000000-0000-0000-0000-000000000000") {
					this.initOppoSelect = true;
				}
				this.OppDataInit = true;
			} else {
				this.OppDataInit = true;
				this.initializeAddOppList();
			}
			if (this.initOppoSelect) {
				this.initOppoSelect = false;
			} else {
				this.handleAddOppDialogCancel();
			}
			this.additionalOppDialog.open();
			let oFormModel = this.getView().getModel("formModel");
			let aActOppData = $.extend(true, [], this.oStorage.get("actOpportunities"));
			oFormModel.setProperty("/bChangedAdditionalOpp", false);
			this.byId("slOpptSearchMulti").setValue();
			this.byId("slAddOpptStatusSel").setSelectedKey("");
			if (!this.oStorage.get("actOpportunities") && !this.oStorage.get("pcOpportunities")) { } else {
				if (this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").getValue() !== "") {
					var oForm = this.View.getModel("formModel");
					var isAccount = oForm.getProperty("/selectedIndex");
					if (isAccount === 1) {
						var accountid = this.getView().getModel("opportunityModel").getProperty("/selectedOpportunity/accountid");
						this.byId("slAdditionalOpptList").getBinding("items").filter([new Filter("ACCOUNT", "EQ", accountid)]);
					} else {
						this.byId("slAdditionalOpptList").getBinding("items").filter([new Filter("OPPT_ID", "NE", this.getView().getModel(
							"opportunityModel").getProperty("/selectedOpportunity/OPPT_ID"))]);

						oThisController.fnFindNonUpdatedData(aActOppData);
					}
				} else {
					this.byId("slAdditionalOpptList").getBinding("items").filter([]);
				}
			}
		},

		/*
		 * function to get non-updated data with respsect to MSL Exists for Additional Opportunities 
		 * only on click of value Help
		 */
		fnFindNonUpdatedData: function (aActOppdata) {
			let aLoadedListIndices = this.byId("slAdditionalOpptList").getBinding("items").aIndices || [];
			let aLoadedListData = this.byId("slAdditionalOpptList").getBinding("items").oList || [];
			if (!aLoadedListIndices.length) {
				return;
			}
			if (aLoadedListData.length && aActOppdata.length) {
				let aNonUpdatedData = [];
				for (let i = 0; i < aLoadedListIndices.length; i++) {
					let iTempIndex = aLoadedListIndices[i];
					let oTempOppData = aLoadedListData[iTempIndex];
					if (oTempOppData && !oTempOppData.hasOwnProperty("SlExists")) {
						aNonUpdatedData.push(oTempOppData.OPPT_ID);
					}
				}
				this.fnGetSLOppDataForMSLExist(aNonUpdatedData, true);
			}
		},

		initializeAddOppList: function () {
			if (this.OppDataInit) {
				var oppNotAvailableList = [];
				var oppoModel = this.getView().getModel("opportunityModel");
				var oppoList = oppoModel.getProperty("/opportunity");
				var formModel = this.getModel("formModel");
				var oSavedOppoList = formModel.getProperty("/to_addopp");
				var oMasterDataModel = this.getOwnerComponent().getModel("masterData");
				oppoList.filter(function (obj) {
					obj.addOppPrevSelect = false;
					obj.addOppSelected = false;
				});
				if (oSavedOppoList.length) {
					oSavedOppoList.filter(function (savedOppObj) {
						var isOppPresent = false;
						var sOppoId = savedOppObj.Opportunityno;
						oppoList.filter(function (obj) {
							if (obj.OPPT_ID === sOppoId) {
								obj.addOppPrevSelect = true;
								obj.addOppSelected = true;
								isOppPresent = true;
							}
						});
						if (!isOppPresent) {
							var oTempObj = jQuery.extend(true, {}, savedOppObj);
							oppNotAvailableList.push(oTempObj);
						}
					});
					oMasterDataModel.setProperty("/AddOppCopy", oppNotAvailableList);
				}
				this.OppDataInit = false;
			}
		},

		//Function triggered when deleted tokens from suggestion list
		fnUpdateAddOppTokens: function (oEvent) {
			var sType = oEvent.getParameter("type");
			if (sType === "removed") {
				var oDeletedOpp = oEvent.getParameter("removedTokens")[0];
				var oppoModel = this.getView().getModel("opportunityModel");
				var sPath = oDeletedOpp.getBindingContext("formModel").getPath();
				var aOppoList = oppoModel.getProperty("/opportunity");
				var oppoId = oDeletedOpp.getProperty("key");
				aOppoList.filter(function (obj) {
					if (oppoId === obj.OPPT_ID) {
						obj.addOppSelected = false;
						obj.addOppPrevSelect = false;
					}
				});
				oppoModel.setProperty("/opportunity", aOppoList);
				oppoModel.refresh(true);
				this.deleteOppFromCopy(oEvent, sPath, oDeletedOpp);
				this.dataChanged();
				oDeletedOpp.fireDelete();
			}
		},

		handleAdditionalOppChange: function (oEvent) {

			var oSource = oEvent.getSource();
			var oppoModel = this.getView().getModel("opportunityModel");
			var sPath = oSource.getBindingContext("formModel").getPath();
			var aOppoList = oppoModel.getProperty("/opportunity");
			let oFormModel = this.getView().getModel("formModel");
			var oppoId = this.getModel("formModel").getProperty(sPath + "/Opportunityno");
			aOppoList.filter(function (obj) {
				if (oppoId === obj.OPPT_ID) {
					obj.addOppSelected = false;
					obj.addOppPrevSelect = false;
				}
			});
			oppoModel.setProperty("/opportunity", aOppoList);
			oppoModel.refresh(true);
			this.deleteOppFromCopy(oEvent, sPath);
			this.dataChanged();
			let aFilters = [];
			aFilters.push(new Filter("OpportunityId", FilterOperator.EQ, oppoId));

			//TO set flag that token has been deleted
			oFormModel.setProperty("/bChangedAdditionalOpp", true);
			this.fnCheckforSLFromAvailabiltySerivce(aFilters, false, {}, "MSLEXISTSDELETE");

		},

		//function to change session storage data based on addtional Opp removed
		fnHandleAddtionalOppDataForMSLExists: function (aActiveSlData) {
			if (aActiveSlData.length === 1) {
				var oFormModel = this.View.getModel("formModel");
				let oSlData = $.extend(true, {}, aActiveSlData[0]);
				let OPP_ID = oSlData.OpportunityId;
				let currentSlNo = oFormModel.getProperty("/SlNo");
				if (currentSlNo === oSlData.SlSnro) {
					this.fnUpdateMSLDataStorage(OPP_ID);
				}
			}
		},

		deleteOppFromCopy: function (oEvent, sPath, oppTokenUpdate) {
			var oMasterDataModel = this.getOwnerComponent().getModel("masterData");
			var oDeletedOpp = this.getModel("formModel").getProperty(sPath);
			var aAddOppCopy = $.extend(true, [], oMasterDataModel.getProperty("/AddOppCopy"));
			if (this.OppDataInit) {
				this.handleDeleteData(oEvent, "formModel", oppTokenUpdate);
			} else {
				var oppIndex;
				aAddOppCopy.filter(function (item, index) {
					if (oDeletedOpp.Opportunityno === item.Opportunityno) {
						oppIndex = index;
					}
				});
				if (oppIndex >= 0) {
					aAddOppCopy.splice(oppIndex, 1);
					oMasterDataModel.setProperty("/AddOppCopy", aAddOppCopy);
				} else {
					this.handleDeleteData(oEvent, "formModel", oppTokenUpdate);
				}
			}
		},

		handleDeleteData: function (oEvent, model, oppTokenUpdate) {
			var oSource = oEvent.getSource();
			if (oppTokenUpdate) {
				oSource = oppTokenUpdate;
			}
			var bindingContext = oSource.getBindingContext(model);
			var iLength = bindingContext.getPath().split("/").length;
			var index = bindingContext.getPath().split("/")[iLength - 1];
			var property = bindingContext.getPath().slice(0, -2);
			oSource.getModel(model).getProperty(property).splice(parseInt(index), 1);
			oSource.getModel(model).refresh();
		},

		handleAddOppDialogCancel: function (oEvent) {
			var oTempArr = [];
			var oppoModel = this.getView().getModel("opportunityModel");
			var aOppoList = oppoModel.getProperty("/opportunity");
			var slId = this.getModel("formModel").getProperty("/SlId");
			aOppoList.filter(function (obj) {
				obj.addOppSelected = obj.addOppPrevSelect;
				if (obj.addOppSelected) {
					var opptObj = {};
					opptObj.Opportunityno = obj.OPPT_ID;
					opptObj.SlId = slId;
					oTempArr.push(opptObj);
				}
			});
			var aAddOppCopy = $.extend(true, [], this.getOwnerComponent().getModel("masterData").getProperty("/AddOppCopy"));
			if (aAddOppCopy.length) {
				oTempArr = oTempArr.concat(aAddOppCopy);
			}
			if (oTempArr.length) {
				this.getView().getModel("formModel").setProperty("/to_addopp", oTempArr);
			}
			oppoModel.setProperty("/opportunity", aOppoList);
			this.additionalOppDialog.close();
			oppoModel.refresh(true);
		},

		handleAddOppStatusSelect: function (oEvent) {
			var aFilters = [];
			var opportunityModel = this.getView().getModel("opportunityModel");
			var sOppId = opportunityModel.getProperty("/selectedOpportunity/OPPT_ID");
			var accountId = opportunityModel.getProperty("/selectedOpportunity/accountid");
			var formModel = this.getView().getModel("formModel");
			var isAccount = formModel.getProperty("/selectedIndex") ? true : false;
			var sSelectedStatus = oEvent.getParameter("selectedItem").getKey();
			var oListItem = this.byId("slAdditionalOpptList").getBinding("items");
			if (sSelectedStatus !== "") {
				aFilters.push(new Filter("active", "EQ", sSelectedStatus));
			}
			if (isAccount) {
				if (accountId) {
					aFilters.push(new Filter("ACCOUNT", "EQ", accountId));
				}
			} else {
				if (sOppId) {
					aFilters.push(new Filter("OPPT_ID", "NE", sOppId));
				}
			}

			this.byId("slAdditionalOpptList").getBinding("items").filter(aFilters);
			this.byId("slOpptSearchMulti").setValue("");
			this.fnHandleActOppFilterChange(oListItem, true);
			this.fnUpdateAddOppFields();
		},

		//function to update add opportunities fields properties on select and deselect
		fnUpdateAddOppFields: function () {
			var oTempArr = [];
			var oppoModel = this.getView().getModel("opportunityModel");
			var aOppoList = oppoModel.getProperty("/opportunity");
			var slId = this.getModel("formModel").getProperty("/SlId");
			var oCurrentSelections = this.getView().getModel("formModel").getProperty("/to_addopp") || [];
			// Ensure aOppoList has correct flags for previously selected items
			oCurrentSelections.forEach(function (selectedItem) {
				var match = aOppoList.find(function (oppo) {
					return oppo.OPPT_ID === selectedItem.Opportunityno;
				});
				if (!match.hasOwnProperty('addOppSelected')) {
					// Set flags if they are missing or incorrect
					match.addOppSelected = true;
					match.addOppPrevSelect = true;
				}
			});
			//var aNewSelections = [];
			aOppoList.filter(function (obj) {
				if (obj.addOppSelected) {
					obj.addOppPrevSelect = true;
					var opptObj = {};
					opptObj.SlId = slId;
					opptObj.Opportunityno = obj.OPPT_ID;
					opptObj.AccountID = obj.ACCOUNT;
					oTempArr.push(opptObj);
				} else {
					obj.addOppPrevSelect = false;
				}
			});
			var aAddOppCopy = $.extend(true, [], this.getOwnerComponent().getModel("masterData").getProperty("/AddOppCopy"));

			if (aAddOppCopy.length) {
				oTempArr = oTempArr.concat(aAddOppCopy);
			}

			this.getView().getModel("formModel").setProperty("/to_addopp", oTempArr);
			oppoModel.refresh();
		},

		onOpptSearch: function (oEvent) {
			let aOpportunityId = [];
			let sOppId = this.getView().getModel("opportunityModel").getProperty("/selectedOpportunity/OPPT_ID");
			let sStatus = this.byId("slAddOpptStatusSel").getSelectedKey();
			let sValue = oEvent.getParameter("query");
			let aFilters = new Filter({
				filters: [
					new Filter("ACCOUNT_NAME", "Contains", sValue),
					new Filter("OPPT_ID", "Contains", sValue),
					new Filter("DESCRIPTION", "Contains", sValue),
					new Filter("ACCOUNT", "Contains", sValue)
				],
				and: false
			});

			if (sOppId) {
				let oSearchFilter1 = aFilters;
				let oppFilter = new Filter("OPPT_ID", "NE", sOppId);
				aFilters = new Filter({
					filters: [oSearchFilter1, oppFilter],
					and: true
				});
			}
			if (sStatus) {
				let oSearchFilter = aFilters;
				let oStatusFilter = new Filter("active", "EQ", sStatus);
				aFilters = new Filter({
					filters: [oSearchFilter, oStatusFilter],
					and: true
				});
			}
			let oList = this.getView().byId("slAdditionalOpptList");
			let oBinding = oList.getBinding("items");
			oBinding.filter([aFilters]);

			if (sValue) {
				this.fnHandleActOppFilterChange(oBinding, true);
			}
		},

		handleAdditionalOpptSelect: function (oEvent) {
			var that = this;
			var oSource = oEvent.getSource();
			var oppoModel = oSource.getModel("opportunityModel");
			var sPath = oSource.getBindingContext("opportunityModel").getPath();

			var oForm = this.View.getModel("formModel");
			var isAccount = oForm.getProperty("/selectedIndex");
			// Additional opportunity : update  starts
			if (oSource.getPressed() && isAccount === 0) {
				let sOppId = oSource.getBindingContext("opportunityModel").getProperty("OPPT_ID");
				var aFilters = [];
				aFilters.push(new Filter("OpportunityId", FilterOperator.EQ, sOppId));
				aFilters.push(new Filter("MainOpp", FilterOperator.EQ, true));
				SLService.validateSuccessLineAvailability(aFilters).then((oData) => {
					let aData = oData.data.results;
					if (aData.length) {
						that._successlineAvailable(oData, true, oSource, oppoModel);
					} else {
						oppoModel.setProperty(sPath + "/addOppSelected", true);
						oSource.setText("Deselect");
					}
				});
			} else if (isAccount === 1 && !oppoModel.getProperty(sPath + "/addOppSelected")) {
				oppoModel.setProperty(sPath + "/addOppSelected", true);
				oSource.setText("Deselect");
			} else {
				oppoModel.setProperty(sPath + "/addOppSelected", false);
				oSource.setText("Select");
			}
			oppoModel.refresh();
			// Additional opportunity : update ends
		},

		handleAdditionalOpptConfirm: function (oEvent) {
			this.fnUpdateAddOppFields();
			this.additionalOppDialog.close();
			this.dataChanged();
		},
		//Additional Opportunities #89
		onCopySL: function () {
			if (!this.copySLDialog) {
				this.copySLDialog = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.CopySLConfirmation",
					this);
				this.getView().addDependent(this.copySLDialog);
			}
			this.copySLDialog.open();
		},
		handleCopySLConfirm: function () {
			this.copySLDialog.close();
			if (!this.copySLOptionalSelectionDialog) {
				this.copySLOptionalSelectionDialog = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.CopyingSLOptionalSelection",
					this);
				this.getView().addDependent(this.copySLOptionalSelectionDialog);
			}
			this.copySLOptionalSelectionDialog.open();
		},
		handleCopySLCancel: function () {
			this.copySLDialog.close();
		},
		handleCreateNewSL: function () {
			this.copySLDialog.close();
			this.getRouter().navTo("SlForm");
		},
		handleContinueSLConfirm: function () {
			let that = this;
			this.copySLOptionalSelectionDialog.close();
			let opportunityModel = this.getView().getModel("opportunityModel");
			let oForm = this.View.getModel("formModel");
			let oAlluserModel = this.View.getModel("alluserModel");
			oForm.setProperty("/newCopy", true);
			oForm.setProperty("/copiedSlName", oForm.getProperty("/SuccessLineName"));
			oForm.setProperty("/copiedTemplateTitle", oForm.getProperty("/Template"));
			let user = this.getOwnerComponent().getModel("user").getData();
			let currentuser = user.UserId;
			let currentUserName = user.UserName;
			oForm.setProperty("/RefSlNo", oForm.getProperty("/SlNo"));
			oForm.setProperty("/SlNo", "");
			oForm.setProperty("/SlId", "00000000-0000-0000-0000-000000000000");
			oForm.setProperty("/SLStatus", "01");
			oForm.setProperty("/SuccessLineName", "");
			oForm.setProperty("/StartDate", null);
			oForm.setProperty("/EstimatedCloseDate", null);
			//	oForm.setProperty("/Template", "");
			//	oForm.setProperty("/TempId", "");
			//	oForm.setProperty("/TemplateInfo", "");
			//oForm.setProperty("/OREConfigID", "");
			oForm.setProperty("/OpportunitiesComments", "");
			oForm.setProperty("/Story", "");
			oForm.setProperty("/MarketUnit", "");
			oForm.setProperty("/AccountID", "");
			oForm.setProperty("/OpportunityId", "");
			oForm.setProperty("/to_acc", []);
			oForm.setProperty("/to_opp", []);
			oForm.setProperty("/to_addopp", []);
			oForm.setProperty("/SlLead", currentuser);
			oForm.setProperty("/SlLeadName", currentUserName);
			oForm.setProperty("/CurrentUser", currentuser);
			oForm.setProperty("/IsArchive", "");
			oForm.setProperty("/SlCompletion", 0);
			oForm.setProperty("TempUpdFlag", "");
			oForm.setProperty("/isSLLeadCurrentUser", false);
			oForm.setProperty("/Links", []);
			oForm.setProperty("/LinkTitle", "");
			oForm.setProperty("/StoryDocumentLink", "");
			oForm.setProperty("/AccountName", "");
			opportunityModel.setProperty("/selectedOpportunity", {});
			let isTeam = oForm.getProperty("/isSlTeam");
			if (!isTeam) {
				this.selectedTeam = {};
			}
			this.getView().getModel("alluserModel").setData(this.selectedTeam);
			oForm.setProperty("/isCopySL", false);
			oForm.setProperty("/editable", true);
			this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").setEditable(true);
			this.opportunityComponentInstance.getRootControl().getController().getView().byId("pcOpportunityInput").setValue("");
		},

		handleCopySLOptionalCancel: function () {
			this.copySLOptionalSelectionDialog.close();
		},
		//function to handle view successline from preExistingSuccessLine
		onViewSuccessLine: function (SlNo) {
			this.getOwnerComponent().getRouter().navTo("SlDetail", {
				OptionalQueryString: {
					SuccessLineID: SlNo
				}
			}, false);
		},

		//Automatically add activity team memeber to opportunity VAT team 10/11/2022
		//Function to find the team members who don't have opportunity access
		fnGetFindOppActUsers: function (oFormFields) {
			var that = this;
			let oActTeam = [];
			this.IsVATAccessSericeTriggered = false;
			var formModel = this.View.getModel("formModel");
			var associateType = formModel.getProperty("/selectedIndex");
			if (associateType === 0) {
				for (let user in this.selectedTeam) {
					var obj = {};
					obj.ID = this.selectedTeam[user].UserId;
					obj.EMAIL = this.selectedTeam[user].EmailId;
					obj.NAME = this.selectedTeam[user].FullName;
					obj.CRMRoleId = this.selectedTeam[user].CRMRoleId;
					obj.CRMRoleDesc = this.selectedTeam[user].CRMRoleDesc;
					oActTeam.push(obj);
				}
				if (!this.selectedTeam[formModel.getProperty("/SlLead")]) {
					var slLead = {};
					slLead.EMAIL = this.SLLeadEmail;
					slLead.CRMRoleId = this.SLLeadCRMRole;
					slLead.CRMRoleDesc = this.SLLeadCRMRoleDesc;
					slLead.ID = formModel.getProperty("/SlLead");
					slLead.NAME = formModel.getProperty("/SlLeadName");
					oActTeam.push(slLead);
				}

				var opportunityModel = this.getView().getModel("opportunityModel");
				var opportunityId = opportunityModel.getProperty("/selectedOpportunity/OPPT_ID");
				var oOppoTeam = that.View.getModel("formModel").getProperty("/SelectTeam") || [];
				if (oActTeam.length) {
					var oNoAccessUsrs = oActTeam.filter(({
						ID: id1,
						EMAIL: email1
					}) => !oOppoTeam.some(({
						UserId: id2,
						EmailId: email2
					}) =>
						id2.toLowerCase() === id1.toLowerCase() && email1.toLowerCase() === email2.toLowerCase()));
					if (oNoAccessUsrs.length) {
						var oTempArr = [];
						oNoAccessUsrs.filter(function (object) {
							if (that.fnFindSameUserObject(object, oTempArr)) {
								object.IsDuplicate = true;
							}
							oTempArr.push(object);
						});
						var successfn = function (UIErrorCode, oResponse) {
							if (UIErrorCode === "HARMONY_SERVER_DOWN" || UIErrorCode === "SERVICE_LIMIT_REACHED") {
								var oMsg =
									"Harmony server is unavailable, users cannot be added to Opportunity team. Do you still want to save Successline?";
								if (UIErrorCode === "SERVICE_LIMIT_REACHED") {
									oMsg = "Unable to reach the service to update VAT team members. Do you still want to save Successline?";
								}
								if (oResponse) {
									var code = JSON.parse(oResponse.responseText).error.code;
									if (code === "Z_CROSS_REPORTING/009") {
										oMsg = "You do not have access to this Opportunity. Do you still want to save Successline?";
									}
								}
								that.fnRemoveNewlyAddedUsers(UIErrorCode, oMsg);
							} else {
								that.fnRemoveCRMRoleProperty();
								that.fnSaveSLForm();
							}
						};
						var oArray = jQuery.extend(true, [], oTempArr);
						var oOppoDataModel = this.opportunityComponentInstance.getModel("oppServerModel");
						var bMetadataLoaded = oOppoDataModel.isMetadataLoadingFailed();
						if (!bMetadataLoaded) {
							this.IsVATAccessSericeTriggered = true;
							this.opportunityComponentInstance._oOpportunityHelper.fnProvideOppoAccess(oArray, opportunityId, successfn, true);
						} else {
							that.fnRemoveCRMRoleProperty();
							that.fnSaveSLForm();
						}
					} else {
						that.fnRemoveCRMRoleProperty();
						that.fnSaveSLForm();
					}
				} else {
					that.fnRemoveCRMRoleProperty();
					that.fnSaveSLForm();
				}
			} else {
				that.fnRemoveCRMRoleProperty();
				that.fnSaveSLForm();
			}
		},

		//Function to find if an same object is present in the array already
		fnFindSameUserObject: function (rObject, oArray) {
			var oSearchedObj = oArray.find(function (object) {
				return object["ID"] === rObject["ID"] && object["EMAIL"] === rObject["EMAIL"];
			});
			return oSearchedObj;
		},

		//Function to remove CRM Role and Desc field on Success/Error of adding users to VAT team, before activity save
		fnRemoveCRMRoleProperty: function () {
			var prop1 = "CRMRoleId";
			var prop2 = "CRMRoleDesc";
			var prop3 = "IsDuplicate";
			var oKeys = Object.keys(this.selectedTeam);
			for (var i = 0; i < oKeys.length; i++) {
				var obj = this.selectedTeam[oKeys[i]];
				this.fnRemoveObjectProperty(prop1, prop2, prop3, obj);
			}
		},

		//Function to delete an object's property
		fnRemoveObjectProperty: function (property1, property2, property3, object) {
			delete object[property1];
			delete object[property2];
			delete object[property3];
			return object;
		},

		//Function to show message box when harmony server is down
		fnShowUserOppoConfrmBox: function (oEvent) {
			this.oUserSelectEvent = jQuery.extend(true, {}, oEvent);
			var associateType = this.getView().getModel("formModel").getProperty("/selectedIndex");
			var oOppoDataModel = this.opportunityComponentInstance.getModel("oppServerModel");
			var bMetadataLoaded = oOppoDataModel.isMetadataLoadingFailed();
			if (oEvent.getSource().getCustomData().length) {
				this.oTeamSelectedField = oEvent.getSource().getCustomData()[0].getKey();
			}
			if (associateType === 0) {
				if (!bMetadataLoaded) {
					this.fnPassSetActTeamUser();
				} else {
					var that = this;
					sap.m.MessageBox.confirm(
						"Since Harmony server is unavailable, users cannot be added to Opportunity team. Do you wish to continue", {
						onClose: function (oAction) {
							if (oAction.toLowerCase() === "cancel") {
								if (that.oTeamSelectedField === "SL_LEAD") {
									that.onCloseSLLeadDialog();
								} else if (that.oTeamSelectedField === "SL_TEAM") {
									that.onCloseUserSelectDialog();
								}
							} else {
								that.fnPassSetActTeamUser();
							}
						}
					});
				}
			} else {
				this.fnPassSetActTeamUser();
			}
		},

		//Function to trigger selected team user function if harmony is down
		fnPassSetActTeamUser: function () {
			if (this.oTeamSelectedField === "SL_LEAD") {
				this.handleLeadUserSelect(this.oUserSelectEvent);
			} else if (this.oTeamSelectedField === "SL_TEAM") {
				this.handleUserSelectMulti(this.oUserSelectEvent);
			}
		},

		//Function to remove newly added team users, when the harmony server is down,[Oppo VAT team]
		fnRemoveNewlyAddedUsers: function (Error, ErrorMsg) {
			var that = this;
			sap.m.MessageBox.confirm(ErrorMsg, {
				onClose: function (oAction) {
					if (oAction.toLowerCase() === "cancel") {
						that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
					} else {
						that.fnRemoveCRMRoleProperty();
						that.fnSaveSLForm(Error);
					}
				}
			});
		},

		//function to run deferred function
		fnDefferredForOpp: function () {
			let oThisController = this;
			let deferred = jQuery.Deferred();
			let username = this.getView().getModel("user").getProperty("/UserId");
			oThisController.opportunityComponentInstance._oOpportunityHelper._getBusinessPartner(username);

			setTimeout(() => {
				// deferred.notify();
				deferred.resolve();
			}, 800);

			return deferred.promise();
		},
		//function to load MSL functionality 
		fnLoadMSLFunctionality: function (time) {
			let timer = (time) ? time : 0;
			let oThisController = this;
			setTimeout(() => {
				//TO LOAD MSL EXISTS METHODS AFTER LOADING THE OPP COMPONENT: 
				let aOpportunityID = [];
				let oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				let aActOpp = oStorage.get("actOpportunities") || [];
				let aPcOpp = oStorage.get("pcOpportunities") || [];
				if (!aActOpp.length && aPcOpp.length) {
					oThisController.fnSetActOpportunitiesData(aPcOpp, [], "", true);
				} else {
					let oSLOppData = oStorage.get("SlopportunityMapData") || {};
					if (aActOpp.length) {
						aActOpp = oThisController.sortOpportunites(aActOpp);
						oStorage.put("actOpportunities", aActOpp);
						aOpportunityID = aActOpp.map((oRow) => {
							return oRow.OPPT_ID;
						});
					} else {
						aOpportunityID = Object.keys(oSLOppData);
					}
					if (aOpportunityID.length) {
						//function to fetch Sl data based on Opp to check MSL Exist 
						this.fnSetFormatTenOppIdForMSLExist(aOpportunityID, false);
					}
				}
			}, timer);
		},

		sortOpportunites: function (aOpportunities) {
			aOpportunities.sort((a, b) => {
				// Sort by 'active' descending (1 before 0)
				if (a.active !== b.active) {
					return b.active - a.active;
				}
				// Then by 'ACCOUNT_NAME' ascending (A → Z)
				return a.ACCOUNT_NAME.trim().localeCompare(b.ACCOUNT_NAME.trim());
			});
			return aOpportunities;
		},

		//handle updatefinished from SL controller select Opp
		onHandleUpdatedFinishedForSelectOpp: function (oEvent) {
			this.onHandleGrowingFinishedForActOppList(oEvent, true);
		},

		//function to handle loadmore/growingFinished in Opportunity Component from SL FORM
		onHandleGrowingFinishedForActOppList: function (oEvent, bSlController) {
			let aListItems = oEvent.getSource().getItems() || [];
			let sReason = oEvent.getParameter("reason");
			if (sReason !== "Growing") {
				return;
			}
			// Initialize processed count if not already done
			if (this._iPrevListLength === undefined) {
				this._iPrevListLength = 10; // Assume first 10 already loaded initially
			}
			let iTotalLength = aListItems.length;
			let iStartIndex = this._iPrevListLength;
			let iPageSize = 10;
			let iRemaining = iTotalLength - iStartIndex;
			let iCountToProcess = Math.min(iPageSize, iRemaining);

			if (iCountToProcess <= 0) return;

			// Slice the newly loaded records
			let aNextBatch = aListItems.slice(iStartIndex, iStartIndex + iCountToProcess);
			let aLoadedOppId = [];
			for (let i = 0; i < aNextBatch.length; i++) {
				let oTempList = aNextBatch[i];
				let oListObj;
				if (bSlController) {
					oListObj = oTempList.getBindingContext("opportunityModel").getObject();
				} else {
					oListObj = oTempList.getBindingContext().getObject();
				}
				aLoadedOppId.push(oListObj.OPPT_ID);
			}
			// Update for the next grow
			this._iPrevListLength = iStartIndex + iCountToProcess;
			// Call the processor
			this.fnGetSLOppDataForMSLExist(aLoadedOppId, bSlController);
		},

		//function to splice first 10 OppIds to fetch the MSL Exist Data
		fnSetFormatTenOppIdForMSLExist: function (aOpportunityID, bSlController) {
			let iPageSize = 10;
			let aTempOppId = $.extend(true, [], aOpportunityID);
			if (aTempOppId.length > iPageSize) {
				let aFirstTenOppId = aTempOppId.splice(0, iPageSize);
				this.fnGetSLOppDataForMSLExist(aFirstTenOppId, bSlController);
			} else {
				this.fnGetSLOppDataForMSLExist(aTempOppId, bSlController);
			}
		},

		//function to handle fetch MSLExist data based on Oppid
		fnGetSLOppDataForMSLExist: function (aOpportunityID, bSlController) {
			if (!aOpportunityID.length) {
				return;
			}
			let oThisController = this;
			let aFilter = [];
			for (let i = 0; i < aOpportunityID.length; i++) {
				let sOppId = aOpportunityID[i];
				aFilter.push(new Filter({
					path: "OppNo",
					// path: "OpportunityId",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: sOppId
				}));
			}
			let oOppCompModel = this.opportunityComponentInstance.getModel("opportunityModel");
			oOppCompModel.setProperty("/isOpptDilogBusy", true);
			oOppCompModel.refresh();
			SLService.getMSLExistDataBasedOnOpp(aFilter).then((oData) => {
				let aResponse = $.extend(true, [], oData.data.results);
				oThisController.fnMapOppDataWithMSLResponse(aResponse, bSlController);
			}).catch((error) => {
				oThisController.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
				oOppCompModel.setProperty("/isOpptDilogBusy", false);
			});

		},

		//function to map the session opp data with MSL Exist Response
		fnMapOppDataWithMSLResponse: function (aResponse, bSlController) {
			let oThisController = this;
			if (!this.oStorage) {
				this.oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			}
			let aActOppData = $.extend(true, [], this.oStorage.get("actOpportunities"));
			let aPcOppData = $.extend(true, [], this.oStorage.get("pcOpportunities"));
			let oOppCompModel = this.opportunityComponentInstance.getModel("opportunityModel");
			let oOpportunityModel = this.getView().getModel("opportunityModel");
			oOpportunityModel.setProperty("/isOpptDilogBusy", true);
			oOppCompModel.setProperty("/isOpptDilogBusy", true);
			if (aActOppData.length) {
				if (aResponse.length) {
					for (let i = 0; i < aResponse.length; i++) {
						let oResponse = aResponse[i];
						let iIndex = aActOppData.findIndex((oRow) => {
							return oRow.OPPT_ID === oResponse.OppNo;
						});
						if (iIndex !== -1) {
							let oCurrentData = aActOppData[iIndex];
							if (oCurrentData.hasOwnProperty("bUIMainOppChange") && oCurrentData.bUIMainOppChange) {
								aActOppData[iIndex].SlExists = "";
								aActOppData[iIndex].bAdditionalOpp = false;
							} else {
								aActOppData[iIndex].SlExists = (oResponse.SlExists === "X") ? "X" : "";
								aActOppData[iIndex].SlId = oResponse.SlId;
								aActOppData[iIndex].SlSnro = (oResponse.SlSnro) ? oResponse.SlSnro : "";
								aActOppData[iIndex].bAdditionalOpp = (oResponse.SlExists === "X" && oResponse.MainOpp) ? true : false;
							}
						}
					}
					setTimeout(() => {
						oOppCompModel.setProperty("/isOpptDilogBusy", true);
						oOpportunityModel.setProperty("/isOpptDilogBusy", true);
						if (bSlController) {
							//for Additional Opp in SL - Select Opportunity
							let oOppSlModel = this.getView().getModel("opportunityModel");
							oOppSlModel.setProperty("/opportunity", aActOppData);
							oOppSlModel.refresh();
						} else {
							//Opportunity Component - Select Opportunity
							oOppCompModel.setProperty("/opportunity", aActOppData);
							oOppCompModel.refresh();

						}
						setTimeout(() => {
							oThisController.oStorage.put("actOpportunities", aActOppData);
							oOppCompModel.setProperty("/isOpptDilogBusy", false);
							oOpportunityModel.setProperty("/isOpptDilogBusy", false);
						}, 1000);
					}, 400);
					oThisController.oStorage.put("actOpportunities", aActOppData);
				} else {
					MessageToast.show("MSL Exists Data Not Found.");
					oOppCompModel.setProperty("/isOpptDilogBusy", false);
					oOpportunityModel.setProperty("/isOpptDilogBusy", false);
				}
				oOppCompModel.refresh();
				oOpportunityModel.refresh();
			} else {
				if (aPcOppData.length) {
					oThisController.fnSetActOpportunitiesData(aPcOppData, aResponse, bSlController);
				}
			}

		},

		//function to update actOpportunities. a clone implmentation of Opportunity component;
		fnSetActOpportunitiesData: function (aPcOppData, aResponse, bSlController, bInitial) {
			let oThisController = this;
			let oActivityTypeModel = this.opportunityComponentInstance.getModel("activityTypeModel");
			let activeOppt = aPcOppData.filter(function (value) {
				if (value.STATUS === "E0001" || value.STATUS === "E0007") {
					return true;
				}
			});
			let opptData = $.extend(true, [], activeOppt);
			let data = {};
			let prvYear = oActivityTypeModel.getProperty("/previousYear");
			let nextYear = oActivityTypeModel.getProperty("/nextFiveYear");
			data = aPcOppData;

			$.each(data, function (index, value) {
				value.EXPECT_END = new Date(value.EXPECT_END);
				if (value.EXPECT_END < prvYear || value.EXPECT_END > nextYear || (value.STATUS ===
					"E0002" || value.STATUS === "E0005")) {
					value.active = 0;
				} else {
					value.active = 1;
				}
			});
			opptData = data;
			data = oThisController.sortOpportunites(data);
			if (!this.oStorage) {
				this.oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			}
			oThisController.oStorage.put("actOpportunities", data);
			if (bInitial) {
				oThisController.fnLoadMSLFunctionality();
			} else {
				oThisController.fnMapOppDataWithMSLResponse(aResponse, bSlController);
			}
		},

		//function to handle MSL Exists Navigation for Opportunity Component
		handleMslExistsBtnForOppComponent: function (oEvent) {
			let oThisController = this;
			let oSource = oEvent.getSource();
			let obindingCont = oEvent.getSource().getBindingContext().getObject();

			oThisController.fnCheckSLAvailableForMSLExist(obindingCont, oSource, false);

		},

		//function to handle MSL Exists Navigation
		handleMslExistsBtn: function (oEvent) {
			let oThisController = this;
			let oSource = oEvent.getSource();
			let obindingCont = oEvent.getSource().getBindingContext("opportunityModel").getObject();

			oThisController.fnCheckSLAvailableForMSLExist(obindingCont, oSource, true);

		},

		//function to check SL Available for MSL Exist
		fnCheckSLAvailableForMSLExist: function (oSelectedData, oSource, bSlController) {
			let oThisController = this;
			let sOppId = oSelectedData.OPPT_ID;
			let aFilters = [];
			aFilters.push(new Filter("OpportunityId", FilterOperator.EQ, sOppId));
			if (bSlController) {
				aFilters.push(new Filter("MainOpp", FilterOperator.EQ, true));
			}
			let oppoModel = oSource.getModel("opportunityModel");
			oThisController.fnCheckforSLFromAvailabiltySerivce(aFilters, bSlController, oSelectedData, "MSLEXISTSCREATE");

		},

		//function to check availabilty logic
		fnCheckforSLFromAvailabiltySerivce: function (aFilters, bSlController, oSelectedData, sFuntionalityType) {
			let oThisController = this;
			let bUserPart = false;
			let bActiveSL = false;
			SLService.validateSuccessLineAvailability(aFilters).then((oData) => {
				let aResponse = oData.data.results || [];
				let aNavCheck = [];
				for (let i = 0; i < aResponse.length; i++) {
					let oTempResult = aResponse[i];
					if (!oTempResult.Archive) { //not archived
						if (oTempResult.SLStatusID === "01") { //Active SL
							if (oTempResult.SLStatusID === "01" && oTempResult.IsPartOfSl === "X") {
								bUserPart = true;
							}
							oTempResult.message = "Already an active SL exists for the same opportunity.";
							oTempResult.Active = true;
							//Only on Primary Opp
							if (!bSlController) {
								if (oTempResult.MainOpp || (!oTempResult.MainOpp && oTempResult.SlOpp)) {
									bActiveSL = true;
									aNavCheck.push(oTempResult);
								}
							} else {
								bActiveSL = true;
								aNavCheck.push(oTempResult);
							}

						}
					}
				}

				switch (sFuntionalityType) {
					case "MSLEXISTSCREATE":
						let oFormModel = this.getView().getModel("formModel");
						let currentSlNo = oFormModel.getProperty("/SlNo");
						let bChangedAdditionalOpp = oFormModel.getProperty("/bChangedAdditionalOpp");
						if (bChangedAdditionalOpp) {
							aNavCheck = aNavCheck.filter((oRow) => {
								return oRow.SlSnro !== currentSlNo;
							});
						}
						if (aNavCheck.length === 1) {
							oThisController.fnHandleCrossNavigation(oSelectedData);
							return;
						}

						if (aNavCheck.length) {
							oThisController.fnHandlePreExistingSLForMSLExists(aNavCheck, bUserPart, bActiveSL);
						} else {
							oThisController.fnHandleCrossNavigation(oSelectedData);
							return;
						}
						break;
					case "MSLEXISTSDELETE":
						oThisController.fnHandleAddtionalOppDataForMSLExists(aNavCheck);
						return;
					default:
				}
			});
		},

		//function to open pre-existing SL for MSL Exists
		fnHandlePreExistingSLForMSLExists: function (aActiveSl, bUserPart, bActiveSL) {
			let oThisController = this;
			let continueMessage = "Click on OK to Continue.";
			let oPreExistingSuccessLineModel = oThisController.getView().getModel("preExistingSuccessLineModel");
			oThisController.getView().getModel("preExistingSuccessLineModel").setData(aActiveSl);
			//Validate User part of the pre-existing SuccessLine
			if (bUserPart) {
				oPreExistingSuccessLineModel.setProperty("/bUsrPart", true);
				oPreExistingSuccessLineModel.setProperty("/bUsrNotPart", false);
			} else {
				oPreExistingSuccessLineModel.setProperty("/bUsrPart", false);
				oPreExistingSuccessLineModel.setProperty("/bUsrNotPart", true);
			}
			oThisController.getView().getModel("preExistingSuccessLineModel").setProperty("/activeSL", bActiveSL);
			oThisController.getView().getModel("preExistingSuccessLineModel").setProperty("/continueMessage", continueMessage);
			oThisController.getView().getModel("formModel").setProperty("/ValidationFlag", false);
			oThisController.getView().getModel("formModel").setProperty("/previewVisible", false);
			sap.ui.getCore().getMessageManager().removeAllMessages();
			oThisController._preExistingSuccessLine();
		},

		//handle cross navigation
		fnHandleCrossNavigation: function (oData) {
			let oThisController = this;
			// oThisController.additionalOppDialog.close();
			if (oData && oData.hasOwnProperty("SlSnro") && oData.SlSnro !== "") {

				let oParamObj = {
					"SuccessLineID": oData.SlSnro
				};

				// window.alert(`Navigate To SL no: ${oData.SlSnro} `);

				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
				var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
					target: {
						semanticObject: "sl",
						action: "App&/SlDetail"
					},
					params: oParamObj
				})) || ""; // generate the Hash to display a Supplier
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: hash
					}
				});

			}
		},

		//function to set bUIMainOppChange to false
		fnSetFormatUiMainOppChangeFlag: function () {
			let aIndices = [];
			if (!this.oStorage) {
				this.oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			}
			let aActOppData = $.extend(true, [], this.oStorage.get("actOpportunities"));

			for (let i = 0; i < aActOppData.length; i++) {
				let oTempData = aActOppData[i];
				if (oTempData.hasOwnProperty("bUIMainOppChange") && oTempData.bUIMainOppChange) {
					aIndices.push(i);
				}
			}

			for (let i = 0; i < aIndices.length; i++) {
				let iTempIndex = aIndices[i];
				if (iTempIndex !== -1) {
					aActOppData[iTempIndex].bUIMainOppChange = false;
				}
			}
			this.oStorage.put("actOpportunities", aActOppData);
		},
		/**
		 *Function to handle the change in risk 
		 */
		handleMSLRisk: function (oEvent) {
			let sKey = oEvent.getSource().getSelectedKey();
			let oMSLRiskTxt = this.getView().byId("idMSLRISKCommentTxt");
			if (sKey === "03") {
				oMSLRiskTxt.setValueState("None");
			}
			this.dataChanged();
		},
		/**
		 *Function to handle the change in risk 
		 */
		handleMSLRiskCommentChange: function (oEvent) {
			this.handleLivechange(oEvent);
		},

		// risk edit changes
		OpenRiskInfoPopOver: function (oEvent) {
			if (!this.riskInfoPopup) {
				this.riskInfoPopup = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.RiskInfo", this);
				this.getView().addDependent(this.riskInfoPopup);
			}
			this.riskInfoPopup.openBy(oEvent.getSource());
		},
		OpenRiskCommentInfoPopOver: function (oEvent) {
			if (!this.riskCmtInfoPopup) {
				this.riskCmtInfoPopup = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.RiskCommentInfo", this);
				this.getView().addDependent(this.riskCmtInfoPopup);
			}
			this.riskCmtInfoPopup.openBy(oEvent.getSource());
		},
		onRiskInfoClose: function (oEvent) {
			this.riskInfoPopup.close();
		},
		onRiskCmntInfoClose: function (oEvent) {
			this.riskCmtInfoPopup.close();
		},
		// Navigation link for the Risk ticket
		navToTicketSystem: function (oEvent) {
			let fieldValue = this.ConstantsMap["0123"].field_value;
			window.open(fieldValue, "_blank");
		},

		//function to handle filters from Active Opportunities and fetch the MSL Data for them
		fnHandleActOppFilterChange: function (oBinding, bAdditionOpp) {
			let aOpportunityId = [];
			let aFilterAppliedData = oBinding.aLastContexts || [];
			for (let i = 0; i < aFilterAppliedData.length; i++) {
				let oList = aFilterAppliedData[i];
				let oItemData = oList.getObject() || false;
				if (oItemData && "OPPT_ID" in oItemData) {
					aOpportunityId.push(oItemData.OPPT_ID);
				}
			}
			if (aOpportunityId) {
				this.fnGetSLOppDataForMSLExist(aOpportunityId, bAdditionOpp);
			}
		},

		/**
		 * Validates url
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		customURLType: SimpleType.extend("url", {
			formatValue: function (oValue) {
				return oValue;
			},

			parseValue: function (oValue) {
				return oValue;
			},

			validateValue: function (oValue) {
				var regex = /^(http[s]?:\/\/){0,1}(www\.){0,1}[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,5}[\.]{0,1}/;
				if (!regex.test(oValue)) {
					throw new ValidateException("'" + oValue + "' is not a valid url");
				}
			}
		}),

	});
});