sap.ui.define([
	"com/presalescentral/successline/controller/BaseController",
	"com/presalescentral/successline/service/OppService",
	"com/presalescentral/successline/service/SLService",
	"com/presalescentral/successline/service/UtilityService",
	"../model/Formatter",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterType",
	"sap/ui/model/FilterOperator",
	"sap/suite/ui/commons/networkgraph/Node",
	"com/presalescentral/successline/controls/CustomLayout",
	"com/presalescentral/successline/classes/SuccessLine",
	"sap/m/MessageToast",
	"sap/base/Log",
	"sap/ui/core/Fragment",
	"sap/ui/util/Storage",
	"com/presalescentral/successline/controls/CustomPopover",
	"sap/m/MenuItem",
	"com/presalescentral/successline/classes/RapidRegistration",
	"com/presalescentral/successline/controls/HoverButton",
	"com/melody/lib/classes/Activity",
	"com/melody/lib/util/Activity",
	"com/melody/lib/controls/mtr/TimeEntry/TimeEntryMenuItem",
	"com/presalescentral/successline/service/MtrService",
	"com/melody/lib/controls/RapidRegistration/RapidRegistration"
], function (BaseController, OppService, SLService, UtilityService, formatter, JSONModel, Filter, FilterType, FilterOperator, Node,
	CustomLayout,
	SuccessLine, MessageToast, Log, Fragment, Storage, CustomPopover, MenuItem, RapidRegistration, HoverButton, MtrActivity,
	ActivityUtil, TimeEntryMenuItem, MtrService, MelodyLibRapidRegistration) {
	"use strict";
	return BaseController.extend("com.presalescentral.successline.controller.SlDetail", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * Called to set models, constants and fetch routing parameters.
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		formatter: formatter,
		onInit: function () {
			var that = this;
			this.initView();
			this.oAvatarSettingsModel = new JSONModel();
			this.oAvatarSettingsModel.setData({
				"viewPortPercentWidth": 100
			});
			this.getView().setModel(this.oAvatarSettingsModel);
			this.oAvatarGroupModel = new JSONModel([]);
			this.getView().setModel(this.oAvatarGroupModel, "groupedAvatars");
			this.oIndividualModel = new JSONModel();
			this.getView().setModel(this.oIndividualModel, "personData");
			this.oPresentationAvatarGroupModel = new JSONModel([]);
			this.getView().setModel(this.oPresentationAvatarGroupModel, "presentationGroupedAvatars");
			const oModel = new JSONModel({
				SuccessLine: new SuccessLine(),
				TouchPointDetails: {},
				PhaseDetails: {},
				SelectedOpportunity: {}
			});
			this.getView().setModel(oModel, "slDefaultModel");
			this._oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			const oRouter = this.getRouter();
			this.tpDetailStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			oRouter.getRoute("SlDetail").attachPatternMatched(this._onRouteMatched, this);
			this.Component = this.getOwnerComponent();
			this.SlDetailModel = this.Component.getModel("SlDetailModel");
			this.Component.getModel("successlineModel").sDefaultUpdateMethod = "PUT";
			this.ConstantsMap = {};
			this.constStorage = new Storage(Storage.Type.session);
			this.ConstantsMap = this.constStorage.get('ConstantsMapData');
			this.RapidRegistration = new RapidRegistration(this);
			this._aClipboardData = [];
			this.getView().setModel(new JSONModel([]), "leadSearch");
			this.getView().setModel(new JSONModel([]), "userSearch");
			this.getView().setModel(new JSONModel([]), "formModel");
			this.getView().setModel(new JSONModel([]), "opportunityModel");
			let oLocalTempDataModel = new JSONModel({});
			this.getView().setModel(oLocalTempDataModel, "slRapidTempModel");
			this.SlActGuid = undefined;
			this.SlPhaseId = undefined;

			this.mtrModel = this.Component.getModel("mtrODataModelModel");
			this.oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);

			this.oSolutionsModel = this.Component.getModel("oSolutionsModel");
			this.getView().setModel(this.oSolutionsModel, "oSolutionsModel");
			this.oSolutionsModel.setProperty("/to_AMaterial", []);
			this.oSolutionsModel.setProperty("/to_ATaxonomy", []);
			this.oSolutionsModel.setProperty("/to_ASol", []);
		},

		/**
		 * Called when router is called for SLDetail. Private function of onInit.
		 * Used to get the SuccessLine ID and GUID to fetch SL details.
		 * @param oEvent- oEvent is passed get argument data
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_onRouteMatched: function (oEvent) {
			const masterSettings = this.getOwnerComponent().getModel("masterSettings");
			const masterOpportunityDataLoaded = masterSettings.getProperty("/masterOpportunityDataLoaded") || false;
			if (!masterOpportunityDataLoaded) {
				masterSettings.setProperty("/masterOpportunityDataLoaded", masterOpportunityDataLoaded);
			}
			const oArgs = oEvent.getParameter("arguments");
			this.SuccessLineId = oArgs["?OptionalQueryString"].SuccessLineID;
			this.SlActGuid = oArgs["?OptionalQueryString"].SlActGuid;
			this.SlPhaseId = undefined;
			this._getSuccessLineData();
			this._getRoleMasterData();
			this._getSourceMasterData();
			//After getting solution hierarchy data, converting into tree structure
			var aMaterialData = this.oSolutionsModel.getProperty("/SolutionHierarchy");
			if (aMaterialData && aMaterialData.length) {
				var sSelectedLevel = this.SlDetailModel.getProperty("/Level2Key");
				this._convertToTree(this, aMaterialData, sSelectedLevel, false);
			}
		},

		/**
		 * Used to dynamically assign roles to activities
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_getActivityRoleData: function () {
			var that = this;
			var associateType = 0;
			associateType = this.getAssociateType();
			SLService.getRoleBasedActivitySufix(this.SuccessLineId, associateType).then((result) => {
				var aActivities = that.getModel("slDefaultModel").getProperty("/SuccessLine/Activities");
				var activityRole = that.getModel("slDefaultModel").getProperty("/SuccessLine/ActivityRole");
				var ParentRoleId = that.getModel("slDefaultModel").getProperty("/SuccessLine/ParentRoleID");
				var aPhaseActivities = that.getModel("slDefaultModel").getProperty("/PhaseDetails/PhaseTouchPoints");
				//	var aActivityTypes = that.getModel("slDefaultModel").getProperty("/SuccessLine/ActivityTypes");
				var aRoleActvt = result.data.results;

				//Separate RoleMpngId "067" for (!sRegAccess && bSlLeadAccess)
				// var aOtherRoleActvt = aRoleActvt.filter((oRole) => {
				// 	return oRole.RoleMpngID === "067";
				// });

				// aRoleActvt = aRoleActvt.filter((oRole) => {
				// 	return oRole.RoleMpngID !== "067";
				// });

				$.each(aActivities, function (index, actvt) {
					let aEnabledRoles = [];
					actvt.Title = actvt.ActvtTypeDesc;
					aRoleActvt.filter((item) => {
						if (actvt.RoleMpngID === "") { //All Role 
							if (item.ActivityId === actvt.ActivityId && item.AsstdId === actvt.ActvtAsstdID) {
								if (item.RoleMpngID === activityRole) {
									actvt.RegistrationAccess = true;
									//Form layout id will be assigned once RegistrationAccess is set to true;
									actvt.frmlayout_id = item.FormLayout;
									actvt.ChildFrmLayoutId = item.ChildFrmLayoutId;
									//	actvt.RoleMpngID = item.RoleMpngID; //Change for Activity Role
									//	actvt.ParentRoleId = ParentRoleId;
								}
								aEnabledRoles.push(item.ActRoleSuffix);
							}
						} else {
							if (item.ActivityId === actvt.ActivityId && item.RoleMpngID === actvt.RoleMpngID) {
								//	actvt.Title = item.ActivityTypeDesc;
								if (item.RoleMpngID === activityRole) {
									actvt.RegistrationAccess = true;
									//Form layout id will be assigned once RegistrationAccess is set to true;
									actvt.frmlayout_id = item.FormLayout;
									actvt.ChildFrmLayoutId = item.ChildFrmLayoutId;
								}
								//SL lead should get registration access when he assign lead
								let isSlLead = that.getModel("slDefaultModel").getProperty("/bSlLeadAccess");
								if (isSlLead && !actvt.RegistrationAccess) {
									actvt.RegistrationAccess = true;
								}
							}
						}
					});
					//Remove duplicates, make it comma separated
					var result = "";
					var actvtEnabledRoles = [...new Set(aEnabledRoles)];
					for (var i = 0; i < actvtEnabledRoles.length; i++) {
						if (actvtEnabledRoles[i] && actvtEnabledRoles[i].trim() !== "") {
							if (result === "") {
								result = actvtEnabledRoles[i];
							} else {
								result = result + " ," + actvtEnabledRoles[i];
							}
						}
					}
					actvt.EnabledRoles = result;
					//	actvt.EnabledRoles = aEnabledRoles;
				});
				this.setHierarchyData();
				this._getActivityRoleFilter(aActivities);

				//this.getModel("slDefaultModel").setProperty("/aOtherRoleActvtData", aOtherRoleActvt && aOtherRoleActvt.length ? aOtherRoleActvt : []);
				this.getModel("slDefaultModel").setProperty("/SuccessLineHierarchy/PlanItemsVisibility", false);
				that.getModel("slDefaultModel").refresh(true);
			});
		},

		/**
		 * Called when router is called for SLDetail. Private function of onInit.
		 * Used to get the SuccessLine ID and GUID to fetch SL details.
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_getSuccessLineData: function (bSelectedRow) {
			const that = this;
			that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
			SLService.getSLDetailData(this.SuccessLineId).then((result) => {
				that.SlDetailModel.setProperty("/isDataRecieved", true);
				this.SlDetailModel.setProperty("/isActvtPressed", true);
				if (result.data.results.length > 0) {
					that.SlDetailModel.setProperty("/OpportunityId", result.data.results[0].OpportunityId);
				}
				if (this.Component.getModel("masterData")) {
					that.SlDetailModel.setProperty("/sEstimatedClosedDate", result.data.results[0].EstCloseDt);
					$.each(result.data.results[0].to_slcomment.results, function (index, item) {
						if (item.CreatedBy === that.Component.getModel("user").getProperty("/UserId")) {
							item.EditActions = [{
								"Text": "Edit",
								"Icon": "sap-icon://edit"
							}, {
								"Text": "Delete",
								"Icon": "sap-icon://delete"
							}];
						}
					}.bind(this));
				}
				const oData = result.data.results[0];
				const tableVisibleCount = oData.to_slphase.results.length + oData.to_sltouchpoint.results.length + oData.to_slactivity.results
					.length;
				const oModel = that.getModel("slDefaultModel");
				const oSuccessLine = new SuccessLine(oData);
				let sParallelSlSnro = oData.ParallelSlSnro;
				oModel.setProperty("/SuccessLine/ParallelSlSnro", sParallelSlSnro);
				oModel.refresh();
				if (oData.to_slstorylink) {
					oSuccessLine.setStoryLinks(oData.to_slstorylink.results);
				}
				if (oData.to_slteam) {
					oSuccessLine.setSlTeam(oData.to_slteam.results);
				}
				if (oData.to_slactivity) {
					oSuccessLine.setSlActivities(oData.to_slactivity.results);
				}
				if (oData.to_slcomment) {
					oSuccessLine.setComments(oData.to_slcomment.results);
					this.SlDetailModel.setProperty("/Comments", oData.to_slcomment.results);
				}
				if (oData.to_slphase) {
					oSuccessLine.setPhases(oData.to_slphase.results);
				}
				if (oData.to_sltouchpoint) {
					oSuccessLine.setTouchPoints(oData.to_sltouchpoint.results,
						(oData.to_slactivity && oData.to_slactivity.results) ? oData.to_slactivity.results : []);
				}
				if (oData.to_sloppact) {
					oSuccessLine.setSlOppActvts(oData.to_sloppact.results);
				}
				if (oData.to_slattach) {
					oSuccessLine.setAttachments(oData.to_slattach.results);
				}
				oModel.setProperty("/SuccessLine", oSuccessLine);
				oModel.setProperty("/SuccessLine/TeamCount", oData.to_slteam.results.length);
				var to_slopp = oData.to_slopp.results;
				if (oData.to_slopp) {
					oModel.setProperty("/SuccessLine/to_slopp", to_slopp);
				}
				//Ability for user to manually mark an MSL as completed #170
				var oTreeTable = this.getView().byId("actvtRegTbl");
				if (oSuccessLine.StatusId === '12') {
					oTreeTable.addStyleClass("sapUiActivityTypeRowBackGround");
				} else {
					oTreeTable.removeStyleClass("sapUiActivityTypeRowBackGround");
				}
				let SlSnro = that.getModel("slDefaultModel").getProperty("/SuccessLine/SlSnro");
				that.getView().getModel("slDefaultModel").setProperty("/SuccessLine/Menu", true);
				Log.debug(oData);
				if (!this.harmonyServiceCheck()) {
					MessageToast.show("Opportunity data unavailable!  Reason: Harmony server down or Unauthorized access!");
				}
				that.fnGetServiceOutcomeAchievedData();
				that.fnSetSLLeadAccess();

				//Production issue fix for 10K+ Opportunity Data
				const oMasterSettingsModel = this.getModel("masterSettings");
				const masterOpportunityDataLoaded = oMasterSettingsModel.getProperty("/masterOpportunityDataLoaded");
				const oMasterSettingsBinding = new sap.ui.model.Binding(oMasterSettingsModel, "/masterOpportunityDataLoaded",
					oMasterSettingsModel.getContext(
						"/masterOpportunityDataLoaded"));
				oMasterSettingsBinding.attachChange(function () {
					that._setOpportunityData(oData.OpportunityId);
					that._setAccountData(oData.AccountId);
					that._setSLAOpportunityData(to_slopp);
				});

				//Production issue fix for 10K+ Opportunity Data
				if (masterOpportunityDataLoaded) {
					that._setOpportunityData(oData.OpportunityId);
					that._setAccountData(oData.AccountId);
					that._setSLAOpportunityData(to_slopp);
				}
				this._getOpptProfitCenterData(oSuccessLine.OpportunityId);
				//this._setContributers(oSuccessLine.Team);
				this._setAuthorized(oSuccessLine.Team, oSuccessLine.CreatedBy);
				this._setSlCompletion(oSuccessLine.Activities);
				this._getPresentationSettings();
				let planningItb = this.byId("idPlanItemsIconTabBarNoIcons");
				if (planningItb.getSelectedKey() === "presentation") {
					planningItb.setSelectedKey("planning");
				}
				if (!oData.to_sloppact.results.length) {
					this.getModel("slDefaultModel").setProperty("/SuccessLineHierarchyVisibleRows", tableVisibleCount);
				}
				this.getModel("slDefaultModel").setProperty("/SuccessLineHierarchy/PlanItemsVisibility", false);

				/*if (this.tpDetailStorage && this.tpDetailStorage.get("oTpDetails") && this.tpDetailStorage.get("oTpDetails").hasOwnProperty(
					"PhaseId") && this.tpDetailStorage.get("oTpDetails").hasOwnProperty(
						"TpointId")) {
					let oTpDetail = this.tpDetailStorage.get("oTpDetails");
					this._setTouchPointSelected(oTpDetail.PhaseId, oTpDetail.TpointId, oTpDetail.TchpointGuid, true);
					// that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
				} */

				const oTpDetail = this.tpDetailStorage?.get("oTpDetails");
				if (oTpDetail?.PhaseId && oTpDetail?.TpointId && oTpDetail?.TchpointGuid) {
					this._setTouchPointSelected(
						oTpDetail.PhaseId,
						oTpDetail.TpointId,
						oTpDetail.TchpointGuid,
						true
					);
				} else if (this.SlActGuid) {
					let aActivities = this.getModel("slDefaultModel").getProperty("/SuccessLine/Activities");
					let sPhaseId = "";
					let sTpId = "";
					$.each(aActivities, function (index, actvt) {
						if (actvt.ActGuid === that.SlActGuid) {
							sPhaseId = actvt.PhaseId;
							sTpId = actvt.TpointId;
						}
					});
					this._setActivitySelected(sPhaseId, sTpId, this.SlActGuid);
					// that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
				} else {
					if (this.SlPhaseId) {
						this._setPhaseDetails(this.SlPhaseId);
						// that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
					} else if (oSuccessLine.Phases[0]) {
						this._setPhaseDetails(oSuccessLine.Phases[0].PhaseId);
						// that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
					}
				}
				this._getCommentsCount();
				this.getServices();
				setTimeout(() => {
					that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
				}, 2000);
			});
		},

		/**
		 * Used to role for dropdown in plan table
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_getActivityRoleFilter: function (oActivites) {
			var that = this;
			var oArray = [];
			oActivites.filter(function (object) {
				if (!that.fnFindSameAccountObject(object.ParentRoleId, oArray)) {
					var oFilter = new sap.ui.model.Filter("RoleID", "EQ", object.ParentRoleId);
					oArray.push(oFilter);
				}
			});
			this.byId("planItemsActivityRole").getBinding("items").filter(oArray);
		},

		//Function to find if an same object is present in the array already
		fnFindSameAccountObject: function (oValue1, oArray) {
			var oSearchedObj = oArray.find(function (object) {
				return object.oValue1 === oValue1;
			});
			return oSearchedObj;
		},

		/**
		 * Called to set authorization mode for user logged in
		 * @param aSlTeam - Passes sl team data, sCreatedBy - sl creator id passed for authorization check
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_setAuthorized: function (aSlTeam, sCreatedBy) {
			let sLoginUserId = this.Component.getModel("user").getProperty("/UserId");
			let isAuthorized = false;
			let isEditForOreUser = true;
			let slLead = this.getModel("slDefaultModel").getProperty("/SuccessLine/SlLead");
			let oAppSettingModel = this.getOwnerComponent().getModel("appSettings");
			let isNonOreUser = oAppSettingModel.getProperty("/isNonOreUser");
			$.each(aSlTeam, function (index, team) {
				if (team.UserId === sLoginUserId) {
					isAuthorized = true;
				}
			});
			if (sLoginUserId === sCreatedBy || sLoginUserId === slLead) {
				isAuthorized = true;
			}
			//if the logged in user is non-ore user then
			if (isNonOreUser) {
				isAuthorized = false;
				isEditForOreUser = false;
			}
			this.getModel("slDefaultModel").setProperty("/SuccessLine/isAuthorized", isAuthorized);
			this.getModel("slDefaultModel").setProperty("/SuccessLine/isEditForOreUser", isEditForOreUser);
		},

		/**
		 * Calculate completion percentage in Detail Header based on activity status
		 * @param aActivities - activities data passed to calculate completion %
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_setSlCompletion: function (aActivities) {
			var that = this;
			let aTouchPoints = this.getModel("slDefaultModel").getProperty("/SuccessLine/TouchPoints");
			let aPhases = this.getModel("slDefaultModel").getProperty("/SuccessLine/Phases");
			let aCompletedAct = [];
			let aActiveActvts = [];
			let aRegActvts = [];
			this.isTpActive = false;
			$.each(aActivities, function (index, actvt) {
				aTouchPoints.filter((item) => {
					if (item.TpointId === actvt.TpointId && item.PhaseId === actvt.PhaseId) {
						that.isTpActive = item.Active;
						return that.isTpActive;
					}
				});
				if (that.isTpActive) {
					if (actvt.StatusId !== "15") {
						aActiveActvts.push(actvt);
					}

				}
				if (that.isTpActive && actvt.StatusId === "12" || actvt.StatusId === "14") {
					aCompletedAct.push(actvt);
				}
				if (that.isTpActive && (actvt.StatusId === "01" || actvt.StatusId === "12")) {
					aRegActvts.push(actvt);
				}
			});
			if (aCompletedAct.length && aActiveActvts.length) {
				var pCompletion = aCompletedAct.length / aActiveActvts.length * 100;
			} else {
				pCompletion = 0;
			}
			this.getModel("slDefaultModel").setProperty("/SuccessLine/ActiveActvts", aActiveActvts);
			this.getModel("slDefaultModel").setProperty("/SuccessLine/SlCompletion", Math.round(pCompletion));
			this.getModel("slDefaultModel").setProperty("/SuccessLine/TotalActCount", aActiveActvts.length);
			this.getModel("slDefaultModel").setProperty("/SuccessLine/ActRegCount", aRegActvts.length);

			//Get unique activity leads's
			const aDistinctActivityLeads = [];
			const map = new Map();
			for (const item of aActivities) {
				if (!map.has(item.ActLeadId)) {
					map.set(item.ActLeadId, true);
					if (item.ActLeadId !== "") {
						aDistinctActivityLeads.push(item);
					}
				}
			}
			this.getModel("slDefaultModel").setProperty("/SuccessLine/UniqueActivityLeads", aDistinctActivityLeads);
		},

		/**
		 * Get's Region data for opportunity
		 * @param oppId - opportunity id  passed to fetch region data
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_getOpptProfitCenterData: function (oppId) {
			var that = this;
			if (oppId && oppId !== "") {
				SLService.getOpptProfitCenterData(oppId).then((oData) => {
					var regionData = oData.data.results[0];
					if (regionData) {
						that.getModel("slDefaultModel").setProperty("/SuccessLine/Region", regionData.region);
						that.getModel("slDefaultModel").setProperty("/SuccessLine/SubRegion", regionData.sub_region);
					}
				});
			}
		},

		/**
		 * Set's Opportunity Data
		 * @param oppId - opportunity id  passed to fetch opportunity data
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_setOpportunityData: function (oppId) {
			let that = this;
			const oppData = this.Component.getModel("opportunityData").getProperty("/opportunityMapData");
			let oOpportunityDataModel = this.Component.getModel("opportunityData");
			let oOpportunityModel = this.getView().getModel("opportunityModel");
			let oFormModel = this.getView().getModel("formModel");
			if (oppData && oppId && oppId !== "") {
				let oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					format: "yMMMd"
				});
				const dateFormat = sap.ui.core.format.DateFormat.getInstance({
					pattern: "dd/MM/y",
					calendarType: sap.ui.core.CalendarType.Gregorian
				});
				let sEstCloseDate = oDateFormat.format(new Date(this.SlDetailModel.getProperty("/sEstimatedClosedDate")));
				let sOpportunity_Expect_End;
				if (oppData[oppId]) {
					sOpportunity_Expect_End = dateFormat.format(new Date(oppData[oppId].EXPECT_END));
				} else {
					sOpportunity_Expect_End = "Not Authorized";
				}
				if (sEstCloseDate === "" || sEstCloseDate === undefined) {
					sEstCloseDate = oDateFormat.format(new Date(oppData[oppId].EXPECT_END));
				}
				if (oppData && oppData[oppId]) {
					let oOppStatusMasterData = $.extend(true, {}, oOpportunityDataModel.getProperty("/oppStatusMasterData"));
					let oOppPhaseMasterData = $.extend(true, {}, oOpportunityDataModel.getProperty("/oppPhaseMasterData"));
					const oSelectedOpp = {
						"ACCOUNT": oppData[oppId].ACCOUNT,
						"ACCOUNT_NAME": oppData[oppId].ACCOUNT_NAME,
						"DESCRIPTION": oppData[oppId].DESCRIPTION,
						"OWNER_NAME": oppData[oppId].OWNER_NAME,
						"STATUS": oppData[oppId].STATUS,
						"STATUS_DESC": (Object.keys(oOppStatusMasterData).length) ? oOppStatusMasterData[oppData[oppId].STATUS].VALUE : "",
						"SALES_PHASE": (Object.keys(oOppPhaseMasterData).length) ? oOppPhaseMasterData[oppData[oppId].CURR_PHASE].VALUE : "",
						"INDUSTRY": oppData[oppId].INDUSTRY_MASTERCODE_TEXT,
						"EstimatedCloseDate": sEstCloseDate,
						"Opp_Expect_end": sOpportunity_Expect_End
					};
					this.SlDetailModel.setProperty("/SelectedOpportunity", oSelectedOpp);

					let oSelectedOpportunity = $.extend(true, {}, oSelectedOpp);
					oSelectedOpportunity.PHASE_DESC = oSelectedOpp.SALES_PHASE;
					oSelectedOpportunity.SALES_ORG_DESC = (oSelectedOpp["SALES_ORG_TEXT"]) ? oSelectedOpp["SALES_ORG_TEXT"] : "";
					oFormModel.setProperty("/Region", that.getView().getModel("slDefaultModel").getProperty(
						"/SuccessLine/Region"));
					oFormModel.setProperty("/SubRegion", that.getView().getModel("slDefaultModel").getProperty(
						"/SuccessLine/SubRegion"));
					oFormModel.setProperty("/Industry", oSelectedOpp.INDUSTRY);
					oOpportunityModel.setProperty("/selectedOpportunity", oSelectedOpportunity);

					this._setAccountData(oSelectedOpp.ACCOUNT, oppId);
					this._getOppTeam(oppId);
				} else {
					this.SlDetailModel.setProperty("/SelectedOpportunity", {});
					this.getView().getModel("formModel").setProperty("/SelectTeam", []);
				}
			} else {
				this.SlDetailModel.setProperty("/SelectedOpportunity", {});
				this.getView().getModel("formModel").setProperty("/SelectTeam", []);
			}
		},

		_setSLAOpportunityData: function (slOppos) {
			var that = this;
			var oTempArr = [];
			var opportunityData = this.Component.getModel("opportunityData");
			let oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				format: "yMMMd"
			});
			const dateFormat = sap.ui.core.format.DateFormat.getInstance({
				pattern: "dd/MM/y",
				calendarType: sap.ui.core.CalendarType.Gregorian
			});
			let sEstCloseDate = oDateFormat.format(new Date(this.SlDetailModel.getProperty("/sEstimatedClosedDate")));
			let oOppStatusMasterData = $.extend(true, {}, opportunityData.getProperty("/oppStatusMasterData"));
			let oOppPhaseMasterData = $.extend(true, {}, opportunityData.getProperty("/oppPhaseMasterData"));
			const oppData = opportunityData.getProperty("/opportunityMapData");
			if (oppData) {
				for (var i = 0; i < slOppos.length; i++) {
					var oppId = slOppos[i].Opportunityno;
					var mainOppId = slOppos[i].MainOpp;
					if (oppId && oppId !== "") {
						var oTempObj;
						const oppData = opportunityData.getProperty("/opportunityMapData");
						if (sEstCloseDate === "" || sEstCloseDate === undefined) {
							sEstCloseDate = oDateFormat.format(new Date(oppData[oppId].EXPECT_END));
						}

						if (oppData && oppData[oppId]) {
							const oSelectedOpp = {
								"ACCOUNT": oppData[oppId].ACCOUNT,
								"ACCOUNT_NAME": oppData[oppId].ACCOUNT_NAME,
								"DESCRIPTION": oppData[oppId].DESCRIPTION,
								"OWNER_NAME": oppData[oppId].OWNER_NAME,
								"STATUS": oppData[oppId].STATUS,
								"STATUS_DESC": (Object.keys(oOppStatusMasterData).length) ? oOppStatusMasterData[oppData[oppId].STATUS].VALUE : "",
								"PHASE_DESC": (Object.keys(oOppPhaseMasterData).length) ? oOppPhaseMasterData[oppData[oppId].CURR_PHASE].VALUE : "",
								"SALES_ORG_TEXT": oppData[oppId].SALES_ORG_TEXT,
								"INDUSTRY": oppData[oppId].INDUSTRY_MASTERCODE_TEXT !== "" ? oppData[oppId].INDUSTRY_MASTERCODE_TEXT : "Currently Unavailable",
								"REGION": "Currently Unavailable",
								"SUB_REGION": "Currently Unavailable",
								"IsChild": true,
								"OPP_ID": oppId,
								"EstimatedCloseDate": sEstCloseDate,
								"Opp_Expect_end": dateFormat.format(new Date(oppData[oppId].EXPECT_END))
							};
							SLService.getOpptProfitCenterData(oppId).then((regionData) => {
								//To update Region and Sub-Region in Additional Opps
								let oData = regionData.data.results;
								let SLAddOpportunities = that.SlDetailModel.getProperty("/SLAddOpportunities");
								if (oData.length) {
									let OppId = oData[0].OPPT_ID;
									let index = SLAddOpportunities.findIndex((slAddOppObj) => {
										return slAddOppObj.OpportunityId === OppId;
									});
									let path = "/SLAddOpportunities/" + index + "/SelectedOpportunities/0";
									that.SlDetailModel.setProperty(path + "/REGION", oData[0].region !== "" ? oData[0].region : "Currently Unavailable");
									that.SlDetailModel.setProperty(path + "/SUB_REGION", oData[0].sub_region !== "" ? oData[0].sub_region :
										"Currently Unavailable");
								}
							});
							OppService.getAccountDetails(oppData[oppId].ACCOUNT).then((oSegData) => {
								//To update Segment in Additional Opps
								let oData = oSegData.data;
								let SLAddOpportunities = that.SlDetailModel.getProperty("/SLAddOpportunities");
								if (oData) {
									let Account = oData.PARTNER;
									for (let j = 0; j < SLAddOpportunities.length; j++) {
										if (SLAddOpportunities[j].ACCOUNT === Account) {
											let path = "/SLAddOpportunities/" + j + "/SelectedOpportunities/0";
											that.SlDetailModel.setProperty(path + "/SEGMENT", oData.SEGMENT !== "" ? oData.SEGMENT : "Currently Unavailable");
										}
									}
								}
							});
							OppService._getOpportunitiesTeam(oppId,
								"OPPT_ID,SALES_ORG_TEXT,INDUSTRY_MASTERCODE,INDUSTRY,INDUSTRY_MASTERCODE_TEXT,INDURSTRY_TEXT").then(
									(OppoSalesData) => {
										//To update Sales Organization and Industry in Additional Opps
										let oData = OppoSalesData.data;
										let OppId = oData.OPPT_ID;
										let SLAddOpportunities = that.SlDetailModel.getProperty("/SLAddOpportunities");
										let index = SLAddOpportunities.findIndex((slAddOppObj) => {
											return slAddOppObj.OpportunityId === OppId;
										});
										let path = "/SLAddOpportunities/" + index + "/SelectedOpportunities/0";
										that.SlDetailModel.setProperty(path + "/SALES_ORG_TEXT", oData.SALES_ORG_TEXT !== "" ? oData.SALES_ORG_TEXT :
											"Currently Unavailable");
										that.SlDetailModel.setProperty(path + "/INDUSTRY", oData.INDUSTRY_MASTERCODE_TEXT !== "" ? oData.INDUSTRY_MASTERCODE_TEXT :
											"Currently Unavailable");
									});
							oTempObj = {
								"IsChild": false,
								"MainOpp": mainOppId,
								"OpportunityId": oppId,
								"ACCOUNT": oppData[oppId].ACCOUNT,
								"SelectedOpportunities": [oSelectedOpp]
							};
							oTempArr.push(oTempObj);
						} else if (mainOppId) {
							oTempObj = {
								"IsChild": false,
								"OpportunityId": oppId
							};
							oTempArr.push(oTempObj);
							this.SlDetailModel.setProperty("/isGetMainOppData", true);
						} else {
							oTempObj = {
								"IsChild": false,
								"MainOpp": mainOppId,
								"OpportunityId": oppId,
								"ACCOUNT": "",
								"SelectedOpportunities": []
							};
							oTempArr.push(oTempObj);
						}
					}
				}
				this.SlDetailModel.setProperty("/SLAddOpportunities", oTempArr);
			}

		},

		/**
		 * Set's Account data
		 * @param sAccountId -  account id  passed to fetch account information
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_setAccountData: function (sAccountId, oppId) {
			var that = this;
			let oFormModel = this.getView().getModel("formModel");
			let oOpportunityModel = this.getView().getModel("opportunityModel");
			let oOpportunityDataModel = this.Component.getModel("opportunityData");
			let oOppData = that.Component.getModel("opportunityData").getProperty("/opportunityMapData");
			if (!oOppData) {
				return;
			}
			if (sAccountId && sAccountId !== "") {
				OppService.getAccountDetails(sAccountId).then((oData) => {
					var isGetMainOppData = that.SlDetailModel.getProperty("/isGetMainOppData");
					if (isGetMainOppData) {
						var SLAddOpportunity = that.SlDetailModel.getProperty("/SLAddOpportunities/0");
						let statusdata = $.extend(true, {}, oOpportunityDataModel.getProperty("/oppStatusMasterData"));
						let status = oData.data.STATUS;
						let StatusDes = "Not Authorized";
						if (statusdata[status]) {
							StatusDes = statusdata[status].VALUE;
						}
						let sOppExpectEndDate;
						if (that.Component.getModel("opportunityData").getData().opportunityMapData[oppId] === undefined) {
							sOppExpectEndDate = "Not Authorized";
						}
						const oSelectedOpp = {
							"ACCOUNT_NAME": oData.data.PARENT_NAME,
							"OWNER_NAME": oData.data.PARENT_ACC_OWNR_NM,
							"STATUS_DESC": StatusDes,
							"SALES_ORG_TEXT": oData.data.SALES_ORG_TEXT,
							"PHASE_DESC": oData.data.PHASE_DESC,
							"SEGMENT": oData.data.SEGMENT,
							"ACCOUNT": oData.data.PARTNER,
							"DESCRIPTION": oData.data.DESCRIPTION,
							"STATUS": oData.data.STATUS,
							"SALES_ORG_DESC": "",
							"SALES_PHASE": "",
							"IsChild": true,
							"INDUSTRY": "Not Authorized",
							"MU_NAME": "Not Authorized",
							"REGION": "Not Authorized",
							"SUB_REGION": "Not Authorized",
							"ADDITIONAL_STATUS": "",
							"OPP_ID": SLAddOpportunity.OpportunityId,
							"Opp_Expect_end": sOppExpectEndDate
						};
						var oTempObj = {
							"IsParent": true,
							"MainOpp": true,
							"IsChild": false,
							"OpportunityId": SLAddOpportunity.OpportunityId,
							"ACCOUNT": oData.data.ACCOUNT,
							"SelectedOpportunities": [oSelectedOpp]
						};
						that.SlDetailModel.setProperty("/SLAddOpportunities/0", oTempObj);
						that.SlDetailModel.setProperty("/isGetMainOppData", false);
						return;
					}
					if (that.SlDetailModel.getProperty("/SelectedOpportunity")) {
						that.SlDetailModel.setProperty("/SelectedOpportunity/ACCOUNT_NAME", oData.data.PARTNER_NAME);
						that.SlDetailModel.setProperty("/SelectedOpportunity/ISS", oData.data.GTM_ISS_DESC);
						that.SlDetailModel.setProperty("/SelectedOpportunity/accountid", oData.data.PARTNER);
						that.SlDetailModel.setProperty("/SelectedOpportunity/SEGMENT", oData.data.SEGMENT);
						that.SlDetailModel.setProperty("/SelectedOpportunity/OWNER_NAME", oData.data.PARENT_ACC_OWNR_NM);
						that.SlDetailModel.setProperty("/SelectedOpportunity/OWNER", oData.data.PARENT_ACC_OWNER);
						that.SlDetailModel.setProperty("/SelectedOpportunity/Active_Account_Status", oData.data.STATUS_DESC);
						that.SlDetailModel.setProperty("/SelectedOpportunity/Regional_Buying_Classification", oData.data.GTM_BUY_REG_DESC);
						that.SlDetailModel.setProperty("/SelectedOpportunity/Regional_Buying_Lifecycle", oData.data.GTM_BUY_GLB_DESC);
						that.SlDetailModel.setProperty("/SelectedOpportunity/Internal_Account_Classification", oData.data.TG_ACCOUNT_DESC);
						that.SlDetailModel.setProperty("/SelectedOpportunity/IMS", oData.data.SEGMENT_DESC);
						that.SlDetailModel.setProperty("/SelectedOpportunity/ERPID", oData.data.ERP_ID);
						that.SlDetailModel.setProperty("/SelectedOpportunity/AccountId_Name", oData.data.PARTNER_NAME + '-' + oData.data.PARTNER);
					} else {
						let obj = {
							"ACCOUNT_NAME": oData.data.PARTNER_NAME,
							"ISS": oData.data.GTM_ISS_DESC,
							"accountid": oData.data.PARTNER,
							"SEGMENT": oData.data.SEGMENT_DESC,
							"OWNER_NAME": oData.data.PARENT_ACC_OWNR_NM,
							"OWNER": oData.data.PARENT_ACC_OWNER,
							"STATUS_DESC": oData.data.STATUS_DESC,
							"Active_Account_Status": oData.data.STATUS_DESC,
							"Regional_Buying_Classification": oData.data.GTM_BUY_REG_DESC,
							"Regional_Buying_Lifecycle": oData.data.GTM_BUY_GLB_DESC,
							"Internal_Account_Classification": oData.data.TG_ACCOUNT_DESC,
							"IMS": oData.data.SEGMENT_DESC,
							"ERPID": oData.data.ERP_ID,
							"AccountId_Name": oData.data.PARTNER_NAME + '-' + oData.data.PARTNER
						};
						that.SlDetailModel.setProperty("/SelectedOpportunity", obj);
					}

					let oSelectedOpp = $.extend(true, {}, that.SlDetailModel.getProperty("/SelectedOpportunity"));
					oSelectedOpp.PHASE_DESC = oSelectedOpp.SALES_PHASE;
					oSelectedOpp.SALES_ORG_DESC = (oSelectedOpp["SALES_ORG_TEXT"]) ? oSelectedOpp["SALES_ORG_TEXT"] : "";
					oFormModel.setProperty("/Region", that.getView().getModel("slDefaultModel").getProperty(
						"/SuccessLine/Region"));
					oFormModel.setProperty("/SubRegion", that.getView().getModel("slDefaultModel").getProperty(
						"/SuccessLine/SubRegion"));
					oFormModel.setProperty("/Industry", oSelectedOpp.INDUSTRY);
					oOpportunityModel.setProperty("/selectedOpportunity", oSelectedOpp);

					if (oppId) {
						const oppData = this.Component.getModel("opportunityData").getProperty("/opportunityMapData");
						if (oppData && oppData[oppId]) {
							let oppEstCloseDate = new Date(oppData[oppId].EXPECT_END);
							let lsfEstCloseDate = this.getView().getModel("slDefaultModel").getProperty("/SuccessLine/EstCloseDt");
							let selectedOpportunity = this.SlDetailModel.getProperty("/SelectedOpportunity");
							let to_slopp = this.getView().getModel("slDefaultModel").getProperty("/SuccessLine/to_slopp");
							let sEstimatedClosedDate = this.SlDetailModel.getProperty("/sEstimatedClosedDate");
							if (sEstimatedClosedDate === "" || sEstimatedClosedDate === undefined) {
								sEstimatedClosedDate = oppEstCloseDate;
							}
							/*	if (oppEstCloseDate.toDateString() !== lsfEstCloseDate.toDateString()) {
									var oTempArr = [];
									to_slopp.filter(function (obj) {
										if (!obj.MainOpp) {
											var oTempObj = {
												"Opportunityno": obj.Opportunityno,
												"SlId": obj.SlId
											};
											oTempArr.push(oTempObj);
										}
									});
									//update Estimated Close date
									let slData = this.getView().getModel("slDefaultModel").getProperty("/SuccessLine");
									let slTeam = this.getView().getModel("slDefaultModel").getProperty("/SuccessLine/Team");
									let aTeam = [];
									for (var i = 0; i < slTeam.length; i++) {
										let sTeam = {
											EmailId: slTeam[i].EmailId,
											FullName: slTeam[i].FullName,
											MobileNumber: slTeam[i].MobileNumber,
											PhoneNumber: slTeam[i].PhoneNumber,
											Role: slTeam[i].Role,
											SlId: slTeam[i].SlId,
											SlSnro: slTeam[i].SlSnro,
											UserId: slTeam[i].UserId
										};
										aTeam.push(sTeam);
									}
									let updateSLForm = {
										AccountId: slData.AccountId,
										EstCloseDate: oppEstCloseDate,
										Name: slData.Name,
										OREConfigID: slData.OREConfigID,
										OppComments: slData.OppComment,
										OpportunityId: slData.OpportunityId,
										SLStatus: slData.StatusId,
										SlId: slData.SlId,
										SlLead: slData.SlLead,
										SlLeadName: slData.SlLeadName,
										SlNo: slData.SlSnro,
										StartDate: slData.StartDate,
										Story: slData.Story,
										TempId: slData.TempId,
										TempTitle: slData.TempTitle,
										to_opp: [{
											OPPT_ID: slData.OpportunityId,
											DESCRIPTION: selectedOpportunity.DESCRIPTION
										}],
										to_acc: [{
											accountname: selectedOpportunity.ACCOUNT_NAME,
											accountid: selectedOpportunity.ACCOUNT,
											industry: selectedOpportunity.INDUSTRY,
											iss: selectedOpportunity.ISS,
											iac: selectedOpportunity.Internal_Account_Classification
										}],
										to_link: slData.StoryLinks,
										to_team: aTeam,
										to_addopp: oTempArr
									};
									SLService.createNewSuccessLine(updateSLForm).then((oData) => {
										that.refreshSL();
									});
								}*/
						}
					}
				});
			}
		},

		/**
		 * Get's roles and sets default role
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_getRoleMasterData: function () {
			SLService.getRoles().then((oData) => {
				let roles = oData.data.results;
				const oModel = this.getModel("slDefaultModel");
				roles.filter(function (obj) {
					if (obj.RoleID === "") {
						obj.RoleID = "0008";
					}
				});
				oModel.setProperty("/SuccessLine/Roles", roles);
				var defaultRole = roles.filter(function (obj) {
					if (obj.DefaultRole === "X") {
						return obj;
					}
				});
				if (defaultRole.length === 0) {
					defaultRole = "0001";
				} else {
					defaultRole = defaultRole[0].RoleID;
				}
				//Role sepcific restriction for Activities
				SLService.getDefaultRole().then((oResponse) => {
					let data = oResponse.data.results[0];
					if (data) {
						let activityRole = data.RoleMpngID;
						oModel.setProperty("/SuccessLine/ActivityRole", activityRole);
						oModel.setProperty("/SuccessLine/ParentRoleID", data.ParentRoleID);
						defaultRole = data.RoleID;
						roles.filter(function (role) {
							if (role.ParentRole) {
								if (defaultRole === role.RoleID) {
									defaultRole = role.ParentRole;
									return;
								}
							}
						});
					}
					oModel.setProperty("/SuccessLine/Role", defaultRole);
					oModel.setProperty("/SuccessLine/DefaultRole", defaultRole);
					this.getRoleBasedActivityTypes(false);
					this._getActivityRoleData();
				});
			});
		},

		/**
		 * Used to get associate type - account or opportunity
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		getAssociateType: function () {
			var associateType = 0;
			if (this.getModel("slDefaultModel").getProperty("/SuccessLine").OpportunityId !== "") {
				associateType = 0;
			} else {
				associateType = 1;
			}
			if (associateType === 0) {
				associateType = 502;
			} else
				if (associateType === 1) {
					associateType = 501;
				}
			return associateType;
		},

		/**
		 * Used to get service list for dropdown selection
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		getServices: function () {
			let aFilter = [new Filter("SourceType", FilterOperator.EQ, "SL_TP")];
			SLService.getSources(aFilter).then((oData) => {
				this.getModel("slDefaultModel").setProperty("/SuccessLine/ServiceSource", oData.data.results);
			});
			SLService.getServices().then((oData) => {
				//For ServiceType 0001 and existing TchpointId, show Outome already in use in service list
				let oTouchPoints = this.getModel("slDefaultModel").getProperty("/SuccessLine/TouchPoints");
				let aResultData = oData.data.results;
				$.each(aResultData, function (index, aServiceList) {
					aServiceList.OutComeUsed = false;
					oTouchPoints.filter((item) => {
						if (item.TpointId === aServiceList.TchpointId && aServiceList.ServiceType === "0001") {
							aServiceList.OutComeUsed = true;
						}
					});
				});
				this.getModel("slDefaultModel").setProperty("/SuccessLine/ServiceList", aResultData);
			});

		},

		/**
		 * Sets ActivityTypes based on associate type
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		getRoleBasedActivityTypes: function (isRoleFilterChanged) {
			var that = this;
			this.Component.getModel("appSettings").setProperty("/isActvtListBusy", true);
			var sRole = this.getModel("slDefaultModel").getProperty("/SuccessLine/Role");
			var currentUserRoleMpngId = this.getModel("slDefaultModel").getProperty("/SuccessLine/ActivityRole");
			var associateType = 0;
			associateType = this.getAssociateType();
			let sSourceType = this.getModel("slDefaultModel").getProperty("/SuccessLine/Source");
			if (sRole === "0008") {
				sRole = "";
			}
			var aFilter = [];
			var bSlLeadAccess = this.getView().getModel("slDefaultModel").getProperty("/bSlLeadAccess");
			if (bSlLeadAccess) {
				aFilter.push(new Filter({
					filters: [
						new Filter({
							path: 'ParentRole',
							operator: FilterOperator.EQ,
							value1: sRole
						}),
						new Filter({
							path: 'ParentRole',
							operator: FilterOperator.EQ,
							value1: ''
						})
					],
					and: false
				}));
			} else {
				aFilter.push(new Filter({
					filters: [
						new Filter({
							path: 'RoleMpngID',
							operator: FilterOperator.EQ,
							value1: currentUserRoleMpngId
						}),
						new Filter({
							path: 'RoleMpngID',
							operator: FilterOperator.EQ,
							value1: ''
						})
					],
					and: false
				}));
			}
			//	aFilter.push(new Filter("ParentRole", FilterOperator.EQ, sRole));
			aFilter.push(new Filter("ActvtAsstdID", FilterOperator.EQ, associateType));
			if (sSourceType !== "001") {
				aFilter.push(new Filter("SourceType", FilterOperator.EQ, sSourceType));
			}
			SLService.getRoleBasedActvtTypes(aFilter).then((oData) => {
				let aResultData = oData.data.results;
				this.getModel("slDefaultModel").setProperty("/SuccessLine/ActivityTypes", aResultData);
				this.ActTypeMap = {};
				let aActvtTypes = [];
				if (aResultData && aResultData.length > 0) {
					aResultData.filter(function (item, index) {
						that.ActTypeMap[item.ActvtTypeDesc] = item;
					});
					$.each(that.ActTypeMap, function (index, item) {
						aActvtTypes.push(item);
					});
				}
				this.getModel("slDefaultModel").setProperty("/SuccessLine/FilteredActTypes", aActvtTypes);
				if (this.byId("actTypeId")) {
					this.byId("actTypeId").setSelectedKey("");
				}
				if (this.byId("addActvtList")) {
					this.byId("addActvtList").getBinding("items").filter([]);
				}
				if (this.byId("addActvtSearch")) {
					this.byId("addActvtSearch").setValue("");
				}
				this.isRoleFilterChanged = isRoleFilterChanged;
				this.Component.getModel("appSettings").setProperty("/isActvtListBusy", false);
			});
		},

		/**
		 * Get's role based activity types
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleRoleSelect: function (oEvent) {
			this.getRoleBasedActivityTypes(false);
		},
		/**
		 * Navigates to SL Form page when Edit button is pressed.
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleEditSuccessLine: function () {
			var oNavParams = {
				PhaseId: this.getModel("slDefaultModel").getProperty("/TouchPointDetails/PhaseId"),
				TpointId: this.getModel("slDefaultModel").getProperty("/TouchPointDetails/TpointId"),
				TchpointGuid: this.getModel("slDefaultModel").getProperty("/TouchPointDetails/TchpointGuid")
			};
			this.tpDetailStorage.put("oTpDetails", oNavParams);
			this.getRouter().navTo("SlForm", {
				OptionalQueryString: {
					SlNo: this.getModel("slDefaultModel").getProperty("/SuccessLine/SlSnro")
				}
			}, false);
		},

		/**
		 * Event called to archive SL
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_archiveSL: function (bState) {
			let oSlArchive = {
				"SlSnro": this.getModel("slDefaultModel").getProperty("/SuccessLine/SlSnro"),
				"SlId": this.getModel("slDefaultModel").getProperty("/SuccessLine/SlId"),
				"TempId": this.getModel("slDefaultModel").getProperty("/SuccessLine/TempId"),
				"StatusId": this.getModel("slDefaultModel").getProperty("/SuccessLine/StatusId"),
				"Archive": this.getModel("slDefaultModel").getProperty("/SuccessLine/Archive")
			};
			let archive = this.getModel("slDefaultModel").getProperty("/SuccessLine/Archive");
			SLService.updateSL(oSlArchive).then((oData) => {
				if (archive) {
					MessageToast.show("Archived");
				} else {
					MessageToast.show("Un Archived");
				}
			});
		},

		/**
		 * Called when Archive Switch is toogled. Archive's or Unarchives the SL based on user selection.
		 * @param oEvent- oEvent is passed get state
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleArchiveSL: function (oEvent) {
			var that = this;
			this.bState = oEvent.getParameter("state");
			let slActive = false;
			let Opportunity = that.getModel("slDefaultModel").getProperty("/SuccessLine/OpportunityId");
			if (!this.bState && Opportunity) {
				let filterBy, searchID, message;
				let continueMessage = "";
				filterBy = "OpportunityId";
				searchID = Opportunity;
				let SlSnro = this.getModel("slDefaultModel").getProperty("/SuccessLine/SlSnro");
				let StatusId = this.getModel("slDefaultModel").getProperty("/SuccessLine/StatusId");
				that.getView().setModel(new JSONModel([]), "preExistingSuccessLineModel");
				let aFilter = [new Filter(filterBy, FilterOperator.EQ, searchID)];
				//Check for Preexisting SuccessLine
				that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
				let aActiveSL = [];
				SLService.validateSuccessLineAvailability(aFilter).then((oData) => {
					that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
					var data = oData.data.results;
					let bUserPart = false;
					let oPreExistingSuccessLineModel = that.getView().getModel("preExistingSuccessLineModel");
					for (var i = 0; i < data.length; i++) {
						if (data[i].SLStatusID === "01" && data[i].SlSnro !== SlSnro && data[i].Archive === false) {
							if (data[i].MainOpp || (!data[i].MainOpp && data[i].SlOpp)) {
								slActive = true;
								message = "Already an active SL exists for the same opportunity, \nPlease archive #SL number " + data[i].SlSnro +
									" and continue with same.";
								oData.data.results[i].Active = true;
								oData.data.results[i].message = message;
								aActiveSL.push(oData.data.results[i]);
							}
						} else {
							data[i].Archive = false; //to hide the empty field
							message = "";
							oData.data.results[i].Active = false;
							oData.data.results[i].message = message;
						}
						if (!data[i].Archive) {
							if (data[i].SLStatusID === "01" && data[i].IsPartOfSl === "X" && data[i].SlSnro !== SlSnro) {
								bUserPart = true;
							}
						}
					}
					if (!slActive || StatusId == "02") {
						this._archiveSL(this.bState);
					} else {
						var result = aActiveSL.filter((item) => {
							return item.SlSnro !== this.getModel("slDefaultModel").getProperty("/SuccessLine/SlSnro");
						});
						that.getView().getModel("preExistingSuccessLineModel").setData(aActiveSL);
						if (bUserPart) {
							oPreExistingSuccessLineModel.setProperty("/bUsrPart", true);
							oPreExistingSuccessLineModel.setProperty("/bUsrNotPart", false);
						} else {
							oPreExistingSuccessLineModel.setProperty("/bUsrPart", false);
							oPreExistingSuccessLineModel.setProperty("/bUsrNotPart", true);
						}
						that.getView().getModel("preExistingSuccessLineModel").setProperty("/activeSL", slActive);
						that.getView().getModel("preExistingSuccessLineModel").setProperty("/continueMessage", continueMessage);
						that.getModel("slDefaultModel").setProperty("/SuccessLine/Archive", true);
						that._preExistingSuccessLine();
					}
				});
			} else {
				this._archiveSL(this.bState);
			}
		},

		/**
		 * Check for preexisting SL
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_preExistingSuccessLine: function () {
			if (!this.preExistingDialog) {
				this.preExistingDialog = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.PreExistingSuccessLine",
					this);
				this.getView().addDependent(this.preExistingDialog);
			}
			this.preExistingDialog.open();
		},

		/**
		 * Close preexisting sl dialog
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onClosePreExistingSL: function () {
			this.preExistingDialog.close();
		},

		/**
		 * Helper method to trigger email to contact
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleContactOwner: function (OwnerEmail, Name) {
			let email = OwnerEmail;
			let subject = Name;
			sap.m.URLHelper.triggerEmail(email, subject);
		},

		/**
		 * Set's the selected touch point when navigating from another view
		 * @param sPhaseId - phase id passed to filter touchpoint data, sTpId - touchpoint id passed to fetch touchpoint data, isStorage - a flag to check if the storage has the data
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_setTouchPointSelected: function (sPhaseId, sTpId, TchpointGuid, isStorage, noChange) {
			let that = this;
			const oModel = this.getModel("slDefaultModel");
			const oSuccessLine = oModel.getProperty("/SuccessLine");
			const aTouchPoints = oSuccessLine.TouchPoints;

			const selectedTouchPoint = aTouchPoints.filter((item) => {
				return (item.TpointId === sTpId && item.PhaseId === sPhaseId && item.TchpointGuid === TchpointGuid);
			});
			if (selectedTouchPoint.length > 0) {
				selectedTouchPoint[0].TpActvtCount = selectedTouchPoint[0].Activities.length;
				selectedTouchPoint[0].serviceType = (selectedTouchPoint[0].ServiceTypeDesc === "Outcome Service") ? "Outcome" : null;
				selectedTouchPoint[0].achieved = (selectedTouchPoint[0].StatusId === "01") ? true : false;
				selectedTouchPoint[0].notes = selectedTouchPoint[0].TchpntNotes;
				selectedTouchPoint[0].isNoteEditable = false;
				let oServiceData = selectedTouchPoint[0];
				SLService.getSOAttachments(oServiceData).then((oData) => {
					let oTempServiceData = $.extend(true, {}, oData);
					let aSOAttachments = oTempServiceData.data.to_TpLinks.results;
					oModel.setProperty("/aSOAttachments", aSOAttachments);
					let aServiceStatus = oTempServiceData.data.to_SrvStatus.results;
					oModel.setProperty("/aServiceStatus", aServiceStatus);
					let aResources = oTempServiceData.data.to_TpResourc.results;
					oModel.setProperty("/aResources", aResources);
					that.fnGetServiceOutcomeAchievedData();
				});

				oModel.setProperty("/TouchPointDetails", selectedTouchPoint[0]);

				if (!noChange) {
					oModel.setProperty("/SuccessLine/TpDetailVisibility", true);
					oModel.setProperty("/SuccessLine/PhaseDetailVisibility", false);
					oModel.setProperty("/SuccessLine/ActivityDetailVisibility", false);
				}
				var oNavParams = {
					PhaseId: selectedTouchPoint[0].PhaseId,
					TpointId: selectedTouchPoint[0].TpointId,
					TchpointGuid: selectedTouchPoint[0].TchpointGuid
				};
				this.tpDetailStorage.put("oTpDetails", oNavParams);
				this.SlActGuid = undefined;
				this.SlPhaseId = undefined;
				var oTreeTable = this.getView().byId("actvtRegTbl");
				var oRows = oTreeTable.getRows();
				let iRowIndex = null;
				var sPath;
				for (var i = 0; i < oRows.length; i++) {

					if (oRows[i].getBindingContext("slDefaultModel")) {
						var oRow = oRows[i].getBindingContext("slDefaultModel").getObject();
						if (oRow.PhaseId === sPhaseId && oRow.TpointId === sTpId &&
							oRow.TchpointGuid === TchpointGuid && oRow.Level === "SERVICE") {
							iRowIndex = oRows[i].getIndex();
							sPath = oRows[i].getBindingContext("slDefaultModel").getPath();
							this.getView().getModel("slDefaultModel").setProperty(sPath + "/selected", true);
							this.selectedIndex = iRowIndex;
							oTreeTable.clearSelection();
							this.getView().byId("actvtRegTbl").setSelectedIndex(iRowIndex);
							oModel.setProperty("/rowSelectedindex", iRowIndex);
							return;
						}

					}
				}
			} else {
				this.tpDetailStorage.put("oTpDetails", null);
				this.refreshSL();
			}
		},

		/**
		 * Used to MTR time record
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleTimeRecord: function (oEvent) {
			oEvent.getSource().openTimeRecordBox();
		},

		/**
		 * Fetch's touchpoints based on phase selected. Also scrolls down to the selected phase in the graph
		 * @param sPhaseId - phase id passed to fetch phase details
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_setPhaseDetails: function (sPhaseId) {
			const oModel = this.getModel("slDefaultModel");
			const oSuccessLine = oModel.getProperty("/SuccessLine");
			let aPhases = [];
			if (sPhaseId) {
				aPhases = oSuccessLine.Phases;
			} else {
				aPhases = oModel.getProperty("/SuccessLineHierarchy/Phases");
			}
			const oPhase = aPhases.find((item) => {
				return item.PhaseId === sPhaseId;
			});
			const aTouchPoints = oSuccessLine.TouchPoints;
			oPhase.PhaseTouchPoints = aTouchPoints.filter((item) => {
				return item.PhaseId === sPhaseId;
			});
			oPhase.TouchPointCount = oPhase.PhaseTouchPoints.length;
			oModel.setProperty("/PhaseDetails", oPhase);
			this.SlPhaseId = sPhaseId;
			this.SlActGuid = undefined;
			oModel.setProperty("/SuccessLine/PhaseDetailVisibility", true);
			oModel.setProperty("/SuccessLine/TpDetailVisibility", false);
			oModel.setProperty("/SuccessLine/ActivityDetailVisibility", false);
			var oTreeTable = this.getView().byId("actvtRegTbl");
			var oRows = oTreeTable.getRows();
			let iRowIndex = null;
			var sPath;
			for (var i = 0; i < oRows.length; i++) {
				if (oRows[i].getBindingContext("slDefaultModel")) {
					var oRow = oRows[i].getBindingContext("slDefaultModel").getObject();
					if (oRow.PhaseId === sPhaseId && oRow.Level === "PHASE") {
						iRowIndex = oRows[i].getIndex();
						sPath = oRows[i].getBindingContext("slDefaultModel").getPath();
						this.getView().getModel("slDefaultModel").setProperty(sPath + "/selected", true);
						this.selectedIndex = iRowIndex;
						oTreeTable.clearSelection();
						this.getView().byId("actvtRegTbl").setSelectedIndex(iRowIndex);
						oModel.setProperty("/rowSelectedindex", iRowIndex);
						return;
					}
				}
			}

		},
		/**
		 * Called when service is enabled or disabled in phase view
		 * @param oEvent- oEvent is passed to get object
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onPhaseTpEnableDisable: function (oEvent, sObj) {
			let oTpData = {
				"TpointId": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/TpointId"),
				"PhaseId": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/PhaseId"),
				"Weight": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/Weight"),
				"TempId": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/TempId"),
				"SlSnro": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/SlSnro"),
				"SlId": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/SlId"),
				"TchpointGuid": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/TchpointGuid"),
				"StatusId": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/StatusId"),
				"TchpntNotes": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/TchpntNotes"),
				"SrvStatusId": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/SrvStatusId")
			};
			this._openEnableDisableDialog(this.getModel("slDefaultModel").getProperty("/TouchPointDetails/Active"),
				this.getModel("slDefaultModel").getProperty("/TouchPointDetails/TpointTitle"),
				oTpData);
		},

		/**
		 * Called when service is enabled or disabled in service view
		 * @param oEvent- oEvent is passed to get state
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onTpEnableDisable: function (oEvent) {
			let sTpName = this.getModel("slDefaultModel").getProperty("/TouchPointDetails/TpointTitle");
			let oTpData = {
				"TpointId": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/TpointId"),
				"PhaseId": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/PhaseId"),
				"Weight": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/Weight"),
				"TempId": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/TempId"),
				"SlSnro": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/SlSnro"),
				"SlId": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/SlId"),
				"TchpointGuid": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/TchpointGuid"),
				"StatusId": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/StatusId"),
				"TchpntNotes": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/TchpntNotes"),
				"SrvStatusId": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/SrvStatusId")
			};
			this._openEnableDisableDialog(this.getModel("slDefaultModel").getProperty("/TouchPointDetails/Active"), sTpName, oTpData);

		},
		/**
		 * Called to open enable or disable confirmation dialog.
		 * @param bState - a flag is passed to check the state of switch,sTpName- tp name passed to display on confirmation pop up,oTpData- tp data passed for the service call
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_openEnableDisableDialog: function (bState, sTpName, oTpData) {
			this.getModel("slDefaultModel").setProperty("/TouchPointDetails/EnableDisableTp", sTpName);
			this.oTpData = {
				"TpointId": oTpData.TpointId,
				"PhaseId": oTpData.PhaseId,
				"Weight": oTpData.Weight,
				"TempId": oTpData.TempId,
				"SlSnro": oTpData.SlSnro,
				"SlId": oTpData.SlId,
				"TchpointGuid": oTpData.TchpointGuid
			};
			this.oTpData1 = {
				"TpointId": oTpData.TpointId,
				"PhaseId": oTpData.PhaseId,
				"Weight": oTpData.Weight,
				"TempId": oTpData.TempId,
				"SlSnro": oTpData.SlSnro,
				"SlId": oTpData.SlId,
				"Active": !bState,
				"TchpointGuid": oTpData.TchpointGuid,
				"StatusId": oTpData.StatusId,
				"TchpntNotes": oTpData.TchpntNotes,
				"SrvStatusId": oTpData.SrvStatusId
			};

			if (!bState) {
				if (!this.enableTPDialog) {
					this.enableTPDialog = sap.ui.xmlfragment(this.getView().getId(),
						"com.presalescentral.successline.fragments.EnableTouchpoint",
						this);
					this.getView().addDependent(this.enableTPDialog);
				}
				this.enableTPDialog.open();

			} else {
				if (!this.disableTPDialog) {
					this.disableTPDialog = sap.ui.xmlfragment(this.getView().getId(),
						"com.presalescentral.successline.fragments.DisableTouchpoint",
						this);
					this.getView().addDependent(this.disableTPDialog);
				}
				this.disableTPDialog.open();
			}
		},
		/**
		 * Callled to Disable Service.
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleDisableTp: function () {
			this.disableTPDialog.close();
			SLService.onDisableTP(this.oTpData, this.oTpData1).then((oData) => {
				this.refreshSL();
			});
		},
		/**
		 * Called to Enable service.
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleEnableTp: function () {
			this.enableTPDialog.close();
			SLService.onDisableTP(this.oTpData, this.oTpData1).then((oData) => {
				this.refreshSL();
			});
		},
		/**
		 * Closes Disable service dialog.
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onCloseDisableTp: function () {
			this.disableTPDialog.close();
			this.byId(this.sSwitchId).setState(!this.byId(this.sSwitchId).getState());
		},
		/**
		 * Closes Enable service dialog.
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onCloseEnableTp: function () {
			this.enableTPDialog.close();
			this.byId(this.sSwitchId).setState(!this.byId(this.sSwitchId).getState());
		},
		/**
		 * Called to add a new activity to service.
		 * @param oEvent-oEvent is passed to get actvt data
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		/*handleAddActivitytoTp: function (oEvent) {
			var that = this;
			this.SlDetailModel.setProperty("/isActvtPressed", false);
			const sSelectedActvt = oEvent.getSource().getBindingContext("slDefaultModel").getProperty("ActvtTypeID");
			var oActvt = {
				"TpointId": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/TpointId"),
				"PhaseId": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/PhaseId"),
				"TempId": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/TempId"),
				"SlSnro": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/SlSnro"),
				"SlId": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/SlId"),
				"ActGuid": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/ActGuid"),
				"ActivityId": sSelectedActvt,
				"RoleMpngID": oEvent.getSource().getBindingContext("slDefaultModel").getProperty("RoleMpngID"),
				"frmlayout_id": oEvent.getSource().getBindingContext("slDefaultModel").getProperty("FormLayoutID"),
				"source": oEvent.getSource().getBindingContext("slDefaultModel").getProperty("SourceId"),
				"SubTitle": oEvent.getSource().getBindingContext("slDefaultModel").getProperty("SubTitle"),
				"tchpoint_guid": this.getModel("slDefaultModel").getProperty("/TouchPointDetails/TchpointGuid")
			};
			that.addActivityDialog.close();
			SLService.postActivity(oActvt).then((oData) => {
				that.getModel("slDefaultModel").setProperty("/TouchPointDetails/isActListBusy", true);
				oData.data.PhaseName = oData.data.PhaseAbv + "-" + oData.data.PhaseTitle;
				var oActvt = oData.data;
				const oModel = that.getModel("slDefaultModel");
				const oSuccessLine = oModel.getProperty("/SuccessLine");
				const aTouchPoints = oSuccessLine.TouchPoints;
				var selectedTouchPoint = aTouchPoints.filter((item) => {
					return (item.TpointId === oActvt.TpointId && item.PhaseId === oActvt.PhaseId);
				});
				SLService.getWrapperDetails(oActvt.ActivityId, oActvt.ActGuid).then((wrpData) => {
					this.SlDetailModel.setProperty("/isActvtPressed", true);
					let aActvts = that.getModel("slDefaultModel").getProperty("/SuccessLine/Activities");
					that.getModel("slDefaultModel").setProperty("/TouchPointDetails/isActListBusy", false);
					oActvt.to_slwrapper = wrpData.data;
					if (wrpData.data.results[0].ActGuid) {
						this.SlActGuid = wrpData.data.results[0].ActGuid;
					}
					oActvt.isDescriptionEditable = false;
					oActvt.isOutcomesEditale = false;
					oActvt.isNoteEditable = false;
					selectedTouchPoint[0].Activities.push(oActvt);
					selectedTouchPoint[0].TpActvtCount = selectedTouchPoint[0].Activities.length;
					aActvts.push(oActvt);
					that.getModel("slDefaultModel").setProperty("/SuccessLine/TotalActCount", aActvts.length);
					var oNavParams = {
						PhaseId: oActvt.PhaseId,
						TpointId: oActvt.TpointId,
						TchpointGuid: oActvt.TchpointGuid
					};
					this.tpDetailStorage.put("oTpDetails", oNavParams);
					//that._getActivityRoleData();
					that.refreshSL();
				});
				//	that.getModel("slDefaultModel").refresh(true);
			});
		},*/

		handleAddActivitytoTp: async function (oEvent) {
			const oAppSettingModel = this.getOwnerComponent().getModel("appSettings");
			const oModel = this.getModel("slDefaultModel");
			this.SlDetailModel.setProperty("/isActvtPressed", false);
			const oSource = oEvent.getSource();
			const oContext = oSource.getBindingContext("slDefaultModel");
			const oTPDetails = oModel.getProperty("/TouchPointDetails") || {};
			const {
				TpointId = "",
				PhaseId = "",
				TempId = "",
				SlSnro = "",
				SlId = "",
				ActGuid,
				TchpointGuid
			} = oTPDetails;

			const oTpActivityPayload = {
				TpointId,
				PhaseId,
				TempId,
				SlSnro,
				SlId,
				ActGuid,
				tchpoint_guid: TchpointGuid,
				ActivityId: oContext.getProperty("ActvtTypeID") || "",
				RoleMpngID: oContext.getProperty("RoleMpngID") || "",
				frmlayout_id: oContext.getProperty("FormLayoutID") || "",
				source: oContext.getProperty("SourceId") || "",
				SubTitle: oContext.getProperty("SubTitle") || ""
			};
			this.addActivityDialog.close();
			try {
				oModel.setProperty("/TouchPointDetails/isActListBusy", true);
				oAppSettingModel.setProperty("/isAppBusy", true);
				const oData = await SLService.postActivity(oTpActivityPayload);
				const oActvtData = oData?.data;
				oActvtData.PhaseName = `${oActvtData.PhaseAbv}-${oActvtData.PhaseTitle}`;
				oActvtData.isDescriptionEditable = false;
				oActvtData.isOutcomesEditale = false;
				oActvtData.isNoteEditable = false;

				// TouchPoints & Activities
				const oSuccessLine = oModel.getProperty("/SuccessLine") || {};
				const aTouchPoints = oSuccessLine.TouchPoints || [];
				const aActivities = oSuccessLine.Activities || [];

				// Find selected TouchPoint
				const oSelectedTP = aTouchPoints.find(tp =>
					tp.TpointId === oActvtData.TpointId &&
					tp.PhaseId === oActvtData.PhaseId
				);

				// Get wrapper details
				const wrprData = await SLService.getWrapperDetails(oActvtData.ActivityId, oActvtData.ActGuid);
				this.SlDetailModel.setProperty("/isActvtPressed", true);
				oActvtData.to_slwrapper = wrprData.data;
				const sActGuid = wrprData?.data?.results?.[0]?.ActGuid;
				if (sActGuid) this.SlActGuid = sActGuid;

				if (oSelectedTP) {
					oSelectedTP.Activities.push(oActvtData);
					oSelectedTP.TpActvtCount = oSelectedTP.Activities.length;
				}

				aActivities.push(oActvtData);
				oModel.setProperty("/SuccessLine/TotalActCount", aActivities.length);

				// Clear temp storage
				this.tpDetailStorage.put("oTpDetails", null);

				// Refresh SL
				this.refreshSL();

				oModel.setProperty("/TouchPointDetails/isActListBusy", false);

			} catch (error) {
				// Handle errors and reset busy state
				oAppSettingModel.setProperty("/isAppBusy", false);
				oModel.setProperty("/TouchPointDetails/isActListBusy", false);
				console.error("Failed to add activity to the Touchpoint:", error);
			}
		},

		/**
		 * Called to edit Notes.
		 * @param oEvent-oEvent is passed to get object
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onEditNotes: function (sObj) {
			this._handleEditNotesVisibility(sObj.ActGuid, true);
		},
		/**
		 * Handles Notes visiblity.
		 * @param actGuid - actvt guid is passed to filter activity,isVisible- a flag to determine visibility of notes, sUpdatedNotes- notes is passed to update in activities
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_handleEditNotesVisibility: function (actGuid, isVisible, sUpdatedNotes) {
			let aActvts = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails");
			aActvts.isNoteEditable = isVisible;
			if (sUpdatedNotes) {
				aActvts.note = sUpdatedNotes;
			}
			let aTpActvts = this.getModel("slDefaultModel").getProperty("/TouchPointDetails/Activities");
			$.each(aTpActvts, function (index, actvt) {
				if (actGuid === actvt.ActGuid) {
					actvt.isNoteEditable = isVisible;
					if (sUpdatedNotes) {
						actvt.note = sUpdatedNotes;
					}
				}
			});
			this.getView().getModel("slDefaultModel").refresh(true);
			this.setRiskColor(aActvts.RiskDesc, 100);
		},

		/**
		 * Handles Validation for notes and on close notes is displayed in non edit mode.
		 * @param oEvent-oEvent is passed to get object
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleCloseNote: function (oEvent) {
			var that = this;
			const oActvt = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails");
			const oWrapper = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails/to_slwrapper/results");
			if (oWrapper && oWrapper.length > 0 && (oWrapper[0].Notes !== "" || that.oStoreWarppr.Notes !== "")) {
				if (oWrapper[0].Notes === that.oStoreWarppr.Notes) {
					this._handleEditNotesVisibility(oActvt.ActGuid, false);
				} else {
					let aTpActvts = this.getModel("slDefaultModel").getProperty("/TouchPointDetails/Activities");
					$.each(aTpActvts, function (index, actvt) {
						if (oActvt.ActGuid === actvt.ActGuid) {
							actvt.to_slwrapper.results[0].Notes = that.oStoreWarppr.Notes;
						}
					});
					that.getModel("slDefaultModel").refresh();
					if (that.oStoreWarppr.Notes !== '') {
						this._handleEditNotesVisibility(oActvt.ActGuid, false);
					}
				}
			} else {
				this._handleEditNotesVisibility(oActvt.ActGuid, false);
			}
		},

		/**
		 * Updates notes to activity.
		 * @param- oEvent is passed to get wrapper details
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleUpdateNote: function (oEvent) {
			var that = this;
			const oWrapper = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails/to_slwrapper/results/0");
			if (oWrapper && oWrapper.Notes.trim() !== "") {
				this.oNotes = {
					"ActGuid": oWrapper.ActGuid,
					"SlId": oWrapper.SlId,
					"SlSnro": oWrapper.SlSnro,
					"PhaseId": oWrapper.PhaseId,
					"TpointId": oWrapper.TpointId,
					"ActivityId": oWrapper.ActivityId,
					"ActivityTitle": oWrapper.ActivityTitle,
					"WrpDescription": oWrapper.WrpDescription,
					"DaysToPrepare": oWrapper.DaysToPrepare,
					"DaysToExecute": oWrapper.DaysToExecute,
					"Deliverables": oWrapper.Deliverables,
					"Outcomes": oWrapper.Outcomes,
					"activity_id": oWrapper.activity_id,
					"Notes": oWrapper.Notes,
					"Registered": oWrapper.Registered,
					"Weight": oWrapper.Weight,
					"SubTitle": oWrapper.SubTitle
				};
				SLService.updateWrapperData(this.oNotes).then((oData) => {
					MessageToast.show("Notes Updated");
					this._handleEditNotesVisibility(that.oNotes.ActGuid, false, that.oNotes.Notes);
					this.oStoreWarppr = jQuery.extend(true, {}, this.oNotes);
				});
			} else {
				MessageToast.show("Enter Notes");
			}
		},

		/**
		 * Appending 0's to reorder weight.
		 * @param number-number is passed to append zero's,length - length is passed to check no of zero's to append
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		padWithZeroes: function (number, length) {
			var myString = "" + number;
			if (myString.length === 1) {
				myString = "00" + myString;
			} else if (myString.length === 2) {
				myString = "0" + myString;
			}
			return myString;
		},

		/**
		 * Called when activity is removed or canceled from service. When Removed the activity is deleted from list and when cancelled it navigates to activity form to cancel activity registration.
		 * @param- oEvent is passed to get object
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onRemoveActvt: function (oEvent) {
			let sActvtAction = oEvent.getSource().getCustomData()[0].getValue();
			if (sActvtAction === "REMOVE") {
				this.oSelectedActvt = oEvent.getSource().getBindingContext("slDefaultModel").getObject();
				if (oEvent.getSource().getText() === "Remove") {
					let sSelectedActvtTitle = this.oSelectedActvt.Title;
					this.getModel("slDefaultModel").setProperty("/TouchPointDetails/SelectedActvtTitle", sSelectedActvtTitle);
					if (!this.removeActvtDialog) {
						this.removeActvtDialog = sap.ui.xmlfragment(this.getView().getId(),
							"com.presalescentral.successline.fragments.RemoveActivity",
							this);
						this.getView().addDependent(this.removeActvtDialog);
					}
					this.removeActvtDialog.open();
				}
			} else if (sActvtAction === "CANCEL") {
				var oNavParams = {
					PhaseId: oEvent.getSource().getBindingContext("slDefaultModel").getProperty("PhaseId"),
					TpointId: oEvent.getSource().getBindingContext("slDefaultModel").getProperty("TpointId"),
					TchpointGuid: oEvent.getSource().getBindingContext("slDefaultModel").getProperty("TchpointGuid")
				};
				this.tpDetailStorage.put("oTpDetails", oNavParams);
				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
				var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
					target: {
						semanticObject: "pcactivityform",
						action: "app"
					},
					params: {
						"ActivityID": parseInt(oEvent.getSource().getBindingContext("slDefaultModel").getProperty("RegisteredActId"))
					}
				})) || ""; // generate the Hash to display a Supplier
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: hash
					}
				});
			}
		},
		/**
		 * Called on Remove activity confirmation.
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleRemoveActvt: function () {
			var that = this;
			SLService.deleteActivity(this.oSelectedActvt).then((oData) => {
				var oNavParams = {
					PhaseId: this.oSelectedActvt.PhaseId,
					TpointId: this.oSelectedActvt.TpointId,
					TchpointGuid: this.oSelectedActvt.TchpointGuid
				};
				this.tpDetailStorage.put("oTpDetails", oNavParams);
				this.refreshSL();
				this.setHierarchyData();
				this.getModel("slDefaultModel").refresh(true);
				this.removeActvtDialog.close();
			});
		},
		/**
		 * Called when Cancel Remove activity is pressed to close the dialog.
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onRemoveActvtCancel: function () {
			this.removeActvtDialog.close();
		},
		/**
		 * Called when activity's are serached in add activity dialog.
		 * @param- oEvent is passed to get search query
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onAddActivitySearch: function (oEvent, sQuery) {
			let searchString = oEvent ? oEvent.getParameter("query") : sQuery;
			if (searchString !== "") {
				var aActDescFilters = new Filter({
					filters: [
						new Filter("ActvtTypeDesc", FilterOperator.Contains, searchString),
						new Filter("SubTitle", FilterOperator.Contains, searchString),
						new Filter("ActivityTypeInfo", FilterOperator.Contains, searchString)
					],
					and: false
				});
				this.byId("addActvtList").getBinding("items").filter([aActDescFilters]);
				this.byId("actTypeId").setSelectedKey("");
			} else {
				this.byId("addActvtList").getBinding("items").filter([]);
			}
		},

		/**
		 * Called when activity searched in activties registered dialog with registration status.
		 * @param- oEvent is passed to get search query
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onActivityRegTblSearch: function (oEvent) {
			var searchString = oEvent.getParameter("query");
			if (searchString !== "") {
				this.getView().byId("actvtRegTbl").getBinding("rows").filter([new Filter("Title", FilterOperator.Contains, searchString)]);
			} else {
				this.getView().byId("actvtRegTbl").getBinding("rows").filter([]);
			}
			this.getView().byId("actvtCombo").removeAllSelectedItems();
			var length = this.getView().byId("actvtRegTbl").getBinding("rows").getLength();
			this.getModel("slDefaultModel").setProperty("/SuccessLineHierarchyVisibleRows", length);

		},
		/**
		 * Handles filtering phases in activities registered dialog.
		 * @param- oEvent is passed to get source
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleActvtChange: function (oEvent) {
			let aFilters = [];
			let items = oEvent.getSource().getSelectedItems();
			for (var i = 0; i < items.length; i++) {
				let text = items[i].getText();
				let filterPhases = new Filter({
					path: "PhaseName",
					operator: sap.ui.model.FilterOperator.Contains,
					value1: text
				});
				aFilters.push(filterPhases);
			}
			if (items.length !== 0) {
				this.getView().byId("actvtRegTbl").getBinding("rows").filter(aFilters);
			} else {
				this.getView().byId("actvtRegTbl").getBinding("rows").filter([]);
			}
			this.getView().byId("actvtSearch").setValue("");
			var length = this.getView().byId("actvtRegTbl").getBinding("rows").getLength();
			this.getModel("slDefaultModel").setProperty("/SuccessLineHierarchyVisibleRows", length);
		},

		/**
		 * Handles filtering on activities registered as user types.
		 *  @param- oEvent is passed to get source
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onSearchActvtLiveChange: function (oEvent) {
			var searchString = oEvent.getParameter("newValue");
			if (searchString === "") {
				this.getView().byId("actvtRegTbl").getBinding("rows").filter([]);
			}
		},

		/**
		 * Opens Comments Dialog
		 *  @param- oEvent is passed to get source
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */

		onCommentsPress: function (oEvent) {
			const oButton = oEvent.getSource();
			if (!this.commentsDialog) {
				Fragment.load({
					name: "com.presalescentral.successline.fragments.Comments",
					controller: this
				}).then(function (oPopover) {
					this.commentsDialog = oPopover;
					this.getView().addDependent(this.commentsDialog);
					this.commentsDialog.openBy(oButton);
				}.bind(this));
			} else {
				this.commentsDialog.openBy(oButton);
			}
		},
		/**
		 * Closes comments dialog
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onCloseCommentsDialog: function () {
			this.commentsDialog.close();

		},
		/**
		 * Opens Activities Registred Dialog.
		 *  @param- oEvent is passed to get source
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleActivityRegistered: function (oEvent) {
			const that = this;
			that.setHierarchyData();
			that.getModel("slDefaultModel").refresh(true);
			let oSource = oEvent.getSource();
			if (!this._activitiesRegPopover) {
				Fragment.load({
					name: "com.presalescentral.successline.fragments.ActivitiesRegistered",
					controller: this
				}).then(function (oPopOver) {
					that._activitiesRegPopover = oPopOver;
					that.getView().addDependent(oPopOver);
					that._activitiesRegPopover.openBy(oSource);
					return oPopOver;

				}.bind(this));
			} else {
				that._activitiesRegPopover.openBy(oSource);
			}

		},
		/**
		 * Closes activities registred dialog.
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onActvtsRegClosePress: function () {
			this.getView().byId("actvtSearch").setValue("");
			this.getView().byId("actvtCombo").removeAllSelectedItems();
			this.getView().byId("actvtRegTbl").getBinding("rows").filter([]);
			this._activitiesRegPopover.close();
			this.getModel("slDefaultModel").refresh(true);
		},
		/**
		 * Opens Team member dteials dialog.
		 *  @param- oEvent is passed to get source
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onTeamMemSelect: function (oEvent) {
			if (!this.slTeamPopOver) {
				this.slTeamPopOver = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.TeamDetails",
					this);
				this.getView().addDependent(this.slTeamPopOver);
			}
			this.slTeamPopOver.openBy(oEvent.getSource());

		},

		/**
		 * Method to open add service dialog
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleAddservicePress: function (sObj) {
			if (!this.addServiceDialog) {
				this.addServiceDialog = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.AddService",
					this);
				this.getView().addDependent(this.addServiceDialog);
			}
			this.addServiceDialog.open();
		},

		/**
		 * Method to close add service dialog
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onAddServiceClose: function () {
			this.addServiceDialog.close();
		},

		/**
		 * Opens Add activity dialog
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleAddActivityPress: function (sObj) {
			if (!this.addActivityDialog) {
				this.addActivityDialog = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.AddActivity",
					this);
				this.getView().addDependent(this.addActivityDialog);
			}
			if (this.isRoleFilterChanged) {
				this.getModel("slDefaultModel").setProperty("/SuccessLine/Source", "001");
				let sDefRole = this.getModel("slDefaultModel").getProperty("/SuccessLine/DefaultRole");
				this.getModel("slDefaultModel").setProperty("/SuccessLine/Role", sDefRole);
				this.getRoleBasedActivityTypes(false);
			}
			this.addActivityDialog.open();
		},
		/**
		 * Closes add activity dialog
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onAddActivityClose: function () {
			this.addActivityDialog.close();
		},

		/**
		 * Called when Comments are posted.
		 * @param- oEvent is passed to get value
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onCommentPost: function (oEvent) {
			let oComment = {
				"SlSnro": this.getModel("slDefaultModel").getProperty("/SuccessLine/SlSnro"),
				"SlId": this.getModel("slDefaultModel").getProperty("/SuccessLine/SlId"),
				"ProjectType": "SLINE",
				"CreatedBy": this.Component.getModel("user").getProperty("/UserId"),
				"CreatedUserName": this.Component.getModel("user").getProperty("/UserName"),
				"CommentDesc": oEvent.getParameter("value"),
				"CreationDate": null,
				"CommentGuid": "00000000-0000-0000-0000-000000000000"
			};
			SLService.postComment(oComment).then((oData) => {
				let oCommentData = oData.data;
				oCommentData.EditActions = [{
					"Text": "Edit",
					"Icon": "sap-icon://edit"
				}, {
					"Text": "Delete",
					"Icon": "sap-icon://delete"
				}];
				const aComments = this.SlDetailModel.getProperty("/Comments");
				this.SlDetailModel.setProperty("/Comments/" + aComments.length, oCommentData);
				this.SlDetailModel.refresh(true);
				MessageToast.show("Comment Posted");
			});
		},
		/**
		 * Called when comment is edited or deleted.
		 * @param- oEvent is passed to get binding context data 
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onActionComment: function (oEvent) {
			let commentData = oEvent.getSource().getParent().getBindingContext("SlDetailModel");
			if (oEvent.getSource().getText().toUpperCase() === "EDIT") {
				this.handleEditComment(oEvent, commentData);
			} else {
				SLService.deleteComment(commentData.getObject()).then((oData) => {
					let sPath = commentData.getPath();
					let index = sPath.split("/")[sPath.split("/").length - 1];
					let aCommentsDataPath = sPath.split("/");
					aCommentsDataPath.pop();
					let aCommentsData = this.SlDetailModel.getProperty(aCommentsDataPath.join("/"));
					aCommentsData.splice(index, 1);
					this.SlDetailModel.setProperty(aCommentsDataPath.join("/"), aCommentsData);
					MessageToast.show("Comment Deleted");
				});
			}
		},
		/**
		 * Opens Edit comment dialog.
		 * @param oEvent- passed to get parent control,commentData- comments data passed to set to model 
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleEditComment: function (oEvent, commentData) {
			let oSource = oEvent.getSource().getParent().getParent();
			if (!this.updateCommentPopover) {
				this.updateCommentPopover = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.EditComment", this);
				this.updateCommentPopover.setModel(new JSONModel());
				this.getView().addDependent(this.updateCommentPopover);
			}
			/*Production bug fix: edit comment*/
			/*this.updateCommentPopover.getModel("slDefaultModel").setData({
				"data": commentData.getObject(),
				"sPath": commentData.getPath()
			});*/
			/*Fix for the production issue: edit comment*/
			this.updateCommentPopover.getModel("slDefaultModel").setProperty("/data", commentData.getObject());

			this.updateCommentPopover.getModel("slDefaultModel").setProperty("/sPath", commentData.getPath());
			this.updateCommentPopover.openBy(oSource);
			this.dataChange = true;
		},
		/**
		 * Called to update comment.
		 * @param- oEvent is passed to get binding context data 
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		updateComment: function (oEvent) {
			let oUpdateData = oEvent.getSource().getModel("slDefaultModel").getProperty("/data");
			var sPath = oEvent.getSource().getModel("slDefaultModel").getProperty("/sPath");
			var oActions = oUpdateData.EditActions;
			let oComment = {
				"SlSnro": this.getModel("slDefaultModel").getProperty("/SuccessLine/SlSnro"),
				"SlId": this.getModel("slDefaultModel").getProperty("/SuccessLine/SlId"),
				"CommentGuid": oUpdateData.CommentGuid,
				"CommentDesc": oEvent.getSource().getValue(),
				"CreatedUserName": this.Component.getModel("user").getProperty("/UserName"),
				"CreatedBy": this.Component.getModel("user").getProperty("/UserId"),
				"CreationDate": null,
				"ProjectType": "SLINE"
			};
			SLService.updateComment(oComment).then((oData) => {
				oData.data.EditActions = oActions;
				this.SlDetailModel.setProperty(sPath, oData.data);
				this.updateCommentPopover.close();
				MessageToast.show("Comment Updated");
			});
		},
		/**
		 * Called to register an activity and navigating to activity form.
		 * @param- oEvent is passed to get binding context data 
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleRegActivity: function (oEvent, sActvt) {
			let that = this;
			var oNavParams = {
				PhaseId: sActvt.PhaseId,
				TpointId: sActvt.TpointId,
				TchpointGuid: sActvt.TchpointGuid
			};
			this.tpDetailStorage.put("oTpDetails", oNavParams);
			let sActvtAction = oEvent.getSource().getCustomData()[0].getValue();
			if (sActvt.ActivityId === "0108") {
				let oSource = oEvent.getSource();
				let statusId = sActvt.StatusId;
				SLService.getSLDetailWrapper(sActvt).then((wrapperData) => {
					let sData = wrapperData.data;
					sActvt.to_slwrapper = sData;
					this.openRapidRegistration(statusId, sActvt, oSource);
					return;
				});
			} else {
				if (sActvtAction === "REG_ACT") {
					let oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
					let hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
						target: {
							semanticObject: "pcactivityform",
							action: "app"
						},
						params: {
							"ActivityTypeID": sActvt.ActivityId,
							"SlGuid": sActvt.ActGuid
						}
					})) || ""; // generate the Hash to display a Supplier
					oCrossAppNavigator.toExternal({
						target: {
							shellHash: hash
						}
					});

				} else {
					var oParam = {
						"ActivityID": parseInt(sActvt.RegisteredActId)
					};
					if (sActvtAction === "REG") { //Already Registered
						oParam.ActivityDetail = true;
					}

					let oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
					let hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
						target: {
							semanticObject: "pcactivityform",
							action: "app"
						},
						params: oParam
					})) || ""; // generate the Hash to display a Supplier
					oCrossAppNavigator.toExternal({
						target: {
							shellHash: hash
						}
					});

				}
			}
		},
		/**
		 * Called when link is pressed to navigate to external link.
		 * @param oEvent- oEvent is passed to get link text
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleLinks: function (oEvent) {
			var url = oEvent.getSource().getBindingContext("slDefaultModel") ? oEvent.getSource().getBindingContext("slDefaultModel").getObject()
				.Link : oEvent.getSource().getHref();
			if (!url.match(/^[a-zA-Z]+:\/\//)) {
				url = 'https://' + url;
			}
			window.open(url, "_blank");

		},
		/**
		 * Called to trigger email in Client app.
		 * @param oEvent- oEvent is passed to get email id
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleSendMailClick: function (oEvent) {
			sap.m.URLHelper.triggerEmail(oEvent.getSource().getBindingContext("slDefaultModel").getProperty("EmailId"));
			sap.git.usage.Reporting.addEvent(this.getOwnerComponent(), "Send Email Event triggered");
		},
		/**
		 * Called to trigger call in client app.
		 * @param oEvent- evt is passed to get mobile number
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleCallClick: function (evt) {
			sap.m.URLHelper.triggerTel(evt.getSource().getBindingContext("slDefaultModel").getProperty("MobileNumber"));
			sap.git.usage.Reporting.addEvent(this.getOwnerComponent(), "Send Email Event triggered");
		},
		/**
		 * Called to expand the wrapper and fetch wrapper details for selected activity.
		 * @param oEvent- oEvent is passed to get id
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleActvtExpand: function (oEvent) {
			let that = this;
			that.getView().getModel("SlDetailModel").setProperty("/RegistrationActvtVisible", false);
			let aIndex = oEvent.getParameter("id").split("-");
			let sIndex = aIndex[aIndex.length - 1];
			let oActvt = oEvent.getSource().getBindingContext("slDefaultModel").getObject();
			that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
			if (oEvent.getParameter("expand")) {
				this.byId("idActList").getItems()[sIndex].getContent()[1].setVisible(false);
				that.getModel("slDefaultModel").setProperty("/TouchPointDetails/isActListBusy", true);
				SLService.getSLDetailWrapper(oActvt).then((wrapperData) => {
					let activities = this.getModel("slDefaultModel").getProperty("/SuccessLine/Activities");
					for (var i = 0; i < activities.length; i++) {
						if (wrapperData.data.results[0].ActGuid === activities[i].ActGuid) {
							activities[i].to_slwrapper = wrapperData.data;
							if (activities[i].to_slwrapper && activities[i].to_slwrapper.results.length > 0) {
								that.oStoreWarppr = jQuery.extend(true, {}, activities[i].to_slwrapper.results[0]);
								that.oStoreWrprFields = jQuery.extend(true, {}, activities[i].to_slwrapper.results[0]);
							}
						}
					}
					let aWrprAttchmnts = wrapperData.data.results[0].to_wrpdoc.results;
					aWrprAttchmnts.filter((item, index) => {
						item.AddRemove = "";
						if (index === aWrprAttchmnts.length - 1) {
							item.AddRemove = "X";
						}
					});
					that.SlDetailModel.setProperty("/WrprAttachments", aWrprAttchmnts);
					this.getModel("slDefaultModel").setProperty("/TouchPointDetails/isActListBusy", false);
					if (wrapperData.data.results[0].RegActId !== '') {
						that.getView().getModel("SlDetailModel").setProperty("/RegistrationActvtVisible", true);
					} else {
						that.getView().getModel("SlDetailModel").setProperty("/RegistrationActvtVisible", false);
					}
					that.getView().getModel("SlDetailModel").setProperty("/RapidRegActivityTeamMembers", wrapperData.data.results[0].to_team.results);
					that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
				});
			} else {
				that.getView().getModel("SlDetailModel").setProperty("/RegistrationActvtVisible", false);
				this.getView().getModel("SlDetailModel").setProperty("/RapidRegActivityTeamMembers", {});
				this.byId("idActList").getItems()[sIndex].getContent()[1].setVisible(true);
				that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
			}
		},

		/**
		 * Open's user details in new tab
		 * @param oEvent- oEvent is passed to get user id
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onViewDetails: function (oEvent) {
			const sUserId = oEvent.getSource().getBindingContext("slDefaultModel").getProperty("UserId");
			window.open(this.ConstantsMap["0071"].field_value + sUserId);
		},
		/**
		 * Opens user info.
		 * @param oEvent- oEvent is passed to get user id
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleAccountPress: function (oEvent) {
			const sUserId = oEvent.getSource().getBindingContext("slDefaultModel").getProperty("UserId");
			window.open(this.ConstantsMap["0185"].field_value + sUserId);
		},
		/**
		 * Opens account info in harmony.
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		navToCRM: function () {
			let sAccountId = this.getModel("slDefaultModel").getProperty("/SuccessLine/AccountId") ? this.getModel("slDefaultModel").getProperty(
				"/SuccessLine/AccountId") :
				this.SlDetailModel.getProperty("/SelectedOpportunity/ACCOUNT");
			if (sAccountId && sAccountId !== "NA") {
				// this.ConstantsMap["0069"]
				window.open(this.ConstantsMap["0185"].field_value + sAccountId, "_blank");
			}
		},

		navToCRMAddOpps: function (oEvent) {
			var oContext = oEvent.getSource().getBindingContext("SlDetailModel");
			var sOppId = "";
			if (oContext) {
				sOppId = oContext.getProperty("OPP_ID");
			}
			if (sOppId) {
				// this.ConstantsMap["0068"]
				window.open(this.ConstantsMap["0183"].field_value + sOppId, "_blank");
			}
		},
		/**
		 * Navigaes to IT direct or translation service.
		 * @param oEvent- oEvent is passed to get selectedkey
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */

		handleCreateService: function (oEvent) {
			let sSelectedKey = oEvent.getSource().getSelectedKey();
			if (sSelectedKey === "0002") {
				let sOppId = this.getModel("slDefaultModel").getProperty("/SuccessLine/opportunityId");
				if (sOppId) {
					let oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
					let hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
						target: {
							semanticObject: "pctranslationform",
							action: "app"
						},
						params: {
							"OpportunityId": sOppId
						}
					})) || ""; // generate the Hash to display a Supplier
					oCrossAppNavigator.toExternal({
						target: {
							shellHash: hash
						}
					});
				} else {
					let oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
					let hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
						target: {
							semanticObject: "pctranslationform",
							action: "app"
						},

					})) || ""; // generate the Hash to display a Supplier
					oCrossAppNavigator.toExternal({
						target: {
							shellHash: hash
						}
					});
				}

			} else {
				window.open(this.ConstantsMap["0075"].field_value);
			}

		},
		/**
		 * Fetch's Industry, Role, Opportunity comments data.
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_getOppTeam: function (sOppId) {
			var that = this;
			this.RoleMap = {};
			// let sOppId = this.getModel("slDefaultModel").getProperty("/SuccessLine/OpportunityId") || sOppId;
			if (sOppId) {
				OppService._getOpportunitiesTeam(sOppId,
					"SALES_ORG_TEXT,OPPT_ID,ACCOUNT_NAME,ACCOUNT,DESCRIPTION,OWNER,OWNER_NAME,STATUS,CURR_PHASE,INDUSTRY_MASTERCODE,INDUSTRY,INDUSTRY_MASTERCODE_TEXT,INDURSTRY_TEXT,PartiesInvolved,Notes,Items"
				).then((oData) => {
					var oResponse = oData.data;
					//Rapid Registration - Opportunity data
					that.SlDetailModel.setProperty("/SelectedOpportunity/opportunity", oResponse);
					that.SlDetailModel.setProperty("/SelectedOpportunity/INDUSTRY", oResponse.INDUSTRY_MASTERCODE_TEXT);
					that.SlDetailModel.setProperty("/SelectedOpportunity/SALES_ORG_TEXT", oResponse.SALES_ORG_TEXT);
					$.each(oResponse.PartiesInvolved.results, function (index, user) {
						that.RoleMap[user.ROLE] = user.ROLE_DESCR;
					});
					$.each(that.getModel("slDefaultModel").getProperty("/SuccessLine/Team"), function (index, slteam) {
						if (slteam.Role) {
							slteam.ROLE_DESC = that.RoleMap[slteam.Role];
						} else {
							slteam.ROLE_DESC = "NA";
						}
					});
					if (oResponse.Notes.results.length > 1) {
						$.each(oResponse.Notes.results, function (index, note) {
							if (note.TDID === "ZO17") {
								that.getModel("slDefaultModel").setProperty("/SuccessLine/OppComments", note.CONC_LINES);
							}
						});
					} else {
						that.getModel("slDefaultModel").setProperty("/SuccessLine/OppComments", "NA");
					}
					that.getView().getModel("formModel").setProperty("/SelectedUsers", oResponse.PartiesInvolved.results);
					let selectedUser = that.getView().getModel("formModel").getProperty("/SelectedUsers");
					let arr = [];
					let aSelectedUser = [];
					for (var i = 0; i < selectedUser.length; i++) {
						if (selectedUser[i].USER_ID && selectedUser[i].EMAIL) {
							selectedUser[i].checked = true;
							let team = {
								"SlId": that.getModel("slDefaultModel").getProperty("/SuccessLine/SlId"),
								"Role": selectedUser[i].ROLE,
								"UserId": selectedUser[i].USER_ID,
								"FullName": selectedUser[i].NAME,
								"PhoneNumber": selectedUser[i].TELEPHONE_NUMBER,
								"MobileNumber": selectedUser[i].MOBILE_NUMBER,
								"EmailId": selectedUser[i].EMAIL,
								"checked": false
							};
							arr.push(team);
							aSelectedUser.push(selectedUser[i]);
						}
					}
					that.getView().getModel("formModel").setProperty("/SelectTeam", arr);
					that.getView().getModel("formModel").setProperty("/SelectedUsers", aSelectedUser);
					that.getView().getModel("formModel").refresh(true);
					that.fnFormOpportunityMaterials(oResponse);
				});
			}

		},
		/**
		 * Handles scroll to phase and to set selected pahse.
		 * @param oEvent- passed oEvent to get custom data value
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleNavToPhase: function (oEvent) {
			let sPhaseId = oEvent.getSource().getCustomData()[0].getValue();
			this._setPhaseDetails(sPhaseId);
		},
		/**
		 * Navigates to Opportunity or Account pressed to harmony page.
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleOpportunityInfoLinkPress: function () {
			if (this.getModel("slDefaultModel").getProperty("/SuccessLine").OpportunityId !== "") {
				let sOppId = this.getModel("slDefaultModel").getProperty("/SuccessLine").OpportunityId;
				if (sOppId) {
					window.open(this.ConstantsMap["0183"].field_value + sOppId, "_blank");
				}
			} else {
				let sAccountId = this.getModel("slDefaultModel").getProperty("/SuccessLine").AccountId;
				if (sAccountId) {
					window.open(this.ConstantsMap["0185"].field_value + sAccountId, "_blank");
				}
			}
		},
		/**
		 * Opens Creator dialog to fetch user details.
		 * @param oEvent- passed oEvent to get source
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onCreatorNamePress: function (oEvent) {
			if (!this.creatorNamePopOver) {
				this.creatorNamePopOver = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.CreatorInfo",
					this);
				this.getView().addDependent(this.creatorNamePopOver);
			}
			this.creatorNamePopOver.openBy(oEvent.getSource());
		},
		/**
		 * Trigger email to creator.
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleSendMailToCreator: function () {
			let sCreatorMail = "";
			this.getModel("slDefaultModel").getProperty("/SuccessLine/Team").filter((item) => {
				if (item.UserId === this.getModel("slDefaultModel").getProperty("/SuccessLine/CreatedBy")) {
					sCreatorMail = item.EmailId;
				}
			});
			sap.m.URLHelper.triggerEmail(sCreatorMail);
			sap.git.usage.Reporting.addEvent(this.getOwnerComponent(), "Send Email Event triggered");
		},
		/**
		 * Trigger call to creator.
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleCallToCreator: function () {
			let sCreatorMobile = "";
			this.getModel("slDefaultModel").getProperty("/SuccessLine/Team").filter((item) => {
				if (item.UserId === this.getModel("slDefaultModel").getProperty("/SuccessLine/CreatedBy")) {
					sCreatorMobile = item.MobileNumber;
				}
			});
			sap.m.URLHelper.triggerTel(sCreatorMobile);
			sap.git.usage.Reporting.addEvent(this.getOwnerComponent(), "Send Email Event triggered");
		},
		/**
		 * Opens creator details in new tab.
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onViewCreatorDetails: function () {
			const sUserId = this.getModel("slDefaultModel").getProperty("/SuccessLine/CreatedBy");
			window.open(this.ConstantsMap["0071"].field_value + sUserId);
		},
		/**
		 * Called when subscribe button is pressed in comments.
		 * @param oEvent- passed oEvent to get parameter
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleSubscribeNotification: function (oEvent) {
			let oNotify = {
				"SlId": this.getModel("slDefaultModel").getProperty("/SuccessLine/SlId"),
				"UserId": this.Component.getModel("user").getProperty("/UserId"),
				"Notify": oEvent.getParameter("pressed")
			};
			SLService.subscribeNotification(oNotify).then((oData) => {
				this.getModel("slDefaultModel").setProperty("/SuccessLine/Notify", oData.data.Notify);

			});

		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleEscape: function (pEscapePending) {
			// Depending on the use case, call pEscapePending.resolve() or pEscapePending.reject() to overwrite the default behavior.

			if (this.enableTPDialog) {
				this.enableTPDialog.close();
			} else if (this.disableTPDialog) {
				this.disableTPDialog.close();
			}
			pEscapePending.resolve();
			this.byId(this.sSwitchId).setState(!this.byId(this.sSwitchId).getState());
		},

		//updates to detali page changes 
		onAttachmentsEdit: function (oEvent) {
			if (!this.attchmntsPopOver) {
				this.attchmntsPopOver = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.SlAttachments",
					this);
				this.getView().addDependent(this.attchmntsPopOver);
			}
			this.attchmntsPopOver.openBy(oEvent.getSource());
			this.attchmntsEvent = oEvent.getSource();
			this.aAttchments = [];
			let aExistAttchmnts = this.SlDetailModel.getProperty("/SlAttachments");
			let aTemp = [];
			aExistAttchmnts.filter((item) => {
				if (item.Active === true) {
					aTemp.push(item);
				}
			});
			if (!aTemp.length) {
				var oNewLink = {
					"Active": true,
					"Link": "",
					"LinkId": "",
					"LinkTitle": "",
					"LinkType": 6,
					"SlSnro": this.getModel("slDefaultModel").getProperty("/SuccessLine/SlSnro"),
					"SlId": this.getModel("slDefaultModel").getProperty("/SuccessLine/SlId"),
					"Status": "X"
				};
				aExistAttchmnts.push(oNewLink);
				this.SlDetailModel.refresh();
			}
			this.aStoreSlAttchmnts = jQuery.extend(true, [], aExistAttchmnts);
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleAddLinkPress: function () {
			let aExistAttchmntData = this.SlDetailModel.getProperty("/SlAttachments");
			var oNewLink = {
				"Active": true,
				"Link": "",
				"LinkId": "",
				"LinkTitle": "",
				"LinkType": 6,
				"SlSnro": this.getModel("slDefaultModel").getProperty("/SuccessLine/SlSnro"),
				"SlId": this.getModel("slDefaultModel").getProperty("/SuccessLine/SlId"),
				"Status": "X",
				"AddRemove": "X"
			};
			let aTemp = [];
			let bIsLinkEmpty = false;
			aExistAttchmntData.filter((item) => {
				if (item.Active === true) {
					aTemp.push(item);
					bIsLinkEmpty = item.Link ? false : true;
				}
			});
			aTemp.filter((item) => {
				if (!item.Link) {
					bIsLinkEmpty = true;
					return;
				}
			});
			if (aTemp.length < 5) {
				if (!bIsLinkEmpty) {
					aExistAttchmntData.filter((item) => {
						item.Status = "";
						item.AddRemove = "";
					});
					aExistAttchmntData.push(oNewLink);
					this.SlDetailModel.setProperty("/SlAttachments", aExistAttchmntData);
				} else {
					let bErrors = this._validateEmptyLinks("idSlAttchmnts");
					if (bErrors) {
						return false;
					}
				}

			} else {
				MessageToast.show("You can add a maximum of five(5) attachment links.");
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleRemoveLink: function (oEvent) {
			let bSaveTrigger = false;
			let aAttchmnts = this.SlDetailModel.getProperty("/SlAttachments");
			aAttchmnts.filter((item) => {
				if (item.Active === true) {
					bSaveTrigger = item.LinkId ? true : false;
				}
			});
			var aIndex = oEvent.getParameter("id").split("-");
			var sIndex = aIndex[aIndex.length - 1];
			this.SlDetailModel.setProperty("/SlAttachments" + "/" + sIndex + "/Active", false);
			let aTemp = [];
			aAttchmnts.filter((item) => {
				if (item.Active === true) {
					aTemp.push(item);
				}
			});
			if (aTemp.length) {
				aTemp[aTemp.length - 1].AddRemove = "X";
			}

			this.SlDetailModel.refresh();
			if (aTemp.length === 0 && bSaveTrigger) {
				this.onSaveAttachments();
			} else {
				if (aTemp.length === 0) {
					this.attchmntsPopOver.close();
				}
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onSaveAttachments: function () {
			let bErrors = this._validateEmptyLinks("idSlAttchmnts");
			if (!bErrors) {
				this.SlDetailModel.setProperty("/isSlAttchmntBusy", true);
				let aTemp = this.SlDetailModel.getProperty("/SlAttachments");
				aTemp.filter((item) => {
					delete item.AddRemove;
				});
				SLService.updateAttachments(aTemp).then((oData) => {
					this.SlDetailModel.setProperty("/isSlAttchmntBusy", false);
					let aAttchmnts = [];
					oData.filter((item, index) => {
						item.data.AddRemove = "";
						aAttchmnts.push(item.data);
					});
					let aActiveLinks = [];
					aAttchmnts.filter((item, index) => {
						if (item.Active === true) {
							aActiveLinks.push(item);
						}
					});
					if (aActiveLinks.length) {
						aActiveLinks[aActiveLinks.length - 1].AddRemove = "X";
					}
					this.SlDetailModel.setProperty("/SlAttachments", aAttchmnts);
					this.getModel("slDefaultModel").setProperty("/SuccessLine/DisplayStoryLinks", aAttchmnts);
					this.aStoreSlAttchmnts = jQuery.extend(true, [], aAttchmnts);
					this.attchmntsPopOver.close();
				});
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onAttchmntCancel: function () {
			this.byId("idSlAttchmnts").getItems().filter((value, index) => {
				var link = value.getItems()[1];
				var displayName = value.getItems()[0];
				displayName.setValueState("None");
				link.setValueState("None");
			});
			this.attchmntsPopOver.close();
			this.SlDetailModel.setProperty("/SlAttachments", this.aStoreSlAttchmnts);
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleUpdateWrpDescription: function (oEvent) {
			const oWrapper = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails/to_slwrapper/results/0");
			if (oWrapper && oWrapper.WrpDescription.trim() !== "") {
				this.oWrpDescrptn = {
					"ActGuid": oWrapper.ActGuid,
					"SlId": oWrapper.SlId,
					"SlSnro": oWrapper.SlSnro,
					"PhaseId": oWrapper.PhaseId,
					"TpointId": oWrapper.TpointId,
					"ActivityId": oWrapper.ActivityId,
					"ActivityTitle": oWrapper.ActivityTitle,
					"WrpDescription": oWrapper.WrpDescription,
					"DaysToPrepare": oWrapper.DaysToPrepare,
					"DaysToExecute": oWrapper.DaysToExecute,
					"Deliverables": oWrapper.Deliverables,
					"Outcomes": oWrapper.Outcomes,
					"activity_id": oWrapper.activity_id,
					"Notes": oWrapper.Notes,
					"Registered": oWrapper.Registered,
					"Weight": oWrapper.Weight,
					"SubTitle": oWrapper.SubTitle
				};
				SLService.updateWrapperData(this.oWrpDescrptn).then((oData) => {
					MessageToast.show("Description Updated");
					this._handleWrprFieldsVisibility(this.oWrpDescrptn.ActGuid, "DESC", false, this.oWrpDescrptn.WrpDescription);
					this.oStoreWrprFields = jQuery.extend(true, {}, this.oWrpDescrptn);
				});
			} else {
				MessageToast.show("Enter Description");
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onWrprDescEdit: function (oEvent) {
			let oActvt = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails");
			this._handleWrprFieldsVisibility(oActvt.ActGuid, "DESC", true);
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleCloseWrpDescription: function (oEvent) {
			var that = this;
			const oActvt = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails");
			const oWrapper = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails/to_slwrapper/results");
			if (oWrapper && oWrapper.length > 0 && (oWrapper[0].WrpDescription !== "" || that.oStoreWrprFields.WrpDescription !== "")) {
				if (oWrapper[0].WrpDescription === that.oStoreWrprFields.WrpDescription) {
					this._handleWrprFieldsVisibility(oActvt.ActGuid, "DESC", false);
				} else {
					oActvt.to_slwrapper.results[0].WrpDescription = that.oStoreWrprFields.WrpDescription;
					if (that.oStoreWrprFields.WrpDescription !== '') {
						this._handleWrprFieldsVisibility(oActvt.ActGuid, "DESC", false);
					}
				}
			} else {
				MessageToast.show("Enter Description");
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleUpdateOutcomeDlvrbles: function (oEvent) {
			const oWrapper = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails/to_slwrapper/results/0");
			if (oWrapper && oWrapper.Outcomes.trim() !== "") {
				this.oWrpOutcomDlvrbls = {
					"ActGuid": oWrapper.ActGuid,
					"SlId": oWrapper.SlId,
					"SlSnro": oWrapper.SlSnro,
					"PhaseId": oWrapper.PhaseId,
					"TpointId": oWrapper.TpointId,
					"ActivityId": oWrapper.ActivityId,
					"ActivityTitle": oWrapper.ActivityTitle,
					"WrpDescription": oWrapper.WrpDescription,
					"DaysToPrepare": oWrapper.DaysToPrepare,
					"DaysToExecute": oWrapper.DaysToExecute,
					"Deliverables": oWrapper.Deliverables,
					"Outcomes": oWrapper.Outcomes,
					"activity_id": oWrapper.activity_id,
					"Notes": oWrapper.Notes,
					"Registered": oWrapper.Registered,
					"Weight": oWrapper.Weight,
					"SubTitle": oWrapper.SubTitle
				};
				SLService.updateWrapperData(this.oWrpOutcomDlvrbls).then((oData) => {
					MessageToast.show("Outcomes/Deliverables Updated");
					this._handleWrprFieldsVisibility(this.oWrpOutcomDlvrbls.ActGuid, "OUTCOM", false, this.oWrpOutcomDlvrbls.Outcomes);
					this.oStoreWrprFields = jQuery.extend(true, {}, this.oWrpOutcomDlvrbls);
				});
			} else {
				MessageToast.show("Enter Outcomes/Deliverables");
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onWrprOutcomeDlvrblesEdit: function (oEvent) {
			let oActvt = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails");
			this._handleWrprFieldsVisibility(oActvt.ActGuid, "OUTCOM", true);
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleCloseOutcomeDlvrbles: function (oEvent) {
			var that = this;
			const oActvt = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails");
			const oWrapper = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails/to_slwrapper/results");
			if (oWrapper && oWrapper.length > 0 && (oWrapper[0].Outcomes !== "" || that.oStoreWrprFields.Outcomes !== "")) {
				if (oWrapper[0].Outcomes === that.oStoreWrprFields.Outcomes) {
					this._handleWrprFieldsVisibility(oActvt.ActGuid, "OUTCOM", false);
				} else {
					oActvt.to_slwrapper.results[0].Outcomes = that.oStoreWrprFields.Outcomes;
					this.getView().getModel("slDefaultModel").refresh(true);

					if (that.oStoreWrprFields.Outcomes !== '') {
						this._handleWrprFieldsVisibility(oActvt.ActGuid, "OUTCOM", false);
					}
				}
			} else {
				MessageToast.show("Enter Outcomes/Deliverables");
			}

		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_handleWrprFieldsVisibility: function (sActGuid, sProperty, flag, sUpdatedValue) {
			this.sProp = sProperty;
			let aActvts = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails");
			if (this.sProp === "DESC") {
				aActvts.isDescriptionEditable = flag;
				if (sUpdatedValue) {
					aActvts.WrpDescription = sUpdatedValue;
				}
			} else if (this.sProp === "OUTCOM") {
				aActvts.isOutcomesEditale = flag;
				if (sUpdatedValue) {
					aActvts.Outcomes = sUpdatedValue;
				}
			} else {
				aActvts.isRiskEditable = flag;
			}
			this.getView().getModel("slDefaultModel").refresh(true);
			let sRiskDesc = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails/RiskDesc");
			this.setRiskColor(sRiskDesc, 100);
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onWrprAttachmentsEdit: function (oEvent) {
			if (!this.wrprAttchmntsPopOver) {
				this.wrprAttchmntsPopOver = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.WrprAttachments",
					this);
				this.getView().addDependent(this.wrprAttchmntsPopOver);
			}
			this.wrprAttchmntsPopOver.openBy(oEvent.getSource());
			let oActvt = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails");
			let aWrprAttchmnts = oActvt.to_slwrapper.results[0].to_wrpdoc.results;
			aWrprAttchmnts.filter((item, index) => {
				item.Status = "";
				if (index === aWrprAttchmnts.length - 1) {
					item.Status = "X";
				}
			});
			this.SlDetailModel.setProperty("/WrprAttachments", aWrprAttchmnts);
			let aActiveLinks = [];
			aWrprAttchmnts.filter((item) => {
				if (item.Active === true) {
					aActiveLinks.push(item);
				}
			});
			if (!aActiveLinks.length) {
				var oNewLink = {
					"ActGuid": oActvt.ActGuid,
					"ActivityId": oActvt.ActivityId,
					"LinkTypeDesc": "",
					"LinkTypeId": 4,
					"PhaseId": oActvt.PhaseId,
					"TpointId": oActvt.TpointId,
					"Active": true,
					"Link": "",
					"LinkId": "",
					"LinkTitle": "",
					"SlSnro": oActvt.SlSnro,
					"SlId": oActvt.SlId,
					"Status": "X"
				};
				aWrprAttchmnts.push(oNewLink);
				this.SlDetailModel.setProperty("/WrprAttachments", aWrprAttchmnts);
			}
			this.aStoreWrprAttchmnts = jQuery.extend(true, [], aWrprAttchmnts);
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleWrprAddLinkPress: function (oEvent) {
			var aExistWrprLinks = this.SlDetailModel.getProperty("/WrprAttachments");
			let oActvt = oEvent.getSource().getBindingContext("SlDetailModel").getObject();
			var oNewLink = {
				"ActGuid": oActvt.ActGuid,
				"ActivityId": oActvt.ActivityId,
				"LinkTypeDesc": "",
				"LinkTypeId": 4,
				"PhaseId": oActvt.PhaseId,
				"TpointId": oActvt.TpointId,
				"Active": true,
				"Link": "",
				"LinkId": "",
				"LinkTitle": "",
				"SlSnro": oActvt.SlSnro,
				"SlId": oActvt.SlId,
				"Status": "X",
				"AddRemove": "X"
			};
			let aTemp = [];
			let bIsWrprLinkEmpty = false;
			aExistWrprLinks.filter((item) => {
				if (item.Active === true) {
					aTemp.push(item);
				}
			});
			aTemp.filter((item) => {
				if (!item.Link) {
					bIsWrprLinkEmpty = true;
					return;
				}
			});
			// if (aTemp.length < 5) {
			if (!bIsWrprLinkEmpty) {
				aExistWrprLinks.filter((item) => {
					item.Status = "";
					item.AddRemove = "";
				});
				aExistWrprLinks.push(oNewLink);
				this.SlDetailModel.refresh();
			} else {
				let bErrors = this._validateEmptyLinks("idWrprAttchmnts");
				if (bErrors) {
					return false;
				}
			}
			// } else {
			// 	MessageToast.show("You can add up to 5 links only");
			// }
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleRemoveWrprLink: function (oEvent) {
			let bSaveTrigger = false;
			let aAttchmnts = this.SlDetailModel.getProperty("/WrprAttachments");
			aAttchmnts.filter((item) => {
				if (item.Active === true) {
					bSaveTrigger = item.LinkId ? true : false;
				}
			});
			var aIndex = oEvent.getParameter("id").split("-");
			var sIndex = aIndex[aIndex.length - 1];
			this.SlDetailModel.setProperty("/WrprAttachments" + "/" + sIndex + "/Active", false);
			let aTemp = [];
			aAttchmnts.filter((item) => {
				if (item.Active === true) {
					aTemp.push(item);
				}
			});
			if (aTemp.length) {
				aTemp[aTemp.length - 1].AddRemove = "X";
			}
			this.removeLinkFromAttachments(oEvent);
			//
			this.SlDetailModel.refresh();
			if (aTemp.length === 0 && bSaveTrigger) {
				this.onSaveWrprAttachments();
			} else {
				if (aTemp.length === 0) {
					this.wrprAttchmntsPopOver.close();
				}
			}
		},

		removeLinkFromAttachments: function (oEvent) {

			var linkId = oEvent.getSource().getBindingContext("SlDetailModel").getProperty("LinkId");
			let oSuccessLine = this.getModel("slDefaultModel").getProperty("/SuccessLine");
			oSuccessLine.Attachments.filter((attachment, index) => {
				if (attachment.LinkId === linkId) {
					oSuccessLine.Attachments.splice(index, 1);
					return;
				}
			});
		},

		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onSaveWrprAttachments: function () {
			let bErrors = this._validateEmptyLinks("idWrprAttchmnts");
			if (!bErrors) {
				this.SlDetailModel.setProperty("/isWrprAttchmntBusy", true);
				let aAttachments = this.SlDetailModel.getProperty("/WrprAttachments");
				aAttachments.filter((item) => {
					delete item.AddRemove;
				});
				SLService.updateWrprAttachments(aAttachments).then((oData) => {
					let aTemp = [];
					oData.filter((item) => {
						aTemp.push(item.data);
					});
					let aActiveLinks = [];
					aTemp.filter((item, index) => {
						if (item.Active === true) {
							aActiveLinks.push(item);
						}
					});
					if (aActiveLinks.length) {
						aActiveLinks[aActiveLinks.length - 1].AddRemove = "X";
					}
					let aActvts = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails");
					aActvts.to_slwrapper.results[0].to_wrpdoc.results = aTemp;
					this.getView().getModel("slDefaultModel").refresh(true);
					this.SlDetailModel.setProperty("/WrprAttachments", aTemp);
					this.aStoreWrprAttchmnts = jQuery.extend(true, [], aTemp);
					this.SlDetailModel.setProperty("/isWrprAttchmntBusy", false);
					this.wrprAttchmntsPopOver.close();
					this.setRiskColor(aActvts.RiskDesc, 100);
					this.addNewLinkToAttachments(aActiveLinks);
				});
			}
		},

		addNewLinkToAttachments: function (aActiveLinks) {
			let attachmentHierarchy = this.getModel("slDefaultModel").getProperty("/AttachmentHierarchy");
			let oSuccessLine = this.getModel("slDefaultModel").getProperty("/SuccessLine");
			aActiveLinks.filter((item, index) => {
				var isNewLink = true;
				oSuccessLine.Attachments.filter((attachment, index) => {
					if (item.LinkId === attachment.LinkId) {
						attachment.Link = item.Link;
						attachment.LinkTitle = item.LinkTitle;
						isNewLink = false;
						return;
					}
				});
				if (isNewLink) {
					item.AttachCat = item.AttachCat ? item.AttachCat : "A";
					item.Level = "ACTIVITY";
					item.Type = "LINK";
					item.Handover = false;
					oSuccessLine.Attachments.push(item);
				}
			});
			this.setHierarchyData();
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onWrprAttchmntCancel: function (oEvent) {
			this.wrprAttchmntsPopOver.close();
			if (this.SlDetailModel.getProperty("/WrprAttachments")) {
				let sActGuid = this.SlDetailModel.getProperty("/WrprAttachments")[0].ActGuid;
				let aActvts = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails");
				aActvts.to_slwrapper.results[0].to_wrpdoc.results = jQuery.extend(true, [], this.aStoreWrprAttchmnts);
			}
			this.SlDetailModel.setProperty("/WrprAttachments", jQuery.extend(true, [], this.aStoreWrprAttchmnts));
			this.byId("idWrprAttchmnts").getItems().filter((value, index) => {
				var link = value.getItems()[1];
				var displayName = value.getItems()[0];
				displayName.setValueState("None");
				link.setValueState("None");
			});
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		groupActRegistered: function (oContext) {
			return {
				key: oContext.getProperty("PhaseName")
			};
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onLinkChange: function (oEvent) {
			oEvent.getSource().setValueState("None");

		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_validateEmptyLinks: function (id) {
			let bErrors = false;
			$.each(this.byId(id).getItems(), function (index, value) {
				var link = value.getItems()[1];
				var displayName = value.getItems()[0];
				if (!displayName.getValue().trim() && value.getVisible()) {
					displayName.setValueState("Error");
					bErrors = true;
				} else {
					displayName.setValueState("None");
				}
				if (!link.getValue() && value.getVisible()) {
					link.setValueState("Error");
					bErrors = true;
				} else if (link.getValue() && value.getVisible()) {
					var regex = /^(http[s]?:\/\/){0,1}(www\.){0,1}[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,5}[\.]{0,1}/;
					if (!regex.test(link.getValue())) {
						link.setValueState("Error");
						bErrors = true;
						MessageToast.show("Enter valid URL");
					} else {
						link.setValueState("None");
					}
				}
			}.bind(this));
			return bErrors;
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_getCommentsCount: function () {
			UtilityService.getCommentsCount(this.SuccessLineId, "SLINE").then((count) => {
				let sCount = count.data.results[0].EntryCount;
				let sDsplayMsg = "";
				if (parseInt(sCount, 10) > 1) {
					sDsplayMsg = parseInt(sCount, 10) + " " + this._oResourceBundle.getText("xmsg.MultpleCmntsMsg");
				} else {
					sDsplayMsg = parseInt(sCount, 10) + " " + this._oResourceBundle.getText("xmsg.singleCmntMsg");
				}
				this.SlDetailModel.setProperty("/EntryCount", parseInt(sCount, 10));
				this.SlDetailModel.setProperty("/CommentsMsg", sDsplayMsg);

			});

		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		keepCloning: function (objectpassed) {
			if (objectpassed === null || typeof objectpassed !== 'object' || objectpassed.constructor() === undefined) {
				return objectpassed;
			} // give temporary-storage the original obj's constructor
			var temporary_storage = objectpassed.constructor();
			for (var key in objectpassed) {
				temporary_storage[key] = this.keepCloning(objectpassed[key]);
			}
			return temporary_storage;
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		setHierarchyData: function (sData) {
			let that = this;
			let oSlDefaultModel = this.getModel("slDefaultModel");
			let oSuccessLine = this.getModel("slDefaultModel").getProperty("/SuccessLine");
			let treedata;
			let attachmentTreedata = {};
			if (!sData) {
				treedata = oSuccessLine.generateActivitiesTree();
				attachmentTreedata = oSuccessLine.generateActivitiesTree();
			} else {
				treedata = sData;
				attachmentTreedata = sData;
			}
			var phases = {};
			var attachmentPhases = {};
			this.getModel("slDefaultModel").setProperty("/SuccessLineHierarchy", phases);
			this.getModel("slDefaultModel").setProperty("/AttachmentHierarchy", attachmentPhases);
			var model = this.getModel("slDefaultModel").getProperty("/SuccessLineHierarchy");
			var attachmentHierarchy = this.getModel("slDefaultModel").getProperty("/AttachmentHierarchy");
			let irowSelectedindex = oSlDefaultModel.getProperty("/rowSelectedindex");
			// Associate Independently Registered Activities with a SuccessLine #70
			if (oSuccessLine.OppActvts.length) {
				var oIndpndtActvt = {
					ActCount: oSuccessLine.OppActvts.length,
					ColorName: "grey",
					CompActCount: oSuccessLine.OppActvts.length,
					Level: "PHASE",
					PhaseCompletion: 0,
					PhaseId: "",
					PhaseName: "",
					PlanActCount: 0,
					RegActCount: 0,
					Title: "Independent Activities",
					Weight: "000",
					collapsed: false,
					isIndependent: true,
					results: []
				};
				oSuccessLine.OppActvts.filter(function (actvt) {
					actvt.Level = "ACTIVITY";
					actvt.Title = actvt.ActvtTypeDesc;
					actvt.isNoteEditable = false;
					actvt.isRiskEditable = false;
					actvt.RegistrationAccess = false;
					actvt.isOutcomesEditale = false;
					actvt.isDescriptionEditable = false;
					actvt.isIndependent = true;
					actvt.RiskColor = "";
					actvt.RiskColorCode = "";
					actvt.EnabledRoles = "";
					oIndpndtActvt.results.push(actvt);
				});
				treedata.push(oIndpndtActvt);
			}
			model.Phases = treedata;
			attachmentHierarchy.Phases = attachmentTreedata;
			//New attachment tab
			this.setAttachmentsToHierarchy(attachmentHierarchy.Phases, oSuccessLine.Attachments);
			//New attachment tab
			setTimeout(() => {
				this.setPlanningTableLength();
				if (typeof irowSelectedindex === "number" && irowSelectedindex !== null) {
					that.fnSetSelectedIndexToTable(irowSelectedindex);
				}
			}, 500);
			let spresentationData = oSuccessLine.presentationChart();
			this.getModel("slDefaultModel").setProperty("/presentationData", spresentationData);
		},

		setAttachmentsToHierarchy: function (aPhases, aAttachments) {
			if (aAttachments.length) {
				aAttachments.filter(function (attachment, index) {
					aPhases.filter(function (phase, index) {
						if (attachment.PhaseId === phase.PhaseId) {
							var aServices = phase.results;
							aServices.filter(function (service, index) {
								if (attachment.TpointId === service.TpointId) {
									var aServiceActvts = service.results;
									if (attachment.AttachCat === "S") {
										attachment.Level = "ACTIVITY";
										attachment.Type = "LINK";
										aServiceActvts.unshift(attachment);
										return;
									} else {
										aServiceActvts.filter(function (actvt, index) {
											if (actvt.ActGuid === attachment.ActGuid && actvt.ActivityId === attachment.ActivityId && actvt.Type !== "LINK") {
												attachment.Level = "ACTIVITY";
												attachment.Type = "LINK";
												aServiceActvts.splice(index + 1, 0, attachment);
												return;
											}
										});
									}
								}
							});
						}
					});
				});
			}
		},

		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		refreshSL: function (bSelectedRow) {
			this._getSuccessLineData(bSelectedRow);
			this._getRoleMasterData();
			this._getSourceMasterData();
			this.getView().getModel("slDefaultModel").refresh(true);
			setTimeout(() => {
				var length = this.getView().byId("actvtRegTbl").getBinding("rows").getLength();
				this.getModel("slDefaultModel").setProperty("/SuccessLineHierarchyVisibleRows", length);
			}, 1000);
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onDragStart: function (oEvent) {
			let SLisAuthorized = this.getView().getModel("slDefaultModel").getProperty("/SuccessLine/isAuthorized");
			if (!SLisAuthorized) {
				oEvent.preventDefault();
			}
			var oTreeTable = this.getView().byId("actvtRegTbl");
			var oDragSession = oEvent.getParameter("dragSession");
			var oDraggedRow = oEvent.getParameter("target");
			var iDraggedRowIndex = oDraggedRow.getIndex();
			var aSelectedIndices = oTreeTable.getSelectedIndices();
			var aDraggedRowContexts = [];

			if (aSelectedIndices.length > 0) {
				// If rows are selected, do not allow to start dragging from a row which is not selected.
				if (aSelectedIndices.indexOf(iDraggedRowIndex) === -1) {
					MessageToast.show("Deselect the selected row to allow drag");
					oEvent.preventDefault();
				} else {
					for (var i = 0; i < aSelectedIndices.length; i++) {
						if (oTreeTable.getContextByIndex(aSelectedIndices[i]).getObject().ActivityId) {
							if (!oTreeTable.getContextByIndex(aSelectedIndices[i]).getObject().RegMandatory) {
								if (oTreeTable.getContextByIndex(aSelectedIndices[i]).getObject().Active) {
									aDraggedRowContexts.push(oTreeTable.getContextByIndex(aSelectedIndices[i]));
								} else {
									MessageToast.show("Activity from disable service cannot be moved to a different service");
									oEvent.preventDefault();
								}
							} else {
								MessageToast.show("Mandatory activity cannot be moved to a different service");
								oEvent.preventDefault();
							}

						} else if (oTreeTable.getContextByIndex(aSelectedIndices[i]).getObject().TpointId) {
							if (oTreeTable.getContextByIndex(aSelectedIndices[i]).getObject().Active) {
								aDraggedRowContexts.push(oTreeTable.getContextByIndex(aSelectedIndices[i]));
							} else {
								MessageToast.show("Disabled service cannot be moved");
								oEvent.preventDefault();
							}
						} else {
							oEvent.preventDefault();
						}

					}
				}
			} else {
				if (oTreeTable.getContextByIndex(iDraggedRowIndex).getObject().ActivityId) {
					if (!oTreeTable.getContextByIndex(iDraggedRowIndex).getObject().RegMandatory) {
						if (oTreeTable.getContextByIndex(iDraggedRowIndex).getObject().Active) {
							aDraggedRowContexts.push(oTreeTable.getContextByIndex(iDraggedRowIndex));
						} else {
							MessageToast.show("Activity from disable service cannot be moved to a different service");
							oEvent.preventDefault();
						}
					} else {
						MessageToast.show("Mandatory activity cannot be moved to a different service");
						oEvent.preventDefault();
					}
				} else if (oTreeTable.getContextByIndex(iDraggedRowIndex).getObject().TpointId) {
					if (oTreeTable.getContextByIndex(iDraggedRowIndex).getObject().Active) {
						aDraggedRowContexts.push(oTreeTable.getContextByIndex(iDraggedRowIndex));
					} else {
						MessageToast.show("Disabled activity cannot be moved to a different service");
						oEvent.preventDefault();
					}
				} else {
					oEvent.preventDefault();
				}

			}
			oDragSession.setComplexData("hierarchymaintenance", {
				draggedRowContexts: aDraggedRowContexts
			});
			// this.collapseServicesL();
		},

		collapseServicesL: function () {
			var aServiceIndexs = [];
			var oTreeTable = this.getView().byId("actvtRegTbl");
			var aRows = oTreeTable.getRows();
			aRows.filter(function (item, index) {
				var level = item.getLevel();
				if (level === 2) {
					aServiceIndexs.push(index);
				}

			});
			oTreeTable.collapse(aServiceIndexs);

		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onDrop: function (oEvent) {
			let that = this;
			var oTreeTable = this.getView().byId("actvtRegTbl");
			var oDragSession = oEvent.getParameter("dragSession");
			var oDroppedRow = oEvent.getParameter("droppedControl");
			var aDraggedRowContexts = oDragSession.getComplexData("hierarchymaintenance").draggedRowContexts;
			var oNewParentContext = oTreeTable.getContextByIndex(oDroppedRow.getIndex());
			let TempId = this.getView().getModel("slDefaultModel").getProperty("/SuccessLine/TempId");
			let SlId = this.getView().getModel("slDefaultModel").getProperty("/SuccessLine/SlId");
			if (aDraggedRowContexts.length === 0 || !oNewParentContext) {
				return;
			}
			var oModel = oTreeTable.getBinding().getModel("slDefaultModel");
			var oNewParent = oNewParentContext.getProperty();
			if (oNewParent.Level === "ACTIVITY") {
				if (!oNewParent.Active) {
					MessageToast.show("Cannot drop an Activity to Disabled service");
					return;
				} else if (!oNewParent.PhaseId) {
					MessageToast.show("Cannot drop an Activity to Indpendent Activities");
					return;
				}
				var selectedObj = aDraggedRowContexts[0].getObject();
				var prevSelectedObj = aDraggedRowContexts[0].getObject();
				var prevPhaseId = prevSelectedObj.PhaseId;
				var prevWeight = prevSelectedObj.Weight;
				var prevTpointId = prevSelectedObj.TpointId;
				var prevTchpointGuid = prevSelectedObj.TchpointGuid;
				if (!prevTchpointGuid) {
					prevTchpointGuid = "00000000-0000-0000-0000-000000000000";
				}
				selectedObj.PhaseId = oNewParent.PhaseId;
				selectedObj.TpointId = oNewParent.TpointId;
				selectedObj.Weight = oNewParent.Weight;
				selectedObj.TchpointGuid = oNewParent.TchpointGuid;
				var oSelectedOpp = this.SlDetailModel.getProperty("/SelectedOpportunity");
				if (oSelectedOpp) {
					selectedObj.accountname = oSelectedOpp.ACCOUNT_NAME;
					selectedObj.iss = oSelectedOpp.ISS;
					selectedObj.iac = oSelectedOpp.Internal_Account_Classification;
					selectedObj.industry = oSelectedOpp.INDUSTRY;
					selectedObj.OppDescription = oSelectedOpp.DESCRIPTION;
				}
				SLService.moveActivitytoService(prevPhaseId, prevWeight, prevTpointId, selectedObj, this.SuccessLineId, SlId, TempId,
					prevTchpointGuid).then((
						sData) => {
						this.SlPhaseId = undefined;
						this.SlActGuid = undefined;
						var oNavParams = {
							PhaseId: oNewParent.PhaseId,
							TpointId: oNewParent.TpointId,
							TchpointGuid: oNewParent.TchpointGuid
						};
						this.tpDetailStorage.put("oTpDetails", oNavParams);
						that.refreshSL();
						// oTreeTable.expandToLevel(2);
					});
			}
			for (var i = 0; i < aDraggedRowContexts.length; i++) {
				if (oNewParentContext.getPath().indexOf(aDraggedRowContexts[i].getPath()) === 0) {
					// Avoid moving a node into one of its child nodes.
					continue;
				}
				if (oNewParent.Level === "PHASE") {
					var selectedObj = aDraggedRowContexts[i].getObject();
					var prevSelectedObj = aDraggedRowContexts[i].getObject();
					var prevPhaseId = prevSelectedObj.PhaseId;
					var prevWeight = prevSelectedObj.Weight;
					var prevTpointId = prevSelectedObj.TpointId;
					selectedObj.PhaseId = oNewParent.PhaseId;
					if (oNewParent.TpointId) {
						selectedObj.TpointId = oNewParent.TpointId;
						selectedObj.TchpointGuid = oNewParent.TchpointGuid;
					}
					selectedObj.Weight = oNewParent.Weight;
					var selectedPath = aDraggedRowContexts[i].getPath();
					if (selectedObj.Level === "SERVICE") {
						var selecteParentPath = "";
						selectedObj.PhaseId = oNewParent.PhaseId;
						for (let tp = 0; tp < selectedObj.results.length; tp++) {
							selectedObj.results[tp].PhaseId = oNewParent.PhaseId;
						}
						var maxWeight = 0;
						if (oNewParent.results.length > 0) {
							maxWeight = Math.max.apply(Math, oNewParent.results.map(function (o) {
								return o.Weight;
							}));
							if (maxWeight === -Infinity) {
								maxWeight = 1;
							} else {
								maxWeight = maxWeight + 1;
							}
						}

						selectedObj.Weight = this.padWithZeroes(maxWeight, maxWeight.toString().length);
						//call new service
						SLService.moveServicetoPhase(prevPhaseId, prevWeight, selectedObj, this.SuccessLineId, SlId, TempId).then((sData) => {
							this.SlPhaseId = oNewParent.PhaseId;
							this.SlActGuid = undefined;
							if (this.tpDetailStorage && this.tpDetailStorage.get("oTpDetails")) {
								this.tpDetailStorage.put("oTpDetails", null);
							}
							that.refreshSL();
							oTreeTable.expandToLevel(2);
						});
					} else {
						MessageToast.show("Cannot drop an Activity to Phase");
						return;
					}
				}
				if (oNewParent.TpointTitle) {
					if (!oNewParent.Active) {
						MessageToast.show("Cannot drop an Activity to Disabled service");
						return;
					}
					var selectedObj = aDraggedRowContexts[i].getObject();
					var prevSelectedObj = aDraggedRowContexts[i].getObject();
					var prevPhaseId = prevSelectedObj.PhaseId;
					var prevWeight = prevSelectedObj.Weight;
					var prevTpointId = prevSelectedObj.TpointId;
					var prevTchpointGuid = prevSelectedObj.TchpointGuid;
					if (!prevTchpointGuid) {
						prevTchpointGuid = "00000000-0000-0000-0000-000000000000";
					}
					selectedObj.PhaseId = oNewParent.PhaseId;
					selectedObj.Weight = oNewParent.Weight;

					if (selectedObj.Level === "ACTIVITY") {
						if (oNewParent.TpointId) {
							selectedObj.TpointId = oNewParent.TpointId;
							selectedObj.TchpointGuid = oNewParent.TchpointGuid;
						}
						SLService.moveActivitytoService(prevPhaseId, prevWeight, prevTpointId, selectedObj, this.SuccessLineId, SlId, TempId,
							prevTchpointGuid).then((
								sData) => {
								this.SlPhaseId = undefined;
								this.SlActGuid = undefined;
								var oNavParams = {
									PhaseId: oNewParent.PhaseId,
									TpointId: oNewParent.TpointId,
									TchpointGuid: oNewParent.TchpointGuid
								};
								this.tpDetailStorage.put("oTpDetails", oNavParams);
								that.refreshSL();
								// oTreeTable.expandToLevel(2);
							});
					} else if (selectedObj.Level === "SERVICE") {
						SLService.moveServicetoPhase(prevPhaseId, prevWeight, selectedObj, this.SuccessLineId, SlId, TempId).then((sData) => {
							this.SlPhaseId = oNewParent.PhaseId;
							this.SlActGuid = undefined;
							if (this.tpDetailStorage && this.tpDetailStorage.get("oTpDetails")) {
								this.tpDetailStorage.put("oTpDetails", null);
							}
							that.refreshSL();
							// oTreeTable.expandToLevel(2);
						});
					}
				}
				oModel.refresh(true);
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		setMenu: function (statusId, oAct, oButton) {
			let slLeadAccess, registrationAccess, activityLeadAccess, customerValidatedAccess;
			let that = this;
			activityLeadAccess = false;
			registrationAccess = false;
			customerValidatedAccess = false;
			let ActivityStatus = this.getOwnerComponent().getModel("masterData").getProperty("/ActivityStatus");
			let allowedRegions = [];
			ActivityStatus.filter(function (actvtStatus, index) {
				if (actvtStatus.StatusId === '14') {
					allowedRegions.push(actvtStatus.RegionHc);
				}
			});
			allowedRegions.filter(function (region, index) {
				if (region === oAct.RequestorRegHC || region === '*') {
					customerValidatedAccess = true;
				}
			});
			var currentUserRoleMpngId = this.getModel("slDefaultModel").getProperty("/SuccessLine/ActivityRole");
			var currentUser = this.getView().getModel("user").getProperty("/UserId");
			let slLead = this.getModel("slDefaultModel").getProperty("/SuccessLine/SlLead");
			var oItems = [];
			var oModel = this.getView().getModel("activityMenuModel");
			let ActivityId = oAct.ActivityId;
			let sCustomeraction = false;
			if (ActivityId === '0108') {
				sCustomeraction = true;
			}

			if (oAct.RegistrationAccess) {
				registrationAccess = true;
			}
			if (oAct.ActLeadId === currentUser) {
				activityLeadAccess = true;
			}
			slLeadAccess = this.getModel("slDefaultModel").getProperty("/bSlLeadAccess");
			if (oAct.RoleMpngID === "") {
				//commented as part of - URGENT BUG: MSL lead unable to register activities #143
				// if (oAct.RegistrationAccess && slLeadAccess) { 
				if (slLeadAccess) {
					slLeadAccess = true;
				} else {
					slLeadAccess = false;
				}
			}
			let OpportunityId = this.getModel("slDefaultModel").getProperty("/SuccessLine/OpportunityId");
			let AccountId = this.getModel("slDefaultModel").getProperty("/SuccessLine/AccountId");
			if (OpportunityId) {
				oAct.ActvtAsstdID = "502";
				oAct.CostTypeValue = OpportunityId;
				oAct.CostTypeName = "Opportunity";
			} else {
				oAct.ActvtAsstdID = "501";
				oAct.CostTypeValue = AccountId;
				oAct.CostTypeName = "Account";
			}

			let sActivityId = oAct.RegisteredActId;
			let updatedStartDate = oAct.StartDate;
			if (sActivityId) {
				sActivityId = (parseInt(oAct.RegisteredActId, 10)).toString();
			}
			const oUserActivitiesModel = sap.ui.getCore().getModel("activities");
			if (oUserActivitiesModel) {
				const aUserActivities = oUserActivitiesModel.getData();
				const oActivity = aUserActivities.find(item => item.ActivityId === sActivityId);
				oAct.MtrActivity = null;
				if (oActivity) {
					oActivity.StartDate = (updatedStartDate) ? updatedStartDate : oActivity.StartDate;
					oAct.MtrActivity = new MtrActivity(oActivity);
					oAct.MtrActivity.ProjectType = "SLINE";
				}
			}
			oModel.setProperty("/activityLeadAccess", activityLeadAccess);
			oModel.setProperty("/registrationAccess", registrationAccess);
			oModel.setProperty("/slLeadAccess", slLeadAccess);
			oModel.setProperty("/customeraction", sCustomeraction);
			oModel.setProperty("/customerValidatedAccess", customerValidatedAccess);
			oModel.setProperty("/statusId", statusId);
			oModel.setProperty("/oAct", oAct);
			oModel.refresh(true);
			this._setActivitySelected(oAct.PhaseId, oAct.TpointId, oAct.ActGuid);
			this.synchPresentationModel('ACTIVITY', oAct);
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		openStatusMenu: function (oEvent, statusId, obj) {
			let that = this;
			let data;
			let sStatusId = statusId;
			let oSlActivityObject = obj;
			let oButton = oEvent.getSource();
			let oActivityMenuModel = this.getView().getModel("activityMenuModel");
			oActivityMenuModel.setProperty("/oSelectedSLActivity", obj);
			this.Component.getModel("masterData").setProperty("/FormLayoutId", obj.frmlayout_id);
			SLService.getActivity(obj).then((sData) => {
				data = sData.data.results[0];
				//check sl activity's frmlayoutId is present and frmlayoutId is empty from the respsonse
				if (oSlActivityObject && "frmlayout_id" in oSlActivityObject && "frmlayout_id" in data && !data.frmlayout_id) {
					data.frmlayout_id = oSlActivityObject.frmlayout_id;
					data.RegistrationAccess = (oSlActivityObject && "RegistrationAccess" in oSlActivityObject) ? oSlActivityObject.RegistrationAccess :
						false;
					data.ChildFrmLayoutId = oSlActivityObject.ChildFrmLayoutId;
				}
				this.loadStatusMenu(sStatusId, data, oButton);
			});
			if (oSlActivityObject.ChildFrmLayoutId) {
				this.getFormLayoutData(oSlActivityObject.ChildFrmLayoutId);
			}
		},

		loadStatusMenu: function (statusId, obj, oButton) {
			let that = this;
			let oModel = this.getModel("slDefaultModel");
			oModel.setProperty("/selectedActivity", obj);
			that.setMenu(statusId, obj, oButton);
			that.ActivityMenuButton = oButton;
			if ("to_paction" in obj) {
				let oPactions = obj.to_paction;
				let aResults = ("results" in oPactions) ? oPactions.results : [];
				if (aResults.length) {
					aResults = that.fnSetAdditionalMenuItems(obj, aResults);
				}
				oModel.setProperty("/aActionMenus", aResults);
			} else {
				oModel.setProperty("/aActionMenus", []);
			}

			if (!that.oMenuDialog) {
				Fragment.load({
					name: "com.presalescentral.successline.fragments.ActivityActionMenu",
					controller: that
				}).then(function (oPopover) {
					that.oMenuDialog = oPopover;
					that.getView().addDependent(that.oMenuDialog);
					that.oMenuDialog.openBy(oButton);
				}.bind(that));
			} else {
				that.oMenuDialog.openBy(oButton);
			}
		},

		//Factory function to create menu items for Action Menu
		fnCreateMenuItemTemplate: function (sId, oContext) {
			let oModel = oContext.getModel();
			let cObject = oModel.getProperty(oContext.getPath());
			let text = cObject["ItemName"];
			text = (text) ? text.toLowerCase().replace(/\s/g, "") : "";
			if (text === "createtimeentry") {
				let that = this;
				let oActivityMenuModel = this.getView().getModel("activityMenuModel");
				let oSavedEnteries = this.getView().getModel("oMTRModel").getProperty("/savedEntries");
				let oMtrActivity = oActivityMenuModel.getProperty("/oAct/MtrActivity");

				let statusId = oActivityMenuModel.getProperty("/statusId");
				let oSelectedSLActivity = oActivityMenuModel.getProperty("/oSelectedSLActivity") || {};
				let StatusId = ("StatusId" in oSelectedSLActivity) ? oSelectedSLActivity.StatusId : "";
				let SLStatusId = ("SLStatus" in oSelectedSLActivity) ? oSelectedSLActivity.SLStatus : "";
				let timeEntryMenuItem = new TimeEntryMenuItem({
					text: "Loading....",
					icon: "sap-icon://locked",
					selectedActivity: oMtrActivity,
					statusId: StatusId,
					enabled: (SLStatusId !== "12") ? true : false,
					press: function (oEvent) {
						that.handleTimeRecord(oEvent);
					},
					entries: oSavedEnteries
				});
				timeEntryMenuItem.data("timeEntryMenuId", cObject["id"]);
				return timeEntryMenuItem;
			} else {
				return new sap.m.MenuItem({
					icon: "{slDefaultModel>Icon}",
					visible: "{slDefaultModel>Visible}",
					text: "{slDefaultModel>ItemName}",
					key: "{slDefaultModel>ActionId}",
					enabled: "{=${slDefaultModel>IsEnabled} === 'X' && ${slDefaultModel>/SuccessLine/StatusId} !=='12' }",
					items: {
						templateShareable: true,
						sorter: { path: 'SortOrder' },
						path: 'slDefaultModel>to_caction/results',
						factory: function () {
							return new sap.m.MenuItem({
								icon: "{parts: ['slDefaultModel>ItemValue', 'slDefaultModel>/selectedActivity/StatusId'], formatter:'com.presalescentral.successline.model.Formatter.getActionMenuIcon'}",
								visible: "{slDefaultModel>Visible}",
								text: "{slDefaultModel>ItemName}",
								key: "{slDefaultModel>ActionId}",
								enabled: "{= ${slDefaultModel>IsEnabled} === 'X'?true:false }"
							})
						},

					}
				});
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		openPhaseMenu: function (oEvent, sObj) {
			let that = this;
			let oButton = oEvent.getSource();
			that._setPhaseDetails(sObj.PhaseId);
			if (!that.oPhaseMenuDialog) {
				Fragment.load({
					name: "com.presalescentral.successline.fragments.PhaseAction",
					controller: that
				}).then(function (oPopover) {
					that.oPhaseMenuDialog = oPopover;
					that.getView().addDependent(that.oPhaseMenuDialog);
					that.oPhaseMenuDialog.openBy(oButton);
				}.bind(that));
			} else {
				that.oPhaseMenuDialog.openBy(oButton);
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		openServiceMenu: function (oEvent, sObj) {
			let that = this;
			let oButton = oEvent.getSource();
			that._setTouchPointSelected(sObj.PhaseId, sObj.TpointId, sObj.TchpointGuid, false, false);
			if (!that.oServiceMenuDialog) {
				Fragment.load({
					name: "com.presalescentral.successline.fragments.ServiceAction",
					controller: that
				}).then(function (oPopover) {
					that.oServiceMenuDialog = oPopover;
					that.getView().addDependent(that.oServiceMenuDialog);
					that.oServiceMenuDialog.openBy(oButton);
				}.bind(that));
			} else {
				that.oServiceMenuDialog.openBy(oButton);
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		refreshActivities: function (data, key, sRefresh, sCancel) {
			const that = this;
			let oModel = this.getModel("slDefaultModel");
			that.getOwnerComponent().getModel("appSettings").setProperty("/isItemBusy", true);
			let aActvts = that.getModel("slDefaultModel").getProperty("/SuccessLine/Activities");
			let OpportunityId = that.getModel("slDefaultModel").getProperty("/SuccessLine/OpportunityId");
			let AccountId = that.getModel("slDefaultModel").getProperty("/SuccessLine/AccountId");
			let ActvtAsstdID = "";
			let CostTypeValue = "";
			let CostTypeName = "";
			if (OpportunityId) {
				ActvtAsstdID = "502";
				CostTypeValue = OpportunityId;
				CostTypeName = "Opportunity";
			} else {
				ActvtAsstdID = "501";
				CostTypeValue = AccountId;
				CostTypeName = "Account";
			}
			if (data.ActGuid) {
				this.SlActGuid = data.ActGuid;
			}
			ActivityUtil.getUserActivities(true).then(function (aUserActivities) {
				aActvts.filter(function (actvt, index) {
					if (actvt.PhaseId === data.PhaseId && actvt.ActivityId === data.ActivityId && actvt.ActGuid ===
						data.ActGuid) {
						if (key) {
							actvt.StatusId = key;
						} else {
							actvt.StatusId = data.StatusId;
						}
						actvt.RegisteredActId = data.RegisteredActId;
						actvt.ActLeadId = data.ActLeadId;
						actvt.ActLead = data.ActLead;
						actvt.ActLeadAbrv = data.ActLeadAbrv;
						actvt.archived = data.archived;
						actvt.MtrActivity = new MtrActivity({
							ActivityId: data.RegisteredActId,
							ActivityTypeId: data.ActivityId,
							ActTypeDesc: data.Title,
							ActAsstId: ActvtAsstdID,
							ActStatusDesc: data.StatusDescription,
							RoleMpngID: data.RoleMpngID,
							CostTypeValue: CostTypeValue,
							CostTypeName: CostTypeName,
							ActivityLead: data.ActLeadId,
							ActLeadName: data.ActLead,
							ParentRoleId: data.ParentRoleId,
							ProjectType: "SLINE",
							ActivitySetStatus: (data.archived) ? "ARCHIVED" : ""
						});
						if (sCancel) {
							actvt.to_slwrapper = [];
						}
					}
				});
				that.getModel("slDefaultModel").setProperty("/SuccessLine/Activities", aActvts);
				that.getModel("slDefaultModel").setProperty("/SuccessLine/TotalActCount", aActvts.length);
				that._setSlCompletion(aActvts);
				//Refresh Activity Registered fragment
				setTimeout(() => {
					that.getOwnerComponent().getModel("appSettings").setProperty("/isItemBusy", false);
					oModel.setProperty("/rowSelectedindex", null);
					that.refreshSL(true);
				}, 1000);
			});
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		getActivity: function (key, obj, sRefresh) {
			let that = this;
			let data;
			SLService.getActivity(obj).then((sData) => {
				data = sData.data.results[0];
				that.refreshActivities(data, key, sRefresh);
			});
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		updateActivityStatus: function (key, obj, isArchived) {
			let that = this;
			let oppData = this.SlDetailModel?.getProperty("/SelectedOpportunity");
			var data = {};
			let TchpointGuid;
			if (obj.tchpoint_guid) {
				TchpointGuid = obj.tchpoint_guid;
			} else if (obj.TchpointGuid) {
				TchpointGuid = obj.TchpointGuid;
			}
			data.SlId = obj.SlId;
			data.SlSnro = obj.SlSnro;
			data.ActGuid = obj.ActGuid;
			data.TempId = obj.TempId;
			data.PhaseId = obj.PhaseId;
			data.TpointId = obj.TpointId;
			data.ActivityId = obj.ActivityId;
			data.Weight = obj.Weight;
			data.RoleMpngID = obj.RoleMpngID;
			data.StatusId = obj.StatusId;
			data.StatusDescription = obj.StatusDescription;
			data.IsGlobal = obj.IsGlobal;
			data.RegMandatory = obj.RegMandatory;
			data.Title = obj.Title;
			data.PhaseTitle = obj.PhaseTitle;
			data.PhaseAbv = obj.PhaseAbv;
			data.RegisteredActId = obj.RegisteredActId;
			data.SubTitle = obj.SubTitle;
			data.note = obj.note;
			data.Active = obj.Active;
			data.ActRegCount = obj.ActRegCount;
			data.TotalActCount = obj.TotalActCount;
			data.IconUrl = obj.IconUrl;
			data.IconColor = obj.IconColor;
			data.frmlayout_id = obj.frmlayout_id;
			data.source = obj.source;
			data.UserRole = obj.UserRole;
			data.ActLeadId = obj.ActLeadId;
			data.ActLead = obj.ActLead;
			data.ActLeadAbrv = obj.ActLeadAbrv;
			data.ActLeadEmail = obj.ActLeadEmail;
			data.tchpoint_guid = TchpointGuid;
			data.CompDate = obj.CompDate;
			data.archived = isArchived;
			data.OppDesc = oppData.DESCRIPTION;
			data.ACCOUNT_NAME = oppData.ACCOUNT_NAME;
			data.iss = oppData.ISS;
			data.iac = oppData.Internal_Account_Classification;
			data.GlobalUltimateID = oppData.ACCOUNT;
			SLService.updateActivity(key, data).then((oData) => {
				if (key === "02") { //For Cancelled Activity, fetch prior status of the activity
					SLService.getActivity(data).then((sData) => {
						data = sData.data.results[0];
						key = data.StatusId;
						that.refreshActivities(data, key, false, true);
					});
				} else {
					if (key === "12") { // to update the model locally if the completion action is triggered
						that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
						that._updateLocalModelPostCompletion(data);
						that.getModel("slDefaultModel").refresh();
						that.getModel("SlDetailModel").refresh();
						let aActvts = that.getModel("slDefaultModel").getProperty("/SuccessLine/Activities");
						that._setSlCompletion(aActvts);
					} else {
						that.refreshActivities(data, key, false);
					}
				}

			});
		},
		/**
		 *Function to optimize the activity completion task, by updating the local model.
		 * {param} Data recived from the service after successful execution of backend call.
		 */
		_updateLocalModelPostCompletion: function (oData) {
			let oActivityStatus = this.getModel("masterData").getData().ActivityStatus;
			let oActivityDetails = this.getModel("slDefaultModel").getData().ActivityDetails;
			let sStatusDescribtion;
			oActivityStatus.forEach((actStatus) => {
				if (actStatus.StatusId === oData.StatusId) {
					sStatusDescribtion = actStatus.StatusDesc;
				}
			});
			let selectData = {};
			let sRegisteredActId = oData.RegisteredActId;
			if (oActivityDetails.RegisteredActId === sRegisteredActId && oActivityDetails.ActivityId === oData.ActivityId) {
				selectData.RiskAssessId = oActivityDetails.RiskId;
				oData.RiskAssessId = oActivityDetails.RiskId;
			}
			selectData.PhaseId = oData.PhaseId;
			selectData.TpointId = oData.TpointId;
			selectData.StatusId = oData.StatusId;
			selectData.ActLeadId = oData.ActLeadId;
			selectData.ActivityId = oData.ActivityId;
			selectData.ActGuid = oData.ActGuid;
			selectData.CompDate = oData.CompDate;
			selectData.StatusDescription = sStatusDescribtion;
			selectData.bCompActvt = true;
			this.RapidRegistration.getSelectActivity(selectData, oData, true);
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		navigatetoActivityForm: function (oParam) {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "pcactivityform",
					action: "app"
				},
				params: oParam
			})) || ""; // generate the Hash to display a Supplier
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onActivityFormAction: function (statusId, oActv, oSource) {
			let that = this;
			var oNavParams = {
				PhaseId: oActv.PhaseId,
				TpointId: oActv.TpointId,
				TchpointGuid: oActv.TchpointGuid
			};
			this.tpDetailStorage.put("oTpDetails", oNavParams);
			var roleID = this.getModel("slDefaultModel").getProperty("/SuccessLine/ActivityRole");
			//URGENT BUG: MSL lead unable to register activities #143
			var bSlLeadAccess = this.getModel("slDefaultModel").getProperty("/bSlLeadAccess");
			let sRegAccess = oActv.RegistrationAccess;
			if (oActv.ActLeadId) {
				roleID = oActv.RoleMpngID;
			}
			/*else if (!sRegAccess && bSlLeadAccess) {
				oActv = that.fnFindFormLayoutIdUsingRoleMapId(oActv);
				roleID = "067";
			}*/
			var oParam;
			if (statusId === "01") { //Register Activity
				//Open Rapid registration
				// this.openRapidRegistration(statusId, oActv, oSource);
				//git-634 change
				this.triggerRapidRegistration(oActv);

			} else if (statusId === "15") { //Already Registered
				if (oActv.ActivityId === '0108') {
					//Open Rapid registration
					this.openRapidRegistration(statusId, oActv, oSource);
				} else {
					this.getView().getModel("slDefaultModel").setProperty("/SuccessLine/Menu", true);
					oParam = {
						"ActivityID": parseInt(oActv.RegisteredActId),
						"ActivityDetail": true
					};
					this.navigatetoActivityForm(oParam);
				}
			}
		},

		//START: Include previously excluded registration fields in the reg dialog #634
		triggerRapidRegistration: function (oActivity) {
			const that = this;
			if (!oActivity || typeof oActivity !== 'object') {
				console.error("Invalid activity data");
				return;
			}
			this.fnGetSelectedActMTRTask(oActivity).then(function (data) {
				that.getTimeEntryDefaultValues(oActivity);
			});
			const oRapidRegActvt = this.formatRapidRegActivityObject(oActivity);
			const rapidRegBtn = new MelodyLibRapidRegistration({
				text: "",
				icon: "",
				enabled: true,
				activityData: oRapidRegActvt,
				activityContextPath: "",
				activityId: oRapidRegActvt.ActivityId,
				press: function (oEvent) {
					const dDate = new Date();
					const oWeekDates = {
						dFirstdate: dDate,
						dLastdate: dDate
					}
					that.onPressRegistration(oEvent, oWeekDates);
				},
				selectedActivity: function (oEvent) {
					that.onSuccessActvtRegistration(oEvent);
				}
			});
			rapidRegBtn.firePress();
		},
		
		formatRapidRegActivityObject: function (oActivity) {
			const oSlDetailModel = this.SlDetailModel;
			const oAccntData = oSlDetailModel.getProperty("/SelectedOpportunity");
			const oOppData = oSlDetailModel.getProperty("/SelectedOpportunity/opportunity");
			const sActvtAsstdId = oActivity.ActvtAsstdID;
			const aOpportunity = [], aAccount = [];
			let sAccountId = "";
			if (oOppData && sActvtAsstdId === "502") {
				const oOpportunity = {
					"ACCOUNT_NAME": oOppData.ACCOUNT_NAME,
					"DESCRIPTION": oOppData.DESCRIPTION, //Added as part of git-729
					"OPPT_ID": oOppData.OPPT_ID || this.SlDetailModel.getProperty("/OpportunityId"),
					"PHASE_DESC": "",
					"accountid": oOppData.ACCOUNT,
					"mastercodeid": oOppData.INDUSTRY_MASTERCODE
				};
				aOpportunity.push(oOpportunity);
			}
			if (oAccntData) {
				sAccountId = oAccntData.ACCOUNT || oAccntData.accountid;
				const oAccount = {
					accountid: sAccountId,
					accountname: oAccntData.ACCOUNT_NAME,
					iac: oAccntData.Internal_Account_Classification,
					iss: oAccntData.ISS
				};
				aAccount.push(oAccount);
			}
			const sRoleMpngID = oActivity.RoleMpngID || this.getModel("slDefaultModel").getProperty("/SuccessLine/ActivityRole");
			let oRapidRegActvt = {
				"SlSnro": oActivity.SlSnro,
				"SLActGUID": oActivity.ActGuid,
				"ActivityLeadName": oActivity.ActLead,
				"ActivityLead": oActivity.ActLeadId,
				"ActivityLeadEmailId": oActivity.ActLeadEmail,
				"ActivityTypeId": oActivity.ActivityId,
				"ActivityTypeDescription": oActivity.ActvtTypeDesc,
				"ActvtAsstdID": oActivity.ActvtAsstdID,
				"ActivityId": oActivity.RegisteredActId ? String(parseInt(oActivity.RegisteredActId, 10)) : "",
				"RoleMpngID": sRoleMpngID,
				"OpportunityNumber": this.SlDetailModel.getProperty("/OpportunityId"),
				"GlobalUltimateID": sAccountId,
				"ChildFrmLayoutId": oActivity.ChildFrmLayoutId,
				"FormLayoutId": oActivity.frmlayout_id,
				"StartDate": new Date(),
				"EndDate": new Date(),
				"CreateDate": new Date(),
				"to_AOpportunity": aOpportunity,
				"to_AAccnt": aAccount,
			};
			return oRapidRegActvt;
		},

		onPressRegistration: function (oEvent, oWeekDates) {
			oEvent.getSource().fnOpenRapidRegDialog(oEvent, oWeekDates);
		},

		onSuccessActvtRegistration: function (oEvent) {
			const oActivityData = oEvent.getParameter("activityData");
			this.RapidRegistration.fnSetSlRapidRegData(oActivityData);
			this.RapidRegistration.fnTriggerTimeEntry(oActivityData);
		},
		//END: Include previously excluded registration fields in the reg dialog #634

		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onActivityStatusChange: function (oEvent, key, oActv) {
			let oSource = oEvent;
			let oModel = this.getModel("slDefaultModel");
			this.getView().getModel("slDefaultModel").setProperty("/SuccessLine/Menu", false);
			switch (key) {
				case '01': //Register Activity
					this.onActivityFormAction(key, oActv, this.ActivityMenuButton);
					break;
				case '02': //Cancel Registration
					this.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
					oActv.CompDate = new Date();
					this.updateActivityStatus(key, oActv);
					break;
				case '11': //Mark as Planned
					this.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
					this.updateActivityStatus(key, oActv);
					break;
				case '12': //Mark as Completed
					this.onCompletionDateEdit(oActv, undefined, key, false);
					break;
				case '14': //Customer Validated
					this.onCompletionDateEdit(oActv, undefined, key, false);
					break;
				case '15': //Mark as Not Applicable
					this.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
					this.updateActivityStatus(key, oActv);
					break;
				case '00005': //Remove Activity
					//TchpointGuid is not present when removing the activity from detail view
					if (oActv.TchpointGuid === undefined) {
						oActv.TchpointGuid = oActv.tchpoint_guid;
					}
					this.oSelectedActvt = oActv;
					let sSelectedActvtTitle = this.oSelectedActvt.Title;
					this.getModel("slDefaultModel").setProperty("/TouchPointDetails/SelectedActvtTitle", sSelectedActvtTitle);
					if (!this.removeActvtDialog) {
						this.removeActvtDialog = sap.ui.xmlfragment(this.getView().getId(),
							"com.presalescentral.successline.fragments.RemoveActivity",
							this);
						this.getView().addDependent(this.removeActvtDialog);
					}
					this.removeActvtDialog.open();
					this.getView().getModel("slDefaultModel").setProperty("/SuccessLine/Menu", true);
					break;
				case '15': //Registered
					this.onActivityFormAction(key, oActv, this.ActivityMenuButton);
					break;
				case '16': //Started
					this.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
					this.updateActivityStatus(key, oActv);
					break;
				case '17': //Progressing
					this.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
					this.updateActivityStatus(key, oActv);
					break;
				case '18': //Presented
					this.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
					this.updateActivityStatus(key, oActv);
					break;
				case '99': //Assign a Lead
					this.ActivityMenuButton = oSource; //TODO
					let oBtnSource = oEvent.getSource();
					this.onActivityLeadEdit(oActv, oBtnSource);
					break;
				case '100': //Revert to Registered
					key = "01";
					this.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
					oActv.CompDate = new Date();
					this.updateActivityStatus(key, oActv);
					break;
				default:
					break;
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleWrapperRegistration: function (oEvent, oActv, statusId) {
			let that = this;
			let oSource = oEvent.getSource();
			that.onActivityFormAction(statusId, oActv, oSource);
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onEditRegisteredActivity: function (oEvent, key, oActv) {
			let that = this;
			let oModel = this.getModel("slDefaultModel");
			this._setActivitySelected(oActv.PhaseId, oActv.TpointId, oActv.ActGuid);
			setTimeout(() => {
				let sActv = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails");
				that.onActivityFormAction(key, sActv, this.ActivityMenuButton);
			}, 1000);
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onCloseActivityLeadDialog: function () {
			this.getView().getModel("slDefaultModel").setProperty("/SuccessLine/Menu", true);
			this.ActvtLeadDialog.close();
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onActivityLeadEdit: function (oActv, oSource) {
			let that = this;
			let currentUser = this.getView().getModel("user").getProperty("/UserId");
			let slLead = this.getView().getModel("slDefaultModel").getProperty("/SuccessLine/SlLead");
			let slStatusId = this.getView().getModel("slDefaultModel").getProperty("/SuccessLine/StatusId");
			let SLisAuthorized = this.getView().getModel("slDefaultModel").getProperty("/SuccessLine/isAuthorized");
			let Archive = this.getView().getModel("slDefaultModel").getProperty("/SuccessLine/Archive");
			if (oActv.isIndependent) {
				return;
			}
			if ((slStatusId === '01' && SLisAuthorized && Archive !== true && oActv.Active === true) && (currentUser === slLead || oActv.RegistrationAccess)) {
				that.SlDetailModel.setProperty("/selectedActvt", oActv);
				that.getView().getModel("masterData").setProperty("/selectedSourceId", "001");
				let SlLeadRegionId = that.getModel("slDefaultModel").getProperty("/SuccessLine/SlLeadRegionId");
				that.getView().getModel("masterData").setProperty("/selectedRegion", SlLeadRegionId);
				let SlSnro = that.getModel("slDefaultModel").getProperty("/SuccessLine/SlSnro");
				that.SlDetailModel.setProperty("/actvtLeadSearch", "");
				SLService.getFromSource(oActv.RoleMpngID, SlSnro, SlLeadRegionId, undefined, "", oActv.ActivityId, oActv.ActvtAsstdID).then((
					oData) => {
					that.getModel("slDefaultModel").setProperty("/SuccessLine/ActivityLeadList", oData.data.results);
				});
				if (!that.ActvtLeadDialog) {
					that.ActvtLeadDialog = sap.ui.xmlfragment(that.getView().getId(),
						"com.presalescentral.successline.fragments.ActivityLead",
						that);
					that.getView().addDependent(that.ActvtLeadDialog);
				}
				if (currentUser === slLead) {
					that.getModel("slDefaultModel").setProperty("/SuccessLine/selfAsignLead", false);

				} else {
					that.getModel("slDefaultModel").setProperty("/SuccessLine/selfAsignLead", true);
				}
				that.ActvtLeadDialog.openBy(oSource);

			} else {
				return;
			}

		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onSourceChange: function (oEvent, sNullRegion) {
			let that = this;
			let key = that.getView().getModel("masterData").getProperty("/selectedSourceId");
			let SlSnro = that.getModel("slDefaultModel").getProperty("/SuccessLine/SlSnro");
			let oActv = that.SlDetailModel.getProperty("/selectedActvt");
			let selectedRegion = that.getView().getModel("masterData").getProperty("/selectedRegion");
			let query = that.SlDetailModel.getProperty("/actvtLeadSearch");
			if (!query) {
				query = "";
			}
			if (sNullRegion) {
				that.getView().getModel("masterData").setProperty("/selectedRegion", "");
				selectedRegion = "";

			}
			if (key === '001') //From SL team
			{
				SLService.getFromSource(oActv.RoleMpngID, SlSnro, selectedRegion, undefined, query, oActv.ActivityId, oActv.ActvtAsstdID).then((
					oData) => {
					that.getModel("slDefaultModel").setProperty("/SuccessLine/ActivityLeadList", oData.data.results);
				});
			} else if (key === '002') { //From Opportunity
				let partiesInvovled = that.getView().getModel("formModel").getProperty("/SelectedUsers");
				if (partiesInvovled) {
					SLService.getFromSource(oActv.RoleMpngID, undefined, selectedRegion, partiesInvovled, query, oActv.ActivityId, oActv.ActvtAsstdID)
						.then((oData) => {
							that.getModel("slDefaultModel").setProperty("/SuccessLine/ActivityLeadList", oData.data.results);
						});
				} else {
					that.getModel("slDefaultModel").setProperty("/SuccessLine/ActivityLeadList", null);
				}
			} else { //From ORE
				SLService.getFromSource(oActv.RoleMpngID, undefined, selectedRegion, undefined, query, oActv.ActivityId, oActv.ActvtAsstdID).then(
					(oData) => {
						that.getModel("slDefaultModel").setProperty("/SuccessLine/ActivityLeadList", oData.data.results);
					});
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleActivityLeadConfirm: function (oEvent, sFromRapidReg, isSelfAssignLead) {
			let that = this;
			let flag = false;
			let oContext = oEvent.getSource().getBindingContext("slDefaultModel");
			let oUserModel = this.Component.getModel("user");
			var selectedObj, selectedLeadName, selectedLeadId, selectedEmail, selectedRolempngId;
			let RoleMpngID = this.getModel("slDefaultModel").getProperty("/ActivityDetails/RoleMpngID");
			let roleID = this.getModel("slDefaultModel").getProperty("/SuccessLine/ActivityRole");
			if (oContext) {
				selectedObj = oContext.getObject();
				selectedLeadName = selectedObj.Name;
				selectedLeadId = selectedObj.UserId;
				selectedEmail = selectedObj.EmailId;
				selectedRolempngId = selectedObj.RolempngId;
				if (sFromRapidReg) {
					this.RapidRegistration.slActLead = {
						CRMRoleDesc: selectedObj.CrmRoleDesc,
						CRMRoleId: selectedObj.CrmRoleId,
						EMAIL: selectedObj.EmailId,
						ID: selectedObj.UserId,
						NAME: selectedObj.Name
					};
				}
			} else {
				selectedLeadName = oUserModel.getProperty("/UserName");
				selectedLeadId = oUserModel.getProperty("/UserId");
				selectedEmail = oUserModel.getProperty("/UserEmail");
				selectedRolempngId = RoleMpngID ? RoleMpngID : roleID;
				if (isSelfAssignLead) {
					selectedObj = {
						EmailId: selectedEmail,
						UserId: selectedLeadId,
						Name: selectedLeadName
					};
				}
			}
			let oppOwner, oppEmail;
			oppOwner = "";
			oppEmail = "";
			let obj = this.SlDetailModel.getProperty("/selectedActvt");
			let OpportunityId = that.getModel("slDefaultModel").getProperty("/SuccessLine/OpportunityId");
			let partiesInvovled = that.getView().getModel("formModel").getProperty("/SelectedUsers");
			let oppDesc, accDesc;
			oppDesc = "";
			accDesc = "";
			if (obj.ActLeadId === selectedLeadId) {
				MessageToast.show("User is already an Activity Lead");
				return;
			}
			if (obj.RoleMpngID === "") {
				obj.RoleMpngID = selectedRolempngId;
			}
			if (OpportunityId && OpportunityId !== "") {
				oppDesc = that.SlDetailModel.getProperty("/SelectedOpportunity/DESCRIPTION");
				//Check if selected activity lead is part of VAT team
				if (partiesInvovled) {
					for (var i = 0; i < partiesInvovled.length; i++) {
						if (partiesInvovled[i].USER_ID === selectedLeadId) {
							flag = true;
						}
					}
					if (!flag) {
						$.each(partiesInvovled, function (index, value) {
							if (value.ROLE === "ZOZOPO01") {
								oppEmail = value.EMAIL;
								oppOwner = value.NAME;
							}
						});
						this.SlDetailModel.setProperty("/vatWarningOppId", OpportunityId);
						this.SlDetailModel.setProperty("/vatWarningUserName", selectedLeadName);
						this.SlDetailModel.setProperty("/vatWarningEmail", selectedEmail);
						this.SlDetailModel.setProperty("/vatWarningoppEmail", oppEmail);
						this.SlDetailModel.setProperty("/vatWarningoppOwner", oppOwner);
						/*if (!this.VATWarningDialog) {
							this.VATWarningDialog = sap.ui.xmlfragment(this.getView().getId(),
								"com.presalescentral.successline.fragments.VATWarning",
								this);
							this.getView().addDependent(this.VATWarningDialog);
						}
						this.VATWarningDialog.open();*/
					} else {
						this.SlDetailModel.setProperty("/vatWarningOppId", "");
					}
				}
			} else {
				accDesc = that.SlDetailModel.getProperty("/SelectedOpportunity/ACCOUNT_NAME");
			}
			let TchpointGuid;
			if (obj.tchpoint_guid) {
				TchpointGuid = obj.tchpoint_guid;
			} else if (obj.TchpointGuid) {
				TchpointGuid = obj.TchpointGuid;
			}
			var data = {};
			data.SlId = obj.SlId;
			data.SlSnro = obj.SlSnro;
			data.ActGuid = obj.ActGuid;
			data.TempId = obj.TempId;
			data.PhaseId = obj.PhaseId;
			data.TpointId = obj.TpointId;
			data.ActivityId = obj.ActivityId;
			data.Weight = obj.Weight;
			data.RoleMpngID = obj.RoleMpngID;
			data.StatusId = obj.StatusId;
			data.StatusDescription = obj.StatusDescription;
			data.IsGlobal = obj.IsGlobal;
			data.RegMandatory = obj.RegMandatory;
			data.Title = obj.Title;
			data.PhaseTitle = obj.PhaseTitle;
			data.PhaseAbv = obj.PhaseAbv;
			data.RegisteredActId = obj.RegisteredActId;
			data.SubTitle = obj.SubTitle;
			data.note = obj.note;
			data.Active = obj.Active;
			data.ActRegCount = obj.ActRegCount;
			data.TotalActCount = obj.TotalActCount;
			data.IconUrl = obj.IconUrl;
			data.IconColor = obj.IconColor;
			data.frmlayout_id = obj.frmlayout_id;
			data.source = obj.source;
			data.UserRole = obj.UserRole;
			data.ActLeadId = selectedLeadId;
			data.ActLead = selectedLeadName;
			data.ActLeadAbrv = obj.ActLeadAbrv;
			data.OpportunityName = oppDesc;
			data.AccountName = accDesc;
			data.ActLeadEmail = selectedEmail;
			data.tchpoint_guid = TchpointGuid;

			this.leadDetails = {
				sFromRapidReg: sFromRapidReg,
				selectedLeadId: selectedLeadId,
				selectedLeadName: selectedLeadName,
				selectedEmail: selectedEmail
			};
			if (OpportunityId) {
				this.fnGetFindOppActUsers(data, selectedObj, selectedLeadId);
			} else {
				this.fnUpdateActivityLead(data);
			}
		},

		//Automatically add activity team memeber to opportunity VAT team
		//Function to find the team members who don't have opportunity access
		fnGetFindOppActUsers: function (data, selectedUser, selectedLeadId) {
			var that = this;
			this.IsVATAccessSericeTriggered = false;
			var formModel = that.getView().getModel("formModel");
			let oSldefaultModel = this.getView().getModel("slDefaultModel");
			var oSlDetailModel = that.getView().getModel("SlDetailModel");
			var opportunityId = oSlDetailModel.getProperty("/OpportunityId");
			var oOppoTeam = formModel.getProperty("/SelectTeam");
			//if (selectedUser.CrmRoleId && selectedUser.CrmRoleDesc) {}
			if (oOppoTeam === null) {
				oOppoTeam = [];
			}
			var oActTeam = [{
				CRMRoleId: selectedUser.CrmRoleId,
				CRMRoleDesc: selectedUser.CrmRoleDesc,
				EMAIL: selectedUser.EmailId,
				ID: selectedUser.UserId,
				NAME: selectedUser.Name
			}];
			var oNoAccessUsrs = oActTeam.filter(({
				ID: id1,
				EMAIL: email1
			}) => !oOppoTeam.some(({
				UserId: id2,
				EmailId: email2
			}) =>
				id2.toLowerCase() === id1.toLowerCase() && email1.toLowerCase() === email2.toLowerCase()));
			if (oNoAccessUsrs.length) {
				var oTempArr = [];
				oNoAccessUsrs.filter(function (object) {
					if (that.fnFindSameUserObject(object, oTempArr)) {
						object.IsDuplicate = true;
					}
					oTempArr.push(object);
				});
				var successfn = function (UIErrorCode, oResponse) {
					if (UIErrorCode === "HARMONY_SERVER_DOWN" || UIErrorCode === "SERVICE_LIMIT_REACHED") {
						var oMsg =
							"Harmony server is unavailable, Activity lead cannot be added to Opportunity team. Do you still want to assign Activity Lead?";
						if (oResponse) {
							var code = JSON.parse(oResponse.responseText).error.code;
							if (code === "Z_CROSS_REPORTING/009") {
								oMsg = "You do not have access to this Opportunity. Do you still want to assign Activity Lead";
							}
						}
						that.fnRemoveNewlyAddedUsers(oMsg);
					} else {
						that.fnUpdateActivityLead(that.updateSLLeadData);
					}
				};
				var oArray = jQuery.extend(true, [], oTempArr);
				var oOppoDataModel = this.opportunityComponentInstance.getModel("oppServerModel");
				var bMetadataLoaded = oOppoDataModel.isMetadataLoadingFailed();
				this.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
				if (!bMetadataLoaded) {
					this.updateSLLeadData = data;
					this.IsVATAccessSericeTriggered = true;
					this.opportunityComponentInstance._oOpportunityHelper.fnProvideOppoAccess(oArray, opportunityId, successfn, true);
				} else {
					that.fnUpdateActivityLead(data);
				}
			} else {
				that.fnUpdateActivityLead(data);
			}

		},

		//Function to find if an same object is present in the array already
		fnFindSameUserObject: function (rObject, oArray) {
			var oSearchedObj = oArray.find(function (object) {
				return object["ID"] === rObject["ID"] && object["EMAIL"] === rObject["EMAIL"];
			});
			return oSearchedObj;
		},

		//Function to remove newly added team users, when the harmony server is down,[Oppo VAT team]
		fnRemoveNewlyAddedUsers: function (ErrorMsg) {
			var that = this;
			sap.m.MessageBox.confirm(ErrorMsg, {
				onClose: function (oAction) {
					if (oAction.toLowerCase() === "cancel") {
						that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
					} else {
						that.fnUpdateActivityLead(that.updateSLLeadData);
					}
				}
			});
		},

		//Function to update Activity lead 
		fnUpdateActivityLead: function (data) {
			var that = this;
			SLService.updateActivity(undefined, data).then((oData) => {
				let OpportunityId = that.getModel("slDefaultModel").getProperty("/SuccessLine/OpportunityId");
				if (OpportunityId && that.IsVATAccessSericeTriggered) {
					var successfn = function (oResponse, isError) {
						if (isError) {
							MessageToast.show("Unable to update Opportunity team members to Melody");
						}
						that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
						that.fnShowActLeadVATPopUp();
					};
					that.opportunityComponentInstance._oOpportunityHelper.fnGetOpportunityOwner(data.ActivityId, data.SlSnro, {}, successfn);
				}
				MessageToast.show("Activity Lead updated successfully");
				that.getView().getModel("SlDetailModel").setProperty("/SlActvtLead", that.leadDetails.selectedLeadId);
				that.getView().getModel("SlDetailModel").setProperty("/SlActvtLeadName", that.leadDetails.selectedLeadName);
				that.getView().getModel("SlDetailModel").setProperty("/SlActvtLeadMail", that.leadDetails.selectedEmail);
				that.getActivity(undefined, data, that.leadDetails.sFromRapidReg);
				that.onCloseActivityLeadDialog();
				if (that.updateSLLeadData) {
					that.leadDetails = undefined;
					that.updateSLLeadData = undefined;
				}
			});
		},

		//Function to show popup on successfully adding Activity lead
		fnShowActLeadVATPopUp: function () {
			if (!this.VATWarningDialog) {
				this.VATWarningDialog = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.VATWarning",
					this);
				this.getView().addDependent(this.VATWarningDialog);
			}
			this.VATWarningDialog.open();
		},

		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onOKVATWarning: function () {
			this.VATWarningDialog.close();
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onRemoveActvtLead: function (oEvent, obj, StatusId, isAuthorized, Archive, Active, sUserId, sSLLead) {
			if (!(obj.RegisteredActId) && StatusId === "01" && isAuthorized && Archive === false && Active === true && (sUserId === sSLLead)) {
				let actvtLead = obj.ActLead;
				if (!this.slRemoveActvtLead) {
					this.slRemoveActvtLead = sap.ui.xmlfragment(this.getView().getId(),
						"com.presalescentral.successline.fragments.RemoveActivityLead",
						this);
					this.getView().addDependent(this.slRemoveActvtLead);
				}
				this.slRemoveActvtLead.openBy(oEvent.getSource());
				this.SlDetailModel.setProperty("/selectedActvt", obj);
				this.SlDetailModel.setProperty("/selectedActvtLeadName", actvtLead);
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onDeleteActivityLead: function (oEvent, obj) {
			let that = this;
			let TchpointGuid;
			if (obj.tchpoint_guid) {
				TchpointGuid = obj.tchpoint_guid;
			} else if (obj.TchpointGuid) {
				TchpointGuid = obj.TchpointGuid;
			}
			var data = {};
			data.SlId = obj.SlId;
			data.SlSnro = obj.SlSnro;
			data.ActGuid = obj.ActGuid;
			data.TempId = obj.TempId;
			data.PhaseId = obj.PhaseId;
			data.TpointId = obj.TpointId;
			data.ActivityId = obj.ActivityId;
			data.Weight = obj.Weight;
			data.RoleMpngID = obj.RoleMpngID;
			data.StatusId = obj.StatusId;
			data.StatusDescription = obj.StatusDescription;
			data.IsGlobal = obj.IsGlobal;
			data.RegMandatory = obj.RegMandatory;
			data.Title = obj.Title;
			data.PhaseTitle = obj.PhaseTitle;
			data.PhaseAbv = obj.PhaseAbv;
			data.RegisteredActId = obj.RegisteredActId;
			data.SubTitle = obj.SubTitle;
			data.note = obj.note;
			data.Active = obj.Active;
			data.ActRegCount = obj.ActRegCount;
			data.TotalActCount = obj.TotalActCount;
			data.IconUrl = obj.IconUrl;
			data.IconColor = obj.IconColor;
			data.frmlayout_id = obj.frmlayout_id;
			data.source = obj.source;
			data.UserRole = obj.UserRole;
			data.ActLeadId = "";
			data.ActLead = "";
			data.ActLeadAbrv = "";
			data.ActLeadEmail = "";
			data.tchpoint_guid = TchpointGuid;
			SLService.updateActivity(undefined, data).then((oData) => {
				MessageToast.show("Activity Lead removed successfully");
				that.getActivity(undefined, data, false);
			});
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onActvtViewDetails: function (oEvent) {
			const sUserId = oEvent.getSource().getBindingContext("SlDetailModel").getProperty("ID");
			window.open(this.ConstantsMap["0071"].field_value + sUserId);
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onActvtSendMailClick: function (oEvent) {
			sap.m.URLHelper.triggerEmail(oEvent.getSource().getBindingContext("SlDetailModel").getProperty("EMAIL"));
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onActvtCallClick: function (evt) {
			sap.m.URLHelper.triggerTel(evt.getSource().getBindingContext("SlDetailModel").getProperty("MobileNumber"));
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_getSourceMasterData: function () {
			let aFilter = [new Filter("SourceType", FilterOperator.EQ, "SL_ACTVT")];
			SLService.getSources(aFilter).then((oData) => {
				this.getModel("slDefaultModel").setProperty("/SuccessLine/Sources", oData.data.results);
				this.getModel("slDefaultModel").setProperty("/SuccessLine/Source", "001");
			});
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleSourceSelect: function () {
			this.getRoleBasedActivityTypes(true);
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleActTypeSelect: function (oEvent) {
			let sActTypeDesc = oEvent.getSource().getSelectedItem().getText();
			if (sActTypeDesc) {
				var aFilter = new Filter({
					filters: [new Filter("ActvtTypeDesc", FilterOperator.EQ, sActTypeDesc)]
				});

				this.byId("addActvtList").getBinding("items").filter(aFilter);
				this.isRoleFilterChanged = true;
			} else {
				this.byId("addActvtList").getBinding("items").filter([]);
				this.byId("actTypeId").setSelectedKey("");
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onOpportunityLinkPress: function (opp) {
			window.open(this.ConstantsMap["0183"].field_value + opp, "_blank");
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onAddAcvtSearchLiveChange: function (oEvent) {
			let sQuery = oEvent.getSource().getValue();
			if (!sQuery) {
				this.onAddActivitySearch(undefined, sQuery);
			}

		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onSuccessLineLeadPress: function (oEvent) {
			if (!this.slLeadInfoPopOver) {
				this.slLeadInfoPopOver = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.SuccessLineLeadInfo",
					this);
				this.getView().addDependent(this.slLeadInfoPopOver);
			}
			this.slLeadInfoPopOver.openBy(oEvent.getSource());
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleSendMailToSuccessLineLead: function (oEvent) {
			let SlLeadEmail = this.getModel("slDefaultModel").getProperty("/SuccessLine/SlLeadEmail");
			sap.m.URLHelper.triggerEmail(SlLeadEmail);
		},
		/**
		 * Trigger call to creator.
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleCallToSuccessLineLead: function (oEvent) {
			let sSlLeadMobile = this.getModel("slDefaultModel").getProperty("/SuccessLine/SlLeadMobile");
			sap.m.URLHelper.triggerTel(sSlLeadMobile);
		},
		/**
		 * Opens creator details in new tab.
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onViewSuccessLineLeadDetails: function (oEvent) {
			const sUserId = this.getModel("slDefaultModel").getProperty("/SuccessLine/SlLead");
			window.open(this.ConstantsMap["0071"].field_value + sUserId);
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onStoryLinkPress: function (oEvent, sUrl) {
			if (!sUrl.match(/^[a-zA-Z]+:\/\//)) {
				sUrl = 'https://' + sUrl;
			}
			window.open(sUrl, "_blank");
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleOpenOppInfoPress: function (oEvent) {
			const masterSettings = this.getOwnerComponent().getModel("masterSettings");
			const masterOpportunityDataLoaded = masterSettings.getProperty("/masterOpportunityDataLoaded");
			if (masterOpportunityDataLoaded) {
				const selectedOpp = this.getView().getModel("SlDetailModel").getProperty("/SelectedOpportunity");
				this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity", selectedOpp);
				this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/PHASE_DESC", selectedOpp.SALES_PHASE);
				this.getView().getModel("formModel").setProperty("/Region", this.getView().getModel("slDefaultModel").getProperty(
					"/SuccessLine/Region"));
				this.getView().getModel("formModel").setProperty("/SubRegion", this.getView().getModel("slDefaultModel").getProperty(
					"/SuccessLine/SubRegion"));
				this.getView().getModel("formModel").setProperty("/Industry", selectedOpp.INDUSTRY);
				this.getView().getModel("opportunityModel").setProperty("/selectedOpportunity/SALES_ORG_DESC", selectedOpp.SALES_ORG_TEXT);
			}
			if (this.getView().getModel("SlDetailModel").getProperty("/OpportunityId")) {
				this.fnOpenOppInfoPress(oEvent);
			} else {
				this.fnOpenAccountInfo(oEvent);
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		fnOpenOppInfoPress: function (oEvent) {
			if (!this.oppInfoPopup) {
				this.oppInfoPopup = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.OpportunityInfoDetailHeader", this);
				this.getView().addDependent(this.oppInfoPopup);
			}
			this.oppInfoPopup.openBy(oEvent.getSource());
			var slAddOppsTreeList = this.byId("slAddOppsTreeList");
			var oItems = slAddOppsTreeList.getItems() || [];
			if (oItems.length >= 1) {
				for (var i = 0; i < oItems.length; i++) {
					if (oItems[i].getExpanded()) {
						oItems[i]._getExpanderControl().firePress();
					}
				}
				if (!oItems[0].getExpanded()) {
					oItems[0]._getExpanderControl().firePress();
				}
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		fnOpenAccountInfo: function (oEvent) {
			if (!this.accountInfoPopup) {
				this.accountInfoPopup = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.AccountInfo", this);
				this.getView().addDependent(this.accountInfoPopup);
			}
			this.accountInfoPopup.openBy(oEvent.getSource());
			this.byId("idSLDetAddOppo").setVisible(true);
		},
		/**
		 * Closes the information fragment for Account
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onCloseAccountInfo: function () {
			this.accountInfoPopup.close();
		},
		/**
		 * Closes the information fragment for Opportunity
		 * @memberOf com.presalescentral.successline.view.SlForm
		 */
		onCloseOppInfo: function () {
			this.oppInfoPopup.close();
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onFilterPlanItems: function (oEvent) {
			if (oEvent.getSource().getPressed()) {
				//show filters
				this.getModel("slDefaultModel").setProperty("/SuccessLineHierarchy/PlanItemsVisibility", true);
			} else {
				//hide filters
				this.getModel("slDefaultModel").setProperty("/SuccessLineHierarchy/PlanItemsVisibility", false);
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_getActivityWrapper: function (isIndpndntActvt) {
			let that = this;
			const oModel = this.getModel("slDefaultModel");
			let oActvt = oModel.getProperty("/ActivityDetails");
			that.getView().getModel("SlDetailModel").setProperty("/RegistrationActvtVisible", false);
			that.getOwnerComponent().getModel("appSettings").setProperty("/isItemBusy", true);
			that.getView().getModel("slDefaultModel").setProperty("/SuccessLine/ActivityDetailsInfo", {});
			SLService.getSLDetailWrapper(oActvt, isIndpndntActvt).then((wrapperData) => {
				let activities = this.getModel("slDefaultModel").getProperty("/SuccessLine/Activities");
				if (isIndpndntActvt) {
					activities = this.getModel("slDefaultModel").getProperty("/SuccessLine/OppActvts");
				}
				for (var i = 0; i < activities.length; i++) {
					if (wrapperData.data.results[0].ActGuid === activities[i].ActGuid) {
						activities[i].to_slwrapper = wrapperData.data;
						if (isIndpndntActvt) {
							activities[i].to_slwrapper.results[0].Notes = activities[i].note;
						}
						if (activities[i].to_slwrapper && activities[i].to_slwrapper.results.length > 0) {
							that.oStoreWarppr = jQuery.extend(true, {}, activities[i].to_slwrapper.results[0]);
							that.oStoreWrprFields = jQuery.extend(true, {}, activities[i].to_slwrapper.results[0]);
							that.oStoreRiskCmnt = jQuery.extend(true, "", activities[i].to_slwrapper.results[0]);
						}
						oModel.setProperty("/ActivityDetails", activities[i]);
						that.getView().getModel("slDefaultModel").setProperty("/SuccessLine/ActivityDetailsInfo/wrapper", activities[i].to_slwrapper
							.results[
							0]);
					}
				}
				if (wrapperData.data.results[0].to_wrpdoc.results.length) {
					let aWrprAttchmnts = wrapperData.data.results[0].to_wrpdoc.results;
					aWrprAttchmnts.filter((item, index) => {
						item.AddRemove = "";
						if (index === aWrprAttchmnts.length - 1) {
							item.AddRemove = "X";
						}
					});
					that.SlDetailModel.setProperty("/WrprAttachments", aWrprAttchmnts);
				}
				if (wrapperData.data.results[0].RegActId !== '') {
					that.getView().getModel("SlDetailModel").setProperty("/RegistrationActvtVisible", true);
				} else {
					that.getView().getModel("SlDetailModel").setProperty("/RegistrationActvtVisible", false);
				}
				that.getView().getModel("SlDetailModel").setProperty("/RapidRegActivityTeamMembers", wrapperData.data.results[0].to_team.results);
				that
					.getOwnerComponent().getModel("appSettings").setProperty("/isItemBusy", false);
				// that.getView().getModel("slDefaultModel").refresh(true);	

				//Above line is commented because the ActivityActionMenu was getting closed: 17/12/2025.
				//And ff it has to be un-commented, please review the ActivityActionMenu functionality

				if (that.oMenuDialog && that.oMenuDialog.isOpen()) {
					that.fnSetTimeEntryVisible(that.oMenuDialog);
				}
				return wrapperData;
			});
		},

		//Function to set Activity Action Menu Popover's Timentry button's visiblity
		fnSetTimeEntryVisible: function (oMenuDialog) {
			let timeEntryMenuIndex = oMenuDialog.getItems().findIndex(item => item.data("timeEntryMenuId") === "createtimeentry");
			let isTimeEntryVisible = oMenuDialog.getItems()[timeEntryMenuIndex].getVisible();
			if (!isTimeEntryVisible) {
				oMenuDialog.removeItem(oMenuDialog.getItems()[timeEntryMenuIndex]);
			}
		},

		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_setActivitySelected: function (sPhaseId, sTpId, sActivityGuid) {
			const oModel = this.getModel("slDefaultModel");
			const oSuccessLine = oModel.getProperty("/SuccessLine");
			const aActivities = oSuccessLine.Activities;
			let bIsInpndntActvt = false;
			let selectedActivity = aActivities.filter((item) => {
				return (item.TpointId === sTpId && item.PhaseId === sPhaseId && item.ActGuid === sActivityGuid);
			});
			// Associate Independently Registered Activities with a SuccessLine #70
			if (!selectedActivity[0]) {
				const aOppActivities = oSuccessLine.OppActvts;
				const selectedOppActivity = aOppActivities.filter((item) => {
					return (item.TpointId === sTpId && item.PhaseId === sPhaseId && item.ActGuid === sActivityGuid);
				});
				selectedActivity = selectedOppActivity;
				bIsInpndntActvt = true;
			}
			if (selectedActivity[0]) {
				oModel.setProperty("/ActivityDetails", selectedActivity[0]);
				this._getActivityWrapper(bIsInpndntActvt);
				oModel.setProperty("/SuccessLine/TpDetailVisibility", false);
				oModel.setProperty("/SuccessLine/ActivityDetailVisibility", true);
				oModel.setProperty("/SuccessLine/PhaseDetailVisibility", false);
				oModel.setProperty("/ActivityDetails/isRiskEditable", false);
				this.SlActGuid = sActivityGuid;
				if (this.tpDetailStorage && this.tpDetailStorage.get("oTpDetails")) {
					this.tpDetailStorage.put("oTpDetails", null);
				}
				let sRiskColor = selectedActivity[0].RiskDesc.toLowerCase();
				this.setRiskColor(sRiskColor, 2000);
				this.SlPhaseId = undefined;
				var oTreeTable = this.getView().byId("actvtRegTbl");
				var oRows = oTreeTable.getRows();
				let iRowIndex = null;
				var sPath;

				for (let i = 0; i < oRows.length; i++) {
					const oContext = oRows[i].getBindingContext("slDefaultModel");
					if (!oContext) continue;

					const oRow = oContext.getObject();
					if (oRow.ActGuid !== sActivityGuid) continue;

					const iRowIndex = oRows[i].getIndex();
					const sPath = oContext.getPath();
					oTreeTable.clearSelection();
					const oModel = this.getView().getModel("slDefaultModel");
					oModel.setProperty(sPath + "/selected", true);
					oModel.setProperty("/rowSelectedindex", iRowIndex);
					this.selectedIndex = iRowIndex;
					this.getView().byId("actvtRegTbl").setSelectedIndex(iRowIndex);
					break;
				}

				/*for (var i = 0; i < oRows.length; i++) {
					if (oRows[i].getBindingContext("slDefaultModel")) {
						var oRow = oRows[i].getBindingContext("slDefaultModel").getObject();
						if (oRow.ActGuid === sActivityGuid) {
							iRowIndex = oRows[i].getIndex();
							oTreeTable.clearSelection();
							sPath = oRows[i].getBindingContext("slDefaultModel").getPath();
							this.getView().getModel("slDefaultModel").setProperty(sPath + "/selected", true);
							this.selectedIndex = iRowIndex;
							this.getView().byId("actvtRegTbl").setSelectedIndex(iRowIndex);
							oModel.setProperty("/rowSelectedindex", iRowIndex);
							return;
						}
					}
				}*/
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		detailSectionSelection: function (sLevel, selectedObj) {
			const oModel = this.getModel("slDefaultModel");
			switch (sLevel) {
				case 'PHASE':
					this._setPhaseDetails(selectedObj.PhaseId);
					oModel.setProperty("/SuccessLine/PhaseDetailVisibility", true);
					oModel.setProperty("/SuccessLine/TpDetailVisibility", false);
					oModel.setProperty("/SuccessLine/ActivityDetailVisibility", false);
					break;
				case 'SERVICE':
					this._setTouchPointSelected(selectedObj.PhaseId, selectedObj.TpointId, selectedObj.TchpointGuid, false);
					oModel.setProperty("/SuccessLine/TpDetailVisibility", true);
					oModel.setProperty("/SuccessLine/PhaseDetailVisibility", false);
					oModel.setProperty("/SuccessLine/ActivityDetailVisibility", false);
					break;
				case 'ACTIVITY':
					oModel.setProperty("/SuccessLine/TpDetailVisibility", false);
					oModel.setProperty("/SuccessLine/ActivityDetailVisibility", true);
					oModel.setProperty("/SuccessLine/PhaseDetailVisibility", false);
					this._setActivitySelected(selectedObj.PhaseId, selectedObj.TpointId, selectedObj.ActGuid);
					break;
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onRowSelectionChange: function (oEvent) {
			var oTreeTable = this.getView().byId("actvtRegTbl");
			let oButton = this.getView().byId("idSubTitleBtn");
			let oUpdateButton = this.getView().byId("idUpdateSubTitle");
			let CancelButton = this.getView().byId("idCancelSubTitle");
			var aSelectedIndices = oTreeTable.getSelectedIndices();
			let inputField = this.getView().byId("idSubTitleText");
			let oSubTitle = this.getView().byId("idSubTitle");
			let isEditForOreUser = this.getModel("slDefaultModel").getProperty("/SuccessLine/isEditForOreUser");
			let StatusId = this.getModel("slDefaultModel").getProperty("/SuccessLine/StatusId");
			// if (oSubTitle.getText().length < 20) {
			// 	oSubTitle.setWidth("auto");
			// } else {
			// 	oSubTitle.setWidth("13rem");
			// }
			let oModel = this.getModel("slDefaultModel");
			var selectedObj, sLevel;
			CancelButton.setVisible(false);
			inputField.setVisible(false);
			oSubTitle.setVisible(true);
			oUpdateButton.setVisible(false);
			if (isEditForOreUser && (StatusId !== "12" || StatusId !== "02")) {
				oButton.setVisible(true);
			} else {
				oButton.setVisible(false);
			}
			this.fnHandleResize(oEvent);
			if (aSelectedIndices.length > 0 && this.selectedIndex !== aSelectedIndices[0]) {
				selectedObj = oTreeTable.getContextByIndex(aSelectedIndices[0]).getObject();
				sLevel = selectedObj.Level;
				selectedObj.selected = true;
				this.getView().byId("presentationChart").clearSelection();
				this.detailSectionSelection(sLevel, selectedObj);
				this.synchPresentationModel(sLevel, selectedObj);
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		fnHandleResize: function (oEvent) {
			let mainSplitter = this.getView().byId("mainSplitter").getDomRef();
			let oSplitter = this.getView().byId("mainSplitter");
			if (mainSplitter && mainSplitter !== null) {
				let firstChild = mainSplitter.firstChild;
				let firstChildNode = $("#" + firstChild.id);
				let tempBeforeScrollPosition = firstChildNode.scrollTop();
				oSplitter._resize = function (e) {
					firstChildNode.scrollTop(tempBeforeScrollPosition);
				};
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onResize: function (oEvent) {

		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		setPlanningTableLength: function () {
			var length = this.getView().byId("actvtRegTbl").getBinding("rows").getLength();
			this.getModel("slDefaultModel").setProperty("/SuccessLineHierarchyVisibleRows", length);
			var AttachmentTbllength = this.getView().byId("attachmentHierarchyTbl").getBinding("rows").getLength();
			this.getModel("slDefaultModel").setProperty("/AttachmentHierarchyVisibleRows", AttachmentTbllength);
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		synchPresentationModel: function (sLevel, selectedObj, isExpand) {
			var sPresentationData = this.getModel("slDefaultModel").getProperty("/presentationData");
			for (var i = 0; i < sPresentationData.phases.length; i++) {
				if (sPresentationData.phases[i].id === selectedObj.PhaseId) {
					if (sLevel === 'PHASE') {
						if (!isExpand) {
							sPresentationData.phases[i].selected = true;
						} else {
							sPresentationData.phases[i].collapsed = selectedObj.collapsed;
						}
						if (selectedObj.collapsed === true) { //When phase is collapsed, collapse the services too
							for (var l = 0; l < sPresentationData.phases[i].services.length; l++) {
								sPresentationData.phases[i].services[l].collapsed = true;
							}
						}
						this.setPlanningTableLength();
					} else if (sLevel === 'SERVICE' || sLevel === 'ACTIVITY') {
						for (var j = 0; j < sPresentationData.phases[i].services.length; j++) {
							if (sPresentationData.phases[i].services[j].id === selectedObj.TchpointGuid) {
								if (sLevel === 'SERVICE') {
									if (!isExpand) {
										sPresentationData.phases[i].services[j].selected = true;
									} else {
										sPresentationData.phases[i].services[j].collapsed = selectedObj.collapsed;
									}
									this.setPlanningTableLength();
								} else if (sLevel === 'ACTIVITY') {
									for (var k = 0; k < sPresentationData.phases[i].services[j].activities.length; k++) {
										if (sPresentationData.phases[i].services[j].activities[k].id === selectedObj.ActGuid) {
											if (!isExpand) {
												sPresentationData.phases[i].services[j].activities[k].selected = true;
											} else {
												sPresentationData.phases[i].services[j].activities[k].collapsed = selectedObj.collapsed;
											}
											this.setPlanningTableLength();
										} else {
											sPresentationData.phases[i].services[j].activities[k].selected = false;
										}
									}
								}
							} else {
								sPresentationData.phases[i].services[j].selected = false;
							}
						}
					}
				} else {
					sPresentationData.phases[i].selected = false;
				}
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		updateTreeTable: function (oEvent) {
			let sSelectecObj = oEvent.getParameters().rowContext.getObject();
			let sPath = oEvent.getParameters().rowContext.getPath();
			let sExpanded = oEvent.getParameters().expanded;
			if (!sExpanded) {
				this.getView().getModel("slDefaultModel").setProperty(sPath + "/collapsed", true);
				sSelectecObj.collapsed = true;
			} else {
				this.getView().getModel("slDefaultModel").setProperty(sPath + "/collapsed", false);
				sSelectecObj.collapsed = false;
			}
			this.setPlanningTableLength();
			this.synchPresentationModel(sSelectecObj.Level, sSelectecObj, 'expand');
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onPlanItemsSearch: function (oEvent) {
			let that = this;
			let searchString = oEvent.getParameter("query");
			if (searchString !== "") {
				that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
				SLService.getPlanItemsSearch(this.SuccessLineId, searchString).then((result) => {
					let aFilters = [];
					for (var i = 0; i < result.data.results.length; i++) {
						let text = result.data.results[i].ActGuid;
						let filterSearch = new Filter({
							path: "ActGuid",
							operator: sap.ui.model.FilterOperator.Contains,
							value1: text
						});
						aFilters.push(filterSearch);
					}
					if (result.data.results.length !== 0) {
						this.getView().byId("actvtRegTbl").getBinding("rows").filter(aFilters);
					} else {
						let filterSearch = new Filter({
							path: "ActGuid",
							operator: sap.ui.model.FilterOperator.Contains,
							value1: null
						});
						aFilters.push(filterSearch);
						this.getView().byId("actvtRegTbl").getBinding("rows").filter(aFilters);
					}
					this.getView().byId("planItemsPhase").removeAllSelectedItems();
					this.getView().byId("planItemsActivityLead").removeAllSelectedItems();
					this.getView().byId("planItemsActivityStatus").removeAllSelectedItems();
					this.getView().byId("planItemsActivityRole").removeAllSelectedItems();
					that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
					this.setPlanningTableLength();
				});
			} else {
				this.getView().byId("planItemsPhase").removeAllSelectedItems();
				this.getView().byId("planItemsActivityLead").removeAllSelectedItems();
				this.getView().byId("planItemsActivityStatus").removeAllSelectedItems();
				this.getView().byId("planItemsActivityRole").removeAllSelectedItems();
				this.getView().byId("actvtRegTbl").getBinding("rows").filter([]);
				this.setPlanningTableLength();
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handlePhasesFilter: function (oEvent) {
			let aFilters = [];
			let items = oEvent.getSource().getSelectedItems();
			for (var i = 0; i < items.length; i++) {
				let text = items[i].getText();
				let filterPhases = new Filter({
					path: "PhaseName",
					operator: sap.ui.model.FilterOperator.Contains,
					value1: text
				});
				aFilters.push(filterPhases);
			}
			if (items.length !== 0) {
				this.getView().byId("actvtRegTbl").getBinding("rows").filter(aFilters);
			} else {
				this.getView().byId("actvtRegTbl").getBinding("rows").filter([]);
			}
			this.getView().byId("planItemSearch").setValue("");
			this.getView().byId("planItemsActivityLead").removeAllSelectedItems();
			this.getView().byId("planItemsActivityStatus").removeAllSelectedItems();
			this.getView().byId("planItemsActivityRole").removeAllSelectedItems();
			this.setPlanningTableLength();
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleActivityLeadFilter: function (oEvent) {
			let aFilters = [];
			let items = oEvent.getSource().getSelectedItems();
			for (var i = 0; i < items.length; i++) {
				let text = items[i].getText();
				let filterPhases = new Filter({
					path: "ActLead",
					operator: sap.ui.model.FilterOperator.Contains,
					value1: text
				});
				aFilters.push(filterPhases);
			}
			if (items.length !== 0) {
				this.getView().byId("actvtRegTbl").getBinding("rows").filter(aFilters);
			} else {
				this.getView().byId("actvtRegTbl").getBinding("rows").filter([]);
			}
			this.getView().byId("planItemSearch").setValue("");
			this.getView().byId("planItemsPhase").removeAllSelectedItems();
			this.getView().byId("planItemsActivityStatus").removeAllSelectedItems();
			this.getView().byId("planItemsActivityRole").removeAllSelectedItems();
			this.setPlanningTableLength();
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleActivityStatusFilter: function (oEvent) {
			let aFilters = [];
			let items = oEvent.getSource().getSelectedItems();
			for (var i = 0; i < items.length; i++) {
				let text = items[i].getKey();
				let filterPhases = new Filter({
					path: "StatusId",
					operator: sap.ui.model.FilterOperator.Contains,
					value1: text
				});
				aFilters.push(filterPhases);
			}
			if (items.length !== 0) {
				this.getView().byId("actvtRegTbl").getBinding("rows").filter(aFilters);
			} else {
				this.getView().byId("actvtRegTbl").getBinding("rows").filter([]);
			}
			this.getView().byId("planItemSearch").setValue("");
			this.getView().byId("planItemsPhase").removeAllSelectedItems();
			this.getView().byId("planItemsActivityLead").removeAllSelectedItems();
			this.getView().byId("planItemsActivityRole").removeAllSelectedItems();
			this.setPlanningTableLength();
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleActivityRoleFilter: function (oEvent) {
			let aFilters = [];
			let items = oEvent.getSource().getSelectedItems();
			for (var i = 0; i < items.length; i++) {
				let text = items[i].getKey();
				let filterPhases = new Filter({
					path: "ParentRoleId",
					operator: sap.ui.model.FilterOperator.Contains,
					value1: text
				});
				aFilters.push(filterPhases);
			}
			if (items.length !== 0) {
				this.getView().byId("actvtRegTbl").getBinding("rows").filter(aFilters);
			} else {
				this.getView().byId("actvtRegTbl").getBinding("rows").filter([]);
			}
			this.getView().byId("planItemSearch").setValue("");
			this.getView().byId("planItemsPhase").removeAllSelectedItems();
			this.getView().byId("planItemsActivityLead").removeAllSelectedItems();
			this.getView().byId("planItemsActivityStatus").removeAllSelectedItems();
			this.setPlanningTableLength();
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onGroupPress: function (oEvent) {
			const oView = this.getView();
			const oSlDefaultModel = this.getView().getModel("slDefaultModel");
			this._oAvatarGroup = oEvent.getSource();
			let iItemsCount = (oSlDefaultModel.getProperty("/ActivityDetails/to_slwrapper/results/0/to_team/results")).length,
				sGroupType = oEvent.getParameter("groupType"),
				iAvatarsDisplayed = oEvent.getParameter("avatarsDisplayed"),
				oEventSource,
				sTitle;

			if (sGroupType === "Group") {
				oEventSource = oEvent.getSource();
			} else {
				oEventSource = oEvent.getParameter("eventSource");
			}

			sTitle = "Team Members (" + iItemsCount + ")";
			this.oAvatarSettingsModel.setData({
				"popoverTitle": sTitle
			});

			if (!this._pAvatarGroupPopover) {
				this._pAvatarGroupPopover = Fragment.load({
					id: oView.getId(),
					name: "com.presalescentral.successline.fragments.AvatarGroupPopover",
					controller: this
				}).then(function (oGroupPopover) {
					oView.addDependent(oGroupPopover);
					return oGroupPopover;
				});
			}
			this._pAvatarGroupPopover.then(function (oGroupPopover) {
				var oNavCon = this.byId("avatarGroupNavCon"),
					oMainPage = this.byId("avatarGroupMain"),
					aContent = this._getContent(sGroupType, iAvatarsDisplayed),
					iNumberOfAvatarsInPopover = aContent.length;

				// Every cell has 68px height + 40px from Popover's header and 8px top margin of the VerticalColumnLayout
				this._sGroupPopoverHeight = (Math.floor(iNumberOfAvatarsInPopover / 2) + iNumberOfAvatarsInPopover % 2) * 68 + 48 + "px";
				this.oAvatarGroupModel.setData(aContent);
				oGroupPopover.setContentHeight(this._sGroupPopoverHeight);
				oNavCon.to(oMainPage);
				oGroupPopover.openBy(oEventSource).addStyleClass("sapFAvatarGroupPopover");
			}.bind(this));
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_getContent: function (sGroupType, iAvatarsDisplayed) {
			var aTeam = this.getView().getModel("slDefaultModel").getProperty("/SuccessLine/ActivityDetailsInfo/wrapper/to_team/results");
			return aTeam.map(function (oAvatarGroupItem) {
				return this._getAvatarModel(oAvatarGroupItem);
			}, this);
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_getAvatarModel: function (oBindingInfo, oAvatarGroupItem) {
			return {
				src: "",
				initials: oBindingInfo.NAME_FIRST.charAt(0) + oBindingInfo.NAME_LAST.charAt(0),
				fallbackIcon: "",
				name: oBindingInfo.NAME,
				id: oBindingInfo.ID,
				jobPosition: "",
				mobile: oBindingInfo.MobileNumber,
				phone: oBindingInfo.PhoneNumber,
				email: oBindingInfo.EMAIL
			};
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onAvatarPress: function (oEvent) {
			var oBindingInfo = oEvent.getSource().getBindingContext("groupedAvatars").getObject(),
				oNavCon = this.byId("avatarGroupNavCon"),
				oDetailPage = this.byId("avatarGroupDetail"),
				oGroupPopover = this.byId("groupPopover");

			oGroupPopover.setContentHeight("375px");
			oGroupPopover.setContentWidth("450px");
			this.oIndividualModel.setData(oBindingInfo);
			oNavCon.to(oDetailPage);
			oGroupPopover.focus();
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onAvatarNavBack: function () {
			var oNavCon = this.byId("avatarGroupNavCon");
			this.byId("groupPopover").setContentHeight(this._sGroupPopoverHeight);
			oNavCon.back();
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onAvatarViewDetails: function (oEvent) {
			const sUserId = oEvent.getSource().data("id");
			window.open(this.ConstantsMap["0071"].field_value + sUserId);
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onAvatarSendMailClick: function (oEvent) {
			const email = oEvent.getSource().getText();
			sap.m.URLHelper.triggerEmail(email);
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onAvatarCallClick: function (oEvent) {
			const mobileNumber = oEvent.getSource().getText();
			sap.m.URLHelper.triggerTel(mobileNumber);
		},

		openActivityToolsTip: function (oElement, bIsMaxLen) {
			let that = this;
			let oView = this.getView();
			if (!that.toolstipDialog) {
				that.toolstipDialog = Fragment.load({
					id: oView.getId(),
					name: "com.presalescentral.successline.fragments.PresActivityToolstip",
					controller: that
				}).then(function (oGroupPopover) {
					oView.addDependent(oGroupPopover);
					return oGroupPopover;
				});
			}
			that.toolstipDialog.then(function (oGroupPopover) {
				if (bIsMaxLen) {
					oGroupPopover.addEventDelegate({
						"onAfterRendering": function () {
							oView.byId("idTooltipPopOver").setContentWidth("50%");
						}
					});
				} else {
					oGroupPopover.addEventDelegate({
						"onAfterRendering": function () {
							oView.byId("idTooltipPopOver").setContentWidth("13%");
						}
					});
				}
				oGroupPopover.openBy(oElement);
			}.bind(that));

		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		openActivityDetailsPopOver: function (oElement) {
			let that = this;
			const oView = this.getView();
			that.bShowMethod = true;
			const oSlDefaultModel = this.getView().getModel("slDefaultModel");
			let sFormLayoutId = oSlDefaultModel.getProperty("/SuccessLine/ActivityDetailsInfo/wrapper/FormLayoutId");
			if (sFormLayoutId === '00027') {
				that.bShowMethod = false;
			}
			let iItemsCount = (oSlDefaultModel.getProperty("/SuccessLine/ActivityDetailsInfo/wrapper/to_team/results")).length,
				sTitle;
			sTitle = "Team Members (" + iItemsCount + ")";
			this.oAvatarSettingsModel.setData({
				"popoverTitle": sTitle
			});

			if (!that.PresActvtDetailDialog) {
				that.PresActvtDetailDialog = Fragment.load({
					id: oView.getId(),
					name: "com.presalescentral.successline.fragments.ActivityDetailsPopOver",
					controller: that
				}).then(function (oGroupPopover) {
					oView.addDependent(oGroupPopover);
					return oGroupPopover;
				});
			}
			that.PresActvtDetailDialog.then(function (oGroupPopover) {
				//to check if the activity is cvj to hide method
				if (that.bShowMethod === false) {
					oView.byId("idActivityMethod").setVisible(false);
				} else {
					oView.byId("idActivityMethod").setVisible(true);
				}
				var oNavCon = that.byId("presGroupNavCon"),
					oMainPage = that.byId("presGroupMain");
				oNavCon.to(oMainPage);
				oGroupPopover.openBy(oElement).addStyleClass("sapFAvatarGroupPopover");
			}.bind(that));

		},
		onOpenToolstip: function (oEvent) {
			const oElement = oEvent.getParameter("element");
			const sSubtitle = oEvent.getParameter("activitySubtitle");
			let bIsMaxLen = false;
			if (sSubtitle.length > 250) {
				bIsMaxLen = true;
			}
			const oSlDefaultModel = this.getView().getModel("slDefaultModel");
			const sEventType = oEvent.getParameter("eventType");
			oSlDefaultModel.setProperty("/SuccessLine/subtitleText", sSubtitle);
			if (sSubtitle === "") {
				return;
			} else {
				if (sEventType === "mouseleave") {
					this.handleCloseToolTip(oEvent);
				} else {

					this.openActivityToolsTip(oElement, bIsMaxLen);
				}
			}
		},
		handleCloseToolTip: function (oEvent) {
			this.byId("idTooltipPopOver").close();
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onOpenDetail: function (oEvent) {
			const oElement = oEvent.getParameter("element");
			const sActivityId = oEvent.getParameter("activityId");
			const sActivityType = oEvent.getParameter("type");
			const oSlDefaultModel = this.getView().getModel("slDefaultModel");
			let that = this;
			let aActivities = oSlDefaultModel.getProperty("/SuccessLine/Activities");
			oSlDefaultModel.setProperty("/SuccessLine/ActivityDetailsInfo", {});
			aActivities.filter((item) => {
				if (item.ActivityId === sActivityType && item.ActGuid === sActivityId) {
					oSlDefaultModel.setProperty("/SuccessLine/ActivityDetailsInfo/ActLead", item.ActLead);
					oSlDefaultModel.setProperty("/SuccessLine/ActivityDetailsInfo/Title", item.Title);
					let sSubtitle = "<em>" + item.SubTitle + "</em>";
					oSlDefaultModel.setProperty("/SuccessLine/ActivityDetailsInfo/SubTitle", sSubtitle);
					oSlDefaultModel.setProperty("/SuccessLine/ActivityDetailsInfo/IconUrl", item.IconUrl);
					oSlDefaultModel.setProperty("/SuccessLine/ActivityDetailsInfo/IconColor", item.IconColor);
					oSlDefaultModel.setProperty("/SuccessLine/ActivityDetailsInfo/StatusDescription", item.StatusDescription);
					oSlDefaultModel.setProperty("/SuccessLine/ActivityDetailsInfo/RiskDesc", item.RiskDesc);
					oSlDefaultModel.setProperty("/SuccessLine/ActivityDetailsInfo/CompDate", item.CompDate);
					if (item.to_slwrapper.results) {
						oSlDefaultModel.setProperty("/SuccessLine/ActivityDetailsInfo/RiskComment", item.to_slwrapper.results[0].RiskComment);
					}
					if (!item.to_slwrapper.results) {
						that.getOwnerComponent().getModel("appSettings").setProperty("/isItemBusy", true);
						SLService.getWrapperDetails(sActivityType, sActivityId).then((wrpData) => {
							let oData = wrpData.data.results[0];
							oSlDefaultModel.setProperty("/SuccessLine/ActivityDetailsInfo/RiskComment", oData.RiskComment);
							that.getView().getModel("slDefaultModel").setProperty("/SuccessLine/ActivityDetailsInfo/wrapper", oData);
							that.getOwnerComponent().getModel("appSettings").setProperty("/isItemBusy", false);
							that.openActivityDetailsPopOver(oElement);
						});
					} else {
						oSlDefaultModel.setProperty("/SuccessLine/ActivityDetailsInfo/wrapper", item.to_slwrapper.results[0]);
						that.openActivityDetailsPopOver(oElement);
					}
				}
			});
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onSelectElement: function (oEvent) {
			const sType = oEvent.getParameter("type");
			const sPhaseId = oEvent.getParameter("phaseId");
			const sTchpointGuid = oEvent.getParameter("serviceId");
			const sActivityId = oEvent.getParameter("activityId");
			const sTouchpointId = oEvent.getParameter("touchpointId");
			let sLevel = sType.toUpperCase();

			let selectedObj = {
				PhaseId: sPhaseId,
				TpointId: sTouchpointId,
				ActGuid: sActivityId,
				TchpointGuid: sTchpointGuid
			};

			this.detailSectionSelection(sLevel, selectedObj);
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onActvtGroupPress: function (oEvent) {
			const oSlDefaultModel = this.getView().getModel("slDefaultModel");
			this._oAvatarGroup = oEvent.getSource();
			let iItemsCount = (oSlDefaultModel.getProperty("/SuccessLine/ActivityDetailsInfo/wrapper/to_team/results")).length;
			let sTitle = "Team Members (" + iItemsCount + ")";
			this.oAvatarSettingsModel.setData({
				"popoverTitle": sTitle
			});
			var oNavCon = this.byId("presGroupNavCon"),
				oDetailPage = this.byId("presGroupMain1"),
				oGroupPopover = this.byId("actvtgroupPopover"),

				aContent = this._getContent();
			this.oPresentationAvatarGroupModel.setData(aContent);
			oNavCon.to(oDetailPage);
			oGroupPopover.focus();
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onPresAvatarPress: function (oEvent, width = "450px", height = "300px") {
			var oBindingInfo = oEvent.getSource().getBindingContext("presentationGroupedAvatars").getObject(),
				oNavCon = this.byId("presGroupNavCon"),
				oDetailPage = this.byId("presGroupDetail"),
				oGroupPopover = this.byId("actvtgroupPopover");
			this.oIndividualModel.setData(oBindingInfo);
			oNavCon.to(oDetailPage);
			oGroupPopover.focus();
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onPresAvatarNavBack: function (oEvent) {
			var oNavCon = this.byId("presGroupNavCon");
			oNavCon.back();
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onSaveSettings: function (oEvent) {
			let sData = this.getView().getModel("presentationSettingsModel").getProperty("/presData");
			let arr = [];
			for (var items in sData) {
				arr.push(sData[items]);
			}
			let data = {
				'Userid': this.Component.getModel("user").getProperty("/UserId"),
				'to_psetng': arr
			};
			SLService.updatePresentationSettings(data).then((result) => {
				MessageToast.show("Presentation settings saved successfully!");
			});
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_getPresentationSettings: function () {
			let sData;
			SLService.getPresentationSettings().then((result) => {
				sData = result.data.results[0].to_psetng.results;
				let sPresentationSettings = {};

				for (var i = 0; i < sData.length; i++) {
					if (!sPresentationSettings[sData[i].OptionId]) {

						sPresentationSettings[sData[i].OptionId] = sData[i];
					}
				}
				this.getView().getModel("presentationSettingsModel").setProperty("/presData", sPresentationSettings);

			});
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onSelectTab: function (oEvent) {
			const sKey = oEvent.getParameter("key");
			const oIconTab = this.getView().byId("idPlanItemsIconTabBarNoIcons");
			if (sKey === "presentation") {
				const data = this.getView().getModel("slDefaultModel").getProperty("/SuccessLineHierarchy/Phases");
				this.setPlanningTableLength();
				const oChart = this.getView().byId("presentationChart");
				oChart.updateChart();
				oIconTab.setStretchContentHeight(false);
			} else {
				let sRiskDesc = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails/RiskDesc");
				this.setRiskColor(sRiskDesc, 100);
				this.getView().getModel("slDefaultModel").refresh(true);
				oIconTab.setStretchContentHeight(true);
				this.setPlanningTableLength();
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onToggleExpandAll: function (oEvent) {
			const bExpanded = oEvent.getParameter("expanded");
			var oTreeTable = this.getView().byId("actvtRegTbl");
			if (!bExpanded) {
				oTreeTable.collapseAll();
			} else {
				oTreeTable.expandToLevel(2);
			}
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onToggleActivityStatus: function (oEvent) {
			const bState = oEvent.getParameter("state");
			var oTreeTable = this.getView().byId("actvtRegTbl");
			oTreeTable.expandToLevel(2);
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onToggleDataLines: function (oEvent) {
			const bState = oEvent.getParameter("state");
			var oTreeTable = this.getView().byId("actvtRegTbl");
			oTreeTable.expandToLevel(2);
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onToggleAutoHide: function (oEvent) {
			const bExpanded = oEvent.getParameter("expanded");
			const phases = oEvent.getParameter("phases");
			var oTreeTable = this.getView().byId("actvtRegTbl");
			var oRows = oTreeTable.getRows();
			var iRowIndex = null;
			var aPhases = [];
			for (var i = 0; i < phases.length; i++) {
				for (var j = 0; j < oRows.length; j++) {
					var oContext = oRows[j].getBindingContext("slDefaultModel");
					if (oContext) {
						var oRow = oContext.getObject();
						if (phases[i] === oRow.PhaseId && oRow.Level === 'PHASE') {
							iRowIndex = oRows[j].getIndex();
							aPhases.push(iRowIndex);
						}
					}
				}

			}
			if (!bExpanded) { //collapse phases
				oTreeTable.collapse(aPhases);
			}

		},
		/**
		 * Navigate to CRM for account
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		navToCRMwithCvaAccnt: function () {
			this.navToCRM();
		},
		/**
		 * Open Rapid registration form
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		openRapidRegistration: function (statusId, oActv, oSource) {
			var that = this;
			var formLayoutId = oActv.frmlayout_id;
			//get default time values
			this.fnGetSelectedActMTRTask(oActv).then(function (data) {
				that.getTimeEntryDefaultValues(oActv);
			});
			//get phase masterdata based on type id and role mpng id
			var isCvjPhaseVisible = this.Component.getModel("masterData").getProperty("/SelectedLayout/CVJPhase/Visible");
			if (isCvjPhaseVisible) {
				this.getCVJPhaseMaster(oActv);
			}
			this.SlDetailModel.setProperty("/isEditMode", oActv.RegisteredActId ? true : false);
			/*	var isSolDataRecieved = this.oSolutionsModel.getProperty("/isSolDataRecieved");
				if (!isSolDataRecieved && (formLayoutId === "00001" || formLayoutId === "00024")) {
					this.getLevel2MasterData();
					this.getSolutionHierarchy();
			}*/

			if (oActv.ActivityId === "0108") {
				this._setActivitySelected(oActv.PhaseId, oActv.TpointId, oActv.ActGuid);
				setTimeout(() => {
					let sActv = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails");
					this._openRapidReg(statusId, sActv, oSource);
				}, 1000);
			} else {
				this._openRapidReg(statusId, oActv, oSource);
			}
		},

		getFormLayoutData: function (childFormLayoutId) {
			var that = this;
			var aFilter = [new Filter("FormLayoutID", "EQ", childFormLayoutId)];
			SLService.getLayoutData(aFilter).then(function (result) {
				var oData = result.data.results[0];
				if (oData) {
					var aLayoutFields = JSON.parse(oData.FormLayoutString).Fields;
					var oMasterDataModel = that.getOwnerComponent().getModel("masterData");
					oMasterDataModel.setProperty("/SelectedLayout", aLayoutFields);
					// oMasterDataModel.setProperty("/FormLayoutId", oData.FormLayoutID);
					oMasterDataModel.refresh(true);
				}
			});
		},

		getCVJPhaseMaster: function (oActv) {
			var that = this;
			var aFilter = [];
			var sActTypeId = oActv.ActivityId;
			var RoleMpngID = this.getModel("slDefaultModel").getProperty("/SuccessLine/ActivityRole");
			if (sActTypeId) {
				aFilter.push(new Filter("Acttypeid", "EQ", sActTypeId));
			}
			if (RoleMpngID) {
				aFilter.push(new Filter("RoleMpngID", "EQ", RoleMpngID));
			}
			SLService.getCVJPhaseMaster(aFilter).then(function (result) {
				var data = result.data.results;
				that.getOwnerComponent().getModel("masterData").setProperty("/CvjPhaseMaster", data);
				var isEditMode = that.SlDetailModel.getProperty("/isEditMode");
				if (!isEditMode) {
					var defaultCvjId = "";
					if (data && data.length === 1) {
						defaultCvjId = data[0].CvjPhaseId;
					} else {
						data.filter(function (item) {
							if (item.DefaultCVJ === "X") {
								defaultCvjId = item.CvjPhaseId;
							}
						});
					}
					that.SlDetailModel.setProperty("/CvjPhaseId", defaultCvjId);
				}
			});
		},

		getDemoLandScapes: function () {
			var oLTypeMap = {};
			var that = this;
			this.landscapeMap = {};
			SLService.getDemoLandScapes().then(function (result) {
				var data = result.data.results;
				for (var i in data) {
					if (!oLTypeMap.hasOwnProperty(data[i].Ltype) && data[i].LTypeDescription !== "") {
						oLTypeMap[data[i].Ltype] = data[i].LTypeDescription;
					}
					if (that.landscapeMap.hasOwnProperty(data[i].LandsId) && data[i].SelectionCat === "Master") {
						data[i].selected = true;
						data[i].prevSelected = true;
					} else {
						data[i].selected = false;
						data[i].prevSelected = false;
					}
				}
				data = that.fnFormatFlatToTreeData(data, "SelectionCat");
				data = that.fnRestructureTreeData(data, "SelectionCat", "landscape");
				that.Component.getModel("masterData").setProperty("/LTypeMap", oLTypeMap);
				that.Component.getModel("masterData").setProperty("/landscape", data);
				that.RapidRegistration.fnDemoEnvSortMenuAction();
				if (that.byId("idLandscapeTable")) {
					that.byId("idLandscapeTable").setBusy(false);
				}
				that.RapidRegistration.fnDemoEnvExpandCollapseAll("", "landscape", "landscapeSearchField", true);
				that.RapidRegistration.fnSetSAPDemoECSelectAll("landscape", "isLandscapeSelectAll");
			});
		},

		//Function to format flat to tree structure data
		fnFormatFlatToTreeData: function (oData, property, removeRecentSelections) {
			return oData.reduce(function (acc, obj) {
				var key = obj[property];
				if (!acc[key]) {
					acc[key] = [];
				}
				// Add object to list for given key's value
				if ((removeRecentSelections && obj.SelectionCat !== "Recent Selection") || !removeRecentSelections)
					acc[key].push(obj);
				return acc;
			}, {});
		},

		//Function to group data in tree structure
		fnRestructureTreeData: function (oData, oFieldProperty, oArrayProperty) {
			var oTempArr = [];
			var oKeys = Object.keys(oData);
			for (var i = 0; i < oKeys.length; i++) {
				var oTempObj = {};
				oTempObj["isParent"] = true;
				oTempObj["isExpanded"] = true;
				oTempObj[oFieldProperty] = oKeys[i];
				oTempObj[oArrayProperty] = oData[oKeys[i]];
				oTempArr.push(oTempObj);
			}
			return oTempArr;
		},

		getTimeEntryDefaultValues: function (oActvt) {
			var roleMpngId;
			var that = this;
			var activityTypeId = oActvt.ActivityId;
			var UserGuid = sap.ui.getCore().getModel("mtrSettings").getProperty("/UserGuid");
			var ActivityId = (oActvt.RegisteredActId) ? parseInt(oActvt.RegisteredActId).toString() : "";
			var oMTRModel = this.getOwnerComponent().getModel("oMTRModel");
			oMTRModel.setProperty("/sDefaultValuesState", "");

			var aFilter = [];
			aFilter.push(new Filter("UserGuid", "EQ", UserGuid));
			aFilter.push(new Filter("ActvtType", "EQ", activityTypeId));
			if (ActivityId) {
				aFilter.push(new Filter("ActivityId", "EQ", ActivityId));
			}

			if (!ActivityId) {
				roleMpngId = this.getModel("slDefaultModel").getProperty("/SuccessLine/ActivityRole");
			} else {
				roleMpngId = oActvt.RoleMpngID;
			}
			if (roleMpngId) {
				aFilter.push(new Filter("RoleMpngID", "EQ", roleMpngId));
			}

			var associateType = oActvt.ActvtAsstdID;
			var AccountDetails = this.SlDetailModel.getProperty("/SelectedOpportunity");
			if (AccountDetails) {
				if (associateType === "501" || associateType === "502") {
					aFilter.push(new Filter("SaleSegType", "EQ", AccountDetails["SEGMENT"]));
				}
			}

			if (associateType === "503") {
				aFilter.push(new Filter("SaleSegType", "EQ", "NA"));
			}
			MtrService.getTimeEntryDefaultValues(aFilter).then(function (result) {
				var bVal = false;
				var estimatedHrs = "0.0";
				var ncfEstimatedHrs = "0.0";
				var oData = result.data.results;
				// let oMTRModel = that.getOwnerComponent().getModel("oMTRModel");
				var aMTRTasks = oMTRModel.getProperty("/aMTRTasks");

				if (oData.length) {
					oData.filter(function (obj) {
						if (obj["CustomerFacing"] === "X") {
							estimatedHrs = obj["EstimatedHrs"];
						} else if (obj["CustomerFacing"] === "") {
							ncfEstimatedHrs = obj["EstimatedHrs"];
						}
					});
				}

				estimatedHrs = that.fnConvertHoursToDays(estimatedHrs);
				ncfEstimatedHrs = that.fnConvertHoursToDays(ncfEstimatedHrs);
				oMTRModel.setProperty("/IsCustomerFacing", bVal);
				oMTRModel.setProperty("/EstimatedTime", estimatedHrs);
				oMTRModel.setProperty("/ReqEstimatedTime", estimatedHrs);
				oMTRModel.setProperty("/PrevReqEstimatedTime", estimatedHrs);
				oMTRModel.setProperty("/CFEstimatedTime", "0.0");
				oMTRModel.setProperty("/NCFEstimatedTime", ncfEstimatedHrs);
				oMTRModel.setProperty("/AlterCustomerFacing", !bVal);

				if (aMTRTasks && aMTRTasks.length === 1) {
					oMTRModel.setProperty("/NCFEstimatedTime", ncfEstimatedHrs);
					oMTRModel.setProperty("/AlterCustomerFacing", false);
					oMTRModel.setProperty("/EstimatedTime", "0.0");
				}
				oMTRModel.setProperty("/sDefaultValuesState", "SUCCESS");
			}).catch((error) => {
				oMTRModel.setProperty("/sDefaultValuesState", "ERROR");
			});

		},

		//Function to convert hours to days
		fnConvertHoursToDays: function (sHours) {
			var days = 0;
			var mtrSettings = sap.ui.getCore().getModel("mtrSettings");
			var timeMatrix = mtrSettings.getProperty("/TimeMatrics");
			if (timeMatrix === "D") {
				sHours = parseFloat(sHours, 1);
				days = sHours / 8;
				var oDecimals = days - Math.floor(days);
				if (oDecimals === 0 || oDecimals > 0.5) {
					days = Math.round(days);
				} else if (oDecimals > 0 && oDecimals < 0.5) {
					days = Math.round(days) + 0.5;
				}
				return days.toString();
			} else {
				return sHours;
			}
		},

		/**
		 * Open Rapid registration form
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		_openRapidReg: function (statusId, oActv, oSource) {
			this.getView().getModel("slDefaultModel").setProperty("/SuccessLine/Menu", false);
			this.tpDetailStorage.put("oTpDetails", undefined);
			this.handleRapidRegistration(statusId, oActv, oSource);
		},
		/**
		 * On expand and collapse of presentation chart
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onPresentationChartExpandCollapse: function (oEvent) {
			const oParameters = oEvent.getParameters();
			let expanded, phaseId, serviceId, touchpointId;
			expanded = oParameters.expanded;
			phaseId = oParameters.phaseId;
			serviceId = oParameters.serviceId;
			touchpointId = oParameters.touchpointId;
			let collapsed = true;
			if (expanded) {
				collapsed = false;
			}
			var oTreeTable = this.getView().byId("actvtRegTbl");
			var oRows = oTreeTable.getRows();
			var iRowIndex = null;
			var sPath;
			for (var i = 0; i < oRows.length; i++) {
				var oRow = oRows[i].getBindingContext("slDefaultModel").getObject();
				if (serviceId === '' && oRow.PhaseId === phaseId) {
					iRowIndex = oRows[i].getIndex();
					sPath = oRows[i].getBindingContext("slDefaultModel").getPath();
					this.getView().getModel("slDefaultModel").setProperty(sPath + "/collapsed", collapsed);
					oRow.collapsed = collapsed;
					if (expanded) {
						oTreeTable.expand(iRowIndex);
					} else {
						oTreeTable.collapse(iRowIndex);
					}
					this.synchPresentationModel('PHASE', oRow, 'expand');
					return;
				} else if (oRow.PhaseId === phaseId && oRow.TpointId === touchpointId && oRow.TchpointGuid === serviceId) {
					iRowIndex = oRows[i].getIndex();
					sPath = oRows[i].getBindingContext("slDefaultModel").getPath();
					this.getView().getModel("slDefaultModel").setProperty(sPath + "/collapsed", collapsed);
					oRow.collapsed = collapsed;
					if (expanded) {
						oTreeTable.expand(iRowIndex);
					} else {
						oTreeTable.collapse(iRowIndex);
					}
					this.synchPresentationModel('SERVICE', oRow, 'expand');
					return;
				}
			}
		},

		//function to open outcome archieved fragment in header
		onHandlePopupOutcomeServiceDetails: function (oEvent) {
			let oSLDefaultModel = this.getView().getModel("slDefaultModel");
			if (!this.OutcomeAchievedPopOver) {
				this.OutcomeAchievedPopOver = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.OutcomeDetails",
					this);
				this.getView().addDependent(this.OutcomeAchievedPopOver);
			}
			this.OutcomeAchievedPopOver.openBy(oEvent.getSource());
			this.SlDetailModel.refresh();
		},

		//function to handle edit notes
		onEditServiceNotes: function (sObj) {
			this._handleEditServiceNotesVisibility(sObj, true);
		},

		//function to handle edit Notes visibility
		_handleEditServiceNotesVisibility: function (oTouchPnts, isVisible, sUpdatedNotes) {
			let oServices = this.getView().getModel("slDefaultModel").getProperty("/TouchPointDetails");
			oServices.isNoteEditable = isVisible;
			if (sUpdatedNotes !== undefined) {
				oServices.TchpntNotes = sUpdatedNotes;
			}
			oServices.notes = oServices.TchpntNotes;
			this.getView().getModel("slDefaultModel").refresh(true);
		},

		//function to handle close SO Notes
		handleCloseSONote: function (oEvent) {
			const oModel = this.getModel("slDefaultModel");
			const oTouchPoint = $.extend(true, {}, oModel.getProperty("/TouchPointDetails"));
			this._handleEditServiceNotesVisibility("", false, oTouchPoint.TchpntNotes);
		},

		//function to update Service Outcome Notes
		handleUpdateSONote: function (oEvent) {
			let that = this;
			const oModel = this.getModel("slDefaultModel");
			const oTouchPoint = this.getView().getModel("slDefaultModel").getProperty("/TouchPointDetails");
			let oSONotes;
			oSONotes = {
				Active: oTouchPoint.Active,
				Description: oTouchPoint.Description,
				IconUrl: oTouchPoint.IconUrl,
				PhaseId: oTouchPoint.PhaseId,
				PhaseTitle: oTouchPoint.PhaseTitle,
				ServiceTypeDesc: oTouchPoint.ServiceTypeDesc,
				ServiceTypeID: oTouchPoint.ServiceTypeID,
				SlId: oTouchPoint.SlId,
				SlSnro: oTouchPoint.SlSnro,
				Source: oTouchPoint.Source,
				StatusDescription: oTouchPoint.StatusDescription,
				StatusId: oTouchPoint.StatusId,
				TPointCompletion: oTouchPoint.TPointCompletion.toString(),
				TchpntNotes: oTouchPoint.notes,
				TchpointGuid: oTouchPoint.TchpointGuid,
				TempId: oTouchPoint.TempId,
				TempTpointGuid: oTouchPoint.TempTpointGuid,
				TpointId: oTouchPoint.TpointId,
				TpointTitle: oTouchPoint.TpointTitle,
				Weight: oTouchPoint.Weight,
				SrvStatusId: oTouchPoint.SrvStatusId
			};
			SLService.updateSOTouchPointData(oSONotes).then((oData) => {
				MessageToast.show("Notes Updated");
				this._handleEditServiceNotesVisibility(oSONotes, false, oSONotes.TchpntNotes);
				this.oStoreSOData = jQuery.extend(true, {}, oSONotes);
			});

		},

		//function to handle SL Detail service attachments
		onServiceOutcomeAttachmentsEdit: function (oEvent) {
			if (!this.SLDetialSOAttachPopOver) {
				this.SLDetialSOAttachPopOver = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.SOAttachments",
					this);
				this.getView().addDependent(this.SLDetialSOAttachPopOver);
			}
			this.SlDetailModel.setProperty("/isSOAttchmntBusy", true);
			this.SLDetialSOAttachPopOver.openBy(oEvent.getSource());
			const oModel = this.getModel("slDefaultModel");
			let oService = this.getView().getModel("slDefaultModel").getProperty("/TouchPointDetails");
			let aExistingSOAttachment = $.extend(true, [], oModel.getProperty("/aSOAttachments"));
			if (!aExistingSOAttachment.length) {
				this.SlDetailModel.setProperty("/aExistingSOAttachment", aExistingSOAttachment);
			}
			if (!aExistingSOAttachment.length) {
				aExistingSOAttachment = [{
					"TchpointGuid": oService.TchpointGuid,
					"LinkTypeId": 7,
					"LinkId": "",
					"LinkTitle": "",
					"Link": "",
					"LinkTypeDesc": "",
					"TpLinkActive": true,
					"AddRemove": "X"
				}];
			}
			aExistingSOAttachment[aExistingSOAttachment.length - 1].AddRemove = "X";
			this.SlDetailModel.setProperty("/aExistingSOAttachment", aExistingSOAttachment);
			this.SlDetailModel.setProperty("/isSOAttchmntBusy", false);
			this.SlDetailModel.refresh(true);
		},

		//function to close the SO Attachment Fragment
		onSOAttchmntCancel: function () {
			this.SLDetialSOAttachPopOver.close();
		},

		//Function to add Link to SO Attahchments
		handleSOAttchAddLink: function (oEvent) {
			let aTemp = [];
			let bIsLinkEmpty = false;
			let aExistingSOAttachment = this.SlDetailModel.getProperty("/aExistingSOAttachment");
			let oServiceData = oEvent.getSource().getBindingContext("SlDetailModel").getObject();
			let oNewLink = {
				"TchpointGuid": oServiceData.TchpointGuid,
				"LinkTypeId": 7,
				"LinkId": "",
				"LinkTitle": "",
				"Link": "",
				"LinkTypeDesc": "",
				"TpLinkActive": true,
				"AddRemove": "X"
			};
			//validations
			aExistingSOAttachment.filter((item) => {
				if (item.TpLinkActive === true) {
					aTemp.push(item);
					bIsLinkEmpty = item.Link ? false : true;
				}
			});
			aTemp.filter((item) => {
				if (!item.Link) {
					bIsLinkEmpty = true;
					return;
				}
			});
			if (aTemp.length < 5) {
				if (!bIsLinkEmpty) {
					aExistingSOAttachment.filter((item) => {
						item.AddRemove = "";
					});
					aExistingSOAttachment.push(oNewLink);
				} else {
					let bErrors = this._validateEmptyLinks("idSOAttchmnts");
					if (bErrors) {
						return false;
					}
				}

			} else {
				MessageToast.show("You can add a maximum of five(5) attachment links.");
			}

			this.SlDetailModel.refresh();
		},

		//Function to Remove Link to SO Attahchments
		handleRemoveSOAttchLink: function (oEvent) {
			let bSaveTrigger = false;
			let aExistingSOAttachment = this.SlDetailModel.getProperty("/aExistingSOAttachment");
			aExistingSOAttachment.filter((item) => {
				if (item.TpLinkActive === true) {
					bSaveTrigger = item.LinkId ? true : false;
				}
			});
			var aIndex = oEvent.getParameter("id").split("-");
			var sIndex = aIndex[aIndex.length - 1];
			this.SlDetailModel.setProperty("/aExistingSOAttachment" + "/" + sIndex + "/TpLinkActive", false);
			let aTemp = [];
			aExistingSOAttachment.filter((item) => {
				if (item.TpLinkActive === true) {
					aTemp.push(item);
				}
			});
			if (aTemp.length) {
				aTemp[aTemp.length - 1].AddRemove = "X";
			}
			this.removeLinkFromAttachments(oEvent);
			this.SlDetailModel.refresh();
			if (aTemp.length === 0 && bSaveTrigger) {
				this.onSaveSOAttachments();
			} else {
				if (aTemp.length === 0) {
					this.SLDetialSOAttachPopOver.close();
				}
			}
		},

		//function to save Service Outcome Attachments
		onSaveSOAttachments: function (oEvent) {
			let bErrors = this._validateEmptyLinks("idSOAttchmnts");
			if (!bErrors) {
				this.SlDetailModel.setProperty("/isSOAttchmntBusy", true);
				let aExistingSOAttachment = this.SlDetailModel.getProperty("/aExistingSOAttachment");
				aExistingSOAttachment.filter((item) => {
					delete item.AddRemove;
				});
				SLService.updateSOAttachments(aExistingSOAttachment).then((oData) => {
					const oModel = this.getModel("slDefaultModel");
					let oTouchPointData = $.extend(true, {}, oModel.getProperty("/TouchPointDetails"));
					let aTemp = [];
					oData.filter((item) => {
						aTemp.push(item.data);
					});
					let aActiveSOLinks = [];
					aTemp.filter((item, index) => {
						if (item.TpLinkActive === true) {
							item.AttachCat = "S";
							item.PhaseId = oTouchPointData.PhaseId;
							item.TpointId = oTouchPointData.TpointId;
							item.SlId = oTouchPointData.SlId;
							item.SlSnro = oTouchPointData.SlSnro;
							item.weight = "000";
							aActiveSOLinks.push(item);
						}
					});
					if (aActiveSOLinks.length) {
						aActiveSOLinks[aActiveSOLinks.length - 1].AddRemove = "X";
					}
					this.SlDetailModel.setProperty("/aExistingSOAttachment", aActiveSOLinks);
					oModel.setProperty("/aSOAttachments", aActiveSOLinks);
					this.aStoreSOAttachment = jQuery.extend(true, [], aTemp);
					this.SlDetailModel.setProperty("/isSOAttchmntBusy", false);
					oModel.refresh();
					this.SLDetialSOAttachPopOver.close();
					this.addNewLinkToAttachments(aActiveSOLinks);
				});
			}
		},

		//function to close the Outcome Achieved Popover
		onCloseOutcomeAchievedPopOver: function () {
			this.OutcomeAchievedPopOver.close();
		},

		//function to get All Service Outcome Achieved Data
		fnGetServiceOutcomeAchievedData: function () {
			const oModel = this.getModel("slDefaultModel");
			oModel.setProperty("/SOAchievedCount", "0");
			oModel.setProperty("/TotalSODataCount", "0");
			let oTouchPointData = $.extend(true, {}, oModel.getProperty("/TouchPointDetails"));
			let oSuccessLine = $.extend(true, {}, oModel.getProperty("/SuccessLine"));
			let aTouchPoints = $.extend(true, [], oSuccessLine.TouchPoints);
			let sStatusID = "01";
			let serviceTypeId = "0001";
			let aTotalSOData = aTouchPoints.filter((oData) => {
				if (oData.Active) {
					return oData.ServiceTypeID === serviceTypeId;
				}
			});
			let aSOAchievedData = aTotalSOData.filter((oData) => {
				return oData.StatusId === sStatusID;
			});
			oModel.setProperty("/TotalSODataCount", aTotalSOData.length);
			oModel.setProperty("/SOAchievedCount", aSOAchievedData.length);
			oModel.setProperty("/aSOAchievedDetails", aSOAchievedData);
			oModel.setProperty("/aTotalSOData", aTotalSOData);
			oModel.refresh();
		},

		//function to handle expand for Outcome Achieved Details Fragments
		onOverflowToolbarPress: function () {
			var oPanel = this.byId("expandablePanel");
			oPanel.setExpanded(!oPanel.getExpanded());
		},

		//function to handle Service Outcome Achieved Switch
		onSOAchievedSwitch: function (oEvent) {
			let that = this;
			const oModel = this.getModel("slDefaultModel");
			let bCurrentState = oEvent.getParameter("state");
			let oTouchPoint = $.extend(true, {}, oModel.getProperty("/TouchPointDetails"));
			let oSONotes = {
				Active: oTouchPoint.Active,
				Description: oTouchPoint.Description,
				IconUrl: oTouchPoint.IconUrl,
				PhaseId: oTouchPoint.PhaseId,
				PhaseTitle: oTouchPoint.PhaseTitle,
				ServiceTypeDesc: (bCurrentState) ? "Outcome Service" : oTouchPoint.ServiceTypeDesc,
				ServiceTypeID: oTouchPoint.ServiceTypeID,
				SlId: oTouchPoint.SlId,
				SlSnro: oTouchPoint.SlSnro,
				Source: oTouchPoint.Source,
				StatusDescription: oTouchPoint.StatusDescription,
				StatusId: (bCurrentState) ? "01" : "",
				TPointCompletion: oTouchPoint.TPointCompletion.toString(),
				TchpntNotes: oTouchPoint.TchpntNotes,
				TchpointGuid: oTouchPoint.TchpointGuid,
				TempId: oTouchPoint.TempId,
				TempTpointGuid: oTouchPoint.TempTpointGuid,
				TpointId: oTouchPoint.TpointId,
				TpointTitle: oTouchPoint.TpointTitle,
				Weight: oTouchPoint.Weight,
				IsAchivedBy: oTouchPoint.IsAchivedBy,
				IsAchivedAt: (oTouchPoint.IsAchivedAt) ? oTouchPoint.IsAchivedAt : new Date(),
				SrvStatusId: oTouchPoint.SrvStatusId,
				SrvStatusChangedAt: (oTouchPoint.SrvStatusChangedAt) ? oTouchPoint.SrvStatusChangedAt : new Date(),
				SrvStatusChangedBy: oTouchPoint.SrvStatusChangedBy
			};

			SLService.updateSOTouchPointData(oSONotes).then((oData) => {
				var oNavParams = {
					PhaseId: this.getModel("slDefaultModel").getProperty("/TouchPointDetails/PhaseId"),
					TpointId: this.getModel("slDefaultModel").getProperty("/TouchPointDetails/TpointId"),
					TchpointGuid: this.getModel("slDefaultModel").getProperty("/TouchPointDetails/TchpointGuid")
				};
				this.tpDetailStorage.put("oTpDetails", oNavParams);
				that.refreshSL();
				that.fnGetServiceOutcomeAchievedData();
			});
		},

		onSOStatusChange: function (oEvent) {
			let that = this;
			let sSrvStatusId = oEvent.getSource().getSelectedKey();
			const oModel = this.getModel("slDefaultModel");
			let oTouchPoint = $.extend(true, {}, oModel.getProperty("/TouchPointDetails"));
			let oSONotes = {
				Active: oTouchPoint.Active,
				PhaseId: oTouchPoint.PhaseId,
				ServiceTypeID: oTouchPoint.ServiceTypeID,
				SlId: oTouchPoint.SlId,
				SlSnro: oTouchPoint.SlSnro,
				Source: oTouchPoint.Source,
				StatusId: oTouchPoint.StatusId,
				TchpntNotes: oTouchPoint.TchpntNotes,
				TchpointGuid: oTouchPoint.TchpointGuid,
				TempId: oTouchPoint.TempId,
				TempTpointGuid: oTouchPoint.TempTpointGuid,
				TpointId: oTouchPoint.TpointId,
				Weight: oTouchPoint.Weight,
				SrvStatusId: sSrvStatusId,
				SrvStatusChangedAt: (oTouchPoint.SrvStatusChangedAt) ? oTouchPoint.SrvStatusChangedAt : new Date(),
				SrvStatusChangedBy: oTouchPoint.SrvStatusChangedBy
			};
			SLService.updateSOTouchPointData(oSONotes).then((oData) => {
				that.refreshSL();
			});
		},

		//function to update Tree Table, itemDetails & PresentationChart
		fnUpdateTreeItemChart: function (oServiceData) {
			const oModel = this.getModel("slDefaultModel");
			let aTreePhases = $.extend(true, [], oModel.getProperty("/SuccessLineHierarchy/Phases"));
			let oPresentationData = $.extend(true, {}, oModel.getProperty("/presentationData"));
			let aTouchPointData = $.extend(true, [], oModel.getProperty("/SuccessLine/TouchPoints"));
			let aPhases = [...oPresentationData.phases];
			let TpPhaseId = oServiceData.PhaseId;

			let iIndexTpointId = aTouchPointData.findIndex((oTpData) => {
				return oTpData.TpointId === oServiceData.TpointId;
			});

			let iIndexPhase = aPhases.findIndex((oPhase) => {
				return oPhase.id === TpPhaseId;
			});

			let iIndexTreePhaseId = aTreePhases.findIndex((oTree) => {
				return oTree.PhaseId === TpPhaseId;
			});

			if (iIndexTpointId !== -1) {
				aTouchPointData[iIndexTpointId].StatusId = oServiceData.StatusId;
			}

			if (iIndexPhase !== -1) {
				let aServices = [...aPhases[iIndexPhase].services];
				let iIndexService = aServices.findIndex((oService) => {
					return oService.id === oServiceData.TpointId;
				});
				if (iIndexService !== -1) {
					aServices[iIndexService].achieved = (oServiceData.StatusId === "01") ? true : false;
					aPhases[iIndexPhase].services = aServices;
					oPresentationData.phases = aPhases;
				}
			}

			if (iIndexTreePhaseId !== -1) {
				let aTreeServices = [...aTreePhases[iIndexTreePhaseId].results];
				let iIndexTreeService = aTreeServices.findIndex((oData) => {
					return oData.TpointId === oServiceData.TpointId;
				});
				if (iIndexTreeService !== -1) {
					aTreeServices[iIndexTreeService].achieved = (oServiceData.StatusId === "01") ? true : false;
					aTreeServices[iIndexTreeService].achievedStatusId = (oServiceData.StatusId === "01") ? "01" : "";
				}
				aTreePhases[iIndexTreePhaseId].results = aTreeServices;
			}

			return {
				"aTouchPointData": aTouchPointData,
				"oPresentationData": oPresentationData,
				"aTreePhases": aTreePhases
			};
		},

		//function to handle SLLead access
		fnSetSLLeadAccess: function () {
			let oModel = this.getModel("slDefaultModel");
			let currentUser = this.getView().getModel("user").getProperty("/UserId");
			let slLead = oModel.getProperty("/SuccessLine/SlLead");
			let bSlLeadAccess = false;
			if (currentUser === slLead) {
				bSlLeadAccess = true;
			}
			oModel.setProperty("/bSlLeadAccess", bSlLeadAccess);
			oModel.refresh(true);
		},
		/**
		 * Event to add service to selected phase
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleAddServiceToPhase: function (oEvent) {
			let that = this;
			const sSelectedService = oEvent.getSource().getBindingContext("slDefaultModel").getObject();
			const sPhaseDetails = this.getView().getModel("slDefaultModel").getProperty("/PhaseDetails");
			const oService = {
				SlId: sPhaseDetails.SlId,
				SlSnro: sPhaseDetails.SlSnro,
				TempId: sPhaseDetails.TempId,
				PhaseId: sPhaseDetails.PhaseId,
				TpointId: sSelectedService.TchpointId,
				TempTpointGuid: sSelectedService.TempTpointGuid
			};
			SLService.postService(oService).then((oData) => {
				that.addServiceDialog.close();
				that.refreshSL();
			});

		},
		/**
		 * Triggered on remove service action and to validate based on the status
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleRemoveServicePress: function (oEvent, sObj) {
			var that = this;
			var oSelectedService = this.getModel("slDefaultModel").getProperty("/TouchPointDetails");
			var result = "";
			var sAchieved, sIsCompleted, sIsPlanned, sIsRegistered, sIsRequired = "";
			var sComma = ",";
			var sAnd = "and";
			let message = "";
			let aText = [];
			let sServiceTitle = oSelectedService.TpointTitle;
			let aActivities = $.extend(true, [], oSelectedService.Activities);
			let aActivityStatus = aActivities.map((oRow) => {
				if (oRow.StatusDescription !== "Recommended") {
					return oRow.StatusDescription;
				}
			});
			aActivityStatus = [...new Set(aActivityStatus)];

			for (let j = 0; j < aActivityStatus.length; j++) {
				let sTempStatus = aActivityStatus[j];
				let sText = "";
				switch (sTempStatus) {
					case "Achieved":
						sText = "has an achieved outcome";
						aText.push(sText);
						break;
					case "Completed":
						sText = "has a completed activity";
						aText.push(sText);
						break;
					case "Registered":
						sText = "has a registered activity";
						aText.push(sText);
						break;
					case "Required":
						sText = "has a required activity";
						aText.push(sText);
						break;
					case "Planned":
						sText = "has a planned activity";
						aText.push(sText);
						break;
					case "Started":
						sText = "has a started activity";
						aText.push(sText);
						break;
					case "Progressing":
						sText = "has a progressing activity";
						aText.push(sText);
						break;
					case "Presented":
						sText = "has a presented activity";
						aText.push(sText);
						break;
					case "Validated":
						sText = "has a validated";
						aText.push(sText);
						break;
					case "Customer Validated":
						sText = "has a customer validated";
						aText.push(sText);
						break;
					default:
				}
			}
			if (oSelectedService.achieved) {
				sAchieved = "has an achieved outcome";
				aText.push(sAchieved);
			}

			for (var i = 0; i < aText.length; i++) {
				if (i === 0) {
					result = aText[i];
				} else if (i === (aText.length - 1)) {
					result = result + " and " + aText[i];
				} else {
					result = result + " ," + aText[i];
				}
			}
			if (result === "") {
				message = "You are about to delete the Sub-phase " + sServiceTitle + " and all of its activities. Are you sure?";
				this.getModel("slDefaultModel").setProperty("/TouchPointDetails/enableRemoveService", true);

			} else {
				message = "The Sub-phase you are trying to remove cannot be removed because it " + result + " ";
				this.getModel("slDefaultModel").setProperty("/TouchPointDetails/enableRemoveService", false);
			}
			this.getModel("slDefaultModel").setProperty("/TouchPointDetails/RemoveServiceMessage", message);
			if (!this.removeServiceDialog) {
				this.removeServiceDialog = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.RemoveService",
					this);
				this.getView().addDependent(this.removeServiceDialog);
			}
			this.removeServiceDialog.open();

		},
		/**
		 * Confirm remove service
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onRemoveServiceContinue: function () {
			var oSelectedService = this.getModel("slDefaultModel").getProperty("/TouchPointDetails");
			this.removeServiceDialog.close();
			var oParam = {
				SlId: oSelectedService.SlId,
				SlSnro: oSelectedService.SlSnro,
				TempId: oSelectedService.TempId,
				PhaseId: oSelectedService.PhaseId,
				TpointId: oSelectedService.TpointId,
				Weight: oSelectedService.Weight,
				TchpointGuid: oSelectedService.TchpointGuid
			};
			SLService.deleteService(oParam).then((oData) => {
				this.refreshSL();
			});
		},
		/**
		 * Cancel remove service dialog
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onRemoveServiceCancel: function () {
			this.removeServiceDialog.close();
		},
		/**
		 * search event for service list
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onAddServiceSearch: function (oEvent, sQuery) {
			let searchString = oEvent ? oEvent.getParameter("query") : sQuery;
			let sSourceKey = this.getView().byId("serviceSource").getSelectedKey();
			let oServiceOutcomeSource = this.getView().byId("serviceOutcomeSwitch");
			let bOutcomeState = oServiceOutcomeSource.getState();
			if (searchString !== "") {
				var aServFilters = new Filter({
					filters: [
						new Filter("Title", FilterOperator.Contains, searchString),
						new Filter("Description", FilterOperator.Contains, searchString),
						new Filter("SourceTitle", FilterOperator.Contains, searchString)
					],
					and: false
				});
				var aSourceFilter = [];
				if (bOutcomeState) {
					aSourceFilter.push(new Filter("ServiceType", FilterOperator.Contains, "0001"));
				}
				if (sSourceKey !== "001") {
					aSourceFilter.push(new Filter("SourceType", FilterOperator.Contains, sSourceKey));
				}
				var aSourceFilters = new Filter({
					filters: aSourceFilter,
					and: true
				});
				var combineFilter = new Filter({
					filters: [aServFilters, aSourceFilters],
					and: true
				});
				this.byId("addServiceList").getBinding("items").filter([combineFilter]);
			} else {
				var aFilter = [];
				if (bOutcomeState) {
					aFilter.push(new Filter("ServiceType", FilterOperator.Contains, "0001"));
				}
				if (sSourceKey !== "001") {
					aFilter.push(new Filter("SourceType", FilterOperator.Contains, sSourceKey));
				}
				var aServceFilters = new Filter({
					filters: aFilter,
					and: true
				});
				this.byId("addServiceList").getBinding("items").filter([aServceFilters]);
			}
		},
		/**
		 * to filter service outcomes
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleShowServiceOutcomes: function (oEvent) {
			this.getView().byId("addServiceSearch").setValue('');
			// this.getView().byId("serviceSource").setSelectedKey('001');
			let oServiceSource = this.getView().byId("serviceSource");
			let sSelectedKey = oServiceSource.getSelectedKey();
			var bState = oEvent.getParameters().state;
			let sSourceKey = this.getView().byId("serviceSource").getSelectedKey();
			if (bState) {
				var aFilter = [];
				aFilter.push(new Filter("ServiceType", FilterOperator.Contains, "0001"));
				if (sSourceKey !== "001") {
					aFilter.push(new Filter("SourceType", FilterOperator.Contains, sSourceKey));
				}
				var aServFilters = new Filter({
					filters: aFilter,
					and: true
				});
				this.byId("addServiceList").getBinding("items").filter([aServFilters]);
			} else {
				if (sSourceKey === "001") {
					this.byId("addServiceList").getBinding("items").filter([]);
				} else {
					var aSourceFilters = new Filter({
						filters: [
							new Filter("SourceType", FilterOperator.Contains, sSourceKey)
						],
						and: false
					});
					this.byId("addServiceList").getBinding("items").filter([aSourceFilters]);
				}
			}
		},
		/**
		 * selection of source to filter the service list
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		handleServiceSourceSelect: function (oEvent) {
			let aFilters = [];
			let aServFilters = "";
			let sKey = oEvent.getParameters().selectedItem.getKey();
			this.getView().byId("addServiceSearch").setValue('');
			let oServiceOutcomeSource = this.getView().byId("serviceOutcomeSwitch");
			let bOutcomeState = oServiceOutcomeSource.getState();
			let oSourceFilters = new Filter("SourceType", FilterOperator.Contains, sKey);
			let oServiceTypeFilters = new Filter("ServiceType", FilterOperator.Contains, "0001");
			// this.getView().byId("serviceOutcomeSwitch").setState(false);
			if (sKey === "001") {
				this.byId("addServiceList").getBinding("items").filter([]);
			} else {
				aFilters.push(oSourceFilters);
				oServiceOutcomeSource.setState(bOutcomeState);
				aServFilters = new Filter({
					filters: aFilters,
					and: false
				});
				this.byId("addServiceList").getBinding("items").filter([aServFilters]);
			}
			if (bOutcomeState) {
				// aFilters = [];
				aFilters.push(oServiceTypeFilters);
				aServFilters = new Filter({
					filters: aFilters,
					and: true
				});
				this.byId("addServiceList").getBinding("items").filter([aServFilters]);
			}
		},
		/**
		 * Search event for add service
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onAddServiceSearchLiveChange: function (oEvent) {
			let sQuery = oEvent.getSource().getValue();
			if (!sQuery) {
				this.onAddServiceSearch(undefined, sQuery);
			}
		},
		/**
		 * Method to edit activity completion date
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 */
		onCompletionDateEdit: function (oActv, oSource, key, isEdit) {
			let message, message2;
			this.getView().getModel("slDefaultModel").setProperty("/ActivityDetails/ConfirmActvt", oActv);
			let initialCompDate = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails/ConfirmActvt/CompDate");
			this.getView().getModel("slDefaultModel").setProperty("/ActivityDetails/ConfirmActvt/InitialCompDate", initialCompDate);
			this.getView().getModel("slDefaultModel").setProperty("/ActivityDetails/MessageKey", key);
			if (key === '12') { //Mark as completed
				message = "Completed";
				message2 = "Completion Date";
			} else { //Mark as validated
				message = "Validated";
				message2 = "Validation Date";
			}
			this.getView().getModel("slDefaultModel").setProperty("/ActivityDetails/MessageStatus", message);
			this.getView().getModel("slDefaultModel").setProperty("/ActivityDetails/MessageStatusDesc", message2);
			if (!isEdit || !oActv.CompDate) {
				oActv.CompDate = new Date();
				this.getView().getModel("slDefaultModel").setProperty("/ActivityDetails/CompDate", oActv.CompDate);
			}
			if (!this.confirmActvtActions) {
				this.confirmActvtActions = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.ConfirmActivityAction",
					this);
				this.getView().addDependent(this.confirmActvtActions);
			}
			this.confirmActvtActions.open();

		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 * event triggered in cancel button press of Confirm activity action
		 */
		handleCancelConfirmActvtAction: function () {
			let oDefaultModel = this.getView().getModel("slDefaultModel");
			oDefaultModel.setProperty("/SuccessLine/Menu", true);
			let initialDate = oDefaultModel.getProperty("/ActivityDetails/ConfirmActvt/InitialCompDate");
			let initialStatus = oDefaultModel.getProperty("/ActivityDetails/to_slwrapper/results/0/Status");
			oDefaultModel.setProperty("/ActivityDetails/CompDate", initialDate);
			this.SlDetailModel.setProperty("/RapidRegActivity/StatusId", (initialStatus === '') ? "01" : initialStatus);
			this.SlDetailModel.refresh(true);
			this.confirmActvtActions.close();
		},
		/**
		 * @memberOf com.presalescentral.successline.view.SlDetail
		 * event triggered in OK button press of Confirm activity action
		 */
		handleOkConfirmActvtAction: function (key, oActv) {
			let initialDate = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails/ConfirmActvt/InitialCompDate");
			let compDate = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails/CompDate");
			if (compDate === null) {
				compDate = initialDate;
			}
			if (!(this.RapidRegistration.rapidRegDialog && this.RapidRegistration.rapidRegDialog.isOpen())) {
				this.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
				this.getView().getModel("slDefaultModel").setProperty("/ActivityDetails/ConfirmActvt/CompDate", compDate);
				this.updateActivityStatus(key, oActv);
			}
			this.confirmActvtActions.close();
		},

		//function to handle setRow selectedIndex
		fnSetSelectedIndexToTable: function (iIndex) {
			let oTreeTable = this.getView().byId("actvtRegTbl");
			oTreeTable.setSelectedIndex(iIndex);
		},
		// risk edit changes
		OpenRiskInfoPopOver: function (oEvent) {
			if (!this.riskInfoPopup) {
				this.riskInfoPopup = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.RiskInfo", this);
				this.getView().addDependent(this.riskInfoPopup);
			}
			this.riskInfoPopup.openBy(oEvent.getSource());
		},
		OpenRiskCommentInfoPopOver: function (oEvent) {
			if (!this.riskCmtInfoPopup) {
				this.riskCmtInfoPopup = sap.ui.xmlfragment(this.getView().getId(),
					"com.presalescentral.successline.fragments.RiskCommentInfo", this);
				this.getView().addDependent(this.riskCmtInfoPopup);
			}
			this.riskCmtInfoPopup.openBy(oEvent.getSource());
		},

		handleUpdateRisk: function () {
			var that = this;
			let oDefaultModel = this.getView().getModel("slDefaultModel");
			let oWrapper = oDefaultModel.getProperty("/ActivityDetails/to_slwrapper/results/0");
			let sRiskId = oDefaultModel.getProperty("/ActivityDetails/RiskId");
			if ((oWrapper && oWrapper.RiskComment.trim() !== "") || sRiskId === "03") {
				let sRiskComment = "";
				if (oWrapper) {
					sRiskComment = oWrapper.RiskComment.trim();
				}
				let RegisteredActId = oDefaultModel.getProperty("/ActivityDetails/RegisteredActId");
				if (RegisteredActId) {
					RegisteredActId = parseInt(RegisteredActId);
					this.getOwnerComponent().getModel("appSettings").setProperty("/isRiskBusy", true);
					SLService.getRapidRegistration(RegisteredActId).then((oResponse) => {
						let oActvtObj = oResponse.data.results[0];
						oActvtObj.RiskComment = sRiskComment;
						oWrapper.RiskComment = sRiskComment;
						let ActivityGuid = oResponse.data.results[0].ActivityGuid;
						let aTeam = that.getView().getModel("slDefaultModel").getProperty("/ActivityDetails/to_slwrapper/results/0/to_team/results");
						that.RapidRegistration._saveRapidReg(true, undefined, aTeam, ActivityGuid, sRiskId, RegisteredActId, oActvtObj);
					});
				}
			} else {
				MessageToast.show("Enter Risk Comments");
			}
		},
		handleCloseRisk: function () {
			let oDefaultModel = this.getView().getModel("slDefaultModel");
			let oActvt = oDefaultModel.getProperty("/ActivityDetails");
			let sRiskDesc = oDefaultModel.getProperty("/ActivityDetails/RiskDesc");
			this._handleWrprFieldsVisibility(oActvt.ActGuid, "RISK", false);
			oDefaultModel.setProperty("/ActivityDetails/RiskId", this.oStoreCurrentActvt.RiskId);
			oDefaultModel.setProperty("/ActivityDetails/to_slwrapper/results/0/RiskComment", this.oStoreRiskCmnt.RiskComment);
			this.setRiskColor(sRiskDesc, 100);
		},

		onRiskEditPress: function (oEvent) {
			let oActvt = this.getView().getModel("slDefaultModel").getProperty("/ActivityDetails");
			// for not to store same activity again
			let oRisk = {
				"RiskId": oActvt.RiskId
			};
			if (this.oStoreCurrentActvt) {
				if (oActvt.ActGuid !== this.oStoreCurrentActvt.ActGuid) {
					this.oStoreCurrentActvt = jQuery.extend(true, {}, oRisk);
				}
			} else {
				this.oStoreCurrentActvt = jQuery.extend(true, {}, oRisk);
			}
			this._handleWrprFieldsVisibility(oActvt.ActGuid, "RISK", true);
		},
		onRiskInfoClose: function (oEvent) {
			this.riskInfoPopup.close();
		},
		onRiskCmntInfoClose: function (oEvent) {
			this.riskCmtInfoPopup.close();
		},
		setRiskColor: function (color, delay) {
			if (color) {
				setTimeout(() => {
					$(".riskCmntTxt").css("border-left", "10px solid" + " " + color.toLowerCase());
				}, delay);
			}
		},
		/**
		 *Handeling the navigation from the cancelled MSL to the activie parallel MSL.
		 *
		 */
		handleParallelMsl: function () {
			let sParallelmSlId;
			let oDefaultModel = this.getModel("slDefaultModel").getData();
			sParallelmSlId = oDefaultModel.SuccessLine.ParallelSlSnro;
			this.getOwnerComponent().getRouter().navTo("SlDetail", {
				OptionalQueryString: {
					SuccessLineID: sParallelmSlId
				}
			}, false);
		},

		onSlDetOppoComponentLoaded: function (oEvent) {
			this.opportunityComponentInstance = oEvent.getSource().getComponentInstance();
			//Add additional opp in rapid registration
			this.getView().setModel(this.opportunityComponentInstance.getModel("activityTypeModel"), "activityTypeModel");
			this.getView().getModel("activityTypeModel").setProperty("/projectType", "ACTVT");
			let oOpportunityModel = this.opportunityComponentInstance.getModel("opportunityModel");
			this.getView().setModel(oOpportunityModel, "opportunityModel");
		},

		//Function to show message box when harmony server is down
		fnShowUserOppoConfrmBox: function (oEvent) {
			this.oDetUserSelectEvent = jQuery.extend(true, {}, oEvent);
			let oSlDetailModel = this.getView().getModel("SlDetailModel");
			let sOpportunity = oSlDetailModel.getProperty("/OpportunityId");
			var oppoComponent = this.opportunityComponentInstance;
			var oOppoDataModel = oppoComponent.getModel("oppServerModel");
			var bMetadataLoaded = oOppoDataModel.isMetadataLoadingFailed();
			var isSelfAssign = this.getView().getModel("slDefaultModel").getProperty("/SuccessLine/selfAsignLead");
			if (sOpportunity) {
				if (!bMetadataLoaded) {
					this.handleActivityLeadConfirm(this.oDetUserSelectEvent, "", isSelfAssign);
				} else {
					var that = this;
					sap.m.MessageBox.confirm(
						"Since Harmony server is unavailable, users cannot be added to Opportunity team. Do you wish to continue", {
						onClose: function (oAction) {
							if (oAction.toLowerCase() === "cancel") {
								that.sActvtLeadDialog.close();
							} else {
								that.handleActivityLeadConfirm(this.oDetUserSelectEvent, "", isSelfAssign);
							}
						}
					});
				}
			} else {
				this.handleActivityLeadConfirm(this.oDetUserSelectEvent, "", isSelfAssign);
			}
		},
		/***
		 * Function to allow useres to edit the Subtitle on Avtivity view
		 * {param} Current activity object
		 */
		onSubTitleEdit: function (oAct) {
			jQuery(".slactivityviewsubtitle").css("border", "1px solid black");
			jQuery(".slactivityviewsubtitle").css("border-color", "#427cac");
			let oView = this.getView();
			let oSubTitle = oView.byId("idSubTitle");
			oSubTitle.setVisible(false);
			let oButton = oView.byId("idSubTitleBtn");
			const oWrapper = oView.getModel("slDefaultModel").getProperty("/ActivityDetails/to_slwrapper/results/0");
			let oUpdateButton = oView.byId("idUpdateSubTitle");
			let CancelButton = oView.byId("idCancelSubTitle");
			let inputField = oView.byId("idSubTitleText");
			inputField.setVisible(true);
			inputField.focus();
			if (inputField.getValue() === "Enter Subtitle") {
				inputField.setValue("");
			}
			this.sIntitialSubTitle = oWrapper.SubTitle;
			inputField.setEditable(true);
			CancelButton.setVisible(true);
			oUpdateButton.setVisible(true);
			oButton.setVisible(false);
		},
		/**
		 ** Function to handle the cancalation of subtitle edit.
		 */
		onCancelUpdateSubTitle: function () {
			let oView = this.getView();
			let oButton = oView.byId("idSubTitleBtn");
			let oUpdateButton = oView.byId("idUpdateSubTitle");
			let CancelButton = oView.byId("idCancelSubTitle");
			let inputField = oView.byId("idSubTitleText");
			let sInitialValue = this.sIntitialSubTitle;
			let sTxtSubTitle = this._oResourceBundle.getText("txtsub");
			let oSubTitle = oView.byId("idSubTitle");
			oSubTitle.setVisible(true);
			inputField.setVisible(false);
			inputField.setEditable(false);
			if (sInitialValue === "") {
				inputField.setValue(sTxtSubTitle);
			} else {
				inputField.setValue(sInitialValue);
			}
			CancelButton.setVisible(false);
			oUpdateButton.setVisible(false);
			oButton.setVisible(true);
		},
		/**
		 *Function to display all the enabled roles.
		 * {param} Instance of the current control
		 */
		onEnabledRolesPress: function (oEvent) {
			this.loadFragment({
				name: "com.presalescentral.successline.fragments.EnabledRolesPopover"
			}).then(function (oPopover) {
				oPopover.openBy(oEvent.getSource());
			});
		},
		/**
		 *Function to make a put call to update the Subtitle.
		 * {param} Instance of the current control
		 */
		handleUpdateSubTitle: function (oEvent) {
			this.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
			let that = this;
			let oView = this.getView();
			let oButton = oView.byId("idSubTitleBtn");
			let oUpdateButton = oView.byId("idUpdateSubTitle");
			let CancelButton = oView.byId("idCancelSubTitle");
			let inputField = oView.byId("idSubTitleText");
			const oWrapper = oView.getModel("slDefaultModel").getProperty("/ActivityDetails/to_slwrapper/results/0");
			let sSubTextTitle = oView.byId("idSubTitleText").getValue();
			let sTxtSubTitle = this._oResourceBundle.getText("txtsub");
			let oModelSl = oView.getModel("slDefaultModel");
			let oSldetailHierarchy = oModelSl.getProperty("/SuccessLineHierarchy/Phases/");
			let oActivityDetail = oModelSl.getData().ActivityDetails;
			let oPresentationDetail = oModelSl.getData().presentationData;
			let oSubTitle = oView.byId("idSubTitle");
			oWrapper.SubTitle = sSubTextTitle;
			if (oWrapper || oWrapper.SubTitle.trim() === "") {
				this.oSubtitle = {
					"ActGuid": oWrapper.ActGuid,
					"SlId": oWrapper.SlId,
					"SlSnro": oWrapper.SlSnro,
					"PhaseId": oWrapper.PhaseId,
					"TpointId": oWrapper.TpointId,
					"ActivityId": oWrapper.ActivityId,
					"ActivityTitle": oWrapper.ActivityTitle,
					"WrpDescription": oWrapper.WrpDescription,
					"DaysToPrepare": oWrapper.DaysToPrepare,
					"DaysToExecute": oWrapper.DaysToExecute,
					"Deliverables": oWrapper.Deliverables,
					"Outcomes": oWrapper.Outcomes,
					"activity_id": oWrapper.activity_id,
					"Notes": oWrapper.Notes,
					"Registered": oWrapper.Registered,
					"Weight": oWrapper.Weight,
					"SubTitle": oWrapper.SubTitle
				};
				SLService.updateWrapperData(this.oSubtitle).then((oData) => {
					MessageToast.show("Subtitle Updated");
					oPresentationDetail.phases.forEach((item) => {
						if (item.id === oWrapper.PhaseId) {
							this.iteRateArray(item.services, oWrapper);
						}
					});
					oSldetailHierarchy.forEach((item) => {
						if (item.PhaseId === oWrapper.PhaseId) {
							that.recurs(item.results, oWrapper);
						}
					});
					that.getView().getModel("slDefaultModel").setProperty("/ActivityDetails/SubTitle", oWrapper.SubTitle);
					that.getView().getModel("slDefaultModel").refresh();
					inputField.setEditable(false);
					// if (oSubTitle.getText().length < 20) {
					// 	oSubTitle.setWidth("auto");
					// } else {
					// 	oSubTitle.setWidth("13rem");
					// }
					CancelButton.setVisible(false);
					oUpdateButton.setVisible(false);
					oButton.setVisible(true);
					oSubTitle.setVisible(true);
					inputField.setVisible(false);
					that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", false);
				});
			} else {
				MessageToast.show(sTxtSubTitle);
			}
		},
		/**
		 *Function to update the local model for the updated Subtitle.
		 */
		recurs: function (data, oWrapper) {
			data.forEach((item) => {
				if (item.TpointId === oWrapper.TpointId) {
					if (item.ActGuid === oWrapper.ActGuid && item.results === undefined) {
						item.SubTitle = oWrapper.SubTitle;
					} else if (item.results !== undefined && Array.isArray(item.results)) {
						this.recurs(item.results, oWrapper);
					}
				}
			});
		},
		/**
		 *Function to handle the update the presentation model on Subtitle edit
		 */
		iteRateArray: function (aData, oWrapper) {
			aData.forEach((item) => {
				if (item.touchpointId === oWrapper.TpointId) {
					if (item.activities !== undefined && Array.isArray(item.activities)) {
						item.activities.forEach((act) => {
							if (act.id === oWrapper.ActGuid) {
								act.subTitle = oWrapper.SubTitle;
							}
						});
					}
				}
			});
		},
		/**
		 *Factory function to generate dynamic menu items
		 */
		generateMenuItemFactory: function (sId, oContext) {
			let sIcon = "";
			let statusId = oContext.getModel().getProperty("/selectedActivity/StatusId");
			let sEnabled = oContext.getProperty(oContext.sPath).IsEnabled;
			let bEnabled = false;
			if (sEnabled === 'X') {
				bEnabled = true;
			}
			let data = oContext.getProperty(oContext.sPath);
			if (statusId === data.ItemValue) {
				sIcon = "sap-icon://accept";
			}
			if (data.length !== 0) {
				return new sap.m.MenuItem({
					text: data.ItemName,
					icon: sIcon,
					key: data.ActionId,
					enabled: bEnabled
				});

			} else {
				return new sap.m.MenuItem({
					visible: false
				});
			}

		},
		onMenuAction: function (oEvent) {

			let that = this;
			let oContext = oEvent.getParameter("item");
			let sAction = oContext.getKey();

			let oActv = this.getModel("slDefaultModel").getProperty("/selectedActivity");
			switch (sAction) {
				case '00003': //Register Activity
					this.onActivityFormAction('01', oActv, this.ActivityMenuButton);
					break;
				case '00001': // mark as planned
					that.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
					that.updateActivityStatus("11", oActv);
					break;
				case '00007': //Cancel Registration
					this.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
					oActv.CompDate = new Date();
					this.updateActivityStatus('02', oActv);
					break;
				case '00012': //Mark as Completed
					this.onCompletionDateEdit(oActv, undefined, "12", false);
					break;
				case '00011': //Customer Validated
					this.onCompletionDateEdit(oActv, undefined, "14", false);
					break;
				case '00002': //Mark as Not Applicable
					this.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
					this.updateActivityStatus("15", oActv);
					break;
				case '00004': //Remove Activity
					//TchpointGuid is not present when removing the activity from detail view
					if (oActv.TchpointGuid === undefined) {
						oActv.TchpointGuid = oActv.tchpoint_guid;
					}
					this.oSelectedActvt = oActv;
					let sSelectedActvtTitle = this.oSelectedActvt.Title;
					this.getModel("slDefaultModel").setProperty("/TouchPointDetails/SelectedActvtTitle", sSelectedActvtTitle);
					if (!this.removeActvtDialog) {
						this.removeActvtDialog = sap.ui.xmlfragment(this.getView().getId(),
							"com.presalescentral.successline.fragments.RemoveActivity",
							this);
						this.getView().addDependent(this.removeActvtDialog);
					}
					this.removeActvtDialog.open();
					this.getView().getModel("slDefaultModel").setProperty("/SuccessLine/Menu", true);
					break;
				case '00006': //Edit Registered activity
					this.onEditRegisteredActivity(this.ActivityMenuButton, '01', oActv);
					break;
				case '00008': //Started
					this.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
					this.updateActivityStatus('16', oActv);
					break;
				case '00009': //Progressing
					this.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
					this.updateActivityStatus('17', oActv);
					break;
				case "00010": //Presented
					this.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
					this.updateActivityStatus('18', oActv);
					break;
				case '99': //Assign a Lead
					let oBtnSource = (typeof this.ActivityMenuButton.getSource === "function") ? this.ActivityMenuButton : this.ActivityMenuButton.getSource();
					this.onActivityLeadEdit(oActv, oBtnSource);
					break;
				case '100': //Revert to Registered
					this.getOwnerComponent().getModel("appSettings").setProperty("/isAppBusy", true);
					oActv.CompDate = new Date();
					this.updateActivityStatus("01", oActv);
					break;
				case "00014": //Edit in full registration
					this.navToFullRegForm(oActv);
					break;
				case "01000": //Archive
					this.updateActivityStatus("", oActv, true);
					break;
				case "01001": // UnArchive
					this.updateActivityStatus("", oActv, false);
					break;
				default:
			}
		},

		navToFullRegForm: function (oActivity) {
			if (this.ConstantsMap) {
				let sParam = parseInt(oActivity.RegisteredActId, 10) + "&IsRapidRegistration=true&ActGUID=" + oActivity.ActGuid;
				// this.ConstantsMap["0176"]
				window.open(this.ConstantsMap["0180"].field_value + sParam);
			}
		},

		onAttachHandoverChange: function (oEvent) {
			let oSource = oEvent.getSource();
			let oContext = oSource.getBindingContext("slDefaultModel");
			let oAttachment = oContext.getObject();
			let sPath = oContext.getPath();
			let bState;
			if (oEvent.getSource().getCustomData().length) {
				bState = false;
			} else {
				bState = oEvent.getSource().getState();
			}
			this.getModel("slDefaultModel").setProperty(sPath + "/Handover", bState);
			SLService.updateAttachmentHandover(oAttachment).then((oData) => {
				// var oAttachment = oData.data.results[0];
			});
		},

		//Navigation link for risk ticket
		navToTicketSystem: function (oEvent) {
			let fieldValue = this.ConstantsMap["0123"].field_value;
			window.open(fieldValue, "_blank");
		},

		//function to add action menu items
		fnSetAdditionalMenuItems: function (oSelectedObj, aResponse) {
			let oActivityMenuModel = this.getView().getModel("activityMenuModel");
			let oSlDefaultModel = this.getView().getModel("slDefaultModel");
			let oSelectedSLActivity = oActivityMenuModel.getProperty("/oSelectedSLActivity") || {};
			let oSuccessLine = oSlDefaultModel.getProperty("/SuccessLine") || {};
			let SLStatusId = ("SLStatus" in oSelectedSLActivity) ? oSelectedSLActivity.SLStatus : "";
			let slLeadAccess = oActivityMenuModel.getProperty("/slLeadAccess");
			// let registrationAccess = oActivityMenuModel.getProperty("/registrationAccess");
			let registrationAccess = ("RegistrationAccess" in oSelectedSLActivity) ? oSelectedSLActivity.RegistrationAccess : false;
			let isAuthorized = ("isAuthorized" in oSuccessLine) ? oSuccessLine.isAuthorized : "";
			let sActStatus = oSelectedObj?.StatusId ?? "";
			let bIsActArchived = oSelectedObj?.archived ?? false;

			//Any Additional Button required add it in options
			let oOptions = {
				createTimeEntry: {
					ItemName: "Create Time Entry",
					id: "createtimeentry",
					SortOrder: "00004",
					Icon: (SLStatusId !== "12") ? "sap-icon://create-entry-time" : "sap-icon://locked",
					IsEnabled: (SLStatusId !== "12") ? "X" : "",
					Visible: !bIsActArchived
				},
				// StatusId 12, archived false
				archive: {
					ItemName: "Archive Activity",
					id: "archive",
					SortOrder: "00005",
					Icon: (SLStatusId !== "12") ? "sap-icon://attachment-zip-file" : "sap-icon://locked",
					IsEnabled: (SLStatusId !== "12") ? "X" : "",
					Visible: (sActStatus === "12" || sActStatus === "14") && !bIsActArchived,
					ActionId: "01000"
				},
				unarchive: {
					ItemName: "Un-Archive Activity",
					id: "unarchive",
					SortOrder: "00006",
					Icon: (SLStatusId !== "12") ? "sap-icon://attachment-zip-file" : "sap-icon://locked",
					IsEnabled: (SLStatusId !== "12") ? "X" : "",
					Visible: (sActStatus === "12" || sActStatus === "14") && bIsActArchived,
					ActionId: "01001"
				}
			};

			//Register Activity Validation
			let registerIndex = aResponse.findIndex((oItem) => {
				let itemName = (oItem.ItemName) ? oItem.ItemName.toLowerCase().replace(/\s/g, "") : "";
				return oItem.ActionId === "00003" && itemName === "registeractivity";
			});

			if (registerIndex !== -1) {
				let oRegister = aResponse[registerIndex];
				let itemName = (oRegister.ItemName) ? oRegister.ItemName.toLowerCase().replace(/\s/g, "") : "";
				if (itemName === "registeractivity") {
					//if ((slLeadAccess || (isAuthorized && registrationAccess)) && SLStatusId !== "12") {
					if ((isAuthorized && registrationAccess) && SLStatusId !== "12") {
						oRegister.IsEnabled = "X";
					} else {
						oRegister.IsEnabled = "";
					}
					aResponse[registerIndex] = oRegister;
				}
			}

			//MSL COMPLETE
			aResponse = aResponse.map((oItem) => {
				return {
					...oItem,
					IsEnabled: (SLStatusId === "12") ? "" : oItem.IsEnabled,
					Icon: (SLStatusId === "12") ? "sap-icon://locked" : oItem.Icon,
					Visible: !bIsActArchived

				}
			});

			let aMenuItems = [];
			for (let key in oOptions) {
				if (key) {
					let oItem = oOptions[key];
					aMenuItems.push(oItem);
				}
			}
			aResponse = aResponse.concat(aMenuItems);
			return aResponse;
		},

		//function to find Formlayout Id for rolemaping_id "067"
		/*fnFindFormLayoutIdUsingRoleMapId: function (actvt) {
			let aOtherRoleActvtData = this.getModel("slDefaultModel").getProperty("/aOtherRoleActvtData");
			var activityRole = this.getModel("slDefaultModel").getProperty("/SuccessLine/ActivityRole");

			let oRoleMapData = aOtherRoleActvtData.find((oRoleData) => {
				return oRoleData.ActivityId === actvt.ActivityId;
			}) || false;

			if (oRoleMapData) {
				actvt.frmlayout_id = oRoleMapData.FormLayout;
			}

			return actvt;
		},*/

		//update to rapid registration #217
		/*getLevel2MasterData: function () {
			var that = this;
			SLService.getLevel2MasterData().then(function (result) {
				var aResults = result.data.results;
				var oMasterDataModel = that.Component.getModel("masterData");
				oMasterDataModel.setProperty("/Level2Data", aResults);
				var isEditMode = that.SlDetailModel.getProperty("/isEditMode");
				if (aResults.length && !isEditMode) {
					that.SlDetailModel.setProperty("/Level2Key", aResults[0].L2Id);
				}
			});
		},*/

		/*getSolutionHierarchy: function () {
					var that = this;
					var oMaterialMap = {};
					this.oSolutionsModel.setProperty("/isSolDataRecieved", false);
					SLService.getSolutionHierarchy().then(function (result) {
						var oData = result.data.results;
						var aMaterialData = oData.map(function (obj, index) {
							obj.isSelected = false;
							oMaterialMap[obj["MatId"]] = index;
							return obj;
						});
						that.oSolutionsModel.setProperty("/SolutionHierarchy", aMaterialData);
						that.oSolutionsModel.setProperty("/MaterialMap", oMaterialMap);
						var sSelectedLevel = that.SlDetailModel.getProperty("/Level2Key");
						that._convertToTree(that, aMaterialData, sSelectedLevel, false);
						that.RapidRegistration.fnSetSelectedSolutions();
						// that.fnSetActDetailGridsBusy("idActivityDetails", false, 0);
						// var RapidRegData = oController.masterDataModel.getProperty("/RapidRegData");
						// if (RapidRegData) {
						// 	var OpportunityID = RapidRegData["OpportunityNumber"];
						// 	if (OpportunityID) {
						// 		oController.onOppModelChange();
						// 	}
						// }
					});
			},*/
		_convertToTree: function (oController, aMaterialData, sSelectedLevel, isOpp) {
			var L4Map = {},
				L5Map = {};
			var aLevelsTree = [];
			for (var i = 0; i < aMaterialData.length; i++) {
				var level2Index = aLevelsTree.findIndex(function (item) {
					return item.LevelId === aMaterialData[i]["L2Id"];
				});
				if (aMaterialData[i]["L2Id"]) {
					if (level2Index === -1) {
						aLevelsTree.push({
							LevelId: aMaterialData[i]["L2Id"],
							LevelDesc: aMaterialData[i]["L2Desc"],
							L2Id: aMaterialData[i]["L2Id"],
							L2Desc: aMaterialData[i]["L2Desc"],
							L3Id: aMaterialData[i]["L3Id"],
							L3Desc: aMaterialData[i]["L3Desc"],
							L4Id: aMaterialData[i]["L4Id"],
							L4Desc: aMaterialData[i]["L4Desc"],
							L5Id: aMaterialData[i]["L5Id"],
							L5Desc: aMaterialData[i]["L5Desc"],
							MatId: aMaterialData[i]["MatId"],
							LevelCount: 2,
							isVisible: false,
							isSelected: false,
							Levels: []
						});
						level2Index = aLevelsTree.length - 1;
					}
					var aLevel3 = aLevelsTree[level2Index].Levels;
				}
				if (aLevel3) {
					var level3Index = aLevel3.findIndex(function (item) {
						return item.LevelId === aMaterialData[i]["L3Id"];
					});
				}
				if (aMaterialData[i]["L3Id"]) {
					if (level3Index === -1) {
						aLevel3.push({
							LevelId: aMaterialData[i]["L3Id"],
							LevelDesc: aMaterialData[i]["L3Desc"],
							L2Id: aMaterialData[i]["L2Id"],
							L2Desc: aMaterialData[i]["L2Desc"],
							L3Id: aMaterialData[i]["L3Id"],
							L3Desc: aMaterialData[i]["L3Desc"],
							L4Id: aMaterialData[i]["L4Id"],
							L4Desc: aMaterialData[i]["L4Desc"],
							L5Id: aMaterialData[i]["L5Id"],
							L5Desc: aMaterialData[i]["L5Desc"],
							MatId: aMaterialData[i]["MatId"],
							LevelCount: 3,
							isVisible: false,
							isSelected: false,
							Levels: []
						});
						level3Index = aLevel3.length - 1;
					}
					var aLevel4 = aLevel3[level3Index].Levels;
				}
				if (aLevel4) {
					var level4Index = aLevel4.findIndex(function (item) {
						return item.LevelId === aMaterialData[i]["L4Id"];
					});
				}
				if (aMaterialData[i]["L4Id"]) {
					if (level4Index === -1) {
						aLevel4.push({
							LevelId: aMaterialData[i]["L4Id"],
							LevelDesc: aMaterialData[i]["L4Desc"],
							L2Id: aMaterialData[i]["L2Id"],
							L2Desc: aMaterialData[i]["L2Desc"],
							L3Id: aMaterialData[i]["L3Id"],
							L3Desc: aMaterialData[i]["L3Desc"],
							L4Id: aMaterialData[i]["L4Id"],
							L4Desc: aMaterialData[i]["L4Desc"],
							L5Id: aMaterialData[i]["L5Id"],
							L5Desc: aMaterialData[i]["L5Desc"],
							MatId: aMaterialData[i]["MatId"],
							LevelCount: 4,
							isVisible: true,
							isSelected: false,
							isOpportunity: false,
							ValueState: "None",
							Levels: []
						});
						level4Index = aLevel4.length - 1;
					}
					var aLevel5 = aLevel4[level4Index].Levels;
				}
				if (aLevel5) {
					var level5Index = aLevel5.findIndex(function (item) {
						return item.LevelId === aMaterialData[i]["L5Id"];
					});
				}
				if (aMaterialData[i]["L5Id"]) {
					if (level5Index === -1) {
						var obj = {
							LevelId: aMaterialData[i]["L5Id"],
							LevelDesc: aMaterialData[i]["L5Desc"],
							L2Id: aMaterialData[i]["L2Id"],
							L2Desc: aMaterialData[i]["L2Desc"],
							L3Id: aMaterialData[i]["L3Id"],
							L3Desc: aMaterialData[i]["L3Desc"],
							L4Id: aMaterialData[i]["L4Id"],
							L4Desc: aMaterialData[i]["L4Desc"],
							L5Id: aMaterialData[i]["L5Id"],
							L5Desc: aMaterialData[i]["L5Desc"],
							MatId: aMaterialData[i]["MatId"],
							LevelCount: 5,
							isVisible: true,
							isSelected: false,
							isOpportunity: false,
							ValueState: "None",
							Levels: [],
							RadioBtnGrpName: aMaterialData[i]["L5Id"]
						};
						aLevel5.push(obj);
						level5Index = aLevel5.length - 1;
						L5Map[aMaterialData[i]["L5Id"]] = aLevel4[level4Index];
						L4Map[aMaterialData[i]["L4Id"]] = aLevel5;
					}
				}
			}
			oController.oSolutionsModel.setProperty("/LevelsHierarchy", aLevelsTree);
			oController.L2Map = {};
			aLevelsTree.filter(function (l2) {
				oController.L2Map[l2.L2Id] = l2;
			});
			if (isOpp) {
				oController.oSolutionsModel.setProperty("/OppLevelsHierarchy", aLevelsTree);
			} else {
				var oLevelData = this.fnJoinAllLevelsData(aLevelsTree);
				oController.oSolutionsModel.setProperty("/SelectedLevelHierarchy", oLevelData);
			}
			oController.oSolutionsModel.setProperty("/L4Map", L4Map);
			oController.oSolutionsModel.setProperty("/L5Map", L5Map);

			//Below lines of code is to form oppo materials array, so it can be selected in popup
			var isEditMode = oController.SlDetailModel.getProperty("/isEditMode");
			if (isEditMode) {
				var to_ATaxonomy = oController.oSolutionsModel.getProperty("/to_ATaxonomy");
				to_ATaxonomy = oController.fnGetL4sChildobject(to_ATaxonomy, L4Map);
				to_ATaxonomy = oController.fnGetL5sParentobject(to_ATaxonomy);
				oController.oSolutionsModel.setProperty("/to_ATaxonomy", to_ATaxonomy);
				var to_AMaterial = oController.oSolutionsModel.getProperty("/to_AMaterial");
				var SolTokens = to_ATaxonomy.concat(to_AMaterial);
				var displayTokens = oController.fnGetDisplayTokens(SolTokens);
				oController.oSolutionsModel.setProperty("/DisplayTokens", displayTokens);
				oController.oSolutionsModel.setProperty("/SolTokens", displayTokens);
				oController.oSolutionsModel.setProperty("/oSolTempArr", $.extend(true, [], to_ATaxonomy));
				oController.oSolutionsModel.setProperty("/oMatTempArr", $.extend(true, [], to_AMaterial));
				var OpportunityMaterials = oController.oSolutionsModel.getProperty("/OpportunityMaterials");
				if (OpportunityMaterials) {
					oController.fnFormOpportunityMaterials(OpportunityMaterials);
					oController.fnFormOppoSolTempArr(to_ATaxonomy, OpportunityMaterials);
				}
			}

			oController.oSolutionsModel.setProperty("/isSolDataRecieved", true);
		},

		fnJoinAllLevelsData: function (aLevelsTree) {
			var oLevelData = [];
			var oKeys = Object.keys(aLevelsTree);
			for (var i = 0; i < oKeys.length; i++) {
				var cLevels = aLevelsTree[oKeys[i]].Levels;
				oLevelData = oLevelData.concat(cLevels);
			}
			return oLevelData;
		},

		//Function to update L4's child array to its parent object
		fnGetL4sChildobject: function (to_ATaxonomy, L4Map) {
			for (var i = 0; i < to_ATaxonomy.length; i++) {
				var levelId = to_ATaxonomy[i].L4Id;
				to_ATaxonomy[i].Levels = L4Map[levelId] ? L4Map[levelId] : [];
			}
			return to_ATaxonomy;
		},

		//Function to find L5's parent object for the checkbox to be selected in EDIT mode
		fnGetL5sParentobject: function (to_ATaxonomy) {
			var that = this;
			var oSolutionsModel = this.oSolutionsModel;
			var L5Map = oSolutionsModel.getProperty("/L5Map");
			for (var i = 0; i < to_ATaxonomy.length; i++) {
				var tmpObj = to_ATaxonomy[i];
				var levelCount = tmpObj.LevelCount;
				if (levelCount === 5) {
					var L4Obj = L5Map[tmpObj["L5Id"]];
					var bVal = that.RapidRegistration.fnFindObjInArray(L4Obj, to_ATaxonomy);
					if (!bVal) {
						L4Obj.isParent = true;
						L4Obj.ValueState = "Information";
						to_ATaxonomy.push(L4Obj);
					}
				}
			}
			return to_ATaxonomy;
		},

		//Function to get display tokens
		fnGetDisplayTokens: function (oSolTempArr) {
			var oTempArr = [];
			oSolTempArr.filter(function (tempObj) {
				if (!tempObj.isParent) {
					oTempArr.push(tempObj);
				}
			});
			return oTempArr;
		},

		//Function to form opportunity's material data for Solution Hierarchy
		//Needs to be reviewed
		fnFormOpportunityMaterials: function (oResponse) {
			var oTempArr = [];
			var oSolutionsModel = this.oSolutionsModel;
			var aOppoMaterials = oResponse.Items.results;
			var MaterialMap = oSolutionsModel.getProperty("/MaterialMap");
			if (MaterialMap) {
				aOppoMaterials.filter(function (oMatObj) {
					if (MaterialMap[oMatObj.PRODUCT_ID] >= 0) {
						var sIndex = MaterialMap[oMatObj.PRODUCT_ID];
						var oTempObj = oSolutionsModel.getProperty("/SolutionHierarchy/" + sIndex);
						oSolutionsModel.setProperty("/SolutionHierarchy/" + sIndex + "/isOpportunity", true);
						oTempArr.push(oTempObj);
					}
				});
				if (oTempArr.length === 0) {
					oTempArr = ["E"];
				}
				oSolutionsModel.setProperty("/OppoMaterials", oTempArr);
			} else {
				var that = this;
				if (that.materialReadCount === undefined) {
					that.materialReadCount = 0;
				}
				if (oResponse) {
					that.oppoMaterials = oResponse;
				}
				setTimeout(function () {
					that.materialReadCount += 1;
					that.fnFormOpportunityMaterials(that.oppoMaterials);
				}, 1000);
			}
		},

		//Function to reset selected solutions and materials on activity type change
		fnClrSolMatOnActChange: function () {
			var oSolutionsModel = this.oSolutionsModel;
			oSolutionsModel.setProperty("/SolTokens", []);
			oSolutionsModel.setProperty("/oSolTempArr", []);
			oSolutionsModel.setProperty("/oMatTempArr", []);
			oSolutionsModel.setProperty("/to_ATaxonomy", []);
			oSolutionsModel.setProperty("/to_AMaterial", []);
			oSolutionsModel.setProperty("/SolutionDesc", "");
			oSolutionsModel.setProperty("/DisplayTokens", []);
			oSolutionsModel.setProperty("/OppSolTempArr", []);
		},

		//Function to form OppSolTempArr objects during Edit case
		fnFormOppoSolTempArr: function (to_ATaxonomy) {
			var OppSolTempArr = [];
			var oSolutionsModel = this.oSolutionsModel;
			var OppoMaterials = oSolutionsModel.getProperty("/OppoMaterials") || [];
			OppoMaterials.filter(function (OppMaterial) {
				to_ATaxonomy.find(function (obj, index) {
					var levelId = "L" + obj.LevelCount + "Id";
					if (obj[levelId] === OppMaterial[levelId]) {
						OppSolTempArr.push(obj);
					}
				});
			});
			oSolutionsModel.setProperty("/OppSolArr", OppSolTempArr);
			oSolutionsModel.setProperty("/OppSolTempArr", OppSolTempArr);
		},

	});
});