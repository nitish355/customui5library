sap.ui.define(
  [
    "com/presalescentral/successline/controller/BaseController",
    "com/presalescentral/successline/service/OppService",
    "com/presalescentral/successline/service/UtilityService",
    "sap/m/MessageToast",
    "sap/base/Log",
    "sap/ui/util/Storage",
  ],
  function (
    BaseController,
    OppService,
    UtilityService,
    MessageToast,
    Log,
    Storage
  ) {
    "use strict";

    return BaseController.extend(
      "com.presalescentral.successline.controller.App",
      {
        //Initialization Method
        onInit: function () {
          this.initView();
          this.getOwnerComponent()
            .getModel("opportunityData")
            .setProperty("/opportunityLoaded", false);
          if (!this.slManagerTeamStorage) {
            this.slManagerTeamStorage = new Storage(Storage.Type.session);
          }
          if (!this.slOpportuities) {
            this.slOpportuities = new Storage(Storage.Type.session);
          }
          if (!this.slManagerTeamStorage.get("SlManagerTeamData")) {
            this.getOwnerComponent()
              .getModel("masterSettings")
              .setProperty("/masterOpportunityDataLoaded", false);
            this.getMyTeamData();
          } else {
            this.myTeamData = {};
            this.myTeamData =
              this.slManagerTeamStorage.get("SlManagerTeamData");
            this.getOwnerComponent()
              .getModel("masterData")
              .setProperty("/myTeamData", this.myTeamData);
            if (
              !this.slOpportuities.get("SlopportunityMapData") ||
              !this.slOpportuities.get("SlaOpportunitiesOwner") ||
              !this.slOpportuities.get("SlaOpportunitiesAccount")
            ) {
              this.getOwnerComponent()
                .getModel("masterSettings")
                .setProperty("/masterOpportunityDataLoaded", false);
              this.getTeamOpportunity();
            } else {
              this.opportunitiesMap = {};
              this.aOpportunitiesOwner = {};
              this.aOpportunitiesAccount = {};
              this.opportunitiesMap = this.slOpportuities.get(
                "SlopportunityMapData"
              );
              this.aOpportunitiesOwner = this.slOpportuities.get(
                "SlaOpportunitiesOwner"
              );
              this.aOpportunitiesAccount = this.slOpportuities.get(
                "SlaOpportunitiesAccount"
              );
              this.getOwnerComponent()
                .getModel("opportunityData")
                .setProperty("/opportunityLoaded", true);
              this.getOwnerComponent()
                .getModel("opportunityData")
                .setProperty("/opportunityMapData", this.opportunitiesMap);
              this.getOwnerComponent()
                .getModel("oppOwnerData")
                .setProperty("/opportunityOwner", this.aOpportunitiesOwner);
              this.getOwnerComponent()
                .getModel("oppAccountData")
                .setProperty("/opportunityAccount", this.aOpportunitiesAccount);
              this.getOwnerComponent()
                .getModel("masterSettings")
                .setProperty("/masterOpportunityDataLoaded", true);
            }
          }
          try {
            //	 if (window.location.host.substring(0, 6).toLowerCase() !== "webide") {
            // if (window.location.hostname.startsWith("webide")) {
            //	jQuery.sap.registerModulePath("com.presalescentral.utility", "../../pcutility/webapp");
            // jQuery.sap.registerModulePath("com.presalescentral.opportunity", "../../pcopportunity/webapp");
            // } else {
            //	jQuery.sap.registerModulePath("com.presalescentral.utility", "../../sap/fiori/pcutility/webapp");
            // jQuery.sap.registerModulePath("com.presalescentral.opportunity", "../../sap/fiori/pcopportunity/webapp");
            // if (sap.ushell && sap.ushell.hasOwnProperty("Container")) {
            // 	var oppoPath = "../../sap/fiori/pcopportunity/webapp";
            // 	var url = document.location.ancestorOrigins["0"];
            // 	if (url && url.includes("cfapps")) {
            // 		oppoPath = "../../fiori/pcopportunity/webapp";
            // 	}
            // 	jQuery.sap.registerModulePath("com.presalescentral.opportunity", oppoPath);
            // } else {
            // 	jQuery.sap.registerModulePath("com.presalescentral.opportunity", "../../pcopportunity/webapp");
            // }
            // jQuery.sap.require("com.presalescentral.opportunity.Component");
            // }
            //jQuery.sap.require("com.presalescentral.utility.Component");
            // jQuery.sap.require("com.presalescentral.opportunity.Component");
          } catch (err) {
            Log.setLevel(jQuery.sap.log.Level.INFO);
            MessageToast.show("couldn't load Component " + err);
          }
        },
        /*	onOreLoaded: function (oEvent) {
				let oUserModel = oEvent.getSource().getComponentInstance().getModel("user");
				this.utilityComponentModel = oEvent.getSource().getComponentInstance().getModel("oreModel");
				oUserModel.getProperty("/UserId");
				this.getOwnerComponent().setModel(oUserModel, "user");
				//	oUserModel.setData({
				//		"appId": 'ACTVT'
				//	}, true);
				this.getTeamOpportunity();
			},*/
        getMyTeamData: function () {
          let that = this;
          this.getOwnerComponent()
            .getModel("utilityModel")
            .metadataLoaded()
            .then(() => {
              //	let loggedUserId = this.getOwnerComponent().getModel("user").getData().UserId;
              UtilityService.getMyTeamData()
                .then(({ data }) => {
                  //	that.fnMasterDataSuccess("myTeamData", data.results);
                  let oModel = that.getModel("masterData");
                  oModel.setProperty("/myTeamData", data.results);
                  this.slManagerTeamStorage.put(
                    "SlManagerTeamData",
                    data.results
                  );
                  that.getTeamOpportunity();
                })
                .catch(function (error) {
                  Log.error("This should never have happened:" + error);
                });
              //	var s = oppService.getTeamOpportunityData();
            })
            .catch(function (error) {
              Log.error("This should never have happened:" + error);
            });
        },
        getTeamOpportunity: function () {
          //	this.getOwnerComponent().getModel("int_pg_opportunityoDataModel");
          let that = this;
          this.getOwnerComponent()
            .getModel("int_pg_opportunityoDataModel")
            .metadataLoaded()
            .then(() => {
              //	let loggedUserId = this.getOwnerComponent().getModel("user").getData().UserId;
              let aAllUsera = that.getModel("masterData").getData().myTeamData;
              //Production issue fix for 10K+ Opportunity Data
              OppService.getTeamOpportunityData(aAllUsera)
                .then((data) => {
                  let batchCount = 100;
                  let aResponse = $.extend(true, [], data);
                  let totalRecords = aResponse.length;
                  let totalBatches = Math.ceil(totalRecords / batchCount);
                  let aPromise = [];
                  for (let i = 0; i < totalBatches; i++) {
                    let startIndex = i * batchCount;
                    let endIndex = startIndex + batchCount;
                    let batchCallRecords = aResponse.slice(
                      startIndex,
                      endIndex
                    );
                    aPromise.push(
                      OppService.getOpportunities(batchCallRecords)
                    );
                  }
                  if (aPromise.length) {
                    Promise.allSettled(aPromise)
                      .then((aResponse) => {
                        aResponse = aResponse || [];
                        let aTempResult = aResponse.map((odata) => {
                          return odata["value"] || [];
                        });
                        let aOppResponseData = [].concat(...aTempResult);
                        if (aOppResponseData.length) {
                          let aConcatData = [];
                          for (let i = 0; i < aOppResponseData.length; i++) {
                            aConcatData = aConcatData.concat(
                              aOppResponseData[i].data.results
                            );
                          }
                          that._createOpportunityMap(aConcatData);
                        }
                      })
                      .catch();
                  }
                })
                .catch(function (error) {
                  Log.error("This should never have happened:" + error);
                });
              //	var s = oppService.getTeamOpportunityData();
            })
            .catch(function (error) {
              //	MessageToast.show("Opportunity data unavilable! /n Reason: Harmony server down /n or Unauthorized access!");
              Log.error("This should never have happened:" + error);
            });
        },

        _createOpportunityMap: function (aOpportunities) {
          this.opportunitiesMap = {};
          this.aOpportunitiesOwner = {};
          this.aOpportunitiesAccount = {};
          //	if (aOpportunities.length) {
          $.each(
            aOpportunities,
            function (idx, obj) {
              if (!this.aOpportunitiesOwner[obj.OPPT_ID]) {
                this.opportunitiesMap[obj.OPPT_ID] = obj;
              }
              this.opportunitiesMap[obj.OPPT_ID] = obj;
              if (!this.aOpportunitiesOwner[obj.OWNER]) {
                this.aOpportunitiesOwner[obj.OWNER] = obj;
              }
              if (!this.aOpportunitiesAccount[obj.ACCOUNT]) {
                this.aOpportunitiesAccount[obj.ACCOUNT] = obj;
              }
            }.bind(this)
          );
          //	}
          /*$.each(aOpportunities, function (index, value) {
				if (!this.aOpportunitiesOwner[value.OWNER]) {

					this.aOpportunitiesOwner[value.OWNER] = value;
				}
			}.bind(this));
			$.each(aOpportunities, function (index, value) {
				if (!this.aOpportunitiesAccount[value.ACCOUNT]) {

					this.aOpportunitiesAccount[value.ACCOUNT] = value;
				}
			}.bind(this));*/
          this.getOwnerComponent()
            .getModel("opportunityData")
            .setProperty("/opportunityMapData", this.opportunitiesMap);
          this.getOwnerComponent()
            .getModel("oppOwnerData")
            .setProperty("/opportunityOwner", this.aOpportunitiesOwner);
          this.getOwnerComponent()
            .getModel("oppAccountData")
            .setProperty("/opportunityAccount", this.aOpportunitiesAccount);
          this.getOwnerComponent()
            .getModel("opportunityData")
            .setProperty("/opportunityLoaded", true);
          this.getOwnerComponent()
            .getModel("masterSettings")
            .setProperty("/masterOpportunityDataLoaded", true);
          this.slOpportuities.put(
            "SlopportunityMapData",
            this.opportunitiesMap
          );
          this.slOpportuities.put(
            "SlaOpportunitiesOwner",
            this.aOpportunitiesOwner
          );
          this.slOpportuities.put(
            "SlaOpportunitiesAccount",
            this.aOpportunitiesAccount
          );

          var oSlModel = this.getOwnerComponent().getModel("slListModel");
          var aSlData = oSlModel.getProperty("/slData");
          if (aSlData.length > 0) {
            this.updateSlList();
          }
          var slDetailModel =
            this.getOwnerComponent().getModel("SlDetailModel");
          var sOppId = slDetailModel.getProperty("/OpportunityId");
          // console.log(sOppId);
          if (sOppId) {
            this.updateSlDetailOppData();
          }
        },
      }
    );
  }
);
