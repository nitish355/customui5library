sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/ui/core/UIComponent",
	"com/presalescentral/successline/model/Formatter",
	"com/presalescentral/successline/service/UtilityService",
	"com/presalescentral/successline/classes/RapidRegistration",
	"com/melody/lib/util/UserMaster",
	"com/melody/lib/util/mtr/MTRModels",
	"com/melody/lib/util/Activity",
	"com/melody/lib/util/mtr/MTRHelper",
	"com/melody/lib/classes/Activity",
], function (Controller, History, UIComponent, Formatter, UtilityService, RapidRegistration, UserMaster, MTRModels, ActivityUtil,
	MTRHelper, MTRActivity) {
	"use strict";

	return Controller.extend("com.presalescentral.successline.controller.BaseController", {
		/**
		 * @type com.presalescentral.ore.model.formatter
		 * @private
		 */
		Formatter: Formatter,

		/**
		 * Convenience method for accessing the event bus.
		 * @protected
		 * @returns {sap.ui.core.EventBus} the event bus for this component
		 */
		getEventBus: function () {
			return this.getOwnerComponent().getEventBus();
		},
		/**
		 * This function applies initial view settings like
		 * 1. Content Density - Compact(Desktop) or Cozy(Mobile/Tablet)
		 * @protected
		 */
		initView: function () {
			if (sap.ui.Device.system.desktop) { // apply compact mode if touch is not supported
				this.getView().addStyleClass("sapUiSizeCompact");
			}
			UserMaster._getUserDetail();
		},
		getRouter: function () {
			return UIComponent.getRouterFor(this);
		},

		/**
		 * Convenience method for getting the view model by name.
		 * @potected
		 * @param {string} [sName] the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function (sName) {
			return this.getView().getModel(sName);
		},

		onNavBack: function () {

			var oHistory, sPreviousHash;

			oHistory = History.getInstance();
			sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				//	this.getRouter().navTo("SlList", {}, true /*no history*/ );
				var oCrossAppNavigator = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService("CrossApplicationNavigation");
				if (oCrossAppNavigator) {
					oCrossAppNavigator.backToPreviousApp();
				}
			}
		},
		navToList: function (oEvent, flag) {
			this.getRouter().navTo("SlList");
		},
		navToForm: function (oEvent, flag) {
			this.getRouter().navTo("SlForm");
		},
		navToDetail: function (oEvent, flag) {
			this.getRouter().navTo("SlDetail");
		},
		updateSlList: function () {
			var oSlModel = this.getOwnerComponent().getModel("slListModel");
			var aSlData = oSlModel.getProperty("/slData");
			var oOppMap = this.getOwnerComponent().getModel("opportunityData").getData();
			for (var i = 0; i < aSlData.length; i++) {
				const oOpportunity = oOppMap.opportunityMapData[aSlData[i].Opporutnityid];
				if (oOpportunity) {
					aSlData[i].OpportunityName = oOpportunity.DESCRIPTION;
					aSlData[i].OpportunityPhase = oOppMap.oppPhaseMasterData[
						oOpportunity.CURR_PHASE].VALUE;
					aSlData[i].OpportunityStatus = oOppMap.oppStatusMasterData[
						oOpportunity.STATUS].VALUE;
				}
			}
			oSlModel.refresh(true);
		},
		updateSlDetailOppData: function () {
			var slDetailModel = this.getOwnerComponent().getModel("SlDetailModel");
			var sOppId = slDetailModel.getProperty("/OpportunityId");
			var oOppMap = this.getOwnerComponent().getModel("opportunityData").getData();
			const oOpportunity = oOppMap.opportunityMapData[sOppId];
			if (oOpportunity) {
				const obj = {
					"ACCOUNT_NAME": oOpportunity.ACCOUNT_NAME,
					"DESCRIPTION": oOpportunity.DESCRIPTION,
					"OWNER_NAME": oOpportunity.OWNER_NAME,
					"STATUS": oOpportunity.STATUS,
					// "STATUS_DESC": oOppMap.oppStatusMasterData[oOpportunity.STATUS].VALUE,
					// "SALES_PHASE": oOppMap.oppPhaseMasterData[oOpportunity.CURR_PHASE].VALUE,
					"INDUSTRY": oOpportunity.INDUSTRY_MASTERCODE_TEXT
				};
				slDetailModel.setProperty("/SelectedOpportunity", obj);
				// console.log(obj);
			}
			slDetailModel.refresh(true);
		},
		harmonyServiceCheck: function () {
			if (this.getOwnerComponent().getModel("int_pg_opportunityoDataModel").isMetadataLoadingFailed()) {
				return false;
			} else {
				return true;
			}
		},
		fnAdminAccess: function () {
			UtilityService.getAuth("SLTEMP")
				.then(({
					data
				}) => {
					if (data) {
						if (data.AuthFlg === "X") {
							return true;
						} else {
							this.getOwnerComponent().getRouter().getTargets().display("notAuthorized", {
								fromTarget: "SlAdminList"
							});
						}
					}
				});
		},
		//Call Rapid Registration method to open fragment
		handleRapidRegistration: function (key, oActv, oSource) {
			if (oActv.ActivityId === "0108") {
				this.RapidRegistration.fnOpenRapidRegDialog(key, oActv, oSource, "CustomerAction");
			} else {
				this.RapidRegistration.fnOpenRapidRegDialog(key, oActv, oSource);
			}
		},

		//defaut time entry value changes
		//Function to get MTR Tasks for a selected Activity based on Association type
		fnGetSelectedActMTRTask: async function (oActvt) {
			var activityTypeId = oActvt.ActivityId;
			var associateType = parseInt(oActvt.ActvtAsstdID, 10);
			var aMTRTasks = [];
			var sActivityId = parseInt(oActvt.RegisteredActId, 10);
			let oMTRModel = this.getOwnerComponent().getModel("oMTRModel");
			var oSettings = MTRModels.getMTRSettingsModel().getData();
			if (oSettings && oSettings.ActivityRecording === "1") {
				if (sActivityId) {
					var aUserActivities = await ActivityUtil.getUserActivities(true);
					var oSelActivity = this.getActivityFromUserActivities(sActivityId, aUserActivities);
					var MTRActivity = this.fnSetMTRActivityObj(oSelActivity);
					if (!MTRActivity || (MTRActivity && MTRActivity.ActivitySetStatus && MTRActivity.ActivitySetStatus !== "")) {
						aMTRTasks = [];
					} else {
						aMTRTasks = await MTRHelper.filterMtrTasks(MTRActivity);
					}
				} else {
					aMTRTasks = await MTRHelper.getActivityTypeTaskMapping(activityTypeId, associateType);
				}
			}
			if (aMTRTasks.length === 2) {
				// this.fnSetRequestorTimeEntryVisible(oLayoutModel, isRequestor);
			} else if (aMTRTasks.length === 1) {
				// this.fnSetRequestorTimeEntryVisible(oLayoutModel, isRequestor);
				oMTRModel.setProperty("/IsCustomerFacing", false);
				oMTRModel.setProperty("/EstimatedTime", "0.0");
			} else {
				oMTRModel.setProperty("/EstimatedTime", "0.0");
				oMTRModel.setProperty("/NCFEstimatedTime", "0.0");
			}
			oMTRModel.setProperty("/aMTRTasks", aMTRTasks);
			return aMTRTasks;
		},

		//Function to get selected activity from UserActivities list
		getActivityFromUserActivities: function (sActivityId, aUserActivities) {
			var oSelActivity = aUserActivities.find(function (oActivity) {
				return oActivity["ActivityId"] === sActivityId.toString();
			});
			return oSelActivity;
		},

		//Function to set MTRActivity object to library
		fnSetMTRActivityObj: function (oSelActivity) {
			var oMTRActivity = new MTRActivity(oSelActivity);
			oMTRActivity.ProjectType = "ACTVT";
			return oMTRActivity;
		},

	});
});