sap.ui.define([
		"com/presalescentral/successline/controller/BaseController",
		"sap/ui/core/routing/History"
], function (BaseController, History) {
	"use strict";

	return BaseController.extend("com.presalescentral.successline.controller.ServiceDown", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.presalescentral.successline.view.NotFound
		 */
		onInit: function () {

		},
		onNavBack: function(){
			var oHistory, sPreviousHash;

			oHistory = History.getInstance();
			sPreviousHash = oHistory.getPreviousHash();
			if(sPreviousHash === "SlForm"){
			window.history.go(-2);	
			}else if(sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				//	this.getRouter().navTo("SlList", {}, true /*no history*/ );
				var oCrossAppNavigator = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService("CrossApplicationNavigation");
				if (oCrossAppNavigator) {
					oCrossAppNavigator.backToPreviousApp();
				}
			}
		},
		navtoDashboard: function(){
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
				var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
					target: {
						semanticObject: "pc",
						action: "app"
					}
				})) || "";
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: hash
					}
				});
		}
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.presalescentral.successline.view.NotFound
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.presalescentral.successline.view.NotFound
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.presalescentral.successline.view.NotFound
		 */
		//	onExit: function() {
		//
		//	}

	});

});