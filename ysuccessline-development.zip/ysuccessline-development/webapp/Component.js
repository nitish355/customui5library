sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"sap/ui/model/json/JSONModel",
	"com/presalescentral/successline/model/Models",
	"com/presalescentral/successline/service/OppService",
	"com/presalescentral/successline/service/SLService",
	"com/presalescentral/successline/Application",
	"com/melody/lib/util/MTR",
	"com/melody/lib/util/Activity",
	"com/melody/lib/util/UserMaster"
], function (UIComponent, Device, JSONModel, models, OppService, SLService, Application, MTRUtil, ActivityUtil, UserMaster) {
	"use strict";

	return UIComponent.extend("com.presalescentral.successline.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			const slListModel = new JSONModel({
				slData: []
			});
			this.setModel(slListModel, "slListModel");
			const SlDetailModel = new JSONModel();
			this.setModel(SlDetailModel, "SlDetailModel");

			var that = this;
			UserMaster.authenticate().then(function (data) {
				that.getModel("user").setProperty("/", data);
				that.getModel("user").setProperty("/appId", "ACTVT");
			});

			MTRUtil.getUserMtrSettings().then(function (response) {
				if (response && response.UserSetting) {
					var oUserSetting = response.UserSetting;
					MTRUtil.getEntries(oUserSetting.UserGuid).then(function (entries) {
						that.getModel("oMTRModel").setProperty("/savedEntries", entries);
						ActivityUtil.getUserActivities()
							.then(function (activities) {
								that.getModel("userActivityMaster").setData(activities);
							});
						//	oSavedEntriesModel.setData(entries);
					});
				}
				//	that.getRouter().initialize();
			});

			//this._initApp();
			Application.getInstance().init(this);
			
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);
			//	this.Component.getModel("int_pg_opportunityoDataModel").setUseBatch(true);

			// enable routing
			//	this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		}
	});
});