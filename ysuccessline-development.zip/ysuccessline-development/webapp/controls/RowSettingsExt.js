/*!
 * ${copyright}
 */
// Provides control com.sample.test.controls.ArrowTitle.
sap.ui.define([
		"jquery.sap.global",
		"sap/ui/table/RowSettings",
		"sap/ui/Device",
		"sap/base/Log",
		"com/presalescentral/successline/controls/types/TextDirection"
	],
	function (jQuery, RowSettings, Device, Log, TextDirection) {
		"use strict";
		/**
		 * Constructor for a ArrowTitle control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends sap/ui/table/RowSettings
		 *
		 * @author SAP SE
		 * @version ${version}
		 *
		 * @constructor
		 * @private
		 * @alias com.presalescentral.successline.controls.RowSettingsExt
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */
		var RowSettingsExt = RowSettings.extend("com.presalescentral.successline.controls.RowSettingsExt", {
			metadata: {
				properties: {
					color: "string"
				}
			},

			init: function () {
				RowSettings.prototype.init.call(this);
			},

			setColor: function (sValue) {
				let color = sValue;
				if(!color) {
					color = "white";
				}
				this.setProperty("color", color.toLowerCase(), true);
				let sRowId = this.getParent().getId();
				
				$("#" + sRowId + "-highlight").css({"background-color": color});
				return this;
			},

			onAfterRendering: function () {
				if (RowSettings.prototype.onAfterRendering) {
					RowSettings.prototype.onAfterRendering.apply(this, arguments);
				}
				var sColor = this.getColor();
				this.setColor(sColor);
			},
			_getHighlightText: function () {
                var sColor = this.getColor();
                this.setColor(sColor);
                if (RowSettings.prototype._getHighlightText) {
                    return RowSettings.prototype._getHighlightText.apply(this);
                }
            }

		});

		return RowSettingsExt;
	}, /* bExport= */ true);