/*!
 * ${copyright}
 */

sap.ui.define(["jquery.sap.global"],

	function ( /*jQuery*/ ) {
		"use strict";

		/**
		 * RowSettingsExt renderer.
		 * @namespace
		 */
		var RowSettingsExtRenderer = {};

		/**
		 * Renders the HTML for the given control, using the provided
		 * {@link sap.ui.core.RenderManager}.
		 *
		 * @param {sap.ui.core.RenderManager} oRm
		 *            the RenderManager that can be used for writing to
		 *            the Render-Output-Buffer
		 * @param {sap.ui.core.Control} oControl
		 *            the control to be rendered
		 */
		RowSettingsExtRenderer.render = function (oRm, oControl) {
			sap.ui.table.RowSettingsRenderer.render(oRm, oControl); //use supercass renderer routine
		};

		return RowSettingsExtRenderer;

	}, /* bExport= */ true);