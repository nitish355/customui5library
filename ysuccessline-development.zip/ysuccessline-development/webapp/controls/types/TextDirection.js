sap.ui.define({
  Top: "Top",
  Bottom: "Bottom",
  Left: "Left",
  Right: "Right"
}, true);