/*!
 * ${copyright}
 */

sap.ui.define(["jquery.sap.global"],

	function ( /*jQuery*/ ) {
		"use strict";

		/**
		 * ArrowTitle renderer.
		 * @namespace
		 */
		var ArrowTitleRenderer = {};

		/**
		 * Renders the HTML for the given control, using the provided
		 * {@link sap.ui.core.RenderManager}.
		 *
		 * @param {sap.ui.core.RenderManager} oRm
		 *            the RenderManager that can be used for writing to
		 *            the Render-Output-Buffer
		 * @param {sap.ui.core.Control} oControl
		 *            the control to be rendered
		 */
		ArrowTitleRenderer.render = function (oRm, oControl) {
			sap.m.TitleRenderer.render(oRm, oControl); //use supercass renderer routine
			oControl.addStyleClass("arrowTitle");
		};

		return ArrowTitleRenderer;

	}, /* bExport= */ true);