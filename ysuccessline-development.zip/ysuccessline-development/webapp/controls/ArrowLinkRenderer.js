/*!
 * ${copyright}
 */

sap.ui.define(["jquery.sap.global"],

	function ( /*jQuery*/ ) {
		"use strict";

		/**
		 * ArrowTitle renderer.
		 * @namespace
		 */
		var ArrowLinkRenderer = {};

		/**
		 * Renders the HTML for the given control, using the provided
		 * {@link sap.ui.core.RenderManager}.
		 *
		 * @param {sap.ui.core.RenderManager} oRm
		 *            the RenderManager that can be used for writing to
		 *            the Render-Output-Buffer
		 * @param {sap.ui.core.Control} oControl
		 *            the control to be rendered
		 */
		ArrowLinkRenderer.render = function (oRm, oControl) {
			sap.m.LinkRenderer.render(oRm, oControl); //use supercass renderer routine
			// oControl.addStyleClass("arrowTitle");
		};

		return ArrowLinkRenderer;

	}, /* bExport= */ true);