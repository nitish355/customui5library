/*!
 * ${copyright}
 */
// Provides control com.sample.test.controls.ArrowTitle.
sap.ui.define([
		"jquery.sap.global",
		"sap/m/Title",
		"sap/ui/Device",
		"sap/base/Log",
		"com/presalescentral/successline/controls/types/TextDirection"
	],
	function (jQuery, Title, Device, Log, TextDirection) {
		"use strict";
		/**
		 * Constructor for a ArrowTitle control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends sap/suite/ui/commons/networkgraph/Node
		 *
		 * @author SAP SE
		 * @version ${version}
		 *
		 * @constructor
		 * @private
		 * @alias com.sample.test.controls.ArrowTitle
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */
		var ArrowTitle = Title.extend("com.presalescentral.successline.controls.ArrowTitle", {
			metadata: {
				properties: {
					color: "string"
				}
			},

			init: function () {
				Title.prototype.init.call(this);

				var libraryPath = jQuery.sap.getModulePath("com.presalescentral.successline"); //get the server location of the ui library
				jQuery.sap.includeStyleSheet(libraryPath + "/controls/ArrowTitle.css"); //specify the css path relative from the ui folder
			},

			setColor: function (sValue) {
				let color = sValue;
				if(!color) {
					color = "red";
				}
				this.setProperty("color", color.toLowerCase(), true);
				this.$().find("span").css({"background-color": color, "border-left-color": color});
				return this;
			},

			onAfterRendering: function () {
				if (Title.prototype.onAfterRendering) {
					Title.prototype.onAfterRendering.apply(this, arguments);
				}
				var sColor = this.getColor();
				this.setColor(sColor);
			}

		});

		return ArrowTitle;
	}, /* bExport= */ true);