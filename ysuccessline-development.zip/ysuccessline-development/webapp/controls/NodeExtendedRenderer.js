/*!
 * ${copyright}
 */

sap.ui.define(["jquery.sap.global"],

	function ( /*jQuery*/ ) {
		"use strict";

		/**
		 * ExpectedDurationBar renderer.
		 * @namespace
		 */
		var NodeExtendedRenderer = {};

		/**
		 * Renders the HTML for the given control, using the provided
		 * {@link sap.ui.core.RenderManager}.
		 *
		 * @param {sap.ui.core.RenderManager} oRm
		 *            the RenderManager that can be used for writing to
		 *            the Render-Output-Buffer
		 * @param {sap.ui.core.Control} oControl
		 *            the control to be rendered
		 */
		NodeExtendedRenderer.render = function (oRm, oControl) {
			sap.suite.ui.commons.networkgraph.NodeRenderer.render(oRm, oControl); //use supercass renderer routine
		};

		return NodeExtendedRenderer;

	}, /* bExport= */ true);