sap.ui.define(["sap/m/Avatar"], function (Control) {
	"use strict";

	return Control.extend("com.presalescentral.successline.controls.HoverButton", {
		 metadata: {
          events: {
              "hover" : {}  // this Button has also a "hover" event, in addition to "press" of the normal Button
          }
      },
  
      // the hover event handler:
      onmouseover : function(evt) {   // is called when the Button is hovered - no event registration required
          this.fireHover();
      },

      renderer: {} // add nothing, just inherit the ButtonRenderer as is; 
                   // In this case (since the renderer is not changed) you could also specify this explicitly with:  renderer:"sap.m.ButtonRenderer"
                   // (means you reuse the ButtonRenderer instead of creating a new view
	});
});
