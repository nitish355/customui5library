/*!
 * ${copyright}
 */
// Provides control com.sample.test.controls.PhaseNavigation.
sap.ui.define(["jquery.sap.global", "sap/ui/core/Control"],
	function (jQuery, Control) {
		"use strict";
		/**
		 * Constructor for a ExpectedDurationBar control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends sap.ui.core.Control
		 *
		 * @author SAP SE
		 * @version ${version}
		 *
		 * @constructor
		 * @private
		 * @alias com.sample.test.controls.PhaseNavigation
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */
		var that;
		var PhaseNavigation = Control.extend("com.presalescentral.successline.controls.PhaseNavigation", {
			metadata: {
				properties: {

				},

				aggregations: {
					phases: {
						type: "sap.m.List",
						multiple: false,
						visibility: "hidden"
					}
				},

				events: {
					/**
					 * Event is fired when the user selects phase.
					 */
					select: {
						parameters: {
							phase: {
								type: "string"
							},
							listItem: {
								type: sap.m.ListItemBase
							},
							selected: {
								type: "boolean"
							},
							selectAll: {
								type: "boolean"
							}
						}
					}
				}
			},
			init: function () {
				that = this;
				//initialisation code, in this case, ensure css is imported
				var libraryPath = jQuery.sap.getModulePath("com.presalescentral.successline"); //get the server location of the ui library
				jQuery.sap.includeStyleSheet(libraryPath + "/controls/PhaseNavigation.css"); //specify the css path relative from the ui folder

				this.setAggregation("phases", new sap.m.List({
					mode: sap.m.ListMode.SingleSelectMaster,
					items: [
						new sap.m.CustomListItem({
							content: new sap.ui.core.HTML("phase-f", {
								// the static content as a long string literal
								content: '<span class="phase">F</span><span class="phase-name">Recognize</span>'
							})
						}).addStyleClass("phase-f").data("phase", "P1"),
						new sap.m.CustomListItem({
							content: new sap.ui.core.HTML("phase-e", {
								// the static content as a long string literal
								content: '<span class="phase">E</span><span class="phase-name">Consider</span>'
							})
						}).addStyleClass("phase-e").data("phase", "P2"),
						new sap.m.CustomListItem({
							content: new sap.ui.core.HTML("phase-d", {
								// the static content as a long string literal
								content: '<span class="phase">D</span><span class="phase-name">Evaluate</span>'
							})
						}).addStyleClass("phase-d").data("phase", "P3"),
						new sap.m.CustomListItem({
							content: new sap.ui.core.HTML("phase-c", {
								// the static content as a long string literal
								content: '<span class="phase">C</span><span class="phase-name">Select</span>'
							})
						}).addStyleClass("phase-c").data("phase", "c"),
						new sap.m.CustomListItem({
							content: new sap.ui.core.HTML("phase-b", {
								// the static content as a long string literal
								content: '<span class="phase">B</span><span class="phase-name">Negotiate</span>'
							})
						}).addStyleClass("phase-b").data("phase", "b"),
						new sap.m.CustomListItem({
							content: new sap.ui.core.HTML("phase-a", {
								// the static content as a long string literal
								content: '<span class="phase">A</span><span class="phase-name">Purchase</span>'
							})
						}).addStyleClass("phase-a").data("phase", "a"),
						new sap.m.CustomListItem({
							content: new sap.ui.core.HTML("phase-h", {
								// the static content as a long string literal
								content: '<span class="phase">H</span><span class="phase-name">Handover</span>'
							})
						}).addStyleClass("phase-h").data("phase", "h")
					],
					selectionChange: function (oEvent) {
						var listItem = oEvent.getParameter("listItem");
						that.fireEvent("select", {
							phase: listItem.data("phase"),
							listItem: oEvent.getParameter("listItem"),
							selected: oEvent.getParameter("selected"),
							selectAll: oEvent.getParameter("selectAll")
						});
					}
				}).addStyleClass("statusIndicator"));
			},
			onAfterRendering: function () {}
		});
		return PhaseNavigation;
	}, /* bExport= */ true);