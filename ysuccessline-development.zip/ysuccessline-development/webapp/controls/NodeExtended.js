/*!
 * ${copyright}
 */
// Provides control com.sample.test.controls.NodeExtended.
sap.ui.define([
		"jquery.sap.global",
		"sap/suite/ui/commons/networkgraph/Node",
		"sap/ui/Device",
		"sap/base/Log",
		"com/presalescentral/successline/controls/types/TextDirection"
	],
	function (jQuery, Node, Device, Log, TextDirection) {
		"use strict";
		/**
		 * Constructor for a NodeExtended control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends sap/suite/ui/commons/networkgraph/Node
		 *
		 * @author SAP SE
		 * @version ${version}
		 *
		 * @constructor
		 * @private
		 * @alias com.sample.test.controls.NodeExtended
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */
		var NodeExtended = Node.extend("com.presalescentral.successline.controls.NodeExtended", {
			metadata: {
				properties: {
					/**
					 * phase
					 */
					phase: {
						type: "string",
						defaultValue: ""
					},
					/**
					 * text direction
					 */
					textDirection: {
						type: "com.presalescentral.successline.controls.types.TextDirection",
						defaultValue: "Bottom"
					},
					color: "string",
					enabled: {		// enabled
						type: "boolean",
						defaultValue: true
					}
				}
			},

			init: function () {
				Node.prototype.init.call(this);

				var libraryPath = jQuery.sap.getModulePath("com.presalescentral.successline"); //get the server location of the ui library
				jQuery.sap.includeStyleSheet(libraryPath + "/controls/NodeExtended.css"); //specify the css path relative from the ui folder
			},

			setTextDirection: function (sTextDirection) {
				this.setProperty("textDirection", sTextDirection);
				switch (sTextDirection) {
				case TextDirection.Top:
					this.$().css("flex-direction", "column-reverse");
					this.$().find(".sapSuiteUiCommonsNetworkGraphDivInnerWrapper").css("top", "-1.4rem");
					this.$().find(".sapSuiteUiCommonsNetworkGraphDivNodeTitle").css("top", "-1.4rem");
					break;
				case TextDirection.Bottom:
					this.$().css("flex-direction", "column");
					break;
				case TextDirection.Left:
					this.$().css("flex-direction", "row-reverse");
					this.$().find(".sapSuiteUiCommonsNetworkGraphDivInnerWrapper").css("left", "-3rem");
					this.$().find(".sapSuiteUiCommonsNetworkGraphDivNodeTitle").css("left", "-3rem");
					break;
				case TextDirection.Right:
					this.$().css("flex-direction", "row");
					this.$().find(".sapSuiteUiCommonsNetworkGraphDivInnerWrapper").css("left", "3rem");
					this.$().find(".sapSuiteUiCommonsNetworkGraphDivNodeTitle").css("left", "3rem");
					break;
				default:
					Log.error("TextDirection value is incorrect");
				}
			},

			setPhase: function (sPhase) {
				this.setProperty("phase", sPhase);
				this.$().attr("data-phase", sPhase);
			},

			setColor: function (sValue) {
				this.setProperty("color", sValue.toLowerCase(), true);
				/*if(sValue) {
					this.$().find(".sapSuiteUiCommonsNetworkDivCircleWrapper").css("border-color", sValue.toLowerCase());
				}*/
				/* else {
									this.$().find(".sapSuiteUiCommonsNetworkGraphDivInner").css("border-color", sValue.toLowerCase());
								}*/

				return this;
			},
			
			setEnabled: function(bValue) {
				/*if(bValue) {
					this.$().removeClass("disabled");
				} else {
					this.$().addClass("disabled");
				}*/
				
				this.setProperty("enabled", bValue, true);
			},

			onAfterRendering: function () {
				if (Node.prototype.onAfterRendering) {
					Node.prototype.onAfterRendering.apply(this, arguments);
				}
				var sPhase = this.getPhase();
				this.$().attr("data-phase", sPhase);

				var sTextDirection = this.getTextDirection();
				this.setTextDirection(sTextDirection);

				var sColor = this.getColor();
				this.setColor(sColor);
				
				var bEnabled = this.getEnabled();
				this.setEnabled(bEnabled);
			}

		});

		return NodeExtended;
	}, /* bExport= */ true);