/*!
 * ${copyright}
 */
// Provides control com.sample.test.controls.ArrowTitle.
sap.ui.define([
		"jquery.sap.global",
		"sap/ui/table/RowSettings"
	],
	function (jQuery, RowSettings) {
		"use strict";
		/**
		 * Constructor for a ArrowTitle control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends sap/suite/ui/commons/networkgraph/Node
		 *
		 * @author SAP SE
		 * @version ${version}
		 *
		 * @constructor
		 * @private
		 * @alias com.sample.test.controls.ArrowTitle
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */
		var CustomRowSettings = RowSettings.extend("com.presalescentral.successline.controls.CustomRowSettings", {
			metadata: {
				properties: {
					color: {		
						type: "string",
						defaultValue: "#ffff"
					}
				}
			},

			init: function () {
				RowSettings.prototype.init.call(this);

			/*	var libraryPath = jQuery.sap.getModulePath("com.presalescentral.successline"); //get the server location of the ui library
				jQuery.sap.includeStyleSheet(libraryPath + "/controls/RowSettings.css"); //specify the css path relative from the ui folder*/
			},

			setColor: function (sValue) {
				let color = sValue;
				if(!color) {
					color = "#ffff";
				}
				this.setProperty("color", color);
				this.getParent().$().css({"background-color": color});
				return this;
			},

			onAfterRendering: function () {
				if (RowSettings.prototype.onAfterRendering) {
					RowSettings.prototype.onAfterRendering.apply(this, arguments);
				}
				
				var sColor = this.getColort();
				this.setColor(sColor);
			}

		});

		return CustomRowSettings;
	}, /* bExport= */ true);