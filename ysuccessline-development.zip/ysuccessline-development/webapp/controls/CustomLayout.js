sap.ui.define([
	"sap/suite/ui/commons/library",
	"sap/suite/ui/commons/networkgraph/layout/LayoutAlgorithm",
	"sap/suite/ui/commons/networkgraph/layout/LayoutTask"
], function (library, LayoutAlgorithm, LayoutTask) {

	var LayoutRenderType = library.networkgraph.LayoutRenderType;

	return LayoutAlgorithm.extend("com.presalescentral.successline.controls.CustomLayout", {
		getLayoutRenderType: function () {
			return LayoutRenderType.LayeredWithGroups;
		},
		layout: function () {
			return new LayoutTask(function (fnResolve, fnReject, oLayoutTask) {
				// The task might have been canceled by a newer update call. Do not update graph as it might collide
				// with another layout task.
				if (oLayoutTask.isTerminated()) {
					fnResolve();
					return;
				}

				var oGraph = this.getParent(),
					aNodes = oGraph.getNodes(),
					aLines = oGraph.getLines();

				var x = 0, y = -100, count = 1;
				$.each(aNodes, function (index, node) {
					
					if(count % 2 === 0) {
						x = 150;
					} else if(count % 3 === 0 ) {
						
						x = 250;
					} else {
						x = 50;
						
					}
					y += 150;
					aNodes[index].setX(x);
					aNodes[index].setY(y);
					count += 1;
					if(count > 3) {
						count = 0;
					}
				}.bind(this));

				for(let i = 0; i < aLines.length; i++) {
					const oSourceNode = aNodes.find(node => {
						return node.getKey() === aLines[i].getFrom();	
					});
					
					const oTargetNode = aNodes.find(node => {
						return node.getKey() === aLines[i].getTo();	
					});
					
					const oSourceNodeCenter = oSourceNode.getCenterPosition();
					
					const oTargetNodeCenter = oTargetNode.getCenterPosition();
					
					aLines[i].setSource({
						x: oSourceNodeCenter.x,
						y: oSourceNodeCenter.y
					});

					aLines[i].setTarget({
						x: oTargetNodeCenter.x,
						y: oTargetNodeCenter.y
					});
					
					aLines[i].addBend({
						x: oSourceNodeCenter.x,
						y: oSourceNodeCenter.y + 150
					});
				}

				fnResolve();
			}.bind(this));
		}
	});
});