/*!
 * ${copyright}
 */

sap.ui.define(["jquery.sap.global"],

	function ( /*jQuery*/ ) {
		"use strict";

		/**
		 * ExpectedDurationBar renderer.
		 * @namespace
		 */
		var PhaseNavigationRenderer = {};

		/**
		 * Renders the HTML for the given control, using the provided
		 * {@link sap.ui.core.RenderManager}.
		 *
		 * @param {sap.ui.core.RenderManager} oRm
		 *            the RenderManager that can be used for writing to
		 *            the Render-Output-Buffer
		 * @param {sap.ui.core.Control} oControl
		 *            the control to be rendered
		 */
		PhaseNavigationRenderer.render = function (oRm, oControl) {

			//first up, render a div for the PhaseNavigation
			oRm.write("<div");
			
			oRm.addClass("sidebar");

			//add this controls style class (plus any additional ones the developer has specified)
			oRm.writeClasses(oControl);

			//render width & height & background properties
            /*oRm.write(" style=\"width: " + oControl.getWidth()
                            + "; height: " + oControl.getHeight()
                            + "\"");*/

			//next, render the control information, this handles your sId (you must do this for your control to be properly tracked by ui5).
			oRm.writeControlData(oControl);
			oRm.write(">");
			
			//<div class="sidebar"><ul><li class="phase-f active"><a href="#"><span class="phase">F</span><span class="phase-name">Recognize</span></a></li><li class="phase-e"><a href="#"><span class="phase">E</span><span class="phase-name">Consider</span></a></li><li class="phase-d"><a href="#"><span class="phase">D</span><span class="phase-name">Evaluate</span></a></li><li class="phase-c"><a href="#"><span class="phase">C</span><span class="phase-name">Select</span></a></li><li class="phase-b"><a href="#"><span class="phase">B</span><span class="phase-name">Negotiate</span></a></li><li class="phase-a"><a href="#"><span class="phase">A</span><span class="phase-name">Purchase</span></a></li><li class="phase-h"><a href="#"><span class="phase">H</span><span class="phase-name">Handover</span></a></li></ul></div>

			oRm.renderControl(oControl.getAggregation("phases"));
			
			//and obviously, close off our div
			oRm.write("</div>");

		};

		return PhaseNavigationRenderer;

	}, /* bExport= */ true);