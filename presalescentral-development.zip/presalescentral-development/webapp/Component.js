sap.ui.define(
  [
    "sap/ovp/app/Component",
    "./ext/model/Application",
    "com/melody/lib/util/UserMaster",
  ],
  function (Component, Application, UserMaster) {
    "use strict";
    /**
     * @fileOverview Application component to display information on entities from the GWSAMPLE_BASIC
     *   OData service.
     * @version @version@
     */
    return Component.extend("com.presalescentral.Component", {
      
      metadata: {
        manifest: "json",
      },

      init: function () {
        var that = this;
        Component.prototype.init.apply(this, arguments);
        UserMaster.authenticate().then(function (data) {
          that.getModel("userDetail").setProperty("/", data);
          that.getModel("userDetail").setProperty("/appId", "PCOVP");
        });
      },

      onAfterRendering: function () {
        var oRootControl;
        oRootControl = this.getRootControl();
        if (oRootControl) {
          sap.ui.require("/com/presalescentral/opportunity/Component");
          var oAppParentId = this.getRootControl().getParent().getId();
          var head1 = sap.ui
            .getCore()
            .byId(oAppParentId + "---mainView--ovpMain");
          var oOppoComponentContainer = new sap.ui.core.ComponentContainer({
            id: "pcOpportunityInputComponent",
            name: "com.presalescentral.opportunity",
            propagateModel: true,
            visible: false,
            lifecycle: "Application",
            componentCreated: function (oEvent) {
              sap.ui.getCore().opportunityComponentInstance = oEvent
                .getSource()
                .getComponentInstance();
            },
          });
          head1.getContent().addItem(oOppoComponentContainer);
          this._oApplication = new Application(this);
        }
      },
    });
  }
);
