(function () {
	"use strict";

	/* controller for custom card  */

	sap.ui.controller("com.presalescentral.ext.MyOpportunities.MyOpportunities", {
		onInit: function () {

		},

		statusColorFormat: function (sVal) {
			if (sVal === "E0001") {
				return "In Process";
			}
			return "New";
		},

		onmyOppoSelect: function (evt) {
			var that = this;
			this.sOppID = evt.getSource().getModel("pcJModel").getProperty(evt.getSource().getBindingContextPath() + "/" + "OPPT_ID");
			var oOppoList = this.byId("idOppoList");
			var fnSuccess = function (data) {
				if (data && data.field_value) {
					window.open(data.field_value + that.sOppID, "_blank");
				}
			};
			var fnError = function () {
				jQuery.sap.log.error("Something wrong with harmony navigation");
			};
			var sURL = "/Yc_Md_M_Constants(const_id='0007',project_type='ACTVT',field_name='ACTIVITY_OPP_URL')";
			oOppoList.getModel().read(sURL, {
				success: fnSuccess,
				error: fnError
			});
		},

		onOppoHeaderPress: function () {
			var oParamObj = {
				"variantId": "0000000004"
			};
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "pcactivityset",
					action: "app"
				},
				params: oParamObj
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		}
	});
})();