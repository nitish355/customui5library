(function () {
	"use strict";

	/* controller for custom card  */

	sap.ui.controller("com.presalescentral.ext.MIIndividualContributors.MIIndividualContributors", {

		//Function to handle List Item press event
		onMMICItemSelect: function (oEvent) {
			const item = oEvent.getSource();
			const bindingContext = item.getBindingContext("pcJModel") || {};
			const bindingObject = bindingContext?.getObject() || {};

			if ("url" in bindingObject) {
				const url = bindingObject.url || "";
				if (url.startsWith("http")) {
					window.open(url, "_blank");
				}
			}
		},

	});
})();