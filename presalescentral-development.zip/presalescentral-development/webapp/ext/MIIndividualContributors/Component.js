sap.ui.define(["sap/ovp/cards/custom/Component"], function (Component) {
	"use strict";

	/* component for custom card */
	return Component.extend("com.presalescentral.ext.MIIndividualContributors.Component", {
		// use inline declaration instead of component.json to save 1 round trip
		metadata: {
			properties: {
				"contentFragment": {
					"type": "string",
					"defaultValue": "com.presalescentral.ext.MIIndividualContributors.MIIndividualContributors"
				},
				"headerFragment": {
					"type": "string",
					"defaultValue": "com.presalescentral.ext.MIIndividualContributors.MIIndividualContributorsHeader"
				},
				"footerFragment": {
					"type": "string",
					"defaultValue": ""
				}
			},

			version: "@version@",

			library: "sap.ovp",

			includes: ["../css/pcCards.css"],

			dependencies: {
				libs: ["sap.m"],
				components: []
			},
			config: {},
			customizing: {
				"sap.ui.controllerExtensions": {
					"sap.ovp.cards.generic.Card": {
						controllerName: "com.presalescentral.ext.MIIndividualContributors.MIIndividualContributors"
					}
				}
			}
		}
	});
});