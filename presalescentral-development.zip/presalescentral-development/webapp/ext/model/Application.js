sap.ui.define([
    "sap/ui/base/Object",
    "sap/ovp/cards/PersonalizationUtils",
    "sap/m/MessageBox",
    "sap/ovp/app/resources",
    "sap/ui/fl/write/api/ControlPersonalizationWriteAPI",
    "sap/ui/Device",
    "sap/ui/model/json/JSONModel",
    "com/melody/lib/controls/QuickNavMenu",
    "com/melody/lib/controls/UserSettings",
    "com/melody/lib/util/UserMaster",
    "sap/ovp/app/ManageCardsUtils",
], function (SAPObject, PersonalizationUtils, MessageBox, OvpResources, ControlPersonalizationWriteAPI, Device, JSONModel, QuickNavMenu, UserSettings, UserMaster, ManageCardsUtils) {
    "use strict";
    return SAPObject.extend("com.presalescentral.model.Application", {
        constructor: function (oComponent) {
            this.init = false;
            this.oComponent = oComponent;
            this.monthMap = this.fnCreateMonthMap();
            this.user = oComponent.getModel("userDetail");
            this.pcJModel = oComponent.getModel("pcJModel");
            this.oBWModel = this.oComponent.getModel("int_bw_SRV");
            this.oOVPModel = this.oComponent.getModel("YMELODY_SRV");
            this.oOpportunityModel = oComponent.getModel("oppModel");
            this.oOppoDataModel = oComponent.getModel("oppServerModel");
            this.utilityModel = oComponent.getModel("utilityModel");
            sap.ui.getCore().setModel(this.oOpportunityModel, "oppModel");
            this.setBusyIndicatorForComponent(true);
            UserMaster._getUserDetail();
            this.fnLoadUtilityComponent(oComponent);
            this._initManageCardClick();
            this.setDashboardLayoutCards(oComponent.getRootControl(), false);
        },

        fnLoadmanageCardsDialog: function (aCards, aResults =[], fnCallback) {
            var mainController = sap.ui.getCore().byId(this.oComponent.getRootControl().getParent().getId() + "---mainView").getController();
            let aOrderedCards = mainController.getUIModel().getProperty("/aOrderedCards") || [];
            const hiddenCards = this.pcJModel.getProperty("/hiddenCards") || aResults;
            try {
                this.updateMCDashboardUtilCard(mainController, hiddenCards, aOrderedCards);

            } catch (error) {
                console.error("ERORR IN fnLoadmanageCardsDialog : ", error)
            }

            if (! mainController.manageCardsDialog) {
                if (sap.ui.getCore().byId("manageCardsDialog")) {
                    sap.ui.getCore().byId("manageCardsDialog").destroy();
                }
                mainController.manageCardsDialog = this.fnLoadManageCardsFragmentDialog(mainController);
            }
            mainController.visibilityChanges = [];
            this.handleCardVisibility(aCards, aResults, fnCallback);
            this.setBusyIndicatorForComponent(false);
        },

        fnLoadManageCardsFragmentDialog: function (mainController) {
            var that = this,
                oManageCardsDialogModel;
            mainController.aManageCardsDialogModelState = [];
            var aOrderedCards = mainController.getView().getModel("ui").getProperty('/aOrderedCards');
            if (! aOrderedCards) {
                aOrderedCards = [];
            }
            sap.ui.core.Fragment.load({
                name: "sap.ovp.app.ManageCard",
                controller: {
                    onManageCardOkButtonPressed: function () {
                        var aDialogCards = mainController.manageCardsDialog.getModel().getProperty('/cards');
                        mainController.createOrDestroyCards.apply(mainController, [mainController.aManageCardsDialogModelState, aDialogCards, false]);
                        mainController.getView().getModel("ui").setProperty('/aOrderedCards', aDialogCards);
                        mainController._updateDashboardLayoutCards(aDialogCards);
                        mainController._updateLayoutWithOrderedCards();
                        PersonalizationUtils.savePersonalization(mainController.visibilityChanges, mainController.getView());
                        mainController.manageCardsDialog.close();
                        // remove error cards which are hidden
                        for (var i = 0; i < aDialogCards.length; i++) {
                            var oCard = aDialogCards[i];
                            var iCardIndex = mainController.aErrorCards.indexOf(oCard.id);
                            if (iCardIndex > -1 && oCard.visibility == false) {
                                mainController.aErrorCards.splice(iCardIndex, 1);
                            }
                        }
                        mainController.aManageCardsDialogModelState = [];
                    }.bind(mainController),
                    onManagecardCancelButtonPressed: function () {
                        mainController.manageCardsDialog.close();
                    }.bind(mainController),
                    onManageCardResetButtonPressed: function () {
                        var sLayoutName = mainController.getLayout().getMetadata().getName();
                        MessageBox.show(OvpResources.getText("reset_cards_confirmation_msg"), {
                            id: "resetCardsConfirmation",
                            icon: MessageBox.Icon.QUESTION,
                            title: OvpResources.getText("reset_cards_confirmation_title"),
                            actions: [
                                MessageBox.Action.OK, MessageBox.Action.CANCEL
                            ],
                            onClose: function (oAction) {
                                if (oAction === MessageBox.Action.OK) {
                                    mainController.manageCardsDialog.setBusy(true);
                                    var aOrderedCards = mainController.getView().getModel("ui").getProperty('/aOrderedCards');
                                    mainController.createOrDestroyCards.apply(mainController, [
                                        aOrderedCards, mainController.aManifestOrderedCards, (sLayoutName === "sap.ovp.ui.DashboardLayout") ? true : false
                                    ]);
                                    mainController.getView().getModel("ui").setProperty('/aOrderedCards', mainController.aManifestOrderedCards);
                                    mainController._resetDashboardLayout();
                                    mainController._updateDashboardLayoutCards(mainController.aManifestOrderedCards);
                                    mainController._updateLayoutWithOrderedCards();
                                    mainController.manageCardsDialog.getModel().setProperty('/cards', mainController.aManifestOrderedCards);
                                    var aCardForDeletion = [];
                                    for (var i = 0; i < aOrderedCards.length; i++) {
                                        aCardForDeletion.push(mainController.getView().byId(aOrderedCards[i].id));
                                    }
                                    ControlPersonalizationWriteAPI.reset({selectors: aCardForDeletion}). finally(function () {
                                        mainController.manageCardsDialog.setBusy(false);
                                        mainController.manageCardsDialog.close();
                                    }.bind(mainController));
                                }
                            }.bind(mainController)
                        });
                    }.bind(mainController),
                    onCardVisibilityChange: function (event) {
                        var parent = event.getSource().getParent();
                        parent.toggleStyleClass('sapOVPHideCardsTableItem');
                        parent.getCells()[0].toggleStyleClass('sapOVPHideCardsDisabledCell');
                        var oCard = event.getSource().getBindingContext().getObject();
                        var iIsCardChangedAgain;
                        mainController.visibilityChanges.forEach(function (oChange, iIndex) {
                            if (oChange.content.cardId === oCard.id) {
                                iIsCardChangedAgain = iIndex;
                            }
                        });
                        if (iIsCardChangedAgain && iIsCardChangedAgain > -1) {
                            mainController.visibilityChanges.splice(iIsCardChangedAgain, 1);
                        } else {
                            mainController.visibilityChanges.push({
                                changeType: "visibility",
                                content: {
                                    cardId: oCard.id,
                                    visibility: event.getParameter("state")
                                },
                                isUserDependent: true
                            });
                        }
                    }.bind(mainController),
                    cardTitleFormatter: function (id) {
                        var oCard = (id !== null) ? mainController._getCardFromManifest(id) : null;
                        if (oCard) {
                            var cardSettings = oCard.settings;
                            return cardSettings.title || cardSettings.category || cardSettings.subTitle;
                        }
                        return id;
                    }.bind(mainController),
                    afterManageCardsDialogOpen: function () {
                        var sLayoutName = mainController.getLayout().getMetadata().getName();
                        var isResetButtonEnabled = (sLayoutName === "sap.ovp.ui.DashboardLayout") ? true : mainController.isValidForReset();
                        var dialogButtons = mainController.manageCardsDialog.getButtons();
                        var resetButton;
                        for (var i = 0; i < dialogButtons.length; i++) {
                            if (dialogButtons[i].sId === 'manageCardsResetBtn') {
                                resetButton = dialogButtons[i];
                            }
                        }
                        resetButton.setEnabled(isResetButtonEnabled);
                        mainController.manageCardsDialog.setProperty('stretch', Device.system.phone);
                    }.bind(mainController),
                    afterManageCardsDialogClose: function () {
                        mainController.visibilityChanges = [];
                        mainController.manageCardsDialog.close();
                    }.bind(mainController),
                    onAfterManageCardsTableUpdated: function (event) {
                        var items = event.oSource.mAggregations.items;
                        if (items) {
                            for (var i = 0; i < items.length; i++) {
                                if (! items[i].getCells()[1].getState()) {
                                    items[i].addStyleClass('sapOVPHideCardsTableItem');
                                    items[i].getCells()[0].addStyleClass('sapOVPHideCardsDisabledCell');
                                }
                            }
                        }
                        setTimeout(function () {
                            document.querySelector('.sapMListTblRow').focus();
                        }, 200);
                    }
                }
            }).then(function (oControl) {
                that.manageCardsDialog = oControl;
                mainController.manageCardsDialog = oControl;
                oManageCardsDialogModel = Object.assign([], aOrderedCards);
                mainController.aManageCardsDialogModelState = that.getManageCardsDialogModelState(aOrderedCards);
                var oModel = new JSONModel({cards: oManageCardsDialogModel});
                mainController.manageCardsDialog.setModel(oModel);
                mainController.manageCardsDialog.setModel(mainController._getOvplibResourceBundle(), "ovplibResourceBundle");
                mainController.getView().addDependent(mainController.manageCardsDialog);
                that.init = true;
                that._initManageCardClick();
            }.bind(mainController));
        },

        _initManageCardClick: function () {
            var that = this;
            var fnManageCard = function (e) {
                if ($(this).has("div:contains('Manage Cards')")) {
                    var aHiddenCards = that.HiddenCardsData.hiddenCards;
                    if (aHiddenCards) {
                        that._configManageCards();
                    } else {
                        var oRootControl = sap.ui.getCore().byId(that.oComponent.getRootControl().getParent().getId() + "---mainView--ovpLayout");
                        that.setDashboardLayoutCards(oRootControl, true, that._configManageCards);
                    }
                }
            };
            $(document).off("click", "#sapUshellMeAreaPopover-cont ul li", fnManageCard);
            $(document).on("click", "#sapUshellMeAreaPopover-cont ul li", fnManageCard);
        },

        fnCreateMonthMap: function () {
            return {
                "Jan": 0,
                "Feb": 1,
                "Mar": 2,
                "Apr": 3,
                "May": 4,
                "Jun": 5,
                "Jul": 6,
                "Aug": 7,
                "Sep": 8,
                "Oct": 9,
                "Nov": 10,
                "Dec": 11
            };
        },

        // Function to diaplay Error messages
        fnDisplayErrorMsg: function (sMsg) {
            jQuery.sap.require("sap.m.MessageBox");
            sap.m.MessageBox.error(sMsg);
        },

        // Function to load Utility component on init of dashboard
        fnLoadUtilityComponent: function (oComponent, userId) {
            var that = this;
            var iCounter = 0;
            var bUserIdCall = "";
            bUserIdCall = jQuery.sap.intervalCall(1500, this, function () {
                ++ iCounter;
                if (iCounter > 20) {
                    this.fnGetCardsData();
                    that.pcJModel.setData({
                        "opsRecordsLength": "0",
                        "opsTotalLength": "0"
                    }, true);
                    jQuery.sap.clearIntervalCall(bUserIdCall);
                }
                if (this.user.getProperty("/UserId")) {
                    jQuery.sap.clearIntervalCall(bUserIdCall);
                    this.getBusinessPartner(this.user.getProperty("/UserId"));
                }
            });
            $("#application-pc-app-component---mainView--ovpMainPageTitle-mainActions")[0] ?. style.removeProperty("flex-basis");
        },

        getBusinessPartner: function (sUserId) {
            var that = this;
            jQuery.sap.require("jquery.sap.storage");
            that.oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
            var oOppData = that.oStorage.get("pcOpportunities");
            if (oOppData && oOppData.length > 0) {
                if (oOppData.length > 0) {
                    $.each(oOppData, function (idx, obj) {
                        var oOppId = obj.OPPT_ID;
                        if (oOppId) {
                            var oOppObj = {};
                            oOppObj[oOppId] = obj;
                            that.oOpportunityModel.setData(oOppObj, true);
                        }
                    });
                }
                if (oOppData.length) {
                    var opsRecordsLength = 0;
                    if (3 - (parseInt(oOppData.length)) <= 0) {
                        opsRecordsLength = 3;
                    } else if (3 - (parseInt(oOppData.length)) > 0) {
                        opsRecordsLength = oOppData.length;
                    }
                }
                that.pcJModel.setData({
                    "opportunities": oOppData.slice(0, 3),
                    "opsRecordsLength": opsRecordsLength,
                    "opsTotalLength": oOppData.length || "0"
                }, true);
                if (oOppData.length !== 0) {
                    that.pcJModel.setProperty("/myOppDataLength", opsRecordsLength + " of " + oOppData.length);
                }
                that.fnGetCardsData();
            } else {
                var fnGetBusinessPartners = that.oOppoDataModel.read("/BusinessPartners", {
                    filters: [new sap.ui.model.Filter(
                            {path: "TYPE", operator: "EQ", value1: "E"}
                        )],
                    urlParameters: {
                        search: sUserId,
                        $select: 'PARTNER'
                    },
                    success: function (oData) {
                        try {
                            var sPartnerId = oData.results[0].PARTNER;
                            that.fnGetOpportunitiesList(sPartnerId);
                        } catch (err) {
                            jQuery.sap.log.info(err);
                        }
                    },
                    error: function (err) {
                        jQuery.sap.log.info(err);
                    }
                });
                that.oOppoDataModel.attachMetadataLoaded(fnGetBusinessPartners);
                that.oOppoDataModel.attachMetadataFailed(that.fnHandleHarmonyFail());
            }
        },

        fnHandleHarmonyFail: function () {
            this.pcJModel.setData({
                "opsRecordsLength": "0",
                "opsTotalLength": "0"
            }, true);
            if (!this.oHrmnyStorage) {
                jQuery.sap.require("jquery.sap.storage");
                this.oHrmnyStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
            }
            if (this.oOppoDataModel.oMetadata.bFailed && !this.oHrmnyStorage.get("showHarmonyError")) {
                jQuery.sap.require("sap.m.MessageToast");
                sap.m.MessageToast.show("Oppurtunity data unavailable!\nReason : Harmony server down or Unauthorized access!", {
                    duration: 9000,
                    width: "30em"
                });
                this.oHrmnyStorage.put("showHarmonyError", true);
                this.fnGetCardsData();
            } else if (this.oHrmnyStorage && this.oHrmnyStorage.get("showHarmonyError")) {
                this.fnGetCardsData();
            }
        },

        // Function to get list of Opportunities
        fnGetOpportunitiesList: function (sPartnerId) {
            var that = this;
            var statusFilter = new sap.ui.model.Filter({
                filters: [
                    new sap.ui.model.Filter(
                        {path: 'STATUS', operator: "EQ", value1: "E0001"}
                    ),
                    new sap.ui.model.Filter(
                        {path: 'STATUS', operator: "EQ", value1: "E0007"}
                    )
                ],
                bAnd: false
            });
            that.oOppoDataModel.read("/Opportunities", {
                async: true,
                filters: [new sap.ui.model.Filter(
                        {
                            filters: [
                                new sap.ui.model.Filter(
                                    {path: "SALES_TEAM_MEMBER", operator: "EQ", value1: sPartnerId}
                                ),
                                statusFilter
                            ],
                            bAnd: true
                        }
                    )],
                urlParameters: {
                    $select: 'STARTDATE,SALES_ORG_TEXT,OPPT_ID,ACCOUNT_NAME,ACCOUNT,DESCRIPTION,OWNER,OWNER_NAME,STATUS,CURR_PHASE,EXPECTED_VALUE,EXPECT_END,INDUSTRY_MASTERCODE_TEXT',
                    $skip: 0,
                    $top: 5
                },
                success: function (data) {
                    try {
                        if (data.results.length > 0) {
                            $.each(data.results, function (idx, obj) {
                                var oOppId = obj.OPPT_ID;
                                if (oOppId) {
                                    var oOppObj = {};
                                    oOppObj[oOppId] = obj;
                                    that.oOpportunityModel.setData(oOppObj, true);
                                }
                            });
                        }
                        if (data.results.length) {
                            var opsRecordsLength = 0;
                            if (3 - (parseInt(data.results.length)) <= 0) {
                                opsRecordsLength = 3;
                            } else if (3 - (parseInt(data.results.length)) > 0) {
                                opsRecordsLength = data.results.length;
                            }
                        }
                        that.pcJModel.setData({
                            "opportunities": data.results.slice(0, 3),
                            "opsRecordsLength": opsRecordsLength,
                            "opsTotalLength": data.results.length || "0"
                        }, true);
                        if (data.results.length !== 0) {
                            that.pcJModel.setProperty("/myOppDataLength", opsRecordsLength + " of " + data.results.length);
                        }
                        // Below line is commented for prod issue user with more opportunities
                        // that.oStorage.put("pcOpportunities", data.results);
                        that.fnGetCardsData();
                    } catch (err) {
                        jQuery.sap.log.info(err);
                        that.fnGetCardsData();
                    }
                },
                error: function (err) {
                    jQuery.sap.log.info(err);
                }
            });
        },

        _getConstants: function () {
            var fnSuccess = function (data) {
                var oConstantsMap = {};
                $.each(data.results, function (index, item) {
                    if (! oConstantsMap.hasOwnProperty(item.const_id)) {
                        oConstantsMap[item.const_id] = item;
                    }
                });
                this.pcJModel.setData({
                    "constants": oConstantsMap,
                    "Target": oConstantsMap['0046'].field_value
                }, true);

            }.bind(this);
            var fnError = function (err) {
                jQuery.sap.log.info(err);
            };
            this.oOVPModel.read("/Yc_Md_M_Constants", {
                async: false,
                success: fnSuccess,
                error: fnError
            });
        },
        fnGetCardsData: function () {
            this._getMySLData();
            this._getMyTeamSLData();
            this._getMIExecutiveData();
            this._getMIManagersData();
            this._getMIIndividualContributorsData();
            // this.getMissingHoursKpi();
            this._changeManageCardsData();
            this._getConstants();
        },

        getMissingHoursKpi: function () {
            var fnSuccess = function (oResponse) {
                    var iTotalMissingHours = 0,
                        iTotalHoursCapacity = 0;
                    $.each(oResponse.results, function (index, item) {
                        if (item.MISSING_HOURS_D_CQ !== null) {
                            iTotalHoursCapacity = iTotalHoursCapacity + parseInt(item.MISSING_HOURS_D_CQ);
                        }
                        if (item.MISSING_HOURS_N_CQ !== null) {
                            iTotalMissingHours = iTotalMissingHours + parseInt(item.MISSING_HOURS_N_CQ);
                        }
                    });
                    var sYear = oResponse.results[0].USER_SELECTION.split(" ")[1].split("-")[0];
                    var sQuarter = "Q" + oResponse.results[0].USER_SELECTION.split(" ")[1].split("-")[1];
                    this.pcJModel.setData({
                        "USER_SELECTION": sYear + "-" + sQuarter
                    }, true);
                    var sMissingHoursPercentage = ((iTotalMissingHours / iTotalHoursCapacity).toFixed(2) * 100);
                    this.pcJModel.setData({
                        "MissingHoursKpi": sMissingHoursPercentage
                    }, true);
                    this.getTopMissingHours();
                    this.getMissingHours();
                }.bind(this),
                fnError = function (err) {
                    jQuery.sap.log.info(err);
                };
            this.oBWModel.read("/MissingHoursKpi", {
                async: false,
                filters: [new sap.ui.model.Filter(
                        {path: "AGG_TYPE", operator: "EQ", value1: "EMP"}
                    )],
                success: fnSuccess,
                error: fnError
            });
        },
        getTopMissingHours: function () {
            var topMissingHoursLength = 0;
            var fnSuccess = function (oResponse) {
                    $.each(oResponse.results, function (index, item) {
                        if (item.CAPACITY_HOURS_WEEKLY !== null && item.MISSING_HOURS_WEEKLY !== null) {
                            item["MISSING_HOURS_PERCENTAGE"] = parseFloat((item.MISSING_HOURS_WEEKLY / item.CAPACITY_HOURS_WEEKLY).toFixed(2) * 100);
                        }
                    });
                    if (oResponse.__count) {
                        if (5 - (parseInt(oResponse.__count)) <= 0) {
                            topMissingHoursLength = 5;
                        } else if (5 - (parseInt(oResponse.__count)) > 0) {
                            topMissingHoursLength = oResponse.__count;
                        }
                    }
                    this.pcJModel.setData({
                        "topMissingHours": oResponse.results,
                        "topMissingHoursLength": topMissingHoursLength,
                        "topMissingHoursTotalLength": oResponse.__count
                    }, true);
                    if (oResponse.__count !== 0) {
                        this.pcJModel.setProperty("/topMissingHoursDataLength", topMissingHoursLength + " of " + oResponse.__count);
                    }
                }.bind(this),
                fnError = function (err) {
                    jQuery.sap.log.info(err);
                };
            this.oBWModel.read("/TopMissingHours", {
                async: false,
                urlParameters: {
                    '$inlinecount': 'allpages'
                },
                filters: [new sap.ui.model.Filter(
                        {path: "YEAR_QUARTER", operator: "EQ", value1: this.pcJModel.getProperty("/USER_SELECTION")}
                    )],
                success: fnSuccess,
                error: fnError
            });
        },

        getMissingHours: function () {
            var fnSuccess = function (oResponse) {
                    $.each(oResponse.results, function (index, value) {
                        value["CA_MONTH_NUM"] = this.monthMap[value.CA_MONTH_NAME_SHORT];
                    }.bind(this));
                    this.pcJModel.setData({
                        "MissingHours": oResponse.results,
                        "isBWPDataAvailable": (oResponse.results.length > 0)
                    }, true);
                }.bind(this),
                fnError = function (err) {
                    jQuery.sap.log.info(err);
                };
            this.oBWModel.read("/MissingHoursDetails", {
                async: false,
                filters: [new sap.ui.model.Filter(
                        {path: "YEAR_QUARTER", operator: "EQ", value1: this.pcJModel.getProperty("/USER_SELECTION")}
                    )],
                success: fnSuccess,
                error: fnError
            });
        },

        _changeManageCardsData: function () {
            jQuery.sap.delayedCall(2000, this, function () {
                var manageCard = sap.ui.getCore().byId("sapUshellMeAreaPopover");
                if (manageCard) {
                    this.manageCardsListData();
                } else {
                    this._changeManageCardsData();
                }
            }.bind(this));
        },

        manageCardsListData: function () {},

        _configManageCards: function () {
            var that = this;
            jQuery.sap.delayedCall(500, this, function () {
                if (sap.ui.getCore().byId("manageCardsResetBtn")) {
                    sap.ui.getCore().byId("manageCardsResetBtn").setVisible(false);
                    var oCardsList = sap.ui.getCore().byId("sapOVPHideCardsTable");
                    var oCardListItems = oCardsList.getItems();
                    var aHiddenCards = that.HiddenCardsData.hiddenCards;
                    var hideCardsMap = {};
                    $.each(aHiddenCards, function (index, cardAuth) {
                        hideCardsMap[parseInt(cardAuth.cardid)] = cardAuth;
                    });
                    $.each(oCardListItems, function (index, item) {
                        var id = item.getBindingContext().getObject().id.split("card")[1];
                        if ((hideCardsMap.hasOwnProperty(parseInt(id)))) {
                            item.getAggregation("cells")[1].setState(false);
                            item.setVisible(false);
                        } else {
                            item.setVisible(true);
                        }
                    });
                    if (this.init) {
                        this.manageCardsDialog.getButtons()[0].firePress();
                        this.init = false;
                    }
                }
            });
        },

        // SL card function
        _getMySLData: function () {
            var that = this;
            that.oOppoDataModel.setDeferredGroups(["BusinessPartnerAttriMySL"]);
            this.getSLServiceData("YC_SL_T_MYSL_CARD", "mySLData", "mySLLength", "mySLTotalLength", "BusinessPartnerAttriMySL", "3");
        },

        // Team SL card function
        _getMyTeamSLData: function () {
            var that = this;
            that.oOppoDataModel.setDeferredGroups(["BusinessPartnerAttriMyTeamSL"]);
            this.getSLServiceData("YC_SL_T_MYTEAMSL_CARD", "myTeamSLData", "myTeamSLLength", "myTeamSLTotalLength", "BusinessPartnerAttriMyTeamSL", "2");
        },

        // Function to get data from SL cards services
        getSLServiceData: function (entitySetName, cardData, cardLength, cardTotalLength, grpID, count) {

                        var cardCount = 0;
                var that = this;
                var fnSuccess = function (data) {
                        if (data !== undefined) {
                            if (cardData === "myTeamSLData") {
                                cardCount = data.results.length;
                            } else {
                                cardCount = data.results.length;
                            } that.getSLDisplayData(data, cardCount, cardLength);
                            that.getSLUniqueData(data, cardData, grpID);

                            this.pcJModel.setProperty("/" + cardData, data.results);
                            this.pcJModel.setProperty("/" + cardLength, cardCount);
                            this.pcJModel.setProperty("/" + cardTotalLength, data.__count || "0");
                            if (data.__count !== "0") {
                                if (cardData === "myTeamSLData") {
                                    this.pcJModel.setProperty("/myTeamSLDataLength", data.results.length + " of " + data.__count);
                                } else {
                                    this.pcJModel.setProperty("/mySLDataLength", data.results.length + " of " + data.__count);
                                }
                            }

                            var oCard = this.pcJModel.getProperty("/" + cardData);
                            var oOpp = this.pcJModel.getData().opportunities;

                            oCard.forEach(function (item) {
                                    oOpp.filter(function (obj) {
                                            if (obj.OPPT_ID === item.OpporutnityId) 
                                                item.OpportunityName = obj.ACCOUNT_NAME;
                                            }
                                        );
                                    }
                                );
                                this.pcJModel.setProperty("/" + cardData, oCard);

                            }
                        }.bind(this);
                        var fnError = function (err) {
                            jQuery.sap.log.info(err);
                        };
                        this.oOVPModel.read("/" + entitySetName, {
                            async: false,
                            urlParameters: {
                                '$inlinecount': 'allpages',
                                '$top': count,
                                '$skip': 0
                            },
                            sorters: [new sap.ui.model.Sorter(
                                    {path: "EndDate", bDescending: false}
                                )],
                            filters: [new sap.ui.model.Filter(
                                    {path: "StatusId", operator: "EQ", value1: "01"}
                                )],
                            success: fnSuccess,
                            error: fnError
                        });
                    },

                        // Function to get how many data it will display in SL cards
                    getSLDisplayData: function (data, count, length) {
                        if (data.__count) {
                            if (count - (parseInt(data.__count)) <= 0) {
                                length = count;
                            } else if (count - (parseInt(data.__count)) > 0) {
                                length = data.__count;
                            }
                        }
                    },

                        // Function to get unique records for Harmony service
                    getSLUniqueData: function (data, propData, grpID) {
                        var aResults = data.results;
                        if (aResults.length > 0) {
                            this.pcJModel.setProperty("/" + propData, aResults);
                            var mOutputData = [];
                            aResults.forEach(function (item) {
                                    var existing = mOutputData.filter(function (v, i) {
                                        return v.AccountId === item.AccountId;
                                    });
                                    if (existing.length) {
                                        var existingIndex = mOutputData.indexOf(existing[0]);
                                        if (! mOutputData[existingIndex].intItem) 
                                            mOutputData[existingIndex].intItem = [];
                                            mOutputData[existingIndex].intItem = mOutputData[existingIndex].intItem.concat(item);
                                        } else {
                                            mOutputData.push(item);
                                        }
                                    }
                                );
                                this.getSLAccData(mOutputData, grpID, propData);
                            }
                        },

                        // Function to get account names from Harmony service and Opportunity model and set it to view for display
                        getSLAccData : function (mOutputData, grpID, propertyData) {
                                var that = this;
                                that.aAllActivityAccountIDMap = [];
                                that.oOppoDataModel.setDeferredGroups([grpID]);
                                $.each(mOutputData, function (index, value) {
                                    if (value.AccountId !== "" && value.AccountId !== undefined) {
                                        that.aAllActivityAccountIDMap[value.AccountId] = value.AccountId;
                                        that.oOppoDataModel.read("/BusinessPartnerAttribSet('" + value.AccountId + "')", {
                                            groupId: grpID,
                                            propData: propertyData
                                        });
                                    }
                                }.bind(that));
                                if (that.aAllActivityAccountIDMap.length > 0 && !(that.oOppoDataModel.isMetadataLoadingFailed())) {
                                    that.oOppoDataModel.submitChanges({
                                        groupId: grpID,
                                        propData: propertyData,
                                        success: function (oResult) {
                                                for (var i in oResult.__batchResponses) {
                                                    if (oResult.__batchResponses[i].data) {
                                                        that.aAllActivityAccountIDMap[oResult.__batchResponses[i].data.PARTNER] = oResult.__batchResponses[i].data;
                                                    }
                                                }
                                                for (var j in that.pcJModel.getProperty("/" + propertyData)) {
                                                    if (that.aAllActivityAccountIDMap[that.pcJModel.getProperty("/" + propertyData)[j].AccountId]) {
                                                        that.pcJModel.getProperty("/" + propertyData)[j].AccountName = that.aAllActivityAccountIDMap[that.pcJModel.getProperty("/" + propertyData)[j].AccountId].PARTNER_NAME;
                                                    }
                                                }
                                                var sCard = this.pcJModel.getProperty("/" + propertyData);

                                                sCard.forEach(function (item) {
                                                        that.pcJModel.getProperty("/" + propertyData).filter(function (obj) {
                                                                if (item.AccountId === obj.AccountId) 
                                                                    item.AccountName = obj.AccountName;
                                                                }
                                                            );
                                                        }
                                                    );
                                                    this.pcJModel.setProperty("/" + propertyData, sCard);

                                                    var tCard = this.pcJModel.getProperty("/" + propertyData);
                                                    var tOpp = this.pcJModel.getData().opportunities;
                                                    tCard.forEach(function (item) {
                                                            tOpp.filter(function (obj) {
                                                                    if (obj.OPPT_ID === item.OpporutnityId) 
                                                                        item.OpportunityName = obj.ACCOUNT_NAME;
                                                                    }
                                                                );
                                                            }
                                                        );
                                                        this.pcJModel.setProperty("/" + propertyData, tCard);
                                                    }.bind(that), error : jQuery.proxy(function (oErr) {
                                                        that._displayErrorMsg("Failed to get BP data.");
                                                    }, that)
                                                }
                                            );
                                        }},

                                    setDashboardLayoutCards : function (oRootControl, bVal, fnCallback) {
                                        if (oRootControl) {
                                            if (bVal) {
                                                oRootControl.attachAfterRendering(jQuery.proxy(function () {
                                                    if (this.pcJModel.getProperty("/isRestorePressed")) {
                                                        this.handleCardVisibility(sap.ui.getCore().byId(oRootControl.getParent().getId() + "---mainView--ovpLayout").getContent(), this.pcJModel.getProperty("/hiddenCards"));
                                                        this.pcJModel.setProperty("/isRestorePressed", false);
                                                    }
                                                }, this));
                                            } else {
                                                sap.ui.getCore().byId(oRootControl.getParent().getId() + "---mainView--ovpLayout").attachAfterRendering(jQuery.proxy(function () {
                                                    if (this.pcJModel.getProperty("/isRestorePressed")) {
                                                        this.handleCardVisibility(sap.ui.getCore().byId(oRootControl.getParent().getId() + "---mainView--ovpLayout").getContent(), this.pcJModel.getProperty("/hiddenCards"));
                                                        this.pcJModel.setProperty("/isRestorePressed", false);
                                                    }
                                                }, this));
                                            }
                                            var aCards = "";
                                            if (bVal) {
                                                aCards = oRootControl.getContent();
                                            } else {
                                                aCards = sap.ui.getCore().byId(oRootControl.getParent().getId() + "---mainView--ovpLayout").getContent();
                                            }
                                            var that = this;
                                            this.oOVPModel.read("/YC_MAC_ROLE_CARDS", {
                                                success: function (oData) {
                                                    this.pcJModel.setData({
                                                        "hiddenCards": oData.results,
                                                        "riskActTotalLength": "0",
                                                        "isRestorePressed": false
                                                    }, true);
                                                    that.HiddenCardsData = {
                                                        "hiddenCards": oData.results,
                                                        "riskActTotalLength": "0",
                                                        "isRestorePressed": false
                                                    };
                                                    if (oData.results.length > 0) {
                                                        jQuery.sap.delayedCall(3000, this, function () {
                                                            this.fnLoadmanageCardsDialog(aCards, oData.results, fnCallback);
                                                        }.bind(this));
                                                    } else {
                                                        this.init = false;
                                                        this.setBusyIndicatorForComponent(false);
                                                    }
                                                }.bind(this),
                                                error: function (err) {
                                                    console.log(err);
                                                    this.setBusyIndicatorForComponent(false);
                                                }
                                            });
                                            this.oOVPModel.metadataLoaded().then(this.setQuickLinksNav());
                                        }
                                    },
                                    handleCardVisibility : function (aCards, cardsVisibilityData, fnCallback) {
                                        var hideCardsMap = {};
                                        $.each(cardsVisibilityData, function (index, cardAuth) {
                                            hideCardsMap[parseInt(cardAuth.cardid)] = cardAuth;
                                        });
                                        var ovpLayout = sap.ui.getCore().byId(this.oComponent.getRootControl().getParent().getId() + "---mainView-ovpLayout");
                                        $.each(aCards, jQuery.proxy(function (idx, card) {
                                            var sCardId = card.getId().split("card")[1];
                                            if (!(hideCardsMap.hasOwnProperty(parseInt(sCardId)))) { // sap.ui.getCore().byId(card.getId()).setVisible(true);
                                            } else { // ovpLayout.removeContent(sap.ui.getCore().byId(card.getId()));
                                                sap.ui.getCore().byId(card.getId()) ?. setVisible(false);
                                            }
                                        }, this));
                                        if (fnCallback) {
                                            fnCallback();
                                        }
                                        this._configManageCards();
                                    },

                                    setQuickLinksNav : function () {
                                        var head1 = sap.ui.getCore().byId(this.oComponent.getRootControl().getParent().getId() + "---mainView--ovpMain");
                                        head1.setHeaderExpanded(false);
                                        var title = head1.getTitle();
                                        var titeHead = title.getHeading();
                                        title.getSnappedContent()[0].setVisible(false);
                                        title.getHeading().getItems()[0].setVisible(false);
                                        var quickLinkBtn = new QuickNavMenu({text: "Melody Quick Nav", useDefaultActionOnly: true});
                                        titeHead.addItem(quickLinkBtn);
                                        // var actionsToolbar = sap.ui.getCore().byId(this.oComponent.getRootControl().getParent().getId() +
                                        // "---mainView--ovpMainPageTitle-_actionsToolbar");
                                        // var aActionToolbarContent = actionsToolbar.getContent();
                                        // aActionToolbarContent.forEach(function (item) {
                                        // if (typeof item.getIcon === "function" && item.getIcon() === 'sap-icon://action') {
                                        // item.setVisible(false);
                                        // }
                                        // });
                                        var oRoot = this.oComponent.getRootControl();
                                        var sToolbarId = oRoot.getParent().getId() + "---mainView--ovpMainPageTitle-_actionsToolbar";
                                        var oToolbar = sap.ui.getCore().byId(sToolbarId);
                                        if (oToolbar && typeof oToolbar.getContent === "function") {
                                            oToolbar.getContent().forEach(function (oItem) {
                                                if (typeof oItem.getIcon === "function" && oItem.getIcon() === "sap-icon://action") {
                                                    oItem.setVisible(false);
                                                }
                                            });
                                        } else {
                                            console.warn("Toolbar not found or invalid.");
                                        }
                                        var oProfileButton = new UserSettings({text: "{userDetail>/UserName}", icon: "sap-icon://employee"});
                                        oToolbar.addContent(oProfileButton);
                                    },


                                    /*
		* Function to update the OVP MainController dashboardUtil Cards
		* this function modifies the standard property used in the SAP OVP Controller, Make sure to validate the property
		* the property dashboardLayoutUtil.aCards contains the layout card objects
		*/
                                    updateMCDashboardUtilCard : function (mainController, hiddenCards =[], aOrderedCards =[]) {
                                        try {
                                            let aVisibilityDeltaChanges = [];
                                            const dashboardLayoutUtil = mainController ?. getLayout() ?. dashboardLayoutUtil || false;
                                            if (! dashboardLayoutUtil) {
                                                return;
                                            }

                                            // check aOrderedCards
                                            for (let i = 0; i < hiddenCards.length; i++) {
                                                let item = hiddenCards[i] || {};
                                                let cardId = parseInt(item.cardid);
                                                if (!isNaN(cardId)) {
                                                    let orderedCardIndex = aOrderedCards.findIndex((card) => {
                                                        let layoutCardId = card ?. id.split("card")[1];
                                                        return parseInt(layoutCardId) === cardId;
                                                    });
                                                    if (orderedCardIndex !== -1) {
                                                        aOrderedCards[orderedCardIndex].visibility = false;
                                                    }
                                                }
                                            }
                                            const cardState = aOrderedCards.map((item) => {
                                                return {id: item.id, visibility: item.visibility}
                                            });
                                            aOrderedCards = aOrderedCards.map((item) => {
                                                return {
                                                    ...item,
                                                    visible: item.visibility
                                                }
                                            }).filter((item) => {
                                                return item.visibility;
                                            });
                                            mainController.getUIModel().setProperty("/aOrderedCards", aOrderedCards);
                                            mainController.getUIModel().refresh(true);

                                            // Update the OVP
                                            mainController.aManifestOrderedCards = aOrderedCards.map((card) => {
                                                return {id: card.id, visibility: card.visibility};
                                            });

                                            mainController.createOrDestroyCards.apply(mainController, [cardState, aOrderedCards, false]);
                                            mainController.updateDashboardLayoutCards(aOrderedCards);
                                            mainController.updateLayoutWithOrderedCards();
                                            PersonalizationUtils.savePersonalization(aVisibilityDeltaChanges, mainController.getView());

                                        } catch (error) {
                                            console.error("ERROR IN updateMCDashboardUtilCard : ", error);
                                        }
                                    },

                                    // Create a state array of cards
                                    getManageCardsDialogModelState : function (aCardArray) {
                                        const aCardsArray = [];
                                        for (let i = 0; i < aCardArray.length; i++) {
                                            aCardsArray.push({id: aCardArray[i].id, visibility: aCardArray[i].visibility});
                                        }
                                        return aCardsArray;
                                    },

                                    // Function to set busy indicator
                                    setBusyIndicatorForComponent : function (value = false) {
                                        this.oComponent.getRootControl().setBusy(value);
                                    },

                                    // function to get Melody Intelligence Individual Contributors
                                    _getMIIndividualContributorsData : function () {
                                        this.getMelodyIntelligenceData("YC_MAC_T_MI_CARD", "melodyIICData", "melodyIICDataLength", "melodyIICDataTotalLength", "folderid", "0000000021");
                                    },

                                    // function to get Melody Intelligence Executives
                                    _getMIExecutiveData : function () {
                                        this.getMelodyIntelligenceData("YC_MAC_T_MI_CARD", "melodyIEData", "melodyIEDataLength", "melodyIEDataTotalLength", "folderid", "0000000023");
                                    },
                                    // function to get Melody Intelligence Managers
                                    _getMIManagersData : function () {
                                        this.getMelodyIntelligenceData("YC_MAC_T_MI_CARD", "melodyIMData", "melodyIMDataLength", "melodyIMDataTotalLength", "folderid", "0000000022");
                                    },

                                    // Function to get all Melody Intelligence cards data
                                    getMelodyIntelligenceData : function (entitySetName, cardData, cardLength, cardTotalLength, filterProperty, filterValue) {
                                        var fnSuccess = function (data = {}) {
                                            const dataKeys = Object.keys(data) || [];
                                            if (dataKeys.length) {
                                                this.pcJModel.setProperty("/" + cardData, data ?. results || []);
                                                this.pcJModel.setProperty("/" + cardLength, data ?. results.length || 0);
                                                this.pcJModel.setProperty("/" + cardTotalLength, data.__count || "0");
                                            }
                                        }.bind(this);
                                        var fnError = function (err) {
                                            jQuery.sap.log.info(err);
                                        };
                                        this.oOVPModel.read("/" + entitySetName, {
                                            async: false,
                                            urlParameters: {
                                                '$inlinecount': 'allpages'
                                            },
                                            sorters: [new sap.ui.model.Sorter(
                                                    {path: "linkid", bDescending: false}
                                                )],
                                            filters: [new sap.ui.model.Filter(
                                                    {path: filterProperty, operator: "EQ", value1: filterValue}
                                                )],
                                            success: fnSuccess,
                                            error: fnError
                                        });
                                    }
                                }
                            );
                        }
                    );
