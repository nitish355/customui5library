(function () {
	"use strict";

	/* controller for custom card  */

	sap.ui.controller("com.presalescentral.ext.MySuccessline.MySuccessline", {

		riskColorFormat: function (sRiskId) {
			var sSemanticColor = 'Success';
			if (sRiskId) {
				switch (sRiskId) {
				case '01':
					sSemanticColor = 'Error';
					break;
				case '02':
					sSemanticColor = 'Warning';
					break;
				case '03':
					sSemanticColor = 'Success';
					break;
				default:
					sSemanticColor = 'Success';
					break;
				}
			}
			return sSemanticColor;
		},
		SlCompletionformat: function (sVal) {
			var percValue = "";
			if (sVal) {
				percValue = parseInt(sVal);
				percValue = percValue + " %";
			}
			return percValue;
		},
		statusColorFormat: function (sVal) {
			var sSemanticColor = 'Success';
			if (sVal !== "") {
				sSemanticColor = 'None';
			}
			return "New";
		},

		onMySLSelect: function (oEvent) {
			var iSuccessLineID = oEvent.getSource().getModel("pcJModel").getProperty(oEvent.getSource().getBindingContextPath() +
				"/" + "SlNo");
			var oParamObj = {
				"SuccessLineID": iSuccessLineID
			};
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "sl",
					action: "App&/SlDetail"
				},
				params: oParamObj
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		},
		onMySLHeaderSelect: function () {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "sl",
					action: "App"
				}
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		},
		formatSLText: function (sSlName) {
			if (sSlName) {
				var sLength = sSlName.length;
				if (sLength && sLength > 15) {
					var sShortText = sSlName.slice(0, 15) + "...";
					return sShortText;
				} else {
					return sSlName;
				}
			}
		}
	});
})();