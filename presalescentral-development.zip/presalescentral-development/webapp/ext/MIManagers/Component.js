sap.ui.define(["sap/ovp/cards/custom/Component"], function (Component) {
	"use strict";

	/* component for custom card */
	return Component.extend("com.presalescentral.ext.MIManagers.Component", {
		// use inline declaration instead of component.json to save 1 round trip
		metadata: {
			properties: {
				"contentFragment": {
					"type": "string",
					"defaultValue": "com.presalescentral.ext.MIManagers.MIManagers"
				},
				"headerFragment": {
					"type": "string",
					"defaultValue": "com.presalescentral.ext.MIManagers.MIManagersHeader"
				},
				"footerFragment": {
					"type": "string",
					"defaultValue": ""
				}
			},

			version: "@version@",

			library: "sap.ovp",

			includes: ["../css/pcCards.css"],

			dependencies: {
				libs: ["sap.m"],
				components: []
			},
			config: {},
			customizing: {
				"sap.ui.controllerExtensions": {
					"sap.ovp.cards.generic.Card": {
						controllerName: "com.presalescentral.ext.MIManagers.MIManagers"
					}
				}
			}
		}
	});
});