(function () {
	"use strict";

	/* controller for custom card  */

	sap.ui.controller("com.presalescentral.ext.MyTeamSuccessline.MyTeamSuccessline", {

		riskColorFormat: function (sRiskId) {
			var sSemanticColor = 'Success';
			if (sRiskId) {
				switch (sRiskId) {
				case '01':
					sSemanticColor = 'Error';
					break;
				case '02':
					sSemanticColor = 'Warning';
					break;
				case '03':
					sSemanticColor = 'Success';
					break;
				default:
					sSemanticColor = 'Success';
					break;
				}
			}

			return sSemanticColor;
		},
		SlCompletionformat: function (sVal) {
			var percValue = "";
			if (sVal) {
				percValue = parseInt(sVal);
				percValue = percValue + "%";
			}
			return percValue;
		},
		statusColor: function (sStatus) {
			if (sStatus) {
				var colorClass;
				switch (sStatus) {
				case 'Error':
					colorClass = 'pcRedBar';
					break;
				case 'Warning':
					colorClass = 'pcYellowBar';
					break;
				case 'Success':
					colorClass = 'pcGreenBar';
					break;
				}

				return colorClass;
			}
		},
		statusCompColor: function (sStatus) {
			if (sStatus) {
				var colorClass;
				switch (sStatus) {
				case 'Error':
					colorClass = 'pcRedBar';
					break;
				case 'Warning':
					colorClass = 'pcYellowBar';
					break;
				case 'Success':
					colorClass = 'pcGreenBar';
					break;
				}

				return colorClass;
			}
		},
		remainingDaysText: function (sDays) {
			var sText = null;
			if (sDays >= "0") {
				sText = "Due in " + sDays + " days";
			} else {
				var pValue = "";
				pValue = -parseInt(sDays);
				sText = "Exceeded by " + pValue + " days";
			}

			return sText;
		},
		onTeamSLSelect: function (oEvent) {
			var iTeamSuccessLineID = oEvent.getSource().getModel("pcJModel").getProperty(oEvent.getSource().getBindingContextPath() + "/" +
				"SlNo");
			var oParamObj = {
				"SuccessLineID": iTeamSuccessLineID
			};
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "sl",
					action: "App&/SlDetail"
				},
				params: oParamObj
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		},
		oTeamSLHeaderSelect: function () {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "sl",
					action: "App&/slvariant"
				}
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});
		}

	});
})();