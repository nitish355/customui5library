const approuter = require('@sap/approuter')();

approuter.beforeRequestHandler.use((req, res, next) => {
    if (req.headers.cookie) {
        const rawCookies = req.headers.cookie.split(';');
        const check = ["cmapi_cookie_privacy"];
        const validate = "cmapi_cookie_privacy";

        for (let cookie of rawCookies) {
            const [name, value] = cookie.trim().split('=');
            if (name.includes(validate)) {
                console.warn("Detected malformed cmapi_cookie_privacy cookie.");
                // return res.redirect("/do/logout");
            }
        }

        const filteredCookies = rawCookies.filter(cookie => {
            const name = cookie.trim().split('=')[0];
            return !check.includes(name);
        });

        req.headers.cookie = filteredCookies.join(';');
        console.log("After : ", req.headers.cookie)
    }

    next();
});

approuter.start();