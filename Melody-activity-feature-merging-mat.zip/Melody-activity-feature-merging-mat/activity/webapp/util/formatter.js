sap.ui.define(
  ["com/melodylib/core/classes/Variant", "com/melody/activity/util/formatter", 
    "sap/ui/core/format/DateFormat",
  "com/melodylib/time/state/TimeState",
"com/melodylib/integration/state/OpportunityState",
"com/melodylib/integration/state/AccountState"],
  function (Variant, formatter, DateFormat,TimeState,OpportunityState,AccountState) {
    return {
      //Function to set Risk Assesment Toggle button type for Risk Color
      fnFormatActRiskBtnType: function (RiskAssementID) {
        var type;
        switch (RiskAssementID) {
          case "01":
            type = sap.m.ButtonType.Reject;
            break;
          case "02":
            type = sap.m.ButtonType.Attention;
            break;
          case "03":
            type = sap.m.ButtonType.Accept;
            break;
          default:
            type = sap.m.ButtonType.Transparent;
        }
        return type;
      },
      //Function to set toggle between Risk Assement Toggle button
      fnSetRiskAssesmenBtn: function (SelectedRAId, CurrentRAId) {
        if (SelectedRAId === CurrentRAId) {
          return true;
        } else {
          return false;
        }
      },
      formatFragmentName: function (tab) {
        return decodeURIComponent(
          "com.melody.activity.fragments.form." + tab.name + "Display"
        );
      },

      //Function to Format Account/Opportunity Name with ID
      fnFormatOppoAccountName: function (Name, ID) {
        var str = "";
        if (Name && Name !== "Not Authorized") {
          str = Name;
          if (ID) {
            str = str + " (" + ID + ")";
          }
        } else if (ID) {
          str = ID;
        } else {
          str = "";
        }
        return str;
      },

      //Function to format date
      fnFormatDate: function (date) {
        let newDate;
        if (
          date &&
          date !== "" &&
          date !== "Invalid Date" &&
          date !== null &&
          date !== undefined
        ) {
          // Use a regular expression to match the digits within the parentheses
          let match = /\/Date\((\d+)\)\//.exec(date);
          if (match) {
            date = Number(match[1]);
            date = new Date(date);
          }

          var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
            format: "yMMMd",
            style: "short",
          });
          newDate = dateFormat.format(date);
        } else {
          newDate = "";
        }
        return newDate;
      },

      formatActivityType: function (types = [], typeId) {
        if (types.length && typeId) {
          let typeObj = types.find((type) => type.id === typeId);
          return typeObj.description;
        }
        return typeId;
      },

      formatInfoLabelColor: function (text) {
        let colorScheme = 7;
        switch (text) {
          case "Account":
            colorScheme = 6;
            break;
          case "Opportunity":
            colorScheme = 9;
            break;
          case "01":
            colorScheme = 8;
            break;
          case "02":
            colorScheme = 2;  // cancelled
            break;
          case "17":
            colorScheme = 1;
            break;
          default:
            colorScheme = null;
            break;
        }
        return colorScheme;
      },

      fnSetOppData: function (oppId) {
        let oppText = "Not Applicable";
        if (oppId) {
          oppText = oppId;
        }
        return oppText;
      },

      fnGetAllCountsMasterData: function (ActivityGUID, countProperty) {
        let count = "0";
        if (ActivityGUID) {
          let value = this.getOwnerComponent()
            .getModel("activityListModel")
            .getObject("/allCountsMasterDataMap")
            ? this.getOwnerComponent()
              .getModel("activityListModel")
              .getObject("/allCountsMasterDataMap/" + ActivityGUID)[
            countProperty
            ]
            : 0;
          if (value || value !== 0) {
            count = value;
          }
        }
        return count;
      },
      demoEnvVisiblity: function (editable, data, visible) {
        if (visible && ((!editable && data?.length) || editable)) return true;
        else return false;
      },
      //Function to format Activity Type  header title text
      fnFormatActTypeTitle: function (isDetailPage, typeDescription, actId) {
        if (isDetailPage === "detail") {
          return typeDescription + " (" + actId + ")";
        } else {
          if (typeDescription) {
            return typeDescription;
          } else {
            return "Activity Type";
          }
        }
      },
      setAccountVisibility: function (associateTypeId, editable, ID) {
        let controlVis = false;
        if (associateTypeId !== "503" && ((!editable && ID) || editable))
          controlVis = true;
        return controlVis;
      },
      setOppoVisibility: function (associateTypeId, editable, ID) {
        let controlVis = false;
        if (associateTypeId === "502" && ((!editable && ID) || editable))
          controlVis = true;
        return controlVis;
      },
      setAssociationType(associationId) {
        let associationType = 0;
        switch (associationId) {
          case "501":
            associationType = 0;
            break;
          case "502":
            associationType = 1;
            break;
          case "503":
            associationType = 2;
            break;
          default:
            associationType = 0;
            break;
        }
        return associationType;
      },

      totalSavedMyEntries: function (aEntries) {
        if (aEntries && aEntries.length > 0) {
          var bEssInMu = aEntries[0].user.essInMu;
          var aActivities = aEntries[0].tasks;
          var iEntriesLength = 0;
          // for (var i = 0; i < aEntries.length; i++) {
          //   var oActivity = aActivities.find(function (item) {
          //     return item.taskId.toString() === aEntries[i].TaskId.toString();
          //   });
          //   if (
          //     oActivity &&
          //     ((bEssInMu && !oActivity.essInMu) || !bEssInMu) &&
          //     oActivity.isArchive !== "X" &&
          //     (aEntries[i].StatusId === "1" || aEntries[i].StatusId === 1)
          //   ) {
          //     iEntriesLength += 1;
          //   }
          // }
          return "Entries(" + aEntries.length + ")";
        } else {
          return "Entries(0)";
        }
      },

      formatHourTaskMethod: function (
        oLocations,
        workDuration,
        sTaskName,
        locationId,
        taskId,
        aTasks,
        user
      ) {
        var oTask = aTasks.find(function (item) {
          return item.taskId.toString() === taskId.toString();
        });
        var formatLocation = "";
        var formatTaskName = "Task Type:";
        if (oTask) {
          formatTaskName = "Task Type:" + oTask.taskName;
        }
        var returnFormat = "";
        var sTimeMatrics = user.timeMatrics;
        var sDayTxt = workDuration > 1 ? " days" : " day";
        var formatWorkDur =
          sTimeMatrics === "H"
            ? "Time:" + workDuration
            : "Time:" + workDuration + sDayTxt;

        returnFormat =
          formatWorkDur + "\n" + formatTaskName + "\n" + formatLocation;
        return returnFormat;
      },

      formatDateMyEntries: function (sDate) {
        if (sDate) {
          return sDate;
        } else {
          return "";
        }
      },

      viewMyEntriesType: function (
        sMtrUid,
        sCostTypeId,
        sCostTypeValue,
        user
      
      ) {
          let timeEntries = TimeState.getInstance().getData().entries;
          var oEntry = timeEntries.find(function (entry) {
            return entry.guid.toUpperCase() === sMtrUid.toUpperCase();
          });
          if (!sCostTypeId || sCostTypeId === "") {
            return "";
          }
          if (sCostTypeId.toString() === "1") {
            let aOpportunities = OpportunityState.getInstance().getData().opportunities;
            var oOpportunity = aOpportunities.find(function (o) {
              return (
                sCostTypeValue !== "" &&
                parseInt(o.id, 10) === parseInt(sCostTypeValue, 10)
              );
            });
            var returnOppValue = oOpportunity
              ? "Opportunity: " +
              oOpportunity.AccountName +
              ": " +
              oOpportunity.id +
              ": " +
              oOpportunity.description
              : "Opportunity: " + sCostTypeValue;
            oEntry.costType.name = returnOppValue;
            oEntry.TypeExportName = returnOppValue;
            return returnOppValue;
          } else if (sCostTypeId.toString() === "2") {
            var returnCostCenter = "Cost Center: " + TimeState.getInstance().getUser().costCenter;
            oEntry.costType.name = returnCostCenter;
            oEntry.TypeExportName = returnCostCenter;
            return returnCostCenter;
          } else if (sCostTypeId.toString() === "3") {
            var aManualIO = user.to_MANUAL;
            var oManualIO = aManualIO.find(function (manualIO) {
              return manualIO.ManualIOID === sCostTypeValue;
            });
            var returnManualIOValue = oManualIO
              ? "Manual IO: " +
              oManualIO.ManualIOID +
              ": " +
              oManualIO.ManualIODesc
              : "Manual IO: " + sCostTypeValue;
            oEntry.CostTypeName = returnManualIOValue;
            oEntry.TypeExportName = returnManualIOValue;
            return returnManualIOValue;
          } else if (sCostTypeId.toString() === "4") {
            var aAccount = AccountState.getInstance().getData().accounts;
            var oAccount = aAccount.find(function (account) {
              return account.id === sCostTypeValue;
            });
            var returnAccountValue = oAccount
              ? "Account Id: " +
              oAccount.id +
              ": " +
              oAccount.AccountDesc
              : "Account Id: " + sCostTypeValue;
            oEntry.costType.name = returnAccountValue;
            oEntry.TypeExportName = returnAccountValue;
            return returnAccountValue;
          } else if (sCostTypeId.toString() === "5") {
            var returnPlaceholderValue = "Placeholder: " + sCostTypeValue;
            oEntry.CostTypeName = returnPlaceholderValue;
            oEntry.TypeExportName = returnPlaceholderValue;
            return returnPlaceholderValue;
          }
        
      },

      getMtrEditButtonVisibility: function (
        sActivityID,
        sTaskId,
        sAddCategoryId,
        tasks
      ) {
        var oTask = tasks.find(function (task) {
          return task.taskId == sTaskId;
        });
        if (
          sActivityID === "" &&
          oTask.IsLearning === false &&
          sAddCategoryId !== "5"
        ) {
          return true;
        } else {
          return false;
        }
      },
      totalFailedMyEntries: function (aEntries) {
        if (aEntries && aEntries.length > 0) {
          var bEssInMu = aEntries[0].user.essInMu;
          var aActivities = aEntries[0].tasks;
          var iEntriesLength = 0;
          for (var i = 0; i < aEntries.length; i++) {
            var oActivity = aActivities.find(function (item) {
              return item.taskId.toString() === aEntries[i].TaskId.toString();
            });
            if (
              oActivity &&
              ((bEssInMu && !oActivity.EssInMu) || !bEssInMu) &&
              oActivity.IsArchive !== "X" &&
              (aEntries[i].StatusId === "3" || aEntries[i].StatusId === 3)
            ) {
              iEntriesLength += 1;
            }
          }
          return "Entries(" + iEntriesLength + ")";
        } else {
          return "Entries(0)";
        }
      },

      totalSubmittedMyEntries: function (aEntries) {
        if (aEntries && aEntries.length > 0) {
          var bEssInMu = aEntries[0].user.essInMu;
          var aActivities = aEntries[0].tasks;
          var iEntriesLength = 0;
          for (var i = 0; i < aEntries.length; i++) {
            var oActivity = aActivities.find(function (item) {
              return item.taskId.toString() === aEntries[i].TaskId.toString();
            });
            if (
              oActivity &&
              ((bEssInMu && !oActivity.EssInMu) || !bEssInMu) &&
              oActivity.IsArchive !== "X" &&
              (aEntries[i].StatusId === "4" || aEntries[i].StatusId === 4)
            ) {
              iEntriesLength += 1;
            }
          }
          return "Entries(" + iEntriesLength + ")";
        } else {
          return "Entries(0)";
        }
      },

      filterSavedMyEntries: function (oEntry, that) {
        if (!that) {
          that = this;
        }
        var aActivities = oEntry.tasks;

        var oActivity = aActivities.find(function (item) {
          return item.taskId == oEntry.TaskId;
        });
        if (
          oActivity &&
          oActivity.IsArchive !== "X" &&
          (oEntry.StatusId === "1" || oEntry.StatusId === 1)
        ) {
          return true;
        } else {
          return false;
        }
      },
      filterFailedMyEntries: function (oEntry, that) {
        if (!that) {
          that = this;
        }
        var aActivities = oEntry.tasks;
        var oActivity = aActivities.find(function (item) {
          return item.taskId == oEntry.TaskId;
        });
        if (
          oActivity &&
          oActivity.IsArchive !== "X" &&
          (oEntry.StatusId === "3" || oEntry.StatusId === 3)
        ) {
          return true;
        } else {
          return false;
        }
      },
      filterSubmittedMyEntries: function (oEntry, that) {
        if (!that) {
          that = this;
        }
        var aActivities = oEntry.tasks;
        var oActivity = aActivities.find(function (item) {
          return item.taskId.toString() === oEntry.TaskId.toString();
        });
        if (
          oActivity &&
          oActivity.IsArchive !== "X" &&
          (oEntry.StatusId === "4" || oEntry.StatusId === 4)
        ) {
          return true;
        } else {
          return false;
        }
      },
      formatActivityRiskButton: function (riskId) {
        var type;
        switch (riskId) {
          case "01":
            type = "Reject";
            break;
          case "02":
            type = "Attention";
            break;
          case "03":
            type = "Accept";
            break;
          default:
            type = "Transparent";
        }
        return type;
      },
      formatRiskButtonPress: function (selectedRiskId, riskId) {
        return riskId === selectedRiskId;
      },

      /**
       * @author DARSHAN
       * @function formatSharingProperty
       * @description function to return sharing type for variant
       * @param {String} sharing
       */
      formatSharingProperty: function (sharing) {
        let type = sap.m.SharingMode.Public;
        if (sharing === "private") {
          type = sap.m.SharingMode.Private;
        }
        return type;
      },

      /**
       * @author DARSHAN
       * @function setVariantModified
       * @description function to return sharing type for variant
       */
      setVariantModified: function (modifiedKey, variantBackUp, activeVariant) {
        if (!activeVariant?.hasConfigurationChanged) {
          return false;
        }

        const modified = activeVariant.hasConfigurationChanged(
          variantBackUp?.configurations,
          modifiedKey
        );
        return modified;
      },

      formatDetailTypes: function (data) {
        return data?.map((each) => each.description).join(",");
      },

      formatSolutions: function (data) {
        return data?.map((each) => each.name).join(",");
      },

      getDetailTypeIds: function (data) {
        return data?.map((each) => each.id);
      },

      setOpportunityId: function (associationId, opportunityId) {
        if (associationId === "502") return opportunityId;
        else return null;
      },

      /**
       * @author DARSHAN
       * @function formatRiskButtons
       * @description function to return pressed based on values
       */
      formatRiskButtons: function (riskType, riskValues = []) {
        if (!riskValues.length) {
          return false;
        }
        switch (riskType) {
          case "RED":
            if (riskValues.indexOf("01") !== -1) {
              return true;
            }
            break;
          case "YELLOW":
            if (riskValues.indexOf("02") !== -1) {
              return true;
            }
            break;
          case "GREEN":
            if (riskValues.indexOf("03") !== -1) {
              return true;
            }
            break;
          default:
            return false;
        }
        return false;
      },

      /**
       * @author DARSHAN
       * @function getListTableHighlight
       * @description function to return table column highlight
       */
      getListTableHighlight: function (riskType) {
        if (!riskType) {
          return sap.ui.core.MessageType.None;
        }
        riskType = riskType.toUpperCase();
        switch (riskType) {
          case "01":
            return sap.ui.core.MessageType.Error;
          case "02":
            return sap.ui.core.MessageType.Warning;
          case "03":
            return sap.ui.core.MessageType.Success;
          default:
            return sap.ui.core.MessageType.None;
        }
      },
      getLead: function (lead, id) {
        if (id)
          return lead;
        else return {};
      },
      formatAddOppDate: function (date) {
        var dateFormat = DateFormat.getDateInstance({
          style: "medium"
        });
        if (date && date !== null && date !== "") {
          return dateFormat.format(new Date(date));
        } else {
          return null;
        }
      },

      handleOppoSelectBtnText: function (selected) {
        if (selected) return 'Deselect';
        else return 'Select';
      },

      getTypesByAssociation: function (types, association) {
        return types[association]

      },

      fnSetTimeMatricsText: function (TimeMatrics, isHours) {
        TimeMatrics = TimeMatrics === "H" ? "hours" : "day(s)";
        if (isHours && TimeMatrics) {
          return isHours + " " + TimeMatrics;
        } else if (isHours === 0 && TimeMatrics) {
          return "0 " + TimeMatrics;
        } else {
          return TimeMatrics;
        }
      },
      //function to format Date for CIS popover
      fnFormatDateForCIS: function (oDate) {
        if (oDate) {
          var date = oDate.getDate();
          date = date < 10 ? "0" + date : date.toString();
          var month = oDate.toLocaleString("default", {
            month: "short"
          });
          return month + " " + date;
        }
      },

      //function format string for CIS popover CF
      fnFormatWorkDurationTimeMatForCISCF: function (sWorkDuration, TimeMatrics) {
        return this.formatter.fnFormatWorkDurationTimeMatForCIS(sWorkDuration, TimeMatrics, "CF");
      },

		//function to format work duration and Time Matrics for CIS popover
		fnFormatWorkDurationTimeMatForCIS: function (sWorkDuration, TimeMatrics, unit) {
			TimeMatrics = TimeMatrics === "H" ? " hours" : " day";
			if (sWorkDuration) {
				return sWorkDuration + " " + TimeMatrics + " " + unit;
			} else {
				return "0 " + TimeMatrics + " " + unit;
			}
		},

      //Function to format text in Submission info popover date-work duration in detail page
      fnFormatEntryInfoFooterText: function (selectedIcon) {
        switch (selectedIcon) {
          case "SAVED":
            return "to submit";
          case "FAILED":
            return "to resolve";
          case "SUBMITTED":
            return "to view";
          default:
            return "";
        }
      },
      //function format string for CIS popover NCF
      fnFormatWorkDurationTimeMatForCISNCF: function (sWorkDuration, TimeMatrics) {
        return this.formatter.fnFormatWorkDurationTimeMatForCIS(sWorkDuration, TimeMatrics, "NCF");
      },

      formatTimeText: function (workDuration) {
			if (!workDuration) {
				return "";
			}
		
			const sTimeMatrics = TimeState.getInstance().getUser().time.unit;

			if (!sTimeMatrics) {
				return "";
			}
			const sDayTxt = parseFloat(workDuration) > 1 ? " days" : " day";
			const returnFormat = (sTimeMatrics === "H") ? `Time: ${workDuration}` : `Time: ${workDuration}${sDayTxt}`;
			return returnFormat;
		}


    };
  }
);
