onmessage = function (oEvent) {
    //ADD LOGIC HERE


    //PASS THE FINAL RESULT HERE
	postMessage();
};