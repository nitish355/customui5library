sap.ui.define(
  [
    "com/melodylib/core/service/CoreService",
    "com/melody/activity/enum/Services",
  ],
  function (CoreService, Services) {
    "use strict";

    let oMasterService = CoreService.extend(
      "com.melody.activity.service.MasterService",
      {
        getActDetRiskButtons: function () {
          return this.odata("/Yc_Mac_M_Risk_Asses").get("activityList");
        },

        getActivityStatusMasterData: function () {
          return this.odata("/YC_MAC_M_ACTVT_STATUS").get("activityModel");
        },

        //ActivityList API
        getActivityList: function (urlParams) {
          let mParameters = {
            filters: [],
            urlParameters: {
              $select: urlParams,
            },
          };
          return this.odata("/YC_MAC_T_ACTVT_SET(P_IncludeTeam='')/Set").get(
            "activityList",
            mParameters
          );
        },

        getActivityListCounts: function (includeTeamflag) {
          return this.odata(
            "/YC_MAC_T_ACTVT_SET_COUNT(P_IncludeTeam='" +
              includeTeamflag +
              "')/Set"
          ).get("activityList");
        },

        //ActivityList Master Data

        getActivityListStatusMasterData: function () {
          return this.odata("/YC_MAC_M_STATUS_LIST").get("activityList");
        },

        getActivityListDelTeamMasterData: function () {
          return this.odata("/YC_MAC_M_DELV_TEAM").get("activityList");
        },

        getActivityListHostTypeMasterData: function () {
          return this.odata("/YC_MAC_M_HOST_TYPE").get("activityList");
        },

        getActivityListLandScapeMasterData: function () {
          return this.odata("/Yc_Mac_M_Landscape_As").get("activityList");
        },

        getActivityListProjectTypeMasterData: function () {
          return this.odata("/YC_MAC_M_PROJ_TYPE").get("activityList");
        },

        getActivityListRegionMasterData: function () {
          return this.odata("/YC_MAC_REGION_MASTER_ACTLIST").get(
            "activityList"
          );
        },

        getActivityListShowroomMasterData: function () {
          return this.odata("/Yc_Mac_M_Showroom_As").get("activityList");
        },

        getActivityListUseCaseMasterData: function () {
          return this.odata("/YC_MAC_M_USE_CASE").get("activityList");
        },

        getActivityListStrategicAreaMasterData: function () {
          return this.odata("/Yc_Mac_M_Strategic_Area").get("activityList");
        },

        getActivityListRoleMasterData: function (parameters) {
          return this.odata("/YC_MAC_M_ACTVTYPE_ROLE").get(
            "activityList",
            parameters
          );
        },

        getActivityMainData: function (aFilters, urlParams) {
          var mParameters = {
            filters: aFilters,
            urlParameters: urlParams,
          };
          return this.odata(Services.GET_ACTIVITY_DATA).get(
            "activityModel",
            mParameters
          );
        },

        getLayoutData: function (aFilters) {
          var mParameters = {
            filters: aFilters,
          };
          return this.odata(Services.GET_FORM_LAYOUTS).get(
            "activityModel",
            mParameters
          );
        },

        getRoleMasterData: function () {
          return this.odata(Services.GET_ROLES_MASTER).get("activityModel");
        },

        getCountData: function (servicePath, parameters) {
          return this.odata(servicePath).get("activityList", parameters);
        },

        getAllActivityIDs: function () {
          return this.odata("/YC_MAC_T_ACTIVITYID").get("activityList");
        },

        getActions:function(params){
          const options = this.getUrlParameters(params);
          return this.odata("/YC_SL_M_ACT_PRNT_ACTION").get("activityList",options);         
        },

        setActivityStatus:function(payload){
          return this.odata("/Yc_Mac_T_Act_Main(guid'" + payload.ActivityGuid + "')").put("activityList",payload);
        },

        getUsersBySearch: function (searchParam) {
          let urlParams = {
            search: searchParam,
          };
          let parameters = {
            filters: [],
            urlParameters: urlParams,
          };
          return this.odata("/Yc_MD_Usersearch").get(
            "activityList",
            parameters
          );
        },

        getActivityTypes: function (filters) {
          const parameters = {
            filters,
          };
          return this.odata(Services.GET_ACTIVITY_TYPES).get(
            "activityModel",
            parameters
          );
        },

        getActTypeEntities: function (filters) {
          const parameters = {
            filters,
          };
          return this.odata(Services.GET_ENTITY_STRING).get(
            "activity",
            parameters
          );
        },

        getAttachments: async function (filters) {
          const parameters = {
            filters: filters,
          };
          return this.odata("/YC_MAC_T_FILE_CONTENT").get(
            "activity",
            parameters
          );
        },

        getMyOpportunities: function (options) {
          let parameters = {
            filters: options?.filters,
            urlParameters: options?.urlParams,
          };
          return this.odata("/OPPORTUNITYNOSet").get(
            "activityList",
            parameters
          );
        },
      }
    );
    return new oMasterService();
  }
);
