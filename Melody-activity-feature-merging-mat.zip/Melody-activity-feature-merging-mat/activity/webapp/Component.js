/**
 * eslint-disable @sap/ui5-jsdocs/no-jsdoc
 */

sap.ui.define(
  [
    "sap/ui/Device",
    "com/melodylib/core/Lib",
    "sap/ui/core/UIComponent",
    "com/melodylib/core/enum/Actions",
    "com/melody/activity/model/models",
    "com/melodylib/core/state/AuthState",
    "com/melody/activity/util/Application",
    "com/melodylib/activity/state/DBRState",
    "com/melodylib/core/state/VariantState",
    "com/melodylib/activity/state/ActivityState",
    "com/melodylib/integration/state/AccountState",
    "com/melodylib/integration/state/OpportunityState",
    "com/melodylib/activity/state/ActivityMasterState",
    "com/melodylib/time/state/TimeState",

  ],
  function (
    Device,
    CoreLib,
    UIComponent,
    Actions,
    models,
    AuthState,
    Application,
    DBRState,
    VariantState,
    ActivityState,
    AccountState,
    OpportunityState,
    ActivityMasterState,
    TimeState
  ) {
    "use strict";

    return UIComponent.extend("com.melody.activity.Component", {
      metadata: {
        manifest: "json",
      },

      /**
       * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
       * @public
       * @override
       */
      init: function () {
        //Initialize States
        this.authState = AuthState.getInstance();
        this.accountState = AccountState.getInstance();
        this.activityState = ActivityState.getInstance();
        this.variantState = VariantState.getInstance();
        this.opportunityState = OpportunityState.getInstance();
        this.activityMasterState = ActivityMasterState.getInstance();
        this.timeState = TimeState.getInstance();
        this.dbrState = DBRState.getInstance();

        // call the base component's init function
        UIComponent.prototype.init.apply(this, arguments);

        // enable routing
        this.router = this.getRouter();
        this.router.initialize();

        //route pattern matched
        this.router.attachRoutePatternMatched(this.routeMatchedComponent, this);

        // set the device model
        this.setModel(models.createDeviceModel(), "device");

        // set models
        this.setModel(this.authState.getModel(), "authState");
        this.setModel(this.variantState.getModel(), "variantState");
        this.setModel(this.accountState.getModel(), "accountState");
        this.activityState.getModel().setSizeLimit(10000);
        this.setModel(this.activityState.getModel(), "activityState");
        this.setModel(this.opportunityState.getModel(), "opportunityState");
        this.setModel(this.timeState.getModel(), "timeState");
        this.setModel(
          this.activityMasterState.getModel(),
          "activityMasterState"
        );
        this.setModel(this.dbrState.getModel(), "dbrState");
        
        //Application
        // Application.getInstance().init(this, UIComponent);

        //SERVICE WORKER
        try {
          // register service worker if supported
          if ("serviceWorker" in navigator) {
            let sServiceWorkerPath = sap.ui.require.toUrl(
              "com/melody/activity/Serviceworker.js"
            );
            navigator.serviceWorker
              .register(sServiceWorkerPath)
              .then(
                function (registration) {
                  console.log(
                    "ServiceWorker registration successful with scope:",
                    registration.scope
                  );
                }.bind(this)
              )
              .catch(function (error) {
                console.log("ServiceWorker registration failed:", error);
              });
          }
        } catch (error) {
          console.log("WEB WORKER FAILED");
        }
      },

      /**
       *
       * @public
       * @function routeMatchedComponent
       * @description function to handle router matched
       *
       */
      routeMatchedComponent: function (event) {
        let groupName = "";
        let variantId = "";

        const routeName = event.getParameter("name");
        switch (routeName) {
          case "MyOpportunities":
            groupName = Actions.variantGroupTypes.opportunity;
            break;
          case "MyEntries":
            groupName = Actions.variantGroupTypes.entries;
            break;
          case "MyDBRs":
            groupName = Actions.variantGroupTypes.dbr;
            break;
          default:
            groupName = Actions.variantGroupTypes.activity;
        }

        let applicationName = this.getManifestEntry("/sap.app/id").replaceAll(
          ".",
          "/"
        );
        let options = {
          appId: applicationName,
          useBatch: true,
          type: Actions.projectTypes.activity,
          variantOptions: {
            groupName,
            variantId,
          },
        };

        //Initialize App data
        CoreLib.getInstance()
          .init(options)
          .then((user) => {
            const rootView = this.getAggregation("rootControl");
            const controller = rootView?.getController();
            const i18n = this.getModel("i18n");
            const activityListModel = controller
              .getOwnerComponent()
              .getModel("activityListModel");
            activityListModel.setProperty("/user", user);
            // activityListModel.setProperty("/userUnauthorized", false);
            // user.oreFlag = "";
            if (user) {
              // activityListModel.setProperty("/userUnauthorized", true);
              if (
                controller &&
                typeof controller.triggerListTableFunctions === "function"
              ) {
                controller.triggerListTableFunctions();
              } else {
                console.error("Controller function not found.");
              }
              this.router.detachRoutePatternMatched(
                this.routeMatchedComponent,
                this
              );
            } else {
              controller.getView().byId("melodyactivitypage").destroyContent();
              controller
                .getView()
                .byId("melodyactivitypage")
                .addContent(
                  new sap.m.FlexBox({
                    items: [
                      new sap.m.IllustratedMessage({
                        title: i18n
                          .getResourceBundle()
                          .getText("notauthorized"),
                        description: i18n
                          .getResourceBundle()
                          .getText("notauthorizednonoreuser"),
                        illustrationSize: "Dialog",
                        illustrationType: sap.m.IllustratedMessageType.NoData,
                      }),
                    ],
                    alignItems: "Center",
                    justifyContent: "Center",
                    height: "100%",
                  })
                );
              // activityListModel.setProperty("/userUnauthorized", false);
            }
          });
      },

      /**
       * This method can be called to determine whether the sapUiSizeCompact or sapUiSizeCozy
       * design mode class should be set, which influences the size appearance of some controls.
       * @public
       * @return {string} css class, either 'sapUiSizeCompact' or 'sapUiSizeCozy' - or an empty string if no css class should be set
       */
      getContentDensityClass: function () {
        if (this._sContentDensityClass === undefined) {
          // check whether FLP has already set the content density class; do nothing in this case
          // eslint-disable-next-line sap-no-proprietary-browser-api
          if (
            document.body.classList.contains("sapUiSizeCozy") ||
            document.body.classList.contains("sapUiSizeCompact")
          ) {
            this._sContentDensityClass = "";
          } else if (!Device.support.touch) {
            // apply "compact" mode if touch is not supported
            this._sContentDensityClass = "sapUiSizeCompact";
          } else {
            // "cozy" in case of touch support; default for most sap.m controls, but needed for desktop-first controls like sap.ui.table.Table
            this._sContentDensityClass = "sapUiSizeCozy";
          }
        }
        return this._sContentDensityClass;
      },
    });
  }
);
