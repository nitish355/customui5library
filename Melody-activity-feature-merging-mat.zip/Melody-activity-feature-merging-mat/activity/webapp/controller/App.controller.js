// @ts-nocheck
sap.ui.define(
  [
    "com/melody/activity/controller/BaseController",
    "com/melodylib/integration/util/opportunity/OpportunityUtil",
  ],
  function (BaseController, OpportunityUtil) {
    "use strict";

    return BaseController.extend("com.melody.activity.controller.App", {
      //Init method
      onInit: function () {
        this.oRouter = this.getOwnerComponent().getRouter();
        this.oRouter.attachRoutePatternMatched(this.onRouteMatched, this);
        //Test
        // if (!this.OpportunityUtil) {
        //   this.OpportunityUtil = OpportunityUtil.getInstance();
        // }
        // this.fnInitializeOpportunities();
        // apply content density mode to root view
        this.getView().addStyleClass(
          this.getOwnerComponent().getContentDensityClass()
        );
      },

      // fnInitializeOpportunities: async function () {
      //   const storage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
      //   let promise = [
      //     this.OpportunityUtil.getConstantData(),
      //     this.OpportunityUtil.getAllOpportunities(),
      //   ];
      //   // @ts-ignore
      //   await Promise.all(promise);
      // },

      onBeforeRouteMatched: function (oEvent) {
        var oModel = this.getOwnerComponent().getModel();

        var sLayout = oEvent.getParameters().arguments.layout;

        // If there is no layout parameter, query for the default level 0 layout (normally OneColumn)
        if (!sLayout) {
          var oNextUIState = this.getOwnerComponent()
            .getHelper()
            .getNextUIState(0);
          sLayout = oNextUIState.layout;
        }

        // Update the layout of the FlexibleColumnLayout
        if (sLayout) {
          oModel.setProperty("/layout", sLayout);
        }
      },

      // Update the close/fullscreen buttons visibility
      _updateUIElements: function () {
        var oModel = this.getOwnerComponent().getModel();
        var oUIState = this.getOwnerComponent().getHelper().getCurrentUIState();
        oModel.setData(oUIState);
      },

      onExit: function () {
        this.oRouter.detachRouteMatched(this.onRouteMatched, this);
        this.oRouter.detachBeforeRouteMatched(this.onBeforeRouteMatched, this);
      },
    });
  }
);
