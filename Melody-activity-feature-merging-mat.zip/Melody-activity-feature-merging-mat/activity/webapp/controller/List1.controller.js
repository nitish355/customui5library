// @ts-nocheck
sap.ui.define(
  [
    "com/melody/activity/controller/BaseController",
    "com/melody/activity/service/MasterService",
    "com/melody/activity/util/MasterData",
    "sap/ui/core/Fragment",
    "com/melody/activity/util/formatter",
    "com/melody/activity/model/Form",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "com/melodylib/core/db/IndexedDB",
    "com/melody/activity/service/AccountService",
  ],
  /**
   * @param {typeof sap.ui.core.mvc.Controller} Controller
   */
  function (
    BaseController,
    MasterService,
    MasterData,
    Fragment,
    formatter,
    Form,
    Filter,
    FilterOperator,
    IndexedDB,
    AccountService,
    ActivityService
  ) {
    "use strict";

    return BaseController.extend("com.melody.activity.controller.List", {
      formatter: formatter,
      onInit: function () {
        let activityListModel =
          this.getOwnerComponent().getModel("activityListModel");
        activityListModel.setProperty("/headerExpanded", true);
        let aFormList = [
          {
            title: "New Activity",
            account: {},
            opportunity: {},
            team: [],
            lead: null,
          },
        ];
        activityListModel.setProperty("/formList", aFormList);
        this._currentView = this.getView();
        this.oRouter = this.getOwnerComponent().getRouter();
        this.oRouter.attachRoutePatternMatched(
          this.onRoutePatternMatched,
          this
        );
      },

      //function to be called on route pattern matched.
      onRoutePatternMatched: function (oEvent) {
        let activityListModel =
          this.getOwnerComponent().getModel("activityListModel");
        let includeTeamflag = "";
        let oColumnsModel = this.getOwnerComponent().getModel("oColumnsModel");
        let aActivityListCols = oColumnsModel.getData().aActivityListCols;
        let urlParams = "ActivityGUID,ActivityTypeId,ActTypeDesc,ActId";
        activityListModel.setProperty("/tableColumns", aActivityListCols);
        aActivityListCols.map((each) => {
          if (each.selected) {
            urlParams = urlParams + "," + each.property;
          }
          oColumnsModel.setProperty(
            "/" + each.key + "Visibility",
            each.selected
          );
        });
        if (oEvent.getParameter("name") === "list") {
          this.handleBrowserNav();
          this.getActivityListCounts(includeTeamflag);
          this.getActivityList(urlParams);
        }
        this.onRouteMatched(oEvent);
      },

      //function to navigate to Activity Registration
      onPressNavToNewActivityRegistration: function () {
        this.handleAuthCheck("registerForm");
        this.oRouter.navTo("registerForm");
        let activityListModel =
          this.getOwnerComponent().getModel("activityListModel");
        // activityListModel.setProperty("/layout", "EndColumnFullScreen");
        activityListModel.setProperty("/mode", "edit");
        activityListModel.setProperty("/formData", "");
      },

      //function to open Personalization Dialog
      onPressPersonalizationDialogOpen: function () {
        if (!this.oPersonalizationDialog)
          Fragment.load({
            name: "com.melody.activity.fragments.list.Personalization",
            controller: this,
          }).then(
            function (oDialog) {
              this.oPersonalizationDialog = oDialog;
              this._currentView.addDependent(oDialog);
              this.oPersonalizationDialog.open();
            }.bind(this)
          );
        else this.oPersonalizationDialog.open();
      },

      //function to control the visibility of columns on selectionchange in persoDialog
      onPressColumnVisibility: function (oEvent) {
        let activityListModel =
          this.getOwnerComponent().getModel("activityListModel");
        let oColumnsModel = this.getOwnerComponent().getModel("oColumnsModel");
        let sPath = oEvent.getParameter("listItem").getBindingContextPath();
        let oSelectedObj = activityListModel.getProperty(sPath);
        let length = oEvent.getSource().getSelectedContextPaths().length;
        if (length < 7) {
          if (oEvent.getParameter("selected")) {
            oColumnsModel.setProperty(
              "/" + oSelectedObj.key + "Visibility",
              true
            );
          } else {
            oColumnsModel.setProperty(
              "/" + oSelectedObj.key + "Visibility",
              false
            );
          }
        } else {
          sap.m.MessageToast.show("Please select max 6 columns");
          oEvent.getParameter("listItem").setSelected(false);
        }
      },

      //function to close Personalization Dialog
      onPressPersonalizationDialogClose: function (oEvent) {
        let activityListModel =
          this.getOwnerComponent().getModel("activityListModel");
        let selectedPaths = oEvent
          .getSource()
          .getParent()
          .getContent()[0]
          .getSelectedContextPaths();
        let urlParams = "ActivityGUID,ActivityTypeId,ActTypeDesc,ActId";
        selectedPaths.map((each) => {
          if (activityListModel.getProperty(each).property) {
            urlParams =
              urlParams + "," + activityListModel.getProperty(each).property;
          }
        });
        this.getActivityList(urlParams);
        this.oPersonalizationDialog.close();
      },

      //function to open popover to display solution data ondemand
      onPressSolutionCountButton: async function (event) {
        let activityListModel =
          this.getOwnerComponent().getModel("activityListModel");
        let selectedRowData = event
          .getSource()
          .getParent()
          .getBindingContext("activityListModel")
          .getObject();
        if (event.getSource().getText() !== "0") {
          let isServiceReq = false;
          if (
            selectedRowData.ActivityTypeId === "0012" ||
            selectedRowData.ActivityTypeId === "0015" ||
            selectedRowData.ActivityTypeId === "0124"
          ) {
            isServiceReq = true;
          }

          let filters = [
            new Filter(
              "ActivityGuid",
              FilterOperator.EQ,
              selectedRowData.ActivityGUID
            ),
            new Filter("IsServiceRequest", FilterOperator.EQ, isServiceReq),
          ];
          activityListModel.setProperty("/FragmentTableBusy", true);
          this.onDemandGetChildData(
            event,
            filters,
            "/Yc_Mac_T_Solution",
            "SolId",
            "SolutionDesc"
          );
        }
      },

      //function to open popover to display team count data ondemand
      onPressTeamCountButton: async function (event) {
        let activityListModel =
          this.getOwnerComponent().getModel("activityListModel");
        let selectedRowData = event
          .getSource()
          .getParent()
          .getBindingContext("activityListModel")
          .getObject();
        if (event.getSource().getText() !== "0") {
          let filters = [
            new Filter(
              "ActivityGuid",
              FilterOperator.EQ,
              selectedRowData.ActivityGUID
            ),
            new Filter("Role", FilterOperator.NE, "RSCMGR"),
          ];
          activityListModel.setProperty("/FragmentTableBusy", true);
          this.onDemandGetChildData(
            event,
            filters,
            "/YC_MAC_T_ACTTEAM_DISTINCT",
            "userid",
            "name"
          );
        }
      },

      //function to open popover to display file count data ondemand
      onPressFileCountButton: async function (event) {
        let activityListModel =
          this.getOwnerComponent().getModel("activityListModel");
        let selectedRowData = event
          .getSource()
          .getParent()
          .getBindingContext("activityListModel")
          .getObject();
        if (event.getSource().getText() !== "0") {
          let filters = [
            new Filter(
              "ActivityGuid",
              FilterOperator.EQ,
              selectedRowData.ActivityGUID
            ),
          ];
          activityListModel.setProperty("/FragmentTableBusy", true);
          this.onDemandGetChildData(
            event,
            filters,
            "/YC_MAC_T_FILE_CONTENT",
            "SolId",
            "userid"
          );
        }
      },

      //function to open popover to display Add Opp count data ondemand
      onPressAddOppCountButton: async function (event) {
        let activityListModel =
          this.getOwnerComponent().getModel("activityListModel");
        let selectedRowData = event
          .getSource()
          .getParent()
          .getBindingContext("activityListModel")
          .getObject();
        if (event.getSource().getText() !== "0") {
          let filters = [
            new Filter(
              "ActivityGuid",
              FilterOperator.EQ,
              selectedRowData.ActivityGUID
            ),
          ];
          activityListModel.setProperty("/FragmentTableBusy", true);
          this.onDemandGetChildData(
            event,
            filters,
            "/YC_MAC_T_ADD_OPP",
            "Url",
            "Url"
          );
        }
      },

      onPressInnovationsCountButton: async function (event) {
        let activityListModel =
          this.getOwnerComponent().getModel("activityListModel");
        let selectedRowData = event
          .getSource()
          .getParent()
          .getBindingContext("activityListModel")
          .getObject();
        if (event.getSource().getText() !== "0") {
          let filters = [
            new Filter(
              "ActivityGuid",
              FilterOperator.EQ,
              selectedRowData.ActivityGUID
            ),
          ];
          activityListModel.setProperty("/FragmentTableBusy", true);
          this.onDemandGetChildData(
            event,
            filters,
            "/YC_MAC_T_ACTSTR_SOL",
            "Description",
            "Description"
          );
        }
      },

      onPressLandScapeCountButton: async function (event) {
        let activityListModel =
          this.getOwnerComponent().getModel("activityListModel");
        let selectedRowData = event
          .getSource()
          .getParent()
          .getBindingContext("activityListModel")
          .getObject();
        if (event.getSource().getText() !== "0") {
          let filters = [
            new Filter(
              "ActivityGuid",
              FilterOperator.EQ,
              selectedRowData.ActivityGUID
            ),
          ];
          activityListModel.setProperty("/FragmentTableBusy", true);
          this.onDemandGetChildData(
            event,
            filters,
            "/YC_MAC_T_ACTLANDSCAPE",
            "LandDescription",
            "LandDescription"
          );
        }
      },

      onPressShowroomCountButton: async function (event) {
        let that = this;
        let activityListModel =
          this.getOwnerComponent().getModel("activityListModel");
        let selectedRowData = event
          .getSource()
          .getParent()
          .getBindingContext("activityListModel")
          .getObject();
        if (event.getSource().getText() !== "0") {
          let filters = [
            new Filter(
              "ActivityGuid",
              FilterOperator.EQ,
              selectedRowData.ActivityGUID
            ),
          ];
          activityListModel.setProperty("/FragmentTableBusy", true);
          this.onDemandGetChildData(
            event,
            filters,
            "/YC_MAC_T_ACTSHOWROOM",
            "Description",
            "Description"
          );
        }
      },

      onPressSuccessFactorCountButton: async function (event) {
        let that = this;
        let activityListModel =
          this.getOwnerComponent().getModel("activityListModel");
        let selectedRowData = event
          .getSource()
          .getParent()
          .getBindingContext("activityListModel")
          .getObject();
        if (event.getSource().getText() !== "0") {
          let filters = [
            new Filter(
              "ActivityGuid",
              FilterOperator.EQ,
              selectedRowData.ActivityGUID
            ),
          ];
          activityListModel.setProperty("/FragmentTableBusy", true);
          this.onDemandGetChildData(
            event,
            filters,
            "/YC_MAC_T_ACTSUCCESS_F",
            "comp_name",
            "comp_name"
          );
        }
      },

      onDemandGetChildData: async function (
        event,
        filters,
        servicePath,
        idProperty,
        descriptionProperty
      ) {
        let that = this;
        let activityListModel =
          this.getOwnerComponent().getModel("activityListModel");
        if (!this._pPopover) {
          this._pPopover = Fragment.load({
            name: "com.melody.activity.fragments.list.CountDisplay",
            controller: this,
          }).then(function (Popover) {
            that._currentView.addDependent(Popover);
            return Popover;
          });
        }
        this._pPopover.then(function (Popover) {
          Popover.openBy(event.getSource());
        });
        let parameters = {
          filters: filters ?? [],
        };
        try {
          let { data } = await MasterService.getCountData(
            servicePath,
            parameters
          );
          if (data?.results.length) {
            let results = data.results ?? [];
            let countData = Array.from(results, (each) => ({
              id: each[idProperty],
              description: each[descriptionProperty],
            }));
            activityListModel.setProperty("/CountData", countData);
            activityListModel.setProperty("/FragmentTableBusy", false);
          }
        } catch {
          activityListModel.setProperty("/FragmentTableBusy", false);
        }
      },

      //function to navigate to Detail Page
      onPressNavToActivityDetail: function (event) {
        let activityListModel =
          this.getOwnerComponent().getModel("activityListModel");
        let activityFormModel =
          this.getOwnerComponent().getModel("activityFormModel");
        // activityListModel.setProperty("/layout", "TwoColumnsMidExpanded");
        activityListModel.setProperty("/headerExpanded", false);
        activityListModel.setProperty("/mode", "read");
        activityListModel.refresh(true);
        let selectedRowData = event
          .getSource()
          .getBindingContext("activityListModel")
          .getObject();
        let layout = activityListModel.getProperty("/layout");
        // if (layout === "TwoColumnsMidExpanded")
        //   this.setActivityForm(selectedRowData.ActId);
        // let formData = new Form({...selectedRowData,formId:selectedRowData.ActId});
        activityFormModel.refresh();
        this.oRouter.navTo("detail", {
          id: selectedRowData.ActId,
        });
      },

      //function to fetch activity List Data
      getActivityList: async function (urlParams) {
        let activityListModel =
          this.getOwnerComponent().getModel("activityListModel");
        activityListModel.setProperty("/IsTableBusy", true);
        try {
          let { data } = await MasterService.getActivityList(urlParams);
          let formattedData = await this.fnSetFormatActivityList(
            data?.results || []
          );
          activityListModel.setProperty("/ActivityList", formattedData);
          activityListModel.setProperty("/IsTableBusy", false);
        } catch (error) {
          console.log(error);
          activityListModel.setProperty("/IsTableBusy", false);
        }
      },

      //function to format the activity List to map opportunity data
      fnSetFormatActivityList: async function (activityList) {
        let masterDataModel =
          this.getOwnerComponent().getModel("masterDataModel");
        this.allAccountIDMap = [];
        if (!activityList || !activityList.length) {
          return [];
        }
        try {
          let accountPromise = [];
          // $.each(
          //   activityList,
          //   function (index, value) {
          //     if (
          //       !value.OpportunityId &&
          //       !this.allAccountIDMap[value.GlobalUltimateID]
          //     ) {
          //       if (value.GlobalUltimateID !== "") {
          //         accountPromise.push(
          //           AccountService.getBusinessAttributeSet(
          //             value.GlobalUltimateID
          //           )
          //         );
          //       }
          //     }
          //   }.bind(this)
          // );
          if (accountPromise.length) {
            let responses = await Promise.all(accountPromise);
            for (let i in responses) {
              if (responses[i].data) {
                this.allAccountIDMap[responses[i].data.PARTNER] =
                  responses[i].data;
              }
            }
          }
          let slNames = [];
          let activityLeads = [];
          const storage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
          let opportunityData = storage.get("myopportunities") || [];
          masterDataModel.setProperty("/AllOpportunities", opportunityData);
          let opportunityMapData = storage.get("myopportunities_map") || {};
          for (let i = 0; i < activityList.length; i++) {
            let tempActivity = activityList[i];
            if (tempActivity.ActivityLead) {
              let leadObj = {
                ActivityLead: tempActivity.ActivityLead,
                ActivityLeadName: tempActivity.ActivityLeadName,
              };
              activityLeads.push(leadObj);
            }
            if (tempActivity.SLName) {
              let slObj = {
                SlSnro: tempActivity.SlSnro,
                SLName: tempActivity.SLName,
              };
              slNames.push(slObj);
            }

            if (tempActivity.OpportunityId) {
              let opportunityData =
                opportunityMapData[tempActivity.OpportunityId] || {};
              tempActivity["OpportunityName"] =
                opportunityData?.OpportunityName;
              tempActivity["AccountId"] = opportunityData?.AccountId;
              tempActivity["AccountName"] = opportunityData?.AccountName;
            } else {
              if (tempActivity?.GlobalUltimateID !== "") {
                tempActivity["AccountId"] =
                  this.allAccountIDMap[tempActivity?.GlobalUltimateID]?.PARTNER;
                tempActivity["AccountName"] =
                  this.allAccountIDMap[
                    tempActivity?.GlobalUltimateID
                  ]?.PARTNER_NAME;
              }
            }
          }
          masterDataModel.setProperty("/SLNames", slNames);
          const uniqueLeads = [
            ...new Map(
              activityLeads.map((item) => [item["ActivityLead"], item])
            ).values(),
          ];
          masterDataModel.setProperty("/ActivityLeadList", uniqueLeads);
          return activityList;
        } catch (error) {
          console.log("Error in fnSetFormatActivityList ", error);
        }
      },

      //function to fetch the counts of each activity based on Guid
      getActivityListCounts: async function (includeTeamflag) {
        var that = this;
        let { data } = await MasterService.getActivityListCounts(
          includeTeamflag
        );
        this.returnMasterDataMap = [];
        $.each(
          data.results,
          function (index, value) {
            if (!that.returnMasterDataMap[value.ActivityGUID]) {
              that.returnMasterDataMap[value.ActivityGUID] = value;
            }
          }.bind(this)
        );

        this.getOwnerComponent()
          .getModel("activityListModel")
          .setProperty("/allCountsMasterDataMap", that.returnMasterDataMap);
        this.getOwnerComponent().getModel("activityListModel").refresh(true);
      },

      //function to open the activityId filter PopUp
      onPressOpenActivityIDFilterLookup: async function (event) {
        let that = this;
        let masterDataModel =
          this.getOwnerComponent().getModel("masterDataModel");
        let activityListModel =
          this.getOwnerComponent().getModel("activityListModel");

        if (!this._ActivityIDLookUpDialog) {
          this._ActivityIDLookUpDialog =
            this.fnCreateFragment("ActivityIDLookup");
        }
        this._ActivityIDLookUpDialog.then(function (dialog) {
          dialog.open();
        });
        activityListModel.setProperty("/FragmentBusy", true);
        try {
          let { data } = await MasterService.getAllActivityIDs();
          masterDataModel.setProperty("/AllActivityID", data.results);
          activityListModel.setProperty("/FragmentBusy", false);
        } catch (error) {
          activityListModel.setProperty("/FragmentBusy", false);
        }
      },

      //function to close any lookup
      onPressActivityDialogClose: function (event) {
        event.getSource().getParent().close();
      },

      //function to open opportunity Lookup
      onPressOpenOpportunityLookUp: function () {
        if (!this._OpportunityLookUpDialog) {
          this._OpportunityLookUpDialog =
            this.fnCreateFragment("OpportunityLookup");
        }
        this._OpportunityLookUpDialog.then(function (dialog) {
          dialog.open();
        });
      },

      //function to open Account Lookup
      onPressOpenAccountLookUp: function () {
        if (!this._AccountLookUpDialog) {
          this._AccountLookUpDialog = this.fnCreateFragment("AccountLookup");
        }
        this._AccountLookUpDialog.then(function (dialog) {
          dialog.open();
        });
      },

      //function to search the account names in Lookup
      onSearchAccountName: async function (event) {
        let masterDataModel =
          this.getOwnerComponent().getModel("masterDataModel");
        let activityListModel =
          this.getOwnerComponent().getModel("activityListModel");
        let searchParam = event.getSource().getValue();
        activityListModel.setProperty("/FragmentTableBusy", true);
        try {
          let { data } = await AccountService.getAccountsListBySearch(
            searchParam
          );
          masterDataModel.setProperty("/AccountSearchList", data.results);
          activityListModel.setProperty("/FragmentTableBusy", false);
        } catch (error) {
          activityListModel.setProperty("/FragmentTableBusy", false);
        }
      },

      onPressOpenActivityTypeLookUp: function () {
        if (!this._ActivityTypeLookUpDialog) {
          this._ActivityTypeLookUpDialog =
            this.fnCreateFragment("ActivityTypeLookup");
        }
        this._ActivityTypeLookUpDialog.then(function (dialog) {
          dialog.open();
        });
      },

      //function to fetch activity types based on role
      onSelectRole: async function (event) {
        let masterDataModel =
          this.getOwnerComponent().getModel("masterDataModel");
        let activityListModel =
          this.getOwnerComponent().getModel("activityListModel");
        let role_id = event.getSource().getSelectedKey();
        activityListModel.setProperty("/FragmentTableBusy", true);
        let activityTypeList = await MasterData.getActivityTypesBasedOnRole(
          role_id
        );
        masterDataModel.setProperty("/ActivityTypeList", activityTypeList);
        activityListModel.setProperty("/FragmentTableBusy", false);
      },

      //function to open Activity Lead Lookup
      onPressOpenActivityLeadLookUp: function () {
        if (!this._ActivityLeadLookUpDialog) {
          this._ActivityLeadLookUpDialog =
            this.fnCreateFragment("ActivityLeadLookup");
        }
        this._ActivityLeadLookUpDialog.then(function (dialog) {
          dialog.open();
        });
      },

      //function to open Activity Team Lookup
      onPressOpenActivityTeamLookUp: function () {
        if (!this._ActivityTeamLookUpDialog) {
          this._ActivityTeamLookUpDialog =
            this.fnCreateFragment("ActivityTeamLookup");
        }
        this._ActivityTeamLookUpDialog.then(function (dialog) {
          dialog.open();
        });
      },

      //function to get the search results of the searched data
      onSearchActivityTeamUser: async function (event) {
        let masterDataModel =
          this.getOwnerComponent().getModel("masterDataModel");
        let activityListModel =
          this.getOwnerComponent().getModel("activityListModel");
        let searchParam = event.getSource().getValue();
        if (searchParam && searchParam !== "") {
          activityListModel.setProperty("/FragmentTableBusy", true);
          try {
            let { data } = await MasterService.getUsersBySearch(searchParam);
            masterDataModel.setProperty("/ActivityTeamUsersList", data.results);
            activityListModel.setProperty("/FragmentTableBusy", false);
          } catch (error) {
            activityListModel.setProperty("/FragmentTableBusy", false);
          }
        }
      },

      //function to open Innovations Lookup
      onPressOpenInnovationsLookUp: function () {
        if (!this._InnovationsLookUpDialog) {
          this._InnovationsLookUpDialog =
            this.fnCreateFragment("InnovationsLookup");
        }
        this._InnovationsLookUpDialog.then(function (dialog) {
          dialog.open();
        });
      },

      onPressOpenLandScapesLookUp: function () {
        if (!this._LandScapesLookUpDialog) {
          this._LandScapesLookUpDialog =
            this.fnCreateFragment("LandscapesLookup");
        }
        this._LandScapesLookUpDialog.then(function (dialog) {
          dialog.open();
        });
      },

      onPressOpenShowroomLookUp: function () {
        if (!this._ShowRoomLookUpDialog) {
          this._ShowRoomLookUpDialog = this.fnCreateFragment("ShowroomLookup");
        }
        this._ShowRoomLookUpDialog.then(function (dialog) {
          dialog.open();
        });
      },

      fnCreateFragment: function (fragmentName) {
        let fragment = Fragment.load({
          name: "com.melody.activity.fragments.list." + fragmentName,
          controller: this,
        }).then(
          function (dialog) {
            this._currentView.addDependent(dialog);
            return dialog;
          }.bind(this)
        );

        return fragment;
      },

      //function to navigate to CRM page on click of opportunity
      onPressNavToCRM: async function (oEvent) {
        let opportunityId = oEvent.getSource().getText();
        let urlConstants =
          (await IndexedDB.fnGetAllDatafromDB({
            dbName: "master-data",
            storeName: "master-data-table",
            keyName: "harmonyconstanturls",
          })) || [];
        window.open(
          `${urlConstants["0011"].field_value}${opportunityId}/plan`,
          "_blank"
        );
      },
      //function to navigate to My Entries
      onPressNavToMyEntries: function () {
        this.oRouter.navTo("MyEntries");
      },
    });
  }
);
