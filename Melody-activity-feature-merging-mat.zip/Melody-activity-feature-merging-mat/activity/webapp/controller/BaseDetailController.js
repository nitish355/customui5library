// @ts-nocheck
sap.ui.define(
  [
    "com/melody/activity/controller/BaseController",
    "sap/ui/core/Fragment",
    "com/melody/activity/util/MasterData",
    "com/melody/activity/util/formatter",
    "com/melodylib/activity/state/ActivityMasterState",
    "com/melodylib/activity/state/ActivityState",
    "com/melodylib/integration/state/OpportunityState",
    "com/melodylib/integration/util/opportunity/OpportunityUtil",
    "sap/ui/model/Filter"
  ],
  /**
   * @param {typeof sap.ui.core.mvc.Controller} Controller
   */
  function (BaseController, Fragment, MasterData, formatter, ActivityMasterState, ActivityState, OpportunityState, OpportunityUtil, Filter) {
    "use strict";

    return BaseController.extend(
      "com.melody.activity.controller.BaseDetailController",
      {
        formatter: formatter,
        //-------Assets and Documents---------

        // function to open edit asessts and documents dialog
        openAssestsDocsPopover: async function () {
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const activityStateModel =
            this.getOwnerComponent().getModel("activityState");
          if (!this.documentDialog) {
            this.documentDialog = await this.loadFragment({
              name: "com.melody.activity.fragments.form.EditAssetDocsDialog",
            });
          }
          const path = activityFormModel.getProperty('/formPath');
          let files = activityStateModel.getProperty(path + "/files/results") || [];

          files = files.map(file => { return { ...file, isDelBtnVisible: true, isAddBtnVisible: false } });
          files.unshift({
            url: "",
            id: "",
            name: "",
            isAddBtnVisible: true,
            isDelBtnVisible: false,
          })
          activityFormModel.setProperty("/files", files);
          this.documentDialog.open();

        },

        // function to close edit asessts and documents dialog
        onCloseEditAssestDocsPopover: function () {
          this.documentDialog.close()

        },
        //Function to validate if user's input is a valid URL
        onValidateAssetDocLink: function (event) {
          const value = event.getSource().getValue();
          const path = event.getSource().getBindingContext('activityFormModel').getPath()
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          if (value) {
            let regexQuery =
              /^((([A-Za-z]{3,9}:(?:\/\/)?)(?:[\-;:&=\+\$,\w]+@)?[A-Za-z0-9\.\-]+|(?:www\.|[\-;:&=\+\$,\w]+@)[A-Za-z0-9\.\-]+)((?:\/[\+~%\/\.\w\-_]*)?\??(?:[\-\+=&;%@\.\w_]*)#?(?:[\.\!\/\\\w]*))?)/g;
            if (!regexQuery.test(value)) {
              activityFormModel.setProperty(path + "/state", "Error");
            } else {
              activityFormModel.setProperty(path + "/state", "None");
            }
          } else {
            activityFormModel.setProperty(path + "/state", "None");
          }
        },

        //Function to validate and Add Filename and URL in Assest/Docs link popover
        addNewAssetDocLink: function (event, data) {
          if (event) {
            var source = event.getSource();
            data = source.getBindingContext("activityFormModel").getObject();
          }
          if (data.name && data.url && data.state !== "Error") {
            let file = {
              url: "",
              id: "",
              name: "",
              isAddBtnVisible: true,
              isDelBtnVisible: false,
            };
            data.isAddBtnVisible = false;
            data.isDelBtnVisible = true;
            const activityFormModel =
              this.getOwnerComponent().getModel("activityFormModel");
            let files = activityFormModel.getProperty("/files");
            files.push(file);
            activityFormModel.setProperty("/files", files);
          } else if (!data.name && data.url) {
            sap.m.MessageToast.show("Please enter Display name");
          } else if (
            data.name &&
            (!data.url || data.state === "Error")
          ) {
            sap.m.MessageToast.show("Please enter valid URL");
          } else {
            sap.m.MessageToast.show("Please enter Display name and URL");
          }
        },

        //Function to Delete Filename and URL in Assest/Docs link popover
        deleteNewAssetDocLink: function (event) {
          const source = event.getSource();
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          let files = activityFormModel.getProperty("/files");
          const path = source.getBindingContext("activityFormModel").getPath();
          const index = parseInt(path.split("/")[2], 10);
          files.splice(index, 1);
          activityFormModel.setProperty("/files", files);
        },

        //function to add docs to form on click of Ok in AssestDocs dialog
        onUpdateAssetsDocs: function () {
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          const formPath = activityFormModel.getProperty("/formPath");
          let files = activityFormModel.getProperty("/files");
          if (files?.length && files[0].name && files[0].url) {
            if (files[0].state !== 'Error') {
              files = files.map(({ id, url, name }) => { return { id, url, name } })
              activityStateModel.setProperty(formPath + "/files/results", files);
              this.onCloseEditAssestDocsPopover();
            } else {
              sap.m.MessageToast.show("Please fill in missing/valid entries");
            }
          }
          else {
            files.splice(0, 1);
            activityStateModel.setProperty(formPath + "/files/results", files);
            this.onCloseEditAssestDocsPopover()
          };
        },

        //------------------- Demo Environments Start ------------------



        // functin to open SapDemoEduCloud Dialog in Demo Env Section
        openLandScapes: async function (type) {
          if (!this.landscapesDialog) {
            this.landscapesDialog = await this.loadFragment({
              name: "com.melody.activity.fragments.demoEnv.Landscapes",
            });
          }
          this.landscapesDialog.open();
          const activityMasterState = this.getOwnerComponent().getModel("activityMasterState");
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          const formPath = activityFormModel.getProperty("/formPath");
          let landscapes, isLandscape = true, landscapeMap = {}, selectedLandscapes = activityStateModel.getProperty(formPath + "/landscapes/results");
          if (type === "demoEducations") {
            landscapes = structuredClone(activityMasterState.getProperty('/demoEducations'));
            isLandscape = false;
            selectedLandscapes.forEach(landscape => {
              if (landscape.type === "0") landscapeMap[landscape['id']] = landscape
            });
          }
          else if (type === "landscapes") {
            landscapes = structuredClone(activityMasterState.getProperty('/landscapes'));
            selectedLandscapes.forEach(landscape => {
              if (landscape.type !== "0") landscapeMap[landscape['id']] = landscape
            });
          }
          landscapes.list.forEach(each => {
            if (landscapeMap[each['id']] && each.category !== "Recent Selection") each.selected = true
          })
          activityFormModel.setProperty('/landscapes', landscapes.tree)
          activityFormModel.setProperty("/isLandscape", isLandscape);
          activityFormModel.setProperty("/landscapeExpanded", true);

        },

        // function to set selected Demo & Education Cloud on click of Ok button in SapDemoEduCloud dialog
        onAddLandscape: function () {
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          let tree = activityFormModel.getProperty('/landscapes')
          let landscapes = this.convertTreeToList(tree);
          landscapes = landscapes.filter(each => each.selected)
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          const formPath = activityFormModel.getProperty("/formPath");
          let existingLandscapes = activityStateModel.getProperty(
            formPath + "/landscapes/results");
          if (landscapes?.length) {
            if (landscapes[0].type === "0")
              existingLandscapes = existingLandscapes.filter(landscape => landscape.type !== "0");
            else if (landscapes[0].type !== "0")
              existingLandscapes = existingLandscapes.filter(landscape => landscape.type === '0');

          }
          landscapes = existingLandscapes.concat(landscapes);
          activityStateModel.setProperty(
            formPath + "/landscapes", {
            results: landscapes
          }
          );
          this.onCloseLandscapes();
        },

        // function to delete landscape 
        onDeleteLandscape: function (event) {
          let indexToDelete = event.getSource().getBindingContext('activityState').getPath().split('/').pop();
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          const formPath = activityFormModel.getProperty("/formPath");
          let landscapes = activityStateModel.getProperty(
            formPath + "/landscapes/results");
          landscapes.splice(indexToDelete, 1);
          activityStateModel.setProperty(
            formPath + "/landscapes", {
            results: landscapes
          })

        },

        // function to close SapDemoEduCloud dialog
        onCloseLandscapes: function () {
          this.landscapesDialog.close();
        },


        // function to show Grouping options on click of group icon in SapDemoEduCloud dialog
        openDemoEnvSortOptions: async function (event) {
          if (!this.SortOptionsPopover) {
            this.SortOptionsPopover = await this.loadFragment({
              name: "com.melody.activity.fragments.demoEnv.DemoEnvSortOptions",
            });
          }
          this.SortOptionsPopover.openBy(event.getSource());

        },

        getDataCenterGroupHeader: function (group) {
          return new sap.m.GroupHeaderListItem({
            title: group.key,
            upperCase: false,
          });
        },

        // function to show all Data Centers on click of add in success factor
        openSuccessFactors: async function () {
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          if (!this.successFactorDialog) {
            this.successFactorDialog = await this.loadFragment({
              name: "com.melody.activity.fragments.demoEnv.SuccessFactor",
            });
          }
          activityFormModel.setProperty("/successFactor", {
            dataCenter: {
              id: null,
              description: null
            },
            company: null,
            userName: null,
            password: null

          })

          this.successFactorDialog.open();

        },

        onAddSuccessFactor: function () {
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          const formPath = activityFormModel.getProperty("/formPath");
          const successFactors = activityStateModel.getProperty(
            formPath + "/successFactors/results"
          );
          const successFactor = activityFormModel.getProperty("/successFactor")
          if (successFactor.company && successFactor.userName && successFactor.dataCenter?.id && successFactor.password) {
            successFactors.push(successFactor);
            activityStateModel.setProperty(
              formPath + "/successFactors/results",
              successFactors
            );
            this.successFactorDialog.close();
          } else sap.m.MessageToast.show("Please fill all the fields");
        },

        onCloseSuccessFactors: function () {
          this.successFactorDialog.close();
        },

        onDeleteSuccessFactor: function (event) {
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          const formPath = activityFormModel.getProperty("/formPath");
          let successFactors = activityStateModel.getProperty(
            formPath + "/successFactors/results"
          );
          const indexToDelete = event
            .getSource()
            .getBindingContext("activityState")
            .getPath()
            .split("/")
            .pop();
          successFactors.splice(indexToDelete, 1);
          activityStateModel.setProperty(
            formPath + "/successFactors/results",
            successFactors
          );
        },
        onEditSuccessFactor: async function (event) {
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const activityStateModel =
            this.getOwnerComponent().getModel("activityState");
          const rowPath = event
            .getSource()
            .getBindingContext("activityState")
            .getPath();
          const successFactor = activityStateModel.getProperty(rowPath);
          activityFormModel.setProperty('/successFactor', successFactor)
          if (!this.successFactorDialog) {
            this.successFactorDialog = await this.loadFragment({
              name: "com.melody.activity.fragments.demoEnv.SuccessFactor",
            });
          }
          this.successFactorDialog.open();
        },
        onChangeDateCenter: function (event) {
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const dataCenter = event.getSource().getSelectedItem().getBindingContext("activityMasterState").getObject()
          activityFormModel.setProperty('/successFactor/dataCenter', dataCenter);
        },

        // function to open ClodEnvironments Dialog to add cloud environments
        onOpenCloudEnv: async function () {
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          if (!this.cloudEnvDialog) {
            this.cloudEnvDialog = await this.loadFragment({
              name: "com.melody.activity.fragments.demoEnv.CloudEnvironments",
            });
          }
          activityFormModel.setProperty("/cloudEnv", {
            instance: null,
            description: null
          });

          activityFormModel.setProperty("/demoCloudEditPath", null);
          this.cloudEnvDialog.open()

        },

        onAddCloudEnv: function () {
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const activityStateModel =
            this.getOwnerComponent().getModel("activityState");
          let cloudEnv = activityFormModel.getProperty('/cloudEnv')
          if (cloudEnv.instance && cloudEnv.description) {
            const formPath = activityFormModel.getProperty("/formPath");
            let cloudEnvironments = activityStateModel.getProperty(
              formPath + "/cloudEnvironments/results"
            );


            const demoCloudEditPath =
              activityFormModel.getProperty("/demoCloudEditPath");
            if (activityFormModel.getProperty("/demoCloudEditPath")) {
              activityStateModel.setProperty(
                demoCloudEditPath,
                cloudEnv
              );

            } else {
              cloudEnvironments.push(cloudEnv);
              activityStateModel.setProperty(
                formPath + "/cloudEnvironments/results",
                cloudEnvironments
              );
            }
            this.onCloseCloudEnv();
          }
          else sap.m.MessageToast.show("Please fill all the fields");
        },
        onCloseCloudEnv: function () {
          this.cloudEnvDialog.close();
        },
        onEditCloudEnv: async function (event) {
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const activityStateModel =
            this.getOwnerComponent().getModel("activityState");
          const rowPath = event
            .getSource()
            .getBindingContext("activityState")
            .getPath();
          const cloudEnv = activityStateModel.getProperty(rowPath);
          activityFormModel.setProperty(
            "/cloudEnv",
            cloudEnv
          );
          activityFormModel.setProperty("/demoCloudEditPath", rowPath);
          if (!this.cloudEnvDialog) {
            this.cloudEnvDialog = await this.loadFragment({
              name: "com.melody.activity.fragments.demoEnv.CloudEnvironments",
            });
          }
          this.cloudEnvDialog.open();
        },
        onDeleteCloudEnv: function (event) {
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const activityStateModel =
            this.getOwnerComponent().getModel("activityState");
          const formPath = activityFormModel.getProperty("/formPath");
          let cloudEnv = activityStateModel.getProperty(
            formPath + "/cloudEnvironments/results"
          );
          const indexToDelete = event
            .getSource()
            .getBindingContext("activityState")
            .getPath()
            .split("/")
            .pop();
          cloudEnv.splice(indexToDelete, 1);
          activityStateModel.setProperty(formPath + "/cloudEnvironments/results", cloudEnv);
        },

        // ----------Demo Environments End -------------

        // function to handle selection of Account in Activity Form
        fnHandleAccountSelection: function (event) {
          const selectedAccount = event.getParameter("selectedAccount");
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const formPath = activityFormModel.getProperty("/formPath");
          // activityFormModel.setProperty(formPath + "/account", selectedAccount);
          // activityFormModel.setProperty(formPath + "/opportunity", {});
        },

        // function to handle selection of Opportunity in Activity Form
        fnHandleOppoSelection: async function (event) {
          const selectedOppo = event.getParameter("selectedOpportunity");
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const activityStateModel =
            this.getOwnerComponent().getModel("activityState");
          const path = activityFormModel.getProperty("/formPath");
          activityStateModel.setProperty(
            path + "/opportunity", selectedOppo)



        },

        // function to navigate to harmony on click of account hyperlink - NOT USED
        navToCRMwithCVJAccnt: function () {
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const formPath = activityFormModel.getProperty("/formPath");
          var account = activityFormModel.getProperty(formPath + "/account");
          account &&
            window.open(
              account.harmonyLink + account.id + "/plan",
              "_blank"
            );
        },

        // function to navigate to harmony on click of opportunity hyperlink - NOT USED
        navCVJOppoToCRM: function () {
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const formPath = activityFormModel.getProperty("/formPath");
          const opportunity = activityFormModel.getProperty(
            formPath + "/opportunity"
          );
          if (opportunity) {
            window.open(
              opportunity.harmonyLink + opportunity.id + "/plan",
              "_blank"
            );
          }
        },

        //Function to open Estimated Time info popover
        openEstimateTimeInfoPopover: async function (event) {
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          let headerText = "",
            contentTxt = "";
          const source = event.getSource();
          var selectedIcon = source.getCustomData()[0].getKey();
          switch (selectedIcon) {
            case "NCFEstimatedTime":
              headerText = this.getResourceBundle().getText("NCF") + " (NCF)";
              contentTxt = this.getResourceBundle().getText(
                "EstimatedTimeInfoLine1",
                ["Non", "prep", "NCF"]
              );
              break;
            case "CFEstimatedTime":
              headerText = this.getResourceBundle().getText("CF") + " (CF)";
              contentTxt = this.getResourceBundle().getText(
                "EstimatedTimeInfoLine1",
                ["", "customer facing", "CF"]
              );
              break;
          }
          activityFormModel.setProperty("/estimatedInfoHeader", headerText);
          activityFormModel.setProperty("/estimatedInfoContent", contentTxt);
          if (!this.EstimateTimeInfoPopover) {
            this.EstimateTimeInfoPopover = await this.loadFragment({
              name: "com.melody.activity.fragments.form.EstimatedTimeInfoPopOver",
            });
          }
          this.EstimateTimeInfoPopover.openBy(event.getSource())

        },


        // fuction to show activity type information on click of activity type info icon
        openActivityTypeInfo: async function (event) {
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const activityStateModel =
            this.getOwnerComponent().getModel("activityState");
          const path = activityFormModel.getProperty("/formPath");
          const activityTypeInfo = activityStateModel.getProperty(
            path + "/type/info"
          );
          activityFormModel.setProperty("/typeInfo", activityTypeInfo);
          if (!this.ActivityTypeInfoPopup) {
            this.ActivityTypeInfoPopup = await this.loadFragment({
              name: "com.melody.activity.fragments.form.ActivityTypeInfo",
            });
          }
          this.ActivityTypeInfoPopup.openBy(event.getSource())

        },
        onChangeRisk: function (event) {
          const source = event.getSource();
          const isPressed = source.getPressed();
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const activityStateModel =
            this.getOwnerComponent().getModel("activityState");
          const path = activityFormModel.getProperty("/formPath");
          if (isPressed) {
            const selectedKey = source.getCustomData()[0].getKey();
            activityStateModel.setProperty(path + "/risk/id", selectedKey);
          }
          else activityStateModel.setProperty(path + "/risk/id", '');
          activityStateModel.refresh(true)
        },
        handleTypeSelection: function (event) {
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const activityStateModel =
            this.getOwnerComponent().getModel("activityState");
          const formPath = activityFormModel.getProperty("/formPath");
          let selectedItems = event.getParameter("selectedItems");
          selectedItems = selectedItems.map(each => {
            return {
              id: each.getKey(),
              description: each.getText()
            }
          })
          activityStateModel.setProperty(formPath + "/detailTypes", selectedItems);
          this.setValueState("detailTypes")

        },
        onChangeGrouping: function (event) {
          let groupBy = event.getParameters().item.getCustomData()[0].getKey();
          const activityMasterStateModel =
            this.getOwnerComponent().getModel("activityMasterState");
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const isLandscape = activityFormModel.getProperty("/isLandscape");
          let data = isLandscape ? activityMasterStateModel.getProperty('/landscapes') : activityMasterStateModel.getProperty('/demoEducations')
          const activityMasterState = ActivityMasterState.getInstance();
          let tree = activityMasterState.convertArrayToTree(data.list, groupBy);
          activityFormModel.setProperty("/landscapes", tree);

        },
        onExpandLandscapes: function () {
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const landscapeExpanded = activityFormModel.getProperty("/landscapeExpanded");
          const treeTable = this.getView().byId("idSapDemoEcTable");
          if (landscapeExpanded) {
            treeTable.collapseAll();
            activityFormModel.setProperty("/landscapeExpanded", false);
          }
          else {
            treeTable.expandToLevel(1);
            activityFormModel.setProperty("/landscapeExpanded", true);
          }
        },
        convertTreeToList: function (tree) {
          var list = [];
          tree.forEach(function (object) {
            var data = object['data'];
            list = list.concat(data);
          });
          return list;
        },
        //-------------------------SOLUTION HIERARCHY START ---------------------------//
        // opens solution hierarchy dialog on click of solutions multiinput in form . fetches and sets the hierarchy data to tree table
        openSolutionHierarchy: async function () {
          if (!this.solutionHierarchyDialog) {
            this.solutionHierarchyDialog = await this.loadFragment({
              name: "com.melody.activity.fragments.form.SolutionHierarchy",
            });

          }
          const activityMasterStateModel = this.getOwnerComponent().getModel("activityMasterState");
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
          activityFormModel.setProperty('/selectedSolTab', "SOLUTION_HIERARCHY");
          const formPath = activityFormModel.getProperty('/formPath');
          const solHierarchyMap = activityStateModel.getProperty(formPath + "/solHierarchyMap");
          const solHierarchyMasterData = activityMasterStateModel.getProperty("/solHierarchy");
          const level2Data = activityMasterStateModel.getProperty("/level2Data");
          let selectedLevel = activityStateModel.getProperty(formPath + '/solLevel');
          if (!selectedLevel.id) selectedLevel = level2Data[0];
          activityFormModel.setProperty('/level2Guid', selectedLevel.guid);
          let solHierarchy = [];
          if (solHierarchyMap.get(selectedLevel.guid)?.levels?.length && solHierarchyMap.get(selectedLevel.guid).levels[0]?.id) {
            solHierarchy = solHierarchyMap.get(selectedLevel.guid)?.levels;
            solHierarchy.forEach(each => {
              each['isParent'] = true
            })
          }
          else {
            solHierarchy = solHierarchyMasterData[selectedLevel.guid]
            solHierarchy.forEach(each => {
              each['isParent'] = true
              solHierarchyMap.set(each.guid, each);
            })
            solHierarchyMap.get(selectedLevel.guid).levels = solHierarchy;
          }
          activityFormModel.setProperty('/solHierarchy', $.extend(true, [], solHierarchy));
          activityFormModel.setProperty("/showDisplayMaterials", false)
          activityFormModel.setProperty("/displayTokens", []);

          activityFormModel.setProperty('/solHierarchyMap', structuredClone(solHierarchyMap))
          let activity = activityStateModel.getProperty(formPath);
          if (activity.association.id === '502') {
            activityFormModel.setProperty('/showOppoTab', true);
          }
          else activityFormModel.setProperty('/showOppoTab', false)
          let solutions = activityStateModel.getProperty(formPath + "/solutions/results")
          activityFormModel.setProperty("/displayTokens", structuredClone(solutions));
          const materials = activityStateModel.getProperty(formPath + '/materials');
          // activityFormModel.setProperty('/materials', $.extend(true, [], materials))
          let materialsMap = new Map();
          // materials.forEach(material => { materialsMap.set(material.guid, material) })
          activityFormModel.setProperty('/materialsMap', materialsMap);

          this.getMaterials(solHierarchy[0]?.guid);
          this.solutionHierarchyDialog.open()
        },


        // gets triggered on click of OK in registration dialog. NOT USED
        // fetches opportunity materials and its corresponding solution hierarchy 
        getOppoSolHierarchy: async function (opportunityId) {
          const opportunityState = OpportunityState.getInstance();
          const activityState = ActivityState.getInstance();
          const activityMasterState = ActivityMasterState.getInstance();
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel")
          let formPath = activityFormModel.getProperty('/formPath');
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          let { data } = await opportunityState.getOpportunitiesTeam(opportunityId);
          let oppoMaterialsMap = {};
          let oppoMaterials = data.Items.results?.map(each => {
            each = { id: each.PRODUCT_ID, name: each.PRODUCT_DESCR }
            // each.selected = true;
            oppoMaterialsMap[each.id] = each
            return each;
          })
          activityStateModel.setProperty(formPath + '/oppoMaterials', oppoMaterialsMap);
          let hierarchyList = await activityState.getHierarchyByMaterials(oppoMaterials);
          let selectedSolsMap = activityStateModel.getProperty(formPath + "/solHierarchyMap"), displayTokens = [];
          let materialPromises = [];
          for (let i = 0; i < hierarchyList.length; i++) {
            hierarchyList[i].selected = true;
            selectedSolsMap.set(hierarchyList[i].guid, hierarchyList[i]);
            if (hierarchyList[i].isFinal) {
              displayTokens.push(hierarchyList[i]);
              materialPromises.push(activityState.getMaterialsById(hierarchyList[i].guid))
            };
          }
          Promise.allSettled(materialPromises).then((responses) => {
            let materials = [];
            responses.forEach(each => materials = materials.concat(each.value));
            materials.forEach(each => {
              each.isMaterial = true;
              if (oppoMaterialsMap[each.id]) {
                each.isOpportunity = true;
                // each.selected = true;
              }
            })
            activityStateModel.setProperty(formPath + '/materials', materials);
            // activityFormModel.setProperty('/materials', $.extend(true, [], materials))

          })
          activityStateModel.setProperty(formPath + '/solutions/results', displayTokens)

          // fetch all children and updating selected propety 
          // Also create opportunity sol hierachy tree
          let oppoSolHierarchy = [], promises = []
          for (let i = 0; i < hierarchyList.length; i++) {
            let node = selectedSolsMap.get(hierarchyList[i].guid);
            if (!node.isFinal) {
              promises.push(activityMasterState.getSolHierarchyById(node.guid))
            }
            const parent = selectedSolsMap.get(node.parentGuid);
            if (parent) {
              parent.levels.push(node);
            } else {
              oppoSolHierarchy.push(node);
            }
          }
          activityStateModel.setProperty(formPath + "/oppSolHierarchy", $.extend(true, [], oppoSolHierarchy));

          let that = this;
          Promise.allSettled(promises)
            .then((responses) => {
              responses.forEach(each => {
                let levels = each.value
                // for (let j = 0; j < levels.length; j++) {
                //   selectedSolsMap.set(levels[j].guid, levels[j])
                //   if (selectedSolsMap.get(levels[j].guid)) {
                //     // levels[j].selected = true;
                //     levels[j] = selectedSolsMap.get(levels[j].guid)
                //   }
                // }
                // selectedSolsMap.get(levels[0].parentGuid).levels = levels;
                levels = levels.map(each => {
                  if (selectedSolsMap.get(each.guid)) {
                    // levels[j].selected = true;
                    each = selectedSolsMap.get(each.guid)
                  }
                  selectedSolsMap.set(each.guid, each)
                  return selectedSolsMap.get(each.guid)
                })
                selectedSolsMap.get(levels[0].parentGuid).levels = levels;
              })

              // setting partial selections
              displayTokens.forEach(each => {
                // that.updatePartialSelections(selectedSolsMap, each)
                that.updateParentSelections(selectedSolsMap, each)

              })
              activityStateModel.setProperty(formPath + '/solHierarchyMap', selectedSolsMap)

            })
            .catch(function (error) {

            });









          // let displayTokens = [];
          // hierarchy.forEach(each => {
          //   displayTokens.push({
          //     id: each.id.split(">").pop(),
          //     name: each.name.split(">").pop(),
          //     guid: each.guid
          //   })
          // })
          // let formPath = activityFormModel.getProperty('/formPath');
          // activityStateModel.setProperty(formPath + '/solutions/results', displayTokens)

          // let level2Data = activityMasterStateModel.getProperty("/level2Data");
          // let tree = [];
          // for (let i = 0; i < hierarchy.length; i++) {
          //   let ids = hierarchy[i].id.split('>');
          //   let firstNode = level2Data.find(each => each.id === ids[0]);
          //   firstNode.selected = true;
          //   await this.getAllChildren(firstNode, ids, 0)
          //   tree = firstNode.levels;
          // }


        },

        // closed solution hierarchy dialog
        closeSolutionHierarchy: function () {
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel")
          activityFormModel.setProperty("/displayTokens", [])
          const solutionTree = this.byId("idSolutionTree");
          solutionTree.removeSelections();
          solutionTree.collapseAll();
          this.solutionHierarchyDialog.close()
        },

        // fetches child solutions on click of expand in sol hierarchy dialog
        onExpandHierarchy: async function (event) {
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          let selectedSolTab = this.byId("ITB_SOL_HIERARCHY").getSelectedKey();
          let formPath = activityFormModel.getProperty('/formPath')
          if (selectedSolTab === 'SOLUTION_HIERARCHY') {
            const row = event.getParameter("itemContext").getObject()
            const solHierarchyMap = activityFormModel.getProperty('/solHierarchyMap');
            let levels = [];
            if (solHierarchyMap.get(row.guid)?.levels?.length && solHierarchyMap.get(row.guid).levels[0].id) {
              levels = solHierarchyMap.get(row.guid).levels
            }
            else {
              const activityMasterState = ActivityMasterState.getInstance();
              levels = await activityMasterState.getSolHierarchyById(row.guid);
              levels = structuredClone(levels);
              levels.forEach(each => {
                solHierarchyMap.set(each.guid, each);
              })
              solHierarchyMap.get(levels[0].parentGuid).levels = levels;
              activityFormModel.setProperty('/solHierarchyMap', solHierarchyMap)
            }
            let path = event.getParameter("itemContext").getPath();
            activityFormModel.setProperty(path + "/levels", levels)

          }

        },

        // controls visibility of materials table in sol hierarchy table on selection change of display materials checkbox 
        onChangeDisplayMat: function (event) {
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
          const selected = event.getSource().getSelected()
          activityFormModel.setProperty("/showDisplayMaterials", selected);
          let selectedSolTab = this.byId("ITB_SOL_HIERARCHY").getSelectedKey();
          let filters;
          if (selectedSolTab === "SOLUTION_HIERARCHY") {

            filters = [];

          }
          else if (selectedSolTab === "FROM_OPPORTUNITY") {
            filters = [new Filter("isOpportunity", "EQ", true)];
          }
          this.byId("idMaterailMTbl").getBinding("items").filter(filters);
        },


        // fetches hierarchy data on dropdown selection change of sol hierarchy
        getSolutionHierarchy: async function (event) {
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
          const formPath = activityFormModel.getProperty('/formPath');
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          let solHierarchyMap = activityFormModel.getProperty("/solHierarchyMap");
          const guid = event.getSource().getSelectedKey();
          let solHierarchy = [];
          if (!solHierarchyMap.get(guid)?.levels?.length) {
            const activityMasterState = ActivityMasterState.getInstance();
            solHierarchy = await activityMasterState.getSolHierarchyById(guid);
            solHierarchy = structuredClone(solHierarchy)
            solHierarchy.forEach(each => {
              solHierarchyMap.set(each.guid, each);
            })
            solHierarchyMap.get(solHierarchy[0].parentGuid).levels = solHierarchy;
          }
          else {
            solHierarchy = solHierarchyMap.get(guid).levels;
          }
          solHierarchy.forEach(each => each['isParent'] = true)
          activityFormModel.setProperty('/solHierarchy', $.extend(true, [], solHierarchy))
          this.getMaterials(solHierarchy[0]?.guid);
          const solutionTree = this.byId("idSolutionTree")
          solutionTree.removeSelections();
          solutionTree.collapseAll();
        },

        // updates selections from current node to last node in sol hierarchy on selection change of a solution
        updateChildrenSelections: function (selectedNode, isSelected, solHierarchyMap, materials, displayTokens) {
          if (materials && !selectedNode.selected) {
            for (let i = materials.length - 1; i >= 0; i--) {
              if (materials[i].triggeredBy === selectedNode.guid) materials.splice(i, 1);
            }
          }
          if (selectedNode.levels?.length && selectedNode.levels[0].id) {
            for (let i = 0; i < selectedNode.levels.length; i++) {
              for (let j = displayTokens.length - 1; j >= 0; j--) {
                if (displayTokens[j].guid === selectedNode.levels[i].guid && !isSelected) displayTokens.splice(j, 1)
              }
              selectedNode.levels[i].selected = isSelected;
              solHierarchyMap.get(selectedNode.levels[i].guid).selected = isSelected
              this.updateChildrenSelections(selectedNode.levels[i], isSelected, solHierarchyMap, materials, displayTokens);
            }
          }
          else return;
        },

        // updates hierachy selections from currentNode to parentNode NOT USED
        updateParentSelections: function (solHierarchyMap, selectedNode, displayTokens) {
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
          if (selectedNode.isParent && displayTokens) {
            activityFormModel.setProperty("/displayTokens", displayTokens);
            return;
          }

          let parentNode = solHierarchyMap.get(selectedNode.parentGuid);
          if (!parentNode) return;
          let partiallySelected = false;
          if (selectedNode.partiallySelected) {
            parentNode.partiallySelected = true;
            parentNode.selected = true
          }
          else {
            partiallySelected = parentNode.levels.find(each => {
              if (selectedNode.selected) return !each.selected
              else return each.selected
            });
            parentNode.partiallySelected = partiallySelected ? true : false;
            parentNode.selected = parentNode.partiallySelected ? true : selectedNode.selected
          }
          if (displayTokens) displayTokens = displayTokens.filter(each => parentNode.guid !== each.guid)
          this.updateParentSelections(solHierarchyMap, parentNode, displayTokens)
        },


        // gets triggered on selection of solution in sol hierarchy dialog . updates selections
        onSelectSolution: async function (event, selectedRow) {
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
          let isSelected = selectedRow ? false : event.getSource().getSelected();
          if (!selectedRow) selectedRow = event.getSource().getBindingContext('activityFormModel').getObject();
          let solHierarchy = activityFormModel.getProperty("/solHierarchy");
          const solHierarchyMap = activityFormModel.getProperty('/solHierarchyMap');
          var materials = activityFormModel.getProperty("/materials")
          var materialsMap = activityFormModel.getProperty("/materialsMap")

          var displayTokens = activityFormModel.getProperty("/displayTokens");
          if (!displayTokens) displayTokens = []
          if (!isSelected) this.updateChildrenSelections(selectedRow, isSelected, solHierarchyMap, materials, displayTokens)  // updating children selections
          // updating parent partial selection and selection based on siblings selections

          if (isSelected) displayTokens.push(selectedRow)
          else {
            displayTokens = displayTokens.filter(each => each.guid !== selectedRow.guid && selectedRow.guid !== each.parentGuid);
          }

          const activityState = ActivityState.getInstance();
          let data = activityState.updateParentSelections(solHierarchyMap, selectedRow, displayTokens, materials);

          activityFormModel.setProperty("/displayTokens", data.displayTokens);
          activityFormModel.setProperty("/solHierarchy", solHierarchy);
          activityFormModel.setProperty("/solHierarchyMap", solHierarchyMap);


          // // set materials 
          // if (selectedRow.selected) {
          //   this.getMaterials(selectedRow.guid)
          // }
          // else {
          //   // materials = materials.filter(each => each.guid !== selectedRow.triggeredBy);
          //   activityFormModel.setProperty("/materials", data.materials);
          //   let materialsMap = new Map();
          //   data.materials?.forEach(material => { materialsMap.set(material.guid, material) })
          //   activityFormModel.setProperty('/materialsMap', materialsMap)
          // }


          this.getMaterials(selectedRow.guid)

        },

        // gets triggered on selection of any solution in sol hierarchy dialog to fetch materials
        getMaterials: async function (guid) {
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
          const formPath = activityFormModel.getProperty('/formPath')
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          const oppoMaterialsMap = activityStateModel.getProperty(formPath + '/oppoMaterials');
          const displayTokens = activityFormModel.getProperty("/displayTokens");
          let selectedMaterials = {};
          displayTokens.forEach(token => { if (token.isMaterial) selectedMaterials[token.id] = token });
          const activityState = ActivityState.getInstance();
          // let materials = activityFormModel.getProperty("/materials")
          let materialsMap = activityFormModel.getProperty("/materialsMap");
          const solHierarchyMap = activityFormModel.getProperty('/solHierarchyMap');
          const selectedRow = solHierarchyMap.get(guid)
          // if (!materials) materials = [];
          let materials = [], fetchMaterials = [];
          let parentNode = solHierarchyMap.get(selectedRow.parentGuid)
          this.setMaterialsData(parentNode, materials, fetchMaterials)
          // if (materialsMap.get(parentNode.guid)) {
          //   // materials = materialsMap.get(selectedRow.parentGuid);
          //   // now filter the selected children
          //   this.setMaterialsData(parentNode, materials);


          // }
          // else if (materialsMap.get(guid)) materials = materialsMap.get(guid);
          // else {
          //   let data = await activityState.getMaterialsById(guid);
          //   data.forEach(each => {
          //     each.isMaterial = true;
          //     if (oppoMaterialsMap[each.id]) {
          //       data.isOpportunity = true;
          //     }
          //     materials.push(each);

          //   })
          //   materialsMap.set(guid, materials);

          // }
          if (fetchMaterials.length) {
            activityFormModel.setProperty('/materialsBusy', true)
            Promise.all(fetchMaterials).then(responses => {
              responses.forEach(each => {
                each.forEach(mat => {
                  mat.isMaterial = true;
                  mat.selected = false;
                  if (oppoMaterialsMap && oppoMaterialsMap[mat.id]) {
                    mat.isOpportunity = true;
                  } if (selectedMaterials[mat.id]) mat.selected = true;
                })
                materialsMap.set(each[0].triggeredBy, each);
                materials = materials.concat(each);
                activityFormModel.setProperty('/materialsBusy', false)

              })
              // set the data to map and push to materials
              activityFormModel.setProperty("/materials", materials)
              activityFormModel.setProperty("/materialsMap", materialsMap)
            })
          }
          activityFormModel.setProperty("/materials", materials)
          activityFormModel.setProperty("/materialsMap", materialsMap)


        },

        setMaterialsData: function (node, materials, fetchMaterials) {
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
          const activityState = ActivityState.getInstance();
          let materialsMap = activityFormModel.getProperty("/materialsMap");
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          const formPath = activityFormModel.getProperty('/formPath')
          const oppoMaterialsMap = activityStateModel.getProperty(formPath + '/oppoMaterials');
          let displayTokens = activityFormModel.getProperty("/displayTokens");
          let selectedTokens = {};
          displayTokens.forEach(token => selectedTokens[token.id] = token);

          // if parent materials are already fetched && is fully Selected
          if (materialsMap.get(node.guid) && node.selected && !node.partiallySelected) {
            materialsMap.get(node.guid).forEach(each => materials.push(each))
          }
          else {
            node.levels.forEach(each => {
              if (each.selected && !each.partiallySelected) {
                // materialsMap.get(node.guid).forEach(mat => {
                //   if (mat.guid === each.guid) materials.push(mat)
                // })
                if (materialsMap.get(each.guid)) {
                  materialsMap.get(each.guid).forEach(each => {
                    each.selected = false;
                    if (selectedTokens[each.id]) each.selected = true;
                    materials.push(each)
                  })
                }
                else {
                  fetchMaterials.push(activityState.getMaterialsById(each.guid))
                  // let data = await activityState.getMaterialsById(guid);
                  // data.forEach(each => {
                  //   each.isMaterial = true;
                  //   if (oppoMaterialsMap[each.id]) {
                  //     data.isOpportunity = true;
                  //   }
                  //   materials.push(each);

                  // })
                  // materialsMap.set(guid, materials);
                  // activityFormModel.setProperty('/materialsMap', materialsMap)
                }
              }
              else if (each.selected && each.partiallySelected) {
                this.setMaterialsData(each, materials, fetchMaterials)
              }
              else {
                // remove if there is any mat mapped to this guid selected
                for (let i = displayTokens.length - 1; i >= 0; i--) {
                  if (displayTokens[i].isMaterial && (displayTokens[i].guid === each.guid || displayTokens[i].triggeredBy === each.guid)) {
                    displayTokens.splice(i, 1);
                  }
                }
                // displayTokens = displayTokens.filter(token => !token.isMaterial || (token.isMaterial && each.guid !== token.guid && each.triggeredBy !== token.guid))
                activityFormModel.setProperty('/displayTokens', displayTokens)
              }
            })
          }
        },
        getMaterials1: async function (guid) {
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
          const formPath = activityFormModel.getProperty('/formPath')
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          const oppoMaterialsMap = activityStateModel.setProperty(formPath + '/oppoMaterials');
          const activityState = ActivityState.getInstance();
          let materials = activityFormModel.getProperty("/materials")
          let materialsMap = activityFormModel.getProperty("/materialsMap")
          if (!materials) materials = [];
          let data = await activityState.getMaterialsById(guid);
          data.forEach(each => {
            if (!materialsMap.get(each.id)) {
              each.isMaterial = true;
              if (oppoMaterialsMap[each.id]) {
                data.isOpportunity = true;
              }
              materials.push(each);
              materialsMap.set(each.id, each);
            }

          })
          // materials = materials.concat(data);
          activityFormModel.setProperty("/materials", materials)

        },

        // gets triggered on selection of checkbox of material table in solution hierarchy dialog 
        onSelectMaterial: function (event) {
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
          let displayTokens = activityFormModel.getProperty("/displayTokens");
          const isSelected = event.getSource().getSelected();
          const selectedRow = event.getSource().getBindingContext('activityFormModel').getObject();
          if (isSelected)
            displayTokens.push(selectedRow);
          else
            displayTokens = displayTokens.filter(each => each.id !== selectedRow.id)
          activityFormModel.setProperty("/displayTokens", displayTokens)

        },

        // gets triggered on click of OK in solution hierarchy dialog
        setSelectedSolutions: function () {
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
          const activityStateModel =
            this.getOwnerComponent().getModel("activityState");
          const displayTokens = activityFormModel.getProperty("/displayTokens");
          const level2Guid = activityFormModel.getProperty('/level2Guid')
          const path = activityFormModel.getProperty('/formPath');
          activityStateModel.setProperty(path + "/solutions/results", displayTokens);
          const solHierarchyMap = activityFormModel.getProperty("/solHierarchyMap");
          activityStateModel.setProperty(path + "/solHierarchyMap", solHierarchyMap);
          activityStateModel.setProperty(path + '/solLevel', solHierarchyMap.get(level2Guid));
          const materials = activityFormModel.getProperty('/materials');
          activityStateModel.setProperty(path + "/materials", materials);
          this.setValueState("solutions")
          this.closeSolutionHierarchy()

        },

        // gets triggered on tab change in solution hierarchy and sets hierarchy data based on tab
        onChangeSolutionTab: function (event) {
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
          var selectedTab = event.getSource().getSelectedKey();
          let hierarchy = [];
          if (selectedTab === "SOLUTION_HIERARCHY") {
            let level2Guid = activityFormModel.getProperty('/level2Guid');
            let solHierarchyMap = activityFormModel.getProperty('/solHierarchyMap');

            hierarchy = solHierarchyMap.get(level2Guid)?.levels


          }
          else if (selectedTab === "FROM_OPPORTUNITY") {
            // set opportunity data 
            const formPath = activityFormModel.getProperty('/formPath');
            const activityStateModel = this.getOwnerComponent().getModel("activityState");
            let oppSolHierarchy = activityStateModel.getProperty(formPath + "/oppSolHierarchy");
            oppSolHierarchy.forEach(each => hierarchy = hierarchy.concat(each.levels))
            hierarchy.forEach(each => each.isParent = true)
            this.getMaterials(hierarchy[0]?.guid);

          }
          activityFormModel.setProperty('/solHierarchy', $.extend(true, [], hierarchy));
          activityFormModel.setProperty('/showDisplayMaterials', false);



        },

        // gets triggerd on deletion of any token from the solution hierarchy dialog
        onDeleteDisplayTokens: function (event) {
          let deletedToken = event.getParameter("removedTokens")[0];
          let deletedSol = deletedToken.getBindingContext("activityFormModel").getObject();
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
          let displayTokens = activityFormModel.getProperty('/displayTokens');
          displayTokens = displayTokens.filter(each => each.id !== deletedSol.id);
          activityFormModel.setProperty('/displayTokens', displayTokens);
          let materials = activityFormModel.getProperty("/materials");
          if (deletedSol.isMaterial) {
            let material = materials.find(each => each.id === deletedSol.id);
            material.selected = false;
            activityFormModel.setProperty("/materials", materials)
          }
          else {
            const solHierarchyMap = activityFormModel.getProperty("/solHierarchyMap");
            solHierarchyMap.get(deletedSol.guid).selected = false;
            const activityState = ActivityState.getInstance();
            let data = activityState.updateParentSelections(solHierarchyMap, solHierarchyMap.get(deletedSol.guid), null, materials);
            activityFormModel.setProperty('/solHierarchyMap', solHierarchyMap)
            // materials = materials.filter(each => each.guid !== deletedSol.guid);
            activityFormModel.setProperty("/materials", data.materials);
            let materialsMap = new Map();
            data.materials?.forEach(material => { materialsMap.set(material.guid, material) })
            activityFormModel.setProperty('/materialsMap', materialsMap)
          }
        },

        // gets triggerd on deletion of any token from the solutions multi input in form
        onDeleteSolution: function (event) {
          let deletedToken = event.getParameter("removedTokens")[0];
          let deletedSol = deletedToken.getBindingContext("activityState").getObject();
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          const formPath = activityFormModel.getProperty('/formPath');
          let solutions = activityStateModel.getProperty(formPath + "/solutions/results");
          solutions = solutions.filter(each => each.id !== deletedSol.id)
          activityStateModel.setProperty(formPath + "/solutions/results", solutions);
          let materials = activityStateModel.getProperty(formPath + "/materials");
          if (deletedSol.isMaterial) {
            let material = materials.find(each => each.id === deletedSol.id)
            material.selected = false;
            activityStateModel.setProperty(formPath + "/materials", materials)
          }
          else {
            const solHierarchyMap = activityStateModel.getProperty(formPath + "/solHierarchyMap");
            solHierarchyMap.get(deletedSol.guid).selected = false;
            const activityState = ActivityState.getInstance();
            let data = activityState.updateParentSelections(solHierarchyMap, solHierarchyMap.get(deletedSol.guid), null, materials);
            activityStateModel.setProperty(formPath + '/solHierarchyMap', solHierarchyMap)
            activityStateModel.setProperty(formPath + "/materials", data.materials);
          }

        },

        //-----------------------SOLUTION HIERARCHY END---------------------//

        // gets triggered on click of save in detail and create page
        onRegisterActivity: async function () {
          const activityState = ActivityState.getInstance();
          activityState.registerActivities();
          this.getRouter().navTo("list");

        },


        // gets triggered on change of startdate/enddate and performs date validation 
        onChangeDate: function (event, property, name) {
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          let formPath = activityFormModel.getProperty('/formPath');
          let activity = activityStateModel.getProperty(formPath);
          let startDate = activity.startDate, endDate = activity.endDate;
          let date = event.getSource().getDateValue();
          if (event.getSource().getProperty('name') === "startDate") {
            date.setHours(9, 0, 0)
          }
          else if (event.getSource().getProperty('name') === "endDate") {
            date.setHours(17, 0, 0)
          }
          if (startDate > endDate && activity[name]) {
            // change only date not time
            let copy = structuredClone(date);
            copy.setHours(activity[property].getHours(), activity[property].getMinutes(), activity[property].getSeconds())
            activity[property] = copy;
          }
          activityStateModel.setProperty(formPath + "/" + property, activity[property]);
          activityStateModel.setProperty(formPath + "/" + name, date);

          this.setValueState(name)

        },

        // gets triggered on change of team to update team count and modified (for VAT validation)
        onChangeTeam: function (event) {
          const team = event.getParameter("team");
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const formPath = activityFormModel.getProperty("/formPath");
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          activityStateModel.setProperty(formPath + '/team/count', team?.length);
          activityStateModel.setProperty(formPath + "/modified/team", true);
          this.setValueState('team');
          const activityState = ActivityState.getInstance();
          activityState.setTimeEntryVisibility(activityStateModel.getProperty(formPath).guid);

        },

        // gets triggered on change of lead / account executive and updates modified which is used for VAT team validation
        onChangeUser: function (event, property) {
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const formPath = activityFormModel.getProperty("/formPath");
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          activityStateModel.setProperty(formPath + "/modified/" + property, true);
          activityStateModel.setProperty(formPath + "/" + property, event.getParameter("user"));
          this.setValueState(property);
          const activityState = ActivityState.getInstance();
          activityState.setTimeEntryVisibility(activityStateModel.getProperty(formPath).guid);
        },

        setValueState: function (property) {
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const formPath = activityFormModel.getProperty("/formPath");
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          activityStateModel.setProperty(formPath + "/valueStates/" + property + "/state", 'None');
        },

        openAdditionalOppos: async function () {
          if (!this.additionalOppoDialog) {
            this.additionalOppoDialog = await this.loadFragment({
              name: "com.melody.activity.fragments.form.AdditionalOppoSelection",
            });
          }
          this.additionalOppoDialog.open();
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const formPath = activityFormModel.getProperty("/formPath");
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          const selectedOpportunities = activityStateModel.getProperty(formPath + '/additionalOpportunities/results');
          const oppoMap = {};
          selectedOpportunities.forEach(each => oppoMap[each.id] = each)
          const storage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
          let opportunities = storage.get("myopportunities");
          opportunities.forEach(opportunity => { opportunity.selected = oppoMap[opportunity.id] ? true : false });
          activityFormModel.setProperty('/additionalOpportunities', opportunities);
          const opportunityId = activityStateModel.getProperty(formPath + '/opportunity/id');
          let filters = [];
          if (opportunityId) {
            filters.push(new Filter("id", "NE", opportunityId));
          }
          this.byId("additionalOpptList").getBinding("items").filter(filters);
        },

        onSearchOppo: function (event) {
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
          const formPath = activityFormModel.getProperty("/formPath");
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          const opportunityId = activityStateModel.getProperty(formPath + '/opportunity/id');
          var status = this.byId("addOpptStatusSel").getSelectedKey();
          var search = event.getParameter("query");
          var filters = new Filter({
            filters: [
              new Filter("accountName", "Contains", search),
              new Filter("id", "Contains", search),
              new Filter("description", "Contains", search),
              new Filter("accountId", "Contains", search)
            ],
            and: false
          });

          if (opportunityId) {
            var oppFilter = new Filter("id", "NE", opportunityId);
            filters = new Filter({
              filters: [filters, oppFilter],
              and: true
            });
          }
          if (status) {
            var statusFilter = new Filter("active", "EQ", status);
            filters = new Filter({
              filters: [filters, statusFilter],
              and: true
            });
          }
          var list = this.getView().byId("additionalOpptList");
          list.getBinding("items").filter([filters]);
        },

        onChangeOppoStatus: function (event) {
          var filters = [];
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          const formPath = activityFormModel.getProperty("/formPath");
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          const opportunityId = activityStateModel.getProperty(formPath + '/opportunity/id');
          var status = oEvent.getParameter("selectedItem").getKey();
          if (status !== "") {
            filters.push(new Filter("active", "EQ", status));
          }
          if (opportunityId) {
            filter.push(new Filter("id", "NE", opportunityId));
          }
          this.byId("additionalOpptList").getBinding("items").filter(filters);
          this.byId("opptSearchMulti").setValue("");
        },

        handleAdditionalOppoSelect: function (event) {
          var source = event.getSource();
          const activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          var path = source.getBindingContext("activityFormModel").getPath();
          if (source.getPressed()) {
            activityFormModel.setProperty(path + "/selected", true);
            // oSource.setText("Deselect");
          } else {
            activityFormModel.setProperty(path + "/selected", false);
            // oSource.setText("Select");
          }
        },
        handleAdditionalOpptConfirm: function () {
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
          const formPath = activityFormModel.getProperty("/formPath");
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          const selectedOpportunities = activityFormModel.getProperty('/additionalOpportunities').filter(opportunity => opportunity.selected);
          activityStateModel.setProperty(formPath + "/additionalOpportunities", { results: selectedOpportunities, count: selectedOpportunities.length });
          this.additionalOppoDialog.close()
        },
        onCloseAdditionalOppo: function () {
          this.additionalOppoDialog.close();
        },
        onDeleteAdditionalOppo: function (event) {
          let deletedToken = event.getParameter("removedTokens")[0];
          deletedToken = deletedToken.getBindingContext("activityState").getObject();
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          const formPath = activityFormModel.getProperty('/formPath');
          let additionalOpportunities = activityStateModel.getProperty(formPath + "/additionalOpportunities/results");
          additionalOpportunities = additionalOpportunities.filter(each => each.id !== deletedToken.id)
          activityStateModel.setProperty(formPath + "/additionalOpportunities", { results: additionalOpportunities, count: additionalOpportunities.length });
        },
        //Function to show Saved/Failed/Submitted entry hours
        fnShowUserEntryHrs(oEvent) {
          var oStatusId = "";
          var sEntryKey = "";
          var sTitle = "Saved / To be Submitted";
          var aEntriesArray = [];
          var selectedIcon = "SAVED";
          var oSource = oEvent.getSource();
          var selectedKey = oSource.getCustomData()[0].getKey();
          const activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
          const activityStateModel = this.getOwnerComponent().getModel("activityState");
          const formPath = activityFormModel.getProperty("/formPath");
          const activity = activityStateModel.getProperty(formPath)
          var oCustomerFacing = activity.estimatedTime.customerFacing;
          var oNonCustomerFacing = activity.estimatedTime.nonCustomerFacing;
          switch (selectedKey) {
            case "SAVED":
              oStatusId = "1";
              selectedIcon = "SAVED";
              sTitle = "Saved / To be Submitted";
              sEntryKey = "aSameSavedEntries";
              break;
            case "FAILED":
              oStatusId = "3";
              selectedIcon = "FAILED";
              sTitle = "Failed Submissions";
              sEntryKey = "aSameFailedEntries";
              break;
            case "SUBMITTED":
              oStatusId = "4";
              selectedIcon = "SUBMITTED";
              sTitle = "Successful Submissions";
              sEntryKey = "aSameSubmittedEntries";
              break;
            default:
              break;
          }
          aEntriesArray = aEntriesArray.concat(oCustomerFacing[sEntryKey]);
          aEntriesArray = aEntriesArray.concat(oNonCustomerFacing[sEntryKey]);
          aEntriesArray = this.fnPerformConcatEntries(aEntriesArray);
          activityFormModel.setProperty("/userEntryPopOverTitle", sTitle);
          activityFormModel.setProperty("/aEntriesArray", aEntriesArray);
          activityFormModel.setProperty("/selectedIcon", selectedIcon);
          activityFormModel.setProperty("/UserEntriesStatus", oStatusId);
          this.fnOpenSubmissionInfoPopover(oEvent);
        },
        async fnOpenSubmissionInfoPopover(event) {
          if (!this.timeEntriesInfoPopover) {
            this.timeEntriesInfoPopover = await this.loadFragment({
              name: "com.melody.activity.fragments.form.TimeEntriesInfoPopover",
            });
          }
          this.timeEntriesInfoPopover.openBy(event.getSource());
        },
        //Function perform concat for the entries array
        fnPerformConcatEntries(aEntriesArray) {
          const activityState = ActivityState.getInstance();
          if (aEntriesArray && !aEntriesArray.length) {
            return aEntriesArray;
          }
          aEntriesArray = activityState.sortTimeEntries(aEntriesArray);
          aEntriesArray = this.fnConcatBasedOnRecordDate(aEntriesArray);
          return aEntriesArray
        },

        //Function to create CF/NCF Entry based on RecordDate
        fnConcatBasedOnRecordDate(aEntries) {
          let oRecordDates = {};
          let aTotalEntries = [];
          for (let i = 0; i < aEntries.length; i++) {
            let oEntry = aEntries[i];
            let entryDate = oEntry.date;
            let TimeMatrics = oEntry.unit;
            let recordDate = oEntry.recordDate;
            let WorkDuration = (oEntry.duration.original) ? Number(oEntry.duration.original) : 0;
            let oNewEntry = {
              entryDate: entryDate,
              cfWorkDuration: 0,
              ncfWorkDuration: 0,
              cfTimeMatrics: TimeMatrics,
              ncfTimeMatrics: TimeMatrics,
              recordDate: recordDate
            };
            if (!oRecordDates[recordDate]) {
              oRecordDates[recordDate] = 1;
              if (oEntry.customerFacing) {
                oNewEntry.cfWorkDuration = WorkDuration;
              } else {
                oNewEntry.ncfWorkDuration = WorkDuration;
              }
              aTotalEntries.push(oNewEntry);
            } else {
              if (oRecordDates[recordDate] >= 1) {
                let indxEntry = aTotalEntries.findIndex((entry) => {
                  return entry.recordDate === recordDate;
                });

                //If entry alreay present;
                if (indxEntry !== -1) {
                  if (oEntry.CustomerFacing) {
                    aTotalEntries[indxEntry].cfWorkDuration += WorkDuration;
                  } else {
                    aTotalEntries[indxEntry].ncfWorkDuration += WorkDuration;
                  }
                  oRecordDates[recordDate] += 1;
                } else {
                  //Worst case scenario
                  oRecordDates[recordDate] = 1;
                  if (oEntry.customerFacing) {
                    oNewEntry.cfWorkDuration = WorkDuration;
                  } else {
                    oNewEntry.ncfWorkDuration = WorkDuration;
                  }
                  aTotalEntries.push(oNewEntry);
                }
              }
            }
          }
          return aTotalEntries;
        },

        //function to navigate to My Entries
        // fnShowUserEntryHrs: function () {
        //   this.getRouter().navTo("MyEntries");
        // },

      }


    );
  }
);
