// @ts-nocheck
sap.ui.define(
    [

        "sap/ui/model/json/JSONModel",

        "com/melody/activity/util/formatter",

        "com/melody/activity/controller/BaseController",
        "com/melodylib/core/db/IndexedDB"

    ],
    function (

        JSONModel,

        formatter,

        BaseController,
        IndexedDB
    ) {
        "use strict";

        return BaseController.extend("com.melody.activity.controller.DraftActivities", {
            formatter: formatter,
            onInit: function () {

                this.router = this.getRouter();
                this.router.attachRoutePatternMatched(
                    this.onRoutePatternMatched,
                    this
                );
                const data = {
                    selectedActivities: [],
                    enableRegistration: false
                }
                const model = new JSONModel(data);
                this.setModel(model);
            },
            onRoutePatternMatched: async function (event) {
                if (event.getParameter("name") === "drafts") {
                    this.onRouteMatched(event);
                    let drafts =
                        (await IndexedDB.fnGetAllDatafromDB({
                            dbName: "myActivities",
                            storeName: "drafts-table",
                            keyName: "activitydrafts",
                        })) || [];
                    let activityState = this.getModel("activityState");
                    activityState.setProperty("/draftActivities", drafts);
                    const table = this.byId("drafts");
                    table.removeSelections();
                    this.getModel().setProperty('/selectedActivities', [])
                }
            },
            onSelectActivity: function (event) {
                const model = this.getModel();
                // let selectedActivities = model.getProperty("/selectedActivities");
                // let activity = event.getParameter("listItem").getBindingContext("activityState").getObject()
                const table = this.byId("drafts");
                let selectedActivities = table.getSelectedContexts().map(each => each.getObject())
                model.setProperty("/selectedActivities",selectedActivities);
                let enableRegistration = false
                // if (event.getParameter("selected")) {
                //     selectedActivities.push(activity)
                // }
                // else {
                //     selectedActivities = selectedActivities.filter(each => each.guid !== activity.guid);
                // }
                if (selectedActivities.length) enableRegistration = true;
                model.setData({
                    selectedActivities,
                    enableRegistration
                })
            },
            editDraftActivities: function (event) {
                const model = this.getModel();
                const activityStateModel =
                    this.getOwnerComponent().getModel("activityState");
                let selectedRows = model.getProperty('/selectedActivities')
                activityStateModel.setProperty('/openedActivities', selectedRows);
                this.router.navTo("registerForm", {
                    drafts: true
                });
            },
            deleteDraftActivities: function () {
                const model = this.getModel();
                const activityStateModel =
                    this.getOwnerComponent().getModel("activityState");
                let selectedRows = model.getProperty('/selectedActivities');
                let drafts = activityStateModel.getProperty('/draftActivities');
                selectedRows = new Set(selectedRows.map(each => each.guid));
                drafts = drafts.filter(item => !selectedRows.has(item.guid));
                IndexedDB.fnInsertDataToDB({
                    dbName: "myActivities",
                    storeName: "drafts-table",
                    keyName: "activitydrafts",
                    aObjectsToInsert: drafts,
                });
                model.setProperty("/enableRegistration", false);
                activityStateModel.setProperty('/draftActivities', drafts)
            },
            onNavBackPress: function () {
                this.router.navTo("list");
            }
        })

    }

);
