// @ts-nocheck
sap.ui.define(
  ["com/melody/activity/controller/BaseDetailController",
    "sap/ui/model/json/JSONModel",
    "com/melody/activity/service/MasterService",
    "com/melody/activity/util/MasterData",
    "com/melodylib/activity/classes/Activity",
    "com/melodylib/activity/state/ActivityState",
    "com/melodylib/activity/state/ActivityMasterState",
    "com/melodylib/core/state/AuthState",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "com/melody/activity/util/formatter"


  ],
  function (BaseDetailController, JSONModel, MasterService, MasterData, Activity, ActivityState, ActivityMasterState, AuthState, MessageToast, MessageBox, formatter) {
    "use strict";

    return BaseDetailController.extend("com.melody.activity.controller.Registration", {
      formatter: formatter,
      onInit: function () {
        this.masterDataModel = this.getOwnerComponent().getModel("masterDataModel");
        // this.masterDataModel.setProperty("/activityTypesMap", {})
        this.activityFormModel = this.getOwnerComponent().getModel("activityFormModel");
        this.activityListModel = this.getOwnerComponent().getModel("activityListModel");
        this.activityMasterStateModel = this.getOwnerComponent().getModel("activityMasterState");
        this.activityStateModel = this.getOwnerComponent().getModel("activityState");
        this.router = this.getRouter();
        this.router.attachRoutePatternMatched(this.onRoutePatternMatched, this);
        this.activityState = ActivityState.getInstance();
        this.activityMasterState = ActivityMasterState.getInstance();
        this.authState = AuthState.getInstance()
        // let defaultRole = this.authState.getData().role;
        // const data = { activity: { role: { id: defaultRole.id, mappingId: defaultRole.mappingId } } }
        const model = new JSONModel();
        this.setModel(model, "registration");
        this.registration = this.getView().getModel("registration");
        // this.registration.setProperty("/activity", { role: { id: defaultRole, mappingId: roleMappingId } });
      },

      onRoutePatternMatched: function (event) {
        if (event.getParameter("name") === "registerForm") {
          this.onRouteMatched(event);
          const drafts = event.getParameter("arguments").drafts;
          this.activityFormModel.setProperty("/editable", true);
          this.setFormPath('/openedActivities/0')
          if (!drafts) {
            const user = this.activityListModel.getProperty('/user')
            const activity = new Activity({
              ActivityLead: user?.id,
              ActivityLeadName: user?.name,
              ActivityLeadEmail: user?.email,
              ActivityLeadRoleDesc: user?.roleDescription
            })
            this.activityStateModel.setProperty("/openedActivities", [activity]);
            this.openRegistrationDialog();
            this.activityState.initializeActivity(activity)
          }

          const tabContainer = this.byId("myTabContainer");
          const tab = tabContainer.getItems()[0]
          tabContainer.setSelectedItem(
            tab
          );

        }

      },

      onPressNavToListScreen: function () {
        this.router.navTo("list");
      },

      //function to add new activity form
      onAddNewForm: function () {
        let activities = this.activityStateModel.getProperty("/openedActivities");
        const user = this.activityListModel.getProperty('/user')
        const newActivity = new Activity({
          ActivityLead: user?.id,
          ActivityLeadName: user?.name,
          ActivityLeadEmail: user?.email,
          ActivityLeadRoleDesc: user?.roleDescription
        })
        activities.push(newActivity)
        this.activityStateModel.setProperty("/openedActivities", activities)
        const tabContainer = this.byId("myTabContainer");
        const lastTab = tabContainer.getItems().pop()
        tabContainer.setSelectedItem(
          lastTab
        );
        this.openRegistrationDialog();
        this.activityState.initializeActivity(newActivity)
      },
      //function to open activity registration dialog
      openRegistrationDialog: async function () {
        this.onChangeAssociation();
        if (!this.ActivityRegFragment) {
          this.ActivityRegFragment = await this.loadFragment({
            name: "com.melody.activity.fragments.form.ActivityRegistration",
          });
        }
        this.ActivityRegFragment.open();
        // to fetch activity Types
        // if (!this.ActivityRegFragment) Fragment.load({
        //   name: "com.melody.activity.fragments.form.ActivityRegistration",
        //   controller: this
        // }).then(function (dialog) {
        //   this.ActivityRegFragment = dialog;
        //   this.getView().addDependent(dialog);
        //   this.ActivityRegFragment.open();
        // }
        //   .bind(this));
        // else {
        //   this.onChangeAssociation(); // to fetch activity Types
        //   this.ActivityRegFragment.open()
        // };
      },
      onChangeRegistrationType: async function () {
        const associationId = this.registration.getProperty("/activity/association/id");
        const currentFormPath = this.activityFormModel.getProperty('/formPath');
        let activity = this.registration.getProperty('/activity')
        let validData = true;

        if (!activity.type.id) {
          validData = false;
          this.registration.setProperty('/activity/typeValueState', 'Error');
        }
        else {
          this.registration.setProperty('/activity/typeValueState', 'None');
        }
        if (associationId === '502') {
          const opportunityId = activity.opportunity.id;
          if (!opportunityId) {
            validData = false
            this.registration.setProperty('/activity/oppoValueState', 'Error');
          }
          else {
            this.registration.setProperty('/activity/oppoValueState', 'None');
            this.activityStateModel.setProperty(currentFormPath + '/opportunity', activity.opportunity)
            this.registration.setProperty('/activity/opportunity', {});
            // this.getOppoSolHierarchy(opportunityId)
            let data = this.activityStateModel.getProperty(currentFormPath)
            this.activityState.setSolutionHierarchy('CREATE', data.guid)
          }

        }
        else if (associationId === '501') {
          let accountId = activity.account.id;
          if (!accountId) {
            validData = false
            this.registration.setProperty('/activity/accountValueState', 'Error');
          }
          else {
            this.registration.setProperty('/activity/accountValueState', 'None');
            this.activityStateModel.setProperty(currentFormPath + '/account', { id: accountId })
            this.registration.setProperty('/activity/account', {})
          }

        }
        else if (associationId === '503') {
          this.registration.setProperty('/activity/regionValueState', 'None');
          this.registration.setProperty('/activity/muValueState', 'None');
          let region = activity.region;
          let marketUnit = activity.marketUnit;
          let title = activity.title;
          if (region) this.registration.setProperty('/activity/regionValueState', 'None');
          else this.registration.setProperty('/activity/regionValueState', 'Error');

          if (marketUnit) this.registration.setProperty('/activity/muValueState', 'None');
          else this.registration.setProperty('/activity/muValueState', 'Error');
          this.activityStateModel.setProperty(currentFormPath + '/region', region)
          this.activityStateModel.setProperty(currentFormPath + '/marketUnit', marketUnit)
          this.activityState.createActivitySet({
            ProfitCenter: activity.profitCenter,
            Description: activity.title
          }, this.activityStateModel.getProperty(currentFormPath))
          // this.activityStateModel.setProperty(currentFormPath + '/set', set)



        }



        if (validData) {
          const type = this.registration.getProperty("/activity/type");
          const role = this.authState.getData().role;
          this.activityStateModel.setProperty(currentFormPath + "/role", role);
          this.activityStateModel.setProperty(currentFormPath + "/type", type);
          this.activityStateModel.setProperty(currentFormPath + "/association/id", associationId);
          this.onCloseRegistrationDialog();
          if (activity.association.id === "502" && activity.type.layout.fields.checkDuplicates.visible) {
            this.checkDuplicateRegistrations(this.activityStateModel.getProperty(currentFormPath))
          }
          this.activityState.getTimeEntryDefaultValues(this.activityStateModel.getProperty(currentFormPath).guid)
        }

      },
      //fuction to close the activity registration dialog
      onCloseRegistrationDialog: function () {
        this.ActivityRegFragment.close();
      },
      onSelectOpportunity: async function (event) {
        const selectedOppo = event.getParameter("selectedOpportunity");
        this.registration.setProperty(
          "/activity/opportunity", selectedOppo)
        this.registration.setProperty("/activity/oppoValueState", 'None');

      },
      onSelectAccount: function () {
        this.registration.setProperty("/activity/accountValueState", 'None');
      },

      checkDuplicateRegistrations1: async function (activity) {
        const openedActivities = this.activityStateModel.getProperty("/openedActivities");
        let duplicateReg = openedActivities.find(each => each.guid !== activity.guid && each.opportunity.id === activity.opportunity.id && each.type.id === activity.type.id);
        let message;
        if (duplicateReg) {
          duplicateReg = [duplicateReg];
          message = "Based on the opportunity and end date you have entered, Melody has indentified possible duplicate activity registrations exist in the opened tabs. You may add yourself to one of the existing by clicking ' Add Me',or you may continue with this new registration."
          // show duplicate dialog
        }
        else {
          duplicateReg = await this.activityState.getDuplicateRegistrations(activity);
          if (duplicateReg.length) {
            message = " Based on the opportunity and end date you have entered, Melody has identified that possible duplicate activity registrations exist.&#xA;You may add yourself to one of the existing by clicking ' Add Me',or you may continue with this new registration."
            // show duplicate dialog
          }
        }
        if (duplicateReg.length) {
          this.activityFormModel.setProperty("/duplicateRegMsg", message);
          this.activityFormModel.setProperty("/duplicateRegistrations", duplicateReg);
          if (!this.duplicateRegDialog) {
            this.duplicateRegDialog = await this.loadFragment({
              name: "com.melody.activity.fragments.form.DuplicateRegistrations",
            });
          }
          this.duplicateRegDialog.open();
        }
      },
      handleAddMePress: function () {
        this.justificationDialog.close();
        const formPath = this.activityFormModel.getProperty("/formPath")
        const activity = this.activityStateModel.getProperty(formPath)
        this.checkDuplicateRegistrations(activity)
      },
      checkDuplicateRegistrations: async function (activity) {
        const openedActivities = this.activityStateModel.getProperty("/openedActivities");
        let duplicateReg = openedActivities.filter(each => each.guid !== activity.guid && each.opportunity.id === activity.opportunity.id && each.type.id === activity.type.id) || [];
        let message;

        let data = await this.activityState.getDuplicateRegistrations(activity);
        if (data.length) duplicateReg = duplicateReg.concat(data)
        if (duplicateReg.length) {
          message = " Based on the opportunity and end date you have entered, Melody has identified that possible duplicate activity registrations exist.&#xA;You may add yourself to one of the existing by clicking ' Add Me',or you may continue with this new registration."
          // show duplicate dialog
        }

        if (duplicateReg.length) {
          this.activityFormModel.setProperty("/duplicateRegMsg", message);
          this.activityFormModel.setProperty("/duplicateRegistrations", duplicateReg);
          if (!this.duplicateRegDialog) {
            this.duplicateRegDialog = await this.loadFragment({
              name: "com.melody.activity.fragments.form.DuplicateRegistrations",
            });
          }
          this.duplicateRegDialog.open();
        }
      },
      handleNewRegistration: async function () {
        if (this.duplicateRegDialog) this.duplicateRegDialog.close();
        if (!this.justificationDialog) {
          this.justificationDialog = await this.loadFragment({
            name: "com.melody.activity.fragments.form.Justification",
          });
        }
        this.justificationDialog.open();
        this.byId("idJustificationComm").setValue('')
      },
      onJustificationLiveChange: function (event) {
        event.getSource().setValueState("None");
      },

      onSubmitJustification: function () {
        const formPath = this.activityFormModel.getProperty("/formPath");
        const activity = this.activityStateModel.getProperty(formPath);
        var justifyComm = this.byId("idJustificationComm").getValue();
        if (justifyComm && justifyComm !== "") {
          this.justificationDialog.close();
          const user = this.activityListModel.getProperty('/user')
          var data = {
            "ProjectType": "ACT_JUSTF",
            "CreatedBy": user.id,
            "CreateUserName": user.name,
            "CommentDesc": justifyComm
          };
          this.activityState.getCommentId(data, activity.guid);
        } else {
          this.byId("idJustificationComm").setValueState("Error");
        }
      },
      onSaveComplete: function (activity) {

        MessageBox.confirm("You have been added as a team member to " + activity.id);
      },
      handleAddMe: async function (event) {
        let duplicateActivity = event.getSource().getBindingContext("activityFormModel").getObject();
        const formPath = this.activityFormModel.getProperty('/formPath');
        const currentActivity = this.activityStateModel.getProperty(formPath);
        this.duplicateRegDialog.close();
        if (duplicateActivity.id) {
          await this.activityState.saveTeam(duplicateActivity.guid);
          this.activityFormModel.setProperty('/duplicate', {
            id: duplicateActivity.id,
            type: currentActivity.type.description,
          })
          if (!this.userAdditionDialog) {
            this.userAdditionDialog = await this.loadFragment({
              name: "com.melody.activity.fragments.form.UserAdditionMessage",
            });
          }
          this.userAdditionDialog.open();
        }
        else {
          let openedActivities = this.activityStateModel.getProperty('/openedActivities');
          const tabContainer = this.byId("myTabContainer");
          let duplicateTab, currentTab;
          tabContainer.getItems().forEach(each => {
            if (each.getBindingContext("activityState").getObject().guid === duplicateActivity.guid) duplicateTab = each;
            if (each.getBindingContext("activityState").getObject().guid === currentActivity.guid) currentTab = each;

          })
          tabContainer.setSelectedItem(
            duplicateTab
          );
          // tabContainer.removeItem(currentTab);
          openedActivities.splice(formPath.split("/")[2], 1);
          this.activityStateModel.setProperty('/openedActivities', openedActivities)

        }
      },
      onCloseUserAddition: function () {
        let openedActivities = this.activityStateModel.getProperty('/openedActivities');
        const formPath = this.activityFormModel.getProperty('/formPath');
        // const currentActivity = this.activityStateModel.getProperty(formPath);
        // const tabContainer = this.byId("myTabContainer");
        // let currentTab =
        //   tabContainer.getItems().find(each => each.getBindingContext("activityState").getObject().guid === currentActivity.guid)
        // tabContainer.removeItem(currentTab);
        openedActivities.splice(formPath.split("/")[2], 1);
        this.activityStateModel.setProperty('/openedActivities', openedActivities)
        this.userAdditionDialog.close();
      },
      onPressActivityId: function () {
        const duplicateActivity = this.activityFormModel.getProperty('/duplicate')
        const detail = window.location.href.replace("registerForm", "detail/" + duplicateActivity.id + "/EDIT/MidColumnFullScreen")
        window.open(
          detail,
          "_blank"
        );
      },
      // function to get all dropdowns data in Activity Registration Dialog - NOT USED
      getRegistrationDropdownsData: async function () {
        const associationId = this.registration.getProperty("/association/id");
        const activityTypesMap = this.masterDataModel.getProperty("/activityTypesMap");
        Promise.allSettled([MasterService.getRoleMasterData(), MasterData.getActivityTypes(associationId, activityTypesMap)]).then(([roles, activityTypes]) => {
          roles = roles?.value?.data?.results || []
          this.masterDataModel.setProperty("/roles", roles)
          this.masterDataModel.setProperty("/activityTypes", activityTypes.value)
          let defaultRole = roles.find(each => each.DefaultRole === "X");
          let roleMappingId = "";
          if (!defaultRole) {
            defaultRole = "0001";
            roleMappingId = "001";
          } else {
            roleMappingId = defaultRole.RoleMpngID;
            defaultRole = defaultRole.RoleID;
          }
          this.registration.setProperty("/role", { id: defaultRole, mappingId: roleMappingId });

        })
      },

      onSelectType: async function (event) {
        const type = event.getSource().getSelectedItem().getBindingContext("activityMasterState").getObject();
        this.registration.setProperty("/activity/type", type)
        this.registration.setProperty("/activity/typeValueState", false)
        const formPath = this.activityFormModel.getProperty("/formPath");
        const guid = this.activityStateModel.getProperty(formPath + "/guid");
        // this.registration.setProperty("/typeId", type.id)
        this.activityState.getTypeData(type,guid)

      },
      onSelectAssociation: function () {
        this.onChangeAssociation(null)
      },
      onChangeAssociation: async function (event) {
        // const activityTypesMap = this.masterDataModel.getProperty("/activityTypesMap")
        this.resetFieldsData(event)
        let associationId;
        const path = this.activityFormModel.getProperty("/formPath");
        if (!event) associationId = this.activityStateModel.getProperty(path + "/association/id");
        else {
          let id = event?.getSource()?.getSelectedIndex()
          if (id === 0) {
            associationId = '501';
          } else if (id === 1) {
            associationId = '502';
          } else if (id === 2) {
            associationId = '503';
          }

        }

        this.registration.setProperty('/activity/association', { id: associationId })
        // const activityTypes = await MasterData.getActivityTypes(associationId, activityTypesMap); //  get from lib (store map in app)
        const types = this.activityMasterStateModel.getProperty('/associations')[associationId]
        // this.registration.setProperty("/types", types);
        this.activityMasterStateModel.setProperty('/selectedAssociationTypes', types);

      },

      // function to open activity registration dialog to edit activity type  -  NOTS USED
      openActivitySelectPopUp: function () {
        const path = this.activityFormModel.getProperty("/formPath");
        const type = this.activityStateModel.getProperty(path + "/type")
        const layout = this.activityStateModel.getProperty(path + "/layout")
        // this.registration.setProperty("/typeId", type.id);
        this.registration.setProperty("/activity/type", type)
        const associationId = this.activityStateModel.getProperty(path + "/association").id
        // const activityTypesMap = this.activityMa.getProperty("/activityTypesMap")
        const types = this.activityMasterStateModel.getProperty("/associations")[associationId];
        this.registration.setProperty('/types', types)
        this.ActivityRegFragment.open()
      },

      // function to reset activity registration dialog fields while opening the dialog and on change of association type 
      resetFieldsData: function (event) {
        const path = this.activityFormModel.getProperty('/formPath');
        const newActivity = this.registration.getProperty('/activity');
        const existingActivity = this.activityStateModel.getProperty(path);
        const activity = {
          account: event ? { id: null } : existingActivity.account,
          type: event ? { id: null } : existingActivity.type,
          opportunity: event ? { id: null } : existingActivity.opportunity,
          region: event ? null : existingActivity.region,
          marketUnit: event ? null : existingActivity.marketUnit,
          title: event ? null : existingActivity.set.description,
          association: event ? newActivity.association : existingActivity.association,
        }
        this.registration.setProperty('/activity', activity)
        // this.registration.setProperty("/regAccountData", null)
        // this.registration.setProperty("/accountId", null)
        // this.registration.setProperty("/activityType", '')
        // this.registration.setProperty("/typeId", '')
        // this.registration.setProperty("/regOppoData", null)
        // this.registration.setProperty("/opportunityId", null)
        // this.registration.setProperty("/region", null)
        // this.registration.setProperty("/marketUnit", null)
        // this.registration.setProperty("/title", null);
      },

      // function to set the form path on tab change in Create mode
      onTabSelect: function (event) {
        const path = event.getParameter('item')?.getBindingContext("activityState").getPath()
        this.setFormPath(path)
        const validationErrors = this.activityStateModel.getProperty(path + "/validationErrors");
        this.activityFormModel.setProperty("/validationErrors", validationErrors);
        const activity = this.activityStateModel.getProperty(path)
        if (activity && activity.isCopied && activity.association.id === "502" && activity.type.layout.fields.checkDuplicates.visible && !activity.justificationComment) this.handleNewRegistration();
      },

      setTimeEntryVisibility: async function (type) {
        const path = this.activityFormModel.getProperty("/formPath");
        const activity = this.activityStateModel.getProperty(path);
        let loggedInUser = this.activityListModel.getProperty('/user');
        let lead = this.activityStateModel.getProperty(path + "/lead");
        let team = this.activityStateModel.getProperty(path + "/team/results");
        let isRequestor = false;
        let actTeam = [];
        actTeam = actTeam.push(lead);
        actTeam = actTeam.concat(team);
        if (actTeam.some(member => member.id === loggedInUser.id)) {
          isRequestor = true;
        }
        if (isRequestor) {
          let mtrTasks = [];
          //*********old code**********
          // var oSettings = MTRModels.getMTRSettingsModel().getData();
          // if (oSettings && oSettings.ActivityRecording === "1") {
          //   if (sActivityId) {
          //     var aUserActivities = await ActivityUtil.getUserActivities(true);
          //     var oSelActivity = this.getActivityFromUserActivities(sActivityId, aUserActivities);
          //     var MTRActivity = this.fnSetMTRActivityObj(oSelActivity);
          //     if (!MTRActivity || (MTRActivity && MTRActivity.ActivitySetStatus && MTRActivity.ActivitySetStatus !== "")) {
          //       aMTRTasks = [];
          //     } else {
          //       aMTRTasks = await MTRHelper.filterMtrTasks(MTRActivity);
          //     }
          //   } else {
          //     aMTRTasks = await MTRHelper.getActivityTypeTaskMapping(activityTypeId, associateType);
          //   }
          // }
          mtrTasks = await this.activityState.getMTRTasks(activity.guid);
          if (mtrTasks.length === 1) {
            this.activityStateModel.setProperty(path + "/type/layout/fields/customerFacingTime", {
              enable: false,
              required: false,
              visible: false
            })
            this.activityStateModel.setProperty(path + "/type/layout/fields/nonCustomerFacingTime", {
              enable: true,
              required: true,
              visible: true
            })
            // this.getTimeEntryDefaultValues();
          }
          else if (mtrTasks.length === 2) {
            this.activityStateModel.setProperty(path + "/type/layout/fields/customerFacingTime", {
              enable: true,
              required: true,
              visible: true
            })
            this.activityStateModel.setProperty(path + "/type/layout/fields/nonCustomerFacingTime", {
              enable: true,
              required: true,
              visible: true
            })
            // this.getTimeEntryDefaultValues();
          }


        }
        else {
          this.activityStateModel.setProperty(path + "/type/layout/fields/customerFacingTime", {
            enable: false,
            required: false,
            visible: false
          });
          this.activityStateModel.setProperty(path + "/type/layout/fields/nonCustomerFacingTime", {
            enable: false,
            required: false,
            visible: false
          });
        }
        this.getTimeEntryDefaultValues();

      },
      getTimeEntryDefaultValues: async function () {
        let loggedInUser = this.activityListModel.getProperty('/user')
        const userGuid = loggedInUser.time.guid;
        const formPath = this.activityFormModel.getProperty('/formPath');
        const activity = this.activityStateModel.getProperty(formPath);
        const defaultValues = await this.activityState.getTimeEntryDefaultValues(activity.guid);
        let cfTime = "0.0", ncfTime = "0.0";
        defaultValues.forEach(each => {
          if (each.CustomerFacing === "X") {
            cfTime = each.EstimatedHrs;
          }
          else {
            ncfTime = each.EstimatedHrs;
          }
        })

        cfTime = this.convertHrsToDays(cfTime);
        ncfTime = this.convertHrsToDays(ncfTime);

        this.activityStateModel.setProperty(formPath + "/estimatedTime", {
          cf: cfTime, ncf: ncfTime
        });


      },

      convertHrsToDays: function (sHours) {
        var days = 0;
        let loggedInUser = this.activityListModel.getProperty('/user')
        const timeMatrix = loggedInUser.time.unit;
        if (timeMatrix === "D") {
          sHours = parseFloat(sHours, 1);
          days = sHours / 8;
          var oDecimals = days - Math.floor(days);
          if (oDecimals === 0 || oDecimals > 0.5) {
            days = Math.round(days);
          } else if (oDecimals > 0 && oDecimals < 0.5) {
            days = Math.round(days) + 0.5;
          }
          return days.toString();
        } else {
          return sHours;
        }
      },
      handleRegionChange: function (event) {
        const regionId = event.getSource().getSelectedKey();
        let regions = this.activityMasterStateModel.getProperty('/regions');
        let region = regions.find(each => each.region === regionId)
        this.registration.setProperty('/marketUnits', region.marketUnits)
        this.registration.setProperty('/activity/marketUnit', region.marketUnits ? region.marketUnits[0].marketUnit : null)
        this.registration.setProperty('/activity/profitCenter', region.profitCenter)
        this.registration.setProperty("/activity/regionValueState", false)

      },
      onSelectMarketUnit: function () {
        this.registration.setProperty("/activity/muValueState", false)

      },
      showErrorsInfo: async function (event) {

        if (!this.errorsInfoPopover) {
          this.errorsInfoPopover = await this.loadFragment({
            name: "com.melody.activity.fragments.form.ErrorsInfoPopover"
          });
        }
        this.errorsInfoPopover.openBy(event.getSource());
      },

      onCloseTab: function (event) {
        // prevent the tab being closed by default
        event.preventDefault();
        var tabToClose = event.getParameter('item');
        const that = this;
        MessageBox.confirm("Do you want to close the tab '" + tabToClose.getName() + "'?", {
          onClose: function (oAction) {
            if (oAction === MessageBox.Action.OK) {
              let openedActivities = that.activityStateModel.getProperty('/openedActivities');
              const formPath = that.activityFormModel.getProperty('/formPath');
              openedActivities.splice(formPath.split("/")[2], 1);
              that.activityStateModel.setProperty('/openedActivities', openedActivities)
              // tabContainer.removeItem(tabToClose);
            }
          }
        });
      },

      onPressCopy: async function (event) {
        if (!this.copyActivityDialog) {
          this.copyActivityDialog = await this.loadFragment({
            name: "com.melody.activity.fragments.form.CopyActivity",
          });
        }
        this.copyActivityDialog.open();
        this.registration.setProperty('/copiesCount', 1);
        const formPath = this.activityFormModel.getProperty('/formPath');
        const activity = this.activityStateModel.getProperty(formPath);
        let columns = structuredClone(Object.values(activity.type.layout.fields));
        columns = columns.filter(each => {
          each.selected = true;
          each.visible = each.visible || false;
          return each.property;
        })
        this.registration.setProperty('/columns', columns);
      },

      onCloseCopyActivity: function () {
        this.copyActivityDialog.close();

      },

      onPressPaste: function () {
        const formPath = this.activityFormModel.getProperty('/formPath');
        const activity = this.activityStateModel.getProperty(formPath);
        let activities = this.activityStateModel.getProperty("/openedActivities");
        const copiesCount = this.registration.getProperty("/copiesCount");
        let columns = this.registration.getProperty('/columns');
        for (let i = 0; i < copiesCount; i++) {
          let newActivity = Object.create(Object.getPrototypeOf(activity));
          Object.assign(newActivity, activity);
          // let newActivity = structuredClone(activity);
          this.activityState.initializeActivity(newActivity);

          newActivity['isCopied'] = true;
          newActivity['justificationComment'] = null;
          activities.push(newActivity)
          this.activityStateModel.setProperty("/openedActivities", activities);
          columns.forEach(column => {
            if (!column.selected) {
              if (column)
                this.activityStateModel.setProperty(`/openedActivities/${activities.length - 1}${column.property}`, column.isArray ? [] : null)
            }
          })

        }
        // columns.forEach(column => {
        //   if (!column.selected) {
        //     this.registration.setProperty(`/openedActivities/${column.property}`, null);
        //   }
        // })
        this.onCloseCopyActivity()
      }
    });
  }
);
