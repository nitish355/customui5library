// @ts-nocheck
sap.ui.define([
	"com/melody/activity/controller/BaseController",
	"sap/ui/core/Fragment",
	"com/melodylib/time/state/TimeState",
	"com/melody/activity/util/formatter",
	"sap/m/MessageBox",
	'sap/m/library',
	'com/melodylib/time/state/TimeMasterState',
	"sap/ui/export/Spreadsheet",




], function (BaseController, Fragment, TimeState, formatter, MessageBox, MLibrary,TimeMasterState,Spreadsheet) {
	"use strict";

	return BaseController.extend("com.melody.activity.controller.MyEntries", {
		formatter: formatter,

		onInit() {
			this.TimeInstance = TimeState.getInstance();
			this.oRouter = this.getOwnerComponent().getRouter();
			this.oRouter.attachRoutePatternMatched(this.onRoutePatternMatched, this);
			 var oTimeStateModel = this.TimeInstance.getModel();
			   oTimeStateModel.attachPropertyChange(function (oEvent) {
        // Refresh the table binding
       
    }.bind(this));

		},
		async onRoutePatternMatched(oEvent) {
			if (oEvent.getParameter("name") === "MyEntries") {
				this.onRouteMatched(oEvent);
				
			}
		},
		//function to open Sort  Dialog 
		async onSortBtnPressed() {
			this.getView().setModel(this.TimeInstance.getModel(), "myEntriesModel");
			if (!this.oSortDialog)
				Fragment.load({
					name: "com.melody.activity.fragments.myEntries.MyEntriesSortDialog",
					controller: this,
				}).then(
					function (oDialog) {
						this.oSortDialog = oDialog;
						this.getView().addDependent(oDialog);
						this.oSortDialog.open();
					}.bind(this)
				);
			else this.oSortDialog.open();
		},
		onNavBackPress: function () {
			this.oRouter.navTo("list");
		},

		_selectedTable: function () {
			var oIconTabBar = this.byId("idIconTabBar");
			var sSelectedTab = oIconTabBar.getSelectedKey();
			var oSelectedEntriesTable = this.byId("idSavedEntriesTable");
			if (sSelectedTab === "submittedEntries") {
				oSelectedEntriesTable = this.byId("idSubmittedEntriesTable");
			} else if (sSelectedTab === "failedEntries") {
				oSelectedEntriesTable = this.byId("idFailedEntriesTable");
			}
			return oSelectedEntriesTable;
		},

		onCreateTimeEntry: function (oEvent) {

            // this.TimeInstance.openTimeDialog(oEvent, this);
			oEvent.getSource().openTimeDialog(oEvent,this);
        },
		onEditTimeEntry : function(oEvent){
			oEvent.getSource().openTimeDialog(oEvent);
		},

		onDeleteSingleEntry: function (oControl) {
			var oSelectedEntriesTable = this._selectedTable();
			var oMtrUid = oControl.getSource();
			var sMtrUid = oMtrUid.getCustomData()[0].getValue();
			var aEntry = [];
			var that = this;
			var oMyTimeEntriesModel = this.getView().getModel("myEntriesModel");
			var oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
			var aEntries = this.TimeInstance.getData().entries;
			var oSingleEntry = aEntries.find(function (item) {
				return item.MtrUid === sMtrUid;
			});
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			var confirmationMsg;
			if (oSingleEntry) {
				confirmationMsg = oResourceBundle.getText("ispConfirmDeleteMsg");
			} else {
				confirmationMsg = oResourceBundle.getText("lsConfirmDeleteMsg");
			}
			if (oSingleEntry) {
				MessageBox.confirm(
					confirmationMsg, {
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					onClose: function (sAction) {
						if (sAction === sap.m.MessageBox.Action.OK) {
							oSelectedEntriesTable.setBusy(true);
							if (oSingleEntry.DataFrom === "L") {
								oSingleEntry.Indicator = "D";
								aEntry.push(oSingleEntry);
								that.TimeInstance.deleteSavedEntries(aEntry).then(function () {
									oMyTimeEntriesModel.setData(that.TimeInstance.getData());
									oMyTimeEntriesModel.refresh(true);
									oSelectedEntriesTable.setBusy(false);
									MessageToast.show(oResourceBundle.getText("deleteEntriesSuccessMsg"));
									that._addMessage(
										sap.ui.core.MessageType.Success,
										oResourceBundle.getText("deleteEntriesSuccessMsg"), "", "");
								});
							}
							if (oSingleEntry.DataFrom === "I") {
								oSingleEntry.Indicator = "D";
								aEntry.push(oSingleEntry);
								that.TimeInstance.deleteSubmittedEntries(aEntry).then(function () {
									oSelectedEntriesTable.setBusy(false);
									oMyTimeEntriesModel.setData(that.TimeInstance.getData());
									oMyTimeEntriesModel.refresh(true);
									that.TimeInstance.updateExpectedBar();
								});
							}
							oMyTimeEntriesModel.setData(that.TimeInstance.getData());
							oMyTimeEntriesModel.refresh(true);
							oSelectedEntriesTable.removeSelections();

						}
					}
				});
			}
		},

		_addMessage: function (type, message, additionalText, description) {
			var oMessage = {
				type: type,
				title: message,
				subtitle: additionalText,
				description: description
			};
			if (oMessageModel) {
				this.TimeInstance.getData()._data.Messages.push(oMessage);
			}

		},

		onSubmitSingleEntry: function (oControl) {
			var oSelectedEntriesTable = this._selectedTable();
			var oMtrUid = oControl.getSource();
			var sMtrUid = oMtrUid.getCustomData()[0].getValue();
			var aEntries = this.TimeInstance.getData().entries;
			var oSingleEntry = aEntries.find(function (item) {
				return item.MtrUid === sMtrUid;
			});
			var that = this;
			var oMyTimeEntriesModel = this.getView().getModel("myEntriesModel");

			var aEntriesToSubmit = [];
			if (oSingleEntry) {
				oSelectedEntriesTable.setBusy(true);
				if (oSingleEntry.isRestricted === false && oSingleEntry.CostTypeId !== "5" && oSingleEntry.CostTypeId !== 5) {
					oSingleEntry.Indicator = "I";
					aEntriesToSubmit.push(oSingleEntry);
				}

				if (aEntriesToSubmit.length > 0) {
					that.TimeInstance.submitEntries(aEntriesToSubmit).then(function (results) {
						oMyTimeEntriesModel.setData(that.TimeInstance.getData());
						oMyTimeEntriesModel.refresh(true);
						oSelectedEntriesTable.setBusy(false);
						that.onSearchString();

					}
);
				} else {
					oSelectedEntriesTable.setBusy(false);
				}
			}
		},
		
		onSearchString: function (oEvent) {
			var sQuery = "";
			if (oEvent) {
				sQuery = oEvent.getParameter("query");

			}

			oController._filterEntries(sQuery);

		},

		_filterEntries: function (sQuery, sDPFromDate, sDPToDate, sActvtType) {
			var that = this;
			var aEntries = this.TimeInstance.getData().entries;
			var oSearchFilters = new Filter([new Filter("RecordDate", FilterOperator.Contains, sQuery),
				new Filter("ActvtDesc", FilterOperator.Contains, sQuery),
				new Filter("AccountName", FilterOperator.Contains, sQuery),
				new Filter("CostTypeName", FilterOperator.Contains, sQuery),
				new Filter("TaskName", FilterOperator.Contains, sQuery),

				new Filter("AccountName", FilterOperator.Contains, sQuery),
				new Filter("AccountID", FilterOperator.Contains, sQuery),
				new Filter("ActTypeDesc", FilterOperator.Contains, sQuery),
				new Filter("ActvtId", FilterOperator.Contains, sQuery),
				new Filter("CostTypeName", FilterOperator.Contains, sQuery),
				new Filter("CostTypeValue", FilterOperator.Contains, sQuery),

			]);
			var oActivityFilter = null;
			if (sActvtType) {
				oActivityFilter = new Filter("ActTypeDesc", FilterOperator.Contains, sActvtType);
			}
			var oDateFilter = null;
			if (sDPFromDate && sDPFromDate !== "" && sDPToDate && sDPToDate !== "") {
				oDateFilter = new Filter("RecordDate", FilterOperator.BT, sDPFromDate, sDPToDate);
			}
			var oSubmittedTableTitle = this.byId("idSubmittedEntriesTitle");
			var oSavedTableTitle = this.byId("idSavedEntriesTitle");
			var oFailedTableTitle = this.byId("idFailedEntriesTitle");

			var oSubmittedTable = this.byId("idSubmittedEntriesTable");
			this._setBindings([
					oSearchFilters
				],

				new sap.ui.model.Filter({
					path: "MtrUid",
					test: function (sMtrUid) {
						var oSubmittedEntry = aEntries.find(function (item) {
							return item.MtrUid === sMtrUid;
						});
						return that.formatter.filterSubmittedMyEntries(oSubmittedEntry, that);
					}
				}),
				oDateFilter, oSubmittedTable, oSubmittedTableTitle, oActivityFilter);

			var oSavedTable = this.byId("idSavedEntriesTable");
			this._setBindings([
					oSearchFilters
				],
				new sap.ui.model.Filter({
					path: "MtrUid",
					test: function (sMtrUid) {
						var oSavedEntry = aEntries.find(function (item) {
							return item.MtrUid === sMtrUid;
						});
						return that.formatter.filterSavedMyEntries(oSavedEntry, that);
					}
				}),
				oDateFilter, oSavedTable, oSavedTableTitle, oActivityFilter);

			var oFailedTable = this.byId("idFailedEntriesTable");
			this._setBindings([
					oSearchFilters
				],
				new sap.ui.model.Filter({
					path: "MtrUid",
					test: function (sMtrUid) {
						var oFailedEntry = aEntries.find(function (item) {
							return item.MtrUid === sMtrUid;
						});
						return that.formatter.filterFailedMyEntries(oFailedEntry, that);
					}
				}),
				oDateFilter, oFailedTable, oFailedTableTitle, oActivityFilter);
		},
		_setBindings: function (aFilters, oCustomFilter, oDateFilters, oTable, oTableTitle, oActivityFilter) {
			var oBinding = oTable.getBinding("items");
			if (oDateFilters) {
				aFilters.push(oDateFilters);
			}

			if (oActivityFilter) {
				aFilters.push(oActivityFilter);
			}
			if (oCustomFilter) {
				aFilters.push(oCustomFilter);
			}
			oBinding.filter(aFilters);
			// get filtered item's length
			var filterLength = oBinding.getLength();
			// set text in title with current length of items in table
			oTableTitle.setText("Entries(" + filterLength + ")");
		},
		onMessagePopoverPress: function (oEvent) {
			this._getMessagePopover().openBy(oEvent.getSource());
		},

		/**
		 * @private
		 */
		_getMessagePopover: function () {
			// create popover lazily
			var that = this;
			// var oMessagesModel = sap.ui.getCore().getModel("messages");
			// that.getView().setModel(oMessagesModel, "myEntriesMessages");
			if (!this._oMessagePopover) {
			
				var oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
				var oLink = new sap.m.Link({
					visible: "{= ${myEntriesMessages>type} === 'Error' ? true : false}",
					text: oResourceBundle.getText("msgCreateTicket"),
					href: oResourceBundle.getText("ticketURL"),
					target: "_blank"
				});

				var oButton = new sap.m.Button({
					icon: "sap-icon://delete",
					press: function (oEvent) {
						that.onClearMessages(oEvent);
					}
				});

				var oMessageTemplate = new sap.m.MessageItem({
					type: "{myEntriesMessages>type}",
					title: "{myEntriesMessages>title}",
					activeTitle: false,
					description: "{myEntriesMessages>description}",
					subtitle: "{myEntriesMessages>subtitle}",
					link: oLink
				});
				this._oMessagePopover = new sap.m.MessagePopover({
					items: {
						path: "myEntriesMessages>/",
						template: oMessageTemplate
					},
					headerButton: oButton,
					activeTitlePress: function (oEvent) {
						that.onPressMessage(oEvent);
					},
					initiallyExpanded: true
				}).addStyleClass("msgPopover");
				// this._oMessagePopover.setModel(oMessagesModel, "myEntriesMessages");
			}

			return this._oMessagePopover;
		},
		onClearMessages: function () {
			this.TimeInstance.getData()._data.Messages = [];
		},

		onSubmitTktPress: function () {
			var oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
			var URLHelper = MLibrary.URLHelper;
			URLHelper.redirect(oResourceBundle.getText("ticketURL"), true);
		},
		onEditFromMTR : function(oEvent){
			oEvent.getSource().openTimeDialog();
		},
		onAfterRendering : function(oEvent){
 			
			
			 setTimeout(() => {
				const  oTable = this.byId("idSavedEntriesTable");
       		 const aEntries = this.getModel("timeState").getProperty("/entries");
      
		
		 //this.getModel("timeState").setProperty("/entries",aEntries)
		 this.getModel("timeState").setProperty("/loading",false)
		 this.byId("idSavedEntriesTitle").setText("Entries" + "(" + aEntries.length + ")")
        if (oTable) {
            oTable.getBinding("items").refresh(true);
			//oTable.setBusy(false)
        }
    }, 4000); // wait 

		},
		openTaskTypeInfoPopup: function (oEvent) {
			debugger;
			const oSource = oEvent.getSource();
			const oView = this.getView();
			const oMyTimeEntriesModel = oView.getModel("timeState");
			//const oSettingModel = MTRUtil.getMTRSettingsModel();
			const aTasks = TimeMasterState.getInstance().getTasks();
			const bindingContext = oSource.getBindingContext("timeState") || {};
			if (this.openTasktypePopup) {
				this.openTasktypePopup.destroy();
				this.openTasktypePopup = null;
			}

			if (!this.openTasktypePopup) {
				this.openTasktypePopup = Fragment.load({
					id: oView.getId() + "_openTasktypePopup",
					name: "com.melody.activity.fragments.myEntries.TaskTypeName",
					controller: this
				}).then(function (oPopover) {
					this.openTasktypePopup = oPopover;
					oView.addDependent(oPopover);
					return oPopover;
				}.bind(this));
			}
			this.openTasktypePopup.then(function (oPopover) {
				let sTaskName = "";
				if (bindingContext) {
					const sPath = bindingContext.getPath();
					const oTaskData = oMyTimeEntriesModel.getProperty(sPath);
					const sTaskId = (oTaskData) ? oTaskData.task.taskId : "";
					const oTask = aTasks.find(function (item) {
						return sTaskId && item.taskId && item.taskId.toString() === sTaskId.toString();
					});
					sTaskName = (oTask) ? oTask.taskName : "";
				}
				oMyTimeEntriesModel.setProperty("/MTRTasktypeinfo", sTaskName);
				oPopover.openBy(oSource);
			});
		},
		onSortEntryDialogConfirm: function (oEvent) {
			var oSelectedEntriesTable = this._selectedTable();
			var mParams = oEvent.getParameters(),
				oBinding = oSelectedEntriesTable.getBinding("items"),
				sPath,
				bDescending,
				aSorters = [];
			sPath = mParams.sortItem.getKey();
			bDescending = mParams.sortDescending;
			aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
			// apply the selected sort and group settings
			oBinding.sort(aSorters);
		},
		onSelectEntries: function (oEvent) {
			var oControl = oEvent.getSource();
			var sTableId = oControl.data("Table");
			var oSelectedEntriesTable = this.byId(sTableId);
			var selectedContexts = oSelectedEntriesTable.getSelectedContexts();
			var deleteBtn, submitBtn;
			if (sTableId === "idSavedEntriesTable") {
				deleteBtn = this.byId("idDeleteBtn");
				
				submitBtn = this.byId("idSubmitBtn");

			} else if (sTableId === "idFailedEntriesTable") {
				deleteBtn = this.byId("idFailedDeleteBtn");
				
				submitBtn = this.byId("idFailedSubmitBtn");

			} else {
				deleteBtn = this.byId("idSubmittedDelBtn");
			}
			
			var bActivityRecording = TimeState.getInstance().getUser().activityRecording;
			if (selectedContexts.length > 0 && bActivityRecording === true) {
				if (sTableId === "idSavedEntriesTable" || sTableId === "idFailedEntriesTable") {
					deleteBtn.setProperty("enabled", true);
					//		editBtn.setProperty("enabled", true);
				} else {
					deleteBtn.setProperty("enabled", true);
				}

				var bEnableSubmit = false;
				for (var i = 0; i < selectedContexts.length; i++) {
					var oEntry = selectedContexts[i].getModel().getProperty(selectedContexts[i].getPath());
					if (oEntry.costType.id !== "5" && oEntry.costType.id !== 5 && bActivityRecording === true && oEntry.isSubmitEnabled) {
						bEnableSubmit = true;
					} else {
						bEnableSubmit = false;
						break;
					}
				}
				if (sTableId === "idSavedEntriesTable" || sTableId === "idFailedEntriesTable")
					submitBtn.setProperty("enabled", bEnableSubmit);
			} else {
				if (sTableId === "idSavedEntriesTable" || sTableId === "idFailedEntriesTable") {
					//	editBtn.setProperty("enabled", false);
					deleteBtn.setProperty("enabled", false);
					submitBtn.setProperty("enabled", false);
				} else {
					deleteBtn.setProperty("enabled", false);

				}
			}
		},

		onDataExport: function () {
			var oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
			var oSelectedEntriesTable = this._selectedTable();
			var filteredEntries = this._filterSelectedTabEntries();
			var dDate = new Date().toString();

			for (var i = 0; i < filteredEntries.length; i++) {
				filteredEntries[i].setTypeExportName();
				filteredEntries[i].setLocationName();
			}
			var bDescending = oSelectedEntriesTable.getBinding("items").aSorters[0].bDescending;
			if (bDescending === true) {
				filteredEntries.sort(function (a, b) {
					return b.recordDate - a.recordDate;
				});
			} else {
				filteredEntries.sort(function (a, b) {
					return a.recordDate - b.recordDate;
				});
			}
			var aCols = this._createColumnConfig();
			var oSettings = {
				workbook: {
					columns: aCols
				},
				dataSource: filteredEntries,
				fileName: "View My Entries_" + dDate + ".xlsx"
			};
			new Spreadsheet(oSettings)
				.build()
				.then(function () {
					MessageToast.show(oResourceBundle.getText("spreadsheetExportSuccess"));
				});
		},

		_filterSelectedTabEntries: function () {
			var oIconTabBar = this.byId("idIconTabBar");
			var sSelectedTab = oIconTabBar.getSelectedKey();
			var oDayWeekTimesheetModel = this.getView().getModel("timeState");
			var aEntries = oDayWeekTimesheetModel.getProperty("/entries");
			var filteredEntries;
			var oSettingsModel = sap.ui.getCore().getModel("mtrSettings");
			var aTasks = TimeMasterState.getInstance().getTasks();
			if (sSelectedTab === "submittedEntries") {
				filteredEntries = aEntries.filter(function (item) {
					return item.status.id === "4";
				});
				for (var i = 0; i < filteredEntries.length; i++) {
					var oTask = aTasks.find(function (item) {
						return item.taskId.toString() === filteredEntries[i].task.taskId.toString();
					});
					if (oTask) {
						filteredEntries[i].task.taskName = oTask.taskName;
					}
				}

			} else if (sSelectedTab === "savedEntries") {
				filteredEntries = aEntries.filter(function (item) {
					return item.status.id === "1";
				});
			} else if (sSelectedTab === "failedEntries") {
				filteredEntries = aEntries.filter(function (item) {
					return item.status.id === "3";
				});
			} else if (sSelectedTab === "inQueueEntries") {
				filteredEntries = aEntries.filter(function (item) {
					return item.status.id === "2";
				});
			}
			return filteredEntries;
		},

		_createColumnConfig: function () {
			//var oSettingsModel = MTRUtil.getMTRSettingsModel();
			var timeMatrics = TimeState.getInstance().getUser().timeMatrics;
			var sDuration = (timeMatrics === "H") ? "Duration(hrs)" : "Duration(days)";
			var oSelectedEntriesTable = this._selectedTable();
			var selTableEntry = oSelectedEntriesTable.getParent().getKey();
			var aCols = [];
			aCols.push({
				label: "Date",
				type: "string",
				property: "FormattedRecordDate",
				width: 50,
				textAlign: "begin"
			});

			aCols.push({
				label: "Task Name",
				type: "string",
				property: "taskName",
				width: 45,
				textAlign: "begin"
			});

			aCols.push({
				label: "Activity Name",
				type: "string",
				property: "ActTypeDesc",
				width: 45,
				textAlign: "begin"
			});

			aCols.push({
				label: "Activity Id",
				type: "string",
				property: "ActvtId",
				width: 45,
				textAlign: "begin"
			});
			aCols.push({
				label: "Account Name",
				type: "string",
				property: "AccountName",
				width: 25,
				textAlign: "begin"
			});
			aCols.push({
				label: "Account Id",
				type: "string",
				property: "AccountID",
				width: 25,
				textAlign: "begin"
			});
			aCols.push({
				label: "Opportunity",
				type: "string",
				property: "TypeExportName",
				width: 50,
				textAlign: "begin"
			});
			aCols.push({
				label: sDuration,
				type: "number",
				property: "duration/current",
				width: 10,
				scale: 1,
				textAlign: "begin"
			});
			if (selTableEntry === "failedEntries") {
				aCols.push({
					label: "Error Message",
					type: "string",
					property: "WorkDurationValueStateText",
					width: 50,
					textAlign: "begin"
				});
			}
			return aCols;
		},


	});
});