// @ts-nocheck
sap.ui.define(
  [
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/json/JSONModel",
    "com/melodylib/core/util/Helper",
    "com/melodylib/core/enum/Actions",
    "com/melodylib/core/classes/Variant",
    "com/melody/activity/util/formatter",
    "com/melodylib/activity/state/DBRState",
    "com/melody/activity/enum/ActivityActions",
    "com/melodylib/integration/state/AccountState",
    "com/melody/activity/controller/BaseController",
    "com/melodylib/activity/state/ActivityMasterState",
  ],
  function (
    Filter,
    FilterOperator,
    JSONModel,
    Helper,
    Actions,
    Variant,
    formatter,
    DBRState,
    ActivityActions,
    AccountState,
    BaseController,
    ActivityMasterState
  ) {
    "use strict";

    return BaseController.extend("com.melody.activity.controller.MyDBRs", {
      formatter: formatter,
      onInit: function () {
        this.initializeStates();
        this.getDBRListVariants();
        this.dbrState = DBRState.getInstance();
        this.activityMasterState = ActivityMasterState.getInstance();
        this.accountState = AccountState.getInstance();
        this.oRouter = this.getOwnerComponent().getRouter();
        const filterProperties = Helper.getFilterProperties(
          ActivityActions.myDBRListFilters
        );
        const data = {
          variant: {
            configurations: {
              properties: filterProperties,
              sort: {
                sortBy: "",
                sortOrderDesc: false,
              },
              group: {
                groupBy: "",
                groupOrderDesc: false,
              },
            },
          },
          Users: {
            busy: false,
            results: [],
          },
          Accounts: {
            busy: false,
            results: [],
          },
        };
        data.variant.columns = this.getColumnsArray(
          data.variant.configurations.properties
        );
        const model = new JSONModel(data);
        this.setModel(model);

        //DBR HEADER
        const headerModel = new JSONModel({ headerExpanded: false });
        const headerExpandedBinding = new sap.ui.model.Binding(
          headerModel,
          "/headerExpanded",
          headerModel.getContext("/headerExpanded")
        );
        headerExpandedBinding.attachChange((event) => {
          this.adjustScrollContainerHeight();
        });
        this.setModel(headerModel, "dbrHeader");

        this.oRouter.attachRoutePatternMatched(
          this.onRoutePatternMatched,
          this
        );
        this.getView().addStyleClass(
          this.getOwnerComponent().getContentDensityClass()
        );
      },

      onRoutePatternMatched: function (event) {
        if (event.getParameter("name") === "MyDBRs") {
          // this.onRouteMatched(event);
          this.initializeStates();
          // this.getDBRsList();
          const dbrHeaderModel = this.getModel("dbrHeader");
          dbrHeaderModel.setProperty("/headerExpanded", true);

          //Setting the scroll event to the scroll container
          const scrollContainer = this.getView().byId("dbrListScrollContainer");

          if (scrollContainer) {
            window.addEventListener("resize", () => {
              this.adjustScrollContainerHeight();
            });
            scrollContainer.attachBrowserEvent(
              "scroll",
              this.onScrollContainerScroll.bind(this)
            );
            setTimeout(() => this.adjustScrollContainerHeight(), 100);
          }

          dbrHeaderModel.refresh();
        }
      },

      /********************** DBR LIST TABLE FUNTIONALITY STARTS HERE ***********************************/

      /**
       * @author DARSHAN
       * @function adjustScrollContainerHeight
       * @description function to set Height based on screen size
       * @param {Object} event
       */
      adjustScrollContainerHeight: function (event) {
        try {
          let scrollContainerTop;
          const scrollContainer = this.getView().byId("dbrListScrollContainer");

          if (!scrollContainer) {
            return;
          }

          // Calculate the available height for the ScrollContainer
          let windowHeight = window.innerHeight;
          if (
            typeof scrollContainer.getDomRef === "function" &&
            typeof scrollContainer.getDomRef()?.getBoundingClientRect ===
              "function"
          ) {
            scrollContainerTop = scrollContainer
              .getDomRef()
              .getBoundingClientRect().top;

            let availableHeight = windowHeight - scrollContainerTop;
            if (windowHeight <= 610 && availableHeight <= 290) {
              availableHeight = 290;
            }
            if (windowHeight > 850 && availableHeight < 450) {
              availableHeight = 570;
            }
            // Set the height of the ScrollContainer
            // console.log("iWindowHeight", windowHeight);
            // console.log("HEIGHT IS SET", availableHeight);
            scrollContainer.setHeight(availableHeight + "px");
          }
        } catch (error) {
          console.log("ERROR IN adjustScrollContainerHeight : ", error);
        }
      },

      /**
       * @author DARSHAN
       * @function onScrollContainerScroll
       * @description function to handle scroll in the scrol container
       * @param {Object} event
       * IIFE and Throlling is used to handle the scroll methods for service calls
       */
      onScrollContainerScroll: function (event) {
        let lastCalled = 0;
        let scrollContainer = event.currentTarget;

        let bIsScrolledToBottom =
          scrollContainer.scrollTop + scrollContainer.clientHeight >=
          scrollContainer.scrollHeight;

        //SCROLL AT BOTTOM
        if (bIsScrolledToBottom) {
          const model = this.getModel();
          const activeVariant = model.getProperty("/variant");
          let dbrState = this.getModel("dbrState");
          let totalDBR = dbrState.getProperty("/totalDBR") || "0";
          let dbrList = dbrState.getProperty("/dbrList") || [];

          //Number Validation
          if (totalDBR) {
            totalDBR = parseInt(totalDBR);
            if (isNaN(totalDBR)) {
              totalDBR = 0;
            }
          }

          //VARIANT UPDATES
          activeVariant.configurations.skip = dbrList.length;
          activeVariant.configurations.inlineCount = false;

          console.log("SCROLL IS AT THE BOTTOM");

          if (dbrList.length !== totalDBR) {
            return (() => {
              const atPresent = new Date().getTime();
              if (atPresent - lastCalled >= 5000) {
                lastCalled = atPresent;
                let isManager = false;
                if ("checkForManagerVariant" in activeVariant) {
                  isManager = activeVariant.checkForManagerVariant();
                }
                //DBR CALL
                this.dbrState.getDBRs(activeVariant.configurations, isManager);
              }
            })();
          }
        }
      },

      /********************** DBR LIST TABLE FUNTIONALITY ENDS HERE **************************************/

      //function to get the DBR List //TODO: Initialization Call
      getDBRsList: async function () {
        const model = this.getModel();
        const activeVariant = model.getProperty("/variant") || {};
        let isManager = false;
        if ("checkForManagerVariant" in activeVariant) {
          isManager = activeVariant.checkForManagerVariant();
        }
        activeVariant.configurations.skip = 0;
        activeVariant.configurations.inlineCount = true;
        await this.dbrState.getDBRs(activeVariant.configurations, isManager);
      },

      /**
       * @author INDU
       * @function onOpenPersonalization
       * @description function to open personalization dialog
       */
      onOpenPersonalization: async function () {
        const model = this.getModel();
        let variant = model.getProperty("/variant");
        model.setProperty(
          "/columnsBackUp",
          JSON.parse(JSON.stringify(variant))
        );
        if (!this.personalizationDialog) {
          this.personalizationDialog = await this.loadFragment({
            name: "com.melody.activity.fragments.list.Personalization",
          });
        }
        this.personalizationDialog.open();
      },

      /**
       * @author INDU
       * @function onSearchPersonalization
       * @description function to search in personalization dialog
       * @param {Object} event
       */
      onSearchPersonalization: function (event) {
        const searchParam = event.getSource().getValue();
        const personalizationList = this.personalizationDialog.getContent()[0];
        const itemsBinding = personalizationList.getBinding("items");
        let filters = [
          new Filter("label", FilterOperator.Contains, searchParam),
        ];
        itemsBinding.filter(filters);
      },

      /**
       * @author INDU
       * @function onClosePersonalization
       * @description function to close personalization dialog
       */
      onClosePersonalization: function () {
        this.personalizationDialog.close();
      },

      /**
       * @author INDU
       * @function onCancelPersonalization
       * @description function to cancel personalization dialog
       */
      onCancelPersonalization: function () {
        const model = this.getView().getModel();
        let columnsBackUp = model.getProperty("/columnsBackUp");
        model.setProperty("/variant", columnsBackUp);
        this.personalizationDialog.close();
      },

      /**
       * @author INDU
       * @function onSelectPersonalization
       * @description function to set selected to the selected column in the columns of Activity List
       * @param {Object} event
       */
      onSelectPersonalization: function (event) {
        let length = event.getSource().getSelectedContextPaths()?.length;
        const listItem = event.getParameter("listItem");
        if (length < 7) {
          const selected = listItem.getProperty("selected");
          const model = this.getView().getModel();
          model.setProperty(
            "/variant/configurations/properties/" +
              listItem.data("key") +
              "/selected",
            selected
          );
        } else {
          sap.m.MessageToast.show("Please select max 6 columns");
          listItem.setSelected(false);
        }
      },

      /********************** FILTER BAR FUNTIONALITY STARTS HERE ***********************************/
      onOpenActivityFilter: async function (event) {
        const source = event.getSource();
        const customData = source?.getCustomData()[0];
        const key = customData?.getKey();
        if (!this.activityFilterDialog) {
          this.activityFilterDialog = await this.loadFragment({
            name: "com.melody.activity.fragments.list.mydbr.ActivityIDLookup",
          });
        }
        this.checkSelectionsInDialog(
          key,
          "activityState",
          this.activityFilterDialog
        );
        this.activityFilterDialog.open();
      },

      onSelectActivityFilter: function (event) {
        const activityState =
          this.getOwnerComponent().getModel("activityState");
        const authState = this.getModel("authState");

        this.addTokens(event, activityState, "activity");
        this.getModel().refresh(true);
      },

      onOpenAccountFilter: async function (event) {
        const model = this.getModel();
        model.setProperty("/Accounts/results", []);
        const source = event.getSource();
        const customData = source?.getCustomData()[0];
        const key = customData?.getKey();
        if (!this.accountFilterDialog) {
          this.accountFilterDialog = await this.loadFragment({
            name: "com.melody.activity.fragments.list.AccountLookup",
          });
        }
        this.accountFilterDialog.open();
      },

      onSearchAccountFilter: async function (event) {
        const model = this.getModel();
        let accounts = [];
        const searchParam = event.getParameter("value");
        model.setProperty("/Accounts/busy", true);
        if (searchParam) {
          accounts = await this.accountState.search(searchParam);
        }
        model.setProperty("/Accounts/results", accounts);
        this.checkSelectionsInDialog("account", null, this.accountFilterDialog);
        model.setProperty("/Accounts/busy", false);
      },

      onSelectAccountFilter: function (event) {
        const model = this.getModel();
        this.addTokens(event, model, "account");
        this.getModel().refresh(true);
      },

      onOpenUserFilter: async function (event) {
        const model = this.getModel();
        const source = event.getSource();
        const customData = source?.getCustomData()[0];
        const key = customData?.getKey();
        model.setProperty("/key", key);
        model.setProperty("/Users/results", []);
        if (!this.userFilterDialog) {
          this.userFilterDialog = await this.loadFragment({
            name: "com.melody.activity.fragments.list.mydbr.UserLookup",
          });
        }
        this.userFilterDialog.open();
      },

      onSearchUser: async function (event) {
        const model = this.getModel();
        const key = model.getProperty("/key");
        let users = [];
        const searchParam = event.getParameter("value");
        model.setProperty("/Users/busy", true);
        if (searchParam) {
          const params = {
            search: searchParam,
          };
          users = await this.activityMasterState.getUsersBySearch(params);
        }
        model.setProperty("/Users/results", users);
        this.checkSelectionsInDialog(key, null, this.userFilterDialog);
        model.setProperty("/Users/busy", false);
      },

      onSelectUsers: function (event) {
        const model = this.getModel();
        const key = model.getProperty("/key");
        this.addTokens(event, model, key);
        this.getModel().refresh(true);
      },

      /**
       * @author  INDU
       * @function handleDateChange
       * @description function to set the value state of the date filter
       * @param {Event} event
       */
      handleDateChange: function (event) {
        let valid = event.getParameter("valid");
        const source = event.getSource();
        if (!source.getValue()) {
          source.setValueState("None");
        } else {
          if (valid && event.getParameter("to") && event.getParameter("from")) {
            source.setValueState("None");
          } else {
            source.setValueState("Error");
            source.setValueStateText("Please Provide Date Range");
          }
        }
        this.onModifyFilter(event);
      },

      addTokens: function (event, contextModel, key) {
        const model = this.getModel();
        const selctions = [];
        const selectedContexts = event.getParameter("selectedContexts");
        selectedContexts.forEach((context) => {
          let path = context.sPath;
          selctions.push({
            value1: contextModel.getProperty(path).id,
          });
        });
        model.setProperty(
          "/variant/configurations/properties/" + key + "/values",
          selctions
        );
        this.setVariantModifiedKeys({
          key: "PROPERTIES",
          property: key,
        });
        model.refresh(true);
      },

      onRemoveTokens: function (event, key) {
        const model = this.getModel();
        const removedTokens = event.getParameter("removedTokens") || [];
        if (removedTokens.length) {
          removedTokens.forEach((token) => {
            let bindingContext = token.getBindingContext();
            if (bindingContext) {
              let path = bindingContext.getPath();
              let contextObject = bindingContext.getObject() || {};
              let selectedTokens =
                model.getProperty(
                  "/variant/configurations/properties/" + key + "/values"
                ) || [];
              let index = selectedTokens.findIndex(
                (item) => item.value1 === contextObject.value1
              );
              if (index !== -1) {
                selectedTokens.splice(index, 1);
              }
              model.setProperty(
                "/variant/configurations/properties/" + key + "/values",
                selectedTokens
              );
              this.setVariantModifiedKeys({
                key: "PROPERTIES",
                property: key,
              });
              this.getModel().refresh(true);
            }
          });
        }
      },

      onMultiInputTokenUpdate: function (event, filterkey) {
        const type = event.getParameter("type");
        if (type === sap.m.Tokenizer.TokenUpdateType.Removed) {
          this.onRemoveTokens(event, filterkey);
        }
      },

      /**
       * @author  DARSHAN
       * @function onMultiComboBoxSelectionFinished
       * @description function to handle multi comboBox change
       * @param {Event} event
       */
      onMultiComboBoxSelectionFinished: function (event) {
        this.onModifyFilter(event);
      },

      /**
       * @author  INDU,DARSHAN
       * @function onModifyFilter
       * @description
       * @param {Event} event
       */
      onModifyFilter: function (event) {
        const authState = this.getModel("authState");
        const source = event.getSource();
        const customData = source?.getCustomData()[0];
        const key = customData?.getKey();
        this.setVariantModifiedKeys({
          key: "PROPERTIES",
          property: key,
        });
        this.getModel().refresh(true);
      },

      /**
       * @author  INDU
       * @function checkSelectionsInDialog
       * @description function to check previous selections in MultiInputs
       * @param {String} key
       * @param {String} modelName
       * @param {Object} dialog
       */
      checkSelectionsInDialog: function (key, modelName, dialog) {
        let name;
        if (modelName) {
          name = modelName;
        }
        const model = this.getModel();
        let tokens = model.getProperty(
          "/variant/configurations/properties/" + key + "/values"
        );
        dialog._removeSelection();
        if (tokens.length) {
          let contextModel = this.getModel(name);
          // if (!contextModel) {
          //   contextModel = model;
          // }
          const selectedKeys = tokens.map((token) => token.value1);
          const items = dialog.getItems();
          items.forEach((item) => {
            let bindingPath = item.getBindingContext(name).sPath;
            let id = contextModel.getProperty(bindingPath).id;
            if (selectedKeys.includes(id)) {
              item.setSelected(true);
            }
          });
        }
      },

      /**
       * @author INDU, DARSHAN
       * @function onClearFilters
       * @description function to clear the fitlers and also to set modified to true in variant management control
       * @param {Object} data
       */
      onClearFilters: function () {
        const model = this.getModel();
        const authState = this.getModel("authState");
        const activeVariant = model.getProperty("/variant");
        const filterProperties = Helper.getFilterProperties(
          ActivityActions.myDBRListFilters
        );

        //Clearing only Filter Properties
        activeVariant.configurations.properties = filterProperties;
        model.setProperty("/variant", activeVariant);
        this.executeDBRFilters();

        //show modifier in variant Management control
        // const variantControl = this.getView().byId("listVariantMangement");
        // if (variantControl) {
        //   variantControl.setModified(true);
        // }
      },

      /********************** FILTER BAR FUNTIONALITY ENDS HERE ***********************************/

      /********************** VIEW SETTINGS SORT/GROUP STARTS HERE ***********************************/

      /**
       * @author INDU
       * @function onOpenViewSettings
       * @description function to handle opening of view settings dialog in list view
       * @param {Event} event
       */
      onOpenViewSettings: async function (event) {
        const model = this.getModel();
        const sortConfig = model.getProperty("/variant/configurations/sort");
        const groupConfig = model.getProperty("/variant/configurations/group");
        if (!this.viewSettingsDialog) {
          this.viewSettingsDialog = await this.loadFragment({
            name: "com.melody.activity.fragments.list.mydbr.TableViewSettings",
          });
        }
        this.viewSettingsDialog.open();

        //TODO: NEED TO CHANGE THIS
        const sortGroupDialog = this.getView().byId("dbrListSortGroupDialog");
        if (sortGroupDialog) {
          if (groupConfig?.groupBy) {
            sortGroupDialog.setSelectedGroupItem(groupConfig.groupBy);
          }

          if (sortConfig?.sortBy) {
            sortGroupDialog.setSelectedSortItem(sortConfig.sortBy);
          }
        }
      },

      /**
       * @author INDU, DARSHAN
       * @function onDBRListSortGroupConfirm
       * @description function to handle sorting and grouping in the table based on property selected
       * @param {Event} event
       * @param {String} tableId
       */
      onDBRListSortGroupConfirm: function (event, tableId) {
        const model = this.getModel();
        const params = event.getParameters();
        const sortConfig = model.getProperty("/variant/configurations/sort");
        const groupConfig = model.getProperty("/variant/configurations/group");

        if (params?.sortItem) {
          const key = params.sortItem.getKey();
          const isDescending = params.groupDescending;
          sortConfig.sortBy = key;
          sortConfig.sortOrderDesc = isDescending;
        } else {
          sortConfig.sortBy = "";
          sortConfig.sortOrderDesc = false;
        }

        if (params?.groupItem) {
          const key = params.groupItem.getKey();
          const isDescending = params.sortDescending;
          groupConfig.groupBy = key;
          groupConfig.groupOrderDesc = isDescending;
        } else {
          groupConfig.groupBy = "";
          groupConfig.groupOrderDesc = false;
        }

        this.setVariantModifiedKeys({
          key: "SORT",
          property: "",
        });
        this.setVariantModifiedKeys({
          key: "GROUP",
          property: "",
        });
        model.setProperty("/variant/configurations/sort", sortConfig);
        model.setProperty("/variant/configurations/group", groupConfig);
        model.refresh();
        this.handleSortGroupDialogConfirm(event, tableId);
      },

      /********************** VIEW SETTINGS SORT/GROUP ENDS HERE ***********************************/
      /********************** VARIANT MANAGEMENT STARTS HERE ***********************************/

      /**
       * @author DARSHAN, INDU
       * @function getDBRListVariants
       * @description function to get logged-in users variants to filter the data
       */
      getDBRListVariants: async function (options) {
        try {
          await this.variantState.getVariants({
            groupName: Actions.variantGroupTypes.dbr,
          });
          const model = this.getModel();
          const variantState = this.getModel("variantState");
          let defaultVariant =
            variantState.getProperty("/defaultVariant") || {};

          if (defaultVariant && defaultVariant?.id !== "standard") {
            //CHECK FOR NEW PROPERTY
            const updatedVariant = this.checkNewFilterProperty(
              defaultVariant,
              Actions.variantGroupTypes.dbr
            );
            if (updatedVariant) {
              defaultVariant = updatedVariant;
            }

            //UPDATE PERSONALIZATION
            defaultVariant.columns = this.getColumnsArray(
              defaultVariant.configurations.properties
            );
            model.setProperty("/variant", defaultVariant);
            model.setProperty(
              "/variantBackUp",
              JSON.parse(JSON.stringify(defaultVariant))
            );
            model.refresh(true);
          } else {
            //CASE WHEN NO VARIANTS ARE PRESENT
            const variant = this.getVariant(Actions.variantGroupTypes.dbr);
            defaultVariant.configurations = variant.configurations;
            defaultVariant.columns = this.getColumnsArray(
              defaultVariant.configurations.properties
            );
            model.setProperty("/variant", defaultVariant);
            model.setProperty(
              "/variantBackUp",
              JSON.parse(JSON.stringify(defaultVariant))
            );
          }
        } catch (error) {
          Helper.showMessage("Something went wrong. Please try again");
          console.log("ERROR  IN getDBRListVariants : ", error);
        }
      },

      /**
       * @author DARSHAN, INDU
       * @function onSaveDBRListVariant
       * @description function to handle "save as" in variant management control
       * @param {Event} event
       */
      onSaveDBRListVariant: async function (event) {
        try {
          const params = event.getParameters();
          const variantState = this.getModel("variantState");
          const model = this.getModel();
          let configurations = model.getProperty("/variant/configurations");
          const variant = new Variant();

          await this.variantState.setVariant({
            params: params,
            variant: variant,
            filters: configurations,
            viewName: Actions.variantGroupTypes.dbr,
          });
          await this.getDBRListVariants({
            groupName: Actions.variantGroupTypes.dbr,
            variantId: "",
          });
          this.setVariantModifiedKeys({}, true);
          this.executeDBRFilters();
        } catch (error) {
          Helper.showMessage("Something went wrong. Please try again");
          console.log("ERROR IN onSaveDBRListVariant : ", error);
        }
      },

      /**
       * @author DARSHAN, INDU
       * @function onSelectDBRListVariant
       * @description function to handle selections of variants from the variant list
       * @param {Event} event
       */
      onSelectDBRListVariant: function (event) {
        try {
          const variantState = this.getModel("variantState");
          const model = this.getModel();
          const variants = variantState.getProperty("/variants/dbr") || [];
          const params = event.getParameters();
          const variantKey = params.key;
          let variant =
            variants.find((data) => {
              return data.id === variantKey;
            }) || false;

          //CHECK FOR NEW PROPERTY
          const updatedVariant = this.checkNewFilterProperty(
            variant,
            Actions.variantGroupTypes.dbr
          );
          if (updatedVariant) {
            variant = updatedVariant;
          }

          //UPDATE PERSONALIZATION
          variant.columns = this.getColumnsArray(
            variant.configurations.properties
          );
          model.setProperty("/variant", variant);
          model.setProperty(
            "/variantBackUp",
            JSON.parse(JSON.stringify(variant))
          );
          const sortConfig = model.getProperty("/variant/configurations/sort");
          const groupConfig = model.getProperty(
            "/variant/configurations/group"
          );
          if (variant?.executeOnSelect) {
            this.executeDBRFilters(); //ADD HERE METHOD TO FIRE THE FILTERS
            this.setSortGroupToTable({
              tableId: "dbrTable",
              sortConfig,
              groupConfig,
            });
          }
          model.refresh(true);
          variantState.refresh();
        } catch (error) {
          Helper.showMessage("Something went wrong. Please try again");
          console.log("ERROR IN onSelectDBRListVariant : ", error);
        }
      },

      /**
       * @author DARSHAN, INDU
       * @function onManageDBRListVariant
       * @description function to handle "save" in "Manage" option in variant management control
       * @param {Event} event
       */
      onManageDBRListVariant: async function (event) {
        try {
          let updateVariant = await this.variantState.manageVariant(
            event,
            Actions.variantGroupTypes.dbr
          );
          if (updateVariant) {
            await this.getDBRListVariants({
              groupName: Actions.variantGroupTypes.dbr,
              variantId: "",
            });
            this.setVariantModifiedKeys({}, true);
            this.executeDBRFilters();
          }
        } catch (error) {
          Helper.showMessage("Something went wrong. Please try again");
          console.log("ERROR IN onManageDBRListVariant : ", error);
        }
      },
      /********************** VARIANT MANAGEMENT ENDS HERE ***********************************/
    });
  }
);
