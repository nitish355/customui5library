// @ts-nocheck
sap.ui.define(
    [
      "com/melody/activity/controller/BaseController"
    ],
    function (BaseController) {
      "use strict";
  
      return BaseController.extend("com.melody.activity.controller.NoAuthorization", {
        onInit: function () {
          
        },
        handleClose: function () {
			window.history.go(-1);
		}
  
        
      });
    }
  );
  