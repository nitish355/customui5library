// @ts-nocheck
sap.ui.define(
  [
    "sap/ui/model/Sorter",
    "sap/ui/model/Filter",
    "sap/ui/core/Fragment",
    "sap/ui/core/UIComponent",
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/FilterOperator",
    "com/melodylib/core/util/Helper",
    "com/melody/activity/model/Form",
    "com/melodylib/core/enum/Actions",
    "com/melodylib/core/state/AuthState",
    "com/melodylib/core/classes/Variant",
    "com/melodylib/core/state/VariantState",
    "com/melody/activity/enum/ActivityActions",
    "com/melody/activity/service/MasterService",
    "com/melodylib/core/model/CoreLibraryModel",
    "com/melodylib/integration/state/OpportunityState",
  ],
  /**
   * @param {typeof sap.ui.core.mvc.Controller} Controller
   */
  function (
    Sorter,
    Filter,
    Fragment,
    UIComponent,
    Controller,
    FilterOperator,
    Helper,
    Form,
    CoreLibActions,
    AuthState,
    Variant,
    VariantState,
    ActivityActions,
    MasterService,
    CoreLibraryModel,
    OpportunityState
  ) {
    "use strict";

    return Controller.extend("com.melody.activity.controller.BaseController", {
      onRouteMatched: function (oEvent) {
        const activityListModel =
          this.getOwnerComponent().getModel("activityListModel");
        const name = oEvent.getParameter("name");
        let layout;
        switch (name) {
          case "list":
            layout = "OneColumn";
            break;
          case "detail":
            layout = "TwoColumnsMidExpanded";
            break;
          case "registerForm":
            layout = "EndColumnFullScreen";
            break;
          case "noAuthorization":
            layout = "EndColumnFullScreen";
            break;
          case "MyEntries":
            layout = "EndColumnFullScreen";
            break;
          case "MyOpportunities":
            layout = "EndColumnFullScreen";
            break;
          case "MyDBRs":
            layout = "EndColumnFullScreen";
            break;
          case "drafts":
            layout = "EndColumnFullScreen";
            break;
          default:
            layout = "OneColumn";
        }
        activityListModel.setProperty("/layout", layout);
        activityListModel.setProperty("/view", name);
        this._currentView = this.getView();
        this.handleBrowserNav();
      },

      getResourceBundle: function () {
        return this.getOwnerComponent().getModel("i18n").getResourceBundle();
      },

      getRouter: function () {
        return UIComponent.getRouterFor(this);
      },

      getUserData: function () {
        const userData = CoreLibraryModel.getProperty("/oUserData");
        return userData;
      },

      /**
       * Convenience method for getting the view model by name in every controller of the application.
       * @public
       * @param {string} sName the model name
       * @returns {sap.ui.model.Model} the model instance
       */
      getModel: function (name) {
        return this.getView().getModel(name);
      },

      /**
       * Convenience method for setting the view model in every controller of the application.
       * @public
       * @param {sap.ui.model.Model} oModel the model instance
       * @param {string} sName the model name
       * @returns {sap.ui.mvc.View} the view instance
       */
      setModel: function (model, name) {
        this.getView().setModel(model, name);
      },

      // function to close all the open dialogs while exiting the screen.
      handleBrowserNav: function () {
        if (sap.m.InstanceManager.getOpenDialogs().length)
          sap.m.InstanceManager.closeAllDialogs();
      },

      // function to set the form path on tab change in create mode and on load of detail screen
      setFormPath: function (path) {
        const activityFormModel =
          this.getOwnerComponent().getModel("activityFormModel");
        activityFormModel.setProperty("/formPath", path);
      },

      // function to handle Non ORE user authentication and navigate to No Authroziation screen
      handleAuthCheck: function (view) {
        const appSettings = this.getOwnerComponent().getModel("appSettings");
        let isNonOreUser = appSettings.getProperty("/isNonOreUser");
        if (isNonOreUser && view === "registerForm")
          this.getRouter().navTo("noAuthorization");
        else return;
      },

      //no need
      fnCreateFragment: function (fragmentName, path) {
        let fragment = Fragment.load({
          name: `com.melody.activity.fragments.${path}.${fragmentName}`,
          controller: this,
        }).then(
          function (dialog) {
            this._currentView.addDependent(dialog);
            return dialog;
          }.bind(this)
        );

        return fragment;
      },

      /**
       * @author DARSHAN
       * @function initializeStates
       * @description function to get model and return
       */
      initializeStates() {
        if (!this.authState) {
          this.authState = AuthState.getInstance();
        }
        if (!this.variantState) {
          this.variantState = VariantState.getInstance();
        }
        if (!this.opportunityState) {
          this.opportunityState = OpportunityState.getInstance();
        }
      },

      /**
       * @author DARSHAN
       * @function triggerListTableFunctions
       * @description function to trigger any other fucntions once after initialization is completed from lib.js from core library
       * Need to improve this method and make more generic and make based on view
       */
      triggerListTableFunctions: function () {
        if (!this?.opportunityState) {
          this.initializeStates();
        }
        const activityListModel = this.getModel("activityListModel");
        const viewName = activityListModel.getProperty("/view");
        switch (viewName) {
          case "MyOpportunities":
            this.getOpportuntityListLookup();
            break;
          default:
        }
      },

      /********************** VIEW SETTINGS DIALOG STARTS HERE ***********************************/

      /**
       * @author DARSHAN
       * @function handleSortGroupDialogConfirm
       * @description function to handle sorting and grouping in the table based on property selected
       * @param {Event} event
       * @param {String} tableId
       */
      handleSortGroupDialogConfirm: function (event, tableId) {
        let groupData;
        const options = [];
        const params = event.getParameters();
        const table = this.getView().byId(tableId);
        const itemsBinding = table.getBinding("items");

        if (params.groupItem) {
          const key = params.groupItem.getKey();
          let groupKey = key.split("/")[0];
          const isDescending = params.groupDescending;
          groupData = this._groupFunction()[groupKey];
          options.push(new Sorter(key, isDescending, groupData));
        }

        if (params.sortItem) {
          const key = params.sortItem.getKey();
          const isDescending = params.sortDescending;
          options.push(new Sorter(key, isDescending));
        }

        itemsBinding.sort(options);
      },

      /**
       * @author DARSHAN
       * @function setSortGroupToTable
       * @description function to handle sorting and grouping in the table based on variant selected
       * @param {String} tableId
       */
      setSortGroupToTable: function (options) {
        const settings = [];
        let groupData;
        const table = this.getView().byId(options.tableId);
        const itemsBinding = table.getBinding("items");

        if (options?.groupConfig?.groupBy) {
          let groupKey = options.groupConfig.groupBy.split("/")[0];
          groupData = this._groupFunction()[groupKey];
          settings.push(
            new Sorter(
              options.groupConfig.groupBy,
              options.groupConfig.groupOrderDesc,
              groupData
            )
          );
        }

        if (options?.sortConfig?.sortBy) {
          settings.push(
            new Sorter(
              options.sortConfig.sortBy,
              options.sortConfig.sortOrderDesc,
              groupData
            )
          );
        }
        if (itemsBinding) {
          itemsBinding.sort(settings);
        }
      },

      /********************** VIEW SETTINGS DIALOG ENDS HERE ***********************************/

      /**
       * @author INDU, BALWANT
       * @function getVariant
       * @description function to set up variants to filter the data in list page
       */
      getVariant: function (listType) {
        let filterProperty;
        let configurations = {
          properties: "",
          search: "",
          sort: {
            sortBy: "",
            sortOrderDesc: false,
          },
          group: {
            groupBy: "",
            groupOrderDesc: false,
          },
        };
        switch (listType) {
          case CoreLibActions.variantGroupTypes.dbr:
            filterProperty = ActivityActions.myDBRListFilters;
            break;
          case CoreLibActions.variantGroupTypes.opportunity:
            filterProperty = ActivityActions.myOpportunityListFilters;
            break;
          default: //ACTIVITY LIST
            filterProperty = ActivityActions.myActivityListFilters;
            configurations.tab = "00";
            break;
        }
        const filterProperties = Helper.getFilterProperties(filterProperty);
        configurations.properties = filterProperties;
        return {
          configurations: configurations,
          columns: this.getColumnsArray(configurations.properties),
        };
      },

      /**
       * @author INDU, BALWANT
       * @function getColumnsArray
       * @description function to generate the columns data for personalization
       * @param {Event} event
       */
      getColumnsArray: function (data) {
        const columns = Object.values(
          Object.keys(data).reduce(function (result, key) {
            result[key] = {
              key: key,
              label: data[key].label,
              selected: data[key].selected,
            };
            return result;
          }, {})
        );
        return columns;
      },

      /********************** LIST FITERS  STARTS HERE ***********************************/
      /**
       * @author INDU
       * @function onClickFilterTableData
       * @description function to filter the table data on Go of FilterBar
       * @param {Event} event
       */
      onClickFilterTableData: function (event, key) {
        let isManager = false;
        const model = this.getModel();
        const variant = model.getProperty("/variant");
        const configurations = model.getProperty("/variant/configurations");
        configurations.skip = 0;
        configurations.inlineCount = true;
        if ("checkForManagerVariant" in variant) {
          isManager = variant.checkForManagerVariant();
          if (isManager) {
            this.variantState.handleIncludeTeam(variant);
          }
        }
        switch (key) {
          case "dbr":
            this.dbrState.getDBRs(configurations, isManager);
            break;
          default:
            this.activityState.getActivities(configurations, isManager);
            break;
        }
        console.log(model);
      },

      /**
       * @author DARSHAN
       * @function executeActivityFilters
       * @description wrapper function to execute activity list filters
       */
      executeActivityFilters: function () {
        this.onClickFilterTableData();
      },

      /**
       * @author INDU
       * @function executeDBRFilters
       * @description wrapper function to execute dbr list filters
       */
      executeDBRFilters: function () {
        this.onClickFilterTableData(null, "dbr");
      },

      /********************** LIST FITERS  ENDS HERE ***********************************/

      /********************** MY OPPORTUNITY LIST FITERS  STARTS HERE ***********************************/
      /**
       * @author DARSHAN
       * @function filterBarSerach
       * @description function to handle filterbar search
       */
      filterBarSerach: function () {
        let tableFilters = [];
        const model = this.getModel("myOpportunitiesList");
        const opportunityVariant = this.getModel("opportunityVariant");
        const tableBinding = this._getListViewTableBinding();
        let properties =
          opportunityVariant.getProperty(
            "/variant/configurations/properties"
          ) || {};
        let globalSearch =
          opportunityVariant.getProperty("/variant/configurations/search") ||
          "";
        const ownerName = properties?.ownerName || false;
        const account = properties?.accountName || false;

        if (globalSearch && globalSearch?.values) {
          const globalFilters = [];
          globalFilters.push(
            new Filter("id", globalSearch.operator, globalSearch?.values)
          );
          globalFilters.push(
            new Filter("accountId", globalSearch.operator, globalSearch?.values)
          );
          globalFilters.push(
            new Filter(
              "accountName",
              globalSearch.operator,
              globalSearch?.values
            )
          );
          globalFilters.push(
            new Filter("owner", globalSearch.operator, globalSearch?.values)
          );
          globalFilters.push(
            new Filter("ownerName", globalSearch.operator, globalSearch?.values)
          );
          globalFilters.push(
            new Filter(
              "description",
              globalSearch.operator,
              globalSearch?.values
            )
          );
          globalFilters.push(
            new Filter("slsnro", globalSearch.operator, globalSearch?.values)
          );
          let globalFilter = new sap.ui.model.Filter({
            filters: globalFilters,
            bAnd: false,
          });
          tableFilters.push(globalFilter);
        }

        if (ownerName && ownerName?.values && ownerName.values.length) {
          tableFilters = tableFilters.concat(
            ownerName.values.map((id) => {
              return new Filter(ownerName.dataProperty, ownerName.operator, id);
            })
          );
        }

        if (account && account?.values && account.values.length) {
          tableFilters = tableFilters.concat(
            account.values.map((id) => {
              return new Filter(account.dataProperty, account.operator, id);
            })
          );
        }

        tableBinding?.filter(tableFilters);
      },
      /********************** MY OPPORTUNITY LIST FITERS  ENDS HERE ***********************************/

      /********************** VARIANT MANAGEMENT STARTS HERE ***********************************/

      /**
       * @author DARSHAN
       * @function getVariants
       * @description function to get logged-in users variants to filter the data
       */
      getVariants: async function (options) {
        try {
          let params = {
            filters: [],
          };
          if (options?.variantId) {
            params.filters.push(
              new Filter({
                path: "variantid",
                operator: sap.ui.model.FilterOperator.EQ,
                value1: options.variantId,
              })
            );
          } else {
            params.filters.push(
              new Filter({
                path: "view_name",
                operator: sap.ui.model.FilterOperator.EQ,
                value1: options.groupName,
              })
            );
          }
          await this.variantState.getVariants(params, options.groupName);
        } catch (error) {
          console.log("ERROR  IN getVariants : ", error);
        }
      },

      /**
       * @private
       * @author DARSHAN
       * @function setVariantModifiedKeys
       * @description function to set changed variant configurations for modified property in variant management
       */
      setVariantModifiedKeys: function (options, clear) {
        let name;
        if (options?.modelName) {
          name = options?.modelName;
        }
        const model = this.getModel(name);
        let modifiedKeys = model.getProperty("/modifiedKeys") || [];
        if (clear) {
          model.setProperty("/modifiedKeys", []);
          model.refresh(true);
          return;
        }

        //SORT & GROUP
        if (options.key === "SORT" || options.key === "GROUP") {
          const key = options.key === "SORT" ? "SORT" : "GROUP";
          let isAvailable = modifiedKeys.some((item) => item.key === key);
          if (!isAvailable) {
            modifiedKeys.push({
              key: options.key,
              property: options.property,
            });
          }
        }

        //TAB
        if (options.key === "TAB") {
          let isAvailable = modifiedKeys.some((item) => item.key === "TAB");
          if (!isAvailable) {
            modifiedKeys.push({
              key: options.key,
              property: options.property,
            });
          }
        }

        //PROPERTY
        if (options.key === "PROPERTIES") {
          let isPropertyAvailable = modifiedKeys.some(
            (item) => item.property === options.property
          );
          if (!isPropertyAvailable) {
            modifiedKeys.push({
              key: options.key,
              property: options.property,
            });
          }
        }

        model.setProperty("/modifiedKeys", modifiedKeys);
        model.refresh(true);
      },
      /********************** VARIANT MANAGEMENT ENDS HERE ***********************************/

      /************* MY OPPORTUNITIES LIST SCREEN STARTS HERE ***********************************/

      /**
       * @author DARSHAN
       * @function getOpportuntityTableData
       * @description function to get MyOpportunity Table Data
       */
      getOpportuntityListLookup: async function () {
        const masterDataModel = this.getModel("masterDataModel");
        let opportunities = this.opportunityState.getData().opportunities || [];
        const opportunityOwner = Array.from(
          new Map(opportunities.map((obj) => [obj.ownerName, obj])).values()
        );
        masterDataModel.setProperty(
          "/opportunityOwnerLookup",
          opportunityOwner
        );
        masterDataModel.refresh();
      },
      /************* MY OPPORTUNITIES LIST SCREEN ENDS HERE ************************************/

      /************** PRIVATE FUNCTIONS STARTS HERE ***********************************/
      /**
       * @author DARSHAN,INDU
       * @function _groupFunction
       * @description function to get row context for grouping
       */
      _groupFunction: function () {
        const notFound = "Not Available";
        return {
          accountName: function (context) {
            let accountName = context.getProperty("accountName") || key;
            accountName = `Account Name : ${accountName}`;
            return {
              key: accountName,
              text: accountName,
            };
          },
          ownerName: function (context) {
            let ownerName = context.getProperty("ownerName") || key;
            ownerName = `Owner : ${ownerName}`;
            return {
              key: ownerName,
              text: ownerName,
            };
          },
          type: function (context) {
            let activityType = context.getProperty("type");
            let key = activityType.description
              ? activityType.description
              : "ACT000";
            let text = activityType.description
              ? `Activity Type : ${activityType.description}`
              : `Activity Type : ${"Not Available"}`;

            return {
              key: key,
              text: text,
            };
          },
          account: function (context) {
            let account = context.getProperty("account");
            let key = account.name ? account.name : "ACC000";
            let text = account.name
              ? `Account : ${account.name}`
              : `Account : ${"Not Available"}`;

            return {
              key: key,
              text: text,
            };
          },
          opportunity: function (context) {
            let opportunity = context.getProperty("opportunity");
            let key = opportunity.description
              ? opportunity.description
              : "OPP000";
            let text = opportunity.description
              ? `Opportunity : ${opportunity.description}`
              : `Opportunity : ${"Not Available"}`;
            return {
              key: key,
              text: text,
            };
          },
          region: function (context) {
            let region = context.getProperty("region");
            return {
              key: region || "REG00",
              text: region
                ? `Region : ${region}`
                : `Region : ${"Not Available"}`,
            };
          },
          risk: function (context) {
            let risk = context.getProperty("risk");
            let key = risk.description ? risk.description : "RSK00";
            let text = risk.description
              ? `Risk : ${risk.description}`
              : `Risk : ${"Not Available"}`;

            return {
              key: key,
              text: text,
            };
          },
          sl: function (context) {
            let sl = context.getProperty("sl");
            let key = sl.slName ? sl.slName : "SL00";
            let text = sl.slName
              ? `SuccessLine : ${risk.slName}`
              : `SuccessLine : ${"Not Available"}`;

            return {
              key: key,
              text: text,
            };
          },
          activityId: function (context) {
            let activityId = context.getProperty("activityId");
            let key = activityId ? activityId : "ACT00";
            let text = activityId
              ? `Activity : ${activityId}`
              : `Activity : ${"Not Available"}`;

            return {
              key: key,
              text: text,
            };
          },
          dealAdvisor: function (context) {
            let dealAdvisor = context.getProperty("dealAdvisor");
            let key = dealAdvisor ? dealAdvisor.id : "DEAL00";
            let text = dealAdvisor
              ? `Deal Advisor : ${dealAdvisor.name}`
              : `Deal Advisor : ${"Not Available"}`;

            return {
              key: key,
              text: text,
            };
          },
          owner: function (context) {
            let owner = context.getProperty("owner");
            let key = owner ? owner.id : "REQOWNER00";
            let text = owner
              ? `Req Owner : ${owner.name}`
              : `Req Owner : ${"Not Available"}`;

            return {
              key: key,
              text: text,
            };
          },
          requestor: function (context) {
            let requestor = context.getProperty("requestor");
            let key = requestor ? requestor.id : "REQ00";
            let text = requestor
              ? `Requestor : ${requestor.name}`
              : `Requestor : ${"Not Available"}`;

            return {
              key: key,
              text: text,
            };
          },
          resourceManager: function (context) {
            let resourceManager = context.getProperty("resourceManager");
            let key = resourceManager ? resourceManager.id : "RES00";
            let text = resourceManager
              ? `Resource Manager : ${resourceManager.name}`
              : `Resource Manager : ${"Not Available"}`;

            return {
              key: key,
              text: text,
            };
          },
          status: function (context) {
            let status = context.getProperty("status");
            let key = status ? status.id : "STAT00";
            let text = status
              ? `Status : ${status.description}`
              : `Status : ${"Not Available"}`;

            return {
              key: key,
              text: text,
            };
          },
          statusReason: function (context) {
            let statusReason = context.getProperty("statusReason");
            let key = statusReason ? statusReason.id : "SR00";
            let text = statusReason
              ? `Status Reason : ${statusReason.description}`
              : `Status Reason : ${"Not Available"}`;

            return {
              key: key,
              text: text,
            };
          },
        };
      },

      /**
       * @private
       * @author DARSHAN
       * @function checkNewFilterProperty
       * @description function to check if any new filter properties has been added
       */
      checkNewFilterProperty: function (variant, viewName) {
        try {
          let filterProperties;
          switch (viewName) {
            case CoreLibActions.variantGroupTypes.opportunity:
              filterProperties = Helper.getFilterProperties(
                ActivityActions.myOpportunityListFilters
              );
              break;
            case CoreLibActions.variantGroupTypes.dbr:
              filterProperties = Helper.getFilterProperties(
                ActivityActions.myDBRListFilters
              );
              break;
            default:
              filterProperties = Helper.getFilterProperties(
                ActivityActions.myActivityListFilters
              );
          }
          let defaultProperties = Object.keys(filterProperties) || [];
          let variantProperties =
            Object.keys(variant.configurations.properties) || [];
          if (defaultProperties.length === variantProperties.length) {
            return false;
          }
          const variantPropertiesSet = new Set(variantProperties);
          const newProperties = defaultProperties.filter(
            (property) => !variantPropertiesSet.has(property)
          );
          for (let i = 0; i < newProperties.length; i++) {
            let property = newProperties[i];
            variant.configurations.properties[property] =
              filterProperties[property];
          }
          return variant;
        } catch (error) {
          console.log("ERROR IN checkNewFilterProperty : ", error);
        }
      },

      /*************** PRIVATE FUNCTIONS ENDS HERE ***********************************/
    });
  }
);
