// @ts-nocheck
sap.ui.define(
  [
    "sap/m/Token",
    "sap/ui/model/Filter",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/FilterOperator",
    "com/melodylib/core/util/Helper",
    "com/melodylib/core/enum/Actions",
    "com/melodylib/core/db/IndexedDB",
    "com/melodylib/core/state/AuthState",
    "com/melody/activity/util/formatter",
    "com/melodylib/core/classes/Variant",
    "com/melody/activity/enum/ActivityActions",
    "com/melodylib/activity/state/ActivityState",
    "com/melody/activity/service/AccountService",
    "com/melody/activity/service/MasterService",
    "com/melody/activity/controller/BaseController",
    "com/melodylib/integration/state/OpportunityState",
  ],
  function (
    Token,
    Filter,
    Fragment,
    JSONModel,
    FilterOperator,
    Helper,
    Actions,
    IndexedDB,
    AuthState,
    formatter,
    Variant,
    ActivityActions,
    ActivityState,
    AccountService,
    MasterService,
    BaseController,
    OpportunityState
  ) {
    "use strict";

    return BaseController.extend(
      "com.melody.activity.controller.MyOpportunities",
      {
        formatter: formatter,
        onInit: function () {
          this.initializeStates();
          this.getMyOpportunityListVariants({
            groupName: Actions.variantGroupTypes.opportunity,
          });
          const model = this.getOwnerComponent().getModel(
            "myOpportunitiesList"
          );
          const activityListModel =
            this.getOwnerComponent().getModel("activityListModel");

          const variantInfo = this.getVariant(
            Actions.variantGroupTypes.opportunity
          );

          const opportunityVariant = new JSONModel({
            configurations: variantInfo.configurations,
            columns: variantInfo.columns,
          });

          this.getView().setModel(model, "myOpportunitiesList");
          this.getView().setModel(opportunityVariant, "opportunityVariant");
          this.oRouter = this.getOwnerComponent().getRouter();
          this.oRouter.attachRoutePatternMatched(
            this.onRoutePatternMatched,
            this
          );

          // apply content density mode to root view
          this.getView().addStyleClass(
            this.getOwnerComponent().getContentDensityClass()
          );

          //Dynamic Header
          const headerModel = new JSONModel({ headerExpanded: false });
          const headerExpandedBinding = new sap.ui.model.Binding(
            headerModel,
            "/headerExpanded",
            headerModel.getContext("/headerExpanded")
          );
          headerExpandedBinding.attachChange((event) => {
            this.adjustScrollContainerHeight();
          });
          this.setModel(headerModel, "opportunityHeader");
        },

        /**
         * @author DARSHAN
         * @function onRoutePatternMatched
         * @description function to handle attach router pattern matched
         * @param {Event} event
         */
        onRoutePatternMatched: async function (event) {
          let urlArguments = event.getParameter("arguments") ?? {};

          let options = {
            groupName: Actions.variantGroupTypes.opportunity,
            variantId: "",
          };
          // this.getMyOpportunityListVariants(options);

          if (event.getParameter("name") === "MyOpportunities") {
            const opportunityHeader = this.getModel("opportunityHeader");
            opportunityHeader.setProperty("/headerExpanded", true);

            //Setting the scroll event to the scroll container
            const scrollContainer = this.getView().byId(
              "opportunityListScrollContainer"
            );

            if (scrollContainer) {
              window.addEventListener("resize", () => {
                this.adjustScrollContainerHeight();
              });
              setTimeout(() => this.adjustScrollContainerHeight(), 100);
            }
          }
        },

        /********************** MY OPPORTUNITY LIST TABLE FUNCTIONALITIES  STARTS HERE ***********************************/

        /**
         * @author DARSHAN
         * @function adjustScrollContainerHeight
         * @description function to set Height based on screen size
         * @param {Object} event
         */
        adjustScrollContainerHeight: function (event) {
          try {
            let scrollContainerTop;
            const scrollContainer = this.getView().byId(
              "opportunityListScrollContainer"
            );

            if (!scrollContainer) {
              return;
            }

            // Calculate the available height for the ScrollContainer
            let windowHeight = window.innerHeight;
            if (
              typeof scrollContainer.getDomRef === "function" &&
              typeof scrollContainer.getDomRef()?.getBoundingClientRect ===
                "function"
            ) {
              scrollContainerTop = scrollContainer
                .getDomRef()
                .getBoundingClientRect().top;

              let availableHeight = windowHeight - scrollContainerTop;
              if (windowHeight <= 610 && availableHeight <= 290) {
                availableHeight = 290;
              }
              if (windowHeight > 850 && availableHeight < 450) {
                availableHeight = 570;
              }
              // Set the height of the ScrollContainer
              // console.log("iWindowHeight", windowHeight);
              // console.log("HEIGHT IS SET", availableHeight);
              scrollContainer.setHeight(availableHeight + "px");
            }
          } catch (error) {
            console.log("ERROR IN adjustScrollContainerHeight : ", error);
          }
        },

        /**********************MY OPPORTUNITY LIST TABLE FUNCTIONALITIES ENDS HERE ***********************************/

        /********************** MY OPPORTUNITY LIST FITERS  STARTS HERE ***********************************/
        /**
         * @author DARSHAN
         * @function myOpportunityFilterClear
         * @description function to handle clearing of filters in the list view
         * @param {Event} event
         */
        myOpportunityFilterClear: function (event) {
          const authState = this.getModel("authState");
          const model = this.getModel("myOpportunitiesList");
          const opportunityVariant = this.getModel("opportunityVariant");
          const tableBinding = this._getListViewTableBinding();
          const accountInput = this.getView().byId("accountMultiInputFilter");
          const ownerInput = this.getView().byId("ownerMultiInputFilter");
          const filterProperties = Helper.getFilterProperties(
            ActivityActions.myOpportunityListFilters
          );
          let configurations =
            opportunityVariant.getProperty("/variant/configurations") || {};

          opportunityVariant.setProperty("/variant/configurations", {
            properties: filterProperties,
            sort: configurations.sort,
            group: configurations.group,
          });

          tableBinding?.filter([]);
          accountInput?.clearSelection();
          accountInput?.setSelectedItems([]);
          ownerInput?.clearSelection();
          ownerInput?.setSelectedItems([]);
          model.refresh();

          //show modifier in variant Management control
          const variantControl = this.getView().byId(
            "myOpportunityVariantManagement"
          );
          if (variantControl) {
            variantControl.setModified(true);
          }
        },

        /**
         * @author DARSHAN
         * @function handleGlobalFilterSearch
         * @description function to handle filterbar global Search
         * @param {Event} event
         */
        handleGlobalFilterSearch: function (event) {
          let query = event.getParameter("query") || "";
          query = query ? query.trim() : "";
          const authState = this.getModel("authState");
          const model = this.getModel("myOpportunitiesList");
          const opportunityVariant = this.getModel("opportunityVariant");
          opportunityVariant.setProperty(
            "/variant/configurations/search",
            query
          );
          authState.refresh();
          this.filterBarSerach();
        },

        /**
         * @author DARSHAN
         * @function handleAccountFilter
         * @description function to handle filterbar Account Name select
         * @param {Event} event
         */
        handleAccountFilter: function (event) {
          const authState = this.getModel("authState");
          const model = this.getModel("myOpportunitiesList");
          const selectedData = this._createFilterData(event, "accountState");
          if (selectedData) {
            model.setProperty("/filterString/accountName", selectedData);
          } else {
            model.setProperty("/filterString/accountName", null);
          }

          model.refresh();
          authState.refresh();
          this.filterBarSerach();
        },

        /**
         * @author DARSHAN
         * @function handleOwnerFilter
         * @description function to handle filterbar Opportunity Owner select
         * @param {Event} event
         */
        handleOwnerFilter: function (event) {
          const authState = this.getModel("authState");
          const model = this.getModel("myOpportunitiesList");
          const selectedData = this._createFilterData(
            event,
            "opportunityState"
          );
          if (selectedData) {
            model.setProperty("/filterString/ownerName", selectedData);
          } else {
            model.setProperty("/filterString/ownerName", []);
          }

          model.refresh();
          authState.refresh();
          this.filterBarSerach();
        },

        /********************** MY OPPORTUNITY LIST FITERS  ENDS HERE ***********************************/

        /**
         * @author DARSHAN
         * @function resetGroupDialog
         * @description function to handle all closing of fragments/Dialog/Popovers
         * @param {Event} event
         */
        resetGroupDialog: function (event) {
          this.groupReset = true;
        },

        /**
         * @author DARSHAN
         * @function opportunityTitleClick
         * @description function to handle title click of object identifier in the list table
         * @param {Event} event
         */
        opportunityTitleClick: async function (event) {
          const opportunity =
            event
              .getSource()
              ?.getBindingContext("opportunityState")
              ?.getObject() || {};
          const urlConstant = (await this._getUrlConstant("0011")) || {};
          if (urlConstant) {
            window.open(
              urlConstant?.value + opportunity.id + "/plan",
              "_blank"
            );
          }
        },

        /**
         * @author DARSHAN
         * @function accountTitleClick
         * @description function to handle title click of object identifier in the list table
         * @param {Event} event
         */
        accountTitleClick: async function (event) {
          const opportunity =
            event
              .getSource()
              ?.getBindingContext("opportunityState")
              ?.getObject() || {};
          const urlConstant = await this._getUrlConstant("0052");
          if (urlConstant) {
            window.open(
              urlConstant?.value + opportunity.accountId + "/plan",
              "_blank"
            );
          }
        },

        /********************** VIEW SETTINGS & PERSONALIZATION DIALOG STARTS HERE ***********************************/

        /**
         * @author DARSHAN
         * @function openViewSettingDialog
         * @description function to open view settings Dialog (Sorting and grouping)
         * @param {Event} event
         */
        openViewSettingDialog: async function (event) {
          const model = this.getModel("myOpportunitiesList");
          const opportunityVariant = this.getModel("opportunityVariant");
          const sortConfig = opportunityVariant.getProperty(
            "/variant/configurations/sort"
          );
          const groupConfig = opportunityVariant.getProperty(
            "/variant/configurations/group"
          );
          let fragment = {
            i18n: "com.melody.activity.i18n.i18n",
            controller: this,
            path: "com.melody.activity.fragments.list.myopportunity.table.TableViewSettingsDialog",
            name: "_myopportunityListSortDialog",
            id: `${this.getView().getId()}_myopportunityListSortDialog`,
            model: model,
            models: [],
          };

          if (!this._myopportunityListViewSettingsDialog) {
            this._myopportunityListViewSettingsDialog = await this.loadFragment(
              {
                name: fragment.path,
              }
            );
          }

          this._myopportunityListViewSettingsDialog.setModel(
            opportunityVariant,
            "opportunityVariant"
          );

          this._myopportunityListViewSettingsDialog.open();

          //TODO:NEED TO CHANGE THIS
          const sortGroupDialog = this.getView().byId(
            "opportunitySortGroupDialog"
          );
          if (sortGroupDialog) {
            if (groupConfig?.groupBy) {
              sortGroupDialog.setSelectedGroupItem(groupConfig.groupBy);
            }

            if (sortConfig?.sortBy) {
              sortGroupDialog.setSelectedSortItem(sortConfig.sortBy);
            }
          }
        },

        /**
         * @author DARSHAN
         * @function accountTitleClick
         * @description function to handle sorting and grouping in the table based on property selected
         * @param {Event} event
         * @param {String} tableId
         */
        onViewSettingDialogConfirm: function (event, tableId) {
          const opportunityVariant = this.getModel("opportunityVariant");
          const params = event.getParameters();
          const sortConfig = opportunityVariant.getProperty(
            "/variant/configurations/sort"
          );
          const groupConfig = opportunityVariant.getProperty(
            "/variant/configurations/group"
          );

          if (params?.sortItem) {
            const key = params.sortItem.getKey();
            const isDescending = params.groupDescending;
            sortConfig.sortBy = key;
            sortConfig.sortOrderDesc = isDescending;
          } else {
            sortConfig.sortBy = "";
            sortConfig.sortOrderDesc = false;
          }

          if (params?.groupItem) {
            const key = params.groupItem.getKey();
            const isDescending = params.sortDescending;
            groupConfig.groupBy = key;
            groupConfig.groupOrderDesc = isDescending;
          } else {
            groupConfig.groupBy = "";
            groupConfig.groupOrderDesc = false;
          }
          this.setVariantModifiedKeys({
            key: "SORT",
            property: "",
            modelName: "opportunityVariant",
          });
          this.setVariantModifiedKeys({
            key: "GROUP",
            property: "",
            modelName: "opportunityVariant",
          });
          opportunityVariant.setProperty(
            "/variant/configurations/sort",
            sortConfig
          );
          opportunityVariant.setProperty(
            "/variant/configurations/group",
            groupConfig
          );
          opportunityVariant.refresh();

          this.handleSortGroupDialogConfirm(event, tableId);
        },

        /**
         * @author DARSHAN
         * @function onPersonalizationDialogOpen
         * @description function to handle opening of personalization Dialog open
         * @param {Event} event
         */
        onPersonalizationDialogOpen: function (event) {
          if (!this.opportunityPersonalizationDialog) {
            Fragment.load({
              name: "com.melody.activity.fragments.list.myopportunity.table.Personalization",
              controller: this,
            }).then(
              function (oDialog) {
                this.opportunityPersonalizationDialog = oDialog;
                this.getView().addDependent(oDialog);
                this.opportunityPersonalizationDialog.open();
              }.bind(this)
            );
          } else {
            this.opportunityPersonalizationDialog.open();
          }
        },

        /**
         * @author INDU
         * @function onSelectPersonalization
         * @description function to set selected to the selected column in the columns of Activity List
         * @param {Object} event
         */
        onSelectPersonalization: function (event) {
          const listItem = event.getParameter("listItem");
          const selected = listItem.getProperty("selected");
          const model = this.getModel("opportunityVariant");
          model.setProperty(
            "/variant/configurations/properties/" +
              listItem.data("key") +
              "/selected",
            selected
          );
        },

        /**
         * @author INDU
         * @function onSearchPersonalization
         * @description function to search in personalization dialog
         * @param {Object} event
         */
        onSearchPersonalization: function (event) {
          const searchParam = event.getSource().getValue();
          const personalizationList =
            this.opportunityPersonalizationDialog.getContent()[0];
          const itemsBinding = personalizationList.getBinding("items");
          let filters = [
            new Filter("label", FilterOperator.Contains, searchParam),
          ];
          itemsBinding.filter(filters);
        },

        /**
         * @author INDU
         * @function onClosePersonalization
         * @description function to close personalization dialog
         */
        onClosePersonalization: function () {
          this.opportunityPersonalizationDialog.close();
        },

        /**********************VIEW SETTINGS & PERSONALIZATION ENDS HERE ***********************************/

        /********************** VARIANT MANAGEMENT STARTS HERE ***********************************/

        /**
         * @author DARSHAN
         * @function getMyOpportunityListVariants
         * @description function to get logged-in users variants to filter the data
         */
        getMyOpportunityListVariants: async function (options) {
          try {
            await this.variantState.getVariants({
              groupName: Actions.variantGroupTypes.opportunity,
            });
            const variantState = this.getModel("variantState");
            const variants = variantState.getProperty("/variants") || [];

            let defaultVariant = variantState.getProperty("/defaultVariant");
            const opportunityVariant = this.getModel("opportunityVariant");
            if (defaultVariant && defaultVariant?.id !== "standard") {
              //CHECK FOR NEW PROPERTY
              const updatedVariant = this.checkNewFilterProperty(
                defaultVariant,
                Actions.variantGroupTypes.opportunity
              );
              if (updatedVariant) {
                defaultVariant = updatedVariant;
              }

              //UPDATE PERSONALIZATION
              defaultVariant.columns = this.getColumnsArray(
                defaultVariant.configurations.properties
              );

              opportunityVariant.setProperty("/variant", defaultVariant);
              opportunityVariant.setProperty(
                "/variantBackUp",
                JSON.parse(JSON.stringify(defaultVariant))
              );
              const sortConfig = opportunityVariant.getProperty(
                "/variant/configurations/sort"
              );
              const groupConfig = opportunityVariant.getProperty(
                "/variant/configurations/group"
              );
              this.setSortGroupToTable({
                tableId: "myOpportunitiesTable",
                sortConfig,
                groupConfig,
              });
              opportunityVariant.refresh();
              this.filterBarSerach();
            } else {
              //CASE WHEN NO VARIANTS ARE PRESENT
              const filterProperties = Helper.getFilterProperties(
                ActivityActions.myOpportunityListFilters
              );
              const variant = {
                configurations: {
                  properties: filterProperties,
                  sort: {
                    sortBy: "",
                    sortOrderDesc: false,
                  },
                  group: {
                    groupBy: "",
                    groupOrderDesc: false,
                  },
                },
              };
              defaultVariant.configurations = variant.configurations;
              //UPDATE PERSONALIZATION
              defaultVariant.columns = this.getColumnsArray(
                defaultVariant.configurations.properties
              );
              opportunityVariant.setProperty("/variant", defaultVariant);
              opportunityVariant.setProperty(
                "/variantBackUp",
                JSON.parse(JSON.stringify(defaultVariant))
              );
              opportunityVariant.refresh();
              this.filterBarSerach(); //TODO:CHECK THIS
            }
          } catch (error) {
            Helper.showMessage("Something went wrong. Please try again");
            console.log("ERROR  IN getMyOpportunityListVariants : ", error);
          }
        },

        /**
         * @author DARSHAN
         * @function onSaveVariant
         * @description function to handle "save as" in variant management control
         * @param {Event} event
         */
        onSaveVariant: async function (event) {
          try {
            const params = event.getParameters();
            const variantState = this.getModel("variantState");
            const model = this.getModel("myOpportunitiesList");
            const opportunityVariant = this.getModel("opportunityVariant");
            let configurations = opportunityVariant.getProperty(
              "/variant/configurations"
            );
            const variant = new Variant();

            await this.variantState.setVariant({
              params: params,
              variant: variant,
              filters: configurations,
              viewName: Actions.variantGroupTypes.opportunity,
            });
            await this.getMyOpportunityListVariants({
              groupName: Actions.variantGroupTypes.opportunity,
              variantId: "",
            });
            this.setVariantModifiedKeys(
              {
                key: "",
                property: "",
                modelName: "opportunityVariant",
              },
              true
            );
          } catch (error) {
            Helper.showMessage("Something went wrong. Please try again");
            console.log("ERROR IN onSaveVariant : ", error);
          }
        },

        /**
         * @author DARSHAN
         * @function onSelectVariant
         * @description function to handle selections of variants from the variant list
         * @param {Event} event
         */
        onSelectVariant: function (event) {
          try {
            const model = this.getModel("myOpportunitiesList");
            const variantState = this.getModel("variantState");
            const opportunityVariant = this.getModel("opportunityVariant");
            const variants =
              variantState.getProperty("/variants/opportunities") || [];
            const params = event.getParameters();
            const variantKey = params.key;
            let variant =
              variants.find((data) => {
                return data.id === variantKey;
              }) || false;

            //CHECK FOR NEW PROPERTY
            const updatedVariant = this.checkNewFilterProperty(
              variant,
              Actions.variantGroupTypes.opportunity
            );
            if (updatedVariant) {
              variant = updatedVariant;
            }

            opportunityVariant.setProperty(
              "/variantBackUp",
              JSON.parse(JSON.stringify(variant))
            );

            opportunityVariant.setProperty("/variant", variant);
            const sortConfig = opportunityVariant.getProperty(
              "/variant/configurations/sort"
            );
            const groupConfig = opportunityVariant.getProperty(
              "/variant/configurations/group"
            );

            if (variant?.executeOnSelect) {
              this.filterBarSerach();
              this.setSortGroupToTable({
                tableId: "myOpportunitiesTable",
                sortConfig,
                groupConfig,
              });
            }
            model.refresh();
            variantState.refresh();
          } catch (error) {
            Helper.showMessage("Something went wrong. Please try again");
            console.log("ERROR IN onSelectVariant : ", error);
          }
        },

        /**
         * @author DARSHAN
         * @function onManageOpportunityVariant
         * @description function to handle "save" in "Manage" option in variant management control
         * @param {Event} event
         */
        onManageOpportunityVariant: async function (event) {
          try {
            let updateVariant = await this.variantState.manageVariant(
              event,
              Actions.variantGroupTypes.opportunity
            );
            if (updateVariant) {
              await this.getMyOpportunityListVariants({
                groupName: Actions.variantGroupTypes.opportunity,
                variantId: "",
              });
              this.setVariantModifiedKeys(
                {
                  key: "",
                  property: "",
                  modelName: "opportunityVariant",
                },
                true
              );
            }
          } catch (error) {
            Helper.showMessage("Something went wrong. Please try again");
            console.log("ERROR IN onManageOpportunityVariant : ", error);
          }
        },
        /********************** VARIANT MANAGEMENT ENDS HERE ***********************************/

        /*****************PRIVATE FUNCTIONS STARTS HERE******************/
        /**
         * @private
         * @author DARSHAN
         * @function _findAndRemove
         * @description function to remove an object in the array
         * @param {Array} items
         * @param {String} key
         * @param {String} value
         */
        _findAndRemove: function (items, key, value) {
          if (!items || !items.length) {
            return items;
          }
          let result = items.filter((data) => {
            return data[key] !== value;
          });
          return result;
        },

        /**
         * @private
         * @author DARSHAN
         * @function _createFilterData
         * @description function to remove an object in the array
         * @param {Event} event
         * @param {Array} tokenKeys
         */
        _createFilterData: function (event, modelName) {
          let selectedItem = event.getParameter("selectedItems") || [];
          let selectedData = selectedItem.map((item) => {
            return item.getBindingContext(modelName).getObject();
          });

          //ADD MODIFIED KEYS
          const source = event.getSource();
          const customData = source?.getCustomData()[0];
          const key = customData?.getKey();
          this.setVariantModifiedKeys({
            key: "PROPERTIES",
            property: key,
            modelName: "opportunityVariant",
          });

          if (selectedData.length) {
            return selectedData;
          }
          return false;
        },

        /**
         * @private
         * @author DARSHAN
         * @function _getListViewTableBinding
         * @description function to get table present in the list view
         */
        _getListViewTableBinding: function () {
          const table = this.getView().byId("myOpportunitiesTable") || false;
          if (table) {
            const bindingItems = table.getBinding("items");
            return bindingItems || false;
          }
          return false;
        },

        /**
         * @private
         * @author DARSHAN
         * @function _getUrlConstant
         * @description function to get url constant based on urlId
         */
        _getUrlConstant: async function (urlId) {
          if (!urlId) {
            return false;
          }
          let urlConstants =
            (await IndexedDB.fnGetAllDatafromDB({
              dbName: "master-data",
              storeName: "master-data-table",
              keyName: "harmonyconstanturls",
            })) || [];
          let urlConstant =
            urlConstants.find((url) => {
              return url.id === urlId;
            }) || false;
          return urlConstant;
        },
        /*****************PRIVATE FUNCTIONS ENDS HERE*******************/
      }
    );
  }
);
