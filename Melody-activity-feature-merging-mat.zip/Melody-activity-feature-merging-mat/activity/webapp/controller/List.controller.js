sap.ui.define(
  [
    "sap/ui/model/Filter",
    "sap/ui/core/ResizeHandler",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/json/JSONModel",
    "com/melodylib/core/util/Helper",
    "com/melodylib/core/enum/Actions",
    "com/melody/activity/util/formatter",
    "com/melodylib/core/classes/Variant",
    "com/melody/activity/util/MasterData",
    "com/melodylib/core/enum/PropertyType",
    "com/melody/activity/enum/ActivityActions",
    "com/melodylib/core/classes/FilterProperty",
    "com/melodylib/activity/state/ActivityState",
    "com/melodylib/integration/state/AccountState",
    "com/melody/activity/controller/BaseController",
    "com/melodylib/activity/state/ActivityMasterState",
    "com/melodylib/activity/state/ActivityColumnState",
    "com/melodylib/core/db/IndexedDB"


  ],
  function (
    Filter,
    ResizeHandler,
    FilterOperator,
    JSONModel,
    Helper,
    Actions,
    formatter,
    Variant,
    MasterData,
    PropertyType,
    ActivityActions,
    VariantProperty,
    ActivityState,
    AccountState,
    BaseController,
    ActivityMasterState,
    ActivityColumnState,
    IndexedDB
  ) {
    "use strict";

    return BaseController.extend("com.melody.activity.controller.List", {
      formatter: formatter,
      onInit: async function () {
        this.initializeStates();
        //VARIANT MANAGEMENT
        this.getActivityListVariants();

        const data = {
          headerExpanded: true,
          countData: {
            busy: true,
            results: [],
          },
          variant: this.getVariant(),
          Users: {
            busy: false,
            results: [],
          },
          Accounts: {
            busy: false,
            results: [],
          },
          actions: {
            busy: false,
            results: [],
          },
        };

        const model = new JSONModel(data);
        this.setModel(model);
        const headerModel = new JSONModel({ headerExpanded: false });
        const headerExpandedBinding = new sap.ui.model.Binding(
          headerModel,
          "/headerExpanded",
          headerModel.getContext("/headerExpanded")
        );
        headerExpandedBinding.attachChange((event) => {
          this.adjustScrollContainerHeight();
        });
        this.setModel(headerModel, "header");

        this.activityMasterState = ActivityMasterState.getInstance();
        this.activityColumnState = ActivityColumnState.getInstance();
        this.accountState = AccountState.getInstance();

        this.setModel(
          this.activityColumnState.getModel(),
          "activityColumnState"
        );

        this.activityState = ActivityState.getInstance();
        this.router = this.getRouter();
        this._isDirty = false;
        this.router.attachRoutePatternMatched(this.onRoutePatternMatched, this);

        // apply content density mode to root view
        this.getView().addStyleClass(
          this.getOwnerComponent().getContentDensityClass()
        );

        let drafts =
          (await IndexedDB.fnGetAllDatafromDB({
            dbName: "myActivities",
            storeName: "drafts-table",
            keyName: "activitydrafts",
          })) || [];
        let activityState = this.getModel("activityState");
        activityState.setProperty("/draftActivities", drafts);
      },

      onRoutePatternMatched: async function (event) {
        let variantOptions;
        this.initializeStates();
        if (event.getParameter("name") === "list") {
          //VARIANT MANAGEMENT
          variantOptions = {
            groupName: Actions.variantGroupTypes.activity,
          };
          const model = this.getModel();
          const headerModel = this.getModel("header");
          const variantState = this.getModel("variantState");
          const variants = variantState.getProperty("/variants") || [];
          headerModel.setProperty("/headerExpanded", true);
          headerModel.refresh();
          this.onRouteMatched(event);



          //Setting the scroll event to the scroll container
          const scrollContainer = this.getView().byId(
            "activityListScrollContainer"
          );

          if (scrollContainer) {
            window.addEventListener("resize", () => {
              this.adjustScrollContainerHeight();
            });
            scrollContainer.attachBrowserEvent(
              "scroll",
              this.onScrollContainerScroll.bind(this)
            );
            setTimeout(() => this.adjustScrollContainerHeight(), 100);
          }


        }
      },

      /********************** ACTIVITY LIST TABLE FUNTIONALITY STARTS HERE ***********************************/

      /**
       * @author DARSHAN
       * @function adjustScrollContainerHeight
       * @description function to set Height based on screen size
       * @param {Object} event
       */
      adjustScrollContainerHeight: function (event) {
        try {
          let scrollContainerTop;
          const scrollContainer = this.getView().byId(
            "activityListScrollContainer"
          );

          if (!scrollContainer) {
            return;
          }

          // Calculate the available height for the ScrollContainer
          let windowHeight = window.innerHeight;
          if (
            typeof scrollContainer.getDomRef === "function" &&
            typeof scrollContainer.getDomRef()?.getBoundingClientRect ===
            "function"
          ) {
            scrollContainerTop = scrollContainer
              .getDomRef()
              .getBoundingClientRect().top;

            let availableHeight = windowHeight - scrollContainerTop;
            if (windowHeight <= 610 && availableHeight <= 290) {
              availableHeight = 290;
            }
            if (windowHeight > 850 && availableHeight < 450) {
              availableHeight = 570;
            }
            // Set the height of the ScrollContainer
            // console.log("iWindowHeight", windowHeight);
            // console.log("HEIGHT IS SET", availableHeight);
            scrollContainer.setHeight(availableHeight + "px");
          }
        } catch (error) {
          console.log("ERROR IN adjustScrollContainerHeight : ", error);
        }
      },

      /**
       * @author DARSHAN
       * @function onScrollContainerScroll
       * @description function to handle scroll in the scrol container
       * @param {Object} event
       * IIFE and Throlling is used to handle the scroll methods for service calls
       */
      onScrollContainerScroll: function (event) {
        let lastCalled = 0;
        let scrollContainer = event.currentTarget;

        let bIsScrolledToBottom =
          scrollContainer.scrollTop + scrollContainer.clientHeight >=
          scrollContainer.scrollHeight;

        //SCROLL AT BOTTOM
        if (bIsScrolledToBottom) {
          const model = this.getModel();
          const activeVariant = model.getProperty("/variant");
          let activityState = this.getModel("activityState");
          let totalActivities =
            activityState.getProperty("/totalActivities") || "0";
          let activities = activityState.getProperty("/activities") || [];

          //Number Validation
          if (totalActivities) {
            totalActivities = parseInt(totalActivities);
            if (isNaN(totalActivities)) {
              totalActivities = 0;
            }
          }

          //VARIANT UPDATES
          activeVariant.configurations.skip = activities.length;
          activeVariant.configurations.inlineCount = false;

          console.log("SCROLL IS AT THE BOTTOM");

          if (activities.length !== totalActivities) {
            return (() => {
              const atPresent = new Date().getTime();
              if (atPresent - lastCalled >= 5000) {
                lastCalled = atPresent;
                let isManager = false;
                if ("checkForManagerVariant" in activeVariant) {
                  isManager = activeVariant.checkForManagerVariant();
                }
                this.activityState.getActivities(
                  activeVariant.configurations,
                  isManager
                );
              }
            })();
          }
        }
      },

      /********************** ACTIVITY LIST TABLE FUNTIONALITY ENDS HERE **************************************/

      /********************** PERSONALIZATION FUNTIONALITY STARTS HERE ***********************************/

      /**
       * @author INDU
       * @function onOpenPersonalization
       * @description function to open personalization dialog
       */
      onOpenPersonalization: async function () {
        const model = this.getModel();
        let variant = model.getProperty("/variant");
        let variantBackUp = structuredClone(variant);
        model.setProperty("/columnsBackUp", variantBackUp);
        if (!this.personalizationDialog) {
          this.personalizationDialog = await this.loadFragment({
            name: "com.melody.activity.fragments.list.Personalization",
          });
        }
        this.personalizationDialog.open();
      },

      /**
       * @author INDU
       * @function onSearchPersonalization
       * @description function to search in personalization dialog
       * @param {Object} event
       */
      onSearchPersonalization: function (event) {
        const searchParam = event.getSource().getValue();
        const personalizationList = this.personalizationDialog.getContent()[0];
        const itemsBinding = personalizationList.getBinding("items");
        let filters = [
          new Filter("label", FilterOperator.Contains, searchParam),
        ];
        itemsBinding.filter(filters);
      },

      /**
       * @author INDU
       * @function onClosePersonalization
       * @description function to close personalization dialog
       */
      onClosePersonalization: function () {
        this.personalizationDialog.close();
      },

      /**
       * @author INDU
       * @function onCancelPersonalization
       * @description function to cancel personalization dialog
       */
      onCancelPersonalization: function () {
        const model = this.getView().getModel();
        let columnsBackUp = model.getProperty("/columnsBackUp");
        model.setProperty("/variant", columnsBackUp);
        this.personalizationDialog.close();
      },

      /**
       * @author INDU
       * @function onSelectPersonalization
       * @description function to set selected to the selected column in the columns of Activity List
       * @param {Object} event
       */
      onSelectPersonalization: function (event) {
        let length = event.getSource().getSelectedContextPaths()?.length;
        const listItem = event.getParameter("listItem");
        if (length < 8) {
          const selected = listItem.getProperty("selected");
          const model = this.getView().getModel();
          model.setProperty(
            "/variant/configurations/properties/" +
            listItem.data("key") +
            "/selected",
            selected
          );
        } else {
          sap.m.MessageToast.show("Please select max 6 columns");
          listItem.setSelected(false);
        }
      },

      /********************** PERSONALIZATION FUNTIONALITY ENDS HERE ***********************************/

      /********************** FILTER BAR FUNTIONALITY STARTS HERE ***********************************/

      /**
       * @author INDU, DARSHAN
       * @function onClearFilters
       * @description function to clear the fitlers and also to set modified to true in variant management control
       * @param {Object} data
       */
      onClearFilters: function () {
        const model = this.getModel();
        const authState = this.getModel("authState");
        const activeVariant = model.getProperty("/variant");
        // const filterProperties = Helper.getFilterProperties(
        //   ActivityActions.myActivityListFilters
        // );

        //Clearing only Filter Properties
        // activeVariant.configurations.properties = filterProperties;
        const properties = activeVariant.configurations.properties;
        for (let p in properties) {
          let property = properties[p];
          if (property.type === "dateRange") {
            property.values.value1 = null;
            property.values.value2 = null;
          } else {
            property.values = [];
          }
        }
        activeVariant.configurations.search = "";
        model.setProperty("/variant", activeVariant);
        this.executeActivityFilters();

        //show modifier in variant Management control
        const variantControl = this.getView().byId("listVariantMangement");
        if (variantControl) {
          variantControl.setModified(true);
        }
      },
      /**
       * @author  INDU
       * @function onSearchActivity
       * @description function to get triggerd on search field change in filter bar
       */
      onSearchActivity: function () {
        this.onClickFilterTableData();
      },

      /**
       * @author  DARSHAN
       * @function onMultiComboBoxSelectionFinished
       * @description function to handle multi comboBox change
       * @param {Event} event
       */
      onMultiComboBoxSelectionFinished: function (event) {
        this.onModifyFilter(event);
      },

      /**
       * @author  INDU
       * @function handleDateChange
       * @description
       * @param {Event} event
       */
      handleDateChange: function (event) {
        let valid = event.getParameter("valid");
        const source = event.getSource();
        if (!source.getValue()) {
          source.setValueState("None");
        } else {
          if (valid && event.getParameter("to") && event.getParameter("from")) {
            source.setValueState("None");
          } else {
            source.setValueState("Error");
            source.setValueStateText("Please Provide Date Range");
          }
        }
        this.onModifyFilter(event);
      },

      /**
       * @author  INDU,DARSHAN
       * @function onModifyFilter
       * @description
       * @param {Event} event
       */
      onModifyFilter: function (event) {
        const authState = this.getModel("authState");
        const source = event.getSource();
        const customData = source?.getCustomData()[0];
        const key = customData?.getKey();
        this.setVariantModifiedKeys({
          key: "PROPERTIES",
          property: key,
        });
        this.getModel().refresh(true);
      },

      /**
       * @author  INDU,DARSHAN
       * @function onCloseFilter
       * @description function to close dialogs
       * @param {Event} event
       */
      onCloseFilter: function (event) {
        const dialog = event.getSource().getParent();
        if ("close" in dialog) {
          dialog.close();
        }
      },

      /**
       * @author  DARSHAN
       * @function onRiskToggleBtnPress
       * @description function to handle press event of toggle button
       * @param {Event} event
       * @param {String} riskType
       */
      onRiskToggleBtnPress: function (event, riskType) {
        let updatedValues;
        const model = this.getModel();
        const riskValues =
          model.getProperty("/variant/configurations/properties/risk/values") ||
          [];
        const pressed = event.getParameter("pressed");
        switch (riskType) {
          case "RED":
            updatedValues = this.setRiskValues(pressed, "01", riskValues);
            break;
          case "YELLOW":
            updatedValues = this.setRiskValues(pressed, "02", riskValues);
            break;
          case "GREEN":
            updatedValues = this.setRiskValues(pressed, "03", riskValues);
            break;
          default:
        }
        model.setProperty(
          "/variant/configurations/properties/risk/values",
          updatedValues
        );
        model.refresh(true);
        this.setVariantModifiedKeys({
          key: "PROPERTIES",
          property: "risk",
        });
        this.executeActivityFilters();
      },

      /**
       * @author  DARSHAN
       * @function onMultiInputTokenUpdate
       * @description function to handle any token change event from the multi input control
       * @param {Event} event
       * @param {String} filterkey
       */
      onMultiInputTokenUpdate: function (event, filterkey) {
        const type = event.getParameter("type");
        if (type === sap.m.Tokenizer.TokenUpdateType.Removed) {
          this.onRemoveTokens(event, filterkey);
        }
      },

      /**
       * @author  INDU, DARSHAN
       * @function addTokens
       * @description function to add tokens to the token field
       * @param {Event} event
       * @param {model} contextModel
       * @param {String} key
       */
      addTokens: function (event, contextModel, key) {
        const model = this.getModel();
        const selctions = [];
        const selectedContexts = event.getParameter("selectedContexts");
        selectedContexts.forEach((context) => {
          let path = context.sPath;
          selctions.push({
            value1: contextModel.getProperty(path).id,
          });
        });
        model.setProperty(
          "/variant/configurations/properties/" + key + "/values",
          selctions
        );
        this.setVariantModifiedKeys({
          key: "PROPERTIES",
          property: key,
        });
        model.refresh(true);
      },

      /**
       * @author  INDU, DARSHAN
       * @function onRemoveTokens
       * @description function to remove tokens and update the model properties
       * @param {Event} event
       * @param {String} filterkey
       */
      onRemoveTokens: function (event, key) {
        const model = this.getModel();
        const removedTokens = event.getParameter("removedTokens") || [];
        if (removedTokens.length) {
          removedTokens.forEach((token) => {
            let bindingContext = token.getBindingContext();
            if (bindingContext) {
              let path = bindingContext.getPath();
              let contextObject = bindingContext.getObject() || {};
              let selectedTokens =
                model.getProperty(
                  "/variant/configurations/properties/" + key + "/values"
                ) || [];
              let index = selectedTokens.findIndex(
                (item) => item.value1 === contextObject.value1
              );
              if (index !== -1) {
                selectedTokens.splice(index, 1);
              }
              model.setProperty(
                "/variant/configurations/properties/" + key + "/values",
                selectedTokens
              );
              this.setVariantModifiedKeys({
                key: "PROPERTIES",
                property: key,
              });
              this.getModel().refresh(true);
            }
          });
        }
      },

      /**
       * @author  INDU
       * @function onSearchValueHelp
       * @description function to search the data in value help dialog
       * @param {Object} event
       */
      onSearchValueHelp: function (oEvent) {
        const searchParam = oEvent.getParameter("value");
        let filters = new Filter({
          aFilters: [
            new Filter("id", FilterOperator.Contains, searchParam),
            new Filter("description", FilterOperator.Contains, searchParam),
          ],
          and: false,
        });
        const itemsBinding = oEvent.getParameter("itemsBinding");
        itemsBinding.filter(filters);
      },

      /**
       * @author  INDU
       * @function checkSelectionsInDialog
       * @description function to check previous selections in MultiInputs
       * @param {String} key
       * @param {String} modelName
       * @param {Object} dialog
       */
      checkSelectionsInDialog: function (key, modelName, dialog) {
        let name;
        if (modelName) {
          name = modelName;
        }
        const model = this.getModel();
        let tokens = model.getProperty(
          "/variant/configurations/properties/" + key + "/values"
        );
        dialog._removeSelection();
        if (tokens.length) {
          let contextModel = this.getModel(name);
          // if (!contextModel) {
          //   contextModel = model;
          // }
          const selectedKeys = tokens.map((token) => token.value1);
          const items = dialog.getItems();
          items.forEach((item) => {
            let bindingPath = item.getBindingContext(name).sPath;
            let id = contextModel.getProperty(bindingPath).id;
            if (selectedKeys.includes(id)) {
              item.setSelected(true);
            }
          });
        }
      },

      onOpenActivityTypeFilter: async function (event) {
        const source = event.getSource();
        const customData = source?.getCustomData()[0];
        const key = customData?.getKey();
        if (!this.activityTypeFilterDialog) {
          this.activityTypeFilterDialog = await this.loadFragment({
            name: "com.melody.activity.fragments.list.ActivityTypeLookup",
          });
        }
        this.checkSelectionsInDialog(
          key,
          "activityMasterState",
          this.activityTypeFilterDialog
        );
        this.activityTypeFilterDialog.open();
      },

      onSelectActivityTypeFilter: function (event) {
        const activityMasterState = this.getOwnerComponent().getModel(
          "activityMasterState"
        );
        const authState = this.getModel("authState");

        this.addTokens(event, activityMasterState, "activity");
        this.getModel().refresh(true);
      },

      onOpenAccountFilter: async function (event) {
        const model = this.getModel();
        model.setProperty("/Accounts/results", []);
        const source = event.getSource();
        const customData = source?.getCustomData()[0];
        const key = customData?.getKey();
        if (!this.accountFilterDialog) {
          this.accountFilterDialog = await this.loadFragment({
            name: "com.melody.activity.fragments.list.AccountLookup",
          });
        }
        this.accountFilterDialog.open();
      },

      onSearchAccountFilter: async function (event) {
        const model = this.getModel();
        let accounts = [];
        const searchParam = event.getParameter("value");
        model.setProperty("/Accounts/busy", true);
        if (searchParam) {
          accounts = await this.accountState.search(searchParam);
        }
        model.setProperty("/Accounts/results", accounts);
        this.checkSelectionsInDialog("account", null, this.accountFilterDialog);
        model.setProperty("/Accounts/busy", false);
      },

      onSelectAccountFilter: function (event) {
        const model = this.getModel();
        this.addTokens(event, model, "account");
        this.getModel().refresh(true);
      },

      onOpenOpportunityFilter: async function (event) {
        const source = event.getSource();
        const customData = source?.getCustomData()[0];
        const key = customData?.getKey();
        if (!this.opportunityFilterDialog) {
          this.opportunityFilterDialog = await this.loadFragment({
            name: "com.melody.activity.fragments.list.OpportunityLookup",
          });
        }
        this.checkSelectionsInDialog(
          key,
          "opportunityState",
          this.opportunityFilterDialog
        );
        this.opportunityFilterDialog.open();
      },

      onSelectOpportunityFilter: function (event) {
        const opportunityState =
          this.getOwnerComponent().getModel("opportunityState");
        const authState = this.getModel("authState");

        this.addTokens(event, opportunityState, "opportunity");
        this.getModel().refresh(true);
      },

      onOpenLeadRequestorFilter: async function (event, key) {
        const model = this.getModel();
        model.setProperty("/key", key);
        model.setProperty("/Users/results", []);
        if (!this.requestorFilterDialog) {
          this.requestorFilterDialog = await this.loadFragment({
            name: "com.melody.activity.fragments.list.ActivityLeadRequestorLookup",
          });
        }
        this.requestorFilterDialog.open();
      },

      onSearchUser: async function (event) {
        const model = this.getModel();
        const key = model.getProperty("/key");
        let users = [];
        const searchParam = event.getParameter("value");
        model.setProperty("/Users/busy", true);
        if (searchParam) {
          const params = {
            search: searchParam,
          };
          users = await this.activityMasterState.getUsersBySearch(params);
        }
        model.setProperty("/Users/results", users);
        this.checkSelectionsInDialog(key, null, this.requestorFilterDialog);
        model.setProperty("/Users/busy", false);
      },

      onSelectUsers: function (event) {
        const model = this.getModel();
        const key = model.getProperty("/key");
        this.addTokens(event, model, key);
        this.getModel().refresh(true);
      },

      /********************** FILTER BAR FUNTIONALITY ENDS HERE ***********************************/

      onPressActiveOrArchive: function (event) {
        const model = this.getModel();
        const configurations = model.getProperty("/variant/configurations");
        this.setVariantModifiedKeys({
          key: "TAB",
          property: "",
        });
        this.executeActivityFilters();
      },

      onOpenActionMenu: async function (event) {
        const model = this.getModel();
        const source = event.getSource();
        let selectedActivity = source
          .getParent()
          .getBindingContext("activityState")
          .getObject();

        model.setProperty("/selectedActivity", selectedActivity);
        let activityState = this.activityState.getModel();
        activityState.setProperty("/loading", true);
        // model.setProperty("/actions/busy", true);
        // model.setProperty("/actions/results", [{ ItemName: "No Data", to_caction: { results: [] } }]);
        model.setProperty("/actions/results", []);

        try {
          let results = await MasterData.getActions(selectedActivity.guid);
          model.setProperty("/actions/results", results);
          if (!this.actionMenuDialog) {
            this.actionMenuDialog = await this.loadFragment({
              name: "com.melody.activity.fragments.list.ActionsMenu",
            });
          }
          this.actionMenuDialog.openBy(source);
          // model.setProperty("/actions/busy", false);
          activityState.setProperty("/loading", false);
        } catch (error) {
          model.setProperty("/actions/results", []);
          // model.setProperty("/actions/busy", false);
          activityState.setProperty("/loading", false);
        }
      },

      onSelectActionMenu: function (event) {
        let sActionId = event.getParameters("items").item.getKey();
        const model = this.getModel();
        const selectedActivity = model.getProperty("/selectedActivity");
        switch (sActionId) {
          case "00006": //Edit Registration
            this.onPressActivity(null, selectedActivity);
            break;
          case "00007": //Cancel Registration
            this.setActivityStatus("02");
            break;
          case "00008": //Change Status to "Started"
            this.setActivityStatus("16");
            break;
          case "00009": //Change Status to "Progressing"
            this.setActivityStatus("17");
            break;
          case "00010": //Change Status to "Presented"
            this.setActivityStatus("18");
            break;
          case "00012":
            break;
          case "00011":
            break;
          case "00013":
            break;
          case "01003": //DBR
            break;
          case "01000": //Archieve
            break;
          case "01001": // UnArchieve
            break;
          case "01002": //Post Demo
            break;
          default:
        }
      },

      setActivityStatus: async function (statusId) {
        const model = this.getModel();
        const configurations = model.getProperty("/variant/configurations");
        let selectedActivity = model.getProperty("/selectedActivity");
        let payload = {
          ActivityId: selectedActivity.id,
          ActivityGuid: selectedActivity.guid,
          Archived: configurations.tab === "X" ? true : false,
          Status: statusId,
          StatusChangedAt: new Date(),
        };
        payload.StatusChangedAt =
          payload.StatusChangedAt.toJSON().split(".")[0] + "Z";
        await MasterData.setActivityStatus(payload);
        this.activityState.getActivities(configurations);
      },

      //function to open any count popover
      onPressCountPopover: async function (event) {
        const source = event.getSource();
        const guid = source.data("guid");
        const type = source.data("type");
        const model = this.getModel();
        let results = [];
        model.setProperty("/countData/busy", true);
        if (!this.countPopover) {
          this.countPopover = await this.loadFragment({
            name: "com.melody.activity.fragments.list.CountDisplay",
          });
        }
        this.countPopover.openBy(source);
        if (guid) {
          switch (type) {
            case "team":
              results = await this.activityState.getTeam(guid);
              break;
            case "files":
              results = await this.activityState.getFiles(guid);
              break;
            case "additionalOpportunities":
              results = await this.activityState.getAddOpps(guid);
              break;
            case "innovations":
              results = await this.activityState.getInnovations(guid);
              break;
            case "landscapes":
              results = await this.activityState.getLandscapes(guid);
              break;
            case "showrooms":
              results = await this.activityState.getShowrooms(guid);
              break;
            case "successFactors":
              results = await this.activityState.getSuccessFactors(guid);
              break;
            case "solutions":
              results = await this.activityState.getSolutions(guid);
              break;
            default:
          }
          model.setProperty("/countData/results", results);
        }
        model.setProperty("/countData/busy", false);
      },

      onPressRegisterActivity: function () {
        // const model = this.getModel();
        // let activityListModel =
        //   this.getOwnerComponent().getModel("activityListModel");
        // activityListModel.setProperty("/layout", "EndColumnFullScreen");
        // activityListModel.setProperty("/mode", "edit");
        this.router.navTo("registerForm");
      },

      onPressActivity: function (event, activity) {
        const model = this.getModel();
        const headerModel = this.getModel("header");
        let activityListModel =
          this.getOwnerComponent().getModel("activityListModel");
        let mode = "EDIT";
        // let activityListModel =
        //   this.getOwnerComponent().getModel("activityListModel");
        // activityListModel.setProperty("/layout", "EndColumnFullScreen");
        // activityListModel.setProperty("/mode", "read");;
        headerModel.setProperty("/headerExpanded", false);
        if (!activity) {
          activity = event
            .getSource()
            .getParent()
            .getBindingContext("activityState")
            .getObject();
          mode = "READ";
        }
        model.refresh();
        headerModel.refresh();
        if (!(window.location.href.includes(activity.id))) activityListModel.setProperty("/busy", true);
        this.router.navTo("detail", {
          id: activity.id,
          mode: mode,
        });
      },

      updateProperty: function (name, isSelected) {
        this._data.map[name].selected = isSelected ? true : false;
        this._data.columns = this.getColumnsArray();
        this.updateModel();
      },

      //function to navigate to My Entries
      onPressNavToMyEntries: function () {
        this.router.navTo("MyEntries");
      },

      /********************** VIEW SETTINGS SORT/GROUP STARTS HERE ***********************************/

      /**
       * @author INDU,DARSHAN
       * @function onOpenViewSettings
       * @description function to handle opening of view settings dialog in list view
       * @param {Event} event
       */
      onOpenViewSettings: async function (event) {
        const model = this.getModel();
        const sortConfig = model.getProperty("/variant/configurations/sort");
        const groupConfig = model.getProperty("/variant/configurations/group");
        if (!this.viewSettingsDialog) {
          this.viewSettingsDialog = await this.loadFragment({
            name: "com.melody.activity.fragments.list.TableViewSettings",
          });
        }
        this.viewSettingsDialog.open();

        //TODO: NEED TO CHANGE THIS
        const sortGroupDialog = this.getView().byId(
          "activityListSortGroupDialog"
        );
        if (sortGroupDialog) {
          if (groupConfig?.groupBy) {
            sortGroupDialog.setSelectedGroupItem(groupConfig.groupBy);
          }

          if (sortConfig?.sortBy) {
            sortGroupDialog.setSelectedSortItem(sortConfig.sortBy);
          }
        }
      },

      /**
       * @author DARSHAN
       * @function handleSortGroupDialogConfirm
       * @description function to handle sorting and grouping in the table based on property selected
       * @param {Event} event
       * @param {String} tableId
       */
      onActivityListSortGroupConfirm: function (event, tableId) {
        const model = this.getModel();
        const params = event.getParameters();
        const sortConfig = model.getProperty("/variant/configurations/sort");
        const groupConfig = model.getProperty("/variant/configurations/group");

        if (params?.sortItem) {
          const key = params.sortItem.getKey();
          const isDescending = params.groupDescending;
          sortConfig.sortBy = key;
          sortConfig.sortOrderDesc = isDescending;
        } else {
          sortConfig.sortBy = "";
          sortConfig.sortOrderDesc = false;
        }

        if (params?.groupItem) {
          const key = params.groupItem.getKey();
          const isDescending = params.sortDescending;
          groupConfig.groupBy = key;
          groupConfig.groupOrderDesc = isDescending;
        } else {
          groupConfig.groupBy = "";
          groupConfig.groupOrderDesc = false;
        }

        this.setVariantModifiedKeys({
          key: "SORT",
          property: "",
        });
        this.setVariantModifiedKeys({
          key: "GROUP",
          property: "",
        });
        model.setProperty("/variant/configurations/sort", sortConfig);
        model.setProperty("/variant/configurations/group", groupConfig);
        model.refresh();
        this.handleSortGroupDialogConfirm(event, tableId);
      },

      /********************** VIEW SETTIGNS SORT/GROUP ENDS HERE ************************************/

      /********************** VARIANT MANAGEMENT STARTS HERE ***********************************/

      /**
       * @author DARSHAN
       * @function getActivityListVariants
       * @description function to get logged-in users variants to filter the data
       */
      getActivityListVariants: async function (options) {
        try {
          await this.variantState.getVariants({
            groupName: Actions.variantGroupTypes.activity,
          });
          const model = this.getModel();
          const variantState = this.getModel("variantState");
          let defaultVariant =
            variantState.getProperty("/defaultVariant") || {};

          if (defaultVariant && defaultVariant?.id !== "standard") {
            //CHECK FOR NEW PROPERTY
            const updatedVariant = this.checkNewFilterProperty(
              defaultVariant,
              Actions.variantGroupTypes.activity
            );
            if (updatedVariant) {
              defaultVariant = updatedVariant;
            }
            //CHECK FOR ARCHIEVED
            defaultVariant.configurations.tab =
              defaultVariant.configurations.tab === "X" ? "X" : "00";

            //UPDATE PERSONALIZATION
            defaultVariant.columns = this.getColumnsArray(
              defaultVariant.configurations.properties
            );
            model.setProperty("/variant", defaultVariant);
            model.setProperty(
              "/variantBackUp",
              JSON.parse(JSON.stringify(defaultVariant))
            );
            model.refresh(true);
          } else {
            //CASE WHEN NO VARIANTS ARE PRESENT
            const variant = this.getVariant();
            defaultVariant.configurations = variant.configurations;
            defaultVariant.columns = this.getColumnsArray(
              defaultVariant.configurations.properties
            );
            model.setProperty("/variant", defaultVariant);
            model.setProperty(
              "/variantBackUp",
              JSON.parse(JSON.stringify(defaultVariant))
            );
          }
        } catch (error) {
          Helper.showMessage("Something went wrong. Please try again");
          console.log("ERROR  IN getActivityListVariants : ", error);
        }
      },

      /**
       * @author DARSHAN
       * @function onSaveActivityListVariant
       * @description function to handle "save as" in variant management control
       * @param {Event} event
       */
      onSaveActivityListVariant: async function (event) {
        try {
          const params = event.getParameters();
          const variantState = this.getModel("variantState");
          const model = this.getModel();
          let configurations = model.getProperty("/variant/configurations");
          const variant = new Variant();

          await this.variantState.setVariant({
            params: params,
            variant: variant,
            filters: configurations,
            viewName: Actions.variantGroupTypes.activity,
          });
          await this.getActivityListVariants({
            groupName: Actions.variantGroupTypes.activity,
            variantId: "",
          });
          this.setVariantModifiedKeys({}, true);
          this.executeActivityFilters();
        } catch (error) {
          Helper.showMessage("Something went wrong. Please try again");
          console.log("ERROR IN onSaveActivityListVariant : ", error);
        }
      },

      /**
       * @author DARSHAN
       * @function onSelectActivityListVariant
       * @description function to handle selections of variants from the variant list
       * @param {Event} event
       */
      onSelectActivityListVariant: function (event) {
        try {
          const variantState = this.getModel("variantState");
          const model = this.getModel();
          const variants =
            variantState.getProperty("/variants/activities") || [];
          const params = event.getParameters();
          const variantKey = params.key;
          let variant =
            variants.find((data) => {
              return data.id === variantKey;
            }) || false;

          //CHECK FOR NEW PROPERTY
          const updatedVariant = this.checkNewFilterProperty(
            variant,
            Actions.variantGroupTypes.activity
          );
          if (updatedVariant) {
            variant = updatedVariant;
          }
          //CHECK FOR ARCHIEVED
          variant.configurations.tab =
            variant.configurations.tab === "X" ? "X" : "00";

          //UPDATE PERSONALIZATION
          variant.columns = this.getColumnsArray(
            variant.configurations.properties
          );
          model.setProperty("/variant", variant);
          model.setProperty(
            "/variantBackUp",
            JSON.parse(JSON.stringify(variant))
          );
          const sortConfig = model.getProperty("/variant/configurations/sort");
          const groupConfig = model.getProperty(
            "/variant/configurations/group"
          );
          if (variant?.executeOnSelect) {
            this.executeActivityFilters(); //ADD HERE METHOD TO FIRE THE FILTERS
            this.setSortGroupToTable({
              tableId: "activityTable",
              sortConfig,
              groupConfig,
            });
          }
          model.refresh(true);
          variantState.refresh();
        } catch (error) {
          Helper.showMessage("Something went wrong. Please try again");
          console.log("ERROR IN onSelectActivityListVariant : ", error);
        }
      },

      /**
       * @author DARSHAN
       * @function onManageActivityListVariant
       * @description function to handle "save" in "Manage" option in variant management control
       * @param {Event} event
       */
      onManageActivityListVariant: async function (event) {
        try {
          let updateVariant = await this.variantState.manageVariant(
            event,
            Actions.variantGroupTypes.activity
          );
          if (updateVariant) {
            await this.getActivityListVariants({
              groupName: Actions.variantGroupTypes.activity,
              variantId: "",
            });
            this.setVariantModifiedKeys({}, true);
            this.executeActivityFilters();
          }
        } catch (error) {
          Helper.showMessage("Something went wrong. Please try again");
          console.log("ERROR IN onManageActivityListVariant : ", error);
        }
      },
      /********************** VARIANT MANAGEMENT ENDS HERE ***********************************/

      /********************** PRIVATE METHODS STARTS HERE ***********************************/
      /**
       * @author  DARSHAN
       * @function setRiskValues
       * @description function to handle add or remove the risktypes in the values;
       * @param {Boolean} pressed
       * @param {String} riskType
       * @param {Array} values
       */
      setRiskValues: function (pressed, riskType, values) {
        let index;
        if (pressed) {
          values.push(riskType);
        } else {
          index = values.findIndex((status) => status === riskType);
          if (index !== -1) {
            values.splice(index, 1);
          }
        }
        return values;
      },

      /********************** PRIVATE METHODS ENDS HERE ************************************/
      deleteTeamMember: function (event) {
        let team = event.getParameter("team");
      },
      addTeamMember: function (event) {
        let team = event.getParameter("team");
      },

      onPressEmployeeInfo: function (event, employeeId) {
        this.authState.getEmployeeInfo(employeeId, event.getSource());
      },

      showDraftActivities: function () {

        this.router.navTo("drafts");
      }

    });
  }
);
