// @ts-nocheck
sap.ui.define(
  [
    "com/melody/activity/controller/BaseDetailController",
    "sap/ui/core/Fragment",
    "com/melody/activity/util/formatter",
    "com/melodylib/activity/state/ActivityState",
    "com/melodylib/core/db/IndexedDB",
    "com/melody/activity/service/MasterService",
    "sap/ui/model/Filter",
    "com/melodylib/integration/state/AccountState",
    "com/melody/activity/util/MasterData",
    "com/melodylib/integration/classes/Opportunity",
    "com/melodylib/activity/classes/Activity",
  ],
  function (
    BaseDetailController,
    Fragment,
    formatter,
    ActivityState,
    IndexedDB,
    MasterService,
    Filter,
    AccountState,
    MasterData,
    Opportunity,
    Activity
  ) {
    "use strict";

    return BaseDetailController.extend(
      "com.melody.activity.controller.Detail",
      {
        formatter: formatter,
        onInit: function () {
          this.router = this.getRouter();
          this.router.attachRoutePatternMatched(
            this.onRoutePatternMatched,
            this
          );
          this.accountState = AccountState.getInstance();
          this.activityState = ActivityState.getInstance();
          this.activityFormModel =
            this.getOwnerComponent().getModel("activityFormModel");
          this.activityStateModel =
            this.getOwnerComponent().getModel("activityState");
            this.formatter=formatter;
        },

        onRoutePatternMatched: function (event) {
          if (event.getParameter("name") === "detail") {
            // this.handleBrowserNav();
            const activityListModel = this.getOwnerComponent().getModel("activityListModel");
            activityListModel.setProperty('/busy', false)
            this.onRouteMatched(event);
            const activity = new Activity();
            this.activityStateModel.setProperty("/openedActivities", [
              activity,
            ]);
            const {mode, layout} = event.getParameter("arguments");
            let editable = mode && mode === "EDIT" ? true : false;
            this.activityFormModel.setProperty("/editable", editable);
            if(layout) this.handleFullScreen(layout)
            const id = event.getParameter("arguments").id;
            // const id = '24113'
            this.getActivityDetail(id);
            this.setFormPath("/openedActivities/0");
          }
        },

        onPressNavToListScreen: function () {
          this.activityFormModel.setProperty("/editable", false);
          this.router.navTo("list");
        },

        // function to open activity edit options popover
        onPressOpenActivityMenu: async function (event) {
          if (!this.MenuDialog) {
            this.MenuDialog = await this.loadFragment({
              name: "com.melody.activity.fragments.form.ActionMenu",
            });
          }
          this.MenuDialog.openBy(event.getSource());
        },

        // function on click of any activity action  (Edit/Cancel..)
        onMenuButtonPress: function () {
          this.activityFormModel.setProperty("/editable", true);
        },

        getActivityDetail: async function (activityId) {
          this.activityState.getActivityById(activityId);
          // this.activityStateModel.setProperty("/openedActivities", [activity]);
          // if (activity?.account?.id)  // will come from libr
          //   this.getAccountDetails(activity?.account?.id);
          // if (activity?.opportunity?.id) // will come from libr
          //   this.getOppoDetails(activity?.opportunity?.id);
          // this.getActivityTypeInfo(activity.type.id); // will come from libr
          // this.getFormLayouts(activity.layout.childId); // will come from libr
          // this.getActTypeEntities(activity.type.id) // will come from libr
        },

        //function to get selected activity type details - NOT USED
        getActivityTypeInfo: async function (typeId) {
          const formPath = this.activityFormModel.getProperty("/formPath");
          const roleId = this.activityStateModel.getProperty(
            formPath + "/roleId"
          );
          const roleMappingId = this.activityStateModel.getProperty(
            formPath + "/role/mappingId"
          );
          let filters = [new Filter("ActvtTypeID", "EQ", typeId)];
          filters.push(new Filter("RoleMpngID", "EQ", roleMappingId));
          const { data } = await MasterService.getActivityTypes(filters);
          this.activityStateModel.setProperty(
            formPath + "/type/info",
            data.results[0]?.ActivityTypeInfo
          );
        },

        // function to fetch the account details  - NOT USED
        getAccountDetails: async function (accountId) {
          // set to activityDetails/0 directly
          const formPath = this.activityFormModel.getProperty("/formPath");
          const [selectedAccount] = await this.accountState.search(accountId);
          this.activityStateModel.setProperty(
            formPath + "/account",
            selectedAccount
          );
        },

        // function to fetch the opportunity details  - NOT USED
        getOppoDetails: async function (opportunityId) {
          const formPath = this.activityFormModel.getProperty("/formPath");
          const storage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
          let opportunityData = storage.get("myopportunities_map")[
              opportunityId
            ],
            harmonyLink;
          if (!opportunityData) {
            let opportunity = new Opportunity();
            opportunityData = {};
            Object.keys(opportunity)?.forEach(
              (key) => (opportunityData[key] = "Not Authorized")
            );
            opportunityData["id"] = opportunityId;
            opportunityData["accountId"] = null;
            // opportunityData = {
            //   AccountId: null,
            //   AccountName: "Not Authorized",
            //   OpportunityId: opportunityId,
            //   OpportunityName: "Not Authorized",
            //   Description: "Not Authorized",
            //   Status: "Not Authorized",
            //   ExpectedEnd: "Not Authorized",
            //   ExpectedValue: "Not Authorized",
            //   Phase: "Not Authorized",
            //   Owner: "Not Authorized",
            //   OwnerName: "Not Authorized",
            //   Industry_MasterCode_Text: "Not Authorized",
            //   Industry: "Not Authorized",
            //   Industry_Text: "Not Authorized",
            //   Sales_Org_Desc: "Not Authorized",
            //   Industry_MasterCode: "Not Authorized",
            //   StatusDescription: "Not Authorized",
            //   Guid: "Not Authorized",
            //   ChangedAt: "Not Authorized",
            //   DisplayAuth: "Not Authorized",
            // };
          }

          // set harmony link
          let harmonyconstanturls =
            (await IndexedDB.fnGetAllDatafromDB({
              dbName: "master-data",
              storeName: "master-data-table",
              keyName: "harmonyconstanturls",
            })) || [];
          harmonyLink = harmonyconstanturls.find(
            (url) => url.id === "0011"
          ).value;

          opportunityData["harmonyLink"] = harmonyLink;
          this.activityStateModel.setProperty(
            formPath + "/opportunity",
            opportunityData
          );
        },

        // function to get entities based on the selected activity type - NOT USED
        getActTypeEntities: async function (typeId) {
          const filters = [new Filter("ActivityTypeId", "EQ", typeId)];
          const { data } = await MasterService.getActTypeEntities(filters);
          const entityString = data?.results?.length
            ? data?.results[0].EntityString
            : "";
          const entities = entityString.split(",");
          this.getAssociationsData(entities);
        },

        // function to fetch all associations data of the entities based on activity type in Detail Mode - NOT USED
        getAssociationsData: function (entities) {
          const path = this.activityFormModel.getProperty("/formPath");
          const guid = this.activityStateModel.getProperty(path + "/guid");
          const controller = this;
          entities.forEach((entity) => {
            switch (entity) {
              case "YC_MAC_T_FILE_CONTENT":
                MasterData.getAttachments(controller, guid);
                break;
            }
          });
        },

        handleFullScreen: function (layout) {
          const activityListModel =
            this.getOwnerComponent().getModel("activityListModel");
          activityListModel.setProperty("/layout", layout);
        },
      }
    );
  }
);
