sap.ui.define([
	"sap/ui/base/Object"
], function (Object) {
	"use strict";
	var ActivityColumn = Object.extend("com.melody.activity.classes.ActivityColumn", {
		constructor: function (data) {
			Object.call(this);
			this.setData(data);
		},

		setData: function (data) {
			if (data) {
                this.id = data.id ? data.id : "";
                this.visible = data.visible ? true : false;
            }
		}
	});
	return ActivityColumn;
});