/* global QUnit */

sap.ui.require(["com/melody/activity/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
