sap.ui.define([
	"commelody/activity/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
