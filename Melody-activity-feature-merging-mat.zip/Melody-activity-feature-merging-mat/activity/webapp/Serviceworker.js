// @ts-nocheck
const CACHE_NAME = "activity-cache-v1";

const aFileCache = ["./", "./index.html", "./resources/sap-ui-core.js"];

//Self is global refernce of this keyword
self.addEventListener("install", (event) => {
  console.log("Service worker installing...");
  // uncomment below line when required
  /*event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log("Opened cache");
      return cache
        .addAll(aFileCache)
        .then(() => {
          console.log("All resources have been cached");
        })
        .catch((error) => {
          console.error("Failed to cache resources:", error);
        });
    })
  );*/
  self.skipWaiting();
});

// Listen to the `activate` event to clear old caches.
self.addEventListener("activate", (event) => {
  console.log("Service Worker activating.");
  // async function deleteOldCaches() {
  //   // List all caches by their names.
  //   const names = await caches.keys();
  //   await Promise.all(
  //     names.map((name) => {
  //       if (name !== CACHE_NAME) {
  //         // If a cache's name is the current name, delete it.
  //         return caches.delete(name);
  //       }
  //     })
  //   );
  // }

  // event.waitUntil(deleteOldCaches());
});

//function which listens to fetch method of the browsers
self.addEventListener("fetch", function (event) {
  let aURLCheck = ["/zharmony_callidus_srv/", "/$metadata"];
  if (event.request.url.includes("/zharmony_callidus_srv/")
    || event.request.url.includes("/$metadata")
  ) {
    console.log("Service Worker API :", event.request.url);
    // Intercept AJAX requests
    event.respondWith(
      caches
        .match(event.request)
        .then(function (response) {
          if (response) {
            return response;
          }
          return fetch(event.request).then(function (networkResponse) {
            if (
              !networkResponse ||
              networkResponse.status !== 200 ||
              networkResponse.type !== "basic"
            ) {
              return networkResponse;
            }
            var responseToCache = networkResponse.clone();
            caches.open(CACHE_NAME).then(function (cache) {
              //HEAD,POST IS NOT SUPPORTEDF
              if (
                event.request.method &&
                ["HEAD"].indexOf(event.request.method) === -1
              ) {
                cache.put(event.request, responseToCache);
              }
            });
            return networkResponse;
          });
        })
        .catch(function (error) {
          console.error("Fetch failed:", error);
          throw error;
        })
    );
  }
});
